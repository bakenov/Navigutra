package com.anz.axle.lg.adapter.d3;

import java.util.Map;

@FunctionalInterface
public interface Subscriber {

    void onUpdate(long receivingTimeNanos, Map<String, String> rawUpdates);
}
