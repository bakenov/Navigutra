package com.anz.markets.efx.fox.processor.state.usersession;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.agrona.collections.Object2IntHashMap;

import com.anz.markets.efx.fox.api.domain.UserSession;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.api.domain.UserSessionRepository;
import com.anz.markets.efx.fox.processor.timer.Timer;

public class DefaultUserSessionRepository implements UserSessionRepository {
    private static final int MISSING_VALUE = -1;
    private final Timer.Factory timerFactory;
    private final long missedHeartbeatTimeoutMillis;
    private final Map<UserSessionKey, UserSession> userSessionMap = new HashMap<>();
    private final Object2IntHashMap<String> onlinePortfolioSessions = new Object2IntHashMap<>(MISSING_VALUE);

    public DefaultUserSessionRepository(final Timer.Factory timerFactory, final long missedHeartbeatTimeoutMillis) {
        this.timerFactory = Objects.requireNonNull(timerFactory);
        this.missedHeartbeatTimeoutMillis = missedHeartbeatTimeoutMillis;
    }

    @Override
    public int onlinePortfolioSessions(final String portfolio) {
        return Integer.max(0 , onlinePortfolioSessions.getValue(portfolio));
    }

    @Override
    public UserSession userSession(final UserSessionKey userSessionKey) {
        return userSessionMap.computeIfAbsent(userSessionKey,
                key -> new DefaultUserSession(key, timerFactory,
                        k -> onlinePortfolioSessions.put(k.portfolio(), onlinePortfolioSessions(k.portfolio()) + 1),
                        k -> onlinePortfolioSessions.put(k.portfolio(), Integer.max(0, onlinePortfolioSessions(k.portfolio()) - 1)),
                        onlinePortfolioSessions::getValue, missedHeartbeatTimeoutMillis));
    }
}
