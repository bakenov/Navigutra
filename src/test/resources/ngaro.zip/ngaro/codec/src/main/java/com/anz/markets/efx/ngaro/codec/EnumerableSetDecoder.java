package com.anz.markets.efx.ngaro.codec;

import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Decoder for an enumerable set of values. Note that the decoder implementation implicitly or explicitly defines the
 * value domain, that is, it defines all possible values {@code V}.
 *
 * @param <V> the type of a set value
 */
public interface EnumerableSetDecoder<V> {

    boolean containsAny();

    boolean contains(V value);

    void decodeTo(Consumer<? super V> consumer);

    void decodeTo(BiConsumer<? super V, ? super Boolean> consumer);

    <S extends Set<? super V>> S decodeTo(S target);
}
