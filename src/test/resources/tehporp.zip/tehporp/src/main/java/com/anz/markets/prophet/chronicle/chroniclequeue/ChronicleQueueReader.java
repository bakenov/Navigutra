package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.FatalError;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.StopException;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.StartAtSeeker;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.monitor.Monitored;
import com.anz.markets.prophet.monitor.ThreadMonitor;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSource;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import net.openhft.chronicle.core.OS;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.wire.DocumentContext;
import org.jetbrains.annotations.TestOnly;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.StreamCorruptedException;
import java.nio.BufferOverflowException;
import java.util.concurrent.ExecutorService;

public class ChronicleQueueReader implements ProphetReader, Monitored {
    // read only CQ not supported on Windows
    public static final boolean USE_READ_ONLY = SystemProperties.CQ_ALLOW_READ_ONLY && !OS.isWindows();

    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleQueueReader.class);
    private static final int FILTERED_LOG_EVENT_INTERVAL = 10_000;

    private final ExecutorService executorService;
    private final SingleChronicleQueue chronicleQueue;
    private final ExcerptTailer tailer;
    private final ReaderConfig config;

    private int ignoredCount = 0;
    private volatile boolean closing = false, readFinished = true;
    private volatile long loopStartMS;
    private volatile Thread thread;
    private volatile Context context;

    public ChronicleQueueReader(final String queuePath, final ReaderConfig config) {
        this(ThreadUtils.NoOpExecutor.INSTANCE, queuePath, config);
    }

    public ChronicleQueueReader(final ExecutorService executorService, final String queuePath, final ReaderConfig config) {
        this.executorService = executorService;
        this.chronicleQueue = ChronicleQueueFactory.createQueue(queuePath, USE_READ_ONLY, config.ringBuffer());
        this.tailer = config.tailerId() > 0 ? chronicleQueue.createTailer(Integer.toString(config.tailerId())) : chronicleQueue.createTailer();
        this.config = config;
        init();
        executorService.submit(this);
    }

    @Override
    public long loopStartMS() {
        return loopStartMS;
    }

    @Override
    public Thread thread() {
        return thread;
    }

    @Override
    public Context context() {
        return context;
    }

    private void init() {
        try {
            // if ! rb and we have chosen a tailer id (e.g. for starin chronicle.df) then don't try and move
            if (config.ringBuffer().enabled() || config.tailerId() <= 0) {
                final StartAtSeeker seeker = config.ringBuffer().enabled() ?
                        new ChronicleQueueStartAtSeekerRB(tailer, config.startPosition()) :
                        new ChronicleQueueStartAtSeeker(tailer, config.startPosition());
                config.startAt().moveToStartIndex(seeker);
            }
            LOGGER.info("Created reader from {} index {} startIndex {} config {}", chronicleQueue.fileAbsolutePath(), Long.toHexString(getTailerIndex()), Long.toHexString(chronicleQueue.firstIndex()), config);
        } catch (SeekException se) {
            close();
            throw se;
        }
    }

    @Override
    public void run() {
        this.thread = Thread.currentThread();
        ThreadMonitor.INSTANCE.addTask(this);

        LOGGER.info("Starting.");
        if (Context.context().header().getEventId() > 0) {
            // for when we create >1 ChronicleQueueReader
            LOGGER.info("NOT replacing context {}", Context.context());
        } else {
            Context.set(new Context(new TimeSourceChronicle()));
        }

        this.context = Context.context();
        final TimeSource timeSource = context.timeSource();
        final Header header = context.header();

        readFinished = false;
        do {
            if (closing) {
                continue;
            }

            // normally we would set loopStartMs when below loop has finished processing, but as we come straight back here, we can do it here
            loopStartMS = Long.MAX_VALUE;
            try (final DocumentContext dc = tailer.readingDocument()) {
                if (!dc.isPresent()) {
                    config.waitStrategy().onTailerStalled(config.pauser());
                    continue;
                }
                config.pauser().reset();

                // use real time for this
                loopStartMS = System.currentTimeMillis();
                final ProphetBytes prophetBytes = ChronicleQueueWrappers.wrapReader(dc);
                final MessageType messageType = ChronicleObjectReader.readHeader(prophetBytes, header);
                context.eventContext().saveCurrentEventTimeStamps(messageType, header);

                // UNKNOWN message handling
                if (messageType == MessageType.UNKNOWN) {
                    config.unknownReadHook().onEvent(context, messageType);
                    continue;
                }

                // set time from chronicle. Have to do this here before any filters called
                if (timeSource instanceof TimeSourceChronicle) { //TODO: work out why in some scenarios this is not a TimeSourceChronicle
                    ((TimeSourceChronicle) timeSource).setFromHeader(header.getEventTimeStampNS());
                }

                // filter out if predicate true - we can use this to filter out messages we have already processed
                if (config.headerFilter().apply(header, getTailerIndex(), messageType)) {
                    if ((ignoredCount++ % FILTERED_LOG_EVENT_INTERVAL) == 0) {
                        LOGGER.info("Filtered {}", ignoredCount);
                    }
                    continue;
                }

                config.startReadHook().onEvent(context, messageType);
                config.chronicleObjectReader().processEntity(prophetBytes, messageType);
                config.endReadHook().onEvent(context, messageType);
            } catch (Error | FatalError t) {
                closing = true;
                LOGGER.error("FatalError. Stop reading. Index=" + getTailerIndex(), t);
            } catch (StopException t) {
                closing = true;
                // don't log exception stack trace
                LOGGER.warn("StopException received. Index={} message {}", Long.toHexString(getTailerIndex()), t.getMessage());
            } catch (Throwable t) {
                if (isFatal(t)) {
                    closing = true;
                    LOGGER.error("Fatal throwable. Stop reading. Index={}", getTailerIndex(), t);
                } else {
                    LOGGER.error("Exception processing message. Index={}", getTailerIndex(), t);
                }
            }
        } while (!closing);

        LOGGER.info("Finishing tailer index {} ", Long.toHexString(getTailerIndex()));
        readFinished = true;
        LOGGER.warn("Finished");
        net.openhft.chronicle.core.io.Closeable.closeQuietly(config.chronicleObjectReader());
        ThreadMonitor.INSTANCE.removeTask(this);
    }

    long getTailerIndex() {
        return tailer.index();
    }

    private boolean isFatal(final Throwable t) {
        // NOTE: Not sure if this is still true, will park here in case.

        // we currently are seeing StreamCorruptedException sometimes when reading  ConfigurationData
        // and this is a subclass of IOException but does not indicate a problem with the chronicle, just the message
        return ((t instanceof IllegalStateException) && ((t.getCause() instanceof IOException) && !(t.getCause() instanceof StreamCorruptedException))) ||
                (t instanceof BufferOverflowException);
    }

    @Override
    public void close() {
        if (chronicleQueue.isClosed()) {
            LOGGER.info("Already closed");
            return;
        }
        this.closing = true;
        LOGGER.info("Closing reader config {}", config);
        int maxIterations = 10;
        while ((! readFinished) && maxIterations-- > 0) {
            ThreadUtils.sleep(500);
            LOGGER.info("Waiting to finish reading.");
        }
        if (! readFinished) {
            LOGGER.warn("Reading did not finish");
        }
        executorService.shutdown();
        chronicleQueue.close();
        LOGGER.info("Closed");
    }

    @TestOnly
    @Override
    public String toString() {
        return "ChronicleQueueReader{" +
                "config=" + config +
                ", ignoredCount=" + ignoredCount +
                '}';
    }
}
