package com.anz.markets.prophet.atest.disco;

import com.anz.markets.disco.config.DiscoPFPConfig;
import com.anz.markets.disco.data.Signal;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.modules.DiscoveryModule;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


public class DiscoTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault configuration1() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,
                "constituentMarkets", Markets.getMarkets(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),  // <- legacy format test
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        // Add config to test pre-aggregation EURUSD.
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, new Markets[]{Markets.getMarkets(Market.HSP, Market.LMAXP), Markets.getMarkets(Market.EBS, Market.OCX), Markets.getMarkets(Market.FASTMATCH) },
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoPFPConfig.FEATURE_NAME, priceFormationPipelineConfig);
        return configuration;
    }

    private ConfigurationDataDefault configuration2() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoPFPConfig.FEATURE_NAME, priceFormationPipelineConfig);
        return configuration;
    }

    @Test
    @RestartBeforeTest(reason = "Clear state.")
    public void basico_discover() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));
            assertThat(signals.getMarket(), is(Market.WSP_MU));
            assertThat(signals.getInstrument(), is(Instrument.AUDUSD));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CBID));
            assertThat(signal1.getValue(), is(0.7503));
            assertThat(signal1.getConditionCode(), is(Symbol.get("CXXX_CXXXXXX_C")));

            final Signal signal2 = signals.getSignal(1);
            assertThat(signal2.getSignalType(), is(SignalType.CASK));
            assertThat(signal2.getValue(), is(0.7505));
            assertThat(signal2.getConditionCode(), is(Symbol.get("CXXX_CXXXXXX_C")));

            // Virtual snapshot.
            final FilteredMarketDataSnapshot mds = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_MU)).getLast();
            assertThat(mds.getBidEventList().size(), Matchers.is(1));
            assertThat(mds.getOfferEventList().size(), Matchers.is(1));
            assertThat(mds, isMarketPricePoint(0, Level.QTY_1M, 0.75030, Level.QTY_1M, 0.75050));
        }

        // No change, no output.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
        }

        // Bid change only.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(1));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CBID));
            assertThat(signal1.getValue(), is(0.7502));
            assertThat(signal1.getConditionCode(), is(Symbol.get("CXXX_CXXXXXX_C")));
        }

        // Ask change only.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(1));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CASK));
            assertThat(signal1.getValue(), is(0.7504));
            assertThat(signal1.getConditionCode(), is(Symbol.get("CXXX_CXXXXXX_C")));
        }

        // Second player arrives, no price change - don't publish even though cc changed.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.LMAXP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75000, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
        }

        // New player ask changes cluster ask
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.LMAXP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75000, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(1));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CASK));
            assertThat(signal1.getValue(), is(0.7503));
            assertThat(signal1.getConditionCode(), is(Symbol.get("CCXX_CCXXXXX_C")));
        }


        // Three players, records outlier.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.OCX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.71000, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.79030, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));

            final Signal signal0 = signals.getSignal(0);
            assertThat(signal0.getSignalType(), is(SignalType.CBID));
            assertThat(signal0.getValue(), is(0.5 * (0.75000 + 0.75020)));
            assertThat(signal0.getConditionCode(), is(Symbol.get("CCX#_CCXCXXX_C")));

            final Signal signal1 = signals.getSignal(1);
            assertThat(signal1.getSignalType(), is(SignalType.CASK));
            assertThat(signal1.getValue(), is(0.5 * (0.75030 + 0.75040)));
            assertThat(signal1.getConditionCode(), is(Symbol.get("CCX#_CCXCXXX_C")));
        }

        // Three players, but no outlier because equidistant.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.OCX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.7498, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.7502, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));

            final Signal signal0 = signals.getSignal(0);
            assertThat(signal0.getSignalType(), is(SignalType.CBID));
            assertThat(signal0.getValue(), is((0.75000 + 0.75020 + 0.7498) / 3.0));
            assertThat(signal0.getConditionCode(), is(Symbol.get("CCXC_CCXCXXX_C")));

            final Signal signal1 = signals.getSignal(1);
            assertThat(signal1.getSignalType(), is(SignalType.CASK));
            assertThat(signal1.getValue(), is((0.75030 + 0.75040 + 0.7502) / 3.0));
            assertThat(signal1.getConditionCode(), is(Symbol.get("CCXC_CCXCXXX_C")));
        }

        // Test config change.
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration2(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.71030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.71050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));
            assertThat(signals.getMarket(), is(Market.WSP_MU));
            assertThat(signals.getInstrument(), is(Instrument.AUDUSD));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CBID));
            assertThat(signal1.getValue(), is(0.7103));
            assertThat(signal1.getConditionCode(), is(Symbol.get("C_C_C")));

            final Signal signal2 = signals.getSignal(1);
            assertThat(signal2.getSignalType(), is(SignalType.CASK));
            assertThat(signal2.getValue(), is(0.7105));
            assertThat(signal2.getConditionCode(), is(Symbol.get("C_C_C")));

            // Virtual snapshot.
            final FilteredMarketDataSnapshot mds = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_MU)).getLast();
            assertThat(mds.getBidEventList().size(), Matchers.is(1));
            assertThat(mds.getOfferEventList().size(), Matchers.is(1));
            assertThat(mds, isMarketPricePoint(0, Level.QTY_1M, 0.71030, Level.QTY_1M, 0.71050));
        }


        // Test that removing config stops disco output.
        given:
        {
            final ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
            prophet.receive(configuration, false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.74050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
            prophet.expect(FilteredMarketDataSnapshot.class, exactly(0), isMarket(Market.WSP_MU));
            prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP));
        }

    }


    @Test
    @RestartBeforeTest(reason = "Clear state.")
    public void test_pre_aggregation() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.LMAXP, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75060, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));
            assertThat(signals.getMarket(), is(Market.WSP_MU));
            assertThat(signals.getInstrument(), is(Instrument.EURUSD));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CBID));
            assertThat(signal1.getValue(), is(0.7502));
            assertThat(signal1.getConditionCode(), is(Symbol.get("(XC)(XX)X__C")));

            final Signal signal2 = signals.getSignal(1);
            assertThat(signal2.getSignalType(), is(SignalType.CASK));
            assertThat(signal2.getValue(), is(0.7506));
            assertThat(signal2.getConditionCode(), is(Symbol.get("(XC)(XX)X__C")));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));
            assertThat(signals.getMarket(), is(Market.WSP_MU));
            assertThat(signals.getInstrument(), is(Instrument.EURUSD));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CBID));
            assertThat(signal1.getValue(), is(0.7503));
            assertThat(signal1.getConditionCode(), is(Symbol.get("(CC)(XX)X__C")));

            final Signal signal2 = signals.getSignal(1);
            assertThat(signal2.getSignalType(), is(SignalType.CASK));
            assertThat(signal2.getValue(), is(0.7505));
            assertThat(signal2.getConditionCode(), is(Symbol.get("(CC)(XX)X__C")));
        }


        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.OCX, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75060, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(1));
            assertThat(signals.getInstrument(), is(Instrument.EURUSD));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CBID));
            assertThat(signal1.getValue(), is(0.7504));
            assertThat(signal1.getConditionCode(), is(Symbol.get("(CC)(XC)X__C")));
        }


        // Add FASTMATCH to test # cc
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.FASTMATCH, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75065, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(1));
            assertThat(signals.getInstrument(), is(Instrument.EURUSD));

            final Signal signal1 = signals.getSignal(0);
            assertThat(signal1.getSignalType(), is(SignalType.CASK));
            assertThat(signal1.getValue(), isNear(0.750625));
            assertThat(signal1.getConditionCode(), is(Symbol.get("(##)(XC)C__C")));
        }
    }


}