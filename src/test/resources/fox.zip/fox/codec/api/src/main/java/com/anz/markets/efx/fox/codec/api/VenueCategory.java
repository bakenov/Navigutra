package com.anz.markets.efx.fox.codec.api;

import java.util.function.Consumer;

public enum VenueCategory {
    BANK,
    INTERBANK,
    MATCHING_AGENT;

    private static final VenueCategory[] VALUES = values();

    public static final int length() {
        return VALUES.length;
    }

    public static final VenueCategory valueByOrdinal(final int ordinal) {
        return VALUES[ordinal];
    }

    public static void forEach(final Consumer<? super VenueCategory> consumer) {
        for (final VenueCategory value : VALUES) {
            consumer.accept(value);
        }
    }
}
