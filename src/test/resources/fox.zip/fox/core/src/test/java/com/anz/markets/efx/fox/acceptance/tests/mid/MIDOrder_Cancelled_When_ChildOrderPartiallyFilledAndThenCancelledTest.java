package com.anz.markets.efx.fox.acceptance.tests.mid;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.NewOrderSingleMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

@RunWith(Spockito.class)
public class MIDOrder_Cancelled_When_ChildOrderPartiallyFilledAndThenCancelledTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MIDOrder_Cancelled_When_ChildOrderPartiallyFilledAndThenCancelledTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private MarketDataFactory marketDataFactory = new MarketDataFactory();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_fill_partially_and_cancel_mid_order() throws Exception {

        final InstrumentKey instrumentKey = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "GB:lg-fxall";
        sorEndpoint.tradingRequest().add(heartbeat);

        final Venue market = Venue.FXALLMB;
        final String clOrdId = "3452435";
        final OrderType orderType = OrderType.MARKET;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 0;
        final double quantity = 1000000;
        final TimeInForce timeInForce = TimeInForce.DAY;
        final String senderCompId = "PROPHET.HEDGER_MID_FXALL_GB";
        final String targetCompId = "GB:fox";

        final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
        order.body.senderCompId = senderCompId;
        order.body.targetCompId = targetCompId;
        order.body.transactTime = acceptanceContext.precisionClock().nanos();
        order.body.timeInForce = timeInForce;
        order.body.orderQty = quantity;
        order.body.clOrdId = clOrdId;
        order.body.currency = currency;
        order.body.ordType = orderType;
        order.body.price = price;
        order.body.targetStrategyName = "MID";
        order.body.securityType = instrumentKey.securityType();
        order.body.settlCurrency = currency;
        order.body.side = side;
        order.body.symbol = instrumentKey.symbol();
        order.body.settlType = instrumentKey.tenor();
        order.parties.add(new Party(PartyRole.USER_NAME, "autotrader-MidHedger"));
        order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
        order.strategyParameters.add(new StrategyParameter("Markets", market.name()));

        sorEndpoint.tradingRequest().add(order);

        snapshots.forEach((venue, snapshotFullRefresh) -> {
            Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                    .matching(SnapshotFullRefreshMatcher.build()
                            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(snapshotFullRefresh.body.senderCompId))
                            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(venue))
                            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId())))
                    .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
        });

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(order.body.senderCompId))
                        .body().matches(NewOrderSingleMatcher.targetCompId().eq(order.body.targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.quoteId().eq(order.body.quoteId))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.targetStrategyName().eq(order.body.targetStrategyName))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterName().eq("Markets"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterValue().eq("FXALLMB"))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                .body().matches(ExecutionReportMatcher.targetCompId().eq(senderCompId))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                .regulatoryTradeIds().countEquals(0);


        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(15, TimeUnit.SECONDS);

        final VenueEndpoint fxallVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.FXALLMB);
        //Expect NewOrderSingle on FXALLMB venue
        final TradingMessage venueNos = Asserter.of(fxallVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueNos.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onNewOrderSingle(final NewOrderSingle nos) {

                final ExecutionReport executionReport1 = fxallVenue.createExecutionReport();

                executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport1.body.timeInForce = nos.body.timeInForce;
                executionReport1.body.marketId = nos.body.marketId;
                executionReport1.body.orderQty = nos.body.orderQty;
                executionReport1.body.orderId = "2345";
                executionReport1.body.clOrdId = nos.body.clOrdId;
                executionReport1.body.origClOrdId = nos.body.clOrdId;
                executionReport1.body.execId = "4567";
                executionReport1.body.quoteId = nos.body.quoteId;
                executionReport1.body.currency = nos.body.currency;
                executionReport1.body.ordType = nos.body.ordType;
                executionReport1.body.price = nos.body.price;
                executionReport1.body.securityType = nos.body.securityType;
                executionReport1.body.senderCompId = "GB:lg-fxall";
                executionReport1.body.targetCompId = senderCompId;
                executionReport1.body.settlCurrency = nos.body.currency;
                executionReport1.body.side = nos.body.side;
                executionReport1.body.symbol = nos.body.symbol;
                executionReport1.body.execType = ExecType.TRADE;
                executionReport1.body.ordStatus = OrderStatus.PARTIALLY_FILLED;
                executionReport1.body.leavesQty = nos.body.orderQty / 2;
                executionReport1.body.cumQty = nos.body.orderQty / 2;
                executionReport1.body.lastQty = nos.body.orderQty / 2;
                executionReport1.body.lastPx = 0.3453;

                final ExecutionReport executionReport2 = fxallVenue.createExecutionReport();
                executionReport2.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport2.body.timeInForce = nos.body.timeInForce;
                executionReport2.body.marketId = nos.body.marketId;
                executionReport2.body.orderQty = nos.body.orderQty;
                executionReport2.body.orderId = "2345";
                executionReport2.body.clOrdId = nos.body.clOrdId;
                executionReport2.body.origClOrdId = nos.body.clOrdId;
                executionReport2.body.execId = "4568";
                executionReport2.body.quoteId = nos.body.quoteId;
                executionReport2.body.currency = nos.body.currency;
                executionReport2.body.ordType = nos.body.ordType;
                executionReport2.body.price = nos.body.price;
                executionReport2.body.securityType = nos.body.securityType;
                executionReport2.body.senderCompId = "GB:lg-fxall";
                executionReport2.body.targetCompId = senderCompId;
                executionReport2.body.settlCurrency = nos.body.currency;
                executionReport2.body.side = nos.body.side;
                executionReport2.body.symbol = nos.body.symbol;
                executionReport2.body.execType = ExecType.CANCELED;
                executionReport2.body.ordStatus = OrderStatus.CANCELED;
                executionReport2.body.leavesQty = 0;
                executionReport2.body.cumQty = nos.body.orderQty / 2;
                executionReport2.body.lastQty = 0;
                executionReport2.body.lastPx = 0;

                fxallVenue.tradingResponse().add(executionReport1);
                fxallVenue.tradingResponse().add(executionReport2);
            }
        });

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.targetCompId().eq(senderCompId))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PARTIALLY_FILLED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .body().matches(ExecutionReportMatcher.cumQty().eq(quantity / 2))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(quantity / 2))
                ).thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.targetCompId().eq(senderCompId))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .body().matches(ExecutionReportMatcher.cumQty().eq(quantity / 2))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0.0d))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }
}
