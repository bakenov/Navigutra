package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringEncoders;

public final class SbeVenueConfigEncoder implements VenueConfigEncoder, VenueConfigEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder venueConfigEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();
    private final EnumerableSetEncoder<VenueConfigEncoder.Body, VenueCategory> venueCategories = new SbeVenueCategorySetEncoder<>(this,
            venueConfigEncoder::venueCategories);
    private final StringEncoder<Body> compId = StringEncoders.forFixedLength(this,
            venueConfigEncoder::compId, com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder.compIdLength());

    private EncodingOrder.VenueConfig encodingOrder = EncodingOrder.VenueConfig.INITIAL;

    SbeVenueConfigEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                          final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        venueConfigEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.VenueConfig.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        venueConfigEncoder.buffer().setMemory(offset, venueConfigEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public Body venue(final Venue venue) {
        encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
        venueConfigEncoder.venue(Enums.venue(venue));
        return this;
    }

    @Override
    public StringEncoder<Body> compId() {
        encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
        return compId;
    }

    @Override
    public EnumerableSetEncoder<Body, VenueCategory> venueCategories() {
        encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
        return venueCategories;
    }

    @Override
    public Trailer enabled(final boolean enabled) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.VenueConfig.TRAILER);
        venueConfigEncoder.enabled(enabled ? YesNo.YES : YesNo.NO);
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.VenueConfig.TRAILER);
                message.messageLength(headerLength + venueConfigEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.VenueConfig.INITIAL;
                headerEncoder.wrap(null, 0);
                venueConfigEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
