package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsItemConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsWideningConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.RiskAdjustedFactor;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.domain.Country;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.wholesale.spreads.EconomicsNewsSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.RiskAdjustedSpreadStrategy;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class ModelSpread_Combined_Test extends BaseAcceptanceSpecification {

    private Instrument driverPairA = Instrument.AUDUSD;
    private EconNews econNewsAUD;

    private ConfigurationDataDefault setUpConfiguration() {

        econNewsAUD = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now());

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
                .setEconNewsItemConfigs(
                        new EconNewsItemConfigImpl(econNewsAUD.getCode(), EconNewsWeight.W_5, Currency.AUD)
                )
                .setEconNewsWideningConfigs(
                        new EconNewsWideningConfigImpl(EconNewsWeight.W_5, 1.25, 1000, 1000, false, Market.ANY)
                )
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, true))
                .setRiskAdjustedSpreadParams(Arrays.asList(
                        new RiskAdjustedFactor(0.0, 0.0),
                        new RiskAdjustedFactor(0.5, 1.25),
                        new RiskAdjustedFactor(1.0, 1.5),
                        new RiskAdjustedFactor(1.4, 2.0),
                        new RiskAdjustedFactor(2.0, 3.0)
                ))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 3000000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7500000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 7500000.0)
                ))
                // disable Mid Skewing
                .setPricingModels(
                        Arrays.asList(
                                new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                        ));

        return configuration;
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_4_5_2})
    @DisplayName("Model Bid Spread from Risk Adjusted factor + Model Offer Spread from Econ News factor")
    @RestartBeforeTest(reason = "Widening needs restart.")
    public void model_spread_from_risk_adjusted_bid_econ_news_adjusted_offer() {

        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration());
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003)); // no OP change as position=0

            // Trigger : position created
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
        }

        then:
        {
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            assertThat(optimalPositionsUpdate, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 5000000, 4822047.659692364, 3621357.792428965, 6976028.347724075, 5238997.28914078, 0.130592, 0.75100)));

            prophet.clearOutputBuffer();
        }

        when:
        {   // send econ news
            prophet.receive(econNewsAUD);

            // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75101, 0.00004));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(driverPairA)).getFirst();
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(3), isWholesaleBookFactors(driverPairA)).getFirst();

            assertThat(wbf.getMarket(), Is.is(Market.WSP_A));
            assertThat(wbf.getSkewedMidPrice(), Is.is(0.75101));
            assertThat(wbf.getBaseSpread(), isNear(0.3));

            assertThat(wbf.getRiskAdjustedWideningBidFactor(),isNear(1.5));
            assertThat(wbf.getRiskAdjustedWideningOfferFactor(), isNear(Double.NaN));

            assertThat(wbf.getEconNewsWideningFactor(), isNear(1.25));

            assertThat(wbf.getOverallBidSpreadInPips(), isNear(0.225));  // from Risk Adjusted factor
            assertThat(wbf.getOverallOfferSpreadInPips(), isNear(0.1875));   // from News Factor which is > than Risk Adjusted(0.15)

            assertThat(wbf.getOverallSpreadInPips(), isNear(0.4125));
            assertThat(wbf.getOverallWideningFactor(), isNear(1.375));

            assertThat(wbf.getModelSpread(), isNear(0.4125));
            assertThat(wbf.getBidSpreadModelSpreadRatio(), isNear(0.54545));
            assertThat(wbf.getOfferSpreadModelSpreadRatio(), isNear(0.45455));

            FeatureTraceLine ftlRisk =  wbf.getPliableBookTrace().getFeatureTrace(RiskAdjustedSpreadStrategy.FEATURE_NAME);
            assertThat(ftlRisk.bidStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftlRisk.offerStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftlRisk.getNumOperationLines(), Matchers.is(1));
            assertThat(ftlRisk.operations[0].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftlRisk.operations[0].var, Matchers.is(PliableBookVariable.BID_SPREAD_IN_PIPS));
            assertThat(ftlRisk.operations[0].oldVal, Matchers.is(0.15));
            assertThat(ftlRisk.operations[0].newVal, isRoundedTo(0.225));

            FeatureTraceLine ftlEconNews =  wbf.getPliableBookTrace().getFeatureTrace(EconomicsNewsSpreadStrategy.FEATURE_NAME);
            assertThat(ftlEconNews.bidStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftlEconNews.offerStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftlEconNews.getNumOperationLines(), Matchers.is(1));
            assertThat(ftlEconNews.operations[0].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftlEconNews.operations[0].var, Matchers.is(PliableBookVariable.OFFER_SPREAD_IN_PIPS));
            assertThat(ftlEconNews.operations[0].oldVal, Matchers.is(0.15));
            assertThat(ftlEconNews.operations[0].newVal, isRoundedTo(0.1875));

            assertThat(clientPrice.getBids().size(), Is.is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.75098750, 0.75102875));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.75096500, 0.75104750));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.75095375, 0.75105688));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.75093500, 0.75107250));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.75085182, 0.75114182));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.75078636, 0.75119636));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.75068818, 0.75127818));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.75064455, 0.75131455));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.75050273, 0.75143273));
            assertThat(clientPrice.getDominantFeatureBid().toString(), is(ftlRisk.featureShortCode));
            assertThat(clientPrice.getDominantFeatureOffer().toString(), is(ftlEconNews.featureShortCode));
        }

    }

}
