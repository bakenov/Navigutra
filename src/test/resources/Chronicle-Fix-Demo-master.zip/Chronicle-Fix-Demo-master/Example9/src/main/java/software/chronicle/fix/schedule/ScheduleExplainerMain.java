package software.chronicle.fix.schedule;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.parsers.MessageParser;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.fix.staticcode.schedule.*;

import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;

public final class ScheduleExplainerMain {
    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(
                FixEngineCfg.class,
                FixSessionCfg.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                StandardSessionScheduleCfg.class,
                ArbitrarySessionCfg.class,
                AlwaysActiveSessionSchedule.class,
                MessageParser.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main(String[] args) throws IOException {
        final FixEngineCfg cfg = Marshallable.fromFile(args.length == 0 ? "schedules.yaml" : args[0]);

        new ScheduleExplainerMain().printSessionSchedules(cfg);
    }

    private void printSessionSchedules(final FixEngineCfg cfg) {
        final StringWriter summary = new StringWriter();
        summary.append("\n\nSummary of example schedules in config file\n\n");

        cfg.fixSessionCfgs().forEach(sessionCfg -> {
            summary.append(String.format("Example schedule for %s/%s%n",
                    sessionCfg.senderCompID(), sessionCfg.targetCompID()));
            final SessionScheduleActionProvider provider = sessionCfg.sessionScheduleActionProvider();

            if (provider instanceof AlwaysActiveSessionSchedule) {
                summary.append("Session is always active\n");
                return;
            }

            final ZonedDateTime startPoint =
                    LocalDateTime.of(2019, 5, 5, 6, 0).
                            atZone(ZoneId.systemDefault());

            final AtomicBoolean sessionStarted = new AtomicBoolean(false);
            final AtomicReference<ZonedDateTime> systemTime = new AtomicReference<>(startPoint);

            final BiConsumer<ZonedDateTime, ScheduleAction> consumer = (timestamp, action) -> {
                summary.append(
                        String.format(" %5s, next change at %9s@%s on %s in %s%n", action,
                                timestamp.getDayOfWeek(), timestamp.toLocalTime(),
                                timestamp.toLocalDate(), timestamp.getZone().getId()));

                boolean newState = action == ScheduleAction.START;

                sessionStarted.set(newState);
                systemTime.set(timestamp.plusNanos(1));
            };

            for (int i = 0; i < 20; i++) {
                final ZonedDateTime timestamp = systemTime.get();
                summary.append(String.format("State at %9s@%s on %s -> ",timestamp.getDayOfWeek(), timestamp.toLocalTime(),
                        timestamp.toLocalDate()));
                provider.getNextStateChange(consumer, timestamp);
            }

            summary.append("\n\n");
        });

        System.out.println(summary);
    }
}
