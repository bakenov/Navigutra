package com.anz.axle.lg.adapter.d3.acceptance;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.Message;
import de.digitec.d3.pricing.streaming.UpdateMessage;
import de.digitec.d3.pricing.streaming.impl.ErrorMessageImpl;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.SubscriptionRequestType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.MarketDataRequest;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class SubscribeUnsubscribeIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SubscribeUnsubscribeIntegrationTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;

    final private String senderCompId = "GB:lg-d3";
    final private Venue marketId = Venue.D3;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());

        System.setProperty("retry.task.millis", "200");
        System.setProperty("expire.task.millis", "200");
        System.setProperty("retry.subscription.seconds", "1");
        System.setProperty("appName", "lg-d3");

        application = new Application("lg-d3", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.throwableQueue().clear();
        acceptanceContext.updateMessageQueue().clear();
        acceptanceContext.pricingRequestMessageQueue().clear();
        acceptanceContext.errorMessageQueue().clear();
        acceptanceContext.subscriptionRequestQueue().clear();
        acceptanceContext.pricingMessageQueue().clear();
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_receive_market_data_request_then_price_and_then_expire() throws Exception {
        //given
        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 2000;

        final MarketDataRequest marketDataRequest = new MarketDataRequest();
        marketDataRequest.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest.body.mdReqId = 1;
        marketDataRequest.body.marketId = marketId;
        marketDataRequest.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest.body.expireTime = exprireTime;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest);

        final SubscriptionRequest subscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Subscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(subscribeRequest, notNullValue());
        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        final UpdateMessage updateMessage = UpdateMessageBuilder.defaultMessage()
                .withSubscriptionId(subscribeRequest.subscriptionId())
                .withCurrencies(symbol.substring(0, 3), symbol.substring(3))
                .withTenor("")
                .withSettlementDate(settlmentDate)
                .build();

        acceptanceContext.updateMessageQueue().add(updateMessage);

        PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                .entries().countAtLeast(1)
                .hops().hasAny()
                .hops().countAtLeast(2))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        LOGGER.info("======= {} ======", message);
        acceptanceContext.pricingMessageQueue().clear();

        final SubscriptionRequest unsubscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Unsubscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.UNSUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.subscriptionId().eq(subscribeRequest.subscriptionId())))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        PricingMessage emptySnapshot = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                        .entries().countEquals(0)
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

    @Test
    public void should_receive_market_data_request_then_error_and_then_resubscribe() throws Exception {
        //given
        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 2000000;

        final MarketDataRequest marketDataRequest = new MarketDataRequest();
        marketDataRequest.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest.body.mdReqId = 1;
        marketDataRequest.body.marketId = marketId;
        marketDataRequest.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest.body.expireTime = exprireTime;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest);

        final SubscriptionRequest subscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Initial")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(subscribeRequest, notNullValue());
        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        final ErrorMessage errorMessage = new ErrorMessageImpl(subscribeRequest.subscriptionId(), Message.ERROR, "Some error");

        acceptanceContext.subscriptionRequestQueue().clear();

        acceptanceContext.errorMessageQueue().add(errorMessage);

        Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Second")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

    }

    @Test
    public void should_receive_market_data_request_then_exception_and_then_resubscribe() throws Exception {

        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 2000000;

        final MarketDataRequest marketDataRequest = new MarketDataRequest();
        marketDataRequest.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest.body.mdReqId = 1;
        marketDataRequest.body.marketId = marketId;
        marketDataRequest.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest.body.expireTime = exprireTime;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest);

        final SubscriptionRequest request = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Initial")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(request, notNullValue());
        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        acceptanceContext.subscriptionRequestQueue().clear();

        acceptanceContext.throwableQueue().add(new RuntimeException("exception: something went really bad"));

        //then expect to resubscribe
        final SubscriptionRequest secondRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Second")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(secondRequest, notNullValue());
    }

    @Test
    public void should_receive_two_market_data_requests_then_price_and_then_extend_expire() throws Exception {

        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 2000;


        final MarketDataRequest marketDataRequest1 = new MarketDataRequest();
        marketDataRequest1.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest1.body.mdReqId = 1;
        marketDataRequest1.body.marketId = marketId;
        marketDataRequest1.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest1.body.expireTime = exprireTime;

        final MarketDataRequest marketDataRequest2 = new MarketDataRequest();
        marketDataRequest2.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest2.body.mdReqId = 2;
        marketDataRequest2.body.marketId = marketId;
        marketDataRequest2.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest2.body.expireTime = exprireTime + 5000;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest1);

        final List<SubscriptionRequest> subscribeRequests = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Initial")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetAll(10, TimeUnit.SECONDS);

        Assert.assertEquals(1, subscribeRequests.size());

        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        final UpdateMessage updateMessage = UpdateMessageBuilder.defaultMessage()
                .withSubscriptionId(subscribeRequests.get(0).subscriptionId())
                .withCurrencies(symbol.substring(0, 3), symbol.substring(3))
                .withTenor("")
                .withSettlementDate(settlmentDate)
                .build();

        acceptanceContext.updateMessageQueue().add(updateMessage);

        PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest1.body.instrumentId))
                        .entries().countAtLeast(1)
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        LOGGER.info("======= {} ======", message);

        acceptanceContext.pricingMessageQueue().clear();

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest2);

        PricingMessage forwardedSnapshot = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest1.body.instrumentId))
                        .entries().countAtLeast(1)
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
        acceptanceContext.pricingMessageQueue().clear();


        // Shouldn't receive an unsubscribe message for the first market data request
        // as the expire time is extended

        Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Not-matching")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.UNSUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.subscriptionId().eq(subscribeRequests.get(0).subscriptionId())))
                .awaitNotMatching(5, TimeUnit.SECONDS);

        // Now receive an unsubscribe request for the extended time
        Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Matching")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.UNSUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.subscriptionId().eq(subscribeRequests.get(0).subscriptionId())))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        PricingMessage emptySnapshot = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest1.body.instrumentId))
                        .entries().countEquals(0)
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

    }
}