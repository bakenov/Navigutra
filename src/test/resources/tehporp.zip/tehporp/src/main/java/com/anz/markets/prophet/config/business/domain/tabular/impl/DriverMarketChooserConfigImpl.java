package com.anz.markets.prophet.config.business.domain.tabular.impl;


import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.DriverMarketChooserConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

public class DriverMarketChooserConfigImpl implements DriverMarketChooserConfig, ProphetMarshallable {

    private Instrument instrument;
    private Market market;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    public DriverMarketChooserConfigImpl() {
    }

    public DriverMarketChooserConfigImpl(final Instrument instrument, final Market market) {
        GcFriendlyAssert.notNull(instrument, "DriverMarketChooserConfig Instrument can NOT be set to null.");
        GcFriendlyAssert.notNull(market, "DriverMarketChooserConfig Market can NOT be set to null.");
        GcFriendlyAssert.isFalse(market == Market.ANY, "DriverMarketChooserConfig can NOT specify ANY market.");

        this.instrument = instrument;
        this.market = market;
    }

    @Override
    public Instrument getInstrument() {
        return this.instrument;
    }

    @Override
    public Market getMarket() {
        return this.market;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        //Should not get here.
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeShort(this.instrument.getValue());
        out.writeByte(this.market.getValue());
    }

    public static ProphetMarshallable constructReadMarshallable(final ProphetBytes in) {
        return new DriverMarketChooserConfigImpl(
                Instrument.readMarshallableValueOf(in),
                Market.valueOf(in.readByte())
        );
    }

    @Override
    public String toString() {
        return "DriverMarketChooserConfigImpl{" +
                "instrument=" + instrument +
                ", market=" + market +
                '}';
    }
}
