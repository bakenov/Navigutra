package com.anz.markets.prophet.atest.pricing._1b_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@DisplayName("Aggbook should be independent of each others WSP_U, WSP_R")
@RestartBeforeTest(reason = "Price filter maintain states")
public class AggBookIndependence extends BaseAcceptanceSpecification {
    @Test
    public void differentMarketsButNoFilterFailed() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 2)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY)
                            )
                    )
                    .setMarketConfigs(Lists.newArrayList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                            new MarketConfigImpl(Market.EBS).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                            new MarketConfigImpl(Market.CITI).setRegion(Region.GB).setInstrument(Instrument.USDCAD)
                            )
                    )
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX,Market.EBS,Market.CITI)
                    .addAggBook(Market.WSP_R,Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,Market.EBS,Market.CITI)
                    .setPassiveHedgerConfigs(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.USDCAD, 0.9450, 0.9700));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CITI, Instrument.USDCAD, 0.9500, 0.9800));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.EBS, Instrument.USDCAD, 0.9600, 0.9900));
        }
        then:
        // wsp_u
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U));

            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));

            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.CITI));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CNX));

            nextMarketData = marketDataSnapshots.get(2);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.EBS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CNX));
        }
        then:
        // wsp_raw
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(2), isMarket(Market.WSP_R));
            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));

            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.EBS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CITI));
        }
    }


    @Test
    public void slowestMarketFilterFailedOnWspU() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            new KeyValueConfigImpl(KeyValueConfigType.MARKET_ORDER_BOOK_SLOWEST_MARKET_TOLERANCE_MS, 100L)
                    )
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 2)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY),
                            tdd.enableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                            )
                    )
                    .setMarketConfigs(Arrays.asList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                            new MarketConfigImpl(Market.EBS).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                            new MarketConfigImpl(Market.CITI).setRegion(Region.GB).setInstrument(Instrument.USDCAD)
                            ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX,Market.EBS,Market.CITI)
                    .addAggBook(Market.WSP_R,Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,Market.EBS,Market.CITI)
                    .setPassiveHedgerConfigs(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.USDCAD, 0.9450, 0.9700));
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CITI, Instrument.USDCAD, 0.9500, 0.9800));
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.EBS, Instrument.USDCAD, 0.9600, 0.9900));
        }
        then:
        // wsp_u, last update fail on slowest market filter.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U));

            // min markets not met. However filter always set to PASS
            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));

            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.CITI));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CNX));

            // AXPROPHET-1055 WSP_U will always PASS filters unless there are no TOB.
            // Therefore SLOWEST MARKET filter will no longer show as FAILED filter
            nextMarketData = marketDataSnapshots.get(2);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.EBS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CITI));
        }
        then:
        // wsp_raw, last update failure on wsp_u does not affect wsp_raw
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(2), isMarket(Market.WSP_R));
            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));

            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.EBS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CITI));
        }
    }
}
