package com.anz.markets.efx.ngaro.sbe;

import com.anz.markets.efx.ngaro.codec.CachingStringDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.ByteValueCache;

/**
 * Contains static factory methods to create decoders for fixed or variable length strings.
 */
public final class StringDecoders {

    public static StringDecoder forFixedLength(final FixedStringSource source, final int length) {
        return new FixedStringDecoder(source, length);
    }

    public static StringDecoder forVariableLength(final VariableStringSource source, final int maxLength) {
        return new VariableStringDecoder(source, maxLength);
    }

    public static CachingStringDecoder forFixedLengthWithCache(final FixedStringSource source, final int length, final int cacheSize) {
        return new CachingStringDecoder(forFixedLength(source, length), length, cacheSize);
    }

    public static CachingStringDecoder forFixedLengthWithCache(final FixedStringSource source, final int length, final ByteValueCache<String> cache) {
        return new CachingStringDecoder(forFixedLength(source, length), length, cache);
    }

    public static CachingStringDecoder forVariableLengthWithCache(final VariableStringSource source, final int maxLength, final int cacheSize) {
        return new CachingStringDecoder(forVariableLength(source, maxLength), maxLength, cacheSize);
    }

    public static CachingStringDecoder forVariableLengthWithCache(final VariableStringSource source, final int maxLength, final ByteValueCache<String> cache) {
        return new CachingStringDecoder(forVariableLength(source, maxLength), maxLength, cache);
    }

    private StringDecoders() {
        throw new RuntimeException("No StringDecoders for you!");
    }
}
