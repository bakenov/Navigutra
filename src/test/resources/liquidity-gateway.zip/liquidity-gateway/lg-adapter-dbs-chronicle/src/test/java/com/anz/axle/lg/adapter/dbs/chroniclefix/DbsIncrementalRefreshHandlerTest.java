package com.anz.axle.lg.adapter.dbs.chroniclefix;

import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.datamodel.DefaultMarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.parsers.MessageParser;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoIncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.Marshallable;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import software.chronicle.fix.tools.FixToDTO;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Consumer;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DbsIncrementalRefreshHandlerTest {

    private static final String SENDER_COMP_ID = "GB:DBS";
    private static final String COMP_ID = "GB:lg-dbs";
    private static final long CURRENT_TIME = 34523453;
    private static final String SYMBOL = "USD/KRW";
    private static final String NORMALISED_SYMBOL = "USDTHB";
    private static final SecurityType SECURITY_TYPE_NDF = SecurityType.FXNDF;
    private static final String MDR_ID = "979620870";
    private static final Tenor TENOR = Tenor.M1;
    private static final int MDR_ID_INT = Integer.parseInt(MDR_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(MDR_ID);
    private static final String SETTL_DATE = "20181207";
    private static final InstrumentKey INSTRUMENT_KEY_NDF = InstrumentKey.of(NORMALISED_SYMBOL, SECURITY_TYPE_NDF, TENOR);


    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    @Mock
    private Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private DbsIncrementalRefreshHandler dbsIncrementalRefreshHandler;
    private PricingEncoderSupplier encoderSupplier;
    private StringToIntCache stringToIntCache;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);


    @Before
    public void setUp() throws Exception {
        final StringToIntCacheFactory stringToIntCacheFactory = new StringToIntCacheFactory(1000, 25, 1000, 8, 1);
        stringToIntCache = stringToIntCacheFactory.get();


        encoderSupplier = new PojoPricingEncoderSupplier(m -> {});
        dbsIncrementalRefreshHandler = new DbsIncrementalRefreshHandler(
                requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, flagsAppender, sourceSequencer);
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY_NDF)).thenReturn(RequestKey.of(Venue.DBS, INSTRUMENT_KEY_NDF));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(MDR_ID_INT)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        doNothing().when(marketDataSubscription).validateSymbol(any(String.class));
        when(marketDataSubscription.symbol()).thenReturn(SYMBOL);

        when(marketDataSubscription.stringToIntCache()).thenReturn(stringToIntCache);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY_NDF);
    }

    @Test
    public void handleNdfIncrementalMessage() throws Exception {
        //given
        final int newEntryId = stringToIntCache.put(SYMBOL+"-1M48");
        final int deleteEntryId = stringToIntCache.put(SYMBOL+"-1M50");
        //when
        dbsIncrementalRefreshHandler.accept(ndfIncrementalMessageFromFix());

        //then
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.senderCompId, is(COMP_ID));
        assertThat(body.marketId, is(Venue.DBS));
        assertThat(body.instrumentId, is(INSTRUMENT_KEY_NDF.instrumentId()));
        assertThat(body.settlDate.format(DateTimeFormatter.ofPattern("YYYYMMdd")), is(SETTL_DATE));
        assertThat(pojoEncoder.message().entries.size(), is(24));

        final List<IncrementalRefresh.Entry> entries = pojoEncoder.message().entries;
        //"279=0|269=0|278=USD/KRW-1M48|55=USD/KRW|270=1118.65000000|271=3000000|272=20181207|282=REUT|299=01c211db|1070=1|1027=-121.00000000|" +
        //mDUpdateAction: "0", mDEntryType: "0", mDEntryID: USD/KRW-1M48, symbol: USD/KRW, mDEntryPx: 1118.65, mDEntrySize: 3E6, mDEntryDate: "20181207", mDEntryOriginator: REUT, quoteEntryID: "01c211db", mDEntryForwardPoints: -121.0, mDQuoteType: 1
        System.out.println(pojoEncoder.message().entries.get(0));
        assertThat(entries.get(0).mdUpdateAction, is(UpdateAction.NEW));
        assertThat(entries.get(0).mdEntryId, is(newEntryId));
        assertThat(entries.get(0).mdEntryPx, is(1118.65));
        assertThat(entries.get(0).mdEntrySize, is(3000000.0));

        //"279=2|269=0|278=USD/KRW-1M50|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
        //mDUpdateAction: "2", mDEntryType: "0", mDEntryID: USD/KRW-1M50, symbol: USD/KRW, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: "20181207", mDEntryOriginator: UNKNOWN, mDEntryForwardPoints: 0.0, mDQuoteType: 1
        assertThat(entries.get(2).mdUpdateAction, is(UpdateAction.DELETE));
        assertThat(entries.get(2).mdEntryId, is(deleteEntryId));
    }

    private MarketDataIncrementalRefresh ndfIncrementalMessageFromFix() throws Exception {
        final String incrementalFixMessage = ("8=FIX.4.2|9=2788|35=X|34=264|49=FLEXECNP|56=ANZ_FLEX|52=20181105-00:00:01.477|262=979620870|" +
                "268=24|" +
                "279=0|269=0|278=USD/KRW-1M48|55=USD/KRW|270=1118.65000000|271=3000000|272=20181207|282=REUT|299=01c211db|1070=1|1027=-121.00000000|" +
                "279=0|269=0|278=USD/KRW-1M49|55=USD/KRW|270=1118.56000000|271=20000000|272=20181207|282=REUT|299=01c211db|1070=1|1027=-130.00000000|" +
                "279=2|269=0|278=USD/KRW-1M50|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M51|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=0|269=1|278=USD/KRW-1M52|55=USD/KRW|270=1118.95000000|271=3000000|272=20181207|282=REUT|299=01c211db|1070=1|1027=-119.00000000|" +
                "279=0|269=1|278=USD/KRW-1M53|55=USD/KRW|270=1119.04000000|271=20000000|272=20181207|282=REUT|299=01c211db|1070=1|1027=-110.00000000|" +
                "279=2|269=1|278=USD/KRW-1M54|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M55|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M56|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M57|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M58|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M59|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M60|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M61|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M62|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M63|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M64|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M65|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M66|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=0|278=USD/KRW-1M67|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M68|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M69|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M70|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|" +
                "279=2|269=1|278=USD/KRW-1M71|55=USD/KRW|270=0.00000000|271=0|272=20181207|282=UNKNOWN|1070=1|1027=0.00000000|10=215|")
                .replace("55=USD/KRW", "55="+SYMBOL)
                .replace("262=979620870", "262="+MDR_ID)
                .replace("272=20181207", "272="+SETTL_DATE)
                .replace('|', (char) 0x01);

        final DefaultMarketDataIncrementalRefresh incrementalRefresh = new DefaultMarketDataIncrementalRefresh();
        final FixToDTO fixToDTO = new FixToDTO(new MessageParser(), MessageNotifier.class);
        fixToDTO.parse(Bytes.from(incrementalFixMessage), sht -> sht.copyTo(incrementalRefresh));
        return incrementalRefresh;
    }

    @Test
    public void handleNdfIncrementalDeletesOnlyMessage() throws Exception {
        //given
        final int deleteEntryId1 = stringToIntCache.put(SYMBOL+"48");
        final int deleteEntryId2 = stringToIntCache.put(SYMBOL+"71");

        //when
        dbsIncrementalRefreshHandler.accept(ndfIncrementalDeletesOnlyMessage());

        //then
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;

        assertThat(body.senderCompId, is(COMP_ID));
        assertThat(body.marketId, is(Venue.DBS));
        assertThat(body.instrumentId, is(INSTRUMENT_KEY_NDF.instrumentId()));
        assertThat(body.settlDate.format(DateTimeFormatter.ofPattern("YYYYMMdd")), is(SETTL_DATE));
        assertThat(pojoEncoder.message().entries.size(), is(24));

        final List<IncrementalRefresh.Entry> entries = pojoEncoder.message().entries;
        assertThat(entries.get(0).mdUpdateAction, is(UpdateAction.DELETE));
        assertThat(entries.get(0).mdEntryId, is(deleteEntryId1));

        assertThat(entries.get(23).mdUpdateAction, is(UpdateAction.DELETE));
        assertThat(entries.get(23).mdEntryId, is(deleteEntryId2));

        entries.forEach(e -> assertThat(e.mdUpdateAction, is(UpdateAction.DELETE)));
    }

    private MarketDataIncrementalRefresh ndfIncrementalDeletesOnlyMessage() {
        final String yamlMessage =
                "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.datamodel.DefaultMarketDataIncrementalRefresh {\n" +
                        "  senderCompID: FLEXECNP,\n" +
                        "  targetCompID: ANZ_FLEX,\n" +
                        "  msgSeqNum: 11,\n" +
                        "  sendingTime: 1541396968031000000,\n" +
                        "  mDReqID: \"1063747585\",\n" +
                        "  marketDataIncrementalRefresh_MDEntriesGrp_1s: [" +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB48, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB49, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB50, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB51, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB52, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB53, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB54, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB55, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB56, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB57, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB58, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB59, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB60, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB61, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB62, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB63, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB64, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB65, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB66, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"0\", mDEntryID: USD/THB67, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB68, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB69, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB70, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }, " +
                        "!com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.datamodel.DefaultMarketDataIncrementalRefresh_MDEntriesGrp_1 { mDUpdateAction: \"2\", mDEntryType: \"1\", mDEntryID: USD/THB71, symbol: USD/THB, mDEntryPx: 0.0, mDEntrySize: 0.0, mDEntryDate: \"20181107\", mDQuoteType: 0 }],\n" +
                        "  noMDEntries: 24\n" +
                        "}";

        return Marshallable.fromString(yamlMessage
                .replace("USD/THB", SYMBOL)
                .replace("1063747585",MDR_ID)
                .replace("mDEntryDate: \"20181107\"","mDEntryDate: \""+SETTL_DATE+"\""));
    }
}