package com.anz.axle.direct.performance.metrics;

public interface Rates extends Count {
    double getMeanRate();

    double getTenSecondRate();

    double getOneMinuteRate();

    double getFiveMinuteRate();

    double getFifteenMinuteRate();
}
