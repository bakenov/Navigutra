package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;
import com.anz.axle.lg.adapter.fix.UserRequestData;
import com.anz.markets.efx.ngaro.api.Venue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.staticcode.messages.FixMessage;

import java.util.Objects;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus.CANCEL_DUPLICATE_SESSION;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus.LOGGED_IN;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus.NOT_LOGGED_IN;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus.PASSWORD_CHANGED;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus.PASSWORD_CHANGE_FAILED;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus.PASSWORD_EXPIRED;

public class EbsUserResponseHandler implements ChronicleMessageHandler<UserResponse> {

    public static final String USER_STATUS_TEXT_CLIENT_INITIATED_SIGNOFF = "Client Initiated Signoff";
    public static final String USER_STATUS_TEXT_PASSWORD_CHANGE_REQUIRED = "Default oldPassword used to signon, oldPassword change required!";
    private final Venue venue;
    private final UserRequestHandler userRequestHandler;
    private final PricingSubscription pricingSubscription;
    private final PasswordManager passwordManager;
    private final EbsBookRules ebsBookRules;
    private final Logger logger;
    private final StringBuilder logMessageBuilder = new StringBuilder();

    public EbsUserResponseHandler(final Venue venue,
                                  final UserRequestHandler userRequestHandler,
                                  final PricingSubscription pricingSubscription,
                                  final PasswordManager passwordManager,
                                  final EbsBookRules ebsBookRules,
                                  final Logger logger) {
        this.venue = Objects.requireNonNull(venue);
        this.userRequestHandler = Objects.requireNonNull(userRequestHandler);
        this.pricingSubscription = Objects.requireNonNull(pricingSubscription);
        this.passwordManager = Objects.requireNonNull(passwordManager);
        this.ebsBookRules = Objects.requireNonNull(ebsBookRules);
        this.logger = Objects.requireNonNull(logger);
    }

    public EbsUserResponseHandler(final Venue venue,
                                  final UserRequestHandler userRequestHandler,
                                  final PricingSubscription pricingSubscription,
                                  final PasswordManager passwordManager,
                                  final EbsBookRules ebsBookRules) {
        this(venue, userRequestHandler, pricingSubscription, passwordManager, ebsBookRules, LoggerFactory.getLogger(EbsUserResponseHandler.class));
    }

    @Override
    public void accept(final UserResponse message) throws IllegalArgumentException {
        //TODO UserStatus 926=1 logged on and NoTradingSessions 386 >= 1

        if (message.userStatus() == FixMessage.UNSET_LONG) {
            logger.warn("UserResponse message missing UserStatus(926). {} Message: {}", venue, message);
            return;
        }
        final int userStatus = (int)message.userStatus();
        switch (userStatus) {
            case LOGGED_IN:
                handleApplicationLogon(message);
                break;
            case NOT_LOGGED_IN:
                handleApplicationLogoff(message);
                break;
            case PASSWORD_CHANGED:
                handleChangePasswordSuccess(message);
                break;
            case PASSWORD_EXPIRED:
                handlePasswordExpired(message);
                break;
            case CANCEL_DUPLICATE_SESSION:
                handleApplicationLogonDuplicateSession(message);
                break;
            case PASSWORD_CHANGE_FAILED:
                handleChangePasswordFailure(message);
                break;
            default:
                logger.warn("Unsupported Venue={} UserStatus(926)={} userStatusText={} received.", venue, userStatus, message.userStatusText());
        }
    }

    private void handleApplicationLogon(final UserResponse message) throws IllegalArgumentException {
        //926 UserStatus Y 1 = Logged In
        logger.info("{} handleApplicationLogon: userStatus={} userStatusText={}", venue, message.userStatus(), message.userStatusText());
        passwordManager.update();
        ebsBookRules.update(message);
        pricingSubscription.subscribe(message);
    }

    private void handleApplicationLogonDuplicateSession(final UserResponse message) throws IllegalArgumentException {
        // UserStatus Y The logon result status  1001 – Cancel Duplicate Session
        // Do not expect to receive this message as the UserRequest contains AutoCancelDuplSession=Y
        logger.warn("{} handleApplicationLogonDuplicateSession: userStatus={} userStatusText={}", venue, message.userStatus(), message.userStatusText());
    }

    private void handleChangePasswordSuccess(final UserResponse message) throws IllegalArgumentException {
        //UserStatus Y The logon result status  5 – Password Changed
        logger.info("{} handleChangePasswordSuccess: userStatus={} userStatusText={}", venue, message.userStatus(), message.userStatusText());
        passwordManager.update();
    }

    private void handleChangePasswordFailure(final UserResponse message) throws IllegalArgumentException {
        //UserStatus Y The logon result status  1002 – Password Change Failed.
        passwordManager.clearNewPassword();
        final String logMessage = String.format("%s handleChangePasswordFailure: userStatus=%d userStatusText=%s", venue, message.userStatus(), message.userStatusText());
        logger.error(logMessage);
    }

    private void handleApplicationLogoff(final UserResponse message) throws IllegalArgumentException {
        //UserStatus Y The logon result status 2 = Not Logged In (same for failed login)
        passwordManager.clearNewPassword();
        final String userStatusText = message.userStatusText() == null ? "" : message.userStatusText();
        logMessageBuilder.setLength(0);
        final String logMessage = logMessageBuilder.append(venue).append(" handleApplicationLogoff: userStatus=").append(message.userStatus()).append(" userStatusText=").append(userStatusText).toString();
        logger.info(logMessage);

        switch (userStatusText) {
            case USER_STATUS_TEXT_PASSWORD_CHANGE_REQUIRED:
                userRequestHandler.send(UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER, message.userRequestID());
                break;
            case USER_STATUS_TEXT_CLIENT_INITIATED_SIGNOFF:
                break;
            default:
                // Example ERROR message
                // 8=FIX.4.4|9=202|35=BF|49=ICAP_Ai_Server|56=ANZ_PINK_GB_EBSHEDGE|34=2|52=20180612-06:01:05.747|336=0|923=2:45001|553=AN2
                // |927=Too many signon attempts. Password suspended and must be reset before signing on again.|926=2|10=078|
                logger.error(logMessage);
        }
    }

    private void handlePasswordExpired(final UserResponse message) throws IllegalArgumentException {
        // UserStatus(tag 926) = 1000 – Password Expired
        // reply with 924 UserRequestType Y 3 = Change Password
        //553 Username Y User name
        //554 Password Y Old oldPassword
        logger.info("{} handlePasswordExpired: userStatus={} userStatusText={} userName={}", venue, message.userStatus(), message.userStatusText(), message.username());
        userRequestHandler.send(UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER, message.userRequestID());
    }
}