package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.Module;
import com.anz.markets.disco.Stage;

public class AbstractModule implements Module {

    private final String name;
    private Stage stage;

    public AbstractModule(String name) {
        this.name = name;
    }

    public AbstractModule() {
        this.name = getClass().getSimpleName();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void init(Stage stage) {
        this.stage = stage;
        sub(stage.getMessageBus());
    }

    public Stage getStage() {
        return stage;
    }

    /** Override for subscriptions. */
    public void sub(MessageBus messageBus) {
        ;
    }

    @Override
    public void finish() {
        ;
    }
}
