package com.anz.markets.prophet.hedger.firewall.threshold;

import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.SecureRandom;

public class RevalPnlLossFirewallJmhTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(RevalPnlLossFirewallJmhTest.class);

    @Benchmark
    public void testAcceptMidRateTradeandOneSecond(@NotNull final Data data) throws Exception {
        data.testAcceptMidRateTradeandOneSecond(data.random.nextInt());
    }

    @State(Scope.Benchmark)
    public static class Data extends AbstractRevalPnlLossFirewallForBwJmhTest {
        final SecureRandom random = new SecureRandom();

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }
}
