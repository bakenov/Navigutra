#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

kdbstats_data_lat - Plugin to monitor the KDB Data Write Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Yuri Litvinov (yuri.litvinov@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=kdbstats
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh

QHOME=/app/kdb/q ; export QHOME
QLIC=$QHOME/QLIC ; export QLIC
TAIL=/usr/bin/tail

SLEEP_SECONDS=5

if [ `uname -s` == "SunOS" ]
then
    DC_TASKSET="psrset -c 0 q"
    NEWTASK="/usr/bin/newtask -p kdb"
    Q=/app/kdb/q/v64/q
else
    PATH=$PATH:/usr/local/bin:$QHOME/l64 ; export PATH
    NEWTASK="taskset -c 0"
    Q=/app/kdb/q/l64/q
fi

if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title KDB Data Write Latency'
    #echo 'graph_args --upper-limit 3'
    echo 'graph_category kdbstats'
    echo 'graph_scale no'

    echo 'fxdepth.label Table fxdepth'
    echo 'fxdepth.draw AREA'    

    echo 'fxquote.label Table fxquote'
    echo 'fxquote.draw STACK'    

    echo 'fxtrade.label Table fxtrade'
    echo 'fxtrade.draw STACK' 
       
    echo 'axletrade.label Table axletrade'
    echo 'axletrade.draw STACK'    
        
    echo 'heartbeat.label Table heartbeat'
    echo 'heartbeat.draw STACK'    

    exit 0
fi
        

KDB_PIDFILE=/data/kdb/logs/pid/DS_TP_FX.1.pid

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ ! -f ${KDB_PIDFILE} ] ; then
        echo "fxdepth.value U"
        echo "fxquote.value  U"
        echo "fxtrade.value U"        
        echo "axletrade.value U"
        echo "heartbeat.value U"
        exit 0
fi

KDB_PID=$(cat ${KDB_PIDFILE})
if [ ! -d /proc/${KDB_PID} ] ; then
        echo "fxdepth.value U"
        echo "fxquote.value  U"
        echo "fxtrade.value U"        
        echo "axletrade.value U"
        echo "heartbeat.value U"
        exit 0
fi


LOGFILE="/tmp/data_lat.log"

if [ -f "$LOGFILE" ]; then
  rm $LOGFILE
fi

$NEWTASK $Q /app/kdb/axle/environment/kdb/munin/data_lat.q > /dev/null

if [ -f "$LOGFILE" ]; then
  cat $LOGFILE                    
else
        echo "fxdepth.value U"
        echo "fxquote.value  U"
        echo "fxtrade.value U"        
        echo "axletrade.value U"
        echo "heartbeat.value U"
fi

