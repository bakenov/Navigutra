package com.anz.markets.efx.fox.firewall.rule;

import java.util.function.Predicate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MetricBasedRuleTest {
    private static final double LIMIT = 3434;
    @Mock
    private NewOrderSingleDecoder newOrderSingle;
    @Mock
    private Metric metric;
    @Mock
    private RuleMatcher ruleMatcher;
    @Mock
    private RuleMatcher anotherRuleMatcher;
    @Mock
    private Predicate<NewOrderSingleDecoder> orderMatcher;
    private MetricBasedRule metricBasedRule;

    @BeforeEach
    void setUp() {
        metricBasedRule = new MetricBasedRule("firewall1",10, "ruleBlah", LIMIT, metric, ruleMatcher, orderMatcher);
    }

    @Test
    void validate_should_succeed_when_metric_value_below_the_limit() {
        //given
        final long currentTime = 100;
        when(metric.nextValue(newOrderSingle, currentTime)).thenReturn(LIMIT - 1);

        //when + then
        assertThat(metricBasedRule.validate(newOrderSingle, currentTime)).isTrue();
    }

    @Test
    void validate_should_NOT_succeed_when_metric_value_above_the_limit() {
        //given
        final long currentTime = 100;
        when(metric.nextValue(newOrderSingle, currentTime)).thenReturn(LIMIT + 1);

        //when + then
        assertThat(metricBasedRule.validate(newOrderSingle, currentTime)).isFalse();
    }

    @Test
    void compareTo_delegate_compare_to_ruleMatcher() {
        //given
        final MetricBasedRule anotherRule = new MetricBasedRule("firewall1", 20, "ruleBlah", LIMIT, metric, anotherRuleMatcher, orderMatcher);

        //when
        metricBasedRule.compareTo(anotherRule);

        //then
        verify(ruleMatcher).compareTo(anotherRuleMatcher);
    }

    @Test
    void match_should_delegate_to_order_matcher_predicate() {
        //when
        metricBasedRule.match(newOrderSingle);

        //then
        verify(orderMatcher).test(newOrderSingle);
    }

    @Test
    void id() {
        assertThat(metricBasedRule.id()).isEqualTo(10);
    }

    @Test
    void metric() {
        assertThat(metricBasedRule.metric()).isEqualTo(metric);
    }
}