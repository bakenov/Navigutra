package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.status.Context;
import net.openhft.chronicle.threads.Pauser;

public interface ReaderConfig {
    int NO_TAILER_ID = -1;
    long startPosition();
    StartAt startAt();
    WaitStrategy waitStrategy();
    Pauser pauser();
    ChronicleHook startReadHook();
    ChronicleHook endReadHook();
    ChronicleHook unknownReadHook();
    Context.HeaderPredicate headerFilter();
    ChronicleObjectReader chronicleObjectReader();
    RingBuffer ringBuffer();
    int tailerId();
}
