package com.anz.markets.efx.fox.acceptance.tests;

import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.pojo.matcher.VenueConfigMatcher;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.Venue;

@RunWith(Spockito.class)
public class Venues_Are_Loaded_From_YamlTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(Venues_Are_Loaded_From_YamlTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.config.class.path", "conf/venue-config-test.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_see_venue_created_commands_and_events_on_startup() throws Exception {

        final VenueConfigMatcher test1Matcher = VenueConfigMatcher.build()
                .body().matches(VenueConfigMatcher.venue().eq(Venue.BARX))
                .body().matches(VenueConfigMatcher.venueCategories().eq(EnumSet.of(VenueCategory.BANK)))
                .body().matches(VenueConfigMatcher.enabled().eq(Boolean.TRUE));

        final VenueConfigMatcher test2Matcher = VenueConfigMatcher.build()
                .body().matches(VenueConfigMatcher.venue().eq(Venue.CMEJMP))
                .body().matches(VenueConfigMatcher.venueCategories().eq(EnumSet.of(VenueCategory.MATCHING_AGENT, VenueCategory.INTERBANK)))
                .body().matches(VenueConfigMatcher.enabled().eq(Boolean.FALSE));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(test1Matcher)
                .thenMatching(test2Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(test1Matcher)
                .thenMatching(test2Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }
}
