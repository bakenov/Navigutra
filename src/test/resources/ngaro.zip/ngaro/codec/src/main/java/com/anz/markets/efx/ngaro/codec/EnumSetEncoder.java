package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

public final class EnumSetEncoder<E, V extends Enum<V>> implements EnumerableSetEncoder<E, V> {

    public interface Setter<V> {
        void set(V value);
    }
    public interface Clearer {
        void clear();
    }

    private final E enclosingEncoder;
    private final IntSupplier lengthSupplier;
    private final IntFunction<V> ordinalToValue;
    private final Setter<? super V> setter;
    private final Clearer clearer;

    public EnumSetEncoder(final E enclosingEncoder,
                          final IntSupplier lengthSupplier,
                          final IntFunction<V> ordinalToValue,
                          final Setter<? super V> setter,
                          final Clearer clearer) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.lengthSupplier = Objects.requireNonNull(lengthSupplier);
        this.ordinalToValue = Objects.requireNonNull(ordinalToValue);
        this.setter = Objects.requireNonNull(setter);
        this.clearer = Objects.requireNonNull(clearer);
    }

    public EnumSetEncoder(final E enclosingEncoder,
                          final IntSupplier lengthSupplier,
                          final IntFunction<V> ordinalToValue,
                          final Set<? super V> backingSet) {
        this(enclosingEncoder, lengthSupplier, ordinalToValue, backingSet::add, backingSet::clear);
    }

    @Override
    public E clear() {
        clearer.clear();
        return enclosingEncoder;
    }

    @Override
    public E add(final V value) {
        setter.set(value);
        return enclosingEncoder;
    }

    @Override
    public E addAll(final Set<? extends V> values) {
        if (!values.isEmpty()) {
            EnumerableSetEncoder.super.addAll(values);
        }
        return enclosingEncoder;
    }

    @Override
    public <S> E addAll(final S source, final BiPredicate<? super S, ? super V> reader) {
        for (int ordinal = 0; ordinal < lengthSupplier.getAsInt(); ordinal++) {
            final V flag = ordinalToValue.apply(ordinal);
            if (reader.test(source, flag)) {
                setter.set(flag);
            }
        }
        return enclosingEncoder;
    }
}
