package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.HandlInst;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.SettlType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.util.CharSequenceBuilder;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.RegulatoryTradeIds;
import com.anz.markets.efx.trading.codec.api.StrategyParameters;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.function.Consumer;

import static com.anz.axle.lg.adapter.chroniclefix.FixSide.fixSide;
import static com.anz.axle.lg.adapter.ebs.EbsTranslator.orderType;
import static com.anz.axle.lg.adapter.ebs.EbsTranslator.timeInForce;
import static com.anz.markets.efx.trading.codec.api.OrderType.FIXING_ORDER;
import static com.anz.markets.efx.trading.codec.api.TradingConstants.VAR_STRING_MAX_LENGTH;

public class EbsNewOrderSingleHandler implements Consumer<NewOrderSingleDecoder> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsNewOrderSingleHandler.class);

    private static final LocalDateFormat DATE_FORMAT = LocalDateFormat.YYYYMMDD;
    public static final String BENCHMARK_FIX_STRATEGY_NAME = "BenchmarkFix";

    private final TradingEncoderSupplier tradingEncoderSupplier;
    private final FixMessageSender fixMessageSender;
    private final SessionState tradingSessionState;

    private final TradingSessionRepository tradingSessionRepository;
    private final TenorLookup tenorLookup;
    private final SymbolPriceDecimalFormat symbolPriceDecimalFormat;

    private final String compId;
    private final LongIdFactory messageIdGenerator;
    private final SourceSequencer sourceSequencer;

    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));
    private final ByteValueCache<String> strategyParameterNameCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> strategyParameterValueCache = new ByteValueCache<>(AsciiString::toString);

    private final NewOrderSingle newOrderSingle;
    private final CharSequenceBuilder charSequenceBuilder = new CharSequenceBuilder();
    private final FixedLengthAsciiString fixedLengthRejectText = new FixedLengthAsciiString(VAR_STRING_MAX_LENGTH);

    public EbsNewOrderSingleHandler(final TradingEncoderSupplier tradingEncoderSupplier,
                                    final FixMessageSender fixMessageSender,
                                    final SessionState tradingSessionState,
                                    final TradingSessionRepository tradingSessionRepository,
                                    final TenorLookup tenorLookup,
                                    final SymbolPriceDecimalFormat symbolPriceDecimalFormat,
                                    final String compId,
                                    final LongIdFactory messageIdGenerator,
                                    final SourceSequencer sourceSequencer) {
        this.tradingEncoderSupplier = Objects.requireNonNull(tradingEncoderSupplier);
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.tradingSessionState = Objects.requireNonNull(tradingSessionState);
        this.tradingSessionRepository = Objects.requireNonNull(tradingSessionRepository);
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
        this.symbolPriceDecimalFormat = Objects.requireNonNull(symbolPriceDecimalFormat);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
        this.newOrderSingle = new DefaultNewOrderSingle();
    }

    @Override
    public void accept(final NewOrderSingleDecoder newOrderSingleDecoder) {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("NewOrderSingle received: {}", toString(newOrderSingleDecoder));

        if (!tradingSessionState.getAsBoolean()) {
            sendExecutionReportReject(newOrderSingleDecoder, "Session logged off");
        } else {
            try {
                sendNewOrderSingle(newOrderSingleDecoder);
            } catch (final RuntimeException e) {
                LOGGER.warn("Unexpected Exception:", e);
                sendExecutionReportReject(newOrderSingleDecoder, e.getMessage());
            }
        }
    }

    private void reset() {
        newOrderSingle.reset();
    }

    private void sendNewOrderSingle(final NewOrderSingleDecoder newOrderSingleDecoder) {
        reset();
        final NewOrderSingleDecoder.Body body = newOrderSingleDecoder.body();

        newOrderSingle.clOrdID(newOrderSingle.clOrdID_buffer());
        newOrderSingle.clOrdID().append(body.clOrdId().decodeStringOrEmpty());

        newOrderSingle.transactTime(body.transactTime());
        newOrderSingle.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        newOrderSingle.symbol(body.symbol().decodeAndCache(symbol7Cache));
        newOrderSingle.cFICode(FixCFICode.to(body.securityType()));
        newOrderSingle.side(fixSide(body.side()));
        newOrderSingle.orderQty(body.orderQty());
        newOrderSingle.ordType(orderType(body.ordType()));
        newOrderSingle.timeInForce(timeInForce(body.timeInForce()));

        final String settlType = tenorLookup.ebsTenor(body.settlType());
        if (settlType != null) {
            newOrderSingle.settlType(settlType);
        }

        if (SettlType.BROKEN.equals(settlType)) {
            newOrderSingle.settlDate(body.settlDate().decodeToFormattedStringOrNull(DATE_FORMAT));
        }

        if (FIXING_ORDER == body.ordType()) {
            newOrderSingle.price(null);
        } else {
            newOrderSingle.price(newOrderSingle.price_buffer());
            newOrderSingle.price().append(symbolPriceDecimalFormat.formatPrice(body.symbol().decodeAndCache(symbolCache), body.price()));
        }

        if (FIXING_ORDER == body.ordType()) {
            final String fixingSessionTag = benchmarkFixStrategyName(newOrderSingleDecoder);
            final TradingSession tradingSession = tradingSessionRepository.findByTradingSessionTag(fixingSessionTag);

            if (tradingSession == null) {
                sendExecutionReportReject(newOrderSingleDecoder, fixedLengthRejectText.set(fixingSessionTag).append(" not available"));
                return;
            }

            if (!tradingSession.isOpen()) {
                sendExecutionReportReject(newOrderSingleDecoder,
                        fixedLengthRejectText.clear()
                                .append("Session closed: ").append(tradingSession.tradingSessionDesc())
                                .append(" openTime=").append(tradingSession.tradSesOpenTime().toString())
                                .append(" closeTime=").append(tradingSession.tradSesCloseTime().toString()));
                return;
            }

            newOrderSingle.tradingSessionID(tradingSession.tradingSessionID());
            newOrderSingle.marketSegmentID(tradingSession.marketSegmentID().fixSegmentID());
            newOrderSingle.valuationDateTime(tradingSession.valuationDateTime());
            newOrderSingle.timeInForce(TimeInForce.GOOD_TILL_CANCEL);
        }

        LOGGER.debug("Sending NewOrderSingle : {}", newOrderSingle);
        fixMessageSender.accept(newOrderSingle);
    }

    private String benchmarkFixStrategyName(final NewOrderSingleDecoder newOrderSingleDecoder) {
        String strategyName = null;
        for (NewOrderSingleDecoder.StrategyParameter strategyParameter : newOrderSingleDecoder.strategyParameters()) {
            if (BENCHMARK_FIX_STRATEGY_NAME.equals(strategyParameter.strategyParameterName().decodeAndCache(strategyParameterNameCache))) {
                strategyName = strategyParameter.strategyParameterValue().decodeAndCache(strategyParameterValueCache);
            } else {
                strategyParameter.strategyParameterValue().decodeToNull();
            }
        }
        return strategyName;
    }

    private CharSequence toString(final NewOrderSingleDecoder newOrderSingleDecoder) {
        return charSequenceBuilder.clear().append(newOrderSingleDecoder::appendTo).get();
    }

    private void sendExecutionReportReject(final NewOrderSingleDecoder newOrderSingleDecoder, final CharSequence rejectText) {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Sending ExecutionReportReject rejectText={}, {}", rejectText, toString(newOrderSingleDecoder));

        final long messageId = messageIdGenerator.get();
        final ExecutionReportEncoder.Body executionReportEncoderBody = tradingEncoderSupplier.executionReport().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .targetCompId().encodeFrom(newOrderSingleDecoder.body().senderCompId())
                .messageId(messageId)
                .orderId().encodeEmpty()
                .clOrdId().encodeFrom(newOrderSingleDecoder.body().clOrdId())
                .origClOrdId().encodeFrom(newOrderSingleDecoder.body().clOrdId())
                .clOrdLinkId().encodeFrom(newOrderSingleDecoder.body().clOrdLinkId())
                .marketId().encodeFrom(newOrderSingleDecoder.body().marketId())
                .execId().encodeEmpty()
                .execType(ExecType.REJECTED)
                .ordStatus(OrderStatus.REJECTED)
                .symbol().encodeFrom(newOrderSingleDecoder.body().symbol())
                .securityType(newOrderSingleDecoder.body().securityType())
                .settlType(newOrderSingleDecoder.body().settlType())
                .orderQty(newOrderSingleDecoder.body().orderQty())
                .ordType(newOrderSingleDecoder.body().ordType())
                .timeInForce(newOrderSingleDecoder.body().timeInForce())
                .displayQty(newOrderSingleDecoder.body().displayQty())
                .targetStrategyName().encodeFrom(newOrderSingleDecoder.body().targetStrategyName())
                .price(newOrderSingleDecoder.body().price())
                .side(newOrderSingleDecoder.body().side())
                .currency().encodeFrom(newOrderSingleDecoder.body().currency())
                .transactTime(newOrderSingleDecoder.body().transactTime())
                .tradeDate().encodeNull()
                .settlDate().encodeFrom(newOrderSingleDecoder.body().settlDate())
                .settlCurrency().encodeFrom(newOrderSingleDecoder.body().settlCurrency())
                .expireTime(newOrderSingleDecoder.body().expireTime())
                .effectiveTime(newOrderSingleDecoder.body().effectiveTime())
                .leavesQty(0)
                .lastQty(0)
                .lastPx(0)
                .cumQty(0)
                .avgPx(0)
                .midPx(0)
                .lastSpotRate(0)
                .lastForwardPoints(0)
                .commission(0)
                .commissionAdjAvgPx(0)
                .commissionAdjLastPx(0);

        final NewOrderSingleDecoder.Party parties = newOrderSingleDecoder.parties();
        final ExecutionReportEncoder.Parties partiesGroup = executionReportEncoderBody.partiesStart(parties.count());
        for (NewOrderSingleDecoder.Party party : parties) {
            partiesGroup.next().partyRole(party.partyRole()).partyId().encodeFrom(party.partyId());
        }
        final NewOrderSingleDecoder.StrategyParameter strategyParameters = newOrderSingleDecoder.strategyParameters();
        final StrategyParameters.Encoder.Next<ExecutionReportEncoder.RegulatoryTradeIds> strategyParametersGroup = partiesGroup.partiesComplete().strategyParametersStart(strategyParameters.count());

        for (NewOrderSingleDecoder.StrategyParameter strategyParameter : strategyParameters) {
            strategyParametersGroup.next()
                    .strategyParameterName().encodeFrom(strategyParameter.strategyParameterName())
                    .strategyParameterValue().encodeFrom(strategyParameter.strategyParameterValue());
        }

        final NewOrderSingleDecoder.RegulatoryTradeId regulatoryTradeIds = newOrderSingleDecoder.regulatoryTradeIds();
        final RegulatoryTradeIds.Encoder.Next<ExecutionReportEncoder.Hops> regulatoryTradeIdsGroup = strategyParametersGroup.strategyParametersComplete().regulatoryTradeIdsStart(regulatoryTradeIds.count());
        for (NewOrderSingleDecoder.RegulatoryTradeId regulatoryTradeId : regulatoryTradeIds) {
            regulatoryTradeIdsGroup.next()
                    .id().encodeFrom(regulatoryTradeId.regulatoryTradeId())
                    .source().encodeFrom(regulatoryTradeId.regulatoryTradeIdSource());
        }
        final NewOrderSingleDecoder.Hop hops = newOrderSingleDecoder.hops();
        final Hops.Encoder.Next<ExecutionReportEncoder.QuoteId> hopsGroup = regulatoryTradeIdsGroup.regulatoryTradeIdsComplete().hopsStart(hops.count());
        for (NewOrderSingleDecoder.Hop hop : hops) {
            hopsGroup.next().hopReceivingTime(hop.hopReceivingTime())
                    .hopSendingTime(hop.hopSendingTime())
                    .hopMessageId(hop.hopMessageId())
                    .hopCompId().encodeFrom(hop.hopCompId());
        }

        hopsGroup.hopsComplete()
                .quoteId().encodeFrom(newOrderSingleDecoder.trailer().quoteId())
                .rejectText().encode(rejectText)
                .messageComplete();
    }
}
