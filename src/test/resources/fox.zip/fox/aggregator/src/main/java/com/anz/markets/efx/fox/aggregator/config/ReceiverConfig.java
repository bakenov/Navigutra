package com.anz.markets.efx.fox.aggregator.config;

import javax.annotation.PostConstruct;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.eventloop.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.fox.aggregator.core.Aggregator;
import com.anz.markets.efx.fox.aggregator.core.CurrentMillisIdGenerator;
import com.anz.markets.efx.fox.aggregator.core.DefaultPricingEncoderLookup;
import com.anz.markets.efx.fox.aggregator.core.DefaultPublicationRegistry;
import com.anz.markets.efx.fox.aggregator.core.DefaultTopicRegistry;
import com.anz.markets.efx.fox.aggregator.core.LongConsumerSupplier;
import com.anz.markets.efx.fox.aggregator.core.PricingEncoderLookup;
import com.anz.markets.efx.fox.aggregator.core.PublicationLookup;
import com.anz.markets.efx.fox.aggregator.core.Publisher;
import com.anz.markets.efx.fox.aggregator.core.SbeMessagePublisher;
import com.anz.markets.efx.fox.aggregator.core.SnapshotterAccessor;
import com.anz.markets.efx.fox.aggregator.core.Subscriber;
import com.anz.markets.efx.fox.aggregator.core.TopicRegistry;
import com.anz.markets.efx.fox.aggregator.core.TopicSubscriber;
import com.anz.markets.efx.fox.aggregator.core.TradingResponseMessageHandler;
import com.anz.markets.efx.fox.aggregator.core.VenueNewOrderSingleHandler;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamEncoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoders;
import static com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries.Factory.SIDE_PRICE_QUANTITY_MARKET;

@Configuration
public class ReceiverConfig {
    /// receiver
    @Bean
    public LongConsumerSupplier receivedTimeConsumerSupplier() {
        return new LongConsumerSupplier();
    }


    @Bean
    public Connection receiverConnection(final Transport transport) {
        return transport.openConnection(() -> {});
    }

    @Bean
    public Queue<Runnable> receiverEventLoopRunnableQueue(@Value("${receiver.event.loop.queue.capacity}") final int queueCapacity) {
        return new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(queueCapacity));
    }

    @Bean
    public MessageHandler tradingResponseMessageHandler(final LongConsumerSupplier receivedTimeConsumerSupplier) {

        final NewOrderSingleHandler newOrderSingleHandler = new VenueNewOrderSingleHandler();

        return TradingResponseMessageHandler.create(new SbeTradingDecoders(), receivedTimeConsumerSupplier, newOrderSingleHandler);
    }

    @Bean
    public Subscriber tradingResponseSubscriber(final Connection receiverConnection,
                                                final EndPointStatusHandler transportEndPointStatusHandler,
                                                final MessageHandler tradingResponseMessageHandler,
                                                final @Value("${trading.response.topic}") String tradingResponseTopicName) {
        return new TopicSubscriber(receiverConnection, transportEndPointStatusHandler, tradingResponseMessageHandler, tradingResponseTopicName);
    }

    @Bean
    public EventLoopStep receiverTransportStep(final Connection receiverConnection,
                                               final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        return EventLoopStep.whenFinalisationNotRequired(() -> receiverConnection.pollingStrategy().processNext());
    }

    @Bean
    public EventLoopStep receiverEventLoopRunnableQueueStep(Queue<Runnable> receiverEventLoopRunnableQueue) {
        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return EventLoopStep.whenFinalisationRequired(() -> receiverEventLoopRunnableQueue.poller().processNext(runnableProcessor));
    }

    @Bean
    public Service receiverEventLoopService(final EventLoopStep receiverTransportStep,
                                            final EventLoopStep receiverEventLoopRunnableQueueStep,
                                            final Supplier<IdleStrategy> idleStrategySupplier) {
        return new EventLoopService("TradingReceiver",
                10, TimeUnit.SECONDS, idleStrategySupplier.get(),
                receiverTransportStep,
                receiverEventLoopRunnableQueueStep
                );
    }

    //publisher

    @Bean
    public DefaultPublicationRegistry publicationRegistry(final EndPointStatusHandler transportEndPointStatusHandler,
                                                          final Connection receiverConnection) {
        return new DefaultPublicationRegistry(receiverConnection, transportEndPointStatusHandler);
    }

    @Bean
    public Publisher publisher(final PublicationLookup publicationLookup) {
        return new Publisher(publicationLookup);
    }

    @Bean
    public TopicRegistry aggBookTopicRegistry() {
        return new DefaultTopicRegistry();
    }

    @Bean
    public PricingEncoders<SbeMessage> sbePricingEncoders(@Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbePricingEncoders(() -> sbeMessage);
    }

    @Bean
    protected LongSupplier messageIdGenerator() {
        return new CurrentMillisIdGenerator();
    }

    @Bean
    protected PricingEncoderLookup pricingEncoderLookup(final PricingEncoders<SbeMessage> sbePricingEncoders,
                                                        final PrecisionClock precisionClock,
                                                        final @Value("${market.data.book.initial.size}") int marketDataBookInitialSize,
                                                        final LongSupplier messageIdGenerator,
                                                        final TopicRegistry aggBookTopicRegistry,
                                                        final MessageHandler publisher,
                                                        final @Value("${messaging.compId}") String compId,
                                                        final @Value("${market.data.book.max.publishable.layers}") int maxPublishableLayers,
                                                        final @Value("${fox.aggregator.source.id}") int foxAggregatorSourceId) {
        return new DefaultPricingEncoderLookup(requestKey -> {
            final SnapshotterBuilder builder = SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, marketDataBookInitialSize, DefaultMarketDataEntry::new, SIDE_PRICE_QUANTITY_MARKET))
                    .withDownstreamEncoder()
                    .forwardSnapshotsAndIncrementsTo(
                            PricingEncoderSupplier.create(sbePricingEncoders, SbeMessagePublisher.create(requestKey, aggBookTopicRegistry, publisher)), maxPublishableLayers);

            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock,  messageIdGenerator, compId, foxAggregatorSourceId);
            final UpstreamEncoderConnector upstreamEncoderConnector = builder.buildUpstreamEncoderConnector(UpdateTypeMismatchHandler.IGNORE_REPLACE_ON_ADD_AND_NOOP_ON_REMOVE);
            return SnapshotterAccessor.create(snapshotter, upstreamEncoderConnector);
        });
    }

    @Bean
    protected Runnable aggregator(final PricingEncoderLookup pricingEncoderLookup,
                                  final PricingClient<MarketDataBook> pricingClient,
                                  final ObjectPool<MarketDataBook> marketDataBookPool,
                                  final PrecisionClock precisionClock,
                                  final List<InstrumentKey> publishableInstruments,
                                  final LongSupplier messageIdGenerator,
                                  final @Value("${messaging.compId}") String compId,
                                  final @Value("${fox.aggregator.source.id}") int foxSource) {
        return new Aggregator(pricingEncoderLookup, pricingClient, marketDataBookPool, precisionClock, publishableInstruments, messageIdGenerator, compId, foxSource);
    }

    @Bean
    public ScheduledFuture<?> priceAggregationJob(final Queue<Runnable> receiverEventLoopRunnableQueue,
                                                  final ScheduledExecutorService scheduledExecutorService,
                                                  final Runnable aggregator,
                                                  @Value("${aggregation.period.millis}") final int aggregationPeriodMillis) {
        return scheduledExecutorService.scheduleWithFixedDelay(() -> receiverEventLoopRunnableQueue.appender().enqueue(aggregator), aggregationPeriodMillis, aggregationPeriodMillis, TimeUnit.MILLISECONDS);
    }

    @Autowired
    private Subscriber tradingResponseSubscriber;

    @PostConstruct
    public void init() {
        tradingResponseSubscriber.subscribe();
    }
}
