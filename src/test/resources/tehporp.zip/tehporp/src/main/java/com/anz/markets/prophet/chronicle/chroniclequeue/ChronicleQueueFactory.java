package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.util.SystemProperties;
import net.openhft.chronicle.bytes.BytesRingBufferStats;
import net.openhft.chronicle.bytes.BytesStore;
import net.openhft.chronicle.core.OS;
import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.core.util.ThrowingBiFunction;
import net.openhft.chronicle.queue.BufferMode;
import net.openhft.chronicle.queue.PretouchHandler;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.enterprise.queue.ChronicleRingBuffer;

import java.io.File;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.function.Consumer;

/**
 * Use this as a central point for creating CQ queues
 */
public enum ChronicleQueueFactory {
    INSTANCE;
    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleQueueFactory.class);
    private static final boolean PRETOUCH_ENABLED = SystemProperties.PRETOUCH_INTERVAL_IN_MILLIS > 0L;

    static {
        if (SystemProperties.CQ_RING_BUFFER_ENABLED) {
            LOGGER.info("Ring buffer is enabled");
        } else {
            LOGGER.info("Ring buffer is disabled");
        }
    }

    public static SingleChronicleQueue createQueue(final String basePath, final boolean readOnly) {
        return createQueue(basePath, readOnly, RingBuffer.NO_RING);
    }

    public static SingleChronicleQueue createQueue(final String basePath, final boolean readOnly, final RingBuffer ringBuffer) {
        return createQueue(basePath, readOnly, ringBuffer, null);
    }

    public static SingleChronicleQueue createQueue(final String basePath, final boolean readOnly, final RingBuffer ringBuffer, final EventLoop eventLoop) {
        final SingleChronicleQueueBuilder builder = SingleChronicleQueueBuilder
                .binary(new File(basePath))
                .readOnly(readOnly)
                .checkInterrupts(false)
                .blockSize(SystemProperties.CQ_BLOCK_SIZE)
                .rollCycle(SystemProperties.CQ_ROLL_CYCLE)
                .rollTime(LocalTime.of(SystemProperties.CQ_ROLL_TIME_HR, SystemProperties.CQ_ROLL_TIME_MIN), ZoneId.of(SystemProperties.CQ_ROLL_TIME_TZ));
        final SingleChronicleQueue queue;

        if (ringBuffer.enabled()) {
            final ThrowingBiFunction<Long, Integer, BytesStore, Exception> byteStore = BufferByteStore.create(basePath);
            builder.bufferBytesStoreCreator(byteStore)
                    // one per core
                    .maxTailers(2)
                    .ringBufferForceCreateReader(SystemProperties.CQ_RING_BUFFER_FORCE_CREATE_READER)
                    .ringBufferReaderCanDrain(false)
                    .eventLoop(eventLoop)
                    .bufferCapacity(SystemProperties.CQ_RING_BUFFER_CAPACITY)
                    .readBufferMode(BufferMode.Asynchronous)
                    .writeBufferMode(BufferMode.Asynchronous);
            if (SystemProperties.CQ_RING_BUFFER_MONITOR_MILLIS > 0) {
                builder.enableRingBufferMonitoring(true).onRingBufferStats(new RingBufferMonitorLogger());
            }
        } else if (ringBuffer.async()) {
            builder.enableRingBufferMonitoring(true)
                    .ringBufferForceCreateReader(SystemProperties.CQ_RING_BUFFER_FORCE_CREATE_READER)
                    .eventLoop(eventLoop)
                    .bufferCapacity(SystemProperties.CQ_RING_BUFFER_CAPACITY)
                    .writeBufferMode(BufferMode.Asynchronous);
            if (SystemProperties.CQ_RING_BUFFER_MONITOR_MILLIS > 0) {
                builder.enableRingBufferMonitoring(true).onRingBufferStats(new RingBufferMonitorLogger());
            }
        }

        queue = builder.build();

        LOGGER.info("Chronicle Queue created -> {}. [readOnly={}, rollCycle={}, ringBuffer={}]", queue, readOnly, SystemProperties.CQ_ROLL_CYCLE, ringBuffer);

        if (PRETOUCH_ENABLED && !readOnly) {
            LOGGER.info("Pretouch active for queue {} with period {}ms.", queue.fileAbsolutePath(), SystemProperties.PRETOUCH_INTERVAL_IN_MILLIS);
            // Schedule pretouch task as soon as a persister queue is created
            queue.eventLoop().addHandler(new PretouchHandler(queue));
        }

        return queue;
    }

    public static String fileNameToRingBufferFileName(final String basePath) {
        String mappedFile = basePath + ".rb";
        if (mappedFile.substring(2).contains("/")) {
            // only for TC tests
            // ignore first 2 chars e.g. ./
            mappedFile = mappedFile.replaceAll("/", "_");
        }
        if (! OS.isWindows()) {
            mappedFile = "/dev/shm/" + mappedFile;
        }
        return mappedFile;
    }

    private static class RingBufferMonitorLogger implements Consumer<BytesRingBufferStats> {
        private long nextTriggerTimeMs;

        @Override
        public void accept(final BytesRingBufferStats stats) {
            if (System.currentTimeMillis() > nextTriggerTimeMs) {
                nextTriggerTimeMs = System.currentTimeMillis() + SystemProperties.CQ_RING_BUFFER_MONITOR_MILLIS;
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.info(stats.toString());
                } else {
                    long l = stats.minNumberOfWriteBytesRemaining();
                    if (l == Long.MAX_VALUE) {
                        // nothing has been written since we last checked
                        l = stats.capacity();
                        LOGGER.info("RB is {}% not being written to", (int) (100 * (1.0 - ((double) l / stats.capacity()))));
                        //nextTriggerTimeMs += (SystemProperties.CQ_RING_BUFFER_MONITOR_MILLIS * 4);
                    } else {
                        LOGGER.info("RB is {}% full", (int) (100 * (1.0 - ((double) l / stats.capacity()))));
                    }
                }
            }
        }
    }

    private static class BufferByteStore {
        static ThrowingBiFunction<Long, Integer, BytesStore, Exception> create(final String basePath) {
            return createMappedStore(basePath);
        }

        static ThrowingBiFunction<Long, Integer, BytesStore, Exception> createMappedStore(final String basePath) {
            final String mappedFile;
            mappedFile = fileNameToRingBufferFileName(basePath);
            return (size, readers) -> ChronicleRingBuffer.mappedBytes(new File(mappedFile), ChronicleRingBuffer.sizeFor(size, readers));
        }
    }
}
