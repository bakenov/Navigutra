package com.anz.markets.efx.fox.firewall.metric;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.fox.firewall.metric.MatchableMetric;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MatchableMetricTest {
    @Mock
    private ExecutionReportDecoder executionReport;
    @Mock
    private NewOrderSingleDecoder newOrderSingle;
    @Mock
    private Metric delegateMetric;
    @Mock
    private ExecutionReportMatcher matcher;

    private MatchableMetric matchableMetric;

    @BeforeEach
    void setUp() {
        matchableMetric = new MatchableMetric(delegateMetric, matcher);
    }

    @Test
    void accept_should_delegate_accept_when_matcher_succeeds() {
        //given
        when(matcher.test(executionReport)).thenReturn(true);

        //when
        matchableMetric.accept(executionReport, 100);

        //then
        verify(delegateMetric).accept(executionReport, 100);
    }

    @Test
    void accept_should_NOT_delegate_accept_when_matcher_fails() {
        //given
        when(matcher.test(executionReport)).thenReturn(false);

        //when
        matchableMetric.accept(executionReport, 100);

        //then
        verify(delegateMetric, never()).accept(executionReport, 100);
    }

    @Test
    void currentValue() {
        //when
        matchableMetric.currentValue(100);
        //then
        verify(delegateMetric).currentValue(100);
    }

    @Test
    void nextValue() {
        //when
        matchableMetric.nextValue(newOrderSingle, 100);
        //then
        verify(delegateMetric).nextValue(newOrderSingle,100);
    }

}