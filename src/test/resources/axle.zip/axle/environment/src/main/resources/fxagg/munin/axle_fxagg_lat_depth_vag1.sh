#!/bin/bash
# (c) 2016 ANZ

TITLE="Depth Latency (VAG1)"
GREPSTR="LatencyDepthPerVag.VAG1"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_lat.common