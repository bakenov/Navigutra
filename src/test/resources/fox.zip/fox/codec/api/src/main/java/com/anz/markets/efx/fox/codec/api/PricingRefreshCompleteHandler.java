package com.anz.markets.efx.fox.codec.api;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;

public interface PricingRefreshCompleteHandler extends MessageDecoder.Handler {
    @Override
    default void onMessageStart(final int source, final long sourceSeq) {
    }

    void onBody(Body body);

    @Override
    default void onMessageComplete() {
    }

    interface Body {
        long instrumentId();
        boolean forceSnapshot();
    }

    @FunctionalInterface
    interface DecoderFactory<M> extends MessageDecoder.Factory<M, PricingRefreshCompleteHandler>, SorDecoders.DecoderFactory<M> {
        @Override
        default MessageDecoder<M> create(final SorHandlerSupplier sorHandlerSupplier, final MessageDecoder.ForwardingLookup<M> forwardingLookup) {
            return create((Supplier<PricingRefreshCompleteHandler>) sorHandlerSupplier::pricingRefreshComplete, forwardingLookup);
        }
    }
}
