// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.util.List;

import quickfix.SessionID;

/**
 * Main application class used to run the application specifically in
 * "command-line" mode - and deals with Script reading and starting the quickfix
 * session.
 */
public class FIXClientApplication
{
    private final String               scriptPath;
    private final String               quickfixConfigPath;
    private final IMessageFlowListener messageFlowListener;
    private final String               senderCompId;
    private final String               senderLocationId;

    /**
     * Main method used to run the application from the command line.
     * 
     * @param args
     *            requires 1 argument - the path to the script file. <br>
     *            optionally accepts a second argument - the path to the
     *            quickfix configuration.
     */
    public static void main(final String[] args)
    {
        if (args.length == 0 || args.length > 2)
        {
            System.out.println("\nInvalid Number of arguments");
            System.out.println("Required number of arguments = 1 or 2:");
            System.out.println("  1 - path to script");
            System.out.println("  2 - (optional) path to quickfix config");
            System.exit(1);
        }

        // Construct the FIX app object and start it running.
        final String scriptPath = args[0];
        final String quickFixConfigPath = args.length == 2 ? args[1] : null;
        final IMessageFlowListener messageFlowListener = new ScriptMessageFlowListener();
        final FIXClientApplication app = new FIXClientApplication(scriptPath,
                quickFixConfigPath,
                messageFlowListener);

        try
        {
            app.runScript();
        }
        catch (final Exception ex)
        {
            messageFlowListener.logError("Error loading and/or parsing script",
                    ex);
            System.exit(1);
        }
    }

    /**
     * Constructor
     * 
     * @param scriptPath
     *            path to the XML script to be run.
     * @param quickfixConfigPath
     * @param messageFlowListener
     */
    public FIXClientApplication(final String scriptPath,
                                final String quickfixConfigPath,
                                final IMessageFlowListener messageFlowListener)
    {
        this(scriptPath,
                quickfixConfigPath,
                QuickFixConfig.getSenderCompID(),
                QuickFixConfig.getSenderLocationID(),
                messageFlowListener);
    }

    /**
     * @param scriptPath
     * @param quickfixConfigPath
     * @param messageFlowListener
     * @param senderCompId
     * @param senderLocationId
     */
    public FIXClientApplication(final String scriptPath,
                                final String quickfixConfigPath,
                                final String senderCompId,
                                final String senderLocationId,
                                final IMessageFlowListener messageFlowListener)
    {
        this.scriptPath = scriptPath;
        this.quickfixConfigPath = quickfixConfigPath;
        this.senderCompId = senderCompId;
        this.senderLocationId = senderLocationId;
        this.messageFlowListener = messageFlowListener;
    }

    /**
     * Method used to parse and execute the script.
     * 
     * @throws Exception
     *             indicates parse error or execution error.
     */
    public void runScript() throws Exception
    {
        this.messageFlowListener.logStatusText("Loading script");

        final ScriptReader reader = new ScriptReader();
        reader.parseScript(this.scriptPath);
        if (reader.hasErrors())
        {
            final String errMsg = "Script contains "
                    + reader.getErrors().size()
                    + " errors";

            this.messageFlowListener.logStatusText(errMsg);
            for (final String error : reader.getErrors())
            {
                this.messageFlowListener.logError(error, null);
            }
            throw new RuntimeException(errMsg);
        }

        this.messageFlowListener.logStatusText("Script loaded and parsed");
        if (executeScript(reader.getFIXMessages()))
        {
            this.messageFlowListener.logStatusText("Script completed successfully");
        }
    }

    /**
     * Actually performs the execution: logs in, runs the script, logs out
     * again.
     * 
     * @param scriptedMessages
     * @throws Exception
     */
    private boolean executeScript(final List<FIXMessage> scriptedMessages)
    {
        final QuickFIXApplication fixApplication = new QuickFIXApplication(this.quickfixConfigPath,
                this.messageFlowListener);
        boolean success = false;

        try
        {
            final SessionID sessionID = fixApplication.login(this.senderCompId,
                    this.senderLocationId);

            final ScriptRunner runner = new ScriptRunner(sessionID,
                    scriptedMessages,
                    fixApplication.getReceivedMessageQueue(),
                    this.messageFlowListener);

            runner.exec();

            success = true;
        }
        catch (final Exception e)
        {
            this.messageFlowListener.logError("Unexpected error running script",
                    e);
        }
        finally
        {
            try
            {
                fixApplication.logout();
            }
            catch (final RuntimeException ex)
            {
                this.messageFlowListener.logError("Unexpected error during logout",
                        ex);
            }
        }

        return success;
    }
}
