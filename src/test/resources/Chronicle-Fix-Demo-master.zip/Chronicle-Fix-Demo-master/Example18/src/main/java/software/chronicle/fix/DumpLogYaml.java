package software.chronicle.fix;

import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.parsers.MessageParser;

import java.io.FileNotFoundException;

public class DumpLogYaml {

    public static void main(String[] args) throws FileNotFoundException {

        String basePath = args.length > 0 ? args[0] : "filestore/sender/target";

        new software.chronicle.fix.tools.DumpLogYaml(new MessageParser(), MessageNotifier.class).dump(basePath);
    }

}

