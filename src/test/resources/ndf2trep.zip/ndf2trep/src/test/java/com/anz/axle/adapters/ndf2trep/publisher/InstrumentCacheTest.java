package com.anz.axle.adapters.ndf2trep.publisher;


import org.junit.Test;

import com.anz.markets.efx.ngaro.api.SecurityType;
import static org.assertj.core.api.Assertions.assertThat;

public class InstrumentCacheTest {
    @Test
    public void testInstrumentCache() {
        InstrumentCache cache = new InstrumentCache();

        assertThat(cache.lookup(SecurityType.FXNDF, "EBS", "USDAUD")).isEqualTo("FXNDF_EBS_USDAUD");
        assertThat(cache.lookup(SecurityType.FXNDF, "EBS", "USDAUD")).isEqualTo("FXNDF_EBS_USDAUD");
        assertThat(cache.lookup(SecurityType.FXNDF, "EBS", "USDCNY")).isEqualTo("FXNDF_EBS_USDCNY");
        assertThat(cache.lookup(SecurityType.FXNDF, "EBS", "USDXXX")).isEqualTo("FXNDF_EBS_USDXXX");

        assertThat(cache.lookup(null, "EBS", "USDAUD")).isNull();
        assertThat(cache.lookup(SecurityType.FXNDF, null, "USDAUD")).isNull();
        assertThat(cache.lookup(SecurityType.FXNDF, "EBS", null)).isNull();
        assertThat(cache.lookup(null, null, "USDAUD")).isNull();
    }

}