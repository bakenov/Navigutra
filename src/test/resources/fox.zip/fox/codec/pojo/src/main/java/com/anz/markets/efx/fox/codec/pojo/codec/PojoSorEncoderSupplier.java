package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoSorEncoderSupplier implements SorEncoderSupplier {
    private final PojoPricingRefreshCompleteEncoder pricingRefreshCompleteEncoder;
    private final PojoTimerExpiryEncoder timerExpiryEncoder;
    private final PojoFirewallConfigEncoder firewallConfigEncoder;
    private final PojoVenueConfigEncoder venueConfigEncoder;
    private final PojoUserConfigEncoder userConfigEncoder;
    private final PojoInitialisationEncoder initialisationEncoder;
    private final PojoInstrumentConfigEncoder instrumentConfigEncoder;
    private final PojoVenueInstrumentConfigEncoder venueInstrumentConfigEncoder;

    public PojoSorEncoderSupplier(final Consumer<? super SorMessage> messageConsumer) {
        this(supplierOf(messageConsumer));
    }

    public PojoSorEncoderSupplier(final Supplier<? extends Consumer<? super SorMessage>> messageConsumerSupplier) {
        this.pricingRefreshCompleteEncoder = new PojoPricingRefreshCompleteEncoder(messageConsumerSupplier);
        this.timerExpiryEncoder = new PojoTimerExpiryEncoder(messageConsumerSupplier);
        this.firewallConfigEncoder = new PojoFirewallConfigEncoder(messageConsumerSupplier);
        this.venueConfigEncoder = new PojoVenueConfigEncoder(messageConsumerSupplier);
        this.userConfigEncoder = new PojoUserConfigEncoder(messageConsumerSupplier);
        this.initialisationEncoder = new PojoInitialisationEncoder(messageConsumerSupplier);
        this.instrumentConfigEncoder = new PojoInstrumentConfigEncoder(messageConsumerSupplier);
        this.venueInstrumentConfigEncoder = new PojoVenueInstrumentConfigEncoder(messageConsumerSupplier);
    }

    private static Supplier<? extends Consumer<? super SorMessage>> supplierOf(final Consumer<? super SorMessage> messageConsumer) {
        Objects.requireNonNull(messageConsumer);
        return () -> messageConsumer;
    }

    @Override
    public PojoPricingRefreshCompleteEncoder pricingRefreshCompleteEncoder() {
        return pricingRefreshCompleteEncoder;
    }

    @Override
    public TimerExpiryEncoder timerExpiryEncoder() {
        return timerExpiryEncoder;
    }

    @Override
    public FirewallConfigEncoder firewallConfigEncoder() {
        return firewallConfigEncoder;
    }

    @Override
    public VenueConfigEncoder venueConfig() {
        return venueConfigEncoder;
    }

    @Override
    public UserConfigEncoder userConfig() {
        return userConfigEncoder;
    }

    @Override
    public InitialisationEncoder initialisation() {
        return initialisationEncoder;
    }

    @Override
    public InstrumentConfigEncoder instrumentConfig() {
        return instrumentConfigEncoder;
    }

    @Override
    public VenueInstrumentConfigEncoder venueInstrumentConfig() {
        return venueInstrumentConfigEncoder;
    }
}
