package com.anz.markets.disco.data;

import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.marketdata.InstrumentAndMarket;

public interface Signals extends InstrumentAndMarket {

    long getExternalEventTimeNS();

    long getExternalSourceId();

    long getSignalsId();

    Instrument getInstrument();

    Market getMarket();

    Signal getSignal(int i);

    int getSize();

    Signal getSignal(SignalType signalType);

    boolean containsSignal(SignalType signalType);

}