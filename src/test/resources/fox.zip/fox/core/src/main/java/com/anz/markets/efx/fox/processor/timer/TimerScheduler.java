package com.anz.markets.efx.fox.processor.timer;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;

public interface TimerScheduler {
    long schedule(long millis, ExpiryHandler expiryHandler);
    boolean cancel(long timerId);

    interface ExpiryHandler {
        TimerGroup timerGroup();
        default boolean onExpiryCommand(long timerId, long triggeredTime, CommandContext commandContext) {return false;}
        default boolean onExpiryEvent(long timerId, long triggeredTime) {return false;}
    }
}
