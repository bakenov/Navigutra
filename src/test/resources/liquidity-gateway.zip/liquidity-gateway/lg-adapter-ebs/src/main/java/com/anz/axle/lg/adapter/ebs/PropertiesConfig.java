package com.anz.axle.lg.adapter.ebs;


import java.util.Properties;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.anz.axle.applicationboot.EnvironmentResolver;
import com.anz.axle.spring.config.NestedPropertiesFactoryBean;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
public class PropertiesConfig {

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer(@Qualifier("applicationProperties") final Properties properties) {
        final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        propertySourcesPlaceholderConfigurer.setProperties(properties);
        return propertySourcesPlaceholderConfigurer;
    }

    @Bean
    NestedPropertiesFactoryBean applicationProperties() {
        final NestedPropertiesFactoryBean propertiesFactoryBean = new NestedPropertiesFactoryBean();
        propertiesFactoryBean.setIgnoreResourceNotFound(true);
        propertiesFactoryBean.setEnv(EnvironmentResolver.environment());
        propertiesFactoryBean.setLocations(new String[]{
                "classpath:conf/market-data-request.properties",
                "classpath:conf/messaging-default.properties",
                "classpath:conf/messaging-${env}.properties",
                "classpath:conf/ebs-default.properties",
                "classpath:conf/ebs-" + System.getProperty("venue", Venue.EBS.name()) + "-${env}.properties",
                "classpath:${ebs.fix.user.password.file}"
        });
        propertiesFactoryBean.setLoadSystemProperties(true);
        return propertiesFactoryBean;
    }
}
