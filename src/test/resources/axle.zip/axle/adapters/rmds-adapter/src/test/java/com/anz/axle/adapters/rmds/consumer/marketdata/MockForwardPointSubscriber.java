package com.anz.axle.adapters.rmds.consumer.marketdata;

import com.anz.axle.adapters.rmds.consumer.ForwardPointSubscriber;
import com.anz.axle.datafabric.domain.trading.EntitySequenceType;

public class MockForwardPointSubscriber extends ForwardPointSubscriber {
   
    @Override
    public void init() {
        // Don't connect to D3/RMDS

        entitySequenceGenerator = entityFactory.createEntitySequenceGenerator("rmds-adapter.forward-points-quote-page", EntitySequenceType.FORWARD_POINTS_QUOTE_PAGE);
    }
}
