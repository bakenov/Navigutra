#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh daxa022z "rm -rf ~/axle/datafabric/workspace/*"
