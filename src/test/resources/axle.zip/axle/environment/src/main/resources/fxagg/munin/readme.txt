# Attention Unix Admin
# --------------------
# 1. please recreate the munin symlinks by running the following script as root:

create_munin_axle_links.sh

# 3. --IF INSTALLING DATAFABRIC--, please run the following script as root:

create_munin_datafabric_links.sh
