package com.anz.markets.disco;

public interface Module {

    String getName();

    void init(Stage stage);

    void finish();
}
