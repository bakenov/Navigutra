package com.anz.markets.prophet.pricer.cross;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.util.AmountUnit;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

public class CrossRateManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private NoOpConsumer<ClientPrice> nfys;
        private ClientPrice clientPriceGPBUSD, clientPriceAUDUSD;
        private Consumer<ClientPrice> clientPriceConsumer;

        @Setup
        public void setup() throws IOException {
            CrossRateManagerTest.setupClass();
            nfys = new NoOpConsumer<>();
            final CrossRateManager crossRateManager = CrossRateManagerTest.createCrossRateManager(nfys);
            clientPriceGPBUSD = MidRateTestHelper.createClientPrice(Instrument.GBPUSD, 1.62, MidRateTestHelper.SPREAD);
            clientPriceAUDUSD = MidRateTestHelper.createClientPrice(Instrument.AUDUSD, 1, 0.76, MidRateTestHelper.SPREAD, AmountUnit.MILLIONS.toDollar(1_000));
            clientPriceConsumer = crossRateManager.consumerClientPrice();
        }
    }

    @Benchmark
    public long changePrice(@NotNull final Data data) throws Exception {
        mutate((PriceAndQtyImpl) data.clientPriceAUDUSD.getBids().get(0));
        mutate((PriceAndQtyImpl) data.clientPriceGPBUSD.getBids().get(0));
        data.clientPriceConsumer.accept(data.clientPriceAUDUSD);
        data.clientPriceConsumer.accept(data.clientPriceGPBUSD);
        return data.nfys.size();
    }

    private void mutate(final PriceAndQtyImpl clientPricePoint) {
        clientPricePoint.setPrice(clientPricePoint.getPrice() + (Math.random() - 0.5d));
    }
}
