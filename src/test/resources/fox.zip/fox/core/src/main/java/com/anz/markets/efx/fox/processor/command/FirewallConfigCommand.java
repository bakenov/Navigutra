package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.sbe.FirewallConfigSbeDecoder;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class FirewallConfigCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(FirewallConfigCommand.class);

    private final CommandContext commandContext;
    private Firewall inboundFirewall;
    private final FirewallConfigSbeDecoder firewallConfigDecoder = new FirewallConfigSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public FirewallConfigCommand(final CommandContext commandContext,
                                 final Firewall inboundFirewall) {
        this.commandContext = Objects.requireNonNull(commandContext);
        this.inboundFirewall = Objects.requireNonNull(inboundFirewall);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!firewallConfigDecoder.wrap(message)) return false;

        logMessage();

        inboundFirewall.onFirewallConfigRuleRequest(commandContext, firewallConfigDecoder);
        logMessage();
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        firewallConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Firewall Config Command: {}", stringBuilder);
    }
}
