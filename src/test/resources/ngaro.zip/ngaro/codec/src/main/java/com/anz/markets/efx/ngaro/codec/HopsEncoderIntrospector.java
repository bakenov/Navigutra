package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ExpandableAsciiString;

final class HopsEncoderIntrospector implements Hops.EncoderIntrospector {

    private final Hops.Handler introspectionHandler;
    private final IntrospectingEncoder<?> introspectingEncoder = new IntrospectingEncoder<>();

    HopsEncoderIntrospector(final Hops.Handler introspectionHandler) {
        this.introspectionHandler = Objects.requireNonNull(introspectionHandler);
    }

    @Override
    public <T> Hops.Encoder<T> introspect(final Hops.Encoder<T> encoder) {
        return introspectingEncoder.init(encoder);
    }

    private final class IntrospectingEncoder<T> implements Hops.Encoder<T> {
        private Hops.Encoder<T> encoder;
        private Next<T> next;
        private Body<T> body;

        <T> Hops.Encoder<T> init(final Hops.Encoder<T> encoder) {
            @SuppressWarnings("unchecked") //we can do this cast because all generic members will be compatible with the encoder's <T>
            final IntrospectingEncoder<T> castEncoder = ((IntrospectingEncoder<T>)this);
            return castEncoder.initInternal(encoder);
        }
        private Hops.Encoder<T> initInternal(final Hops.Encoder<T> encoder) {
            this.encoder = Objects.requireNonNull(encoder);
            this.next = null;
            this.body = null;
            this.handlerBody.reset();
            return this;
        }


        private final Next<T> introspectingNext = new Next<T>() {
            @Override
            public Body<T> next() {
                body = nonNull("IntrospectingEncoder.next", next).next();
                next = null;
                handlerBody.next();
                return introspectingBody;
            }

            @Override
            public T hopsComplete() {
                final T trailer = nonNull("IntrospectingEncoder.next", next).hopsComplete();
                introspectionHandler.onHopsComplete(0);
                next = null;
                return trailer;
            }
        };

        private HandlerBody handlerBody = new HandlerBody();
        private final Body<T> introspectingBody = new Body<T>() {
            @Override
            public StringEncoder<Body<T>> hopCompId() {
                nonNull("IntrospectingEncoder.body", body);
                return hopCompIdEncoder;
            }

            @Override
            public Body<T> hopMessageId(long messageId) {
                nonNull("IntrospectingEncoder.body", body);
                handlerBody.hopMessageId = messageId;
                return introspectingBody;
            }

            @Override
            public Body<T> hopReceivingTime(long nanosSinceEpoch) {
                nonNull("IntrospectingEncoder.body", body);
                handlerBody.hopReceivingTime = nanosSinceEpoch;
                return introspectingBody;
            }

            @Override
            public Body<T> hopSendingTime(long nanosSinceEpoch) {
                nonNull("IntrospectingEncoder.body", body);
                handlerBody.hopSendingTime = nanosSinceEpoch;
                return introspectingBody;
            }

            @Override
            public Body<T> next() {
                body = nonNull("IntrospectingEncoder.body", body).next();
                if (handlerBody.hopIndex >= 0) {
                    introspectionHandler.onHops_Body(handlerBody, handlerBody.hopIndex, handlerBody.hopsCount);
                }
                handlerBody.next();
                return introspectingBody;
            }

            @Override
            public T hopsComplete() {
                if (handlerBody.hopIndex >= 0) {
                    introspectionHandler.onHops_Body(handlerBody, handlerBody.hopIndex, handlerBody.hopsCount);
                }
                introspectionHandler.onHopsComplete(handlerBody.hopIndex + 1);
                final T trailer = nonNull("IntrospectingEncoder.body", body).hopsComplete();
                body = null;
                handlerBody.reset();
                return trailer;
            }
        };
        private final StringEncoder<Body<T>> hopCompIdEncoder = AsciiStringEncoder.forExpandableAsciiString(introspectingBody, handlerBody.hopCompId);

        @Override
        public Next<T> hopsStart(int maxEntries) {
            next = nonNull("IntrospectingEncoder.encoder", encoder).hopsStart(maxEntries);
            introspectionHandler.onHopsStart(maxEntries);
            handlerBody.init(maxEntries);
            encoder = null;
            return introspectingNext;
        }

        @Override
        public T hopsEmpty() {
            final T trailer = nonNull("IntrospectingEncoder.encoder", encoder).hopsEmpty();
            introspectionHandler.onHopsStart(0);
            introspectionHandler.onHopsComplete(0);
            encoder = null;
            return trailer;
        }
    }

    private static final class HandlerBody implements Hops.Handler.Body {
        private final ExpandableAsciiString hopCompId = new ExpandableAsciiString();
        private final StringDecoder hopCompIdDecoder = AsciiStringDecoder.forAsciiString(hopCompId);
        private int hopsCount;
        private int hopIndex;
        private long hopMessageId;
        private long hopReceivingTime;
        private long hopSendingTime;

        @Override
        public StringDecoder hopCompId() {
            return hopCompIdDecoder;
        }

        @Override
        public long hopMessageId() {
            return hopMessageId;
        }

        @Override
        public long hopReceivingTime() {
            return hopReceivingTime;
        }

        @Override
        public long hopSendingTime() {
            return hopSendingTime;
        }

        void reset() {
            this.hopCompId.clear();
            this.hopIndex = -1;
            this.hopMessageId = 0;
            this.hopReceivingTime = 0;
            this.hopSendingTime = 0;
        }
        void init(final int hopsCount) {
            reset();
            this.hopsCount = hopsCount;
        }
        void next() {
            final int nextIndex = hopIndex + 1;
            reset();
            this.hopIndex = nextIndex;
        }
    }

    private static <E> E nonNull(final String name, final E encoder) {
        if (encoder != null) return encoder;
        throw new IllegalStateException(name + " is not initialised (hint: is encoding or decoding order violated?)");
    }
}
