package com.anz.markets.prophet.positionrisk;

import net.openhft.chronicle.core.OS;

import java.io.File;
import java.io.IOException;

public class FileUtil {
    public static String tmpFile(String id) throws IOException {
        return tmpFile(id, "");
    }

    public static String tmpFile(String id, String after) throws IOException {
        final String basePath = OS.TARGET + "/deleteme_" + id + after + "_" + System.currentTimeMillis();
        final File file = new File(basePath);
        file.deleteOnExit();
        return file.getCanonicalPath();
    }
}
