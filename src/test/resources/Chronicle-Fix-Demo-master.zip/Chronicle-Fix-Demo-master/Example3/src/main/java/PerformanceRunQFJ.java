import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.jlbh.JLBH;
import net.openhft.chronicle.core.jlbh.JLBHOptions;
import net.openhft.chronicle.core.jlbh.JLBHTask;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.core.util.NanoSampler;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.Marshallable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import quickfix.*;
import quickfix.field.*;
import quickfix.mina.SessionConnector;
import software.chronicle.fix.PerformanceConfig;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.util.Date;
import java.util.concurrent.TimeoutException;

/**
 * TODO: numbers
 */
public class PerformanceRunQFJ implements JLBHTask {
    private static final String BEGIN_STRING = "FIX.4.2";
    private static final Date TRANSACT_TIME = new Date();
    private static final Logger LOGGER = LoggerFactory.getLogger(PerformanceRunQFJ.class);
    private static final MessageFactory messageFactory = new quickfix.fix42.MessageFactory();
    private static final Message executionReport = messageFactory.create(BEGIN_STRING, MsgType.EXECUTION_REPORT);
    private static final Message newOrderSingle = messageFactory.create(BEGIN_STRING, MsgType.ORDER_SINGLE);
    private static final StringBuilder clOrdId = new StringBuilder();

    private static final String HOST_PORT = "host.port";
    private static PerformanceConfig config;

    static {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(false);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    private JLBH jlbh;
    private NanoSampler createExecutionReportSampler;
    private Session client, server;

    public static void main(String[] args) throws IOException {
        ClassAliasPool.CLASS_ALIASES.addAlias(PerformanceConfig.class, RollCycles.class);
        SingleChronicleQueueBuilder.addAliases();
        config = Marshallable.fromFile(PerformanceConfig.class, "performance.yaml");

        if (config.hostPort.equals(HOST_PORT)) {
            TCPRegistry.reset();
            TCPRegistry.createServerSocketChannelFor(config.hostPort);
            ServerSocketChannel ssc = TCPRegistry.acquireServerSocketChannel(config.hostPort);
            ssc.close();
        }

        JLBHOptions jlbhOptions = new JLBHOptions()
                .iterations(config.iterations)
                .throughput(config.throughput)
                .runs(config.runs)
                .recordOSJitter(true)
                .accountForCoordinatedOmmission(true)
                .warmUpIterations(150_000)
                .jlbhTask(new PerformanceRunQFJ());
        JLBH jlbh = new JLBH(jlbhOptions);
        jlbh.start();
    }

    private static Message createExecutionReport(String clOrdID) {
        executionReport.setUtcTimeStamp(TransactTime.FIELD, TRANSACT_TIME);
        executionReport.setChar(Side.FIELD, '1');
        executionReport.setString(ClOrdID.FIELD, clOrdID);
        executionReport.setDouble(AvgPx.FIELD, 23.56);
        return executionReport;
    }

    @Override
    public void init(JLBH jlbh) {
        this.jlbh = jlbh;

        try {
            if (config.isServer) {
                createExecutionReportSampler = this.jlbh.addProbe("createExecutionReportSampler");

                server = buildEngine(false);
            }
            if (config.isClient) {
                client = buildEngine(true);
                client.logon();
                int counter = 0;
                while (!client.isLoggedOn()) {
                    Jvm.pause(1000);
                    if (++counter > 300) {
                        throw new TimeoutException("while waiting to become loggedin");
                    }
                }
            }
        } catch (Exception t) {
            Jvm.rethrow(t);
        }

    }

    @Override
    public void complete() {
        System.exit(0);
    }

    @Override
    public void run(long startTimeNs) {
        if (!config.isClient) {
            return;
        }

        newOrderSingle.setChar(OrdType.FIELD, '2');
        newOrderSingle.setChar(Side.FIELD, '1');
        newOrderSingle.setString(Symbol.FIELD, "LCOM1");
        clOrdId.setLength(0);
        clOrdId.append(startTimeNs);
        newOrderSingle.setString(ClOrdID.FIELD, clOrdId.toString());
        newOrderSingle.setChar(HandlInst.FIELD, '3');
        newOrderSingle.setUtcTimeStamp(TransactTime.FIELD, TRANSACT_TIME);
        newOrderSingle.setDouble(OrderQty.FIELD, 1);
        newOrderSingle.setDouble(Price.FIELD, 200.0);
        newOrderSingle.setChar(TimeInForce.FIELD, '0');
        newOrderSingle.setString(MaturityMonthYear.FIELD, "201106");
        newOrderSingle.setString(SecurityType.FIELD, "FUT");
        newOrderSingle.setString(IDSource.FIELD, "5");
        newOrderSingle.setString(SecurityID.FIELD, "LCOM1");
        newOrderSingle.setString(Account.FIELD, "ABCTEST1");
        client.send(newOrderSingle);
    }

    private Session buildEngine(boolean initiator) throws IOException, ConfigError {
        InetSocketAddress address = TCPRegistry.lookup(config.hostPort);
        SessionSettings sessionSettings = new SessionSettings(PerformanceRunQFJ.class.getResourceAsStream("/perf_quickfix.ini"));
        if (initiator) {
            sessionSettings.setString("SocketConnectHost", address.getHostName());
            sessionSettings.setLong("SocketConnectPort", address.getPort());
        } else {
            sessionSettings.setString("SocketAcceptAddress", address.getHostName());
            sessionSettings.setLong("SocketAcceptPort", address.getPort());
        }
        FileStoreFactory fileStoreFactory = new FileStoreFactory(sessionSettings);
        // turn off all logging to stdout
        ScreenLogFactory logFactory = new ScreenLogFactory(false, false, false, false);

        SessionConnector connector;
        if (initiator) {
            connector = new SocketInitiator(new MyNotifier(),
                    fileStoreFactory, sessionSettings, logFactory,
                    messageFactory);
        } else {
            connector = new SocketAcceptor(new MyNotifier(),
                    fileStoreFactory, sessionSettings, logFactory,
                    messageFactory);
        }
        connector.start();
        SessionID sessionId = connector.getSessions().get(0);
        return Session.lookupSession(sessionId);
    }

    private class MyNotifier implements Application {
        long next = System.currentTimeMillis() + 5000;

        private void onNewOrderSingle(Message newOrderSingle) throws FieldNotFound {
            if (next < System.currentTimeMillis()) {
                System.out.println("------- " + newOrderSingle.getHeader().getInt(MsgSeqNum.FIELD));
                next += 5000;
            }
            long now = System.nanoTime();
            Message executionReport = createExecutionReport(newOrderSingle.getString(ClOrdID.FIELD));
            long nanoTime = System.nanoTime() - now;
            createExecutionReportSampler.sampleNanos(nanoTime);
            if (!config.isClient) {
                jlbh.sample(nanoTime);
            }
            server.send(executionReport);
        }

        public void onExecutionReport(Message executionReport) throws FieldNotFound {
            String clOrdId = executionReport.getString(ClOrdID.FIELD);
            long startTime = Long.parseLong(clOrdId);
            long nanoTime = System.nanoTime() - startTime;
            jlbh.sample(nanoTime);
        }

        @Override
        public void onCreate(SessionID sessionID) {
//            LOGGER.info("onCreate {}", sessionID);
        }

        @Override
        public void onLogon(SessionID sessionID) {
//            LOGGER.info("onLogon {}", sessionID);
        }

        @Override
        public void onLogout(SessionID sessionID) {
        }

        @Override
        public void toAdmin(Message message, SessionID sessionID) {
//            LOGGER.info("toAdmin {} {}", message, sessionID);
        }

        @Override
        public void fromAdmin(Message message, SessionID sessionID) throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue, RejectLogon {
//            LOGGER.info("fromAdmin {} {}", message, sessionID);
        }

        @Override
        public void toApp(Message message, SessionID sessionID) throws DoNotSend {
//            LOGGER.info("toApp {} {}", message, sessionID);
        }

        @Override
        public void fromApp(Message message, SessionID sessionID) throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue, UnsupportedMessageType {
//            LOGGER.info("fromApp {} {}", message, sessionID);
            String msgType = message.getHeader().getString(MsgType.FIELD);
            if (msgType.equals(MsgType.ORDER_SINGLE)) {
                onNewOrderSingle(message);
            } else if (msgType.equals(MsgType.EXECUTION_REPORT)) {
                onExecutionReport(message);
            } else {
                System.out.println("unrecognised: " + message);
            }
        }
    }
}
