package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import org.agrona.DirectBuffer;

import java.util.Objects;

public final class DecodingMessageHandler implements MessageHandler {

    private final MessageDecoder<SbeMessage> pricingDecoder;
    private final SbeMessageForReading sbeMessage;

    public DecodingMessageHandler(final MessageDecoder<SbeMessage> pricingDecoder) {
        this.pricingDecoder = Objects.requireNonNull(pricingDecoder);
        this.sbeMessage = new SbeMessageForReading();
    }

    @Override
    public void onMessage(final Topic topic, final DirectBuffer buffer, final int offset, final int length, final long receiveTimeNanosSinceEpoch) {
        try {
            this.pricingDecoder.decode(sbeMessage.wrap(buffer, offset, length));
        } finally {
            sbeMessage.unwrap();
        }
    }
}
