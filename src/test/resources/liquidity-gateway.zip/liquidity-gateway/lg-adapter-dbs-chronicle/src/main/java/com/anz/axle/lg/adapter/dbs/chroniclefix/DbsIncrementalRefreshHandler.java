package com.anz.axle.lg.adapter.dbs.chroniclefix;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSide;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.MarketDataIncrementalRefresh_MDEntriesGrp_1;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.MDQuoteType;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.MDUpdateAction;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import net.openhft.chronicle.bytes.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.staticcode.messages.FixMessage;

import java.util.Objects;
import java.util.function.Consumer;

public final class DbsIncrementalRefreshHandler implements ChronicleMessageHandler<MarketDataIncrementalRefresh> {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbsIncrementalRefreshHandler.class);
    private static final double DEFAULT_FORWARD_POINTS = 0;
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();
    private static final int MIN_QTY = 0;

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public DbsIncrementalRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                        final PricingEncoderLookup pricingEncoderLookup,
                                        final PrecisionClock precisionClock,
                                        final SubscriptionManager subscriptionManager,
                                        final String senderCompId,
                                        final String compId,
                                        final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender,
                                        final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final MarketDataIncrementalRefresh message) throws IllegalArgumentException {
        accept(message, Long.MIN_VALUE);
    }

    @Override
    public void accept(final MarketDataIncrementalRefresh message, final long receivedByAdapterTimestampNanos) throws IllegalArgumentException {

        final long receivingTimeNanos = receivedByAdapterTimestampNanos <= 0 ? precisionClock.nanos() : receivedByAdapterTimestampNanos;

        LOGGER.debug("MarketDataIncrementalRefresh received: {}", message);
        final Bytes mdReqID = message.mDReqID();
        final int mdRequestId = (int) mdReqID.parseLong();
        final long entriesCount = message.noMDEntries();

        if (entriesCount > 0) {
            final long sequenceNumber = message.msgSeqNum();
            final long messageId = sequenceNumber;
            final long sendingTimeNanos = message.sendingTime();

            final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);
            if (subscription == null) {
                LOGGER.warn("No subscription found for requestId: {}. Discard : {}", mdRequestId, message);
                return;
            }
            final StringToIntCache entryId2IntCache = subscription.stringToIntCache();
            final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
            // one HashMap but object has a complex hashCode
            final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
            flagsAppender.accept(encoder.mdFlags());

            encoder
                .senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .sendingTime(sendingTimeNanos)
                .referenceSpotDate().encodeNull()
                .tradeDate().encodeNull();

            final long groups = message.noMDEntries();
            if (groups > 0) {
                final MarketDataIncrementalRefresh_MDEntriesGrp_1 priceEntryGroup = message.marketDataIncrementalRefresh_MDEntriesGrp_1(0);
                encoder.settlDate().encodeFormatted(priceEntryGroup.mDEntryDate(), DATE_DECODER);
            }

            final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next = encoder.entriesStart((int) entriesCount);

            for (int i = 0; i < groups; i++) {
                final MarketDataIncrementalRefresh_MDEntriesGrp_1 priceEntryGroup = message.marketDataIncrementalRefresh_MDEntriesGrp_1(i);

                final char mdEntryType = priceEntryGroup.mDEntryType();
                final EntryType side = FixSide.from(mdEntryType);
                final String fixSymbol = priceEntryGroup.symbol();
                subscription.validateSymbol(fixSymbol);

                final double forwardPoints = forwardPoints(priceEntryGroup, DEFAULT_FORWARD_POINTS);

                final double mdEntryPx = nanToZero(priceEntryGroup. mDEntryPx());
                final double mdEntrySize = nanToZero(priceEntryGroup.mDEntrySize());

                final boolean indicative = priceEntryGroup.mDQuoteType() != MDQuoteType.TRADEABLE;

                final UpdateAction updateAction = updateAction(priceEntryGroup.mDUpdateAction());

                final int mdEntryId;
                if (updateAction == UpdateAction.DELETE) {
                    mdEntryId = entryId2IntCache.remove(priceEntryGroup.mDEntryID());
                } else {
                    mdEntryId = entryId2IntCache.put(priceEntryGroup.mDEntryID());
                }

                final IncrementalRefreshEncoder.MdEntries.Body mdEntries_body = mdEntries_Next.next()
                        .mdUpdateAction(updateAction)
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(side)
                        .mdEntrySize(mdEntrySize)
                        .minQty(MIN_QTY)
                        .mdEntryPx(mdEntryPx)
                        .mdEntryForwardPoints(forwardPoints)
                        .mdEntryId(mdEntryId)
                        .mdEntryRefId(0)
                        .quoteEntryId(0);

                if (indicative) {
                    mdEntries_body.mdEntryFlags().add(Flag.INDICATIVE);
                }
            }

            mdEntries_Next.entriesComplete()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .messageComplete();
        }
    }

    private double forwardPoints(final MarketDataIncrementalRefresh_MDEntriesGrp_1 priceEntryGroup, final double defaultForwardPoints) {
        if (priceEntryGroup.mDEntryForwardPoints() != FixMessage.UNSET_DOUBLE) {
            return nanToZero(priceEntryGroup.mDEntryForwardPoints());
        } else {
            return defaultForwardPoints;
        }
    }

    private UpdateAction updateAction(final char mdUpdateAction) {

        switch (mdUpdateAction) {
            case MDUpdateAction.NEW: return UpdateAction.NEW;
            case MDUpdateAction.DELETE: return UpdateAction.DELETE;
            case MDUpdateAction.CHANGE: return UpdateAction.CHANGE;
            default:
                throw new RuntimeException("Unsupported update action " + mdUpdateAction);
        }
    }

    private double nanToZero(final double value) {
        return Double.isNaN(value) ? 0.0 : value;
        //TODO replace this with generated Double unset value as 0 not NaN
    }
}
