package com.anz.markets.efx.fox.processor.state;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.RegulatoryTradeIds;
import com.anz.markets.efx.trading.codec.api.StrategyParameters;

public class ParentExecutionReportPublisher {

    public static long newExecReportAndGetOrderId(final CommandContext commandContext,
                                                  final NewOrderSingleDecoder newOrderSingleDecoder) {
        final long orderId = commandContext.idGenerator().getAsLong();
        publishExecutionReport(commandContext, newOrderSingleDecoder,
                orderId, ExecType.NEW, OrderStatus.NEW , null);
        return orderId;
    }

    public static void rejectedExecReport(final CommandContext commandContext,
                                          final NewOrderSingleDecoder newOrderSingleDecoder,
                                          final String rejectText) {
        publishExecutionReport(commandContext, newOrderSingleDecoder,
                commandContext.idGenerator().getAsLong(), ExecType.REJECTED, OrderStatus.REJECTED , rejectText);
    }

    public static void publishExecutionReport(final CommandContext commandContext,
                                            final NewOrderSingleDecoder newOrderSingleDecoder,
                                            final long orderId,
                                            final ExecType execType,
                                            final OrderStatus orderStatus,
                                            final String rejectText) {
        final int source = commandContext.source();
        final long sourceSeq = commandContext.idGenerator().getAsLong();

        final ExecutionReportEncoder.Body executionReportEncoderBody = commandContext.tradingEncoderSupplier().executionReport()
                .messageStart(source, sourceSeq)
                .senderCompId().encode(commandContext.senderCompId())
                .targetCompId().encodeFrom(newOrderSingleDecoder.body().senderCompId())
                .messageId(sourceSeq)
                .orderId().encodeLong(orderId)
                .clOrdId().encodeFrom(newOrderSingleDecoder.body().clOrdId())
                .origClOrdId().encodeFrom(newOrderSingleDecoder.body().clOrdId())
                .clOrdLinkId().encodeFrom(newOrderSingleDecoder.body().clOrdLinkId())
                .marketId().encodeFrom(newOrderSingleDecoder.body().marketId())
                .execId().encodeLong(commandContext.idGenerator().getAsLong())
                .execType(execType)
                .ordStatus(orderStatus)
                .symbol().encodeFrom(newOrderSingleDecoder.body().symbol())
                .securityType(newOrderSingleDecoder.body().securityType())
                .settlType(newOrderSingleDecoder.body().settlType())
                .orderQty(newOrderSingleDecoder.body().orderQty())
                .ordType(newOrderSingleDecoder.body().ordType())
                .timeInForce(newOrderSingleDecoder.body().timeInForce())
                .displayQty(newOrderSingleDecoder.body().displayQty())
                .targetStrategyName().encodeFrom(newOrderSingleDecoder.body().targetStrategyName())
                .price(newOrderSingleDecoder.body().price())
                .side(newOrderSingleDecoder.body().side())
                .currency().encodeFrom(newOrderSingleDecoder.body().currency())
                .transactTime(commandContext.precisionClock().millis())
                .tradeDate().encodeEpochMillis(commandContext.precisionClock().millis())
                .settlDate().encodeFrom(newOrderSingleDecoder.body().settlDate())
                .settlCurrency().encodeFrom(newOrderSingleDecoder.body().settlCurrency())
                .expireTime(newOrderSingleDecoder.body().expireTime())
                .effectiveTime(newOrderSingleDecoder.body().effectiveTime())
                .leavesQty(newOrderSingleDecoder.body().orderQty())
                .lastQty(0)
                .lastPx(0)
                .cumQty(0)
                .avgPx(0)
                .midPx(0)
                .lastSpotRate(0)
                .lastForwardPoints(0)
                .commission(0)
                .commissionAdjAvgPx(0)
                .commissionAdjLastPx(0);

        final NewOrderSingleDecoder.Party parties = newOrderSingleDecoder.parties();
        final int partiesCount = parties.count();
        final ExecutionReportEncoder.Parties partiesGroup  = executionReportEncoderBody.partiesStart(partiesCount);
        for (NewOrderSingleDecoder.Party party : parties) {
            partiesGroup.next().partyRole(party.partyRole()).partyId().encodeFrom(party.partyId());
        }
        final NewOrderSingleDecoder.StrategyParameter strategyParameters = newOrderSingleDecoder.strategyParameters();
        final int strategyParametersCount = strategyParameters.count();
        final StrategyParameters.Encoder.Next<ExecutionReportEncoder.RegulatoryTradeIds> strategyParametersGroup = partiesGroup.partiesComplete().strategyParametersStart(strategyParametersCount);

        for (NewOrderSingleDecoder.StrategyParameter strategyParameter : strategyParameters) {
            strategyParametersGroup.next()
                    .strategyParameterName().encodeFrom(strategyParameter.strategyParameterName())
                    .strategyParameterValue().encodeFrom(strategyParameter.strategyParameterValue());
        }

        final NewOrderSingleDecoder.RegulatoryTradeId regulatoryTradeIds = newOrderSingleDecoder.regulatoryTradeIds();
        final int regulatoryTradeIdsCount = regulatoryTradeIds.count();
        final RegulatoryTradeIds.Encoder.Next<ExecutionReportEncoder.Hops> regulatoryTradeIdsGroup = strategyParametersGroup.strategyParametersComplete().regulatoryTradeIdsStart(regulatoryTradeIdsCount);
        for (NewOrderSingleDecoder.RegulatoryTradeId regulatoryTradeId : regulatoryTradeIds) {
            regulatoryTradeIdsGroup.next()
                    .id().encodeFrom(regulatoryTradeId.regulatoryTradeId())
                    .source().encodeFrom(regulatoryTradeId.regulatoryTradeIdSource());
        }
        final NewOrderSingleDecoder.Hop hops = newOrderSingleDecoder.hops();
        final int hopsCount = hops.count();
        final Hops.Encoder.Next<ExecutionReportEncoder.QuoteId> hopsGroup = regulatoryTradeIdsGroup.regulatoryTradeIdsComplete().hopsStart(hopsCount);
        for (NewOrderSingleDecoder.Hop hop : hops) {
            hopsGroup.next().hopReceivingTime(hop.hopReceivingTime())
                    .hopSendingTime(hop.hopSendingTime())
                    .hopMessageId(hop.hopMessageId())
                    .hopCompId().encodeFrom(hop.hopCompId());
        }
        hopsGroup.hopsComplete()
                .quoteId().encodeFrom(newOrderSingleDecoder.trailer().quoteId())
                .rejectText().encodeNullable(rejectText)
                .messageComplete();
    }

    private ParentExecutionReportPublisher() {
        throw new IllegalStateException("No ParentExecutionReportPublisher for you");
    }
}
