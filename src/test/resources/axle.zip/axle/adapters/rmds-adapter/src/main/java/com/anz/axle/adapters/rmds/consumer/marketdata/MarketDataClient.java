package com.anz.axle.adapters.rmds.consumer.marketdata;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.anz.markets.adapters.trep.Item;
import com.anz.markets.adapters.trep.consumer.Subscriber;
import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.ComplEvent;
import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.InterestSpec;
import com.reuters.rfa.session.MarketDataItemSub;
import com.reuters.rfa.session.event.ConnectionEvent;
import com.reuters.rfa.session.event.ConnectionStatus;
import com.reuters.rfa.session.event.MarketDataItemEvent;
import com.reuters.rfa.session.event.MarketDataSvcEvent;
import com.reuters.tibmsg.Tib;
import com.reuters.tibmsg.TibException;
import com.reuters.tibmsg.TibField;
import com.reuters.tibmsg.TibMfeedDict;
import com.reuters.tibmsg.TibMsg;

/**
 * Simple marketfeed subscriber
 * @author winstonr
 *
 */
public class MarketDataClient implements Client {
    private static final Logger logger = Logger.getLogger(MarketDataClient.class);
    private final Subscriber subscriber;
    TibMsg msg = new TibMsg();
    TibField field = new TibField();
    
    public MarketDataClient(Subscriber sub) {
        subscriber = sub;
    }

    @Override
    public void processEvent(Event event) {
        switch (event.getType()) {
            case Event.MARKET_DATA_ITEM_EVENT:
                processMarketDataItemEvent((MarketDataItemEvent)event);
                break;
            case Event.MARKET_DATA_SVC_EVENT:
                processMarketDataSvcEvent((MarketDataSvcEvent)event);
                break;
            case Event.CONNECTION_EVENT:
                processConnectionEvent((ConnectionEvent)event);
                break;
            case Event.COMPLETION_EVENT:
                processCompletionEvent((ComplEvent)event);
                break;
            default:
                if (logger.isInfoEnabled())
                    logger.info("Unhandled event type: " + event);
                break;
        }
    }
 
    /** 
     * Handler method for market data connection service events
     * @param marketDataSvcEvent
     */
    protected void processMarketDataSvcEvent(final MarketDataSvcEvent marketDataSvcEvent) {
        logger.info("Received MARKET_DATA_SVC_EVENT: " + marketDataSvcEvent);
    }
    
    
    protected void processCompletionEvent(final ComplEvent event ) {
        InterestSpec interestSpec = event.getInterestSpec();
        if (interestSpec != null && interestSpec instanceof MarketDataItemSub) {
            String itemName = ((MarketDataItemSub) interestSpec).getItemName();
            logger.info("Received COMPLETION_EVENT [Event stream closed: " +  event.isEventStreamClosed() + "item:" + itemName + ",event:" + event.toString() + "]");
            subscriber.onStreamClosed(itemName, event.getHandle());
        }
        else { 
            logger.info("Received COMPLETION_EVENT [Event stream closed: " +  event.isEventStreamClosed() + "item:<unknown>,event:" + event.toString() + "]");
            subscriber.onStreamClosed(event.getHandle());
        }
    }
    

    /**
     * Handler method for connection events
     * @param connectionEvent
     */
    protected void processConnectionEvent(ConnectionEvent connectionEvent) {
        ConnectionStatus status = connectionEvent.getConnectionStatus();
        logger.info("Received CONNECTION_EVENT: " + connectionEvent.getConnectionName() 
                + ", status=" + connectionEvent.getConnectionStatus());
        
        if (status.getState() == ConnectionStatus.UP)
            handleConnectionUp();
        else if (status.getState() == ConnectionStatus.DOWN) {
            if (status.getStatusCode() == ConnectionStatus.CLOSED)
                handleConnectionDown(status.getStatusText());   
        }
    }

    /**
     * Handler method for connection down events
     */
    protected void handleConnectionDown(final String text) {
       logger.warn("Connection down [reason=" + text + "]");
       subscriber.onConnectionDown();
    }

    /**
     * Handler method for connection up/restored events
     */
    private void handleConnectionUp() {
        logger.info("Connection up");
        subscriber.onConnectionUp();
    }

    /**
     * Process event type MARKET_DATA_ITEM_EVENT. Based on the message type of
     * the event take the appropriate actions.
     */
    protected void processMarketDataItemEvent(final MarketDataItemEvent marketDataItemEvent) {
        if ((marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.IMAGE)
                || (marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.UNSOLICITED_IMAGE)
                || (marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.UPDATE)
                || (marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.CORRECTION)
                || (marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.CLOSING_RUN)) {
            final byte[] data = marketDataItemEvent.getData();
            int length = (data != null ? data.length : 0);

            if (logger.isDebugEnabled())
                logger.debug("Received MARKET_DATA_ITEM_EVENT (data), service = "
                    + marketDataItemEvent.getServiceName() + ", dataFormat = "
                    + marketDataItemEvent.getDataFormat() + ", msgType = "
                    + marketDataItemEvent.getMarketDataMsgType() + ", item = "
                    + marketDataItemEvent.getItemName() + ", status = "
                    + marketDataItemEvent.getStatus() + ", datasize = " + length);

            if (length == 0) return;

            try {
                msg.ReUse();
                field.ReUse();
                msg.UnPack(data);
                
                Item item = new Item();
                item.setName(marketDataItemEvent.getItemName());
                Map<String, String> fieldMap = new HashMap<String, String>();
                
                for (int status = field.First(msg); status == TibMsg.TIBMSG_OK; status = field.Next()) {
                    if (logger.isTraceEnabled()) logger.trace("Processing:  " + field.Name());
                    String name = field.Name();
                    String value = null;
                    int fid = field.MfeedFid(); 
                    if (fid != 0) {
                        int index = fid >= 0 ? fid : TibMsg.GetMfeedDictPosFids() - fid;
                        TibMfeedDict dict = TibMsg.GetMfeedDictionary()[index];
                        if (dict.fhint == Tib.HINT_MFEED_ENUMERATED) {
                            String enumValueStr = field.StringData();
                            try {
                                int enumValue = Integer.parseInt(enumValueStr);
                                value = TibMsg.EnumIndex2Value(field.MfeedFid(), enumValue);
                            }
                            catch (NumberFormatException nfe) {
                                logger.warn("Error parsing enumerated value", nfe);
                            }
                        }
                        else {
                            value = field.StringData();
                        }
                    }
                    else {
                       value = field.StringData();
                    }
                    
                    fieldMap.put(name, value);
                }
                
                item.setFields(fieldMap);
                
                boolean refresh = marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.IMAGE;
                
                if (refresh)
                    subscriber.onRefresh(item);
                else
                    subscriber.onUpdate(item);
            }
            catch (TibException te) {
                logger.error("Unable to unpack data", te);
            }
        }
        else if (marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.STATUS) {
            if (logger.isDebugEnabled())
            logger.debug("Received MARKET_DATA_ITEM_EVENT (status), service = "
                    + marketDataItemEvent.getServiceName() + ", msgType = "
                    + marketDataItemEvent.getMarketDataMsgType() + ", item = "
                    + marketDataItemEvent.getItemName() + ", status = "
                    + marketDataItemEvent.getStatus().toString());

        }
        else if (marketDataItemEvent.getMarketDataMsgType() == MarketDataItemEvent.RENAME) {
            if (logger.isDebugEnabled())
            logger.debug("Received MARKET_DATA_ITEM_EVENT( rename ), service = "
                    + marketDataItemEvent.getServiceName() + ", msgType = "
                    + marketDataItemEvent.getMarketDataMsgType() + ", item = "
                    + marketDataItemEvent.getItemName() + ", new item name = "
                    + marketDataItemEvent.getNewItemName());
        }
        else {
            if (logger.isDebugEnabled())
            logger.debug("Received MARKET_DATA_ITEM_EVENT (misc), service = "
                    + marketDataItemEvent.getServiceName() + ", msgType = "
                    + marketDataItemEvent.getMarketDataMsgType() + ", item = "
                    + marketDataItemEvent.getItemName());
        }
    }
}

