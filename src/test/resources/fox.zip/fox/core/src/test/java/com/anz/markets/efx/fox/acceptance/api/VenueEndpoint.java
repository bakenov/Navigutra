package com.anz.markets.efx.fox.acceptance.api;

import java.util.Queue;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

public interface VenueEndpoint {
    Venue venue();
    Queue<PricingMessage> pricingQueue(final String symbol, final SecurityType securityType);
    Queue<PricingMessage> lastMarketTrade();
    Queue<TradingMessage> tradingRequest();
    Queue<TradingMessage> tradingResponse();
    ExecutionReport createExecutionReport();
    OrderCancelReject createOrderCancelReject();

    interface Lookup {
        VenueEndpoint lookup(Venue venue);
    }
}
