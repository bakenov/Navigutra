package com.anz.axle.lg.adapter.fast.chroniclefix;

import software.chronicle.fix.codegen.CodeGenerator;
import software.chronicle.fix.codegen.FixType;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class FastChronicleFixCodeGenerator {

    public static void main(final String[] args) throws IOException {
        final CodeGenerator cg = new CodeGenerator();
        cg.codePackage("com.anz.axle.lg.adapter.fast.chroniclefix.generated");
        cg.schemaFile("lg-adapter-fast-chronicle", "src/main/resources/conf/FIX42-fast.xml");
        cg.codeDirectory("lg-adapter-fast-chronicle", "target/generated-sources");
        cg.clean(true);

        // Retain decimal precision when reading floating point.
        cg.includeDecimalPrecision(false);

        // internal representation for datetimes
        cg.internalTimeUnit(TimeUnit.NANOSECONDS);

        cg.backwardCompatible(false);

        // this will cause the MDEntryID field to be bytes ( which has lower latency ) rather than a String
        // TODO: use AsciiString not Bytes
        cg.classOverride(f -> f.name().equals("MDEntryID") || f.name().equals("MDReqID") ? FixType.BYTES : null);
        cg.run();
    }
}