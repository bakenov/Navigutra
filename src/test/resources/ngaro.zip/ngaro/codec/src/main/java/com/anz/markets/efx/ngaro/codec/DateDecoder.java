package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;

import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDateEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

/**
 * Decoder for date only without time such as {@link LocalDate}.
 */
public interface DateDecoder {

    /** @return the days-since-epoch value, or 0 if the date was null */
    long decodeEpochDays();

    /** @return the year (1-9999), or 0 if the date was null */
    int decodeYear();

    /** @return the month (1-12), or 0 if the date was null */
    int decodeMonth();

    /** @return the day of the month (1-31), or 0 if the date was null */
    int decodeDay();

    /** @return the packed date, or 0 if the date was null */
    default int decodePacked(final LocalDatePacking packing) {
        return packing.pack(decodeYear(), decodeMonth(), decodeDay());
    }

    /** @return the milliseconds-since-epoch value, or 0 if the date was null */
    default long decodeEpochMillis() {
        return decodeEpochDays() * Epoch.MILLIS_PER_DAY;
    }

    /** @return the seconds-since-epoch value, or 0 if the date was null */
    default long decodeEpochSeconds() {
        return decodeEpochDays() * Epoch.SECONDS_PER_DAY;
    }

    /** @return true if value was not null */
    default <T> boolean decodeToFormatted(final T target, final ByteWriter<? super T> writer, final LocalDateFormat format) {
        return decodeToFormatted(target, writer, 0, format.getDefaultEncoder());
    }

    /** @return true if value was not null */
    default <T> boolean decodeToFormatted(final T target, final ByteWriter<? super T> writer, final int offset, final LocalDateEncoder encoder) {
        return encoder.encode(target, writer, offset, decodeYear(), decodeMonth(), decodeDay());
    }

    @Garbage(Garbage.Type.RESULT)
    default LocalDate decodeLocalDateOrNull() {
        final int year = decodeYear();
        final int month = decodeMonth();
        final int day = decodeDay();
        return (year == 0 & month == 0 & day == 0) ? null : LocalDate.of(year, month, day);
    }

    @Garbage(Garbage.Type.ANY)
    default String decodeToFormattedStringOrNull(final LocalDateFormat format) {
        return decodeToFormattedStringOrNull(format.getDefaultEncoder());
    }

    @Garbage(Garbage.Type.ANY)
    default String decodeToFormattedStringOrNull(final LocalDateEncoder encoder) {
        final StringBuilder sb = new StringBuilder(encoder.getDateFormat().getLength());
        final boolean nonNull = decodeToFormatted(sb, ByteWriter.STRING_BUILDER, 0, encoder);
        return nonNull ? sb.toString() : null;
    }

}