package com.anz.markets.efx.ngaro.collections;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class EnumObjTableTest {

    enum Column {
        C1,
        C2,
        C3,
        CX
    }

    enum Row {
        R1,
        R2,
        R3,
        RX
    }

    @Test
    public void testForEachColumnWithRowKeyConstraint() {
        EnumObjTable<Row, Column, String> enumTable = new EnumObjTable(Row.class, Column.class);
        enumTable.put(Row.R1, Column.C1, "R1-C1");
        enumTable.put(Row.R1, Column.C2, "R1-C2");
        enumTable.put(Row.R1, Column.C3, "R1-C3");
        enumTable.put(Row.R2, Column.CX, "R2-CX");
        enumTable.put(Row.R3, Column.CX, "R3-CX");

        ArrayList<Column> columns = new ArrayList<>();
        ArrayList<String> values = new ArrayList<>();

        enumTable.forEachColumnKeyWithRowKey((k, v) -> {
            columns.add(k);
            values.add(v);
        }, Row.R1);

        assertThat(columns.get(0), is(Column.C1));
        assertThat(columns.get(1), is(Column.C2));
        assertThat(columns.get(2), is(Column.C3));
        assertThat(values.get(0), is("R1-C1"));
        assertThat(values.get(1), is("R1-C2"));
        assertThat(values.get(2), is("R1-C3"));
    }

    @Test
    public void testToString() {
        EnumObjTable<Row, Column, String> enumTable = new EnumObjTable(Row.class, Column.class);
        enumTable.put(Row.R1, Column.C1, "R1-C1");
        enumTable.put(Row.R1, Column.C2, "R1-C2");
        Assert.assertThat(enumTable.toString(), is("R1/C1=R1-C1,R1/C2=R1-C2"));
    }
}