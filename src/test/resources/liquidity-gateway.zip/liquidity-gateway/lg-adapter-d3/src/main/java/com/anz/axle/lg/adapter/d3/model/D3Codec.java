package com.anz.axle.lg.adapter.d3.model;

import java.time.LocalDate;
import java.util.Optional;
import java.util.function.Function;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.pricing.codec.api.Flag;

public final class D3Codec {
    private static final Logger LOGGER = LoggerFactory.getLogger(D3Codec.class);

    public static final String TRADING_DATE = "DATE";
    public static final String NEAR_TENOR = "FTENOR";
    public static final String NEAR_DATE = "FVDATE";
    public static final String PIP = "PIP";
    public static final String HOLIDAY_WARNING = "HOLWARN";
    public static final String STATUS = "STATUS";
    public static final String CLASSIFICATION = "CLS";
    public static final String CURVE_NAME = "CURVE";
    public static final String UPDATE_TIME = "TIMEACT";
    public static final String CURRENCY1 = "CCY1";
    public static final String CURRENCY2 = "CCY2";
    public static final String SPOT_BID = "SBID";
    public static final String SPOT_ASK = "SASK";
    public static final String SPOT_DATE = "SPOT_DATE";
    public static final String NEAR_FORWARD_POINT_BID = "FBID";
    public static final String NEAR_FORWARD_POINT_ASK = "FASK";
    public static final String NEAR_ALL_IN_BID = "FOBID";
    public static final String NEAR_ALL_IN_ASK = "FOASK";

    private static final Optional<Flag> FLAG_INDICATIVE = Optional.of(Flag.INDICATIVE);
    private static final Optional<Flag> FLAG_LATENT = Optional.of(Flag.LATENT);
    private static final Optional<Flag> FLAG_SOURCE_ERROR = Optional.of(Flag.SOURCE_ERROR);


    private static final LocalDateDecoder localDateDecoder = LocalDateFormat.YYYYMMDD.getDefaultDecoder();
    private static final LocalDateEncoder localDateEncoder = LocalDateFormat.YYYYMMDD.getDefaultEncoder();

    private static final ThreadLocal<StringBuilder> stringBuilder = ThreadLocal.withInitial(StringBuilder::new);

    private D3Codec() {
    }

    public static String formatDate(final @NotNull LocalDate localDate) {
        final StringBuilder stringBuilder = D3Codec.stringBuilder.get();
        localDateEncoder.encodeNullable(stringBuilder, ByteWriter.STRING_BUILDER, localDate);
        return stringBuilder.toString();
    }

    public static Optional<LocalDate> asLocalDate(final String fieldName,
                                                  final Function<String, String> stringValueSupplier) {
        final String stringValue = stringValueSupplier.apply(fieldName);
        if (isEmpty(stringValue)) {
            return Optional.empty();
        } else {
            return Optional.of(localDateDecoder.decodeLocalDateOrNull(stringValue, ByteReader.CHAR_SEQUENCE));
        }
    }

    public static double asDouble(final String fieldName,
                                  final Function<String, String> stringValueSupplier) {
        final String stringValue = stringValueSupplier.apply(fieldName);
        if (isEmpty(stringValue)) {
            return Double.NaN;
        } else {
            try {
                return Double.parseDouble(stringValue);
            } catch (final NumberFormatException exception) {
                final String message = String.format("Field [%s] does not contain valid double [%s].", fieldName, stringValue);
                LOGGER.error(message, exception);
                throw new IllegalArgumentException(message, exception);
            }
        }
    }

    public static boolean asBoolean(final String fieldName,
                                    final Function<String, String> stringValueSupplier) {
        return Boolean.parseBoolean(stringValueSupplier.apply(fieldName));
    }

    public static Optional<Flag> asMarketDataFlag(final String fieldName,
                                                  final Function<String, String> stringValueSupplier) {
        final String stringValue = stringValueSupplier.apply(fieldName);
        if (stringValue == null) {
            throw new IllegalArgumentException("Unknown state [null]");
        }
        switch (stringValue) {
            case "FIRM":
                return Optional.empty();
            case "INDICATIVE":
                return FLAG_INDICATIVE;
            case "STALE":
                return FLAG_LATENT;
            case "ERROR":
                return FLAG_SOURCE_ERROR;
            default:
                throw new IllegalArgumentException("Unknown state [" + stringValue + "]");
        }
    }

    private static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
}
