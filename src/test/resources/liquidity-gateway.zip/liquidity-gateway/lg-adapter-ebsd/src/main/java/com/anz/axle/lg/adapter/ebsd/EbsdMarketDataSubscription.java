package com.anz.axle.lg.adapter.ebsd;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class EbsdMarketDataSubscription implements MarketDataSubscription {

    private static final int DEFAULT_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK = false;
    private static final boolean DEFAULT_FULL_REFRESH = false;

    private final String symbol;
    private final int marketDepth;
    private final boolean aggregateBook;
    private final boolean fullRefresh;
    private final InstrumentKey instrumentKey;
    private final StringToIntCache stringToIntCache;

    public EbsdMarketDataSubscription(final String symbol, final int marketDepth, final boolean aggregateBook, final boolean fullRefresh, final StringToIntCache stringToIntCache) {
        this.symbol = Objects.requireNonNull(symbol);
        this.marketDepth = marketDepth;
        this.aggregateBook = aggregateBook;
        this.fullRefresh = fullRefresh;
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), SecurityType.FXSPOT, Tenor.SP);
        this.stringToIntCache = Objects.requireNonNull(stringToIntCache);
    }

    public static EbsdMarketDataSubscription forIdAndymbol(final String symbol, final StringToIntCache stringToIntCache) {
        return new EbsdMarketDataSubscription(symbol, DEFAULT_MARKET_DEPTH, DEFAULT_AGGREGATE_BOOK, DEFAULT_FULL_REFRESH, stringToIntCache);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return Venue.EBSD;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public boolean fullRefresh() {
        return fullRefresh;
    }

    @Override
    public boolean aggregateBook() {
        return aggregateBook;
    }

    @Override
    public int marketDepth() {
        return marketDepth;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return stringToIntCache;
    }

    @Override
    public String toString() {
        return "EbsdMarketDataSubscription{" +
                "id=" + instrumentKey.instrumentId() +
                ", symbol='" + symbol + '\'' +
                ", instrumentKey=" + instrumentKey +
                '}';
    }
}
