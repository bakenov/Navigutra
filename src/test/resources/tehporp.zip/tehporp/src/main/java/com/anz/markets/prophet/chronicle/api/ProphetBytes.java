package com.anz.markets.prophet.chronicle.api;

import com.anz.markets.prophet.annotation.NotGcFriendly;
import org.jetbrains.annotations.TestOnly;

public interface ProphetBytes {
    void skipBytesRead(final int bytesToSkip);
    default void skipBytesWrite(final int bytesToSkip) {
        skipBytesRead(bytesToSkip);
    }
    boolean readBoolean();
    byte readByte();
    long readLong();
    int readInt();
    double readDouble();
    float readFloat();
    String readUTF8();
    void readUTF8(StringBuilder sb);
    short readShort();
    <E> E readEnum(Class<E> clazz);
    int read(final byte[] bytes, final int offset, final int length);
    int read(final byte[] bytes);

    @NotGcFriendly("Garbagy")
    <E> E readObject(Class<E> clazz);

    void writeBoolean(final boolean value);
    void writeByte(final byte value);
    void writeInt(final int value);
    void writeLong(final long value);
    void writeFloat(final float value);
    void writeDouble(final double value);
    void writeUTF8(final String value);
    void writeUTF8(final CharSequence value);
    void writeShort(final short value);
    <E extends Enum<E>> void writeEnum(final Enum<E> value);
    void write(final byte[] bytes, final int offset, final int length);
    /**
     * Write passed bytes to this, starting from bytes.readPosition() and ending when all of bytes written
     * @param from bytes
     */
    default void write(final ProphetBytes from) {
        // TODO: optimise this once we are rid of CQ3
        long remaining = from.length() - from.readPosition();
        for (long i = 0; i<remaining; i++) {
            writeByte(from.readByte());
        }
    }

    @NotGcFriendly("Garbagy")
    <E> void writeObject(E object);

    // Note: Some sort of quick hack so the ToolsCommon components work without much changes
    ToolsCommonTailer getTailer();

    @TestOnly
    void position(long position);

    @TestOnly
    long position();

    default long readPosition() {
        return position();
    }

    default void readPosition(long position) {
        position(position);
    }

    default long writePosition() {
        return position();
    }

    default void writePosition(long position) {
        position(position);
    }

    default int length() {
        return (int) writePosition();
    }
}
