package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.sbe.OrderCancelRequestSbeDecoder;

public class ParentOrderCancelRequestCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParentOrderCancelRequestCommand.class);

    private final ParentOrderRepository.WithInit parentOrderRepository;
    private final CommandContext commandContext;

    private final OrderCancelRequestSbeDecoder orderCancelRequestDecoder = new OrderCancelRequestSbeDecoder();

    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> senderCompIdCache = new ByteValueCache<>(AsciiString::toString);

    private final StringBuilder stringBuilder = new StringBuilder();

    public ParentOrderCancelRequestCommand(final ParentOrderRepository.WithInit parentOrderRepository,
                                           final CommandContext commandContext) {
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if(!orderCancelRequestDecoder.wrap(message)) return false;

        final String marketId = orderCancelRequestDecoder.body().marketId().decodeAndCache(marketIdCache);

        if (Venue.FOX.name().equals(marketId)) {
            logMessage();

            final long orderId = orderCancelRequestDecoder.body().orderId().decodeLongOrZero();
            final ParentOrder parentOrder;
            if (orderId > 0) {
                parentOrder = parentOrderRepository.lookupByOrderId(orderId);
            } else {
                final long origClOrdId = orderCancelRequestDecoder.body().origClOrdId().decodeLongOrZero();
                final String senderCompId = orderCancelRequestDecoder.body().senderCompId().decodeAndCache(senderCompIdCache);
                parentOrder = parentOrderRepository.lookupByClOrderId(senderCompId, origClOrdId);
            }
            if (parentOrder != null) {
                parentOrder.onParentOrderCancelRequest(commandContext, orderCancelRequestDecoder);
            } else {
                sendOrderCancelReject();
            }
            return true;
        }
        return false;
    }

    private void sendOrderCancelReject() {
        final int source = commandContext.source();
        final long sourceSeq = commandContext.idGenerator().getAsLong();
        commandContext.tradingEncoderSupplier().orderCancelReject().messageStart(source, sourceSeq)
                .senderCompId().encode("GB:fox")
                .messageId(sourceSeq)
                .marketId().encode(Venue.FOX.name())
                .clOrdId().encodeFrom(orderCancelRequestDecoder.body().clOrdId())
                .origClOrdId().encodeFrom(orderCancelRequestDecoder.body().origClOrdId())
                .clOrdLinkId().encodeFrom(orderCancelRequestDecoder.body().clOrdLinkId())
                .orderId().encodeFrom(orderCancelRequestDecoder.body().orderId())
                .transactTime(commandContext.precisionClock().nanos())
                .ordStatus(OrderStatus.REJECTED)
                .cxlRejResponseTo(OrderCancelRequestType.ORDER_CANCEL_REQUEST)
                .cxlRejReason(OrderCancelRejectReason.UNKNOWN_ORDER)
                .partiesEmpty()
                .hopsEmpty()
                .text().encodeEmpty()
                .messageComplete();
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        this.orderCancelRequestDecoder.appendTo(stringBuilder);
        LOGGER.info("Action parent OCRQ: {}", stringBuilder);
    }
}
