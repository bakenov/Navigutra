package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWideningConfig;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;

public class EconNewsWideningConfigImpl implements EconNewsWideningConfig, ProphetMarshallable {
    private EconNewsWeight weight;
    private double wideningFactor;
    private long widenBeforeMs;
    private long tightenAfterMs;
    private boolean priceIndicative = false;
    private Market market = Market.ANY;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public EconNewsWideningConfigImpl() {
    }

    public EconNewsWideningConfigImpl(final EconNewsWeight weight,
                                      final double wideningFactor,
                                      final long widenBeforeMs,
                                      final long tightenAfterMs,
                                      final boolean priceIndicative,
                                      final Market market) {
        this.weight = weight;
        this.wideningFactor = wideningFactor;
        this.widenBeforeMs = widenBeforeMs;
        this.tightenAfterMs = tightenAfterMs;
        this.priceIndicative = priceIndicative;
        this.market = market;
    }

    @Override
    public EconNewsWeight getWeight() {
        return weight;
    }

    @Override
    public double getWideningFactor() {
        return wideningFactor;
    }

    public long getWidenBeforeMs() {
        return widenBeforeMs;
    }

    public long getTightenAfterMs() {
        return tightenAfterMs;
    }

    @Override
    public boolean isPriceIndicative() {
        return priceIndicative;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        Context.context().header().before(MessageVersion.VERSION_0_82, () -> {
            weight = in.readEnum(EconNewsWeight.class);
            wideningFactor = in.readDouble();
            widenBeforeMs = in.readLong();
            tightenAfterMs = in.readLong();
        });
        Context.context().header().since(MessageVersion.VERSION_0_82, () -> {
            weight = EconNewsWeight.valueOf(in.readByte());
            wideningFactor = in.readDouble();
            widenBeforeMs = in.readLong();
            tightenAfterMs = in.readLong();
            priceIndicative = in.readBoolean();
            market = Market.valueOf(in.readByte());
        });
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(weight.getValue());
        out.writeDouble(wideningFactor);
        out.writeLong(widenBeforeMs);
        out.writeLong(tightenAfterMs);
        out.writeBoolean(priceIndicative);
        out.writeByte(market.getValue());
    }

    @Override
    public String toString() {
        return "EconNewsWideningConfigImpl{" +
                "weight=" + weight +
                ", wideningFactor=" + wideningFactor +
                ", widenBeforeMs=" + widenBeforeMs +
                ", tightenAfterMs=" + tightenAfterMs +
                ", priceIndicative=" + priceIndicative +
                ", market=" + market +
                '}';
    }
}
