package com.anz.axle.adapters.ndf2trep.publisher;

import org.junit.Before;
import org.junit.Test;

import static com.anz.axle.adapters.ndf2trep.publisher.TrepAsserter.assertEqualTrepQuote;

public class TrepQuoteTest {

    private static final String SERVICE_NAME = "TEST";
    private static final String RIC_NAME = "AUSUSD";
    private TrepQuote.Builder trepQuoteBuilder;

    @Before
    public void beforeEach() {
        trepQuoteBuilder = new TrepQuote.Builder().serviceName(SERVICE_NAME).ricName(RIC_NAME);
    }

    @Test
    public void builderBidAndOffer() {
        final TrepQuote trepQuote = trepQuoteBuilder
                .updateBid(0.79, 1L)
                .updateOffer(0.78, 1L)
                .build();

        assertEqualTrepQuote(trepQuote, expectedTrepQuote(TrepQuote.QuoteType.EXECUTABLE, 0.79, 0.78));
    }

    @Test
    public void isEmptyBook() {
        final TrepQuote trepQuote = trepQuoteBuilder.isIndicative(true).build();
        assertEqualTrepQuote(trepQuote, expectedTrepQuote(TrepQuote.QuoteType.INDICATIVE, Double.NaN, Double.NaN));
    }

    @Test
    public void builderReset() {
        final TrepQuote.Builder builder = trepQuoteBuilder
                .updateBid(0.79, 1L)
                .updateOffer(0.77, 1L);

        assertEqualTrepQuote(builder.build(), expectedTrepQuote(TrepQuote.QuoteType.EXECUTABLE, 0.79, 0.77));

        final TrepQuote resetQuote = builder.reset().serviceName(SERVICE_NAME).ricName(RIC_NAME).build();
        assertEqualTrepQuote(resetQuote, expectedTrepQuote(TrepQuote.QuoteType.INDICATIVE, Double.NaN, Double.NaN));
    }

    private TrepQuote expectedTrepQuote(final TrepQuote.QuoteType quoteType, final double bid, final double ask) {
        return TrepQuote.createUpdateQuote(quoteType, SERVICE_NAME, RIC_NAME, bid, ask, 1L);
    }
}
