package com.anz.markets.efx.fox.firewalls.rules.config;

import org.yaml.snakeyaml.TypeDescription;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FirewallsConfig {
    private Map<String, FirewallRuleCategoryConfig> firewalls = new HashMap<>();

    public void setFirewalls(final Map<String, FirewallRuleCategoryConfig> firewallTypes){
        firewalls = firewallTypes;
    }

    public Map<String, FirewallRuleCategoryConfig> getFirewalls() {
        return firewalls;
    }

    public static Yaml yaml() {
        final Constructor constructor = new Constructor(FirewallsConfig.class);

        final TypeDescription firewallsPropertyDescription = new TypeDescription(FirewallsConfig.class);
        firewallsPropertyDescription.addPropertyParameters("firewalls", String.class, FirewallRuleCategoryConfig.class);

        final TypeDescription firewallCategoriesPropertyDescription = new TypeDescription(FirewallRuleCategoryConfig.class);
        firewallsPropertyDescription.addPropertyParameters("firewallTypeConfigs", FirewallTypeConfig.class);

        final TypeDescription firewallTypeConfigPropertyDescription = new TypeDescription(FirewallTypeConfig.class);
        firewallTypeConfigPropertyDescription.addPropertyParameters("firewallName", String.class);
        firewallTypeConfigPropertyDescription.addPropertyParameters("columns", String.class);
        firewallTypeConfigPropertyDescription.addPropertyParameters("rules", List.class);

        constructor.addTypeDescription(firewallsPropertyDescription);
        constructor.addTypeDescription(firewallCategoriesPropertyDescription);
        constructor.addTypeDescription(firewallTypeConfigPropertyDescription);
        return new Yaml(constructor);
    }
}
