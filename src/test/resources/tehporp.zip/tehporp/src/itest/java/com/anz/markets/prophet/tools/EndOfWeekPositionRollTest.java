package com.anz.markets.prophet.tools;

import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.efx.ngaro.math.Epsilon;
import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.HeaderPredicates;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.control.BiasPositionControlImpl;
import com.anz.markets.prophet.domain.pnl.ProfitAndLossImpl;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.positionrisk.AdjustmentImpl;
import com.anz.markets.prophet.positionrisk.FileUtil;
import com.anz.markets.prophet.positionrisk.Position;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class EndOfWeekPositionRollTest {
    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    @Before
    public void setup() {
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    private void setup(final boolean providePnl, final String chronicleOut) throws IOException {
        Context.set(new Context(new TimeSourceChronicle()));
        final Header header = Context.context().header();
        long eventId = 0;
        long timeStampNS = TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis());

        Positions publishPositions = new Positions();
        ProfitAndLossImpl publishProfitAndLoss = new ProfitAndLossImpl();
        publishProfitAndLoss.setPortfolio(Portfolio.CLIENTS_NET);

        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(chronicleOut)) {
            for (int i = 0; i < 10000; i++) {
                header.setEventId(eventId);
                header.setStartTimeStampNS(timeStampNS);
                persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
                eventId += 1;
                timeStampNS += TimeUnit.SECONDS.toNanos(1);
            }

            if (providePnl) {
                publishProfitAndLoss.incrementBy(10);
                persister.sink(MessageType.PROFIT_AND_LOSS).accept(publishProfitAndLoss);
            }
            eventId += 1;
            timeStampNS += TimeUnit.SECONDS.toNanos(1);
            header.setEventId(eventId);
            header.setStartTimeStampNS(timeStampNS);

            publishPositions.setFromAdjustmentOrMidRate(new Position(Currency.USD, Portfolio.CLIENTS_NET).setPositionInNotional(100), Positions.LAST_ADJUSTMENT_IDENTIFIER);
            persister.sink(MessageType.POSITIONS).accept(publishPositions);
            publishPositions.setFromAdjustmentOrMidRate(new Position(Currency.AUD, Portfolio.CLIENTS_NET).setPositionInNotional(10), Positions.LAST_ADJUSTMENT_IDENTIFIER);
            persister.sink(MessageType.POSITIONS).accept(publishPositions);
            if (providePnl) {
                publishProfitAndLoss.incrementBy(20);
                persister.sink(MessageType.PROFIT_AND_LOSS).accept(publishProfitAndLoss);
            }
        }
    }

    @Test
    public void testRollWithPnl() throws IOException {
        final String chronicleIn = FileUtil.tmpFile(this.getClass().getSimpleName(), "in");
        final String chronicleOut = FileUtil.tmpFile(this.getClass().getSimpleName(), "out");

        setup(true, chronicleOut);
        EndOfWeekPositionRoll.rollPositions(chronicleIn, chronicleOut, 10, true);
        check(70, 10, chronicleIn);
    }

    @Test
    public void testRollWithoutPnl() throws IOException {
        final String chronicleIn = FileUtil.tmpFile(this.getClass().getSimpleName(), "in");
        final String chronicleOut = FileUtil.tmpFile(this.getClass().getSimpleName(), "out");

        setup(false, chronicleOut);
        EndOfWeekPositionRoll.rollPositions(chronicleIn, chronicleOut, 10, true);
        check(100, 10, chronicleIn);
    }

    private void check(final double expectedUSD,
                       final double expectedAUD,
                       final String chronicleIn) throws IOException {
        final TrackPositions trackPositionsReader = new TrackPositions();
        try (final ProphetReader reader = ChronicleReaderFactory.createToolsCommonReader(
                ThreadUtils.SameThreadExecutor.INSTANCE, chronicleIn, trackPositionsReader, HeaderPredicates.FILTER_ALLOW_ALL,
                StartAt.START, -1L, ChronicleHook.unknownMessageCounter(), WaitStrategy.STOP_ON_STALL)) {
            assertEquals(expectedUSD, trackPositionsReader.getPosition(Currency.USD), Epsilon.EPS_0_1.getValue());
            assertEquals(expectedAUD, trackPositionsReader.getPosition(Currency.AUD), Epsilon.EPS_0_1.getValue());
        }

        for (Currency ccy : Currency.VALUES) {
            if (!ccy.isHypotheticalCurrency()) {
                assertEquals(0, trackPositionsReader.getBiasControl(ccy), 0);
            }
        }
    }

    private class TrackPositions implements ChronicleObjectReader {
        private final EnumDoubleMap<Currency> latestPositions = new EnumDoubleMap(Currency.class);
        private final EnumDoubleMap<Currency> latestBiasControl = new EnumDoubleMap(Currency.class);
        private final AdjustmentImpl readAdjustment = new AdjustmentImpl();
        private final BiasPositionControlImpl biasControl = new BiasPositionControlImpl();

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            if (messageType == MessageType.ADJUSTMENT) {
                readAdjustment.readMarshallable(bytes);
                if (readAdjustment.getPortfolio() == Portfolio.CLIENTS_NET) {
                    latestPositions.put(readAdjustment.getCcy(), readAdjustment.getAmount());
                }
            }

            if (messageType == MessageType.BIAS_OFFSET_CONTROL) {
                biasControl.readMarshallable(bytes);
                latestBiasControl.put(biasControl.getCurrency(), biasControl.getBiasPosition());
            }
        }

        public double getPosition(final Currency ccy) {
            return latestPositions.get(ccy);
        }

        public double getBiasControl(final Currency ccy) {
            return latestBiasControl.get(ccy);
        }
    }
}
