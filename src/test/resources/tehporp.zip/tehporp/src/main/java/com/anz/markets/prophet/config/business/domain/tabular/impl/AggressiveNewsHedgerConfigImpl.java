package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveNewsHedgerConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AggressiveNewsHedgerConfigImpl implements AggressiveNewsHedgerConfig, ProphetMarshallable {
    private Market market;
    private Instrument instrument;
    private long triggerBeforeNewsMS = 0;
    private double minimumNewsWeight = Double.NaN;
    private double minimumRisk = Double.NaN;
    private double minimumOrderQuantity = Double.NaN;
    private double maximumSpread = Double.NaN;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public AggressiveNewsHedgerConfigImpl() {
    }

    public AggressiveNewsHedgerConfigImpl(final Instrument instrument,
                                          final Market market) {
        this.instrument = instrument;
        this.market = market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    public long getTriggerBeforeNewsMS() {
        return triggerBeforeNewsMS;
    }

    public double getMinimumNewsWeight() {
        return minimumNewsWeight;
    }

    public double getMinimumRisk() {
        return minimumRisk;
    }

    public double getMinimumOrderQuantity() {
        return minimumOrderQuantity;
    }

    public double getMaximumSpread() {
        return maximumSpread;
    }


    public AggressiveNewsHedgerConfigImpl setTriggerBeforeNewsMS(final long triggerBeforeNewsMS) {
        this.triggerBeforeNewsMS = triggerBeforeNewsMS;
        return this;
    }

    public AggressiveNewsHedgerConfigImpl setMinimumNewsWeight(final double minimumNewsWeight) {
        this.minimumNewsWeight = minimumNewsWeight;
        return this;
    }

    public AggressiveNewsHedgerConfigImpl setMinimumRisk(final double minimumRisk) {
        this.minimumRisk = minimumRisk;
        return this;
    }

    public AggressiveNewsHedgerConfigImpl setMinimumOrderQuantity(final double minimumOrderQuantity) {
        this.minimumOrderQuantity = minimumOrderQuantity;
        return this;
    }

    public AggressiveNewsHedgerConfigImpl setMaximumSpread(final double maximumSpread) {
        this.maximumSpread = maximumSpread;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        Context.context().header().before(MessageVersion.VERSION_0_26, () -> {
            this.market = in.readEnum(Market.class);
            this.instrument = in.readEnum(Instrument.class);
            in.readDouble();
            in.readDouble();
            in.readDouble();
            in.readDouble();
            in.readDouble();
            in.readDouble();
            in.readDouble();
            in.readDouble();
        });
        // Only valid from message version 25 onwards
        Context.context().header().since(MessageVersion.VERSION_0_26, () -> {
            this.market = Market.valueOf(in.readByte());
            this.instrument = Instrument.readMarshallableValueOf(in);
            this.triggerBeforeNewsMS = in.readLong();
            this.minimumNewsWeight = in.readDouble();
            this.minimumRisk = in.readDouble();
            this.minimumOrderQuantity = in.readDouble();
            this.maximumSpread = in.readDouble();
        });
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(this.market.getValue());
        out.writeShort(this.instrument.getValue());
        out.writeLong(this.triggerBeforeNewsMS);
        out.writeDouble(this.minimumNewsWeight);
        out.writeDouble(this.minimumRisk);
        out.writeDouble(this.minimumOrderQuantity);
        out.writeDouble(this.maximumSpread);
    }

    @Override
    public String toString() {
        return "AggressiveHedgerConfigImpl{" +
                "market=" + market +
                ", instrument=" + instrument +
                ", triggerBeforeNewsMS=" + triggerBeforeNewsMS +
                ", newsMinimumNewsWeight=" + minimumNewsWeight +
                ", minimumRisk=" + minimumRisk +
                ", minimumOrderQuantity=" + minimumOrderQuantity +
                ", maximumSpread=" + maximumSpread +
                '}';
    }

}
