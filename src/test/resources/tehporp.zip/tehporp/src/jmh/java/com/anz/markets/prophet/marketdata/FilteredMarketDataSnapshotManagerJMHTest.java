package com.anz.markets.prophet.marketdata;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.util.ProphetMarshallableCopierTest;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

public class FilteredMarketDataSnapshotManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private TestStubConsumer<FilteredMarketDataSnapshot> filteredMarketDataSnapshotConsumer = new TestStubConsumer<>();
        private Consumer<MarketData> consumerOfMarketData;
        private MarketDataSnapshot marketsSnapshot;
        private MarketDataIncrement marketsIncrement;

        @Setup
        public void setup() throws IOException {
            IndexedConfigurationData indexedConfigurationData = createMarketsConfiguration();
            FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager = new FilteredMarketDataSnapshotManager(filteredMarketDataSnapshotConsumer,signals -> {});
            filteredMarketDataSnapshotManager.consumerIndexedConfigurationData().accept(indexedConfigurationData);
            consumerOfMarketData = filteredMarketDataSnapshotManager.consumerOfMarketData();
            marketsSnapshot = ProphetMarshallableCopierTest.createMarketDataSnapshot();
            marketsIncrement = MidRateTestHelper.createMarketDataIncrement();
        }

        @NotNull
        public IndexedConfigurationData createMarketsConfiguration() {
            return TestConfigurationDataFactory.configurationDataForAggBookFiltering();
        }
    }

    @Benchmark
    public long acceptMarketDataSnapshot(@NotNull final Data data) throws Exception {
        data.consumerOfMarketData.accept(data.marketsSnapshot);
        return data.filteredMarketDataSnapshotConsumer.getEvents().size();
    }

    @Benchmark
    public long acceptMarketDataIncrement(@NotNull final Data data) throws Exception {
        data.consumerOfMarketData.accept(data.marketsIncrement);
        return data.filteredMarketDataSnapshotConsumer.getEvents().size();
    }
}
