package com.anz.axle.environment;

import com.anz.axle.ant.*;
import com.anz.axle.util.ThreadUtils;
import net.sf.antcontrib.property.Variable;
import org.apache.tools.ant.*;
import org.apache.tools.ant.property.LocalProperties;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.taskdefs.condition.ResourceContains;
import org.apache.tools.ant.taskdefs.optional.ssh.Scp;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.types.Reference;
import org.springframework.util.PropertyPlaceholderHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static java.lang.String.format;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.springframework.util.ObjectUtils.nullSafeEquals;


public class AdministrationTask extends Task implements TaskContainer {
    private static final String DATAFABRIC_NODE_PROPERTY = "datafabric.node";
    private static final String DATAFABRIC_COMPONENT_PROPERTY = "datafabric.component";
    private static final String DATAFABRIC_NODE_COMPONENT_PROPERTY = "datafabric.node-component";
    private static final String DATAFABRIC_ACTION_PROPERTY = "datafabric.action";
    public static final String STOP_ACTION = "stop";
    public static final String START_ACTION = "start";
    public static final boolean FORCE = true;
    public static final String CACHE_SERVER_COMPONENT = "CacheServer";

    private String action;
    private String component;
    private String environment;
    private String region;
    private String version;

    private List<Task> nestedDatafabricTasks = new ArrayList<Task>();

    @Override
    public void execute() throws BuildException {
        log("...........................................................");
        log(format("... Running %s %s %s %s %s ", action, component, version, environment, region));
        log("...........................................................");

        // Resolve build number
        BuildNumberResolverTask buildNumberResolverTask = new BuildNumberResolverTask();
        buildNumberResolverTask.setProject(getProject());
        buildNumberResolverTask.setVersion(replace("${version}"));
        buildNumberResolverTask.execute();

        // Action every component

        Component actionComponent = parseComponent(region);
        actionComponent.action(action);

        log("...........................................................");
    }

    private void upload(String host, String fromFile, String toDir) {
        unsetProperty("ssh.output");
        echo("Scp " + fromFile + " axle@" + host + ":" + toDir);

        Scp execTask = new Scp();
        execTask.setProject(getProject());
        execTask.setTrust(true);
        execTask.setHost(host);
        execTask.setFailonerror(true);
        execTask.setKeyfile("/app/fxdev/.ssh/id_dsa");
        execTask.setUsername("axle");
        execTask.setFile(fromFile);
        execTask.setRemoteTodir("axle@" + host + ":" + toDir);
        execTask.setPort(7222);
        execTask.execute();
    }

    private void ssh(String host, String command) {
        ssh(host, command, true);
    }

    private void ssh(String host, String command, boolean failOnError) {
        unsetProperty("ssh.output");

        QuietSSHExec execTask = new QuietSSHExec();
        execTask.setProject(getProject());
        execTask.setTrust(true);
        execTask.setFailonerror(failOnError);
        execTask.setKeyfile("/app/fxdev/.ssh/id_dsa");
        execTask.setUsername("axle");
        execTask.setOutputproperty("ssh.output");
        execTask.setPort(7222);
        execTask.execute();
    }

    private void unix(String command, String outputProperty) {
        unsetProperty(outputProperty);

        ExecTask execTask = new ExecTask();
        execTask.setProject(getProject());
        execTask.setExecutable("bash");
        execTask.setOutputproperty(outputProperty);
        execTask.createArg().setValue("-c");
        execTask.createArg().setValue(command);
        execTask.execute();
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public interface Component {
        void action(String action);

        boolean isActioned();
    }

    public interface Components {
        List<Component> getComponents();
    }

    public Component parseComponent(String rawString) {
        List<Component> components = new ArrayList<Component>();
        if (rawString.contains(",")) {
            String[] rawComponents = rawString.split(",");
            for (String rawComponent : rawComponents) {
                Component parsedComponent = parseComponent(rawComponent);
                if (parsedComponent != null) {
                    components.add(parsedComponent);
                }
            }
            return new SequentialComponent(components);
        } else {
            if (rawString.contains("|")) {
                String[] rawComponents = rawString.split("\\|");
                for (String rawComponent : rawComponents) {
                    Component parsedComponent = parseComponent(rawComponent);
                    if (parsedComponent != null) {
                        components.add(parsedComponent);
                    }
                }
                return new ParallelComponent(components);
            } else {
                String[] rawComponents = rawString.split(":");
                String componentName = rawComponents[0];
                if (rawComponents.length > 1) {
                    String componentHost = rawComponents[1];
                    String componentActionOverride = null;
                    if (rawComponents.length > 2) {
                        // TODO do some nice safety checking here
                        componentActionOverride = getProject().getProperty("admin.phase.alias." + rawComponents[2]);
                    }
                    if (component.equals("all") || component.equals(componentName)) {
                        return new SingleComponentOrder(componentName, componentHost, componentActionOverride);
                    } else {
                        return null;
                    }
                } else {
                    String actionOrderProperty = format("admin.action.order.%s.%s.%s", environment, rawString, action);
                    String actionOrder = getProject().getProperty(actionOrderProperty);
                    if (isNotBlank(actionOrder)) {
                        return parseComponent(actionOrder);
                    } else {
                        throw new BuildException("No action order definition for " + actionOrderProperty);
                    }
                }
            }
        }
    }

    public abstract class AbstractComponent implements Component {
        private List<Component> components = new ArrayList<Component>();
        private boolean actioned = false;

        public AbstractComponent(List<Component> components) {
            this.components = components;
        }

        public void actioned() {
            this.actioned = true;
        }

        public boolean isActioned() {
            return actioned;
        }

        public List<Component> getComponents() {
            return components;
        }
    }

    public class SequentialComponent extends AbstractComponent {

        public SequentialComponent(List<Component> components) {
            super(components);
        }

        @Override
        public void action(String action) {
        	try {
        	    final AtomicReference<BuildException> exception = new AtomicReference<BuildException>();
	            for (Component component : getComponents()) {
	                try {
	                    component.action(action);
	                } catch (RuntimeException e) {
	                    log("Failed to run " + action + "-component, e=" + e, e, Project.MSG_ERR);
	                    exception.compareAndSet(null, new BuildException("Failed to run " + action + "-component, e=" + e, e));
	                } catch (Error e) {
                        log("Failed to run " + action + "-component, e=" + e, e, Project.MSG_ERR);
                        exception.compareAndSet(null, new BuildException("Failed to run " + action + "-component, e=" + e, e));
	                }
	            }
	            final BuildException e = exception.get();
	            if (e != null) {
	                throw e;
	            }
        	} finally {
        		actioned();
        	}
        }
    }

    public class ParallelComponent extends AbstractComponent {
        public ParallelComponent(List<Component> components) {
            super(components);
        }

        @Override
        public void action(final String action) {
            for (final Component component : getComponents()) {
                new Thread(action + "-" + component + "-thread") {
                    @Override
                    public void run() {
                        try {
                            if (component instanceof SingleComponentOrder) {
                                setName(action + "-" + ((SingleComponentOrder) component).component + "-" + ((SingleComponentOrder) component).host + "-thread");
                            }
                            component.action(action);
                        } catch (RuntimeException e) {
                            log("Failed to run " + action + "-component, e=" + e, e, Project.MSG_ERR);
                            throw e;
                        } catch (Error e) {
                            log("Failed to run " + action + "-component, e=" + e, e, Project.MSG_ERR);
                            throw e;
                        }
                    }
                }.start();
            }

            // Wait for all parallel tasks to finish
            while (!isActioned()) {
                ThreadUtils.sleep(300);
            }
            actioned();
        }

        @Override
        public boolean isActioned() {
            boolean actioned = true;
            for (final Component component : getComponents()) {
                actioned &= component.isActioned();
            }
            return actioned;
        }
    }

    public class SingleComponentOrder extends AbstractComponent {
        private String component;
        private String host;
        private String actionOverride;

        public SingleComponentOrder(String component, String host, String actionOverride) {
            super(null);
            this.component = component;
            this.host = host;
            this.actionOverride = actionOverride;
        }

        public String getAction() {
            if (isNotBlank(actionOverride)) {
                return actionOverride;
            } else {
                return action;
            }
        }

        @Override
        public void action(String action) {
            try {
                LocalProperties.get(getProject()).copy();

                // Resolve component path
                String componentPath = replace(format("${admin.%s.artifact.path}/${admin.build.id}/${admin.%s.artifact.path}", version, this.component));
                resetProperty("componentPath", replace(format("${admin.%s.artifact.path}/${admin.build.id}/${admin.%s.artifact.path}", version, this.component)));
                log(replace("Resolved component path " + componentPath), Project.MSG_DEBUG);

                // Resolve hostname
                String hostname = getProject().getProperty("admin.host.alias." + this.host);
                if (isBlank(hostname)) {
                    throw new BuildException("Failed to find hostname for alias " + this.host);
                }
                log("Resolved hostname " + hostname, Project.MSG_DEBUG);

                // Resolve host path
                String hostnamePath = getProject().getProperty(replace("admin." + hostname + ".axle.path"));
                if (isBlank(hostnamePath)) {
                    hostnamePath = getProject().getProperty("admin.default.axle.path");
                }

                // Resolve log file
                String logFile = replace("${logs.dir}/" + action + "-" + this.component + "-" + host + ".log");
                create("action", logFile);

                log(action + "ing component " + this.component + " on host " + hostname, Project.MSG_DEBUG);
                MacroInstance macroInstance = (MacroInstance) getProject().createTask(action + "-component");
                macroInstance.setDynamicAttribute("action", getAction());
                macroInstance.setDynamicAttribute("hostname", hostname);
                macroInstance.setDynamicAttribute("component", this.component);
                macroInstance.setDynamicAttribute("componentpath", componentPath);
                macroInstance.setDynamicAttribute("hosthomepath", hostnamePath);
                macroInstance.setDynamicAttribute("version", version);
                macroInstance.setDynamicAttribute("environment", environment);
                macroInstance.setDynamicAttribute("region", region);
                macroInstance.setDynamicAttribute("logfile", logFile);
                macroInstance.execute();
            } catch (Throwable t) {
                log("Failed to run " + action + "-component, e=" + t, t, Project.MSG_ERR);
                throw new BuildException("Failed to run " + action + "-component, e=", t);
            } finally {
                actioned();
            }
        }
    }

    private void mkdir(String dir) {
        QuietMkdir mkdirTask = new QuietMkdir();
        mkdirTask.setProject(getProject());
        File dirFile = new File(replace(dir));
        mkdirTask.setDir(dirFile);
        mkdirTask.execute();
    }

    private void createPid() {
        jpsUntilLive("${datafabric.node-component}", "${datafabric.node-component}.pid");
        failUnless("Cannot create pid for ${datafabric.node-component} because it is not running", "${datafabric.node-component}.pid");
        create("${datafabric.node-component}.pid", "${logs.dir}/${datafabric.node-component}.pid");
    }

    private void create(String textProperty, String file) {
        CreateTask createTask = new CreateTask();
        createTask.setProject(getProject());
        createTask.setTextProperty(replace(textProperty));
        createTask.setFile(replace(file));
        createTask.execute();
    }

    private void failUnless(String message, String unless) {
        Exit fail = new Exit();
        fail.setProject(getProject());
        fail.setMessage(replace(message));
        if (isNotBlank(unless)) {
            fail.setUnless(replace(unless));
        }
        fail.execute();
    }

    private void fail(String message) {
        failUnless(message, null);
    }

    private void jpsUntilLive(String task, String pidProperty) {
        JpsUntilLiveTask jpsUntilLiveTask = new JpsUntilLiveTask();
        jpsUntilLiveTask.setProject(getProject());
        jpsUntilLiveTask.setTask(replace(task));
        jpsUntilLiveTask.setPidProperty(replace(pidProperty));
        jpsUntilLiveTask.execute();
    }

    private ResourceContains resourceContains(String resource, String substring, boolean caseSensitive) {
        ResourceContains resourceContainsTask = new ResourceContains();
        resourceContainsTask.setProject(getProject());
        resourceContainsTask.setResource(replace(resource));
        resourceContainsTask.setSubstring(replace(substring));
        resourceContainsTask.setCasesensitive(caseSensitive);
        return resourceContainsTask;
    }

    private WaitFor waitFor(String maxWait, String timeoutProperty) {
        WaitFor waitForTask = new WaitFor();
        waitForTask.setProject(getProject());
        waitForTask.setMaxWait(Long.parseLong(replace(maxWait)));
        waitForTask.setCheckEvery(100);
        waitForTask.setTimeoutProperty(replace(timeoutProperty));
        return waitForTask;
    }

    private boolean isTaskRunning(String task) {
        JpsTask jpsTask = new JpsTask();
        jpsTask.setProject(getProject());
//        jpsTask.setPidProperty(replace(pidProperty));
        jpsTask.setTask(replace(task));
        return jpsTask.executeIsTaskRunning();
    }

    private void readPid(String srcFile, String property) {
        LoadFile loadFileTask = new LoadFile();
        loadFileTask.setProject(getProject());
        loadFileTask.setSrcFile(new File(replace(srcFile)));
        loadFileTask.setProperty(replace(property));
        loadFileTask.setFailonerror(false);
        loadFileTask.setQuiet(true);
        loadFileTask.execute();
    }


    private void deleteFromDirIncludes(String dir, String includes) {
        Delete deleteTask = new Delete();
        deleteTask.setProject(getProject());
        deleteTask.setFailOnError(false);
        deleteTask.setQuiet(true);
        FileSet fileSet = new FileSet();
        fileSet.setProject(getProject());
        fileSet.setDir(new File(replace(dir)));
        fileSet.setIncludes(replace(includes));
        deleteTask.addFileset(fileSet);
        deleteTask.execute();
    }

    private void replaceAll(String file) {
        ReplaceAllTask replaceAllTask = new ReplaceAllTask();
        replaceAllTask.setProject(getProject());
        replaceAllTask.setNested(true);
        replaceAllTask.setFile(new File(replace(file)));
        replaceAllTask.execute();
    }

    private void copyToFile(String fromFile, String toFile) {
        QuietCopy copyTask = new QuietCopy();
        copyTask.setProject(getProject());
        copyTask.setFile(new File(replace(fromFile)));
        copyTask.setTofile(new File(replace(toFile)));
        copyTask.setOverwrite(true);
        copyTask.execute();
    }

    private void echo(String message) {
        Echo echoTask = new Echo();
        echoTask.setProject(getProject());
        echoTask.setMessage(message);
        echoTask.execute();
    }

    private void copyToDir(String fromFile, String toDir) {
        QuietCopy copyTask = new QuietCopy();
        copyTask.setProject(getProject());
        copyTask.setFile(new File(replace(fromFile)));
        copyTask.setTodir(new File(replace(toDir)));
        copyTask.setOverwrite(true);
        copyTask.setVerbose(false);
        copyTask.execute();
    }

    /**
     * We don't use the standard getProject().replaceProperties(value); because it doesn't handle nested properties.
     *
     * @param value the string to replace.
     * @return the replaced string.
     */
    private String replace(String value) {
        return new PropertyPlaceholderHelper("${", "}").replacePlaceholders(value, new PropertyPlaceholderHelper.PlaceholderResolver() {
            @Override
            public String resolvePlaceholder(String placeholderName) {
                return getProject().getProperty(placeholderName);
            }
        });
    }

    private void resetProperty(String name, String value) {
        variable(name, null, true);
        variable(name, value, false);
    }

    private void unsetProperty(String name) {
        variable(name, null, true);
    }

    private void variable(String name, String value, boolean unset) {
        Variable variableTask = new Variable();
        variableTask.setProject(getProject());
        variableTask.setUnset(unset);
        variableTask.setName(name);
        variableTask.setValue(value);
        variableTask.execute();
    }


    private void kill(String pidProperty, boolean force) {
        KillTask killTask = new KillTask();
        killTask.setProject(getProject());
        killTask.setPidProperty(replace(pidProperty));
        killTask.setForce(force);
        killTask.execute();
    }

    private void java(String classname, String maxmemory, boolean spawn, String[] jvmargs, String[] args) {
        Java javaTask = new Java();
        javaTask.setProject(getProject());
        javaTask.setClassname(replace(classname));
        javaTask.setFork(true);
        javaTask.setSpawn(spawn);
        javaTask.setMaxmemory(replace(maxmemory));
        javaTask.setClasspathRef(new Reference("datafabric.classpath"));
        javaTask.setDir(new File(replace("${workspace.dir}/${datafabric.node}")));
        if (!spawn) {
            javaTask.setOutput(new File(replace("${logs.dir}/${datafabric.node-component}.startup.log")));
        }

        // Jvm args
        for (String jvmarg : jvmargs) {
            if (isNotBlank(jvmarg)) {
                javaTask.createJvmarg().setValue(replace(jvmarg));
            }
        }

        // Args
        javaTask.createArg().setValue(replace("${datafabric.${datafabric.component}.${datafabric.action}.args}"));
        for (String arg : args) {
            if (isNotBlank(arg)) {
                javaTask.createArg().setValue(replace(arg));
            }
        }

        javaTask.execute();
    }

    @SuppressWarnings("unchecked")
    private MacroDef createMacroDef() {
        MacroDef macroDef = new MacroDef();
        macroDef.setProject(getProject());
        macroDef.createSequential().getNested().addAll(nestedDatafabricTasks);
        macroDef.addConfiguredAttribute(createMacroDefAttribute(DATAFABRIC_NODE_PROPERTY));
        macroDef.addConfiguredAttribute(createMacroDefAttribute(DATAFABRIC_COMPONENT_PROPERTY));
        return macroDef;
    }

    private MacroDef.Attribute createMacroDefAttribute(String name) {
        MacroDef.Attribute nodeAttribute = new MacroDef.Attribute();
        nodeAttribute.setName(name);
        return nodeAttribute;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    private List<String> getNodes(String node) {
        List<String> allNodes = new ArrayList<String>();
        allNodes.add("AU.Melbourne-Markets.Primary");
        allNodes.add("AU.Melbourne-Markets.Backup");
        allNodes.add("GB.London.Primary");
        allNodes.add("GB.London.Backup");
        allNodes.add("JP.Tokyo.Primary");
        allNodes.add("JP.Tokyo.Backup");

        List<String> selectedNodes = new ArrayList<String>();
        if (nullSafeEquals(node, "all")) {
            selectedNodes.addAll(allNodes);
        } else {
            if (isNotBlank(node)) {
                for (String currentNode : allNodes) {
                    if (currentNode.contains(node)) {
                        selectedNodes.add(currentNode);
                    }
                }
            }
        }
        return selectedNodes;
    }

    private List<String> getComponents(String component) {
        List<String> allComponents = new ArrayList<String>();
        allComponents.add("Locator");
        allComponents.add("CacheServer");
        allComponents.add("AdminAgent");

        List<String> selectedComponents = new ArrayList<String>();
        if (nullSafeEquals(component, "all")) {
            selectedComponents.addAll(allComponents);
        } else {
            if (isNotBlank(component)) {
                for (String currentComponent : allComponents) {
                    if (currentComponent.contains(component)) {
                        selectedComponents.add(currentComponent);
                    }
                }
            }
        }
        return selectedComponents;
    }

    @Override
    public void addTask(Task task) {
        nestedDatafabricTasks.add(task);
    }
}
