package com.anz.axle.lg.adapter.ebsd.quickfix;

import java.math.BigDecimal;

import org.junit.Test;

import quickfix.field.AggregatedBook;
import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateType;
import quickfix.field.MarketDepth;
import quickfix.field.SecurityType;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.fix42.MarketDataRequest;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EbsdMarketDataRequestEncoderTest {

    @Test
    public void testMarketDataSubscription() throws Exception {
        final int marketDepthInt = 1;
        final boolean aggregateBook = true;
        final boolean fullRefresh = false;
        final String expectedSymbol = "AUD/USD";
        final String requestId = "34214521";

        final EbsdMarketDataRequestEncoder encoder = new EbsdMarketDataRequestEncoder();

        final MarketDataSubscription subscription = mock(MarketDataSubscription.class);
        when(subscription.aggregateBook()).thenReturn(aggregateBook);
        when(subscription.symbol()).thenReturn(expectedSymbol);
        when(subscription.marketDepth()).thenReturn(marketDepthInt);
        when(subscription.fullRefresh()).thenReturn(fullRefresh);

        final MarketDataRequest marketDataRequest = encoder.encodeSubscribe(Integer.parseInt(requestId), subscription);

        final MDReqID mdReqId = marketDataRequest.getMDReqID();
        final MarketDepth marketDepth =  marketDataRequest.getMarketDepth();
        final AggregatedBook aggregatedBook = marketDataRequest.getAggregatedBook();
        final SubscriptionRequestType subscriptionRequestType = marketDataRequest.getSubscriptionRequestType();
        final MDUpdateType mdUpdateType = marketDataRequest.getMDUpdateType();
        final BigDecimal mdBookType = marketDataRequest.getDecimal(quickfix.field.MDBookType.FIELD);
        final MarketDataRequest.NoMDEntryTypes bidMdEntryTypesGroup = new MarketDataRequest.NoMDEntryTypes();
        marketDataRequest.getGroup(1, bidMdEntryTypesGroup);
        final MDEntryType bidBdEntryType = bidMdEntryTypesGroup.getMDEntryType();

        final MarketDataRequest.NoMDEntryTypes offerMdEntryTypesGroup = new MarketDataRequest.NoMDEntryTypes();
        marketDataRequest.getGroup(2, offerMdEntryTypesGroup);
        final MDEntryType offerBdEntryType = offerMdEntryTypesGroup.getMDEntryType();

        final MarketDataRequest.NoRelatedSym noRelatedSymGroup = new MarketDataRequest.NoRelatedSym();
        marketDataRequest.getGroup(1, noRelatedSymGroup);
        final Symbol symbol = noRelatedSymGroup.getSymbol();
        final SecurityType securityType = noRelatedSymGroup.getSecurityType();
        final String marketSegmentId = noRelatedSymGroup.getString(FixConstants.MARKET_SEGMENT_ID_FIELD);

        assertEquals(mdReqId.getValue(), requestId);
        assertEquals(marketDepth.getValue(), marketDepthInt);
        assertEquals(aggregatedBook.getValue(), aggregateBook);
        assertEquals(subscriptionRequestType.getValue(), EbsdMarketDataRequestEncoder.SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE);
        assertEquals(mdUpdateType.getValue(), MDUpdateType.INCREMENTAL_REFRESH);
        assertEquals(mdBookType.intValue(), EbsdMarketDataRequestEncoder.MD_BOOK_TYPE_PRICEDEPTH_SWEEPABLE);


        assertEquals(bidBdEntryType.getValue(), MDEntryType.BID);
        assertEquals(offerBdEntryType.getValue(), MDEntryType.OFFER);

        assertEquals(symbol.getValue(), expectedSymbol);
        assertEquals(securityType.getValue(), FixConstants.SECURITY_TYPE_FXSPOT);
        assertEquals(marketSegmentId, FixConstants.MARKET_SEGMENT_ID_DIRECT);
    }
}