package com.anz.markets.efx.ngaro.maths;

import com.anz.markets.efx.ngaro.collections.NotGcFriendly;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.text.NumberFormat;

/**
 * Copied from spdee-direct (thanks chaps!) and some changes applied
 */
public class DoubleTools {
    private static Epsilon EPSILON = Epsilon.EPS_1eNegative10;
    /**
     * all powers of 10 which can be represented exactly as a double
     */
    private static final double[] POW_TEN = {1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13, 1e14, 1e15, 1e16, 1e17, 1e18, 1e19, 1e20, 1e21, 1e22};
    private static final NumberFormat NUMBER_FORMATS[] = new NumberFormat[POW_TEN.length];

    static {
        for (int i = 0; i < NUMBER_FORMATS.length; i++) {
            NUMBER_FORMATS[i] = NumberFormat.getInstance();
            NUMBER_FORMATS[i].setMinimumFractionDigits(i);
            NUMBER_FORMATS[i].setMaximumFractionDigits(i);
        }
    }

    public static String format(double number, int places) {
        return NUMBER_FORMATS[places].format(number);
    }

    public static int compare(double v1, double v2) {
        if (EPSILON.equalsEpsilon(v1, v2)) {
            return 0;
        }
        return v1 > v2 ? 1 : -1;
    }




    /**
     * Rounds half away from zero
     */
    public static double round(double from, int places) {
        if (Double.isNaN(from)) {
            return from;
        }
        double pow = getPowerOfTen(places);
        double intermediate;
        if (from < 0.0) {
            intermediate = Math.ceil((from * pow) + -0.5);
        } else {
            intermediate = Math.floor((from * pow) + 0.5);
        }
        double rounded = intermediate / pow;
        return rounded;
    }

    /**
     * Rounds down
     */
    public static double roundDown(double from, int places) {
        if (Double.isNaN(from)) {
            return from;
        }
        double pow = getPowerOfTen(places);
        final double intermediate = Math.floor(from * pow);
        double rounded = intermediate / pow;
        return rounded;
    }

    /**
     * Rounds up
     */
    public static double roundUp(double from, int places) {
        if (Double.isNaN(from)) {
            return from;
        }
        double pow = getPowerOfTen(places);
        final double intermediate = Math.ceil(from * pow);
        double rounded = intermediate / pow;
        return rounded;
    }

    public static int truncateToNearestWholeNumber(final double amount, final int precisionInWholeNumber) {
        final int amt = (int) DoubleTools.round(amount, 0);
        return precisionInWholeNumber == 0 ? amt : (amt / precisionInWholeNumber) * precisionInWholeNumber;
    }

    /**
     * NaN is treated as less than all real number.
     * NaN == NaN which means will return false.
     */
    public static boolean isGreaterThan(final double value1, final double value2) {
        if (EPSILON.equalsEpsilon(value1, value2)) {
            return false;
        }
        return greaterThan(value1, value2);
    }

    public static boolean isGreaterThanOrEqual(final double value1, final double value2) {
        if (EPSILON.equalsEpsilon(value1, value2)) {
            return true;
        }
        return greaterThan(value1, value2);
    }

    private static boolean greaterThan(final double value1, final double value2) {
        if (Double.isNaN(value1) && !Double.isNaN(value2)) {
            return false;
        }
        if (!Double.isNaN(value1) && Double.isNaN(value2)) {
            return true;
        }
        return value1 > value2;
    }

    public static boolean isLessThan(final double value1, final double value2) {
        return !isGreaterThanOrEqual(value1, value2);
    }

    public static boolean isLessThanOrEqual(final double value1, final double value2) {
        return !isGreaterThan(value1, value2);
    }

    /**
     * Is the absolute difference between p1 and p2 less than epsilon
     */
    public static boolean equalsEpsilon(final double epsilon, double p1, double p2) {
        GcFriendlyAssert.isFalse(Double.isNaN(epsilon));
        if (eitherValueIsNan(p1, p2)) {
            return false;
        }
        return (Double.isNaN(p1) && Double.isNaN(p2)) || Math.abs(p1 - p2) < epsilon;
    }

    /**
     * Is the absolute difference between p1 and p2 less than epsilon
     */
    public static boolean equalsEpsilonExclusive(final double epsilon, double p1, double p2) {
        GcFriendlyAssert.isFalse(Double.isNaN(epsilon));
        if (eitherValueIsNan(p1, p2)) {
            return false;
        }
        return (Double.isNaN(p1) && Double.isNaN(p2)) || Math.abs(p1 - p2) < epsilon - 1.0e-10;
    }

    /**
     * Is the absolute difference between p1 and p2 less than epsilon
     */
    public static boolean equalsEpsilonInclusive(final double epsilon, double p1, double p2) {
        GcFriendlyAssert.isFalse(Double.isNaN(epsilon));
        if (eitherValueIsNan(p1, p2)) {
            return false;
        }
        return (Double.isNaN(p1) && Double.isNaN(p2)) || isLessThanOrEqual(Math.abs(p1 - p2), epsilon);
    }

    private static boolean eitherValueIsNan(final double p1, final double p2) {
        return (Double.isNaN(p1) && !Double.isNaN(p2)) || (!Double.isNaN(p1) && Double.isNaN(p2));
    }

    private DoubleTools() {
        throw new RuntimeException("No PriceRounderDouble for you!");
    }


    /**
     * Return number of decimal places given in the value.
     */
    @NotGcFriendly // Use for testing framework
    public static int decimalPlaces(final double value) {
        final String text = Double.toString(Math.abs(value));
        final int integerPlaces = text.indexOf('.');
        final int decimalPlaces = text.length() - integerPlaces - 1;
        return decimalPlaces;
    }

    private static double getPowerOfTen(int n) {
        if (n < 0 || n >= POW_TEN.length) {
            throw new IllegalArgumentException("illegal power: " + n);
        }
        return POW_TEN[n];
    }

}
