package com.anz.markets.efx.ngaro.collections;

@FunctionalInterface
public interface ObjBooleanPredicate<T> {

    boolean test(T t, boolean v);
}
