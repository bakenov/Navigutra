package com.anz.markets.efx.ngaro.time;

import java.nio.ByteBuffer;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteWriter;

public class LocalDateEncoderTest {

    private final LocalDateEncoder localDateEncoder = LocalDateFormat.YYYYMMDD.getDefaultEncoder();

    @Test
    public void encodeEpochMillis() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeEpochMillis(string, ByteWriter.STRING_BUILDER, offset, localDate.toEpochDay() * 24 * 3600 * 1000);
        localDateEncoder.encodeEpochMillis(bytes, ByteWriter.BYTE_ARRAY, localDate.toEpochDay() * 24 * 3600 * 1000);
        localDateEncoder.encodeEpochMillis(buffer, ByteWriter.BYTE_BUFFER, localDate.toEpochDay() * 24 * 3600 * 1000);

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test
    public void encodeEpochSeconds() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeEpochSeconds(string, ByteWriter.STRING_BUILDER, offset, localDate.toEpochDay() * 24 * 3600);
        localDateEncoder.encodeEpochSeconds(bytes, ByteWriter.BYTE_ARRAY, localDate.toEpochDay() * 24 * 3600);
        localDateEncoder.encodeEpochSeconds(buffer, ByteWriter.BYTE_BUFFER, localDate.toEpochDay() * 24 * 3600);

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeEpochSecondsInvalidYear() {
        //given
        final LocalDate localDate = LocalDate.of(-1, 1, 1);
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeEpochSeconds(sb, ByteWriter.STRING_BUILDER, offset, localDate.toEpochDay() * 24 * 3600);

        //then: expect exception
    }

    @Test
    public void encodeEpochDays() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeEpochDays(string, ByteWriter.STRING_BUILDER, offset, localDate.toEpochDay());
        localDateEncoder.encodeEpochDays(bytes, ByteWriter.BYTE_ARRAY, localDate.toEpochDay());
        localDateEncoder.encodeEpochDays(buffer, ByteWriter.BYTE_BUFFER, localDate.toEpochDay());

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test
    public void encodeEpochNull() {
        //given
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeEpochDays(string, ByteWriter.STRING_BUILDER, offset, 0);
        localDateEncoder.encodeEpochDays(bytes, ByteWriter.BYTE_ARRAY, 0);
        localDateEncoder.encodeEpochDays(buffer, ByteWriter.BYTE_BUFFER, 0);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));

        //when
        localDateEncoder.encodeEpochSeconds(string, ByteWriter.STRING_BUILDER, offset, 0);
        localDateEncoder.encodeEpochSeconds(bytes, ByteWriter.BYTE_ARRAY, 0);
        localDateEncoder.encodeEpochSeconds(buffer, ByteWriter.BYTE_BUFFER, 0);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));

        //when
        localDateEncoder.encodeEpochMillis(string, ByteWriter.STRING_BUILDER, offset, 0);
        localDateEncoder.encodeEpochMillis(bytes, ByteWriter.BYTE_ARRAY, 0);
        localDateEncoder.encodeEpochMillis(buffer, ByteWriter.BYTE_BUFFER, 0);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeLocalDate() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeNullable(string, ByteWriter.STRING_BUILDER, offset, localDate);
        localDateEncoder.encodeNullable(bytes, ByteWriter.BYTE_ARRAY, localDate);
        localDateEncoder.encodeNullable(buffer, ByteWriter.BYTE_BUFFER, localDate);

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test
    public void encodeLocalDateNull() {
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeNullable(string, ByteWriter.STRING_BUILDER, offset, null);
        localDateEncoder.encodeNullable(bytes, ByteWriter.BYTE_ARRAY, null);
        localDateEncoder.encodeNullable(buffer, ByteWriter.BYTE_BUFFER, null);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeNull() {
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeNull(string, ByteWriter.STRING_BUILDER, offset);
        localDateEncoder.encodeNull(bytes, ByteWriter.BYTE_ARRAY);
        localDateEncoder.encodeNull(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeAllFormats() {
        final LocalDate input = LocalDate.of(2017, 02, 24);
        final LocalDateFormat[] formats = {LocalDateFormat.YYYYMMDD, LocalDateFormat.MMDDYYYY, LocalDateFormat.DDMMYYYY,
                LocalDateFormat.YYYY_MM_DD, LocalDateFormat.MM_DD_YYYY, LocalDateFormat.DD_MM_YYYY};
        final String[] dateStrings = {"20170224", "02242017", "24022017",
                "2017-02-24", "02-24-2017", "24-02-2017"};
        final char[] delims = {'-', '/', '.'};

        for (int f = 0; f < formats.length; f++) {
            for (final char delim : delims) {
                final int length = formats[f].getLength();
                final LocalDateEncoder encoder = LocalDateEncoder.valueOf(formats[f], delim);
                final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
                final int offset = 3;
                final byte[] bytes = new byte[length];
                final ByteBuffer buffer = ByteBuffer.allocate(length);

                //when
                encoder.encodeNullable(string, ByteWriter.STRING_BUILDER, offset, input);
                encoder.encodeNullable(bytes, ByteWriter.BYTE_ARRAY, input);
                encoder.encodeNullable(buffer, ByteWriter.BYTE_BUFFER, input);

                //then
                final String expected = dateStrings[f].replace('-', delim);
                final String expectedString = "abc" + expected +"defghklmnopkrstuvwxyz".substring(expected.length());
                final String expectedBytes = expected + "\0\0\0\0\0\0\0\0\0\0".substring(0, length).substring(expected.length());
                Assert.assertEquals("encoded string not as expected for format " + formats[f], expectedString, string.toString());
                Assert.assertEquals("encoded bytes not as expected for format " + formats[f], expectedBytes, new String(bytes));
                Assert.assertEquals("encoded buffer not as expected for format " + formats[f], expectedBytes, new String(buffer.array()));
            }
        }
    }

    @Test
    public void encode() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encode(string, ByteWriter.STRING_BUILDER, offset, localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
        localDateEncoder.encode(bytes, ByteWriter.BYTE_ARRAY, localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
        localDateEncoder.encode(buffer, ByteWriter.BYTE_BUFFER, localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test
    public void encodeYearMonthDayNull() {
        //given
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encode(string, ByteWriter.STRING_BUILDER, offset, 0, 0, 0);
        localDateEncoder.encode(bytes, ByteWriter.BYTE_ARRAY, 0, 0, 0);
        localDateEncoder.encode(buffer, ByteWriter.BYTE_BUFFER, 0, 0, 0);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeYearMonthDay() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeYear(string, ByteWriter.STRING_BUILDER, offset, localDate.getYear());
        localDateEncoder.encodeMonth(string, ByteWriter.STRING_BUILDER, offset, localDate.getMonthValue());
        localDateEncoder.encodeDay(string, ByteWriter.STRING_BUILDER, offset, localDate.getDayOfMonth());
        localDateEncoder.encodeYear(bytes, ByteWriter.BYTE_ARRAY, localDate.getYear());
        localDateEncoder.encodeMonth(bytes, ByteWriter.BYTE_ARRAY, localDate.getMonthValue());
        localDateEncoder.encodeDay(bytes, ByteWriter.BYTE_ARRAY, localDate.getDayOfMonth());
        localDateEncoder.encodeYear(buffer, ByteWriter.BYTE_BUFFER, localDate.getYear());
        localDateEncoder.encodeMonth(buffer, ByteWriter.BYTE_BUFFER, localDate.getMonthValue());
        localDateEncoder.encodeDay(buffer, ByteWriter.BYTE_BUFFER, localDate.getDayOfMonth());

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test
    public void encodePackedNull() {
        //given
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodePacked(string, ByteWriter.STRING_BUILDER, offset, 0, LocalDatePacking.BINARY);
        localDateEncoder.encodePacked(bytes, ByteWriter.BYTE_ARRAY, 0, 0, LocalDatePacking.DECIMAL);
        localDateEncoder.encodePacked(buffer, ByteWriter.BYTE_BUFFER, 0, LocalDatePacking.BINARY);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodePacked() {
        //given
        final LocalDate localDate = LocalDate.of(2016, 12, 15);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodePacked(string, ByteWriter.STRING_BUILDER, offset,
                LocalDatePacking.BINARY.pack(localDate), LocalDatePacking.BINARY);
        localDateEncoder.encodePacked(bytes, ByteWriter.BYTE_ARRAY,
                LocalDatePacking.DECIMAL.pack(localDate), LocalDatePacking.DECIMAL);
        localDateEncoder.encodePacked(buffer, ByteWriter.BYTE_BUFFER,
                LocalDatePacking.BINARY.pack(localDate), LocalDatePacking.BINARY);

        //then
        Assert.assertEquals("encoded string not as expected", "abc20161215nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "20161215", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "20161215", new String(buffer.array()));
    }

    @Test
    public void encodeDelimiters() {
        //given
        final LocalDateEncoder encoder = new LocalDateEncoder(LocalDateFormat.YYYY_MM_DD);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getDateFormat().getLength());

        //when
        encoder.encodeDelimiters(string, ByteWriter.STRING_BUILDER, offset);
        encoder.encodeDelimiters(bytes, ByteWriter.BYTE_ARRAY);
        encoder.encodeDelimiters(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefg-kl-nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0-\0\0-\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0-\0\0-\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeDelimiters_ifNoDelimitersInFormat() {
        //given
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localDateEncoder.getDateFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localDateEncoder.getDateFormat().getLength());

        //when
        localDateEncoder.encodeDelimiters(string, ByteWriter.STRING_BUILDER, offset);
        localDateEncoder.encodeDelimiters(bytes, ByteWriter.BYTE_ARRAY);
        localDateEncoder.encodeDelimiters(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeYearNegative() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeYear(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeYearTooLarge() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeYear(sb, ByteWriter.STRING_BUILDER, offset, 10000);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMonthNegative() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeMonth(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMonthZero() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeMonth(sb, ByteWriter.STRING_BUILDER, offset, 0);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMonthTooLarge() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeMonth(sb, ByteWriter.STRING_BUILDER, offset, 13);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeDayNegative() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeDay(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeDayZero() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeDay(sb, ByteWriter.STRING_BUILDER, offset, 0);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeDayTooLarge() {
        //given
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localDateEncoder.encodeDay(sb, ByteWriter.STRING_BUILDER, offset, 32);

        //then: expecte exception
    }
}