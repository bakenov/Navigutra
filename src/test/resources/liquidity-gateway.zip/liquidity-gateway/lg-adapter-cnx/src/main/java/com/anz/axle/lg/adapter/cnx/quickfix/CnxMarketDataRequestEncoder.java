package com.anz.axle.lg.adapter.cnx.quickfix;

import quickfix.field.AggregatedBook;
import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateType;
import quickfix.field.MarketDepth;
import quickfix.field.MsgType;
import quickfix.field.NoRelatedSym;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.fix42.MarketDataRequest;

import com.anz.axle.lg.adapter.fix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

public class CnxMarketDataRequestEncoder implements MarketDataRequestEncoder<MarketDataRequest> {
    protected static final char SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE = '1';
    protected static final char SUBSCRIPTION_REQUEST_TYPE_UNSUBSCRIBE = '2';

    private final MarketDataRequest marketDataRequest = new MarketDataRequest();
    private final MarketDataRequest.NoMDEntryTypes bidEntryType = new MarketDataRequest.NoMDEntryTypes();
    private final MarketDataRequest.NoMDEntryTypes offerEntryType = new MarketDataRequest.NoMDEntryTypes();
    private final MarketDataRequest.NoRelatedSym group = new MarketDataRequest.NoRelatedSym();

    public CnxMarketDataRequestEncoder() {
        bidEntryType.set(new MDEntryType(MDEntryType.BID));
        offerEntryType.set(new MDEntryType(MDEntryType.OFFER));
    }

    @Override
    public MarketDataRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(marketDataRequest, requestId, subscription, SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE);
    }

    @Override
    public MarketDataRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(marketDataRequest, requestId, subscription, SUBSCRIPTION_REQUEST_TYPE_UNSUBSCRIBE);
    }


    private MarketDataRequest encode(final MarketDataRequest marketDataRequest, final long requestId, final MarketDataSubscription subscription, final char subscriptionRequestType) {
        marketDataRequest.clear();
        marketDataRequest.getHeader().setString(MsgType.FIELD, MsgType.MARKET_DATA_REQUEST);
        marketDataRequest.setInt(MDReqID.FIELD, (int) requestId);
        marketDataRequest.setChar(SubscriptionRequestType.FIELD, subscriptionRequestType);
        marketDataRequest.setInt(MarketDepth.FIELD, subscription.marketDepth());
        marketDataRequest.setInt(MDUpdateType.FIELD, subscription.fullRefresh() ? MDUpdateType.FULL_REFRESH : MDUpdateType.INCREMENTAL_REFRESH);
        marketDataRequest.setBoolean(AggregatedBook.FIELD, subscription.aggregateBook());
        marketDataRequest.addGroup(bidEntryType);
        marketDataRequest.addGroup(offerEntryType);
        marketDataRequest.setInt(NoRelatedSym.FIELD, 1);
        group.clear();
        group.setString(Symbol.FIELD, subscription.symbol());
        marketDataRequest.addGroup(group);
        return marketDataRequest;
    }
}
