package com.anz.markets.efx.ngaro.core;

import java.util.function.Supplier;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertSame;

/**
 * Unit test for {@link CachingSupplier}
 */
@RunWith(MockitoJUnitRunner.class)
public class CachingSupplierTest {

    @Mock
    private Supplier<String> stringSupplier;

    @Test
    public void getResetGet() throws Exception {
        //given
        final String value1 = "First String";
        final String value2 = "Second String";
        final String value3 = "Third String";
        Mockito.when(stringSupplier.get()).thenReturn(value1, value2, value3);
        final CachingSupplier<String> cachingSupplier = CachingSupplier.of(stringSupplier);
        final InOrder inOrder = Mockito.inOrder(stringSupplier);

        //when
        final String actual1 = cachingSupplier.get();
        final String actual2 = cachingSupplier.get();

        //then
        assertSame("actual1 not as expected", value1, actual1);
        assertSame("actual2 not as expected", value1, actual2);
        inOrder.verify(stringSupplier, Mockito.times(1)).get();
        inOrder.verifyNoMoreInteractions();

        //when
        cachingSupplier.reset();
        final String actual3 = cachingSupplier.get();
        final String actual4 = cachingSupplier.get();

        //then
        assertSame("actual3 not as expected", value2, actual3);
        assertSame("actual4 not as expected", value2, actual4);
        inOrder.verify(stringSupplier, Mockito.times(1)).get();
        inOrder.verifyNoMoreInteractions();
    }

}