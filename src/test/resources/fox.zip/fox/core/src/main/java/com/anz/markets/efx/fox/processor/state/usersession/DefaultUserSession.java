package com.anz.markets.efx.fox.processor.state.usersession;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.UserSession;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.processor.timer.Timer;

public class DefaultUserSession implements UserSession {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultUserSession.class);

    private final UserSessionKey userSessionKey;
    private final Timer missedHeartbeatTimer;
    private final Consumer<UserSessionKey> onGoingOnlineHandler;
    private final Consumer<UserSessionKey> onGoingOfflineHandler;
    private final ToIntFunction<String> onlinePortfolioSessionsLookup;
    private final long missedHeartbeatTimeoutMillis;
    private boolean online;

    public DefaultUserSession(final UserSessionKey userSessionKey,
                              final Timer.Factory timerFactory,
                              final Consumer<UserSessionKey> onGoingOnlineHandler,
                              final Consumer<UserSessionKey> onGoingOfflineHandler,
                              final ToIntFunction<String> onlinePortfolioSessionsLookup,
                              final long missedHeartbeatTimeoutMillis) {
        this.userSessionKey = Objects.requireNonNull(userSessionKey);
        this.onGoingOnlineHandler = Objects.requireNonNull(onGoingOnlineHandler);
        this.onGoingOfflineHandler = Objects.requireNonNull(onGoingOfflineHandler);
        this.onlinePortfolioSessionsLookup = Objects.requireNonNull(onlinePortfolioSessionsLookup);
        this.missedHeartbeatTimeoutMillis = missedHeartbeatTimeoutMillis;
        this.missedHeartbeatTimer = timerFactory.create(new UserSessionMissedHeartbeatHandler(this));
    }

    @Override
    public int onlinePortfolioSessions() {
        return onlinePortfolioSessionsLookup.applyAsInt(userSessionKey.portfolio());
    }

    @Override
    public void updateOffline() {
        if (online()) {
            LOGGER.info("User session {} goes offline", userSessionKey.sessionId());
            online = false;
            onGoingOfflineHandler.accept(userSessionKey);
        }
    }

    @Override
    public void updateOnline() {
        if(!online()) {
            LOGGER.info("User session {} goes online", userSessionKey.sessionId());
            online = true;
            onGoingOnlineHandler.accept(userSessionKey);
        }
        missedHeartbeatTimer.cancel();
        missedHeartbeatTimer.schedule(missedHeartbeatTimeoutMillis);
    }

    @Override
    public UserSessionKey userSessionKey() {
        return userSessionKey;
    }

    @Override
    public boolean online() {
        return online;
    }
}
