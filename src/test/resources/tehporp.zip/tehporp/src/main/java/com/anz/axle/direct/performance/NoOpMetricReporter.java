package com.anz.axle.direct.performance;

import com.anz.axle.direct.performance.metrics.BasicStats;
import com.anz.axle.direct.performance.metrics.Count;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.axle.direct.performance.metrics.Rates;

import java.util.Collection;

public enum NoOpMetricReporter implements MetricReporter {
    INSTANCE;

    @Override
    public void appendCounts(final Collection<Count> counters) {
        // not implemented
    }

    @Override
    public void appendBasicStats(final Collection<BasicStats> basicStatsList) {
        // not implemented
    }

    @Override
    public void appendHistograms(final Collection<Percentiles> percentilesList) {
        // not implemented
    }

    @Override
    public void appendRates(final Collection<Rates> ratesList) {
        // not implemented
    }

    @Override
    public void beginReports() {
        // not implemented
    }

    @Override
    public void endReports() {
        // not implemented
    }

}
