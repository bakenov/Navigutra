#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_price_freq_au - Plugin to monitor the Price Update Frequency (VAG1)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=z::deprecated
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Price Update Frequency (VAG1) [DEPRECATED]'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category z::deprecated'
    echo 'graph_scale no'
    echo 'price4.label Venue Price Updates (RFX)'
    echo 'price4.draw AREA'
    echo 'price7.label Venue Price Updates (CME)'
    echo 'price7.draw STACK'
    echo 'price9.label Venue Price Updates (GS)'
    echo 'price9.draw STACK'
    echo 'price10.label Venue Price Updates (CMZ)'
    echo 'price10.draw STACK'
    echo 'price15.label Venue Price Updates (BARX)'
    echo 'price15.draw STACK'
    echo 'price19.label Venue Price Updates (FXBK)'
    echo 'price19.draw STACK'
    echo 'price18.label Venue Price Updates (ANZD)'
    echo 'price18.draw STACK'
    echo 'price5.label AggBooks Aggregated'
    echo 'price5.draw LINE2'
    echo 'price5.colour FF0000'		# RED
    echo 'price11.label AggBooks Published to Main'
    echo 'price11.draw LINE2'
    echo 'price11.colour FFFFFF'	# WHITE
    exit 0
fi

echo "price4.value U"
echo "price7.value U"
echo "price9.value U"
echo "price10.value U"
echo "price15.value U"
echo "price19.value U"
echo "price18.value U"
echo "price5.value U"
echo "price11.value U"
exit 0