package com.anz.axle.lg.adapter.apama.event;

import java.util.List;
import java.util.Map;

import com.apama.event.Event;
import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;
import com.apama.event.parser.SequenceFieldType;

public final class EbsMarketDataSnapshotFullRefresh {
    public static final String EVENT_NAME = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh";
    public static final Field<String> FIELD_TRANSPORT = GeneralApamaEventFields.FIELD_TRANSPORT;
    public static final Field<String> FIELD_SESSION = GeneralApamaEventFields.FIELD_SESSION;
    public static final Field<String> FIELD_MD_REQ_ID = MarketDataApamaEventFields.FIELD_MD_REQ_ID;
    public static final Field<String> FIELD_SYMBOL = GeneralApamaEventFields.FIELD_SYMBOL;
    public static final EbsServiceIdField FIELD_SERVICE_ID = new EbsServiceIdField();
    public static final Field<List<Event>> FIELD_MD_NO_ENTRIES = new Field<>("NoMDEntries", new SequenceFieldType<>(MarketDataSnapshotFullRefresh_MDEntry.EVENT_TYPE));
    public static final Field<Map<Long, Double>> FIELD_TIMESTAMPS = GeneralApamaEventFields.FIELD_TIMESTAMPS;
    public static final Field<Map<String, String>> FIELD_PAYLOAD = GeneralApamaEventFields.FIELD_PAYLOAD;

    public static final EventType EVENT_TYPE = initEventType(EVENT_NAME);

    static EventType initEventType(final String eventName) {
        return new EventType(
                eventName,
                FIELD_TRANSPORT,
                FIELD_SESSION,
                FIELD_MD_REQ_ID,
                FIELD_SYMBOL,
                FIELD_SERVICE_ID,
                FIELD_MD_NO_ENTRIES,
                FIELD_TIMESTAMPS,
                FIELD_PAYLOAD);
    }
}
