package com.anz.axle.acc;

import org.apache.log4j.Logger;
import org.quartz.impl.StdScheduler;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public class Shutdown extends Thread {
	private static final Logger LOG = Logger.getLogger(Shutdown.class);
	private StdScheduler scheduler;

	public Shutdown(StdScheduler scheduler) {
		this.scheduler = scheduler;
	}

	public void run() {
		LOG.warn("Starting shutdown sequence.");
		LOG.info("-- Job scheduler is shutting down...");
		scheduler.shutdown(true);
		while(!scheduler.isShutdown()) {
			try {
                LOG.info("-- Job scheduler is trying to shut down...");
				Thread.sleep(500);
			} catch (InterruptedException e) {
				LOG.error("Thread interrupted", e);
			}
		}
		LOG.info("-- Job scheduler has shut down.");
		LOG.warn("Shutdown sequence complete.");
	}
}
