package software.chronicle.fix.using.queue;

import net.openhft.chronicle.bytes.MethodReader;
import net.openhft.chronicle.queue.ExcerptAppender;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.WireIn;
import software.chronicle.fix.business.logic.BusinessLogic;
import software.chronicle.fix.business.logic.ExecutionReportListener;
import software.chronicle.fix.sessioncode.messages.Logon;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import static java.util.concurrent.Executors.newSingleThreadExecutor;

class ServerMessageNotifier implements MessageNotifier, Demarshallable {

    private transient final BusinessLogic out;
    private transient FixSessionHandler session;

    public ServerMessageNotifier(@SuppressWarnings("unused") WireIn w) {
        final SingleChronicleQueue outQ = SingleChronicleQueueBuilder.binary("fix-to-business-logic").build();
        final ExcerptAppender excerptAppender = outQ.acquireAppender();

        this.out = excerptAppender.methodWriter(BusinessLogic.class);
        newSingleThreadExecutor().submit(this::send);
    }

    private void send() {
        final SingleChronicleQueue inQ = SingleChronicleQueueBuilder.binary("business-logic-to-fix").build();
        MethodReader methodReader = inQ.createTailer().methodReader(new InBound());
        for (; ; ) {
            methodReader.readOne();
        }
    }

    @Override
    public void onLogon(final FixSessionHandler session, final Logon logon) {
        this.session = session;

    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }

    @Override
    public void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        out.onNewOrderSingle(newOrderSingle);
    }

    class InBound implements ExecutionReportListener {

        @Override
        public void onExecutionReport(final software.chronicle.generated.code.messages.ExecutionReport executionReport) {
            executionReport.transactTime(session.context().timeProvider().currentTimeMillis());
            session.sendMessage(executionReport);
        }
    }
}
