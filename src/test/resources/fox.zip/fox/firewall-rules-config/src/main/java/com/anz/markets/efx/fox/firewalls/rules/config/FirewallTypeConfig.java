package com.anz.markets.efx.fox.firewalls.rules.config;

import java.util.ArrayList;
import java.util.List;

public class FirewallTypeConfig {
    private String firewallName;
    private List<String> columns;
    private List<List<Object>> rules;
    private List<FirewallConfigInstance> configuredInstances;

    public String getFirewallName() {
        return firewallName;
    }

    public void setFirewallName(final String firewallName) {
        this.firewallName = firewallName;
    }

    public void setColumns(final List<String> columns) {
        this.columns = columns;
    }

    public void setRules(final List<List<Object>> rules) {
        this.rules = rules;
    }

    private void clearThenBuildConfigInstance() {
        configuredInstances = new ArrayList<>();

        //validate size of columns matches all rules
        int columnSize = columns.size();
        for (List<Object> rule : rules) {
            if (rule.size() != columnSize) {
                throw new IllegalArgumentException("Rule " + rule.get(0) + " found in firewallName '" + firewallName + "' contains " + rule.size() + " fields defined whilst there exists " + columnSize + " named columns");
            }
        }

        for (List<Object> rule : rules) {
            final FirewallConfigInstance configInstance = new FirewallConfigInstance();
            for (int i = 0; i < columns.size(); i++) {
                final String fieldName = columns.get(i).trim();
                final Object value = rule.get(i);
                configInstance.callSetter(fieldName, value, firewallName, rule);
            }
            configuredInstances.add(configInstance);
        }
    }

    public List<FirewallConfigInstance> getConfiguredInstances() {
        if(columns != null && columns.size() > 0 && rules != null && rules.size() > 0){
            clearThenBuildConfigInstance();
        }
        return configuredInstances;
    }
}
