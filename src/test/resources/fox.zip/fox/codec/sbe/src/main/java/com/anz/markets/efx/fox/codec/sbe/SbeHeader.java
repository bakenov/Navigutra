package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class SbeHeader implements Header {
    private final MessageHeaderDecoder messageHeaderDecoder;

    public SbeHeader() {
        this(new MessageHeaderDecoder());
    }

    public SbeHeader(final MessageHeaderDecoder messageHeaderDecoder) {
        this.messageHeaderDecoder = Objects.requireNonNull(messageHeaderDecoder);
    }

    @Override
    public int source() {
        return messageHeaderDecoder.source();
    }

    @Override
    public long sourceSeq() {
        return messageHeaderDecoder.sourceSeq();
    }

    public boolean wrap(final SbeMessage sbeMessage) {
        messageHeaderDecoder.wrap(sbeMessage.buffer(), 0);
        return true;
    }

}
