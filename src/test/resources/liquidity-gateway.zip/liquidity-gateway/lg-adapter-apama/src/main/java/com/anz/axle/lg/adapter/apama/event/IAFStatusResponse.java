package com.anz.axle.lg.adapter.apama.event;

import java.util.Map;

import com.apama.event.parser.BooleanFieldType;
import com.apama.event.parser.DictionaryFieldType;
import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;
import com.apama.event.parser.IntegerFieldType;
import com.apama.event.parser.StringFieldType;

public class IAFStatusResponse {
    public static final String EVENT_NAME = "com.apama.adapters.IAFStatusResponse_1";
    public static final Field<String> FIELD_TRANSPORT = GeneralApamaEventFields.FIELD_TRANSPORT;
    public static final Field<Boolean> FIELD_RUNNING = new Field<>("running", BooleanFieldType.TYPE);
    public static final Field<Long> FIELD_ID = GeneralApamaEventFields.FIELD_ID;
    public static final Field<Long> FIELD_MAX_IAF_STATUS_VERSION = new Field<>("maxIAFStatusVersion", IntegerFieldType.TYPE);
    public static final Field<Long> FIELD_IAF_PORT = new Field<>("iafPort", IntegerFieldType.TYPE);
    public static final Field<String> FIELD_CONFIG_NAME = new Field<>("configName", StringFieldType.TYPE);
    public static final Field<String> FIELD_CODEC_NAME = new Field<>("codecName", StringFieldType.TYPE);
    public static final Field<Boolean> FIELD_RESTARTED = new Field<>("restarted", BooleanFieldType.TYPE);
    public static final Field<Map<String, String>> FIELD_CODEC_STATUS = new Field<>("codecStatus", new DictionaryFieldType<>(StringFieldType.TYPE, StringFieldType.TYPE));
    public static final Field<Map<String, String>> FIELD_TRANSPORT_STATUS = new Field<>("transportStatus", new DictionaryFieldType<>(StringFieldType.TYPE, StringFieldType.TYPE));

    public static final EventType EVENT_TYPE = initEventType();

    private static EventType initEventType() {
        return new EventType(EVENT_NAME,
                FIELD_ID,
                FIELD_MAX_IAF_STATUS_VERSION,
                FIELD_IAF_PORT,
                FIELD_CONFIG_NAME,
                FIELD_CODEC_NAME,
                FIELD_TRANSPORT,
                FIELD_RUNNING,
                FIELD_RESTARTED,
                FIELD_CODEC_STATUS,
                FIELD_TRANSPORT_STATUS);
    }
}
