package com.anz.axle.lg.adapter.apama.ebs;

import java.util.List;
import java.util.function.Function;

import com.google.common.collect.Lists;

import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

public class SettleDateToTenor implements Function<String, Tenor> {
    private final static LocalDateDecoder SETTLEMENT_DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    @SuppressWarnings("unchecked")
    private final static List<Tenor> EOM_TENORS = Lists.newArrayList (
        Tenor.EOM1, Tenor.EOM2,  Tenor.EOM3,  Tenor.EOM4,
        Tenor.EOM5, Tenor.EOM6,  Tenor.EOM7,  Tenor.EOM8,
        Tenor.EOM9, Tenor.EOM10, Tenor.EOM11, Tenor.EOY1
    );

    @Override
    public Tenor apply(final String settleDate) {
        if (settleDate == null) return Tenor.SP;
        final int month = SETTLEMENT_DATE_DECODER.decodeMonth(settleDate, ByteReader.CHAR_SEQUENCE);
        return EOM_TENORS.get(month - 1);
    }
}
