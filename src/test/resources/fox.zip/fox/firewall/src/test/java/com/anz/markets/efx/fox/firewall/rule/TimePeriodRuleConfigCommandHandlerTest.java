package com.anz.markets.efx.fox.firewall.rule;

import java.util.function.LongSupplier;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.sbe.FirewallConfigSbeDecoder;
import com.anz.markets.efx.fox.codec.sbe.SorCodecUtil;
import com.anz.markets.efx.fox.firewall.rule.TimePeriodRuleConfigCommandHandler;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(Spockito.class)
public class TimePeriodRuleConfigCommandHandlerTest {
    private final SorCodecUtil.Codec commandCodec = SorCodecUtil.create();
    private final SorCodecUtil.Codec eventCodec = SorCodecUtil.create();

    private CommandContext commandContext = mock(CommandContext.class);

    @Test
    @Spockito.Unroll({
            "| firewallName   | ruleId   | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period   | periodUnit    | local    | comment  | lastEditUsername | lastEditTime  | limitThreshold | accepted |",
            "|================|==========|===============|==================|=============|==================|=================|==============|=====================|==============|===============|==========|===============|==========|==========|==================|===============|================|==========|",
            "| firewall1      | 10       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 3              | true     |",
            "| firewall1      | 20       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 5              | true     |",
            "| firewall1      | 20       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | blah          | false    | blah     | anufriea         | 3456          | 5              | false    |",
            "| firewall2      | 30       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 1              | false    |",
            "| firewall2      | 40       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 1              | false    |"
    })
    public void handleCommand(final String firewallName, final long ruleId, final String regionPattern, final String orderTypePattern,
                       final String deskPattern,  final String portfolioPattern, final String usernamePattern,
                       final String venuePattern, final String securityTypePattern, final String tenorPattern, final String symbolPattern,
                       final long period, final String periodUnit, final boolean local, final String comment,
                       final String lastEditUsername, final long lastEditTime, final long limitThreshold, final boolean accepted) {

        //given
        commandCodec.encoderSupplier().firewallConfigEncoder().messageStart(1, 2)
                .firewallName().encode(firewallName)
                .ruleId(ruleId)
                .regionPattern().encode(regionPattern)
                .orderTypePattern().encode(orderTypePattern)
                .deskPattern().encode(deskPattern)
                .portfolioPattern().encode(portfolioPattern)
                .usernamePattern().encode(usernamePattern)
                .venuePattern().encode(venuePattern)
                .securityTypePattern().encode(securityTypePattern)
                .tenorPattern().encode(tenorPattern)
                .symbolPattern().encode(symbolPattern)
                .period(period)
                .periodUnit().encode(periodUnit)
                .local(local)
                .lastEditUsername().encode(lastEditUsername)
                .lastEditTime(lastEditTime)
                .comment().encode(comment)
                .limitThreshold(limitThreshold)
                .messageComplete();

        final LongSupplier idGenerator = () -> 123;
        when(commandContext.source()).thenReturn(10);
        when(commandContext.idGenerator()).thenReturn(idGenerator);
        when(commandContext.sorEncoderSupplier()).thenReturn(eventCodec.encoderSupplier());

        final TimePeriodRuleConfigCommandHandler commandHandler = new TimePeriodRuleConfigCommandHandler("firewall1");

        //when
        commandHandler.handleCommand(commandCodec.firewallConfigSbeDecoder(), commandContext);

        //then
        if (accepted) {
            final FirewallConfigSbeDecoder.Body firewallConfigBody = eventCodec.firewallConfigSbeDecoder().body();

            assertThat(firewallConfigBody.firewallName().decodeStringOrNull()).isEqualTo(firewallName);
        } else {
            verify(commandContext, never()).source();
        }
    }
}