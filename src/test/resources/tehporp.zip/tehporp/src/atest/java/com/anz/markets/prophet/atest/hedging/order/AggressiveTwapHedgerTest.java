package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTakeProfitHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.OptimalPositionConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.HedgePortfolioState;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.VolatilityType;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerState.SELL_REQ;
import static com.anz.markets.prophet.domain.HedgeTriggerType.AGR_AXL_TWAP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURGBP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCAD;
import static com.anz.markets.prophet.domain.Level.QTY_1M;
import static com.anz.markets.prophet.domain.Level.QTY_2M;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.matcher.LamdaMatcher.f;
import static java.lang.Math.abs;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.isIn;

@RestartBeforeTest(reason = "As hedger states are left hanging")
@Requirement({Requirement.Ref.HEDGING_4_3})
public class AggressiveTwapHedgerTest extends BaseAcceptanceSpecification {
    NewOrder newOrder;
    NewOrder newOrder2;

    @Test
    public void shouldStartWithHedgersIdle() {
        when:
        {
            prophet.receive(tdd.configuration_hedging_001(), false);
        }
        then:
        {
            List<HedgeDecision> hedgeDecisions = prophet.expect(HedgeDecision.class, atLeast(50));
            for (HedgeDecision hd : hedgeDecisions) {
                assertThat(hd.getHedgeTriggerState(), isIn(new HedgeTriggerState[]{HedgeTriggerState.IDLE, HedgeTriggerState.NO_CONFIG}));
            }
        }
    }

    @Test
    public void shouldNotEmitHedgingOrderWhenDisabled() {
        when:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, AUDUSD).setMaximumSpread(0.0002).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(1_000_000).setMinimumRisk(1_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(10_000)
            )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        and:
        // wait for order rate time period of 10 sec
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, AGR_AXL_TWAP, SELL_REQ)), 10_000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotMetNoHedgeSellOrder() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.0001)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_000_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000),
                            new PriceAndQtyImpl(0.74995, 749_999),
                            new PriceAndQtyImpl(0.74993, 100_00)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
                    tdd.now()));
        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(3_000);
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotMetNoHedgeBuyOrder() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double buyOrderPrice = 0.75006;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.0001)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_000_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 250_000),
                            new PriceAndQtyImpl(0.75005, 999_999),
                            new PriceAndQtyImpl(0.75007, 100_00)),
                    tdd.now()));
        }
        when:
        // t+0 hedger places out BUY 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(3_000);
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyMetAtSellOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.0001)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_000_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000),
                            new PriceAndQtyImpl(0.74994, 1_750_000),
                            new PriceAndQtyImpl(0.74993, 100_00)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
                    tdd.now()));

        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // t+3 after order rate time period
        {
            prophet.incrementTime(3_000);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getPrice(), is(sellOrderPrice));
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotEnoughDepthAtSellOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.0001)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_000_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000),
                            new PriceAndQtyImpl(0.74995, 500_00),
                            new PriceAndQtyImpl(0.74994, 100_00)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
                    tdd.now()));
        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(3_000);
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getPrice(), is(sellOrderPrice));
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotEnoughDepthAtBuyOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double buyOrderPrice = 0.75006;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.0001)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_000_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 250_000),
                            new PriceAndQtyImpl(0.75005, 999_999)),
                    tdd.now()));
        }
        when:
        // t+0 hedger places out BUY 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(3_000);
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getPrice(), is(buyOrderPrice));
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void noLiquidityAtSellOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.0001)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_250_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74993, 500_000),
                            new PriceAndQtyImpl(0.74992, 750_000),
                            new PriceAndQtyImpl(0.74991, 100_00)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
                    tdd.now()));
        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(3_000);
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void noLiquidityAtBuyOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        long minQty = 1_250_000;
        double buyOrderPrice = 0.75006;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                            .setMaximumSpread(0.00010)
                            .setMinimumQuantity(minQty)
                            .setMinimumRisk(1_250_000)
                            .setOrderRateLimit(1_500_000)
                            .setOrderRateTimePeriodMS(3_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75007, 250_000),
                            new PriceAndQtyImpl(0.75008, 999_999),
                            new PriceAndQtyImpl(0.75008, 100_00)),
                    tdd.now()));
        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(3_000);
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void shouldEmitHedgingOrderWhenLongGradientPositionMet() {
        double minRisk = 1_500_001.5;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0002).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(100_000).setMinimumRisk(minRisk).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0003).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(1_000_000).setMinimumRisk(15_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0004).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(2_000_000).setMinimumRisk(30_000_000).setOrderRateLimit(5_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(1500000.0));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional() == minRisk, is(true));
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(1_000);
        }
        and:
        {
            final double expectedOrderQuantity = 1_000_000;
            final double expectedOrderPrice = 0.75002 - 0.0002;

            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(SELL_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELLING));
            assertThat(hedgeDecision.get(1).getQuantity(), is(expectedOrderQuantity));
            assertThat(hedgeDecision.get(1).getPrice(), is(expectedOrderPrice));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
            assertThat(newOrder.getQuantity(), is(expectedOrderQuantity));
            assertThat(newOrder.getPrice(), is(expectedOrderPrice));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
    }

    @Test
    public void shouldEmitHedgingOrderWhenShortGradientPositionMet() {
        double minRisk = 1_500_001;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0002).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(100_000).setMinimumRisk(minRisk).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0003).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(2_000_000).setMinimumRisk(15_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0004).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(5_000_000).setMinimumRisk(30_000_000).setOrderRateLimit(5_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74997, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(-1500000.0));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(abs(op.getGradientPositionInNotional()) > minRisk, is(true));
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(1_000);
        }
        and:
        {
            final double expectedOrderQuantity = 1_000_000;
            final double expectedOrderPrice = 0.74997 + 0.0002;

            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.BUYING));
            assertThat(hedgeDecision.get(1).getQuantity(), is(expectedOrderQuantity));
            assertThat(hedgeDecision.get(1).getPrice(), is(expectedOrderPrice));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
            assertThat(newOrder.getQuantity(), is(expectedOrderQuantity));
            assertThat(newOrder.getPrice(), is(expectedOrderPrice));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void strategyToUseBiasedPositions() {
        double minRisk = 1_500_001;
        long orderRateLimit = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0002).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(100_000).setMinimumRisk(minRisk).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0003).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(2_000_000).setMinimumRisk(15_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0004).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(5_000_000).setMinimumRisk(30_000_000).setOrderRateLimit(5_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74997, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(-1500000.0));
            assertThat(abs(op.getGradientPositionInNotional()) >= minRisk, is(false));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, -2_000_001.0));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(abs(op.getGradientPositionInNotional()) > 0, is(true)); // LONG pos
            assertThat(abs(op.getGradientPositionInNotional()) > minRisk, is(true));
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(1_000);
        }
        then:
        // since long biased position => SELL (unbiased pos is still short though)
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
            assertThat(newOrder.getQuantity(), is((double)orderRateLimit));
        }
    }

    @Test
    public void shouldEmitHedgingOrderUsingCorrectTier() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0001).setMinimumQuantity(1_000_000).setMinimumRisk(1_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(2_000_000).setMinimumRisk(3_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0004).setMinimumQuantity(5_000_000).setMinimumRisk(30_000_000).setOrderRateLimit(5_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74997, Level.QTY_2M.getQty(), 0.75002, Level.QTY_2M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(-3_000_000.0));
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(1_000);
        }
        and:
        {
            final double expectedOrderQuantity = 2_000_000.;
            final double expectedOrderPrice = 0.74997 + 0.0002;

            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP));
            assertThat(hedgeDecision.get(1).getQuantity(), is(expectedOrderQuantity));
            assertThat(hedgeDecision.get(1).getPrice(), is(expectedOrderPrice));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(expectedOrderQuantity));
            assertThat(newOrder.getPrice(), is(expectedOrderPrice));
        }
    }

    @Test
    public void shouldEmitHedgingOrderUsingHighestTier() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0001).setMinimumQuantity(1_000_000).setMinimumRisk(1_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(2_000_000).setMinimumRisk(3_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0004).setMinimumQuantity(5_000_000).setMinimumRisk(7_500_000).setOrderRateLimit(5_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74997, Level.QTY_5M.getQty(), 0.75002, Level.QTY_1M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_100, 0.750000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional() > 7500000, is(true));
        }
        and:
        // after order rate timeout.
        {
            prophet.incrementTime(1_000);
        }
        and:
        {
            final double expectedOrderQuantity = 5_000_000.;
            final double expectedOrderPrice = 0.74962;

            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP));
            assertThat(hedgeDecision.get(1).getQuantity(), is(expectedOrderQuantity));
            assertThat(hedgeDecision.get(1).getPrice(), is(expectedOrderPrice));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(expectedOrderQuantity));
            assertThat(newOrder.getPrice(), is(expectedOrderPrice));
        }
    }

    @Test
    public void adhereOrderRateLimitOnOneSecBoundary() {
        long orderRateLimit = 1_000_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(100_000).setMinimumRisk(1_500_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(100_000).setMinimumRisk(1_500_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, Level.QTY_2M.getQty(), 0.75002, Level.QTY_2M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, EURUSD, 1.0500, Level.QTY_2M.getQty(), 1.05004, Level.QTY_1M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, EURUSD, 1.0500, 1.05004, now()));
        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        and:
        // t+3 after order rate timeout.
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_000_000d));
        }
        when:
        // t+5.5 AUD/USD filled but unable to place out another order due to limits. However, allowed to place out EURUSD @ t+8.5
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2) + TimeUnit.MILLISECONDS.toMillis(500));

            prophet.receive(tdd.client_trade_001(EURUSD, 3_000_000, 1.05000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }

        when:
        // t+6 hedger now able to send AUDUSD hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_000_000d));
        }
        and:
        // after EURUSD order rate timeout.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        // EURUSD is allowed to be sent out @ t+9(due to 1 sec tick)
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD));
        }
    }

    @Test
    // scenario no longer relevant after AXPROPHET-632 as twap only gets activated at 1 second granularity
    public void adhereOrderRateLimitOffOneSecBoundary() {
        long orderRateLimit = 1_000_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(100_000).setMinimumRisk(1_500_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(100_000).setMinimumRisk(1_500_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, Level.QTY_2M.getQty(), 0.75002, Level.QTY_2M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, EURUSD, 1.0500, 1.05004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, EURUSD, 1.0500, 1.05004, now()));
        }
        when:
        // t+0.5 hedger places out SELL 2mio order
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        then:
        // t+4
        {
            prophet.incrementTime(orderRateTimePeriod);
            prophet.notExpect(NewOrder.class);
            prophet.incrementTime(500); // because client order was sent at 500ms. twap only gets activated at 1 second granularity

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_000_000d));
        }
        when:
        // t+6.5 AUD/USD filled but unable to place out another order due to limits.
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2) + TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+7 hedger now able to send SELL 2mio hedge order - 3 seconds after when last new order was sent at t4.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_000_000d));
        }
    }

    @Test
    public void adhereOrderRateLimitAscendingTiers() {
        long orderRateLimitTier1 = 1_250_000;
        long orderRateLimitTier2 = 2_000_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(100_000)
                                    .setMinimumRisk(190_000)
                                    .setOrderRateLimit(orderRateLimitTier1)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriod)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_000_000)
                                    .setOrderRateLimit(orderRateLimitTier2)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriod)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, Level.QTY_2M.getQty(), 0.75002, Level.QTY_1M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 hedger places out SELL order with OrderRate Limit Amount
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(1500000.0));
        }
        and:
        // t+3 after order rate time period
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TWAP;posNotional=1000000;epNotional=1500000;tier=0;availQtyInWindow=1250000;windowMS=3000"));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_250_000d));
        }
        when:
        // Order filled @t+4.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // Unable to place out order until t+7
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(-375_000d));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+7, hedger allowed to place order for remaining pos.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
        }
        then:
        {
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TWAP;posNotional=-250000;epNotional=-375000;tier=0;availQtyInWindow=1250000;windowMS=3000"));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(375_000d));
        }
        when:
        // t+7.5 Receive Client deal to increase grad pos
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        then:
        {
            // based on grad pos, meets Tier 2 min risk. Unable to hedge until t+7.5 + 3 = t(10.5)
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional() > 3_000_000d, is(true));
        }
        when:
        // t+8.5 375_000 order filled which will reduce next Order Rate Limit.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1000));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // t+11 Tier 2 Order Rate window expires(which started @t7.5
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2500);
        }
        and:
        {
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TWAP;posNotional=3125000;epNotional=4687500;tier=1;availQtyInWindow=1625000;windowMS=3000"));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(orderRateLimitTier2 - 375_000d));
        }
    }

    @Test
    public void adhereOrderRateLimitAscendingTiers2() {
        long orderRateLimitTier1 = 1_250_000;
        long orderRateLimitTier2 = 1_000_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(100_000)
                                    .setMinimumRisk(190_000)
                                    .setOrderRateLimit(orderRateLimitTier1)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriod)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_000_000)
                                    .setOrderRateLimit(orderRateLimitTier2)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriod)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, Level.QTY_2M.getQty(), 0.75002, Level.QTY_1M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 hedger places out SELL order with OrderRate Limit Amount
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(1500000.0));
        }
        and:
        // t+3 after order rate time period
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TWAP;posNotional=1000000;epNotional=1500000;tier=0;availQtyInWindow=1250000;windowMS=3000"));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_250_000d));
        }
        when:
        // Order filled @t+4.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // Unable to place out order until t+7
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(-375_000d));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+7, hedger allowed to place order for remaining pos.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
        }
        then:
        {
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TWAP;posNotional=-250000;epNotional=-375000;tier=0;availQtyInWindow=1250000;windowMS=3000"));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(375_000d));
        }
        when:
        // t+7.5 375_000 order filled which will reduce next Order Rate Limit.
        // Receive Client deal to increase grad pos
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);

            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            // based on grad pos, use Tier 2 config. Unabled to hedge until t+7.5 + order rate window
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional() > 3_000_000d, is(true));
        }
        and:
        // t+11 after order rate timeout.
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3500);
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TWAP;posNotional=2125000;epNotional=3187500;tier=1;availQtyInWindow=1000000;windowMS=3000"));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is((double)orderRateLimitTier2));
        }
    }

    @Test
    public void adhereOrderRateLimitDescendingTiers() {
        long orderRateLimitTier1 = 1_250_000;
        long orderRateLimitTier2 = 2_000_000;
        long orderRateTimePeriodTier1 = 2_000;
        long orderRateTimePeriodTier2 = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(100_000)
                                    .setMinimumRisk(190_000)
                                    .setOrderRateLimit(orderRateLimitTier1)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriodTier1),
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_000_000)
                                    .setOrderRateLimit(orderRateLimitTier2)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriodTier2)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 hedger places out SELL order with OrderRate Limit Amount
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(4_500_000d));
        }
        and:
        // t+3 after order rate time period
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriodTier2);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(2_000_000d));
        }
        when:
        // Order filled @t+4.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // Unable to place out order until orderRateTimePeriodTier1 i.e t+6
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), is(1_500_000d));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+6, hedger allowed to place order for orderRateLimitTier1 amt
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriodTier1);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_250_000d));
        }
    }

    @Test
    public void adhereOrderRateLimitPartialFill() {
        long orderRateLimit = 1_500_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(100_000).setMinimumRisk(1_250_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, Level.QTY_2M.getQty(), 0.75002, Level.QTY_2M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        and:
        // t+3 after order rate timeout.
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(1_500_000d));
        }
        when:
        // t+3 order 1 partial filled for 1mio
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_000_000, 0.75000);
        }
        and:
        // at t+3 still 500k left in orderRateLimit so place order immediately
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(500_000d));
        }
        when:
        // t+5 client deal arrives. But cannot hedge as AUD/USD order still open
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+6 hedging order acked and filled. 1mio done at t+3 slides out so able to hedge
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receiveHedgeOrderFullFill(newOrder);

        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(1_000_000d));
        }
    }

    @Test
    public void adhereMinimumQtyPartialFill() {
        long orderRateLimit = 2_000_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(1_100_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 receive client trade
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        and:
        // t+3 hedger places order
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(2_000_000d));
        }
        when:
        // t+4 order 1 partial filled for 1.25mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_250_000, 0.75000);
        }
        then:
        // in terms of limits, allowed another 750_000, however this is below Min Qty.
        // So unable to hedge at t+5 since trigger is on one sec interval
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+5 no hedging order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+7 after order rate period, hedger allowed to place out order(op pos qty)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(1_125_000d));
        }
    }

    @Test
    public void adhereOrderRateLimitIgnoreRejects() {
        long orderRateLimit = 4_000_000;
        long orderRateTimePeriod = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(100_000).setMinimumRisk(1_000_000).setOrderRateLimit(orderRateLimit).setOrderRateTimePeriodMS(orderRateTimePeriod)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, Level.QTY_2M.getQty(), 0.75002, Level.QTY_2M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 hedger decides to place out SELL order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        and:
        // t+3 orderRateTimePeriod is up place order
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_500_000d));
        }
        when:
        // t+5 hedger places out BUY order
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.client_trade_001(AUDUSD, -750_000, 0.75000));
        }
        and:
        // t+8 orderRateTimePeriod is up place order
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriod);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(1_875_000d));
        }
        when:
        // t+8.5 2nd Order is rejected
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        // t+9, continue to hedge as rejected orders not counted in limits - needs to be at second interval for trigger to hedge
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(1_875_000d));
        }
        when:
        // t+9.4 3rd order is rejected
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        // t+10 continue to hedge as rejected orders not counted in limits - needs to be at second interval for trigger to hedge
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(600));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(1_875_000d));
        }
    }

    @Test
    public void doNotImmediatelySendOrderWhenHedgerManuallyTurnedOn() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(1_500_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_100_000, 0.750000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            // give new price to cause hedger to make a decision
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74990, 0.75000, now()));
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void oneOpenOrderPerInstrument() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, AUDUSD).setMaximumSpread(0.0002).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(1_000_000).setMinimumRisk(1_500_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, USDCAD).setMaximumSpread(0.0003).setTradingTimeZone(TradingTimeZone.LDN).setMinimumQuantity(2_000_000).setMinimumRisk(1_500_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.30100, QTY_2M.getQty(), 1.30110, QTY_1M.getQty(), now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.30095, 1.30111, now()));

            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_100_000, 0.750000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
        when:
        // t+2
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_100_000, 0.750000));
        }
        and:
        // t+3 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD)), 1_000);
        }
        when:
        // t+4
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDCAD, 5_500_000, 1.30110));
        }
        and:
        // t+5 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD)), 1_000);
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD));
        }
    }

    @Test
    public void canEmitMultipleHedgingOrdersMultiCcy() {
        double minRisk = 1_500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, GBPUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(minRisk).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, EURGBP).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0003).setMinimumQuantity(1_000_000).setMinimumRisk(minRisk).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(GBPUSD, -800_000, 1.25000));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(GBPUSD, AGR_AXL_TWAP));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(GBPUSD, AGR_AXL_TWAP)), 1_000);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 12_00_000, 0.85000));
        }
        then:
        // gradient position meets min risk for both instruments
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition eurGBPOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURGBP).findFirst().get();
            assertThat(Math.abs(eurGBPOp.getGradientPositionInNotional()) >= minRisk, is(true));

            final OptimalPosition gbpUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == GBPUSD).findFirst().get();
            assertThat(Math.abs(gbpUSDOp.getGradientPositionInNotional()) >= minRisk &&
                    gbpUSDOp.getGradientPositionInNotional() < 0, is(true));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        and:
        // hedger places orders for both currencies
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
            assertThat(newOrder2.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    public void manuallyTurnAggressiveHedgerOff() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(1_500_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_100_000, 0.750000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.disableHedger(HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_AGGRESSIVE, HedgePortfolioState.PENDING_DISABLED));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_AGGRESSIVE, HedgePortfolioState.DISABLED));
        }
    }

    @Test
    public void shouldEmitHedgingOrderCrossPairSanity() {
        double minRisk = 1_500_001;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setAggressiveTwapHedgerConfigs(Arrays.asList(
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.EURSEK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.002).setMinimumQuantity(1_000_000).setMinimumRisk(minRisk).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.EURSEK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.003).setMinimumQuantity(2_000_000).setMinimumRisk(15_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000),
                    new AggressiveTwapHedgerConfigImpl(AXL, Instrument.EURSEK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.004).setMinimumQuantity(5_000_000).setMinimumRisk(30_000_000).setOrderRateLimit(5_000_000).setOrderRateTimePeriodMS(1_000)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, Instrument.EURSEK, 9.550, 0.002));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.EURSEK, 9.550, 0.002));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.EURUSD, 1.05555));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.EURSEK, -1_000_000, 9.550));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == Instrument.EURSEK).findFirst().get();
            assertThat(op.getGradientPositionInNotional(), isRoundedTo(-1500000.0));

            prophet.notExpect(NewOrder.class, isOrderInstrument(Instrument.EURSEK));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.EURSEK, -1, 9.550));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == Instrument.EURSEK).findFirst().get();
            assertThat(abs(op.getGradientPositionInNotional()) > minRisk, is(true));
        }
        and:
        {
            final double expectedOrderQuantity = 1_000_000.;
            final double expectedOrderPrice = 9.549 + 0.002;

            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(Instrument.EURSEK, AGR_AXL_TWAP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.BUYING));
            assertThat(hedgeDecision.get(1).getQuantity(), is(expectedOrderQuantity));
            assertThat(hedgeDecision.get(1).getPrice(), isRoundedTo(expectedOrderPrice));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getInstrument(), is(Instrument.EURSEK));
            assertThat(newOrder.getQuantity(), is(expectedOrderQuantity));
            assertThat(newOrder.getPrice(), isRoundedTo(expectedOrderPrice));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(Instrument.EURSEK, AGR_AXL_TWAP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
    }

    @Test
    // remove Decision To Hedge At End Of Time Window
    public void minRiskNotMetEndOfTimeWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_500_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(2_000)
                                    .setMinimumVolatility(1.0)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A)
                    ))
                    .setRealisedVolatilityConfigs(Arrays.asList(
                            new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75101, 0.00003));

            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // both minRisk and minVol met
        {
            prophet.notExpect(NewOrder.class);
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(3)).getLast();
            assertThat(realisedVolatility.volatility(), f(vol -> (vol > 1.0)));
        }
        when:
        // t+1 receive opposite client trade to reduce grad pos to 0
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // t+1 after orderRateTimePeriod do not hedge since minRisk not met
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_1001})
    // remove Decision To Hedge At End Of Time Window
    public void minVolNotMetEndOfTimeWindow() {
        double minVol = 0.1;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(500_000)
                                    .setMinimumRisk(500_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(2_000)
                                    .setMinimumVolatility(minVol)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A)
                    ))
                    .setRealisedVolatilityConfigs(Arrays.asList(
                            new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75105, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75110, 0.00003));

            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // both minRisk and minVol met
        {
            prophet.notExpect(NewOrder.class);
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(3)).getLast();
            assertThat(realisedVolatility.volatility(), f(vol -> (vol > minVol)));
        }
        when:
        // t+1 receive marketdata update
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75109, 0.00003));
        }
        then:
        // vol is now below minVol
        {
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(realisedVolatility.volatility(), f(vol -> (vol < minVol)));
        }
        and:
        // after orderRateTimePeriod do not hedge since minVol not met
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_000);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_1001})
    public void minVolMetOnReceiptOfClientTrade() {
        double minVol = 6.33;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(500_000)
                                    .setMinimumRisk(100_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(1_000)
                                    .setMinimumVolatility(1.0)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A),
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(500_000)
                                    .setMinimumRisk(500_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(2_000)
                                    .setMinimumVolatility(1.0)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A),
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(500_000)
                                    .setMinimumRisk(500_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(3_000)
                                    .setMinimumVolatility(minVol)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A)
                    ))
                    .setRealisedVolatilityConfigs(Arrays.asList(
                            new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75105, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75110, 0.00003));

            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // setOrderRateTimePeriodMS(3_000) tier both minRisk and minVol met
        {
            prophet.notExpect(NewOrder.class);
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(3)).getLast();
            assertThat(realisedVolatility.volatility(), f(vol -> (vol > minVol)));
        }
        and:
        // after orderRateTimePeriod hedge since minRisk and minVol met
        {
            prophet.incrementTime(() -> prophet.expect(NewOrder.class), 4_000);
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("tier=2"));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_1001})
    public void minVolMetOnMarketDataUpdate() {
        double minVol = 0.32;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(500_000)
                                    .setMinimumRisk(500_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(2_000)
                                    .setMinimumVolatility(minVol)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A),
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(500_000)
                                    .setMinimumRisk(500_000)
                                    .setOrderRateLimit(1_000_000)
                                    .setOrderRateTimePeriodMS(1_000)
                                    .setMinimumVolatility(100)
                                    .setVolatilityFactorWindow(FactorWindow.CAT_A)
                    ))
                    .setRealisedVolatilityConfigs(Arrays.asList(
                            new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75000, 0.00004));
            prophet.incrementTime(5);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75005, 0.00004));

            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // minRisk met but minVol NOT met
        {
            prophet.notExpect(NewOrder.class);
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(2)).getLast();
            assertThat(realisedVolatility.volatility(), f(vol -> (vol < minVol)));
        }
        when:
        // @t+1.505 sec
        // .setOrderRateTimePeriodMS(2_000) tier minRisk met AND minVol met
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.75020, 0.00004));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(realisedVolatility.volatility(), f(vol -> (vol > minVol)));
        }
        and:
        // after orderRateTimePeriod place order
        {
            prophet.incrementTime(() -> prophet.expect(NewOrder.class), 2_500);
        }
    }

    @Test
    public void twapAmtGreaterThanTakeProfit() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(2_000)
                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_00)
                                    .setMinimumRisk(4_000_000)
                                    .setOrderRateLimit(3_000_001)
                                    .setOrderRateTimePeriodMS(1_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 3000000, 0.75002, 3000001));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 3000000, 0.75004, 3000000));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        // Even though TWAP has greater hedge amount, TWAP can only hedge at the end of its time window. However TP can hedge immediately
        {
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TP, HedgeTriggerState.BUYING)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(3000000d));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // t+1 after TWAP orderRateTimePeriod
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // TWAP can't place out because TP has placed out order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUY_REQ));
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUYING));
        }
        when:
        // t+1 TP partial filled
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1, 0.75000);
        }
        then:
        // TWAP is able to place out now and has greater hedge amount over TP
        {
            HedgeDecision twapHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUYING)).getLast();
            assertThat(twapHedgeDecision.getQuantity(), is(3000001d));

            prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_TP));
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TP, HedgeTriggerState.BUY_REQ)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(2999999d));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedInBetweenOrderRateWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                        new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                .setMaximumSpread(0.0001)
                                .setMinimumQuantity(100_000)
                                .setMinimumRisk(1_000_000)
                                .setOrderRateLimit(1_500_000)
                                .setOrderRateTimePeriodMS(3_000)
                    ))
                    // Pause period set to 5 seconds
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_HEDGING_PERIOD_SEC, 5))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.75004, now()));
        }
        when:
        // t+0 hedger to place out SELL 2mio order at end of OrderRateTimePeriod
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1
        {
            prophet.incrementTime(1_000);
            // set Active Pause
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        and:
        // t+3 after order rate time period, since PAUSE is active, do NOT hedge
        {
            prophet.incrementTime(2_000);
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+6 PAUSE period inactive.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(3_000);
        }
        then:
        {
            prophet.expect(HedgeCurrencyControl.class, isHedgingCcyUnpaused(Currency.AUD));
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeInitialTrigger() {
        long orderRateTimePeriodMS = 3_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumQuantity(100_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(1_500_000)
                                    .setOrderRateTimePeriodMS(orderRateTimePeriodMS)
                    ))
                    // Pause period set to 5 seconds
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_HEDGING_PERIOD_SEC, 5))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.75004, now()));

            // Pause enabled
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        when:
        // t+0 Since TWAP is already in SLEEPING state, do NOT start OrderRateTimePeriod i.e TWAP does not place order at t+3
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // t+3 after order rate time period, do not hedge
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriodMS);
        }
        when:
        // t+5 PAUSE period inactive.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(2_000);
        }
        then:
        {
            prophet.expect(HedgeCurrencyControl.class, isHedgingCcyUnpaused(Currency.AUD));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // TWAP hedgers at end of OrderRateTimePeriod i.e t+8
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), orderRateTimePeriodMS);
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }
}
