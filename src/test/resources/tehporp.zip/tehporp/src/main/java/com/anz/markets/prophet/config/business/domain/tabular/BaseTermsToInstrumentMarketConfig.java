package com.anz.markets.prophet.config.business.domain.tabular;

import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

public interface BaseTermsToInstrumentMarketConfig extends ProphetMarshallable {

    BaseTermsToInstrumentMarketConfig EMPTY = new BaseTermsToInstrumentMarketConfigImpl();

    Market getMarket();

    Instrument getInstrument();

    Currency getBaseCurrency();

    Currency getTermsCurrency();
}
