package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.Wires;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.sessioncode.messages.Logon;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import static software.chronicle.generated.code.messages.NewOrderSingle.newNewOrderSingle;

/**
 * @author Rob Austin.
 */
public class ClientMessageNotifierExample11 implements MessageNotifier, Marshallable {

    @NotNull
    private static NewOrderSingle newOrderSingle(FixSessionContext context) {
        final NewOrderSingle serverExpects = newNewOrderSingle(Wires.acquireBytes(), context);
        serverExpects.ordType('2');
        serverExpects.side('1');
        serverExpects.symbol(Bytes.from("LCOM1"));
        serverExpects.clOrdID(Bytes.elasticByteBuffer(10).append("clordid").append(1));
        serverExpects.handlInst('3');
        serverExpects.transactTime(1451902315496L);
        serverExpects.orderQty(1);
        serverExpects.price(200.0);
        serverExpects.timeInForce('0');
        serverExpects.maturityMonthYear("201106");
        serverExpects.securityType("FUT");
        serverExpects.idSource("5");
        serverExpects.securityID(Bytes.from("LCOM1"));
        serverExpects.account(Bytes.from("ABCTEST1"));
        return serverExpects;
    }

    @Override
    public void onLogon(FixSessionHandler session, Logon logon) {
        session.sendMessage(newOrderSingle(session.context()));
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }

}
