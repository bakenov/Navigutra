package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Properties;
import java.util.function.Consumer;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import net.openhft.chronicle.core.time.SystemTimeProvider;
import net.openhft.chronicle.core.time.TimeProvider;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.SessionMessageProvider;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.CheckLatencyProbes;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.FixEngine;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.PerformanceProbes;
import com.anz.axle.lg.adapter.chroniclefix.tools.FixLogConsumer;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    private final String compId;
    private final String senderCompId;
    private final Venue venue;

    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId,
                     @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public SessionID tradingSessionId(@Value("${hsp.fix.trading.sendercompid}") final String tradingSenderCompId, @Value("${hsp.fix.trading.targetcompid}") final String tradingTargetCompId) {
        return new SessionID(tradingSenderCompId, tradingTargetCompId);
    }

    @Bean
    public SessionState tradingSessionState() {
        return new SessionState("TradingSession");
    }

    @Bean
    public Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState tradingSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(tradingSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> snapshotFullRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState tradingSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(tradingSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public FixEngineCfg fixEngineCfg(final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/hsp-chroniclefix.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final FixEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

    @Bean
    public Consumer<FixLog> tradingFixLogConsumer(@Value("${hsp.fix.trading.log_all}") final boolean enableLogging,
                                                  @Value("${hsp.fix.file.log.path}") final String logPath,
                                                  @Value("${hsp.fix.trading.logging.base_path}") final String bashPath,
                                                  @Value("${hsp.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public SessionMessageProvider tradingSessionMessageProvider(final FixEngineCfg fixEngineCfg,
                                                                @Value("${hsp.fix.trading.username}") final String tradingUserName,
                                                                @Value("${hsp.fix.trading.password}") final String tradingPassword,
                                                                @Value("${appOptions:}") final String appOptions) {
        final FixSessionCfg tradingSessionCfg = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
        return new HspTradingSessionMessageProvider("Trading", tradingUserName, tradingPassword, OptionMatcher.HAS_RESET.test(appOptions), tradingSessionCfg);
    }

    @Bean
    public TimeProvider timeProvider() {
        return SystemTimeProvider.INSTANCE;
    }

    @Bean
    public FixEngine fixTradingEngine(final FixEngineCfg fixEngineCfg,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      final SessionMessageProvider tradingSessionMessageProvider,
                                      final Consumer<FixLog> tradingFixLogConsumer,
                                      final PrecisionClock precisionClock,
                                      final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                      final LongIdFactory tradingMessageIdGenerator,
                                      final EventLoopAdapter fixTradingEventLoopStep,
                                      final MetricRepository<Metric, Venue> metricRepository,
                                      @Value("${hsp.fix.trading.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      @Value("${hsp.fix.trading.allowedLatencyMs}") final int allowedLatencyMs,
                                      @Value("${hsp.fix.trading.session.enable}") final boolean enableTradingSession,
                                      final SourceSequencer sourceSequencer) throws Exception {

        final FixSessionCfg tradingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
        tradingSession.sessionMessageProvider(tradingSessionMessageProvider);

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);
        final ChronicleMessageHandler<ExecutionReport> executionReportHandler = new MonitoredChronicleMessageHandler<>(
                new HspExecutionReportHandler(tradingResponseEncoderSupplier, precisionClock, senderCompId, compId, venue, tradingMessageIdGenerator::get, sourceSequencer),
                metricRecorder);
        final FixTradingApplication fixTradingApplication = new FixTradingApplication(executionReportHandler, applicationLogonHandler);
        tradingSession.messageNotifier(fixTradingApplication);
        tradingSession.probes(new CheckLatencyProbes(new PerformanceProbes(), allowedLatencyMs));
        tradingSession.consumer(tradingFixLogConsumer);

        final ChronicleFixEngine chronicleFixEngine = fixEngineCfg.createInstance(tradingSession.hostId(), fixTradingEventLoopStep);

        return FixEngine.create("HSP-TR-SUBSCRIBER", chronicleFixEngine, waitForLogoutTimeoutInSec, enableTradingSession);
    }
}