package com.anz.markets.efx.fox.codec.api;


import org.junit.Test;

import com.anz.markets.efx.ngaro.api.Venue;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

public class VenueInstrumentConfigEncoderTest {
    @Test
    public void encoderChaining() {
        final VenueInstrumentConfigEncoder encoder = mock(VenueInstrumentConfigEncoder.class, RETURNS_DEEP_STUBS);

        encoder.messageStart(0, 0)
                .venue(Venue.FAST)
                .instrumentId(353453)
                .clipSizeMultiple(1000000)
                .maxAllowedParentOrderQty(5000000)
                .minClipSize(1000000)
                .maxClipSize(5000000)
                .priceIncrement(0.0001)
                .sizeIncrement(0)
                .staleDataTimeout(100)
                .priority(10)
                .proportion(10)
                .enabled(true)
                .messageComplete();
    }
}