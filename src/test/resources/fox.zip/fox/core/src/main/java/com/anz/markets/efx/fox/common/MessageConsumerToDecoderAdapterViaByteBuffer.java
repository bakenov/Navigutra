package com.anz.markets.efx.fox.common;

import java.nio.ByteBuffer;
import java.util.Objects;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;
import org.tools4j.eventsourcing.api.MessageConsumer;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;

public class MessageConsumerToDecoderAdapterViaByteBuffer implements MessageConsumer {
    private final MessageDecoder<SbeMessage> decoder;
    private final MutableDirectBuffer zeroOffsetBuffer;
    private final MutableSbeMessage sbeMessage;

    public MessageConsumerToDecoderAdapterViaByteBuffer(final MessageDecoder<SbeMessage> decoder, final int bufferSize) {
        this.decoder = Objects.requireNonNull(decoder);
        this.zeroOffsetBuffer = new UnsafeBuffer(ByteBuffer.allocateDirect(bufferSize));
        this.sbeMessage = new SbeMessageForWriting(zeroOffsetBuffer);
    }

    @Override
    public void accept(final DirectBuffer directBuffer, final int offset, final int length) {
        zeroOffsetBuffer.putBytes(0, directBuffer, offset, length);
        sbeMessage.messageLength(length);
        decoder.decode(sbeMessage);
    }
}
