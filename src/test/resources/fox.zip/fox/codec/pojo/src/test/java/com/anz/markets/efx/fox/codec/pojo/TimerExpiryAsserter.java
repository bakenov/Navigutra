package com.anz.markets.efx.fox.codec.pojo;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TimerExpiryAsserter {
    private final TimerExpiry message;

    public TimerExpiryAsserter(final TimerExpiry message) {
        this.message = Objects.requireNonNull(message);
    }

    public static TimerExpiryAsserter expect(final TimerExpiry message) {
        return new TimerExpiryAsserter(message);
    }

    public static TimerExpiryAsserter expect(final MessageHeader header, final TimerExpiry.Body body) {
        return new TimerExpiryAsserter(SorMessage.timerExpiry(header, body));
    }

    public TimerExpiry message() {
        return message;
    }

    public TimerExpiry.Body body() {
        return message.body;
    }

    public TimerExpiryHandler assertingTimerExpiryHandler() {
        return new TimerExpiryHandler() {

            @Override
            public void onMessageStart(final int source, final long sourceSeq) {
                HeaderAsserter.assertHeader(header(), source, sourceSeq);
            }

            @Override
            public void onBody(final Body body) {
                assertEquals("triggeredTime not as expected", TimerExpiryAsserter.this.body().triggeredTime, body.triggeredTime());
                assertEquals("timerId not as expected", TimerExpiryAsserter.this.body().timerId, body.timerId());
                assertEquals("timerGroup not as expected", TimerExpiryAsserter.this.body().timerGroup, body.timerGroup());
            }
        };
    }

    public MessageHeader header() {
        return message.header;
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a TimerExpiry", sorMessage instanceof TimerExpiry);
        assertTimerExpiry((TimerExpiry) sorMessage);
    }

    public void assertTimerExpiry(final TimerExpiry timerExpiry) {
        assertBody(timerExpiry.body);
    }

    public void assertBody(final TimerExpiry.Body body) {
        assertEquals("triggeredTime not as expected", body().triggeredTime, body.triggeredTime);
        assertEquals("timerId not as expected", body().timerId, body.timerId);
        assertEquals("timerGroup not as expected", body().timerGroup, body.timerGroup);
    }
}
