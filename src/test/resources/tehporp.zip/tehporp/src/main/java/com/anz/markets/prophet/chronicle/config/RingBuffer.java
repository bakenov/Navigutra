package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.util.SystemProperties;

public enum RingBuffer {
    /**
     * No RB
     */
    NO_RING,
    /**
     * Used to write asynchronously via RB to a queue. Readers read from underlying
     */
    ASYNC,
    /**
     * As ASYNC but reader also reads from RB
     */
    RING;

    public boolean enabled() {
        return SystemProperties.CQ_RING_BUFFER_ENABLED && this == RING;
    }

    public boolean async() {
        return SystemProperties.CQ_RING_BUFFER_ENABLED && this == ASYNC;
    }
}
