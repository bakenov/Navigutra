package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.efx.ngaro.collections.EnumBooleanTable;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.config.business.domain.tabular.MITRConfigs;
import com.anz.markets.prophet.config.business.domain.tabular.MITRFeaturesConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MarketType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;

import java.util.EnumMap;

public class AggregatedBookConfig {

    public static final String FEATURE_NAME = "PFP_AGG_BOOK".intern();
    public static final String PARAM_CONSTITUENTS = "constituentMarkets".intern();

    private final EnumObjTable<Market, TradingTimeZone, AggBookTimezoneConfig> constituentsMaps = new EnumObjTable(Market.class, TradingTimeZone.class);

    private class AggBookTimezoneConfig {
        EnumBooleanTable<Instrument, Market> constituentMatrix = new EnumBooleanTable<>(Instrument.class, Market.class);
        EnumMap<Instrument, Markets> constituents = new EnumMap<>(Instrument.class);
    }

    public AggregatedBookConfig(final MITRConfigs priceFormationPipelineConfigs) {
        for (Market aggbookMarket : Market.VALUES) {
            if (aggbookMarket.getMarketType() == MarketType.INTERNAL_AGG) {
                for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                    AggBookTimezoneConfig aggBookTimezoneConfig = new AggBookTimezoneConfig();
                    constituentsMaps.put(aggbookMarket, ttz, aggBookTimezoneConfig);
                    for (Instrument instrument : Instrument.VALUES) {
                        Markets cons = Markets.getMarkets();
                        if (priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
                            final MITRFeaturesConfig c = priceFormationPipelineConfigs.getConfig(aggbookMarket, instrument, ttz);
                            cons = c.getMarketsParam(FEATURE_NAME, PARAM_CONSTITUENTS);
                        }
                        aggBookTimezoneConfig.constituents.put(instrument, cons);
                        for (Market market : cons.get()) {
                            aggBookTimezoneConfig.constituentMatrix.put(instrument, market, true);
                        }
                    }
                }
            }
        }
    }

    public EnumBooleanTable<Instrument, Market> getConstituentMatrix(final Market aggBook, final TradingTimeZone ttz) {
        GcFriendlyAssert.isFalse(ttz == TradingTimeZone.GLOBAL, "GLOBAL is not a valid trading timezone.");
        AggBookTimezoneConfig c = constituentsMaps.get(aggBook, ttz);
        GcFriendlyAssert.notNull(c, "%s is not a valid agg book market.", aggBook);
        return c.constituentMatrix;
    }

    public Markets getConstituents(final Market aggBook, final TradingTimeZone ttz, Instrument instrument) {
        GcFriendlyAssert.isFalse(ttz == TradingTimeZone.GLOBAL, "GLOBAL is not a valid trading timezone.");
        AggBookTimezoneConfig c = constituentsMaps.get(aggBook, ttz);
        GcFriendlyAssert.notNull(c, "%s is not a valid agg book market.", aggBook);
        return c.constituents.get(instrument);
    }

}
