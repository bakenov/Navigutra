package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.matcher.ValueMatcher;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface InitialisationMatcher extends Predicate<Object> {

    Matcher<InitialisationMatcher, Initialisation.Body> body();

    static InitialisationMatcher build() {
        return new InitialisationMatcher() {
            private Predicate<Initialisation> predicate = Matchers.isA(Initialisation.class);

            @Override
            public Matcher<InitialisationMatcher, Initialisation.Body> body() {
                return matcher -> andThen(translate(initialisation -> initialisation.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof Initialisation && predicate.test((Initialisation) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private InitialisationMatcher matcher() {
                return this;
            }

            private InitialisationMatcher andThen(final Predicate<? super Initialisation> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ValueMatcher<Initialisation.Body, InitStage> initStage() {
        return ValueMatcher.create("initStage", b -> b.initStage);
    }
}
