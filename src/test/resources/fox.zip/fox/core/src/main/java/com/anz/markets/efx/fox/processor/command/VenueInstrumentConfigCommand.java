package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.Venue;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.VenueInstrumentConfigSbeDecoder;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class VenueInstrumentConfigCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueInstrumentConfigCommand.class);

    private final CommandContext commandContext;
    private final VenueInstrumentConfigSbeDecoder venueInstrumentConfigDecoder = new VenueInstrumentConfigSbeDecoder();
    private final InstrumentKey.Lookup instrumentKeyLookup = new DefaultInstrumentKeyLookup();


    private final StringBuilder stringBuilder = new StringBuilder();

    public VenueInstrumentConfigCommand(final CommandContext commandContext) {
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!venueInstrumentConfigDecoder.wrap(message)) return false;
        appendVenueInstrumentConfig();

        final VenueInstrumentConfigDecoder.Body body = venueInstrumentConfigDecoder.body();

        final Instrument instrument = commandContext.instrumentRepository().lookup(body.instrumentId());
        if (instrument == null) {
            LOGGER.warn("Cannot apply VenueInstrumentConfig due to missing Instrument. {}, {}", stringBuilder, instrumentKeyLookup.lookup(body.instrumentId()));
            return true;
        }

        final Venue venue = commandContext.venueRepository().lookup(body.venue());
        if (venue == null) {
            LOGGER.warn("Cannot apply VenueInstrumentConfig due to missing Venue. {}", stringBuilder);
            return true;
        }

        LOGGER.info("Create or Update Venue Instrument Command: {}", stringBuilder);

        commandContext.eventApplier().decode(message);
        return true;
    }

    private void appendVenueInstrumentConfig() {
        stringBuilder.setLength(0);
        venueInstrumentConfigDecoder.appendTo(stringBuilder);
    }
}
