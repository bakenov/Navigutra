package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.general.KeyValueConfig;
import com.anz.markets.prophet.domain.CovarianceCategory;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This is a type safe key value config map.
 * <p>
 * The key must exists in KeyValueConfigType which details the actual key name in string and its type.
 * <p>
 * This KeyValueConfigMap is intialised by passing raw map of key/value string.
 */
public class TypeSafeKeyValueConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(TypeSafeKeyValueConfig.class);

    private Map<KeyValueConfigType, Object> map = new HashMap<>();

    public TypeSafeKeyValueConfig(final KeyValueConfig... keyValueConfigs) {
        this(Lists.newArrayList(keyValueConfigs));
    }

    TypeSafeKeyValueConfig(final List<KeyValueConfig> keyValueConfigs) {

        // check that each key is defined in KeyValueConfigType.
        keyValueConfigs.forEach(keyValueConfig ->
        {
            GcFriendlyAssert.notNull(keyValueConfig, "keyValueConfig must not be null.");
            GcFriendlyAssert.notNull(keyValueConfig.getKeyName(), "Config key must not be null: %s. Please check configuration.", keyValueConfig);
            GcFriendlyAssert.notNull(keyValueConfig.getValueName(), "Config for key %s must not be null. Please check configuration.", keyValueConfig.getKeyName());

            final KeyValueConfigType keyValueConfigType = KeyValueConfigType.getByKeyName(keyValueConfig.getKeyName());
            if (keyValueConfigType != null) {
                if (keyValueConfigType.getType() == boolean.class) {
                    map.put(keyValueConfigType, Boolean.valueOf(keyValueConfig.getValueName()));
                } else if (keyValueConfigType.getType() == double.class) {
                    map.put(keyValueConfigType, Double.valueOf(keyValueConfig.getValueName()));
                } else if (keyValueConfigType.getType() == long.class) {
                    map.put(keyValueConfigType, Long.valueOf(keyValueConfig.getValueName()));
                } else if (keyValueConfigType.getType() == int.class) {
                    map.put(keyValueConfigType, Integer.valueOf(keyValueConfig.getValueName()));
                } else if (keyValueConfigType.getType() == String.class) {
                    map.put(keyValueConfigType, String.valueOf(keyValueConfig.getValueName()));
                } else if (keyValueConfigType.getType() == Instrument[].class) {
                    map.put(keyValueConfigType, parseEnumList(keyValueConfig.getValueName(), Instrument.class));
                } else if (keyValueConfigType.getType() == Currency[].class) {
                    map.put(keyValueConfigType, parseEnumList(keyValueConfig.getValueName(), Currency.class));
                } else if (keyValueConfigType.getType() == Market[].class) {
                    map.put(keyValueConfigType, parseEnumList(keyValueConfig.getValueName(), Market.class));
                } else if (keyValueConfigType.getType() == Region.class) {
                    map.put(keyValueConfigType, parseEnum(keyValueConfig.getValueName(), Region.class));
                } else if (keyValueConfigType.getType() == Market.class) {
                    map.put(keyValueConfigType, parseEnum(keyValueConfig.getValueName(), Market.class));
                } else if (keyValueConfigType.getType() == CovarianceCategory.class) {
                    map.put(keyValueConfigType, parseEnum(keyValueConfig.getValueName(), CovarianceCategory.class));
                } else if (keyValueConfigType.getType() == Portfolio[].class) {
                    map.put(keyValueConfigType, parseEnumList(keyValueConfig.getValueName(), Portfolio.class));
                } else if (keyValueConfigType.getType() == PositionType[].class) {
                    map.put(keyValueConfigType, parseEnumList(keyValueConfig.getValueName(), PositionType.class));
                } else {
                    throw new IllegalArgumentException("Unsupported type: " + keyValueConfigType + " found while loading " + keyValueConfig);
                }
            } else {
                LOGGER.warn("Config key is not valid {}. This config will be ignored.", keyValueConfig);
            }
        });
    }

    public String getString(KeyValueConfigType key) {
        final Object o = map.get(key);
        GcFriendlyAssert.notNull(o, "Config for key %s must be set. Please check configuration.", key);
        return (String) o;
    }

    public String getString(final KeyValueConfigType key, final String defaultValue) {
        if (map.containsKey(key)) {
            return getString(key);
        }
        return defaultValue;
    }

    public long getLong(final KeyValueConfigType key) {
        final Object o = map.get(key);
        GcFriendlyAssert.notNull(o, "Config for key %s must be set. Please check configuration.", key);
        return (long) o;
    }

    public long getLong(final KeyValueConfigType key, final long defaultValue) {
        if (map.containsKey(key)) {
            return getLong(key);
        }
        return defaultValue;
    }

    public int getInt(final KeyValueConfigType key) {
        final Object value = map.get(key);
        GcFriendlyAssert.notNull(value, "Config for key %s must be set. Please check configuration.", key);
        return (int) value;
    }

    public int getInt(KeyValueConfigType key, final int defaultValue) {
        if (map.containsKey(key)) {
            return getInt(key);
        }
        return defaultValue;
    }

    public boolean getBoolean(final KeyValueConfigType key) {
        final Object o = map.get(key);
        GcFriendlyAssert.notNull(o, "Config for key %s must be set. Please check configuration.", key);
        return (boolean) map.get(key);
    }

    public boolean getBoolean(final KeyValueConfigType key, final boolean defaultValue) {
        if (map.containsKey(key)) {
            return getBoolean(key);
        }
        return defaultValue;
    }

    public double getDouble(final KeyValueConfigType key) {
        final Object o = map.get(key);
        GcFriendlyAssert.notNull(o, "Config for key %s must be set. Please check configuration.", key);
        return (double) o;
    }

    public double getDouble(final KeyValueConfigType key, final double defaultValue) {
        if (map.containsKey(key)) {
            return getDouble(key);
        }
        return defaultValue;
    }

    @SuppressWarnings("unchecked")
    public <T extends Enum> T getEnum(final KeyValueConfigType key, T defaultValue) {
        if (map.containsKey(key)) {
            return getEnum(key);
        }
        return defaultValue;
    }

    @SuppressWarnings("unchecked")
    public <T extends Enum> T getEnum(final KeyValueConfigType key) {
        final Object o = map.get(key);
        GcFriendlyAssert.notNull(o, "Config for key %s must be set. Please check configuration.", key);
        return (T) o;
    }

    @SuppressWarnings("unchecked")
    public <T extends Enum> List<T> getEnumList(final KeyValueConfigType key) {
        final Object o = map.get(key);
        GcFriendlyAssert.notNull(o, "Config for key %s must be set. Please check configuration.", key);
        return (List<T>) o;
    }

    public <T extends Enum> Set<T> getEnumSet(final KeyValueConfigType key) {
        List<T> l = getEnumList(key);
        if (l.size() == 0) {
            return Collections.emptySet();
        } else {
            return EnumSet.copyOf(l);
        }
    }

    public <T extends Enum> List<T> getEnumList(final KeyValueConfigType key, final List<T> defaultList) {
        if (map.containsKey(key)) {
            return getEnumList(key);
        }
        return defaultList;
    }

    public boolean isSet(final KeyValueConfigType keyValueConfigType) {
        return map.containsKey(keyValueConfigType);
    }

    @SuppressWarnings("unchecked")
    private <T extends Enum> List<T> parseEnumList(String s, Class<T> clazz) {

        if (s.trim().length() == 0) {
            return Collections.emptyList();
        }

        final String[] values = s.trim().split("\\s*,\\s*");

        List<T> list = new ArrayList<>(values.length);
        for (String value : values) {
            list.add(parseEnum(value, clazz));
        }
        return list;
    }

    private <T extends Enum> T parseEnum(String value, Class<T> clazz) {
        return (T) Enum.valueOf(clazz, value);
    }

    public Set<KeyValueConfigType> getKeys() {
        return map.keySet();
    }
}
