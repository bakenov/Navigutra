package com.anz.markets.prophet.config.business.domain.tabular.general;

import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

/**
 * Define open and close hours for each [OperatingHourEntity](#com.anz.markets.prophet.domain.OperatingHourEntity).
 * <p>
 * Hours is a comma delimited value of OperatingHourSpecification.
 * <p>
 * OperatingHourSpecification is in the format of "[OPEN|CLOSE] [Mon|Tue|Wed|Thu|Fri|Sat|Sun] [HH:mm] [timeZoneId]"
 * e.g.,
 * <p>
 * OPEN Mon 05:00 Pacific/Auckland,CLOSE Fri 16:55 America/New_York
 * <p>
 * The time is specified in 24 hr format and is local to the timezone and day light saving if it is in play.
 * <p>
 * timeZoneId is the timezone id <b>without</b> daylight saving following are common timezone ids that can be used.
 * <p>
 * America/Chicago
 * America/Los_Angeles
 * America/New_York
 * Asia/Hong_Kong
 * Asia/Shanghai
 * Asia/Singapore
 * Asia/Tokyo
 * Australia/Sydney
 * Europe/Moscow
 * Europe/Paris
 * GMT
 * Pacific/Auckland
 *
 * @see OperatingHourEntity
 */
public interface OperatingHourConfig extends ProphetMarshallable {
    OperatingHourEntity getEntity();

    String getHours();

    @JsonIgnore
    List<OperatingHourSpecification> getHoursAsList();

}
