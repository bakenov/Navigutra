package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import org.hamcrest.CoreMatchers;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Ignore("NOP skew has been removed")
@RestartBeforeTest(reason = "op cached")
public class Optimal_Position_Risk_Skew_and_NOP_Skew_Combined extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument driverCrossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 1.0))  // set high Overall-skew threshold
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0)
                ))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(com.google.common.collect.Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ));

        return configuration;
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_4, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Optimal Risk Skew + NOP Skew < Overall Skew")
    public void optimal_risk_skew_plus_nop_skew_less_than_overall_skew() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(driverCrossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 500_000, 78.420));
        }
        then:
        {
            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3755000.0));

            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(3774729.2418772564));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(550000.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), is(-4739670.3296703305));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Optimal Position Risk skew monitors equiv position
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, atLeast(1),isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition usdJpyOp = optimalPositionsUpdate.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == directPair).findFirst().get();
            assertThat(usdJpyOp.getPositionInSystemBase(), is(-2848046.7483755294));

            // Overall-Skew = (2847865.04 / 4000000) * 1.0 = 0.56957301
            // OP skew = (2848046.7483755294 / 4000000) * 0.5 = 0.35600584
            // NOP skew = 12819400, USD NOP Limit = 20 mio, ratio = 0.64 => skew = 0.1
            // Output Skew = OP skew + NOP skew = 0.45600584 (< Overall-Skew)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.87136802));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(directPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getSkewedMid(), new IsRoundedTo((float)103.87136802));
            assertThat(clientPrice.getUnskewedMid(), new IsRoundedTo(103.870));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // AUD/USD SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Optimal Position Risk skew monitors equiv position
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, atLeast(1),isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition audUsdOp = optimalPositionsUpdate.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(audUsdOp.getPositionInSystemBase(), is(-3966041.450603498));

            // Overall-Skew = (3966041.450603498 / 5000000) * 1.0 = 0.793
            // OP skew = (3966041.450603498 / 5000000) * 0.5 = 0.3966041450603498
            // NOP skew = 12819400, USD NOP Limit = 22_806_762 mio, ratio = 0.56 => skew = 0.1
            // Output Skew = OP skew + NOP skew = 0.4966041450603498 (< Overall-Skew)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.7510649));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(indirectPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getSkewedMid(), new IsRoundedTo(0.7510649));
            assertThat(clientPrice.getUnskewedMid(), new IsRoundedTo(0.75105));

            ClientPrice cpCross = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDJPY, Market.WSP_A)).getFirst();
            assertThat(cpCross.getSkewedMid(), new IsRoundedTo((float)78.01413844));
            assertThat(cpCross.getUnskewedMid(), new IsRoundedTo((float)78.0115635));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverCrossPair, 9.105, 0.003));
        }
        then:
        // EUR/SEK SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Optimal Position Risk skew monitors equiv position
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, atLeast(1),isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition eurSekOp = optimalPositionsUpdate.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == driverCrossPair).findFirst().get();
            assertThat(eurSekOp.getPositionInSystemBase(), is(4737067.545304777));

            // Overall-Skew = (4737067.545304777 / 5000000) * 1.0 = 0.9474135090609554
            // OP skew = (4737067.545304777 / 50000) * 0.5 = 0.4737067545304777
            // NOP skew = 12819400, USD NOP Limit = 20_000_000 mio, ratio = 0.64 => skew = 0.1
            // Output Skew = OP skew + NOP skew = 0.5737067545304777 (< Overall-Skew)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(driverCrossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.1027052));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverCrossPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getSkewedMid(), new IsRoundedTo((float)9.1027052));
            assertThat(clientPrice.getUnskewedMid(), new IsRoundedTo(9.105));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_4, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Optimal Risk Skew + NOP Skew > Overall Skew with Positive Position")
    public void optimal_risk_skew_plus_nop_skew_greater_than_overall_skew_positive_pos() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.setMaxSkewQuantities(Arrays.asList(
                    new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 1_800_000.0),
                    new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 67_000.0),
                    new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                    new MaxSkewQuantities(Market.WSP_A, Currency.USD, 16_660_000.0)
            ));

            prophet.receive(configuration, false);
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(driverCrossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 100_000, 7.420));
        }

        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(3), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(3));
            assertThat(optimalPositionsUpdates.get(2), isOptimalPosition(tdd.optimalPosition(indirectPair, 5000000, 4833475.63185882, 3629940.1995259738, 6988128.305291844, 5248084.357274175, 0.1308821123414711, 0.75100)));
            assertThat(optimalPositionsUpdates.get(2), isOptimalPosition(tdd.optimalPosition(directPair, 3774729.2418772564, 3262553.596761254, 3262553.596761254, 3028745.880134908, 3028745.880134908, 0.03320753363080583, 103.875)));
            assertThat(optimalPositionsUpdates.get(2), isOptimalPosition(tdd.optimalPosition(driverCrossPair, 81538.46153846155, 81538.46153846155, 89692.3076923077, 50269.694423807174, 55296.6638661879, -0.002709960241899705, 9.1)));

            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(3755000.0));

            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(-3774729.2418772564));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY LONG optimal position.  Apply -ve skew to improve OFFER(client BUY)
        {
            // Overall-Skew = (3303784.8396822973 / 16_660_000) * 1.0 = 0.198
            // OP skew = (3303784.8396822973 / 16_660_000) * 0.5 = 0.09915
            // NOP skew = 7529729.2418772564, USD NOP Limit = 20 mio, ratio = 0.376 => skew = 0.1
            // Output Skew = OP skew + NOP skew = 0.1992 (> Overall-Skew). Therefore limit to Overall Skew 0.198
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.86941247));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // AUD/USD LONG optimal position.  Apply -ve skew to improve BID(client sell)
        {
            // Overall-Skew = (3621357.792428965 / 1800000) * 1.0 = min(1.0, 2.01) = 1.0
            // OP skew = (3621357.792428965 / 1800000) * 0.5 = min(0.5, 1.006) = 0.5
            // NOP skew = 7529729.2418772564, USD NOP Limit = 22_806_762 mio, ratio = 0.33 => skew = 0.0
            // Output Skew = OP skew + NOP skew = 1.006 (> Overall-Skew). Therefore limit to Overall Skew 1.0
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75103500));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverCrossPair, 9.105, 0.003));
        }
        then:
        // EUR/SEK LONG optimal position.  Apply -ve skew to improve OFFER(client buy)
        {
            // Overall-Skew = (13039.17178714283 / 67_000) * 1.0 = 0.1946
            // OP skew = (13039.17178714283 / 67_000) * 0.5 = 0.0973
            // NOP skew = 7529729.2418772564, USD NOP Limit = 10_100_000 mio, ratio = 0.746 => skew = 0.1
            // Output Skew = OP skew + NOP skew = 0.1973 (> Overall-Skew). Therefore limit to Overall Skew 0.1946
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(driverCrossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.1026));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_4, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Optimal Risk Skew + NOP Skew > Overall Skew with Negative Position")
    public void optimal_risk_skew_plus_nop_skew_greater_than_overall_skew_negative_pos() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.setMaxSkewQuantities(Arrays.asList(
                    new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 1_800_000.0),
                    new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 67_000.0),
                    new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                    new MaxSkewQuantities(Market.WSP_A, Currency.USD, 16_660_000.0)
            ));

            prophet.receive(configuration);
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(driverCrossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 500_000, 70.420));
        }

        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(2), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(2));
            assertThat(optimalPositionsUpdates.get(1), isOptimalPosition(tdd.optimalPosition(indirectPair, -5000000, -5222573.332864645, -3922152.5729813483, -5572140.542798105, -4184677.547641377, -0.08314626545987287, 0.75100)));
            assertThat(optimalPositionsUpdates.get(1), isOptimalPosition(tdd.optimalPosition(directPair, -3774729.2418772564, -2922465.1577265235, -2922465.1577265235, -2673282.4618267305, -2673282.4618267305, -0.017489030971278047, 103.875)));
            assertThat(optimalPositionsUpdates.get(1), isOptimalPosition(tdd.optimalPosition(driverCrossPair, 3869230.7692307695, 3869230.7692307695, 4256153.846153847, 5803846.153846154, 6384230.76923077, 0.1616285426017626, 9.1)));

            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3755000.0));

            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(3774729.2418772564));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }

        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve OFFER(client BUY)
        {
            // Overall-Skew = (3303784.8396822973 / 16_660_000) * 1.0 = 0.198
            // OP skew = (3303784.8396822973 / 16_660_000) * 0.5 = 0.09915
            // NOP skew = 7529729.2418772564, USD NOP Limit = 20 mio, ratio = 0.376 => skew = 0.1
            // Output Skew = OP skew + NOP skew = 0.1992 (> Overall-Skew). Therefore limit to Overall Skew 0.198
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.870526));

            prophet.clearOutputBuffer();
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void optimal_risk_skew_plus_nop_skew_biased_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(driverCrossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 500_000, 78.420));
            prophet.receive(tdd.biasPosition(Currency.AUD, 3_000_000));
            prophet.receive(tdd.biasPosition(Currency.EUR, 1_500_000));
        }

        then:
        {
            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(4), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3755000.0));

            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(3774729.2418772564));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(550000.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), is(-4739670.3296703305));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(-6_008_000.0));

            assertThat(positionsUpdates.get(3).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(3).getPosition1().getPositionInSystemBase(), is(-1_100_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Optimal Position Risk skew monitors equiv position
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, atLeast(1),isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition usdJpyOp = optimalPositionsUpdate.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == directPair).findFirst().get();
            assertThat(usdJpyOp.getPositionInSystemBase(), is(-1739436.6464580258));

            // Overall-Skew = (1739436.6464580258 / 4000000) * 1.0 = 0.435
            // OP skew = (1739436.6464580258 / 4000000) * 0.5 = 0.217429580807253225
            // NOP skew = 15622399, USD NOP Limit = 20 mio, ratio = 0.78 => skew = 0.2
            // Output Skew = OP skew + NOP skew = 0.417429580807253225 (< Overall-Skew)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.87125229));
        }
    }
}
