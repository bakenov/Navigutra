package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.util.Objects;

import net.openhft.chronicle.bytes.Bytes;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public final class HspNewOrderSingleHandler implements NewOrderSingleHandler {

    private final FixMessageSender fixMessageSender;
    private final String account;
    private final NewOrderSingle newOrderSingle;

    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));

    public HspNewOrderSingleHandler(final FixMessageSender fixMessageSender,
                                    final String account) {
        this(fixMessageSender, account, NewOrderSingle.newNewOrderSingle(Bytes.allocateElasticDirect(), fixMessageSender.context()));
    }

    public HspNewOrderSingleHandler(final FixMessageSender fixMessageSender,
                                    final String account,
                                    final NewOrderSingle newOrderSingle) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.account = Objects.requireNonNull(account);
        this.newOrderSingle = Objects.requireNonNull(newOrderSingle);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.reset();
    }

    @Override
    public void onBody(final Body body) {
        newOrderSingle.clOrdID(body.clOrdId().decodeStringOrNull());
        newOrderSingle.transactTime(body.transactTime());
        newOrderSingle.symbol(body.symbol().decodeAndCache(symbol7Cache));
        newOrderSingle.securityType(com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.SecurityType.FOREIGN_EXCHANGE_CONTRACT);
        newOrderSingle.side(side(body.side()));
        newOrderSingle.orderQty(body.orderQty());
        newOrderSingle.ordType(orderType(body.ordType()));
        newOrderSingle.timeInForce(timeInForce(body.timeInForce()));
        newOrderSingle.currency(currency(body));
        newOrderSingle.account(account);

        if (body.ordType() == OrderType.LIMIT) {
            newOrderSingle.price(body.price());
        }
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.OrdType.LIMIT;
            case MARKET: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.OrdType.MARKET;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case FOK: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.TimeInForce.FILL_OR_KILL;
            case IOC: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.TimeInForce.IMMEDIATE_OR_CANCEL;
            case DAY: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.TimeInForce.DAY;
            default: throw new IllegalArgumentException("Unsupported timeInForce" + timeInForce);
        }
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.Side.BUY;
            case SELL: return com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
    }
}
