package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoInstrumentConfigHandler implements InstrumentConfigHandler {

    private final Consumer<? super InstrumentConfig> messageConsumer;

    private InstrumentConfig message = SorMessage.instrumentConfig();

    public InstrumentConfig message() {
        return message;
    }

    public PojoInstrumentConfigHandler() {
        this(msg -> {});
    }

    public PojoInstrumentConfigHandler(final Consumer<? super InstrumentConfig> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.instrumentConfig();
    }

    @Override
    public void onBody(final Body body) {
        message.body.instrumentId = body.instrumentId();
        message.body.pipSizeDivisor = body.pipSizeDivisor();
        message.body.enabled = body.enabled();
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
