package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveNewsHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTakeProfitHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsItemConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsWideningConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.efx.ngaro.math.DoubleTools;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Instrument.AUDJPY;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURCHF;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCHF;
import static com.anz.markets.prophet.domain.Instrument.USDJPY;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.lessThan;

@Requirement(Requirement.Ref.HEDGING_4_2)
@RestartBeforeTest(reason = "As hedger states are left hanging")
public class AggressiveNewsHedgerTest extends BaseAcceptanceSpecification {
    private static final double MAX_QTY_USD = 300d;
    private EconNews econNewsAUD;
    private EconNews econNewsEUR;
    private EconNews econNewsUSD;
    private EconNews econNewsJPY;
    private NewOrder newOrder;

    private ConfigurationDataDefault setUpConfiguration() {

        econNewsAUD = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now() + 2000);
        econNewsEUR = new EconNewsImpl().setCode("NEWS_CODE#2").setCountry(Country.AU).setEventTimeStampMS(now() + 2000);
        econNewsUSD = new EconNewsImpl().setCode("NEWS_CODE#3").setCountry(Country.AU).setEventTimeStampMS(now() + 2000);
        econNewsJPY = new EconNewsImpl().setCode("NEWS_CODE#4").setCountry(Country.AU).setEventTimeStampMS(now() + 2000);

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setEconNewsItemConfigs(
                        new EconNewsItemConfigImpl(econNewsAUD.getCode(), EconNewsWeight.W_15, Currency.AUD),
                        new EconNewsItemConfigImpl(econNewsEUR.getCode(), EconNewsWeight.W_15, Currency.EUR),
                        new EconNewsItemConfigImpl(econNewsUSD.getCode(), EconNewsWeight.W_10, Currency.USD),
                        new EconNewsItemConfigImpl(econNewsJPY.getCode(), EconNewsWeight.W_5, Currency.JPY)
                )
                .setEconNewsWideningConfigs(
                        new EconNewsWideningConfigImpl(EconNewsWeight.W_10, 10.0, 250, 250, false, Market.ANY),
                        new EconNewsWideningConfigImpl(EconNewsWeight.W_5, 5.0, 250, 250, false, Market.ANY)
                )
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
                .setAggressiveTwapHedgerConfigs(Arrays.asList(
                        new AggressiveTwapHedgerConfigImpl(AXL, USDJPY).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(600_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                        new AggressiveTwapHedgerConfigImpl(AXL, USDJPY).setTradingTimeZone(TradingTimeZone.NYK).setMaximumSpread(0.0005).setMinimumQuantity(3_000_000).setMinimumRisk(900_000_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(1_000)
                ))
                .setAggressiveNewsHedgerConfigs(Arrays.asList(
                        new AggressiveNewsHedgerConfigImpl(AUDUSD, Market.AXL)
                                .setTriggerBeforeNewsMS(1_000)
                                .setMaximumSpread(0.0001)
                                .setMinimumNewsWeight(1)
                                .setMinimumOrderQuantity(1000000)
                                .setMinimumRisk(1000000),
                        new AggressiveNewsHedgerConfigImpl(USDJPY, Market.AXL)
                                .setTriggerBeforeNewsMS(1_000)
                                .setMaximumSpread(0.001)
                                .setMinimumNewsWeight(1)
                                .setMinimumOrderQuantity(1000000)
                                .setMinimumRisk(1000000),
                        new AggressiveNewsHedgerConfigImpl(EURCHF, Market.AXL)
                                .setTriggerBeforeNewsMS(1_000)
                                .setMaximumSpread(0.001)
                                .setMinimumNewsWeight(1)
                                .setMinimumOrderQuantity(1000000)
                                .setMinimumRisk(1000000)
                ));

        return configuration;
    }

    @Test
    public void minNewsWeightNotMetNoHedge() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.00001)
                                    .setMinimumNewsWeight(16)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.75004, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void retractDecisionToHedge() {
        EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now() + 5000);

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(4_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(2_000_000)
                    ))
            );
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNews);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.75004, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+3 order still not placed out. Retract decision to place out order
        {
            // increment time by half of setTriggerBeforeNewsMS
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
    }

    @Test
    public void retractDecisionToHedgeWhenHedgerEnabled() {
        EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now() + 124000);

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(123_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(2_000_000)
                    ))
            );
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNews);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.75004, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+62 turn on hedger. Decision to Hedge now 61 secs old(i.e greater than default 60 secs)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(61));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));

            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
    }

    @Test
    public void instrWithMultiNewsAtSameTimeBothMinNewsWeightNotMet() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNewsAUD.getCode(), EconNewsWeight.W_15, Currency.AUD),
                            new EconNewsItemConfigImpl(econNewsUSD.getCode(), EconNewsWeight.W_10, Currency.USD)
                    )
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.00001)
                                    .setMinimumNewsWeight(16)
                                    .setMinimumOrderQuantity(1000000)
                                    .setMinimumRisk(1000000),
                            new AggressiveNewsHedgerConfigImpl(USDJPY, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1000000)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(econNewsUSD);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, USDJPY, 85.500));
            prophet.receive(tdd.marketDataSnapshot(AXL, USDJPY, 85.500));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
            prophet.receive(tdd.client_trade_001(USDJPY, 2_000_000, 85.500));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDJPY)).getLast();
        }
        then:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
            checkPositionsFlattened(Currency.JPY);
        }
    }

    @Test
    public void instrWithMultiNewsAtSameTimeOneMinNewsWeightMet() {
        NewOrder newOrder2;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNewsAUD.getCode(), EconNewsWeight.W_15, Currency.AUD),
                            new EconNewsItemConfigImpl(econNewsUSD.getCode(), EconNewsWeight.W_10, Currency.USD)
                    )
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.00001)
                                    .setMinimumNewsWeight(11)
                                    .setMinimumOrderQuantity(1000000)
                                    .setMinimumRisk(1000000),
                            new AggressiveNewsHedgerConfigImpl(USDJPY, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1000000)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(econNewsUSD);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000, 0.00001));
            prophet.receive(tdd.marketDataSnapshot(CNX, USDJPY, 85.500));
            prophet.receive(tdd.marketDataSnapshot(AXL, USDJPY, 85.500));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
            prophet.receive(tdd.client_trade_001(USDJPY, 2_000_000, 85.500));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDJPY)).getLast();
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_NEWS;posNotional=2000000;epNotional=2766721;newsCode=NEWS_CODE#1"));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_NEWS;posNotional=2000000;epNotional=1633278;newsCode=NEWS_CODE#3"));
        }
        then:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.receiveHedgeOrderFullFill(newOrder2);
            checkPositionsFlattened(Currency.AUD, Currency.USD, Currency.JPY);
        }
    }

    @Test
    public void instrWithMultiNewsAtSameTimeBothMinNewsWeightMet() {
        NewOrder newOrder2;
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(econNewsUSD);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000, 0.00001));
            prophet.receive(tdd.marketDataSnapshot(CNX, USDJPY, 85.500));
            prophet.receive(tdd.marketDataSnapshot(AXL, USDJPY, 85.500));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
            prophet.receive(tdd.client_trade_001(USDJPY, 2_000_000, 85.500));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDJPY)).getLast();
        }
        and:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.receiveHedgeOrderFullFill(newOrder2);
            checkPositionsFlattened(Currency.AUD, Currency.USD, Currency.JPY);
        }
    }

    @Test
    public void minRiskNotMetNoHedgeAUDUSD() {
        double minRisk = 2_000_001;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.00001)
                                    .setMinimumNewsWeight(15)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(minRisk)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.75004, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(opPos.getInstrumentPositionInNotional(), is(2_000_000.0));
            assertThat(opPos.getInstrumentPositionInNotional() >= minRisk, is(false));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void minRiskNotMetNoHedgeUSDJPY() {
        double minRisk = 2_000_001;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.USDJPY, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(minRisk)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsJPY);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDJPY, 110.500, 110.550, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDJPY, 110.500, 110.550, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDJPY, 2_000_000, 110.525));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDJPY).findFirst().get();
            assertThat(opPos.getInstrumentPositionInNotional(), is(2_000_000.0));
            assertThat(opPos.getInstrumentPositionInNotional() >= minRisk, is(false));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    @DisplayName("Verify biased instrument position used for Min Risk but Unbiased for Order Amount")
    public void strategyToUseBiasedPositionsForMinRiskOnly() {
        double minRisk = 2_000_001;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.USDJPY, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.02)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(minRisk)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsJPY);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDJPY, 110.500, 110.505, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDJPY, 110.500, 110.505, now()));

            // set up biased position
            prophet.receive(tdd.biasPosition(Currency.JPY, -500_000_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDJPY, 2_000_000, 110.5025));
        }
        then:
        {
            // unbiased Instrument Position does NOT meet min risk
            OptimalPositions pos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDJPY).findFirst().get();
            assertThat(opPos.getInstrumentPositionInNotional(), is(2_000_000.0));
            assertThat(opPos.getInstrumentPositionInNotional() >= minRisk, is(false));

            // biased Instrument Position meets min risk
            OptimalPositions biasedPos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition biasedOpPos = biasedPos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDJPY).findFirst().get();
            assertThat(biasedOpPos.getInstrumentPositionInNotional(), isRoundedTo(-2_524_784.5));
            assertThat(Math.abs(biasedOpPos.getInstrumentPositionInNotional()) >= minRisk, is(true));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // order amount and side still based off UNBIASED position
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDJPY)).getLast();
            assertThat(newOrder.getQuantity(), is(2_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }        
    }

    @Test
    public void minRiskNotMetNoHedgeEURCHF() {
        final double minRiskConfig = 1_344_508;
        minRiskBoundaryEURCHF(minRiskConfig);
    }

    @Test
    public void minRiskMetHedgeEURCHF() {
        final double minRiskConfig = 1_344_507;
        minRiskBoundaryEURCHF(minRiskConfig);
    }

    private void minRiskBoundaryEURCHF(double minRiskConfig) {
        double EURCHFPosQty;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_CROSSED)
                    ))
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(EURCHF, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(minRiskConfig)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsEUR);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCHF, 1.0500, 1.0550, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCHF, 1.0500, 1.0550, now()));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURCHF, 1.0675));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.06000));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURCHF, -2_000_000, 0.75000));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURCHF).findFirst().get();
            EURCHFPosQty = Math.abs(opPos.getInstrumentPositionInNotional());
            assertThat(EURCHFPosQty, isRoundedTo(1344507.69));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            if (EURCHFPosQty < minRiskConfig) {
                prophet.notExpect(NewOrder.class);
            } else if (EURCHFPosQty >= minRiskConfig) {
                prophet.expect(NewOrder.class, isOrderInstrument(EURCHF));
            }
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotMetNoHedgeSellOrder() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        double minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(minQty)
                                    .setMinimumRisk(1000000)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP,Market.GS)
                    .addAggBook(Market.WSP_BENCH,Instrument.AUDUSD,TradingTimeZone.GLOBAL, Region.GB,Market.DEUT,Market.HSP,Market.GS)
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
//            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
//                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000),
//                            new PriceAndQtyImpl(0.74995, 749_999),
//                            new PriceAndQtyImpl(0.74993, 100_00)),
//                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
//                    tdd.now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, AUDUSD, 0.74995, 749_999, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, AUDUSD, 0.74993, 100_00, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, AUDUSD, 0.74996, 500_000, 0.75004, 2_000_000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotMetNoHedgeBuyOrder() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        double minQty = 1_250_000;
        double buyOrderPrice = 0.75006;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(minQty)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 250_000),
                            new PriceAndQtyImpl(0.75005, 999_999),
                            new PriceAndQtyImpl(0.75007, 100_00)),
                    tdd.now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotEnoughDepthAtSellOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        double minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(minQty)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000),
                            new PriceAndQtyImpl(0.74995, 500_00),
                            new PriceAndQtyImpl(0.74994, 100_00)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
                    tdd.now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            NewOrder order = prophet.expect(NewOrder.class).getFirst();
            assertThat(order.getPrice(), is(sellOrderPrice));
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void minQtyNotEnoughDepthAtBuyOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        double minQty = 1_250_000;
        double buyOrderPrice = 0.75006;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(minQty)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 250_000),
                            new PriceAndQtyImpl(0.75005, 999_999)),
                    tdd.now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            NewOrder order = prophet.expect(NewOrder.class).getFirst();
            assertThat(order.getPrice(), is(buyOrderPrice));
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void noLiquidityAtSellOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        double minQty = 1_250_000;
        double sellOrderPrice = 0.74994;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(minQty)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74993, 500_000),
                            new PriceAndQtyImpl(0.74992, 749_999),
                            new PriceAndQtyImpl(0.74991, 100_00)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 4_000_000)),
                    tdd.now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-741 minQty check
    public void noLiquidityAtBuyOrderPrice() {
        // market must have at least "min qty" liquidity available at better/equal to hedging price
        double minQty = 1_250_000;
        double buyOrderPrice = 0.75006;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(minQty)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75007, 250_000),
                            new PriceAndQtyImpl(0.75008, 999_999),
                            new PriceAndQtyImpl(0.75008, 100_00)),
                    tdd.now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void hedgeSellOrderCorrectPriceNonJPY() {
        double maxSpreadBps = 0.0002;
        double tobBid = 0.74995;
        double tobOffer = 0.75005;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(maxSpreadBps)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(2_000_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, tobBid, tobOffer, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(tobOffer - maxSpreadBps));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            checkPositionsFlattened(Currency.AUD, Currency.USD);
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void hedgeBuyOrderCorrectPriceJPY() {
        double maxSpreadBps = 0.02;
        double tobBid = 112.555;
        double tobOffer = 112.565;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(USDJPY, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(maxSpreadBps)
                                    .setMinimumNewsWeight(5)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsJPY);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDJPY, 112.550, 112.570, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDJPY, tobBid, tobOffer, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDJPY, -2_000_000, 112.565));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(USDJPY, HedgeTriggerType.AGR_AXL_NEWS));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.BUYING));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDJPY)).getLast();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(tobBid + maxSpreadBps));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        {
            checkPositionsFlattened(Currency.USD, Currency.JPY);
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(USDJPY, HedgeTriggerType.AGR_AXL_NEWS)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void correctHedgeAmtAUDUSD() {
        double audQty = 2_000_000;

        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsUSD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74999, 0.75001));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, audQty, 0.75002));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(Math.abs(opPos.getInstrumentPositionInNotional()), is(audQty));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(audQty));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.7500);
        }
        then:
        {
            checkPositionsFlattened(Currency.AUD, Currency.USD);
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void correctHedgeAmtUSDJPY() {
        double AUDJPYClientAmt = -2_000_000;
        double AUDJPYClientRate = 85.500;
        double JPYQty = -(AUDJPYClientAmt * AUDJPYClientRate);
        double USDJPYMid = 1.100;
        double USDQty = Math.round(JPYQty / USDJPYMid);

        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsUSD);
            prophet.receive(tdd.marketDataSnapshot(CNX, USDJPY, USDJPYMid));
            prophet.receive(tdd.marketDataSnapshot(AXL, USDJPY, USDJPYMid));

            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDJPY, AUDJPYClientAmt, AUDJPYClientRate));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDJPY).findFirst().get();
            assertThat(Math.abs(opPos.getInstrumentPositionInNotional()) >= 1_000_000, is(true));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDJPY)).getLast();
            assertThat(newOrder.getQuantity(), is(USDQty));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDJPY, HedgeTriggerType.AGR_AXL_NEWS, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    private void checkPositionsFlattened(final Currency... ccys) {
        final LinkedList<Positions> positionsList = prophet.expect(Positions.class, atLeast((ccys.length + 1) / 2), isPortfolio(Portfolio.CLIENTS_NET));
        final EnumDoubleMap<Currency> systemBase = new EnumDoubleMap<>(Currency.class);
        for (Positions positions : positionsList) {
            systemBase.put(positions.getPosition1().getCcy(), positions.getPosition1().getPositionInSystemBase());
            systemBase.put(positions.getPosition2().getCcy(), positions.getPosition2().getPositionInSystemBase());
        }
        for (Currency ccy : ccys) {
            assertThat(systemBase.containsKey(ccy), is(true));
            assertThat(Math.abs(systemBase.get(ccy)), lessThan(MAX_QTY_USD));
        }
    }

    @Test
    public void correctHedgeAmtEURCHF() {
        double EURCHFClientAmt = 2_000_000;
        double EURCHFClientRate = 0.75000;
        double CHFQty = EURCHFClientAmt * EURCHFClientRate;
        double USDCHFMid = 1.0525;
        double EURUSDMid = 1.0600;
        double EURCHFPosQty = (CHFQty / USDCHFMid / EURUSDMid);

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_CROSSED)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.USDCHF,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_BENCH,Instrument.EURCHF,TradingTimeZone.GLOBAL, Region.GB,Market.HSP)
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsEUR);
            prophet.receive(tdd.marketDataSnapshot(CNX, USDCHF, USDCHFMid));
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, USDCHF, USDCHFMid));
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, EURCHF, 1.0675));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, EURUSDMid));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURCHF, EURCHFClientAmt, EURCHFClientRate));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURCHF).findFirst().get();
            assertThat(opPos.getInstrumentPositionInNotional(), is(EURCHFPosQty));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURCHF)).getLast();
            assertThat(newOrder.getQuantity(), is(DoubleTools.round(EURCHFPosQty, 0)));
        }
    }

    @Ignore("AXPROPHET-592 not implemented")
    @Test
    public void aggressiveNewsConfigUpdated() {
        /**
         While hedger has already queued up upcoming news event, user updates(increases) setMinimumNewsWeight config
         such that the queued news even weight is now less than setMinimumNewsWeight.  The queued news event must be removed.
         */
    }

    @Ignore("AXPROPHET-592 not implemented")
    @Test
    public void existingNewsEventWeightUpdated() {
        /**
         While hedger has already queued up upcoming news event, user updates(decreases) the same news event's weighting
         in the config(econNewsItemConfigs) such that it is now LESS than hedger's setMinimumNewsWeight.
         The queued news event must be removed.
         */
    }

    @Test
    public void existingNewsEventTimeUpdated() {
        EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now() + 4000);
        EconNews updatedEconNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now() + 5000);
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(2_000)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(100_000)
                                    .setMinimumRisk(1000000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNews);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 1_000_000, 0.75004, 1_000_000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74996, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75004, 250_000),
                            new PriceAndQtyImpl(0.75005, 999_999)),
                    tdd.now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 receive updated news Event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(updatedEconNews);
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+2 old trigger time, do not expect order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+3 new trigger time, expect order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }

    @Ignore("need ability to increment time and send client trade simultaneously")
    @Test
    @Requirement(Requirement.Ref.HEDGING_4_1_8)
    @DisplayName("Aggressive News Strategy take precedence over Take Profit Strategy when hedging amts are equal")
    public void newsAndTakeProfitEqualHedgingAmts() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveNewsHedgerConfigs(Arrays.asList(
                            new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL)
                                    .setTriggerBeforeNewsMS(1_000)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumNewsWeight(1)
                                    .setMinimumOrderQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                    ))
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_000_000)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsAUD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74995, 0.75005, now()));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1 trigger time before news event. Counterparty deal also arrives.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(Math.abs(opPos.getInstrumentPositionInNotional()), is(1_000_000d));

            // TP BUYING_REQ only
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TP, HedgeTriggerState.BUY_REQ));
            HedgeDecision twapHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_TP)).getLast();
            assertThat(twapHedgeDecision.getQuantity(), is(1_000_000d));

            // News strategy SELLING_REQ and SELLING
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS, HedgeTriggerState.SELLING));
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_NEWS)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(1_000_000d));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000d));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedNotApplicable() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(econNewsUSD);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74999, 0.75001));

            // Pause enabled
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75002));
        }
        and:
        // t+1 trigger time before news event
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
    }
}
