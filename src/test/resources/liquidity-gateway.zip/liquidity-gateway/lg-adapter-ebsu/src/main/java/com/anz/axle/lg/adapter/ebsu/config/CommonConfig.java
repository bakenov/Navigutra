package com.anz.axle.lg.adapter.ebsu.config;

import com.anz.axle.lg.publisher.LazyPublicationRegistry;
import com.anz.axle.lg.publisher.PublicationLookup;
import com.anz.axle.lg.publisher.Publisher;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

// TODO: this is same as in tr-sbe
@Configuration
public class CommonConfig {
    @Bean
    public PrecisionClock precisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public SourceSequencer sourceSequencer(@Value("${messaging.source.id}") final int sourceId) {
        return SourceSequencer.of(sourceId);
    }

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("async-%d").build());
    }

    @Bean
    public LazyPublicationRegistry publicationRegistry(final Connection connection,
                                                       final EndPointStatusHandler endPointStatusHandler) {
        return new LazyPublicationRegistry(connection, endPointStatusHandler);
    }

    @Bean
    public Publisher publisher(final PublicationLookup publicationLookup) {
        return new Publisher(publicationLookup);
    }
}
