package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.DiscoTightenByConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.collections.EnumDoubleMapMarshaller;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
public class DiscoTightenByConfigImpl implements DiscoTightenByConfig, ProphetMarshallable {

    private Market market;
    private Instrument instrument;
    private EnumDoubleMap<TradingTimeZone> tightenByByTimeZone = new EnumDoubleMap<>(TradingTimeZone.class);
    private Region region = Region.GB;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public DiscoTightenByConfigImpl() {
    }

    public DiscoTightenByConfigImpl(final Market market,
                                    final Instrument instrument,
                                    final Region region) {
        this.market = market;
        this.instrument = instrument;
        this.region = region;
    }

    public DiscoTightenByConfigImpl set(final TradingTimeZone tradingTimeZone,
                                        final double tightenBy) {
        tightenByByTimeZone.put(tradingTimeZone, tightenBy);
        return this;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public double get(final TradingTimeZone tradingTimeZone) {
        return tightenByByTimeZone.get(tradingTimeZone);
    }

    @Override
    public Region getRegion() {
        return region;
    }

    public EnumDoubleMap<TradingTimeZone> getTightenByByTimeZone() {
        return tightenByByTimeZone;
    }

    public void setTightenByByTimeZone(final EnumDoubleMap<TradingTimeZone> tightenbyByTimeZone) {
        this.tightenByByTimeZone = tightenbyByTimeZone;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        this.market = Market.valueOf(in.readByte());
        this.instrument = Instrument.readMarshallableValueOf(in);
        EnumDoubleMapMarshaller.readMarshallable(tightenByByTimeZone, in);
        this.region = Region.valueOf(in.readByte());
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(market.getValue());
        out.writeShort(instrument.getValue());
        EnumDoubleMapMarshaller.writeMarshallable(tightenByByTimeZone, out);
        out.writeByte(region.getValue());
    }

    @Override
    public String toString() {
        return "DiscoTightenByConfigImpl{" +
                "region=" + region +
                ", instrument=" + instrument +
                ", market=" + market +
                ", tightenByByTimeZone=" + tightenByByTimeZone +
                '}';
    }
}
