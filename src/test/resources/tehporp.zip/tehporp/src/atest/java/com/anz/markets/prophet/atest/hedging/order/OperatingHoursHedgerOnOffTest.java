package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELL_REQ;
import static com.anz.markets.prophet.domain.HedgeTriggerType.MID_BGC_EP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_CONTROL;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_FIREWALL;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.ENABLE_BY_CONTROL;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "As hedger states are left hanging", initialOperatingHourChime = OperatingHourSpecification.State.UNDEFINED)
public class OperatingHoursHedgerOnOffTest extends BaseAcceptanceSpecification {
    private NewOrder hedgingOrder1;
    private CancelOrder cancelOrder;

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setHedgePortfolioConfigs(asList(
                        new HedgePortfolioConfigImpl(Market.BGCMIDFX, Portfolio.HEDGER_MID_BGC).setEnabled(true).setMinimumTimeToLiveMS(1).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(1000).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setOrderQuantityPrecision(0),
                        new HedgePortfolioConfigImpl(Market.FXALLMB, Portfolio.HEDGER_MID_FXALL).setEnabled(true).setMinimumTimeToLiveMS(0).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(0).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setOrderQuantityPrecision(0),
                        new HedgePortfolioConfigImpl(Market.EBSHEDGE, Portfolio.HEDGER_MID_EBS).setEnabled(true).setMinimumTimeToLiveMS(1).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(0).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setOrderQuantityPrecision(0),
                        new HedgePortfolioConfigImpl(Market.AXL, Portfolio.HEDGER_AGGRESSIVE).setEnabled(true).setMinimumTimeToLiveMS(1).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(0).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setOrderQuantityPrecision(0),
                        new HedgePortfolioConfigImpl(Market.EBS, Portfolio.HEDGER_PASSIVE_EBS).setEnabled(true).setMinimumTimeToLiveMS(1).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(0).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setOrderQuantityPrecision(0),
                        new HedgePortfolioConfigImpl(Market.RFX, Portfolio.HEDGER_PASSIVE_RFX).setEnabled(true).setMinimumTimeToLiveMS(1).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(0).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setOrderQuantityPrecision(0),
                        new HedgePortfolioConfigImpl(Market.AXL, Portfolio.HEDGER_ARBITRAGE).setEnabled(true).setMinimumTimeToLiveMS(1).setOrderUnknownTimeoutMS(0).setCancelUnknownTimeoutMS(0).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setOrderQuantityPrecision(0)
                ));

        return configuration;
    }

    @Test
    public void operatingHoursUndefinedTreatedAsClosed() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        // since operating hours undefined, unable to hedge as treated as CLOSED
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void multipleOperatingHoursDoesNotOverwriteEachOther() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_AGGRESSIVE, "OPEN Mon 01:00 GMT"));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        // since operating hours CLOSED for BGC MID, unable to hedge
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void uponCloseEventDoNotTurnHedgerOff() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        {
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
        }
        then:
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_MID_BGC));
        }
    }

    @Test
    public void uponCloseEventCancelOpenOrder() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2sec receive CLOSE chime
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
        }
        then:
        // cancel order sent. Hedger status does not change.
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            prophet.notExpect(HedgeStatus.class, hedgeStatus(HEDGER_MID_BGC));
        }
        when:
        // receive Cancel Ack
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0.0, 0.0));
        }
        then:
        // hedge status unchanged with business hour chime close.
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatus(HEDGER_MID_BGC));
        }
        and:
        // ready to buy again. i.e Does not hedge during outages
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(EURUSD, MID_BGC_EP, SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void afterCloseEventCancelOrderTimeOut() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2sec receive CLOSE chime
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
        }
        then:
        // cancel order sent. Hedger status does not changed
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            prophet.notExpect(HedgeStatus.class, hedgeStatus(HEDGER_MID_BGC));
        }
        when:
        // t+3 order cancel timeout
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedge is off due to LATEST reason of DISABLE_BY_ORDER_TIMEOUT
        {
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_ORDER_TIMEOUT));
        }
        and:
        // ready to buy again
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(EURUSD, MID_BGC_EP, SELL_REQ));
        }
        when:
        // t+3.5 receive OPEN chime and EXPECT hedger to REMAIN OFF
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        // since hedger is off no hedging order
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+4 user enables hedger
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05010));
        }
        then:
        {
            prophet.expect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void doNotHedgeWhenManuallyTurnedOnDuringOutage() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, MID_BGC_EP));
            prophet.expect(HedgeDecision.class, isHedgeDecision(EURUSD, MID_BGC_EP, SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+1, user manually turns on Hedger
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void hedgePlacesOrderOnceOutageConcludes() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2sec receive CLOSE chime
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
        }
        then:
        // cancel order sent.
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
        }
        when:
        // receive Cancel Ack
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0.0, 0.0));
        }
        then:
        // hedger can't place order during outages
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_MID_BGC));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // outage concludes i.e receive OPEN chime
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // no order until new decision, trigger hedge update via new price
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05100));
        }
        then:
        // hedger allowed to place order
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
    }

    @Test
    public void userTurnOffBeforeCloseEvent() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2sec user turn OFF
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.disableHedger(HEDGER_MID_BGC));
        }
        then:
        // cancel order sent. Hedger in PENDING DISABLE STATE only
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
        }
        when:
        // receive Cancel Ack
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0.0, 0.0));
        }
        then:
        // hedger is off
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_CONTROL));
        }
        when:
        // receive CLOSE chime and then OPEN chime
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        // do NOT auto turn ON
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // user manually turns on hedger
        {
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOn(HEDGER_MID_BGC, ENABLE_BY_CONTROL));
        }
    }

    @Test
    public void disabledByFirewallBeforeCloseEvent() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setHedgeFirewallConfigs(asList(
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_MIN, -10.00, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true)
                    ))
            );
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+0.5 order filled
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05500));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));

            prophet.receiveHedgeOrderFullFill(hedgingOrder1, 1.0500);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, HEDGER_MID_BGC));
        }
        when:
        // t+1.5 market update causing FIREWALL to trigger
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05550));
        }
        then:
        {
            HedgeFirewallStatus firewallStatus = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, HEDGER_MID_BGC)).getLast();
            assertThat(firewallStatus.getStatus(), is(HedgeFirewallStatus.Status.BREACHED));

            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_FIREWALL));
        }
        when:
        // t+3.0sec receive CLOSE chime
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1500));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));

        }
        then:
        {
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_FIREWALL));
        }
        when:
        // t+61sec receive client trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(60));
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_100, 1.05000));
        }
        then:
        // hedger can't place order during outages
        {
            prophet.expect(HedgeDecision.class, isHedgeDecision(EURUSD, MID_BGC_EP, SELL_REQ));
        }
        when:
        // user turn on hedger manually
        {
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOn(HEDGER_MID_BGC));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // receive open chime
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // no order until new decision, trigger hedge update via new price
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05100));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    public void afterCloseEventManualOffReceivedDoNotAutoOn() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2sec receive CLOSE chime
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
        }
        then:
        // cancel order sent. Hedger status is not changed.
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            prophet.notExpect(HedgeStatus.class, hedgeStatus(HEDGER_MID_BGC));
        }
        when:
        // t+2.1 manual off received and then cancel ack received
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
            prophet.receive(tdd.disableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0, 0));
        }
        then:
        // hedger is off due to LATEST reason of DISABLE_BY_CONTROL
        {
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_CONTROL));
        }
        and:
        // ready to buy again
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(EURUSD, MID_BGC_EP, SELL_REQ));
        }
        when:
        // t+2.2 receive OPEN chime
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        // since hedger is off no hedging order
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void afterCloseEventHedgerDisabledThenFirewallBreached() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setHedgeFirewallConfigs(asList(
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_MIN, -10.00, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, true)
                    ))
            );
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2sec receive CLOSE chime
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05500));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
        }
        then:
        // cancel order sent. Hedger status does not changed.
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            prophet.notExpect(HedgeStatus.class, hedgeStatus(HEDGER_MID_BGC));
        }
        when:
        // t+2.5 order filled => FIREWALL triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));

            prophet.receiveHedgeOrderFullFill(hedgingOrder1, 1.0500);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, HEDGER_MID_BGC));
        }
        when:
        // t+3.5 market update causing FIREWALL to trigger
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05590));
        }
        then:
        {
            HedgeFirewallStatus firewallStatus = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, HEDGER_MID_BGC)).getLast();
            assertThat(firewallStatus.getStatus(), is(HedgeFirewallStatus.Status.BREACHED));

            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_FIREWALL));
        }
        when:
        // t+4.5 receive OPEN chime and EXPECT hedger stay off
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        {
            // hedge status published by one second chime
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_FIREWALL));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }
}
