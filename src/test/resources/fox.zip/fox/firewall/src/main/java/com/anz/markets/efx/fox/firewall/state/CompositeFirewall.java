package com.anz.markets.efx.fox.firewall.state;

import java.util.Map;
import java.util.Objects;

import org.agrona.collections.Object2ObjectHashMap;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class CompositeFirewall implements Firewall {

    private final Map<String, Firewall> firewalls = new Object2ObjectHashMap<>();
    private final String compositeName;
    private final OrderConsumer successfulOrderConsumer;
    private final ByteValueCache<String> nameCache = new ByteValueCache<>(AsciiString::toString, 64, 128);

    public CompositeFirewall(final String compositeName,
                             final OrderConsumer successfulOrderConsumer,
                             final Firewall... firewalls) {
        this.compositeName = Objects.requireNonNull(compositeName);
        this.successfulOrderConsumer = Objects.requireNonNull(successfulOrderConsumer);

        for (Firewall firewall : Objects.requireNonNull(firewalls)) {
            this.firewalls.put(firewall.firewallName(), firewall);
        }
    }

    @Override
    public void onFirewallConfigRuleRequest(final CommandContext commandContext, final FirewallConfigDecoder firewallConfigDecoder) {
        final Firewall firewall = firewalls.get(firewallConfigDecoder.body().firewallName().decodeAndCache(nameCache));
        if(firewall != null){
            firewall.onFirewallConfigRuleRequest(commandContext, firewallConfigDecoder);
        }
    }

    @Override
    public void applyFirewallConfigRuleResponse(final EventContext eventContext, final FirewallConfigDecoder firewallConfigDecoder) {
        final Firewall firewall = firewalls.get(firewallConfigDecoder.body().firewallName().decodeAndCache(nameCache));
        if(firewall != null){
            firewall.applyFirewallConfigRuleResponse(eventContext, firewallConfigDecoder);
        }
    }

    @Override
    public void applyExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
        for (Firewall firewall : firewalls.values()) {
            firewall.applyExecutionReport(eventContext, executionReportDecoder);
        }
    }

    @Override
    public String firewallName() {
        return compositeName;
    }

    @Override
    public boolean accept(final NewOrderSingleDecoder newOrderSingle, final CommandContext commandContext) {
        for (Firewall firewall : firewalls.values()) {
            final boolean result = firewall.accept(newOrderSingle, commandContext);
            if(!result) return false;
        }
        successfulOrderConsumer.accept(newOrderSingle, commandContext);
        return true;
    }
}
