package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;

public interface VenueConfigEncoder extends MessageEncoder<VenueConfigEncoder.Body> {
    @Override
    Body messageStart(final int source, final long sourceSeq);

    interface Body {
        Body venue(Venue venue);
        StringEncoder<Body> compId();
        EnumerableSetEncoder<Body, VenueCategory> venueCategories();
        Trailer enabled(boolean enabled);
    }
}
