package com.anz.axle.lg.adapter.cnx;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
public class LastMarketTradeSubscriptionConfig {

    private final AsyncMarketDataSubscriber asyncMarketDataSubscriber;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final Venue venue;

    public LastMarketTradeSubscriptionConfig(@Qualifier("asyncLastMarketTradeSubscriber") final AsyncMarketDataSubscriber asyncLastMarketTradeSubscriber,
                                             @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues) {
        this.asyncMarketDataSubscriber = Objects.requireNonNull(asyncLastMarketTradeSubscriber);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.venue = Venue.CNX;
    }

    @PostConstruct
    void init() {
        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            final CnxLastMarketTradeSubscription fixSubscription =
                    CnxLastMarketTradeSubscription.fullRefreshForIdAndSymbol(SymbolNormaliser.toSymbol7(symbol));
            asyncMarketDataSubscriber.schedule(fixSubscription);
        });
    }
}
