package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.function.IntSupplier;

import org.agrona.collections.Int2ObjectCache;
import org.agrona.collections.Object2IntHashMap;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import com.anz.markets.efx.ngaro.core.ObjectPool;

public class StringToIntAsciiCache implements StringToIntCache {
    private final static AsciiString NULL_ASCII_STRING = FixedLengthAsciiString.EMPTY;
    private final static int MISSING_VALUE = -1;

    private final ObjectPool<MutableAsciiString> objectPool;
    private final int getMaxStringLength;
    private final Object2IntHashMap<MutableAsciiString> asciiToKeyHashMap = new Object2IntHashMap<>(MISSING_VALUE);
    private final Int2ObjectCache<MutableAsciiString> keyToAsciiCache;
    private final IntSupplier keySupplier;
    private final StringDecoderWrapper stringDecoderWrapper;

    public StringToIntAsciiCache(final ObjectPool<MutableAsciiString> objectPool,
                                 final int getMaxStringLength,
                                 final IntSupplier keySupplier,
                                 final int cacheSetNums,
                                 final int cacheSetSize) {
        this.objectPool = Objects.requireNonNull(objectPool);
        this.getMaxStringLength = getMaxStringLength;
        this.keySupplier = Objects.requireNonNull(keySupplier);

        keyToAsciiCache = new Int2ObjectCache<>(cacheSetNums, cacheSetSize, asciiString -> {
            asciiToKeyHashMap.removeKey(asciiString);
            asciiString.clear();
            objectPool.release(asciiString);
        });

        this.stringDecoderWrapper = new StringDecoderWrapper();
    }

    private int put(final MutableAsciiString asciiString) {
        int key = asciiToKeyHashMap.getValue(asciiString);
        if (key == MISSING_VALUE) {
            key = keySupplier.getAsInt();
            asciiToKeyHashMap.put(asciiString, key);
            keyToAsciiCache.put(key, asciiString);
            return key;
        } else {
            asciiString.clear();
            objectPool.release(asciiString);
        }

        return key;
    }

    private int remove(final MutableAsciiString asciiString) {
        int key = asciiToKeyHashMap.getValue(asciiString);
        if (key != MISSING_VALUE) {
            keyToAsciiCache.remove(key);
            return key;
        }
        asciiString.clear();
        objectPool.release(asciiString);

        return key;
    }

    @Override
    public int put(final StringDecoder stringDecoder) {
        final MutableAsciiString temp = objectPool.borrowOrNew();
        stringDecoder.decodeTo(temp, getMaxStringLength);
        return put(temp);
    }

    @Override
    public int remove(final StringDecoder stringDecoder) {
        final MutableAsciiString temp = objectPool.borrowOrNew();
        stringDecoder.decodeTo(temp, getMaxStringLength);
        return remove(temp);
    }

    @Override
    public <S> int put(final S source, final ByteReader<? super S> reader, final int sourceOffset, final int length) {
        final MutableAsciiString temp = objectPool.borrowOrNew();
        temp.set(source, reader, sourceOffset, Math.min(length, getMaxStringLength));

        return put(temp);
    }

    @Override
    public <S> int remove(final S source, final ByteReader<? super S> reader, final int sourceOffset, final int length) {
        final MutableAsciiString temp = objectPool.borrowOrNew();
        temp.set(source, reader, sourceOffset, Math.min(length, getMaxStringLength));

        return remove(temp);
    }

    private AsciiString nonNullAsciiString(final int key) {
        final AsciiString asciiString = keyToAsciiCache.get(key);
        if (asciiString == null) {
            return NULL_ASCII_STRING;
        }
        return asciiString;
    }

    @Override
    public StringDecoder get(final int key) {
        return stringDecoderWrapper.wrap(nonNullAsciiString(key));
    }

    @Override
    public String getStringOrNull(final int key) {
        return nonNullAsciiString(key).toStringOrNull();
    }

    @Override
    public void clear() {
       keyToAsciiCache.clear();
    }

    @Override
    public int size() {
        return keyToAsciiCache.size();
    }

    private class StringDecoderWrapper {
        final AsciiStringDecoder asciiStringDecoder;
        AsciiString asciiString;

        public StringDecoderWrapper() {
            asciiStringDecoder = AsciiStringDecoder.forSupplier(() -> asciiString);
        }

        public AsciiStringDecoder wrap(final AsciiString asciiString) {
            this.asciiString = Objects.requireNonNull(asciiString);
            return asciiStringDecoder;
        }
    }
}
