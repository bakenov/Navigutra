package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.MarketDataIncrementalRefresh_MDEntriesGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDBookType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDElementName;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDEntryType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDUpdateAction;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.AggressorAction;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.LastMarketTradeEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.function.Consumer;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.QuoteCondition.NO_DATA_AVAILABLE;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.QuoteCondition.NO_MARKET_ACTIVITY;


public class EbsIncrementalRefreshHandler implements ChronicleMessageHandler<MarketDataIncrementalRefresh> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsIncrementalRefreshHandler.class);

    private final CachedFunction<String, String> symbol6Lookup = CachedFunction.of(SymbolNormaliser::toSymbol6);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PricingEncoderSupplier lastMarketTradePricingEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalFlagsAppender;
    private final TenorLookup tenorLookup;
    private final SourceSequencer sourceSequencer;
    private final InstrumentKey.Lookup instrumentKeyLookup = new DefaultInstrumentKeyLookup();

    public EbsIncrementalRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                        final PricingEncoderLookup pricingEncoderLookup,
                                        final PricingEncoderSupplier lastMarketTradePricingEncoderSupplier,
                                        final PrecisionClock precisionClock,
                                        final String senderCompId,
                                        final String compId,
                                        final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalFlagsAppender,
                                        final TenorLookup tenorLookup,
                                        final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.lastMarketTradePricingEncoderSupplier = Objects.requireNonNull(lastMarketTradePricingEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.incrementalFlagsAppender = Objects.requireNonNull(incrementalFlagsAppender);
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final MarketDataIncrementalRefresh message) throws IllegalArgumentException {
        accept(message, Long.MIN_VALUE);
    }

    @Override
    public void accept(final MarketDataIncrementalRefresh message, final long receivedByAdapterTimestampNanos) throws IllegalArgumentException {
        final long receivingTimeNanos = receivedByAdapterTimestampNanos <= 0 ? precisionClock.nanos() : receivedByAdapterTimestampNanos;
        LOGGER.debug("MarketDataIncrementalRefresh received: {}", message);

        if (message.mDBookType() != MDBookType.PRICE_DEPTH) {
            LOGGER.info("Non PRICE_DEPTH MarketDataIncrementalRefresh received. Skip: msgSeqNum={} MDBookType={} with NoMDEntries={}", message.msgSeqNum(), message.mDBookType(), message.noMDEntries());
            return;
        }

        RequestKey requestKey = null;
        int startIdx = 0;
        int endIdx = 0;
        MarketDataIncrementalRefresh_MDEntriesGrp_1 prevEntry = null;

        for (int i = 0; i < message.noMDEntries(); i++) {
            final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry = message.marketDataIncrementalRefresh_MDEntriesGrp_1(i);

            if (prevEntry == null) {
                prevEntry = entry;
                requestKey = requestKeyLookup.lookup(instrumentKey(entry));
                startIdx = i;
            }

            if (isGroup(prevEntry, entry)) {
                endIdx = i;
            } else {
                encodeGroup(requestKey, message, startIdx, endIdx, receivingTimeNanos);
                prevEntry = entry;
                requestKey = requestKeyLookup.lookup(instrumentKey(entry));
                startIdx = i;
                endIdx = startIdx;
            }
        }
        encodeGroup(requestKey, message, startIdx, endIdx, receivingTimeNanos);
    }

    private boolean isGroup(final MarketDataIncrementalRefresh_MDEntriesGrp_1 prevEntry, final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry) {

        if (instrumentKey(prevEntry).instrumentId() != instrumentKey(entry).instrumentId()) {
            return false;
        }
        final long prevType = isTrade(prevEntry.mDEntryType()) ? 2 : 0;
        final long currentType = isTrade(entry.mDEntryType()) ? 2 : 0;

        return prevType == currentType;
    }

    private void encodeGroup(final RequestKey requestKey, final MarketDataIncrementalRefresh message, final int startIdx, final int endIdx, final long receivingTimeNanos) {
        final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry = message.marketDataIncrementalRefresh_MDEntriesGrp_1(startIdx);

        if (hasNoMarket(message, startIdx, endIdx, requestKey, receivingTimeNanos)) {
            return;
        }

        if (isBidOrOffer(entry.mDEntryType())) {
            encodeIncrementalRefreshGroup(requestKey, message, startIdx, endIdx, receivingTimeNanos);
        } else if (isTrade(entry.mDEntryType())) {
            encodeLastMarketTradeGroup(requestKey, message, startIdx, endIdx, receivingTimeNanos);
        } else {
            LOGGER.debug("Ignore entries: {} for {}", MDEntryType.asString(entry.mDEntryType()) , requestKey);
        }
    }

    private void encodeLastMarketTradeGroup(final RequestKey requestKey, final MarketDataIncrementalRefresh message, final int startIdx, final int endIdx, final long receivingTimeNanos) {
        for (int i = startIdx; i <= endIdx; i++) {
            final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry = message.marketDataIncrementalRefresh_MDEntriesGrp_1(i);
            encodeLastMarketTrade(requestKey, message, receivingTimeNanos, entry);
        }
    }

    private void encodeEmptySnapshot(final RequestKey requestKey, final MarketDataIncrementalRefresh message, final long receivingTimeNanos) {
        final long messageId = message.msgSeqNum();
        final long sendingTimeNanos = message.sendingTime();

        pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                    .senderCompId().encode(compId)
                    .messageId(messageId)
                    .possResend(false)
                    .sendingTime(sendingTimeNanos)
                    .instrumentId(requestKey.instrumentKey().instrumentId())
                    .marketId(requestKey.market())
                    .tradeDate().encodeNull()
                    .settlDate().encodeNull()
                    .referenceSpotDate().encodeNull()
                    .mdFlags().add(Flag.NO_MARKET)
                    .entriesEmpty()
                    .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .messageComplete();
    }

    private boolean hasNoMarket(final MarketDataIncrementalRefresh message, final int startIdx, final int endIdx, final RequestKey requestKey, final long receivingTimeNanos) {
        boolean hasNoMarket = false;
        for (int i = startIdx; i <= endIdx; i++) {
            final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry = message.marketDataIncrementalRefresh_MDEntriesGrp_1(i);
            if (isNoMarket(entry)) {
                encodeEmptySnapshot(requestKey, message, receivingTimeNanos);
                hasNoMarket = true;
            }
        }
        return hasNoMarket;
    }

    private boolean isNoMarket(final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry) {
        return NO_MARKET_ACTIVITY.equals(entry.quoteCondition()) || NO_DATA_AVAILABLE.equals(entry.quoteCondition());
    }

    private void encodeIncrementalRefreshGroup(final RequestKey requestKey, final MarketDataIncrementalRefresh message, final int startIdx, final int endIdx, final long receivingTimeNanos) {
        final long messageId = message.msgSeqNum();
        final long sendingTimeNanos = message.sendingTime();
        final int entriesCount = (endIdx + 1) - startIdx;
        final int maxImplicitUpdates = pricingEncoderLookup.sizeOfCurrentSnapshot(requestKey);

        final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        incrementalFlagsAppender.accept(encoder.mdFlags());

        final IncrementalRefreshEncoder.MdEntries.Next mdEntries_next = encoder
                .senderCompId().encode(compId)
                .messageId(messageId)
                .sendingTime(sendingTimeNanos)
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .marketId(requestKey.market())
                .tradeDate().encodeNull()
                .settlDate().encodeNull()
                .referenceSpotDate().encodeNull()
                .mdFlags().clear()
                .entriesStart(entriesCount * 2 + maxImplicitUpdates);

        for (int i = startIdx; i <= endIdx; i++) {
            final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry = message.marketDataIncrementalRefresh_MDEntriesGrp_1(i);
            final char mDEntryType = entry.mDEntryType();

            final InstrumentKey entryKey = instrumentKey(entry);

            if (requestKey.instrumentKey().instrumentId() != entryKey.instrumentId()) {
                LOGGER.error("Unexpected instrument found on group={} - {} - Skipping entry", requestKey.instrumentKey().symbol(), entryKey.symbol());
                continue;
            }

            if (!isBidOrOffer(mDEntryType)) {
                continue;
            }

            final IncrementalRefreshEncoder.MdEntries.Body entryBody = mdEntries_next.next();
            entryBody
                    .transactTime(sendingTimeNanos)
                    .mdUpdateAction(updateAction(entry.mDUpdateAction()))
                    .mdMkt(requestKey.market())
                    .mdEntryType(entry.mDEntryType() == MDEntryType.BID ? EntryType.BID : EntryType.OFFER)
                    .mdEntryPx(entry.mDEntryPx())
                    .mdEntrySize(entry.mDEntrySize())
                    .minQty(0.0)
                    .mdEntryRefId(0)
                    .mdEntryId(0);
        }

        mdEntries_next.entriesComplete()
                .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
                .messageComplete();
    }

    private void encodeLastMarketTrade(final RequestKey requestKey, final MarketDataIncrementalRefresh message, final long receivingTimeNanos, final MarketDataIncrementalRefresh_MDEntriesGrp_1 entry) {
        final long messageId = message.msgSeqNum();
        final long sendingTimeNanos = message.sendingTime();
        final LastMarketTradeEncoder.Body encoder = lastMarketTradePricingEncoderSupplier.lastMarketTrade().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        encoder.senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .sendingTime(sendingTimeNanos)
                .mdEntryPx(entry.mDEntryPx())
                .mdEntrySize(0.0)
                .aggressorAction(aggressorActionOrNull(entry.mDElementName()))
                .hopsStart(2)
            .next()
                .hopCompId().encode(senderCompId)
                .hopMessageId(messageId)
                .hopReceivingTime(0)
                .hopSendingTime(sendingTimeNanos)
            .next()
                .hopCompId().encode(compId)
                .hopMessageId(messageId)
                .hopReceivingTime(receivingTimeNanos)
                .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
            .messageComplete();
        LOGGER.debug("Encoded LastMarketTrade: price={} {}", entry.mDEntryPx(), requestKey);
    }

    private AggressorAction aggressorActionOrNull(final String mDElementName) {
        if (mDElementName != null) {
            switch (mDElementName) {
                case MDElementName.PAID:    return AggressorAction.PAID;
                case MDElementName.GIVEN:   return AggressorAction.GIVEN;
            }
        }
        return null;
    }

    private InstrumentKey instrumentKey(final MarketDataIncrementalRefresh_MDEntriesGrp_1 mdEntriesGrp_1) {
        final String symbol6 = symbol6Lookup.apply(mdEntriesGrp_1.symbol());
        final SecurityType securityType = FixCFICode.from(mdEntriesGrp_1.cFICode());
        final Tenor tenor = tenorLookup.anzTenor(mdEntriesGrp_1.settlType());
        final long instrumentId = InstrumentKey.instrumentId(symbol6, securityType, tenor, null);
        return instrumentKeyLookup.lookup(instrumentId);
    }

    private boolean isBidOrOffer(final char mDEntryType) {
        return mDEntryType == MDEntryType.BID || mDEntryType == MDEntryType.OFFER;
    }

    private boolean isTrade(final char mDEntryType) {
        return mDEntryType == MDEntryType.TRADE;
    }

    private UpdateAction updateAction(final char mdUpdateAction) {
        switch (mdUpdateAction) {
            case MDUpdateAction.NEW: return UpdateAction.NEW;
            case MDUpdateAction.DELETE: return UpdateAction.DELETE;
            case MDUpdateAction.CHANGE: return UpdateAction.CHANGE;
            default:
                throw new RuntimeException("Unsupported update action " + mdUpdateAction);
        }
    }
}
