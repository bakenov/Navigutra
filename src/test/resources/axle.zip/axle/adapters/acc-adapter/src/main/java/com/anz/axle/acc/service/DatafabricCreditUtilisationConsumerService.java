package com.anz.axle.acc.service;

import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionDAO;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValueDAO;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * Implementation of the CreditUtilisationConsumerService to communicate
 * credit information to the datafabric.
 *
 * @author jonesr18
 */
@Transactional
@Service("datafabricCreditUtilisationConsumerService")
public class DatafabricCreditUtilisationConsumerService implements CreditUtilisationConsumerService {

    private final static Logger LOG = Logger.getLogger(DatafabricCreditUtilisationConsumerService.class);

    @Autowired
    private CounterpartyCreditUtilisationValueDAO counterpartyCreditUtilisationValueDao;
    
    @Autowired
    private CurrencyVenueExclusionDAO currencyVenueExclusionDao;

    @Autowired
    @Qualifier("counterpartyCreditUtilisationValuesBuilder")
    private Builder<Collection<CounterpartyCreditUtilisationValue>, CounterpartyCreditUtilisations> utilisationsBuilder;

    @Autowired
    @Qualifier("currencyVenueExclusionsBuilder")
    private Builder<Collection<CurrencyVenueExclusion>, CurrentVenueCurrencyCreditStates> exclusionsBuilder = null;

    @Autowired
    @Qualifier("logConsumedCreditUtilisationConsumerServiceListener")
    private CreditUtilisationConsumerServiceListener listener;

    /**
     * This method consumers CurrentVenueCurrencyCreditStates and saves
     * new values or values with a different isExcluded property to
     * the datafabric.
     * @param states
     * @return true if the consumption returned successfully, false if there was an exception.
     */
    @Override
    public boolean consume(CurrentVenueCurrencyCreditStates states) {
        try {
            Collection<CurrencyVenueExclusion> exclusions = exclusionsBuilder.build(states);
            for(CurrencyVenueExclusion exclusion : exclusions) {
                if(currencyVenueExclusionDao.has(exclusion.getKey())) {
                    CurrencyVenueExclusion datafabricExclusion = currencyVenueExclusionDao.findByKey(exclusion.getKey());
                    if(datafabricExclusion.isExcluded() != exclusion.isExcluded()) {
                        currencyVenueExclusionDao.save(exclusion);
                        listener.onConsume(exclusion);
                    }
                } else {
                    currencyVenueExclusionDao.save(exclusion);
                    listener.onConsume(exclusion);
                }
            }
            return true;
        } catch (Throwable th) {
            LOG.error("There was an exception when saving exclusions to the datafabric.", th);
            return false;
        }
    }

    /**
     * This method consumes CounterpartyCreditUtilisations and saves their
     * transformed state into the datafabric if the value has changed according
     * to its equals method or the datafabric does not have a copy according to its
     * key.
     * @param utilisations
     * @return true if the consumption returned successfully, false if there was an exception.
     */
    @Override
    public boolean consume(CounterpartyCreditUtilisations utilisations) {
        try {
            Collection<CounterpartyCreditUtilisationValue> values = utilisationsBuilder.build(utilisations);
            for(CounterpartyCreditUtilisationValue value : values) {
                if(counterpartyCreditUtilisationValueDao.has(value.getKey())) {
                    CounterpartyCreditUtilisationValue datafabricCopy = counterpartyCreditUtilisationValueDao.findByKey(value.getKey());
                    if(!datafabricCopy.equals(value)) {
                        counterpartyCreditUtilisationValueDao.save(value);
                        listener.onConsume(value);
                    }
                } else {
                    counterpartyCreditUtilisationValueDao.save(value);
                    listener.onConsume(value);
                }
            }
            return true;
        } catch (Throwable th) {
            LOG.error("There was an exception saving counterparty utilisations to datafabric.", th);
            return false;
        }
    }

    /**
     * testing purposes only.
     * @param exclusionsBuilder
     */
    protected void setExclusionsBuilder(Builder<Collection<CurrencyVenueExclusion>, CurrentVenueCurrencyCreditStates> exclusionsBuilder) {
        this.exclusionsBuilder = exclusionsBuilder;
    }

    /**
     * testing purposes only.
     * @param dao
     */
    protected void setCurrencyVenueExclusionDAO(CurrencyVenueExclusionDAO dao) {
        this.currencyVenueExclusionDao = dao;
    }

    /**
     * testing purposes only.
     * @param dao
     */
    public void setCounterpartyCreditUtilisationValueDAO(CounterpartyCreditUtilisationValueDAO dao) {
        this.counterpartyCreditUtilisationValueDao = dao;
    }

    /**
     * testing purposes only.
     * @param utilisationsBuilder
     */
    public void setUtilisationsBuilder(Builder<Collection<CounterpartyCreditUtilisationValue>, CounterpartyCreditUtilisations> utilisationsBuilder) {
        this.utilisationsBuilder = utilisationsBuilder;
    }

    /**
     * Testing purposes only.
     * @param listener
     */
    public void setListener(CreditUtilisationConsumerServiceListener listener) {
        this.listener = listener;
    }
}
