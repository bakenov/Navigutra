#!/bin/bash

source ~/bin/shell-env/daxa009s/.functions

hosts="auq4054s auq4009s"
ssh_all_in_list "$hosts" "find ~/logs -type f -name '*pid*' | xargs rm -f"
ssh_all_in_list "$hosts" "ps -ef | egrep '(java|iaf|corr)' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
