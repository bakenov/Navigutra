package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.adapters.rmds.AbstractTest;
import com.anz.axle.adapters.rmds.ItemBuilder;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.perf.CollectorThread;
import com.anz.axle.perf.FeederThread;
import com.anz.axle.perf.PerformanceCollector;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.ForwardPointsQuotePageKey;
import com.anz.axle.util.ThreadUtils;
import com.anz.markets.adapters.trep.Item;
import org.apache.log4j.Logger;
import org.hamcrest.core.Is;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static com.anz.axle.common.util.LateFormatter.format;
import static org.hamcrest.MatcherAssert.assertThat;


public class RmdsAdapterPerformanceIntegrationTest extends AbstractTest {
    public static final Logger LOG = Logger.getLogger(RmdsAdapterPerformanceIntegrationTest.class);

    @Autowired
    private ForwardPointSubscriber subscriber;


    @Test
    public void shouldPerformWell() {
        LOG.info("Launching saver and collector threads to test performance of rmds adapter...");

        // Create and start datafabric data saver threads
        final FeederThread<Item> feederThread1 = new FeederThread<Item>(new ItemBuilder(1), new FeederThread.Feeder<Item>() {
            @Override
            public void feed(Item entity) {
                subscriber.onUpdate(entity);
            }
        }, 4, ThreadUtils.MINUTE);

        // Create database collector threads
        final CollectorThread<ForwardPointsQuotePage, Item> collectorThread1 = new CollectorThread<ForwardPointsQuotePage, Item>(feederThread1, new CollectorThread.Collector<ForwardPointsQuotePage, Item>() {
            @Override
            public ForwardPointsQuotePage collect(Item item) {
                ForwardPointsQuotePageKey key = new ForwardPointsQuotePageKey(CurrencyPair.toSymbol(item.getValue("GV1_TEXT")),
                        D3ForwardQuote.resolveTenor(item.getName()).getKey());
                return forwardPointsQuotePageDAO.findByKey(key);
            }
        });

        // Start database collector threads
        collectorThread1.start();

        // Start feeding D3 forward points
        feederThread1.start();

        LOG.info("Waiting for all objects to be saved to the database...");

        // Wait until the write behind saves all items
        ThreadUtils.wait(new ThreadUtils.Completable() {
            @Override
            public Result complete() {
                return new Result(
                        collectorThread1.isFinished()
                );
            }
        }, ThreadUtils.FIVE_MINUTES);

        PerformanceCollector.print(LOG);
        float avg = PerformanceCollector.avg("collect." + ForwardPointsQuotePage.class.getSimpleName());
        long max = PerformanceCollector.max("collect." + ForwardPointsQuotePage.class.getSimpleName());
        long count = PerformanceCollector.count("collect." + ForwardPointsQuotePage.class.getSimpleName());
        assertThat(format("Expected at less then 100ms average AWB for [%s] but was [%s]", ForwardPointsQuotePage.class.getSimpleName(), avg).toString(),
                avg < 100, Is.is(true));
        assertThat(format("Expected at less then 200ms max AWB for [%s] but was [%s]", ForwardPointsQuotePage.class.getSimpleName(), max).toString(),
                max < 500, Is.is(true));
        assertThat(format("Expected at exactly %s AWBs for [%s] but was [%s]", feederThread1.getCount(), ForwardPointsQuotePage.class.getSimpleName(), count).toString(),
                count, Is.is(feederThread1.getCount()));
    }
}
