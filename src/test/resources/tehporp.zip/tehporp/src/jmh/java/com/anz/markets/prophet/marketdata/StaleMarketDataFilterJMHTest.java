package com.anz.markets.prophet.marketdata;


import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.marketdata.filter.AbstractStaleMarketDataFilterForBwJmhTest;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;

public class StaleMarketDataFilterJMHTest {

    @State(Scope.Benchmark)
    public static class Data extends AbstractStaleMarketDataFilterForBwJmhTest {

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }

    @Benchmark
    public FilterDecision testPerformFilter(@NotNull final Data data) throws Exception {
        return data.testPerformFilter();
    }
}
