package com.anz.markets.efx.fox.firewall.rule;

import java.util.Objects;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.api.RuleConfigCommandHandler;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;

public class NonPeriodRuleConfigCommandHandler implements RuleConfigCommandHandler {
    private final String firewallName;
    private final ByteValueCache<String> stringsCache = new ByteValueCache<>(AsciiString::toString);


    public NonPeriodRuleConfigCommandHandler(final String firewallName) {
        this.firewallName = Objects.requireNonNull(firewallName);
    }

    @Override
    public void handleCommand(final FirewallConfigDecoder ruleConfig, final CommandContext commandContext) {
        final FirewallConfigDecoder.Body body = ruleConfig.body();
        final String ruleFirewallName = body.firewallName().decodeAndCache(stringsCache);
        if (firewallName.equals(ruleFirewallName)) {
            if (body.limitThreshold() > 0) {
                encodeResponse(commandContext, ruleConfig);
            }
        }
    }

    private void encodeResponse(final CommandContext commandContext, final FirewallConfigDecoder ruleConfigCommand) {
        final FirewallConfigDecoder.Body body = ruleConfigCommand.body();
        commandContext.sorEncoderSupplier().firewallConfigEncoder()
                .messageStart(commandContext.source(), commandContext.idGenerator().getAsLong())
                .firewallName().encodeFrom(body.firewallName())
                .ruleId(body.ruleId())
                .regionPattern().encodeFrom(body.regionPattern())
                .orderTypePattern().encodeFrom(body.orderTypePattern())
                .deskPattern().encodeFrom(body.deskPattern())
                .portfolioPattern().encodeFrom(body.portfolioPattern())
                .usernamePattern().encodeFrom(body.usernamePattern())
                .venuePattern().encodeFrom(body.venuePattern())
                .securityTypePattern().encodeFrom(body.securityTypePattern())
                .tenorPattern().encodeFrom(body.tenorPattern())
                .symbolPattern().encodeFrom(body.symbolPattern())
                .period(body.period())
                .periodUnit().encodeFrom(body.periodUnit())
                .comment().encodeFrom(body.comment())
                .lastEditUsername().encodeFrom(body.lastEditUsername())
                .lastEditTime(body.lastEditTime())
                .limitThreshold(body.limitThreshold()).messageComplete();
    }

}
