package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

/**
 * Encoder for date only without time such as {@link LocalDate}.
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 */
public interface DateEncoder<E> {

    E encodeNull();

    /** Encodes the given date, or null if all arguments are 0*/
    E encode(int year, int month, int day);

    /** Encodes the days-since-epoch value, or null if the value is 0*/
    E encodeEpochDays(long epochDays);

    /** Encodes the given packed value, or null if the value is 0*/
    default E encode(final LocalDatePacking packing, final int packed) {
        return encode(packing.unpackYear(packed), packing.unpackMonth(packed), packing.unpackDay(packed));
    }

    default E encodeNullable(final LocalDate localDate) {
        return localDate != null ? encode(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth()) :
                encodeNull();
    }

    default E encodeFormatted(final CharSequence s, final LocalDateFormat format) {
        return s != null ? encodeFormatted(s, format.getDefaultDecoder()) : encodeNull();
    }

    default E encodeFormatted(final CharSequence s, final LocalDateDecoder decoder) {
        return s != null ? encodeFormatted(s, ByteReader.CHAR_SEQUENCE, 0, decoder) : encodeNull();
    }

    default <S> E encodeFormatted(final S source, final ByteReader<? super S> reader, final LocalDateFormat format) {
        return encodeFormatted(source, reader, 0, format.getDefaultDecoder());
    }

    default <S> E encodeFormatted(final S source, final ByteReader<? super S> reader, final int offset, final LocalDateDecoder decoder) {
        return encode(
                decoder.decodeYear(source, reader, offset),
                decoder.decodeMonth(source, reader, offset),
                decoder.decodeDay(source, reader, offset)
        );
    }

    default E encodeFrom(final DateDecoder localDateDecoder) {
        return encode(localDateDecoder.decodeYear(), localDateDecoder.decodeMonth(), localDateDecoder.decodeDay());
    }

    /** Encodes the milliseconds-since-epoch value, or null if the value is 0*/
    default E encodeEpochMillis(final long epochMillis) {
        return encodeEpochSeconds(epochMillis / Epoch.MILLIS_PER_SECOND);
    }

    /** Encodes the seconds-since-epoch value, or null if the value is 0*/
    default E encodeEpochSeconds(final long epochSeconds) {
        return encodeEpochDays(epochSeconds / Epoch.SECONDS_PER_DAY);
    }
}