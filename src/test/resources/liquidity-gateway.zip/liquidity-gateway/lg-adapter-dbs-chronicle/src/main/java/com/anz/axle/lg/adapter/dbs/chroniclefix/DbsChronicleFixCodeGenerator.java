package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import software.chronicle.fix.codegen.CodeGenerator;
import software.chronicle.fix.codegen.FixType;

public class DbsChronicleFixCodeGenerator {

    public static void main(final String[] args) throws IOException {
        final CodeGenerator cg = new CodeGenerator();
        cg.codePackage("com.anz.axle.lg.adapter.dbs.chroniclefix.generated");
        cg.schemaFile("lg-adapter-dbs-chronicle","src/main/resources/conf/FIX42-dbs.xml");
        cg.codeDirectory("lg-adapter-dbs-chronicle/target/generated-sources");

        // Retain decimal precision when reading floating point.
        cg.includeDecimalPrecision(false);

        // internal representation for datetimes
        cg.internalTimeUnit(TimeUnit.NANOSECONDS);

        cg.backwardCompatible(false);

        // this will cause the MDEntryID field to be bytes ( which has lower latency ) rather than a String
        // TODO: use AsciiString not Bytes
        cg.classOverride(f -> f.name().equals("MDEntryID") || f.name().equals("MDReqID") ? FixType.BYTES : null);
        cg.run();
    }
}