package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;

public interface ParentOrder {
    ParentOrderDetails details();
    void onStart(CommandContext commandContext);
    void onPriceUpdate(CommandContext commandContext);
    void onChildExecutionReport(CommandContext commandContext, ExecutionReportDecoder executionReportDecoder);
    void onChildOrderCancelReject(CommandContext commandContext, OrderCancelRejectDecoder orderCancelRejectDecoder);
    void onParentOrderCancelRequest(CommandContext commandContext, OrderCancelRequestDecoder orderCancelRequestDecoder);

    void applyNewChildOrder(ChildOrder childOrder);
    void applyChildExecutionReport(ExecutionReportDecoder executionReportDecoder);
    void applyChildOrderCancelReject(OrderCancelRejectDecoder orderCancelRejectDecoder);
    void applyParentExecutionReport(EventContext eventContext, ExecutionReportDecoder executionReportDecoder);
    void release();
}
