package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.OrderCancelRequestSbeDecoder;

public class ChildOrderCancelRequestEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChildOrderCancelRequestEvent.class);

    private final ChildOrderRepository childOrderRepository;
    private final StringBuilder stringBuilder = new StringBuilder();
    private final OrderCancelRequestSbeDecoder orderCancelRequestDecoder = new OrderCancelRequestSbeDecoder();

    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    public ChildOrderCancelRequestEvent(final ChildOrderRepository childOrderRepository) {
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if(!orderCancelRequestDecoder.wrap(message)) return false;

        final String marketId = orderCancelRequestDecoder.body().marketId().decodeAndCache(marketIdCache);
        if (!Venue.FOX.name().equals(marketId)) {
            logMessage();

            final long childOrigClOrdId = orderCancelRequestDecoder.body().origClOrdId().decodeLongOrZero();

            if (childOrigClOrdId > 0) {
                final ChildOrder childOrder = childOrderRepository.lookupByClOrdId(childOrigClOrdId);
                if (childOrder != null) {
                    childOrder.applyCancelRequest(orderCancelRequestDecoder);
                }
            }
            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        orderCancelRequestDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying child OCRQ: {}", stringBuilder);
    }
}
