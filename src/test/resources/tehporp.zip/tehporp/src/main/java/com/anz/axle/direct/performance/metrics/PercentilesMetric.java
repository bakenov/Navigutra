package com.anz.axle.direct.performance.metrics;

import java.util.concurrent.atomic.AtomicLongArray;

// Sourced from the excellent com.anz.axle.direct.performance.metrics (SPDEE)

public class PercentilesMetric implements Metric<Percentiles> {

    private final AtomicLongArray buckets;
    private final int maxBucket;
    private final String name;
    private final long minValue;
    private final long maxValue;

    private final BasicMinMaxAverage minMaxAverage;

    public PercentilesMetric(final String name,
                             long minValue,
                             long maxValue) {
        this.name = name;
        this.minValue = minValue;
        this.maxValue = maxValue;
        maxBucket = Index.DecimalThreeDigits.toBucket(maxValue);
        buckets = new AtomicLongArray(maxBucket + 1);
        minMaxAverage = new BasicMinMaxAverage(name);
    }

    @Override
    public void record(final long value) {
        final int i = toIndex(value);
        buckets.incrementAndGet(i);
        minMaxAverage.record(value);
    }

    int toIndex(final long value) {
        return Index.DecimalThreeDigits.toBucket(Math.max(0, Math.min(value - minValue, maxValue)));
    }

    long fromIndex(final int index) {
        return minValue + Index.DecimalThreeDigits.fromBucket(Math.max(0, Math.min(maxBucket, index)));
    }

    @Override
    // Not atomic, but thread-safe.
    public Percentiles snapshot() {
        return new PercentilesSnapshot(PercentilesMetric.this.name, PercentilesMetric.this.minMaxAverage.snapshot(), bucketSnapshot(), minValue, maxValue);
    }

    private long[] bucketSnapshot() {
        final long[] longs = new long[buckets.length()];
        for (int i = 0; i < buckets.length(); i++) {
            longs[i] = buckets.get(i);
        }
        return longs;
    }

    @Override
    public void clear() {
        for (int i = 0; i < buckets.length(); i++) {
            buckets.set(i, 0);
        }
        minMaxAverage.clear();
    }

    @Override
    public String getName() {
        return name;
    }

    private static final class PercentilesSnapshot implements Percentiles {
        private final String name;
        private final BasicStats minMaxAverage;
        private final long[] buckets;
        private final long minValue;
        private final long maxValue;

        private PercentilesSnapshot(final String name,
                                    final BasicStats minMaxAverage,
                                    final long[] buckets,
                                    final long minValue,
                                    final long maxValue) {
            this.name = name;
            this.minMaxAverage = minMaxAverage;
            this.buckets = buckets;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }

        @Override
        public double getPercentile(final double percentile) {
            if (getCount() == 0) {
                return Double.NaN;
            }

            final double quantile = percentile / 100;
            if (quantile <= 0.0) {
                return minMaxAverage.getMin();
            }
            if (quantile >= 1.0) {
                return minMaxAverage.getMax();
            }
            long target = (long) Math.ceil(quantile * getCount());
            for (int i = 0; i < buckets.length; i++) {
                target -= buckets[i];
                if (buckets[i] > 0 && target <= 0) {
                    return minValue + Index.DecimalThreeDigits.fromBucket(i);
                }
            }
            // Should never occur
            return minMaxAverage.getMax();
        }

        @Override
        public double getMin() {
            return minMaxAverage.getMin();
        }

        @Override
        public double getMean() {
            return minMaxAverage.getMean();
        }

        @Override
        public double getMax() {
            return minMaxAverage.getMax();
        }

        @Override
        public long getCount() {
            return minMaxAverage.getCount();
        }

        @Override
        public String getName() {
            return name;
        }
    }
}
