package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;

public interface RuleConfigCommandHandler {
    void handleCommand(FirewallConfigDecoder ruleConfig, CommandContext commandContext);
}
