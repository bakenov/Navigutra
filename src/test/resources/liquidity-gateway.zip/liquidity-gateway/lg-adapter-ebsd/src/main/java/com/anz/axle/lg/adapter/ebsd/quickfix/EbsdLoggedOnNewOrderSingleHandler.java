package com.anz.axle.lg.adapter.ebsd.quickfix;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import quickfix.Message;
import quickfix.field.Account;
import quickfix.field.ClOrdID;
import quickfix.field.Currency;
import quickfix.field.MsgType;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.PartyID;
import quickfix.field.PartyIDSource;
import quickfix.field.Price;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix44.NewOrderSingle;

import com.anz.axle.lg.adapter.quickfix.FixSide;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

import static com.anz.axle.lg.adapter.ebsd.quickfix.FixConstants.MARKET_SEGMENT_ID_DIRECT;
import static com.anz.axle.lg.adapter.ebsd.quickfix.FixConstants.MARKET_SEGMENT_ID_FIELD;
import static com.anz.axle.lg.adapter.ebsd.quickfix.FixConstants.SECURITY_TYPE_FXSPOT;

public final class EbsdLoggedOnNewOrderSingleHandler implements NewOrderSingleHandler {
    private static final boolean INCLUDE_MILLISECONDS = true;
    private final Consumer<Message> fixMessageSender;
    private final NewOrderSingle newOrderSingle = new NewOrderSingle();
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final Map<String, String> symbol7Map = new HashMap<>();
    private final Date transactTime = new Date();
    private final String account;
    private final Map<PartyRole, String> partyIds;

    public EbsdLoggedOnNewOrderSingleHandler(final Consumer<Message> fixMessageSender,
                                             final String account,
                                             final Map<PartyRole, String> partyIds) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.account = Objects.requireNonNull(account);
        this.partyIds = Objects.requireNonNull(partyIds);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.clear();
    }

    @Override
    public void onBody(final Body body) {
        newOrderSingle.getHeader().setString(MsgType.FIELD, MsgType.ORDER_SINGLE);
        newOrderSingle.setString(ClOrdID.FIELD, body.clOrdId().decodeStringOrNull());
        newOrderSingle.setString(Account.FIELD, account);
        newOrderSingle.setString(Symbol.FIELD, symbol7(body));
        newOrderSingle.setString(quickfix.field.SecurityType.FIELD, SECURITY_TYPE_FXSPOT);
        newOrderSingle.setString(MARKET_SEGMENT_ID_FIELD, MARKET_SEGMENT_ID_DIRECT);
        newOrderSingle.setChar(quickfix.field.Side.FIELD, FixSide.side(body.side()));
        newOrderSingle.setChar(OrdType.FIELD, orderType(body.ordType()));
        newOrderSingle.setChar(quickfix.field.TimeInForce.FIELD, timeInForce(body.timeInForce()));
        newOrderSingle.setDouble(OrderQty.FIELD, body.orderQty());
        newOrderSingle.setDouble(Price.FIELD, body.price());
        newOrderSingle.setString(Currency.FIELD, currency(body));
        newOrderSingle.setUtcTimeStamp(TransactTime.FIELD, transactTime(body.transactTime()), INCLUDE_MILLISECONDS);

        partyIds.forEach((partyRole, value) -> {
            final NewOrderSingle.NoPartyIDs noPartyIDs = new NewOrderSingle.NoPartyIDs();
            noPartyIDs.setString(PartyID.FIELD, value);
            noPartyIDs.setChar(PartyIDSource.FIELD, 'D');
            noPartyIDs.setInt(quickfix.field.PartyRole.FIELD, partyRole(partyRole));
            newOrderSingle.addGroup(noPartyIDs);
        });
    }

    private int partyRole(final PartyRole role) {
        switch (role) {
            case EXECUTING_FIRM: return quickfix.field.PartyRole.EXECUTING_FIRM;
            case EXECUTING_TRADER: return quickfix.field.PartyRole.EXECUTING_TRADER;
            default: throw new IllegalArgumentException("Unsupported PartyRole " + role);
        }
    }

    private Date transactTime(long transactTimeNanos) {
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(transactTimeNanos));
        return transactTime;
    }

    private String symbol7(final Body body) {
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        return symbol7Map.computeIfAbsent(symbol, SymbolNormaliser::toSymbol7);
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT: return OrdType.LIMIT;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case DAY: return quickfix.field.TimeInForce.DAY;
            case GTC: return quickfix.field.TimeInForce.GOOD_TILL_CANCEL;
            case IOC: return quickfix.field.TimeInForce.IMMEDIATE_OR_CANCEL;
            case FOK: return quickfix.field.TimeInForce.FILL_OR_KILL;
            case GTD: return quickfix.field.TimeInForce.GOOD_TILL_DATE;
            default: throw new IllegalArgumentException("Unsupported timeInForce" + timeInForce);
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
    }
}
