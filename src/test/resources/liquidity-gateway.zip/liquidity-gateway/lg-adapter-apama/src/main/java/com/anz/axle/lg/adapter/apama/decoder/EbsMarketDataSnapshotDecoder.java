package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.EbsMarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.apama.event.MarketDataSnapshotFullRefresh_MDEntry;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static com.anz.axle.lg.adapter.apama.decoder.EbsMarketDataEntries.hasNoMarket;
import static com.anz.axle.lg.adapter.apama.decoder.FixStringConstants.SENDING_TIME;
import static com.anz.axle.lg.adapter.apama.decoder.MarketDataEntriesEncoder.encodeZeroEntriesForEmptySnapshot;

/**
 * Decodes Apama events as defined by {@link EbsMarketDataSnapshotFullRefresh}
 */
public final class EbsMarketDataSnapshotDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsMarketDataSnapshotDecoder.class);

    private final Function<Event, RequestKey> messageEventToRequestKey;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdSupplier;
    private final SourceSequencer sourceSequencer;

    public EbsMarketDataSnapshotDecoder(final Function<Event, RequestKey> messageEventToRequestKey,
                                        final PricingEncoderLookup pricingEncoderLookup,
                                        final PrecisionClock precisionClock,
                                        final String senderCompId,
                                        final String compId,
                                        final LongSupplier messageIdSupplier,
 final SourceSequencer sourceSequencer) {
        this.messageEventToRequestKey = Objects.requireNonNull(messageEventToRequestKey);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdSupplier = Objects.requireNonNull(messageIdSupplier);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void decode(final Event ebsSnapshot) {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("Apama event received: {}", ebsSnapshot);

        // Only process Price Depth View messages
        if (!EbsMarketDataSnapshotFullRefresh.FIELD_SERVICE_ID.isPriceDepthView(ebsSnapshot)) {
            return;
        }

        final List<Event> mdEntries = ebsSnapshot.getField(EbsMarketDataSnapshotFullRefresh.FIELD_MD_NO_ENTRIES);
        final Map<String, String> payload = ebsSnapshot.getField(EbsMarketDataSnapshotFullRefresh.FIELD_PAYLOAD);
        final long sendingTimeNanos = UtcTimestampConverter.dateTimeToNanos(payload.get(SENDING_TIME));

        final RequestKey requestKey = messageEventToRequestKey.apply(ebsSnapshot);
        if (requestKey == null) {
            //invalid symbol, skit the event
            return;
        }
        final PricingEncoderSupplier encoderSupplier = pricingEncoderLookup.lookup(requestKey);
        final long messageId = messageIdSupplier.getAsLong();
        if (hasNoMarket(requestKey, mdEntries, 0, MdEntries.BID_OR_ASK_MATCHING_ALL)) {
            encodeZeroEntriesForEmptySnapshot(encoderSupplier, Flag.NO_MARKET, requestKey, sendingTimeNanos,
                    receivingTimeNanos, senderCompId, compId, messageId, precisionClock, sourceSequencer);
        } else {
            final int entriesCnt = MdEntries.count(requestKey, mdEntries, 0, MdEntries.BID_OR_ASK_MATCHING_ALL);
            if (entriesCnt > 0) {
                final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_next = encoderSupplier.snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                        .senderCompId().encode(compId)
                        .messageId(messageId)
                        .possResend(false)
                        .sendingTime(sendingTimeNanos)
                        .instrumentId(requestKey.instrumentKey().instrumentId())
                        .marketId(requestKey.market())
                        .tradeDate().encodeNull()
                        .settlDate().encodeNull()
                        .referenceSpotDate().encodeNull()
                        .entriesStart(entriesCnt);

                for (int i = 0; i < mdEntries.size(); i++) {
                    final Event mdEntry = mdEntries.get(i);
                    if (MdEntries.BID_OR_ASK_MATCHING_ALL.test(requestKey, mdEntry)) {
                        final double entryPx = mdEntry.getField(MarketDataSnapshotFullRefresh_MDEntry.FIELD_MD_ENTRY_PX);
                        final double entrySize = mdEntry.getField(MarketDataSnapshotFullRefresh_MDEntry.FIELD_MD_ENTRY_SIZE);
                        final EntryType side = MarketDataSnapshotFullRefresh_MDEntry.FIELD_MD_ENTRY_TYPE.getSide(mdEntry);

                        mdEntries_next.next()
                                .transactTime(sendingTimeNanos)
                                .mdMkt(requestKey.market())
                                .mdEntryType(side)
                                .mdEntryPx(entryPx)
                                .mdEntrySize(entrySize)
                                .minQty(entrySize)
                                .mdEntryId(0)
                                .quoteEntryId(0);
                    }
                }
                mdEntries_next.entriesComplete()
                        .hopsStart(2)
                            .next()
                                .hopCompId().encode(senderCompId)
                                .hopMessageId(messageId)
                                .hopReceivingTime(0)
                                .hopSendingTime(sendingTimeNanos)
                            .next()
                                .hopCompId().encode(compId)
                                .hopMessageId(messageId)
                                .hopReceivingTime(receivingTimeNanos)
                                .hopSendingTime(precisionClock.nanos())
                            .hopsComplete()
                        .messageComplete();
            }
        }
    }

}