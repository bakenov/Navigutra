package com.anz.markets.efx.ngaro.codec;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link CachingStringDecoder}
 */
public class CachingStringDecoderTest {

    @Test
    public void decodeFixedString() throws Exception {
        //given
        final String stringValue = "Hello World";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);
        final CachingStringDecoder sharedCacheDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cachingStringDecoder.getCache());

        //when
        final String decoded = cachingStringDecoder.decodeStringOrNull();

        //then
        assertEquals("decoded string should be equal", stringValue, decoded);
        assertNotSame("decoded string should not be same instance as source value", stringValue, decoded);

        //when
        final String second = cachingStringDecoder.decodeStringOrNull();

        //then
        assertSame("second decoded string should be same instance as first decoced", decoded, second);
        assertFalse("shared cache should not be empty", sharedCacheDecoder.getCache().getCacheSize() == 0);
    }

    @Test
    public void decodeFixedStringViaCache() throws Exception {
        //given
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);


        final String stringValue = "Hello World";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        final String decoded = cachingStringDecoder.decodeAndCache(cache);

        //then
        assertEquals("decoded string should be equal", stringValue, decoded);
        assertNotSame("decoded string should not be same instance as source value", stringValue, decoded);

        //when
        final String second = cachingStringDecoder.decodeAndCache(cache);

        //then
        assertSame("second decoded string should be same instance as first decoced", decoded, second);
        assertFalse("shared cache should not be empty", cache.getCacheSize() == 0);
    }

    @Test
    public void decodeFixedStringViaCache_whenEmpty() throws Exception {
        //given
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);


        final String stringValue = "";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        final String decoded = cachingStringDecoder.decodeAndCache(cache);

        //then
        assertEquals("decoded string should be equal", null, decoded);
        assertTrue("shared cache should not be empty", cache.getCacheSize() == 0);
    }

    @Test
    public void decodeTo() throws Exception {
        //given
        final String stringValue = "Hello World";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        final int offset = 7;
        final int maxLength = "Hello".length();
        final StringBuilder target1 = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        final StringBuilder target2 = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        final StringBuilder target3 = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        final StringBuilder target4 = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        cachingStringDecoder.decodeTo(target1, ByteWriter.STRING_BUILDER);
        cachingStringDecoder.decodeTo(target2);
        cachingStringDecoder.decodeTo(target3, ByteWriter.STRING_BUILDER, offset, maxLength);
        cachingStringDecoder.decodeTo(target4, maxLength);

        //then
        assertEquals("target1 should be equal", "Hello WorldLMNOPQRSTUVWXYZ", target1.toString());
        assertEquals("target2 should be equal", "ABCDEFGHIJKLMNOPQRSTUVWXYZHello World", target2.toString());
        assertEquals("target3 should be equal", "ABCDEFGHelloMNOPQRSTUVWXYZ", target3.toString());
        assertEquals("target4 should be equal", "ABCDEFGHIJKLMNOPQRSTUVWXYZHello", target4.toString());
        assertEquals("cache should still be empty", 0, cachingStringDecoder.getCache().getCacheSize());
    }

    @Test
    public void decodeToNull() throws Exception {
        //given
        final String stringValue = "Hello World";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        final int decodedLength = cachingStringDecoder.decodeToNull();

        //then
        assertEquals("decoded string length be equal", stringValue.length(), decodedLength);
        assertEquals("cache should still be empty", 0, cachingStringDecoder.getCache().getCacheSize());
    }

    @Test
    public void cache() throws Exception {
        //given
        final String stringValue = "Hello World";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        final String preCached = stringValue.substring(0, 5) + stringValue.substring(5);
        cachingStringDecoder.cache(preCached);

        //then
        assertNotSame("should not be same instance", stringValue, preCached);
        assertEquals("decoded string should be same instance as pre-cached string", preCached, cachingStringDecoder.decodeStringOrNull());
    }

    @Test
    public void getCache() throws Exception {
        //given
        final String stringValue = "Hello World";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        final ByteValueCache<String> cache = cachingStringDecoder.getCache();

        //then
        assertNotNull("cache should not be null", cache);
        assertEquals("cache should be empty", 0, cache.getCacheSize());
    }

    @Test
    public void decodeLong() throws Exception {
        //given
        final String stringValue = "345454323";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        assertEquals(cachingStringDecoder.decodeLongOrZero(), 345454323);
    }

    @Test
    public void decodeLongFromEmptyString() throws Exception {
        //given
        final String stringValue = "";
        final int cacheSize = 32;
        final CachingStringDecoder cachingStringDecoder = new CachingStringDecoder(AsciiStringDecoder.forString(stringValue), stringValue.length(), cacheSize);

        //when
        assertEquals(cachingStringDecoder.decodeLongOrZero(), 0);
    }

}