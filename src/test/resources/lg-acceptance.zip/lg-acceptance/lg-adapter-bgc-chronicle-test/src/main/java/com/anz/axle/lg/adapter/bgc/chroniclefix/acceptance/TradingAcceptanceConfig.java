package com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceConfig;
import com.anz.axle.lg.adapter.bgc.chroniclefix.ServerConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({ServerConfig.class, SharedAcceptanceConfig.class})
public class TradingAcceptanceConfig {
}