#!/bin/bash
source ~/axle/environment/shell/axle.rc

DATE_TODAY=`date +%Y%m%d`
DATE_NOW=`date +%Y%m%d_%H%M%S`

echo "*********************************************"
echo "POST ARCHIVE CLEAN UP $DATE_NOW"
echo "*********************************************"

if [ -d $HOME/apama/bin/ ]
then
    . $HOME/apama/bin/apama_env
fi

PATH=$PATH:/opt/csw/bin
export PATH

AXLE=$HOME/axle
ARCHIVE=$HOME/archive
ARCHIVE_LOGS=$ARCHIVE/logs

cd $ARCHIVE_LOGS

if [ ! `pwd` = $ARCHIVE_LOGS ]
then
    echo "UNSAFE execution. Was not in $ARCHIVE_LOGS, not running"
    exit 0
fi

# Remove old archive logs
echo "Removing archive logs  ..."
count=`find . -type d -mtime +$ARCHIVE_RETENTION_DAYS | wc -l | sed 's/^ *//'`
echo "There is $count directories(s) that are $ARCHIVE_RETENTION_DAYS days old in directory $ARCHIVE_LOGS"
if [ $count -gt 0 ]
then
        find . -type d -mtime +$ARCHIVE_RETENTION_DAYS -print
        find . -type d -mtime +$ARCHIVE_RETENTION_DAYS | xargs rm -rf
else
        echo "Do Nothing ..."
fi

# Remove old archive logs (replays)
echo "Removing replays archive logs ..."
count=`find . -type f -name correlator-replay* -mtime +14 | wc -l | sed 's/^ *//'`
echo "There is $count item(s) that are 14 days old in directory $ARCHIVE_LOGS"
if [ $count -gt 0 ]
then
        find . -type f -name correlator-replay* -mtime +14 -print
        find . -type f -name correlator-replay* -mtime +14 | xargs rm
else
        echo "Do nothing ..."
fi

# Remove empty log directories
for DIR in `find . -type d -print`
do
	if [ 0 -eq `ls -A $DIR | wc -l` ]
	then
		echo "Removing empty directory: $DIR "
		rm -r $DIR
	fi
done

# Compress files in 'previous' directory
if [[ -d $ARCHIVE_LOGS/previous ]] && [[ "${ARCHIVE_RETENTION_COMPRESSED:-no}" = yes ]]
then
    echo "compressing last weeks log files"
    FIND_COMMAND="find $ARCHIVE_LOGS/previous -type f -mtime -$ARCHIVE_RETENTION_DAYS | egrep -v '\.gz$'"
    echo "finding files to compress using command: $FIND_COMMAND"
    if [ -f ~/bin/parallel ]; then
        echo "parallel command found, using it to gzip files..."
        eval $FIND_COMMAND | ~/bin/parallel --no-notice gzip -9 "{}"
    else
        echo 'parallel command not found, if running on a Linux box, please ensure that its installed - usually at ~/bin/parallel - that it is on the path, and that it has execute permissions...'
        eval $FIND_COMMAND | xargs -r gzip -9
    fi
fi