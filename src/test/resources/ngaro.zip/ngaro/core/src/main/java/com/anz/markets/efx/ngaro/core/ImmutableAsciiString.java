package com.anz.markets.efx.ngaro.core;

import java.util.Objects;

public final class ImmutableAsciiString implements AsciiString {

    private final byte[] value;

    /**
     * Constructor, does NOT clone the byte array!
     * @param bytes the bytes underlying the newly created string, NOT cloned!
     */
    ImmutableAsciiString(final byte[] bytes) {
        this.value = Objects.requireNonNull(bytes);
    }

    /**
     * Constructor based on a char sequence
     * @param s the string containing the ascii characters
     */
    public ImmutableAsciiString(final String s) {
        this((CharSequence)s);
    }
    /**
     * Constructor based on a char sequence
     * @param charSequence the character sequence containing the ascii characters
     */
    public ImmutableAsciiString(final CharSequence charSequence) {
        this(toBytes(charSequence));
    }

    @Override
    public int length() {
        return value.length;
    }

    @Override
    public byte get(final int index) {
        return value[index];
    }

    /**
     * Copies the characters of this ascii string into target using the given writer; the first character is placed into
     * {@code target[offset]}.
     *
     * @param target    the target to write to
     * @param writer    the writer writing to target
     * @param offset    the target start position
     * @param maxLength
     * @param <T>
     * @return
     */
    @Override
    public <T> int get(final T target, final ByteWriter<? super T> writer, final int offset, final int maxLength) {
        final int copyLen = Math.min(length(), maxLength);
        Bytes.copy(value, ByteReader.BYTE_ARRAY, 0, target, writer, offset, copyLen);
        return copyLen;
    }

    @Override
    public int hashCode() {
        return AsciiString.hashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
        return equals(this, obj);
    }

    static boolean equals(final AsciiString self, final Object other) {
        if (other == null) return false;
        if (other == self) return true;
        if (other instanceof AsciiString) {
            return 0 == AsciiString.compare(self, (AsciiString)other);
        }
        return false;
    }

    @Override
    @Garbage(Garbage.Type.RESULT)
    public String toString() {
        return new String(value);
    }

    private static byte[] toBytes(final CharSequence charSequence) {
        int len;
        for (len = 0; len < charSequence.length(); len++) {
            if (charSequence.charAt(len) == NULL) {
                break;
            }
        }
        final byte[] bytes = new byte[len];
        for (int i = 0; i < len; i++) {
            bytes[i] = (byte)charSequence.charAt(i);
        }
        return bytes;
    }
}
