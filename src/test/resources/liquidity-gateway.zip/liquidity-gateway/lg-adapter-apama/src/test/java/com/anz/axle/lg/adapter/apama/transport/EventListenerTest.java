package com.anz.axle.lg.adapter.apama.transport;

import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.event.Event;

@RunWith(MockitoJUnitRunner.class)
public class EventListenerTest {

    @Mock
    private Consumer<Event> eventConsumer;

    @Mock
    private Event event;

    private EventListener eventListener;

    @Before
    public void setUp() throws Exception {
        eventListener = new EventListener(eventConsumer);
    }

    @Test
    public void handleEvent() throws Exception {
        //when
        eventListener.handleEvent(event);

        //then
        eventConsumer.accept(event);
    }

    @Test
    public void handleEvents() throws Exception {
        //when
        eventListener.handleEvents( new Event[] {event});

        //then
        eventConsumer.accept(event);

    }

}