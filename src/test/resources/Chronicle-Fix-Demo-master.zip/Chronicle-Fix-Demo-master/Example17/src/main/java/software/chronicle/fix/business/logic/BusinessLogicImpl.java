package software.chronicle.fix.business.logic;

import net.openhft.chronicle.bytes.MethodReader;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import software.chronicle.generated.code.fields.OrdStatus;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.NewOrderSingle;
import software.chronicle.generated.code.messages.datamodel.DefaultExecutionReport;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * This could be run in its own thread or own process.
 */
public class BusinessLogicImpl implements BusinessLogic {
    private BusinessLogic out;
    private final ExecutionReport executionReport = new DefaultExecutionReport();
    private AtomicBoolean stopped = new AtomicBoolean(false);

    public BusinessLogicImpl() {
        final SingleChronicleQueue inQ = SingleChronicleQueueBuilder.binary("fix-to-business-logic").build();
        final SingleChronicleQueue outQ = SingleChronicleQueueBuilder.binary("business-logic-to-fix").build();

        out = outQ.acquireAppender().methodWriter(BusinessLogic.class);

        ExcerptTailer tailer = inQ.createTailer();
        MethodReader methodReader = tailer.methodReader(this);

        for(;;) {
            methodReader.readOne();
        }
    }

    @Override
    public void onExecutionReport(final ExecutionReport executionReport) {
        throw new UnsupportedOperationException("todo");
    }

    @Override
    public void onNewOrderSingle(final NewOrderSingle newOrderSingle) {

        // this is where you will do your Business logic

        executionReport.reset();
        executionReport.avgPx(12.0);
        executionReport.clOrdID(newOrderSingle.clOrdID());
        executionReport.ordStatus(OrdStatus.NEW);
        executionReport.side('1');

        out.onExecutionReport(executionReport);
    }
}
