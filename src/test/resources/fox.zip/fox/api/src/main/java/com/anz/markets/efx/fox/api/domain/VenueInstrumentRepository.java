package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface VenueInstrumentRepository {
    VenueInstrument lookup(Venue venueId, long instrumentId);
    VenueInstrument lookup(RequestKey requestKey);
    VenueInstrument apply(VenueInstrumentConfigDecoder venueInstrumentConfigDecoder);
}