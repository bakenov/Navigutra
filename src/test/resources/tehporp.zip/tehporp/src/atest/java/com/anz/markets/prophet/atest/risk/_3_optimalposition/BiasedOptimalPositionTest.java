package com.anz.markets.prophet.atest.risk._3_optimalposition;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import org.junit.Test;
import java.util.EnumSet;

import static org.hamcrest.MatcherAssert.assertThat;

/**
 * AXPROPHET-964  Biased position per currency
 * new Biased positions will be relative to the Bias offset
 * Biased positions will also generate Biased Optimal Positions
 */
@Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
@RestartBeforeTest(reason = "OP remember positions")
public class BiasedOptimalPositionTest extends BaseAcceptanceSpecification {

    private static final EnumSet<Instrument> OPTIMAL_POSITION_INSTRUMENTS = EnumSet.of(
            Instrument.AUDJPY,
            Instrument.AUDNZD,
            Instrument.AUDUSD,
            Instrument.EURAUD,
            Instrument.EURCHF,
            Instrument.EURCZK,
            Instrument.EURDKK,
            Instrument.EURGBP,
            Instrument.EURHUF,
            Instrument.EURJPY,
            Instrument.EURNOK,
            Instrument.EURPLN,
            Instrument.EURSEK,
            Instrument.EURUSD,
            Instrument.GBPJPY,
            Instrument.GBPUSD,
            Instrument.NZDUSD,
            Instrument.USDCAD,
            Instrument.USDCHF,
            Instrument.USDCNH,
            Instrument.USDHKD,
            Instrument.USDILS,
            Instrument.USDJPY,
            Instrument.USDMXN,
            Instrument.USDSGD,
            Instrument.USDTHB,
            Instrument.USDTRY,
            Instrument.USDZAR
    );

    @Test
    @DisplayName("Calculate biased Op Position AUD")
    public void calculate_biased_op_position_AUD() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75)); // Trigger : position created
        }
        then:
        // since no bias, biased optimal positions are the same
        {
            final OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPositions biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();

            assertThat(optimalPositionsUpdates, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1_000_000, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 0.0, -94063.46248900656, -94063.46248900656, 0.0, 0.0, -0.005282478906068361, Double.NaN)));

            assertThat(biasOptimalPositionsUpdates, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1_000_000, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 0.0, -94063.46248900656, -94063.46248900656, 0.0, 0.0, -0.005282478906068361, Double.NaN)));
        }
        when:
        // Send positive biased offset
        // Biased AUD position will be zero
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, 1_000_000));
        }
        then:
        {
            prophet.notExpect(OptimalPositions.class, isOptimalPositionType(OptimalPositionType.PRICING));
            final OptimalPositions biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();

            assertThat(biasOptimalPositionsUpdates, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            // biased optimal positions are different
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.75)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.NaN)));
        }
        when:
        // Send negative biased offset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, -2_000_000));
        }
        then:
        {
            prophet.notExpect(OptimalPositions.class, isOptimalPositionType(OptimalPositionType.PRICING));
            final OptimalPositions biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();

            assertThat(biasOptimalPositionsUpdates, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 3_000_000, 3_000_000, 2_250_000, 4_500_000, 3_375_000, 0.1492038166887317, 0.75)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 162694.23116457928, 162694.23116457928, 0.0, 0.0, 0.022622843272959443, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 124726.04187577748, 124726.04187577748, 0.0, 0.0, 0.017340364366891084, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 929433.247253015, 929433.247253015, 0.0, 0.0, 0.07034788870688735, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 0.0, -282190.38746701967, -282190.38746701967, 0.0, 0.0, -0.005282478906068361, Double.NaN)));
        }
    }

    @Test
    @DisplayName("Calculate biased Op Position JPY")
    public void calculate_biased_op_position_JPY() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
        }
        when:
        // start with positive biased JPY offset
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.04));

            prophet.receive(tdd.biasPosition(Currency.JPY, 80_000_000));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, 1_000_000, 88.500)); // Trigger : position created
        }
        then:
        {
            final OptimalPositions biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();

            assertThat(biasOptimalPositionsUpdates, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 0.0, -89877.96071399016, -67408.47053549263, 0.0, 0.0, -0.009942342066612861, 0.75)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, -128320.51989868573, -128320.51989868573, 0.0, 0.0, -0.03968697123999922, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 128018.12803235496, 128018.12803235496, 0.0, 0.0, 0.039586705835529805, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, -68299.47354806906, -68299.47354806906, 0.0, 0.0, -0.011498125200456462, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 1903954.802259887, 1903954.802259887, 1903954.8022598869, 2855932.203389831, 2855932.203389831, 0.07927367707552903, 88.5)));
        }
        when:
        // send negative biased JPY offset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.JPY, -160_000_000));
        }
        then:
        {
            final OptimalPositions biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();

            assertThat(biasOptimalPositionsUpdates, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 0.0, 38138.125762909774, 28603.59432218233, 0.0, 0.0, 0.009942342066612861, 0.75)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 54450.54701932361, 54450.54701932361, 0.0, 0.0, 0.03968697123999922, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, -54322.232369812344, -54322.232369812344, 0.0, 0.0, -0.039586705835529805, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 28981.675719210307, 28981.675719210307, 0.0, 0.0, 0.011498125200456462, 1.0)));
            assertThat(biasOptimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, -807909.604519774, -807909.604519774, -807909.604519774, -1211864.4067796608, -1211864.4067796608, -0.07927367707552903, 88.5)));
        }
    }
}
