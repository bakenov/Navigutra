package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.conflate.PeriodicFlushingCache;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.marketdata.MarketSnapshotManager;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.ActivationProcessor;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.util.function.Consumer;

/**
 * Copied from ConsumerConfig and cut down
 */
@Configuration
@PropertySources({
        @PropertySource(value = "classpath:conf/core-conflate.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class ConsumerConflateConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ConsumerConflateConfig.class);

    @Autowired
    private Environment env;

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    // business functionality entry points - the below are wired in to ChronicleReaders
    @Bean
    public Consumer<TradingTimeZoneChime> tradingTimeZoneConsumer(final MarketSnapshotManager marketSnapshotManager,
                                                                  final PeriodicFlushingCache<MarketData> marketSnapshotManagerFMDS,
                                                                  final PeriodicFlushingCache<ClientPrice> clientPriceCache) {
        return new NotifierDefault<>(marketSnapshotManager.consumerOfTradingTimeZone(),
                marketSnapshotManagerFMDS.consumerOfTradingTimeZone(), clientPriceCache.consumerOfTradingTimeZone());
    }

    @Bean
    public Consumer<Activate> activateConsumers(final ActivationProcessor activationProcessor) {
        return activationProcessor;
    }

    @Bean
    public Consumer<MarketData> marketDataConsumers(final MarketSnapshotManager marketSnapshotManager) {
        return marketSnapshotManager.consumerOfMarketData();
    }

    @Bean
    public Consumer<MarketData> marketDataConsumersFMDS(
            final PeriodicFlushingCache<MarketData> marketSnapshotManagerFMDS) {
        return marketSnapshotManagerFMDS.consumer();
    }

    @Bean
    public Consumer<ClientPrice> clientPriceConsumer(final PeriodicFlushingCache<ClientPrice> clientPriceCache) {
        return clientPriceCache.consumer();
    }

    @Bean
    public ActivationProcessor activationProcessor(@Value("${core.instance:0}") final int coreInstance,
                                                   @Qualifier("activateSink") final Consumer<Activate> activateSink) {
        return new ActivationProcessor(new NotifierDefault<>(activateSink), coreInstance);
    }

    // RawSnapshots
    @Bean
    public MarketSnapshotManager marketSnapshotManager(
            @Value("${conflate.flush.every:10000}") final int flushEvery,
            @Qualifier("marketDataSink") final Consumer<MarketData> marketDataSink) {
        return new MarketSnapshotManager(marketDataSink, flushEvery);
    }

    @Bean
    public PeriodicFlushingCache<MarketData> marketSnapshotManagerFMDS(
            @Value("${conflate.flush.every:10000}") final int flushEvery,
            @Qualifier("midRateSink") final Consumer<MidRate> midRateSink) {
        final Consumer<MarketData> adaptedMidRateSink = marketData -> midRateSink.accept((MidRate) marketData);
        return new PeriodicFlushingCache<>(adaptedMidRateSink, FilteredMarketDataSnapshotImpl::forMarket, flushEvery);
    }

    @Bean
    public PeriodicFlushingCache<ClientPrice> clientPriceCacher(
            @Value("${conflate.flush.every:10000}") final int flushEvery,
            @Qualifier("clientPriceSink") final Consumer<ClientPrice> clientPriceSink) {
        return new PeriodicFlushingCache<>(clientPriceSink, ClientPriceImpl::new, flushEvery);
    }
}
