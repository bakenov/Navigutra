package com.anz.axle.adapters.ndf2trep.acceptance;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import com.anz.markets.adapters.trep.Item;

public class TestMessageProcessor implements MessageProcessor<Item> {

    private LinkedBlockingQueue<Item> queue = new LinkedBlockingQueue<Item>();

    @Override
    public void process(Item payload, String description) {
        queue.offer(payload);
    }

    public Item getLatestRateForRIC() throws InterruptedException {
        return queue.poll(5, TimeUnit.SECONDS);
    }

    public void clear() {
        queue.clear();
    }
}
