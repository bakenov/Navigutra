package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class TriangulationTest_DirectDirect_CHFJPY extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_6)
    @DisplayName("Triangulation of cross pair from DIRECT-DIRECT driver pairs: CHFJPY")
    public void given_indirect_direct_driver_pairs_triangulate_cross_pair() throws Exception {
        setup:
        {
            // Risk Skew not applied since 0 equiv position
            // NOP Skew not applied since NOP is 0
            // Overall Skew is 0

            // No News Events
            // Since no further price updates, Volatility is 0
            // Since no further price updates, Market Gap Factor not applicable
            // Since Equiv Pos is 0, Risk Adjusted Factor Not Applicable
            // i.e MODEL SPREAD == BASE SPREAD
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                            ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 20),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 25),

                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            // receive driver pair a
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 0.96376, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.963720, 0.963800));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.963705, 0.963815));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.963660, 0.963860));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.963630, 0.963890));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.963510, 0.964010));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.963410, 0.964110));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.962660, 0.964860));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.961260, 0.966260));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.961510, 0.966010));
        }
        when:
        {
            // receive driver pair b
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 101.005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDJPY)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 101.003500, 101.006500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 101.002000, 101.008000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 101.001250, 101.008750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 101.000000, 101.010000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 100.993500, 101.016500));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 100.988500, 101.021500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 100.970000, 101.039000));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 100.957500, 101.052500));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 100.930000, 101.080000));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.CHFJPY)).getFirst();
            // not enough quantity to make up to the same depth as the direct pairs.
            assertThat(clientPrice.getBids().size(), is(8));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 104.797041706655, 104.809085064932));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 104.793661964976, 104.812466040319));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 104.787886951069, 104.818243910014));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 104.782310740191, 104.823829490217));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 104.762216724373, 104.843946183918));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 104.733475015516, 104.872897063865));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 104.630125037494, 104.976995507575));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 104.482546645540, 105.125233023480));
        }
    }


}
