package com.anz.markets.prophet.pricer.wholesale;


import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;

public class EconomicsNewsSpreadStrategyJMHTest {

    @State(Scope.Benchmark)
    public static class Data extends AbstractEconomicsNewsSpreadStrategyForBwJmhTest {

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }

    @Benchmark
    public double testProcessingWholsaleBook(@NotNull final Data data) throws Exception {
        return data.testAcceptWholesaleBook();
    }
}
