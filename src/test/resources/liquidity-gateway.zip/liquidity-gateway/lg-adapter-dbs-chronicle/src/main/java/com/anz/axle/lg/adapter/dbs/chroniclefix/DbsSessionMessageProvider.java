package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.nio.ByteBuffer;
import java.util.Objects;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.fields.EncryptMethod;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.VanillaSessionMessageProvider;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.datamodel.DefaultLogon;

public class DbsSessionMessageProvider extends VanillaSessionMessageProvider {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbsSessionMessageProvider.class);
    private boolean firstTime = true;

    private FixSessionCfg fixSessionCfg;
    final boolean onceOffResetSeqNumber;

    public DbsSessionMessageProvider(final String name,
                                     final boolean onceOffResetSeqNumber,
                                     final FixSessionCfg fixSessionCfg) {
        this.onceOffResetSeqNumber = onceOffResetSeqNumber;
        if (onceOffResetSeqNumber) {
            this.fixSessionCfg = Objects.requireNonNull(fixSessionCfg);
        }

        LOGGER.info("{} - Once-off sequence reset is {}", Objects.requireNonNull(name), onceOffResetSeqNumber ? "enabled" : "disabled");
    }

    @Override
    public Logon getLogon(@NotNull final Bytes<ByteBuffer> bytes, @NotNull final FixSessionContext context, @NotNull final SessionID sessionID, final long heartbeatInterval, final char resetSeqNumFlag) {

        final Logon logon = new DefaultLogon();

        logon.encryptMethod(EncryptMethod.NONE_OTHER);
        logon.heartBtInt(heartbeatInterval);

        if (onceOffResetSeqNumber) {
            onceOffResetSeqNumber(logon, resetSeqNumFlag);
        }
        return logon;
    }

    private void onceOffResetSeqNumber(final Logon logon, final char resetSeqNumFlag) {
        if (firstTime) {
            logon.resetSeqNumFlag( 'Y');
            fixSessionCfg.msgSequenceHandler().resetToInitialState();
            firstTime = false;
        } else {
            if (resetSeqNumFlag != FixMessage.UNSET_CHAR) {
                logon.resetSeqNumFlag(resetSeqNumFlag);
            }
        }
    }
}
