#!/bin/bash


die () {
        echo >&2 "$@"
        exit 1
}

[ "$#" -ge 1 ] || die "1 argument required, $# provided.  Usage wait-for-algo-unit-test-to-complete.sh <full-test-path>"

UNIT_TEST_COMPLETE_PATH=$1
SEARCH_FOR="$UNIT_TEST_COMPLETE_PATH:: COMPLETE"
echo "Searching for $SEARCH_FOR"
COUNT=0
while [ $COUNT -lt 30 ] && [ -z $UNIT_TEST_COMPLETE ]
do 
	LOG_FILE_CONTENT=`ssh AxlSv@daxa003z "cat ~/axle/fxagg-core/logs/log-MsUnit.log"`
	[[ $LOG_FILE_CONTENT == *$SEARCH_FOR* ]] && UNIT_TEST_COMPLETE=true
	COUNT=$[$COUNT+1]
done

if [ -z $UNIT_TEST_COMPLETE ];then
    echo "TIMED OUT WAITING FOR UNIT TEST TO COMPLETE"
    exit 1;
else
    echo "UNIT TEST COMPLETE"
    exit 0;
fi
