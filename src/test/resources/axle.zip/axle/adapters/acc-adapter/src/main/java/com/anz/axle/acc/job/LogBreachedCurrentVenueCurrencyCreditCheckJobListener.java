package com.anz.axle.acc.job;

import com.anz.axle.common.domain.CurrentVenueCurrencyCreditState;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("logBreachedCurrentVenueCurrencyCreditCheckJobListener")
public class LogBreachedCurrentVenueCurrencyCreditCheckJobListener implements CurrentVenueCurrencyCreditCheckJobListener {
    private static final Logger LOG = Logger.getLogger(CurrentVenueCurrencyCreditCheckJob.class);
    @Override
    public void listen(CurrentVenueCurrencyCreditStates states) {
        for(CurrentVenueCurrencyCreditState state : states.findAll()) {
            if(state.getIsBreached()) {
                LOG.info("Breach detected: " + state.toString());
            }
        }
    }
}
