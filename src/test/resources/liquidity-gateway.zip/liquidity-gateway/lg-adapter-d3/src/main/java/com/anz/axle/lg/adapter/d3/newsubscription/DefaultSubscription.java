package com.anz.axle.lg.adapter.d3.newsubscription;

import java.io.IOException;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.StreamingException;
import de.digitec.d3.pricing.streaming.StreamingService;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.ngaro.log.DateTimeFormatter;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalTimeFormat;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;

public final class DefaultSubscription implements Subscription {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultSubscription.class);
    private static final Set<Flag> LOGGED_OFF_FLAGS = EnumSet.of(Flag.LOGGED_OFF);
    private static final Set<Flag> MISSED_HEATBEAT_FLAGS = EnumSet.of(Flag.MISSED_HEARTBEAT);
    private static final Set<Flag> STOPPED_FLAGS = EnumSet.of(Flag.STOPPED);
    private static final Set<Flag> EMPTY_FLAGS = EnumSet.noneOf(Flag.class);

    private final String d3Symbol;
    private final LongSupplier subscriptionIdGenerator;
    private final UpdateProcessor delegateUpdateProcessor;
    private final SubscriptionRegistry.Registerer registerer;
    private final SubscriptionRegistry.Unregisterer unregisterer;
    private final Queue.Appender<Runnable> requestsAppender;
    private final Queue.Appender<Runnable> acknowledgeAppender;
    private final StreamingService streamingService;
    private final PrecisionClock precisionClock;
    private final Snapshotter snapshotter;
    private final long retrySubscriptionMillis;

    private final UnsubscribedState unsubscribedState;
    private final SubscribeRequestedState subscribeRequestedState;
    private final SubscribedState subscribedState;
    private final RetryState retryState;
    private final UnsubscribeRequestedState unsubscribeRequestedState;
    private final ResubscribeRequestedState resubscribeRequestedState;

    private final Runnable subscribeAcknowledgement;
    private final DateTimeFormatter dateTimeFormatter = new DateTimeFormatter(LocalDateFormat.DD_MM_YYYY, LocalTimeFormat.HH_MM_SS_MMM);

    private State currentState;
    private long currentSubscriptionId;
    private long expireTimeMillis = 0;
    private String currentError;
    private long nextRetryEpochTimeMillis = 0;

    public DefaultSubscription(final String d3Symbol,
                               final LongSupplier subscriptionIdGenerator,
                               final UpdateProcessor delegateUpdateProcessor,
                               final SubscriptionRegistry.Registerer registerer,
                               final SubscriptionRegistry.Unregisterer unregisterer,
                               final Queue.Appender<Runnable> requestsAppender,
                               final Queue.Appender<Runnable> acknowledgeAppender,
                               final StreamingService streamingService,
                               final PrecisionClock precisionClock,
                               final Snapshotter snapshotter,
                               final long retrySubscriptionMillis) {
        this.d3Symbol = Objects.requireNonNull(d3Symbol);
        this.subscriptionIdGenerator = Objects.requireNonNull(subscriptionIdGenerator);
        this.delegateUpdateProcessor = Objects.requireNonNull(delegateUpdateProcessor);
        this.registerer = Objects.requireNonNull(registerer);
        this.unregisterer = Objects.requireNonNull(unregisterer);
        this.requestsAppender = Objects.requireNonNull(requestsAppender);
        this.acknowledgeAppender = Objects.requireNonNull(acknowledgeAppender);
        this.streamingService = Objects.requireNonNull(streamingService);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.retrySubscriptionMillis = retrySubscriptionMillis;
        this.snapshotter = Objects.requireNonNull(snapshotter);

        this.unsubscribedState = new UnsubscribedState();
        this.subscribeRequestedState = new SubscribeRequestedState();
        this.subscribedState = new SubscribedState();
        this.retryState = new RetryState();
        this.unsubscribeRequestedState = new UnsubscribeRequestedState();
        this.resubscribeRequestedState = new ResubscribeRequestedState();

        this.currentState = unsubscribedState;

        this.subscribeAcknowledgement = this::acknowledgeSubscribe;
    }

    private void acknowledgeSubscribe() {
        final State state = this.currentState;
        final State newState = state.acknowledgeSubscribe();
        if (newState != state) this.currentState = newState;
    }

    private void acknowledgeUnsubscribe() {
        final State state = this.currentState;
        final State newState = state.acknowledgeUnsubscribe();
        if (newState != state) this.currentState = newState;
    }

    @Override
    public void processUpdate(final UpdateMessage updateMessage) {
        delegateUpdateProcessor.processUpdate(updateMessage);
    }

    @Override
    public void processError(final ErrorMessage errorMessage) {
        processError(errorMessage.getErrorText());
    }

    @Override
    public void processError(final String errorMessage) {
        final State state = this.currentState;
        final State newState = state.error(errorMessage);
        if (newState != state) this.currentState = newState;
    }

    @Override
    public void subscribe(final long expireTimeMillis) {
        final State state = this.currentState;
        final State newState = state.subscribe(expireTimeMillis);
        if (newState != state) this.currentState = newState;
    }

    @Override
    public void resubscribe(long subscribeDelayMillis) {
        final State state = this.currentState;
        final State newState = state.resubscribe(subscribeDelayMillis);
        if (newState != state) this.currentState = newState;
    }

    @Override
    public void handleExpired() {
        final State state = this.currentState;
        final State newState = state.handleExpired();
        if (newState != state) this.currentState = newState;
    }

    @Override
    public void handleMissedUpdate() {
        currentState.handleMissedUpdate();
    }

    @Override
    public void retryFailed() {
        final State state = this.currentState;
        final State newState = state.retryFailed();
        if (newState != state) this.currentState = newState;
    }

    @Override
    public void publishLatestUpdate() {
        currentState.publishLatestUpdate();
    }

    @Override
    public void stop() {
        final State state = this.currentState;
        final State newState = state.stop();
        if (newState != state) this.currentState = newState;
    }

    private Runnable createSubscribeRequest(final long subscriptionId) {
        //this runs on request processing thread
        return () -> {
            Runnable acknowledgement = subscribeAcknowledgement;
            try {
                if (!streamingService.isConnected()) {
                    LOGGER.info("StreamingService is not connected, connecting ...");
                    streamingService.connect();
                }
                streamingService.subscribe(String.valueOf(subscriptionId), d3Symbol);
            } catch (final StreamingException | IOException e ) {
                acknowledgement = () -> {
                    unregisterer.unregister(subscriptionId); //has to run on mainEventLoop thread!
                    processError(e.getMessage());
                };
            }
            try {
                acknowledgeAppender.enqueue(acknowledgement);
            } catch (final Exception ex) {
                LOGGER.error("Failed to enqueue an acknowledgement", ex);
            }
        };
    }

    private Runnable createUnsubscribeRequest(final long subscriptionId) {
        //this runs on request processing thread
        return () -> {
            try {
                if (streamingService.isConnected()) {
                    streamingService.unsubscribe(String.valueOf(subscriptionId));
                } else {
                    LOGGER.warn("StreamingService is not connected, could not unsubscribe but still will ack unsubscribe");
                }
            } catch (StreamingException e) {
                LOGGER.warn("StreamingService exception {}, could not unsubscribe but still will ack unsubscribe", e);
            } finally {
                try {
                    acknowledgeAppender.enqueue(() -> {
                        unregisterer.unregister(subscriptionId);
                        acknowledgeUnsubscribe();
                    });
                } catch (final Exception ex) {
                    LOGGER.warn("Failed to enqueue acknowledgment request", ex);
                }
            }
        };
    }

    private boolean requestSubscribe() {
        currentSubscriptionId = subscriptionIdGenerator.getAsLong();
        registerer.register(currentSubscriptionId, DefaultSubscription.this);
        try {
            requestsAppender.enqueue(createSubscribeRequest(currentSubscriptionId));
            return true;
        } catch (final Exception ex) {
            LOGGER.warn("Could not enqueue subscribe request to requestsEventLoopRunnableQueue. Unregistering subscriptionId: " + currentSubscriptionId);
            unregisterer.unregister(currentSubscriptionId);
            return false;
        }
    }

    private boolean requestUnsubscribe() {
        try {
            requestsAppender.enqueue(createUnsubscribeRequest(currentSubscriptionId));
            return true;
        } catch (final Exception ex) {
            LOGGER.warn("Could not enqueue unsubscribe request to requestsEventLoopRunnableQueue");
            return false;
        }
    }

    private interface State {
        State subscribe(long expireTimeMillis);
        State resubscribe(long subscribeDelayMillis);
        State acknowledgeSubscribe();
        State acknowledgeUnsubscribe();
        State error(String message);
        State stop();
        State handleExpired();
        State retryFailed();
        void handleMissedUpdate();
        void publishLatestUpdate();
        default String stateName() {
            return this.getClass().getSimpleName();
        }
    }

    private void reset() {
        expireTimeMillis = 0;
        nextRetryEpochTimeMillis = 0;
    }

    private void updateExpireTime(final long expireTimeMillis) {
        this.expireTimeMillis = Long.max(this.expireTimeMillis, expireTimeMillis);
    }

    private void updateNextRetryTime() {
        nextRetryEpochTimeMillis = precisionClock.millis() + retrySubscriptionMillis;
    }

    private void updateNextRetryTime(final long retrySubscriptionMillis) {
        nextRetryEpochTimeMillis = precisionClock.millis() + retrySubscriptionMillis;
    }

    private void clearBookAndForwardEmptySnapshot(final Set<Flag> flags, final String proceedingState) {
        try {
            snapshotter.clearBookAndForwardEmptySnapshot(flags);
        } catch (final Exception ex){
            LOGGER.warn("Exception occurred while sending empty snapshot, proceed switching to " + proceedingState + " state", ex);
        }
    }

    private void forwardCurrentSnapshot() {
        try {
            snapshotter.forwardCurrentSnapshot();
        } catch (final Exception ex){
            LOGGER.warn("Exception occurred while forwarding a snapshot", ex);
        }
    }

    private void forwardCurrentSnapshotUpdatingFlags() {
        try {
            snapshotter.forwardCurrentSnapshotUpdatingFlags(marketDataBook -> marketDataBook.flag(Flag.LOGGED_OFF), EMPTY_FLAGS);
        } catch (final Exception ex){
            LOGGER.warn("Exception occurred while conditionally forwarding a snapshot", ex);
        }
    }

    private final class UnsubscribedState implements State {
        @Override
        public State subscribe(final long expireTimeMillis) {
            updateExpireTime(expireTimeMillis);
            if (requestSubscribe()) {
                logSubcribe(stateName(), expireTimeMillis);
                return subscribeRequestedState;
            } else {
                return retryState;
            }
        }

        @Override
        public State resubscribe(final long subscribeDelayMillis) {
            //no op
            return this;
        }

        @Override
        public State acknowledgeSubscribe() {
            //no op
            return this;
        }

        @Override
        public State acknowledgeUnsubscribe() {
            //no op
            return this;
        }

        @Override
        public State error(final String message) {
            //no op
            return this;
        }

        @Override
        public State stop() {
            //no op
            return this;
        }

        @Override
        public State handleExpired() {
            //no op
            return this;
        }

        @Override
        public State retryFailed() {
            //no op
            return this;
        }

        @Override
        public void handleMissedUpdate() {
            //no op
        }

        @Override
        public void publishLatestUpdate() {
            //no op
        }
    }

    private final class SubscribeRequestedState implements State {
        @Override
        public State subscribe(final long expireTimeMillis) {
            updateExpireTime(expireTimeMillis);
            logSubcribe(stateName(), expireTimeMillis);
            return this;
        }

        @Override
        public State resubscribe(final long subscribeDelayMillis) {
            //no op
            return this;
        }

        @Override
        public State acknowledgeSubscribe() {
            logAcknowledgeSubscribe(stateName());
            forwardCurrentSnapshotUpdatingFlags();
            return subscribedState;
        }

        @Override
        public State acknowledgeUnsubscribe() {
            logAcknowledgeUnsubscribe(stateName(), "This is normal as subscribe was requested when unsubscribe was in progress");
            return this;
        }

        @Override
        public State error(final String message) {
            currentError = message;
            updateNextRetryTime();
            logError(stateName(), message);
            return retryState;
        }

        @Override
        public State stop() {
            logStop(stateName());
            return unsubscribedState;
        }

        @Override
        public State handleExpired() {
            //no op
            return this;
        }

        @Override
        public State retryFailed() {
            //no op
            return this;
        }

        @Override
        public void handleMissedUpdate() {
            //no op
        }

        @Override
        public void publishLatestUpdate() {
            //no op
        }
    }

    private final class SubscribedState implements State {
        @Override
        public State subscribe(final long expireTimeMillis) {
            updateExpireTime(expireTimeMillis);
            forwardCurrentSnapshot();
            logSubcribe(stateName(), expireTimeMillis);
            return this;
        }

        @Override
        public State resubscribe(final long subscribeDelayMillis) {
            if (requestUnsubscribe()) {
                resubscribeRequestedState.subscribeDelayMillis(subscribeDelayMillis);
                logResubcribe(stateName(), subscribeDelayMillis);
                return resubscribeRequestedState;
            } else {
                return this;
            }
        }

        @Override
        public State acknowledgeSubscribe() {
            //no op
            return this;
        }

        @Override
        public State acknowledgeUnsubscribe() {
            //no op
            return this;
        }

        @Override
        public State error(final String message) {
            currentError = message;
            updateNextRetryTime();
            clearBookAndForwardEmptySnapshot(LOGGED_OFF_FLAGS, "retryState");
            logError(stateName(), message);
            return retryState;
        }

        @Override
        public State stop() {
            clearBookAndForwardEmptySnapshot(STOPPED_FLAGS, "unsubscribedState");
            logStop(stateName());
            return unsubscribedState;
        }

        @Override
        public State handleExpired() {
            if (precisionClock.millis() > expireTimeMillis) {
                logExpired(stateName(), "unsubscribing");
                if (requestUnsubscribe()) {
                    return unsubscribeRequestedState;
                }
            }
            return this;
        }

        @Override
        public State retryFailed() {
            //no op
            return this;
        }

        @Override
        public void handleMissedUpdate() {
            snapshotter.clearBookAndForwardEmptySnapshot(MISSED_HEATBEAT_FLAGS);
        }

        @Override
        public void publishLatestUpdate() {
            snapshotter.forwardCurrentSnapshot();
        }
    }

    private final class RetryState implements State {
        @Override
        public State subscribe(final long expireTimeMillis) {
            updateExpireTime(expireTimeMillis);
            if (requestSubscribe()) {
                logSubcribe(stateName(), expireTimeMillis);
                return subscribeRequestedState;
            } else {
                return this;
            }
        }

        @Override
        public State resubscribe(final long subscribeDelayMillis) {
            //no op
            return this;
        }

        @Override
        public State acknowledgeSubscribe() {
            //no op
            return this;
        }

        @Override
        public State acknowledgeUnsubscribe() {
            logAcknowledgeUnsubscribe(stateName(), "This is normal as subscribe failed when unsubscribe was in progress (which is finalised now)");
            return this;
        }

        @Override
        public State error(final String message) {
            currentError = message;
            logError(stateName(), message);
            return this;
        }

        @Override
        public State stop() {
            logStop(stateName());
            return unsubscribedState;
        }

        @Override
        public State handleExpired() {
            if (precisionClock.millis() > expireTimeMillis) {
                clearBookAndForwardEmptySnapshot(LOGGED_OFF_FLAGS, "unsubscribedState");
                reset();
                logExpired(stateName(), "already unsubscribed");
                return unsubscribedState;
            }
            return this;
        }

        @Override
        public State retryFailed() {
            if (precisionClock.millis() > nextRetryEpochTimeMillis) {
                if (requestSubscribe()) {
                    logRetryFailed(stateName(), "subscribing");
                    return subscribeRequestedState;
                }
            }
            return this;
        }

        @Override
        public void handleMissedUpdate() {
            //no op
        }

        @Override
        public void publishLatestUpdate() {
            //no op
        }
    }

    private final class UnsubscribeRequestedState implements State {
        @Override
        public State subscribe(final long expireTimeMillis) {
            updateExpireTime(expireTimeMillis);
            if (requestSubscribe()) {
                logSubcribe(stateName(), expireTimeMillis);
                return subscribeRequestedState;
            } else {
                return retryState;
            }
        }

        @Override
        public State resubscribe(final long subscribeDelayMillis) {
            //no op
            return this;
        }

        @Override
        public State acknowledgeSubscribe() {
            //no op
            return this;
        }

        @Override
        public State acknowledgeUnsubscribe() {
            clearBookAndForwardEmptySnapshot(LOGGED_OFF_FLAGS, "unsubscribedState");
            reset();
            logAcknowledgeUnsubscribe(stateName(), "done");
            return unsubscribedState;
        }

        @Override
        public State error(final String message) {
            currentError = message;
            clearBookAndForwardEmptySnapshot(LOGGED_OFF_FLAGS, "unsubscribedState");
            reset();
            logError(stateName(), message);
            return unsubscribedState;
        }

        @Override
        public State stop() {
            clearBookAndForwardEmptySnapshot(STOPPED_FLAGS, "unsubscribedState");
            logStop(stateName());
            return unsubscribedState;
        }

        @Override
        public State handleExpired() {
            //no op
            return this;
        }

        @Override
        public State retryFailed() {
            //no op
            return this;
        }

        @Override
        public void handleMissedUpdate() {
            //no op
        }

        @Override
        public void publishLatestUpdate() {
            //no op
        }
    }

    private final class ResubscribeRequestedState implements State {
        private long subscribeDelayMillis = 0;

        @Override
        public State subscribe(final long expireTimeMillis) {
            updateExpireTime(expireTimeMillis);
            forwardCurrentSnapshot();
            logSubcribe(stateName(), expireTimeMillis);
            return this;
        }

        public void subscribeDelayMillis(final long subscribeDelayMillis) {
            this.subscribeDelayMillis = subscribeDelayMillis;
        }

        @Override
        public State resubscribe(final long subscribeDelayMillis) {
            //no op
            return this;
        }

        @Override
        public State acknowledgeSubscribe() {
            //no op
            return this;
        }

        @Override
        public State acknowledgeUnsubscribe() {
            clearBookAndForwardEmptySnapshot(LOGGED_OFF_FLAGS, "subscribeRequestedState");
            logAcknowledgeUnsubscribe(stateName(), "Switching to retry state, will subscribe in " + TimeUnit.MILLISECONDS.toSeconds(subscribeDelayMillis) + " seconds");
            updateNextRetryTime(subscribeDelayMillis);
            return retryState;
        }

        @Override
        public State error(final String message) {
            currentError = message;
            updateNextRetryTime(subscribeDelayMillis);
            clearBookAndForwardEmptySnapshot(LOGGED_OFF_FLAGS, "retryState");
            logError(stateName(), message);
            return retryState;
        }

        @Override
        public State stop() {
            clearBookAndForwardEmptySnapshot(STOPPED_FLAGS, "unsubscribedState");
            logStop(stateName());
            return unsubscribedState;
        }

        @Override
        public State handleExpired() {
            //no op
            return this;
        }

        @Override
        public State retryFailed() {
            //no op
            return this;
        }

        @Override
        public void handleMissedUpdate() {
            //no op
        }

        @Override
        public void publishLatestUpdate() {
            //no op
        }
    }

    private void logSubcribe(final String currentState, final long expireTimeMillis) {
        LOGGER.info( "{}: subscribe ({}), symbol: {}, subscriptionId: {}, expireTime: {}", currentState, format(expireTimeMillis), d3Symbol, currentSubscriptionId, format(this.expireTimeMillis));
    }

    private void logResubcribe(final String currentState, final long subscribeDelayMillis) {
        LOGGER.info( "{}: resubscribe ({} seconds), symbol: {}, subscriptionId: {}, expireTime: {}", currentState, TimeUnit.MICROSECONDS.toSeconds(subscribeDelayMillis), d3Symbol, currentSubscriptionId, format(this.expireTimeMillis));
    }

    private void logAcknowledgeSubscribe(final String currentState) {
        LOGGER.info("{}: acknowledgeSubscribe(), symbol: {}, subscriptionId: {}, expireTime: {}", currentState, d3Symbol, currentSubscriptionId, format(expireTimeMillis));
    }

    private void logAcknowledgeUnsubscribe(final String currentState, final String comments) {
        LOGGER.info("{}: acknowledgeUnsubscribe(), symbol: {}. {}", currentState, d3Symbol, comments);
    }

    private void logError(final String currentState, final String errorMessage) {
        LOGGER.error("{}: error({}), symbol: {}, subscriptionId: {}, expireTime: {}, nextRetryTime: {}", currentState, errorMessage, d3Symbol, currentSubscriptionId, format(expireTimeMillis), format(nextRetryEpochTimeMillis));
    }

    private void logStop(final String currentState) {
        LOGGER.info("{}: stop(), symbol: {}, subscriptionId: {}, expireTime: {}", currentState, d3Symbol, currentSubscriptionId, format(expireTimeMillis));
    }

    private void logExpired(final String currentState, final String nextAction) {
        LOGGER.info("{}: expired - {} , symbol: {}, subscriptionId: {}, expireTime: {}", currentState, nextAction, d3Symbol, currentSubscriptionId, format(expireTimeMillis));
    }

    private void logRetryFailed(final String currentState, final String nextAction) {
        LOGGER.info("{}: retry - {} , symbol: {}, subscriptionId: {}, expireTime: {}", currentState, nextAction, d3Symbol, currentSubscriptionId, format(expireTimeMillis));
    }

    private CharSequence format(final long epochTimeMillis) {
        return epochTimeMillis == Long.MAX_VALUE ? "none" : dateTimeFormatter.epochMillis(epochTimeMillis);
    }
}
