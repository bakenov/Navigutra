#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-spdee-dealing-pdc-latency Plugin to monitor the SPDEE Dealing PDC Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title SPDEE Dealing PDC Latency'
    echo 'graph_category spdee'
    echo 'graph_scale no'
    echo 'latency.label SPDEE Dealing PDC Latency'
    echo 'latency.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "latency.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "latency.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
egrep 'dealing.validate.*.PdcValidator.success,,' $LOGFILE | tail -100 | awk -F, '

BEGIN {
        latency=0;
}

/dealing.validate.(mdr|order).(spot|forward|swap|block).PdcValidator/ {latency=$15}

END {
        print "latency.value " latency;
}
'
fi

