package com.anz.markets.prophet.chronicle;

/**
 * tell ChronicleReader to stop reading
 **/
public class StopException extends RuntimeException {
    public StopException(final String msg) {
        super(msg);
    }
}
