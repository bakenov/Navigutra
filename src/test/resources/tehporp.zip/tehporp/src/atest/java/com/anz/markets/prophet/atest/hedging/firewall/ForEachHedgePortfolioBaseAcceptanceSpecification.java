package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.domain.Portfolio;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Runs test for all portfolio to ensure that they are all configured.
 */
@RunWith(Parameterized.class)
@RestartBeforeTest(reason = "Firewall keeps states and there is no normal operational mechanism to clear it. Therefore it needs to be restarted.")
public abstract class ForEachHedgePortfolioBaseAcceptanceSpecification extends BaseAcceptanceSpecification {
    private static final Logger LOGGER = LoggerFactory.getLogger(ForEachHedgePortfolioBaseAcceptanceSpecification.class);

    @Parameterized.Parameter
    public Portfolio portfolio;


    @Parameterized.Parameters(name = "{index}: portfolio({0})")
    public static Object[] data() {
        if (RUN_ALL_PARAMETERIZE_TESTS) {
            final List<Portfolio> hedgeBook = Arrays.asList(Portfolio.VALUES).stream().filter(Portfolio::isHedger).collect(Collectors.toList());
            return hedgeBook.toArray();
        } else {
            LOGGER.warn("Not running all parameterized test in order to save time. To run all parameterized test set {}=true, all tests should be run nightly.", RUN_ALL_PARAMETERIZE_TESTS);
            return notionalData();
        }
    }

    public static Object[] notionalData() {
        return new Portfolio[]{Portfolio.HEDGER_AGGRESSIVE};
    }
}
