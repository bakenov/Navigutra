package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.fox.firewall.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.fox.firewall.metric.MatchableMetric;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public interface Metric {
    void accept(ExecutionReportDecoder executionReport, long currentTimeNanos);
    void accept(NewOrderSingleDecoder newOrderSingle, long currentTimeNanos);

    double currentValue(long currentTimeNanos);

    double nextValue(NewOrderSingleDecoder newOrderSingle, long currentTimeNanos);

    static Metric withMatcher(final Metric metric, final ExecutionReportMatcher matcher) {
        return new MatchableMetric(metric, matcher);
    }
}
