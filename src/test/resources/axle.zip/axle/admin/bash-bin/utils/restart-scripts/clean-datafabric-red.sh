#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa035z "rm -rf ~/axle/datafabric/workspace"
ssh AxlSv@daxa018z "rm -rf ~/axle/datafabric/workspace"
