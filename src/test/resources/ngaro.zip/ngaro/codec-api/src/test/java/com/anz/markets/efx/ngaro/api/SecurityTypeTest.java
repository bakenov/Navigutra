package com.anz.markets.efx.ngaro.api;

import java.util.function.Consumer;
import java.util.stream.Stream;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class SecurityTypeTest {

    @Test
    public void valueByOrdinal() {
        Stream.of(SecurityType.values())
                .forEach(securityType ->
                        assertThat(SecurityType.valueByOrdinal(securityType.ordinal())).isEqualTo(securityType)
                );
    }

    @Test
    public void forEach() {
        @SuppressWarnings({"unchecked", "rawType"})
        final Consumer<SecurityType> consumer = mock(Consumer.class);
        SecurityType.forEach(consumer);
        Stream.of(SecurityType.values()).forEach(securityType -> verify(consumer).accept(securityType));
    }
}