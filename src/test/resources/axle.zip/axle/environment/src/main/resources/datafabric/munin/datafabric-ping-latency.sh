#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-ping-latency - Plugin to monitor the Datafabric Ping Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Pradeep Bagadi(pradeep.bagadi@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

HOME_DATACENTRE=${datafabric.node}
HOME_DATACENTRE_SHORT=`echo $HOME_DATACENTRE | awk -F. '{ print $(NF-1); }'`

REMOTE1='Datafabric.'${datafabric.remote1.node}'.Primary'
REMOTE2='Datafabric.'${datafabric.remote2.node}'.Primary'

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Datafabric - ' $HOME_DATACENTRE ' - Ping Roundtrip Latency'
    echo 'graph_category datafabric'
    echo 'graph_scale no'

    echo 'latency1.label ' $REMOTE1
    echo 'latency1.draw LINE2'

    echo 'latency2.label ' $REMOTE2
    echo 'latency2.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "latency1.value U"
        echo "latency2.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "latency1.value U"
        echo "latency2.value U"
        exit 0
fi

LOGFILE=`ls -1 -atr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`


if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
grep Primary,ping.roundtrip.traveltime,Datafabric.*Primary $LOGFILE | tail -5 | awk -F, '
BEGIN {
        latency1=0;
        latency2=0;
}



/'"$REMOTE1"'/ {latency1=$15}
/'"$REMOTE2"'/ {latency2=$15}
END {
        print "latency1.value " latency1;
        print "latency2.value " latency2;
}
'
fi






