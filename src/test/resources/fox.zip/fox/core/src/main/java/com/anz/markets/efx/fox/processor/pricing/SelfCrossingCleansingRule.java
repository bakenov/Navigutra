package com.anz.markets.efx.fox.processor.pricing;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;

public class SelfCrossingCleansingRule implements Consumer<VenueInstrument> {

    @Override
    public void accept(final VenueInstrument venueInstrument) {
        final MarketDataBook marketDataBook = venueInstrument.marketDataBook();
        if(!marketDataBook.flagsIsEmpty()) return;

        final MarketDataEntries bids = marketDataBook.bids();
        final MarketDataEntries asks = marketDataBook.asks();

        int askStartIdx = 0;

        for (int bidIdx = 0; bidIdx < bids.size(); bidIdx++) {
            final MarketDataEntry bid = bids.get(bidIdx);

            for (int askIdx = askStartIdx; askIdx < asks.size() ; askIdx++) {
                final MarketDataEntry ask = asks.get(askIdx);

                if (bid.price() > ask.price()) {
                    if (bid.transactTimeNanos() > ask.transactTimeNanos()) {
                        ask.flag(Flag.SELF_CROSSING);
                        askStartIdx = askIdx + 1;
                    } else {
                        if (bid.transactTimeNanos() < ask.transactTimeNanos()) {
                            bid.flag(Flag.SELF_CROSSING);
                            break;
                        } else {
                            if (bid.quantity() > ask.quantity()) {
                                ask.flag(Flag.SELF_CROSSING);
                                askStartIdx = askIdx + 1;
                            } else {
                                bid.flag(Flag.SELF_CROSSING);
                                break;
                            }
                        }
                    }
                } else {
                    return;
                }
            }
        }
    }
}
