package com.anz.markets.prophet.config.business.domain.tabular;

public interface HasChanged<T> {
    boolean differs(T other);
}
