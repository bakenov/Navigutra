package com.anz.axle.acc.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.joda.time.LocalDate;

import com.anz.axle.common.domain.Amount;
import com.anz.axle.common.domain.CounterpartyCreditPool;
import com.anz.axle.common.domain.Identifiable;
import com.anz.axle.common.domain.Operation;
import com.anz.axle.common.domain.TradeState;
import com.anz.axle.common.domain.Venue;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Entity
@Table(name="TRADE_ACC_VIEW")
public class CreditUtilisingTrade implements Identifiable {
    @Id
    private Long id;

    @ManyToOne
    @JoinColumn(name="CREDIT_POOL")
    private CounterpartyCreditPool creditPool;

    @ManyToOne
    @JoinColumn(name="VENUE_ID")
    private Venue venue;

    @Column(name="SOURCE_SYSTEM_TRADE_ID")
    private String sourceSystemTradeId;

    @Column(name="SETTLEMENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date rawSpotDate;

    @Column(name="TRADE_STATE_NAME")
    private String rawTradeState;

    @Column(name = "USD_LAST_DONE_AMOUNT", precision = 2, scale=19, columnDefinition="NUMBER(19,2)")
    private Double rawUsdLastDoneAmount = 0.0d;

    @Column(name="OPERATION")
    private String rawOperation;

    public CreditUtilisingTrade() {
    }

    public CreditUtilisingTrade(Long id, CounterpartyCreditPool creditPool, Venue venue, String sourceSystemTradeId, Date rawSpotDate, String rawTradeState, Double rawUsdLastDoneAmount, String rawOperation) {
        this.id = id;
        this.creditPool = creditPool;
        this.venue = venue;
        this.sourceSystemTradeId = sourceSystemTradeId;
        this.rawSpotDate = rawSpotDate;
        this.rawTradeState = rawTradeState;
        this.rawUsdLastDoneAmount = rawUsdLastDoneAmount;
        this.rawOperation = rawOperation;
    }

    public CreditUtilisingTrade(double rawUsdLastDoneAmount, Date rawSpotDate, CounterpartyCreditPool creditPool) {
        this.rawUsdLastDoneAmount = rawUsdLastDoneAmount;
        this.rawSpotDate = rawSpotDate;
        this.creditPool = creditPool;
    }

    public Long getId() {
        return id;
    }

    public CounterpartyCreditPool getCreditPool() {
        return creditPool;
    }

    public Venue getVenue() {
        return venue;
    }

    public String getSourceSystemTradeId() {
        return sourceSystemTradeId;
    }

    public Date getRawSpotDate() {
        return rawSpotDate;
    }

    public LocalDate getSpotDate() {
        return new LocalDate(getRawSpotDate());
    }

    public String getRawTradeState() {
        return rawTradeState;
    }

    public TradeState getTradeState() {
        return TradeState.valueOf(rawTradeState);
    }

    public Double getRawUsdLastDoneAmount() {
        return rawUsdLastDoneAmount;
    }

    public Amount getUsdLastDoneAmount() {
        return new Amount(getRawUsdLastDoneAmount());
    }

    public Operation getOperation() {
        return Operation.findByCode(rawOperation);
    }

    @Override
    public String toString() {
        return "CreditUtilisingTrade{" +
                "id=" + id +
                ", creditPool=" + creditPool +
                ", venue=" + venue +
                ", sourceSystemTradeId='" + sourceSystemTradeId + '\'' +
                ", rawSpotDate=" + rawSpotDate +
                ", rawTradeState='" + rawTradeState + '\'' +
                ", rawUsdLastDoneAmount=" + rawUsdLastDoneAmount +
                ", rawOperation='" + rawOperation + '\'' +
                '}';
    }
}
