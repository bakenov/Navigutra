package com.anz.markets.efx.fox.sender;

import java.util.Objects;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.NewOrderSingleSbeDecoder;

public class NewOrderSingleRouter implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NewOrderSingleRouter.class);

    private final Function<String, MessageDecoder<SbeMessage>> venueTradingRequestDelegateLookup;
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);
    private final NewOrderSingleSbeDecoder decoder = new NewOrderSingleSbeDecoder();
    private StringBuilder stringBuilder = new StringBuilder();

    public NewOrderSingleRouter(final Function<String, MessageDecoder<SbeMessage>> venueTradingRequestDelegateLookup) {
        this.venueTradingRequestDelegateLookup = Objects.requireNonNull(venueTradingRequestDelegateLookup);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if(!decoder.wrap(message)) return false;

        LOGGER.info("Sending NOS");
        final String marketId = decoder.body().marketId().decodeAndCache(marketIdCache);
        final MessageDecoder<SbeMessage> venueTradingRequestDelegate =  venueTradingRequestDelegateLookup.apply(marketId);
        if (venueTradingRequestDelegate != null) {
            venueTradingRequestDelegate.decode(message);
            logMessage();
        }
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        decoder.appendTo(stringBuilder);
        LOGGER.info("Sending NOS: {}", stringBuilder);
    }

}
