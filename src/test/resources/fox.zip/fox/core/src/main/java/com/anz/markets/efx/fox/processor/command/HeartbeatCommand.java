package com.anz.markets.efx.fox.processor.command;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.processor.state.usersession.UserSessionKeyFactory;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.HeartbeatSbeDecoder;

public class HeartbeatCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(HeartbeatCommand.class);

    private final CommandContext commandContext;
    private final UserRepository userRepository;
    private final VenueRepository venueRepository;

    private final HeartbeatSbeDecoder heartbeatDecoder = new HeartbeatSbeDecoder();
    private final Map<String, UserSessionKey> userSessionKeyMap = new HashMap<>();
    private final UserSessionKeyFactory userSessionKeyFactory = new UserSessionKeyFactory();
    private final ByteValueCache<String> senderCompIdCache = new ByteValueCache<>(AsciiString::toString);
    private final StringBuilder stringBuilder = new StringBuilder();

    public HeartbeatCommand(final CommandContext commandContext,
                            final UserRepository userRepository,
                            final VenueRepository venueRepository) {
        this.commandContext = Objects.requireNonNull(commandContext);
        this.userRepository = Objects.requireNonNull(userRepository);
        this.venueRepository = Objects.requireNonNull(venueRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!heartbeatDecoder.wrap(message)) return false;

        final String senderCompId = heartbeatDecoder.body().senderCompId().decodeAndCache(senderCompIdCache);
        final UserSessionKey userSessionKey = userSessionKeyMap.computeIfAbsent(senderCompId, userSessionKeyFactory);

        if (userSessionKey != UserSessionKey.UNKNOWN) {
            if (userRepository.lookup(userSessionKey.userName()) != null) {
                logMessage();

                commandContext.eventApplier().decode(message);
            }
        } else if (venueRepository.lookup(senderCompId) != null) {
            commandContext.eventApplier().decode(message);
        }
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        heartbeatDecoder.appendTo(stringBuilder);
        LOGGER.info("Heartbeat command: {}", stringBuilder);
    }
}
