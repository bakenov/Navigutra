package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.domain.chronicle.Header;

import java.util.function.ToLongFunction;

public interface StartAtSeeker {
    void firstIndex();
    void lastIndex();
    void configIndex();
    void findIndex(final ToLongFunction<Header> headerToLongFunction, final boolean exactMatch);
}
