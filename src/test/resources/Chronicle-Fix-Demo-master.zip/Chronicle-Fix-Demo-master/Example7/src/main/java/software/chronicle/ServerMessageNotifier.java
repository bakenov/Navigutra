package software.chronicle;

import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.Wires;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.fields.ExecType;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.Random;

import static software.chronicle.generated.code.messages.ExecutionReport.newExecutionReport;

public class ServerMessageNotifier implements MessageNotifier, Marshallable {

    private char[] execTypes = new char[]{ExecType.NEW, ExecType.PARTIAL_FILL, ExecType.CANCELED};
    private Random random = new Random();

    @Override
    public void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        int max = 1 + random.nextInt(execTypes.length);
        for (int i = 0; i < max; i++) {
            final ExecutionReport executionReport = newExecutionReport(Wires.acquireBytes(), session.context());
            executionReport.clOrdID(newOrderSingle.clOrdID());
            executionReport.side('1');
            executionReport.avgPx(12.0 + random.nextDouble());
            executionReport.execType(execTypes[i]);
            session.sendMessage(executionReport);
        }
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }
}
