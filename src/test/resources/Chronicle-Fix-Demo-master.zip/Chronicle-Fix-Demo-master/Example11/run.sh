#!/bin/bash

MAVEN_OPTS=-ea mvn exec:java
