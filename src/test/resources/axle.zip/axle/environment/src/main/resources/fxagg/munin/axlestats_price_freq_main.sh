#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_price_freq_main - Plugin to monitor the Price Update Frequency (Main)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=z::deprecated
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Price Update Frequency (Main) [DEPRECATED]'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category z::deprecated'
    echo 'graph_scale no'
    echo 'price5.label AggBooks Received from VAGs'
    echo 'price5.draw LINE2'
    echo 'price5.colour 000000'		# BLACK        
    echo 'price11.label AggBooks Published to Algo'
    echo 'price11.draw LINE2'
    echo 'price11.colour 0000FF'	# BLUE
    echo 'price12.label AggBooks Published to GUI'
    echo 'price12.draw LINE2'    
    echo 'price12.colour FF0000'	# RED    
    echo 'price13.label AggBooks Published to Datafabric'
    echo 'price13.draw LINE2'
    echo 'price13.colour FF8000'	# ORANGE
    exit 0
fi

echo "price5.value U"
echo "price11.value U"
echo "price12.value U"
echo "price13.value U"
exit 0