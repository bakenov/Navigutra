package com.anz.markets.efx.fox.common.pricing;

public interface PricingRefresher {
    boolean refresh(long instrumentId, boolean forceSnapshot);

    default PricingRefresher thenIfDoneOrForced(final PricingRefresher pricingRefresher) {
        return (instrumentId, forceSnapshot)  -> {
            if (this.refresh(instrumentId, forceSnapshot) | forceSnapshot) {
                pricingRefresher.refresh(instrumentId, forceSnapshot);
                return true;
            }
            return false;
        };
    }
}
