package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketGapFactorConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketGapToWideningFactorConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketWideningFactorToDecayPeriodConfigImpl;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.wholesale.spreads.MarketGapSpreadAdjustmentStrategy;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1134})
@RestartBeforeTest(reason = "Market gap has state")
public class ModelSpread_MarketGap_Factor_Test extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET, new Instrument[] { Instrument.EURUSD }))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, true))
                .setMarketGapFactorConfigs(Arrays.asList(new MarketGapFactorConfigImpl(FactorWindow.CAT_A, 100L, 1L, 0.70, 0.25, 0.30, 0.75)))
                .setMarketGapToWideningFactorConfigs(com.google.common.collect.Lists.newArrayList(
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 64.0, 80.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 3.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 6.0, 7.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 12.0, 20.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 36.0, 60.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 72.0, 95.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 64.0, 80.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 64.0, 80.0)
                ))
                .setMarketWideningFactorToDecayPeriodConfigs(com.google.common.collect.Lists.newArrayList(
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 3.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 10.0, 10000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.ANY, Region.GB, 80.0, 45000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 3.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 10.0, 10000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 80.0, 45000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 3.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 10.0, 10000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 80.0, 45000)
                ));

        return configuration;
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_4_4_5, Requirement.Ref.PRICING_4_4_6})
    @DisplayName("market moving to OFFER side - negative gap ratio")
    public void negative_gap_ratio() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            // Monitoring period: 100 ms
            ConfigurationDataDefault config = setUpConfiguration();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01000, 0.00004));

            prophet.incrementTime(50);  // ignored.
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01024, 0.00004));

            prophet.incrementTime(50); //t+100 market is moving towards OFFER side
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01013, 0.00004));
        }

        then:
        {
            // WSP_U TOB MID Gap Ratio = |1.01-1.01013|/base spread 0.00003 = 4.333
            // MG Factor = 3.5, decay period 3 sec.  Therefore gradient = (3.5-1)/3 = -0.83333
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(3), isWholesaleBookFactors(Market.WSP_A)).getLast();

            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), new IsRoundedTo(-4.33));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.875));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(2.625));
            assertThat(wbf.getOverallBidSpreadInPips(), isNear(0.3 * wbf.getMarketGap().getGapBidFactor()));
            assertThat(wbf.getOverallOfferSpreadInPips(), isNear(0.3 * wbf.getMarketGap().getGapOfferFactor()));
            assertThat(wbf.getModelSpread(), isNear(1.05));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(MarketGapSpreadAdjustmentStrategy.FEATURE_NAME);
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.getNumOperationLines(), Matchers.is(2));
            assertThat(ftl.operations[0].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.BID_SPREAD_IN_PIPS));
            assertThat(ftl.operations[0].oldVal, Matchers.is(0.15));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.2625));
            assertThat(ftl.operations[1].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftl.operations[1].var, Matchers.is(PliableBookVariable.OFFER_SPREAD_IN_PIPS));
            assertThat(ftl.operations[1].oldVal, Matchers.is(0.15));
            assertThat(ftl.operations[1].newVal, isRoundedTo(0.7875));

            assertThat(ftl.data[0].var.toString(), Matchers.is("bidSpread"));
            assertThat(ftl.data[0].fx, isRoundedTo(0.2625));
            assertThat(ftl.data[0].sx.toString(), is("CAT_A"));
            assertThat(ftl.data[1].var.toString(), Matchers.is("askSpread"));
            assertThat(ftl.data[1].fx, isRoundedTo(0.7875));
            assertThat(ftl.data[1].sx.toString(), is("CAT_A"));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceMarket(Market.WSP_A)).getLast();
            assertThat(clientPrice.getDominantFeatureBid().toString(), is(ftl.featureShortCode));
            assertThat(clientPrice.getDominantFeatureOffer().toString(), is(ftl.featureShortCode));
        }

        when:
        // at 0.75 second into decay period: Factor = 3.5 + (-0.83333*0.75) = 2.875
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(750);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01012, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();

            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(2.875));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), new IsRoundedTo(0.71875));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(2.15625));
            assertThat(wbf.getModelSpread(), isNear(0.8625));
        }

        when:
        // at 3 seconds(end) into decay period: Factor = 1  i.e fully decayed
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(2249);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01013, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();

            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(1));   // actual returned val is 0.999999999
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(0.75));

            // (0.25*0.3)=0.075 but cannot be less than half base spread(0.3)
            assertThat(wbf.getOverallBidSpreadInPips(), isNear(0.15));
            // 0.75*0.3
            assertThat(wbf.getOverallOfferSpreadInPips(), isNear(0.225));
            assertThat(wbf.getOverallSpreadInPips(), isNear(0.375));
            assertThat(wbf.getModelSpread(), isNear(0.375));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_4_4_5, Requirement.Ref.PRICING_4_4_6})
    @DisplayName("market moving to BID side - positive gap ratio")
    public void positive_gap_ratio() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            // Monitoring period: 100 ms
            ConfigurationDataDefault config = setUpConfiguration();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75193, 0.00004));

            prophet.incrementTime(50);  // ignored.
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75050, 0.00004));

            prophet.incrementTime(50); //t+100 market is moving towards BID side
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00004));
        }

        then:
        {
            // WSP_U TOB MID Gap Ratio = |0.75193 - 0.75000|/base spread 0.00003 = 64.333
            // Highest MG Factor 80 applied. Decay period 45 sec.  Therefore gradient = (80-1)/45 = -1.75555555555
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(3), isWholesaleBookFactors(Market.WSP_A)).getLast();

            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), new IsRoundedTo(64.33));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(80.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(80.0));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.70));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(56.0));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.30));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(24.0));
            assertThat(wbf.getModelSpread(), isNear(24.0));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceMarket(Market.WSP_A)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.748320, 0.750720));
            prophet.clearOutputBuffer();
        }

        when:
        // at 30 seconds into decay period: Factor = 80 + (-1.75555555555*30) = 27.3333333333
        {
            prophet.incrementTime(30000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75001, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();

            assertThat(wbf.getMarketGap().getGapFactor(), isNear(80.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(27.333));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.70));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(19.133));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.30));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(8.2));
            assertThat(wbf.getModelSpread(), isNear(8.2));

            prophet.clearOutputBuffer();
        }

        when:
        // at 45 seconds(end) into decay period: Factor = 1  i.e fully decayed
        {
            prophet.incrementTime(15000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75003, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();

            assertThat(wbf.getMarketGap().getGapFactor(), isNear(80.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(1));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.70));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.70));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.30));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(0.30));

            // 0.70 * 0.3
            assertThat(wbf.getOverallBidSpreadInPips(), isNear(0.21));
            // (0.3 * 0.3)=0.09 but cannot be less than half base spread(0.3)
            assertThat(wbf.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf.getOverallSpreadInPips(), isNear(0.36));
            assertThat(wbf.getModelSpread(), isNear(0.36));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_4_4_5, Requirement.Ref.PRICING_4_4_6})
    @DisplayName("new MG NOT triggered during decay period")
    public void new_mkt_gap_NOT_triggered_during_decay_period() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            // Monitoring period: 100 ms
            ConfigurationDataDefault config = setUpConfiguration();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01000, 0.00004));

            prophet.incrementTime(50);  // ignored.
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01024, 0.00004));

            prophet.incrementTime(50); //t+100 market is moving towards OFFER side
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01013, 0.00004));
        }

        then:
        {
            // WSP_U TOB MID Gap Ratio = |1.01-1.01013|/base spread 0.00003 = 4.333
            // MG Factor = 3.5, decay period 3 sec.  Therefore gradient = (3.5-1)/3 = -0.83333
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(3), isWholesaleBookFactors(Market.WSP_A)).getLast();

            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), new IsRoundedTo(-4.33));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.875));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(2.625));
            assertThat(wbf.getModelSpread(), isNear(1.05));

            prophet.clearOutputBuffer();
        }

        when:
        // 1600 into decay period: Factor = 3.5 + (-0.83333*1.6) = 2.16666
        {
            prophet.incrementTime(1600);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01012, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(2.167));
            prophet.clearOutputBuffer();
        }

        when:
        // 1700 into decay period: Factor = 3.5 + (-0.83333*1.7) = 2.083
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01005, 0.00004));
        }

        then:
        {   // WSP_U TOB MID Gap Ratio = |1.01012 - 1.01005|/base spread 0.00003 = 2.3333  => MG Factor = 2 < Decayed factor 2.083
            // new MG decay period NOT triggered
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), new IsRoundedTo(2.33));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(2.083));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_4_4_5, Requirement.Ref.PRICING_4_4_6})
    @DisplayName("new MG triggered during decay period - reverse direction")
    public void new_mkt_gap_triggered_during_decay_period() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            // Monitoring period: 100 ms
            ConfigurationDataDefault config = setUpConfiguration();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01000, 0.00004));

            prophet.incrementTime(50);  // ignored.
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01024, 0.00004));

            prophet.incrementTime(50); //t+100 market is moving towards OFFER side
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01013, 0.00004));
        }

        then:
        {
            // WSP_U TOB MID Gap Ratio = |1.01-1.01013|/base spread 0.00003 = 4.333
            // MG Factor = 3.5, decay period 3 sec.  Therefore gradient = (3.5-1)/3 = -0.83333
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(3), isWholesaleBookFactors(Market.WSP_A)).getLast();

            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), new IsRoundedTo(-4.33));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.875));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(2.625));
            assertThat(wbf.getModelSpread(), isNear(1.05));

            prophet.clearOutputBuffer();
        }

        when:
        // 1700 into decay period: Factor = 3.5 + (-0.83333*1.7) = 2.083
        {
            prophet.incrementTime(1700);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01012, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(3.5));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(2.083));
            prophet.clearOutputBuffer();
        }

        when:
        // 1800ms into decay period: MG Factor = 3.5 + (-0.83333*1.8) = 2.0  (code returns 1.9999999999999)
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01005, 0.00004));
        }

        then:
        {   // WSP_U TOB MID Gap Ratio = |1.01012 - 1.01005|/base spread 0.00003 = 2.3333  => MG Factor of 2 > Decayed factor 1.99999999
            // NEW MG Factor = 2.0, NEW decay period 1500ms.  Therefore gradient = (2-1)/1.5 = -0.66666
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), new IsRoundedTo(2.33));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(2.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(2.0));
            prophet.clearOutputBuffer();
        }

        when:
        // at 1400ms into decay period: Factor = 2.0 + (-0.66666*1.4) = 1.0666666
        {
            prophet.incrementTime(1400);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01004, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(2.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(1.067));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.70));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.7467));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.30));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(0.32));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_4_4_7})
    @DisplayName("Multi gap window overlay")
    public void multi_gap_window_overlay() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setMarketGapFactorConfigs(Arrays.asList(
                    new MarketGapFactorConfigImpl(FactorWindow.CAT_A, 300L, 1L, 0.70, 0.25, 0.30, 0.75),
                    new MarketGapFactorConfigImpl(FactorWindow.CAT_B, 2000L, 1L, 0.50, 0.50, 0.50, 0.50)
            ))
                    .setMarketGapToWideningFactorConfigs(com.google.common.collect.Lists.newArrayList(
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 2.0, 2.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 4.0, 3.5),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 6.0, 10.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 2.0, 2.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 4.0, 3.5),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 6.0, 10.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 2.0, 2.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 4.0, 3.5),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 6.0, 10.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_B, Market.WSP_A, Region.GB, 2.0, 6.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_B, Market.WSP_A, Region.GB, 4.0, 12.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_B, Market.WSP_B, Region.GB, 2.0, 6.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_B, Market.WSP_B, Region.GB, 4.0, 12.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_B, Market.WSP_C, Region.GB, 2.0, 6.0),
                            new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_B, Market.WSP_C, Region.GB, 4.0, 12.0)
                    ))
                    .setMarketWideningFactorToDecayPeriodConfigs(com.google.common.collect.Lists.newArrayList(
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 1.0, 0),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 2.0, 1500),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 3.5, 3000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, Region.GB, 10.0, 10000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 1.0, 0),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 2.0, 1500),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 3.5, 3000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, Region.GB, 10.0, 10000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 1.0, 0),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 2.0, 1500),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 3.5, 3000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, Region.GB, 10.0, 10000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_A, Region.GB, 1.0, 0),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_A, Region.GB, 6.0, 5000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_A, Region.GB, 12.0, 10000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_B, Region.GB, 1.0, 0),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_B, Region.GB, 6.0, 5000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_B, Region.GB, 12.0, 10000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_C, Region.GB, 1.0, 0),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_C, Region.GB, 6.0, 5000),
                            new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_B, Market.WSP_C, Region.GB, 12.0, 10000)
                    ));
            prophet.receive(config);
        }

        when:
        {
            prophet.incrementTime(1200); // t@1200ms
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01000, 0.00004));

            prophet.incrementTime(300); // t@1500ms
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01019, 0.00004));
        }

        then:
        {   // t@1500ms  <=START
            // CAT_A Gap Ratio = |1.01-1.01019|/base spread 0.00003 = 6.333
            // CAT_A MG Factor = 10, decay period 10 sec.  Therefore gradient = (10-1)/10 = -0.9 i.e y = 10-0.9x
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(2), isWholesaleBookFactors(Market.WSP_A)).getLast();

            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_A).getMarketGapRatio(), isNear(-6.33));
            assertThat(wbf.getWindowMarketGapMap().get(FactorWindow.CAT_A).getGradient(), isNear(0.0009));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(10.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(10.0));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(2500); //t@4000  i.e sample for CAT_B
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01000, 0.00004));

            prophet.clearOutputBuffer();

            prophet.incrementTime(1700); //t@5700  i.e sample for CAT_A, sample for CAT_B
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01003, 0.00004));
        }

        then:
        {   // t@5700 i.e 4200ms into decay period: CAT_A MG Factor = 10 - (0.9*4.2) = 6.22
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(10.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(6.22));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(300); //t@6000  i.e sample for CAT_A, sample for CAT_B
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01007, 0.00004));
        }

        then:
        {   // CAT_A samples: t@5700 and t@6000.  CAT_B samples: t@4000 and t@6000
            // t@6000 i.e 4500ms into decay period: CAT_A MG Factor = 10 - (0.9*4.5) = 5.95
            // CAT_B Gap Ratio = |1.01000 - 1.01007|/base spread 0.00003 = 2.3333  => CAT_B MG Factor of 6 > CAT_A Decayed factor 5.95
            // NEW CAT_B MG Factor = 6.0, NEW decay period 5000ms.
            // Therefore  CAT_B gradient = (6-1)/5 = -1.0 i.e y = 6 - x =>
            // Since at t@6000, shift 4.5seconds along x-axis => y = 6 - (x-4.5) = 10.5 - x
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getWindowMarketGapDataMap().get(FactorWindow.CAT_B).getMarketGapRatio(), new IsRoundedTo(-2.33));
            assertThat(wbf.getWindowMarketGapMap().get(FactorWindow.CAT_A).getGapFactorAtCurrentTime(), new IsRoundedTo(5.95));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(6.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(6.0));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.50));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(3.0));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.50));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(3.0));
        }

        // CAT_A y = 10-0.9x
        // CAT_B y = 10.5-x
        // intercept @ x=5 seconds from t@1500 i.e t@6500
        when:
        {   // at t@6550
            // i.e 550ms into CAT_B decay period: CAT_B MG Factor = 10.5 - 5.05 =  5.45
            // i.e 5050ms into CAT_A decay period: CAT_A MG Factor = 10 - (0.9x5.05) =  5.455
            // CAT_A > CAT_B!!
            prophet.clearOutputBuffer();
            prophet.incrementTime(550);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01005, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getWindowMarketGapMap().get(FactorWindow.CAT_A).getGapFactorAtCurrentTime(), new IsRoundedTo(5.455));
            assertThat(wbf.getWindowMarketGapMap().get(FactorWindow.CAT_B).getGapFactorAtCurrentTime(), new IsRoundedTo(5.45));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(10.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(5.455));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(1.36375));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(4.09125));
        }

        when:
        {   // at t@11500 i.e end of CAT_A decay period
            // i.e 5050ms into CAT_A decay period: CAT_A MG Factor = 10 - (0.9x10) =  1.0
            prophet.clearOutputBuffer();
            prophet.incrementTime(4950);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.01004, 0.00004));
        }

        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf.getWindowMarketGapMap().get(FactorWindow.CAT_A).getGapFactorAtCurrentTime(), new IsRoundedTo(1.0));
            assertThat(wbf.getMarketGap().getGapFactor(), isNear(10.0));
            assertThat(wbf.getMarketGap().getGapFactorAtCurrentTime(), isNear(1.0));
            assertThat(wbf.getMarketGap().getGapBidRatioFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapBidFactor(), isNear(0.25));
            assertThat(wbf.getMarketGap().getGapOfferRatioFactor(), isNear(0.75));
            assertThat(wbf.getMarketGap().getGapOfferFactor(), isNear(0.75));
        }
    }
}
