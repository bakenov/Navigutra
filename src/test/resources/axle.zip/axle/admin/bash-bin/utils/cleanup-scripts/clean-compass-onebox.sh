find /app/axle/mahi/log/mahifx-binlog -type f -mtime +2 -delete
find /app/axle/mahi/log/mahifx-binlog -type f -size +1M -exec sh -c 'cat /dev/null > "$1"' -- {} \;
find /app/axle/mahi/log/mahifx-tickstore -type f -size +1M -exec sh -c 'cat /dev/null > "$1"' -- {} \;
find /app/axle/mahi/log/graphite -type f -exec sh -c 'cat /dev/null > "$1"' -- {} \;
