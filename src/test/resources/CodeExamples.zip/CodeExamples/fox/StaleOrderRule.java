package com.anz.markets.efx.fox.firewall.rule.customer;

import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class StaleOrderRule implements Rule, Comparable<Rule> {

    private final long timeoutThreshold;
    private final TimeUnit timeUnit;
    private final LongSupplier timeSupplier;
    private final CustomerRuleType type;

    public StaleOrderRule(CustomerRuleType type, final long timeoutThreshold, final TimeUnit timeUnit, final LongSupplier timeSupplier) {
        this.type = type;
        this.timeoutThreshold = timeoutThreshold;
        this.timeUnit = timeUnit;
        this.timeSupplier = timeSupplier;
    }

    @Override
    public boolean validate(NewOrderSingleDecoder newOrderSingle, long currentTimeNanos) {
        if (currentTimeNanos + TimeUnit.NANOSECONDS.convert(timeoutThreshold, timeUnit) < timeSupplier.getAsLong())
            return false;
        return true;
    }

    @Override
    public String description() {
        return type.getDescription().toString();
    }

    @Override
    public Priority priority() {
        return type.getPriority();
    }

    @Override
    public int compareTo(Rule o) {
        return Integer.compare(type.getPriority().getPriority(), o.priority().getPriority());
    }
}
