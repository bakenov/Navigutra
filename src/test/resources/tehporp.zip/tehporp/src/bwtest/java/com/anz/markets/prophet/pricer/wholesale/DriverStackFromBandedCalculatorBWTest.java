package com.anz.markets.prophet.pricer.wholesale;


import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.impl.SpreadAndWeight;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DriverStackFromBandedCalculatorBWTest {

    private final DriverStackFromBandedCalculator driverStackFromBandedCalculator = new DriverStackFromBandedCalculatorImpl();

    private static final int REPS = 200_000, THRESHOLD = 1000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private WholesaleBook wholesaleBook = new WholesaleBook(Market.WSP_A, Instrument.AUDUSD);

    List<SpreadAndWeight> spreadAndWeights = new ArrayList<>();

    public DriverStackFromBandedCalculatorBWTest() throws IOException {
        driverStackFromBandedCalculator.applyConfiguration(new DriverInstrumentWholesaleBookManagerTest().indexedConfigurationData);


        spreadAndWeights.add(new SpreadAndWeight(Level.QTY_1M, 0.4, 0.4, 0.4, 0.4));
        spreadAndWeights.add(new SpreadAndWeight(Level.QTY_2M, 0.4, 0.4, 0.4, 0.4));
        spreadAndWeights.add(new SpreadAndWeight(Level.QTY_10M, 0.4, 0.4, 0.4, 0.4));
        spreadAndWeights.add(new SpreadAndWeight(Level.QTY_15M, 0.4, 0.4, 0.4, 0.4));
    }

    public void scenario_SpreadBasedBookFormation() {
        wholesaleBook.reset();
        wholesaleBook.initInstrument(Instrument.AUDUSD);
        final WholesaleBookFactorsImpl wholesaleBookFactors = wholesaleBook.getWholesaleBookFactors();

        wholesaleBookFactors.setSkewedMidPrice(1.1);
        wholesaleBookFactors.setStackSpreadAndWeights(spreadAndWeights);

        wholesaleBookFactors.addConfigSpread(Level.QTY_1M, 0.4);
        wholesaleBookFactors.addConfigSpread(Level.QTY_2M, 0.5);
        wholesaleBookFactors.addConfigSpread(Level.QTY_4M, 0.6);
        wholesaleBookFactors.addConfigSpread(Level.QTY_10M, 0.7);
        wholesaleBookFactors.addConfigSpread(Level.QTY_15M, 0.8);
        wholesaleBookFactors.addConfigSpread(Level.QTY_30M, 0.9);

        wholesaleBookFactors.setModelSpread(0.4);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_1M).setModelSpread(0.4);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_2M).setModelSpread(0.5);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_4M).setModelSpread(0.6);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_10M).setModelSpread(0.7);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_15M).setModelSpread(0.8);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_30M).setModelSpread(0.9);

        driverStackFromBandedCalculator.execute(wholesaleBook);
    }

    @Test
    public void test_SpreadBasedBookFormation() {
        helper.testAllocationNotExceeded(
                this::scenario_SpreadBasedBookFormation,
                REPS, REPS,
                THRESHOLD
        );
    }

}
