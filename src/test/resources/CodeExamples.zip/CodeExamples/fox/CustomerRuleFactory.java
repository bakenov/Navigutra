package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.fox.firewall.rule.customer.CustomerRuleType;

public interface CustomerRuleFactory {

    Rule buildRule(CharSequence ruleClassName);

    Rule buildRule(CustomerRuleType type);

}
