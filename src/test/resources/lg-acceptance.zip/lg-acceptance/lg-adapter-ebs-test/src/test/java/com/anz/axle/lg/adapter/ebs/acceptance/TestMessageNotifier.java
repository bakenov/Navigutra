package com.anz.axle.lg.adapter.ebs.acceptance;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.fix.sessioncode.generators.MessageGenerator;
import software.chronicle.fix.sessioncode.messages.Logout;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.FixSessionHandler;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultLogon;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultLogout;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultMarketDataRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultReject;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultUserRequest;

public class TestMessageNotifier implements MessageNotifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(TestMessageNotifier.class);
    private final BlockingQueue<StandardHeaderTrailer> queue = new ArrayBlockingQueue<>(1024);

    public BlockingQueue<StandardHeaderTrailer> queue() {
        return queue;
    }

    private void queue(final StandardHeaderTrailer original, final StandardHeaderTrailer copy) {
        LOGGER.info("Received: {}", original);
        queue.add(copyTo(original, copy));
    }

    private StandardHeaderTrailer copyTo(final StandardHeaderTrailer from, final StandardHeaderTrailer to) {
        from.copyTo(to);
        return to;
    }

    @Override
    public void onLogon(final FixSessionHandler session, final Logon logon) {
        queue(logon, new DefaultLogon());
    }

    @Override
    public void onExecutionReport(final FixSessionHandler session, final ExecutionReport executionReport) {
        queue(executionReport, new DefaultExecutionReport());
    }

    @Override
    public void onReject(final FixSessionHandler session, final Reject reject) {
        queue(reject, new DefaultReject());
    }

    @Override
    public void onNewOrderSingle(final FixSessionHandler session, final NewOrderSingle newOrderSingle) {
        queue(newOrderSingle, new DefaultNewOrderSingle());
    }

    @Override
    public void onLogout(final FixSessionHandler session, final Logout logout) {
        queue(logout, new DefaultLogout());
    }

    @Override
    public void onUserRequest(final FixSessionHandler session, final UserRequest userRequest) {
        queue(userRequest, new DefaultUserRequest());
    }

    @Override
    public void onMarketDataRequest(final FixSessionHandler session, final MarketDataRequest marketDataRequest) {
        queue(marketDataRequest, new DefaultMarketDataRequest());
    }

    @Override
    public void onOrderCancelRequest(final FixSessionHandler session, final OrderCancelRequest orderCancelRequest) {
        queue(orderCancelRequest, new DefaultOrderCancelRequest());
    }

    @Override
    public void onUnsupportedMessageType(final FixSessionHandler session, final int msgType) {
        LOGGER.error("onUnsupportedMessageType |{}| received!", msgType);
    }
}
