package com.anz.markets.prophet.risk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.status.Context;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.util.function.Consumer;

import static com.anz.markets.prophet.domain.Currency.AUD;
import static com.anz.markets.prophet.domain.marketrisk.impl.CorrelatedRiskFactorsImplTest.createCorrelatedRiskFactorsImpl;
import static com.anz.markets.prophet.risk.GradientOptimalPositionManagerTest.createIndexedConfigurationData;
import static com.anz.markets.prophet.util.AmountUnit.MILLIONS;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GradientOptimalPositionManagerBWTest {
    private static final int REPS = 100_000;
    private static final int ALLOCATION_BUDGET = 400;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private final Consumer<Positions> consumerOfBiasPositions;
    private final Positions biasPositions;

    private double increment = 1000d;

    private final Consumer<OptimalPositions> consumers = consumers -> {
    };

    public GradientOptimalPositionManagerBWTest() throws Exception {
        Context.context().region(Region.GB);
        final GradientOptimalPositionManager optimalPositionManager = GradientOptimalPositionManagerTest.getGradientOptimalPositionManager(consumers, createCorrelatedRiskFactorsImpl(13), createIndexedConfigurationData());
        consumerOfBiasPositions = optimalPositionManager.consumerOfPositions();
        biasPositions = MidRateTestHelper.biasPositionsFromPositions(MidRateTestHelper.createPositions(AUD, MILLIONS.toDollar(100), 1));
        warmup();
    }

    public void warmup() {
        calculateOptimalPosition(biasPositions);
    }

    @Test
    public void testOps() {
        biasPositions.getPosition1().setPositionInNotional(100_000 + increment);
        increment++;
        helper.testAllocationNotExceeded(
                () -> calculateOptimalPosition(biasPositions),
                ALLOCATION_BUDGET
        );
    }

    public void calculateOptimalPosition(Positions positions) {
        for (int i = 0; i < REPS; i++) {
            consumerOfBiasPositions.accept(positions);
        }
    }
}
