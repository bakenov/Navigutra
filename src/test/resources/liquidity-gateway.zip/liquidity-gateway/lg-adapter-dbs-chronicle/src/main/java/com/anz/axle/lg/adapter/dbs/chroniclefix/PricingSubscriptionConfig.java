package com.anz.axle.lg.adapter.dbs.chroniclefix;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

@Configuration
public class PricingSubscriptionConfig {

    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final AsyncMarketDataSubscriber asyncMarketDataSubscriber;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final VenueSymbolMatrix fxNdfVenueSymbolMatrix;
    private final VenueSymbolMatrix fxFwdVenueSymbolMatrix;
    private final Map<String, Set<Tenor>> fxNdfSymbolTenors;
    private final Map<String, Set<Tenor>> fxFwdSymbolTenors;
    private final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory;
    private final Venue venue;

    public PricingSubscriptionConfig(final TopicRegistry pricingTopicRegistry,
                                     final PublicationRegistry publicationRegistry,
                                     final AsyncMarketDataSubscriber asyncMarketDataSubscriber,
                                     @Value("${venue}") final Venue venue,
                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                     @Value("#{${symbol.venues.FXNDF}}") final Map<String, Set<Venue>> fxNdfSymbolVenues,
                                     @Value("#{${symbol.venues.FXFWD}}") final Map<String, Set<Venue>> fxFwdSymbolVenues,
                                     @Value("#{${symbol.tenors.FXNDF.${venue}}}") final Map<String, Set<Tenor>> fxNdfSymbolTenors,
                                     @Value("#{${symbol.tenors.FXFWD.${venue}}}") final Map<String, Set<Tenor>> fxFwdSymbolTenors,
                                     final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory) {
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.asyncMarketDataSubscriber = Objects.requireNonNull(asyncMarketDataSubscriber);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.fxNdfVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxNdfSymbolVenues));
        this.fxFwdVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxFwdSymbolVenues));
        this.fxNdfSymbolTenors = Objects.requireNonNull(fxNdfSymbolTenors);
        this.fxFwdSymbolTenors = Objects.requireNonNull(fxFwdSymbolTenors);
        this.stringToIntQuoteIdCacheFactory = Objects.requireNonNull(stringToIntQuoteIdCacheFactory);
        this.venue = Objects.requireNonNull(venue);
    }

    @PostConstruct
    void init() {
        initSpotPublicationsAndSubscriptions();
        initPublicationsAndSubscriptions(SecurityType.FXNDF, fxNdfVenueSymbolMatrix, fxNdfSymbolTenors);
        initPublicationsAndSubscriptions(SecurityType.FXFWD, fxFwdVenueSymbolMatrix, fxFwdSymbolTenors);
    }

    private void initSpotPublicationsAndSubscriptions() {
        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP));

            publicationRegistry.registerPublication(topic);

            final DbsMarketDataSubscription fixSubscription = new DbsMarketDataSubscription(SymbolNormaliser.toSymbol7(symbol), SecurityType.FXSPOT, Tenor.SP, venue, stringToIntQuoteIdCacheFactory.get());
            asyncMarketDataSubscriber.schedule(fixSubscription);
        });
    }

    private void initPublicationsAndSubscriptions(final SecurityType securityType,
                                                  final VenueSymbolMatrix venueSymbolMatrix,
                                                  final Map<String, Set<Tenor>> symbolTenors) {
        venueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {

            final Set<Tenor> tenors = symbolTenors.getOrDefault(symbol, Collections.emptySet());
            tenors.forEach(tenor -> {
                final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol, securityType, tenor));
                publicationRegistry.registerPublication(topic);

                final DbsMarketDataSubscription fixSubscription = new DbsMarketDataSubscription(
                        SymbolNormaliser.toSymbol7(symbol), securityType, tenor, venue, stringToIntQuoteIdCacheFactory.get());
                asyncMarketDataSubscriber.schedule(fixSubscription);
            });
        });
    }
}
