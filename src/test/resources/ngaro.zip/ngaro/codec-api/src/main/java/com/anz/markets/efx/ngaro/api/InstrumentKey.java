package com.anz.markets.efx.ngaro.api;

import java.time.LocalDate;
import java.util.Optional;

public interface InstrumentKey {
    long instrumentId();
    String symbol();
    SecurityType securityType();
    Tenor tenor();
    Optional<LocalDate> settlementDate();

    static long instrumentId(final CharSequence symbol) {
        return instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP);
    }

    static long instrumentId(final CharSequence symbol, final SecurityType securityType, final Tenor tenor) {
        return instrumentId(symbol, securityType, tenor, null);
    }

    static long instrumentId(final CharSequence symbol, final SecurityType securityType, final Tenor tenor, final LocalDate settlmentDate) {
        return DefaultInstrumentKey.encodeInstrumentId(symbol, securityType, tenor, settlmentDate);
    }


    static InstrumentKey of(final long instrumentId) {
        return new DefaultInstrumentKey(instrumentId);
    }

    static InstrumentKey of(final CharSequence symbol, final SecurityType securityType, final Tenor tenor) {
        return new DefaultInstrumentKey(instrumentId(symbol, securityType, tenor, null));
    }

    static InstrumentKey of(final CharSequence symbol) {
        return of(symbol, SecurityType.FXSPOT, Tenor.SP);
    }

    static InstrumentKey of(final CharSequence symbol, final SecurityType securityType, final LocalDate settlementDate) {
        return new DefaultInstrumentKey(instrumentId(symbol, securityType, Tenor.BROKEN, settlementDate));
    }

    interface Lookup {
        InstrumentKey lookup(long instrumentId);

        default InstrumentKey lookup(final CharSequence symbol, final SecurityType securityType, final Tenor tenor, final LocalDate settlmentDate) {
            return lookup(instrumentId(symbol, securityType, tenor, settlmentDate));
        }
    }
}
