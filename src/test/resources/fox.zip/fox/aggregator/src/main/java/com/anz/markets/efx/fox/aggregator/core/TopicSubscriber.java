package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;

import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Subscription;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;

public class TopicSubscriber implements Subscriber {
    private final Connection connection;
    private final EndPointStatusHandler endPointStatusHandler;
    private final MessageHandler messageHandler;
    private final String topicName;

    public TopicSubscriber(final Connection connection,
                           final EndPointStatusHandler endPointStatusHandler,
                           final MessageHandler messageHandler,
                           final String topicName) {
        this.connection = Objects.requireNonNull(connection);
        this.messageHandler = Objects.requireNonNull(messageHandler);
        this.endPointStatusHandler = Objects.requireNonNull(endPointStatusHandler);
        this.topicName = Objects.requireNonNull(topicName);
    }

    @Override
    public Subscription subscribe() {
        final Topic tradingResponsesTopic = DefaultTopic.create(topicName);
        return connection.openSubscription(tradingResponsesTopic, endPointStatusHandler, messageHandler);
    }
}
