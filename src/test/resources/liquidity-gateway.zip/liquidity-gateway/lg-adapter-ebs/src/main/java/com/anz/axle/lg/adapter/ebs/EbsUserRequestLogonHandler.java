package com.anz.axle.lg.adapter.ebs;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.UserRequestData;

public class EbsUserRequestLogonHandler implements LogonHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsUserRequestLogonHandler.class);
    private final String sessionName;
    private final LogonHandler marketDataSubscriberLogonHandler;
    private final UserRequestHandler userRequestHandler;

    public EbsUserRequestLogonHandler(final String sessionName,
                                      final LogonHandler marketDataSubscriberLogonHandler,
                                      final UserRequestHandler userRequestHandler) {
        this.sessionName = Objects.requireNonNull(sessionName);
        this.marketDataSubscriberLogonHandler = Objects.requireNonNull(marketDataSubscriberLogonHandler);
        this.userRequestHandler = Objects.requireNonNull(userRequestHandler);
    }

    @Override
    public void onLogon() {
        LOGGER.debug("{} Logon received.", sessionName);
        userRequestHandler.send(UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_LOGONUSER);
    }

    @Override
    public void onLogout() {
        LOGGER.debug("{} Logout received.", sessionName);
        marketDataSubscriberLogonHandler.onLogout();
    }
}
