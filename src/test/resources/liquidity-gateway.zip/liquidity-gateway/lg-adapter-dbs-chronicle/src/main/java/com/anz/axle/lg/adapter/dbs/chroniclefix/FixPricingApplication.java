package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Objects;

import software.chronicle.fix.staticcode.FixSessionHandler;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.PerformanceProbes;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MarketDataRequestReject;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MessageNotifier;

public class FixPricingApplication extends FixSessionApplication implements MessageNotifier {

    private final ChronicleMessageHandler<MarketDataIncrementalRefresh> incrementalRefreshHandler;
    private final ChronicleMessageHandler<MarketDataRequestReject> marketDataRequestRejectHandler;

    public FixPricingApplication(final ChronicleMessageHandler<MarketDataIncrementalRefresh> incrementalRefreshHandler,
                                 final ChronicleMessageHandler<MarketDataRequestReject> marketDataRequestRejectHandler,
                                 final ApplicationLogonHandler applicationLogonHandler) {
        super(Objects.requireNonNull(applicationLogonHandler));
        this.incrementalRefreshHandler = Objects.requireNonNull(incrementalRefreshHandler);
        this.marketDataRequestRejectHandler = Objects.requireNonNull(marketDataRequestRejectHandler);
    }

    @Override
    public void onMarketDataRequestReject(final FixSessionHandler session, final MarketDataRequestReject marketDataRequestReject) {
        marketDataRequestRejectHandler.accept(marketDataRequestReject);
    }

    @Override
    public void onMarketDataIncrementalRefresh(final FixSessionHandler session, final MarketDataIncrementalRefresh marketDataIncrementalRefresh) {
        if (session.probes() instanceof PerformanceProbes) {
            final PerformanceProbes probes = (PerformanceProbes) session.probes();
            incrementalRefreshHandler.accept(marketDataIncrementalRefresh, probes.readTimeNS());
        } else {
            incrementalRefreshHandler.accept(marketDataIncrementalRefresh);
        }
    }
}