package com.anz.axle.lg.adapter.apama.ebs;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import com.anz.markets.efx.ngaro.api.Tenor;


public class SettleTypeToTenor implements Function<String, Tenor> {
    static final String SETTLTYPE_SPOT = "0";

    private final Map<String, Tenor> cache = new HashMap<>();

    @Override
    public Tenor apply(final String settleType) {
        return cache.computeIfAbsent(settleType, st -> {
            if (SETTLTYPE_SPOT.equals(st)) {
                return Tenor.SP;
            } else {
                return Tenor.valueOf(st);
            }
        });
    }
}
