package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ToolsCommonTailer;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.util.ObjectSerializer;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.DocumentContext;
import org.jetbrains.annotations.TestOnly;

import java.util.Objects;

public enum ChronicleQueueWrappers {
    INSTANCE;

    private static final String STRING_EMPTY = "";

    // One instance for each type per thread, to avoid collision when running multiple processes in the same JVM
    private ThreadLocal<CQBytes> reader = ThreadLocal.withInitial(CQBytes::new);
    private ThreadLocal<CQBytes> writer = ThreadLocal.withInitial(CQBytes::new);

    // Used by ToolsCommon components only!
    private static CQTailer cqTailer = new CQTailer();

    public static ProphetBytes wrapReader(final DocumentContext dc) {
        cqTailer.setContext(dc);
        return INSTANCE.reader.get().withBytes(Objects.requireNonNull(dc.wire()).bytes());
    }

    public static ProphetBytes wrapWriter(final DocumentContext dc) {
        return INSTANCE.writer.get().withBytes(Objects.requireNonNull(dc.wire()).bytes());
    }

    public static ProphetBytes wrapBytes(final Bytes bytes) {
        return INSTANCE.writer.get().withBytes(bytes);
    }

    @TestOnly
    public static ProphetBytes wrapFixedSize() {
        return INSTANCE.writer.get().withBytes(Bytes.allocateDirect(LegacyChroniclePersister.EXCERPT_CAPACITY));
    }

    /**
     * Wrapper class for CQ byte streams
     **/
    private static class CQBytes implements ProphetBytes {
        private Bytes bytes;

        private CQBytes withBytes(final Bytes bytes) {
            this.bytes = bytes;
            return this;
        }

        @Override
        public void skipBytesRead(final int bytesToSkip) {
            bytes.readSkip(bytesToSkip);
        }

        @Override
        public boolean readBoolean() {
            return bytes.readBoolean();
        }

        @Override
        public byte readByte() {
            return bytes.readByte();
        }

        @Override
        public long readLong() {
            return bytes.readLong();
        }

        @Override
        public int readInt() {
            return bytes.readInt();
        }

        @Override
        public double readDouble() {
            return bytes.readDouble();
        }

        @Override
        public float readFloat() {
            return bytes.readFloat();
        }

        @Override
        public String readUTF8() {
            final long posBeforeRead = bytes.readPosition();
            final String utf8 = bytes.readUtf8();

            // Address CQ4 bug
            if (bytes.readPosition() == posBeforeRead) {
                bytes.readPosition(posBeforeRead + 1);
                return STRING_EMPTY;
            }

            return utf8;
        }

        @Override
        public void readUTF8(StringBuilder sb) {
            bytes.readUtf8(sb);
        }

        @Override
        public short readShort() {
            return bytes.readShort();
        }

        @Override
        public <E> E readEnum(final Class<E> clazz) {
            return (E) bytes.readEnum(clazz);
        }

        @Override
        public int read(final byte[] bytes, final int offset, final int length) {
            return this.bytes.read(bytes, offset, length);
        }

        @Override
        public int read(final byte[] bytes) {
            return this.bytes.read(bytes);
        }

        @Override
        @NotGcFriendly("Garbagy")
        public <E> E readObject(final Class<E> clazz) {
            return ObjectSerializer.INSTANCE.readSerializable(bytes);
        }

        @Override
        public void writeBoolean(final boolean value) {
            bytes.writeBoolean(value);
        }

        @Override
        public void writeByte(final byte value) {
            bytes.writeByte(value);
        }

        @Override
        public void writeInt(final int value) {
            bytes.writeInt(value);
        }

        @Override
        public void writeLong(final long value) {
            bytes.writeLong(value);
        }

        @Override
        public void writeFloat(final float value) {
            bytes.writeFloat(value);
        }

        @Override
        public void writeDouble(final double value) {
            bytes.writeDouble(value);
        }

        @Override
        public void writeUTF8(final String value) {
            bytes.writeUtf8(value);
        }

        @Override
        public void writeUTF8(final CharSequence value) {
            bytes.writeUtf8(value);
        }

        @Override
        public void writeShort(final short value) {
            bytes.writeShort(value);
        }

        @Override
        public <E extends Enum<E>> void writeEnum(final Enum<E> value) {
            bytes.writeEnum(value);
        }

        @Override
        public void write(final byte[] bytes, final int offset, final int length) {
            this.bytes.write(bytes, offset, length);
        }

        @Override
        @NotGcFriendly("Garbagy")
        public <E> void writeObject(final E object) {
            ObjectSerializer.INSTANCE.writeSerializable(bytes, object);
        }

        @Override
        public ToolsCommonTailer getTailer() {
            return cqTailer;
        }

        @Override
        public void position(final long position) {
            readPosition(position);
        }

        @Override
        public long position() {
            return readPosition();
        }

        @Override
        public long readPosition() {
            return bytes.readPosition();
        }

        @Override
        public void readPosition(final long position) {
            bytes.readPosition(position);
        }

        @Override
        public long writePosition() {
            return bytes.writePosition();
        }

        @Override
        public void writePosition(final long position) {
            bytes.writePosition(position);
        }

        @Override
        public int length() {
            return bytes.length();
        }
    }

    /**
     * Wrapper class for CQ document context + bytes, only used by ToolsCommon
     **/
    private static class CQTailer implements ToolsCommonTailer {
        private DocumentContext readerDocumentContext;
        private Bytes readerBytes;

        void setContext(final DocumentContext readerDocumentContext) {
            this.readerDocumentContext = readerDocumentContext;
            this.readerBytes = Objects.requireNonNull(readerDocumentContext.wire()).bytes();
        }

        @Override
        public long position() {
            return readerBytes.readPosition();
        }

        @Override
        public long index() {
            return readerDocumentContext.index();
        }

        @Override
        public void position(final long position) {
            readerBytes.readPosition(position);
        }
    }
}
