package com.anz.axle.lg.adapter.deut;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

@Configuration
public class PricingSubscriptionConfig {

    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final AsyncMarketDataSubscriber asyncMarketDataSubscriber;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final Venue venue;
    private final boolean fullRefresh;
    private final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory;


    public PricingSubscriptionConfig(final TopicRegistry pricingTopicRegistry,
                                     final PublicationRegistry publicationRegistry,
                                     final AsyncMarketDataSubscriber asyncMarketDataSubscriber,
                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                     @Value("${deut.fix.pricing.subscription.fullRefresh}") final boolean fullRefresh,
                                     final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory) {
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.asyncMarketDataSubscriber = Objects.requireNonNull(asyncMarketDataSubscriber);
        this.stringToIntQuoteIdCacheFactory = Objects.requireNonNull(stringToIntQuoteIdCacheFactory);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.fullRefresh = fullRefresh;
        this.venue = Venue.DEUT;
    }

    @PostConstruct
    void init() {
        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol));
            publicationRegistry.registerPublication(topic);

            final DeutMarketDataSubscription fixSubscription =
                    DeutMarketDataSubscription.fullRefreshForIdAndSymbol(SymbolNormaliser.toSymbol7(symbol), fullRefresh, stringToIntQuoteIdCacheFactory.get());
            asyncMarketDataSubscriber.schedule(fixSubscription);
        });
    }
}
