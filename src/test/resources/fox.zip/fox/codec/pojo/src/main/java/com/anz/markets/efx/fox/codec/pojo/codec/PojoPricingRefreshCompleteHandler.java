package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoPricingRefreshCompleteHandler implements PricingRefreshCompleteHandler {

    private final Consumer<? super PricingRefreshComplete> messageConsumer;

    private PricingRefreshComplete message = SorMessage.pricingRefreshComplete();

    public PricingRefreshComplete message() {
        return message;
    }

    public PojoPricingRefreshCompleteHandler() {
        this(msg -> {});
    }

    public PojoPricingRefreshCompleteHandler(final Consumer<? super PricingRefreshComplete> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.pricingRefreshComplete();
        message.header.source = source;
        message.header.sourceSeq = sourceSeq;
    }

    @Override
    public void onBody(final Body body) {
        message.body.instrumentId = body.instrumentId();
        message.body.forceSnapshot = body.forceSnapshot();
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
