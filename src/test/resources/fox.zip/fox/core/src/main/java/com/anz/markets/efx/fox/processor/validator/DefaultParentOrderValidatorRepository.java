package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.processor.state.OrderTextMessage;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DefaultParentOrderValidatorRepository implements ParentOrderValidatorRepository {
    private final Map<String, ParentOrderValidator> parentOrderValidatorMap = new HashMap<>();
    private final AlwaysRejectParentOrderValidator rejectValidator;

    public DefaultParentOrderValidatorRepository(final ParentOrderValidator.ErrorHandler errorHandler,
                                                 final ParentOrderValidator.NamedValidator... namedValidators) {
        Objects.requireNonNull(errorHandler);
        Objects.requireNonNull(namedValidators);

        rejectValidator = new AlwaysRejectParentOrderValidator(errorHandler, OrderTextMessage.UNKNOWN_STRATEGY.getText());

        Arrays.stream(namedValidators)
                .forEach(namedValidator -> parentOrderValidatorMap.put(namedValidator.name(), namedValidator));
    }

    @Override
    public ParentOrderValidator lookupByStrategyName(final String strategyName) {
        return parentOrderValidatorMap.getOrDefault(strategyName, rejectValidator);
    }
}
