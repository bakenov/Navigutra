package com.anz.markets.efx.ngaro.core;


import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;


public class LongCodecTest {
    interface TestBody {
        void evaluate(final long value, final MutableAsciiString asciiString);
    }

    private void scatterIntervalsThroughLongRange(final long interval, final long stepMultiplier, final TestBody testBody) {
        final MutableAsciiString asciiString = AsciiString.fixedLength(20);

        long value = 0;
        long stopValue = interval;

        while(value >= 0 && value < Long.MAX_VALUE) {
            System.out.println("Encoding from " + value + " to " + stopValue);
            while(value < stopValue) {
                testBody.evaluate(value, asciiString);
                value++;
            }
            stopValue =  Math.min(Long.MAX_VALUE, stopValue * stepMultiplier);
            value = Math.min(Long.MAX_VALUE, stopValue - interval);
        }
    }

    @Test
    public void encodeLong() {
        scatterIntervalsThroughLongRange(1_000_000, 999, (value, asciiString) -> {
            LongCodec.encodeSigned(value, asciiString);
            assertThat(LongCodec.decodeSigned(asciiString)).isEqualTo(value);
        });
    }

    @Test
    public void encodeNegativeLong() {
        scatterIntervalsThroughLongRange(2_000_000, 888, (value, asciiString) -> {
            LongCodec.encodeSigned(-value, asciiString);
            assertThat(LongCodec.decodeSigned(asciiString)).isEqualTo(-value);
        });
    }

    @Test
    public void encodeLongToHex() {
        scatterIntervalsThroughLongRange(3_000_000, 777, (value, asciiString) -> {
            LongCodec.encodeUnsignedHex(value, asciiString);
            assertThat(LongCodec.decodeUnsignedHex(asciiString)).isEqualTo(value);
        });
    }

    @Test
    public void encodeNegativeLongToHex() {
        scatterIntervalsThroughLongRange(4_000_000, 789, (value, asciiString) -> {
            LongCodec.encodeUnsignedHex(-value, asciiString);
            assertThat(LongCodec.decodeUnsignedHex(asciiString)).isEqualTo(-value);
        });
    }

    @Test(expected = NumberFormatException.class)
    public void decode_hex_should_throw_number_format_exception() {
        final MutableAsciiString asciiString = AsciiString.fixedLength(20);
        asciiString.append("blah");

        LongCodec.decodeUnsignedHex(asciiString);
    }

    @Test(expected = NumberFormatException.class)
    public void decode_should_throw_number_format_exception() {
        final MutableAsciiString asciiString = AsciiString.fixedLength(20);
        asciiString.append("blah");

        LongCodec.decodeSigned(asciiString);
    }

    @Test(expected = NumberFormatException.class)
    public void decode_hex_should_throw_number_format_exception_when_sign_is_provided() {
        final MutableAsciiString asciiString = AsciiString.fixedLength(20);
        asciiString.append("-FF");

        LongCodec.decodeUnsignedHex(asciiString);
    }

}

