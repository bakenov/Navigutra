package com.anz.markets.prophet.chime;


import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.SpotDateRollChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import java.util.function.Consumer;

@ManagedResource
public class ChimeManager {

    protected static final Logger LOGGER = LoggerFactory.getLogger(ChimeManager.class);

    private final Consumer<TradingTimeZoneChime> tradingTimeZoneChimeConsumer;
    private final Consumer<HourChime> hourChimeConsumer;
    private final Consumer<EndOfWeekChime> endOfWeekChimeConsumer;
    private final Consumer<SpotDateRollChime> spotDateRollChimeConsumer = NoConsumer.instance();

    private final TradingTimeZoneChime tradingTimeZoneChime = TradingTimeZoneChime.INSTANCE;

    public ChimeManager(final Consumer<TradingTimeZoneChime> tradingTimeZoneChimeConsumer,
                        final Consumer<HourChime> hourChimeConsumer,
                        final Consumer<EndOfWeekChime> endOfWeekChimeConsumer) {
        this.tradingTimeZoneChimeConsumer = tradingTimeZoneChimeConsumer;
        this.hourChimeConsumer = hourChimeConsumer;
        this.endOfWeekChimeConsumer = endOfWeekChimeConsumer;
    }

    @ManagedAttribute
    public TradingTimeZone getCurrentTradingTimeZone() {
        return tradingTimeZoneChime.getTradingTimeZone();
    }

    @ManagedAttribute
    public int getUTCHour() {
        return HourChime.INSTANCE.getHourOfDayUTC();
    }

    @NotGcFriendly("new DateTime...but every hour")
    @ManagedOperation(description = "TradingTimeZone LDN")
    public boolean triggerUTCHourChime() {
        return triggerUTCHourChime(new DateTime(DateTimeZone.UTC).getHourOfDay());
    }

    @ManagedOperation
    public boolean triggerUTCHourChime(int hourOfDayInUTC) {
        try {
            HourChime.INSTANCE.setHourOfDayUTC(hourOfDayInUTC);
            hourChimeConsumer.accept(HourChime.INSTANCE);
            return true;
        } catch (RuntimeException e) {
            LOGGER.error("unable to send hourChime: ", e);
        }
        return false;
    }

    @ManagedOperation
    public boolean triggerEndOfWeekChime() {
        try {
            endOfWeekChimeConsumer.accept(EndOfWeekChime.INSTANCE);
            return true;
        } catch (RuntimeException e) {
            LOGGER.error("unable to send endOfWeekChime: ", e);
        }
        return false;
    }

    @ManagedOperation
    public boolean triggerSpotDateRollChime() {
        try {
            spotDateRollChimeConsumer.accept(SpotDateRollChime.INSTANCE);
            return true;
        } catch (RuntimeException e) {
            LOGGER.error("unable to send spotDateRollChime: ", e);
        }
        return false;
    }

    @ManagedOperation(description = "TradingTimeZone LDN")
    public boolean triggerTimeZoneLondon() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.LDN);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone LDNNYK")
    public boolean triggerTimeZoneLondonNewYork() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.LDNNYK);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone NYK")
    public boolean triggerTimeZoneNewYork() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.NYK);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone TWILIGHT")
    public boolean triggerTimeZoneTwilight() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.TWILIGHT);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone ROLL")
    public boolean triggerTimeZoneRoll() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.ROLL);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone SNG")
    public boolean triggerTimeZoneSingapore() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.SNG);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone SNGLDN")
    public boolean triggerTimeZoneSingaporeLondon() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.SNGLDN);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone SNGMON")
    public boolean triggerTimeZoneSingaporeMonday() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.SNGMON);
        return trigger();
    }

    @ManagedOperation(description = "TradingTimeZone WEEKEND")
    public boolean triggerTimeZoneWeekend() {
        tradingTimeZoneChime.setTradingTimeZone(TradingTimeZone.WEEKEND);
        return trigger();
    }

    private boolean trigger() {
        try {
            tradingTimeZoneChimeConsumer.accept(tradingTimeZoneChime);
            return true;
        } catch (RuntimeException e) {
            LOGGER.error("unable to trigger tradingTimeZoneChime for {}: ", tradingTimeZoneChime.getTradingTimeZone(), e);
        }
        return false;
    }


}

