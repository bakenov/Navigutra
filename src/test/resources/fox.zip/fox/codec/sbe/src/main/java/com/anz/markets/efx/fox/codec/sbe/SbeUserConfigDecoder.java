package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringDecoders;

final class SbeUserConfigDecoder {
    private final UserConfigDecoder userConfigDecoder = new UserConfigDecoder();
    private final Consumer<StringBuilder> messageLogger = userConfigDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.UserConfig encodingOrder = EncodingOrder.UserConfig.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final UserConfigHandler userConfigHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.UserConfig.INITIAL;
        userConfigDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            userConfigHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            userConfigHandler.messageForwarder(messageForwarder);
            userConfigHandler.messageLogger(messageLogger);
            body.decode(userConfigHandler);
            userConfigHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.UserConfig.INITIAL;
            userConfigDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements UserConfigHandler.Body {
        private final EnumerableSetDecoder<UserGroup> userGroups = new SbeUserGroupSetDecoder(userConfigDecoder::userGroups);
        private final StringDecoder userName = StringDecoders.forFixedLength(
                userConfigDecoder::userName, UserConfigDecoder.userNameLength());
        private final StringDecoder location = StringDecoders.forFixedLength(
                userConfigDecoder::location, UserConfigDecoder.locationLength());

        void decode(final UserConfigHandler userConfigHandler) {
            encodingOrder = EncodingOrder.UserConfig.BODY;
            userConfigHandler.onBody(this);
        }

        @Override
        public StringDecoder userName() {
            encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
            return userName;
        }

        @Override
        public EnumerableSetDecoder<UserGroup> userGroups() {
            encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
            return userGroups;
        }

        @Override
        public StringDecoder location() {
            encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
            return location;
        }
    }
}
