package com.anz.markets.efx.ngaro.sbe;

import java.io.IOException;
import java.util.Objects;

import org.agrona.ExpandableArrayBuffer;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.LongCodec;

/**
 * Decoder for variable length string from an SBE data element.
 * <p/>
 * This class is NOT thread safe!
 */
public final class VariableStringDecoder implements StringDecoder {

    private final VariableStringSource source;
    private final ExpandableArrayBuffer buffer;

    public VariableStringDecoder(final VariableStringSource source, final int initialBufferSize) {
        Objects.requireNonNull(source);
        if (initialBufferSize < 0) {
            throw new IllegalArgumentException("Negative value for initialBufferSize: " + initialBufferSize);
        }
        this.source = source;
        this.buffer = new ExpandableArrayBuffer(initialBufferSize);
    }

    @Override
    public String decodeStringOrNull() {
        final int len = source.getBytes(buffer, 0, Integer.MAX_VALUE);
        return len == 0 ? null : new String(buffer.byteArray(), 0, len);
    }

    @Override
    public <T> T decodeAndCache(final ByteValueCache<T> cache) {
        final int len = source.getBytes(buffer, 0, Integer.MAX_VALUE);
        return len == 0 ? null : cache.lookupOrCache(buffer, ExpandableArrayBuffer::getByte, len);
    }

    @Override
    public <A extends Appendable> A decodeTo(final A target, final int maxTargetLength) {
        final int len = source.getBytes(buffer, 0, maxTargetLength);
        for (int i = 0; i < len; i++) {
            try {
                target.append((char) buffer.getByte(i));
            } catch (final IOException e) {
                throw new RuntimeException("append failed, e=" + e, e);
            }
        }
        return target;
    }

    @Override
    public <T> int decodeTo(final T target, final ByteWriter<? super T> writer, final int targetOffset, final int maxTargetLength) {
        final int len = source.getBytes(buffer, 0, maxTargetLength);
        for (int i = 0; i < len; i++) {
            writer.writeByte(target, i + targetOffset, buffer.getByte(i));
        }
        return len;
    }

    @Override
    public int decodeToNull() {
        return source.getBytes(buffer, 0, Integer.MAX_VALUE);
    }

    @Override
    public long decodeLong(final long defaultValue) {
        final int len = source.getBytes(buffer, 0, Integer.MAX_VALUE);
        if (len == 0) {
            return defaultValue;
        }
        return LongCodec.decodeSigned(buffer, ExpandableArrayBuffer::getByte, len, 10);
    }
}