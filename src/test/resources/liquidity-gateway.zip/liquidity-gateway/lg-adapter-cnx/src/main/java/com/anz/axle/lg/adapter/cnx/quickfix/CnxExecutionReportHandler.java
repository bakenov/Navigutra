package com.anz.axle.lg.adapter.cnx.quickfix;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.AvgPx;
import quickfix.field.ClOrdID;
import quickfix.field.CumQty;
import quickfix.field.Currency;
import quickfix.field.ExecID;
import quickfix.field.LastPx;
import quickfix.field.LastQty;
import quickfix.field.LeavesQty;
import quickfix.field.MsgSeqNum;
import quickfix.field.NoContraBrokers;
import quickfix.field.OrdStatus;
import quickfix.field.OrderID;
import quickfix.field.OrderQty;
import quickfix.field.OrigClOrdID;
import quickfix.field.Price;
import quickfix.field.SendingTime;
import quickfix.field.TransactTime;

import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDateTimeDecoder;
import com.anz.markets.efx.ngaro.time.LocalTimeFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

import static com.anz.axle.lg.adapter.quickfix.FixFields.accountOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.textOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.clientIdOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.doubleOrZero;
import static com.anz.axle.lg.adapter.quickfix.FixFields.execBrokerOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.tradeDateOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.valueOrNull;

public class CnxExecutionReportHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(CnxExecutionReportHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();
    private static LocalDateTimeDecoder TIMESTAMP_DECODER_SECONDS = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYYMMDD, LocalTimeFormat.HH_MM_SS);
    private static final LocalDateTimeDecoder UTC_DATE_TIME_DECODER_MILLIS = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYYMMDD, LocalTimeFormat.HH_MM_SS_MMM, '-');

    private final TradingEncoderSupplier tradingResponseEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;

    private final Map<String, String> symbol6Map = new HashMap<>();
    private final SourceSequencer sourceSequencer;

    public CnxExecutionReportHandler(final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                     final PrecisionClock precisionClock,
                                     final String senderCompId,
                                     final String compId,
                                     final LongSupplier messageIdGenerator,
 final SourceSequencer sourceSequencer) {
        this.tradingResponseEncoderSupplier = Objects.requireNonNull(tradingResponseEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.EXECUTION_REPORT;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("ExecutionReport received: {}", message);

        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = sendingTimeNanos(message);

        final String orderId = message.getString(OrderID.FIELD);
        final String clOrderId = message.getString(ClOrdID.FIELD);
        final String origClOrderId = message.getString(OrigClOrdID.FIELD);
        final String execId = message.getString(ExecID.FIELD);
        final ExecType execType = execType(message);
        final OrderStatus orderStatus = orderStatus(message);
        final String account = accountOrNull(message);
        final String symbol = symbol(message);
        final String currency = valueOrNull(message, Currency.FIELD);
        final Side side = side(message);
        final OrderType orderType = orderTypeOrNull(message);
        final double price = doubleOrZero(message, Price.FIELD);
        final double orderQty = doubleOrZero(message, OrderQty.FIELD);
        final double lastPx = doubleOrZero(message, LastPx.FIELD);
        final double lastQty = doubleOrZero(message, LastQty.FIELD);
        final double leavesQty = orderStatus == OrderStatus.REJECTED ? 0.0 : doubleOrZero(message, LeavesQty.FIELD);
        final double cumQty = doubleOrZero(message, CumQty.FIELD);
        final double avgPx = doubleOrZero(message, AvgPx.FIELD);
        final long transactTimeNanos = transactTimeNanos(message);
        final String settlDate = settlDateOrNull(message);
        final String tradeDate = tradeDateOrNull(message);
        final String cancellationReason = textOrNull(message);

        final ExecutionReportEncoder.Body bodyEncoder = tradingResponseEncoderSupplier.executionReport().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
            .senderCompId().encode(compId)
            .messageId(messageId)
            .orderId().encode(orderId)
            .clOrdId().encode(clOrderId)
            .origClOrdId().encode(origClOrderId)
            .clOrdLinkId().encodeEmpty()
            .marketId().encode(Venue.CNX.name())
            .execId().encode(execId)
            .execType(execType)
            .ordStatus(orderStatus)
            .symbol().encode(symbol)
            .orderQty(orderQty)
            .ordType(orderType)
            .targetStrategyName().encodeEmpty()
            .price(price)
            .side(side)
            .currency().encodeNullable(currency)
            .transactTime(transactTimeNanos > 0 ? transactTimeNanos : sendingTimeNanos)
            .tradeDate().encodeFormatted(tradeDate, DATE_DECODER)
            .settlDate().encodeFormatted(settlDate, DATE_DECODER)
            .settlCurrency().encodeNullable(currency)
            .lastQty(lastQty)
            .lastPx(lastPx)
            .leavesQty(leavesQty)
            .cumQty(cumQty)
            .avgPx(avgPx);
        addParties(bodyEncoder, account, contraBrokerOrNull(message), clientIdOrNull(message), execBrokerOrNull(message))
            .strategyParametersEmpty()
            .regulatoryTradeIdsEmpty()
            .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(sequenceNumber)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
            .quoteId().encodeEmpty()
            .rejectText().encodeNullable(cancellationReason)
            .messageComplete();
    }

    private ExecutionReportEncoder.StrategyParameters addParties(final ExecutionReportEncoder.Body bodyEncoder,
                                                                 final String account,
                                                                 final String contraBroker,
                                                                 final String clientId,
                                                                 final String execBroker) {
        int partiesCount = 0;
        if (account != null) partiesCount ++;
        if (contraBroker != null) partiesCount ++;
        if (clientId != null) partiesCount ++;
        if (execBroker != null) partiesCount ++;

        final ExecutionReportEncoder.Parties parties = bodyEncoder.partiesStart(partiesCount);

        if (account != null) {
            parties.next()
                    .partyRole(PartyRole.SETTLEMENT_ACCOUNT)
                    .partyId().encodeNullable(account);
        }
        if (contraBroker != null) {
            parties.next()
                    .partyRole(PartyRole.CONTRA_FIRM)
                    .partyId().encodeNullable(contraBroker);
        }
        if (clientId != null) {
            parties.next()
                    .partyRole(PartyRole.CLIENT_ID)
                    .partyId().encodeNullable(clientId);
        }
        if (execBroker != null) {
            parties.next()
                    .partyRole(PartyRole.EXECUTING_FIRM)
                    .partyId().encodeNullable(execBroker);
        }
        return parties.partiesComplete();
    }

    private String symbol(final Message message) throws FieldNotFound {
        return symbol6Map.computeIfAbsent(message.getString(quickfix.field.Symbol.FIELD), SymbolNormaliser::toSymbol6);
    }

    private ExecType execType(final Message message) throws FieldNotFound {
        final char execType = message.getChar(quickfix.field.ExecType.FIELD);
        switch (execType) {
            case quickfix.field.ExecType.NEW :  return ExecType.NEW;
            case quickfix.field.ExecType.FILL : return ExecType.TRADE;
            case quickfix.field.ExecType.CANCELED : return ExecType.CANCELED;
            case quickfix.field.ExecType.REPLACE: return ExecType.REPLACED;
            case quickfix.field.ExecType.REJECTED : return ExecType.REJECTED;
            case quickfix.field.ExecType.SUSPENDED: return ExecType.SUSPENDED;
            case quickfix.field.ExecType.TRADE : return ExecType.TRADE;
            case quickfix.field.ExecType.EXPIRED : return ExecType.EXPIRED;
            case quickfix.field.ExecType.ORDER_STATUS : return ExecType.ORDER_STATUS;
            default: throw new IllegalArgumentException("Unsupported execType " + execType);
        }
    }

    private OrderType orderTypeOrNull(final Message message) throws FieldNotFound {
        if (message.isSetField(quickfix.field.OrdType.FIELD)) {
            final char ordType = message.getChar(quickfix.field.OrdType.FIELD);
            switch (ordType) {
                case quickfix.field.OrdType.STOP: return OrderType.STOP_LOSS;
                case quickfix.field.OrdType.STOP_LIMIT: return OrderType.STOP_LIMIT;
                case quickfix.field.OrdType.FOREX_MARKET: return OrderType.MARKET;
                case quickfix.field.OrdType.FOREX_LIMIT: return OrderType.LIMIT;
                default: throw new IllegalArgumentException("Unsupported ordType " + ordType);
            }
        } else {
            return null;
        }
    }

    private Side side(final Message message) throws FieldNotFound {
        final char side = message.getChar(quickfix.field.Side.FIELD);
        switch (side) {
            case quickfix.field.Side.BUY : return Side.BUY;
            case quickfix.field.Side.SELL : return Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side " + side);
        }
    }

    private OrderStatus orderStatus(final Message message) throws FieldNotFound {
        final char ordStatus = message.getChar(quickfix.field.OrdStatus.FIELD);
        switch (ordStatus) {
            case OrdStatus.NEW : return OrderStatus.NEW;
            case OrdStatus.PARTIALLY_FILLED : return OrderStatus.PARTIALLY_FILLED;
            case OrdStatus.FILLED : return OrderStatus.FILLED;
            case OrdStatus.CANCELED : return OrderStatus.CANCELED;
            case OrdStatus.REPLACED: return OrderStatus.REPLACED;
            case OrdStatus.PENDING_CANCEL: return OrderStatus.PENDING_CANCEL;
            case OrdStatus.REJECTED : return OrderStatus.REJECTED;
            case OrdStatus.EXPIRED: return OrderStatus.EXPIRED;
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private String settlDateOrNull(final Message message) throws FieldNotFound {
        final String settlDate = valueOrNull(message, quickfix.field.SettlDate.FIELD);
        return (settlDate != null && settlDate.length() == 8) ? settlDate : null;
    }

    private long transactTimeNanos(final Message message) throws FieldNotFound {
        if (message.isSetField(TransactTime.FIELD)) {
            return TIMESTAMP_DECODER_SECONDS.decodeEpochNanos(message.getString(TransactTime.FIELD), ByteReader.CHAR_SEQUENCE, 0);
        } else {
            return 0;
        }
    }

    private long sendingTimeNanos(final Message message) throws FieldNotFound {
        return UTC_DATE_TIME_DECODER_MILLIS.decodeEpochNanos(message.getHeader().getString(SendingTime.FIELD), ByteReader.CHAR_SEQUENCE, 0);
    }

    private String contraBrokerOrNull(final Message message) throws FieldNotFound {
        if (message.isSetField(NoContraBrokers.FIELD)) {
            final int entriesCount = message.getInt(NoContraBrokers.FIELD);
            if (entriesCount > 1) {
                throw new IllegalArgumentException("If contrabrokers specified, it must be 'NoContraBrokers=1 as the cnx fix spec says");
            }
            for (Group contraBrokerGroup : message.getGroups(NoContraBrokers.FIELD)) {
                return contraBrokerGroup.getString(quickfix.field.ContraBroker.FIELD);
            }
        }
        return null;
    }
}
