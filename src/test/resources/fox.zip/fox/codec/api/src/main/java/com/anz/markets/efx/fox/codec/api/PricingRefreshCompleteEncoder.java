package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;

public interface PricingRefreshCompleteEncoder extends MessageEncoder<PricingRefreshCompleteEncoder.Body> {
    @Override
    Body messageStart(int source, long sourceSeq);

    interface Body {
        Body instrumentId(long instrumentId);
        MessageEncoder.Trailer forceSnapshot(boolean forceSnapshot);
    }
}
