package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import software.chronicle.itch.staticcode.AdminMessage;
import software.chronicle.itch.staticcode.ItchServerSessionHandler;

public class ItchAdminMessageSender implements Consumer<AdminMessage> {
    private final Supplier<ItchServerSessionHandler> supplier;
    private ItchServerSessionHandler session;

    public ItchAdminMessageSender(final Supplier<ItchServerSessionHandler> supplier) {
        this.supplier = Objects.requireNonNull(supplier);
    }

    @Override
    public void accept(final AdminMessage message) {
        session().sendMessage(message);
    }

    private ItchServerSessionHandler session() {
        if (session == null) {
            session = supplier.get();
        }
        return session;
    }
}
