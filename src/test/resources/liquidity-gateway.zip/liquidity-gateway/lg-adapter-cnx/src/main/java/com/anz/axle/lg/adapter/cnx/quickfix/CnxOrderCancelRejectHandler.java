package com.anz.axle.lg.adapter.cnx.quickfix;

import java.util.Objects;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Message;
import quickfix.field.ClOrdID;
import quickfix.field.CxlRejReason;
import quickfix.field.CxlRejResponseTo;
import quickfix.field.MsgSeqNum;
import quickfix.field.OrdStatus;
import quickfix.field.OrderID;
import quickfix.field.OrigClOrdID;
import quickfix.field.SendingTime;
import quickfix.field.TransactTime;

import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDateTimeDecoder;
import com.anz.markets.efx.ngaro.time.LocalTimeFormat;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectEncoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

import static com.anz.axle.lg.adapter.quickfix.FixFields.accountOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.clientIdOrNull;
import static com.anz.axle.lg.adapter.quickfix.FixFields.textOrNull;

public class CnxOrderCancelRejectHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(CnxOrderCancelRejectHandler.class);
    private static LocalDateTimeDecoder TIMESTAMP_DECODER_SECONDS = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYYMMDD, LocalTimeFormat.HH_MM_SS);
    private static final LocalDateTimeDecoder UTC_DATE_TIME_DECODER_MILLIS = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYYMMDD, LocalTimeFormat.HH_MM_SS_MMM, '-');

    private final TradingEncoderSupplier tradingEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;
    private final SourceSequencer sourceSequencer;

    public CnxOrderCancelRejectHandler(final TradingEncoderSupplier tradingEncoderSupplier,
                                       final PrecisionClock precisionClock,
                                       final String senderCompId,
                                       final String compId,
                                       final LongSupplier messageIdGenerator,
 final SourceSequencer sourceSequencer) {
        this.tradingEncoderSupplier = Objects.requireNonNull(tradingEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.ORDER_CANCEL_REJECT;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("OrderCancelReject received: {}", message);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = sendingTimeNanos(message);
        final String orderId = message.getString(OrderID.FIELD);
        final String clOrderId = message.getString(ClOrdID.FIELD);
        final String origClOrderId = message.getString(OrigClOrdID.FIELD);
        final OrderStatus orderStatus = orderStatus(message);
        final String account = accountOrNull(message);
        final long transactTimeNanos = transactTimeNanos(message);

        final OrderCancelRejectEncoder.Body bodyEncoder = tradingEncoderSupplier.orderCancelReject().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
            .senderCompId().encode(compId)
            .messageId(messageId)
            .orderId().encode(orderId)
            .clOrdId().encode(clOrderId)
            .origClOrdId().encode(origClOrderId)
            .clOrdLinkId().encodeEmpty()
            .ordStatus(orderStatus)
            .transactTime(transactTimeNanos > 0 ? transactTimeNanos : sendingTimeNanos)
            .cxlRejResponseTo(cxlRejResponseTo(message))
            .cxlRejReason(cxlRejReasonOrOther(message));

        addParties(bodyEncoder, account, clientIdOrNull(message))
            .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(sequenceNumber)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
                .text().encode(textOrNull(message))
            .messageComplete();
    }

    private OrderCancelRejectEncoder.Hops addParties(final  OrderCancelRejectEncoder.Body bodyEncoder,
                                                     final String account,
                                                     final String clientId) {
        int partiesCount = 0;
        if (account != null) partiesCount ++;
        if (clientId != null) partiesCount ++;
        final OrderCancelRejectEncoder.Parties parties = bodyEncoder.partiesStart(partiesCount);
        if (account != null) {
            parties.next()
                    .partyRole(PartyRole.SETTLEMENT_ACCOUNT)
                    .partyId().encodeNullable(account);
        }
        if (clientId != null) {
            parties.next()
                    .partyRole(PartyRole.CLIENT_ID)
                    .partyId().encodeNullable(clientId);
        }
        return parties.partiesComplete();
    }

    private OrderCancelRequestType cxlRejResponseTo(final Message message) throws FieldNotFound {
        final char cxlRejResponseTo = message.getChar(quickfix.field.CxlRejResponseTo.FIELD);
        switch (cxlRejResponseTo) {
            case CxlRejResponseTo.ORDER_CANCEL_REPLACE_REQUEST :  return OrderCancelRequestType.ORDER_CANCEL_REPLACE_REQUEST;
            case CxlRejResponseTo.ORDER_CANCEL_REQUEST : return OrderCancelRequestType.ORDER_CANCEL_REQUEST;
            default: throw new IllegalArgumentException("Unsupported cxlRejResponseTo " + cxlRejResponseTo);
        }
    }

    private OrderCancelRejectReason cxlRejReasonOrOther(final Message message) throws FieldNotFound {
        if (!message.isSetField(quickfix.field.CxlRejReason.FIELD)) {
            return OrderCancelRejectReason.OTHER;
        }

        final int cxlRejReason = message.getInt(quickfix.field.CxlRejReason.FIELD);
        switch (cxlRejReason) {
            case CxlRejReason.TOO_LATE_TO_CANCEL :  return OrderCancelRejectReason.TOO_LATE_TO_CANCEL;
            case CxlRejReason.UNKNOWN_ORDER :  return OrderCancelRejectReason.UNKNOWN_ORDER;
            case CxlRejReason.BROKER_EXCHANGE_OPTION :  return OrderCancelRejectReason.OTHER;
            case CxlRejReason.ORDER_ALREADY_IN_PENDING_CANCEL_OR_PENDING_REPLACE_STATUS :  return OrderCancelRejectReason.ORDER_ALREADY_IN_PENDING_STATUS;
            default: throw new IllegalArgumentException("Unsupported cxlRejReasonOrOther " + cxlRejReason);
        }
    }

    private OrderStatus orderStatus(final Message message) throws FieldNotFound {
        final char ordStatus = message.getChar(OrdStatus.FIELD);
        switch (ordStatus) {
            case OrdStatus.REJECTED : return OrderStatus.REJECTED;
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private long transactTimeNanos(final Message message) throws FieldNotFound {
        if (message.isSetField(TransactTime.FIELD)) {
            return TIMESTAMP_DECODER_SECONDS.decodeEpochNanos(message.getString(TransactTime.FIELD), ByteReader.CHAR_SEQUENCE, 0);
        } else {
            return 0;
        }
    }

    private long sendingTimeNanos(final Message message) throws FieldNotFound {
        return UTC_DATE_TIME_DECODER_MILLIS.decodeEpochNanos(message.getHeader().getString(SendingTime.FIELD), ByteReader.CHAR_SEQUENCE, 0);
    }
}
