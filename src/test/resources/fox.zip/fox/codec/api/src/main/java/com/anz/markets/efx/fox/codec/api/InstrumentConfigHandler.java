package com.anz.markets.efx.fox.codec.api;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;

public interface InstrumentConfigHandler extends MessageDecoder.Handler {
    @Override
    default void onMessageStart(final int source, final long sourceSeq) {
    }

    void onBody(Body body);

    @Override
    default void onMessageComplete() {
    }

    interface Body {
        long instrumentId();
        int pipSizeDivisor();
        boolean enabled();
    }

    @FunctionalInterface
    interface DecoderFactory<M> extends MessageDecoder.Factory<M, InstrumentConfigHandler>, SorDecoders.DecoderFactory<M> {
        @Override
        default MessageDecoder<M> create(final SorHandlerSupplier sorHandlerSupplier, final MessageDecoder.ForwardingLookup<M> forwardingLookup) {
            return create((Supplier<InstrumentConfigHandler>) sorHandlerSupplier::instrumentConfigHandler, forwardingLookup);
        }
    }
}
