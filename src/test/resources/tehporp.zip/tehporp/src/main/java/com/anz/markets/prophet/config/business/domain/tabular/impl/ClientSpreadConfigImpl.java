package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.prophet.domain.collections.EnumDoubleMapMarshaller;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
public class ClientSpreadConfigImpl implements ClientSpreadConfig, ProphetMarshallable {

    private Market market;
    private Instrument instrument;
    private double qty;
    private EnumDoubleMap<TradingTimeZone> spreadByTimeZone = new EnumDoubleMap<>(TradingTimeZone.class);
    private Region region = Region.GB;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public ClientSpreadConfigImpl() {
    }

    public ClientSpreadConfigImpl(final Market market,
                                  final Instrument instrument,
                                  final double qty,
                                  final Region region) {
        this.market = market;
        this.instrument = instrument;
        this.qty = qty;
        this.region = region;
    }

    public ClientSpreadConfigImpl set(final TradingTimeZone tradingTimeZone,
                                      final double spread) {
        spreadByTimeZone.put(tradingTimeZone, spread);
        return this;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public double getQty() {
        return qty;
    }

    @Override
    public double get(final TradingTimeZone tradingTimeZone) {
        return spreadByTimeZone.get(tradingTimeZone);
    }

    @Override
    public Region getRegion() {
        return region;
    }

    public EnumDoubleMap<TradingTimeZone> getSpreadByTimeZone() {
        return spreadByTimeZone;
    }

    public void setSpreadByTimeZone(final EnumDoubleMap<TradingTimeZone> spreadByTimeZone) {
        this.spreadByTimeZone = spreadByTimeZone;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        // this uses readEnum cos that is what EnumMapDouble.writeMarshallable does
        Context.context().header().before(MessageVersion.VERSION_0_42, () ->{
            this.market = in.readEnum(Market.class);
            this.instrument = in.readEnum(Instrument.class);
        });
        Context.context().header().since(MessageVersion.VERSION_0_42, () ->{
            this.market = Market.valueOf(in.readByte());
            this.instrument = Instrument.readMarshallableValueOf(in);
        });
        this.qty = in.readDouble();
        EnumDoubleMapMarshaller.readMarshallable(spreadByTimeZone, in);
        Context.context().header().since(MessageVersion.VERSION_0_39, () -> this.region = Region.valueOf(in.readByte()));
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(market.getValue());
        out.writeShort(instrument.getValue());
        out.writeDouble(qty);
        EnumDoubleMapMarshaller.writeMarshallable(spreadByTimeZone, out);
        out.writeByte(region.getValue());
    }

    @Override
    public String toString() {
        return "ClientSpreadConfigImpl{" +
                "region=" + region +
                ", instrument=" + instrument +
                ", market=" + market +
                ", qty=" + qty +
                ", spreadByTimeZone=" + spreadByTimeZone +
                '}';
    }
}
