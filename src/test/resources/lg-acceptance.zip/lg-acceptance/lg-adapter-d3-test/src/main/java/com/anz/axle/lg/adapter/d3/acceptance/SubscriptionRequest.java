package com.anz.axle.lg.adapter.d3.acceptance;

import java.util.Objects;

public class SubscriptionRequest {
    public enum Type {
        SUBSCRIBE,
        UNSUBSCRIBE
    }
    private Type type;
    private String subscriptionId;
    private String symbol;

    private SubscriptionRequest(final Type type, final String subscriptionId, final String symbol) {
        this.type = type;
        this.subscriptionId = subscriptionId;
        this.symbol = symbol;
    }

    static SubscriptionRequest forSubscribe(final String subscriptionId, final String symbol) {
        Objects.requireNonNull(subscriptionId);
        Objects.requireNonNull(symbol);
        return new SubscriptionRequest(Type.SUBSCRIBE, subscriptionId, symbol);
    }

    static SubscriptionRequest forUnsubscribe(final String subscriptionId) {
        Objects.requireNonNull(subscriptionId);
        return new SubscriptionRequest(Type.UNSUBSCRIBE, subscriptionId, null);
    }

    public Type type() {
        return type;
    }

    public String subscriptionId() {
        return subscriptionId;
    }

    public String symbol() {
        return symbol;
    }

    @Override
    public String toString() {
        return "SubscriptionRequest{" +
                "type=" + type +
                ", subscriptionId='" + subscriptionId + '\'' +
                ", symbol='" + symbol + '\'' +
                '}';
    }
}
