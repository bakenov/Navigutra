package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.codec.pojo.matcher.VenueInstrumentConfigMatcher;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class VenueInstruments_Are_Loaded_From_YamlTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueInstruments_Are_Loaded_From_YamlTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private VenueInstrumentRepository venueInstrumentRepository;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config-test.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        venueInstrumentRepository = application.getApplicationContext().getBean(VenueInstrumentRepository.class,"venueInstrumentRepository");
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_see_venue_created_commands_and_events_on_startup() throws Exception {

        final VenueInstrumentConfigMatcher test1Matcher = VenueInstrumentConfigMatcher.build()
                .body().matches(VenueInstrumentConfigMatcher.venue().eq(Venue.FAST))
                .body().matches(VenueInstrumentConfigMatcher.instrumentId().eq(InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT, Tenor.SP)))
                .body().matches(VenueInstrumentConfigMatcher.enabled().eq(Boolean.TRUE));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(test1Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(test1Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(venueInstrumentRepository.lookup(Venue.FAST, InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT, Tenor.SP)).enabled()).isTrue();
    }
}
