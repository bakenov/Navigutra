package com.anz.markets.efx.fox.acceptance.config;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SystemPropertyApplier implements PropertyApplier {
    private final Map<String,String> properties = new HashMap<>();

    @Override
    public void set(final String key, final String val) {
        Objects.requireNonNull(key);
        Objects.requireNonNull(val);

        System.setProperty(key, val);
        properties.put(key,val);
    }

    @Override
    public String get(final String key) {
        Objects.requireNonNull(key);
        return System.getProperty(key);
    }

    @Override
    public void rollback() {
        for(String propertyKey : properties.keySet()) {
            System.getProperties().remove(propertyKey);
        }
    }
}
