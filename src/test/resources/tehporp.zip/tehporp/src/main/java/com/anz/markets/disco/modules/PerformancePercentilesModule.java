package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.utils.Symbol;
import net.openhft.chronicle.core.util.Histogram;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

public class PerformancePercentilesModule extends AbstractModule {

    private final Logger log = LoggerFactory.getLogger(PerformancePercentilesModule.class);

    private final long dumpHistosEveryNanos = TimeUnit.SECONDS.toNanos(60);

    private final Histogram histogram = new Histogram();
    private final Histogram totalHistogram = new Histogram();

    private final int skipFirst;

    private long lastHistosDumpNanos;
    private long firstEventTime;
    private long n;

    public PerformancePercentilesModule(int skipFirst) {
        this.skipFirst = skipFirst;
    }

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.subAny(this::sampleAndDumpHistos);
    }

    private void sampleAndDumpHistos(Symbol messageType, Object message) {

        if (getStage().getMessageBus().isInputEvent()) {
            n++;
            if (n > skipFirst) {
                if (firstEventTime == 0) {
                    firstEventTime = System.nanoTime();
                }
                final long t = System.nanoTime();
                final long delta = t - getStage().getMessageBus().getDriverEventSystemTimeNanos();
                histogram.sampleNanos(delta);
                totalHistogram.sampleNanos(delta);
                if (t - lastHistosDumpNanos > dumpHistosEveryNanos) {
                    if (lastHistosDumpNanos > 0) {
                        logStats("1M", lastHistosDumpNanos, t, totalHistogram, false);
                        histogram.reset();
                    }
                    lastHistosDumpNanos = t;
                }
            }
        }
    }

    private final DecimalFormat intf = new DecimalFormat("#,###");

    @Override
    public void finish() {
        logStats("total",firstEventTime,System.nanoTime(),totalHistogram,true);
    }

    private void logStats(String name, long startTime, long endTime, Histogram histogram, boolean includeSkip) {
        final long durationMillis = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
        final int eps = (int) (1000 * histogram.totalCount() / durationMillis);
        if(includeSkip) {
            log.info("{} runtime (after {}) was {} seconds for {} events giving {} EPS.", name, intf.format(skipFirst), durationMillis / 1000.0, intf.format(histogram.totalCount()), intf.format(eps));
        } else {
            log.info("{} runtime was {} seconds for {} events giving {} EPS.", name, durationMillis / 1000.0, intf.format(histogram.totalCount()), intf.format(eps));
        }
        log.info("{} histos {}", histogram.toMicrosFormat());
    }
}
