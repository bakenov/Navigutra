package software.chronicle.fix;

import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.Wires;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.fields.OrdStatus;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import static software.chronicle.generated.code.messages.ExecutionReport.newExecutionReport;

/**
 * @author Rob Austin.
 */
public class ServerMessageNotifier implements MessageNotifier, Marshallable {

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }

    @Override
    public void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        System.out.println("received - onNewOrderSingle=" + newOrderSingle);

        final ExecutionReport executionReport = newExecutionReport(Wires.acquireBytes(), session.context());
        executionReport.avgPx(12.0);
        executionReport.clOrdID(newOrderSingle.clOrdID());
        executionReport.ordStatus(OrdStatus.NEW);
        executionReport.side('1');
        executionReport.transactTime(session.context().timeProvider().currentTimeMillis());
        session.sendMessage(executionReport);
    }
}
