package software.chronicle;

import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.generated.code.messages.MessageNotifier;

/**
 * Created by Jerry Shea on 22/09/17.
 */
public class DropCopyMessageNotifier implements MessageNotifier, Marshallable {
}
