package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.EnumSet;
import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoUserConfigHandler implements UserConfigHandler {

    private final Consumer<? super UserConfig> messageConsumer;

    private UserConfig message = SorMessage.userConfig();

    public UserConfig message() {
        return message;
    }

    public PojoUserConfigHandler() {
        this(msg -> {});
    }

    public PojoUserConfigHandler(final Consumer<? super UserConfig> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.userConfig();
    }

    @Override
    public void onBody(final Body body) {
        message.body.userName = body.userName().decodeStringOrNull();
        message.body.location = body.location().decodeStringOrEmpty();
        message.body.userGroups = body.userGroups().decodeTo(EnumSet.noneOf(UserGroup.class));
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
