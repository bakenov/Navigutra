package com.anz.axle.lg.adapter.d3.acceptance;

import java.util.Objects;
import java.util.function.Predicate;

import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;

import static com.anz.markets.efx.matcher.Matchers.translate;

public interface SubscriptionRequestMatcher extends Predicate<Object> {
    Matcher<SubscriptionRequestMatcher, SubscriptionRequest> body();

    static SubscriptionRequestMatcher build(final String name) {
        Objects.requireNonNull(name);
        return new SubscriptionRequestMatcher() {
            private Predicate<SubscriptionRequest> predicate = Matchers.isA(SubscriptionRequest.class);

            @Override
            public Matcher<SubscriptionRequestMatcher, SubscriptionRequest> body() {
                return matcher -> andThen(translate(subscriptionRequest -> subscriptionRequest, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof SubscriptionRequest && predicate.test((SubscriptionRequest) o);
            }

            @Override
            public String toString() {
                return name + ":" + predicate.toString();
            }

            private SubscriptionRequestMatcher andThen(final Predicate<? super SubscriptionRequest> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<SubscriptionRequest, SubscriptionRequest.Type> type() {
        return ComparisonMatcher.create("type", b -> b.type());
    }

    static ComparisonMatcher<SubscriptionRequest, String> subscriptionId() {
        return ComparisonMatcher.create("subscriptionId", b -> b.subscriptionId());
    }

    static ComparisonMatcher<SubscriptionRequest, String> symbol() {
        return ComparisonMatcher.create("symbol", b -> b.symbol());
    }

}
