package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.common.pricing.PricingFeed;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExecutePricingRefreshCompleteHandler implements PricingRefreshCompleteHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExecutePricingRefreshCompleteHandler.class);
    private final PricingFeed.Request pricingFeedRequest;
    private final InstrumentRepository instrumentRepository;
    private final ParentOrderRepository parentOrderRepository;
    private final Consumer<Instrument> instrumentConsumer;

    private long currentInstrumentId;
    private final Consumer<ParentOrder> parentOrderPriceUpdateNotifier;
    private final InstrumentKey.Lookup instrumentKeyLookup = new DefaultInstrumentKeyLookup();

    public ExecutePricingRefreshCompleteHandler(final CommandContext commandContext,
                                                final PricingFeed.Request pricingFeedRequest,
                                                final InstrumentRepository instrumentRepository,
                                                final ParentOrderRepository parentOrderRepository,
                                                final Consumer<Instrument> instrumentConsumer) {
        this.pricingFeedRequest = Objects.requireNonNull(pricingFeedRequest);
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
        this.instrumentConsumer = Objects.requireNonNull(instrumentConsumer);

        this.parentOrderPriceUpdateNotifier = parentOrder -> {
            if (parentOrder.details().instrument().key().instrumentId() == currentInstrumentId) {
                parentOrder.onPriceUpdate(commandContext);
            }
        };
    }

    @Override
    public void onBody(final Body body) {
        final Instrument instrument = instrumentRepository.lookup(body.instrumentId());

        if (instrument != null) {
            instrumentConsumer.accept(instrument);

            this.currentInstrumentId = body.instrumentId();
            parentOrderRepository.forEach(parentOrderPriceUpdateNotifier);

            pricingFeedRequest.submit(body.instrumentId(), body.forceSnapshot());
        } else {
            LOGGER.warn("Unknown instrument for {}", instrumentKeyLookup.lookup(body.instrumentId()));
        }
    }
}
