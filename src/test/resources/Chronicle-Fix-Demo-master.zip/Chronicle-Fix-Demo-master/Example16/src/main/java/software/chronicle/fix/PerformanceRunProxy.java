package software.chronicle.fix;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.jlbh.JLBH;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.messages.MessageNotifier;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class PerformanceRunProxy extends PerformanceRun {

    public static void main(String[] args) throws IOException {
        StartAndSendOrdersToProxy.addAliases();

        IOTools.deleteDirWithFiles("proxy", 10);

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");
        TCPRegistry.createServerSocketChannelFor("host1.port");

        PerformanceRun.runWith(new PerformanceRunProxy());
    }

    @Override
    public void init(JLBH jlbh) {

        try {
            final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");

            final ChronicleFixEngine proxyToEndpoint = fixEngineCfg.createInstance(2, eventGroup("proxyOut_"));
            FixSessionHandler proxyToEndpointSession = proxyToEndpoint.sessions().iterator().next();
            ProxyNotifier proxyToEndpointNotifier = (ProxyNotifier) proxyToEndpointSession.messageNotifier();

            final ChronicleFixEngine proxy = fixEngineCfg.createInstance(3, eventGroup("proxyIn_"));
            FixSessionHandler proxySession = proxy.sessions().iterator().next();
            ProxyNotifier proxyNotifier = (ProxyNotifier) proxySession.messageNotifier();

            // wire together two proxies for messages in and out
            proxyToEndpointNotifier.proxySession(proxySession);
            proxyNotifier.proxySession(proxyToEndpointSession);

            // this waits for endpoint to connect to proxy
            super.init(jlbh);

            // wait for connection to be made between proxy and test client
            boolean success = proxyNotifier.loggedIn.await(5, TimeUnit.SECONDS);
            if (!success)
                throw new TimeoutException("while waiting to become loggedin");

        } catch (Exception t) {
            Jvm.rethrow(t);
        }
    }

    @NotNull
    @Override
    protected FixSessionCfg initiatorConfig(JLBH lth, MessageNotifier messageNotifier) {
        FixSessionCfg cfg = super.initiatorConfig(lth, messageNotifier);
        cfg.targetCompID("GENERATOR");
        cfg.senderCompID("PROXY");
        cfg.socketConnectHostPort(new String[] { "host.port" });
        return cfg;
    }

    @NotNull
    @Override
    protected FixSessionCfg acceptorConfig(JLBH lth) {
        FixSessionCfg cfg = super.acceptorConfig(lth);
        cfg.targetCompID("PROXY");
        cfg.senderCompID("ENDPOINT");
        cfg.socketAcceptorHostPort("host1.port");
        return cfg;
    }
}