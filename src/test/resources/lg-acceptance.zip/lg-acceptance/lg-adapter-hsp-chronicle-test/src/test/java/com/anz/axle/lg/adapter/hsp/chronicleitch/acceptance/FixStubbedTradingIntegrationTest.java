package com.anz.axle.lg.adapter.hsp.chronicleitch.acceptance;

import java.util.concurrent.TimeUnit;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.ExecType;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.spec.fix50sp2.fieldtype.OrdStatus;
import org.fix4j.test.fixmodel.Field;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.Failure;
import org.fix4j.test.session.MatchingSession;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.TradingFixSessionHelper;
import com.anz.axle.lg.adapter.hsp.acceptance.AcceptanceConfig;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.markets.efx.trading.codec.api.ExecType.REJECTED;
import static com.anz.markets.efx.trading.codec.api.ExecType.TRADE;
import static org.fix4j.test.util.Asserts.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class FixStubbedTradingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixStubbedTradingIntegrationTest.class);
    private static final String NORMALISED_SYMBOL = "AUDCAD";
    private static final String SYMBOL = "AUD/CAD";
    private static final String CURRENCY = "AUD";
    private static final String SENDER_COMP_ID = "GB:lg-hsp";
    private static final String FIRST_HOP = "GB:HSP";
    private static final double DELTA = 1e-15;

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private MatchingSession tradingServer;
    private TradingFixSessionHelper tradingTestHelper;

    private static final String FIX_DATA_DICTIONARY_FILE = "conf/FIX42-hsp.xml";

    private static final double TOLERANCE = 1e-15;

    static {
        System.getProperties().putAll(StringUtils.parseMap(
    "appName:lg-hsp" +
                ",venue:HSP" +
                ",default.log.appender:Console" +
                ",default.log.level:DEBUG" +
                ",hsp.fix.trading.log_all:false" +
                ",hsp.fix.trading.session.enable:true" +
                ",hsp.itch.pricing.session.enable:false" +
                ",hsp.itch.pricing.log_all:false" +
                ",chronicle.fix.logging:false"
        ));
    }

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ {}", testName.getMethodName());

        tradingTestHelper = new TradingFixSessionHelper("hsp", "GB_HSP_TR_S", "GB_HSP_TR_T", "FIX.4.2", FIX_DATA_DICTIONARY_FILE);

        if (testName.getMethodName().equals("order_cancel_request_not_supported")) {
            System.getProperties().put("fix4j.default.fix.msg.wait.timeout.ms", "5000");
        }
        System.getProperties().put("hsp.fix.trading.waitForLogoutTimeoutInSec","2");
        // DO NOT start ItchEngine else AlwaysStartOnPrimaryConnectionStrategy will not disconnect when not connected first. Resulting in tests not stopping.
        System.getProperties().put("hsp.itch.pricing.session.enable","false");

        tradingServer = tradingTestHelper.createTradingSession();

        application = new Application("lg-hsp-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() throws Exception {
        if (tradingServer != null) tradingServer.shutdown();
        waitForStop(application, 3, 500, testName.getMethodName());
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private NewOrderSingle newOrderSingleUMMessage(final String symbol) {
        final double quantity = 16863000000.0;
        final double price = 1.33627;
        final Side side = Side.SELL;

        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = TimeInForce.IOC;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.orderQty = quantity;
        newOrderSingle.body.clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        newOrderSingle.body.marketId = Venue.HSP.name();
        newOrderSingle.body.currency = symbol.substring(0, 3);
        newOrderSingle.body.ordType = OrderType.LIMIT;
        newOrderSingle.body.price = price;
        newOrderSingle.body.senderCompId = "GB:lg-acc";
        newOrderSingle.body.settlCurrency = newOrderSingle.body.currency;
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = symbol;
        return newOrderSingle;
    }

    private FixMessage executionReportFixMessage(final FixMessage newOrderSingle, final String orderId, final ExecType.Values executionStatus) {
        final String execId = "2312321";
        final String settlDate = "20191202";

        final FixMessageBuilder fixMessageBuilder = new FixMessageBuilder();

        switch (executionStatus) {
            case TRADE_PARTIAL_FILL_OR_FILL:
                fixMessageBuilder.withField(FieldTypes.ExecType, "F");
                fixMessageBuilder.withField(FieldTypes.OrdStatus, OrdStatus.Values.FILLED.getOrdinal());
                break;
            case REJECTED:
                fixMessageBuilder.withField(FieldTypes.ExecType, executionStatus.getOrdinal());
                fixMessageBuilder.withField(FieldTypes.OrdStatus, OrdStatus.Values.REJECTED.getOrdinal());
                fixMessageBuilder.withField(FieldTypes.Text, "Rejection Test");
                break;
            default:
                throw new IllegalArgumentException("Unknown execution status type (supported are Fill or Rejected)");
        }

        return fixMessageBuilder.withField(new Field(FieldTypes.MsgType, MsgType.Values.EXECUTIONREPORT.getOrdinal()))
                .withField(FieldTypes.OrderID, orderId)
                .withField(FieldTypes.ClOrdID, newOrderSingle)
                .withField(FieldTypes.ExecID, execId)
                .withField(FieldTypes.Account, "FIX-SIM")
                .withField(FieldTypes.Symbol, newOrderSingle)
                .withField(FieldTypes.Side, newOrderSingle)
                .withField(FieldTypes.OrderQty, newOrderSingle)
                .withField(FieldTypes.OrdType, newOrderSingle)
                .withField(FieldTypes.Price, newOrderSingle)
                .withField(FieldTypes.Currency, newOrderSingle)
                .withField(FieldTypes.TimeInForce, newOrderSingle)
                .withField(FieldTypes.LastQty, newOrderSingle.getField(FieldTypes.OrderQty).getValue())
                .withField(FieldTypes.LastPx, newOrderSingle.getField(FieldTypes.Price).getValue())
                .withField(FieldTypes.LeavesQty, 0.0)
                .withField(FieldTypes.CumQty, newOrderSingle.getField(FieldTypes.OrderQty).getValue())
                .withField(FieldTypes.AvgPx, newOrderSingle.getField(FieldTypes.Price).getValue())
                .withField(FieldTypes.MinQty, newOrderSingle.getField(FieldTypes.OrderQty).getValue())
                .withField(FieldTypes.SettlDate, settlDate)
                .build();
    }

    @Test
    public void should_reject_order_as_trading_is_logged_off() throws Exception {

        final NewOrderSingle newOrderSingle = newOrderSingleUMMessage("AUDUSD");

        LOGGER.info(newOrderSingle.toString());
        LOGGER.info("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        //Then trading request should be rejected
        final TradingMessage tradingResponse = Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(SENDER_COMP_ID))
                        .body().matches(ExecutionReportMatcher.orderId().isNull())
                        .body().matches(ExecutionReportMatcher.execId().isNull())
                        .body().matches(ExecutionReportMatcher.execType().eq(REJECTED)))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        tradingResponse.accept(new TradingMessageVisitor.Exception() {
            @Override
            public void onExecutionReport(final ExecutionReport executionReport) {
                Assert.assertEquals(SENDER_COMP_ID, executionReport.body.senderCompId);
                Assert.assertNull(executionReport.body.orderId);
                Assert.assertNull(executionReport.body.execId);
                Assert.assertEquals(REJECTED, executionReport.body.execType);
                Assert.assertEquals(OrderStatus.REJECTED, executionReport.body.ordStatus);
                Assert.assertEquals(Venue.HSP.name(), executionReport.body.marketId);
                Assert.assertEquals(TimeInForce.IOC, executionReport.body.timeInForce);
                Assert.assertEquals(16863000000.0, executionReport.body.orderQty, DELTA);
                Assert.assertEquals(1.33627, executionReport.body.price, DELTA);
                Assert.assertEquals("AUD", executionReport.body.currency);
                Assert.assertEquals(OrderType.LIMIT, executionReport.body.ordType);
                Assert.assertEquals("AUD", executionReport.body.settlCurrency);
                Assert.assertNull(executionReport.body.settlDate);
                Assert.assertEquals(Side.SELL, executionReport.body.side);
                Assert.assertEquals(SymbolNormaliser.toSymbol6("AUD/USD"), executionReport.body.symbol);
                Assert.assertEquals(0.0, executionReport.body.lastQty, DELTA);
                Assert.assertEquals(0.0, executionReport.body.lastPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.commissionAdjLastPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.midPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.lastSpotRate, DELTA);
                Assert.assertEquals(0.0, executionReport.body.lastForwardPoints, DELTA);
                Assert.assertEquals(0.0, executionReport.body.leavesQty, DELTA);
                Assert.assertEquals(0.0, executionReport.body.cumQty, DELTA);
                Assert.assertEquals(0.0, executionReport.body.avgPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.commissionAdjAvgPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.commission, DELTA);
                Assert.assertEquals(0, executionReport.parties.size());
                Assert.assertEquals(0, executionReport.strategyParameters.size());
                Assert.assertEquals(0, executionReport.regulatoryTradeIds.size());
                Assert.assertEquals(1, executionReport.hops.size());
                Assert.assertEquals(SENDER_COMP_ID, executionReport.hops.get(0).hopCompId);
                Assert.assertEquals(executionReport.body.messageId, executionReport.hops.get(0).hopMessageId);
                Assert.assertEquals(0, executionReport.hops.get(0).hopReceivingTime);
            }
        });
        LOGGER.info("==============================================================");
    }

    @Test
    public void should_fill_order() throws Exception {
        //wait for trading server login
        tradingServer.discardUntil("35=A");
        Thread.sleep(500);

        final NewOrderSingle newOrderSingle = newOrderSingleUMMessage("AUDUSD");

        LOGGER.info(newOrderSingle.toString());
        LOGGER.info("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        //When new order request is received by the trading server
        final FixMessage newOrderSingleFix = tradingServer.discardUntil("35=D|55=AUD/USD|");
        final String orderId = "wefqe323";
        final String execId = "2312321";

        //Then Execution Report is sent to the adapter
        tradingServer.send(executionReportFixMessage(newOrderSingleFix, "wefqe323", ExecType.Values.TRADE_PARTIAL_FILL_OR_FILL));
        final TradingMessage tradingResponse = Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(SENDER_COMP_ID))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(newOrderSingleFix.getField(11).getValue())))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        tradingResponse.accept(new TradingMessageVisitor.Exception() {
            @Override
            public void onExecutionReport(final ExecutionReport executionReport) {
                Assert.assertEquals(SENDER_COMP_ID, executionReport.body.senderCompId);
                Assert.assertEquals(orderId, executionReport.body.orderId);
                Assert.assertEquals(execId, executionReport.body.execId);
                Assert.assertEquals(newOrderSingleFix.getField(11).getValue(), executionReport.body.clOrdId);
                Assert.assertEquals(TRADE, executionReport.body.execType);
                Assert.assertEquals(OrderStatus.FILLED, executionReport.body.ordStatus);
                Assert.assertEquals(TimeInForce.IOC, executionReport.body.timeInForce);
                Assert.assertEquals(16863000000.0, executionReport.body.orderQty, DELTA);
                Assert.assertEquals(1.33627, executionReport.body.price, DELTA);
                Assert.assertEquals("AUD", executionReport.body.currency);
                Assert.assertEquals("AUD", executionReport.body.settlCurrency);
                //Assert.assertEquals(LocalDateFormat.YYYYMMDD.getDefaultDecoder().decodeLocalDateOrNull(settlDate, ByteReader.CHAR_SEQUENCE), executionReport.body.settlDate);
                Assert.assertEquals(Side.SELL, executionReport.body.side);
                Assert.assertEquals(SymbolNormaliser.toSymbol6("AUD/USD"), executionReport.body.symbol);
                Assert.assertEquals(16863000000.0, executionReport.body.lastQty, DELTA);
                Assert.assertEquals(1.33627, executionReport.body.lastPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.commissionAdjLastPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.midPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.lastSpotRate, DELTA);
                Assert.assertEquals(0.0, executionReport.body.lastForwardPoints, DELTA);
                Assert.assertEquals(0.0, executionReport.body.leavesQty, DELTA);
                Assert.assertEquals(16863000000.0, executionReport.body.cumQty, DELTA);
                Assert.assertEquals(1.33627, executionReport.body.avgPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.commissionAdjAvgPx, DELTA);
                Assert.assertEquals(0.0, executionReport.body.commission, DELTA);
                Assert.assertEquals(1, executionReport.parties.size());
                Assert.assertEquals(PartyRole.SETTLEMENT_ACCOUNT, executionReport.parties.get(0).partyRole);
                Assert.assertEquals("FIX-SIM", executionReport.parties.get(0).partyId);
                Assert.assertEquals(0, executionReport.strategyParameters.size());
                Assert.assertEquals(0, executionReport.regulatoryTradeIds.size());
                Assert.assertEquals(2, executionReport.hops.size());
                Assert.assertEquals("GB:HSP", executionReport.hops.get(0).hopCompId);
                Assert.assertEquals(0, executionReport.hops.get(0).hopReceivingTime);
                Assert.assertEquals(SENDER_COMP_ID, executionReport.hops.get(1).hopCompId);
            }
        });
        LOGGER.info("==============================================================");
    }

    @Test
    public void new_order_single_rejected() throws Exception {

        //wait for trading server login
        tradingServer.discardUntil("35=A");
        Thread.sleep(1000);

        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(NORMALISED_SYMBOL);
        LOGGER.info(newOrderSingleUM.toString());
        LOGGER.info("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);
        final FixMessage newOrderSingle = tradingServer.discardUntil("35=D|55=" + SYMBOL + "|");

        //And Execution Report is sent with Status as Rejected
        tradingServer.send(executionReportFixMessage(newOrderSingle, "UNKNOWN", ExecType.Values.REJECTED));

        //Then Order with Rejected status is received
        final TradingMessage tradingResponse = Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(newOrderSingle.getField(11).getValue()))
                        .body().matches(ExecutionReportMatcher.orderId().eq("UNKNOWN"))
                        .body().matches(ExecutionReportMatcher.rejectText().eq("Rejection Test")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        tradingResponse.accept(new TradingMessageVisitor.Exception() {
            @Override
            public void onExecutionReport(final ExecutionReport executionReport) {
                    assertEquals(SENDER_COMP_ID, executionReport.body.senderCompId);
                    assertEquals("UNKNOWN", executionReport.body.orderId);
                    assertEquals("2312321", executionReport.body.execId);
                    assertEquals(newOrderSingle.getField(11).getValue(), executionReport.body.clOrdId);
                    assertEquals(REJECTED, executionReport.body.execType);
                    assertEquals(OrderStatus.REJECTED, executionReport.body.ordStatus);
                    assertEquals(Venue.HSP.name(), executionReport.body.marketId);
                    assertEquals(16863000000.0, executionReport.body.orderQty, TOLERANCE);
                    assertEquals(1.33627, executionReport.body.price, TOLERANCE);
                    assertEquals(CURRENCY, executionReport.body.currency);
                    assertNotNull(executionReport.body.settlDate);
                    assertEquals(Side.SELL, executionReport.body.side);
                    assertEquals(NORMALISED_SYMBOL, executionReport.body.symbol);
                    assertEquals(16863000000.0, executionReport.body.lastQty, TOLERANCE);
                    assertEquals(1.33627, executionReport.body.lastPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.commissionAdjLastPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.midPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.lastForwardPoints, TOLERANCE);
                    assertEquals(0.0, executionReport.body.leavesQty, TOLERANCE);
                    assertEquals(16863000000.0, executionReport.body.cumQty, TOLERANCE);
                    assertEquals(1.33627, executionReport.body.avgPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.commissionAdjAvgPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.commission, TOLERANCE);
                    assertEquals("Rejection Test", executionReport.body.rejectText);
                    assertEquals(1, executionReport.parties.size());
                    assertEquals(PartyRole.SETTLEMENT_ACCOUNT, executionReport.parties.get(0).partyRole);
                    assertEquals("FIX-SIM", executionReport.parties.get(0).partyId);
                    assertEquals(0, executionReport.strategyParameters.size());
                    assertEquals(0, executionReport.regulatoryTradeIds.size());
                    assertEquals(2, executionReport.hops.size());
                    assertEquals(FIRST_HOP, executionReport.hops.get(0).hopCompId);
                    assertEquals(0, executionReport.hops.get(0).hopReceivingTime);
                    assertEquals(SENDER_COMP_ID, executionReport.hops.get(1).hopCompId);
                    assertEquals(executionReport.body.messageId, executionReport.hops.get(1).hopMessageId);
                }
        });

        LOGGER.info(tradingResponse.toString());
        LOGGER.info("==============================================================");
    }

    @Test
    public void order_cancel_request_not_supported() throws Exception {

        //wait for trading server login
        Thread.sleep(1000);
        tradingServer.discardUntil("35=A");

        final OrderCancelRequest orderCancelRequest = new OrderCancelRequest();

        LOGGER.info(orderCancelRequest.toString());
        LOGGER.info("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequest);

        //Then verify that Order Cancel Request is not sent
        try {
            tradingServer.discardUntil("35=F|55=" + SYMBOL + "|");
        } catch (final Failure failure) {
            LOGGER.info("Order cancel request not yet handled, expected exception={}", failure);
            return;
        }

        LOGGER.info("==============================================================");
    }

    @Test
    public void should_send_logout_when_shutting_down() throws Exception {

        //wait for trading server login
        LOGGER.info("Waiting for Logon...");
        tradingServer.discardUntil("35=A");

        application.stop();

        final FixMessage logoutRequest = tradingServer.discardUntil("35=5");
        System.out.println(logoutRequest.toString());
        System.out.println("==============================================================");

        assertNotNull(logoutRequest.getField(FieldTypes.Text).getValue());
    }

    @Test
    public void should_send_logout_when_receive_logout() throws Exception {

        //wait for trading server login
        LOGGER.info("Waiting for Logon...");
        FixMessage logonMessage = tradingServer.discardUntil("35=A");
        assertNull(logonMessage.getField(FieldTypes.ResetSeqNumFlag));
        final FixMessage logoffMessage = new FixMessageBuilder().withField(FieldTypes.MsgType, "5").withField(FieldTypes.Text, "HSP").build();
        // send logoff to adaptor
        tradingServer.send(logoffMessage);

        final FixMessage logoutRequest = tradingServer.discardUntil("35=5");

        System.out.println(logoutRequest.toString());
        System.out.println("==============================================================");
    }
}
