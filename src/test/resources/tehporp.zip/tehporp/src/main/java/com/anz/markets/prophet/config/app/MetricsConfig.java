package com.anz.markets.prophet.config.app;

import com.anz.axle.direct.performance.MetricReporter;
import com.anz.axle.direct.performance.NoOpMetricReporter;
import com.anz.markets.disco.data.MutableSignals;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.data.kdb.KDBSignalsBatchPublisher;
import com.anz.markets.prophet.chime.ChimeConsumerMBean;
import com.anz.markets.prophet.chime.bespoke.RateChimer;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderSequential;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig.ChronicleType;
import com.anz.markets.prophet.config.app.importable.BackTestConfig;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.ConsumerMetricsConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.app.importable.TradingTimeZoneManager;
import com.anz.markets.prophet.config.business.ConfigReader;
import com.anz.markets.prophet.config.business.doclet.ConfigHttpServer;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.domain.common.EndEventImpl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.hedger.HedgeDecisionImpl;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.InstrumentAndMarketEnablementFilter;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataIncrementImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.pnl.ProfitAndLossImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.status.HedgeStatusImpl;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.hedger.HedgerStatusViewer;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import com.anz.markets.prophet.kdb.KDBClientPriceToFxDepthBatchPublisher;
import com.anz.markets.prophet.kdb.KDBClientPriceToFxQuoteBatchPublisher;
import com.anz.markets.prophet.kdb.KDBClientPriceToFxQuotePublisher;
import com.anz.markets.prophet.kdb.KDBConnection;
import com.anz.markets.prophet.kdb.KDBGenericProfitAndLossPublisher;
import com.anz.markets.prophet.kdb.KDBHedgeDecisionPublisher;
import com.anz.markets.prophet.kdb.KDBHedgeFirewallStatusPublisher;
import com.anz.markets.prophet.kdb.KDBMarketDataSnapshotToFxQuoteBatchPublisher;
import com.anz.markets.prophet.kdb.KDBMetricsPublisher;
import com.anz.markets.prophet.kdb.KDBMilestonePublisher;
import com.anz.markets.prophet.kdb.KDBOptimalPositionPublisher;
import com.anz.markets.prophet.kdb.KDBPositionPublisher;
import com.anz.markets.prophet.kdb.KDBProfitAndLossPublisher;
import com.anz.markets.prophet.kdb.KDBPublisher;
import com.anz.markets.prophet.kdb.KDBReader;
import com.anz.markets.prophet.kdb.KDBRealisedVolatilityPublisher;
import com.anz.markets.prophet.kdb.KDBRiskPathPublisher;
import com.anz.markets.prophet.kdb.KDBWholesaleBookFactorsBatchPublisher;
import com.anz.markets.prophet.kdb.KdbLastEventReader;
import com.anz.markets.prophet.mangement.ClientPriceIndicativeReporter;
import com.anz.markets.prophet.mangement.EsperRunner;
import com.anz.markets.prophet.mangement.GenericReporter;
import com.anz.markets.prophet.mangement.GenericReporterTable;
import com.anz.markets.prophet.mangement.ReporterByEventId;
import com.anz.markets.prophet.marketdata.FilteredMarketDataSnapshotManager;
import com.anz.markets.prophet.marketdata.MarketDataReader;
import com.anz.markets.prophet.marketdata.aggbook.AggregatedBookManager;
import com.anz.markets.prophet.metrics.MetricsClientPriceReader;
import com.anz.markets.prophet.metrics.Metric;
import com.anz.markets.prophet.metrics.MetricsPerfRecorder;
import com.anz.markets.prophet.metrics.MetricsReader;
import com.anz.markets.prophet.perftest.PerfRecorderEndEventPercentiles;
import com.anz.markets.prophet.perftest.PerfRecorderHeaderPercentiles;
import com.anz.markets.prophet.positionrisk.Position;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.ValueAtRiskImpl;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.risk.realvol.RealisedVolatilityImpl;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

import static com.anz.markets.prophet.util.ThreadUtils.singleExecutorService;

@Configuration
@Import({BusinessConfig.class, BackTestConfig.class, ConsumerMetricsConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/metrics.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class MetricsConfig extends JmxConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(MetricsConfig.class);

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.metrics:5}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    @Bean
    public Metric metric(@Value("${sl4j.report.seconds:300}") final int reportFreq) {
        final Metric metric = new Metric();
        metric.startSlf4jReporter(reportFreq);
        return metric;
    }

    @Bean
    public ProphetReader inboundChronicleReader(@Value("${chronicle.in.path:./chronicle.in}") final String chronicleInPath,
                                                final Metric metric,
                                                final ChronicleObjectReader forwardPointReader) throws IOException {
        final ExecutorService executorService = singleExecutorService("metrics-in");

        final MetricsReader metricsReader = new MetricsReader(metric, Stage.STARFISHIN);
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.FORWARD_POINT, forwardPointReader);
        final ChronicleObjectReader reader = new ChronicleObjectReaderSequential(metricsReader, new ChronicleObjectReaderMulti(map, true));

        return ChronicleReaderFactory.createSimpleReader(executorService, reader, chronicleInPath, StartAt.START, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader inboundChronicleReaderKDB(@NotNull KdbLastEventReader kdbLastEventReaderIn,
                                                   @Value("${chronicle.in.path:./chronicle.in}") final String chronicleInPath,
                                                   final ChronicleObjectReader inConfigReader,
                                                   final ChronicleObjectReader inMarketDataReader,
                                                   final ChronicleObjectReader inOneSecondReader,
                                                   final ChronicleObjectReader inTradingTimeZoneChimeReader,
                                                   @Value("${kdb.write.enabled}") final boolean kdbEnabled,
                                                   @Value("${kdb.marketPriceStartEventIdOverride:0}") final long pricerStartEventIdOverride
    ) {

        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CONFIGURATION, inConfigReader);
        map.put(MessageType.ONE_SECOND, inOneSecondReader);
        map.put(MessageType.TIMEZONE_CHIME, inTradingTimeZoneChimeReader);
        map.put(MessageType.MARKET_DATA_SNAPSHOT, inMarketDataReader);
        map.put(MessageType.MARKET_DATA_INCREMENT, inMarketDataReader);

        if (!kdbEnabled) {
            LOGGER.warn("KDB is not enabled. Set kdb.write.enabled property to enable this feature.");
        }

        return ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("inChronicleKdb"), chronicleInPath, map, kdbLastEventReaderIn, pricerStartEventIdOverride);
    }

    @Bean
    public ProphetReader inboundChronicleReaderKDB2(@NotNull KdbLastEventReader kdb2LastEventReaderIn,
                                                   @Value("${chronicle.in.path:./chronicle.in}") final String chronicleInPath,
                                                   final ChronicleObjectReader inConfigReader2,
                                                   final ChronicleObjectReader inMarketDataReader2,
                                                   final ChronicleObjectReader inOneSecondReader2,
                                                    final ChronicleObjectReader inTradingTimeZoneChimeReader2,
                                                   @Value("${kdb2.write.enabled}") final boolean kdbEnabled,
                                                   @Value("${kdb2.marketPriceStartEventIdOverride:0}") final long pricerStartEventIdOverride
    ) {

        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CONFIGURATION, inConfigReader2);
        map.put(MessageType.ONE_SECOND, inOneSecondReader2);
        map.put(MessageType.TIMEZONE_CHIME, inTradingTimeZoneChimeReader2);
        map.put(MessageType.MARKET_DATA_SNAPSHOT, inMarketDataReader2);
        map.put(MessageType.MARKET_DATA_INCREMENT, inMarketDataReader2);

        if (!kdbEnabled) {
            LOGGER.warn("KDB is not enabled. Set kdb2.write.enabled property to enable this feature.");
            return null;
        } else {
            return ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("inChronicleKdb2"), chronicleInPath, map, kdb2LastEventReaderIn, pricerStartEventIdOverride);
        }
    }

    @Bean
    public List<ProphetReader> outboundChronicleReaderKDB(
            @NotNull KdbLastEventReader kdbLastEventReader,
            @NotNull @Value("${chronicle.pricer.out.path:./chronicle.out}") final String chronicleOutPath,
            @NotNull final ChronicleReaderGeneric<OptimalPositions> optimalPositionsReaderKDB,
            @NotNull final ChronicleReaderGeneric<Positions> positionsReaderKDB,
            @NotNull final ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneReaderKDB,
            @NotNull final ChronicleReaderGeneric<ProfitAndLoss> profitAndLossReader,
            @NotNull final ChronicleReaderGeneric<ValueAtRisk> valueAtRiskReader,
            @NotNull final ChronicleReaderGeneric<RealisedVolatility> realisedVolatilityReader,
            @NotNull final MetricsClientPriceReader clientPriceReader,
            @NotNull final MarketDataReader filteredMarketDataReader,
            @NotNull final ChronicleReaderGeneric<OneSecond> oneSecondReader,
            @NotNull final ChronicleReaderGeneric<WholesaleBookFactors> wholesaleBookFactorsReader,
            @NotNull final ChronicleReaderGeneric<Signals> signalsReader,
            @Value("${kdb.write.enabled}") final boolean kdbEnabled,
            @Value("${kdb.clientPriceStartEventIdOverride:0}") final long pricerStartEventIdOverride
    ) {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.OPTIMAL_POSITIONS, optimalPositionsReaderKDB);
        map.put(MessageType.PROFIT_AND_LOSS, profitAndLossReader);
        map.put(MessageType.VALUE_AT_RISK, valueAtRiskReader);
        map.put(MessageType.POSITIONS, positionsReaderKDB);
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, filteredMarketDataReader);
        map.put(MessageType.CLIENT_PRICE, clientPriceReader.fromSource(chronicleOutPath));
        map.put(MessageType.ONE_SECOND, oneSecondReader);
        map.put(MessageType.WHOLESALE_BOOK_FACTORS, wholesaleBookFactorsReader);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneReaderKDB);
        map.put(MessageType.REALISED_VOLATILITY, realisedVolatilityReader);
        map.put(MessageType.SIGNALS, signalsReader);

        if (!kdbEnabled) {
            LOGGER.warn("KDB is not enabled. Set kdb.write.enabled property to enable this feature.");
        }

        final ProphetReader pricingOutReader = ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("pricingChronicleKdb"), chronicleOutPath, map, kdbLastEventReader, pricerStartEventIdOverride);
        final List<ProphetReader> resultList = Lists.newArrayList(pricingOutReader);

        return resultList;
    }

    @Bean
    public List<ProphetReader> outboundChronicleReaderKDB2(
            @NotNull KdbLastEventReader kdb2LastEventReader,
            @NotNull @Value("${chronicle.pricer.out.path:./chronicle.out}") final String chronicleOutPath,
            @NotNull final ChronicleReaderGeneric<OptimalPositions> optimalPositionsReaderKDB2,
            @NotNull final ChronicleReaderGeneric<Positions> positionsReaderKDB2,
            @NotNull final ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneReaderKDB2,
            @NotNull final ChronicleReaderGeneric<ProfitAndLoss> profitAndLossReader2,
            @NotNull final ChronicleReaderGeneric<ValueAtRisk> valueAtRiskReader2,
            @NotNull final ChronicleReaderGeneric<RealisedVolatility> realisedVolatilityReader2,
            @NotNull final MetricsClientPriceReader clientPriceReader2,
            @NotNull final MarketDataReader filteredMarketDataReader2,
            @NotNull final ChronicleReaderGeneric<OneSecond> oneSecondReader2,
            @NotNull final ChronicleReaderGeneric<WholesaleBookFactors> wholesaleBookFactorsReader2,
            @NotNull final ChronicleReaderGeneric<Signals> signalsReader2,
            @Value("${kdb2.write.enabled}") final boolean kdbEnabled,
            @Value("${kdb2.clientPriceStartEventIdOverride:0}") final long pricerStartEventIdOverride
    ) {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.OPTIMAL_POSITIONS, optimalPositionsReaderKDB2);
        map.put(MessageType.PROFIT_AND_LOSS, profitAndLossReader2);
        map.put(MessageType.VALUE_AT_RISK, valueAtRiskReader2);
        map.put(MessageType.POSITIONS, positionsReaderKDB2);
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, filteredMarketDataReader2);
        map.put(MessageType.CLIENT_PRICE, clientPriceReader2.fromSource(chronicleOutPath));
        map.put(MessageType.ONE_SECOND, oneSecondReader2);
        map.put(MessageType.WHOLESALE_BOOK_FACTORS, wholesaleBookFactorsReader2);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneReaderKDB2);
        map.put(MessageType.REALISED_VOLATILITY, realisedVolatilityReader2);
        map.put(MessageType.SIGNALS, signalsReader2);

        if (!kdbEnabled) {
            LOGGER.warn("KDB2 is not enabled. Set kdb2.write.enabled property to enable this feature.");
            return Collections.emptyList();
        } else {

            final ProphetReader pricingOutReader = ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("pricingChronicleKdb2"), chronicleOutPath, map, kdb2LastEventReader, pricerStartEventIdOverride);
            final List<ProphetReader> resultList = Lists.newArrayList(pricingOutReader);

            return resultList;
        }
    }

    @Bean
    public List<ProphetReader> outboundCrossChronicleReaderKDB(
            @NotNull KdbLastEventReader kdbLastEventReader,
            @NotNull @Value("${chronicle.cross.out.path:./chronicle.cross.out}") final String chronicleOutPath,
            @NotNull final MetricsClientPriceReader clientPriceCrossReader,
            @Value("${kdb.write.enabled}") final boolean kdbEnabled,
            @Value("${kdb.clientPriceStartEventIdOverride:0}") final long pricerStartEventIdOverride
    ) {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CLIENT_PRICE, clientPriceCrossReader.fromSource(chronicleOutPath));

        if (!kdbEnabled) {
            LOGGER.warn("KDB is not enabled. Set kdb.write.enabled property to enable this feature.");
        }

        final ProphetReader pricingOutReader = ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("pricingCrossChronicleKdb"), chronicleOutPath, map, kdbLastEventReader, pricerStartEventIdOverride);
        final List<ProphetReader> resultList = Lists.newArrayList(pricingOutReader);

        return resultList;
    }
    @Bean
    public List<ProphetReader> outboundCrossChronicleReaderKDB2(
            @NotNull KdbLastEventReader kdb2LastEventReader,
            @NotNull @Value("${chronicle.cross.out.path:./chronicle.cross.out}") final String chronicleOutPath,
            @NotNull final MetricsClientPriceReader clientPriceCrossReader2,
            @Value("${kdb2.write.enabled}") final boolean kdbEnabled,
            @Value("${kdb2.clientPriceStartEventIdOverride:0}") final long pricerStartEventIdOverride
    ) {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CLIENT_PRICE, clientPriceCrossReader2.fromSource(chronicleOutPath));

        if (!kdbEnabled) {
            LOGGER.warn("KDB2 is not enabled. Set kdb2.write.enabled property to enable this feature.");
            return Collections.emptyList();
        } else {

            final ProphetReader pricingOutReader = ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("pricingCrossChronicleKdb2"), chronicleOutPath, map, kdb2LastEventReader, pricerStartEventIdOverride);
            final List<ProphetReader> resultList = Lists.newArrayList(pricingOutReader);

            return resultList;
        }
    }

    @Bean
    public ProphetReader hedgingOutboundChronicleReaderKDB(@NotNull KdbLastEventReader kdbLastEventReader,
                                                           @NotNull @Value("${chronicle.hedger.out.path:./chronicle.hedger.out}") final String chronicleOutPath,
                                                           @NotNull final ChronicleReaderGeneric<HedgeFirewallStatus> hedgeFirewallStatusReaderKDB,
                                                           @NotNull final ChronicleReaderGeneric<RiskPath> riskPathReaderKDB,
                                                           @NotNull final ChronicleReaderGeneric<HedgeDecision> hedgeDecisionReader,
                                                           @NotNull final ChronicleReaderGeneric<ProfitAndLoss> hedgersProfitAndLossReader,
                                                           @Value("${kdb.write.enabled}") final boolean kdbEnabled) {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.HEDGE_DECISION, hedgeDecisionReader);
        map.put(MessageType.HEDGE_FIREWALL_STATUS, hedgeFirewallStatusReaderKDB);
        map.put(MessageType.RISK_PATH, riskPathReaderKDB);
        map.put(MessageType.PROFIT_AND_LOSS, hedgersProfitAndLossReader);

        if (!kdbEnabled) {
            LOGGER.warn("KDB is not enabled. Set kdb.write.enabled property to enable this feature.");
        }

        return ChronicleReaderFactory.createEventIdBoundReader(singleExecutorService("hedgingChronicleKdb"), chronicleOutPath, map, kdbLastEventReader, 0);
    }

    @Bean
    public List<ProphetReader> outboundChronicleReaderJMX(
            @NotNull @Value("${chronicle.pricer.out.path:./chronicle.out}") final String chronicleOutPath,
            @NotNull @Qualifier("positionsReaderJMX") final ChronicleReaderGeneric<Positions> positionsReader,
            @NotNull final ChronicleReaderGeneric<FilteredMarketDataSnapshot> aggBookMbean,
            @NotNull final ChronicleReaderGeneric<ClientPrice> clientPriceMbean,
            @NotNull final ChronicleReaderGeneric<OptimalPositions> optimalPositionsReaderJMX,
            @NotNull final ChronicleReaderGeneric<ValueAtRisk> valueAtRiskMbean,
            @NotNull final ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneReader,
            @NotNull final ChronicleReaderGeneric<HourChime> hourChimeReader,
            @NotNull final ChronicleReaderGeneric<HedgeFirewallStatus> hedgeFirewallStatusMbean,
            @NotNull final ChronicleReaderGeneric<WholesaleBookFactors> wholesaleBookFactorsMBean,
            @NotNull final ChronicleReaderGeneric<EndOfWeekChime> endOfWeekChimeReader,
            @NotNull final ChronicleReaderGeneric<ConfigurationData> configurationDataMbean,
            @NotNull final ChronicleReaderGeneric<HedgeStatus> hedgeStatusReader) throws IOException {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CONFIGURATION, configurationDataMbean);
        map.put(MessageType.POSITIONS, positionsReader);
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, aggBookMbean);
        map.put(MessageType.CLIENT_PRICE, clientPriceMbean);
        map.put(MessageType.OPTIMAL_POSITIONS, optimalPositionsReaderJMX);
        map.put(MessageType.VALUE_AT_RISK, valueAtRiskMbean);
        map.put(MessageType.WHOLESALE_BOOK_FACTORS, wholesaleBookFactorsMBean);
        map.put(MessageType.END_OF_WEEK_CHIME, endOfWeekChimeReader);
        map.put(MessageType.HOUR_CHIME, hourChimeReader);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneReader);
        map.put(MessageType.HEDGE_STATUS, hedgeStatusReader);
        map.put(MessageType.HEDGE_FIREWALL_STATUS, hedgeFirewallStatusMbean);

        final ChronicleObjectReader readers = new ChronicleObjectReaderMulti(map, true);
        final ProphetReader outReader = ChronicleReaderFactory.createSimpleReader(singleExecutorService("jmx"), readers, chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
        final List<ProphetReader> resultList = Lists.newArrayList(outReader);

        return resultList;
    }

    @Bean
    public MetricReporter kdbMetricsPublisher(@Value("${kdb.write.metrics.enabled:true}") final boolean publishMetricsToKdbEnabled,
                                              @Value("${kdb.metrics.synchronous:false}") final boolean synchronous,
                                              @NotNull final KDBPublisher kdbPublisherForTicketPlant) {
        if (publishMetricsToKdbEnabled) {
            return new KDBMetricsPublisher(kdbPublisherForTicketPlant, synchronous);
        } else {
            return NoOpMetricReporter.INSTANCE;
        }
    }

    @Bean
    public MetricsPerfRecorder metricsPerfRecorder(@Value("${metrics.reportEverySeconds}") final int reportEverySec,
                                                   final MetricReporter kdbMetricsPublisher) {
        return new MetricsPerfRecorder(reportEverySec, kdbMetricsPublisher)
                .register(Stage.HEDGE, new PerfRecorderHeaderPercentiles("chOutH.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.HEDGE, new PerfRecorderHeaderPercentiles("chOutH.receive.to.start", Header::getEventTimeStampNS, Header::getStartTimeStampNS))
                .register(Stage.HEDGE, new PerfRecorderHeaderPercentiles("chOutH.receive.to.finish", Header::getEventTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.PRICE, new PerfRecorderHeaderPercentiles("chOut.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.PRICE, new PerfRecorderHeaderPercentiles("chOut.receive.to.start", Header::getEventTimeStampNS, Header::getStartTimeStampNS))
                .register(Stage.PRICE, new PerfRecorderHeaderPercentiles("chOut.receive.to.finish", Header::getEventTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.CROSS, new PerfRecorderHeaderPercentiles("chOutX.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.CROSS, new PerfRecorderHeaderPercentiles("chOutX.receive.to.start", Header::getEventTimeStampNS, Header::getStartTimeStampNS))
                .register(Stage.CROSS, new PerfRecorderHeaderPercentiles("chOutX.receive.to.finish", Header::getEventTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.STARFISHOUT, new PerfRecorderHeaderPercentiles("chStarOut.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.STARFISHOUT, new PerfRecorderHeaderPercentiles("chStarOut.receive.to.start", Header::getEventTimeStampNS, Header::getStartTimeStampNS))
                .register(Stage.STARFISHOUT, new PerfRecorderHeaderPercentiles("chStarOut.receive.to.finish", Header::getEventTimeStampNS, Header::getFinishTimeStampNS))
                .register(Stage.STARFISHIN, new PerfRecorderHeaderPercentiles("chIn.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS))

                // new EndEvent metrics gathering
                .register(Stage.STARFISHOUT, new PerfRecorderEndEventPercentiles());
    }

    @Bean
    public ProphetReader outboundChronicleReaderMetricsStarfishIn(
            @NotNull @Value("${chronicle.in.path:./chronicle.in}") final String chronicleOutPath,
            final MetricsPerfRecorder metricsPerfRecorder) throws IOException {
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("metrics-star-in"), metricsPerfRecorder.forStage(Stage.STARFISHIN), chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader outboundChronicleReaderMetrics(
            @NotNull @Value("${chronicle.pricer.out.path:./chronicle.out}") final String chronicleOutPath,
            final MetricsPerfRecorder metricsPerfRecorder) throws IOException {
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("metrics-out"), metricsPerfRecorder.forStage(Stage.PRICE), chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader outboundChronicleReaderMetricsCrossOut(
            @NotNull @Value("${chronicle.cross.out.path:./chronicle.cross.out}") final String chronicleOutPath,
            final MetricsPerfRecorder metricsPerfRecorder) throws IOException {
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("metrics-cross-out"), metricsPerfRecorder.forStage(Stage.CROSS), chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader outboundChronicleReaderMetricsHedgerOut(
            @NotNull @Value("${chronicle.hedger.out.path:./chronicle.hedger.out}") final String chronicleOutPath,
            final MetricsPerfRecorder metricsPerfRecorder) throws IOException {
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("metrics-hedger-out"), metricsPerfRecorder.forStage(Stage.HEDGE), chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader outboundChronicleReaderMetricsStarfishOut(
            @NotNull @Value("${chronicle.star.out.path:./chronicle.star.out}") final String chronicleOutPath,
            final MetricsPerfRecorder metricsPerfRecorder) throws IOException {
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("metrics-star-out"), metricsPerfRecorder.forStage(Stage.STARFISHOUT), chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader starfishOutChronicleReaderMilestones(
                                                        @NotNull @Value("${chronicle.star.out.path:./chronicle.star.out}") final String chronicleOutPath,
                                                        @Value("${kdb.write.milestones.enabled:true}") final boolean enabled,
                                                        @Value("${kdb.milestones.sample.every:100}") final long sampleEvery,
                                                        @Value("${kdb.milestones.synchronous:false}") final boolean synchronous,
                                                        @Value("${backtest.enabled:false}") final boolean isBackTestEnabled,
                                                        @NotNull final KDBPublisher kdbPublisherForTicketPlant) throws IOException {
        final KDBMilestonePublisher kdbMilestonePublisher = new KDBMilestonePublisher(kdbPublisherForTicketPlant, enabled && !isBackTestEnabled, sampleEvery, synchronous);
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.END_EVENT, new ChronicleReaderGeneric<>(new EndEventImpl(), kdbMilestonePublisher.consumeEndEvent()));
        map.put(MessageType.ONE_SECOND, new ChronicleReaderGeneric<>(OneSecond.INSTANCE, kdbMilestonePublisher.consumerOfEvent()));
        final ChronicleObjectReader readers = new ChronicleObjectReaderMulti(map, true);
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("milestones-starout"), readers, chronicleOutPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public ProphetReader inChronicleReaderMilestones(@Value("${chronicle.in.path:./chronicle.in}") final String chronicleInPath,
                                                     @Value("${kdb.write.milestones.enabled:true}") final boolean enabled,
                                                     @Value("${kdb.milestones.sample.every:100}") final long sampleEvery,
                                                     @Value("${kdb.milestones.synchronous:false}") final boolean synchronous,
                                                     @Value("${backtest.enabled:false}") final boolean isBackTestEnabled,
                                                     @NotNull final KDBPublisher kdbPublisherForTicketPlant) throws IOException {
        final KDBMilestonePublisher kdbMilestonePublisher = new KDBMilestonePublisher(kdbPublisherForTicketPlant, enabled && !isBackTestEnabled, sampleEvery, synchronous);
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.MARKET_DATA_SNAPSHOT, new ChronicleReaderGeneric<>(MarketDataSnapshotImpl.forMarket(), kdbMilestonePublisher.consumeMarketDataTimestamps()));
        map.put(MessageType.MARKET_DATA_INCREMENT, new ChronicleReaderGeneric<>(new MarketDataIncrementImpl(), kdbMilestonePublisher.consumeMarketDataTimestamps()));
        map.put(MessageType.ONE_SECOND, new ChronicleReaderGeneric<>(OneSecond.INSTANCE, kdbMilestonePublisher.consumerOfEvent()));
        final ChronicleObjectReader readers = new ChronicleObjectReaderMulti(map, true);
        return ChronicleReaderFactory.createSimpleReader(singleExecutorService("milestones-starin"), readers, chronicleInPath, StartAt.END, RingBuffer.NO_RING);
    }

    @Bean
    public KdbLastEventReader kdbLastEventReaderIn(@NotNull @Qualifier("kdbGateway") final KDBReader kdbGateway,
                                                   @Value("${kdb.write.lastEventId.enabled:true}") final boolean kdbLastEventIdEnabled,
                                                   @NotNull @Value("${kdb.table.marketdata.depth:prophetfxdepth}") final String tableFXDepth,
                                                   @NotNull @Value("#{'${kdb.write.newTables:}'.split(',')}") final Set<String> newTables,
                                                   @NotNull @Value("#{'${kdb.write.publisherAwareTables:}'.split(',')}") final Set<String> publisherAwareTables) {
        LOGGER.info("KDB Last Event Reader CIN (kdb): enabled={}, lastEventIdEnabled={}", kdbGateway.isEnabled(), kdbLastEventIdEnabled);
        Map<MessageType, String[]> data = new HashMap<>();
        data.put(MessageType.MARKET_DATA_SNAPSHOT, new String[]{tableFXDepth});
        data.put(MessageType.MARKET_DATA_INCREMENT, new String[]{tableFXDepth});
        return new KdbLastEventReader(kdbGateway, data, newTables, publisherAwareTables, kdbGateway.isEnabled() && kdbLastEventIdEnabled);
    }

    @Bean
    public KdbLastEventReader kdb2LastEventReaderIn(@NotNull @Qualifier("kdb2Gateway") final KDBReader kdbGateway,
                                                   @Value("${kdb2.write.lastEventId.enabled:true}") final boolean kdbLastEventIdEnabled,
                                                   @NotNull @Value("${kdb2.table.marketdata.depth:prophetfxdepth}") final String tableFXDepth,
                                                   @NotNull @Value("#{'${kdb2.write.newTables:}'.split(',')}") final Set<String> newTables,
                                                    @NotNull @Value("#{'${kdb2.write.publisherAwareTables:}'.split(',')}") final Set<String> publisherAwareTables) {
        LOGGER.info("KDB Last Event Reader CIN (kdb2): enabled={}, lastEventIdEnabled={}", kdbGateway.isEnabled(), kdbLastEventIdEnabled);
        Map<MessageType, String[]> data = new HashMap<>();
        data.put(MessageType.MARKET_DATA_SNAPSHOT, new String[]{tableFXDepth});
        data.put(MessageType.MARKET_DATA_INCREMENT, new String[]{tableFXDepth});
        return new KdbLastEventReader(kdbGateway, data, newTables, publisherAwareTables, kdbGateway.isEnabled() && kdbLastEventIdEnabled);
    }

    @Bean
    public KdbLastEventReader kdbLastEventReader(@NotNull @Qualifier("kdbGateway") final KDBReader kdbGateway,
                                                 @Value("${kdb.write.lastEventId.enabled:true}") final boolean kdbLastEventIdEnabled,
                                                 @Value("${kdb.table.position:prophetposition}") final String tableProphetPosition,
                                                 @Value("${kdb.table.equivposition:prophetequivposition}") final String tableOptimalPosition,
                                                 @Value("${kdb.table.pnl:prophetpnl}") final String tablePnl,
                                                 @NotNull @Value("${kdb.table.hedgedecision:prophethedgedecision}") final String tableHedgeDecision,
                                                 @NotNull @Value("${kdb.table.hedgefirewall:prophethedgefirewall}") final String tableHedgeFirewallDecision,
                                                 @NotNull @Value("${kdb.table.clientprice.tob:prophetfxquote}") final String tableFXQuote,
                                                 @NotNull @Value("${kdb.table.riskpath:prophetriskpath}") final String tableRiskPath,
                                                 @NotNull @Value("${kdb.table.volatility:volatility}") final String tableVolatility,
                                                 @NotNull @Value("#{'${kdb.write.newTables:}'.split(',')}") final Set<String> newTables,
                                                 @NotNull @Value("#{'${kdb.write.publisherAwareTables:}'.split(',')}") final Set<String> publisherAwareTables) {

        LOGGER.info("KDB Last Event Reader COUT (kdb): enabled={}, lastEventIdEnabled={}", kdbGateway.isEnabled(), kdbLastEventIdEnabled);

        Map<MessageType, String[]> data = new HashMap<>();

        data.put(MessageType.CLIENT_PRICE, new String[]{tableFXQuote});
        data.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, new String[]{tableFXQuote});
        data.put(MessageType.OPTIMAL_POSITIONS, new String[]{tableOptimalPosition});
        data.put(MessageType.POSITIONS, new String[]{tableProphetPosition});
        data.put(MessageType.VALUE_AT_RISK, new String[]{tablePnl});
        data.put(MessageType.PROFIT_AND_LOSS, new String[]{tablePnl});
        data.put(MessageType.HEDGE_DECISION, new String[]{tableHedgeDecision});
        data.put(MessageType.HEDGE_FIREWALL_STATUS, new String[]{tableHedgeFirewallDecision});
        data.put(MessageType.RISK_PATH, new String[]{tableRiskPath});
        data.put(MessageType.REALISED_VOLATILITY, new String[]{tableVolatility});
        data.put(MessageType.WHOLESALE_BOOK_FACTORS, KDBWholesaleBookFactorsBatchPublisher.TABLES);
        data.put(MessageType.SIGNALS, new String[] { KDBSignalsBatchPublisher.TABLE_NAME });

        return new KdbLastEventReader(kdbGateway, data, newTables, publisherAwareTables, kdbGateway.isEnabled() && kdbLastEventIdEnabled);
    }

    @Bean
    public KdbLastEventReader kdb2LastEventReader(@NotNull @Qualifier("kdb2Gateway") final KDBReader kdb2Gateway,
                                                 @Value("${kdb2.write.lastEventId.enabled:true}") final boolean kdbLastEventIdEnabled,
                                                 @Value("${kdb2.table.position:prophetposition}") final String tableProphetPosition,
                                                 @Value("${kdb2.table.equivposition:prophetequivposition}") final String tableOptimalPosition,
                                                 @Value("${kdb2.table.pnl:prophetpnl}") final String tablePnl,
                                                 @NotNull @Value("${kdb2.table.hedgedecision:prophethedgedecision}") final String tableHedgeDecision,
                                                 @NotNull @Value("${kdb2.table.hedgefirewall:prophethedgefirewall}") final String tableHedgeFirewallDecision,
                                                 @NotNull @Value("${kdb2.table.clientprice.tob:prophetfxquote}") final String tableFXQuote,
                                                 @NotNull @Value("${kdb2.table.riskpath:prophetriskpath}") final String tableRiskPath,
                                                 @NotNull @Value("${kdb2.table.volatility:volatility}") final String tableVolatility,
                                                 @NotNull @Value("#{'${kdb2.write.newTables:}'.split(',')}") final Set<String> newTables,
                                                  @NotNull @Value("#{'${kdb2.write.publisherAwareTables:}'.split(',')}") final Set<String> publisherAwareTables) {

        LOGGER.info("KDB Last Event Reader COUT (kdb2): enabled={}, lastEventIdEnabled={}", kdb2Gateway.isEnabled(), kdbLastEventIdEnabled);

        Map<MessageType, String[]> data = new HashMap<>();

        data.put(MessageType.CLIENT_PRICE, new String[]{tableFXQuote});
        data.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, new String[]{tableFXQuote});
        data.put(MessageType.OPTIMAL_POSITIONS, new String[]{tableOptimalPosition});
        data.put(MessageType.POSITIONS, new String[]{tableProphetPosition});
        data.put(MessageType.VALUE_AT_RISK, new String[]{tablePnl});
        data.put(MessageType.PROFIT_AND_LOSS, new String[]{tablePnl});
        data.put(MessageType.HEDGE_DECISION, new String[]{tableHedgeDecision});
        data.put(MessageType.HEDGE_FIREWALL_STATUS, new String[]{tableHedgeFirewallDecision});
        data.put(MessageType.RISK_PATH, new String[]{tableRiskPath});
        data.put(MessageType.REALISED_VOLATILITY, new String[]{tableVolatility});
        data.put(MessageType.WHOLESALE_BOOK_FACTORS, KDBWholesaleBookFactorsBatchPublisher.TABLES);
        data.put(MessageType.SIGNALS, new String[] { KDBSignalsBatchPublisher.TABLE_NAME });

        return new KdbLastEventReader(kdb2Gateway, data, newTables, publisherAwareTables, kdb2Gateway.isEnabled() && kdbLastEventIdEnabled);
    }

    @Bean
    public ConfigReader inConfigReader(final Consumer<ConfigurationData> inConfigurationDataConsumer) {
        return new ConfigReader(new NotifierDefault<>(inConfigurationDataConsumer));
    }

    @Bean
    public ConfigReader inConfigReader2(final Consumer<ConfigurationData> inConfigurationDataConsumer2) {
        return new ConfigReader(new NotifierDefault<>(inConfigurationDataConsumer2));
    }

    @Bean
    public MarketDataReader inMarketDataReader(final Consumer<MarketData> inMarketDataConsumers) {
        return new MarketDataReader(Arrays.asList(inMarketDataConsumers));
    }

    @Bean
    public MarketDataReader inMarketDataReader2(final Consumer<MarketData> inMarketDataConsumers2) {
        return new MarketDataReader(Arrays.asList(inMarketDataConsumers2));
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> inOneSecondReader(final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, filteredMarketDataSnapshotManager.consumerOfOneSecond());
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> inOneSecondReader2(final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager2) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, filteredMarketDataSnapshotManager2.consumerOfOneSecond());
    }

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> inTradingTimeZoneChimeReader(TradingTimeZoneManager tradingTimeZoneManager) {
        return new ChronicleReaderGeneric<>(new TradingTimeZoneChime(), tradingTimeZoneManager);
    }

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> inTradingTimeZoneChimeReader2(TradingTimeZoneManager tradingTimeZoneManager2) {
        return new ChronicleReaderGeneric<>(new TradingTimeZoneChime(), tradingTimeZoneManager2);
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManager2(final AggregatedBookManager primaryAggregatedBookManager2, final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager2) {
        return new TradingTimeZoneManager(new NotifierDefault<>(primaryAggregatedBookManager2.consumerTradingTimeZoneChime(), filteredMarketDataSnapshotManager2.consumerOfTradingTimeZoneChime()));
    }

    // readers
    @Bean
    public ChronicleReaderGeneric<HedgeStatus> hedgeStatusReader(
            final HedgerStatusViewer hedgerStatusViewer) {
        return new ChronicleReaderGeneric<>(new HedgeStatusImpl(), hedgerStatusViewer.consumerOfHedgeStatus());
    }

    @Bean
    public ChronicleReaderGeneric<OptimalPositions> optimalPositionsReaderKDB(
            final KDBOptimalPositionPublisher kdbOptimalPositionPublisher) {
        return new ChronicleReaderGeneric<>(new OptimalPositions(), kdbOptimalPositionPublisher.consumeOptimalPositions());
    }

    @Bean
    public ChronicleReaderGeneric<OptimalPositions> optimalPositionsReaderKDB2(
            final KDBOptimalPositionPublisher kdb2OptimalPositionPublisher) {
        return new ChronicleReaderGeneric<>(new OptimalPositions(), kdb2OptimalPositionPublisher.consumeOptimalPositions());
    }

    @Bean
    public ChronicleReaderGeneric<OptimalPositions> optimalPositionsReaderJMX(
            final Consumer<OptimalPosition> optimalPositionReporter) {
        return new ChronicleReaderGeneric<>(new OptimalPositions(), optimalPositions -> {
            optimalPositions.ops.forEach(optimalPositionReporter);
        });
    }

    @Bean
    public ChronicleReaderGeneric<Positions> positionsReaderKDB(
            final KDBPositionPublisher kdbPositionPublisher) {
        return new ChronicleReaderGeneric<>(new Positions(), kdbPositionPublisher.consumeOfPositions());
    }

    @Bean
    public ChronicleReaderGeneric<Positions> positionsReaderKDB2(
            final KDBPositionPublisher kdb2PositionPublisher) {
        return new ChronicleReaderGeneric<>(new Positions(), kdb2PositionPublisher.consumeOfPositions());
    }

    @Bean
    public ChronicleReaderGeneric<HedgeFirewallStatus> hedgeFirewallStatusReaderKDB(
            final KDBHedgeFirewallStatusPublisher kdbHedgeFirewallStatusPublisher) {
        return new ChronicleReaderGeneric<>(new HedgeFirewallStatusImpl(), kdbHedgeFirewallStatusPublisher.consumeOfHedgeFirewallStatus());
    }

    @Bean
    public ChronicleReaderGeneric<RiskPath> riskPathReaderKDB(
            final KDBRiskPathPublisher kdbRiskPathPublisher) {
        return new ChronicleReaderGeneric<>(new RiskPath(), kdbRiskPathPublisher.consumeOfRiskPath());
    }

    @Bean
    public ChronicleReaderGeneric<Positions> positionsReaderJMX(
            final Consumer<Position> positionConsumer) {
        final Consumer<Positions> positionsConsumer = positions -> positions.forEach(positionConsumer);
        return new ChronicleReaderGeneric<>(new Positions(), positionsConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<ProfitAndLoss> profitAndLossReader(
            final KDBProfitAndLossPublisher kdbProfitAndLossPublisher,
            final KDBGenericProfitAndLossPublisher kdbBiasOffsetProfitAndLossPublisher
    ) {
        return new ChronicleReaderGeneric<>(new ProfitAndLossImpl(), pnl -> {
            if (pnl.getPortfolio() == Portfolio.BIAS_OFFSET) {
                kdbBiasOffsetProfitAndLossPublisher.consumerOfProfitAndLoss().accept(pnl);
            } else {
                kdbProfitAndLossPublisher.consumerOfProfitAndLoss().accept(pnl);
            }
        });
    }

    @Bean
    public ChronicleReaderGeneric<ProfitAndLoss> profitAndLossReader2(
            final KDBProfitAndLossPublisher kdb2ProfitAndLossPublisher,
            final KDBGenericProfitAndLossPublisher kdb2BiasOffsetProfitAndLossPublisher
    ) {
        return new ChronicleReaderGeneric<>(new ProfitAndLossImpl(), pnl -> {
            if (pnl.getPortfolio() == Portfolio.BIAS_OFFSET) {
                kdb2BiasOffsetProfitAndLossPublisher.consumerOfProfitAndLoss().accept(pnl);
            } else {
                kdb2ProfitAndLossPublisher.consumerOfProfitAndLoss().accept(pnl);
            }
        });
    }

    @Bean
    public ChronicleReaderGeneric<RealisedVolatility> realisedVolatilityReader(
            final KDBRealisedVolatilityPublisher kdbRealisedVolatilityPublisher
    ) {
        return new ChronicleReaderGeneric<>(new RealisedVolatilityImpl(), kdbRealisedVolatilityPublisher.consumerOfRealisedVolatility());
    }

    @Bean
    public ChronicleReaderGeneric<RealisedVolatility> realisedVolatilityReader2(
            final KDBRealisedVolatilityPublisher kdb2RealisedVolatilityPublisher
    ) {
        return new ChronicleReaderGeneric<>(new RealisedVolatilityImpl(), kdb2RealisedVolatilityPublisher.consumerOfRealisedVolatility());
    }

    @Bean
    public ChronicleReaderGeneric<ProfitAndLoss> hedgersProfitAndLossReader(
            final KDBGenericProfitAndLossPublisher kdbHedgersProfitAndLossPublisher
    ) {
        return new ChronicleReaderGeneric<>(new ProfitAndLossImpl(), kdbHedgersProfitAndLossPublisher.consumerOfProfitAndLoss());
    }

    @Bean
    public ChronicleReaderGeneric<HedgeDecision> hedgeDecisionReader(
            final KDBHedgeDecisionPublisher hedgeDecisionPublisher) {
        return new ChronicleReaderGeneric<>(new HedgeDecisionImpl(), hedgeDecisionPublisher.consumerOfHedgeDecision());
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManager(final ChimeConsumerMBean chimeConsumerMBean, final AggregatedBookManager primaryAggregatedBookManager, final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager) {
        return new TradingTimeZoneManager(new NotifierDefault<>(chimeConsumerMBean.consumerOfTradingTimeZoneChime(), primaryAggregatedBookManager.consumerTradingTimeZoneChime(), filteredMarketDataSnapshotManager.consumerOfTradingTimeZoneChime()));
    }

    /**
     * Note: The TradingTimeZoneManager will miss the first timezone chime on startup due to metrics only receiving events above the previous id seen in KDB.
     * This means that the Context timezone (and any other listeners) will remain WEEKEND until the next timezone change.
     * The current use appears to be limited to JMX.  For more important uses this will need to be corrected.
     */
    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneReader(final TradingTimeZoneManager tradingTimeZoneManager) {
        return new ChronicleReaderGeneric<>(new TradingTimeZoneChime(), tradingTimeZoneManager);
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManagerKDB() {
        return new TradingTimeZoneManager(new NotifierDefault<>());
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManagerKDB2() {
        return new TradingTimeZoneManager(new NotifierDefault<>());
    }

    /**
     * See comments in tradingTimeZoneReader above.
     */
    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneReaderKDB(final TradingTimeZoneManager tradingTimeZoneManagerKDB) {
        return new ChronicleReaderGeneric<>(new TradingTimeZoneChime(), tradingTimeZoneManagerKDB);
    }

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneReaderKDB2(final TradingTimeZoneManager tradingTimeZoneManagerKDB2) {
        return new ChronicleReaderGeneric<>(new TradingTimeZoneChime(), tradingTimeZoneManagerKDB2);
    }

    @Bean
    public ChronicleReaderGeneric<HourChime> hourChimeReader(
            final ChimeConsumerMBean chimeConsumerMBean) {
        return new ChronicleReaderGeneric<>(HourChime.INSTANCE, chimeConsumerMBean.consumerOfHourChime());
    }

    @Bean
    public ChronicleReaderGeneric<EndOfWeekChime> endOfWeekChimeReader(
            final ChimeConsumerMBean chimeConsumerMBean) {
        return new ChronicleReaderGeneric<>(EndOfWeekChime.INSTANCE, chimeConsumerMBean.consumerOfEndOfWeekChime());
    }

    @Bean
    public ChronicleReaderGeneric<ValueAtRisk> valueAtRiskReader(
            final KDBProfitAndLossPublisher kdbProfitAndLossPublisher) {
        return new ChronicleReaderGeneric<>(new ValueAtRiskImpl(), kdbProfitAndLossPublisher.consumerOfValueAtRisk());
    }

    @Bean
    public ChronicleReaderGeneric<ValueAtRisk> valueAtRiskReader2(
            final KDBProfitAndLossPublisher kdb2ProfitAndLossPublisher) {
        return new ChronicleReaderGeneric<>(new ValueAtRiskImpl(), kdb2ProfitAndLossPublisher.consumerOfValueAtRisk());
    }

    @Bean
    public ChronicleReaderGeneric<ForwardPoint> forwardPointReader(
            final Consumer<ForwardPoint> forwardPointReporter) {
        return new ChronicleReaderGeneric<>(new ForwardPointImpl(), forwardPointReporter);
    }

    // kdb publishers
    @Bean
    public KDBPublisher kdbPublisherForTicketPlant(final @Value("${kdb.credential}") String user,
                                                   final @Value("${kdb.host}") String host,
                                                   final @Value("${kdb.tp.pub.port}") int port,
                                                   @Value("${kdb.write.enabled}") final boolean kdbEnabled) throws Exception {
        return new KDBPublisher("kdb",new KDBConnection(host, port, user), kdbEnabled);
    }

    @Bean
    public KDBPublisher kdb2PublisherForTicketPlant(final @Value("${kdb2.credential}") String user,
                                                    final @Value("${kdb2.host}") String host,
                                                    final @Value("${kdb2.tp.pub.port}") int port,
                                                    @Value("${kdb2.write.enabled}") final boolean kdbEnabled) throws Exception {
        return new KDBPublisher("kdb2", new KDBConnection(host, port, user), kdbEnabled);
    }

    @Bean
    @Scope("prototype")
    public KDBReader kdbGateway(final @Value("${kdb.credential}") String user,
                                final @Value("${kdb.host}") String host,
                                final @Value("${kdb.gw.port}") int port,
                                final @Value("${kdb.write.enabled}") boolean kdbEnabled,
                                final Metric metric) throws Exception {
        return new KDBReader("kdb", new KDBConnection(host, port, user), metric, kdbEnabled);
    }

    @Bean
    @Scope("prototype")
    public KDBReader kdb2Gateway(final @Value("${kdb2.credential}") String user,
                                 final @Value("${kdb2.host}") String host,
                                 final @Value("${kdb2.gw.port}") int port,
                                 final @Value("${kdb2.write.enabled}") boolean kdbEnabled,
                                 final Metric metric) throws Exception {
        return new KDBReader("kdb2",new KDBConnection(host, port, user), metric, kdbEnabled);
    }

    @Bean
    public KDBPositionPublisher kdbPositionPublisher(final KDBPublisher kdbPublisherForTicketPlant,
                                                     @Value("${kdb.table.position:prophetposition}") final String table,
                                                     @Value("#{'${kdb.position.portfolio:CLIENTS_NET,BIAS_OFFSET}'.split(',')}") final Set<Portfolio> portfolios,
                                                     @Value("${kdb.position.synchronous:false}") final boolean synchronous,
                                                     @Value("${kdb.position.enabled:true}") final boolean enabled,
                                                     @Value("${kdb.position.acceptOnlyNotionalChange:false}") final boolean acceptOnlyNotionalChange) throws Exception {
        return new KDBPositionPublisher(kdbPublisherForTicketPlant, table, portfolios, synchronous, enabled, acceptOnlyNotionalChange);
    }

    @Bean
    public KDBPositionPublisher kdb2PositionPublisher(final KDBPublisher kdb2PublisherForTicketPlant,
                                                     @Value("${kdb2.table.position:prophetposition}") final String table,
                                                     @Value("#{'${kdb2.position.portfolio:CLIENTS_NET,BIAS_OFFSET}'.split(',')}") final Set<Portfolio> portfolios,
                                                     @Value("${kdb2.position.synchronous:false}") final boolean synchronous,
                                                     @Value("${kdb2.position.enabled:true}") final boolean enabled,
                                                     @Value("${kdb2.position.acceptOnlyNotionalChange:false}") final boolean acceptOnlyNotionalChange) throws Exception {
        return new KDBPositionPublisher(kdb2PublisherForTicketPlant, table, portfolios, synchronous, enabled, acceptOnlyNotionalChange);
    }

    @Bean
    public KDBOptimalPositionPublisher kdbOptimalPositionPublisher(final KDBPublisher kdbPublisherForTicketPlant,
                                                                   @Value("${kdb.table.equivposition:prophetequivposition}") final String table,
                                                                   @Value("${kdb.party}") final String party,
                                                                   @Value("${kdb.equivposition.synchronous:false}") final boolean synchronous,
                                                                   @Value("${kdb.equivposition.enabled:true}") final boolean enabled) throws Exception {
        return new KDBOptimalPositionPublisher(kdbPublisherForTicketPlant, table, party, synchronous, enabled);
    }

    @Bean
    public KDBOptimalPositionPublisher kdb2OptimalPositionPublisher(final KDBPublisher kdb2PublisherForTicketPlant,
                                                                   @Value("${kdb2.table.equivposition:prophetequivposition}") final String table,
                                                                   @Value("${kdb2.party}") final String party,
                                                                   @Value("${kdb2.equivposition.synchronous:false}") final boolean synchronous,
                                                                   @Value("${kdb2.equivposition.enabled:true}") final boolean enabled) throws Exception {
        return new KDBOptimalPositionPublisher(kdb2PublisherForTicketPlant, table, party, synchronous, enabled);
    }

    @Bean
    public KDBProfitAndLossPublisher kdbProfitAndLossPublisher(final KDBPublisher kdbPublisherForTicketPlant,
                                                               @Value("${kdb.table.pnl:prophetpnl}") final String table,
                                                               @Value("${kdb.prophetpnl.portfolio:CLIENTS_NET}") final Portfolio portfolio,
                                                               @Value("${kdb.prophetpnl.synchronous:false}") final boolean synchronous,
                                                               @Value("${kdb.prophetpnl.enabled:true}") final boolean enabled) throws Exception {
        return new KDBProfitAndLossPublisher(kdbPublisherForTicketPlant, table, portfolio, synchronous, enabled);
    }

    @Bean
    public KDBProfitAndLossPublisher kdb2ProfitAndLossPublisher(final KDBPublisher kdb2PublisherForTicketPlant,
                                                               @Value("${kdb2.table.pnl:prophetpnl}") final String table,
                                                               @Value("${kdb2.prophetpnl.portfolio:CLIENTS_NET}") final Portfolio portfolio,
                                                               @Value("${kdb2.prophetpnl.synchronous:false}") final boolean synchronous,
                                                               @Value("${kdb2.prophetpnl.enabled:true}") final boolean enabled) throws Exception {
        return new KDBProfitAndLossPublisher(kdb2PublisherForTicketPlant, table, portfolio, synchronous, enabled);
    }

    @Bean
    public KDBGenericProfitAndLossPublisher kdbHedgersProfitAndLossPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.pnl:prophetpnl}") final String table,
            @Value("${kdb.prophetpnl.synchronous:false}") final boolean synchronous,
            @Value("${kdb.prophetpnl.enabled:true}") final boolean enabled) {
        return new KDBGenericProfitAndLossPublisher(kdbPublisherForTicketPlant, table, synchronous, enabled,
                pnl -> pnl.getPortfolio().isHedger(),
                pnl -> "REVAL_" + pnl.getPortfolio().name(),
                pnl -> pnl.getValueSystemBaseCurrency());
    }

    @Bean
    public KDBGenericProfitAndLossPublisher kdbBiasOffsetProfitAndLossPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.pnl:prophetpnl}") final String table,
            @Value("${kdb.prophetpnl.synchronous:false}") final boolean synchronous,
            @Value("${kdb.prophetpnl.enabled:true}") final boolean enabled) {
        return new KDBGenericProfitAndLossPublisher(kdbPublisherForTicketPlant, table, synchronous, enabled,
                pnl -> pnl.getPortfolio() == Portfolio.BIAS_OFFSET,
                pnl -> "BIAS_CONTROL",
                pnl -> -pnl.getValueSystemBaseCurrency());
    }

    @Bean
    public KDBGenericProfitAndLossPublisher kdb2BiasOffsetProfitAndLossPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.pnl:prophetpnl}") final String table,
            @Value("${kdb2.prophetpnl.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.prophetpnl.enabled:true}") final boolean enabled) {
        return new KDBGenericProfitAndLossPublisher(kdb2PublisherForTicketPlant, table, synchronous, enabled,
                pnl -> pnl.getPortfolio() == Portfolio.BIAS_OFFSET,
                pnl -> "BIAS_CONTROL",
                pnl -> -pnl.getValueSystemBaseCurrency());
    }

    @Bean
    public KDBRealisedVolatilityPublisher kdbRealisedVolatilityPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.volatility:volatility}") final String table,
            @Value("${kdb.volatility.synchronous:false}") final boolean synchronous,
            @Value("${kdb.volatility.enabled:false}") final boolean enabled) throws Exception {
        return new KDBRealisedVolatilityPublisher(kdbPublisherForTicketPlant, table, synchronous, enabled);
    }

    @Bean
    public KDBRealisedVolatilityPublisher kdb2RealisedVolatilityPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.volatility:volatility}") final String table,
            @Value("${kdb2.volatility.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.volatility.enabled:false}") final boolean enabled) throws Exception {
        return new KDBRealisedVolatilityPublisher(kdb2PublisherForTicketPlant, table, synchronous, enabled);
    }

    @Bean
    public KDBHedgeDecisionPublisher kdbHedgeDecisionPublisher(final KDBPublisher kdbPublisherForTicketPlant,
                                                               @NotNull @Value("${kdb.table.hedge:prophethedgedecision}") final String table,
                                                               @Value("${kdb.prophethedgedecision.synchronous:false}") final boolean synchronous,
                                                               @Value("${kdb.prophethedgedecision.enabled:true}") final boolean enabled) throws Exception {
        return new KDBHedgeDecisionPublisher(kdbPublisherForTicketPlant, table, synchronous, enabled);
    }

    /**
     * TODO: Remove unbatched price publisher once batched is in full use in JP and GB.
     */
    @Bean
    public KDBClientPriceToFxQuotePublisher kdbClientPriceToFxQuotePublisher(
            @NotNull final KDBPublisher kdbPublisherForTicketPlant,
            @NotNull @Value("${kdb.table.clientprice.tob:prophetfxquote}") final String table,
            @NotNull @Value("#{'${kdb.table.clientprice.tob.prophetfxquote.models:ANY}'.split(',')}") final String[] models,
            @NotNull @Value("#{'${kdb.table.clientprice.tob.prophetfxquote.instruments:ANY}'}") final String instruments,  // default all (LEGACY)
            @Value("${kdb.clientprice.tob.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.tob.enabled:true}") final boolean enabled,
            @Value("${kdb.clientprice.tob.publish.all.throttle.states:true}") final boolean publishAllThrottleStates,
            @Value("${kdb.clientprice.tob.publishOnChimer:false}") final boolean publishOnChimer) throws Exception {
        return new KDBClientPriceToFxQuotePublisher(kdbPublisherForTicketPlant, table, synchronous, enabled, publishAllThrottleStates, publishOnChimer, Market.valueOf(models), StringUtils.isBlank(instruments) ? Collections.emptyList() : Instrument.valueOf(Arrays.asList(instruments.split(","))));
    }

    @Bean
    public KDBClientPriceToFxQuotePublisher kdb2ClientPriceToFxQuotePublisher(
            @NotNull final KDBPublisher kdb2PublisherForTicketPlant,
            @NotNull @Value("${kdb2.table.clientprice.tob:prophetfxquote}") final String table,
            @NotNull @Value("#{'${kdb2.table.clientprice.tob.prophetfxquote.models:ANY}'.split(',')}") final String[] models,
            @NotNull @Value("#{'${kdb2.table.clientprice.tob.prophetfxquote.instruments:ANY}'}") final String instruments,  // default all (LEGACY)
            @Value("${kdb2.clientprice.tob.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.tob.enabled:true}") final boolean enabled,
            @Value("${kdb2.clientprice.tob.publish.all.throttle.states:true}") final boolean publishAllThrottleStates,
            @Value("${kdb2.clientprice.tob.publishOnChimer:false}") final boolean publishOnChimer) throws Exception {
        return new KDBClientPriceToFxQuotePublisher(kdb2PublisherForTicketPlant, table, synchronous, enabled, publishAllThrottleStates, publishOnChimer, Market.valueOf(models), StringUtils.isBlank(instruments) ? Collections.emptyList() : Instrument.valueOf(Arrays.asList(instruments.split(","))));
    }

    /**
     * Note: use either kdbClientPriceToFxQuotePublisher or kdbClientPriceToFxQuoteBatchedPublisher
     */
    @Bean
    public KDBClientPriceToFxQuoteBatchPublisher kdbClientPriceToFxQuoteBatchedPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.clientprice.tob.batched.prophetfxquote.models:ANY}") final String models,
            @Value("${kdb.table.clientprice.tob.batched.prophetfxquote.instruments:ANY}") final String instruments,
            @Value("${kdb.clientprice.tob.batched.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.tob.batched.enabled:false}") final boolean enabled,
            @Value("${kdb.clientprice.tob.enabled:true}") final boolean nonBatchedEnabled) {
        if (nonBatchedEnabled) {
            LOGGER.warn("Both the non-batched and batched client price publishers are enabled - ensure you know what you are doing and that data doesn't overlap.");
        }
        return new KDBClientPriceToFxQuoteBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public KDBClientPriceToFxQuoteBatchPublisher kdb2ClientPriceToFxQuoteBatchedPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.clientprice.tob.batched.prophetfxquote.models:ANY}") final String models,
            @Value("${kdb2.table.clientprice.tob.batched.prophetfxquote.instruments:ANY}") final String instruments,
            @Value("${kdb2.clientprice.tob.batched.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.tob.batched.enabled:false}") final boolean enabled) {
        return new KDBClientPriceToFxQuoteBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }


    @Bean
    public KDBClientPriceToFxDepthBatchPublisher kdbClientPriceToFxDepthBatchPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.clientprice.prophetfxdepth.models:WSP_A}") final String models,
            @Value("${kdb.table.clientprice.prophetfxdepth.instruments:ANY}") final String instruments,
            @Value("${kdb.clientprice.depth.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.depth.enabled:true}") final boolean enabled) throws Exception {
        return new KDBClientPriceToFxDepthBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments), false);
    }

    @Bean
    public KDBClientPriceToFxDepthBatchPublisher kdb2ClientPriceToFxDepthBatchPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.clientprice.prophetfxdepth.models:WSP_A}") final String models,
            @Value("${kdb2.table.clientprice.prophetfxdepth.instruments:ANY}") final String instruments,
            @Value("${kdb2.clientprice.depth.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.depth.enabled:true}") final boolean enabled) throws Exception {
        return new KDBClientPriceToFxDepthBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments), false);
    }

    @Bean
    public KDBClientPriceToFxDepthBatchPublisher kdbMarketDataSnapshotToFxDepthBatchPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.marketdata.prophetfxdepth.models:ANY}") final String models,
            @Value("${kdb.table.clientprice.prophetfxdepth.instruments:ANY}") final String instruments,
            @Value("${kdb.marketdata.depth.synchronous:false}") final boolean synchronous,
            @Value("${kdb.marketdata.depth.enabled:true}") final boolean enabled) throws Exception {
        return new KDBClientPriceToFxDepthBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments), true);
    }

    @Bean
    public KDBClientPriceToFxDepthBatchPublisher kdb2MarketDataSnapshotToFxDepthBatchPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.marketdata.prophetfxdepth.models:RFX,HSP,EBS,BARX,CITI,DEUT,UBS,JPM,FASTMATCH}") final String models,
            @Value("${kdb2.table.clientprice.prophetfxdepth.instruments:ANY}") final String instruments,
            @Value("${kdb2.marketdata.depth.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.marketdata.depth.enabled:true}") final boolean enabled) throws Exception {
        return new KDBClientPriceToFxDepthBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments), true);
    }

    @Bean
    public KDBWholesaleBookFactorsBatchPublisher kdbWholesaleBookFactorsPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.clientprice.wbf.models:ANY}") final String models,
            @Value("${kdb.table.clientprice.wbf.instruments:ANY}") final String instruments,
            // These should generally be left to ANY model, ANY instrument to allow data that exists to be published.  Control of data collected is via CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET.
            @Value("${kdb.clientprice.wbf.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.wbf.enabled:true}") final boolean enabled) throws Exception {
        return new KDBWholesaleBookFactorsBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public KDBWholesaleBookFactorsBatchPublisher kdb2WholesaleBookFactorsPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.clientprice.wbf.models:ANY}") final String models,
            @Value("${kdb2.table.clientprice.wbf.instruments:ANY}") final String instruments,
            // These should generally be left to ANY model, ANY instrument to allow data that exists to be published.  Control of data collected is via CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET.
            @Value("${kdb2.clientprice.wbf.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.wbf.enabled:true}") final boolean enabled) throws Exception {
        return new KDBWholesaleBookFactorsBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public KDBSignalsBatchPublisher kdbSignalsBatchPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.discosignals.models:ANY}") final String models,
            @Value("${kdb.table.discosignals.instruments:ANY}") final String instruments,
            @Value("${kdb.discosignals.synchronous:false}") final boolean synchronous,
            @Value("${kdb.discosignals.enabled:true}") final boolean enabled) {
        return new KDBSignalsBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public KDBSignalsBatchPublisher kdb2SignalsBatchPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.discosignals.models:ANY}") final String models,
            @Value("${kdb2.table.discosignals.instruments:ANY}") final String instruments,
            @Value("${kdb2.discosignals.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.discosignals.enabled:true}") final boolean enabled) {
        return new KDBSignalsBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public ChronicleReaderGeneric<WholesaleBookFactors> wholesaleBookFactorsReader(
            @NotNull final KDBWholesaleBookFactorsBatchPublisher kdbWholesaleBookFactorsPublisher) {
        return new ChronicleReaderGeneric<>(new WholesaleBookFactorsImpl(), kdbWholesaleBookFactorsPublisher.consumeWholesaleBookFactors());
    }

    @Bean
    public ChronicleReaderGeneric<WholesaleBookFactors> wholesaleBookFactorsReader2(
            @NotNull final KDBWholesaleBookFactorsBatchPublisher kdb2WholesaleBookFactorsPublisher) {
        return new ChronicleReaderGeneric<>(new WholesaleBookFactorsImpl(), kdb2WholesaleBookFactorsPublisher.consumeWholesaleBookFactors());
    }

    @Bean
    public ChronicleReaderGeneric<Signals> signalsReader(
            @NotNull final KDBSignalsBatchPublisher kdbSignalsBatchPublisher) {
        return new ChronicleReaderGeneric<>(new MutableSignals(), kdbSignalsBatchPublisher.consumeSignals());
    }

    @Bean
    public ChronicleReaderGeneric<Signals> signalsReader2(
            @NotNull final KDBSignalsBatchPublisher kdb2SignalsBatchPublisher) {
        return new ChronicleReaderGeneric<>(new MutableSignals(), kdb2SignalsBatchPublisher.consumeSignals());
    }

    @Bean
    public MetricsClientPriceReader clientPriceReader(
            @NotNull final KDBClientPriceToFxQuotePublisher kdbClientPriceToFxQuotePublisher,
            @NotNull final KDBClientPriceToFxQuoteBatchPublisher kdbClientPriceToFxQuoteBatchedPublisher,
            @NotNull final KDBClientPriceToFxDepthBatchPublisher kdbClientPriceToFxDepthBatchPublisher) throws IOException {
        return new MetricsClientPriceReader(Arrays.asList(kdbClientPriceToFxQuotePublisher.consumeClientPrice(), kdbClientPriceToFxQuoteBatchedPublisher.consumeQuote(), kdbClientPriceToFxDepthBatchPublisher.consumeClientPrice()));
    }

    @Bean
    public MetricsClientPriceReader clientPriceReader2(
            @NotNull final KDBClientPriceToFxQuotePublisher kdb2ClientPriceToFxQuotePublisher,
            @NotNull final KDBClientPriceToFxQuoteBatchPublisher kdb2ClientPriceToFxQuoteBatchedPublisher,
            @NotNull final KDBClientPriceToFxDepthBatchPublisher kdb2ClientPriceToFxDepthBatchPublisher) throws IOException {
        return new MetricsClientPriceReader(Arrays.asList(kdb2ClientPriceToFxQuotePublisher.consumeClientPrice(), kdb2ClientPriceToFxQuoteBatchedPublisher.consumeQuote(), kdb2ClientPriceToFxDepthBatchPublisher.consumeClientPrice()));
    }

    @Bean
    public MetricsClientPriceReader clientPriceCrossReader(
            @NotNull final KDBClientPriceToFxQuotePublisher kdbClientPriceCrossToFxQuotePublisher,
            @NotNull final KDBClientPriceToFxQuoteBatchPublisher kdbClientPriceCrossToFxQuoteBatchedPublisher,
            @NotNull final KDBClientPriceToFxDepthBatchPublisher kdbClientPriceCrossToFxDepthBatchPublisher) throws IOException {
        return new MetricsClientPriceReader(Arrays.asList(kdbClientPriceCrossToFxQuotePublisher.consumeClientPrice(),
                kdbClientPriceCrossToFxQuoteBatchedPublisher.consumeQuote(),
                kdbClientPriceCrossToFxDepthBatchPublisher.consumeClientPrice()));
    }

    @Bean
    public MetricsClientPriceReader clientPriceCrossReader2(
            @NotNull final KDBClientPriceToFxQuotePublisher kdb2ClientPriceCrossToFxQuotePublisher,
            @NotNull final KDBClientPriceToFxQuoteBatchPublisher kdb2ClientPriceCrossToFxQuoteBatchedPublisher,
            @NotNull final KDBClientPriceToFxDepthBatchPublisher kdb2ClientPriceCrossToFxDepthBatchPublisher) throws IOException {
        return new MetricsClientPriceReader(Arrays.asList(kdb2ClientPriceCrossToFxQuotePublisher.consumeClientPrice(),
                kdb2ClientPriceCrossToFxQuoteBatchedPublisher.consumeQuote(),
                kdb2ClientPriceCrossToFxDepthBatchPublisher.consumeClientPrice()));
    }


    @Bean
    public KDBMarketDataSnapshotToFxQuoteBatchPublisher kdbMarketDataSnapshotToFxQuotePublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.market.tob.prophetfxquote.markets:ANY}") final String markets,
            @Value("${kdb.table.market.tob.prophetfxquote.instruments:ANY}") final String instruments,
            @Value("${kdb.market.tob.synchronous:false}") final boolean synchronous,
            @Value("${kdb.market.tob.enabled:true}") final boolean enabled) {
        return new KDBMarketDataSnapshotToFxQuoteBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, markets, instruments));
    }

    @Bean
    public KDBMarketDataSnapshotToFxQuoteBatchPublisher kdb2MarketDataSnapshotToFxQuotePublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.market.tob.prophetfxquote.markets:ANY}") final String markets,
            @Value("${kdb2.table.market.tob.prophetfxquote.instruments:ANY}") final String instruments,
            @Value("${kdb2.market.tob.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.market.tob.enabled:true}") final boolean enabled) {
        return new KDBMarketDataSnapshotToFxQuoteBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, markets, instruments));
    }

    @Bean
    public KDBHedgeFirewallStatusPublisher kdbHedgeFirewallStatusPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.hedgefirewall:prophethedgefirewall}") final String table,
            @Value("${kdb.hedgefirewallstatus.synchronous:false}") final boolean synchronous,
            @Value("${kdb.hedgefirewallstatus.enabled:true}") final boolean enabled) throws Exception {
        return new KDBHedgeFirewallStatusPublisher(kdbPublisherForTicketPlant, table, synchronous, enabled);
    }

    @Bean
    public KDBClientPriceToFxQuotePublisher kdbClientPriceCrossToFxQuotePublisher(
            @NotNull final KDBPublisher kdbPublisherForTicketPlant,
            @NotNull @Value("${kdb.table.clientprice.tob:prophetfxquote}") final String table,
            @NotNull @Value("#{'${kdb.table.clientprice.tob.prophetfxquote.models:ANY}'.split(',')}") final String[] models,
            @NotNull @Value("#{'${kdb.table.clientprice.tob.prophetfxquote.instruments:ANY}'}") final String instruments,  // default all (LEGACY)
            @Value("${kdb.clientprice.tob.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.tob.enabled:true}") final boolean enabled,
            @Value("${kdb.clientprice.tob.publish.all.throttle.states:true}") final boolean publishAllThrottleStates,
            @Value("${kdb.clientprice.tob.publishOnChimer:false}") final boolean publishOnChimer) throws Exception {
        return new KDBClientPriceToFxQuotePublisher(kdbPublisherForTicketPlant, table, synchronous, enabled, publishAllThrottleStates, publishOnChimer, Market.valueOf(models), StringUtils.isBlank(instruments) ? Collections.emptyList() : Instrument.valueOf(Arrays.asList(instruments.split(","))));
    }

    @Bean
    public KDBClientPriceToFxQuotePublisher kdb2ClientPriceCrossToFxQuotePublisher(
            @NotNull final KDBPublisher kdb2PublisherForTicketPlant,
            @NotNull @Value("${kdb2.table.clientprice.tob:prophetfxquote}") final String table,
            @NotNull @Value("#{'${kdb2.table.clientprice.tob.prophetfxquote.models:ANY}'.split(',')}") final String[] models,
            @NotNull @Value("#{'${kdb2.table.clientprice.tob.prophetfxquote.instruments:ANY}'}") final String instruments,  // default all (LEGACY)
            @Value("${kdb2.clientprice.tob.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.tob.enabled:true}") final boolean enabled,
            @Value("${kdb2.clientprice.tob.publish.all.throttle.states:true}") final boolean publishAllThrottleStates,
            @Value("${kdb2.clientprice.tob.publishOnChimer:false}") final boolean publishOnChimer) throws Exception {
        return new KDBClientPriceToFxQuotePublisher(kdb2PublisherForTicketPlant, table, synchronous, enabled, publishAllThrottleStates, publishOnChimer, Market.valueOf(models), StringUtils.isBlank(instruments) ? Collections.emptyList() : Instrument.valueOf(Arrays.asList(instruments.split(","))));
    }

    @Bean
    public KDBClientPriceToFxQuoteBatchPublisher kdbClientPriceCrossToFxQuoteBatchedPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.clientprice.tob.batched.prophetfxquote.models:ANY}") final String models,
            @Value("${kdb.table.clientprice.tob.batched.prophetfxquote.instruments:ANY}") final String instruments,
            @Value("${kdb.clientprice.tob.batched.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.tob.batched.enabled:false}") final boolean enabled,
            @Value("${kdb.clientprice.tob.enabled:true}") final boolean nonBatchedEnabled) {
        if (nonBatchedEnabled) {
            LOGGER.warn("Both the non-batched and batched client price publishers are enabled - ensure you know what you are doing and that data doesn't overlap.");
        }
        return new KDBClientPriceToFxQuoteBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public KDBClientPriceToFxQuoteBatchPublisher kdb2ClientPriceCrossToFxQuoteBatchedPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.clientprice.tob.batched.prophetfxquote.models:ANY}") final String models,
            @Value("${kdb2.table.clientprice.tob.batched.prophetfxquote.instruments:ANY}") final String instruments,
            @Value("${kdb2.clientprice.tob.batched.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.tob.batched.enabled:false}") final boolean enabled) {
        return new KDBClientPriceToFxQuoteBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments));
    }

    @Bean
    public KDBClientPriceToFxDepthBatchPublisher kdbClientPriceCrossToFxDepthBatchPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.clientprice.prophetfxdepth.models:WSP_A}") final String models,
            @Value("${kdb.table.clientprice.prophetfxdepth.instruments:ANY}") final String instruments,
            @Value("${kdb.clientprice.depth.synchronous:false}") final boolean synchronous,
            @Value("${kdb.clientprice.depth.enabled:true}") final boolean enabled) throws Exception {
        return new KDBClientPriceToFxDepthBatchPublisher(kdbPublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments), false);
    }

    @Bean
    public KDBClientPriceToFxDepthBatchPublisher kdb2ClientPriceCrossToFxDepthBatchPublisher(
            final KDBPublisher kdb2PublisherForTicketPlant,
            @Value("${kdb2.table.clientprice.prophetfxdepth.models:WSP_A}") final String models,
            @Value("${kdb2.table.clientprice.prophetfxdepth.instruments:ANY}") final String instruments,
            @Value("${kdb2.clientprice.depth.synchronous:false}") final boolean synchronous,
            @Value("${kdb2.clientprice.depth.enabled:true}") final boolean enabled) throws Exception {
        return new KDBClientPriceToFxDepthBatchPublisher(kdb2PublisherForTicketPlant, synchronous, new InstrumentAndMarketEnablementFilter(enabled, models, instruments), false);
    }


    @Bean
    public KDBRiskPathPublisher kdbRiskPathPublisher(
            final KDBPublisher kdbPublisherForTicketPlant,
            @Value("${kdb.table.riskpath:prophetriskpath}") final String table,
            @Value("${kdb.riskpath.synchronous:false}") final boolean synchronous,
            @Value("${kdb.riskpath.enabled:false}") final boolean enabled) throws Exception {
        return new KDBRiskPathPublisher(kdbPublisherForTicketPlant, table, synchronous, enabled);
    }

    // Reads truncated market book from chronicle.pricer.out, used for TOB data processing only.
    @Bean // todo: make into specific aggbook and market data
    public MarketDataReader filteredMarketDataReader(@NotNull final KDBMarketDataSnapshotToFxQuoteBatchPublisher kdbMarketDataSnapshotToFxQuotePublisher) {
        final Consumer<FilteredMarketDataSnapshot> pubConsumer = kdbMarketDataSnapshotToFxQuotePublisher.consumeQuote();
        return new MarketDataReader(NotifierDefault.asList(x -> {
            if (x instanceof FilteredMarketDataSnapshot) {
                pubConsumer.accept((FilteredMarketDataSnapshot) x);
            }
        }));
    }

    @Bean
    public MarketDataReader filteredMarketDataReader2(@NotNull final KDBMarketDataSnapshotToFxQuoteBatchPublisher kdb2MarketDataSnapshotToFxQuotePublisher) {
        final Consumer<FilteredMarketDataSnapshot> pubConsumer = kdb2MarketDataSnapshotToFxQuotePublisher.consumeQuote();
        return new MarketDataReader(NotifierDefault.asList(x -> {
            if (x instanceof FilteredMarketDataSnapshot) {
                pubConsumer.accept((FilteredMarketDataSnapshot) x);
            }
        }));
    }

    // Builds market book from chronicle.in to populate kdb market depth
    @Bean
    public Consumer<FilteredMarketDataSnapshot> marketDepthSink(final KDBClientPriceToFxDepthBatchPublisher kdbMarketDataSnapshotToFxDepthBatchPublisher) {
        return new NotifierDefault(kdbMarketDataSnapshotToFxDepthBatchPublisher.consumeFilterableMidRate());
    }

    @Bean
    public Consumer<FilteredMarketDataSnapshot> marketDepthSink2(final KDBClientPriceToFxDepthBatchPublisher kdb2MarketDataSnapshotToFxDepthBatchPublisher) {
        return new NotifierDefault(kdb2MarketDataSnapshotToFxDepthBatchPublisher.consumeFilterableMidRate());
    }

    // JMX publishers
    @Bean
    public ChimeConsumerMBean chimeConsumerMBean() {
        return new ChimeConsumerMBean();
    }

    @Bean
    public GenericReporter<Currency, Position, String> positionsReporter() {
        return new GenericReporter<>(Position::getCcy, new GenericReporter.ValueGetterToString<>());
    }

    @Bean
    public GenericReporter<Currency, Position, String> biasPositionsReporter() {
        return new GenericReporter<>(Position::getCcy, new GenericReporter.ValueGetterToString<>());
    }

    @Bean
    public Consumer<Position> positionConsumer(
            final GenericReporter<Currency, Position, String> positionsReporter,
            final GenericReporter<Currency, Position, String> biasPositionsReporter) {
        return position -> {
            if (Portfolio.CLIENTS_NET == position.getPortfolio()) {
                positionsReporter.accept(position);
            } else if (Portfolio.BIAS_OFFSET == position.getPortfolio()) {
                biasPositionsReporter.accept(position);
            }
        };
    }

    @Bean
    public Consumer<FilteredMarketDataSnapshot> aggBookReporter() {
        // TODO: timestamp or how old
        return new GenericReporterTable<>(MarketData::getInstrument, MarketData::getMarket,
                Instrument.class, Market.class, new GenericReporterTable.ValueGetterToString<>());
    }

    @Bean
    public ChronicleReaderGeneric<FilteredMarketDataSnapshot> aggBookMbean(
            Consumer<FilteredMarketDataSnapshot> aggBookReporter) {
        return new ChronicleReaderGeneric<>(FilteredMarketDataSnapshotImpl.forAggBook(), aggBookReporter);
    }

    @Bean
    public Consumer<ClientPrice> clientPriceReporter() {
        return new GenericReporterTable<>(ClientPrice::getInstrument, ClientPrice::getMarket,
                Instrument.class, Market.class, new GenericReporterTable.ValueGetterToString<>());
    }

    @Bean
    public Consumer<ClientPrice> clientPriceIndicativeReporter() {
        return new ClientPriceIndicativeReporter();
    }

    @Bean
    public ChronicleReaderGeneric<ClientPrice> clientPriceMbean(final Consumer<ClientPrice> clientPriceReporter,
                                                                final Consumer<ClientPrice> clientPriceIndicativeReporter) {
        return new ChronicleReaderGeneric<>(new ClientPriceImpl(), clientPriceReporter, clientPriceIndicativeReporter);
    }

    @Bean
    public ChronicleReaderGeneric<WholesaleBookFactors> wholesaleBookFactorsMBean(
            Consumer<WholesaleBookFactors> wholesaleBookFactorsReporter) {
        return new ChronicleReaderGeneric<>(new WholesaleBookFactorsImpl(), wholesaleBookFactorsReporter);
    }

    @Bean
    public Consumer<WholesaleBookFactors> wholesaleBookFactorsReporter() {
        return new GenericReporter<>(wbf -> wbf.getInstrument(), new GenericReporter.ValueGetterToString<>());
    }

    @Bean
    public Consumer<OptimalPosition> optimalPositionReporter() {
        return new GenericReporter<>(op -> op.getInstrument(), new GenericReporter.ValueGetterToString<>());
    }

    @Bean
    public Consumer<HedgeFirewallStatus> hedgeFirewallStatusReporter() {
        return new GenericReporter<>(status -> status.getPortfolio() + "/" + status.getHedgeFirewallType(), entity -> String.format("%s (%s)", entity.getStatus(), entity.getDescription()));
    }

    @Bean
    public ChronicleReaderGeneric<HedgeFirewallStatus> hedgeFirewallStatusMbean(
            Consumer<HedgeFirewallStatus> hedgeFirewallStatusReporter) {
        return new ChronicleReaderGeneric<>(new HedgeFirewallStatusImpl(), hedgeFirewallStatusReporter);
    }

    @Bean
    public Consumer<ValueAtRisk> valueAtRiskReporter() {
        return new GenericReporter<>(valueAtRisk -> "VaR", new GenericReporter.ValueGetterToString<>());
    }

    @Bean
    public ChronicleReaderGeneric<ValueAtRisk> valueAtRiskMbean(Consumer<ValueAtRisk> valueAtRiskReporter) {
        return new ChronicleReaderGeneric<>(new ValueAtRiskImpl(), valueAtRiskReporter);
    }

    @Bean
    public Consumer<ConfigurationData> configurationDataReporter() {
        return new GenericReporter<>(configurationData -> "configurationData", new GenericReporter.ValueGetterToString<>());
    }

    @Bean
    public ChronicleReaderGeneric<ConfigurationData> configurationDataMbean(
            Consumer<ConfigurationData> configurationDataReporter) {
        return new ChronicleReaderGeneric<>(new ConfigurationDataDefault(), configurationDataReporter);
    }

    @Bean
    public ReporterByEventId reporterByEventId(
            @Value("#{'${chronicle.paths:./chronicle.in,./chronicle.out,./chronicle.hedger.out,./chronicle.star.out}'.split(',')}") final String[] chroniclePaths) {

        return new ReporterByEventId(chroniclePaths);
    }

    @Bean
    public Consumer<ForwardPoint> forwardPointReporter() {
        return new GenericReporter<>(forwardPoint -> forwardPoint.getInstrument(), new GenericReporter.ValueGetterToString<>());
    }

    // TODO: something to show config errors?

    @Bean
    public EsperRunner esperRunner() {
        return new EsperRunner(ChronicleType.INDEXED);
    }

    @Bean
    @Profile("!ACCEPTANCE_TEST") // this clashes when multiple config in same jvms.
    public ConfigHttpServer configHttpServer() throws IOException {
        final ConfigHttpServer configHttpServer = new ConfigHttpServer(envPort + configDocOffsetPort);
        configHttpServer.start();
        return configHttpServer;
    }

    // JMX hedger status viewer
    @Bean
    public HedgerStatusViewer hedgerStatusViewer() {
        return new HedgerStatusViewer();
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> oneSecondReader(final Consumer<OneSecond> oneSecondConsumer) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, oneSecondConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> oneSecondReader2(final Consumer<OneSecond> oneSecondConsumer2) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, oneSecondConsumer2);
    }

    @Bean
    public Consumer<OneSecond> kdbPublishersRateChimer(
            @Value("${kdbfxquote.minimumRateSec:60}") final int minimumRateSec,
            final KDBClientPriceToFxQuotePublisher kdbClientPriceToFxQuotePublisher,
            @Qualifier("kdbBufferedPublishersEventConsumerForPublishing") final Consumer kdbBufferedPublishersEventConsumerForPublishing) {
        // ^^  kdbBufferedPublishersEventConsumerForPublishing are not chimed on one second if backtesting and hence must be chimed here to flush.
        return new RateChimer(minimumRateSec, new NotifierDefault<>(kdbClientPriceToFxQuotePublisher.consumerOfChime(), kdbBufferedPublishersEventConsumerForPublishing));
    }

    @Bean
    public Consumer<OneSecond> kdb2PublishersRateChimer(
            @Value("${kdbfxquote2.minimumRateSec:60}") final int minimumRateSec,
            final KDBClientPriceToFxQuotePublisher kdb2ClientPriceToFxQuotePublisher,
            @Qualifier("kdb2BufferedPublishersEventConsumerForPublishing") final Consumer kdb2BufferedPublishersEventConsumerForPublishing) {
        // ^^  kdbBufferedPublishersEventConsumerForPublishing are not chimed on one second if backtesting and hence must be chimed here to flush.
        return new RateChimer(minimumRateSec, new NotifierDefault<>(kdb2ClientPriceToFxQuotePublisher.consumerOfChime(), kdb2BufferedPublishersEventConsumerForPublishing));
    }

    @Bean
    public Consumer kdbBufferedPublishersEventConsumerForPublishing(
            final KDBClientPriceToFxQuoteBatchPublisher kdbClientPriceToFxQuoteBatchedPublisher,
            final KDBClientPriceToFxQuoteBatchPublisher kdbClientPriceCrossToFxQuoteBatchedPublisher,
            final KDBWholesaleBookFactorsBatchPublisher kdbWholesaleBookFactorsPublisher,
            final KDBClientPriceToFxDepthBatchPublisher kdbClientPriceToFxDepthBatchPublisher,
            final KDBClientPriceToFxDepthBatchPublisher kdbClientPriceCrossToFxDepthBatchPublisher,
            final KDBClientPriceToFxDepthBatchPublisher kdbMarketDataSnapshotToFxDepthBatchPublisher,
            final KDBMarketDataSnapshotToFxQuoteBatchPublisher kdbMarketDataSnapshotToFxQuotePublisher,
            final KDBSignalsBatchPublisher kdbSignalsBatchPublisher) {
        return new NotifierDefault(kdbClientPriceToFxQuoteBatchedPublisher.consumerOfEvent(),
                kdbClientPriceCrossToFxQuoteBatchedPublisher.consumerOfEvent(),
                kdbWholesaleBookFactorsPublisher.consumerOfEvent(),
                kdbClientPriceToFxDepthBatchPublisher.consumerOfEvent(),
                kdbClientPriceCrossToFxDepthBatchPublisher.consumerOfEvent(),
                kdbMarketDataSnapshotToFxDepthBatchPublisher.consumerOfEvent(),
                kdbMarketDataSnapshotToFxQuotePublisher.consumerOfEvent(),
                kdbSignalsBatchPublisher.consumerOfEvent());
    }

    @Bean
    public Consumer kdb2BufferedPublishersEventConsumerForPublishing(
            final KDBClientPriceToFxQuoteBatchPublisher kdb2ClientPriceToFxQuoteBatchedPublisher,
            final KDBClientPriceToFxQuoteBatchPublisher kdb2ClientPriceCrossToFxQuoteBatchedPublisher,
            final KDBWholesaleBookFactorsBatchPublisher kdb2WholesaleBookFactorsPublisher,
            final KDBClientPriceToFxDepthBatchPublisher kdb2ClientPriceToFxDepthBatchPublisher,
            final KDBClientPriceToFxDepthBatchPublisher kdb2ClientPriceCrossToFxDepthBatchPublisher,
            final KDBClientPriceToFxDepthBatchPublisher kdb2MarketDataSnapshotToFxDepthBatchPublisher,
            final KDBMarketDataSnapshotToFxQuoteBatchPublisher kdb2MarketDataSnapshotToFxQuotePublisher,
            final KDBSignalsBatchPublisher kdb2SignalsBatchPublisher) {
        return new NotifierDefault(kdb2ClientPriceToFxQuoteBatchedPublisher.consumerOfEvent(),
                kdb2ClientPriceCrossToFxQuoteBatchedPublisher.consumerOfEvent(),
                kdb2WholesaleBookFactorsPublisher.consumerOfEvent(),
                kdb2ClientPriceToFxDepthBatchPublisher.consumerOfEvent(),
                kdb2ClientPriceCrossToFxDepthBatchPublisher.consumerOfEvent(),
                kdb2MarketDataSnapshotToFxDepthBatchPublisher.consumerOfEvent(),
                kdb2MarketDataSnapshotToFxQuotePublisher.consumerOfEvent(),
                kdb2SignalsBatchPublisher.consumerOfEvent());
    }

    @Bean
    public Consumer<OneSecond> oneSecondConsumer(
            @Value("${backtest.enabled:false}") final boolean isBackTestEnabled,
            @Qualifier("kdbPublishersRateChimer") final Consumer<OneSecond> kdbPublishersRateChimer,
            @Qualifier("kdbBufferedPublishersEventConsumerForPublishing") final Consumer kdbBufferedPublishersEventConsumerForPublishing) {

        // TODO: fix this - doesn't make sense to publish with inception TS of OneSecond

        if (isBackTestEnabled) {
            // maximise batching by less frequent publishing (omit kdbBufferedPublishersEventConsumerForPublishing).
            return new NotifierDefault(kdbPublishersRateChimer);
        } else {
            return new NotifierDefault(kdbPublishersRateChimer, kdbBufferedPublishersEventConsumerForPublishing
            );
        }
    }

    @Bean
    public Consumer<OneSecond> oneSecondConsumer2(
            @Value("${backtest.enabled:false}") final boolean isBackTestEnabled,
            @Qualifier("kdb2PublishersRateChimer") final Consumer<OneSecond> kdb2PublishersRateChimer,
            @Qualifier("kdb2BufferedPublishersEventConsumerForPublishing") final Consumer kdb2BufferedPublishersEventConsumerForPublishing) {

        if (isBackTestEnabled) {
            // maximise batching by less frequent publishing (omit kdb2BufferedPublishersEventConsumerForPublishing).
            return new NotifierDefault(kdb2PublishersRateChimer);
        } else {
            return new NotifierDefault(kdb2PublishersRateChimer, kdb2BufferedPublishersEventConsumerForPublishing
            );
        }
    }
}
