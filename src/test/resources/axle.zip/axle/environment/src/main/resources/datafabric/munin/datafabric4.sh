#!/bin/bash
# -*- sh -*-
source ~/axle/environment/shell/axle.rc &> /dev/null

: << =cut

=head1 NAME

datafabric4 - Plugin to monitor the Datafabric

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=datafabric
 #%# capabilities=autoconf

=cut

HOME_DATACENTRE=${datafabric.node}
HOME_DATACENTRE_SHORT=`echo $HOME_DATACENTRE | awk -F. '{ print $(NF-1); }'`

if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Datafabric 4 -' $HOME_DATACENTRE '- Operation Frequency for Trading Region (number of operations per second)'
    echo 'graph_category datafabric'
    echo 'graph_scale no'
    echo 'df4_1.label Agg Book'
    echo 'df4_1.draw AREA'
    echo 'df4_2.label Algo Status'
    echo 'df4_2.draw STACK'
    echo 'df4_3.label Deals'
    echo 'df4_3.draw STACK'
    echo 'df4_4.label Execution Order'
    echo 'df4_4.draw STACK'
    echo 'df4_5.label Position'
    echo 'df4_5.draw STACK'
    echo 'df4_6.label Position Config'
    echo 'df4_6.draw STACK'
    echo 'df4_7.label Trading Order'
    echo 'df4_7.draw STACK'
    exit 0
fi

function emptyRecord() {
  echo "df4_1.value U"
  echo "df4_2.value U"
  echo "df4_3.value U"
  echo "df4_4.value U"
  echo "df4_5.value U"
  echo "df4_6.value U"
  echo "df4_7.value U"
}

GEMFIRE_HOME=~/gemfire
LOGS=~/axle/datafabric/logs
if [ -f /etc/redhat-release ] ; then
    DATEPATH=date
else
    DATEPATH=/opt/sfw/bin/date
fi

# Munin plugins are executed every 5 minutes (production setting as of 2015-06-02)
# In case this changes, be sure to adjust the extract reuse and the stat sweep windows below (in all fabric plugins)

LATEST_DAT=`ls -ltr $LOGS/ | grep .dat | grep "$HOME_DATACENTRE.statistics-" | tr -s ' ' | tail -1 | awk -F' ' '{ print $(NF); }'`
LATEST_DAT_FILE=$LOGS/$LATEST_DAT
# Reuse stat extract if it was created within the last 1.5 minutes - this number is based on below:
#  - the plugin is executed every 5 minutes (dictated by the master)
#  - it takes around 3 minutes to produce the file (in the lab)
#  - deduct a further half minute to not to overlap with the next schedule
STATS_FILE="`find -L $LOGS -cmin -1.5 -type f -name "${HOME_DATACENTRE}.statreport-*.txt" | sort | tail -1`"

if [ "$LATEST_DAT_FILE" == "" ] && [ "$STATS_FILE" == "" ]; then
  emptyRecord
  exit 0
fi

# Refresh the cache - this is a very resource intensive operation
if [ "$STATS_FILE" == "" ]; then
  TIME_STAMP=`$DATEPATH -u '+%Y-%m-%d_%H-%M-00'`
  STATS_FILE=$LOGS/$HOME_DATACENTRE.statreport-$TIME_STAMP.txt
  # use a 5 minute period up until the start of the present minute
  TIME_FROM=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC' --date '-5 min'`
  TIME_UNTIL=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC'`
  DF_STAT_EXTRACT_CMD="${GEMFIRE_HOME}/bin/gemfire stats -starttime=\"${TIME_FROM}\" -endtime=\"${TIME_UNTIL}\" -archive=\"${LATEST_DAT_FILE}\" -persec"

  $DF_STAT_EXTRACT_CMD > "$STATS_FILE"
fi

# If there are no data, bail out honouring semantics
if [ ! -s "$STATS_FILE" ]; then
  emptyRecord
  exit 0
fi

egrep "(Partitioned Region|createsCompleted|putsCompleted|destroysCompleted|getsCompleted|containsKeyCompleted|putAllsCompleted|containsValueForKeyCompleted|createTime|putTime|containsKeyTime|putAllsTime|containsValueForKeyTime)" $STATS_FILE | awk -F' ' '
BEGIN {
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:createsCompleted:average"] = "df4_1_1";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putsCompleted:average"] = "df4_1_2";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:destroysCompleted:average"] = "df4_1_3";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:getsCompleted:average"] = "df4_1_4";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsKeyCompleted:average"] = "df4_1_5";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putAllsCompleted:average"] = "df4_1_6";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsValueForKeyCompleted:average"] = "df4_1_7";

  lookingfor["Partitioned Region /axle_trading_Deals Statistics:createsCompleted:average"] = "df4_3_1";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putsCompleted:average"] = "df4_3_2";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:destroysCompleted:average"] = "df4_3_3";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:getsCompleted:average"] = "df4_3_4";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsKeyCompleted:average"] = "df4_3_5";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putAllsCompleted:average"] = "df4_3_6";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsValueForKeyCompleted:average"] = "df4_3_7";

  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:createsCompleted:average"] = "df4_4_1";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putsCompleted:average"] = "df4_4_2";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:destroysCompleted:average"] = "df4_4_3";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:getsCompleted:average"] = "df4_4_4";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsKeyCompleted:average"] = "df4_4_5";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putAllsCompleted:average"] = "df4_4_6";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsValueForKeyCompleted:average"] = "df4_4_7";

  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:createsCompleted:average"] = "df4_7_1";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putsCompleted:average"] = "df4_7_2";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:destroysCompleted:average"] = "df4_7_3";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:getsCompleted:average"] = "df4_7_4";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsKeyCompleted:average"] = "df4_7_5";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putAllsCompleted:average"] = "df4_7_6";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsValueForKeyCompleted:average"] = "df4_7_7";
}
/^[a-zA-Z]/ {
  section  = substr($0,1,index($0,",")-1);
}
/^  / {
  statistic = $1;
  for (i=2; i<=NF; i++) {
    fieldandvalue = $i;
    equals = index(fieldandvalue,"=");
    if (equals > 0) {
      fieldname = substr(fieldandvalue,1,equals-1);
      value = substr(fieldandvalue,equals+1);
      outputname = lookingfor[section ":" statistic ":" fieldname];
      if (outputname != "") {
        values[outputname] = value;
      }
    }
  }
}
END {
  print "df4_1.value " values["df4_1_1"] + values["df4_1_2"] + values["df4_1_3"] + values["df4_1_4"] + values["df4_1_5"] + values["df4_1_6"] + values["df4_1_7"];
  print "df4_2.value " values["df4_2_1"] + values["df4_2_2"] + values["df4_2_3"] + values["df4_2_4"] + values["df4_2_5"] + values["df4_2_6"] + values["df4_2_7"];
  print "df4_3.value " values["df4_3_1"] + values["df4_3_2"] + values["df4_3_3"] + values["df4_3_4"] + values["df4_3_5"] + values["df4_3_6"] + values["df4_3_7"];
  print "df4_4.value " values["df4_4_1"] + values["df4_4_2"] + values["df4_4_3"] + values["df4_4_4"] + values["df4_4_5"] + values["df4_4_6"] + values["df4_4_7"];
  print "df4_5.value " values["df4_5_1"] + values["df4_5_2"] + values["df4_5_3"] + values["df4_5_4"] + values["df4_5_5"] + values["df4_5_6"] + values["df4_5_7"];
  print "df4_6.value " values["df4_6_1"] + values["df4_6_2"] + values["df4_6_3"] + values["df4_6_4"] + values["df4_6_5"] + values["df4_6_6"] + values["df4_6_7"];
  print "df4_7.value " values["df4_7_1"] + values["df4_7_2"] + values["df4_7_3"] + values["df4_7_4"] + values["df4_7_5"] + values["df4_7_6"] + values["df4_7_7"];
}
'
