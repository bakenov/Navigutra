package com.anz.axle.lg.adapter.apama.config.venue;

import java.util.Objects;

import com.anz.axle.lg.adapter.apama.transport.ConnectionConfig;
import com.anz.markets.efx.ngaro.api.Venue;

public final class DefaultConnectionConfig implements ConnectionConfig {
    private final Venue venue;
    private final String host;
    private final int port;
    private final String channelName;
    private final int connectionPollingInterval;

    public DefaultConnectionConfig(final Venue venue,
                                   final String host,
                                   final int port,
                                   final int connectionPollingInterval) {
        this(venue, host, port, "", connectionPollingInterval);
    }
    public DefaultConnectionConfig(final Venue venue,
                                   final String host,
                                   final int port,
                                   final String channelName,
                                   final int connectionPollingInterval) {
        this.venue = Objects.requireNonNull(venue);
        this.host = Objects.requireNonNull(host);
        this.port = port;
        this.channelName = Objects.requireNonNull(channelName);
        this.connectionPollingInterval = connectionPollingInterval;
    }

    public Venue venue() {
        return venue;
    }

    public String host() {
        return host;
    }

    public int port() {
        return port;
    }

    @Override
    public String channelName() {
        return channelName;
    }

    public int connectionPollingInterval() {
        return connectionPollingInterval;
    }

    @Override
    public String toString() {
        return "DefaultConnectionConfig{" +
                "venue='" + venue + '\'' +
                ", host='" + host + '\'' +
                ", port=" + port +
                ", channelName=" + channelName +
                ", connectionPollingInterval=" + connectionPollingInterval +
                '}';
    }
}
