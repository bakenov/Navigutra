package com.anz.axle.lg.adapter.cnx;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.agrona.concurrent.IdleStrategy;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.CommonConfig;
import com.anz.axle.servicelifecycle.Service;
import com.anz.lg.messaging.event.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.queue.Queue;

@Configuration
@Import(CommonConfig.class)
public class OverrideConfig {

    @Bean
    public Service mainEventLoop(@Qualifier("fixPricingEventLoopStep") final EventLoopStep fixPricingEventLoopStep,
                                 @Qualifier("fixLastMarketTradeEventLoopStep") final EventLoopStep fixLastMarketTradeEventLoopStep,
                                 @Qualifier("fixTradingEventLoopStep") final EventLoopStep fixTradingEventLoopStep,
                                 @Qualifier("backPressureStrategyEventLoopStep") final EventLoopStep backPressureStrategyEventLoopStep,
                                 final EventLoopStep mainLoopMonitoringStep,
                                 final Queue<Runnable> mainEventLoopQueue,
                                 final Connection connection,
                                 final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor,
                                 final IdleStrategy idleStrategy) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return new EventLoopService(
                CommonConfig.MAIN_EVENT_LOOP_NAME,
                10, TimeUnit.SECONDS, idleStrategy,
                fixPricingEventLoopStep,
                fixLastMarketTradeEventLoopStep,
                fixTradingEventLoopStep,
                backPressureStrategyEventLoopStep,
                EventLoopStep.whenFinalisationRequired(() -> mainEventLoopQueue.poller().processNext(runnableProcessor)),
                EventLoopStep.whenFinalisationNotRequired(() -> connection.pollingStrategy().processNext()),
                mainLoopMonitoringStep);
    }

}
