package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface InstrumentConfigMatcher extends Predicate<Object> {

    Matcher<InstrumentConfigMatcher, InstrumentConfig.Body> body();

    static InstrumentConfigMatcher build() {
        return new InstrumentConfigMatcher() {
            private Predicate<InstrumentConfig> predicate = Matchers.isA(InstrumentConfig.class);

            @Override
            public Matcher<InstrumentConfigMatcher, InstrumentConfig.Body> body() {
                return matcher -> andThen(translate(instrumentConfig -> instrumentConfig.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof InstrumentConfig && predicate.test((InstrumentConfig) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private InstrumentConfigMatcher matcher() {
                return this;
            }

            private InstrumentConfigMatcher andThen(final Predicate<? super InstrumentConfig> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<InstrumentConfig.Body, Long> instrumentId() {
        return ComparisonMatcher.create("instrumentId", b -> b.instrumentId);
    }

    static ComparisonMatcher<InstrumentConfig.Body, Integer> pipSizeDivisor() {
        return ComparisonMatcher.create("pipSizeDivisor", b -> b.pipSizeDivisor);
    }

    static ComparisonMatcher<InstrumentConfig.Body, Boolean> enabled() {
        return ComparisonMatcher.create("enabled", b -> b.enabled);
    }
}
