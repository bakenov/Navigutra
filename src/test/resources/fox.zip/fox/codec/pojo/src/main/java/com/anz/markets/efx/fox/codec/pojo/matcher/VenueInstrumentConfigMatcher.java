package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface VenueInstrumentConfigMatcher extends Predicate<Object> {

    Matcher<VenueInstrumentConfigMatcher, VenueInstrumentConfig.Body> body();

    static VenueInstrumentConfigMatcher build() {
        return new VenueInstrumentConfigMatcher() {
            private Predicate<VenueInstrumentConfig> predicate = Matchers.isA(VenueInstrumentConfig.class);

            @Override
            public Matcher<VenueInstrumentConfigMatcher, VenueInstrumentConfig.Body> body() {
                return matcher -> andThen(translate(venueInstrumentConfig -> venueInstrumentConfig.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof VenueInstrumentConfig && predicate.test((VenueInstrumentConfig) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private VenueInstrumentConfigMatcher matcher() {
                return this;
            }

            private VenueInstrumentConfigMatcher andThen(final Predicate<? super VenueInstrumentConfig> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<VenueInstrumentConfig.Body, Venue> venue() {
        return ComparisonMatcher.create("venue", b -> b.venue);
    }

    static ComparisonMatcher<VenueInstrumentConfig.Body, Long> instrumentId() {
        return ComparisonMatcher.create("instrumentId", b -> b.instrumentId);
    }

    static ComparisonMatcher<VenueInstrumentConfig.Body, Boolean> enabled() {
        return ComparisonMatcher.create("enabled", b -> b.enabled);
    }
}
