package com.anz.axle.lg.adapter.apama.event;

import com.apama.event.Event;
import com.apama.event.parser.Field;
import com.apama.event.parser.IntegerFieldType;


public class EbsServiceIdField extends Field<Long> {
    private static final int BOOK_TYPE_PRICE_DEPTH_VIEW = 2;

    public EbsServiceIdField() {
        super("serviceId", IntegerFieldType.TYPE);
    }

    /**
     * Checks whether given ebs message is Depth View (as opposed to Amount View, Spread View, or Full Amount View which are ignored by us)
     */
    public boolean isPriceDepthView(final Event ebsSnapshotOrIncrement) {
        final long mdBookType = ebsSnapshotOrIncrement.getField(this);
        return mdBookType == BOOK_TYPE_PRICE_DEPTH_VIEW;
    }

}
