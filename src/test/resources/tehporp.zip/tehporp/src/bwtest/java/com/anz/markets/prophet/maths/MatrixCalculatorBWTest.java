package com.anz.markets.prophet.maths;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MatrixCalculatorBWTest {
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();

    // reuse static data setup for all tests

    private static final int REPS = 100_000;

    double[][] A = {{1, 2, 3, 4}};
    double[] x = {1, 2, 3, 4};
    double[] y = new double[x.length];

    @BeforeClass
    public static void setup() {
    }

    @Test
    public void testAAA_Warmup() {
        multiply();
        dot();
    }

    @Test
    public void testMultiply() {
        helper.testAllocationNotExceeded(
                () -> multiply(),
                0 // no allocation!
        );
    }

    @Test
    public void testDotProduct() {
        helper.testAllocationNotExceeded(
                () -> dot(),
                0 // no allocation!
        );
    }

    public void multiply() {
        for (int i = 0; i < REPS; i++) {
            MatrixCalculator.multiply(A, x, y);
        }
    }

    public void dot() {
        for (int i = 0; i < REPS; i++) {
            MatrixCalculator.dot(x, x);
        }
    }
}

