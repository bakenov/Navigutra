package com.anz.markets.prophet.annotation;

public @interface GcFriendly {
    String[] value() default "";
}
