package com.anz.markets.efx.fox.acceptance.api;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;

import com.anz.markets.efx.fox.api.domain.DefaultSourceSequencer;
import com.anz.markets.efx.fox.api.domain.SourceSequencer;
import com.anz.markets.efx.fox.venue.config.VenueConfig;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

public class MarketDataFactory {
    private final static BiFunction<Integer, MarketDataEntry, SnapshotFullRefresh.Entry> DEFAULT_ENTRY_FACTORY =
            (id, marketDataEntry) ->
                new SnapshotFullRefresh.Entry(0, marketDataEntry.marketId,
                        marketDataEntry.entryType, marketDataEntry.entryPx, 0,
                        marketDataEntry.entrySize, 0, marketDataEntry.entryFlag,
                        id, 0, 0);

    private final Function<Venue, String> senderCompIdLookup;
    private final BiFunction<Integer, MarketDataEntry, SnapshotFullRefresh.Entry> entryFunction;
    private final SourceSequencer sourceSequencer;
    private VenueConfig venueConfig = VenueConfig.yaml().load(this.getClass().getClassLoader().getResourceAsStream("conf/venue-config-GB.yaml"));


    public MarketDataFactory(final SourceSequencer sourceSequencer,
                             final String venueConfigFile,
                             final BiFunction<Integer, MarketDataEntry, SnapshotFullRefresh.Entry> entryFunction) {
        this.entryFunction = Objects.requireNonNull(entryFunction);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
        this.venueConfig = VenueConfig.yaml().load(this.getClass().getClassLoader().getResourceAsStream(venueConfigFile));
        this.senderCompIdLookup = venue -> venueConfig.getVenues().get(venue).getCompId();
    }

    public MarketDataFactory(final SourceSequencer sourceSequencer) {
        this(sourceSequencer, "conf/venue-config-GB.yaml", DEFAULT_ENTRY_FACTORY);
    }

    public MarketDataFactory() {
        this(new DefaultSourceSequencer(87567), "conf/venue-config-GB.yaml", DEFAULT_ENTRY_FACTORY);
    }


    public static class MarketDataEntry {
        public Venue marketId;
        public EntryType entryType;
        public double entryPx;
        public double entrySize;
        public EnumSet<Flag> entryFlag;

        public MarketDataEntry() {}

        public MarketDataEntry(final Venue marketId,
                               final EntryType entryType,
                               final double entryPx,
                               final double entrySize,
                               final EnumSet<Flag> entryFlag) {
            this.marketId = Objects.requireNonNull(marketId);
            this.entryType = Objects.requireNonNull(entryType);
            this.entryPx = entryPx;
            this.entrySize = entrySize;
            this.entryFlag = entryFlag;
        }
    }

    public Map<Venue, SnapshotFullRefresh> createMarketData(final InstrumentKey instrumentKey,
                                                            final long sendingTimeNanos,
                                                            final LocalDate tradeDate,
                                                            final LocalDate settlDate,
                                                            final EnumSet<Flag> mdFlags,
                                                            MarketDataEntry[] entries) {
        final Map<Venue, List<SnapshotFullRefresh.Entry>> venueEntryMap = new HashMap<>();
        for (int i = 0; i < entries.length; i++) {
            final MarketDataEntry entry = entries[i];
            venueEntryMap.computeIfAbsent(entry.marketId, venue -> new ArrayList<>())
                    .add(entryFunction.apply(i, entry));
        }
        final Map<Venue, SnapshotFullRefresh> venueSnapshots = new HashMap<>();
        venueEntryMap.forEach((venue, snapshotEntries) -> {
            int lastBidPosition = 0;
            int lastOfferPosition = 0;
            for (SnapshotFullRefresh.Entry entry : snapshotEntries) {
                entry.mdEntryPositionNo = (entry.mdEntryType == EntryType.BID) ? ++lastBidPosition : ++lastOfferPosition;
            }
            venueSnapshots.put(venue, PricingMessage.snapshotFullRefresh(
                    new MessageHeader(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                    new SnapshotFullRefresh.Body(senderCompIdLookup.apply(venue), 0, false,
                            sendingTimeNanos, sendingTimeNanos, instrumentKey.instrumentId(), venue, tradeDate,
                            settlDate, settlDate, mdFlags), snapshotEntries.toArray(new SnapshotFullRefresh.Entry[0]), new Hop[0])
            );
        });

        return venueSnapshots;
    }
}
