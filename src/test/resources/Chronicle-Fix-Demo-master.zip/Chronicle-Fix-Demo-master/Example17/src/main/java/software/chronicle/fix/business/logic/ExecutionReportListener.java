package software.chronicle.fix.business.logic;

public interface ExecutionReportListener {
    void onExecutionReport(software.chronicle.generated.code.messages.ExecutionReport executionReport);
}
