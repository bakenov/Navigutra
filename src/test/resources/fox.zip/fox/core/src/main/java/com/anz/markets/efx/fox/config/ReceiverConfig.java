package com.anz.markets.efx.fox.config;

import javax.annotation.PostConstruct;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.LongFunction;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.tools4j.eventsourcing.api.ExecutionQueue;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.eventloop.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.fox.api.domain.SourceSequencer;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.sbe.SbeSorEncoders;
import com.anz.markets.efx.fox.common.pricing.ScheduledPriceRefreshExecutionStep;
import com.anz.markets.efx.fox.receiver.AsyncVenueSubscriber;
import com.anz.markets.efx.fox.receiver.ConfigurationInitialiserBuilder;
import com.anz.markets.efx.fox.receiver.InstrumentConfigLoader;
import com.anz.markets.efx.fox.receiver.MessageHandlerToMessageDecoder;
import com.anz.markets.efx.fox.receiver.FirewallConfigLoader;
import com.anz.markets.efx.fox.receiver.pricing.DrivingInstrumentIdFactory;
import com.anz.markets.efx.fox.receiver.pricing.MultipleInstrumentPricingRefresher;
import com.anz.markets.efx.fox.receiver.pricing.PricingClientPollerAndExecutionQueueForwarder;
import com.anz.markets.efx.fox.receiver.LongConsumerSupplier;
import com.anz.markets.efx.fox.receiver.NewOrderSingleMessageDecoder;
import com.anz.markets.efx.fox.common.pricing.PricingRefresher;
import com.anz.markets.efx.fox.receiver.QueueAppendingMessageDecoder;
import com.anz.markets.efx.fox.receiver.Subscriber;
import com.anz.markets.efx.fox.receiver.TopicSubscriber;
import com.anz.markets.efx.fox.receiver.UserConfigLoader;
import com.anz.markets.efx.fox.receiver.VenueConfigLoader;
import com.anz.markets.efx.fox.receiver.VenueInstrumentConfigLoader;
import com.anz.markets.efx.fox.receiver.VenueSubscriber;
import com.anz.markets.efx.fox.receiver.VenueTradingResponseSubscriber;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.codec.snapshot.state.IdGenerator;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.Queue;

@Configuration
public class ReceiverConfig {
    @Bean
    public Queue<Runnable> receiverRunnableQueue(@Value("${runnable.queue.capacity}") final int runnableQueueCapacity) {
        return new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(runnableQueueCapacity));
    }

    @Bean
    public EventLoopStep receiverRunnableQueueEventLoopStep(final Queue<Runnable> receiverRunnableQueue) {
        final Consumer<? super Runnable> eventProcessor = Runnable::run;
        return EventLoopStep.whenFinalisationRequired(() -> receiverRunnableQueue.poller().processNext(eventProcessor));
    }

    @Bean
    public LongConsumerSupplier receivedTimeConsumerSupplier() {
        return new LongConsumerSupplier();
    }

    @Bean
    public Connection receiverConnection(final Transport transport) {
        return transport.openConnection(() -> {
        });
    }

    private static MutableSbeMessage createSbeMessage(final int messageBufferSize) {
        final UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(messageBufferSize));
        return new SbeMessageForWriting(buffer);
    }

    @Bean
    public SorEncoderSupplier sorEncoderSupplier(@Value("${messaging.sbe.buffer.capacity}") final int sbeMessageBufferCapacity,
                                                 final ExecutionQueue executionQueue,
                                                 final @Value("${fox.direct.command.append.source.id}") int sourceId,
                                                 final PrecisionClock systemPrecisionClock) {
        final MutableSbeMessage sbeMessage = createSbeMessage(sbeMessageBufferCapacity);
        final SorEncoders<SbeMessage> sbeSorEncoders = new SbeSorEncoders(() -> sbeMessage);

        final LongSupplier sorMessageSeqGenerator = new IdGenerator();
        final Consumer<SbeMessage> sbeMessageConsumer = mutableSbeMessage ->
                executionQueue.appender()
                        .accept(sourceId, sorMessageSeqGenerator.getAsLong(), systemPrecisionClock.nanos(),
                                mutableSbeMessage.buffer(), 0, mutableSbeMessage.messageLength());

        return sbeSorEncoders.toSorEncoderSupplier(sbeMessageConsumer);
    }

    @Bean
    public PricingRefresher pricingRefresher(final ExecutionQueue executionQueue,
                                             final PricingClient<MutableSbeMessage> pricingClient,
                                             final SorEncoderSupplier sorEncoderSupplier,
                                             final PrecisionClock systemPrecisionClock,
                                             final @Value("${fox.pricing.snapshot.source.id}") int pricingSnapshotSource,
                                             final @Value("#{${cross.symbol.to.driving.symbols:T(java.util.Collections).emptyMap()}}")  Map<String, List<String>> crossSymbolDrivingSymbols) {
        final SourceSequencer sourceSequencer = SourceSequencer.of(pricingSnapshotSource);
        final PricingRefresher pricingRefresher = new PricingClientPollerAndExecutionQueueForwarder(executionQueue, pricingClient, systemPrecisionClock, sourceSequencer);
        final PricingRefresher pricingRefreshCompleter = (instrumentId, forceSnapshot) -> {
            sorEncoderSupplier.pricingRefreshCompleteEncoder().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                    .instrumentId(instrumentId)
                    .forceSnapshot(forceSnapshot)
                    .messageComplete();
            return true;
        };
        final LongFunction<Long[]> drivingInstrumentIdsFactory = new DrivingInstrumentIdFactory(crossSymbolDrivingSymbols);

        return new MultipleInstrumentPricingRefresher(pricingRefresher, pricingRefreshCompleter, drivingInstrumentIdsFactory);
    }

    @Bean
    public EventLoopStep pricingFeedRequestProcessingStep(@Value("${pricing.feed.queue.size}") final int queueSize,
                                                          final java.util.Queue<InstrumentKey> pricingFeedRequestQueue,
                                                          final PricingRefresher pricingRefresher) {
        return new ScheduledPriceRefreshExecutionStep(pricingFeedRequestQueue, queueSize, pricingRefresher);
    }

    @Bean
    public MessageDecoder<SbeMessage> queueAppendingMessageDecoder(
            final ExecutionQueue executionQueue,
            final PrecisionClock systemPrecisionClock) {

        return new QueueAppendingMessageDecoder(executionQueue, systemPrecisionClock);
    }

    @Bean
    public Runnable configurationIntialiser(final @Value("${reset.all}") boolean resetAll,
                                            final @Value("${firewall.config.class.path}") String firewallConfigFilePath,
                                            final @Value("${venue.config.class.path}") String venueConfigClassPath,
                                            final @Value("${instrument.config.class.path}") String instrumentConfigClassPath,
                                            final @Value("${venue.instrument.config.class.path}") String venueInstrumentConfigClassPath,
                                            final @Value("${user.config.class.path}") String userConfigClassPath,
                                            final SorEncoderSupplier sorEncoderSupplier) {

        return ConfigurationInitialiserBuilder.create(sorEncoderSupplier, resetAll)
                .add(new FirewallConfigLoader(firewallConfigFilePath, sorEncoderSupplier))
                .add(new VenueConfigLoader(venueConfigClassPath, sorEncoderSupplier))
                .add(new InstrumentConfigLoader(instrumentConfigClassPath, sorEncoderSupplier))
                .add(new VenueInstrumentConfigLoader(venueInstrumentConfigClassPath, sorEncoderSupplier))
                .add(new UserConfigLoader(userConfigClassPath, sorEncoderSupplier))
                .build();
    }

    @Bean
    public MessageHandler tradingRequestMessageHandler(final LongConsumerSupplier receivedTimeConsumerSupplier,
                                                       final PricingRefresher pricingRefresher,
                                                       final MessageDecoder<SbeMessage> queueAppendingMessageDecoder) {
        final NewOrderSingleMessageDecoder newOrderSingleMessageDecoder = new NewOrderSingleMessageDecoder(pricingRefresher);
        return new MessageHandlerToMessageDecoder(receivedTimeConsumerSupplier,
                newOrderSingleMessageDecoder.andThen(queueAppendingMessageDecoder)
                .orThen(queueAppendingMessageDecoder));
    }

    @Bean
    public Subscriber tradingRequestSubscriber(final Connection receiverConnection,
                                               final EndPointStatusHandler transportEndPointStatusHandler,
                                               final MessageHandler tradingRequestMessageHandler,
                                               final @Value("${trading.request.topic}") String tradingRequestTopicName) {
        return new TopicSubscriber(receiverConnection,
                transportEndPointStatusHandler,
                tradingRequestMessageHandler,
                tradingRequestTopicName);
    }

    @Bean
    public  MessageHandler queueAppendingMessageHandler(final LongConsumerSupplier receivedTimeConsumerSupplier,
                                                  final MessageDecoder<SbeMessage> queueAppendingMessageDecoder) {
        return new MessageHandlerToMessageDecoder(receivedTimeConsumerSupplier, queueAppendingMessageDecoder);
    }

    @Bean
    public Subscriber loopbackSubscriber(final Connection receiverConnection,
                                         final EndPointStatusHandler transportEndPointStatusHandler,
                                         final MessageHandler queueAppendingMessageHandler,
                                         final @Value("${loopback.topic}") String loopbackTopicName) {
        return new TopicSubscriber(receiverConnection, transportEndPointStatusHandler, queueAppendingMessageHandler, loopbackTopicName);
    }

    @Bean
    public Subscriber configSubscriber(final Connection receiverConnection,
                                         final EndPointStatusHandler transportEndPointStatusHandler,
                                         final MessageHandler queueAppendingMessageHandler,
                                         final @Value("${config.topic}") String configTopic) {
        return new TopicSubscriber(receiverConnection, transportEndPointStatusHandler, queueAppendingMessageHandler, configTopic);
    }

    @Bean
    public Subscriber heartbeatSubscriber(final Connection receiverConnection,
                                       final EndPointStatusHandler transportEndPointStatusHandler,
                                       final MessageHandler queueAppendingMessageHandler,
                                       final @Value("${heartbeat.topic}") String heartbeatTopic) {
        return new TopicSubscriber(receiverConnection, transportEndPointStatusHandler, queueAppendingMessageHandler, heartbeatTopic);
    }

    @Bean
    public VenueSubscriber venueTradingResponseSubscriber(final Connection receiverConnection,
                                                          final EndPointStatusHandler transportEndPointStatusHandler,
                                                          final MessageHandler queueAppendingMessageHandler,
                                                          final @Value("${venue.trading.response.topic.suffix}") String venueTradingResponseTopicSuffix) {
        return new VenueTradingResponseSubscriber(receiverConnection, transportEndPointStatusHandler, queueAppendingMessageHandler, venueTradingResponseTopicSuffix);
    }

    @Bean
    public VenueSubscriber.Async venueSubscriber(final VenueSubscriber venueTradingResponseSubscriber,
                                                 final Queue<Runnable> receiverRunnableQueue) {
        return new AsyncVenueSubscriber(receiverRunnableQueue, venueTradingResponseSubscriber);
    }

    @Bean
    public EventLoopStep receiverTransportStep(final Connection receiverConnection,
                                               final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        return EventLoopStep.whenFinalisationNotRequired(() -> receiverConnection.pollingStrategy().processNext());
    }

    @Bean
    public Service receiverEventLoopService(@Value("${receiver.finalisation.timeout.seconds}") int finalisationTimeoutSeconds,
                                            final EventLoopStep receiverTransportStep,
                                            final EventLoopStep receiverRunnableQueueEventLoopStep,
                                            final Supplier<IdleStrategy> eventSourcingIdleStrategyFactory,
                                            final EventLoopStep pricingFeedRequestProcessingStep) {
        return new EventLoopService("EventReceiver",
                finalisationTimeoutSeconds, TimeUnit.SECONDS, eventSourcingIdleStrategyFactory.get(),
                receiverRunnableQueueEventLoopStep,
                receiverTransportStep,
                EventLoopStep.whenFinalisationNotRequired(pricingFeedRequestProcessingStep));
    }

    @Autowired
    private Subscriber tradingRequestSubscriber;

    @Autowired
    private Subscriber loopbackSubscriber;

    @Autowired
    private Subscriber configSubscriber;

    @Autowired
    private Subscriber heartbeatSubscriber;

    @Autowired
    private Runnable configurationIntialiser;

    @PostConstruct
    public void init() {
        configurationIntialiser.run();
        tradingRequestSubscriber.subscribe();
        loopbackSubscriber.subscribe();
        configSubscriber.subscribe();
        heartbeatSubscriber.subscribe();
    }
}
