package com.anz.axle.lg.adapter.anz;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class AnzMarketDataSubscription implements MarketDataSubscription {
    private static final int DEFAULT_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK = false;
    private static final boolean DEFAULT_FULL_REFRESH = true;
    private final String symbol;
    private final InstrumentKey instrumentKey;

    public AnzMarketDataSubscription(final String symbol) {
        this.symbol = Objects.requireNonNull(symbol);
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), SecurityType.FXSPOT, Tenor.SP);
    }

    public static AnzMarketDataSubscription idSymbol(final String symbol) {
        return new AnzMarketDataSubscription(symbol);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return Venue.ANZD;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public boolean fullRefresh() {
        return DEFAULT_FULL_REFRESH;
    }

    @Override
    public boolean aggregateBook() {
        return DEFAULT_AGGREGATE_BOOK;
    }

    @Override
    public int marketDepth() {
        return DEFAULT_MARKET_DEPTH;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return null;
    }

    @Override
    public String toString() {
        return "AnzMarketDataSubscription{" +
                "id=" + instrumentKey.instrumentId() +
                ", symbol='" + symbol + '\'' +
                ", instrumentKey=" + instrumentKey +
                '}';
    }
}
