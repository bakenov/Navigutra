package com.anz.markets.efx.ngaro.codec;

import java.io.IOException;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.ImmutableAsciiString;
import com.anz.markets.efx.ngaro.core.LongCodec;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link AsciiStringDecoder}
 */
public class AsciiStringDecoderTest {

    @Test(expected = NullPointerException.class)
    public void noNullSupplier() {
        AsciiStringDecoder.forSupplier(null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullAsciiString() {
        AsciiStringDecoder.forAsciiString(null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullString() {
        AsciiStringDecoder.forString(null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullCharSequence() {
        AsciiStringDecoder.forCharSequence(null);
    }

    @Test
    public void decodeEmpty() throws Exception {
        final int len = 3;
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(new FixedLengthAsciiString(len));

        //when
        final String output1 = dec.decodeStringOrNull();

        //then
        assertNull("output1 should be null", output1);

        //when
        final String output2 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output2 should be empty string", "", output2);
    }

    @Test
    public void decodeStringOrNull() throws Exception {
        //given
        final int len = 6;
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final String input3 = "";

        //when
        input.set(input1);
        final String output1 = dec.decodeStringOrNull();

        //then
        assertEquals("output1 should be 123456", "123456", output1);

        //when
        input.set(input2);
        final String output2 = dec.decodeStringOrNull();

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);

        //when
        input.set(input3);
        final String output3 = dec.decodeStringOrNull();

        //then
        assertEquals("output2 should be null", null, output3);
    }

    @Test
    public void decodeStringOrNullViaCache_whenAsciiNotEmpty() throws Exception {
        final int len = 6;
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123456";

        //when
        input.set(input1);
        final String output1 = dec.decodeAndCache(cache);

        //then
        assertEquals("output1 should be equal to input1", input1, output1);
        assertNotSame("output1 should not be the same reference to input1", input1, output1);

        assertTrue(cache.isCached(input1));

        //when
        input.set(input1);
        final String output2 = dec.decodeAndCache(cache);

        //then
        assertSame("output1 should be the same reference to output2", output1, output2);
    }

    @Test
    public void decodeStringOrNullViaCache_whenAsciiEmpty() throws Exception {
        final int len = 6;
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "";

        //when
        input.set(input1);
        final String output1 = dec.decodeAndCache(cache);

        //then
        assertEquals("should be null", null, output1);
    }

    @Test
    public void decodeStringOrNullViaCache_whenAsciiNotSet() throws Exception {
        final int len = 6;
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);

        //when
        final String output1 = dec.decodeAndCache(cache);

        //then
        assertEquals("should be null", null, output1);
    }

    @Test
    public void decodeStringOrEmpty() throws Exception {
        //given
        final int len = 6;
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final String input3 = "";

        //when
        input.set(input1);
        final String output1 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output1 should be 123456", "123456", output1);

        //when
        input.set(input2);
        final String output2 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);

        //when
        input.set(input3);
        final String output3 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output2 should be empty string", "", output3);
    }

    @Test
    public void decodeToAppendable() throws Exception {
        //given
        final int len = 6;
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final StringBuilder output = new StringBuilder();

        //when
        input.set(input1);
        final Appendable a1 = dec.decodeTo(output, len);

        //then
        assertEquals("output should end with 123456", input1, output.toString());
        assertSame("returned appendable should be same as the target", output, a1);

        //when
        input.set(input2);
        final Appendable a2 = dec.decodeTo(output, len);

        //then
        assertEquals("output should end with XYZ", "123456XYZ", output.toString());
        assertSame("returned appendable should be same as the target", output, a2);

        //when
        input.set(input1);
        final Appendable a3 = dec.decodeTo(output, 3);

        //then
        assertEquals("output should end with 123", "123456XYZ123", output.toString());
        assertSame("returned appendable should be same as the target", output, a3);

        //when
        input.clear();
        final Appendable a4 = dec.decodeTo(output, len);

        //then
        assertEquals("output should not have changed", "123456XYZ123", output.toString());
        assertSame("returned appendable should be same as the target", output, a4);
    }

    @Test(expected = RuntimeException.class)
    public void decodeToAppendable_throwsException() throws Exception {
        //given
        final int len = 6;
        final AsciiString input = new ImmutableAsciiString("hello world");
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final Appendable output = new Appendable() {
            @Override
            public Appendable append(final CharSequence csq) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final char c) throws IOException {
                throw new IOException("Test appendable exception");
            }
        };

        //when
        dec.decodeTo(output, len);

        //then: expect exception
    }

    @Test
    public void decodeToByteWriter() throws Exception {
        //given
        final int len = 6;
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final StringBuilder output = new StringBuilder("pqrstuvwxyz");
        int tgtOffset = 0;

        //when
        input.set(input1);
        final int len1 = dec.decodeTo(output, ByteWriter.STRING_BUILDER);

        //then
        assertEquals("output should contain 123456 at " + tgtOffset, "123456vwxyz", output.toString());
        assertEquals("len1 should be " + len, len, len1);

        //when
        tgtOffset = 0;
        input.set(input2);
        final int len2 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, len);

        //then
        assertEquals("output should contain XYZ at " + tgtOffset, "XYZ456vwxyz", output.toString());
        assertEquals("len2 should be 3", 3, len2);

        //when
        tgtOffset = 1;
        input.set(input1);
        final int len3 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, 3);

        //then
        assertEquals("output should contain 123 at " + tgtOffset, "X12356vwxyz", output.toString());
        assertEquals("len3 should be 3", 3, len3);

        //when
        tgtOffset = 0;
        input.clear();
        final int len4 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, len);

        //then
        assertEquals("output should not have changed", "X12356vwxyz", output.toString());
        assertEquals("len4 should be 0", 0, len4);
    }

    @Test
    public void decodeTo_proper_clear() {
        //given
        final int len = 6;
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123";
        final MutableAsciiString output = new FixedLengthAsciiString(len).set("123456");

        //when
        input.set(input1);
        output.clear();

        dec.decodeTo(output, len);

        //then
        assertEquals("output should be 123", "123", output.toString());
    }

    @Test
    public void decodeToNull() throws Exception {
        //given
        final int len = 6;
        final MutableAsciiString input = new FixedLengthAsciiString(len);
        final AsciiStringDecoder dec = AsciiStringDecoder.forAsciiString(input);
        final String input1 = "123456";
        final String input2 = "XYZ";

        //when
        input.set(input1);
        final int len1 = dec.decodeToNull();

        //then
        assertEquals("len1 not as expected", len, input1.length(), len1);

        //when
        input.set(input2);
        final int len2 = dec.decodeToNull();

        //then
        assertEquals("len2 not as expected", input2.length(), len2);

        //when
        input.clear();
        final int len3 = dec.decodeToNull();

        //then
        assertEquals("len3 should be 0", 0, len3);
    }

    @Test
    public void decodeLong() {
        final long value = 56789564;
        final FixedLengthAsciiString asciiString = AsciiString.fixedLength(20);
        LongCodec.encodeSigned(value, asciiString);

        final StringDecoder dec = AsciiStringDecoder.forAsciiString(asciiString);

        assertEquals(dec.decodeLongOrZero(), value);
    }

    @Test
    public void decodeLongFromEmptyAsciiString() {
        final FixedLengthAsciiString asciiString = AsciiString.fixedLength(20);

        final StringDecoder dec = AsciiStringDecoder.forAsciiString(asciiString);

        assertEquals(dec.decodeLongOrZero(), 0);
    }

}