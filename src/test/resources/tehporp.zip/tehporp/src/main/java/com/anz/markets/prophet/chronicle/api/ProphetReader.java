package com.anz.markets.prophet.chronicle.api;

import java.io.Closeable;

/** Primarily a marker class for now **/
public interface ProphetReader extends Runnable, Closeable {
}
