package com.anz.axle.lg.adapter.hsp.chronicle;

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.anz.axle.applicationboot.EnvironmentResolver;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.spring.config.NestedPropertiesFactoryBean;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
public class PropertiesConfig {
    @Bean
    public SourceSequencer sourceSequencer(@Value("${messaging.${venue}.source.id}") final int sourceId) {
        return SourceSequencer.of(sourceId);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer(@Qualifier("applicationProperties") final Properties properties) {
        final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        propertySourcesPlaceholderConfigurer.setProperties(properties);
        return propertySourcesPlaceholderConfigurer;
    }

    @Bean
    NestedPropertiesFactoryBean applicationProperties() throws IOException {
        final NestedPropertiesFactoryBean propertiesFactoryBean = new NestedPropertiesFactoryBean();
        propertiesFactoryBean.setIgnoreResourceNotFound(true);
        propertiesFactoryBean.setEnv(EnvironmentResolver.environment());
        propertiesFactoryBean.setLocations(new String[]{
                "classpath:conf/market-data-request.properties",
                "classpath:conf/messaging-default.properties",
                "classpath:conf/messaging-${env}.properties",
                "classpath:conf/hsp-chronicle-default.properties",
                "classpath:conf/hsp-chronicle-" + System.getProperty("venue", Venue.HSPMD.name()) + "-${env}.properties"
        });
        propertiesFactoryBean.setLoadSystemProperties(true);
        return propertiesFactoryBean;
    }
}
