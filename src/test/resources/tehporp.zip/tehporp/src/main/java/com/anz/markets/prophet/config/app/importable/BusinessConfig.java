package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.persistence.json.JsonConfigLoader;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.net.URL;

@Configuration
public class BusinessConfig {

    // /business.config.json is reference from the root of classpath because prophet/conf is in classpath
    @Bean
    public ConfigurationData configurationData(
            @Value("${business.config.json.file:/business.config.json}") final String jsonFile) throws IOException {
        final URL jsonUrl = this.getClass().getResource(jsonFile);
        GcFriendlyAssert.notNull(jsonUrl, "business.config.json.file is not configured or file cannot be found: %s", jsonFile);
        final ConfigurationDataDefault configurationData = new JsonConfigLoader().load(jsonUrl);
        return configurationData;
    }
}
