package com.anz.markets.efx.fox.firewall.state;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SlidingTimeWindowMeterTest {

    @Test
    void add() {
        final SlidingTimeWindowMeter slidingTimeWindowMeter = new SlidingTimeWindowMeter(3000, TimeUnit.MILLISECONDS);

        assertThat(slidingTimeWindowMeter.get(1000000097_000000L)).isEqualTo(0);
        slidingTimeWindowMeter.add(1000000097_000000L,1);

        assertThat(slidingTimeWindowMeter.get(1000001000_000000L)).isEqualTo(1);
        slidingTimeWindowMeter.add(1000001000_000000L, 2);

        assertThat(slidingTimeWindowMeter.get(1000001100_000000L)).isEqualTo(3);
        slidingTimeWindowMeter.add(1000002100_000000L,3);

        assertThat(slidingTimeWindowMeter.get(1000002100_000000L)).isEqualTo(6);
        slidingTimeWindowMeter.add(10000031000_00000L,4);

        assertThat(slidingTimeWindowMeter.get(1000003100_000000L)).isEqualTo(9);
        //rateMeter.add(4);
    }
}