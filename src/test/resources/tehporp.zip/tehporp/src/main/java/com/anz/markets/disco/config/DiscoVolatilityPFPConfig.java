package com.anz.markets.disco.config;

import com.anz.markets.disco.data.SignalType;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.config.business.domain.tabular.MITRConfigs;
import com.anz.markets.prophet.config.business.domain.tabular.MITRFeaturesConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumMap;

public class DiscoVolatilityPFPConfig {

    private final Logger log = LoggerFactory.getLogger(DiscoVolatilityPFPConfig.class);

    public static final String FEATURE_NAME_PREFIX = "PFP_DISCO_";
    public static final String FEATURE_NAME_TV1 = (FEATURE_NAME_PREFIX + SignalType.TV1.name()).intern();
    public static final String FEATURE_NAME_TV2 = (FEATURE_NAME_PREFIX + SignalType.TV2.name()).intern();
    public static final String FEATURE_NAME_TV3 = (FEATURE_NAME_PREFIX + SignalType.TV3.name()).intern();

    public static final String PARAM_TIME_PERIOD_SECONDS = "timePeriodsSeconds";
    public static final String PARAM_INC_SPREAD = "incSpread";      // Required for TV1 only
    public static final String PARAM_VOL_STEP = "volStep";          // Required for TV1 only
    public static final String PARAM_VOL_START = "volStart";        // Required for TV1 only
    public static final String PARAM_VOL_POWER = "volPower";        // Required for TV1 only

    private final EnumObjTable<Market, TradingTimeZone, EnumMap<Instrument, DiscoVolatilityPFPRowConfig>> configMap = new EnumObjTable(Market.class, TradingTimeZone.class);

    public class DiscoVolatilityPFPRowConfig {
        public int timePeriodSeconds[];
        public double incSpread;
        public double volStep;
        public double volStart;
        public double volPower;
    }

    public DiscoVolatilityPFPConfig(final MITRConfigs priceFormationPipelineConfigs, String featureName) {
        if (!priceFormationPipelineConfigs.hasFeature(featureName)) {
            log.warn("{} will be disabled.  Config table does not exist.", featureName);
            return;
        }
        boolean hasConfig = false;
        for (Market market : Market.VALUES) {
            if (!market.isWildcard()) {
                for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                    final EnumMap<Instrument, DiscoVolatilityPFPRowConfig> instrumentMap = new EnumMap<>(Instrument.class);
                    configMap.put(market, ttz, instrumentMap);
                    for (Instrument instrument : Instrument.VALUES) {
                        if (priceFormationPipelineConfigs.hasFeature(featureName)) {
                            final MITRFeaturesConfig c = priceFormationPipelineConfigs.getConfig(market, instrument, ttz);
                            final String timePeriods = c.getStringParam(featureName, PARAM_TIME_PERIOD_SECONDS).get();
                            if (timePeriods != null && timePeriods.length() > 0) {
                                final String timePeriodsSplit[] = timePeriods.split(",|;|\\|");
                                final DiscoVolatilityPFPRowConfig rowConfig = new DiscoVolatilityPFPRowConfig();
                                rowConfig.timePeriodSeconds = new int[timePeriodsSplit.length];
                                for (int i = 0; i < rowConfig.timePeriodSeconds.length; i++) {
                                    rowConfig.timePeriodSeconds[i] = Integer.parseInt(timePeriodsSplit[i]);
                                }
                                rowConfig.incSpread = c.getDoubleParamOrNaN(featureName, PARAM_INC_SPREAD).get();
                                rowConfig.volStep = c.getDoubleParamOrNaN(featureName, PARAM_VOL_STEP).get();
                                rowConfig.volStart = c.getDoubleParamOrNaN(featureName, PARAM_VOL_START).get();
                                rowConfig.volPower = c.getDoubleParamOrNaN(featureName, PARAM_VOL_POWER).get();
                                instrumentMap.put(instrument, rowConfig);
                                hasConfig = true;
                            }
                        }
                    }
                }
            }
        }
        if (hasConfig) {
            log.info("{} has valid config.", featureName);
        } else {
            log.info("{} is not configured.", featureName);
        }
    }

    public EnumObjTable<Market, TradingTimeZone, EnumMap<Instrument, DiscoVolatilityPFPRowConfig>> getConfig() {
        return configMap;
    }

}
