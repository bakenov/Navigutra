package com.anz.axle.acc.domain;

import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionKey;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditState;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("currencyVenueExclusionKeyBuilder")
public class CurrencyVenueExclusionKeyBuilder implements Builder<CurrencyVenueExclusionKey, CurrentVenueCurrencyCreditState> {
    @Override
    public CurrencyVenueExclusionKey build(CurrentVenueCurrencyCreditState input) throws BuilderException {
        CurrencyVenueExclusionKey key = new CurrencyVenueExclusionKey();
        key.setSymbol(input.getPair().getSymbol());
        key.setVenue(input.getVenue().getAggregatorCode());
        key.setSource("CREDIT_CHECK");
        return key;
    }
}
