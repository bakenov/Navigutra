#!/bin/bash

mvn exec:java

