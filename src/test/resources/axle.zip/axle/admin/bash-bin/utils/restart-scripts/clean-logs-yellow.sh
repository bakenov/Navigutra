#!/bin/bash

# Axle
ssh AxlSv@daxa0XXz "find ~/logs -type f -delete"
ssh AxlSv@daxa0XXz "find ~/logs -type f -delete"

# Proxy broker
ssh AxlSv@daxa0XXz "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
ssh AxlSv@daxa0XXz "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
