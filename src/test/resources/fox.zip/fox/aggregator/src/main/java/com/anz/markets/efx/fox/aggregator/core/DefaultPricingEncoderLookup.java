package com.anz.markets.efx.fox.aggregator.core;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public final class DefaultPricingEncoderLookup implements PricingEncoderLookup {

    private final Map<RequestKey, SnapshotterAccessor> cache = new HashMap<>();
    private final Function<RequestKey, SnapshotterAccessor> snapshotterFactory;

    public DefaultPricingEncoderLookup(final SnapshotterFactory snapshotterFactory) {
        this.snapshotterFactory = snapshotterFactory::create;
    }

    @Override
    public PricingEncoderSupplier lookup(final RequestKey requestKey) {
        return cache.computeIfAbsent(requestKey, snapshotterFactory).pricingEncoderSupplier();
    }

}
