package com.anz.markets.efx.fox.processor.state.usersession;

import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.codec.api.Region;

public class UserSessionKeyFactory implements Function<CharSequence, UserSessionKey> {
    private final Pattern fxtrader = Pattern.compile("FXTrader\\.(.*)\\.(.*)\\.(.*)");
    private final Pattern midHedger = Pattern.compile("PROPHET\\.HEDGER_MID_(.*)_(.*)");
    private final Pattern benchmarkTrader = Pattern.compile("BenchmarkTrader\\.(.*)\\.(.*)\\.(.*)");
    private final Pattern daxleAlgoTrader = Pattern.compile("DaxleAlgoTrader\\.(.*)\\.(.*)\\.(.*)");

    @Override
    public UserSessionKey apply(final CharSequence asciiString) {
        final String sessionId = asciiString.toString();
        final Matcher fxTraderMatcher = fxtrader.matcher(sessionId);
        if (fxTraderMatcher.find()) {
            final String region = fxTraderMatcher.group(1);
            final String userName = fxTraderMatcher.group(2);
            final String portfolio = fxTraderMatcher.group(3);
            return UserSessionKey.of(sessionId, userName, portfolio, Region.valueOf(region));
        }

        final Matcher midHedgerMatcher = midHedger.matcher(sessionId);
        if (midHedgerMatcher.find()) {
            final String userName = userName(midHedgerMatcher.group(1));
            final String region = midHedgerMatcher.group(2);
            return UserSessionKey.of(sessionId, userName, "XEFX", Region.valueOf(region));
        }

        final Matcher benchmarkTraderMatcher = benchmarkTrader.matcher(sessionId);
        if (benchmarkTraderMatcher.find()) {
            final String region = benchmarkTraderMatcher.group(1);
            final String userName = benchmarkTraderMatcher.group(2);
            final String portfolio = benchmarkTraderMatcher.group(3);
            return UserSessionKey.of(sessionId, userName, portfolio, Region.valueOf(region));
        }

        final Matcher algoTraderMatcher = daxleAlgoTrader.matcher(sessionId);
        if (algoTraderMatcher.find()) {
            final String region = algoTraderMatcher.group(1);
            final String userName = algoTraderMatcher.group(2);
            final String portfolio = algoTraderMatcher.group(3);
            return UserSessionKey.of(sessionId, userName, portfolio, Region.valueOf(region));
        }

        return UserSessionKey.UNKNOWN;
    }

    private static String userName(final String midVenue) {
        switch(midVenue) {
            case "FXALL": return "prophet-autotrader-MidHedger";
            default:
                return "prophet-autotrader-MidHedger" + midVenue;
        }
    }
}
