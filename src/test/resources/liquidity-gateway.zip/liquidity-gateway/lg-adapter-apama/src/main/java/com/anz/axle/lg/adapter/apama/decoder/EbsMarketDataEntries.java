package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.MarketDataSnapshotFullRefresh_MDEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static com.anz.axle.lg.adapter.apama.decoder.FixNumericConstants.TAG_QUOTE_CONDITION;
import static com.anz.axle.lg.adapter.apama.decoder.FixNumericConstants.TAG_TRADE_CONDITION;
import static com.anz.axle.lg.adapter.apama.decoder.FixStringConstants.CONDITION_NO_DATA_AVAILABLE;
import static com.anz.axle.lg.adapter.apama.decoder.FixStringConstants.CONDITION_NO_MARKET_ACTIVITY;

public final class EbsMarketDataEntries {

    public static boolean hasNoMarket(final RequestKey requestKey,
                                      final List<? extends Event> mdEntries,
                                      final int startIndex,
                                      final BiPredicate<? super RequestKey, ? super Event> entryAcceptor) {
        for (int i = startIndex; i < mdEntries.size(); i++) {
            final Event mdEntry = mdEntries.get(i);
            if (entryAcceptor.test(requestKey, mdEntry)) {
                if (hasNoMarket(mdEntry)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean hasNoMarket(final Event mdEntry) {
        final Map<Long, String> extraParams = mdEntry.getField(MarketDataSnapshotFullRefresh_MDEntry.FIELD_EXTRA_PARAMS);

        return isNoMarketTagValue(extraParams.getOrDefault(TAG_QUOTE_CONDITION, "")) ||
                isNoMarketTagValue(extraParams.getOrDefault(TAG_TRADE_CONDITION, ""));
    }

    private static boolean isNoMarketTagValue(final String value) {
        final boolean noMarketActivity = value.equals(CONDITION_NO_MARKET_ACTIVITY);
        final boolean noDataAvailable = value.equals(CONDITION_NO_DATA_AVAILABLE);
        return noMarketActivity || noDataAvailable;
    }
}
