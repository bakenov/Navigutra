package software.chronicle.fix;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog.ReadWrite;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.NewOrderSingle;
import software.chronicle.generated.code.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

/**
 * @author Jerry Shea.
 */
public class StartAndSendOrdersToProxy {
    private static Logger LOGGER = LoggerFactory.getLogger(StartAndSendOrdersToProxy.class);

    public static void main(String[] args) throws Exception {
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        addAliases();

        // all sessions are configured in this file
        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");

        // set up TCP
        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port", "host1.port");

        try (final ChronicleFixEngine endpoint = fixEngineCfg.createInstance(1)) {
            FixSessionHandler endpointSession = endpoint.sessions().iterator().next();
            EndpointNotifier endpointNotifier = (EndpointNotifier) endpointSession.messageNotifier();

            try (final ChronicleFixEngine proxyToEndpoint = fixEngineCfg.createInstance(2)) {
                FixSessionHandler proxyToEndpointSession = proxyToEndpoint.sessions().iterator().next();
                ProxyNotifier proxyToEndpointNotifier = (ProxyNotifier) proxyToEndpointSession.messageNotifier();

                try (final ChronicleFixEngine proxy = fixEngineCfg.createInstance(3)) {
                    FixSessionHandler proxySession = proxy.sessions().iterator().next();
                    ProxyNotifier proxyNotifier = (ProxyNotifier) proxySession.messageNotifier();

                    // wire together two proxies for messages in and out
                    proxyToEndpointNotifier.proxySession(proxySession);
                    proxyNotifier.proxySession(proxyToEndpointSession);

                    // wait for connection to be made between proxy and endpoint
                    assert endpointNotifier.loggedIn.await(5, TimeUnit.SECONDS);

                    try (final ChronicleFixEngine generator = fixEngineCfg.createInstance(4)) {
                        FixSessionHandler generatorSession = generator.sessions().iterator().next();
                        GeneratorNotifier generatorNotifier = (GeneratorNotifier) generatorSession.messageNotifier();
                        assert generatorNotifier.loggedIn.await(5, TimeUnit.SECONDS);

                        for (int i = 0; i < 10; i++) {
                            NewOrderSingle newOrderSingle = newOrderSingle(i);
                            LOGGER.info("Sending newOrderSingle {}", newOrderSingle.clOrdID());
                            generatorSession.sendMessage(newOrderSingle);
                            Jvm.pause(1000);
                        }

                        // leave running for ever
                        // TODO: ctrl-c
                        // LockSupport.park();
                        Jvm.pause( 1000 );
                    }
                }
            }
        }
    }

    static void addAliases() {
        ClassAliasPool.CLASS_ALIASES.addAlias(ProxyNotifier.class,
                EndpointNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                LoggingMode.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                ReadWrite.class);
    }

    @NotNull
    private static NewOrderSingle newOrderSingle(int id) {
        final NewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        newOrderSingle.ordType('2');
        newOrderSingle.side('1');
        newOrderSingle.symbol(Bytes.from("LCOM1"));
        newOrderSingle.clOrdID(Bytes.from("clordid_" + id));
        newOrderSingle.handlInst('3');
        newOrderSingle.transactTime(1451902315496L + id);
        newOrderSingle.orderQty(1 + id);
        newOrderSingle.price(200.0);
        newOrderSingle.timeInForce('0');
        newOrderSingle.maturityMonthYear("201106");
        newOrderSingle.securityType("FUT");
        newOrderSingle.idSource("5");
        newOrderSingle.securityID(Bytes.from("LCOM1"));
        newOrderSingle.account(Bytes.from("ABCTEST1"));
        return newOrderSingle;
    }
}

