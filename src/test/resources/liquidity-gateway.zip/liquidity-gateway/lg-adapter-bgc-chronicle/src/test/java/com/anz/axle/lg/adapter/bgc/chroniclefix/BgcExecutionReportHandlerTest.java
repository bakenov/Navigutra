package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultHeaderTrailer;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingEncoderSupplier;
import org.junit.Before;
import org.junit.Test;
import software.chronicle.fix.staticcode.messages.FixMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BgcExecutionReportHandlerTest {

    private static final String SENDER_COMP_ID = "GB:BGCMIDFX";
    private static final String COMP_ID = "GB:lg-bgcc";
    private static final long CURRENT_TIME = 34523453;

    private BgcExecutionReportHandler executionReportHandler;
    private TradingEncoderSupplier encoderSupplier;
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    private final BgcFixToDTOTestDataGenerator dataGenerator = new BgcFixToDTOTestDataGenerator();
    private Consumer<DefaultHeaderTrailer> handlerConsumer;
    private List<com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport> executionReportList;

    @Before
    public void setUp() throws Exception {
        executionReportList = new ArrayList();
        encoderSupplier = new PojoTradingEncoderSupplier(e -> executionReportList.add((com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport)e));
        executionReportHandler = new BgcExecutionReportHandler(
                encoderSupplier,
                precisionClock,
                SENDER_COMP_ID,
                COMP_ID,
                System::currentTimeMillis,
                sourceSequencer);

        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);

        handlerConsumer = s -> {
            if (s instanceof ExecutionReport) executionReportHandler.accept((ExecutionReport) s);
        };
    }

    @Test
    public void bgcFillSequence() {
        // given
        final List<DefaultHeaderTrailer> bgcFillSequence = dataGenerator.bgcFillSequence();

        // when
        bgcFillSequence.forEach(handlerConsumer);

        //then
        assertThat(executionReportList.size(), is(2));

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erNew = executionReportList.get(0);
        final ExecutionReport bgcErNew = (ExecutionReport)bgcFillSequence.get(1);
        assertExecutionReport(erNew, bgcErNew, OrderStatus.NEW, ExecType.NEW);

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erFill = executionReportList.get(1);
        final ExecutionReport bgcErCalculated = (ExecutionReport)bgcFillSequence.get(3);
        assertExecutionReport(erFill, bgcErCalculated, OrderStatus.FILLED, ExecType.TRADE);

        assertThat(erFill.parties.size(), is(3));
        assertThat(erFill.parties.get(0).partyRole, is(PartyRole.CLIENT_ID));
        assertThat(erFill.parties.get(0).partyId, is("UBZK"));
        assertThat(erFill.parties.get(1).partyRole, is(PartyRole.BUYER));
        assertThat(erFill.parties.get(1).partyId, is("ANZM"));
        assertThat(erFill.parties.get(2).partyRole, is(PartyRole.CONTRA_FIRM));
        assertThat(erFill.parties.get(2).partyId, is("UBZK"));
    }

    @Test
    public void bgcCancelSequence() {
        // given
        final List<DefaultHeaderTrailer> bgcCancelSequence = dataGenerator.bgcCancelSequence();

        // when
        bgcCancelSequence.forEach(handlerConsumer);

        //then
        assertThat(executionReportList.size(), is(2));

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erNew = executionReportList.get(0);
        final ExecutionReport bgcErNew = (ExecutionReport)bgcCancelSequence.get(1);
        assertExecutionReport(erNew, bgcErNew, OrderStatus.NEW, ExecType.NEW);

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erCancel = executionReportList.get(1);
        final ExecutionReport bgcErCalculated = (ExecutionReport)bgcCancelSequence.get(3);
        assertExecutionReport(erCancel, bgcErCalculated, OrderStatus.CANCELED, ExecType.CANCELED);
        assertThat("Cancelled. leavesQty should be 0", erCancel.body.leavesQty, is(0.0));
    }

    @Test
    public void bgcCancelRequestPendingCancelCancelSequence() {
        // given
        final List<DefaultHeaderTrailer> bgcPendingCancelCancelSequence = dataGenerator.bgcCancelRequestPendingCancelCancelSequence();

        // when
        bgcPendingCancelCancelSequence.forEach(handlerConsumer);

        //then
        assertThat(executionReportList.size(), is(3));

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erNew = executionReportList.get(0);
        final ExecutionReport bgcErNew = (ExecutionReport)bgcPendingCancelCancelSequence.get(1);
        assertExecutionReport(erNew, bgcErNew, OrderStatus.NEW, ExecType.NEW);

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erPendingCancel = executionReportList.get(1);
        final ExecutionReport bgcErPendingCancel = (ExecutionReport)bgcPendingCancelCancelSequence.get(3);
        assertExecutionReport(erPendingCancel, bgcErPendingCancel, OrderStatus.PENDING_CANCEL, ExecType.PENDING_CANCEL);

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erCancel = executionReportList.get(2);
        final ExecutionReport bgcErCalculated = (ExecutionReport)bgcPendingCancelCancelSequence.get(4);
        assertExecutionReport(erCancel, bgcErCalculated, OrderStatus.CANCELED, ExecType.CANCELED);
        assertThat("Cancelled. leavesQty should be 0", erCancel.body.leavesQty, is(0.0));
    }

    @Test
    public void bgcRejectSequence() {

        // given
        final List<DefaultHeaderTrailer> bgcRejectSequence = dataGenerator.bgcRejectSequence();

        // when
        bgcRejectSequence.forEach(handlerConsumer);

        //then
        assertThat(executionReportList.size(), is(1));

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport erReject = executionReportList.get(0);
        final ExecutionReport bgcErReject = (ExecutionReport)bgcRejectSequence.get(1);
        assertExecutionReport(erReject, bgcErReject, OrderStatus.REJECTED, ExecType.REJECTED);
        assertThat("Reject leavesQty should be 0", erReject.body.leavesQty, is(0.0));
    }

    private void assertExecutionReport(final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport er, final ExecutionReport bgcEr, final OrderStatus orderStatus, final ExecType execType) {
        assertThat("ordStatus", er.body.ordStatus, is(orderStatus));
        assertThat("execID", er.body.execId, is(bgcEr.execID()));
        assertThat("execType", er.body.execType, is(execType));
        assertThat("ordType", er.body.ordType, is(OrderType.LIMIT));
        assertThat("lastPx", er.body.lastPx, is(unsetToZero(bgcEr.lastPx())));
        assertThat("lastQty", er.body.lastQty, is(unsetToZero(bgcEr.lastQty())));
        assertThat("cumQty", er.body.cumQty, is(unsetToZero(bgcEr.cumQty())));
        assertThat("leavesQty", er.body.leavesQty, is(unsetToZero(bgcEr.leavesQty())));
        assertThat("transactTime", er.body.transactTime, is(bgcEr.transactTime()));
    }

    private double unsetToZero(final double value) {
        return value == FixMessage.UNSET_DOUBLE || Double.isNaN(value) ? 0.0 : value;
    }
}