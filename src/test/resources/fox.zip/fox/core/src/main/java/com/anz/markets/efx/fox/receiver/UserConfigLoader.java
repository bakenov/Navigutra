package com.anz.markets.efx.fox.receiver;

import java.io.InputStream;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.user.config.UserConfig;

public class UserConfigLoader implements Runnable {
    private final UserConfig userConfig;
    private final SorEncoderSupplier encoderSupplier;

    public UserConfigLoader(final String fileName, final SorEncoderSupplier encoderSupplier) {
        final InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(Objects.requireNonNull(fileName));
        this.userConfig = UserConfig.yaml().load(inputStream);
        this.encoderSupplier = Objects.requireNonNull(encoderSupplier);
    }

    @Override
    public void run() {
        userConfig.getUsers().forEach((userEntry) -> {
            encoderSupplier.userConfig().messageStart(0,0)
                    .userGroups().addAll(userEntry.getUserGroups())
                    .userName().encode(userEntry.getUserName())
                    .location().encode(userEntry.getLocation())
                    .messageComplete();
        });
    }
}
