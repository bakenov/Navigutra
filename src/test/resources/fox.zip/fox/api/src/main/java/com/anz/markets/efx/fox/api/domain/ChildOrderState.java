package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;

public interface ChildOrderState {
    interface NotInitialisedOrderState {
    }

    interface WaitingOrderState {
        void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder);
        void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus);
    }

    interface WorkingOrderState {
        void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus);
    }

    interface DeadOrderState {
    }

    interface PendingCancelOrderState {
        void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus);
    }

    interface UnknownOrderState {
    }
}
