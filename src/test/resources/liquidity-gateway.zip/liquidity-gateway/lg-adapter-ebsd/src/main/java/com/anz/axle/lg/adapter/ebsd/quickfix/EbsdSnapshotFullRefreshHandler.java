package com.anz.axle.lg.adapter.ebsd.quickfix;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.MDEntryPx;
import quickfix.field.MDEntrySize;
import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MsgSeqNum;
import quickfix.field.NoMDEntries;
import quickfix.field.SendingTime;
import quickfix.field.Symbol;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.FixSide;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

import static com.anz.axle.lg.adapter.quickfix.FixFields.entryIdToCacheInt;

public class EbsdSnapshotFullRefreshHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsdSnapshotFullRefreshHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public EbsdSnapshotFullRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                          final PricingEncoderLookup pricingEncoderLookup,
                                          final PrecisionClock precisionClock,
                                          final SubscriptionManager subscriptionManager,
                                          final String senderCompId,
                                          final String compId,
                                          final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender,
                                          final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_SNAPSHOT;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("MarketDataSnapshotFullRefresh received: {}", message);
        if (message.getInt(NoMDEntries.FIELD) > 0) {
            final int mdRequestId = message.getInt(MDReqID.FIELD);
            final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
            final long messageId = sequenceNumber; //FIXME prepend with uniquely generated session id
            final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
            final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());
            final String fixSymbol = message.getString(Symbol.FIELD);
            final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);
            subscription.validateSymbol(fixSymbol);
            final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
            final List<Group> groups = FixPriceGroup.getPriceGroupsAndHandleEmptyBookCase(message);

            final SnapshotFullRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
            flagsAppender.accept(encoder.mdFlags());

            final SnapshotFullRefreshEncoder.Body mdEntries = encoder
                    .possResend(false)
                    .marketId(requestKey.market())
                    .instrumentId(requestKey.instrumentKey().instrumentId())
                    .senderCompId().encode(compId)
                    .messageId(messageId)
                    .sendingTime(sendingTimeNanos)
                    .referenceSpotDate().encodeNull()
                    .tradeDate().encodeNull()
                    .settlDate().encodeNull();

            Hops.Encoder<MessageEncoder.Trailer> hops;
            if (groups != null) {
                hops = encodeEntries(sendingTimeNanos, requestKey, groups, mdEntries, subscription.stringToIntCache());
            } else {
                hops = mdEntries.entriesEmpty();
            }

            hops
                .hopsStart(2)
                .next()
                .hopCompId().encode(senderCompId)
                .hopMessageId(sequenceNumber)
                .hopSendingTime(sendingTimeNanos)
                .next()
                .hopCompId().encode(compId)
                .hopMessageId(messageId)
                .hopReceivingTime(receivingTimeNanos)
                .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
                .messageComplete();
        }
    }

    private Hops.Encoder<MessageEncoder.Trailer> encodeEntries(final long sendingTimeNanos, final RequestKey requestKey, final List<Group> groups, final SnapshotFullRefreshEncoder.Body mdEntries, final StringToIntCache stringToIntCache) throws FieldNotFound {
        final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = mdEntries.entriesStart(groups.size());
        for (Group priceEntryGroup : groups) {
            final char mdEntryType = priceEntryGroup.getChar(MDEntryType.FIELD);
            final EntryType side = FixSide.from(mdEntryType);
            final int mdEntryId = entryIdToCacheInt(stringToIntCache, priceEntryGroup);
            final double mdEntryPx = priceEntryGroup.getDouble(MDEntryPx.FIELD);
            final double mdEntrySize = priceEntryGroup.getDouble(MDEntrySize.FIELD);
            // mdEntryOriginator is not used now, but could be used later: final String mdEntryOriginator = priceEntryGroup.getString(MDEntryOriginator.FIELD);
            mdEntries_Next.next()
                    .transactTime(sendingTimeNanos)
                    .mdMkt(requestKey.market())
                    .mdEntryType(side)
                    .mdEntrySize(mdEntrySize)
                    .mdEntryPx(mdEntryPx)
                    .mdEntryId(mdEntryId)
                    .quoteEntryId(0);
        }
        return mdEntries_Next.entriesComplete();
    }
}
