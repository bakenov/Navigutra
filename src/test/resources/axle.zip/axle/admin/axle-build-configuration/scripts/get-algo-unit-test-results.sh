#!/bin/bash
ssh AxlSv@daxa003 "cat ~/axle/fxagg-core/logs/log-MsUnit.log"
