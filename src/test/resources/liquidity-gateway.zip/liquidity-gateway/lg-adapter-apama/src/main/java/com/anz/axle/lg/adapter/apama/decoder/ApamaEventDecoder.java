package com.anz.axle.lg.adapter.apama.decoder;

import com.apama.event.Event;

public interface ApamaEventDecoder {
    void decode(Event event);
}
