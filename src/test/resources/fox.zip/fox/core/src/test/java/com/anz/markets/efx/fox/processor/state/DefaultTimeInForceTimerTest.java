package com.anz.markets.efx.fox.processor.state;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class DefaultTimeInForceTimerTest {
    @Mock
    private TimerScheduler timerScheduler;
    @Mock
    private TimeInForceTimerConfig timeInForceTimerConfig;
    @Mock
    private TimerScheduler.ExpiryHandler expiryHandler;

    private DefaultTimeInForceTimer childOrderTimer;

    @BeforeEach
    void setUp() {
        childOrderTimer = new DefaultTimeInForceTimer(timerScheduler, timeInForceTimerConfig, expiryHandler);
        when(expiryHandler.timerGroup()).thenReturn(TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD);
    }

    @Test
    void schedule_when_initialised_for_time_in_force() {
        //given
        final TimeInForce inForce = TimeInForce.IOC;
        final long timout = 3400;

        when(timeInForceTimerConfig.millis(TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD, inForce)).thenReturn(timout);
        childOrderTimer.reset(inForce);

        //when
        childOrderTimer.schedule();

        //then
        verify(timerScheduler).schedule(timout, expiryHandler);
    }

    @Test
    void cancel() {
        //given
        final TimeInForce inForce = TimeInForce.IOC;
        final long timout = 3400;
        final long expectedTimerId = 323432;

        when(timeInForceTimerConfig.millis(TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD, inForce)).thenReturn(timout);
        when(timerScheduler.schedule(timout, expiryHandler)).thenReturn(expectedTimerId);
        childOrderTimer.reset(inForce);
        childOrderTimer.schedule();

        //when
        childOrderTimer.cancel();

        //then
        verify(timerScheduler).schedule(timout, expiryHandler);
        verify(timerScheduler).cancel(expectedTimerId);
    }

    @Test
    void reset_should_cancel_current_timer_and_reset_the_timeout() {
        //given
        final TimeInForce inForce = TimeInForce.IOC;
        final long timout = 3400;
        final long expectedTimerId = 323432;

        when(timeInForceTimerConfig.millis(TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD, inForce)).thenReturn(timout);
        when(timerScheduler.schedule(timout, expiryHandler)).thenReturn(expectedTimerId);
        childOrderTimer.reset(inForce);
        childOrderTimer.schedule();

        //when
        childOrderTimer.reset(inForce);

        //then
        verify(timerScheduler).schedule(timout, expiryHandler);
        verify(timerScheduler).cancel(expectedTimerId);

        verify(timeInForceTimerConfig, times(2)).millis(TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD, inForce);
    }
}