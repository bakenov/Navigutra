package com.anz.axle.lg.adapter.ebs.acceptance;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.ebs.EbsNewOrderSingleHandler;
import com.anz.axle.lg.adapter.ebs.TradingSessionRepository;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.SettlType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import net.openhft.chronicle.core.Jvm;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.axle.lg.adapter.chroniclefix.FixSide.fixSide;
import static com.anz.markets.efx.trading.codec.api.ExecType.CANCELED;
import static com.anz.markets.efx.trading.codec.api.ExecType.NEW;
import static com.anz.markets.efx.trading.codec.api.ExecType.TRADE;

@Ignore("Ignored for TeamCity tests")
public class EbsUatIntegrationTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsUatIntegrationTest.class);
    private static final char BUY = com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.BUY;
    private static final char SELL = com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.SELL;

    public static final String GB_LG_EBS = "GB:lg-ebsh";
    public static final String GB_LG_ACC = "GB:lg-acc";
    @Rule
    public final TestName testName = new TestName();
    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private PriceListener priceListener;
    private FixMessageSender fixMessageSender;
    private TradingSessionRepository tradingSessionRepository;

    private Venue venue;
    private String senderCompId;
    private String targetCompId;
    private String userName;
    private String password;
    private String host;
    private String port;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        if (testName.getMethodName().startsWith("EBSHEDGE_")) {
            venue = Venue.EBSHEDGE;
            senderCompId = "ANZ_PINK_GB_EBSHEDGE";
            targetCompId = "ICAP_Ai_Server";
            userName = "AN1";
            password = "AN16550976311";
            host = "10.54.189.22";
            port = "4320";
        } else {
            venue = Venue.EBS;
            senderCompId = "ANZ_PINK_GB_EBS";
            targetCompId = "ICAP_Ai_Server";
            userName = "AX2";
            password = "TT87TT873";
            host = "10.54.180.217";
            port = "4300";
            System.setProperty("ebs.fix.user.request.AllowFixingInfo", "Y");
        }

//        final String path = "target/ebs/"+System.currentTimeMillis();
        final String path = "target/ebs";
        final String fixFilePath = path + "/log/";
        final String fixStorePath = path + "/store/";
        final String passwordFile = path +"/"+venue.name()+"-passwords.properties";
        System.out.println("PASSWORD_FILE="+new File(passwordFile).getAbsolutePath());
        System.setProperty("ebs.fix.user.password.file", new File(passwordFile).getAbsolutePath());

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" +venue.name().toLowerCase()+
                                ",venue:" + venue.name() +
                                ",appOptions:--reset" +
                                "," + "ebs.fix.socket.use.ssl:N" +
                                "," + "ebs.fix.log.destination:STDOUT" +
                                "," + "ebs.fix.file.log.path:" + fixFilePath +
                                "," + "ebs.fix.file.store.path:" + fixStorePath +
                                "," + "ebs.fix.log_all:true" +
                                "," + "ebs.fix.reconnectInterval:1" +
                                "," + "ebs.fix.sendercompid:" +senderCompId+
                                "," + "ebs.fix.targetcompid:" +targetCompId+
                                "," + "ebs.fix.user.request.username:" +userName+
                                "," + "ebs.fix.user.request.password:" +password+
                                "," + "ebs.fix.host:"+host+
                                "," + "ebs.fix.port:"+port
                ));

        application = new Application("lg-ebs-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        tradingSessionRepository = application.getApplicationContext().getBean("tradingSessionRepository", TradingSessionRepository.class);
        fixMessageSender = application.getApplicationContext().getBean("ebsMessageSender", FixMessageSender.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        priceListener = new PriceListener(acceptanceContext.pricingMessageQueue());
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void EBS_Send_ORDER_AndReceive_ER() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build().body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS));

        Jvm.pause(10000);
        final PriceEntry entry = priceListener.awaitAnyPrice(matcher, 60);
        System.out.println(entry);
        System.out.println("==============================================================");

        final NewOrderSingle newOrderSingle = newOrderSingle(clOrdId, entry, entry.price, entry.size, OrderType.LIMIT);
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        System.out.println("====Waiting for NEW===========================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, NEW, 1);
        System.out.println("====Waiting for TRADE========================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, TRADE, 5);
    }

    @Test
    public void EBS_Send_ORDER_And_Cancel() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build().body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS));

        Jvm.pause(10000);
        final PriceEntry entry = priceListener.awaitAnyPrice(matcher, 60);
        System.out.println(entry);
        System.out.println("==============================================================");

        final NewOrderSingle newOrderSingle = newOrderSingle(clOrdId, entry, entry.price, entry.size + 2000000, OrderType.LIMIT);
        newOrderSingle.body.timeInForce = com.anz.markets.efx.trading.codec.api.TimeInForce.GTC;

        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        System.out.println("====Cancel Order=============================================");
        Jvm.pause(100);
        sendOrderCancelRequest(newOrderSingle);

        Jvm.pause(5000);
        System.out.println("====Waiting for CANCEL========================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, CANCELED, 1);
    }

    @Test
    public void EBSHEDGE_Send_hedge_ORDER_AndReceive_ER() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build().body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBSHEDGE));

        Jvm.pause(20000);
        final PriceEntry priceEntry = priceListener.awaitAnyPrice(matcher, 60);
        System.out.println(priceEntry);
        priceEntry.price = 0.0;
        System.out.println("==============================================================");

        sendHedgeORDER(clOrdId, priceEntry);

        Jvm.pause(30000);
    }

    private void sendHedgeORDER(final String clOrdId, final PriceEntry priceEntry) throws Exception {
        final NewOrderSingle newOrderSingle = newOrderSingle(clOrdId, priceEntry, priceEntry.price, priceEntry.size, OrderType.LIMIT);
        newOrderSingle.body.symbol = "EURUSD"; // tradable in UAT
        newOrderSingle.body.side = Side.SELL;
        newOrderSingle.body.orderQty = 1000000;
        newOrderSingle.body.timeInForce = com.anz.markets.efx.trading.codec.api.TimeInForce.GTC;
        newOrderSingle.body.price = 0.0;

        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
    }

    @Test
    public void EBS_Send_FIXING_ORDER_AndReceive_ER() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build().body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS));

        Jvm.pause(5000);
        final PriceEntry priceEntry = priceListener.awaitAnyPrice(matcher, 60);
        System.out.println(priceEntry);
        System.out.println("==============================================================");

        priceEntry.size = 30_000000;
        final NewOrderSingle newOrderSingle_AUDUSD = newOrderSingleFixingOrder(priceEntry, "EURUSD", "WMR_LONDON_1100");
        newOrderSingle_AUDUSD.body.side = Side.BUY;
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle_AUDUSD.toString());
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle_AUDUSD);

        priceEntry.size = 50_000000;
        final NewOrderSingle newOrderSingle_EURUSD = newOrderSingleFixingOrder(priceEntry, "EURUSD", "WMR_LONDON_1200");
        newOrderSingle_EURUSD.body.side = Side.SELL;
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle_EURUSD.toString());
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle_EURUSD);

        while (true) TimeUnit.SECONDS.sleep(10);
    }

    private void sendFixingOrder(final String clOrdId_old, final PriceEntry priceEntry) throws Exception {
        tradingSessionRepository.tradingSessions().stream().filter(s -> s.isOpen()).forEach(session -> {
            final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
            final NewOrderSingle newOrderSingle = newOrderSingle(clOrdId, priceEntry, priceEntry.price, priceEntry.size, OrderType.FIXING_ORDER);
            newOrderSingle.body.price = 0.0;
            newOrderSingle.body.timeInForce = com.anz.markets.efx.trading.codec.api.TimeInForce.GTC;
            newOrderSingle.body.symbol = "EURUSD";
            newOrderSingle.body.orderQty = 1000000;

            System.out.println("====Placing FIXING_ORDER on: " + session);
            newOrderSingle.strategyParameters.add(new StrategyParameter(EbsNewOrderSingleHandler.BENCHMARK_FIX_STRATEGY_NAME, session.tradingSessionTag()));
            System.out.println("====Placing order=============================================");
            System.out.println(newOrderSingle.toString());
            System.out.println("==============================================================");
            acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
        });
    }

    private NewOrderSingle newOrderSingleFixingOrder(final PriceEntry priceEntry, final String symbol, final String sessionTag) throws Exception {

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final NewOrderSingle newOrderSingle = newOrderSingle(clOrdId, priceEntry, priceEntry.price, priceEntry.size, OrderType.FIXING_ORDER);
        newOrderSingle.body.price = 0.0;
        newOrderSingle.body.timeInForce = com.anz.markets.efx.trading.codec.api.TimeInForce.GTC;
        newOrderSingle.body.symbol = symbol;
        newOrderSingle.strategyParameters.add(new StrategyParameter(EbsNewOrderSingleHandler.BENCHMARK_FIX_STRATEGY_NAME, sessionTag));
        return newOrderSingle;
    }

    private OrderCancelRequest sendOrderCancelRequest(final NewOrderSingle newOrderSingle) {
        final OrderCancelRequest cancelRequest = new DefaultOrderCancelRequest();
        cancelRequest.clOrdID(cancelRequest.clOrdID_buffer());
        cancelRequest.clOrdID().append("" + acceptanceContext.tradingMessageIdGenerator().get());
        cancelRequest.origClOrdID(cancelRequest.orderID_buffer());
        cancelRequest.origClOrdID().append(newOrderSingle.body.clOrdId);
        cancelRequest.symbol(SymbolNormaliser.toSymbol7(newOrderSingle.body.symbol));
        cancelRequest.cFICode(FixCFICode.to(newOrderSingle.body.securityType));
        cancelRequest.settlType(SettlType.SPOT);
        cancelRequest.side(fixSide(newOrderSingle.body.side));
        cancelRequest.ordType(OrdType.LIMIT);
        cancelRequest.timeInForce(TimeInForce.GOOD_TILL_CANCEL);
        cancelRequest.transactTime(acceptanceContext.precisionClock().nanos());

        fixMessageSender.accept(cancelRequest);
        return cancelRequest;
    }

    private NewOrderSingle newOrderSingle(final String clOrdId, final PriceEntry entry, final double price, final double size, final OrderType orderType) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.messageId = System.currentTimeMillis();
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.symbol = entry.instrumentKey.symbol();
        newOrderSingle.body.securityType = entry.instrumentKey.securityType();
        newOrderSingle.body.settlType = entry.instrumentKey.tenor();
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.side = entry.side;
        newOrderSingle.body.timeInForce = com.anz.markets.efx.trading.codec.api.TimeInForce.IOC;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private void assertExecutionReport(final PriceEntry priceEntry, final String clOrdId, final OrderType orderType, final ExecType execType, final long sleepBefore) throws Exception {
        TimeUnit.SECONDS.sleep(sleepBefore);

        final ExecutionReportMatcher matcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.marketId().eq(venue.name()))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.symbol().eq(priceEntry.instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.side().eq(priceEntry.side));
        switch (execType) {
            case NEW:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW));
                break;
            case TRADE:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED));
                break;
            case CANCELED:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED));
                break;
        }

        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(matcher)
                .awaitMatchAndGetLast(30, TimeUnit.SECONDS);
    }

    private void assertExecutionReport(final PriceEntry priceEntry, final String clOrdId, final OrderType orderType, final ExecType execType) throws Exception {
        assertExecutionReport(priceEntry, clOrdId, orderType, execType, 0L);
    }

}
