package com.anz.markets.prophet.risk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.status.Context;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.util.Collections;
import java.util.function.Consumer;

import static com.anz.markets.prophet.domain.Currency.AUD;
import static com.anz.markets.prophet.util.AmountUnit.MILLIONS;

@Ignore
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OptimalPositionManagerBWTest {
    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private final Consumer<Positions> consumerOfPositions;
    private final Positions positions;

    public OptimalPositionManagerBWTest() {
        Context.context().region(Region.GB);
        final OptimalPositionManager optimalPositionManager = OptimalPositionManagerTest.createOptimalPositionManager(Collections.emptyList());
        consumerOfPositions = optimalPositionManager.consumerOfPositions();
        positions = MidRateTestHelper.createPositions(AUD, MILLIONS.toDollar(100), 1);
        warmup();
    }

    public void warmup() {
        calculateOptimalPosition(positions);
    }

    @Test
    public void testCalculateVaRForThreePositions() {
        //                AllocationRecorder.addSampler(new Sampler() {
        //                    public void sampleAllocation(int count,
        //                                                 String desc,
        //                                                 Object newObj,
        //                                                 long size) {
        //                        System.out.println("I just allocated the object " + newObj + " of type " + desc + " whose size is " + size);
        //                        if (count != -1) { System.out.println("It's an array of size " + count); }
        //                    }
        //                });
        //        calculateOptimalPosition(positions);
        helper.testAllocationNotExceeded(
                () -> calculateOptimalPosition(positions),
                0 // no allocation!
        );
    }

    public void calculateOptimalPosition(Positions positions) {
        for (int i = 0; i < REPS; i++) {
            consumerOfPositions.accept(positions);
        }
    }
}
