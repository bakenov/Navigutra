package com.anz.markets.efx.ngaro.sbe;

import java.util.function.Supplier;

import org.agrona.DirectBuffer;

/**
 * Provides indexed write access to string bytes. Such methods are for instance found on SBE decoders for variable
 * length strings.
 */
@FunctionalInterface
public interface VariableStringTarget {
    Object putBytes(DirectBuffer source, int sourceOffset, int length);

    static VariableStringTarget lazy(final Supplier<VariableStringTarget> supplier) {
        return Lazy.variableStringTarget(supplier);
    }
}
