package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.domain.Currency;
import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.util.function.Consumer;

public class ProfitAndLossManagerBWTest {

    private static final int REPS = 100_000;

    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private final Consumer<Positions> consumerOfPositions;

    private final Positions position_case1 = MidRateTestHelper.createPositions(Currency.AUD, 1_000_000.0, 0.5);
    private final Positions position_case2 = MidRateTestHelper.createPositions(Currency.AUD, 1_000_000.0, 0.6);
    private final Positions position_case3 = MidRateTestHelper.createPositions(Currency.USD, -500_000.0, 1.0);
    private final Positions position_case4 = MidRateTestHelper.createPositions(Currency.USD, 0L, 1.0);

    public ProfitAndLossManagerBWTest() {
        final ProfitAndLossManager profitAndLossManager = new ProfitAndLossManager(new NoOpConsumer<>());
        consumerOfPositions = profitAndLossManager.consumerOfPositions();
        warmup();
    }

    //    @Test
    //    public void pnlCalculationTest() {
    //        AllocationRecorder.addSampler(new Sampler() {
    //            public void sampleAllocation(int count,
    //                                         String desc,
    //                                         Object newObj,
    //                                         long size) {
    //                System.out.println("I just allocated the object " + newObj + " of type " + desc + " whose size is " + size);
    //                if (count != -1) { System.out.println("It's an array of size " + count); }
    //            }
    //        });
    //        profitAndLossManager.forEach(position_case1);
    //    }


    private void pnlCalculation() {
        consumerOfPositions.accept(position_case1);
        consumerOfPositions.accept(position_case2);
        consumerOfPositions.accept(position_case3);
        consumerOfPositions.accept(position_case4);
    }

    public void warmup() {
        for (int i = 0; i < REPS; i++) {
            pnlCalculation();
        }
    }

    @Test
    public void test_Calculation() {
        helper.testAllocationNotExceeded(
                this::acceptPositionForPnLCalculation,
                0 // no allocation!
        );
    }

    private void acceptPositionForPnLCalculation() {
        for (int i = 0; i < REPS; i++) {
            pnlCalculation();
        }
    }
}
