package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradingSessionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public class EbsTradingSessionStatusHandler implements ChronicleMessageHandler<TradingSessionStatus> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsTradingSessionStatusHandler.class);
    private final TradingSessionRepository tradingSessionRepository;

    public EbsTradingSessionStatusHandler(final TradingSessionRepository tradingSessionRepository) {
        this.tradingSessionRepository = Objects.requireNonNull(tradingSessionRepository);
    }

    @Override
    public void accept(final TradingSessionStatus message) throws IllegalArgumentException {
        LOGGER.info("Received: {}", message);
        tradingSessionRepository.updateStatus(message);
    }
}
