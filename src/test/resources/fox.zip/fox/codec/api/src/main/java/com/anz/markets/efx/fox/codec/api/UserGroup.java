package com.anz.markets.efx.fox.codec.api;

import java.util.function.Consumer;

public enum UserGroup {
    TRADER,
    ADMIN,
    SUPER_ADMIN,
    READ_ONLY;

    private static final UserGroup[] VALUES = values();

    public static final int length() {
        return VALUES.length;
    }

    public static final UserGroup valueByOrdinal(final int ordinal) {
        return VALUES[ordinal];
    }

    public static void forEach(final Consumer<? super UserGroup> consumer) {
        for (final UserGroup value : VALUES) {
            consumer.accept(value);
        }
    }
}
