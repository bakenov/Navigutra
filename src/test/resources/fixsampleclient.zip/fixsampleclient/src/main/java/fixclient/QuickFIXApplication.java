// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.LinkedBlockingQueue;

import quickfix.Application;
import quickfix.ConfigError;
import quickfix.DoNotSend;
import quickfix.FieldConvertError;
import quickfix.FieldNotFound;
import quickfix.FileLogFactory;
import quickfix.FileStoreFactory;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;
import quickfix.Initiator;
import quickfix.Message;
import quickfix.RejectLogon;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;
import quickfix.UnsupportedMessageType;
import quickfix.field.DefaultApplExtID;
import quickfix.field.MsgType;

/**
 * QuickFIXApplication deals with all FIX communication and message
 * transformation. This class provides basic login/logout methods, plus the
 * callbacks which record the incoming messages and can augment the outgoing
 * ones.
 */
public class QuickFIXApplication implements Application
{
    private static final String                QUICKFIX_CONFIG_FILE = "config/quickfix.cfg";

    private final String                       quickfixConfigPath;
    private Initiator                          initiator            = null;
    private final Object                       logonLock            = new Object();
    private SessionID                          sessionID            = null;
    private boolean                            fixLoggedIn          = false;
    private boolean                            fixLoginFailed       = false;

    private final LinkedBlockingQueue<Message> receivedMessageQueue = new LinkedBlockingQueue<Message>();
    private final IMessageFlowListener         messageFlowListener;

    /**
     * 
     * @param quickfixConfigPath
     * @param messageFlowListener
     */
    public QuickFIXApplication(final String quickfixConfigPath,
                               final IMessageFlowListener messageFlowListener)
    {
        this.quickfixConfigPath = quickfixConfigPath;
        this.messageFlowListener = messageFlowListener;
    }

    /**
     * Primary method for connecting to FIX gateway. Performs "branch logon" and
     * stabilizes sequence numbers.
     * 
     * @param senderCompId
     * @param senderLocationId
     * 
     * @return the session ID - used by QuickFIX to identify this FIX (branch)
     *         session.
     * @throws Exception
     */
    public SessionID login(final String senderCompId,
            final String senderLocationId) throws Exception
    {
        final int fixTimeout = FIXConfig.getFIXTimeout();

        final SessionSettings settings = createSession(this.quickfixConfigPath,
                senderCompId,
                senderLocationId,
                "QFA"); // always use the same session qualifier

        final long startTime = System.currentTimeMillis();

        synchronized (this.logonLock)
        {
            this.initiator = new SocketInitiator(this,
                    new FileStoreFactory(settings),
                    settings,
                    new FileLogFactory(settings),
                    new CustomMessageFactory());

            this.messageFlowListener.logStatusText("Logging in to FIX");
            this.initiator.start();

            // Wait until onLogon() sends notification that the FIX logon has
            // been successful (or onLogout sends notification that it has
            // failed).
            while (true)
            {
                final long elapsed = System.currentTimeMillis() - startTime;
                if (this.fixLoggedIn)
                {
                    break;
                }

                if (this.fixLoginFailed)
                {
                    this.fixLoginFailed = false;
                    throw new Exception("Fix login failed");
                }

                if (elapsed >= fixTimeout)
                {
                    throw new Exception("FIX login timed out");
                }

                this.logonLock.wait(1000);
            }
        }

        return this.sessionID;
    }

    /**
     * @param configPath
     * @param senderCompId
     * @param senderLocationId
     * @param sessionQualifier
     * @return Some session settings
     * @throws ConfigError
     * @throws FieldConvertError
     * @throws IOException
     */
    private static SessionSettings createSession(final String configPath,
            final String senderCompId,
            final String senderLocationId,
            final String sessionQualifier) throws ConfigError,
            FieldConvertError,
            IOException
    {
        // Load quickfix settings from file path if supplied, otherwise look for
        // the default file on the class path.
        final InputStream is;
        if (configPath == null) {
            is = ClassLoader.getSystemResourceAsStream(QUICKFIX_CONFIG_FILE);
        } else {
            is = ClassLoader.getSystemResourceAsStream(configPath);
        }
            if (is == null)
            {
                throw new FileNotFoundException(QUICKFIX_CONFIG_FILE
                        + " not found on classpath");
            }
//        }
//        else
//        {
//            is = new FileInputStream(configPath);
//        }

        final SessionSettings sessionSettings = new SessionSettings(is);
        is.close();

        final SessionID sessionID = new SessionID(sessionSettings.getString(SessionSettings.BEGINSTRING),
                senderCompId,
                null,
                senderLocationId,
                sessionSettings.getString(SessionSettings.TARGETCOMPID),
                sessionSettings.getString(SessionSettings.TARGETSUBID),
                null,
                sessionQualifier);

        sessionSettings.setString(sessionID,
                SessionSettings.SENDERCOMPID,
                senderCompId);
        sessionSettings.setString(sessionID,
                SessionSettings.SENDERLOCID,
                senderLocationId);
        sessionSettings.setString(sessionID,
                SessionSettings.SESSION_QUALIFIER,
                sessionQualifier);

        return sessionSettings;
    }

    /**
     * Primary method for disconnecting from FIX gateway.
     */
    public void logout()
    {
        synchronized (this.logonLock)
        {
            if (!this.fixLoggedIn)
            {
                this.messageFlowListener.logStatusText("Warning: Already logged out of FIX");
            }

            this.messageFlowListener.logStatusText("Trying logging out of FIX...");

            if (this.initiator != null)
            {
                // This operation is synchronous - onLogout() is called in
                // this thread before the call to stop() returns.
                this.initiator.stop();
                this.initiator = null;
            }
        }
    }

    /**
     * Accesses the Queue of messages currently received from the FIX
     * 
     * @return A blocking queue containing any received messages.
     */
    public LinkedBlockingQueue<Message> getReceivedMessageQueue()
    {
        return this.receivedMessageQueue;
    }

    /**
     * @see quickfix.Application#fromAdmin(quickfix.Message, quickfix.SessionID)
     */
    public void fromAdmin(final Message message, final SessionID sessionId) throws FieldNotFound,
            IncorrectDataFormat,
            IncorrectTagValue,
            RejectLogon
    {
        // Session Reject messages added to the queue so can be viewed in the
        // client
        final String msgtype = message.getHeader().getString(MsgType.FIELD);
        if (MsgType.REJECT.equals(msgtype))
        {
            this.receivedMessageQueue.add(message);
        }
    }

    /**
     * @see quickfix.Application#fromApp(quickfix.Message, quickfix.SessionID)
     */
    public void fromApp(final Message message, final SessionID sessionId) throws FieldNotFound,
            IncorrectDataFormat,
            IncorrectTagValue,
            UnsupportedMessageType
    {
        // Add message to the received message blocking queue (externally
        // accessible via getReceivedMessageQueue() so the rest of the
        // client app can get at it.
        this.receivedMessageQueue.add(message);
    }

    /**
     * @see quickfix.Application#onCreate(quickfix.SessionID)
     */
    public void onCreate(final SessionID sessionId)
    {
        /* Do nothing */
    }

    /**
     * @see quickfix.Application#onLogon(quickfix.SessionID)
     */
    public void onLogon(final SessionID sessionId)
    {
        this.messageFlowListener.logStatusText("Logged in to FIX");

        synchronized (this.logonLock)
        {
            this.sessionID = sessionId;
            this.fixLoggedIn = true;

            // Notify the login() thread that the logon succeeded
            this.logonLock.notify();
        }
    }

    /**
     * @see quickfix.Application#onLogout(quickfix.SessionID)
     */
    public void onLogout(final SessionID sessionId)
    {
        this.messageFlowListener.logStatusText("Logged out of FIX");

        synchronized (this.logonLock)
        {
            if (!this.fixLoggedIn)
            {
                // A log out was received without ever having successfully
                // logged in - this must be in direct response to a failed
                // login attempt.
                this.fixLoginFailed = true;
            }

            this.fixLoggedIn = false;

            // Notify the login() thread of the logout
            this.logonLock.notify();

        }

    }

    /**
     * Notification of outgoing admin messages. We add 1407 here if required
     * 
     * @see quickfix.Application#toAdmin(quickfix.Message, quickfix.SessionID)
     */
    public void toAdmin(final Message message, final SessionID sessionId)
    {
        // If the defaultApplVerID has not been set as yet, set it!
        try
        {
            if (message.getHeader()
                    .getString(MsgType.FIELD)
                    .equals(MsgType.LOGON)
                    && !message.isSetField(DefaultApplExtID.FIELD))
            {
                message.setInt(DefaultApplExtID.FIELD,
                        QuickFixConfig.getDefaultApplExtID().intValue());
            }
        }
        catch (final FieldNotFound e)
        {
            // No Impl - invalid message!
        }
    }

    /**
     * Notification of outgoing app messages. We ignore these.
     * 
     * @see quickfix.Application#toApp(quickfix.Message, quickfix.SessionID)
     */
    public void toApp(final Message outgoingMsg, final SessionID sessionId) throws DoNotSend
    {
        /* Do Nothing */
    }
}
