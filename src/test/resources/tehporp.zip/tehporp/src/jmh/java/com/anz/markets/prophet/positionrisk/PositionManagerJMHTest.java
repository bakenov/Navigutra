package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.positionrisk.PositionManager.PositionsUpdatePhase;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.syscontrol.TableNotifierDefault;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.util.function.Consumer;

public class PositionManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private TestStubConsumer<Positions> positionBaseChanged = new TestStubConsumer<>();
        private Consumer<Trade> consumerOfTrade;
        private Consumer<MidRate> consumerOfMidRate;

        @Setup
        public void setup() {
            final TableNotifierDefault<PositionsUpdatePhase, Portfolio, Positions> positionsNotifierTable = new TableNotifierDefault<>(PositionsUpdatePhase.class, Portfolio.class);
            positionsNotifierTable.register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, positionBaseChanged);
            final Consumer<Adjustment> adjustmentSink = NoConsumer.instance();

            PositionManager positionManager = new PositionManager(positionsNotifierTable, adjustmentSink);

            consumerOfTrade = positionManager.consumerOfTrade();
            consumerOfMidRate = positionManager.consumerOfMidRate();
        }
    }

    @Benchmark
    public long acceptTrade(@NotNull final Data data) {
        data.consumerOfTrade.accept(PositionManagerTest.TRADE_AUDUSD_BUY);
        return data.positionBaseChanged.getEvents().size();
    }

    @Benchmark
    public long acceptMidRateUSDBase(@NotNull final Data data) {
        data.consumerOfMidRate.accept(PositionManagerTest.MIDRATE_USDCHF);
        return data.positionBaseChanged.getEvents().size();
    }

    @Benchmark
    public long acceptMidRate(@NotNull final Data data) {
        data.consumerOfMidRate.accept(PositionManagerTest.MIDRATE_EURGBP);
        return data.positionBaseChanged.getEvents().size();
    }
}
