#!/bin/bash

echo "Start sync-logs-from-remote-boxes-init ("`date`")"

cd /app/fxdev/hudson/scripts

LOG_DEST=~/axle/logs
if [ ! -d $LOG_DEST ] 
then
	echo "Creating base directory $LOG_DEST..."
	mkdir $LOG_DEST
fi
if [ ! -d $LOG_DEST/daxa009s ] 
then
	echo "Creating directory $LOG_DEST/daxa009s ..."
	mkdir $LOG_DEST/daxa009s
fi

echo "Runing sync-logs-from-remote-boxes.sh..."
./sync-logs-from-remote-boxes.sh > $LOG_DEST/daxa009s/sync-logs-from-remote-boxes.log 2>&1
echo "Done sync-logs-from-remote-boxes"

