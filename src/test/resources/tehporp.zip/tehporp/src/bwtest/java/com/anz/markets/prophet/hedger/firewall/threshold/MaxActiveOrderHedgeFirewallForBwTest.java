package com.anz.markets.prophet.hedger.firewall.threshold;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MaxActiveOrderHedgeFirewallForBwTest extends AbstractMaximumActiveOrderHedgeFirewallForBwJmhTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MaxActiveOrderHedgeFirewallForBwTest.class);

    private static final int REPS = 100_000;
    private static final int THRESHOLD = 0;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    @Test
    public void test_acceptValue() {
        //        AllocationRecorder.addSampler((count, desc, newObj, size) -> {
        //            boolean found = false;
        //            for (StackTraceElement stack : Thread.currentThread().getStackTrace()) {
        //                if (!stack.getClassName().contains(this.getClass().getName()) && stack.getClassName().contains("prophet")) {
        //                    found = true;
        //                    break;
        //                }
        //            }
        //            if (found) {
        //            System.out.println("I just allocated the object " + newObj.toString() + " of type " + desc + " whose size is " + size);
        //            System.out.println(Arrays.toString(Thread.currentThread().getStackTrace()));
        //            if (count != -1) { System.out.println("It's an array of size " + count); }
        //            }
        //        });

        helper.testAllocationNotExceeded(
                this::scenario_acceptValue,
                REPS, REPS,
                THRESHOLD // no allocation!
        );
    }

    private void scenario_acceptValue() {
        this.acceptOrderEvent();
    }
}
