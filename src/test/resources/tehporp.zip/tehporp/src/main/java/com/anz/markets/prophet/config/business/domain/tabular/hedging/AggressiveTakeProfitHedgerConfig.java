package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTakeProfitHedgerConfigImpl;


public interface AggressiveTakeProfitHedgerConfig extends HedgeInstrumentConfig {
    AggressiveTakeProfitHedgerConfig EMPTY = new AggressiveTakeProfitHedgerConfigImpl();

    double getMaximumRiskIncrease();

    double getTriggeringTradeMultiplier();

    double getMinimumTriggerQuantity();

    double getMinimumOrderQuantity();

    double getMinimumPriceImprovementPips();

    long getActivePeriodMS();

    String getCounterparty();

    boolean isLiquidityCheckEnabled();

}

