package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.codec.sbe.InstrumentConfigSbeDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class InstrumentConfigEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(InstrumentConfigEvent.class);

    private final InstrumentRepository instrumentRepository;
    private final InstrumentConfigSbeDecoder instrumentConfigDecoder = new InstrumentConfigSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public InstrumentConfigEvent(final InstrumentRepository instrumentRepository) {
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!instrumentConfigDecoder.wrap(message)) return false;
        logMessage();

        instrumentRepository.apply(instrumentConfigDecoder);
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        instrumentConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying instrument config: {}", stringBuilder);
    }
}
