package com.anz.axle.lg.adapter.dbs.chroniclefix;

import org.junit.Test;

import net.openhft.chronicle.bytes.Bytes;

import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.generators.MessageGenerator;

import static org.junit.Assert.assertEquals;

public class MessageGenerateTest {
    // https://github.com/ChronicleEnterprise/Chronicle-FIX/issues/320
    @Test
    public void doubleGenerate() {
        final MessageGenerator messageGenerator = new MessageGenerator();
        messageGenerator.bytes(Bytes.elasticByteBuffer());
        messageGenerator.price(6.85202);
        final String generated = messageGenerator.bytes().toString().replace((char) 0x01, '|');
        assertEquals("|44=6.85202", generated);
    }
}
