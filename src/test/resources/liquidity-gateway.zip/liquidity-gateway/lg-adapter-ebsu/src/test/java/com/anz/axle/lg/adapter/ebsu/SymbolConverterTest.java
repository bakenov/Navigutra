package com.anz.axle.lg.adapter.ebsu;

import org.junit.Test;
import com.anz.markets.efx.ngaro.api.SecurityType;
import software.chronicle.ebs.itch.generated.preview.messages.datamodel.server.DefaultInstrumentDirectory;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class SymbolConverterTest {

    @Test
    public void test() {
        DefaultInstrumentDirectory instrumentDirectory = new DefaultInstrumentDirectory();
        instrumentDirectory.securityType(software.chronicle.ebs.itch.generated.preview.fields.SecurityType.FX_SPOT);
        instrumentDirectory.description("FXSPOT.AUDCAD(EBSM_CLOB)       ");
        Map<String, String> ebsuSymbolLookup = new HashMap<>();
        assertEquals("AUDCAD", new SymbolConverter(SecurityType.FXSPOT, ebsuSymbolLookup).toSymbol6(instrumentDirectory));
    }

    @Test
    public void testNdf() {
        DefaultInstrumentDirectory instrumentDirectory = new DefaultInstrumentDirectory();
        instrumentDirectory.securityType(software.chronicle.ebs.itch.generated.preview.fields.SecurityType.FX_NDF);
        instrumentDirectory.description("FXNDF.USDTWD.M1(EBSM_CLOB)              ");
        Map<String, String> ebsuSymbolLookup = new HashMap<>();
        assertEquals("USDTWD", new SymbolConverter(SecurityType.FXNDF, ebsuSymbolLookup).toSymbol6(instrumentDirectory));
    }

    @Test
    public void testNdfOnSEF() {
        DefaultInstrumentDirectory instrumentDirectory = new DefaultInstrumentDirectory();
        instrumentDirectory.securityType(software.chronicle.ebs.itch.generated.preview.fields.SecurityType.FX_NDF);
        instrumentDirectory.description("FXNDF.USDBRS.JUN(EBSM_SEF)              ");
        Map<String, String> ebsuSymbolLookup = new HashMap<>();
        assertEquals("USDBRS", new SymbolConverter(SecurityType.FXNDF, ebsuSymbolLookup).toSymbol6(instrumentDirectory));
    }
}