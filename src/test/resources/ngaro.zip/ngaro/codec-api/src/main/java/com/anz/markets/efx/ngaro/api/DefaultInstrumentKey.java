package com.anz.markets.efx.ngaro.api;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

class DefaultInstrumentKey implements InstrumentKey {
    private static final long SETTLMENT_DATE_MASK = 0xFFFF;
    private static final int SETTLMENT_DATE_BITS = 16;

    private static final long TENOR_MASK = 0xFF;
    private static final int TENOR_BITS = 8;

    private static final long SECURITY_TYPE_MASK = 0xF;
    private static final int SECURITY_TYPE_BITS = 4;

    private static final long SYMBOL_CHAR_MASK = 0x3F;
    private static final int SYMBOL_CHAR_BITS = 6;
    private static final int SYMBOL_CHAR_LENGTH = 6;

    private final long instrumentId;
    private final String symbol;
    private final SecurityType securityType;
    private final Tenor tenor;
    private final Optional<LocalDate> settlmentDate;

    public static long encodeInstrumentId(final CharSequence symbol, final SecurityType securityType, final Tenor tenor, final LocalDate settlmentDate) {
        if (symbol.length() != SYMBOL_CHAR_LENGTH) throw new IllegalArgumentException();
        Objects.requireNonNull(securityType);
        Objects.requireNonNull(tenor);

        long packed = 0;
        for (int i = SYMBOL_CHAR_LENGTH - 1; i >= 0 ; i--) {
            final byte symbolByte = fromAscii(symbol.charAt(i));
            packed |=  symbolByte;
            if (i > 0) packed <<= SYMBOL_CHAR_BITS;
        }
        packed <<= SECURITY_TYPE_BITS;
        packed |= securityType.ordinal();

        packed <<= TENOR_BITS;
        packed |= tenor.ordinal();

        packed <<= SETTLMENT_DATE_BITS;
        if (settlmentDate != null) packed |= settlmentDate.toEpochDay();

        return packed;
    }

    public DefaultInstrumentKey(final long instrumentId) {
        this.instrumentId = instrumentId;
        final StringBuilder stringBuilder = new StringBuilder();

        long packed = instrumentId;
        final long settlmentDateEpochDays = (packed & SETTLMENT_DATE_MASK);
        packed >>>= SETTLMENT_DATE_BITS;
        final int tenorOrdinal = (int) (packed & TENOR_MASK);
        packed >>>= TENOR_BITS;
        final int securityTypeOrdinal = (int) (packed & SECURITY_TYPE_MASK);
        packed >>>= SECURITY_TYPE_BITS;
        for (int i = 0; i < SYMBOL_CHAR_LENGTH; i++) {
            final byte symbolByte = (byte) (packed & SYMBOL_CHAR_MASK);
            stringBuilder.append(toAscii(symbolByte));

            packed >>>= SYMBOL_CHAR_BITS;
        }

        this.settlmentDate = (settlmentDateEpochDays > 0) ? Optional.of(LocalDate.ofEpochDay(settlmentDateEpochDays)) : Optional.empty();
        this.tenor = Tenor.valueByOrdinal(tenorOrdinal);
        this.securityType = SecurityType.valueByOrdinal(securityTypeOrdinal);
        this.symbol = stringBuilder.toString();
    }

    private static char toAscii(final byte symbolChar) {
        return (char) (symbolChar + '0');
    }

    private static byte fromAscii(final char symbolChar) {
        final char upperSymbolChar = Character.toUpperCase(symbolChar);
        return (byte) (upperSymbolChar >= '0' && upperSymbolChar <= 'Z' ? upperSymbolChar - '0' : '_' - '0');
    }

    @Override
    public long instrumentId() {
        return instrumentId;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public SecurityType securityType() {
        return securityType;
    }

    @Override
    public Tenor tenor() {
        return tenor;
    }

    @Override
    public Optional<LocalDate> settlementDate() {
        return settlmentDate;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final DefaultInstrumentKey that = (DefaultInstrumentKey) o;

        return instrumentId == that.instrumentId;
    }

    @Override
    public int hashCode() {
        return (int) (instrumentId ^ (instrumentId >>> 32));
    }

    @Override
    public String toString() {
        return "InstrumentKey{" +
                "instrumentId=" + instrumentId +
                ", symbol='" + symbol + '\'' +
                ", securityType=" + securityType +
                ", tenor=" + tenor +
                ", settlmentDate=" + settlmentDate +
                '}';
    }
}
