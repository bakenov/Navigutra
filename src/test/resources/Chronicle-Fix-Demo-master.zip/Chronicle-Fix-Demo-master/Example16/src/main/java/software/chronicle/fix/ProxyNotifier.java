package software.chronicle.fix;

import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.WireIn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Logon;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.concurrent.CountDownLatch;

public class ProxyNotifier implements MessageNotifier, Demarshallable {
    private static Logger LOGGER = LoggerFactory.getLogger(ProxyNotifier.class);
    CountDownLatch loggedIn = new CountDownLatch(1);

    private FixSessionHandler proxySession;

    private ProxyNotifier(WireIn w) {
    }

    void proxySession(FixSessionHandler proxySession) {
        this.proxySession = proxySession;
    }

    @Override
    public MessageGenerator onExecutionReport(ExecutionReport executionReport) {
        proxySession.sendMessage(executionReport);
        return null;
    }

    @Override
    public MessageGenerator onNewOrderSingle(NewOrderSingle newOrderSingle) {
        proxySession.sendMessage(newOrderSingle);
        return null;
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        loggedIn.countDown();
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        LOGGER.error("Reject {}", reject);
    }
}
