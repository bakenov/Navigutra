package com.anz.axle.acc.job;

import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("logAllCurrentCounterpartyCreditUtilisationJobListener")
public class LogAllCurrentCounterpartyCreditUtilisationJobListener implements CurrentCounterpartyCreditUtilisationJobListener {
    private static final Logger LOG = Logger.getLogger(CurrentCounterpartyCreditUtilisationJob.class);
    @Override
    public void listen(CounterpartyCreditUtilisations utilisations) {
        for(CounterpartyCreditUtilisation utilisation : utilisations.findAll()) {
            LOG.info(utilisation.toString());
        }
    }
}
