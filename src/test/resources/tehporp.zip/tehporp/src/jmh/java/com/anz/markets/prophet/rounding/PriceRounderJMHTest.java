package com.anz.markets.prophet.rounding;

import com.anz.markets.prophet.domain.OrderSide;
import org.openjdk.jmh.annotations.Benchmark;

public class PriceRounderJMHTest {

    private static final int PLACES = 6;
    private static final double FROM = 0.123123123;

    @Benchmark
    public double roundDown() {
        return OrderSide.BID.roundPrice(PLACES, FROM);
    }

    @Benchmark
    public double roundUp() {
        return OrderSide.OFFER.roundPrice(PLACES, FROM);
    }
}
