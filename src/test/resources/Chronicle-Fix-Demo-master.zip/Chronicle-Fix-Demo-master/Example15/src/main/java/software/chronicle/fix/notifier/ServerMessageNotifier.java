package software.chronicle.fix.notifier;

import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.generated.code.messages.MessageNotifier;

/**
 * @author Rob Austin.
 */
public class ServerMessageNotifier implements MessageNotifier, Marshallable {
    // todo this is the message notifier for message received
}
