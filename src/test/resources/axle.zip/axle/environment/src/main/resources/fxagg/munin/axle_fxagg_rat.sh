#!/bin/bash
# (c) 2016 ANZ

# Munin plugin monitoring pricing ratios (e.g. conflation)

# NOTE: including scripts need to define the following variables:
#   - TITLE:     the title of the graph
#   - VENUES:    venues to be displayed, e.g. "CNX|EBSD|EBS|RFX"
#   - COLORS:    line color for above venues, same order, e.g. "FFFFFF|000000"

TITLE="Pricing Ratios"
CATEGORY="fxagg::ratio"
VLABEL="% of Incoming Depth Events"
DATA_SIZE="custom 1w, 10s for 4w, 5m for 3m, 30m for 1y"
DATAPOINTS=300  # 1 point per second in 5min window

PIDFILE=/app/axle/logs/fxagg/Correlator-FxAgg.pid
LOGFILE=/app/axle/logs/fxagg/log-PricingStats.log
EPOCHFILE="/var/tmp/`basename $0`.epoch"

source /app/axle/axle/environment/fxagg/munin/axle_epoch.common

run_autoconf() {
    echo yes
}

run_config() {
    SCALE=100   # scale to percentage value
    echo "graph_title $TITLE"
    echo "graph_category $CATEGORY"
    echo "graph_vlabel $VLABEL"
    echo "graph_data_size $DATA_SIZE"
    echo "update_rate 1"
    echo "graph_scale no"
    echo "graph_args --lower-limit 0 --upper-limit 100"

    echo "ratio_Cleansed.label % of error-free depth events: (din-derr)/din"
    echo "ratio_Cleansed.draw LINE2"
    echo "ratio_Cleansed.color 60BD68"   # green
    echo "ratio_Cleansed.cdef ratio_Cleansed,$SCALE,*"
    echo "ratio_Processed.label % of processed depth events: dout/din"
    echo "ratio_Processed.draw LINE2"
    echo "ratio_Processed.color FAA43A"   # orange
    echo "ratio_Processed.cdef ratio_Processed,$SCALE,*"
    echo "ratio_Aggregated.label Aggregated to incoming depth events: agg/din"
    echo "ratio_Aggregated.draw LINE2"
    echo "ratio_Aggregated.color 5DA5DA"   # blue
    echo "ratio_Aggregated.cdef ratio_Aggregated,$SCALE,*"
}

run_fetch_unknown() {
    echo "ratio_Cleansed.value U"
    echo "ratio_Processed.value U"
    echo "ratio_Aggregated.value U"
}

# Example log lines:
# [2016-11-11 02:55:32.721 INFO] RatioDepthCleansed       MAIN    161     1.00
# [2016-11-11 02:55:32.721 INFO] RatioDepthProcessed      MAIN    134     0.83
# [2016-11-11 02:55:32.721 INFO] RatioDepthAggregated     MAIN    132     0.82
run_fetch() {

    # data unknown if there is no PIDFILE or no LOGFILE
    if [ ! -f ${PIDFILE} ] || [ ! -f ${LOGFILE} ] ; then
        run_fetch_unknown
        return
    fi

    # data unknown if process is not running
    PID=$(cat ${PIDFILE})
    if [ ! -d /proc/${PID} ] ; then
        run_fetch_unknown
        return
    fi

    EPOCH_MIN=`get_epoch_last "${EPOCHFILE}"`
    EPOCH_MAX=`date +%s`

    # number of data points for all 3 ratios in 5min window (plus 30 seconds tolerance)
    ALLPOINTS=$((3*(DATAPOINTS + 30)))

    # NOTE: first tail is to speed up grep
    #       second tail is: #ratios x 5min
    tail -15000 $LOGFILE | grep RatioDepth | tail -$ALLPOINTS | awk -v emin=$EPOCH_MIN -v emax=$EPOCH_MAX -v efile=$EPOCHFILE -F'[ \t]' '
    BEGIN {
        elast=emin;
    }
    /RatioDepth/ {
        # $1=[2016-11-03 23:19:00.000 INFO] RatioDepthXXX
        tstr = substr($1, 2, length($1) - 1) " " $2; # date/time substring
        rnam = substr($4, 11, length($4) - 10); # cut off "RatioDepth" prefix
        rval = $7;
        # reformat date string as epoch value
        cmd = "date +%s --date=\"" tstr "\"";
        cmd | getline epoch;
        if (emin <= epoch && epoch <= emax) {
            print "ratio_" rnam ".value " epoch ":" rval;
            elast=(epoch > elast ? epoch : elast);
        }
    }
    END {
        # store last epoch value that we have returned
        system("echo " (elast+1) " > " efile);
    }'
}

run_${1:-fetch}
exit 0