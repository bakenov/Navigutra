package com.anz.markets.efx.fox.firewall.state;

import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToLongFunction;

import com.anz.markets.efx.fox.api.domain.User;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.fox.firewall.api.RuleConfigCommandHandler;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class MetricBasedFirewall implements Firewall {
    private final String name;
    private final MetricBasedRuleMatcher ruleMatcher;
    private final OrderConsumer delegate;
    private final RuleConfigCommandHandler ruleConfigCommandHandler;
    private final Predicate<ExecutionReportDecoder> acceptableExecutionReportsFilter;

    public MetricBasedFirewall(final String firewallName,
                               final Function<FirewallConfigDecoder, Metric> metricFactory,
                               final ToLongFunction<FirewallConfigDecoder> metricKeyFunction,
                               final RuleConfigCommandHandler ruleConfigCommandHandler,
                               final UserRepository userRepository,
                               final OrderConsumer.ErrorHandler errorHandler,
                               final Predicate<ExecutionReportDecoder> acceptableExecutionReportsFilter) {
        this.name = Objects.requireNonNull(firewallName);
        this.ruleConfigCommandHandler = Objects.requireNonNull(ruleConfigCommandHandler);
        this.acceptableExecutionReportsFilter = Objects.requireNonNull(acceptableExecutionReportsFilter);

        this.ruleMatcher = new MetricBasedRuleMatcher(firewallName,
                metricFactory,
                metricKeyFunction,
                username -> {
                    final User user = userRepository.lookup(username);
                    if (user == null) {
                        return "UNKNOWN";
                    }
                    return user.desk();
                });
        this.delegate = new RuleValidatingFirewall(ruleMatcher, errorHandler);
    }

    @Override
    public void onFirewallConfigRuleRequest(final CommandContext commandContext, final FirewallConfigDecoder firewallConfigDecoder) {
        ruleConfigCommandHandler.handleCommand(firewallConfigDecoder, commandContext);
    }

    @Override
    public void applyFirewallConfigRuleResponse(final EventContext eventContext, final FirewallConfigDecoder firewallConfigDecoder) {
        this.ruleMatcher.apply(firewallConfigDecoder, eventContext);
    }

    @Override
    public void applyExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
        if (acceptableExecutionReportsFilter.test(executionReportDecoder)) {
            this.ruleMatcher.apply(executionReportDecoder, eventContext);
        }
    }

    @Override
    public String firewallName() {
        return name;
    }

    @Override
    public boolean accept(final NewOrderSingleDecoder newOrderSingle, final CommandContext commandContext) {
        return delegate.accept(newOrderSingle, commandContext);
    }
}
