package com.anz.markets.prophet.chronicle.legacychronicle;

import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.ChronicleQueueBuilder;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class LegacyChronicleConfig {
    public static Chronicle createChronicle(final String path, final ChronicleType type,
                                            final ReadWrite readOnly) throws IOException {
        ChronicleQueueBuilder chronicleQueueBuilder = createChronicleQueueBuilder(path, type, readOnly);
        return chronicleQueueBuilder.build();
    }

    public static Chronicle source(final String path, final ChronicleType type,
                                   final ReadWrite readOnly, final int port) throws IOException {
        final ChronicleQueueBuilder chronicleQueueBuilder = createChronicleQueueBuilder(path, type, readOnly);
        ChronicleQueueBuilder.ReplicaChronicleQueueBuilder replicaChronicleQueueBuilder;
        if (chronicleQueueBuilder instanceof ChronicleQueueBuilder.IndexedChronicleQueueBuilder) {
            replicaChronicleQueueBuilder = ((ChronicleQueueBuilder.IndexedChronicleQueueBuilder) chronicleQueueBuilder).source();
        } else {
            throw new UnsupportedOperationException();
        }
        replicaChronicleQueueBuilder.bindAddress(port);
        return replicaChronicleQueueBuilder.build();
    }

    public static Chronicle sink(final String host, final int port, final long reconnectIntervalMS,
                                 final Integer minBufferSize, final Integer sendBufferSize, final Integer receiveBufferSize) throws IOException {
        final ChronicleQueueBuilder.ReplicaChronicleQueueBuilder rt = ChronicleQueueBuilder.remoteTailer().
                connectAddress(host, port).
                reconnectionAttempts(Integer.MAX_VALUE).
                reconnectionInterval(reconnectIntervalMS, TimeUnit.MILLISECONDS);
        if (minBufferSize != null) {
            rt.minBufferSize(minBufferSize);
        }
        if (sendBufferSize != null) {
            rt.sendBufferSize(sendBufferSize);
        }
        if (receiveBufferSize != null) {
            rt.receiveBufferSize(receiveBufferSize);
        }
        return rt.build();
    }

    private static ChronicleQueueBuilder createChronicleQueueBuilder(final String path,
                                                                     final ChronicleType type,
                                                                     final ReadWrite readOnly) {
        ChronicleQueueBuilder chronicleQueueBuilder;
        if (type == ChronicleType.INDEXED) {
            chronicleQueueBuilder = ChronicleQueueBuilder.indexed(path);
            if (readOnly.readOnly()) {
                ((ChronicleQueueBuilder.IndexedChronicleQueueBuilder) chronicleQueueBuilder).setReadOnly(readOnly.readOnly());
            }
        } else {
            throw new UnsupportedOperationException();
        }
        return chronicleQueueBuilder;
    }

    public enum ChronicleType {
        INDEXED,
    }

    /**
     * Note that if the chronicle doesn't exist then trying to open it read-only will blow up when it tries to create the chronicle.
     * This is expected behaviour.
     */
    public enum ReadWrite {
        READ_ONLY, READ_WRITE;

        public boolean readOnly() {
            return this == READ_ONLY;
        }
    }
}
