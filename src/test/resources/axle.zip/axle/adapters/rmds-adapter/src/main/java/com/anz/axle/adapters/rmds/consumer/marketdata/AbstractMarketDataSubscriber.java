package com.anz.axle.adapters.rmds.consumer.marketdata;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import com.anz.axle.adapters.rmds.consumer.ItemProvider;
import com.anz.markets.adapters.trep.Item;
import com.anz.markets.adapters.trep.consumer.Subscriber;
import com.reuters.rfa.common.Context;
import com.reuters.rfa.common.DispatchException;
import com.reuters.rfa.common.EventQueue;
import com.reuters.rfa.common.EventSource;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.StandardPrincipalIdentity;
import com.reuters.rfa.common.TokenizedPrincipalIdentity;
import com.reuters.rfa.config.ConfigProvider;
import com.reuters.rfa.session.MarketDataItemSub;
import com.reuters.rfa.session.MarketDataSubscriberInterestSpec;
import com.reuters.rfa.session.Session;

/**
 * This class contains a framework for subscribing to RMDS using the legacy MarketFeed model 
 * @author winstonr
 *
 */
public abstract class AbstractMarketDataSubscriber<T> implements Subscriber<T> {
    private static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AbstractMarketDataSubscriber.class);

    protected String serviceName;
    protected List<String> itemNames;
    protected LinkedList<String> subjectNames;
    
    protected String sessionName;
    protected long dispatchInterval = 1000L;
    protected StandardPrincipalIdentity standardPI;
    protected TokenizedPrincipalIdentity tokenizedPI;
    protected Session session;
    protected EventQueue eventQueue;
    protected com.reuters.rfa.session.MarketDataSubscriber marketDataSubscriber;
    protected Handle mdsClientHandle;
    protected Handle itemHandle;
    protected String user;

    private ConfigProvider configProvider;

    private ItemProvider itemProvider;

    /**
     * The constructor initializes variables using the command line arguments.
     * It also creates the principal identity used to permission market data.
     */
    public AbstractMarketDataSubscriber() {
        if (logger.isDebugEnabled()) {
            Logger logger = Logger.getLogger("com.reuters.rfa");
            logger.setLevel(Level.FINE);
            Handler[] handlers = logger.getHandlers();

            if (handlers.length == 0) {
                Handler handler = new ConsoleHandler();
                handler.setLevel(Level.FINE);
                logger.addHandler(handler);
            }

            for (Handler handler : handlers) {
                handler.setLevel(Level.FINE);
            }
        }
    }

    /**
     * Initializes context, creates the session, creates a client
     * MDSubDemoClient that can handle event callbacks. Also creates the
     * MarketDataSubscriber event source with appropriate
     * MarketDataSubscriberInterestSpec and subscribes to all the items
     * specified in the command line.
     */
    @PostConstruct
    public void init() {
        if (user != null) createPrincipals(user, "0.0.0.0/localhost", "256");

        Context.initialize(configProvider);

        if (tokenizedPI != null) { 
            logger.info("Acquiring session: [" + sessionName + "], credentials: [" +  user + "]");
            session = Session.acquire(sessionName, tokenizedPI);
        }
        else {
            logger.info("Acquiring session: [" + sessionName + "]");
            session = Session.acquire(sessionName);
        }

        if (session == null) {
            logger.error("Could not acquire session.");
            System.exit(1);
        }

        logger.info("Using RFA Version: " + Context.getRFAVersionInfo().getProductVersion());

        // Create an object to receive event callbacks
        MarketDataClient client = new MarketDataClient(this);

        // Create an Event Queue
        eventQueue = EventQueue.create("myEventQueue");

        marketDataSubscriber = (com.reuters.rfa.session.MarketDataSubscriber)session
                .createEventSource(EventSource.MARKET_DATA_SUBSCRIBER, "myMarketDataSubscriber",
                        true, standardPI);

        // Register for service and connection status
        MarketDataSubscriberInterestSpec marketDataSubscriberInterestSpec = new MarketDataSubscriberInterestSpec();
        marketDataSubscriberInterestSpec.setMarketDataSvcInterest(true);
        marketDataSubscriberInterestSpec.setConnectionInterest(true);
        marketDataSubscriberInterestSpec.setEntitlementsInterest(true);
        mdsClientHandle = marketDataSubscriber.registerClient(eventQueue,
                marketDataSubscriberInterestSpec,
                client, null);

        if (itemProvider != null)
            itemNames = itemProvider.getItems();

        for (final String itemName : itemNames) {
            logger.info("Subscribing to " + itemName);
            MarketDataItemSub marketDataItemSub = new MarketDataItemSub();
            marketDataItemSub.setItemName(itemName);
            marketDataItemSub.setServiceName(serviceName);
            marketDataSubscriber.subscribe(eventQueue, marketDataItemSub, client, null);
        }
    }

    /**
     * Dispatch events from the event queue for the duration given by runTime.
     */
    public void run() {
        while (true) {
            try {
                eventQueue.dispatch(dispatchInterval);
            }
            catch (DispatchException de) {
                logger.warn("Caught dispatch exception", de);
                if (!eventQueue.isActive())
                logger.warn("Queue deactivated");
                return;
            }
        }
    }

    /**
     * Cleanup before exit.
     */
    public void cleanup() {
        logger.info("Unsubscribing and unregistering client");
        marketDataSubscriber.unsubscribeAll();
        marketDataSubscriber.unregisterClient(mdsClientHandle);
        marketDataSubscriber.destroy();
        eventQueue.deactivate();
        session.release();
        Context.uninitialize();
        logger.info("Subscriber deactivated");
    }

    public void onUpdate(final Item item) {
        logger.info("[UPDATE]" + item);
    }


    /**
     * Create TokenizedPrincipalIdentity and StandardPrincipalIdentity
     */
    public void createPrincipals(final String user, final String position, final String application) {
        tokenizedPI = new TokenizedPrincipalIdentity();
        String tokenString = user;
        if (!application.isEmpty()) {
            tokenString = tokenString + "+" + application;
            if (!position.isEmpty())
                tokenString = tokenString + "+" + position;
        }
        tokenizedPI.setBuffer(tokenString.getBytes());
        standardPI = new StandardPrincipalIdentity();
        standardPI.setName(user);
        standardPI.setPosition(position);
        standardPI.setAppName(application);
    }

    /**
     * Set the configuration provider
     * @param config
     */
    public void setConfigProvider(ConfigProvider configProvider) {
        this.configProvider = configProvider;
    }

    /**
     * Set the RFA session name
     * @param sessionName
     */
    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

    /** 
     * Set the name of the RMDS session (e.g. AXLE/SPDEE)
     * @param serviceName
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * Set the name of the DACS user for this session
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    public void setItemProvider(ItemProvider itemProvider) {
        this.itemProvider = itemProvider;
    }
}

