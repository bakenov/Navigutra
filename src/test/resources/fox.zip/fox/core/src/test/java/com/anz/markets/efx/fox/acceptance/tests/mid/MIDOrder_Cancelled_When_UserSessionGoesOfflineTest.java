package com.anz.markets.efx.fox.acceptance.tests.mid;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.NewOrderSingleMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRequestMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

@RunWith(Spockito.class)
public class MIDOrder_Cancelled_When_UserSessionGoesOfflineTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MIDOrder_Cancelled_When_UserSessionGoesOfflineTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private MarketDataFactory marketDataFactory = new MarketDataFactory();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("user.session.timeout.millis", "3000");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
        System.getProperties().remove("user.session.timeout.millis");
    }

    @Test
    public void should_fill_partially_and_cancel_mid_order() throws Exception {

        final InstrumentKey instrumentKey = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat venueHeartbeat = sorEndpoint.createHeartbeat();
        venueHeartbeat.body.senderCompId = "GB:lg-fxall";
        sorEndpoint.tradingRequest().add(venueHeartbeat);

        Heartbeat userHeartbeat = sorEndpoint.createHeartbeat();
        userHeartbeat.body.senderCompId = "FXTrader.GB.anufriea.XEFX";

        sorEndpoint.tradingRequest().add(userHeartbeat);

        final HeartbeatMatcher heartbeatMatcher = HeartbeatMatcher.build()
                .header().matches(HeartbeatMatcher.source().gt(0))
                .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                .body().matches(HeartbeatMatcher.senderCompId().eq(userHeartbeat.body.senderCompId))
                .body().matches(HeartbeatMatcher.messageId().gt(0L));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        final Venue market = Venue.FXALLMB;
        final String clOrdId = "3452435";
        final OrderType orderType = OrderType.MARKET;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 0;
        final double quantity = 1000000;
        final TimeInForce timeInForce = TimeInForce.DAY;
        final String senderCompId = "PROPHET.HEDGER_MID_FXALL_GB";
        final String targetCompId = "GB:fox";

        final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
        order.body.senderCompId = senderCompId;
        order.body.targetCompId = targetCompId;
        order.body.transactTime = acceptanceContext.precisionClock().nanos();
        order.body.timeInForce = timeInForce;
        order.body.orderQty = quantity;
        order.body.clOrdId = clOrdId;
        order.body.currency = currency;
        order.body.ordType = orderType;
        order.body.price = price;
        order.body.targetStrategyName = "MID";
        order.body.securityType = instrumentKey.securityType();
        order.body.settlCurrency = currency;
        order.body.side = side;
        order.body.symbol = instrumentKey.symbol();
        order.body.settlType = instrumentKey.tenor();
        order.parties.add(new Party(PartyRole.USER_NAME, "autotrader-MidHedger"));
        order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
        order.parties.add(new Party(PartyRole.SOURCE_REGION, "GB"));
        order.parties.add(new Party(PartyRole.TARGET_REGION, "GB"));

        order.strategyParameters.add(new StrategyParameter("Markets", market.name()));

        sorEndpoint.tradingRequest().add(order);

        snapshots.forEach((venue, snapshotFullRefresh) -> {
            Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                    .matching(SnapshotFullRefreshMatcher.build()
                            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(snapshotFullRefresh.body.senderCompId))
                            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(venue))
                            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId())))
                    .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
        });


        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(order.body.senderCompId))
                        .body().matches(NewOrderSingleMatcher.targetCompId().eq(order.body.targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.quoteId().eq(order.body.quoteId))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.targetStrategyName().eq(order.body.targetStrategyName))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterName().eq("Markets"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterValue().eq("FXALLMB"))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                .body().matches(ExecutionReportMatcher.targetCompId().eq(senderCompId))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                .regulatoryTradeIds().countEquals(0);


        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        final TradingMessage parentOrderNewER = Asserter.of(sorEndpoint.tradingResponse())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(15, TimeUnit.SECONDS);

        final VenueEndpoint fxallVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.FXALLMB);
        final TradingMessage venueNos = Asserter.of(fxallVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueNos.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onNewOrderSingle(final NewOrderSingle nos) {

                final ExecutionReport executionReport1 = fxallVenue.createExecutionReport();

                executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport1.body.timeInForce = nos.body.timeInForce;
                executionReport1.body.marketId = nos.body.marketId;
                executionReport1.body.orderQty = nos.body.orderQty;
                executionReport1.body.orderId = "2345";
                executionReport1.body.clOrdId = nos.body.clOrdId;
                executionReport1.body.origClOrdId = nos.body.clOrdId;
                executionReport1.body.execId = "4567";
                executionReport1.body.quoteId = nos.body.quoteId;
                executionReport1.body.currency = nos.body.currency;
                executionReport1.body.ordType = nos.body.ordType;
                executionReport1.body.price = nos.body.price;
                executionReport1.body.securityType = nos.body.securityType;
                executionReport1.body.senderCompId = "GB:lg-fxall";
                executionReport1.body.targetCompId = senderCompId;
                executionReport1.body.settlCurrency = nos.body.currency;
                executionReport1.body.side = nos.body.side;
                executionReport1.body.symbol = nos.body.symbol;
                executionReport1.body.execType = ExecType.NEW;
                executionReport1.body.ordStatus = OrderStatus.NEW;
                executionReport1.body.leavesQty = nos.body.orderQty;
                executionReport1.body.cumQty = 0;
                executionReport1.body.lastQty = 0;
                executionReport1.body.lastPx = 0;

                fxallVenue.tradingResponse().add(executionReport1);
            }
        });

        final TradingMessage parentOcrq = (TradingMessage) Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(OrderCancelRequestMatcher.build()
                        .body().matches(OrderCancelRequestMatcher.senderCompId().eq(targetCompId))
                        .body().matches(OrderCancelRequestMatcher.marketId().eq(Venue.FOX.name()))
                        .body().matches(OrderCancelRequestMatcher.origClOrdId().eq(clOrdId))
                )
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        parentOcrq.accept(
                new TradingMessageVisitor.Silent() {
                    @Override
                    public void onOrderCancelRequest(final OrderCancelRequest parentOcrq) {

                        venueNos.accept(new TradingMessageVisitor.Silent() {
                            @Override
                            public void onNewOrderSingle(final NewOrderSingle nos) {

                                final TradingMessage venueOrderCancelRequest = Asserter.of(fxallVenue.tradingRequest())
                                        .matching(OrderCancelRequestMatcher.build()
                                                .body().matches(OrderCancelRequestMatcher.senderCompId().eq(targetCompId))
                                                .body().matches(OrderCancelRequestMatcher.marketId().eq(nos.body.marketId))
                                                .body().matches(OrderCancelRequestMatcher.orderQty().eq(nos.body.orderQty))
                                                .body().matches(OrderCancelRequestMatcher.side().eq(nos.body.side))
                                                .body().matches(OrderCancelRequestMatcher.origClOrdId().eq(nos.body.clOrdId))
                                                .body().matches(OrderCancelRequestMatcher.securityType().eq(nos.body.securityType))
                                                .body().matches(OrderCancelRequestMatcher.settlType().eq(nos.body.settlType))
                                                .body().matches(OrderCancelRequestMatcher.symbol().eq(nos.body.symbol))
                                        )
                                        .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

                                venueOrderCancelRequest.accept(new TradingMessageVisitor.Silent() {
                                    @Override
                                    public void onOrderCancelRequest(final OrderCancelRequest venueOCReq) {
                                        final ExecutionReport executionReport1 = fxallVenue.createExecutionReport();

                                        executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                                        executionReport1.body.timeInForce = venueOCReq.body.timeInForce;
                                        executionReport1.body.marketId = venueOCReq.body.marketId;
                                        executionReport1.body.orderQty = venueOCReq.body.orderQty;
                                        executionReport1.body.orderId = venueOCReq.body.orderId;
                                        executionReport1.body.clOrdId = venueOCReq.body.clOrdId;
                                        executionReport1.body.origClOrdId = venueOCReq.body.origClOrdId;
                                        executionReport1.body.execId = "456723454";
                                        executionReport1.body.ordType = venueOCReq.body.ordType;
                                        executionReport1.body.securityType = venueOCReq.body.securityType;
                                        executionReport1.body.senderCompId = "GB:lg-fxall";
                                        executionReport1.body.targetCompId = senderCompId;
                                        executionReport1.body.side = venueOCReq.body.side;
                                        executionReport1.body.symbol = venueOCReq.body.symbol;
                                        executionReport1.body.currency = nos.body.currency;
                                        executionReport1.body.price = nos.body.price;
                                        executionReport1.body.settlCurrency = nos.body.currency;
                                        executionReport1.body.execType = ExecType.CANCELED;
                                        executionReport1.body.ordStatus = OrderStatus.CANCELED;
                                        executionReport1.body.leavesQty = 0;
                                        executionReport1.body.cumQty = 0;
                                        executionReport1.body.lastQty = 0;
                                        executionReport1.body.lastPx = 0;

                                        fxallVenue.tradingResponse().add(executionReport1);
                                    }
                                });
                            }
                        });

                        Asserter.of(sorEndpoint.tradingResponse())
                                .matching(ExecutionReportMatcher.build()
                                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                                        .body().matches(ExecutionReportMatcher.clOrdId().eq(parentOcrq.body.clOrdId))
                                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.CANCELED))
                                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED))
                                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                                        .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                                        .body().matches(ExecutionReportMatcher.side().eq(side))
                                        .body().matches(ExecutionReportMatcher.price().eq(price))
                                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                                        .body().matches(ExecutionReportMatcher.cumQty().eq(0.0))
                                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0.0))
                                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);
                    }
                });
        }
}
