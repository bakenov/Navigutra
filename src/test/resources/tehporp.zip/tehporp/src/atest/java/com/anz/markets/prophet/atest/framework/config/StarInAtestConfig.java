package com.anz.markets.prophet.atest.framework.config;

import com.anz.axle.falcon.MillenniumFalcon;
import com.anz.axle.falcon.framework.DockedMillenniumFalcon;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.prophet.atest.framework.impl.TestUmConnection;
import com.anz.markets.prophet.config.app.StarfishInConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(StarfishInConfig.class)
public class StarInAtestConfig {
    @Bean(destroyMethod = "close")
    public Connection umConnection() {
        return new TestUmConnection();
    }

    @Bean
    public MillenniumFalcon millenniumFalcon() {
        return new DockedMillenniumFalcon();
    }
}