package com.anz.markets.efx.ngaro.codec;

public interface Header {
    int source();
    long sourceSeq();
}
