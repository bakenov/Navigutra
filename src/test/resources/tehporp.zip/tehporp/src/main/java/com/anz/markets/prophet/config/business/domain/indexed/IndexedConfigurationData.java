package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.efx.ngaro.collections.EnumDoubleTable;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.collections.EnumSet;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.tabular.BaseTermsToInstrumentMarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.MITRConfigs;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgeFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MITRConfigsImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.OptimalPositionConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PassthroughSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierClippingConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.RiskAdjustedFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolumeSkewConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.PricingModel;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LatencyFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LiquidityFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.MinimumMarketFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.StaleFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.skew.NetOpenPositionSkewRatioConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.DiscoTightenByConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsItemConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWideningConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.EconNewsUnionWithConfig;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.InstrumentConvention;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.collections.EnumTableSetImpl;
import com.anz.markets.prophet.pricer.PrecisionConfiguration;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import com.anz.markets.prophet.pricer.wholesale.BaseSpreadConfiguration;
import com.anz.markets.prophet.pricer.wholesale.BaseSpreadConfigurationDefault;
import com.anz.markets.prophet.risk.CovarianceMatrixManagedAssets;
import com.anz.markets.prophet.status.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * IndexedConfigration data is immutable and can only be built from ConfigurationData.
 * <p>
 * This class decorate ConfigurationData to provide fast and easy/friendly access to the raw/unindexed configuration data.
 */
public class IndexedConfigurationData {
    protected static final Logger LOGGER = LoggerFactory.getLogger(IndexedConfigurationData.class);

    private final ConfigurationData configurationData;
    private final NetOpenPositionLimit netOpenPositionLimit;
    private final EnumDoubleTable<Market, Currency> maxSkewQuantities = new EnumDoubleTable<>(Market.class, Currency.class);
    private final List<SyntheticInstrumentConfig> syntheticInstrumentConfigs;
    private final EnumSet<Market> activePricingModels = new EnumSet<>(Market.class);
    private StaleFilterConfigs staleFilterConfigs;
    private LatencyFilterConfigs latencyFilterConfigs;
    private final List<ClientSpreadConfig> clientSpreadConfigs;
    private final TrimKeyableConfigs liquidityFilterConfigs = new TrimKeyableConfigs<LiquidityFilterConfig>();
    private CovarianceMatrixManagedAssets covarianceMatrixManagedAssets;
    private TypeSafeKeyValueConfig typeSafeKeyValueConfig;
    private final List<Instrument> optimalPositionInstruments = new ArrayList<>();
    private BaseSpreadConfiguration baseSpreadConfiguration;
    private PrecisionConfiguration precisionConfiguration;
    private final EnumObjTable<Market, Instrument, MarketConfig> marketConfigs = new EnumObjTable<>(Market.class, Instrument.class);
    private final List<MarketConfig> marketConfigList = new ArrayList<>();
    private final List<Instrument> driverInstruments = new ArrayList<>();
    private final EnumObjTable<Market,Instrument, DiscoTightenByConfig> discoTightenBy = new EnumObjTable<>(Market.class,Instrument.class);
    private final EnumObjMap<Instrument,Market> discoDriverMarket = new EnumObjMap<>(Instrument.class,Market.class);
    private final EnumDoubleTable<Instrument, TradingTimeZone> standardMarketSpread = new EnumDoubleTable<>(Instrument.class, TradingTimeZone.class);
    private final EnumDoubleMap<Instrument> spreadMultipliers = new EnumDoubleMap<>(Instrument.class);
    private final EnumObjTable<Market, Instrument, VolumeSkewConfig> volumeSkewConfigTable = new EnumObjTable<>(Market.class, Instrument.class);
    private final EnumObjTable<Market, Instrument, PricingModel> pricingModelConfigTable = new EnumObjTable<>(Market.class, Instrument.class);
    private final EnumTableSetImpl<Market, Instrument> marketInstrumentPassthrough = new EnumTableSetImpl(Market.class, Instrument.class);

    // econ news
    private final Map<CharSequence, EconNewsItemConfig> econNewsItemConfigByCode = new HashMap<>(1000);
    private final EnumObjTable<EconNewsWeight, Market, EconNewsWideningConfig> econNewsWideningConfigByWeightAndMarket = new EnumObjTable<>(EconNewsWeight.class, Market.class);
    private final Map<CharSequence, EconNewsUnionWithConfig> econNewsUnionWithConfigByCode = new HashMap<>(1000);

    private final VolatilityWideningConfigs volatilityWideningConfigs;
    private final VolatilityWideningPercentileConfigs volatilityWideningPercentileConfigs;
    private final FilterEnabledConfigs filterEnabledConfigs;

    private EnumObjTable<Portfolio, HedgeFirewallType, HedgeFirewallConfig> hedgeFirewallConfigByPortfolio = new EnumObjTable<>(Portfolio.class, HedgeFirewallType.class);
    private IndexedOperatingHourConfig indexedOperatingHourConfig;

    private MITRConfigs priceFormationPipelineConfigs;

    private final List<ClientPriceThrottleConfig> clientPriceThrottleConfigs;
    private final List<SyntheticWideningFactor> syntheticWideningFactors;
    private EnumDoubleMap<Instrument> minimumMarketFilterConfig = new EnumDoubleMap<>(Instrument.class);
    private final List<PriceBarrierClippingConfig> priceBarrierClippingConfigs = new ArrayList<>();
    private final AggregatedBookConfig aggregatedBookConfig;

    public IndexedConfigurationData(final ConfigurationData configurationData) {
        this.configurationData = configurationData;
        this.activePricingModels.clear();
        indexPricingModel(configurationData);
        //this is ok, because we ave forced the default and any overridden setting to have the same active flag...
        configurationData.getPricingModels().stream().filter(m -> m.isEnabled()).forEach(m -> activePricingModels.add(m.getMarket()));

        this.clientSpreadConfigs = ClientSpreadConfig.explodeClientSpreadConfigs(configurationData.getClientSpreadConfigs(), activePricingModels);
        this.syntheticInstrumentConfigs = SyntheticInstrumentConfig.explodeSyntheticInstrumentConfigs(configurationData.getSyntheticInstrumentConfigs(), activePricingModels);

        final EnumSet<Instrument> synthConfigInstruments = new EnumSet<>(Instrument.class);
        final EnumSet<Instrument> allInstruments = new EnumSet<>(Instrument.class);
        configurationData.getSyntheticInstrumentConfigs().stream().filter(cfg -> cfg.getInstrument().getInstrumentConvention() == InstrumentConvention.CONVENTION).forEach(cfg -> synthConfigInstruments.add(cfg.getInstrument()));
        Arrays.stream(Instrument.VALUES).forEach(inst -> allInstruments.add(inst));

        this.clientPriceThrottleConfigs = (List<ClientPriceThrottleConfig>) BaseTermsToInstrumentMarketConfigImpl.propagateCurrencyAndMarketWildcards(configurationData.getClientPriceThrottleConfigs(), allInstruments, activePricingModels);
        this.syntheticWideningFactors = (List<SyntheticWideningFactor>)BaseTermsToInstrumentMarketConfigImpl.propagateCurrencyAndMarketWildcards(configurationData.getSyntheticWideningFactors(), synthConfigInstruments, activePricingModels);

        this.netOpenPositionLimit = new NetOpenPositionLimit(configurationData.getNetOpenPositionLimitConfigs());
        GcFriendlyAssert.isFalse(netOpenPositionLimit.netOpenPositionLimitByCurrency.isEmpty(), "netOpenPositionLimit.netOpenPositionLimitByCurrency isEmpty()");

        // TODO: these need to be lazy IMHO
        // TODO: need to work out a way to ensure that these are only constructed if the underlying config has changed (see HasChanged)
        indexKeyValueConfigs(configurationData);
        indexBaseSpreadConfiguration(configurationData);
        indexPrecisionConfiguration(configurationData);
        indexCovarianceMatrix();
        indexEconNewsConfigs(configurationData);
        indexOptimalPositionInstruments(configurationData);
        indexPrimaryMarkets(configurationData);
        indexMaxSkewQuantities(configurationData);
        indexSpreads(configurationData);
        indexVolumeSkewConfigTable(configurationData);
        indexMinimumMarketFilterConfig(configurationData);
        indexPriceBarrierClippingConfigs(configurationData);
        volatilityWideningConfigs = new VolatilityWideningConfigs(configurationData.getVolatilityWideningConfigs());
        volatilityWideningPercentileConfigs = new VolatilityWideningPercentileConfigs(configurationData.getVolatilityWideningPercentileConfigs());
        filterEnabledConfigs = new FilterEnabledConfigs(configurationData.getFilterEnabledConfigs());
        setStaleFilterConfigs(configurationData.getStaleFilterConfigs());
        setLatencyFilterConfigs(configurationData.getLatencyFilterConfigs());
        liquidityFilterConfigs.populate(configurationData.getLiquidityFilterConfigs());
        driverInstruments.clear();
        hedgeFirewallConfigByPortfolio.clear();
        indexedOperatingHourConfig = new IndexedOperatingHourConfig(configurationData.getOperatingHourConfigs());
        priceFormationPipelineConfigs = new MITRConfigsImpl<>(configurationData.getPriceFormationPipelineConfigs());
        aggregatedBookConfig = new AggregatedBookConfig(getPriceFormationPipelineConfigs());

        buildTightenByConfig();
        buildDiscoDriverMarket();
        final List<Instrument> driverInstruments = getDriverInstruments();
        synthConfigInstruments.forEach((instrument, v) -> GcFriendlyAssert.isFalse(driverInstruments.contains(instrument), "Synthetic instrument config must not contain driver: %s", instrument));

        populateMarketInstrumentPassthrough();
    }

    /**
     * Driver instruments are instruments that we received market data for and generates unskew prices.
     */
    public List<Instrument> getDriverInstruments() {
        if (driverInstruments.isEmpty()) {
            buildDriverPairs(minimumMarketFilterConfig);
        }
        return driverInstruments;
    }

    public List<Currency> getDriverCurrencies() {
        final List<Currency> driverCurrencies = new ArrayList<>();
        for (Instrument instrument : driverInstruments) {
            final Currency dealtCurrency = instrument.getDealt();
            final Currency termsCurrency = instrument.getTerms();

            if (!driverCurrencies.contains(dealtCurrency)) {
                driverCurrencies.add(dealtCurrency);
            }
            if (!driverCurrencies.contains(termsCurrency)) {
                driverCurrencies.add(termsCurrency);
            }
        }
        return driverCurrencies;
    }

    public EnumSet<Market> getActivePricingModels() {
        return activePricingModels;
    }

    public List<SyntheticInstrumentConfig> getSyntheticInstrumentConfigs() {
        return syntheticInstrumentConfigs;
    }

    private void buildDriverPairs(EnumDoubleMap minimumOrderBook) {
        driverInstruments.clear();
        for (Instrument instrument : Instrument.VALUES) {
            // Add DISCO drivers.
            getActivePricingModels().forEach((market, value) -> {
                final boolean discoTime = getDiscoTightenByConfigMap().get(market,instrument) != null;
                if (discoTime && !driverInstruments.contains(instrument)) {
                   driverInstruments.add(instrument);
                }
            });
            for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                final Markets constituents = getAggregatedBookConfig().getConstituents(Market.WSP_U, ttz, instrument);
                final int n = constituents.get().length;
                if (n > 0) {
                    if (n >= minimumOrderBook.get(instrument)) {
                        if (!driverInstruments.contains(instrument)) {
                            driverInstruments.add(instrument);
                        }
                    } else {
                        LOGGER.warn("Market config for {} does not meet minimum order book config of {} in timezone {}.", instrument, minimumOrderBook, ttz);
                    }
                }
           }
        }
        Collections.sort(driverInstruments, Comparator.comparing(o -> o.name()));
    }

    public EnumObjTable<Market,Instrument, DiscoTightenByConfig> getDiscoTightenByConfigMap() {
        return discoTightenBy;
    }

    private void buildTightenByConfig() {
        discoTightenBy.clear();
        final List<DiscoTightenByConfig> discoTightenByConfigList = DiscoTightenByConfig.explodeConfigs(getConfigurationData().getDiscoTightenByConfigs(), getActivePricingModels());
        for (DiscoTightenByConfig discoTightenByConfig : discoTightenByConfigList) {
            if (discoTightenByConfig.getRegion() == Context.context().region() || discoTightenByConfig.getRegion() == Region.ANY) {
                discoTightenBy.put(discoTightenByConfig.getMarket(), discoTightenByConfig.getInstrument(), discoTightenByConfig);
            }
        }
    }

    public EnumObjMap<Instrument,Market> getDiscoDriverMarketMap() {
        return discoDriverMarket;
    }

    private void buildDiscoDriverMarket() {
        discoDriverMarket.clear();
        getConfigurationData().getDriverMarketChooserConfigs().forEach(config -> this.discoDriverMarket.put(config.getInstrument(), config.getMarket()));
        for (Instrument i : Instrument.values()) {
            discoDriverMarket.computeIfAbsent(i, (instrument) -> {
                if (discoDriverMarket.containsKey(Instrument.ANY)) {
                    return discoDriverMarket.get(Instrument.ANY);
                }
                return Market.WSP_MU;
            });
        }
    }

    private void indexSpreads(final ConfigurationData configurationData) {
        GcFriendlyAssert.notEmpty(configurationData.getStandardMarketSpreadConfigs(), "StandardMarketSpread must be configured.");

        configurationData.getStandardMarketSpreadConfigs().forEach(standardMarketSpread1 -> {
            for (final TradingTimeZone tradingTimeZone : TradingTimeZone.VALUES) {
                final double spread = standardMarketSpread1.get(tradingTimeZone);
                standardMarketSpread.put(standardMarketSpread1.getInstrument(), tradingTimeZone, spread);
            }
        });

        GcFriendlyAssert.notEmpty(configurationData.getInstrumentConfigs(), "InstrumentConfig must be configured.");
        spreadMultipliers.clear();
        configurationData.getInstrumentConfigs().forEach(instrumentConfig ->
            spreadMultipliers.put(instrumentConfig.getInstrument(), instrumentConfig.getSpreadMultiplier())
        );
    }

    private void indexVolumeSkewConfigTable(final ConfigurationData configurationData) {
        GcFriendlyAssert.notEmpty(configurationData.getVolumeSkewConfigs(), "VolumeSkewConfigs must be configured.");
        volumeSkewConfigTable.clear();
        configurationData.getVolumeSkewConfigs().forEach(volumeSkewConfig -> volumeSkewConfigTable.put(volumeSkewConfig.getMarket(), volumeSkewConfig.getInstrument(), volumeSkewConfig));
    }

    private void setLatencyFilterConfigs(List<LatencyFilterConfig> latencyFilterConfigs) {
        if (!CollectionUtils.isEmpty(latencyFilterConfigs)) {
            this.latencyFilterConfigs = new LatencyFilterConfigs(latencyFilterConfigs);
        }
    }

    private void setStaleFilterConfigs(List<StaleFilterConfig> staleFilterConfigs) {
        if (!CollectionUtils.isEmpty(staleFilterConfigs)) {
            this.staleFilterConfigs = new StaleFilterConfigs(staleFilterConfigs);
        }
    }

    public ConfigurationData getConfigurationData() {
        return configurationData;
    }

    private void indexCovarianceMatrix() {
        if (typeSafeKeyValueConfig != null && typeSafeKeyValueConfig.isSet(KeyValueConfigType.RISK_COVARIANCE_MATRIX_MANAGED_ASSETS)) {
            this.covarianceMatrixManagedAssets = new CovarianceMatrixManagedAssets(typeSafeKeyValueConfig.getEnumList(KeyValueConfigType.RISK_COVARIANCE_MATRIX_MANAGED_ASSETS));
        }
    }

    private void indexKeyValueConfigs(final ConfigurationData configurationData) {
        if (configurationData.getKeyValueConfigs() != null) {
            typeSafeKeyValueConfig = new TypeSafeKeyValueConfig(configurationData.getKeyValueConfigs());
        }
    }

    private void indexBaseSpreadConfiguration(final ConfigurationData configurationData) {
        baseSpreadConfiguration = new BaseSpreadConfigurationDefault(configurationData, getPricingModelConfigTable(), getClientSpreadConfigs(), getSyntheticWideningFactors());
    }

    private void indexPrecisionConfiguration(final ConfigurationData configurationData) {
        precisionConfiguration = new PrecisionConfiguration(configurationData.getInstrumentConfigs());
    }

    private void indexPrimaryMarkets(final ConfigurationData configurationData) {
        configurationData.getMarketConfigs().forEach(marketConfig -> {
            if (marketConfig.getRegion() == Context.context().region()) {
                marketConfigs.put(marketConfig.getMarket(), marketConfig.getInstrument(), marketConfig);
                marketConfigList.add(marketConfig);
            }
        });
        GcFriendlyAssert.isFalse(marketConfigList.isEmpty(), "No MarketConfigs available for region %s", Context.context().region());
    }

    @Deprecated
    private void indexOptimalPositionInstruments(final ConfigurationData configurationData) {
        GcFriendlyAssert.notNull(covarianceMatrixManagedAssets, "No covarianceMatrixManagedAssets");
        final java.util.EnumSet optimalPositionPairs = java.util.EnumSet.noneOf(Instrument.class);
        optimalPositionInstruments.clear();
        if (typeSafeKeyValueConfig.isSet(KeyValueConfigType.EQUILVALENT_POSITION_MINIMAL_INSTRUMENT_SET)) {
            optimalPositionPairs.addAll(typeSafeKeyValueConfig.getEnumList(KeyValueConfigType.EQUILVALENT_POSITION_MINIMAL_INSTRUMENT_SET));
        }
        configurationData.getAggressiveNewsHedgerConfigs().forEach(hedgerConfig -> {
            optimalPositionPairs.add(hedgerConfig.getInstrument());
        });
        configurationData.getAggressiveTwapHedgerConfigs().forEach(hedgerConfig -> {
            optimalPositionPairs.add(hedgerConfig.getInstrument());
        });
        configurationData.getMidHedgerConfigs().forEach(hedgerConfig -> {
            optimalPositionPairs.add(hedgerConfig.getInstrument());
        });
        configurationData.getPassiveHedgerConfigs().forEach(hedgerConfig -> {
            optimalPositionPairs.add(hedgerConfig.getInstrument());
        });
        optimalPositionInstruments.addAll(optimalPositionPairs);
    }

    private void indexEconNewsConfigs(final ConfigurationData configurationData) {
        final List<EconNewsItemConfig> econNewsItemConfigs = configurationData.getEconNewsItemConfigs();
        final List<EconNewsWideningConfig> econNewsWideningConfigs = configurationData.getEconNewsWideningConfigs();

        GcFriendlyAssert.notNull(econNewsItemConfigs, "no EconNewsItemConfigs");
        econNewsItemConfigByCode.clear();
        for (final EconNewsItemConfig econNewsItemConfig : econNewsItemConfigs) {
            econNewsItemConfigByCode.putIfAbsent(econNewsItemConfig.getCode(), econNewsItemConfig);
        }

        GcFriendlyAssert.notNull(econNewsWideningConfigs, "no EconNewsWideningConfigs");
        econNewsWideningConfigByWeightAndMarket.clear();

        // explode the configs into each market
        List<EconNewsWideningConfig> econNewsWideningConfigWildcards = new ArrayList<>();
        econNewsWideningConfigs.forEach(econNewsWideningConfig -> {
            if(econNewsWideningConfig.getMarket() == Market.ANY) {
                econNewsWideningConfigWildcards.add(econNewsWideningConfig);
            }
            else {
                if(econNewsWideningConfigByWeightAndMarket.containsKey(econNewsWideningConfig.getWeight(), econNewsWideningConfig.getMarket())) {
                    LOGGER.warn("Duplicate econNewsWideningConfig for weight={} and market={}, will use last received", econNewsWideningConfig.getWeight(), econNewsWideningConfig.getMarket());
                }
                econNewsWideningConfigByWeightAndMarket.put(econNewsWideningConfig.getWeight(), econNewsWideningConfig.getMarket(), econNewsWideningConfig);
            }
        });
        econNewsWideningConfigWildcards.forEach(econNewsWideningConfig -> getActivePricingModels().keys(market -> {
            if (!econNewsWideningConfigByWeightAndMarket.containsKey(econNewsWideningConfig.getWeight(), market)) {
                econNewsWideningConfigByWeightAndMarket.put(econNewsWideningConfig.getWeight(), market, econNewsWideningConfig);
            }
        }));
    }

    public double getMarketSpread(final Instrument instrument) {
        return standardMarketSpread.get(instrument, Context.context().tradingTimeZone());
    }

    public double getSpreadMultiplier(final Instrument instrument) {
        return spreadMultipliers.getOrDefault(instrument, InstrumentConfig.DEFAULT_SPREAD_MULTIPLIER);
    }

    public NetOpenPositionLimit getNetOpenPositionLimit() {
        return this.netOpenPositionLimit;
    }

    public double getSkew(final double calculatedRatio) {
        final List<NetOpenPositionSkewRatioConfig> netOpenPositionSkewRatioConfigs = configurationData.getNetOpenPositionSkewRatioConfigs();
        GcFriendlyAssert.isTrue(netOpenPositionSkewRatioConfigs.size() > 1, "no netOpenPositionSkewRatioConfigs");
        if (Double.isNaN(calculatedRatio)) {
            return 0d;
        }
        final int max = netOpenPositionSkewRatioConfigs.size();
        NetOpenPositionSkewRatioConfig previous = netOpenPositionSkewRatioConfigs.get(0);
        for (int i = 1; i < max; i++) {
            final NetOpenPositionSkewRatioConfig range = netOpenPositionSkewRatioConfigs.get(i);
            if (calculatedRatio < range.getRatio() && calculatedRatio > previous.getRatio()) {
                return previous.getSkew();
            }
            if (calculatedRatio == range.getRatio()) {
                return range.getSkew();
            }
            if (calculatedRatio == previous.getRatio()) {
                return previous.getSkew();
            }
            previous = range;
        }
        final NetOpenPositionSkewRatioConfig last = netOpenPositionSkewRatioConfigs.get(max - 1);
        if (calculatedRatio >= last.getRatio()) {
            return last.getSkew();
        }
        return 0d;
    }

    private void indexPricingModel(final ConfigurationData config) {
        pricingModelConfigTable.clear();
        config.getPricingModels().forEach(cfg -> {
            pricingModelConfigTable.put(cfg.getMarket(), cfg.getInstrument(), cfg);
        });

        //check that any overridden pricing model (by inst) have a default inst.ANY setup.
        pricingModelConfigTable.forEachIf(pricingModel -> (pricingModel.getInstrument() != Instrument.ANY),
                pricingModel -> GcFriendlyAssert.isTrue(pricingModelConfigTable.containsKey(pricingModel.getMarket(), Instrument.ANY),
                                                "ANY Instrument not specified for market: " + pricingModel.getMarket()));

        //check that any overridden model has the same active flag set as the default inst.ANY.
        pricingModelConfigTable.forEachIf(pricingModel -> (pricingModel.getInstrument() != Instrument.ANY),
                pricingModel -> {
                    boolean anyEnabled = pricingModelConfigTable.get(pricingModel.getMarket(), Instrument.ANY).isEnabled();

                    GcFriendlyAssert.isTrue(pricingModelConfigTable.get(pricingModel.getMarket(), Instrument.ANY).isEnabled() == pricingModel.isEnabled(),
                            "Default model (" + pricingModel.getMarket() + ") and override settings must be consistently active: (inst.ANY=" + anyEnabled + " != inst." + pricingModel.getInstrument() + "=" + pricingModel.isEnabled() + ")");
        });

        //proliferate default setting to all instruments.
        pricingModelConfigTable.forEachRowKeyWithColumnKey((market, pricingModel) -> {
            for (Instrument instrument : Instrument.VALUES) {
                pricingModelConfigTable.computeIfAbsent(market, instrument, (m, i) -> pricingModel);
            }
        }, Instrument.ANY);
    }

    private void populateMarketInstrumentPassthrough() {
        marketInstrumentPassthrough.clear();

        List<PassthroughSpreadConfig> marketWildcards = new ArrayList<>();

        final List<Market> localMarketAutoPassthroughModels = getKeyValueConfig().getEnumList(KeyValueConfigType.LOCAL_MARKET_PASSTHROUGH_MODELS, Collections.singletonList(Market.WSP_A));
        localMarketAutoPassthroughModels.stream().filter(m -> getActivePricingModels().contains(m)).forEach(m -> Arrays.stream(Instrument.VALUES).filter(i -> i.isLM()).forEach(i -> marketInstrumentPassthrough.add(m, i)));

        getConfigurationData().getPassthroughSpreadConfigs().forEach(c -> {
            if (c.getMarket() == Market.ANY) {
                marketWildcards.add(c);
            } else {
                // allow this to override the auto-passthrough
                marketInstrumentPassthrough.add(c.getMarket(), c.getInstrument());
            }
        });
        marketWildcards.forEach(c -> getActivePricingModels().keys(market -> {
            if (!marketInstrumentPassthrough.contains(market, c.getInstrument())) {
                marketInstrumentPassthrough.add(market, c.getInstrument());
            }
        }));
    }

    private void indexPriceBarrierClippingConfigs(final ConfigurationData configurationData) {
        priceBarrierClippingConfigs.clear();

        List<PriceBarrierClippingConfig> anyMarketConf = configurationData.getPriceBarrierClippingConfigs().stream().filter(p -> p.market == Market.ANY).collect(Collectors.toList());

        priceBarrierClippingConfigs.addAll(configurationData.getPriceBarrierClippingConfigs().stream().filter(p -> p.market != Market.ANY).collect(Collectors.toList()));

        List<PriceBarrierClippingConfig> anyConfExpanded = new ArrayList<>();
        for (PriceBarrierClippingConfig anyConf : anyMarketConf) {
            for (Market m : Market.CLIENT_PRICING_MARKETS) {
                if (priceBarrierClippingConfigs.stream().noneMatch(p -> p.market == m)) {
                    anyConfExpanded.add(PriceBarrierClippingConfig.fromExistingWithMarket(anyConf, m));
                }
            }
        }
        priceBarrierClippingConfigs.addAll(anyConfExpanded);

    }

    public List<PriceBarrierClippingConfig> getPriceBarrierClippingConfigs() {
        return priceBarrierClippingConfigs;
    }

    public boolean isPassthroughInstrument(final Market market, final Instrument instrument) {
        return marketInstrumentPassthrough.contains(market, instrument);
    }


    public EnumObjTable<Market, Instrument, PricingModel> getPricingModelConfigTable() {
        return pricingModelConfigTable;
    }

    private void indexMinimumMarketFilterConfig(final ConfigurationData config) {
        minimumMarketFilterConfig.clear();

        // Explode out the mandatory ANY instrument
        MinimumMarketFilterConfig wildcard = MinimumMarketFilterConfig.EMPTY;
        for (MinimumMarketFilterConfig mmfc : config.getMinimumMarketsFilterConfigs()) {
            if (mmfc.getInstrument() == Instrument.ANY) {
                wildcard = mmfc;
            } else {
                minimumMarketFilterConfig.put(mmfc.getInstrument(), mmfc.getMinimumMarkets());
            }
        }
        GcFriendlyAssert.isTrue(wildcard != MinimumMarketFilterConfig.EMPTY, "MinimumMarketFilterConfig must contain an Instrument.ANY setting");
        for (Instrument instrument : Instrument.VALUES) {
            if (!minimumMarketFilterConfig.containsKey(instrument)) {
                minimumMarketFilterConfig.put(instrument, wildcard.getMinimumMarkets());
            }
        }
    }

    private void indexMaxSkewQuantities(final ConfigurationData cfgData) {
        maxSkewQuantities.clear();
        cfgData.getMaxSkewQuantities().forEach(msq -> maxSkewQuantities.put(msq.market, msq.currency, msq.value));
    }

    public EnumDoubleTable<Market, Currency> getMaxSkewQuantities() {
        return maxSkewQuantities;
    }

    public List<RiskAdjustedFactor> getRiskAdjustedSpreadParams() {
        return configurationData.getRiskAdjustedSpreadParams();
    }

    @Deprecated
    public CovarianceMatrixManagedAssets getCovarianceMatrixManagedAssets() {
        return covarianceMatrixManagedAssets;
    }

    @Deprecated
    public List<Instrument> getOptimalPositionInstruments() {
        return optimalPositionInstruments;
    }

    public TypeSafeKeyValueConfig getKeyValueConfig() {
        return this.typeSafeKeyValueConfig;
    }

    public EconNewsUnionWithConfig createEconNewsUnionWithConfig(final EconNews econNews) {
        // lookup item config and weight config - iff all exists create a entry for use.
        final EconNewsItemConfig econNewsItemConfig = econNewsItemConfigByCode.get(econNews.getCode());
        if (econNewsItemConfig != null) {
            EnumObjMap<Market, EconNewsWideningConfig> econNewsWideningConfigByMarket = new EnumObjMap<>(Market.class);
            econNewsWideningConfigByWeightAndMarket.forEachColumnKeyWithRowKey((m, c) -> econNewsWideningConfigByMarket.put(m, c), econNewsItemConfig.getWeight());
            if (!econNewsWideningConfigByMarket.isEmpty()) {
                EconNewsUnionWithConfig econNewsUnionWithConfig = econNewsUnionWithConfigByCode.get(econNews.getCode());
                if (econNewsUnionWithConfig == null) {
                    econNewsUnionWithConfig = new EconNewsUnionWithConfig(econNews, econNewsItemConfig, econNewsWideningConfigByMarket);
                    econNewsUnionWithConfigByCode.put(econNews.getCode(), econNewsUnionWithConfig);
                } else {
                    econNewsUnionWithConfig.set(econNews, econNewsItemConfig, econNewsWideningConfigByMarket);
                }
                return econNewsUnionWithConfig;
            } else {
                // weight definition should exists if it is referenced. Will be forgiving here to allow system to continue.
                LOGGER.error("EconNewsWeightConfig is not configured for weight {}. This econ news will be ignored and pricing will continue. This is likely a configuration error.", econNewsItemConfig.getWeight());
            }
        } else {
            LOGGER.debug("EconNewsItemConfig is not configured for news code {}", econNews.getCode());
        }
        return null;
    }

    public VolatilityWideningConfigs getVolatilityWideningConfigs() {
        return volatilityWideningConfigs;
    }

    public VolatilityWideningPercentileConfigs getVolatilityWideningPercentileConfigs() {
        return volatilityWideningPercentileConfigs;
    }

    public FilterEnabledConfigs getFilterEnabledConfigs() {
        return filterEnabledConfigs;
    }

    public BaseSpreadConfiguration getBaseSpreadConfiguration() {
        return baseSpreadConfiguration;
    }

    public List<SyntheticWideningFactor> getSyntheticWideningFactors() {
        return syntheticWideningFactors;
    }

    public List<ClientPriceThrottleConfig> getClientPriceThrottleConfigs() {
        return clientPriceThrottleConfigs;
    }

    public PrecisionConfiguration getPrecisionConfiguration() {
        return precisionConfiguration;
    }

    public EnumObjTable<Market, Instrument, MarketConfig> getMarketConfigs() {
        return marketConfigs;
    }

    public StaleFilterConfigs getStaleFilterConfigs() {
        return staleFilterConfigs;
    }

    public LatencyFilterConfigs getLatencyFilterConfigs() {
        return latencyFilterConfigs;
    }

    public TrimKeyableConfigs<LiquidityFilterConfig> getLiquidityFilterConfigs() {
        return liquidityFilterConfigs;
    }

    public EnumObjTable<Portfolio, HedgeFirewallType, HedgeFirewallConfig> getHedgeFirewallConfigByPortfolio() {
        if (hedgeFirewallConfigByPortfolio.isEmpty()) {
            configurationData.getHedgeFirewallConfigs().forEach(config -> hedgeFirewallConfigByPortfolio.put(config.getPortfolio(), config.getHedgeFirewallType(), config));
        }
        return hedgeFirewallConfigByPortfolio;
    }

    public List<OptimalPositionConfig> getOptimalPositionConfigs() {
        return configurationData.getOptimalPositionConfigs();
    }

    public IndexedOperatingHourConfig getIndexedOperatingHourConfig() {
        return indexedOperatingHourConfig;
    }

    public List<RealisedVolatilityConfig> getRealisedVolatilityConfigs() {
        return configurationData.getRealisedVolatilityConfigs();
    }

    public double pipsToRate(final Instrument instrument, final double pips) {
        return getBaseSpreadConfiguration().pipsToRate(instrument, pips);
    }

    public MITRConfigs getPriceFormationPipelineConfigs() {
        return priceFormationPipelineConfigs;
    }

    public EnumObjTable<Market, Instrument, VolumeSkewConfig> getVolumeSkewConfigTable() {
        return volumeSkewConfigTable;
    }

    public EnumDoubleMap<Instrument> getMinimumMarketFilterConfig() {
        return minimumMarketFilterConfig;
    }

    public List<ClientSpreadConfig> getClientSpreadConfigs() {
        return clientSpreadConfigs;
    }

    public AggregatedBookConfig getAggregatedBookConfig() {
        return aggregatedBookConfig;
    }

}
