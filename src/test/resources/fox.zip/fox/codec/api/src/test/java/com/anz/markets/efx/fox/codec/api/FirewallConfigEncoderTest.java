package com.anz.markets.efx.fox.codec.api;


import org.junit.Test;

import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

public class FirewallConfigEncoderTest {
    @Test
    public void encoderChaining() {
        final FirewallConfigEncoder encoder = mock(FirewallConfigEncoder.class, RETURNS_DEEP_STUBS);

        encoder.messageStart(1, 2)
                .firewallName().encode("TestFirewall")
                .ruleId(123)
                .regionPattern().encode("*")
                .orderTypePattern().encode("*")
                .deskPattern().encode("EFX*")
                .venuePattern().encode("*")
                .portfolioPattern().encode("*")
                .usernamePattern().encode("*")
                .securityTypePattern().encode("*")
                .tenorPattern().encode("*")
                .symbolPattern().encode("*")
                .period(60)
                .periodUnit().encode("s")
                .local(true)
                .comment().encode("Set as limits for EFX users need to be greater than other users")
                .lastEditUsername().encode("sawenkoa")
                .lastEditTime(45445)
                .limitThreshold(100000000.0)
                .messageComplete();
    }
}