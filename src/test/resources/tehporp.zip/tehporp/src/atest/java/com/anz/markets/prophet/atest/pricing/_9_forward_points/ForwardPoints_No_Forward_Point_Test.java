package com.anz.markets.prophet.atest.pricing._9_forward_points;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.EmptyBookReason;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;
import java.time.LocalDate;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class ForwardPoints_No_Forward_Point_Test extends BaseAcceptanceSpecification {


    @RestartBeforeTest(reason="clear forward points")
    @Test
    public void no_forward_points_available_do_not_price_cross() throws Exception {

        final Instrument driverPairA = Instrument.USDCAD;
        final Instrument driverPairB = Instrument.USDJPY;
        final Instrument crossPair = Instrument.CADJPY;

        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(1)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(2)));

            // Do NOT send fwd points for driverPairA
            //            prophet.receive(tdd.forwardPoint(driverPairA, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            //            prophet.receive(tdd.forwardPoint(driverPairA, -0.44d, -0.06d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.30525, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(7));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.305220000, 1.305280000));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.305197500, 1.305302500));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.305155000, 1.305345000));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.305155000, 1.305345000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.305080000, 1.305420000));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.304980000, 1.305520000));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.304650000, 1.305850000));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 101.005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 101.003500, 101.006500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 101.002000, 101.008000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 101.001250, 101.008750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 101.000000, 101.010000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 100.993500, 101.016500));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 100.988500, 101.021500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 100.970500, 101.039500));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 100.957500, 101.052500));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 100.930000, 101.080000));
        }
        and:
        {
            prophet.notExpect(org.apache.logging.log4j.Level.ERROR, matches(".*"));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPrice.getBids().size(), is(0));
            assertThat(clientPrice.getEmptyBookReason(), is(EmptyBookReason.CROSS_RATE_FORWARD_CURVE_MISSING_ENTIRELY));
        }
    }
}
