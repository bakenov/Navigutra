package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ToolsCommonTailer;
import net.openhft.chronicle.ExcerptAppender;
import net.openhft.chronicle.ExcerptTailer;
import net.openhft.lang.io.Bytes;

public enum LegacyChronicleWrappers {
    INSTANCE;

    // One instance for each type per thread, to avoid collision when running multiple processes in the same JVM
    private ThreadLocal<LCBytes<Bytes>> bytes = ThreadLocal.withInitial(LCBytes::new);
    private ThreadLocal<LCBytes<ExcerptTailer>> tailer = ThreadLocal.withInitial(LCBytes::new);
    private ThreadLocal<LCBytes<ExcerptAppender>> appender = ThreadLocal.withInitial(LCBytes::new);

    // Used by ToolsCommon components only!
    private static LCTailer lcTailer = new LCTailer();

    public static ProphetBytes wrap(final Bytes bytes) {
        return INSTANCE.bytes.get().withBytes(bytes);
    }

    public static ProphetBytes wrap(final ExcerptAppender appender) {
        return INSTANCE.appender.get().withBytes(appender);
    }

    public static ProphetBytes wrap(final ExcerptTailer tailer) {
        lcTailer.setTailer(tailer);
        return INSTANCE.tailer.get().withBytes(tailer);
    }

    /**
     * Wrapper class for Legacy Chronicle (CQ3) byte streams
     **/
    private static class LCBytes<BYTES_SOURCE extends Bytes> implements ProphetBytes {
        private BYTES_SOURCE bytes;

        private LCBytes<BYTES_SOURCE> withBytes(final BYTES_SOURCE bytes) {
            this.bytes = bytes;
            return this;
        }

        @Override
        public void skipBytesRead(final int bytesToSkip) {
            bytes.skipBytes(bytesToSkip);
        }

        @Override
        public boolean readBoolean() {
            return bytes.readBoolean();
        }

        @Override
        public byte readByte() {
            return bytes.readByte();
        }

        @Override
        public long readLong() {
            return bytes.readLong();
        }

        @Override
        public int readInt() {
            return bytes.readInt();
        }

        @Override
        public double readDouble() {
            return bytes.readDouble();
        }

        @Override
        public float readFloat() {
            return bytes.readFloat();
        }

        @Override
        public String readUTF8() {
            return bytes.readUTF();
        }

        @Override
        public void readUTF8(StringBuilder sb) {
            bytes.readUTFΔ(sb);
        }

        @Override
        public short readShort() {
            return bytes.readShort();
        }

        @Override
        public <E> E readEnum(final Class<E> clazz) {
            return bytes.readEnum(clazz);
        }

        @Override
        public int read(final byte[] bytes, final int offset, final int length) {
            return this.bytes.read(bytes, offset, length);
        }

        @Override
        public int read(final byte[] bytes) {
            return this.bytes.read(bytes);
        }

        @Override
        @NotGcFriendly("Garbagy")
        public <E> E readObject(final Class<E> clazz) {
            return bytes.readObject(clazz);
        }

        @Override
        public void writeBoolean(final boolean value) {
            bytes.writeBoolean(value);
        }

        @Override
        public void writeByte(final byte value) {
            bytes.writeByte(value);
        }

        @Override
        public void writeInt(final int value) {
            bytes.writeInt(value);
        }

        @Override
        public void writeLong(final long value) {
            bytes.writeLong(value);
        }

        @Override
        public void writeFloat(final float value) {
            bytes.writeFloat(value);
        }

        @Override
        public void writeDouble(final double value) {
            bytes.writeDouble(value);
        }

        @Override
        public void writeUTF8(final String value) {
            bytes.writeUTF(value);
        }

        @Override
        public void writeUTF8(final CharSequence value) {
            bytes.writeUTFΔ(value);
        }

        @Override
        public void writeShort(final short value) {
            bytes.writeShort(value);
        }

        @Override
        public <E extends Enum<E>> void writeEnum(final Enum<E> value) {
            bytes.writeEnum(value);
        }

        @Override
        public void write(final byte[] bytes, final int offset, final int length) {
            this.bytes.write(bytes, offset, length);
        }

        @Override
        @NotGcFriendly("Garbagy")
        public <E> void writeObject(final E object) {
            bytes.writeObject(object);
        }

        @Override
        public ToolsCommonTailer getTailer() {
            return lcTailer;
        }

        @Override
        public void position(final long position) {
            bytes.position(position);
        }

        @Override
        public long position() {
            return bytes.position();
        }

        @Override
        public int length() {
            return bytes.length();
        }
    }

    /**
     * Wrapper class for Legacy Chronicle (CQ3) tailer, only used by ToolsCommon
     **/
    private static class LCTailer implements ToolsCommonTailer {
        private ExcerptTailer tailer;

        void setTailer(final ExcerptTailer tailer) {
            this.tailer = tailer;
        }

        @Override
        public long position() {
            return tailer.position();
        }

        @Override
        public long index() {
            return tailer.index();
        }

        @Override
        public void position(final long position) {
            tailer.position(position);
        }
    }
}