package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.EnumSet;
import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoVenueConfigHandler implements VenueConfigHandler {

    private final Consumer<? super VenueConfig> messageConsumer;

    private VenueConfig message = SorMessage.venueConfig();

    public VenueConfig message() {
        return message;
    }

    public PojoVenueConfigHandler() {
        this(msg -> {});
    }

    public PojoVenueConfigHandler(final Consumer<? super VenueConfig> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.venueConfig();
    }

    @Override
    public void onBody(final Body body) {
        message.body.venue = body.venue();
        message.body.compId = body.compId().decodeStringOrNull();
        message.body.enabled = body.enabled();
        message.body.venueCategories = body.venueCategories().decodeTo(EnumSet.noneOf(VenueCategory.class));
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
