package com.anz.axle.lg.adapter.cnx.quickfix;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import quickfix.Message;
import quickfix.field.ClOrdID;
import quickfix.field.ClientID;
import quickfix.field.MsgType;
import quickfix.field.OrderID;
import quickfix.field.OrderQty;
import quickfix.field.OrigClOrdID;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix42.OrderCancelRequest;

import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestHandler;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;

public final class CnxLoggedOnOrderCancelRequestHandler implements OrderCancelRequestHandler {
    private static final boolean INCLUDE_MILLISECONDS = false;
    private final Consumer<Message> fixMessageSender;
    private final OrderCancelRequest orderCancel = new OrderCancelRequest();
    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));
    private final Date transactTime = new Date();

    public CnxLoggedOnOrderCancelRequestHandler(final Consumer<Message> fixMessageSender) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        orderCancel.clear();
    }

    @Override
    public void onBody(final Body body) {
        orderCancel.getHeader().setString(MsgType.FIELD, MsgType.ORDER_CANCEL_REQUEST);
        orderCancel.setString(ClOrdID.FIELD, body.clOrdId().decodeStringOrNull());
        orderCancel.setDouble(OrderQty.FIELD, body.orderQty());
        orderCancel.setString(OrigClOrdID.FIELD, body.origClOrdId().decodeStringOrNull());
        orderCancel.setChar(quickfix.field.Side.FIELD, side(body.side()));
        orderCancel.setString(Symbol.FIELD, body.symbol().decodeAndCache(symbol7Cache));
        orderCancel.setUtcTimeStamp(TransactTime.FIELD, transactTime(body.transactTime()), INCLUDE_MILLISECONDS);
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return quickfix.field.Side.BUY;
            case SELL: return quickfix.field.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }

    private Date transactTime(final long transactTimeNanos) {
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(transactTimeNanos));
        return transactTime;
    }

    @Override
    public void onParties_Entry(final PartyRole partyRole, final StringDecoder partyId, final int partiesIndex, final int maxPartiesCount) {
        if (partyRole == PartyRole.CLIENT_ID) {
            orderCancel.setString(ClientID.FIELD, partyId.decodeStringOrEmpty());
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(orderCancel);
    }
}
