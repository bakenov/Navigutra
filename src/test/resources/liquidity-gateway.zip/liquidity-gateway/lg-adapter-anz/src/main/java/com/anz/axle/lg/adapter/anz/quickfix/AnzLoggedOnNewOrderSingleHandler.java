package com.anz.axle.lg.adapter.anz.quickfix;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import quickfix.Message;
import quickfix.field.Account;
import quickfix.field.ClOrdID;
import quickfix.field.ClientID;
import quickfix.field.Currency;
import quickfix.field.HandlInst;
import quickfix.field.MsgType;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.Price;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix44.NewOrderSingle;

import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;

public final class AnzLoggedOnNewOrderSingleHandler implements NewOrderSingleHandler {
    private static final boolean INCLUDE_MILLISECONDS = true;
    private final Consumer<Message> fixMessageSender;
    private final NewOrderSingle newOrderSingle = new NewOrderSingle();
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final Date transactTime = new Date();
    private final Map<String, String> symbol7Map = new HashMap<>();
    private final String account;

    public AnzLoggedOnNewOrderSingleHandler(final Consumer<Message> fixMessageSender,
                                            final String account) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.account = Objects.requireNonNull(account);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.clear();
    }

    @Override
    public void onBody(final Body body) {
        newOrderSingle.getHeader().setString(MsgType.FIELD, MsgType.ORDER_SINGLE);
        newOrderSingle.setString(ClOrdID.FIELD, body.clOrdId().decodeStringOrNull());
        newOrderSingle.setString(Symbol.FIELD, symbol7(body));
        newOrderSingle.setString(Account.FIELD, account);
        newOrderSingle.setChar(HandlInst.FIELD, HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        newOrderSingle.setChar(quickfix.field.Side.FIELD, side(body.side()));
        newOrderSingle.setDouble(OrderQty.FIELD, body.orderQty());
        newOrderSingle.setString(Currency.FIELD, currency(body));
        newOrderSingle.setChar(OrdType.FIELD, orderType(body.ordType()));
        newOrderSingle.setDouble(Price.FIELD, body.price());
        newOrderSingle.setUtcTimeStamp(TransactTime.FIELD, transactTime(body.transactTime()), INCLUDE_MILLISECONDS);
    }

    private Date transactTime(long transactTimeNanos) {
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(transactTimeNanos));
        return transactTime;
    }

    private String symbol7(final Body body) {
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        return symbol7Map.computeIfAbsent(symbol, SymbolNormaliser::toSymbol7);
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT: return OrdType.FOREX_LIMIT;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return quickfix.field.Side.BUY;
            case SELL: return quickfix.field.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }

    @Override
    public void onParties_Entry(final PartyRole partyRole, final StringDecoder partyId, final int partiesIndex, final int maxPartiesCount) {
        if (partyRole == PartyRole.CLIENT_ID) {
            newOrderSingle.setString(ClientID.FIELD, partyId.decodeStringOrEmpty());
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
    }
}
