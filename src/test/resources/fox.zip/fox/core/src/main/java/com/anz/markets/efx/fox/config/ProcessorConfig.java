package com.anz.markets.efx.fox.config;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.agrona.collections.MutableLong;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.tools4j.eventsourcing.api.CommandExecutorFactory;
import org.tools4j.eventsourcing.api.EventApplierFactory;
import org.tools4j.eventsourcing.api.ExecutionQueue;
import org.tools4j.eventsourcing.api.MessageConsumer;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.domain.UserSessionRepository;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.api.eventsourcing.UpdatablePrecisionClock;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.sbe.SbeSorEncoders;
import com.anz.markets.efx.fox.common.pricing.DefaultOpenOrdersObserver;
import com.anz.markets.efx.fox.common.pricing.PricingFeed;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.processor.command.DefaultCommandExecutorFactory;
import com.anz.markets.efx.fox.processor.event.DefaultEventApplierFactory;
import com.anz.markets.efx.fox.processor.pricing.NoopDownstreamDecoderConnector;
import com.anz.markets.efx.fox.processor.pricing.UpstreamSnapshotFullRefreshHandlerRouter;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.fox.processor.state.DefaultParentOrderRepository;
import com.anz.markets.efx.fox.processor.state.DefaultTimeInForceTimer;
import com.anz.markets.efx.fox.processor.state.DefaultUserRepository;
import com.anz.markets.efx.fox.processor.state.MutableParentOrderRepository;
import com.anz.markets.efx.fox.processor.state.ParentOrderFactory;
import com.anz.markets.efx.fox.processor.state.TimeInForceTimer;
import com.anz.markets.efx.fox.processor.state.TimeInForceTimerConfig;
import com.anz.markets.efx.fox.processor.state.UpdatableIdGenerator;
import com.anz.markets.efx.fox.processor.state.ematch.EMatchParentOrder;
import com.anz.markets.efx.fox.processor.state.ematch.EMatchParentOrderFactory;
import com.anz.markets.efx.fox.processor.state.ematch.EMatchParentOrderValidator;
import com.anz.markets.efx.fox.processor.state.health.Health;
import com.anz.markets.efx.fox.processor.state.instrument.DefaultInstrumentRepository;
import com.anz.markets.efx.fox.processor.state.mid.StaticVenueTimeInForceLookup;
import com.anz.markets.efx.fox.processor.state.mid.MidParentOrder;
import com.anz.markets.efx.fox.processor.state.mid.MidParentOrderFactory;
import com.anz.markets.efx.fox.processor.state.mid.MidParentOrderValidator;
import com.anz.markets.efx.fox.processor.state.sweeper.DefaultParentOrder;
import com.anz.markets.efx.fox.processor.state.sweeper.DefaultParentOrderFactory;
import com.anz.markets.efx.fox.processor.state.sweeper.DefaultParentOrderValidator;
import com.anz.markets.efx.fox.processor.state.usersession.DefaultUserSessionRepository;
import com.anz.markets.efx.fox.processor.state.venue.DefaultVenueRepository;
import com.anz.markets.efx.fox.processor.state.venueInstrument.DefaultVenueInstrumentRepository;
import com.anz.markets.efx.fox.processor.timer.DefaultTimer;
import com.anz.markets.efx.fox.processor.timer.Timer;
import com.anz.markets.efx.fox.processor.timer.TimerController;
import com.anz.markets.efx.fox.processor.validator.DefaultParentOrderValidatorRepository;
import com.anz.markets.efx.fox.processor.validator.DefaultValidationErrorHandler;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidatorRepository;
import com.anz.markets.efx.fox.receiver.VenueSubscriber;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.client.api.SnapshotterDecoderLookup;
import com.anz.markets.efx.pricing.client.api.SnapshotterDecoderSupplier;
import com.anz.markets.efx.pricing.client.conflator.DefaultSnapshotterDecoderLookup;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.IdGenerator;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingEncoders;

@Configuration
public class ProcessorConfig {

    @Bean
    public UpdatablePrecisionClock eventPrecisionClock() {
        return new UpdatablePrecisionClock();
    }

    @Bean
    public SnapshotterDecoderLookup snapshotterDecoderLookup(@Value("${messaging.compId}") final String compId,
                                                             final PrecisionClock eventPrecisionClock,
                                                             final VenueInstrumentRepository venueInstrumentRepository,
                                                             final @Value("${fox.snapshotter.source.id}") int foxSnapshotterSourceId) {
            final LongSupplier messageIdSupplier = new IdGenerator();

        final Function<RequestKey, SnapshotterBuilder> snapshotterBuilderFactory = requestKey -> {
            final SnapshotterBuilder.DownstreamDecoderConnectorBuilder downstreamDecoderConnectorBuilder =
                    SnapshotterBuilder
                            .withMarketDataBook(venueInstrumentRepository.lookup(requestKey).marketDataBook())
                            .withDownstreamDecoder();

            return downstreamDecoderConnectorBuilder
                    .connectedTo(new NoopDownstreamDecoderConnector());
        };

        return new DefaultSnapshotterDecoderLookup(
                SnapshotterDecoderSupplier.factory(
                        eventPrecisionClock,
                        messageIdSupplier,
                        snapshotterBuilderFactory,
                        UpdateTypeMismatchHandler.WARN,
                        compId,
                        foxSnapshotterSourceId));
    }

    @Bean
    public SnapshotFullRefreshHandler snapshotterFullRefreshHandler(final SnapshotterDecoderLookup snapshotterDecoderLookup) {
        return new UpstreamSnapshotFullRefreshHandlerRouter(snapshotterDecoderLookup, new DefaultRequestKeyLookup());
    }

    @Bean
    public Function<MessageConsumer, TradingEncoderSupplier> tradingEncoderSupplierFactory(@Value("${messaging.sbe.buffer.capacity}") final int sbeMessageBufferCapacity) {
        final UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(sbeMessageBufferCapacity));
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final SbeTradingEncoders sbeTradingEncoders = new SbeTradingEncoders(() -> sbeMessage);

        return messageConsumer ->
                sbeTradingEncoders.toTradingEncoderSupplier(
                        message -> messageConsumer.accept(message.buffer(), 0, message.messageLength()));
    }

    @Bean
    public Function<MessageConsumer, SorEncoderSupplier> sorEncoderSupplierFactory(@Value("${messaging.sbe.buffer.capacity}") final int sbeMessageBufferCapacity) {
        final UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(sbeMessageBufferCapacity));
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final SbeSorEncoders sbeSorEncoders = new SbeSorEncoders(() -> sbeMessage);

        return messageConsumer ->
                sbeSorEncoders.toSorEncoderSupplier(
                        message -> messageConsumer.accept(message.buffer(), 0, message.messageLength()));
    }

    @Bean
    public MessageDecoder<SbeMessage> loopbackPublishingDecoder(final Connection senderConnection,
                                                                final @Value("${loopback.topic}") String loopbackTopicName,
                                                                final EndPointStatusHandler transportEndPointStatusHandler) {
        final Topic loopbackTopic = DefaultTopic.create(loopbackTopicName);
        final Publication loopbackPublication = senderConnection.openPublication(loopbackTopic, transportEndPointStatusHandler);

        return sbeMessage -> loopbackPublication.publish(sbeMessage.buffer(), 0, sbeMessage.messageLength());
    }

    @Bean
    public SorEncoders<SbeMessage> loopbackSbeSorEncoders(@Value("${messaging.sbe.buffer.capacity}") final int sbeMessageBufferCapacity) {
        final UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(sbeMessageBufferCapacity));
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbeSorEncoders(() -> sbeMessage);
    }

    @Bean
    public SorEncoderSupplier loopbackSorEncoderSupplier(final SorEncoders<SbeMessage> loopbackSbeSorEncoders,
                                                         final MessageDecoder<SbeMessage> loopbackPublishingDecoder) {
        return loopbackSbeSorEncoders.toSorEncoderSupplier(
                loopbackPublishingDecoder::decode);
    }

    @Bean
    public TimeInForceTimerConfig timeInForceTimerConfig(@Value("#{${time.in.force.timer.limits:T(java.util.Collections).emptyMap()}}") final Map<TimeInForce, Map<TimerGroup, Long>> timeInForceTimerLimits) {
        return (timerGroup, timeInForce) -> timeInForceTimerLimits.get(timeInForce).get(timerGroup);
    }

    @Bean
    public TimerController timerController(final @Value("${fox.timer.expiry.source.id}") int timerExpirySourceId,
                                           final PrecisionClock systemPrecisionClock,
                                           final PrecisionClock eventPrecisionClock,
                                           final SorEncoderSupplier loopbackSorEncoderSupplier) {
        final UpdatableIdGenerator idGenerator = new UpdatableIdGenerator();
        idGenerator.accept(systemPrecisionClock.micros());
        return TimerController.forNanosClock(
                timerExpirySourceId,
                idGenerator,
                systemPrecisionClock,
                eventPrecisionClock,
                10,
                1024 * 1024,
                1024,
                loopbackSorEncoderSupplier);
    }

    @Bean
    public TimeInForceTimer.Factory timeInForceTimerFactory(final TimerController timerController,
                                                            final TimeInForceTimerConfig timeInForceTimerConfig) {
        return (expiryHandler) -> new DefaultTimeInForceTimer(timerController.timerScheduler(), timeInForceTimerConfig, expiryHandler);
    }

    @Bean
    public Timer.Factory timerFactory(final TimerController timerController) {
        return (expiryHandler) -> new DefaultTimer(timerController.timerScheduler(), expiryHandler);
    }

    @Bean
    public ParentOrderValidator.ErrorHandler parentOrderValidationErrorHandler() {
        return new DefaultValidationErrorHandler();
    }

    @Bean
    public ParentOrderValidatorRepository parentOrderValidatorRepository(final ParentOrderValidator.ErrorHandler parentOrderValidationErrorHandler,
                                                                         final InstrumentRepository instrumentRepository) {
        return new DefaultParentOrderValidatorRepository(parentOrderValidationErrorHandler,
                new EMatchParentOrderValidator(parentOrderValidationErrorHandler, instrumentRepository),
                new MidParentOrderValidator(parentOrderValidationErrorHandler, instrumentRepository),
                new DefaultParentOrderValidator(parentOrderValidationErrorHandler, instrumentRepository)
        );
    }

    @Bean
    public ParentOrderRepository.WithInit parentOrderRepository(final TimerController timerController, final InstrumentRepository instrumentRepository) {
        final ParentOrderRepository.Mutable mutableActiveParentOrderRepository = new MutableParentOrderRepository();
        final DefaultParentOrderFactory defaultParentOrderFactory = new DefaultParentOrderFactory(
                DefaultParentOrder.STRATEGY_NAME,
                mutableActiveParentOrderRepository,
                100, instrumentRepository);

        final MidParentOrderFactory midParentOrderFactory = new MidParentOrderFactory(
                MidParentOrder.STRATEGY_NAME,
                mutableActiveParentOrderRepository,
                100,
                timerController.timerScheduler(),
                instrumentRepository,
                new StaticVenueTimeInForceLookup());

        final EMatchParentOrderFactory ematchParentOrderFactory = new EMatchParentOrderFactory(
                EMatchParentOrder.STRATEGY_NAME,
                mutableActiveParentOrderRepository,
                100,
                timerController.timerScheduler(), instrumentRepository);

        final ParentOrderFactory parentOrderFactory = ParentOrderFactory.of(defaultParentOrderFactory, midParentOrderFactory, ematchParentOrderFactory);

        return new DefaultParentOrderRepository(parentOrderFactory, mutableActiveParentOrderRepository);
    }

    @Bean
    public ChildOrderRepository childOrderRepository(final TimeInForceTimer.Factory timeInForceTimerFactory, final VenueInstrumentRepository venueInstrumentRepository) {
        return new ChildOrderRepository(300, timeInForceTimerFactory, venueInstrumentRepository);
    }

    @Bean
    public VenueRepository venueRepository(@Lazy final VenueSubscriber.Async venueSubscriber,
                                           final Timer.Factory timerFactory,
                                           final @Value("${venue.timeout.millis}") int timoutMillis) {
        return new DefaultVenueRepository(venueSubscriber, timerFactory, timoutMillis);
    }

    @Bean
    public InstrumentRepository instrumentRepository(final @Value("#{${cross.symbol.to.driving.symbols:T(java.util.Collections).emptyMap()}}")  Map<String, List<String>> crossSymbolDrivingSymbols) {
        return new DefaultInstrumentRepository(crossSymbolDrivingSymbols);
    }

    @Bean
    public VenueInstrumentRepository venueInstrumentRepository(final InstrumentRepository instrumentRepository,
                                                               final VenueRepository venueRepository,
                                                               final PricingClient<MutableSbeMessage> pricingClient,
                                                               @Value("${initial.book.entries}") final int initialBookEntries) {
        return new DefaultVenueInstrumentRepository(instrumentRepository, venueRepository, initialBookEntries,
                enabledVenueInstrument -> pricingClient.pricingSubscriber().subscribe(enabledVenueInstrument.requestKey()),
                disabledVenueInstrument -> pricingClient.pricingSubscriber().unsubscribe(disabledVenueInstrument.requestKey()));
    }

    @Bean
    public UserRepository userRepository() {
        return new DefaultUserRepository();
    }

    @Bean
    public UserSessionRepository userSessionRepository(final Timer.Factory timerFactory,
                                                       final @Value("${user.session.timeout.millis}") int timoutMillis) {
        return new DefaultUserSessionRepository(timerFactory, timoutMillis);
    }

    @Bean 
    public Health health(final TimerController timerController) {
        return new Health(timerController.timerScheduler(), 3000);
    }

    @Bean
    public PricingFeed.OpenOrdersObserver pricingFeedOpenOrders() {
        return new DefaultOpenOrdersObserver();
    }

    @Bean
    public PricingFeed.Request pricingFeedRequest(final PricingFeed.OpenOrdersObserver pricingFeedOpenOrders,
                                                  final Queue<InstrumentKey> pricingFeedRequestQueue) {
        final InstrumentKey.Lookup instrumentKeyLookup = new DefaultInstrumentKeyLookup();

        return (instrumentId, forceSnapshot) -> {
            if (forceSnapshot || pricingFeedOpenOrders.count(instrumentId) > 0) {
                pricingFeedRequestQueue.offer(instrumentKeyLookup.lookup(instrumentId));
            }
        };
    }

    @Bean
    public MutableLong idGeneratorOffset() {
        return new MutableLong();
    }

    @Bean
    public EventApplierFactory eventApplierFactory(final SnapshotFullRefreshHandler snapshotterFullRefreshHandler,
                                                   final UpdatablePrecisionClock eventPrecisionClock,
                                                   final ParentOrderRepository.WithInit parentOrderRepository,
                                                   final ChildOrderRepository childOrderRepository,
                                                   final TimerController timerController,
                                                   final VenueRepository venueRepository,
                                                   final InstrumentRepository instrumentRepository,
                                                   final VenueInstrumentRepository venueInstrumentRepository,
                                                   final UserRepository userRepository,
                                                   final UserSessionRepository userSessionRepository,
                                                   final MutableLong idGeneratorOffset,
                                                   final Health health,
                                                   @Value("${messaging.compId}") final String compId,
                                                   final Firewall inboundFirewall,
                                                   final PricingFeed.OpenOrdersObserver pricingFeedOpenOrders) {
        return new DefaultEventApplierFactory(snapshotterFullRefreshHandler,
                parentOrderRepository,
                childOrderRepository,
                venueRepository,
                instrumentRepository,
                venueInstrumentRepository,
                userRepository,
                userSessionRepository,
                idGeneratorOffset,
                eventPrecisionClock,
                timerController,
                health,
                compId,
                inboundFirewall,
                pricingFeedOpenOrders);
    }


    @Bean
    public CommandExecutorFactory commandExecutorFactory(final UpdatablePrecisionClock eventPrecisionClock,
                                                         final ParentOrderRepository.WithInit parentOrderRepository,
                                                         final ChildOrderRepository childOrderRepository,
                                                         final SnapshotFullRefreshHandler snapshotterFullRefreshHandler,
                                                         final Function<MessageConsumer, TradingEncoderSupplier> tradingEncoderSupplierFactory,
                                                         final Function<MessageConsumer, SorEncoderSupplier> sorEncoderSupplierFactory,
                                                         final TimerController timerController,
                                                         final VenueRepository venueRepository,
                                                         final UserRepository userRepository,
                                                         final InstrumentRepository instrumentRepository,
                                                         final VenueInstrumentRepository venueInstrumentRepository,
                                                         final ParentOrderValidatorRepository parentOrderValidatorRepository,
                                                         final UserSessionRepository userSessionRepository,
                                                         final MutableLong idGeneratorOffset,
                                                         @Value("${messaging.compId}") final String compId,
                                                         @Value("${fox.processor.source.id}") final int processorSourceId,
                                                         final Firewall inboundFirewall,
                                                         final PricingFeed.Request pricingFeedRequest) {
        return new DefaultCommandExecutorFactory(
                eventPrecisionClock,
                parentOrderRepository,
                childOrderRepository,
                venueRepository,
                userRepository,
                userSessionRepository,
                parentOrderValidatorRepository,
                instrumentRepository,
                venueInstrumentRepository,
                idGeneratorOffset,
                snapshotterFullRefreshHandler,
                tradingEncoderSupplierFactory,
                sorEncoderSupplierFactory,
                timerController,
                compId,
                processorSourceId,
                inboundFirewall,
                pricingFeedRequest);
    }

    @Bean
    public EventLoopService processorEventLoopService(@Value("${processor.finalisation.timeout.seconds}") int finalisationTimeoutSeconds,
                                                      final ExecutionQueue executionQueue,
                                                      final Supplier<IdleStrategy> eventSourcingIdleStrategyFactory,
                                                      final TimerController timerController) {
        return new EventLoopService("EventProcessor",
                finalisationTimeoutSeconds, TimeUnit.SECONDS,
                eventSourcingIdleStrategyFactory.get(),
                EventLoopStep.whenFinalisationNotRequired(() -> executionQueue.executorStep().perform()),
                EventLoopStep.whenFinalisationNotRequired(timerController.eventLoopStep()));
    }
}
