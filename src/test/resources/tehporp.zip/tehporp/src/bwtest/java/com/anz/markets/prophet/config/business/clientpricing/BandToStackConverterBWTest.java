package com.anz.markets.prophet.config.business.clientpricing;

import com.anz.markets.prophet.pricer.BandToStackConverter;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BandToStackConverterBWTest {
    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private static final double[][] VALUES_IN_BANDS = {
            {1, 0.1},
            {3, 0.2},
            {5, 0.2},
            {10, 0.3},
            {15, 0.4},
            {20, 0.5},
            {30, 0.6}};

    private static final double[][] VALUES_IN_STACKS = {
            {1, Double.NaN},
            {2, Double.NaN},
            {2, Double.NaN},
            {5, Double.NaN},
            {5, Double.NaN},
            {5, Double.NaN},
            {10, Double.NaN},
    };

    @Test
    public void testAAA_Warmup() {
        shouldCreateStackFromBand();
    }

    @Test
    public void testBandToStackConverter() {
        helper.testAllocationNotExceeded(
                this::shouldCreateStackFromBand,
                0 // no allocation!
        );
    }

    private void shouldCreateStackFromBand() {
        for (int i = 0; i < REPS; i++) {
            BandToStackConverter.bandedToStackConverter(VALUES_IN_BANDS, VALUES_IN_STACKS);
        }
    }
}
