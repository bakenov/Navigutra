#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

kdbstats_dstpfx_filesize - Plugin to monitor the size of KDB file DS_TP_FX during the day    

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Yuri Litvinov (yuri.litvinov@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=kdbstats
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title KDB TP FX intraday file size'
    #echo 'graph_args --upper-limit 15000000000'
    echo 'graph_category kdbstats'
    echo 'graph_scale no'

    echo 'filesize.label DS_TP_FX intraday size'
    echo 'filesize.draw LINE2'    

    exit 0
fi
        

KDB_PIDFILE=/data/kdb/logs/pid/DS_TP_FX.1.pid

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ ! -f ${KDB_PIDFILE} ] ; then
        echo "filesize.value U"
        exit 0
fi

KDB_PID=$(cat ${KDB_PIDFILE})
if [ ! -d /proc/${KDB_PID} ] ; then
        echo "filesize.value U"
        exit 0
fi


LOGFILE="/data/kdb/DeltaStreamData/DS_TP_FX"

if [ -f "$LOGFILE" ]; then


filesizeKB=`du -k -L $LOGFILE | tr -s ' ' | awk '{ print $1 }'`
echo "filesize.value" $((filesizeKB*1024))

else
         echo "filesize.value U"
fi

