package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.tools.FixToDTO;

import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.datamodel.DefaultExecutionReport;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.parsers.MessageParser;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingEncoderSupplier;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class HspExecutionReportHandlerTest {
    private static final String SENDER_COMP_ID = "GB:DBS";
    private static final String COMP_ID = "GB:lg-hsp";
    private static final String SPOT_SYMBOL = "USD/SGD";
    private static final String CURRENCY = "USD";
    private static final String SPOT_NORMALISED_SYMBOL = "USDSGD";
    private static final String SETTL_DATE = "20181116";
    private static final long CURRENT_TIME = 34523453;

    private HspExecutionReportHandler hspExecutionReportHandler;
    private TradingEncoderSupplier encoderSupplier;
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport executionReport;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    @Before
    public void setUp() throws Exception {
        encoderSupplier = new PojoTradingEncoderSupplier(m -> executionReport = (com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport)m);
        hspExecutionReportHandler = new HspExecutionReportHandler(
                encoderSupplier,
                precisionClock,
                SENDER_COMP_ID,
                COMP_ID,
                Venue.HSP,
                System::currentTimeMillis, sourceSequencer);

        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
    }

    @Test
    public void acceptExecutionReportMessage_SPOT_FILL() throws Exception {
        //when
        hspExecutionReportHandler.accept(executionReportMessageFromFix_SPOT_FILL());

        //then
        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport.Body body = executionReport.body;

        assertThat(body.senderCompId, is(COMP_ID));
        assertThat(body.marketId, is(Venue.HSP.name()));
        assertThat(body.symbol, is(SPOT_NORMALISED_SYMBOL));
        assertThat(body.securityType, is(SecurityType.FXSPOT));
        assertThat(body.ordStatus, is(OrderStatus.FILLED));
        assertThat(body.side, is(Side.SELL));
        assertThat(body.currency, is(CURRENCY));
        assertThat(body.settlDate.format(DateTimeFormatter.ofPattern("YYYYMMdd")), is(SETTL_DATE));
        assertThat(body.price, is(108.862));
        assertThat(body.avgPx, is(108.863));
        assertThat(body.lastPx, is(108.863));
        assertThat(body.lastQty, is(1000000.0));
        assertThat(body.cumQty, is(1000000.0));
        assertThat(body.leavesQty, is(0.0));
        assertThat(executionReport.parties.size(), is(2));
        assertThat(executionReport.parties.get(0).partyRole, is(PartyRole.SETTLEMENT_ACCOUNT));
        assertThat(executionReport.parties.get(0).partyId, is("ANZBANK2"));
        assertThat(executionReport.parties.get(1).partyRole, is(PartyRole.CONTRA_FIRM));
        assertThat(executionReport.parties.get(1).partyId, is("AIG"));
    }

    private ExecutionReport executionReportMessageFromFix_SPOT_FILL() throws Exception {
        final String executionReportFixMessage = ("8=FIX.4.2|9=0382|35=8|49=HSFX-FIX-BRIDGE|56=ny5anz|57=ny5anz_fix|34=48|52=20190130-22:53:44.012|1=ANZBANK2|6=108.863|11=1548823159183|14=1000000|15=USD|17=TRD_32857|20=0|" +
                "31=108.863|32=1000000|37=20335322303611|38=1000000|39=2|44=108.862|54=2|55=USD/JPY|58=passive is firm|59=3|60=20190130-22:53:44.012|64=20190204|75=20190131|76=Y|119=1000000|120=USD|150=F|151=0|167=FOR|192=108863000|382=1|375=AIG|10=093|")
                .replace("55=USD/JPY", "55="+SPOT_SYMBOL)
                .replace("64=20190204", "64="+SETTL_DATE)
                .replace('|', (char) 0x01);

        final ExecutionReport executionReport = new DefaultExecutionReport();
        final FixToDTO fixToDTO = new FixToDTO(new MessageParser(), MessageNotifier.class);
        fixToDTO.parse(Bytes.from(executionReportFixMessage), sht -> sht.copyTo(executionReport));
        return executionReport;
    }
}