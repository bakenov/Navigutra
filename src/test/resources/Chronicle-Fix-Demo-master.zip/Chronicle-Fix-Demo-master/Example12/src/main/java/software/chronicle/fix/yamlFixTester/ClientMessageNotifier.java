package software.chronicle.fix.yamlFixTester;

import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.WireIn;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.Logon;
import software.chronicle.generated.code.messages.MessageNotifier;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class ClientMessageNotifier implements MessageNotifier, Marshallable, Demarshallable {

    private transient CountDownLatch awaitTillConnected;
    private transient CountDownLatch waitTillLoggedInReceivedOnClient;

    private ClientMessageNotifier(WireIn wireIn) {
        waitTillLoggedInReceivedOnClient = new CountDownLatch(1);
        awaitTillConnected = new CountDownLatch(1);
    }

    @Override
    public MessageGenerator onExecutionReport(ExecutionReport executionReport) {
        return null;
    }

    public boolean awaitTillConnected(final long timeout, final TimeUnit timeUnit) throws InterruptedException {
        return awaitTillConnected.await(timeout, timeUnit);
    }

    @Override
    public void onStartOfConnection(SessionID sessionID) {
        awaitTillConnected.countDown();
    }

    @Override
    public void onLogon(FixSessionHandler session, Logon logon) {
        // the acknowledgement of the logon
        waitTillLoggedInReceivedOnClient.countDown();
    }

    public void reset() {
        waitTillLoggedInReceivedOnClient = new CountDownLatch(1);
    }

    public boolean awaitTillLoggedIn(int timeout, TimeUnit timeUnit) throws InterruptedException {
        return waitTillLoggedInReceivedOnClient.await(timeout, timeUnit);
    }

}
