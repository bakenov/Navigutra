package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.HeaderPredicates;
import com.anz.markets.prophet.chronicle.config.PauserFactory;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.event.EndEventHopAppender;
import com.anz.markets.prophet.status.Context;
import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.threads.Pauser;

import java.io.IOException;
import java.util.function.Consumer;

public class LegacyChronicleReaderConfig implements ReaderConfig {
    public static final int START_INDEX = -1;
    public String chroniclePath;
    public final LegacyChronicleConfig.ChronicleType chronicleType;
    /**
     * Performs in-memory activities on receipt of an event
     */
    public final ChronicleHook startReadHook;
    public final ChronicleHook endReadHook;
    public final ChronicleHook unknownReadHook;
    public final Context.HeaderPredicate headerFilter;
    public final Pauser pauser;
    public final StartAt startAt;
    public final LegacyChronicleConfig.ReadWrite readOnly;
    public final long startPosition;
    public final WaitStrategy waitStrategy;

    private LegacyChronicleReaderConfig(final String chroniclePath,
                                        final LegacyChronicleConfig.ChronicleType chronicleType,
                                        final ChronicleHook startReadHook,
                                        final ChronicleHook endReadHook,
                                        final ChronicleHook unknownReadHook,
                                        final Context.HeaderPredicate headerFilter,
                                        final Pauser pauser,
                                        final StartAt startAt,
                                        final LegacyChronicleConfig.ReadWrite readOnly) {
        this(chroniclePath, chronicleType, startReadHook, endReadHook, unknownReadHook, headerFilter, pauser,
                startAt, readOnly, START_INDEX, WaitStrategy.PAUSE);
    }

    LegacyChronicleReaderConfig(final String chroniclePath,
                                final LegacyChronicleConfig.ChronicleType chronicleType,
                                final ChronicleHook startReadHook,
                                final ChronicleHook endReadHook,
                                final ChronicleHook unknownReadHook,
                                final Context.HeaderPredicate headerFilter,
                                final Pauser pauser,
                                final StartAt startAt,
                                final LegacyChronicleConfig.ReadWrite readOnly,
                                final long startPosition,
                                final WaitStrategy waitStrategy) {
        this.chroniclePath = chroniclePath;
        this.chronicleType = chronicleType;
        this.startReadHook = startReadHook;
        this.endReadHook = endReadHook;
        this.unknownReadHook = unknownReadHook;
        this.headerFilter = headerFilter;
        this.pauser = pauser;
        this.startAt = startAt;
        this.readOnly = readOnly;
        this.startPosition = startPosition;
        this.waitStrategy = waitStrategy;
    }

    public LegacyChronicleReaderConfig(final ReaderConfig config, final String basePath) {
        this(basePath, LegacyChronicleConfig.ChronicleType.INDEXED, config.startReadHook(), config.endReadHook(), config.unknownReadHook(),
                config.headerFilter(), config.pauser(), config.startAt(), LegacyChronicleConfig.ReadWrite.READ_WRITE, config.startPosition(), config.waitStrategy());
    }

    /**
     * Used for testing and tools only
     */
    public static LegacyChronicleReaderConfig readOnly(final String chroniclePath,
                                                       final LegacyChronicleConfig.ChronicleType chronicleType) {
        return readOnly(chroniclePath, chronicleType, StartAt.START);
    }

    public static LegacyChronicleReaderConfig readOnly(final String chroniclePath,
                                                       final LegacyChronicleConfig.ChronicleType chronicleType,
                                                       final StartAt startAt) {
        return readOnly(chroniclePath, chronicleType, HeaderPredicates.FILTER_ALLOW_ALL, startAt);
    }

    /**
     * java.lang.IllegalStateException: java.io.IOException: Channel not open for writing - cannot extend file to required size
     * TODO: get to the bottom of why a r/o chronicle tries to extend a file
     */
    public static LegacyChronicleReaderConfig readOnlyNotReallyUntilWeWorkOutTheProblem(final String chroniclePath,
                                                                                        final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.DO_NOTHING, ChronicleHook.DO_NOTHING, ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                PauserFactory.create(), StartAt.START, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    public static LegacyChronicleReaderConfig readOnly(final String chroniclePath,
                                                       final LegacyChronicleConfig.ChronicleType chronicleType,
                                                       final Context.HeaderPredicate headerFilter,
                                                       final StartAt startAt) {
        return readOnly(chroniclePath, chronicleType, headerFilter, startAt, START_INDEX);
    }

    public static LegacyChronicleReaderConfig readOnly(final String chroniclePath,
                                                       final LegacyChronicleConfig.ChronicleType chronicleType,
                                                       final Context.HeaderPredicate headerFilter,
                                                       final StartAt startAt,
                                                       final long startPosition) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.DO_NOTHING, ChronicleHook.DO_NOTHING, ChronicleHook.unknownMessageCounter(), headerFilter,
                PauserFactory.create(), startAt, LegacyChronicleConfig.ReadWrite.READ_ONLY, startPosition, WaitStrategy.PAUSE);
    }

    /**
     * reader for core.
     */
    public static LegacyChronicleReaderConfig core(final String chroniclePath,
                                                   final LegacyChronicleConfig.ChronicleType chronicleType) {
        return core(chroniclePath, chronicleType, START_INDEX, true, () -> { /**/ });
    }

    public static LegacyChronicleReaderConfig core(final String chroniclePath,
                                                   final LegacyChronicleConfig.ChronicleType chronicleType,
                                                   final long startIndex,
                                                   final EndEventHopAppender hopAppender) {
        return core(chroniclePath, chronicleType, startIndex, true, hopAppender);
    }

    public static LegacyChronicleReaderConfig core(final String chroniclePath,
                                                   final LegacyChronicleConfig.ChronicleType chronicleType,
                                                   final long startIndex,
                                                   final boolean usePauser,
                                                   final EndEventHopAppender hopAppender) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.START_READ, ChronicleHook.endEventHop(hopAppender), ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                usePauser ? PauserFactory.create() : PauserFactory.none(), StartAt.INDEX, LegacyChronicleConfig.ReadWrite.READ_WRITE, startIndex, WaitStrategy.PAUSE);
    }

    /**
     * Use this config to read from StarfishIn output, i.e. chronicle.in
     */
    public static LegacyChronicleReaderConfig core(final String chroniclePath,
                                                   final LegacyChronicleConfig.ChronicleType chronicleType,
                                                   final long startIndex,
                                                   final boolean usePauser,
                                                   final Consumer<EndEvent> endEventSink) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.START_READ, ChronicleHook.endEventInception(endEventSink), ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                usePauser ? PauserFactory.create() : PauserFactory.none(), StartAt.INDEX, LegacyChronicleConfig.ReadWrite.READ_WRITE, startIndex, WaitStrategy.PAUSE);
    }

    public static LegacyChronicleReaderConfig core(String inPath, boolean pauser, boolean replay, boolean end, final Consumer<EndEvent> endEventSink) {
        return new LegacyChronicleReaderConfig(inPath, LegacyChronicleConfig.ChronicleType.INDEXED, ChronicleHook.START_READ,
                ChronicleHook.endEventInception(endEventSink), ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                pauser ? PauserFactory.create() : PauserFactory.none(), replay ? StartAt.START : StartAt.END, LegacyChronicleConfig.ReadWrite.READ_WRITE, 0, end ? WaitStrategy.STOP_ON_STALL : WaitStrategy.PAUSE);
    }


    /**
     * metrics reader.
     */

    public static LegacyChronicleReaderConfig metrics(final String chroniclePath,
                                                      final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.DO_NOTHING, ChronicleHook.DO_NOTHING, ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                PauserFactory.create(), StartAt.START, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    /**
     * starfish out readers
     */
    public static LegacyChronicleReaderConfig starfishOut(final String chroniclePath,
                                                          final LegacyChronicleConfig.ChronicleType chronicleType,
                                                          final long allowableLagFromRealTimeMS,
                                                          final EndEventHopAppender hopAppender) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.START_READ, ChronicleHook.endEventHop(hopAppender), ChronicleHook.unknownMessageCounter(), new HeaderPredicates.TimelyDataFilter(allowableLagFromRealTimeMS),
                PauserFactory.create(), StartAt.END, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    /**
     * StartfishIn reads from a chronicle from which the integration layer has populated with data from datafabric.
     */
    public static LegacyChronicleReaderConfig fromDatafabric(final String chroniclePath,
                                                             final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.START_READ, ChronicleHook.DO_NOTHING, ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                PauserFactory.create(), StartAt.END, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    /**
     * perfTest chronicle-in read only reader. This will spin waiting for header.processedCoreTimeStampNS to be written
     */
    public static LegacyChronicleReaderConfig perfTestChronicleInReader(final String chroniclePath,
                                                                        final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType,
                ChronicleHook.DO_NOTHING, ChronicleHook.DO_NOTHING, ChronicleHook.unknownMessageCounter(), HeaderPredicates.FILTER_ALLOW_ALL,
                PauserFactory.create(), StartAt.START, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    public Chronicle createChronicle() throws IOException {
        return LegacyChronicleConfig.createChronicle(chroniclePath, chronicleType, readOnly);
    }

    @Override
    public long startPosition() {
        return startPosition;
    }

    @Override
    public StartAt startAt() {
        return startAt;
    }

    @Override
    public WaitStrategy waitStrategy() {
        return waitStrategy;
    }

    @Override
    public net.openhft.chronicle.threads.Pauser pauser() {
        return pauser;
    }

    @Override
    public ChronicleHook startReadHook() {
        return startReadHook;
    }

    @Override
    public ChronicleHook endReadHook() {
        return endReadHook;
    }

    @Override
    public ChronicleHook unknownReadHook() {
        return unknownReadHook;
    }

    @Override
    public Context.HeaderPredicate headerFilter() {
        return headerFilter;
    }

    @Override
    public ChronicleObjectReader chronicleObjectReader() {
        // NOTE: Legacy CQ3 code
        throw new UnsupportedOperationException();
    }

    @Override
    public RingBuffer ringBuffer() {
        throw new UnsupportedOperationException();
    }

    @Override
    public int tailerId() {
        throw new UnsupportedOperationException();
    }

    @Override
    public String toString() {
        return "LegacyChronicleReaderConfig{" +
                "chroniclePath='" + chroniclePath + '\'' +
                ", chronicleType=" + chronicleType +
                ", startReadHook=" + startReadHook +
                ", endReadHook=" + endReadHook +
                ", unknownReadHook=" + unknownReadHook +
                ", headerFilter=" + headerFilter +
                ", pauser=" + pauser +
                ", startAt=" + startAt +
                ", startPosition=" + startPosition +
                ", readOnly=" + readOnly +
                ", waitStrategy=" + waitStrategy +
                '}';
    }
}
