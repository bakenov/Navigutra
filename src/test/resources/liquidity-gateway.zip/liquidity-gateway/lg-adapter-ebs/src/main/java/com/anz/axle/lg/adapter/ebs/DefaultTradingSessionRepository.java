package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradingSessionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class DefaultTradingSessionRepository implements TradingSessionRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultTradingSessionRepository.class);

    private final Map<String, TradingSession> tradingSessionIdMap = new HashMap<>();
    private final Map<String, TradingSession> tradingSessionTagMap = new HashMap<>();

    @Override
    public TradingSession addOrUpdate(final TradingSession tradingSession) {
        if (tradingSession != null) {
            LOGGER.info("Add to cache {}", tradingSession);
            tradingSessionIdMap.put(tradingSession.tradingSessionID(), tradingSession);
            tradingSessionTagMap.put(tradingSession.tradingSessionTag(), tradingSession);
        }
        return tradingSession;
    }

    @Override
    public TradingSession updateStatus(final TradingSessionStatus tradingSessionStatus) {
        final TradingSession tradingSession = findByTradingSessionID(tradingSessionStatus.tradingSessionID());
        if (tradingSession != null) {
            tradingSession.tradingSessionStatus(tradingSessionStatus.tradSesStatus());
            tradingSession.valuationDateTime(tradingSessionStatus.valuationDateTime());
            LOGGER.info("Updated {} to {} valuationDateTime={}", tradingSession.tradingSessionTag(), tradingSessionStatus.text(), tradingSessionStatus.valuationDateTime());
        }

        return tradingSession;
    }

    @Override
    public TradingSession findByTradingSessionID(final String tradingSessionID) {
        return tradingSessionIdMap.get(tradingSessionID);
    }

    @Override
    public TradingSession findByTradingSessionTag(final String tradingSessionTag) {
        return tradingSessionTagMap.get(tradingSessionTag);
    }

    @Override
    public Collection<TradingSession> tradingSessions() {
        return tradingSessionIdMap.values();
    }

    @Override
    public void reset() {
        tradingSessionIdMap.clear();
        tradingSessionTagMap.clear();
    }
}
