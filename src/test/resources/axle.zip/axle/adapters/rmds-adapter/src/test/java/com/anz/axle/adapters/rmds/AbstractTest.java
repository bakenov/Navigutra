package com.anz.axle.adapters.rmds;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.transaction.annotation.Transactional;

import com.anz.axle.datafabric.client.pricing.ForwardPointsQuotePageDAO;

@ContextConfiguration(locations = {"classpath:rmds-applicationContext.xml", "classpath:rmds-applicationContext-test.xml"})
@Transactional
@Rollback
public abstract class AbstractTest extends AbstractJUnit4SpringContextTests {

    @Autowired
    protected ForwardPointsQuotePageDAO forwardPointsQuotePageDAO;
}
