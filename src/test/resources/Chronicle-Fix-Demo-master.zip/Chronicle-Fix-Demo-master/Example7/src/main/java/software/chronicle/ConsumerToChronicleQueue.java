package software.chronicle;

import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.AbstractMarshallable;
import net.openhft.chronicle.wire.DocumentContext;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog.ReadWrite;
import software.chronicle.generated.code.MessageManifest;

import java.util.function.Consumer;

public class ConsumerToChronicleQueue extends AbstractMarshallable implements Consumer<FixLog> {

    private final SingleChronicleQueue log;

    public ConsumerToChronicleQueue() {
        log = SingleChronicleQueueBuilder.binary("log").build();
    }

    @Override
    public void accept(FixLog fixLog) {
        // this consumer is called for all incoming and outgoing FIX messages.
        // It can perform processing synchronously (on the FIX engine's main
        // thread) or else record the message for processing asynchronously.
        //
        // In this case we write the message to a chronicle queue which will
        // ensure that the message is persisted and async processing can stop
        // and restart, or be run from a separate process.

        if (fixLog.rw() == ReadWrite.R) {
            // incoming

            // msgType is not set when rw == R
            record(fixLog);
        } else {
            // outgoing

            // fixLog is fully populated so can filter
            if (fixLog.msgType() == MessageManifest.ExecutionReport) {
                record(fixLog);
            }
        }
    }

    private void record(FixLog fixLog) {
        try (@NotNull DocumentContext documentContext = log.acquireAppender().writingDocument()) {
            documentContext.wire().getValueOut().marshallable(fixLog);
        }
    }
}