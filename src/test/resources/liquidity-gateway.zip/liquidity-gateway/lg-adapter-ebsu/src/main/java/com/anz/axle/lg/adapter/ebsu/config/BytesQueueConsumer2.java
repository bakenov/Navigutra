package com.anz.axle.lg.adapter.ebsu.config;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.io.IORuntimeException;
import net.openhft.chronicle.queue.ChronicleQueue;
import net.openhft.chronicle.queue.ExcerptAppender;
import net.openhft.chronicle.queue.RollCycle;
import net.openhft.chronicle.wire.DocumentContext;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.WireIn;
import org.jetbrains.annotations.NotNull;
import software.chronicle.ebs.util.StreamType;
import software.chronicle.itch.staticcode.ItchLog;

import java.io.Closeable;
import java.io.IOException;
import java.util.Objects;
import java.util.function.Consumer;

/**
 * Replacement for OOTB BytesQueueConsumer with additional functionality for RollCycle
 */
public class BytesQueueConsumer2 implements Consumer<ItchLog>, Marshallable, Closeable {
    private transient ChronicleQueue queue;
    private String dir = "log";
    private StreamType streamType;
    private RollCycle rollCycle;

    public BytesQueueConsumer2(@NotNull final String dir, @NotNull final StreamType streamType, @NotNull final RollCycle rollCycle) {
        this.streamType = Objects.requireNonNull(streamType);
        this.dir = Objects.requireNonNull(dir);
        this.rollCycle = Objects.requireNonNull(rollCycle);
        this.createQueue();
    }

    public void readMarshallable(final WireIn wire) throws IORuntimeException {
        final String dirFromWire = wire.read("dir").text();
        if (dirFromWire != null) {
            this.dir = dirFromWire;
        }

        this.createQueue();
    }

    protected void createQueue() {
        if (this.queue != null) {
            this.queue.close();
        }

        this.queue = ChronicleQueue.singleBuilder(this.dir).rollCycle(rollCycle).build();
    }

    public void accept(final ItchLog log) {
        final Bytes msg = log.msg();
        final ExcerptAppender excerptAppender = queue.acquireAppender();
        try (DocumentContext dc = excerptAppender.writingDocument()) {
            Bytes<?> bytes = dc.wire().bytes();
            bytes.writeByte((byte) streamType.ordinal());
            bytes.writeLong(System.currentTimeMillis());
            bytes.write(msg);
        }
    }

    public void close() throws IOException {
        this.queue.close();
    }
}

