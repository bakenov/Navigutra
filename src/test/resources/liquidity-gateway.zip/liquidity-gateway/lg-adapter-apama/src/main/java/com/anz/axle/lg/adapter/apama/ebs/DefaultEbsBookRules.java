package com.anz.axle.lg.adapter.apama.ebs;

import java.util.HashMap;
import java.util.Map;

import com.anz.markets.efx.ngaro.api.SecurityType;

public final class DefaultEbsBookRules implements EbsBookRules {

    private static final int INDEX_PRICE_DEPTH = 0;
    private static final int INDEX_PRICE_RANGE_INCREMENT = 1;
    private static final int INDEX_PRICE_RANGE_STEPS = 2;

    private final Map<String, Config> fxSpotConfigBySymbol;
    private final Map<String, Config> fxNdfConfigBySymbol;

    public DefaultEbsBookRules(final Map<String, double[]> fxSpotBookRules, final Map<String, double[]> fxNdfBookRules) {
        this.fxSpotConfigBySymbol = toConfigMap(fxSpotBookRules);
        this.fxNdfConfigBySymbol = toConfigMap(fxNdfBookRules);
    }

    private Map<String, Config> configMap(final SecurityType securityType) {
        switch (securityType) {
            case FXSPOT: return fxSpotConfigBySymbol;
            case FXNDF: return fxNdfConfigBySymbol;
            default: throw new IllegalStateException("Unsupported security type " + securityType);
        }
    }

    @Override
    public Config configFor(final String symbol, final SecurityType securityType) {
        final Config config = configMap(securityType).get(symbol);
        if (config != null) {
            return config;
        }
        throw new IllegalArgumentException("No BookRule configuration found for " + symbol);
    }

    private Map<String, Config> toConfigMap(final Map<String, double[]> bookRules) {
        final Map<String, Config> config = new HashMap<>(bookRules.size(), 0.67f);
        for (final String symbol : bookRules.keySet()) {
            config.put(symbol, toConfig(symbol, bookRules.get(symbol)));
        }
        return config;
    }

    private Config toConfig(final String symbol, final double[] depthIncrementSteps) {
        if (depthIncrementSteps == null) {
            throw new IllegalArgumentException("bookRules is null for " + symbol);
        }
        if (depthIncrementSteps.length != 3) {
            throw new IllegalArgumentException("Expected 3 values (PriceDepth, PriceDepthRange.Increment, PriceDepthRange.Steps) in bookRules but found " +
                    depthIncrementSteps.length + " for " + symbol);
        }
        final int depth = toIntegral(depthIncrementSteps, INDEX_PRICE_DEPTH, "PriceDepth", symbol);
        final double priceRangeIncrement = depthIncrementSteps[INDEX_PRICE_RANGE_INCREMENT];
        final int priceRangeSteps = toIntegral(depthIncrementSteps, INDEX_PRICE_RANGE_STEPS, "PriceDepthRange.Steps", symbol);
        return new DefaultConfig(depth, priceRangeIncrement, priceRangeSteps);
    }

    private static int toIntegral(final double[] depthIncrementSteps, int index, final String valueName, final String symbol) {
        final double value = depthIncrementSteps[index];
        final int integral = (int)value;
        if (integral != value) {
            throw new IllegalArgumentException(valueName + " boolRule value with index=" + index +
                    " must be integral but was " + value + " for " + symbol);
        }
        return integral;
    }

    public static class DefaultConfig implements Config {

        private final int depth;
        private final double priceRangeIncrement;
        private final int priceRangeSteps;

        public DefaultConfig(final int depth, final double priceRangeIncrement, final int priceRangeSteps) {
            this.depth = depth;
            this.priceRangeIncrement = priceRangeIncrement;
            this.priceRangeSteps = priceRangeSteps;
        }
        @Override
        public int depth() {
            return depth;
        }

        @Override
        public double priceRangeIncrement() {
            return priceRangeIncrement;
        }

        @Override
        public int priceRangeSteps() {
            return priceRangeSteps;
        }

        @Override
        public String toString() {
            return "DefaultConfig{" +
                    "depth=" + depth +
                    ", priceRangeIncrement=" + priceRangeIncrement +
                    ", priceRangeSteps=" + priceRangeSteps +
                    '}';
        }
    }
}
