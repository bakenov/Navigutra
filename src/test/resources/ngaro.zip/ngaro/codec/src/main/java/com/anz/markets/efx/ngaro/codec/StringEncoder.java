package com.anz.markets.efx.ngaro.codec;

import java.util.function.BiFunction;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;

/**
 * Encoder for string values.
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 */
public interface StringEncoder<E> {

    E encodeEmpty();

    E encodeFrom(StringDecoder stringDecoder);

    <S> E encode(S source, ByteReader<? super S> reader, int sourceOffset, int length);

    E encodeLong(final long value);

    default E encode(final AsciiString source) {
        return encode(source, 0, source.length());
    }

    default E encode(final AsciiString source, int sourceOffset, int length) {
        return encode(source, ByteReader.ASCII_STRING, sourceOffset, length);
    }

    default E encode(final CharSequence source) {
        return encode(source, 0, source.length());
    }

    default E encodeNullable(final CharSequence source) {
        return source == null ? encodeEmpty() : encode(source);
    }

    /**
     * Transforms and encodes the given {@code value} using the specified {@code transform}.
     *
     * @param transform a transformer from value type to string encoder
     * @return the enclosing encoder
     * @see EnumTransforms#fromEnum()
     * @see EnumTransforms#fromEnumNullable()
     */
    default <T> E encode(final T value, final BiFunction<? super T, ? super StringEncoder<E>, ? extends E> transform) {
        return transform.apply(value, this);
    }

    default E encode(CharSequence source, int sourceOffset, int length) {
        return encode(source, ByteReader.CHAR_SEQUENCE, sourceOffset, length);
    }

    default <S> E encode(final S source, final ByteReader<? super S> reader, final int length) {
        return encode(source, reader, 0, length);
    }
}
