package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;
import java.util.function.Function;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;

public class VenueNewOrderSingleHandler implements NewOrderSingleHandler {
    private final ByteValueCache<String> senderCompIdCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);

    private MessageForwarder messageForwarder;

    public VenueNewOrderSingleHandler() {
    }

    @Override
    public void onBody(final Body body) {
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        final SecurityType securityType = body.securityType();
        final Tenor tenor = body.settlType();
        final long instrumentId = InstrumentKey.instrumentId(symbol, securityType, tenor);
    }

    @Override
    public void messageForwarder(final MessageForwarder messageForwarder) {
        this.messageForwarder = Objects.requireNonNull(messageForwarder);
    }
}
