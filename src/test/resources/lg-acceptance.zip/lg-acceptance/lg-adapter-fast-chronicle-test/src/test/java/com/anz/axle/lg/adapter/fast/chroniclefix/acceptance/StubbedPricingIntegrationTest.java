package com.anz.axle.lg.adapter.fast.chroniclefix.acceptance;

import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MDEntryType;
import org.fix4j.spec.fix50sp2.fieldtype.MDUpdateAction;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.PricingFixSessionHelper;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.instrumentId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.marketId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.senderCompId;

public class StubbedPricingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StubbedPricingIntegrationTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private MatchingSession pricingServer;
    private PricingFixSessionHelper pricingFixSessionHelper;

    final private String senderCompId = "GB:lg-fast";
    final private Venue marketId = Venue.FAST;
    private static final String FIX_DATA_DICTIONARY_FILE = "conf/FIX42-fast.xml";

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().put("fix4j.default.fix.msg.wait.timeout.ms", "10000");

        pricingFixSessionHelper = new PricingFixSessionHelper("fast", "GB_FASTMATCH_MD_S", "GB_FASTMATCH_MD_T", "FIX.4.2", FIX_DATA_DICTIONARY_FILE);
        pricingServer = pricingFixSessionHelper.createPricingSession();

        application = new Application("lg-fast-chronicle-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        if (pricingServer != null) pricingServer.shutdown();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private Predicate<Object> defaultIncrementalRefreshMessageMatcher() {
        return IncrementalRefreshMatcher.build()
                .body().matches(senderCompId().eq(senderCompId))
                .body().matches(marketId().eq(marketId))
                .body().matches(instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().countAtLeast(1)
                .hops().hasAny()
                .hops().countAtLeast(2);
    }

    private Predicate<Object> emptySnapshotMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().hasNone();
    }


    private final FixMessage defaultIncrementalRefreshFixMessage(String requestId) {
        final String symbol = "AUD/USD";
        final String newEntryId1 = "B#-1388272055";
        final String newEntryQuantityString1 = "16863000000.00";
        final String newEntryPriceString1 = "1.33627";

        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATAINCREMENTALREFRESH.getOrdinal())
                .withField(FieldTypes.MDReqID, requestId)
                .withField(FieldTypes.NoMDEntries, 1)
                .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.NEW.getOrdinal())
                .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
                .withField(FieldTypes.MDEntryID, newEntryId1)
                .withField(FieldTypes.Symbol, symbol)
                .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
                .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
                .build();
    }

    @Test
    public void should_receive_pricing_information_for_the_registered_ccy_pair() throws Exception {

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=AUD/USD");
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataIncrementalRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultIncrementalRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataIncrementalRefresh processed message is available in pricing queue.
        PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                    LOGGER.info(incrementalRefresh.toString());
                    Assert.assertEquals(marketId, incrementalRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), incrementalRefresh.body.instrumentId);
                    Assert.assertEquals(senderCompId, incrementalRefresh.body.senderCompId);
                    Assert.assertNull(incrementalRefresh.body.tradeDate);
                    Assert.assertEquals(1, incrementalRefresh.entries.size());
                    Assert.assertEquals(1, incrementalRefresh.entries.get(0).mdEntryId);
                    Assert.assertEquals(UpdateAction.NEW, incrementalRefresh.entries.get(0).mdUpdateAction);
                    Assert.assertEquals(EntryType.BID, incrementalRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(1.33627, incrementalRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, incrementalRefresh.entries.get(0).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(16863000000.00, incrementalRefresh.entries.get(0).mdEntrySize, 1e-6);
                    Assert.assertEquals(0.0, incrementalRefresh.entries.get(0).minQty, 1e-6);
                    Assert.assertEquals(2, incrementalRefresh.hops.size());
                    Assert.assertEquals("GB:FAST", incrementalRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, incrementalRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(incrementalRefresh.body.sendingTime, incrementalRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, incrementalRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(1).hopMessageId);
                    Assert.assertEquals(acceptanceContext.precisionClock().nanos(), incrementalRefresh.hops.get(1).hopReceivingTime);
                    Assert.assertEquals(acceptanceContext.precisionClock().nanos(), incrementalRefresh.hops.get(1).hopSendingTime);
                }
        });
    }

    @Test
    public void should_send_empty_snapshot_when_marketdata_fix_disconnects() throws Exception {

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=AUD/USD");

        //And the MarketDataIncrementalRefresh is sent to adapter.
        pricingServer.send(defaultIncrementalRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //And the  MarketDataIncrementalRefresh processed message is available in pricing queue.
        final PricingMessage pricingMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println(pricingMessage.toString());
        System.out.println("==============================================================");

        //When Pricing Server is down and disconnected from the adapter
        pricingServer.shutdown();

        //Then empty snapshots are sent from the adapter
        //final PricingMessage pricingSnapShotMessage = acceptanceContext.pricingMessageQueue().poll();
        final PricingMessage pricingSnapshotMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(emptySnapshotMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println(pricingSnapshotMessage.toString());

        System.out.println("==============================================================");
    }

    @Test
    public void should_send_logout_when_shutting_down() throws Exception {

        LOGGER.info("Waiting for Logon...");
        pricingServer.discardUntil("35=V");

        application.stop();

        final FixMessage logoutRequest = pricingServer.discardUntil("35=5");

        System.out.println(logoutRequest.toString());
        System.out.println("==============================================================");
    }

    @Test
    public void market_data_request_rejected() throws Exception {

        //Given MarketDataRequest message received for ccy pair.s
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=AUD/USD");
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataRequestReject is sent to adapter.
        pricingServer.send(pricingFixSessionHelper.marketDataRequestRejectFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then no snapshots are sent from the adapter
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }

    @Test
    public void should_not_send_empty_snapshot_when_not_logged_on() throws Exception {

        //Given pricingServer (venue simulator) is down
        //When adapter is not connected
        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }
}