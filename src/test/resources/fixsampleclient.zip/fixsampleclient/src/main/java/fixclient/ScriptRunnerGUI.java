// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Thread.UncaughtExceptionHandler;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 * This is the primary launcher class for the GUI version of the FixClient
 * application. It is responsible for:
 * <ul>
 * <li>the main() launcher method</li>
 * <li>the GUI layout</li>
 * <li>the high-level actions of the controls</li>
 * <li>enablement of those controls</li>
 * </ul>
 */
public class ScriptRunnerGUI extends JFrame
{
    private static final long                 serialVersionUID        = 1L;

    private static final String               GUI_TITLE               = "D3000 FIX Sample Application";
    private static final int                  GUI_HEIGHT              = 795;
    private static final int                  GUI_WIDTH               = 1051;
    private static final String               DEFAULT_CONFIG_FILE     = "config/quickfix.cfg";
    private static final String               DEFAULT_ICON_IMAGE_FILE = "config/TR.png";

    // TODO change to add/remove rather then loadScript
    // control buttons
    private JButton                           loadScriptButton;
    private JButton                           runButton;
    private JButton                           stopButton;
    private JCheckBox                         statusFollowTailButton;

    // dynamically updated areas
    private JTable                            outgoingMessageTable;
    private JTable                            incomingMessageTable;
    private JTextArea                         statusArea;
    private JTextArea                         scriptArea;
    private String                            scriptPath;
    private final String                      configFileName;
    private MessageFlowDataModel              outgoingMessageDataModel;
    private MessageFlowDataModel              incomingMessageDataModel;
    private final GUIMessageFlowListener      messageFlowListener;

    // used as state management flags
    private transient SwingWorker<Void, Void> scriptRunnerWorker      = null;
    private boolean                           loaded                  = false;

    /**
     * Invoked to display the details of a selected message in a Dialog.
     * 
     * @param table
     */
    private void displayMessageDetailDialog(final JTable table)
    {
        table.getSelectionModel().getLeadSelectionIndex();
        final int selectedRow = table.getSelectedRow();
        final Vector<?> allData = ((DefaultTableModel) table.getModel()).getDataVector();
        final int actualRow = allData.size() - selectedRow - 1;

        final Vector<?> rowData = (Vector<?>) allData.get(actualRow);
        final JDialog dialog = new JDialog(ScriptRunnerGUI.this,
                "Message Data",
                true);
        dialog.setSize(new Dimension(700, 200));
        dialog.setBackground(Color.YELLOW);

        final JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        final StringBuffer buffer = new StringBuffer();
        buffer.append("35-MsgType:").append(rowData.get(0)).append("\n");
        buffer.append("34-MsgSeqNum:").append(rowData.get(1)).append("\n");
        buffer.append("11-ClOrdId:").append(rowData.get(2)).append("\n");
        buffer.append("39-OrdStatus:").append(rowData.get(3)).append("\n");
        buffer.append("FullMessage:").append(rowData.get(4)).append("\n");

        textArea.setText(buffer.toString());
        textArea.setFont(Font.getFont("Arial"));
        textArea.setForeground(Color.BLUE);
        final JScrollPane scrollPane = new JScrollPane(textArea);
        dialog.add(scrollPane);
        dialog.setVisible(true);
    }

    /**
     * Presents a File Dialog for a new script file, and displays it in the
     * "script area".
     * <p>
     * This method can only be called from the Swing EDT.
     */
    private void loadScriptFile()
    {
        if (!SwingUtilities.isEventDispatchThread())
        {
            throw new RuntimeException("Method should only be called on event thread");
        }
        final JFileChooser fileChooser = new JFileChooser();

        final FileNameExtensionFilter filter = new FileNameExtensionFilter("XML files",
                "xml");
        fileChooser.setFileFilter(filter);

        // Open the file chooser at the last location, or in the current
        // directory if it's the first time
        File path = null;
        if (ScriptRunnerGUI.this.scriptPath != null)
        {
            path = new File(ScriptRunnerGUI.this.scriptPath);
        }

        if (path == null || !path.exists())
        {
            final String userDirPath = System.getProperty("user.dir");
            path = new File(userDirPath);
        }
        fileChooser.setCurrentDirectory(path);
        final int returnVal = fileChooser.showOpenDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION)
        {
            final File chosenFile = fileChooser.getSelectedFile();
            try
            {
                this.scriptPath = chosenFile.getAbsolutePath();

                this.messageFlowListener.logStatusText("Selected file is:"
                        + this.scriptPath);

                final FileReader reader = new FileReader(chosenFile);
                final BufferedReader br = new BufferedReader(reader);
                final StringBuffer buffer = new StringBuffer();
                String line;

                while ((line = br.readLine()) != null)
                {
                    buffer.append(line).append("\n");
                }
                br.close();
                reader.close();

                this.scriptArea.setText("");
                this.scriptArea.setText(buffer.toString());
                this.loaded = true;
                updateComponentEnablement();
            }
            catch (final IOException e1)
            {
                JOptionPane.showMessageDialog(ScriptRunnerGUI.this,
                        "Failed To Open File: " + e1.getLocalizedMessage(),
                        "Open Failed",
                        JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    /**
     * Launches the currently loaded script. It uses a SwingWorker to fire the
     * script execution into the background; it also sets ands restores the
     * enabled state of the controls.
     * <p>
     * This method can only be called from the Swing EDT.
     */
    private void runScript()
    {
        if (!SwingUtilities.isEventDispatchThread())
        {
            throw new RuntimeException("Method should only be called on event thread");
        }
        if (this.scriptRunnerWorker != null)
        {
            throw new IllegalStateException("Script already running");
        }
        if (!this.loaded)
        {
            throw new IllegalStateException("No script loaded");
        }
        final FIXClientApplication client = new FIXClientApplication(this.scriptPath,
                this.configFileName,
                this.messageFlowListener);

        // scriptRunnerWorker doubles as an "isRunning" flag
        this.scriptRunnerWorker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground()
            {
                try
                {
                    client.runScript();
                }
                catch (final InterruptedException ex)
                {
                    // implies that the "Stop" button was pressed.
                    ScriptRunnerGUI.this.messageFlowListener.logStatusText("*** Script interrupted ***");
                }
                catch (final Exception ex)
                {
                    ScriptRunnerGUI.this.messageFlowListener.logError("Error executing script",
                            ex);
                }
                return null;
            }

            @Override
            protected void done()
            {
                // reset the worker - we're no longer running
                ScriptRunnerGUI.this.scriptRunnerWorker = null;
                updateComponentEnablement();
            }
        };

        updateComponentEnablement();
        this.scriptRunnerWorker.execute();
    }

    /**
     * Cancels the current running script. If none running, then does nothing.
     * This may be called from any thread, but is most likely called by the EDT
     * in response to a "Stop" request.
     */
    private void cancelScript()
    {
        final SwingWorker<Void, Void> worker = this.scriptRunnerWorker;
        if (worker != null)
        {
            worker.cancel(true);
        }
    }

    /**
     * Utility method that sets the enabled state of the control buttons.
     */
    private void updateComponentEnablement()
    {
        final boolean running = this.scriptRunnerWorker != null;

        // these are disabled when running
        this.loadScriptButton.setEnabled(!running);
        this.runButton.setEnabled(!running && this.loaded);

        // these are enabled when running
        this.stopButton.setEnabled(running);
    }

    /**
     * Creates the button toolbars, and assigns the actions to the buttons.
     */
    private JPanel createControlPanel()
    {
        final JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Control Panel"));
        panel.setLayout(new BorderLayout());

        final Insets margin = new Insets(2, 5, 2, 5);
        final JToolBar controlPanelToolBar = new JToolBar("Control Tools");
        controlPanelToolBar.setFloatable(false);

        this.loadScriptButton = new JButton("Load Script");
        this.loadScriptButton.setBorderPainted(true);
        this.loadScriptButton.setSize(10, 10);
        this.loadScriptButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e)
            {
                loadScriptFile();
            }
        });
        this.loadScriptButton.setMargin(margin);

        this.runButton = new JButton("Run");
        this.runButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e)
            {
                runScript();
            }
        });
        this.runButton.setMargin(margin);

        this.stopButton = new JButton("Stop");
        this.stopButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent e)
            {
                cancelScript();
            }
        });
        this.stopButton.setMargin(margin);

        final JSeparator separator = new JSeparator(SwingConstants.VERTICAL);

        controlPanelToolBar.add(this.loadScriptButton, BorderLayout.LINE_START);
        controlPanelToolBar.add(separator);
        controlPanelToolBar.add(this.runButton, BorderLayout.AFTER_LAST_LINE);
        controlPanelToolBar.add(separator, BorderLayout.AFTER_LAST_LINE);
        controlPanelToolBar.add(this.stopButton, BorderLayout.AFTER_LAST_LINE);
        controlPanelToolBar.add(separator, BorderLayout.AFTER_LAST_LINE);

        panel.add(controlPanelToolBar);

        updateComponentEnablement();
        return panel;
    }

    /**
     * Method that puts together the overall UI.
     * 
     * @param pane
     *            the container that will hold these components - typically the
     *            ContentPane of the main Frame.
     */
    private void addComponentsToPane(final Container pane)
    {
        pane.setLayout(new BorderLayout());

        final JPanel controlPanel = createControlPanel();

        final JPanel centralPanel = new JPanel();
        centralPanel.setLayout(new BorderLayout());

        final JPanel scriptPanel = new JPanel();
        scriptPanel.setLayout(new BorderLayout());

        this.scriptArea = new JTextArea();
        this.scriptArea.setEditable(false);
        this.scriptArea.setVisible(true);
        scriptPanel.add(this.scriptArea);

        final JScrollPane scriptScrollPane = new JScrollPane(scriptPanel,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scriptScrollPane.setVisible(true);

        scriptScrollPane.setBorder(BorderFactory.createTitledBorder("Loaded Script"));

        final JPanel messageFlowPanel = new JPanel();
        messageFlowPanel.setBorder(BorderFactory.createTitledBorder("Message Flow"));
        messageFlowPanel.setLayout(new BorderLayout());

        final JPanel outgoingFIXPanel = new JPanel();
        outgoingFIXPanel.setBorder(BorderFactory.createTitledBorder("Outgoing FIX"));
        outgoingFIXPanel.setLayout(new BorderLayout());

        this.outgoingMessageDataModel = new MessageFlowDataModel();

        this.outgoingMessageTable = new JTable(this.outgoingMessageDataModel);
        final JScrollPane outgoingScrollPane = new JScrollPane(this.outgoingMessageTable,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        this.outgoingMessageTable.setFillsViewportHeight(true);
        this.outgoingMessageTable.setShowGrid(true);
        this.outgoingMessageTable.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        this.outgoingMessageTable.setRowSelectionAllowed(true);
        this.outgoingMessageTable.setColumnSelectionAllowed(true);

        this.outgoingMessageTable.getSelectionModel()
                .addListSelectionListener(new ListSelectionListener() {
                    public void valueChanged(final ListSelectionEvent e)
                    {
                        if (!e.getValueIsAdjusting())
                        {
                            displayMessageDetailDialog(ScriptRunnerGUI.this.outgoingMessageTable);
                        }
                    }
                });

        System.out.println("outgoing table width "
                + this.outgoingMessageTable.getWidth());

        outgoingFIXPanel.add(outgoingScrollPane, BorderLayout.CENTER);

        final JPanel incomingFIXPanel = new JPanel();
        incomingFIXPanel.setBorder(BorderFactory.createTitledBorder("Incoming FIX"));
        incomingFIXPanel.setLayout(new BorderLayout());

        this.incomingMessageDataModel = new MessageFlowDataModel();
        this.incomingMessageTable = new JTable(this.incomingMessageDataModel);
        this.incomingMessageTable.setFillsViewportHeight(true);
        this.incomingMessageTable.setShowGrid(true);
        this.incomingMessageTable.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        this.incomingMessageTable.setRowSelectionAllowed(true);
        this.incomingMessageTable.setColumnSelectionAllowed(true);

        this.incomingMessageTable.getSelectionModel()
                .addListSelectionListener(new ListSelectionListener() {
                    public void valueChanged(final ListSelectionEvent e)
                    {
                        if (!e.getValueIsAdjusting())
                        {
                            displayMessageDetailDialog(ScriptRunnerGUI.this.incomingMessageTable);
                        }
                    }
                });

        final JScrollPane incomingScrollPane = new JScrollPane(this.incomingMessageTable,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        incomingFIXPanel.add(incomingScrollPane, BorderLayout.CENTER);

        final JSplitPane splitPaneMessageFlow = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPaneMessageFlow.setDividerLocation(241);
        splitPaneMessageFlow.setTopComponent(outgoingFIXPanel);
        splitPaneMessageFlow.setBottomComponent(incomingFIXPanel);
        messageFlowPanel.add(splitPaneMessageFlow, BorderLayout.CENTER);

        final JSplitPane splitPaneScriptMessage = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPaneScriptMessage.setDividerLocation(311);

        centralPanel.add(splitPaneScriptMessage, BorderLayout.CENTER);
        splitPaneScriptMessage.setLeftComponent(scriptScrollPane);
        splitPaneScriptMessage.setRightComponent(messageFlowPanel);

        final JPanel statusPanel = new JPanel();
        statusPanel.setLayout(new BorderLayout());

        this.statusFollowTailButton = new JCheckBox("Follow tail");
        this.statusFollowTailButton.setSelected(true);
        this.statusFollowTailButton.addItemListener(new ItemListener() {
            public void itemStateChanged(final ItemEvent e)
            {
                updateStatusScrolling();
            }
        });
        statusPanel.add(this.statusFollowTailButton, BorderLayout.NORTH);
        this.statusArea = new JTextArea();

        this.statusArea.setEditable(false);
        this.statusArea.setForeground(Color.BLUE);
        this.statusArea.setFont(Font.getFont("Arial"));
        this.statusArea.setLineWrap(true);
        this.statusArea.setWrapStyleWord(true);
        this.statusArea.getDocument()
                .addDocumentListener(new DocumentListener() {
                    public void insertUpdate(final DocumentEvent e)
                    {
                        updateStatusScrolling();
                    }

                    public void removeUpdate(final DocumentEvent e)
                    {
                        insertUpdate(e);
                    }

                    public void changedUpdate(final DocumentEvent e)
                    {
                        insertUpdate(e);
                    }
                });

        final JScrollPane statusScrollPane = new JScrollPane(this.statusArea,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        statusPanel.add(statusScrollPane, BorderLayout.CENTER);
        statusPanel.setBorder(BorderFactory.createTitledBorder("Status"));

        final JSplitPane splitPaneStatusCentral = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPaneStatusCentral.setDividerLocation(186);

        pane.add(controlPanel, BorderLayout.NORTH);
        pane.add(splitPaneStatusCentral, BorderLayout.CENTER);
        splitPaneStatusCentral.setTopComponent(statusPanel);
        splitPaneStatusCentral.setBottomComponent(centralPanel);

        setResizable(true);
    }

    /**
     * Invoked on selecting the statusFollowTail mode, or on any change to the
     * statusArea's text.
     * <p>
     * JTextArea will auto-scroll when the caret is at the end of the doc to
     * follow the newly added text (because the text is actually inserted before
     * the caret-at-end). So if we are in Follow mode, we force the caret to the
     * end; if we aren't, we ensure the caret is NOT at the end.
     */
    void updateStatusScrolling()
    {
        final int docLength = this.statusArea.getDocument().getLength();
        if (this.statusFollowTailButton.isSelected())
        {
            // We're "following" - set caret to bottom of display
            this.statusArea.setCaretPosition(docLength);
        }
        else
        {
            // if not "following", then move (invisible) caret from end to
            // prevent auto-scroll
            if (this.statusArea.getCaretPosition() == docLength
                    && docLength > 0)
            {
                this.statusArea.setCaretPosition(docLength - 1);
            }
        }
    }

    /**
     * Primary entry point for the GUI Application.
     * 
     * @param args
     *            no command-line args are required. A single optional arg may
     *            be supplied to indicate an alternative location for the
     *            QuickFIX config file (default is "
     *            <tt>./config/quickfix.cfg</tt>").
     */
    public static void main(final String args[])
    {
        String configFile = null;
        if (args != null && args.length > 0)
        {
            configFile = args[0];
        }
        try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (final Exception e)
        {
            System.err.println("Failed to initialize system look-and-feel - using default instead");
        }
        startApp(configFile);
    }

    private static void startApp(final String configFile)
    {
        final UncaughtExceptionHandler handler = new UncaughtExceptionHandler() {
            public void uncaughtException(final Thread t, final Throwable e)
            {
                System.err.println("Uncaught Exception: "
                        + e
                        + ' '
                        + e.getMessage());
                e.printStackTrace();
            }
        };

        // Run the GUI in the context of the Swing Event Dispatch Thread.
        SwingUtilities.invokeLater(new Runnable() {
            public void run()
            {
                new ScriptRunnerGUI(configFile);
                Thread.currentThread().setUncaughtExceptionHandler(handler);
            }
        });
    }

    /**
     * @param configFile
     */
    public ScriptRunnerGUI(final String configFile)
    {
        super(GUI_TITLE);
        this.configFileName = configFile == null
                ? DEFAULT_CONFIG_FILE
                : configFile;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        URL url = this.getClass().getClassLoader().getResource(DEFAULT_ICON_IMAGE_FILE);
        final ImageIcon icon = new ImageIcon(url);
        setIconImage(icon.getImage());
        setSize(GUI_WIDTH, GUI_HEIGHT);
        addComponentsToPane(getContentPane());
        addWindowListener(new WindowCloser());
        setVisible(true);
        this.messageFlowListener = new GUIMessageFlowListener(this.incomingMessageTable,
                this.outgoingMessageTable,
                this.statusArea);
    }

    class WindowCloser extends WindowAdapter
    {
        /**
         * Stops the messageFlowListener on shutdown.
         * 
         * @see java.awt.event.WindowListener#windowClosed(java.awt.event.WindowEvent)
         */
        @Override
        public void windowClosed(final WindowEvent e)
        {
            ScriptRunnerGUI.this.messageFlowListener.stop();
        }
    }
}
