package com.anz.markets.prophet.pricer.firewall;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.TestStubNotifier;
import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierClippingConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQty;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.status.Context;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static com.anz.markets.prophet.marketdata.TestConfigurationDataFactory.withDefaults;

public class PriceBarrierFirewallBWTest {
    private static final int REPS = 1_000_000;
    private static final int THRESHOLD = 200;
    private static final double PRICE_INCREMENT_AMOUNT = 0.0001;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private ClientPriceImpl testPrice;
    private boolean movingTowardsFloor;

    private PriceBarrierFirewall firewall = new PriceBarrierFirewall(new ClientPriceCache(new TestStubNotifier<>()), new DataRegisters());

    private IndexedConfigurationData createConfiguration(final boolean enabled, final boolean autoReset,
                                                         final List<PriceBarrierFirewallConfig> firewallConfigs,
                                                         final List<PriceBarrierClippingConfig> clippingConfigs) {
        final ConfigurationDataDefault configurationDataDefault = withDefaults(new ConfigurationDataDefault());
        configurationDataDefault.putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, enabled));
        configurationDataDefault.putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, autoReset));
        configurationDataDefault.setPriceBarrierFirewallConfigs(firewallConfigs);
        configurationDataDefault.setPriceBarrierClippingConfigs(clippingConfigs);
        return new IndexedConfigurationData(configurationDataDefault);
    }

    private List<PriceBarrierClippingConfig> createClippingConfigForInstrument(final Instrument inst) {
        final List<PriceBarrierClippingConfig> clippingConfigs = Lists.newArrayList(
                new PriceBarrierClippingConfig(inst, Market.WSP_A, 200, 10_000_000.0, 20),
                new PriceBarrierClippingConfig(inst, Market.WSP_A, 100,  5_000_000.0, 20),
                new PriceBarrierClippingConfig(inst, Market.WSP_A,  50,  3_000_000.0, 20)
        );
        return clippingConfigs;
    }

    private IndexedConfigurationData singleInstrumentClippingConfiguration(final Instrument instrument) {
        return createConfiguration(true, true,
                Collections.singletonList(new PriceBarrierFirewallConfig(instrument, "", 7.415, 7.485, instrument.getTerms())),
                createClippingConfigForInstrument(instrument));
    }

    private void movePriceTowards(final ClientPriceImpl price, final double byAmount, final boolean moveToFloor) {
        final double delta = moveToFloor ? -1*byAmount : byAmount;
        double p;
        for (final PriceAndQty bid : price.getBids()) {
            p = bid.getPrice();
            ((PriceAndQtyImpl)bid).setPrice(p + delta);
        }
        for (final PriceAndQty offer : price.getOffers()) {
            p = offer.getPrice();
            ((PriceAndQtyImpl)offer).setPrice(p + delta);
        }
    }

    public void runTest() {
        if (testPrice.isBidAndOfferIndicative()) {
            movingTowardsFloor = !movingTowardsFloor;
        }
        movePriceTowards(testPrice, PRICE_INCREMENT_AMOUNT, movingTowardsFloor);
        firewall.perform(testPrice);
    }

    @Test
    public void singleInstrumentTest() {
        Context.context().region(Region.GB);
        final Instrument inst = Instrument.AUDUSD;
        firewall.applyConfiguration(singleInstrumentClippingConfiguration(inst));
        testPrice = MidRateTestHelper.createClientPrice(inst,
                7.447, 0.02,  1.0,
                7.445, 0.02,  3.0,
                7.442, 0.02,  5.0,
                7.440, 0.02, 10.0);
        helper.testAllocationNotExceeded(this::runTest, REPS, REPS, THRESHOLD);
    }


}
