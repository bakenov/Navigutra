package com.anz.markets.efx.fox.processor.state.ematch;

import java.util.Objects;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.processor.state.ParentOrderFactory;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.ngaro.core.ObjectPool;

public class EMatchParentOrderFactory implements ParentOrderFactory.NamedFactory {

    private final String strategyName;
    private final ObjectPool<EMatchParentOrder> parentOrderPool;

    public EMatchParentOrderFactory(final String strategyName,
                                    final ParentOrderRepository.Mutable parentOrderRepository,
                                    final int initialPoolSize,
                                    final TimerScheduler timerScheduler,
                                    final InstrumentRepository instrumentRepository) {
        this.strategyName = Objects.requireNonNull(strategyName);
        Objects.requireNonNull(parentOrderRepository);
        Objects.requireNonNull(timerScheduler);
        Objects.requireNonNull(instrumentRepository);

        parentOrderPool = new ObjectPool<>(
                releaser -> new EMatchParentOrder(timerScheduler,
                        releaser.andThen(parentOrder -> {
                            parentOrderRepository.removeByOrderId(parentOrder.details().orderId());
                            parentOrderRepository.removeByClOrderId(parentOrder.details().senderCompId(), parentOrder.details().origClOrdId());
                        }), instrumentRepository),
                initialPoolSize);
    }

    @Override
    public String name() {
        return strategyName;
    }

    @Override
    public ParentOrder get() {
        return parentOrderPool.borrowOrNew();
    }
}
