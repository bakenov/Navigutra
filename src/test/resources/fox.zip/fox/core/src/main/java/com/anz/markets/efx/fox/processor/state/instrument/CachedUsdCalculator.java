package com.anz.markets.efx.fox.processor.state.instrument;

import java.util.Objects;
import java.util.function.DoubleUnaryOperator;
import java.util.function.Supplier;

public class CachedUsdCalculator implements DoubleUnaryOperator {
    private final Supplier<DoubleUnaryOperator> usdCalculatorFactory;
    private DoubleUnaryOperator usdCalculator;

    public CachedUsdCalculator(final Supplier<DoubleUnaryOperator> usdCalculatorFactory) {
        this.usdCalculatorFactory = Objects.requireNonNull(usdCalculatorFactory);
    }

    @Override
    public double applyAsDouble(final double nominalAmount) {
        if (usdCalculator == null) {
            usdCalculator = usdCalculatorFactory.get();
            if (usdCalculator == null) return Double.NaN;
        }
        return usdCalculator.applyAsDouble(nominalAmount);
    }
}
