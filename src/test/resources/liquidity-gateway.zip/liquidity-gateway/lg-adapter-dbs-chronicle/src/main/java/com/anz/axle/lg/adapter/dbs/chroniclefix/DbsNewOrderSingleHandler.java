package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Map;
import java.util.Objects;
import java.util.function.LongSupplier;

import net.openhft.chronicle.bytes.Bytes;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.HandlInst;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public final class DbsNewOrderSingleHandler implements NewOrderSingleHandler {

    private static final LocalDateFormat DATE_FORMAT = LocalDateFormat.YYYYMMDD;
    private final FixMessageSender fixMessageSender;
    private final LongSupplier receivedTimeNanosSupplier;
    private final Map<Tenor, String> tenors;
    private final String senderSubID;
    private final String password;
    private final String account;

    private final NewOrderSingle newOrderSingle;

    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);

    private final CachedFunction<String, String> symbol7Lookup = CachedFunction.of(SymbolNormaliser::toSymbol7);

    public DbsNewOrderSingleHandler(final FixMessageSender fixMessageSender,
                                    final LongSupplier receivedTimeNanosSupplier,
                                    final Map<Tenor, String> tenors,
                                    final String senderSubID,
                                    final String password,
                                    final String account) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.receivedTimeNanosSupplier = Objects.requireNonNull(receivedTimeNanosSupplier);
        this.tenors = Objects.requireNonNull(tenors);
        this.senderSubID = Objects.requireNonNull(senderSubID);
        this.password = Objects.requireNonNull(password);
        this.account = Objects.requireNonNull(account);
        this.newOrderSingle = NewOrderSingle.newNewOrderSingle(Bytes.allocateElasticDirect(), fixMessageSender.context());
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.reset();
    }

    @Override
    public void onBody(final Body body) {
        newOrderSingle.clOrdID(body.clOrdId().decodeStringOrNull());
        newOrderSingle.transactTime(body.transactTime());
        newOrderSingle.handlInst(HandlInst.AUTOMATED_EXECUTION_NO_INTERVENTION);
        newOrderSingle.symbol(symbol7(body));
        newOrderSingle.side(side(body.side()));
        newOrderSingle.orderQty(body.orderQty());
        newOrderSingle.ordType(orderType(body.ordType()));
        newOrderSingle.currency(currency(body));
        newOrderSingle.senderSubID(senderSubID);
        newOrderSingle.password(password);
        newOrderSingle.account(account);

        newOrderSingle.securityType(securityType(body.securityType()));
        if (SecurityType.FXNDF.equals(body.securityType())) {
            // no tenor in NewOrderSingle trading codec at this point. default to 1M
            newOrderSingle.tenor(tenor(Tenor.M1));
            newOrderSingle.maturityDate(body.settlDate().decodeToFormattedStringOrNull(DATE_FORMAT));
        }

        if (body.ordType() == OrderType.LIMIT) {
            newOrderSingle.price(body.price());
            final char timeInForce = timeInForce(body.timeInForce());
            newOrderSingle.timeInForce(timeInForce);
            if (com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_DATE == timeInForce) {
                newOrderSingle.expireTime(body.expireTime());
            }
        }
    }

    private String securityType(final SecurityType securityType) {
        if (securityType == null) return null;
        switch (securityType) {
            case FXSPOT: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.SecurityType.SPOT;
            case FXNDF: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.SecurityType.NDF;
            case FXFWD: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.SecurityType.FORWARD;
            default: return null;
        }
    }

    private String tenor(final Tenor tenor) {
        final String ftTenor = tenors.get(tenor);
        if (ftTenor == null) {
            throw new IllegalArgumentException("No flextrade tenor known for: " + ftTenor);
        }
        return ftTenor;
    }

    private String symbol7(final Body body) {
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        return symbol7Lookup.apply(symbol);
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT: return OrdType.LIMIT;
            case MARKET: return OrdType.MARKET;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case DAY: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.TimeInForce.DAY;
            case GTC: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_CANCEL;
            case IOC: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.TimeInForce.IMMEDIATE_OR_CANCEL;
            case FOK: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.TimeInForce.FILL_OR_KILL;
            case GTD: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_DATE;
            default: throw new IllegalArgumentException("Unsupported timeInForce" + timeInForce);
        }
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.Side.BUY;
            case SELL: return com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
    }
}
