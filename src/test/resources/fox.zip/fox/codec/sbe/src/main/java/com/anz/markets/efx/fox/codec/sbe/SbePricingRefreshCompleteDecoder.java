package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

final class SbePricingRefreshCompleteDecoder {
    private final PricingRefreshCompleteDecoder pricingRefreshCompleteDecoder = new PricingRefreshCompleteDecoder();
    private final Consumer<StringBuilder> messageLogger = pricingRefreshCompleteDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.PricingRefreshComplete encodingOrder = EncodingOrder.PricingRefreshComplete.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final PricingRefreshCompleteHandler pricingRefreshCompleteHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.PricingRefreshComplete.INITIAL;
        pricingRefreshCompleteDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            pricingRefreshCompleteHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            pricingRefreshCompleteHandler.messageForwarder(messageForwarder);
            pricingRefreshCompleteHandler.messageLogger(messageLogger);
            body.decode(pricingRefreshCompleteHandler);
            pricingRefreshCompleteHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.PricingRefreshComplete.INITIAL;
            pricingRefreshCompleteDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements PricingRefreshCompleteHandler.Body {
        void decode(final PricingRefreshCompleteHandler pricingRefreshCompleteHandler) {
            encodingOrder = EncodingOrder.PricingRefreshComplete.BODY;
            pricingRefreshCompleteHandler.onBody(this);
        }

        @Override
        public long instrumentId() {
            encodingOrder.checkStrict(EncodingOrder.PricingRefreshComplete.BODY);
            return pricingRefreshCompleteDecoder.instrumentId();
        }

        @Override
        public boolean forceSnapshot() {
            encodingOrder.checkStrict(EncodingOrder.PricingRefreshComplete.BODY);
            return pricingRefreshCompleteDecoder.forceSnapshot() == YesNo.YES;
        }

    }
}
