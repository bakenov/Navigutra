package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;

import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;

public interface SnapshotterAccessor {
    Snapshotter snapshotter();
    PricingEncoderSupplier pricingEncoderSupplier();

    static SnapshotterAccessor create(final Snapshotter snapshotter, final PricingEncoderSupplier pricingEncoderSupplier) {
        Objects.requireNonNull(snapshotter);
        Objects.requireNonNull(pricingEncoderSupplier);

        return new SnapshotterAccessor() {
            @Override
            public Snapshotter snapshotter() {
                return snapshotter;
            }

            @Override
            public PricingEncoderSupplier pricingEncoderSupplier() {
                return pricingEncoderSupplier;
            }
        };
    }
}
