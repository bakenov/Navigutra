package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.WireIn;
import software.chronicle.fix.sessioncode.messages.Logon;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;

import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MessageNotifier;

public class ClientMessageNotifier implements MessageNotifier, Marshallable, Demarshallable {

    private transient CountDownLatch awaitTillConnected;
    private transient CountDownLatch waitTillLoggedInReceivedOnClient;

    private ClientMessageNotifier(final WireIn wireIn) {
        waitTillLoggedInReceivedOnClient = new CountDownLatch(1);
        awaitTillConnected = new CountDownLatch(1);
    }

    public boolean awaitTillConnected(final long timeout, final TimeUnit timeUnit) throws InterruptedException {
        return awaitTillConnected.await(timeout, timeUnit);
    }

    @Override
    public void onStartOfConnection(final SessionID sessionID) {
        awaitTillConnected.countDown();
    }

    @Override
    public void onLogon(final FixSessionHandler session, final Logon logon) {
        // the acknowledgement of the logon
        waitTillLoggedInReceivedOnClient.countDown();
    }

    public void reset() {
        waitTillLoggedInReceivedOnClient = new CountDownLatch(1);
    }

    public boolean awaitTillLoggedIn(final int timeout, final TimeUnit timeUnit) throws InterruptedException {
        return waitTillLoggedInReceivedOnClient.await(timeout, timeUnit);
    }

}
