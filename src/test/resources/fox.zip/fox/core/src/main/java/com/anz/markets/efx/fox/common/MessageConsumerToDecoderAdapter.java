package com.anz.markets.efx.fox.common;

import java.util.Objects;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.eventsourcing.api.MessageConsumer;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;

public class MessageConsumerToDecoderAdapter implements MessageConsumer {
    private final static Logger LOGGER = LoggerFactory.getLogger(MessageConsumerToDecoderAdapter.class);

    private final MessageDecoder<SbeMessage> decoder;
    private final MutableDirectBuffer zeroOffsetBuffer = new UnsafeBuffer();
    private final MutableSbeMessage sbeMessage = new SbeMessageForWriting(zeroOffsetBuffer);

    public MessageConsumerToDecoderAdapter(final MessageDecoder<SbeMessage> decoder) {
        this.decoder = Objects.requireNonNull(decoder);
    }

    @Override
    public void accept(final DirectBuffer directBuffer, final int offset, final int length) {
        try {
            zeroOffsetBuffer.wrap(directBuffer, offset, length);
            sbeMessage.messageLength(length);
            decoder.decode(sbeMessage);
        } catch (final Exception ex) {
            LOGGER.error("Failed to handle message", ex);
        }
    }
}
