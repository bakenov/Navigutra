package com.anz.markets.prophet.atest.pricing._9_forward_points;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.EmptyBookReason;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import org.junit.Test;

import java.time.LocalDate;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class ForwardPoints_Missing_Point_In_Curve_Test extends BaseAcceptanceSpecification {

    @Test
    // https://jira.service.anz/browse/AXPROPHET-692
    @DisplayName("Do not interpolate/generate client price when end point fwd point is NaN")
    public void endPointFwdPointNan() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.USDCAD;
        final Instrument crossPair = Instrument.EURCAD;

        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(5)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(1)));

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(5)));

            // receive/send fwd points for driverPairB
            prophet.receive(tdd.forwardPoint(driverPairB, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(driverPairB, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));

            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            // receive driver pair EURUSD MID rate = 1.11455
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.11455, 0.00001));
        }

        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // receive driver pair USDCAD MID Rate = 1.30525
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.30525, 0.00001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_A));
        }
        and:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A));
        }
        when:
        // since fwd point is NaN, clear client price for cross pair
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.forwardPoint(driverPairB, Double.NaN, Double.NaN, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.11450, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getLast();
            assertThat(clientPrice.getBids().size(), is(0));
            assertThat(clientPrice.getOffers().size(), is(0));
            assertThat(clientPrice.getEmptyBookReason(), is(EmptyBookReason.CROSS_RATE_MISSING_FORWARD_POINTS));
        }
    }

    @Test
    // https://jira.service.anz/browse/AXPROPHET-692
    @DisplayName("Do not interpolate/generate client price when end point fwd tenor missing")
    public void endPointFwdPointMissing() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.USDCAD;
        final Instrument crossPair = Instrument.EURCAD;

        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(5)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(1)));

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(5)));

            // receive/send fwd points for driverPairB. Do not send SPOT_NEXT T+2 fwd point which is a required tenor used for interpolation
            prophet.receive(tdd.forwardPoint(driverPairB, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));

            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.11455, 0.00001));
        }

        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.30525, 0.00001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_A));
        }
        and:
        // since SPOT_NEXT T+2 fwd point is missing, unable to interpolate and generate client price
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(crossPair));
        }
    }
}
