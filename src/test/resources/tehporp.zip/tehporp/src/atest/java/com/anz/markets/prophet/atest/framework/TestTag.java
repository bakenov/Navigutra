package com.anz.markets.prophet.atest.framework;

public class TestTag {
    public static final String FIX_ME_PLEASE = "FIX_ME_PLEASE";
    public static final String WIP = "WIP";

}
