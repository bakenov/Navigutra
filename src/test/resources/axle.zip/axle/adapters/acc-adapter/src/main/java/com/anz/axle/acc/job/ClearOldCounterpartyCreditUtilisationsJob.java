package com.anz.axle.acc.job;

import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValueDAO;
import com.anz.axle.acc.domain.BusinessLocalDate;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("clearOldCounterpartyCreditUtilisationsJob")
public class ClearOldCounterpartyCreditUtilisationsJob implements Runnable {
    private static final Logger LOG = Logger.getLogger(ClearOldCounterpartyCreditUtilisationsJob.class);

    @Autowired
    private CounterpartyCreditUtilisationValueDAO dao;

    private volatile int maxAgeInDays = 15;

    private volatile LocalDate now;

    public void run() {
        LocalDate earliestDate = new BusinessLocalDate(getNow()).rollBack(maxAgeInDays).getDate();
        LOG.debug("Start Clear Old Counterparty Credit Utilisations job [before:" + earliestDate + "]...");
        List<CounterpartyCreditUtilisationValue> utilisations = dao.findAll();
        for(CounterpartyCreditUtilisationValue value : utilisations) {
            if(value.getSpotDate().isBefore(earliestDate)) {
                dao.remove(value.getKey());
                if(!dao.has(value.getKey())) {
                    LOG.info("Removed Counterparty Credit Utilisation Value " + value.toString());
                } else {
                    LOG.warn("Failed to remove Counterparty Credit Utilisation Value " + value.toString());
                }
            }
        }
        LOG.debug("Clear Old Counterparty Credit Utilisations job completed");
    }

    /**
     * This parameter specifies the maximum age in days of CounterpartyCreditUtilisations.
     * Items with a spot day before now - maxAgeInDays will be removed by this job.
     * @param days
     */
    public void setMaxAgeInDays(int days){
        this.maxAgeInDays = days;
    }

    /**
     * Testing purposes only.
     * @param dao
     */
    public void setCounterpartyCreditUtilisationDAO(CounterpartyCreditUtilisationValueDAO dao) {
        this.dao = dao;
    }

     /**
     * Testing purposes only.
     * @param now
     */
    public void setNow(LocalDate now) {
        this.now = now;
    }

    private LocalDate getNow() {
        if(now == null) {
            return new LocalDate();
        }
        return now;
    }
}
