package com.anz.markets.prophet.atest.framework.impl;

import java.util.List;

public class AtLeastMessageCountPredicate implements MessageCountPredicate {
    private int count;

    public AtLeastMessageCountPredicate(final int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return String.format("Expect at least a count of %d message(s)", count);
    }

    @Override
    public boolean test(final List list) {
        return list != null && list.size() >= count;
    }
}
