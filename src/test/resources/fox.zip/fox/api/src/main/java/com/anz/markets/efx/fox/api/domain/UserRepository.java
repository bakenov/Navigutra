package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.codec.api.UserConfigDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface UserRepository {
    User lookup(String userName);
    User lookup(StringDecoder userName);
    User init(UserConfigDecoder userConfigDecoder);
}