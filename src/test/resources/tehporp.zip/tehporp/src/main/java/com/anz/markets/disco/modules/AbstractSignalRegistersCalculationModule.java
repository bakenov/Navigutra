package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.data.SignalRegisters;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.prophet.domain.marketdata.InstrumentAndMarket;

public abstract class AbstractSignalRegistersCalculationModule extends AbstractModule implements SignalRegisters.SignalRegistersListener {

    private final SignalType signalTypes[];

    private SignalRegisterModule signalRegisterModule;

    public AbstractSignalRegistersCalculationModule(final SignalType... signalTypes) {
        this.signalTypes = signalTypes;
    }

    public SignalRegisters getSignalRegisters() {
        return signalRegisterModule.getSignalRegisters();
    }

    public Signals getSignals(InstrumentAndMarket instrumentAndMarket) {
        return getSignalRegisters().getSignals(instrumentAndMarket);
    }

    @Override
    public void sub(MessageBus messageBus) {
        signalRegisterModule = getStage().getProcessingModule(SignalRegisterModule.class);
        signalRegisterModule.getSignalRegisters().addListener(this, signalTypes);
    }
}
