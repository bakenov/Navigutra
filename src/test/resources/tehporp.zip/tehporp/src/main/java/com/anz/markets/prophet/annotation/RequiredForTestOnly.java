package com.anz.markets.prophet.annotation;

public @interface RequiredForTestOnly {
    String[] value();

    public static final String TEST_ONLY = "For testing purposes only.";
}
