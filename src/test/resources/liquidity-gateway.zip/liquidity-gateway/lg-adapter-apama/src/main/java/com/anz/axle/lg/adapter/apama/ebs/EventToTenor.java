package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Objects;
import java.util.function.Function;

import com.apama.event.Event;

import com.anz.markets.efx.ngaro.api.Tenor;

public class EventToTenor implements Function<Event, Tenor> {
    static final String SETTLTYPE_BROKEN = "B";

    private final Function<Event, String> eventToSettleType;
    private final Function<Event, String> eventToSettleDate;
    private final Function<String, Tenor> settleDateToTenor;
    private final Function<String, Tenor> settleTypeToTenor;

    public EventToTenor(final Function<Event, String> eventToSettleType,
                        final Function<Event, String> eventToSettleDate,
                        final Function<String, Tenor> settleTypeToTenor,
                        final Function<String, Tenor> settleDateToTenor) {
        this.eventToSettleType = Objects.requireNonNull(eventToSettleType);
        this.eventToSettleDate = Objects.requireNonNull(eventToSettleDate);
        this.settleTypeToTenor = Objects.requireNonNull(settleTypeToTenor);
        this.settleDateToTenor = Objects.requireNonNull(settleDateToTenor);
    }

    public static EventToTenor forEntryEvent(final Function<String, Tenor> settleTypeToTenor) {
        return new EventToTenor(EventFunctions.ENTRY_TO_SETTL_TYPE,
                                EventFunctions.ENTRY_TO_SETTL_DATE,
                                settleTypeToTenor,
                                EventFunctions.SETTL_DATE_TO_TENOR);
    }

    public static EventToTenor forMessageEvent(final Function<String, Tenor> settleTypeToTenor) {
        return new EventToTenor(EventFunctions.MESSAGE_TO_SETTL_TYPE,
                                EventFunctions.MESSAGE_TO_SETTL_DATE,
                                settleTypeToTenor,
                                EventFunctions.SETTL_DATE_TO_TENOR);
    }

    @Override
    public Tenor apply(final Event event) {
        final String settlType = eventToSettleType.apply(event);
        if (settlType != null) {
            if (SETTLTYPE_BROKEN.equals(settlType)) {
                final String settlDate = eventToSettleDate.apply(event);
                if (settlDate != null) {
                    return settleDateToTenor.apply(settlDate);
                } else {
                    throw new IllegalStateException("empty settlement date for broken tenor");
                }
            } else {
                return settleTypeToTenor.apply(settlType);
            }
        } else {
            return Tenor.SP;
        }
    }
}
