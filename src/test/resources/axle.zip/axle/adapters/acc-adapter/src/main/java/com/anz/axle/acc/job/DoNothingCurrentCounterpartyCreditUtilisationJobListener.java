package com.anz.axle.acc.job;

import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("doNothingCurrentCounterpartyCreditUtilisationJobListener")
public class DoNothingCurrentCounterpartyCreditUtilisationJobListener implements CurrentCounterpartyCreditUtilisationJobListener {
    @Override
    public void listen(CounterpartyCreditUtilisations utilisations) {
    }
}
