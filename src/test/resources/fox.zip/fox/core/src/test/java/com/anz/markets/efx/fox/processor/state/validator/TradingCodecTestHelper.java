package com.anz.markets.efx.fox.processor.state.validator;

import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.trading.codec.api.*;
import com.anz.markets.efx.trading.codec.sbe.NewOrderSingleSbeDecoder;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingEncoders;

public class TradingCodecTestHelper {
    private SbeMessageForWriting sbeTradingMessageForWriting;
    private SbeTradingEncoders sbeTradingEncoders;
    private NewOrderSingleEncoder newOrderSingleEncoder;
    private NewOrderSingleSbeDecoder newOrderSingleSbeDecoder;

    private String expectedSymbol = "EURUSD";
    private String expectedMarketId = "EBS";
    private SecurityType expectedSecurityType = SecurityType.FXSPOT;
    private Tenor expectedTenor = Tenor.SP;
    private long expectedQuantity = 1_000_000;
    private String expectedTargetStrategyName = "Sweeper";
    private String expectedUserName = "litvinc";
    private String expectedPortfolio = "P_LITVINC";
    private String expectedMarkets = "EBS";
    private OrderType expectedOrderType = OrderType.MARKET;
    private TimeInForce expectedTimeInForce = TimeInForce.GTC;
    private OrderStatus expectedOrderStatus;
    private ExecType expectedExecutionType;

    public TradingCodecTestHelper() {
        sbeTradingMessageForWriting = new SbeMessageForWriting(8192);
        sbeTradingEncoders = new SbeTradingEncoders(() -> sbeTradingMessageForWriting);
        newOrderSingleEncoder = sbeTradingEncoders.newOrderSingle().create(msg -> {});
        newOrderSingleSbeDecoder = new NewOrderSingleSbeDecoder();
    }


    public long expectedQuantity() {
        return expectedQuantity;
    }

    public void expectedQuantity(final long expectedQuantity) {
        this.expectedQuantity = expectedQuantity;
    }

    public OrderType expectedOrderType() {
        return expectedOrderType;
    }

    public void expectedOrderType(final OrderType expectedOrderType) {
        this.expectedOrderType = expectedOrderType;
    }

    public TimeInForce expectedTimeInForce() {
        return expectedTimeInForce;
    }

    public void expectedTimeInForce(final TimeInForce expectedTimeInForce) {
        this.expectedTimeInForce = expectedTimeInForce;
    }

    public NewOrderSingleDecoder encodeNewOrderSingle() {

        newOrderSingleEncoder.messageStart(2, 20)
                .senderCompId().encode("GB:validationTest")
                .messageId(18)
                .clOrdId().encode("TestClientId")
                .symbol().encode(expectedSymbol)
                .marketId().encode(expectedMarketId)
                .securityType(expectedSecurityType)
                .settlType(expectedTenor)
                .orderQty(expectedQuantity)
                .ordType(expectedOrderType)
                .targetStrategyName().encode(expectedTargetStrategyName)
                .price(0)
                .side(Side.BUY)
                .currency().encode("EUR")
                .timeInForce(expectedTimeInForce)
                .transactTime(1497338461000000L) //20170613-07:21:01 in nanos
                .partiesStart(3)
                .next()
                .partyRole(PartyRole.CLIENT_ID)
                .partyId().encode("14617523")
                .next()
                .partyRole(PartyRole.PORTFOLIO)
                .partyId().encode(expectedPortfolio)
                .next()
                .partyRole(PartyRole.USER_NAME)
                .partyId().encode(expectedUserName)
                .partiesComplete()
                .strategyParametersStart(1)
                .next()
                .strategyParameterName().encode("Markets")
                .strategyParameterValue().encode(expectedMarkets)
                .strategyParametersComplete()
                .regulatoryTradeIdsStart(2)
                .next()
                .id().encode("123123")
                .source().encode("blah")
                .next()
                .id().encode("535635")
                .source().encode("blah2")
                .regulatoryTradeIdsComplete()
                .hopsStart(1)
                .next()
                .hopCompId().encode("GB:daxled")
                .hopMessageId(45634)
                .hopReceivingTime(0)
                .hopSendingTime(1497338461000000L) //20170613-07:21:01 in nanos
                .hopsComplete()
                .quoteId().encodeEmpty()
                .messageComplete();

        newOrderSingleSbeDecoder.wrap(sbeTradingMessageForWriting);
        return newOrderSingleSbeDecoder;
    }

}
