package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditState;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("currencyVenueExclusionBuilder")
public class CurrencyVenueExclusionBuilder implements Builder<CurrencyVenueExclusion, CurrentVenueCurrencyCreditState> {

    @Autowired
    @Qualifier(value = "currencyVenueExclusionKeyBuilder")
    private Builder<CurrencyVenueExclusionKey, CurrentVenueCurrencyCreditState> keyBuilder;

    @Override
    public CurrencyVenueExclusion build(CurrentVenueCurrencyCreditState input) throws BuilderException {
        CurrencyVenueExclusion exclusion = new CurrencyVenueExclusion();
        exclusion.setCommonExclusion(true);
        exclusion.setExcluded(input.getIsBreached());
        exclusion.setSymbol(input.getPair().getSymbol());
        exclusion.setVenue(input.getVenue().getAggregatorCode());
        exclusion.setSource("CREDIT_CHECK");
        exclusion.setMessage(input.toString());
        exclusion.setLastChangeTimestamp(new Date().getTime());
        exclusion.setKey(keyBuilder.build(input));
        return exclusion;
    }

    public void setKeyBuilder(Builder<CurrencyVenueExclusionKey, CurrentVenueCurrencyCreditState> keyBuilder) {
        this.keyBuilder = keyBuilder;
    }
}
