package software.chronicle.fix;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.queue.ChronicleQueue;
import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.DocumentContext;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.Pollable;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.staticcode.msgseq.fixlog.VanillaFixLog;
import software.chronicle.fix.staticcode.util.FixLogUtil;

import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * @author Rob Austin.
 */
public class CapturingFixLogConsumer implements Consumer<FixLog>, Marshallable, Closeable, Pollable {

    private transient final BlockingQueue<FixLog> capturedMessageQueue = new ArrayBlockingQueue<>(1024);
    private transient final ChronicleQueue log  = ChronicleQueue.singleBuilder("log").build();
    
    // synchronise this as it can be attached to multiple engines/sessions
    @Override
    public synchronized void accept(FixLog fixLog) {
        Bytes msg = fixLog.msg();
        Bytes<ByteBuffer> copy = Bytes.elasticByteBuffer((int) msg.readRemaining());
        copy.write(msg);
        fixLog.msg(copy);
        capturedMessageQueue.add(deepCopy(fixLog));
        try (@NotNull DocumentContext dc = log.acquireAppender().writingDocument()) {
            try {
                fixLog.writeMarshallable(dc.wire().bytes());
            } catch (Throwable e) {
                Jvm.rethrow(e);
            }
        }

    }

    private FixLog deepCopy(FixLog fixLog) {
        FixLog copy = new VanillaFixLog();
        Bytes<ByteBuffer> buffer = Bytes.elasticByteBuffer(256);
        fixLog.writeMarshallable(buffer);
        copy.readMarshallable(buffer);
        FixLogUtil.populateMissingMsgType(copy);
        return copy;
    }

    @Override
    public FixLog poll(long timeout, TimeUnit timeUnit) throws InterruptedException {
        return capturedMessageQueue.poll(timeout, timeUnit);
    }

    public int messageCount() {
        return capturedMessageQueue.size();
    }

    @Override
    public void close() throws IOException {
        log.close();
    }
}
