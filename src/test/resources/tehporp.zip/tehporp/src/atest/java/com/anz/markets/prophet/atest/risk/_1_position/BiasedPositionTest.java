package com.anz.markets.prophet.atest.risk._1_position;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.positionrisk.Positions;
import org.apache.logging.log4j.Level;
import org.junit.Test;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.USDJPY;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

/**
 * AXPROPHET-964  Biased position per currency
 * new Biased positions will be relative to the Bias offset
 * Biased positions will also generate Biased Optimal Positions
 *
 * Note - requirements for calculating biased avg execution rate and biased position pnl not defined. However there are no
 * features that will use biased avg execution rate and biased pnl. Therefore these values are not verified.
 */
@Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
public class BiasedPositionTest extends BaseAcceptanceSpecification {
    private double positionBias;
    private double EPSILON = 1e-6;

    @Test
    public void send_position_adjustment_given_position_bias() {
        prophet.resetAllPositions();

        positionBias = 1_000_000;

        setup:
        // begin with a biased offset
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            // set up position Bias on AUD
            prophet.receive(tdd.biasPosition(Currency.AUD, positionBias));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(2_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET)).getLast();
            Positions biasPositionsUpdate = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getLast();

            and:
            {
                assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0));
                assertThat(positionsUpdate.getPosition1().getPnl(), is(closeTo((((0.9 + 0.8 * 2) / 3) - 0.7500) * -3_000_000, 7)));
            }
            and:
            {
                assertThat(biasPositionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
                assertThat(biasPositionsUpdate.getPosition1().getPositionInNotional(), is(positionsUpdate.getPosition1().getPositionInNotional() + (-positionBias)));
            }
        }
        when:
        // send an position adjustment
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75005, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.adjustment(Currency.AUD, 2_000_000));
        }
        then:
        // adjustment is at current WSP_U mid
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            Positions biasedPositionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();

            and:
            {
                assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0 + 2_000_000.0));
            }
            and:
            {
                assertThat(biasedPositionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
                assertThat(biasedPositionsUpdate.getPosition1().getPositionInNotional(), is(positionsUpdate.getPosition1().getPositionInNotional() + (-positionBias)));
            }
        }
    }

    @Test
    public void calculate_biased_position_AUD() {
        prophet.resetAllPositions();

        positionBias = 0;
        setup:
        // begin with a 0 biased offset
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75000, 0.00040));
            // set up position Bias on AUD
            prophet.receive(tdd.biasPosition(Currency.AUD, positionBias));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
        }
        then:
        // Biased positions the same as unbiased since 0 biased offset
        {
            Positions position = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(position.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(position.getPosition1().getPositionInNotional(), is(1_000_000.0));

            assertThat(position.getPosition2().getCcy(), is(Currency.USD));
            assertThat(position.getPosition2().getPositionInNotional(), is(-900_000.0));

            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(position.getPosition1().getPositionInNotional()));
            assertThat(biasedPosition.getPosition1().getPositionInSystemBase(), is(position.getPosition1().getPositionInSystemBase()));

            assertThat(biasedPosition.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedPosition.getPosition2().getPositionInNotional(), is(position.getPosition2().getPositionInNotional()));
            assertThat(biasedPosition.getPosition2().getPositionInSystemBase(), is(position.getPosition2().getPositionInSystemBase()));
        }
        when:
        // Send positive biased position
        // Biased AUD position will be zero
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, 1_000_000.0));
        }
        then:
        // only expect biased position as unbiased position unchanged
        {
            prophet.notExpect(Positions.class, isPortfolio(Portfolio.CLIENTS_NET));
            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.countPositions(), is(2));
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(-1_000_000.0));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(750_000.0));

            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.countPositions(), is(2));
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(0.0));
            assertThat(biasedPosition.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedPosition.getPosition2().getPositionInNotional(), is(-900_000.0 + 750_000.0));
        }
        when:
        // Send negative biased position
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, -2_000_000));
        }
        then:
        {
            prophet.notExpect(Positions.class, isPortfolio(Portfolio.CLIENTS_NET));
            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.countPositions(), is(2));
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(2_000_000.0));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(-2_000_000.0 * 0.75));

            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.countPositions(), is(2));
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(3_000_000.0));
            assertThat(biasedPosition.getPosition1().getPositionInSystemBase(), is(3_000_000.0 * 0.75));
            assertThat(biasedPosition.getPosition1().getAvgRate(), is(0.75));
            assertThat(biasedPosition.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedPosition.getPosition2().getPositionInNotional(), is(-900_000.0 + (-1_500_000)));
        }
        when:
        // Receive the same/current position bias
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, -2_000_000));
        }
        then:
        // prophet sends bias position
        {
            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.countPositions(), is(2));
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(3_000_000.0));
            assertThat(biasedPosition.getPosition1().getPositionInSystemBase(), is(3_000_000.0 * 0.75));
            assertThat(biasedPosition.getPosition1().getAvgRate(), is(0.75));
            assertThat(biasedPosition.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedPosition.getPosition2().getPositionInNotional(), is(-900_000.0 + (-1_500_000)));
        }
        when:
        // Receive 0 position bias
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, 0.0));
        }
        then:
        // prophet sends bias position
        {
            prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
        }
    }

    @Test
    public void calculate_biased_position_JPY() {
        prophet.resetAllPositions();

        setup:
        // begin with negative Biased JPY offset
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshot(USDJPY, 88.500, 0.04));
            prophet.receive(tdd.biasPosition(Currency.JPY, -240_000_000));
            prophet.clearOutputBuffer();
        }
        when:
        // receive client trade
        {
            prophet.receive(tdd.client_trade_001(USDJPY, 2_000_000, 88.505));
        }
        then:
        {
            Positions position = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(position.getPosition1().getCcy(), is(Currency.USD));
            assertThat(position.getPosition1().getPositionInNotional(), is(2_000_000.0));

            assertThat(position.getPosition2().getCcy(), is(Currency.JPY));
            assertThat(position.getPosition2().getPositionInNotional(), is(-177_010_000.0));

            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.USD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(2_000_000.0 + (-240_000_000 / 88.5)));

            assertThat(biasedPosition.getPosition2().getCcy(), is(Currency.JPY));
            assertThat(biasedPosition.getPosition2().getPositionInNotional(), is(closeTo(position.getPosition2().getPositionInNotional() + 240_000_000, EPSILON)));
            assertThat(biasedPosition.getPosition2().getPositionInSystemBase(), is(closeTo(biasedPosition.getPosition2().getPositionInNotional() / 88.500, EPSILON)));
            assertThat(biasedPosition.getPosition2().getAvgRate(), isRoundedTo(88.48595238)); // 62990000 / 711864
        }
        when:
        // Send positive biased offset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.JPY, 80_000_000));
        }
        then:
        {
            prophet.notExpect(Positions.class, isPortfolio(Portfolio.CLIENTS_NET));
            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.countPositions(), is(2));
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.USD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(2_000_000.0 + (80_000_000 / 88.5)));
            assertThat(biasedPosition.getPosition2().getCcy(), is(Currency.JPY));
            assertThat(biasedPosition.getPosition2().getPositionInNotional(), is(closeTo((-177_010_000.0) + (-80_000_000), EPSILON)));
            assertThat(biasedPosition.getPosition2().getPositionInSystemBase(), is(biasedPosition.getPosition2().getPositionInNotional() / 88.500));
        }
    }

    @Test
    public void biased_position_limit_breached() {
        double ccyLimitUsd = 2_000_000.0;
        double totalLimitUsd = 2_100_000.0;

        setup:
        {
            prophet.resetAllPositions();
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.POSITION_BIAS_OFFSET_CURRENCY_LIMIT_USD, ccyLimitUsd))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.POSITION_BIAS_OFFSET_TOTAL_LIMIT_USD, totalLimitUsd))
            );
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDJPY, 88.000, 0.04));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
        }
        when:
        // Send AUD biased position
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, 2_000_000));
        }
        then:
        {
            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(-2_000_000.0));
            assertThat(biasedOffset.getPosition1().getPositionInSystemBase(), is(-1_500_000.0));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(1_500_000.0));
        }
        when:
        // Send JPY biased position
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.JPY, -88_000_000.0));
        }
        then:
        {
            prophet.notExpect(Positions.class, isPortfolio(Portfolio.CLIENTS_NET));
            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(1_500_000.0 + (-1_000_000.0)));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.JPY));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(88_000_000.0));
        }
        when:
        // Send AUD biased position breaching ccy usd limit
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, (2_000_000.0 / 0.75) + 1));
        }
        then:
        // since ccy usd limit breached, resend existing position bias offset
        {
            prophet.expect(Level.WARN, matches(".*AUD greater than 2000000.0 USD, requested -2000000.75"));

            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(-2_000_000.0));
            assertThat(biasedOffset.getPosition1().getPositionInSystemBase(), is(-1_500_000.0));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(500_000.0));
        }
        when:
        // Send JPY biased position breaching ccy usd limit
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.JPY, (-2_000_000.0 * 88.00) - 1));
        }
        then:
        // since ccy usd limit breached, resend existing offset
        {
            prophet.expect(Level.WARN, matches(".*JPY greater than 2000000.0 USD, requested 2000000.0113636365"));

            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(500_000.0));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.JPY));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(88_000_000.0));
        }
        when:
        // Send JPY biased position breaching TOTAL ccy usd limit
        {
            prophet.clearOutputBuffer();
            // existing biased AUD in system base is -1.5mio
            prophet.receive(tdd.biasPosition(Currency.JPY, (600_000 * 88.000) + 1));
        }
        then:
        // since ccy usd limit breached, resend existing offset
        {
            prophet.expect(Level.WARN, matches(".*JPY greater than 2100000.0 USD, requested -2100000.0113636362"));

            Positions biasedOffset = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasedOffset.getPosition1().getCcy(), is(Currency.USD));
            assertThat(biasedOffset.getPosition1().getPositionInNotional(), is(500_000.0));
            assertThat(biasedOffset.getPosition2().getCcy(), is(Currency.JPY));
            assertThat(biasedOffset.getPosition2().getPositionInNotional(), is(88_000_000.0));
        }
    }
}
