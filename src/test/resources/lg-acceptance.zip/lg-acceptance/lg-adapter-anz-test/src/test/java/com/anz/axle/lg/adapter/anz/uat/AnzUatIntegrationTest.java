package com.anz.axle.lg.adapter.anz.uat;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.anz.acceptance.AcceptanceConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.NanoClock;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

@Category(UatTest.class)
@RunWith(Spockito.class)
public class AnzUatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(AnzUatIntegrationTest.class);
    public static final String GB_LG_ANZ = "GB:lg-anz";
    public static final String GB_LG_ACC = "GB:lg-acc";
    private static final String CLIENT_ID = "tester1";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private PriceListener priceListener;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-anz" +
                                ",default.log.level:DEBUG" +
                                ",anz.fix.log.destination:FILE" +
                                ",anz.fix.trading.reset.on.logon:Y" +
                                ",anz.fix.trading.reset.on.logout:Y" +
                                ",anz.fix.trading.reset.on.disconnect:Y" +

                                ",anz.fix.pricing.sendercompid:PINK_GB_ANZD_FXAGG_MD" +
                                ",anz.fix.pricing.targetcompid:PINK_ANZ_DAPI_MD" +
                                ",anz.fix.pricing.host:daxa003z.unix.anz" +
                                ",anz.fix.pricing.port:7565" +
                                ",anz.fix.pricing.password:anz12345" +

                                ",anz.fix.trading.sendercompid:PINK_GB_ANZD_FXAGG_TR" +
                                ",anz.fix.trading.targetcompid:PINK_ANZ_DAPI_TR" +
                                ",anz.fix.trading.host:daxa003z.unix.anz" +
                                ",anz.fix.trading.port:7566" +
                                ",anz.fix.trading.password:anz12345"
                ));

        application = new Application("lg-anz-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        priceListener = new PriceListener(acceptanceContext.pricingMessageQueue());
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void testSendOrderAndReceiveExecutionReport() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(GB_LG_ANZ))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.ANZD))
                .entries().anyMatches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                .hops().hasAny();

        final PriceEntry priceEntry = priceListener.awaitPrice(matcher, EntryType.OFFER);

        System.out.println(priceEntry);
        System.out.println("==============================================================");

        final NewOrderSingle newOrderSingle = newOrderSingle(priceEntry.instrumentKey.symbol(), clOrdId, priceEntry.side, priceEntry.price,
                CLIENT_ID, priceEntry.size, priceEntry.currency(), OrderType.LIMIT, priceEntry);
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertSingleFill(priceEntry, clOrdId, OrderType.LIMIT);
    }

    private NewOrderSingle newOrderSingle(final String symbol, final String clOrdId, final Side side, final double price, final String clientId,
                                          final double size, final String currency, final OrderType orderType, final PriceEntry priceEntry) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.timeInForce = TimeInForce.FOK;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.symbol = symbol;
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.side = side;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.transactTime = NanoClock.nanoClockUTC().nanos();
        newOrderSingle.parties.add(new Party(PartyRole.CLIENT_ID, clientId));
        newOrderSingle.body.settlDate = priceEntry.settlDate;

        return newOrderSingle;
    }

    private void assertSingleFill(final PriceEntry priceEntry, final String clOrdId, final OrderType orderType) throws Exception {

        final Queue<TradingMessage> receivedResponse = receivedResponse(2, 1l, 10);

        Asserter.of(receivedResponse)
            .matching(ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_ANZ))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.symbol().eq(priceEntry.instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(priceEntry.currency()))
                .body().matches(ExecutionReportMatcher.marketId().eq(Venue.ANZD.name()))
                .body().matches(ExecutionReportMatcher.side().eq(priceEntry.side))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0)
                .hops().countAtLeast(2))
            .thenMatching(ExecutionReportMatcher.build()
                    .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_ANZ))
                    .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                    .body().matches(ExecutionReportMatcher.marketId().eq(Venue.ANZD.name()))
                    .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                    .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                    .body().matches(ExecutionReportMatcher.symbol().eq(priceEntry.instrumentKey.symbol()))
                    .body().matches(ExecutionReportMatcher.currency().eq(priceEntry.currency()))
                    .body().matches(ExecutionReportMatcher.side().eq(priceEntry.side))
                    .strategyParameters().countEquals(0)
                    .regulatoryTradeIds().countEquals(0)
                    .hops().countAtLeast(2))
            .awaitMatchAndGetLast(20, TimeUnit.SECONDS);
    }

    private Queue<TradingMessage> receivedResponse(final int expectedNo, final long secondsDelay, final int noOfDelay) throws Exception {
        final Queue<TradingMessage> receivedResponses = new ConcurrentLinkedQueue();
        int delayCount = 0;
        while (receivedResponses.size() < expectedNo) {
            if (delayCount == noOfDelay) {
                receivedResponses.forEach(e -> System.out.println("Received: " + e));
                Assert.fail("Expected " + expectedNo + ", but only " + receivedResponses.size() + " received.");
            }

            final TradingMessage event = acceptanceContext.tradingResponseMessageQueue().poll();
            if (event != null) {
                receivedResponses.add(event);
            } else {
                System.out.println("Waiting for message. Expected " + expectedNo + ", but only " + receivedResponses.size() + " received. Delay " + delayCount +"/"+noOfDelay);
                TimeUnit.SECONDS.sleep(secondsDelay);
                delayCount++;
            }
        }
        return receivedResponses;
    }
}