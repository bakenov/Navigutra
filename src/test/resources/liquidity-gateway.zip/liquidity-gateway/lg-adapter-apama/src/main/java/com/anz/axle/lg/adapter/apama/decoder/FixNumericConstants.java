package com.anz.axle.lg.adapter.apama.decoder;


public final class FixNumericConstants {
    public static final Long MIN_QTY = Long.valueOf(110);
    public static final Long BID_PX = Long.valueOf(132);
    public static final Long OFFER_PX = Long.valueOf(133);
    public static final Long BID_SIZE = Long.valueOf(134);
    public static final Long OFFER_SIZE = Long.valueOf(135);
    public static final Long QUOTE_CONDITION = Long.valueOf(276);
    public static final Long MD_ENTRY_ID = Long.valueOf(278);
    public static final Long MD_ENTRY_REF_ID = Long.valueOf(280);
    public static final Long QUOTE_ENTRY_ID = Long.valueOf(299);
    public static final Long QUOTE_TYPE = Long.valueOf(537);
    public static final long TAG_QUOTE_CONDITION = 276;
    public static final long TAG_TRADE_CONDITION = 277;
    public static final long TAG_CFI_CODE = 461;
    public static final long TAG_SETTL_TYPE = 63;
    public static final long TAG_SETTL_DATE = 64;
}
