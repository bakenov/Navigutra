package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;

import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.itch.cfg.ItchEngineCfg;
import software.chronicle.itch.cfg.ItchSessionCfg;
import software.chronicle.itch.sessioncode.messages.client.LogoutRequest;
import software.chronicle.itch.sessioncode.messages.server.LoginAccepted;
import software.chronicle.itch.staticcode.ChronicleItchEngine;
import software.chronicle.itch.staticcode.ItchLog;
import software.chronicle.itch.staticcode.ItchServerSessionHandler;
import software.chronicle.itch.staticcode.SessionMessageProvider;
import software.chronicle.itchcboe.messages.MarketSnapshot;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredChronicleMessageHandler;
import com.anz.axle.lg.adapter.chronicleitch.ItchEncodingSubscriptionSender;
import com.anz.axle.lg.adapter.chronicleitch.ItchEngine;
import com.anz.axle.lg.adapter.chronicleitch.ItchLogConsumer;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestSender;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import software.chronicle.itchcboe.messages.server.Sequenced;

@Configuration
public class ItchConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItchConfig.class);

    private final String compId;
    private final String senderCompId;
    private final Venue venue;

    public ItchConfig(@Value("${messaging.compId}") final String compId,
                      @Value("${messaging.senderCompId}") final String senderCompId,
                      @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public ItchEngineCfg itchEngineCfg(@Qualifier("applicationProperties") final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/hsp-chronicleitch.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        ClassAliasPool.CLASS_ALIASES.addAlias(
                ItchEngineCfg.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                LoggingMode.class);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final ItchEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

    @Bean
    public SessionMessageProvider sessionMessageProvider(@Value("${hsp.itch.pricing.username}") final String userName,
                                                         @Value("${hsp.itch.pricing.password}") final String password) {
        return new HspSessionMessageProvider(userName, password);
    }

    @Bean
    public LongSupplier sequenceNumberSupplier() {
        final AtomicLong sequenceNumber = new AtomicLong();
        return () -> sequenceNumber.incrementAndGet();
    }

    @Bean
    public LogonHandler logonHandler(@Qualifier("marketDataSubscriber") final Supplier<LogonHandler> pricingSessionLogonHandlerSupplier) {
        return pricingSessionLogonHandlerSupplier.get();
    }

    @Bean
    public ChronicleMessageHandler<Object> adminMessageMessageHandler(final LogonHandler logonHandler,
                                                                      final Queue<Runnable> mainEventLoopQueue) {
        return (message) -> {
            if (message instanceof LoginAccepted) {
                mainEventLoopQueue.appender().enqueue(() -> logonHandler.onLogon());
            } else if (message instanceof Sequenced || message instanceof LogoutRequest) {
                mainEventLoopQueue.appender().enqueue(() -> logonHandler.onLogout());
            }
        };
    }

    @Bean
    public Consumer<ItchLog> itchLogConsumer(@Value("${hsp.itch.pricing.log_all}") final boolean enableLogging,
                                             @Value("${hsp.itch.pricing.filestore.base_path}") final String bashPath,
                                             @Value("${hsp.itch.log.queue.RollCycle}") final RollCycles rollCycle) {
        return ItchLogConsumer.create(enableLogging, bashPath, rollCycle);
    }

    @Bean
    public ItchSessionCfg itchSessionCfg(final ItchEngineCfg itchEngineCfg,
                                         final SessionMessageProvider sessionMessageProvider) {
        final ItchSessionCfg itchSessionCfg = (ItchSessionCfg)itchEngineCfg.fixSessionCfgs().iterator().next();
        itchSessionCfg.sessionMessageProviderItch(sessionMessageProvider);
        return itchSessionCfg;
    }

    @Bean
    public ItchAdminMessageSender itchAdminMessageSender(@Lazy final ItchEngine itchEngine) {
        return new ItchAdminMessageSender(() -> (ItchServerSessionHandler) itchEngine.getConnector().getHandler("CLIENT"));
    }

    @Bean
    public ItchAppMessageSender itchAppMessageSender(@Lazy final ItchEngine itchEngine) {
        return new ItchAppMessageSender(() -> (ItchServerSessionHandler) itchEngine.getConnector().getHandler("CLIENT"));
    }

    @Bean
    public ItchEngine itchEngine(final ItchEngineCfg itchEngineCfg,
                                 final SessionMessageProvider sessionMessageProvider,
                                 final LogonHandler logonHandler,
                                 final VenueRequestKeyLookup requestKeyLookup,
                                 final PricingEncoderLookup pricingEncoderLookup,
                                 final PrecisionClock precisionClock,
                                 final SubscriptionManager subscriptionManager,
                                 final LongSupplier sequenceNumberSupplier,
                                 final ChronicleMessageHandler<Object> adminMessageMessageHandler,
                                 final MetricRepository<Metric, Venue> metricRepository,
                                 final EventLoopAdapter itchPricingEventLoopStep,
                                 final Consumer<ItchLog> itchLogConsumer,
                                 final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshEncoderFlagsAppender,
                                 final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> snapshotFullRefreshEncoderFlagsAppender,
                                 @Value("${hsp.itch.pricing.session.enable:true}") final boolean enablePricingSession,
                                 final SourceSequencer sourceSequencer) {
        final ItchSessionCfg itchSessionCfg = (ItchSessionCfg)itchEngineCfg.fixSessionCfgs().iterator().next();
        itchSessionCfg.sessionMessageProviderItch(sessionMessageProvider);
        itchSessionCfg.consumerItch(itchLogConsumer);
        final SymbolOrderIdSideLookUp symbolOrderIdSideLookUp = new SymbolOrderIdSideLookUp();
        final ChronicleMessageHandler<MarketSnapshot> marketSnapshotHandler = new HspMarketSnapshotHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, sequenceNumberSupplier, senderCompId, compId, symbolOrderIdSideLookUp, snapshotFullRefreshEncoderFlagsAppender, sourceSequencer);
        final HspIncrementalMessageHandler incrementalMessageHandler = new HspIncrementalMessageHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, sequenceNumberSupplier, senderCompId, compId, symbolOrderIdSideLookUp, incrementalRefreshEncoderFlagsAppender, sourceSequencer);

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value);

        final ItchPricingApplication itchPricingApplication = new ItchPricingApplication(
                new MonitoredChronicleMessageHandler<>(adminMessageMessageHandler, metricRecorder),
                new MonitoredChronicleMessageHandler<>(marketSnapshotHandler, metricRecorder),
                new MonitoredChronicleMessageHandler<>(incrementalMessageHandler.newOrderHandler(), metricRecorder),
                new MonitoredChronicleMessageHandler<>(incrementalMessageHandler.modifyOrderHandler(), metricRecorder),
                new MonitoredChronicleMessageHandler<>(incrementalMessageHandler.cancelOrderHandler(), metricRecorder));
        itchSessionCfg.messageNotifierItch(itchPricingApplication);

        final ChronicleItchEngine chronicleItchEngine = new ChronicleItchEngine(itchPricingEventLoopStep, Arrays.asList(itchSessionCfg));
        return ItchEngine.create(venue.name(), chronicleItchEngine, logonHandler, enablePricingSession);
    }

    @Bean
    public SubscriptionRequestSender encodingSubscriptionSender(final ItchAppMessageSender itchAppMessageSender) {
        return new ItchEncodingSubscriptionSender(
                new HspItchMarketDataRequestEncoder(),
                (msg) -> itchAppMessageSender.accept(msg));
    }
}