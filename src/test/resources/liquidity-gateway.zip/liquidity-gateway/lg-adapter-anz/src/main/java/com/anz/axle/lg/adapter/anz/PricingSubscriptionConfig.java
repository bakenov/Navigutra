package com.anz.axle.lg.adapter.anz;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
public class PricingSubscriptionConfig {

    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final AsyncMarketDataSubscriber asyncMarketDataSubscriber;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final Venue venue;

    public PricingSubscriptionConfig(final TopicRegistry pricingTopicRegistry,
                                     final PublicationRegistry publicationRegistry,
                                     final AsyncMarketDataSubscriber asyncMarketDataSubscriber,
                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues) {
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.asyncMarketDataSubscriber = Objects.requireNonNull(asyncMarketDataSubscriber);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.venue = Venue.ANZD;
    }

    @PostConstruct
    void init() {
        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol));
            publicationRegistry.registerPublication(topic);

            final AnzMarketDataSubscription fixSubscription =
                    AnzMarketDataSubscription.idSymbol(SymbolNormaliser.toSymbol7(symbol));
            asyncMarketDataSubscriber.schedule(fixSubscription);
        });
    }
}
