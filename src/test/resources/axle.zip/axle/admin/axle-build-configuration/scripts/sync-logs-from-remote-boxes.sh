#!/bin/bash

echo "Start sync-logs-from-remote-boxes... ("`date`")"

#Note: RED-Correlator2 and Purple-Correlator2 is excluded from the list
SERVERS=( daxa018z daxa019z daxa012z auq4000s daxa003z )
FILES_TO_SYNC=( "log-VWAP-order*" "log-SOR-order*" "log-FirewallLiquidityCategoryExclusionService.log" "log-FirewallServiceThrottler*" )

cd /app/fxdev/hudson/scripts
WEBAPPS=/app/fxdev/apache-tomcat/webapps
LOG_DEST=~/axle/logs
if [ ! -d $LOG_DEST ] 
then
	echo "Creating base directory $LOG_DEST..."
	mkdir $LOG_DEST
fi

for SERVER in ${SERVERS[@]}
do 
	SERVER_DEST=$LOG_DEST/$SERVER
	if [ ! -d $SERVER_DEST ] 
	then
		echo "Creating base directory $SERVER_DEST..."
		mkdir $SERVER_DEST
	fi

	FXAGG_DEST=$SERVER_DEST/fxagg
	if [ ! -d $FXAGG_DEST ] 
	then
		echo "Creating base directory $FXAGG_DEST..."
		mkdir $FXAGG_DEST
	fi

	for FILE in ${FILES_TO_SYNC[@]}
	   do 
		echo "rsync $SERVER: $FILE"
		/opt/sfw/bin/rsync --rsync-path=/opt/sfw/bin/rsync -ar axle@$SERVER:~/logs/fxagg/$FILE $FXAGG_DEST 
		
		# create symbolic link when not exist 
		if [ ! -d $WEBAPPS/logs ]
		then
			echo "Create symbolic link $WEBAPPS/logs -> /app/fxdev/axle/logs"
			ln -s /app/fxdev/axle/logs $WEBAPPS/logs	
		fi
		echo ""
	done
done

cd $LOG_DEST
# remove logs which are 8 weeks old
count=`find . -type f -mtime +56 | wc -l | sed 's/^ *//'`
if [ $count -gt 0 ]
then
	echo "Removing logs which are 8 weeks old ..." 
	echo "There is $count item(s) that are 8 weeks old"
	find . -type f -mtime +56 -print
	find . -type f -mtime +56 | xargs rm
fi

echo "Done sync-logs-from-remote-boxes"
