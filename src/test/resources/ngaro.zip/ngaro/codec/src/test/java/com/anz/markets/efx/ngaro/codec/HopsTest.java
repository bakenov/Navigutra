package com.anz.markets.efx.ngaro.codec;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class HopsTest {

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private OrderEncoder orderEncoder;

    interface OrderEncoder extends MessageEncoder<OrderEncoder.Body> {
        interface Body extends Hops.Encoder<MessageEncoder.Trailer> {
            OrderEncoder.Body orderId(int id);
            OrderEncoder.Body quantity(double qty);
            OrderEncoder.Body price(double price);
        }
    }

    private static final class Hop {
        final String hopCompId;
        final long hopMessageId;
        final long hopReceivingTime;
        final long hopSendingTime;
        public Hop(final Hops.Handler.Body hopBody) {
            this.hopCompId = hopBody.hopCompId().decodeStringOrNull();
            this.hopMessageId = hopBody.hopMessageId();
            this.hopReceivingTime = hopBody.hopReceivingTime();
            this.hopSendingTime = hopBody.hopSendingTime();
        }
    }

    @Test
    public void hopsEncoderIntrospector_introspect() {
        //given
        final List<Hop> hops = new ArrayList<>();
        final Hops.Handler introspectingHandler = spy(new Hops.Handler() {
            @Override
            public void onHops_Body(Body hop, int hopsIndex, int maxHopsCount) {
                hops.add(new Hop((hop)));
            }
        });
        final Hops.EncoderIntrospector hopsIntrospector = Hops.EncoderIntrospector.create(introspectingHandler);

        //WHEN: without introspection
        orderEncoder.messageStart(2,20)
                .orderId(123)
                .price(1.22345)
                .quantity(1000000)
                .hopsStart(2).next()
                    .hopCompId().encode("COMPID_1")
                    .hopMessageId(111)
                    .hopReceivingTime(0)
                    .hopSendingTime(111111)
                .next()
                    .hopCompId().encode("COMPID_2")
                    .hopMessageId(222)
                    .hopReceivingTime(222222)
                    .hopSendingTime(333333)
                .hopsComplete()
                .messageComplete();

        //THEN
        verify(introspectingHandler, never()).onHopsStart(anyInt());
        verify(introspectingHandler, never()).onHops_Body(any(), anyInt(), anyInt());
        verify(introspectingHandler, never()).onHopsComplete(anyInt());

        //WHEN: with introspection
        hopsIntrospector.introspect(
                orderEncoder.messageStart(2,20)
                    .orderId(123)
                    .price(1.22345)
                    .quantity(1000000)
                ).hopsStart(3).next()
                    .hopCompId().encode("COMPID_1")
                    .hopMessageId(111)
                    .hopReceivingTime(0)
                    .hopSendingTime(111111)
                .next()
                    .hopCompId().encode("COMPID_2")
                    .hopMessageId(222)
                    .hopReceivingTime(222222)
                    .hopSendingTime(333333)
                .hopsComplete()
                .messageComplete();

        //THEN
        verify(introspectingHandler).onHopsStart(3);
        verify(introspectingHandler).onHops_Body(any(), eq(0), eq(3));
        verify(introspectingHandler).onHops_Body(any(), eq(1), eq(3));
        verify(introspectingHandler).onHopsComplete(2);

        assertEquals("hops count", 2, hops.size());
        assertEquals("hop[0].hopCompId", "COMPID_1", hops.get(0).hopCompId);
        assertEquals("hop[0].hopMessageId", 111, hops.get(0).hopMessageId);
        assertEquals("hop[0].hopReceivingTime", 0, hops.get(0).hopReceivingTime);
        assertEquals("hop[0].hopSendingTime", 111111, hops.get(0).hopSendingTime);
        assertEquals("hop[1].hopCompId", "COMPID_2", hops.get(1).hopCompId);
        assertEquals("hop[1].hopMessageId", 222, hops.get(1).hopMessageId);
        assertEquals("hop[1].hopReceivingTime", 222222, hops.get(1).hopReceivingTime);
        assertEquals("hop[1].hopSendingTime", 333333, hops.get(1).hopSendingTime);
    }

    @Test
    public void hopsEncoderIntrospector_introspectEmpty() {
        //given
        final Hops.Handler introspectingHandler = mock(Hops.Handler.class);
        final Hops.EncoderIntrospector hopsIntrospector = Hops.EncoderIntrospector.create(introspectingHandler);
        final InOrder inOrder = inOrder(introspectingHandler);

        //when
        hopsIntrospector.introspect(
                orderEncoder.messageStart(2, 20)
                        .orderId(123)
                        .price(1.22345)
                        .quantity(1000000)
        ).hopsEmpty().messageComplete();

        //then
        inOrder.verify(introspectingHandler).onHopsStart(0);
        inOrder.verify(introspectingHandler, never()).onHops_Body(any(), anyInt(), anyInt());
        inOrder.verify(introspectingHandler).onHopsComplete(0);

        //when
        hopsIntrospector.introspect(
                orderEncoder.messageStart(2,20)
                        .orderId(123)
                        .price(1.22345)
                        .quantity(1000000)
        ).hopsStart(1).hopsComplete();

        //then
        inOrder.verify(introspectingHandler).onHopsStart(1);
        inOrder.verify(introspectingHandler, never()).onHops_Body(any(), anyInt(), anyInt());
        inOrder.verify(introspectingHandler).onHopsComplete(0);
    }

    @Test(expected = IllegalStateException.class)
    public void hopsEncoderIntrospector_outOfOrderEncoding() {
        //given
        final Hops.Handler introspectingHandler = mock(Hops.Handler.class);
        final Hops.EncoderIntrospector hopsIntrospector = Hops.EncoderIntrospector.create(introspectingHandler);
        final InOrder inOrder = inOrder(introspectingHandler);

        //when
        final Hops.Encoder<MessageEncoder.Trailer> encoder = hopsIntrospector.introspect(
                orderEncoder.messageStart(2,20)
                        .orderId(123)
                        .price(1.22345)
                        .quantity(1000000)
        );

        encoder.hopsEmpty().messageComplete();

        encoder.hopsStart(1);
    }
}