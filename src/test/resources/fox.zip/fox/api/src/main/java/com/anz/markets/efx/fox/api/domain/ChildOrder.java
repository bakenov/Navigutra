package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;

public interface ChildOrder {
    void onTransition();
    ChildOrderDetails details();
    ParentOrder parentOrder();
    void init(EventContext eventContext, NewOrderSingleDecoder newOrderSingleDecoder, ParentOrder parentOrder);
    void requestCancel(CommandContext commandContext, OrderCancelRequestDecoder parentOrderCancelRequestDecoder);
    void applyCancelRequest(OrderCancelRequestDecoder orderCancelRequestDecoder);
    void applyExecutionReport(ExecutionReportDecoder executionReportDecoder);
    void applyOrderCancelReject(OrderCancelRejectDecoder orderCancelRejectDecoder);
    void release();
    void accept(ChildOrderVisitor visitor);
}
