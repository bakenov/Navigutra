package com.anz.axle.lg.adapter.citi.quickfix;

import java.util.Objects;

import quickfix.field.MsgType;
import quickfix.field.OrderQty;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteRequestType;
import quickfix.field.QuoteType;
import quickfix.field.Symbol;
import quickfix.field.TargetSubID;
import quickfix.fix44.QuoteRequest;

import com.anz.axle.lg.adapter.fix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

public class CitiMarketDataRequestEncoder implements MarketDataRequestEncoder<QuoteRequest> {
    protected static final char SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE = '1';
    protected static final char SUBSCRIPTION_REQUEST_TYPE_UNSUBSCRIBE = '2';
    private static final int TIERED_MASS_QUOTE = -1;
    private final String targetSubId;
    private final boolean requestTieredMassQuote;
    private final QuoteRequest quoteRequest = new QuoteRequest();
    private final QuoteRequest.NoRelatedSym group = new QuoteRequest.NoRelatedSym();

    public CitiMarketDataRequestEncoder(final String targetSubId,
                                        final boolean requestTieredMassQuote) {
        this.targetSubId = Objects.requireNonNull(targetSubId);
        this.requestTieredMassQuote = requestTieredMassQuote;
    }

    @Override
    public QuoteRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(quoteRequest, requestId, subscription, SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE);
    }

    @Override
    public QuoteRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(quoteRequest, requestId, subscription, SUBSCRIPTION_REQUEST_TYPE_UNSUBSCRIBE);
    }

    private QuoteRequest encode(final QuoteRequest quoteRequest, final long requestId, final MarketDataSubscription subscription, final char subscriptionRequestType) {
        quoteRequest.clear();
        quoteRequest.getHeader().setString(MsgType.FIELD, MsgType.QUOTE_REQUEST);
        quoteRequest.getHeader().setString(TargetSubID.FIELD, targetSubId);
        quoteRequest.setString(QuoteReqID.FIELD, Long.toString(requestId));
        group.clear();
        group.setString(Symbol.FIELD, subscription.instrumentKey().symbol());
        group.setInt(QuoteRequestType.FIELD, QuoteRequestType.AUTOMATIC);
        group.setInt(QuoteType.FIELD, QuoteType.RESTRICTED_TRADEABLE);
        group.setString(quickfix.field.Currency.FIELD, subscription.symbol().substring(0, 3));
        if(requestTieredMassQuote) {
            group.setDouble(OrderQty.FIELD, TIERED_MASS_QUOTE);
        }
        quoteRequest.addGroup(group);
        return quoteRequest;
    }
}
