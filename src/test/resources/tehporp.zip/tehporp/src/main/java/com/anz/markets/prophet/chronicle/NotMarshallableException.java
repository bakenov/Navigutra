package com.anz.markets.prophet.chronicle;

public class NotMarshallableException extends RuntimeException {
}
