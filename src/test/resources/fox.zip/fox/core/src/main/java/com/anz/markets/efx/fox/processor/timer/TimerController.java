package com.anz.markets.efx.fox.processor.timer;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.LongSupplier;

import org.agrona.DeadlineTimerWheel;
import org.agrona.collections.Long2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.sbe.TimerExpirySbeDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class TimerController {
    private static final Logger LOGGER = LoggerFactory.getLogger(TimerController.class);

    private final int sourceId;
    private final LongSupplier idGenerator;

    private final TimeUnit timeUnit;
    private final Function<TimeUnit, DeadlineTimerWheel> timerWheelFactory;
    private final LongSupplier systemTimeSupplier;
    private final LongSupplier eventTimeSupplier;
    private final int maxTimersToExpire;
    private final SorEncoderSupplier sorEncoderSupplier;
    private final Long2ObjectHashMap<TimerScheduler.ExpiryHandler> timerToObjectMap = new Long2ObjectHashMap<>();

    private final TimerScheduler timerScheduler;
    private final EventLoopStep eventLoopStep;

    private DeadlineTimerWheel timerWheel;

    public TimerController(final int sourceId,
                           final LongSupplier idGenerator,
                           final TimeUnit timeUnit,
                           final Function<TimeUnit, DeadlineTimerWheel> timerWheelFactory,
                           final LongSupplier systemTimeSupplier,
                           final LongSupplier eventTimeSupplier,
                           final int maxTimersToExpire,
                           final SorEncoderSupplier sorEncoderSupplier) {
        this.sourceId = sourceId;
        this.idGenerator = Objects.requireNonNull(idGenerator);
        this.timerWheelFactory = Objects.requireNonNull(timerWheelFactory);
        this.timeUnit = timeUnit;
        this.systemTimeSupplier = Objects.requireNonNull(systemTimeSupplier);
        this.eventTimeSupplier = Objects.requireNonNull(eventTimeSupplier);
        this.maxTimersToExpire = maxTimersToExpire;
        this.sorEncoderSupplier = Objects.requireNonNull(sorEncoderSupplier);

        this.timerScheduler = new Scheduler();
        this.eventLoopStep = new Step();
    }

    public static TimerController forNanosClock(final int sourceId,
                                                final LongSupplier idGenerator,
                                                final PrecisionClock systemPrecisionClock,
                                                final PrecisionClock eventPrecisionClock,
                                                final int maxTimersToExpire,
                                                final int tickResolution,
                                                final int ticksPerWheel,
                                                final SorEncoderSupplier sorEncoderSupplier) {
        return new TimerController(sourceId,
                idGenerator,
                TimeUnit.NANOSECONDS,
                timeUnit -> new DeadlineTimerWheel(timeUnit, eventPrecisionClock.nanos(), tickResolution, ticksPerWheel),
                systemPrecisionClock::nanos,
                eventPrecisionClock::nanos,
                maxTimersToExpire,
                sorEncoderSupplier);
    }

    public TimerScheduler timerScheduler() {
        return timerScheduler;
    }

    public EventLoopStep eventLoopStep() {
        return eventLoopStep;
    }

    public MessageDecoder<SbeMessage> timerExpiryCommand(final CommandContext commandContext) {
        return new TimerExpiryCommand(commandContext);
    }

    public MessageDecoder<SbeMessage> timerExpiryEvent() {
        return new TimerExpiryEvent();
    }

    private DeadlineTimerWheel timerWheel() {
        if (timerWheel == null) {
            timerWheel = timerWheelFactory.apply(timeUnit);
        }
        return timerWheel;
    }

    class Scheduler implements TimerScheduler {
        @Override
        public long schedule(final long millis, final TimerScheduler.ExpiryHandler expiryHandler) {
            final long now = eventTimeSupplier.getAsLong();
            final long timeoutInTimeunit = timeUnit.convert(millis, TimeUnit.MILLISECONDS);
            final long timerId = timerWheel().scheduleTimer(now + timeoutInTimeunit);
            timerToObjectMap.put(timerId, expiryHandler);

            LOGGER.debug("Scheduled timer {}", timerId);

            return timerId;
        }

        @Override
        public boolean cancel(final long timerId) {
            timerToObjectMap.remove(timerId);
            final boolean timerCancelled = timerWheel().cancelTimer(timerId);
            LOGGER.debug("Cancelled timer {}, {}", timerId, timerCancelled);
            return timerCancelled;
        }
    }

    class Step implements EventLoopStep {
        private final DeadlineTimerWheel.TimerHandler timerHandler = (tUnit, now, timerId) -> {
            final long triggeredTimeNanos = tUnit.toNanos(now);
            final TimerScheduler.ExpiryHandler expiryHandler = timerToObjectMap.get(timerId);
            if (expiryHandler != null) {
                LOGGER.debug("Sent timer expiry timerId={}, triggeredTimeNanos={}", timerId, triggeredTimeNanos);

                sorEncoderSupplier.timerExpiryEncoder()
                        .messageStart(sourceId, idGenerator.getAsLong())
                        .triggeredTime(triggeredTimeNanos)
                        .timerId(timerId)
                        .timerGroup(expiryHandler.timerGroup())
                        .messageComplete();
            }
            return true;
        };

        @Override
        public boolean process() {
            if (timerWheel != null) {
                final long tickTimeBefore = timerWheel.currentTickTime();
                final int expired = timerWheel.poll(systemTimeSupplier.getAsLong(), timerHandler, maxTimersToExpire);
                return expired > 0 || timerWheel.currentTickTime() - tickTimeBefore > 0;
            }
            return false;
        }
    }

    class TimerExpiryCommand implements MessageDecoder<SbeMessage> {
        private final CommandContext commandContext;
        private final TimerExpirySbeDecoder decoder = new TimerExpirySbeDecoder();

        public TimerExpiryCommand(final CommandContext commandContext) {
            this.commandContext = Objects.requireNonNull(commandContext);
        }

        @Override
        public boolean decode(final SbeMessage message) {
            if (!decoder.wrap(message)) return false;

            LOGGER.debug("Received timer expiry as command timerId={}, triggeredTime={}", decoder.body().timerId(), decoder.body().triggeredTime());
            final long timerId = decoder.body().timerId();
            final TimerScheduler.ExpiryHandler expiryHandler = timerToObjectMap.get(timerId);
            if (expiryHandler != null && decoder.body().timerGroup() == expiryHandler.timerGroup()) {
                expiryHandler.onExpiryCommand(timerId, decoder.body().triggeredTime(), commandContext);
                LOGGER.debug("Handled timer expiry for timerId={}, triggeredTime={}", timerId, decoder.body().triggeredTime());
            }
            commandContext.eventApplier().decode(message);
            return true;
        }
    }

    class TimerExpiryEvent implements MessageDecoder<SbeMessage> {
        private final TimerExpirySbeDecoder decoder = new TimerExpirySbeDecoder();

        @Override
        public boolean decode(final SbeMessage message) {
            if (!decoder.wrap(message)) return false;

            LOGGER.debug("Received timer expiry as event timerId={}, triggeredTime={}", decoder.body().timerId(), decoder.body().triggeredTime());
            final long timerId = decoder.body().timerId();
            final TimerScheduler.ExpiryHandler expiryHandler = timerToObjectMap.remove(timerId);
            if (expiryHandler != null && decoder.body().timerGroup() == expiryHandler.timerGroup()) {
                LOGGER.debug("Cleaned timer timerId={}, triggeredTime={}", timerId, decoder.body().triggeredTime());
                expiryHandler.onExpiryEvent(timerId, decoder.body().triggeredTime());
                timerScheduler.cancel(timerId);
            }
            return true;
        }
    }
}
