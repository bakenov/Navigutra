package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.datamodel.AbstractDataModel;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSide;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.components.MarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

public final class FastSnapshotFullRefreshHandler implements FixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(FastSnapshotFullRefreshHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final SourceSequencer sourceSequencer;

    public FastSnapshotFullRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                          final PricingEncoderLookup pricingEncoderLookup,
                                          final PrecisionClock precisionClock,
                                          final SubscriptionManager subscriptionManager,
                                          final String senderCompId,
                                          final String compId,
                                          final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final AbstractDataModel message) throws IllegalArgumentException {
        accept(message, Long.MIN_VALUE);
    }

    @Override
    public void accept(final AbstractDataModel adm, long receivedByAdapterTimestampNanos) throws IllegalArgumentException {
        assert adm instanceof MarketDataSnapshotFullRefresh;
        final MarketDataSnapshotFullRefresh message = (MarketDataSnapshotFullRefresh) adm;

        final long receivingTimeNanos = receivedByAdapterTimestampNanos <= 0 ? precisionClock.nanos() : receivedByAdapterTimestampNanos;
        LOGGER.debug("MarketDataSnapshotFullRefresh received: {}", message);
        final Bytes mdReqID = message.mDReqID();
        final int mdRequestId = (int) mdReqID.parseLong();
        final long entriesCount = message.noMDEntries();

        if (entriesCount > 0) {
            final long sequenceNumber = message.msgSeqNum();
            final long messageId = sequenceNumber;
            final long sendingTimeNanos = message.sendingTime();

            final String fixSymbol = message.symbol();

            final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);
            subscription.validateSymbol(fixSymbol);

            final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());

            final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                    .possResend(false)
                    .marketId(requestKey.market())
                    .instrumentId(requestKey.instrumentKey().instrumentId())
                    .senderCompId().encode(compId)
                    .messageId(messageId)
                    .sendingTime(sendingTimeNanos)
                    .referenceSpotDate().encodeNull()
                    .tradeDate().encodeNull()
                    .settlDate().encodeNull()
                    .entriesStart((int) entriesCount);

            final long groups = message.noMDEntries();
            for (int i = 0; i < groups; i++) {
                final MarketDataSnapshotFullRefresh_MDEntriesGrp_1 priceEntryGroup = message.marketDataSnapshotFullRefresh_MDEntriesGrp_1(i);

                final char mdEntryType = priceEntryGroup.mDEntryType();
                final EntryType side = FixSide.from(mdEntryType);

                final Bytes mdEntryId = priceEntryGroup.mDEntryID();
                final int mdEntryIdInt = subscription.stringToIntCache().put(mdEntryId);

                final double mdEntryPx = priceEntryGroup.mDEntryPx();
                final double mdEntrySize = priceEntryGroup.mDEntrySize();

                final double minQty = Double.isNaN(priceEntryGroup.minQty()) ? 0.0 : priceEntryGroup.minQty();

                mdEntries_Next.next()
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(side)
                        .mdEntrySize(mdEntrySize)
                        .minQty(minQty)
                        .mdEntryPx(mdEntryPx)
                        .mdEntryId(mdEntryIdInt)
                        .quoteEntryId(0);
            }

            mdEntries_Next.entriesComplete()
                    .hopsStart(2)
                        .next()
                            .hopCompId().encode(senderCompId)
                            .hopMessageId(sequenceNumber)
                            .hopSendingTime(sendingTimeNanos)
                        .next()
                            .hopCompId().encode(compId)
                            .hopMessageId(messageId)
                            .hopReceivingTime(receivingTimeNanos)
                            .hopSendingTime(precisionClock.nanos())
                            .hopsComplete()
                        .messageComplete();
        }
    }
}
