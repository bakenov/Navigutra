package com.anz.markets.prophet.chronicle.legacychronicle;


import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.HeaderPredicates;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.kdb.KdbLastEventReader;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.ThreadUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;

public class LegacyChronicleReaderDependant implements ProphetReader {

    private static final Logger LOGGER = LoggerFactory.getLogger(LegacyChronicleReaderDependant.class);

    private LegacyChronicleReader LegacyChronicleReader = null;
    private final LegacyChronicleReaderConfig config;
    private final EnumMap<MessageType, ChronicleObjectReader> map;
    private final KdbLastEventReader kdbLastEventReader;
    private final long priceDataStartEventIdOverride;

    public LegacyChronicleReaderDependant(final LegacyChronicleReaderConfig config,
                                          final EnumMap<MessageType, ChronicleObjectReader> map,
                                          final KdbLastEventReader kdbLastEventReader) {
        this(config, map, kdbLastEventReader,0L);
    }

    public LegacyChronicleReaderDependant(final LegacyChronicleReaderConfig config,
                                          final EnumMap<MessageType, ChronicleObjectReader> map,
                                          final KdbLastEventReader kdbLastEventReader, final long priceDataStartEventIdOverride) {
        this.map = map;
        this.config = config;
        this.kdbLastEventReader = kdbLastEventReader;
        this.priceDataStartEventIdOverride = priceDataStartEventIdOverride;
    }

    @Override
    public void close() throws IOException {
        if (LegacyChronicleReader != null) {
            LegacyChronicleReader.close();
        }
    }

    @Override
    public void run() {
        try {
            LOGGER.info("Starting KDB Chronicle Reader...waiting for eventIds");
            final Map<MessageType, Long> eventIdsForMessageType = kdbLastEventReader.getEventIdsForMessageTypes(config.chroniclePath);
            final Context.HeaderPredicate messageTypeEventIdPredicate = getHeaderPredicate(eventIdsForMessageType, priceDataStartEventIdOverride, map);

            final Optional<Long> minimumEventId =  eventIdsForMessageType.values().stream().filter(e -> e != 0).min(Long::compare);
            final ChronicleObjectReader readers = new ChronicleObjectReaderMulti(map, true);
            final LegacyChronicleReaderConfigBuilder configBuilder = new LegacyChronicleReaderConfigBuilder(config).setHeaderFilter(messageTypeEventIdPredicate);
            if (minimumEventId.isPresent()) {
                // use EVENTID_CLOSEST for weekend restarts
                configBuilder.setStartAt(StartAt.EVENTID_CLOSEST).setStartPosition(minimumEventId.get());
            }
            new LegacyChronicleReader(ThreadUtils.SameThreadExecutor.INSTANCE, readers, configBuilder.createChronicleConfigReader());
        } catch (Exception e) {
            LOGGER.error("Failed to create chronicle reader", e);
            throw new RuntimeException("Failed to create chronicle reader", e);
        }
    }

    public static Context.HeaderPredicate getHeaderPredicate(final Map<MessageType, Long> eventIdsForMessageType, final long priceDataStartEventIdOverride, final EnumMap<MessageType, ChronicleObjectReader> map) {
        if(priceDataStartEventIdOverride > 0) {
            LOGGER.info("Using priceDataStartEventIdOverride {}", priceDataStartEventIdOverride);
            eventIdsForMessageType.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, priceDataStartEventIdOverride);
            eventIdsForMessageType.put(MessageType.CLIENT_PRICE, priceDataStartEventIdOverride);
        }
        return new HeaderPredicates.MessageTypeEventIdPredicate(eventIdsForMessageType, map);
    }
}
