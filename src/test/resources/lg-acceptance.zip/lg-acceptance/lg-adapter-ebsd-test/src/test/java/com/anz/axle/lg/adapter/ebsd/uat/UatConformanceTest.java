package com.anz.axle.lg.adapter.ebsd.uat;


import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.ebsd.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.ebsd.acceptance.AcceptanceContext;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;

import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.instrumentId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.marketId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.mdEntryType;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.senderCompId;

@Ignore("long running conformance test to be ignored.")
@RunWith(Spockito.class)
public class UatConformanceTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatConformanceTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("EURGBP", SecurityType.FXSPOT, Tenor.SP);

    public static final String GB_LG_EBSD = "GB:lg-ebsd";
    public static final String GB_LG_ACC = "GB:lg-acc";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PriceListener priceListener;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-ebsd" +
                                ",ebsd.fix.log.destination:STDOUT" +
                                ",ebsd.fix.trading.reset.on.logon:N" +
                                ",ebsd.fix.trading.reset.on.logout:N" +
                                ",ebsd.fix.trading.reset.on.disconnect:N" +
                                ",ebsd.fix.pricing.sendercompid:IVA1.QUOTE.3" +
                                ",ebsd.fix.pricing.targetcompid:EBS.TEST.QUOTE" +
                                ",ebsd.fix.pricing.host:10.54.189.41" +
                                ",ebsd.fix.pricing.port:9809" +
                                ",ebsd.fix.trading.sendercompid:IVA1.ORDER.3" +
                                ",ebsd.fix.trading.targetcompid:EBS.TEST.ORDER" +
                                ",ebsd.fix.trading.host:10.54.189.41" +
                                ",ebsd.fix.trading.port:9809" +
                                ",ebsd.fix.trading.account:IVA1" +
                                ",ebsd.fix.username:anz" +
                                ",ebsd.fix.password:anz123"
                ));

        application = new Application("lg-ebsd-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        priceListener = new PriceListener(acceptanceContext.pricingMessageQueue());
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static final String SYMBOL = "EURGBP";
    private static final String CURRENCY = "EUR";
    private static final Side SIDE = Side.BUY;
    private static final EntryType ENTRYTYPE_SIDE = (SIDE == Side.SELL)  ? EntryType.BID : EntryType.OFFER;
    //    private static final double PRICE_OFFSET = 0.0005;
    private static final double PRICE_OFFSET = 0.0100;


    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void testExecution_IOC_FullyFilled_27() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        System.out.println("FOUND " + priceEntry.size + "@"+priceEntry.price);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.GTD, price, 1 + priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertFill(OrderStatus.FILLED, OrderType.LIMIT, 1 + priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);
    }

    @Test
    public void testExecution_IOC_PartiallyFilled_28() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.GTD, price, 50 * priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        TimeUnit.MINUTES.sleep(3);
//        assertFill(OrderStatus.PARTIALLY_FILLED, OrderType.LIMIT, priceEntry.getSize(), SYMBOL, clOrdId, SIDE, CURRENCY);
    }

    @Test
    public void testExecutionNegative_IOC_Rejected_32() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingleInvalidData(OrderType.LIMIT, TimeInForce.IOC, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertReject(clOrdId);
    }


    @Test
    public void testExecutionNegative_IOC_Cancelled_33() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = offMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.IOC, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertCancelled(clOrdId);
    }


    @Test
    public void manual_testExecution_DAY_RestsInMarket_36() throws Exception {

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = offMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertAccepted(clOrdId);
    }


    @Test
    public void testExecution_DAY_Filled_37() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertFill(OrderStatus.FILLED, OrderType.LIMIT, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);
    }

    @Test
    public void manual_testExecution_GTC_RestsInMarket_38() throws Exception {

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = offMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.GTC, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertAccepted(clOrdId);
    }

    @Test
    public void testExecution_GTC_Filled_39() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.GTC, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertFill(OrderStatus.FILLED, OrderType.LIMIT, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);
    }

    @Test
    public void manual_testExecution_GTD_RestsInMarket_40() throws Exception {

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = offMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.GTD, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertAccepted(clOrdId);
    }

    @Test
    public void testExecution_GTD_Filled_41() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.GTD, price, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertFill(OrderStatus.FILLED, OrderType.LIMIT, priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);
    }

    @Test
    public void testExecution_Graceful_disconnect_52() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitPrice(INSTRUMENT_KEY.instrumentId(), ENTRYTYPE_SIDE);
        final double price = inMarketPrice(priceEntry.price, SIDE);

        final NewOrderSingle newOrderSingle1 = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, 2 * priceEntry.size, SYMBOL, clOrdId, SIDE, CURRENCY);
//        final NewOrderSingle newOrderSingle2 = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, 2 * priceEntry.size(), "EURUSD", clOrdId, SIDE, CURRENCY);

        System.out.println(newOrderSingle1.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle1);
//        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle2);

//        assertFill(OrderStatus.PARTIALLY_FILLED, OrderType.LIMIT, priceEntry.size(), SYMBOL, clOrdId, SIDE, CURRENCY);

        TimeUnit.MINUTES.sleep(1);
    }




    private double inMarketPrice(final double price, final Side side) {
        return price + ((side == Side.BUY) ? + PRICE_OFFSET : -PRICE_OFFSET);
    }

    private double offMarketPrice(final double price, final Side side) {
        return price + ((side == Side.BUY) ? - 10*PRICE_OFFSET : + 10*PRICE_OFFSET);
    }

    private PriceEntry awaitPrice(final long instrumentId, final EntryType entryType) {
        final IncrementalRefreshMatcher matcher = IncrementalRefreshMatcher.build()
                .body().matches(senderCompId().eq(GB_LG_EBSD))
                .body().matches(marketId().eq(Venue.EBSD))
                .body().matches(instrumentId().eq(instrumentId))
                .entries().anyMatches(mdEntryType().eq(entryType))
                .hops().countAtLeast(2);

        return priceListener.awaitPrice(matcher,entryType);
    }

    private NewOrderSingle newOrderSingle(final OrderType orderType, final TimeInForce timeInForce, final double price, final double size, final String symbol, final String clOrdId, final Side side,
                                          final String currency) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = timeInForce;
        if (timeInForce == TimeInForce.GTD) {
            newOrderSingle.body.expireTime = acceptanceContext.precisionClock().nanos() + 3600000000000L;
        }
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.price = price;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = symbol;
        return newOrderSingle;
    }

    private NewOrderSingle newOrderSingleInvalidData(final OrderType orderType, final TimeInForce timeInForce, final double price, final double size, final String symbol, final String clOrdId, final Side side,
                                                     final String currency) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = timeInForce;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.price = price;
        newOrderSingle.body.securityType = SecurityType.FXSWAP;
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = "BLAH/BLAH";
        return newOrderSingle;
    }


    private void assertFill(final OrderStatus orderStatus, final OrderType orderType, final double size, final String symbol, final String clOrdId, final Side side,
                            final String currency) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_EBSD))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.EBSD.name()))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW)))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_EBSD))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.EBSD.name()))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(orderStatus))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().eq(size))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }


    private void assertCancelled(final String clOrdId) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_EBSD))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.EBSD.name()))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW)))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_EBSD))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private void assertAccepted(final String clOrdId) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_EBSD))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.EBSD.name()))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW)))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }



    private void assertReject(final String clOrdId) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_EBSD))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.EBSD.name()))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.REJECTED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.REJECTED))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }
}