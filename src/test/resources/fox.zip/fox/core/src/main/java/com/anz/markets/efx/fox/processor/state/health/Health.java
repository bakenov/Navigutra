package com.anz.markets.efx.fox.processor.state.health;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;

public class Health {
    private static final Logger LOGGER = LoggerFactory.getLogger(Health.class);

    private final TimerScheduler timerScheduler;
    private final long delayMillis;

    private long currentTimerId;

    private final TimerScheduler.ExpiryHandler expiryHandler = new TimerScheduler.ExpiryHandler() {
        @Override
        public TimerGroup timerGroup() {
            return TimerGroup.SYSTEM_HEARTBEAT;
        }

        @Override
        public boolean onExpiryCommand(final long timerId, final long triggeredTime, final CommandContext commandContext) {
            LOGGER.debug("Heartbeat timer expiry command. timerId={}, triggeredTime={}, currentTimerId={}", timerId, triggeredTime, currentTimerId);
            final int source = commandContext.source();
            final long sourceSeq = commandContext.idGenerator().getAsLong();
            commandContext.tradingEncoderSupplier().heartbeat().messageStart(source, sourceSeq)
                    .messageId(sourceSeq)
                    .senderCompId().encode(commandContext.senderCompId())
                    .hopsEmpty()
                    .messageComplete();
            return true;
        }

        @Override
        public boolean onExpiryEvent(final long timerId, final long triggeredTime) {
            LOGGER.debug("Heartbeat timer expiry event. timerId={}, triggeredTime={}, currentTimerId={}", timerId, triggeredTime, currentTimerId);
            reset();
            scheduleHeartbeat();
            return true;
        }
    };

    private void reset() {
        currentTimerId = 0;
    }

    public Health(final TimerScheduler timerScheduler, final long delayMillis) {
        this.timerScheduler = Objects.requireNonNull(timerScheduler);
        this.delayMillis = delayMillis;
    }

    public void scheduleHeartbeat() {
        if (currentTimerId == 0) {
            currentTimerId = timerScheduler.schedule(delayMillis, expiryHandler);
        }
    }
}
