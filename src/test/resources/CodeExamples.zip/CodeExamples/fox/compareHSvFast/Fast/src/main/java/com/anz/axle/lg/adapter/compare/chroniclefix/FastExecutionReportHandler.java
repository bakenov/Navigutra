package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.sessioncode.fields.MsgSeqNum;
import software.chronicle.fix.sessioncode.fields.SendingTime;
import software.chronicle.fix.sessioncode.fields.Text;
import software.chronicle.fix.staticcode.messages.FixConstants;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageHandler;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Account;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.AvgPx;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.ClOrdID;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Commission2;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.ContraBroker;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.ContraID;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.CumQty;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Currency;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.ExecID;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.FutSettDate;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.LastMktPx;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.LastPx;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.LastShares;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.LeavesQty;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.OrderID;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.OrderQty;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.OrigClOrdID;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Price;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Symbol;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.TradeDate;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.TransactTime;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Parties;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

public final class FastExecutionReportHandler implements FixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(FastExecutionReportHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    private final TradingEncoderSupplier tradingResponseEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;


    private final Map<String, String> symbol6Map = new HashMap<>();
    private final SourceSequencer sourceSequencer;

    public FastExecutionReportHandler(final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                      final PrecisionClock precisionClock,
                                      final String senderCompId,
                                      final String compId,
                                      final LongSupplier messageIdGenerator,
                                      final SourceSequencer sourceSequencer) {
        this.tradingResponseEncoderSupplier = Objects.requireNonNull(tradingResponseEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final AbstractDataModel message) throws IllegalArgumentException {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("ExecutionReport received: {}", message);

        final int sequenceNumber = message.getInt(MsgSeqNum.FIELD);
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = sendingTimeNanos(message);

        final String orderId = message.getString(OrderID.FIELD);
        final String clOrderId = message.getString(ClOrdID.FIELD);
        final String origClOrderId = origClientOrderId(message);
        final String execId = message.getString(ExecID.FIELD);
        final ExecType execType = execType(message);
        final OrderStatus orderStatus = orderStatus(message);
        final String account = message.getString(Account.FIELD);
        final String symbol = symbol(message);
        final Side side = side(message);
        final double orderQty = orderQty(message);
        final OrderType orderType =  orderType(message);
        final double price = price(message);
        final String currency = currency(message);
        final double lastQty = lastQty(message);
        final double lastPx = lastPx(message);
        final double leavesQty = leavesQty(message);
        final double cumQty = cumQty(message);
        final double avgPx = avgPx(message);
        final double commission = commission(message);
        final long transactTimeNanos = transactTimeNanos(message);
        final String contraId = contraIdOrNull(message);
        final String contraBroker = contraBrokerOrNull(message);
        final String settlDate = settlDateOrNull(message);
        final String tradeDate = tradeDateOrNull(message);
        final String cancellationReason = cancellationReasonOrNull(message);
        final double lastMktPx = lastMktPx(message);

        final ExecutionReportEncoder.Body bodyEncoder = tradingResponseEncoderSupplier.executionReport()
                .messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .orderId().encode(orderId)
                .clOrdId().encode(clOrderId)
                .origClOrdId().encode(origClOrderId)
                .clOrdLinkId().encodeEmpty()
                .marketId().encode(Venue.FAST.name())
                .execId().encode(execId)
                .execType(execType)
                .ordStatus(orderStatus)
                .symbol().encode(symbol)
                .securityType(SecurityType.FXSPOT)
                .orderQty(orderQty)
                .ordType(orderType)
                .targetStrategyName().encodeEmpty()
                .price(price)
                .side(side)
                .currency().encode(currency)
                .timeInForce(null)
                .transactTime(transactTimeNanos > 0 ? transactTimeNanos : sendingTimeNanos)
                .tradeDate().encodeFormatted(tradeDate, DATE_DECODER)
                .settlDate().encodeFormatted(settlDate, DATE_DECODER)
                .settlCurrency().encode(currency)
                .lastQty(lastQty)
                .lastPx(lastPx)
                .leavesQty(leavesQty)
                .lastSpotRate(lastMktPx)
                .cumQty(cumQty)
                .avgPx(avgPx)
                .commission(commission);

        addParties(bodyEncoder, account, contraBroker, contraId)
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .quoteId().encodeEmpty()
                .rejectText().encodeNullable(cancellationReason)
                .messageComplete();
    }

    private ExecutionReportEncoder.StrategyParameters addParties(final ExecutionReportEncoder.Body bodyEncoder, final String account, final String contraBroker, final String contraId) {
        int partiesCount = 0;
        if (account != null) partiesCount ++;
        if (contraBroker != null) partiesCount ++;
        if (contraId != null) partiesCount ++;

        final Parties.Encoder.Next<ExecutionReportEncoder.StrategyParameters> partiesNext = bodyEncoder.partiesStart(partiesCount);

        if (account != null) {
            partiesNext.next()
                    .partyRole(PartyRole.SETTLEMENT_ACCOUNT)
                    .partyId().encodeNullable(account);
        }
        if (contraId != null) {
            partiesNext.next()
                    .partyRole(PartyRole.CLIENT_ID)
                    .partyId().encodeNullable(contraId);
        }
        if (contraBroker != null) {
            partiesNext.next()
                    .partyRole(PartyRole.CONTRA_FIRM)
                    .partyId().encodeNullable(contraBroker);
        }
        return partiesNext.partiesComplete();
    }

    private long transactTimeNanos(final AbstractDataModel message) throws IllegalArgumentException {

        if (isSet(message.getString(TransactTime.FIELD))) {
            return message.getLong(TransactTime.FIELD);
        } else {
            return 0;
        }
    }

    private long sendingTimeNanos(final AbstractDataModel message) throws IllegalArgumentException {
        return message.getLong(SendingTime.FIELD);
    }

    private boolean isSet(final Object val) {
        return !FixConstants.isUnset(val);
    }

    private String origClientOrderId(final AbstractDataModel message) throws IllegalArgumentException {

        if (isSet(message.getString(OrigClOrdID.FIELD))) {
            return message.getString(OrigClOrdID.FIELD);
        } else {
            return message.getString(ClOrdID.FIELD);
        }
    }

    private String symbol(final AbstractDataModel message) throws IllegalArgumentException {
        final String symbol = message.getString(Symbol.FIELD);
        return symbol6Map.computeIfAbsent(symbol, SymbolNormaliser::toSymbol6);
    }

    private ExecType execType(final AbstractDataModel message) throws IllegalArgumentException {
        final char execType = message.getChar(com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.ExecType.FIELD);
        switch (execType) {
            case '0' : return ExecType.NEW;
            case '1' : return ExecType.TRADE;
            case '2' : return ExecType.TRADE;
            case '4' : return ExecType.CANCELED;
            case '8' : return ExecType.REJECTED;
            case 'C' : return ExecType.EXPIRED;
            case 'F' : return ExecType.TRADE;
            default: throw new IllegalArgumentException("Unsupported execType " + execType);
        }
    }

    private double orderQty(final AbstractDataModel message) throws IllegalArgumentException {
        double orderQty = message.getDouble(OrderQty.FIELD);
        if (!isSet(orderQty)) {
            throw new IllegalArgumentException("orderQty is expected");
        }
        return orderQty;
    }

    private OrderType orderType(final AbstractDataModel message) throws IllegalArgumentException {

        final char ordType =  message.getChar(OrdType.FIELD);

        if (isSet(ordType)) {
            switch (ordType) {
                case '1' : return OrderType.MARKET;
                case '2' : return OrderType.LIMIT;
                default: throw new IllegalArgumentException("Unsupported ordType " + ordType);
            }
        } else {
            throw new IllegalArgumentException("ordType is expected");
        }
    }

    private double price(final AbstractDataModel message) throws IllegalArgumentException {
        final double price = message.getDouble(Price.FIELD);
        return isSet(price) ? price : Double.NaN;
    }

    private Side side(final AbstractDataModel message) throws IllegalArgumentException {
        final char side = message.getChar(com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Side.FIELD);
        switch (side) {
            case '1' : return Side.BUY;
            case '2' : return Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side " + side);
        }
    }

    private String currency(final AbstractDataModel message) throws IllegalArgumentException {

        final String currency = message.getString(Currency.FIELD);
        if (!isSet(currency)) {
            throw new IllegalArgumentException("currency is expected");
        }
        return currency;
    }

    private OrderStatus orderStatus(final AbstractDataModel message) throws IllegalArgumentException {
        final char ordStatus = message.getChar(OrdStatus.FIELD);
        switch (ordStatus) {
            case '0' : return OrderStatus.NEW;
            case '1' : return OrderStatus.PARTIALLY_FILLED;
            case '2' : return OrderStatus.FILLED;
            case '3' : return OrderStatus.DONE_FOR_DAY;
            case '4' : return OrderStatus.CANCELED;
            case '8' : return OrderStatus.REJECTED;
            case 'C' : return OrderStatus.EXPIRED;
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private double lastQty(final AbstractDataModel message) throws IllegalArgumentException {
        final double lastQty =  message.getDouble(LastShares.FIELD);
        return isSet(lastQty) ? lastQty : 0;
    }

    private double lastPx(final AbstractDataModel message) throws IllegalArgumentException {
        final double lastPx = message.getDouble(LastPx.FIELD);
        return isSet(lastPx) ? lastPx : 0;
    }

    private double lastMktPx(final AbstractDataModel message) throws IllegalArgumentException  {

        final double lastMktPx = message.getDouble(LastMktPx.FIELD);
        return isSet(lastMktPx) ? lastMktPx : lastPx(message);
    }

    private double leavesQty(final AbstractDataModel message) throws IllegalArgumentException {

        final double leavesQty = message.getDouble(LeavesQty.FIELD);
        if (!isSet(leavesQty)) {
            throw new IllegalArgumentException("leavesQty is expected");
        }
        return leavesQty;
    }

    private double cumQty(final AbstractDataModel message) throws IllegalArgumentException {

        final double cumQty = message.getDouble(CumQty.FIELD);
        if (!isSet(cumQty)) {
            throw new IllegalArgumentException("cumQty is expected");
        }
        return cumQty;
    }

    private double avgPx(final AbstractDataModel message) throws IllegalArgumentException {

        final double avgPx = message.getDouble(AvgPx.FIELD);
        if (!isSet(avgPx)) {
            throw new IllegalArgumentException("avgPx is expected");
        }
        return avgPx;
    }

    private double commission(final AbstractDataModel message) throws IllegalArgumentException {

        final double commission = message.getDouble(Commission2.FIELD);
        return isSet(commission) ? commission : 0;
    }

    private String cancellationReasonOrNull(final AbstractDataModel message) throws IllegalArgumentException {
        return message.getString(Text.FIELD);
    }

    private String contraIdOrNull(final AbstractDataModel message) throws IllegalArgumentException {
        return message.getString(ContraID.FIELD);
    }

    private String contraBrokerOrNull(final AbstractDataModel message) throws IllegalArgumentException {
        return message.getString(ContraBroker.FIELD);
    }

    private String settlDateOrNull(final AbstractDataModel message) throws IllegalArgumentException {
        return message.getString(FutSettDate.FIELD);
    }

    private String tradeDateOrNull(final AbstractDataModel message) throws IllegalArgumentException {
        return message.getString(TradeDate.FIELD);
    }
}
