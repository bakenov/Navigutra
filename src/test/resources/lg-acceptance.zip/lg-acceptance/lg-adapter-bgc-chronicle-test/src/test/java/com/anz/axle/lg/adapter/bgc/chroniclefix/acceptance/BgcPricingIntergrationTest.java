package com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.TestUtils;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Quote;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.wire.Marshallable;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.FixVersion;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.yaml.TcpSession;

import java.util.EnumSet;
import java.util.Queue;
import java.util.function.Predicate;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.getRandomFreeLocalPort;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class BgcPricingIntergrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcPricingIntergrationTest.class);

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private Venue marketId;

    // Server side
    private static final String HOST = "localhost";
    private static final String TARGET_COMP_ID = "SERVER";
    private static final String USERNAME = "STUB";
    private static final String PASSWORD = "PASSWORD";

    private FixSessionHandler serverSession;
    private Queue<StandardHeaderTrailer> serverReceiveQueue;
    private FixEngineCfg cfg;
    private ChronicleFixEngine engine;
    private TcpSession tcpSession;
    private PrecisionClock precisionClock;

    private String appName;
    private String senderCompId;
    private int port;
    private String fixFilePath;
    private String fixStorePath;
    private String path;

    @Before
    public void setup() throws Exception {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        appName = "bgc";
        marketId = Venue.BGCMIDFX;
        senderCompId = "_BGC_";
        setPersistStorePath(appName, testName.getMethodName());
        port = getRandomFreeLocalPort();
        path = "target/" + appName + "/" + System.currentTimeMillis();

        fixFilePath = path + "/log/";
        fixStorePath = path + "/store/";

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + appName +
                                ",venue:" + marketId.name() +
                                ",appOptions:--reset" +
                                ",default.log.appender:Console" +
                                ",default.log.level:DEBUG" +
                                ",chronicle.fix.logging:true" +
                                "," + appName + ".fix.pricing.session.enable:true" +
                                "," + appName + ".fix.trading.session.enable:false" +
                                "," + appName + ".fix.socket.use.ssl:N" +
                                "," + appName + ".fix.log.destination:STDOUT" +
                                "," + appName + ".fix.file.log.path:" + fixFilePath +
                                "," + appName + ".fix.file.store.path:" + fixStorePath +
                                "," + appName + ".fix.log_all:true" +
                                "," + appName + ".fix.reconnectInterval:1" +
                                "," + appName + ".fix.pricing.sendercompid:" + senderCompId +
                                "," + appName + ".fix.pricing.targetcompid:" + TARGET_COMP_ID +
                                "," + appName + ".fix.pricing.username:" + USERNAME +
                                "," + appName + ".fix.pricing.password:" + PASSWORD +
                                "," + appName + ".fix.pricing.host:" + HOST +
                                "," + appName + ".fix.pricing.port:" + port
                ));

        System.setProperty("rounding.decimal.place.symbols", "{'3':{'EURJPY','USDJPY','EURHUF'}}");

        startServerSide();

        application = new Application("lg-bgc-acceptance", PricingAcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        precisionClock = application.getApplicationContext().getBean(PrecisionClock.class);
        assertTrue(TestUtils.waitFor(serverSession::isConnected, 10_000));
        LOGGER.info("Server connected.");
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        IOTools.deleteDirWithFiles(path);
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void sendPricesToBGC() {
        // wait for login reply from BGC
        final Logon logon = (Logon) waitFor(Logon.class);
        assertThat(logon.senderCompID(), is(senderCompId));
        serverReceiveQueue.clear();

        final SnapshotFullRefresh fullRefresh = new SnapshotFullRefresh();
        fullRefresh.body.senderCompId = "GB:lg-acc";
        fullRefresh.body.marketId = Venue.BGCMIDFX;
        fullRefresh.body.instrumentId = InstrumentKey.instrumentId("EURJPY", SecurityType.FXSPOT, Tenor.SP);
        fullRefresh.body.messageId = 1;
        fullRefresh.body.sendingTime = 0;
        fullRefresh.entries.add(createEntry(EntryType.BID, 0.12345d, 1.0d));
        fullRefresh.entries.add(createEntry(EntryType.OFFER, 0.13345d, 2.0d));

        acceptanceContext.pricingMessageQueue().add(fullRefresh);

        // BGC wait and receive quote
        final Quote quote = (Quote) waitFor(Quote.class);

        assertThat(quote.symbol(), is("EUR/JPY"));
        assertThat(quote.securityType(), is("FXSPOT"));
        assertThat("round to 3 dec place", quote.bidPx(), is(0.123d));
        assertThat(quote.bidSize(), is(1.0d));
        assertThat("round to 3 dec place", quote.offerPx(), is(0.134d));
        assertThat(quote.offerSize(), is(2.0d));
    }

    private SnapshotFullRefresh.Entry createEntry(final EntryType type, final double price, final double size) {
        final SnapshotFullRefresh.Entry entry =  new SnapshotFullRefresh.Entry();
        entry.mdEntryFlags = EnumSet.noneOf(Flag.class);
        entry.mdEntryType = type;
        entry.mdEntryPx = price;
        entry.mdEntrySize = size;
        entry.transactTime = precisionClock.nanos(); // so price will not be stale and filter out by snapshotter
        return entry;
    }

    @BeforeClass
    public static void beforeClass() {
        deleteAll();
    }
    @AfterClass
    public static void afterClass() {
        deleteAll();
    }

    private static void deleteAll() {
        IOTools.deleteDirWithFiles("target/bgc/");
    }


    private void startServerSide() throws Exception {
        cfg = Marshallable.fromFile("fix-bgc-acceptor.yaml");

        final FixSessionCfg sessionCfg = cfg.fixSessionCfgs().iterator().next();
        assertEquals(sessionCfg.name(), "SERVER");
        sessionCfg.fixVersion(FixVersion.V4_4);
        sessionCfg.fileStorePath(fixStorePath);
        sessionCfg.socketAcceptorHostPort(HOST + ":" + port);
        sessionCfg.targetCompID(TARGET_COMP_ID);
        sessionCfg.senderCompID(senderCompId);
        sessionCfg.messageNotifier(new BgcMessageNotifier());

        engine = new ChronicleFixEngine(sessionCfg);
        serverSession = engine.getHandler(SessionID.create(sessionCfg));
        tcpSession = new TcpSession(sessionCfg);

        serverReceiveQueue = ((BgcMessageNotifier) serverSession.messageNotifier()).queue();
    }

    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass) {
        return waitFor(messageClass, "Waiting for "+messageClass.getSimpleName()+"...");
    }
    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass, final String text) {
        return waitFor(messageClass, 60, text);
    }
    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass, final int timeout, final String text) {
        return waitFor(m -> messageClass.isInstance(m), timeout, text);
    }
    private StandardHeaderTrailer waitFor(final Predicate<? super Object> predicate, final int timeout, final String text) {
        return TestUtils.waitFor(serverReceiveQueue, predicate, timeout, text);
    }
}
