package com.anz.axle.lg.adapter.d3.newsubscription;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.LongConsumer;
import java.util.function.LongSupplier;

import org.agrona.collections.Long2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.StreamingService;

import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamEncoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.queue.Queue;

/**
 * This class is not thread-safe. It is supposed to be confined to MainEventLoop thread.
 */
public class DefaultSubscriptionRegistry implements SubscriptionRegistry {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultSubscriptionRegistry.class);

    private final Long2ObjectHashMap<Subscription> subscriptionById = new Long2ObjectHashMap<>();
    private final Map<RequestKey, Subscription> subscriptionByRequestKey = new HashMap<>();

    private final Registerer registerer = subscriptionById::put;
    private final Unregisterer unregisterer = subscriptionById::remove;
    private final ByIdLookup byIdLookup = this::lookup;
    private final ByVenueRequestKeyLookup byVenueRequestKeyLookup;
    private final PrecisionClock precisionClock;
    private final Queue.Appender<Runnable> mainEventLoopRunnableQueueAppender;

    private long lastUpdateTimeNanos;
    private final LongConsumer updateTimeNanosUpdater = value -> lastUpdateTimeNanos = value;
    private final long missedUpdateNanos;
    private final long spotDateRollSubscribeDelayMillis;

    private final Consumer<Subscription> submitSubscriptionHandleMissedUpdate;
    private final Consumer<Subscription> submitSubscriptionPublishLatestUpdate;
    private final Consumer<Subscription> submitSubscriptionStop;
    private final Consumer<Subscription> submitspotDateRollResubscribe;

    public DefaultSubscriptionRegistry(final SecurityType securityType,
                                       final LongSupplier idGenerator,
                                       final PricingEncoders<SbeMessage> sbePricingEncoders,
                                       final PrecisionClock precisionClock,
                                       final PublicationRegistry publicationRegistry,
                                       final MessageHandler publisher,
                                       final Queue.Appender<Runnable> serviceRequestEventLoopRunnableQueueAppender,
                                       final Queue.Appender<Runnable> mainEventLoopRunnableQueueAppender,
                                       final StreamingService streamingService,
                                       final long retrySubscriptionSeconds,
                                       final long missedUpdateSeconds,
                                       final String compId,
                                       final String senderCompId,
                                       final Function<RequestKey, String> requestKeyToD3Symbol,
                                       final int marketDataBookInitialSize,
                                       final SourceSequencer sourceSequencer,
                                       final long spotDateRollSubscribeDelaySeconds) {
        Objects.requireNonNull(sourceSequencer);
        Objects.requireNonNull(securityType);
        Objects.requireNonNull(idGenerator);
        Objects.requireNonNull(sbePricingEncoders);
        Objects.requireNonNull(publicationRegistry);
        Objects.requireNonNull(publisher);
        Objects.requireNonNull(serviceRequestEventLoopRunnableQueueAppender);
        Objects.requireNonNull(streamingService);
        Objects.requireNonNull(compId);
        Objects.requireNonNull(senderCompId);
        Objects.requireNonNull(requestKeyToD3Symbol);

        this.spotDateRollSubscribeDelayMillis = TimeUnit.SECONDS.toMillis(spotDateRollSubscribeDelaySeconds);
        this.mainEventLoopRunnableQueueAppender = Objects.requireNonNull(mainEventLoopRunnableQueueAppender);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.missedUpdateNanos = TimeUnit.SECONDS.toNanos(missedUpdateSeconds);
        this.lastUpdateTimeNanos = precisionClock.nanos();

        final long retrySubscriptionMillis = TimeUnit.SECONDS.toMillis(retrySubscriptionSeconds);

        final Function<RequestKey, Subscription> factory = requestKey -> {
            final Topic topic = DefaultTopic.create(securityType + "_" + requestKey.market() + "_" + requestKey.instrumentKey().symbol());
            publicationRegistry.registerPublication(topic);
            final Consumer<SbeMessage> sbeMessageConsumer = sbeMessage -> publisher.onMessage(topic, sbeMessage.buffer(), 0, sbeMessage.messageLength(), 0);
            final PricingEncoderSupplier downStreamPricingEncoderSupplier = PricingEncoderSupplier.create(sbePricingEncoders, sbeMessageConsumer);

            final SnapshotterBuilder builder = SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, marketDataBookInitialSize))
                    .withDownstreamEncoder()
                    .forwardSnapshotsAndIncrementsTo(downStreamPricingEncoderSupplier);

            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock,  idGenerator, compId, 0);
            final UpstreamEncoderConnector upstreamEncoderConnector = builder.buildUpstreamEncoderConnector(UpdateTypeMismatchHandler.WARN);

            final UpdateProcessor updateProcessor = new DefaultUpdateProcessor(requestKey, upstreamEncoderConnector, precisionClock, idGenerator, updateTimeNanosUpdater, compId, senderCompId, sourceSequencer);

            return new DefaultSubscription(requestKeyToD3Symbol.apply(requestKey), idGenerator, updateProcessor, registerer, unregisterer,
                    serviceRequestEventLoopRunnableQueueAppender, mainEventLoopRunnableQueueAppender,
                    streamingService, precisionClock, snapshotter, retrySubscriptionMillis);
        };


        byVenueRequestKeyLookup = requestKey -> subscriptionByRequestKey.computeIfAbsent(requestKey, factory);
        submitSubscriptionHandleMissedUpdate = fullQueueHandler(subscription -> mainEventLoopRunnableQueueAppender.enqueue(() -> {
            subscription.handleMissedUpdate();
            subscription.resubscribe(0);
        }));
        submitSubscriptionPublishLatestUpdate = fullQueueHandler(subscription -> mainEventLoopRunnableQueueAppender.enqueue(subscription::publishLatestUpdate)) ;
        submitSubscriptionStop = fullQueueHandler(subscription -> mainEventLoopRunnableQueueAppender.enqueue(subscription::stop));
        submitspotDateRollResubscribe = fullQueueHandler(subscription -> mainEventLoopRunnableQueueAppender.enqueue(() -> subscription.resubscribe(spotDateRollSubscribeDelayMillis)));
    }

    /**
     * FIXME: as Queue lacks a name that could help us identify which queue is potentially full
     */
    private static Consumer<Subscription> fullQueueHandler(final Consumer<Subscription> delegateSubscription) {
        return subscription -> {
            try {
                delegateSubscription.accept(subscription);
            } catch (final Exception ex) {
                throw new IllegalStateException("Failed to process a command possibly due to the mainEventLoopRunnableQueue being full", ex);
            }
        };
    }

    @Override
    public ByIdLookup byIdLookup() {
        return byIdLookup;
    }

    @Override
    public ByVenueRequestKeyLookup byVenueRequestKeyLookup() {
        return byVenueRequestKeyLookup;
    }

    private Subscription lookup(final long subscirptionId) {
        final Subscription subscription = subscriptionById.get(subscirptionId);
        if (subscription == null) return Subscription.NO_OP;
        return subscription;
    }

    @Override
    public void checkAndRetryAllFailed() {
        subscriptionByRequestKey.values().forEach(Subscription::retryFailed);
    }

    @Override
    public void checkAndHandleAllExpired() {
        subscriptionByRequestKey.values().forEach(Subscription::handleExpired);
    }

    @Override
    public void errorAll(final String errorMessage) {
        final Consumer<Subscription> submitSubscriptionProcessError = subscription -> mainEventLoopRunnableQueueAppender.enqueue(() -> subscription.processError(errorMessage));
        subscriptionByRequestKey.values().forEach(submitSubscriptionProcessError);
    }

    @Override
    public void checkAndHandleMissedUpdate() {
        final long currentTimeNanos = precisionClock.nanos();
        if (lastUpdateTimeNanos < currentTimeNanos - missedUpdateNanos) {
            lastUpdateTimeNanos = currentTimeNanos;

            LOGGER.error("Missed update detected, handling missed update on all active subscriptions");
            subscriptionByRequestKey.values().forEach(submitSubscriptionHandleMissedUpdate);
        }
    }

    @Override
    public void publishLatestUpdates() {
        LOGGER.info("Publishing latest updates");
        subscriptionByRequestKey.values().forEach(submitSubscriptionPublishLatestUpdate);
    }

    @Override
    public void spotDateRollResubscribe() {
        LOGGER.info("Resubscribing all active subscriptions on spot date roll");
        subscriptionByRequestKey.values().forEach(submitspotDateRollResubscribe);
    }

    @Override
    public void submitStop() {
        LOGGER.info("Stopping all subscriptions");
        mainEventLoopRunnableQueueAppender.enqueue(() -> subscriptionByRequestKey.values().forEach(submitSubscriptionStop));
    }
}
