package com.anz.markets.efx.fox.processor.pricing;

import java.util.function.Consumer;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;

public class InstrumentMidPriceCalculator implements Consumer<Instrument> {
    private static final Predicate<VenueInstrument> TRADABLE = venueInstrument -> venueInstrument.marketDataBook().flagsIsEmpty();
    private double midPriceTotal = 0;
    private int midPriceElements = 0;

    @Override
    public void accept(final Instrument instrument) {
        midPriceTotal = 0;
        midPriceElements = 0;
        instrument.forEach(TRADABLE, venueInstrument -> {
            final MarketDataEntry topBid = venueInstrument.topBid();
            final MarketDataEntry topAsk = venueInstrument.topAsk();

            if (topBid != null && topAsk != null) {
                final double bidPrice = topBid.price();
                final double askPrice = topAsk.price();

                midPriceTotal += bidPrice + (askPrice - bidPrice)/2;
                midPriceElements++;
            }
        });
        if (midPriceElements > 0) {
            instrument.consensusMidPrice(midPriceTotal / midPriceElements);
        } else {
            instrument.consensusMidPrice(Double.NaN);
        }
    }
}
