package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.config.business.domain.tabular.impl.PassiveHedgerConfigImpl;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;

public interface PassiveHedgerConfig extends HedgeInstrumentConfig {
    PassiveHedgerConfig EMPTY = new PassiveHedgerConfigImpl();

    TradingTimeZone getTradingTimeZone();

    /**
     * Level of risk (minimum position)
     */
    double getMinimumRisk();

    /**
     * Size of order for hedger to send to the market to manage risk
     */
    double getOrderQuantity();

    double getShowQuantity();

    /**
     * total number active orders for this instrument.
     */
    long getNumberOfOrders();

    /**
     * This parameter controls the maximum spread (pips) a hedger is allowed to improve the front of stack (top of the book) on the 'target market'.
     * i.	    Positive value (e.g. 0.5 pips) would indicate that a hedger is allowed to place an order at X pips tighter (better) than the target-market's TOB price.
     * ii.	Zero value (e.g. 0.0 pips) would indicate that a hedger is allowed to place an order at the same rate as the target-market's TOB price (but NOT any tighter).
     * iii.	Negative value (e.g. -0.5 pips) would indicate that a hedger is allowed to place an order at X pips wider (worse) than the target-market's TOB price.
     */
    double getMaximumTargetMarketPriceImprovementPips();

    /**
     * Specifies a market provider whose prices should be monitored by a hedger as part of determining a LIMIT price for a passive order
     */
    Market getReferenceMarket();

    /**
     * TODO: clarify with PC
     */
    double getTotalOpenQuantity();

    /**
     * Arbitrage Protection Distance: This parameter controls the minimum distance to be maintained between the current price of a hedger's order and current TOB (BID or OFFER) of a Target-market.
     * i.	Positive value (e.g. 0.5 pips) would indicate that our OFFER must be at least X pips greater than the target-market's TOB BID (and vice versa for our BID order: must be X pips less than target-market's TOB OFFER).
     * ii.	Value of zero (0.0 pip) would indicate that our OFFER is allowed to be the same as the target-market's TOB BID (and vice versa for our BID order).
     * iii.	Negative value (e.g. -0.5 pips) would indicate that our order's rate can be cross with the target-market's TOB rate i.e. our OFFER can be (at the maximum) X pips less than the target-market's TOB BID (and vice versa for our BID order: can be (at the maximum) X pips greater than target-market's TOB OFFER).
     */
    double getArbitrageProtectionDistancePips();

    /**
     * addition spread in pips to apply
     */
    double getAdditionalSpreadPips();

    /**
     * Reference price moving average sample count
     */
    int getPriceSamples();

    /**
     * Reference price moving average sample frequency in milliseconds
     */
    long getPriceSampleInterval();

    /**
     * Panic state duration in milliseconds
     */
    long getPanicStateDurationMS();

    /**
     * Size of spike required to trigger a panic state, as multiple of "standard market spread"
     */
    double getSpikePriceStandardSpreadFactor();
}
