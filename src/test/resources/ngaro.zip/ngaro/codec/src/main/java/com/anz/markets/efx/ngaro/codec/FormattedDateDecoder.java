package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

/**
 * Decoder for date only without time decoded from a fixed length string formatted for instance as YYYYMMDD.
 * <p/>
 * This class thread safe. NOTE however that the {@code target} and {@link ByteReader} passed to the constructor may not
 * be thread safe and hence the resulting decoder instance may also not be thread safe.
 *
 * @param <S> the source type
 */
public final class FormattedDateDecoder<S> implements DateDecoder {

    private final S source;
    private final ByteReader<? super S> reader;
    private final LocalDateDecoder localDateDecoder;

    public FormattedDateDecoder(final S source, final ByteReader<? super S> reader, final LocalDateFormat localDateFormat) {
        this(source, reader, localDateFormat.getDefaultDecoder());
    }

    public FormattedDateDecoder(final S source, final ByteReader<? super S> reader, final LocalDateDecoder localDateDecoder) {
        this.source = Objects.requireNonNull(source);
        this.reader = Objects.requireNonNull(reader);
        this.localDateDecoder = Objects.requireNonNull(localDateDecoder);
    }

    public static FormattedDateDecoder<AsciiString> forAsciiString(final LocalDateFormat localDateFormat) {
        return forAsciiString(new FixedLengthAsciiString(localDateFormat.getLength()), localDateFormat);
    }

    public static FormattedDateDecoder<AsciiString> forAsciiString(final AsciiString asciiString, final LocalDateFormat localDateFormat) {
        return forSourceAndFormat(asciiString, ByteReader.ASCII_STRING, localDateFormat);
    }

    public static <S> FormattedDateDecoder<S> forSourceAndFormat(final S source, final ByteReader<? super S> reader,
                                                                 final LocalDateFormat localDateFormat) {
        return new FormattedDateDecoder<>(source, reader, localDateFormat);
    }

    public static <S> FormattedDateDecoder<S> forSourceAndEncoder(final S source, final ByteReader<? super S> reader,
                                                                  final LocalDateDecoder localDateDecoder) {
        return new FormattedDateDecoder<>(source, reader, localDateDecoder);
    }

    public S source() {
        return source;
    }

    @Override
    public LocalDate decodeLocalDateOrNull() {
        return localDateDecoder.decodeLocalDateOrNull(source, reader);
    }

    @Override
    public long decodeEpochMillis() {
        return localDateDecoder.decodeEpochMillis(source, reader);
    }

    @Override
    public long decodeEpochSeconds() {
        return localDateDecoder.decodeEpochSeconds(source, reader);
    }

    @Override
    public long decodeEpochDays() {
        return localDateDecoder.decodeEpochDays(source, reader);
    }

    @Override
    public int decodeYear() {
        return localDateDecoder.decodeYear(source, reader);
    }

    @Override
    public int decodeMonth() {
        return localDateDecoder.decodeMonth(source, reader);
    }

    @Override
    public int decodeDay() {
        return localDateDecoder.decodeDay(source, reader);
    }
}