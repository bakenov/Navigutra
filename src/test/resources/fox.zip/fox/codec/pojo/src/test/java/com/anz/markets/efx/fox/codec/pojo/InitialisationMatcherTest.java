package com.anz.markets.efx.fox.codec.pojo;

import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.pojo.matcher.InitialisationMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class InitialisationMatcherTest {
    private Predicate<Initialisation> predicate = Matchers.isA(Initialisation.class);
    private InitialisationMatcher matcher = new InitialisationMatcher() {
        @Override
        public Matcher<InitialisationMatcher, Initialisation.Body> body() {
            return matcher -> andThen(translate(initialisation -> initialisation.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof Initialisation && predicate.test((Initialisation) o);
        }

        private InitialisationMatcher andThen(final Predicate<? super Initialisation> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final Initialisation initialisation = SorMessage.initialisation(
                new MessageHeader(),
                new Initialisation.Body(InitStage.BEGIN));
        assertTrue(matcher.test(initialisation));
        assertNotNull(matcher.body());
    }
}
