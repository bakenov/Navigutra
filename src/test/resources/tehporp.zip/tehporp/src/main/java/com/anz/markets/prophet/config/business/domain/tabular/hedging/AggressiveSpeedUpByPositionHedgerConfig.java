package com.anz.markets.prophet.config.business.domain.tabular.hedging;


import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveSpeedUpByPositionHedgerConfigImpl;
import com.anz.markets.efx.ngaro.math.Epsilon;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Comparator;

public interface AggressiveSpeedUpByPositionHedgerConfig extends AggressiveSpeedUpHedgerConfig {

    AggressiveSpeedUpByPositionHedgerConfig EMPTY = new AggressiveSpeedUpByPositionHedgerConfigImpl();

    long getPositionMonitorWindowSeconds();

    @JsonIgnore
    static Comparator<AggressiveSpeedUpByPositionHedgerConfig> descendingRiskLevelComparator = (o1, o2) -> {
        // group by standard keys first
        final int mktCompare = o1.getMarket().getValue() - o2.getMarket().getValue();
        if (mktCompare != 0) {
            return mktCompare < 0 ? 1: -1;
        }
        final int instCompare = o1.getInstrument().getValue() - o2.getInstrument().getValue();
        if (instCompare != 0) {
            return instCompare < 0 ? 1: -1;
        }
        final int ttzCompare = o1.getTradingTimeZone().getValue() - o2.getTradingTimeZone().getValue();
        if (ttzCompare != 0) {
            return ttzCompare < 0 ? 1: -1;
        }

        // then for this particular config perform descending sort, so pick up the highest level first
        final double riskCompare =  o2.getMinimumRisk() - o1.getMinimumRisk();
        if (!Epsilon.equalsZero(riskCompare)) {
            return riskCompare < 0 ? -1 : 1;
        }
        // shouldn't have multiple at one level but descending sort pnl thresholds for safety so that the lowest threshold is retained
        final double pnlCompare = (o2.getPnLThreshold() - o1.getPnLThreshold());
        return Epsilon.equalsZero(pnlCompare) ? 0 : pnlCompare < 0 ? -1 : 1;
    };
}
