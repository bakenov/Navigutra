package com.anz.markets.disco;

public interface InputModule extends Module {

    void start();

    boolean isFinished();

}
