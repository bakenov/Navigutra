package com.anz.markets.prophet.config.business.domain.indexed;


import com.anz.markets.prophet.config.business.domain.tabular.risk.NetOpenPositionLimitConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;

import java.util.List;

public class NetOpenPositionLimit {
    public final EnumDoubleMap<Currency> netOpenPositionLimitByCurrency = new EnumDoubleMap<>(Currency.class);

    public NetOpenPositionLimit(final List<NetOpenPositionLimitConfig> netOpenPositionLimitConfigs) {
        if (netOpenPositionLimitConfigs != null) {
            netOpenPositionLimitConfigs.forEach(config ->
                    netOpenPositionLimitByCurrency.put(config.getCurrency(), config.getLimit()));
        }
    }

    public double getLimit(final Currency currency) {
        return netOpenPositionLimitByCurrency.get(currency);
    }
}
