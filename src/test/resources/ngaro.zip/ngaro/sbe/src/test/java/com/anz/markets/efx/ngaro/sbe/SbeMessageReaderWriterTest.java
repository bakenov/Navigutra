package com.anz.markets.efx.ngaro.sbe;

import org.agrona.ExpandableArrayBuffer;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class SbeMessageReaderWriterTest {

    @Test
    public void testReaderWriter() {
        // setup - put message
        final SbeMessageForWriting sbeMessageForWriting = new SbeMessageForWriting(new ExpandableArrayBuffer(100));
        sbeMessageForWriting.buffer().putByte(0, (byte)0x01);
        sbeMessageForWriting.buffer().putByte(1, (byte)0x02);
        sbeMessageForWriting.messageLength(2);

        // read message
        final SbeMessageForReading sbeMessageForReading = new SbeMessageForReading();
        sbeMessageForReading.wrap(sbeMessageForWriting);
        assertEquals(2, sbeMessageForReading.messageLength());
        assertEquals((byte)0x01, sbeMessageForReading.buffer().getByte(0));
        assertEquals((byte)0x02, sbeMessageForReading.buffer().getByte(1));

        // reading beyond boundary
        try {
            sbeMessageForReading.buffer().getByte(3);
            fail("Should have failed when requesting for index 3, as there are only 2 bytes to be read");
        } catch (IndexOutOfBoundsException e) {
            assertEquals("index=3 capacity=2", e.getMessage());
        }

        // unwrap message, should not be able to read beyond this
        sbeMessageForReading.unwrap();

        try {
            sbeMessageForReading.buffer().getByte(0);
            fail("Should not be able to read after message is unwrapped");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("call wrap(..) before accessing message"));
        }
    }

    @Test
    public void should_not_be_able_to_read_before_wrapping() {
        try {
            final SbeMessageForReading sbeMessageForReading = new SbeMessageForReading();
            sbeMessageForReading.messageLength();
            fail("Should not be able to read anything as nothing is wrapped");
        } catch (final IllegalStateException e) {
            assertTrue(e.getMessage().contains("call wrap(..) before accessing message"));
        }
    }
}
