package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.HeaderDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface VenueConfigDecoder extends HeaderDecoder {
    Body body();
    void appendTo(StringBuilder stringBuilder);

    interface Body {
        Venue venue();
        StringDecoder compId();
        EnumerableSetDecoder<VenueCategory> venueCategories();
        boolean enabled();
    }
}