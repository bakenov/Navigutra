package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.*;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import org.joda.time.LocalDate;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public class CurrencyVenueExclusionsBuilderTest {
    @Test
    public void test_that_exclusions_are_built() throws BuilderException {
        Currency aud = new Currency(1l, "AUD", "AUD", 2);
        Currency usd = new Currency(2l, "USD", "USD", 2);
        CurrencyPair audusd = new CurrencyPair(aud, usd);
        CurrencyPair usdaud = new CurrencyPair(usd, aud);
        Venue venue = new Venue();
        venue.setAggregatorCode("BARX");

        CurrentVenueCurrencyCreditState state = new CurrentVenueCurrencyCreditState(true, audusd, venue, new LocalDate(), new LocalDate(), 0.83d);
        CurrentVenueCurrencyCreditState anotherState = new CurrentVenueCurrencyCreditState(true, usdaud, venue, new LocalDate(), new LocalDate(), 0.83d);
        Collection<CurrentVenueCurrencyCreditState> stateCollection = new ArrayList<CurrentVenueCurrencyCreditState>();
        stateCollection.add(state);
        stateCollection.add(anotherState);
        CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates(stateCollection);
        CurrencyVenueExclusionBuilder venueExclusionBuilder = new CurrencyVenueExclusionBuilder();
        CurrencyVenueExclusionsBuilder venueExclusionsBuilder = new CurrencyVenueExclusionsBuilder();
        venueExclusionBuilder.setKeyBuilder(new CurrencyVenueExclusionKeyBuilder());
        venueExclusionsBuilder.setBuilder(venueExclusionBuilder);

        Collection<CurrencyVenueExclusion> exclusions  = venueExclusionsBuilder.build(states);
        Iterator<CurrencyVenueExclusion> iterator = exclusions.iterator();

        assertEquals(2, exclusions.size());
        CurrencyVenueExclusion exclusionOne = iterator.next();
        CurrencyVenueExclusion exclusionTwo = iterator.next();

        assertEquals("BARX", exclusionOne.getKey().getVenue());
        assertEquals("AUD/USD", exclusionOne.getKey().getSymbol());
        assertEquals("CREDIT_CHECK", exclusionOne.getKey().getSource());
        assertTrue(exclusionOne.isCommonExclusion());
        assertTrue(exclusionOne.isExcluded());
        assertEquals("BARX", exclusionOne.getVenue());
        assertEquals("AUD/USD", exclusionOne.getSymbol());
        assertEquals("CREDIT_CHECK", exclusionOne.getSource());

        assertEquals("BARX", exclusionTwo.getKey().getVenue());
        assertEquals("USD/AUD", exclusionTwo.getKey().getSymbol());
        assertEquals("CREDIT_CHECK", exclusionTwo.getKey().getSource());

        assertTrue(exclusionTwo.isCommonExclusion());
        assertTrue(exclusionTwo.isExcluded());
        assertEquals("BARX", exclusionTwo.getVenue());
        assertEquals("USD/AUD", exclusionTwo.getSymbol());
        assertEquals("CREDIT_CHECK", exclusionTwo.getSource());
    }
}