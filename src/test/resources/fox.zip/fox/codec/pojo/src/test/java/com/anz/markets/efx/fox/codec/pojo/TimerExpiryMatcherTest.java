package com.anz.markets.efx.fox.codec.pojo;

import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.pojo.matcher.TimerExpiryMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.codec.Header;

import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class TimerExpiryMatcherTest {
    private Predicate<TimerExpiry> predicate = Matchers.isA(TimerExpiry.class);
    private TimerExpiryMatcher matcher = new TimerExpiryMatcher() {
        @Override
        public Matcher<TimerExpiryMatcher, Header> header() {
            return matcher -> andThen(translate(timerExpiry -> timerExpiry.header, matcher));
        }
        @Override
        public Matcher<TimerExpiryMatcher, TimerExpiry.Body> body() {
            return matcher -> andThen(translate(timerExpiry -> timerExpiry.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof TimerExpiry && predicate.test((TimerExpiry) o);
        }

        private TimerExpiryMatcher andThen(final Predicate<? super TimerExpiry> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final TimerExpiry timerExpiry = SorMessage.timerExpiry(new MessageHeader(5, 10),
                new TimerExpiry.Body(234234, 56, 32, TimerGroup.PARENT_ORDER_RELEASE));
        assertTrue(matcher.test(timerExpiry));
        assertNotNull(matcher.body());
    }
}
