package com.anz.markets.efx.fox.firewall.rule;

import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

/**
 * The custom rule for order stale check
 * Input stale time is in milliseconds,
 * but all internal calculations are done in nanoseconds
 */
public class StaleOrderRule implements Rule {

    private final long timeoutNanos;
    private final String description;

    public StaleOrderRule(final long timeoutMillis) {
        this.timeoutNanos = TimeUnit.NANOSECONDS.convert(timeoutMillis, TimeUnit.MILLISECONDS);
        this.description = "Stale Order Firewall Rule for " + timeoutMillis + " millis";
    }

    @Override
    public boolean validate(NewOrderSingleDecoder newOrderSingle, long currentTimeNanos) {
        return newOrderSingle.body().transactTime() + timeoutNanos >= currentTimeNanos;
    }

    @Override
    public String description() {
        return description;
    }

}
