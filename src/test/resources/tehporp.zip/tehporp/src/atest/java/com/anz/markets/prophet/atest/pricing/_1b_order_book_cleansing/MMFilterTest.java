package com.anz.markets.prophet.atest.pricing._1b_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AdjustAggregatedConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.domain.IndicativeReason;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import com.google.common.collect.Lists;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Instrument.ANY;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * MM-Filter : order book must contain at least X markets. else mark book as INDICATIVE
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MMFilterTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_1_11)
    @DisplayName("Testing minimal market from 1 market to 2 markets.")
    public void should_remove_market_WHEN_is_minimum_market_is_not_met_and_reaggregated_when_new_data_arrives() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAdjustAggregatedConfigs(Lists.newArrayList(
                            new AdjustAggregatedConfigImpl(ANY, 0),
                            new AdjustAggregatedConfigImpl(AUDUSD, 1_000_000)
                    ))
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 2)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY)
                            )
                    )
                    .setMarketConfigs(Lists.newArrayList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                            new MarketConfigImpl(Market.EBS).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                            new MarketConfigImpl(Market.CITI).setRegion(Region.GB).setInstrument(Instrument.USDCAD)
                            )
                    )
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX,Market.EBS, Market.CITI)
                    .setPassiveHedgerConfigs(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.USDCAD, 0.9450, 0.9700));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CITI, Instrument.USDCAD, 0.9500, 0.9800));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.EBS, Instrument.USDCAD, 0.9600, 0.9900));
        }
        then:
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U));

            // AXPROPHET-1096 filter decision set to always PASS. But now we set the IndicativeReason when triggered
            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.MINIMUM_MARKETS_NOT_AVAILABLE));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.CNX));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CNX));

            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.NONE));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.CITI));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CNX));

            nextMarketData = marketDataSnapshots.get(2);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.EBS));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookOffer()).getMarket(), is(Market.CNX));

            LinkedList<FilteredMarketDataSnapshot> muDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.WSP_U));
            assertThat(muDataSnapshots.get(0).getIndicativeReason(), is(IndicativeReason.MINIMUM_MARKETS_NOT_AVAILABLE));
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_1_11, Ref.PRICING_AXPROPHET_1096})
    @DisplayName("Testing minimal market from 2 markets to 1 market.")
    public void should_remove_market_WHEN_is_minimum_market_is_not_met_and_reaggregated_when_existing_market_is_pulled() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_TAGGED_INDICATIVE_ENABLED, true))
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 2)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY)
                            )
                    )
                    .setMarketConfigs(Lists.newArrayList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.AUDUSD),
                            new MarketConfigImpl(Market.EBS).setRegion(Region.GB).setInstrument(Instrument.AUDUSD),
                            new MarketConfigImpl(Market.CITI).setRegion(Region.GB).setInstrument(Instrument.AUDUSD)
                            )
                    )
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX,Market.EBS, Market.CITI)
                    .setPassiveHedgerConfigs(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.9400, 0.9700));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CITI, Instrument.AUDUSD, 0.9500, 0.9800));
            prophet.receive(tdd.marketDataSnapshot_pullPrice(Market.CNX, Instrument.AUDUSD));
        }
        then:
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U));

            // set MINIMUM_MARKETS_NOT_AVAILABLE flag
            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.MINIMUM_MARKETS_NOT_AVAILABLE));

            // clear MINIMUM_MARKETS_NOT_AVAILABLE flag
            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.NONE));
            assertThat(((MarketDataNewOrder) nextMarketData.getTopOfBookBid()).getMarket(), is(Market.CITI));

            // set MINIMUM_MARKETS_NOT_AVAILABLE flag
            nextMarketData = marketDataSnapshots.get(2);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.MINIMUM_MARKETS_NOT_AVAILABLE));

            // Since MINIMUM_MARKETS_NOT_AVAILABLE flag is set, client price WSP_A is INDICATIVE
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(3), isClientPriceMarket(Market.WSP_A)).getLast();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPrice, PricingFirewallType.MINIMUM_MARKETS);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.9350, 0.9650));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot.isEmpty(), is(false));
            assertThat(marketDataSnapshot.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), is(Market.CITI));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceMarket(Market.WSP_A)).getLast();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.FIRM));
        }
    }

    @Test
    @DisplayName("No need to set Bid/Offer indicative flag since client book is empty")
    public void do_not_set_indic_flag_when_client_book_is_empty() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_TAGGED_INDICATIVE_ENABLED, true))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.9400, 0.9700));
            prophet.receive(tdd.marketDataSnapshot_pullPrice(Market.CNX, Instrument.AUDUSD));
        }
        then:
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshots = prophet.expect(FilteredMarketDataSnapshot.class, exactly(2), isMarket(Market.WSP_U));

            // clear MINIMUM_MARKETS_NOT_AVAILABLE flag
            FilteredMarketDataSnapshot nextMarketData = marketDataSnapshots.get(0);
            assertThat(nextMarketData.isEmpty(), is(false));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.NONE));

            // set MINIMUM_MARKETS_NOT_AVAILABLE flag
            nextMarketData = marketDataSnapshots.get(1);
            assertThat(nextMarketData.isEmpty(), is(true));
            assertThat(nextMarketData.getIndicativeReason(), is(IndicativeReason.MINIMUM_MARKETS_NOT_AVAILABLE));

            // since client price WSP_A is empty no need to set BidAndOfferIndicative flag
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(2), isClientPriceMarket(Market.WSP_A)).getLast();
            assertThat(clientPrice.isEmpty(), is(true));
            assertThat(clientPrice.isBidAndOfferIndicative(), is(false));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.9350, 0.9650));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceMarket(Market.WSP_A)).getLast();
            assertThat(clientPrice.isEmpty(), is(false));
            assertThat(clientPrice.isBidAndOfferIndicative(), is(false));
        }
    }
}
