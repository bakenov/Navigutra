package com.anz.markets.prophet.marketdata.filter;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBook;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.status.Context;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class OrderBookSlowestMarketFilterBWTest {

    private static final int REPS = 100_000, THRESHOLD = 0, START_TIME_MS = 1000;
    private static TestTimeSource timeSource;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private OrderBookSlowestMarketFilter orderBookSlowestMarketFilter;
    private AggregatedBook aggBook;

    @BeforeClass
    public static void warmup() {
        timeSource = new TestTimeSource(START_TIME_MS);
        Context.set(new Context(timeSource));
        Context.region(Region.GB);
        final OrderBookSlowestMarketFilterBWTest test = new OrderBookSlowestMarketFilterBWTest();
        test.setUp();
        test.moreThanTwoMarkets();
    }

    @Before
    public void setUp() {
        orderBookSlowestMarketFilter = OrderBookSlowestMarketFilterTest.createValidSlowestMarketFilter(1);
        aggBook = OrderBookSlowestMarketFilterTest.createFilteredAggBookParams(START_TIME_MS, START_TIME_MS);
    }

    @Test
    public void testWithMoreThanTwoMarkets() {
        helper.testAllocationNotExceeded(
                () -> moreThanTwoMarkets(),
                REPS, REPS,
                THRESHOLD
        );
    }

    public void moreThanTwoMarkets() {
        final FilterDecision filterDecision = orderBookSlowestMarketFilter.perform(aggBook).getFilterOutcome();
        if (filterDecision != FilterDecision.PASS) {
            throw new AssertionError("not PASS");
        }
    }
}