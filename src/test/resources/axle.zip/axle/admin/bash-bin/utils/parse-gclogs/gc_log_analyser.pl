#!/usr/bin/perl

use List::Util qw( min max sum );
use Math::Complex;

my @matchedlines;
my %gctimedata;
my %gcfrequencydata;
my $foundMatchingLines = 0;
my @allData;
my @headers = ("Mean","Median","Min","Max","StdDev","95Perc","99Perc","Count","Time (s)");

foreach $file (@ARGV) {
  print "Processing: $file...";
  open (MYFILE, $file) || die "Could not open file: $file\n";
  $numMatchedLines = 0;
  while(<MYFILE>) {
    chomp;
    # match lines like this: 2014-08-31T21:05:09.772+0000: 243.092: [GC 2 ....
    if ($_ =~ /^\d{4,4}-\d{2,2}-\d{2,2}T.* \[GC.* \[ParNew: \d.*$/ && index($_, 'CMS') == -1) {
      $foundMatchingLines = 1;
      $numMatchedLines++;
   	  @tokens = split(' ', $_);
      $date = substr($tokens[0], 0, 10);
      $time = substr($tokens[0], 11, 12);
      # Calculate reclaimed heap space - transform this: 1685096K->8694K into this: 1685096 - 8694 = 1676402
      $parnewReduction = int(substr($tokens[5],0,index($tokens[5],'K'))) - int(substr($tokens[5],index($tokens[5],'>')+1, index($tokens[5],'(') - 2 - index($tokens[5],'>')+1));
      $heapReduction = int(substr($tokens[8],0,index($tokens[8],'K'))) - int(substr($tokens[8],index($tokens[8],'>')+1, index($tokens[8],'(') - 2 - index($tokens[8],'>')+1));
      $heapsize = int(substr($tokens[8],index($tokens[8],'>')+1, index($tokens[8],'(') - 2 - index($tokens[8],'>')));
      $gctime = $tokens[9] * 1000;
      if ($gctime > 0) {
      	  push @{ $gctimedata{$date} }, $gctime ;
      	  push @{ $gcfrequencydata{$date} }, "$time $parnewReduction $heapReduction $heapsize $gctime";
      	  push (@allData, $gctime);
      }
    }
  }
  print " found $numMatchedLines GC events\n";
  close(MYFILE) || die "Could not close file: $file\n";
}
if (not $foundMatchingLines) { print "No matching lines found in log files. Exiting...\n"; exit 0; }

@keys = sort (keys %gctimedata);
$numDates = @keys;
print "\nGC duration stats (ms)\n\n========================================================================================\n";
print "\t\t\t\t\t\t\t\t\t   GC\tTotal GC\nDate\t\t";
foreach $column (@headers) {
	printf("%6s\t",$column);
}
print "\n----------------------------------------------------------------------------------------\n";

$distributionString;
$frequencyString;
foreach $key (@keys) {
  @gcdata = sort {$a <=> $b} @{$gctimedata{$key}};
  @frequencydata = sort (@{$gcfrequencydata{$key}});
  $size = @gcdata;
  $mean = mean(@gcdata);
  $max = max(@gcdata);
  printStats($key, $mean, median(@gcdata), min(@gcdata), max(@gcdata), stddev(\@gcdata, $mean), percentile(\@gcdata,95), percentile(\@gcdata,99), $size, sum(@gcdata) / 1000);
  $distributionString .= distribution(\@gcdata, $key, $max);
  $frequencyString .= hourlyFrequency(\@frequencydata, $key) . "\n";
}

# If we have more than one days data, calculate averages of whole dataset
if ($numDates > 1) {
	@allData = sort @allData;
	$totalSize = @allData;
	$totalMean = mean(@allData);
	$totalMax = max(@allData);
	$distributionString .= distribution(\@allData, "All Dates", $totalMax);
	print "----------------------------------------------------------------------------------------\n";
	printStats("All dates", $totalMean, median(@allData), min(@allData), $totalMax, stddev(\@allData, $totalMean), percentile(\@allData,95), percentile(\@allData,99), $totalSize, sum(@allData) / 1000);
}
print "\n\nHourly frequency of GC\n\n$frequencyString\n";
print("Distribution of GC duration\n\n$distributionString");

sub printStats {
  my ($date, $mean, $median, $min, $max, $stddev, $perc95, $perc99, $count, $sum) = @_;
  $decimalFormat = "%6.2f\t";
  print "$date\t";
  printf($decimalFormat, $mean);
  printf($decimalFormat, $median);
  printf($decimalFormat, $min);
  printf($decimalFormat, $max);
  printf($decimalFormat, $stddev);
  printf($decimalFormat, $perc95);
  printf($decimalFormat, $perc99);
  printf("%6d", $count);
  printf("\t%8d\n", $sum);
}

sub percentile {
  my ($data, $percentile) = @_;
  @array = @$data;
  $arraysize = @array;
  $realIndex = ($percentile / 100) * $arraysize;
  $index = int($realIndex);
  $frac = $realIndex - $index;
  return ($index < $arraysize) ? ($array[$index-1]*(1-$frac))+($array[$index]*$frac) : $array[$index-1];
}

sub distribution {
  my ($data, $date, $max) = @_;
  @array = @$data;
  $distribution = "$date\n=====================\n";
  $distribution .= "GC (ms)\t\tCount\n---------------------\n";
  $top = $max + 10;
  for ($i = 10; $i <= $top; $i += 10) {
  	$count = 0;
   	foreach $item (@array) {
  	  if ($item <= $i and $item > $i-10) { $count++; }
    }
    if ($count > 0) { $distribution .=  sprintf("%7s",$i-10 . "-$i") . "\t\t" . sprintf("%5s",$count) . "\n"; }
  }
  return "$distribution\n";
}

sub median {
  my @array = @_;
  my $length = @array;
  return (length % 2) ? $array[int($length/2)] : ($array[int($length/2)-1] + $array[int($length/2)])/2;
}

sub mean {
  return sum (@_)/@_;
}

sub stddev {
  my ($data, $mean) = @_;
  @array = @$data;
  $runningTotal = 0;
  $count = @array;
  foreach $item (@array) { $runningTotal += ($item - $mean) * ($item - $mean); }
  return sqrt($runningTotal / $count);
}

sub hourlyFrequency {
  my ($data, $date) = @_;
  $frequency = "============================================================================================\n";
  $frequency .= "$date\t\t\t\t    Avg heap\tAvg GC\t    Max GC\t\tTime\n";
  $frequency .= "\t\t\t\t\t   reclaimed\t  Time\t      Time\t  longest GC\n";
  $frequency .= "Time\t\tCount\tAvg GC/min\t per GC (Mb)\t  (ms)\t      (ms)\t    occurred\n";
  $frequency .= "--------------------------------------------------------------------------------------------\n";
  @array = @$data;
  $prevHour = substr($array[0],0,2);
  $parnewRunningTotal = 0;
  $heapSizeRunningTotal = 0;
  $gcTimeRunningTotal = 0;
  $count = 0;
  $maxGCTime = 0;
  $timeMaxGCOccurred = "";

  #open (FH, '>>', 'heaptimeseries.csv') or die "Could not open file $!";
  foreach $item (@array) {
  	  @tokens = split(' ',$item);
  	  $hour = substr($tokens[0],0,2);
  	  $max = $tokens[4];
  	#  print FH "\"$date\",\"$tokens[0]\",\"$tokens[3]\"\n";
  	  if ($hour != $prevHour) {
  	  	  $frequency .= $prevHour . ":00-" . ($prevHour+1 < 10 ? "0" . ($prevHour+1) : ($prevHour+1)) . ":00\t" . sprintf("%5s",$count) . "\t" . sprintf("%10.2f",($count / 60)) . "\t" . sprintf("%12d",($heapSizeRunningTotal / $count / 1024)) . sprintf("%10.2f", $gcTimeRunningTotal / $count) . "\t" . sprintf("%10.2f",$maxGCTime) . "\t$timeMaxGCOccurred" . "\n";
  	  	  $prevHour = $hour;
  	  	  $count = 1;
  	  	  $parnewRunningTotal = 0;
  	  	  $heapSizeRunningTotal = 0;
  	  	  $maxGCTime = 0;
  	  	  $timeMaxGCOccurred = "";
  	  	  $gcTimeRunningTotal = 0;
  	  }
  	  else {
  	  	  $count++;
  	  	  if ($max > $maxGCTime) {
  	  	    $maxGCTime = $max;
  	  	    $timeMaxGCOccurred = $tokens[0];
  	  	  }
  	  	  $parnewRunningTotal += int($tokens[1]);
  	  	  $heapSizeRunningTotal += int($tokens[2]);
  	  	  $gcTimeRunningTotal += $tokens[4];
  	  }
  }
  $frequency .= $prevHour . ":00-" . ($prevHour+1 < 10 ? "0" . ($prevHour+1) : ($prevHour+1)) . ":00\t" . sprintf("%5s",$count) . "\t" . sprintf("%10.2f",($count / 60)) . "\t" . sprintf("%12d",($heapSizeRunningTotal / $count / 1024)) . sprintf("%10.2f", $gcTimeRunningTotal / $count) . "\t".  sprintf("%10.2f",$maxGCTime) .  "\t$timeMaxGCOccurred" . "\n";
  #close (FH) or die "unable to close file\n";
  return $frequency;
}