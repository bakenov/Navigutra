package com.anz.markets.efx.ngaro.sbe;

import org.agrona.DirectBuffer;

public interface SbeMessage {
    DirectBuffer buffer();
    /** @return message length including header */
    int messageLength();
}
