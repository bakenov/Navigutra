package com.anz.markets.efx.fox.firewall.rule.customer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.firewall.api.PropertyProvider;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for compareTo method of the CustomerRules
 */
@ExtendWith(MockitoExtension.class)
class CustomerRuleTest {

    private static final long TIMEOUT = 1;
    private static final TimeUnit TIME_UNIT = TimeUnit.SECONDS;

    private DummyRule rule1;
    private StaleOrderRule rule2;

    @BeforeEach
    void setUp() {
        PropertyProvider properties = (k) -> {
            switch(k) {
                case StaleOrderRule.TIMEOUT_THRESHOLD_PROPERTY_NAME:
                    return Long.toString(TIMEOUT);
                case StaleOrderRule.TIMEOUT_TIME_UNIT_PROPERTY_NAME:
                    return TIME_UNIT.name();
                default:
                    return null;
            }
        };
        LongSupplier timeSupplier = () -> System.nanoTime();
        rule1 = new DummyRule(CustomerRuleType.DUMMY, timeSupplier, properties);
        rule2 = new StaleOrderRule(CustomerRuleType.STALE_ORDER, timeSupplier, properties);
    }

    @Test
    void test_corporator() {
        ArrayList<CustomerRule> list = new ArrayList<>();
        list.add(rule1);
        list.add(rule2);
        assertThat(list.get(0).priority()).isEqualTo(CustomerRule.Priority.LOWWEST);
        assertThat(list.get(1).priority()).isEqualTo(CustomerRule.Priority.HIGHEST);
        Collections.sort(list);
        assertThat(list.get(0).priority()).isEqualTo(CustomerRule.Priority.HIGHEST);
        assertThat(list.get(1).priority()).isEqualTo(CustomerRule.Priority.LOWWEST);
    }

    @Test
    void test_corporator2() {
        ArrayList<CustomerRule> list = new ArrayList<>();
        list.add(rule1);
        list.add(rule2);
        assertThat(list.get(1).priority()).isEqualTo(CustomerRule.Priority.HIGHEST);
        assertThat(list.get(0).priority()).isEqualTo(CustomerRule.Priority.LOWWEST);
        Collections.sort(list);
        assertThat(list.get(0).priority()).isEqualTo(CustomerRule.Priority.HIGHEST);
        assertThat(list.get(1).priority()).isEqualTo(CustomerRule.Priority.LOWWEST);
    }
}