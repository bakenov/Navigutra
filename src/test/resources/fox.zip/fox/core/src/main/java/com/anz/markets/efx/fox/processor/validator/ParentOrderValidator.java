package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;


public interface ParentOrderValidator {
    interface ErrorHandler {
        void onError(String errorMessage, NewOrderSingleDecoder parentOrder, CommandContext commandContext);
    }

    interface NamedValidator extends ParentOrderValidator {
        String name();
    }

    boolean validate(NewOrderSingleDecoder parentOrder, CommandContext commandContext);
}
