package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link FormattedDateEncoder}
 */
public class FormattedDateEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test
    public void encode() throws Exception {
        //given
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encode(2016, 02, 28);

        //then
        assertEquals("encoded string not as expected", "20160228", encoder.target().toStringOrNull());

        //when
        encoder.encodeNullable(LocalDate.of(2017, 03, 14));

        //then
        assertEquals("encoded string not as expected", "20170314", encoder.target().toStringOrNull());

        //when
        encoder.encodeNullable(null);

        //then
        assertEquals("encoded string should be null", null, encoder.target().toStringOrNull());
    }

    @Test
    public void encodeFormatted() throws Exception {
        //given
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeFormatted("20160228", LocalDateFormat.YYYYMMDD);

        //then
        assertEquals("encoded string not as expected", "20160228", encoder.target().toStringOrNull());

        //when
        encoder.encodeFormatted("13-03-2017", LocalDateFormat.DD_MM_YYYY);

        //then
        assertEquals("encoded string not as expected", "20170313", encoder.target().toStringOrNull());

        //when
        encoder.encodeFormatted("abc23-12-2015", ByteReader.CHAR_SEQUENCE, 3, LocalDateFormat.DD_MM_YYYY.getDefaultDecoder());

        //then
        assertEquals("encoded string not as expected", "20151223", encoder.target().toStringOrNull());

        //when
        encoder.encodeFormatted(null, LocalDateFormat.YYYYMMDD);

        //then
        assertEquals("encoded string should be null", null, encoder.target().toStringOrNull());

        //when
        encoder.encodeFormatted(null, LocalDateFormat.YYYYMMDD.getDefaultDecoder());

        //then
        assertEquals("encoded string should be null", null, encoder.target().toStringOrNull());
    }

    @Test
    public void encodeEpochMillis() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeEpochMillis(localDate.toEpochDay() * Epoch.MILLIS_PER_DAY);

        //then
        assertEquals("encoded string not as expected", "20170314", encoder.target().toStringOrNull());
    }

    @Test
    public void encodeEpochSeconds() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeEpochSeconds(localDate.toEpochDay() * Epoch.SECONDS_PER_DAY);

        //then
        assertEquals("encoded string not as expected", "20170314", encoder.target().toStringOrNull());
    }

    @Test
    public void encodePackedDecimal() throws Exception {
        //given
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encode(LocalDatePacking.DECIMAL, 20170314);

        //then
        assertEquals("encoded string not as expected", "20170314", encoder.target().toStringOrNull());
    }

    @Test
    public void encodePackedBinary() throws Exception {
        //given
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encode(LocalDatePacking.BINARY, LocalDatePacking.BINARY.pack(2017, 03, 14));

        //then
        assertEquals("encoded string not as expected", "20170314", encoder.target().toStringOrNull());
    }

    @Test
    public void encodeEpochDays() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeEpochDays(localDate.toEpochDay());

        //then
        assertEquals("encoded string not as expected", "20170314", encoder.target().toStringOrNull());
    }

    @Test
    public void encodeNull() throws Exception {
        //given
        final FormattedDateEncoder<?, MutableAsciiString> encoder = FormattedDateEncoder.forAsciiString(
                ENCLOSING_ENCODER, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeNull();

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encodeNullable(null);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encode(0, 0, 0);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encodeEpochDays(0);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encodeEpochSeconds(0);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encodeEpochMillis(0);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encode(LocalDatePacking.BINARY, 0);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());

        //when
        encoder.encode(LocalDatePacking.DECIMAL, 0);

        //then
        assertEquals("encoded string not as expected", null, encoder.target().toStringOrNull());
    }

}