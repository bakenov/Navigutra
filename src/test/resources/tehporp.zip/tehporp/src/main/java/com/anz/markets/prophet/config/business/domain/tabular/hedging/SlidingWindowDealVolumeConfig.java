package com.anz.markets.prophet.config.business.domain.tabular.hedging;


import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SlidingWindowDealVolumeConfigImpl;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.TradingTimeZone;

import java.util.List;

public interface SlidingWindowDealVolumeConfig extends ProphetMarshallable {

    SlidingWindowDealVolumeConfig EMPTY = new SlidingWindowDealVolumeConfigImpl("UNDEFINED", Instrument.ANY, 0, 0, 0, "", TradingTimeZone.GLOBAL);

    String getClient();

    List<String> getClientsAsList();

    Instrument getInstrument();

    double getFillQuantity();

    long getFillIntervalMS();

    long getDelayPeriodMS();

    String getStandDownTriggers();

    List<HedgeTriggerType> getStandDownTriggersAsList();

    TradingTimeZone getTradingTimeZone();
}
