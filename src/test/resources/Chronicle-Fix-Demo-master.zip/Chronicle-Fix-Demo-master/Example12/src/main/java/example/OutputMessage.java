package example;

import net.openhft.chronicle.wire.AbstractMarshallable;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.yaml.InvokeWithSession;

/**
 * Created by Jerry Shea on 25/10/18.
 */
public class OutputMessage extends AbstractMarshallable implements InvokeWithSession {
    private String message;

    @Override
    public void accept(FixSessionHandler fixSessionHandler, FixSessionHandler fixSessionHandler2) {
        System.out.println(message);
    }
}
