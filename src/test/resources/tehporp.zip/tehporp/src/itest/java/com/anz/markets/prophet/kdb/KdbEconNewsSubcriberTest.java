package com.anz.markets.prophet.kdb;

import com.anz.markets.prophet.domain.Country;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import org.junit.Test;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.function.Consumer;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class KdbEconNewsSubcriberTest {

    private static final String TIMESTAMP_COL = "timestamp";
    private static final String SYM_COL = "sym";
    private static final String SOURCE_COL = "source";
    private static final String COUNTRY_COL = "country";
    private static final String DESCRIPTION_COL = "description";
    private static final String NEWSOURCE_COL = "newsource";
    private static final String PERIOD_COL = "period";
    private static final String ACTUAL_VOL = "actual";
    private static final String PRIORVAL_COL = "priorval";
    private static final String REVISED_COL = "revised";
    private static final String UNITS_COL = "units";
    private static final String SURVEYMIN_COL = "surveymin";
    private static final String SURVEYMAX_COL = "surveymax";
    private static final String SURVEYNUM_COL = "surveynum";
    private static final String EVENTTIMESTAMP_COL = "eventtimestamp";

    private static final String CODE = "ADHOCALL5=ECIAN";
    private static final Timestamp EVENTTIMESTAMP = new Timestamp(100), EVENTTIMESTAMP2 = new Timestamp(200);

    private static final String TEST_HOST = "";
    private static final int TEST_PORT = 0;
    private static final String TEST_CREDENTIALS = "";
    private final Consumer<EconNews> econNewsConsumer = new Consumer<EconNews>() {
        @Override
        public void accept(final EconNews econNews) {

        }
    };

    private KDBConnection.Flip kdbEconNewsUpdate;

    private final KdbEconNewsSubscriber econNewsSubscriber;
    private final KdbEconNewsDeserialiser deserialiser = new KdbEconNewsDeserialiser();

    public KdbEconNewsSubcriberTest() throws IOException, KDBConnection.KException {
        super();
        initaliseTestData();
        this.econNewsSubscriber = new KdbEconNewsSubscriber(TEST_HOST, TEST_PORT, TEST_CREDENTIALS, econNewsConsumer);
    }


    @Test
    public void testAcceptEconNewsUpdate() {
        EconNewsImpl econNews = new EconNewsImpl();
        econNews.setCode(CODE);
        econNews.setDescription("Jap");
        econNews.setCountry(Country.JP);
        econNews.setEventTimeStampMS(EVENTTIMESTAMP.getTime());
        EconNewsImpl econNews2 = new EconNewsImpl();
        econNews2.setCode(CODE + "2");
        econNews2.setDescription("Jap2");
        econNews2.setCountry(Country.EMPTY);
        econNews2.setEventTimeStampMS(EVENTTIMESTAMP2.getTime());

        List<EconNews> econNewsList = deserialiser.deserialise(kdbEconNewsUpdate);
        assertThat(2, is(econNewsList.size()));

        assertSame(econNews, econNewsList.get(0));
        assertSame(econNews2, econNewsList.get(1));
    }

    private void assertSame(final EconNewsImpl econNews, final EconNews news) {
        assertThat(news.getCode(), is(econNews.getCode()));
        assertThat(news.getDescription(), is(econNews.getDescription()));
        assertThat(news.getCountry(), is(econNews.getCountry()));
        assertThat(news.getEventTimeStampMS(), is(econNews.getEventTimeStampMS()));
    }

    private void initaliseTestData() {
        String[] cols = {TIMESTAMP_COL, SYM_COL, SOURCE_COL, COUNTRY_COL, DESCRIPTION_COL, NEWSOURCE_COL, PERIOD_COL, ACTUAL_VOL, PRIORVAL_COL, REVISED_COL, UNITS_COL, SURVEYMAX_COL, SURVEYMIN_COL, SURVEYNUM_COL, EVENTTIMESTAMP_COL};
        final long time = System.currentTimeMillis();
        Object[] data = new Object[]{
                new Timestamp[]{EVENTTIMESTAMP, EVENTTIMESTAMP2},
                new String[]{CODE, CODE + "2"},
                new String[]{"REUTERS"},
                new String[]{"JP", ""},
                new Object[]{new char[]{'J', 'a', 'p'}, new char[]{'J', 'a', 'p', '2'}},
                new String[]{"ANZ"},
                new String[]{"Daily"},
                new Integer[]{Integer.MIN_VALUE},
                new Integer[]{Integer.MIN_VALUE},
                new Integer[]{Integer.MIN_VALUE},
                new Integer[]{Integer.MIN_VALUE},
                new Integer[]{Integer.MIN_VALUE},
                new Integer[]{Integer.MIN_VALUE},
                new Integer[]{Integer.MIN_VALUE},
                new Timestamp[]{EVENTTIMESTAMP, EVENTTIMESTAMP2}};

        KDBConnection.Dict econNewsData = new KDBConnection.Dict(cols, data);
        this.kdbEconNewsUpdate = new KDBConnection.Flip(econNewsData);

    }

}