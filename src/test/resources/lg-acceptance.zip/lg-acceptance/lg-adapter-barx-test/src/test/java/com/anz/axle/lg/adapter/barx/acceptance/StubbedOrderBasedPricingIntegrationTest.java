package com.anz.axle.lg.adapter.barx.acceptance;

import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.PricingFixSessionHelper;
import com.anz.axle.lg.adapter.acceptance.utils.TradingFixSessionHelper;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;


public class StubbedOrderBasedPricingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StubbedOrderBasedPricingIntegrationTest.class);

    private static final String senderCompId = "GB:lg-barx";
    private static final Venue marketId = Venue.BARX;
    private static final String QUOTE_ENTRY_ID = "12345678";
    private static final String QUANTITY_STRING = "1000000.00";
    private static final String BID_PRICE_STRING = "0.7567";
    private static final String OFFER_PRICE_STRING = "0.7569";
    private static final String NORMALISED_SYMBOL = "AUDUSD";
    private static final String SYMBOL = SymbolNormaliser.toSymbol7(NORMALISED_SYMBOL);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(NORMALISED_SYMBOL, SecurityType.FXSPOT, Tenor.SP);

    private static final String FIX_DATA_DICTIONARY_FILE = "conf/FIX42-barx.xml";


    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private MatchingSession pricingServer;
    private MatchingSession tradingServer;
    private SharedAcceptanceContext acceptanceContext;
    private PricingFixSessionHelper pricingFixSessionHelper;
    private TradingFixSessionHelper tradingFixSessionHelper;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
            StringUtils.parseMap(
            "appName:lg-barx" +
                    ",default.log.level:DEBUG" +
                    ",barx.fix.log.destination:FILE" +
                    ",barx.fix.trading.reset.on.logon:Y" +
                    ",barx.fix.trading.reset.on.logout:Y" +
                    ",barx.fix.trading.reset.on.disconnect:Y" +

                    ",barx.fix.pricing.sendercompid:GB_BARX_MD_S" +
                    ",barx.fix.pricing.targetcompid:GB_BARX_MD_T" +
                    ",barx.fix.pricing.host:localhost" +
                    ",barx.fix.pricing.port:55589" +

                    ",barx.fix.trading.sendercompid:GB_BARX_TR_S" +
                    ",barx.fix.trading.targetcompid:GB_BARX_TR_T" +
                    ",barx.fix.trading.host:localhost" +
                    ",barx.fix.trading.port:55590"
            ));

        pricingFixSessionHelper = new PricingFixSessionHelper("barx", "GB_BARX_MD_S", "GB_BARX_MD_T", "FIX.4.2", FIX_DATA_DICTIONARY_FILE);
        tradingFixSessionHelper = new TradingFixSessionHelper("barx", "GB_BARX_TR_S", "GB_BARX_TR_T", "FIX.4.2", FIX_DATA_DICTIONARY_FILE);

        application = new Application("lg-barx-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        if (pricingServer != null) pricingServer.shutdown();
        if (tradingServer != null) tradingServer.shutdown();

        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private Predicate<Object> defaultIncrementalRefreshMessageMatcher() {
        return IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(marketId))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().countEquals(2)
                .hops().countAtLeast(2);
    }

    private final FixMessage defaultQuoteFixMessage(final String requestId) {
        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.QUOTE.getOrdinal())
                .withField(FieldTypes.QuoteReqID, requestId)
                .withField(FieldTypes.QuoteID, QUOTE_ENTRY_ID)
                .withField(FieldTypes.QuoteType, "2")

                .withField(FieldTypes.Symbol, NORMALISED_SYMBOL)
                .withField(FieldTypes.BidPx, BID_PRICE_STRING)
                .withField(FieldTypes.OfferPx, OFFER_PRICE_STRING)
                .withField(FieldTypes.BidSize, QUANTITY_STRING)
                .withField(FieldTypes.OfferSize, QUANTITY_STRING)
                .withField(FieldTypes.BidSpotRate, BID_PRICE_STRING)
                .withField(FieldTypes.OfferSpotRate, OFFER_PRICE_STRING)

                .build();
    }

    @Test
    public void should_receive_pricing_and_send_order_with_expected_quoteId() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();
        tradingServer = tradingFixSessionHelper.createTradingSession();

        tradingServer.discardUntil("35=A");


        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for QuoteRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("55=" + SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataSnapshotRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultQuoteFixMessage(marketDataRequest.getField(FieldTypes.QuoteReqID).getValue()));

        //Then the  MarketDataSnapshotRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);


        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                    LOGGER.info(incrementalRefresh.toString());
                    final NewOrderSingle newOrder = newOrder(incrementalRefresh, 1000000.0, Side.SELL);
                    LOGGER.info(newOrder.toString());
                    LOGGER.info("==============================================================");
                    acceptanceContext.tradingRequestMessageQueue().add(newOrder);

                    tradingServer.discardUntil("35=D|55=" + SYMBOL + "|117=" + QUOTE_ENTRY_ID);
                }
        });
    }

    private NewOrderSingle newOrder(final IncrementalRefresh incrementalRefresh, final double quantity, final Side side) {
        final InstrumentKey instrumentKey = InstrumentKey.of(incrementalRefresh.body.instrumentId);
        final int entryIndex = side == Side.SELL ? 0 : 1;

        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.ordType = OrderType.PREVIOUSLY_QUOTED;
        newOrderSingle.body.timeInForce = TimeInForce.FOK;
        newOrderSingle.body.price = incrementalRefresh.entries.get(entryIndex).mdEntryPx;
        newOrderSingle.body.quoteId = incrementalRefresh.entries.get(entryIndex).quoteEntryId + "";
        newOrderSingle.body.messageId = acceptanceContext.tradingMessageIdGenerator().get();
        newOrderSingle.body.orderQty = quantity;
        newOrderSingle.body.clOrdId = acceptanceContext.tradingMessageIdGenerator().get() + "";
        newOrderSingle.body.currency = instrumentKey.symbol().substring(0, 3);
        newOrderSingle.body.marketId = marketId.name();

        newOrderSingle.body.senderCompId = "GB:lg-acc";
        newOrderSingle.body.settlCurrency = newOrderSingle.body.currency;
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = instrumentKey.symbol();
        newOrderSingle.body.securityType = instrumentKey.securityType();
        newOrderSingle.body.settlType = instrumentKey.tenor();
        return newOrderSingle;
    }

}