package com.anz.markets.efx.fox.codec.pojo;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

public class InitialisationAsserter {
    private final Initialisation message;

    public InitialisationAsserter(final Initialisation message) {
        this.message = Objects.requireNonNull(message);
    }

    public static InitialisationAsserter expect(final Initialisation message) {
        return new InitialisationAsserter(message);
    }

    public static InitialisationAsserter expect(final MessageHeader header, final Initialisation.Body body) {
        return new InitialisationAsserter(SorMessage.initialisation(header, body));
    }

    public Initialisation message() {
        return message;
    }

    public Initialisation.Body body() {
        return message.body;
    }

    public InitialisationHandler assertingInitialisationHandler() {
        return body -> {
            assertEquals("initStage not as expected", body().initStage, body.initStage());
        };
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a Initialisation", sorMessage instanceof Initialisation);
        assertInitialisation((Initialisation) sorMessage);
    }

    public void assertInitialisation(final Initialisation initialisation) {
        assertBody(initialisation.body);
    }

    public void assertBody(final Initialisation.Body body) {
        assertEquals("initStage not as expected", body().initStage, body.initStage);
    }
}
