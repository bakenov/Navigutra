package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTwapHedgerConfig;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AggressiveTwapHedgerConfigImpl implements AggressiveTwapHedgerConfig, ProphetMarshallable {
    private Market market;
    private Instrument instrument;
    private TradingTimeZone tradingTimeZone = TradingTimeZone.GLOBAL;
    public long orderRateLimit;
    public long orderRateTimePeriodMS;
    public double maximumSpread = Double.NaN;
    public long minimumQuantity;
    public double minimumRisk = Double.NaN;
    public FactorWindow volatilityFactorWindow = FactorWindow.NONE;
    public double minimumVolatility = Double.NaN;

    public transient int volatilityPeriodInMillis = 0;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public AggressiveTwapHedgerConfigImpl() {
    }

    public AggressiveTwapHedgerConfigImpl(final Market market,
                                          final Instrument instrument) {
        this.market = market;
        this.instrument = instrument;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public double getMaximumSpread() {
        return maximumSpread;
    }

    @Override
    public long getMinimumQuantity() {
        return minimumQuantity;
    }

    @Override
    public double getMinimumRisk() {
        return minimumRisk;
    }

    @Override
    public long getOrderRateLimit() {
        return orderRateLimit;
    }

    @Override
    public long getOrderRateTimePeriodMS() {
        return orderRateTimePeriodMS;
    }

    @Override
    public TradingTimeZone getTradingTimeZone() {
        return tradingTimeZone;
    }

    @Override
    public FactorWindow getVolatilityFactorWindow() {
        return volatilityFactorWindow;
    }

    @Override
    public double getMinimumVolatility() {
        return minimumVolatility;
    }

    @JsonIgnore
    @Override
    public int getVolatilityPeriodInMillis() {
        return volatilityPeriodInMillis;
    }

    public AggressiveTwapHedgerConfigImpl setMaximumSpread(final double maximumSpread) {
        this.maximumSpread = maximumSpread;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setMinimumQuantity(final long minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setMinimumRisk(final double minimumRisk) {
        this.minimumRisk = minimumRisk;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setOrderRateLimit(final long orderRateLimit) {
        this.orderRateLimit = orderRateLimit;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setOrderRateTimePeriodMS(final long orderRateTimePeriodMS) {
        this.orderRateTimePeriodMS = orderRateTimePeriodMS;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setTradingTimeZone(final TradingTimeZone tradingTimeZone) {
        this.tradingTimeZone = tradingTimeZone;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setVolatilityFactorWindow(final FactorWindow volatilityFactorWindow) {
        this.volatilityFactorWindow = volatilityFactorWindow;
        return this;
    }

    public AggressiveTwapHedgerConfigImpl setMinimumVolatility(final double minimumVolatility) {
        this.minimumVolatility = minimumVolatility;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        Context.context().header().before(MessageVersion.VERSION_0_27, () -> {
            this.market = in.readEnum(Market.class);
            this.instrument = in.readEnum(Instrument.class);
            this.orderRateLimit = in.readLong();
            this.orderRateTimePeriodMS = in.readLong();
            this.maximumSpread = in.readDouble();
            this.minimumQuantity = in.readLong();
            this.minimumRisk = in.readDouble();
        });
        Context.context().header().since(MessageVersion.VERSION_0_27, () -> {
            this.market = Market.valueOf(in.readByte());
            this.instrument = Instrument.readMarshallableValueOf(in);
            this.orderRateLimit = in.readLong();
            this.orderRateTimePeriodMS = in.readLong();
            this.maximumSpread = in.readDouble();
            this.minimumQuantity = in.readLong();
            this.minimumRisk = in.readDouble();
        });
        Context.context().header().before(MessageVersion.VERSION_0_32, () -> this.tradingTimeZone = TradingTimeZone.GLOBAL);
        Context.context().header().since(MessageVersion.VERSION_0_32, () -> this.tradingTimeZone = TradingTimeZone.valueOf(in.readByte()));
        Context.context().header().since(MessageVersion.VERSION_0_58, () -> {
            this.volatilityFactorWindow = FactorWindow.valueOf(in.readByte());
            this.minimumVolatility = in.readDouble();
        });
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(this.market.getValue());
        out.writeShort(this.instrument.getValue());
        out.writeLong(this.orderRateLimit);
        out.writeLong(this.orderRateTimePeriodMS);
        out.writeDouble(this.maximumSpread);
        out.writeLong(this.minimumQuantity);
        out.writeDouble(this.minimumRisk);
        out.writeByte(this.tradingTimeZone.getValue());
        out.writeByte(this.volatilityFactorWindow.getValue());
        out.writeDouble(this.minimumVolatility);
    }

    @Override
    public String toString() {
        return "AggressiveTwapHedgerConfigImpl{" +
                "market=" + market +
                ", instrument=" + instrument +
                ", tradingTimeZone=" + tradingTimeZone +
                ", orderRateLimit=" + orderRateLimit +
                ", orderRateTimePeriodMS=" + orderRateTimePeriodMS +
                ", maximumSpread=" + maximumSpread +
                ", minimumQuantity=" + minimumQuantity +
                ", minimumRisk=" + minimumRisk +
                ", volatilityFactorWindow=" + volatilityFactorWindow +
                ", minimumVolatility=" + minimumVolatility +
                '}';
    }
}
