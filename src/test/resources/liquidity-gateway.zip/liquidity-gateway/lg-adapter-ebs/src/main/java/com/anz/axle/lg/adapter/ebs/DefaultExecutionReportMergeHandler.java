package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradeCaptureReport;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import net.openhft.chronicle.bytes.Bytes;
import org.agrona.collections.Long2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.CANCELED;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.NEW;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.REPLACE;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.TRADE;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.TRIGGERED_OR_ACTIVATED_BY_SYSTEM;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MatchStatus.COMPARED_MATCHED_OR_AFFIRMED;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MatchStatus.PENDING_AWAITING_CONCLUSION;

public class DefaultExecutionReportMergeHandler implements EbsExecutionReportMergeHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultExecutionReportMergeHandler.class);

    private final Long2ObjectHashMap<ExecutionReportMerger> clOrdIdToExecutionReportMap;
    private final ObjectPool<ExecutionReportMerger> executionReportMergerPool;
    private final ChronicleMessageHandler<ExecutionReport> executionReportHandler;
    private final Bytes clOrdID_buffer = Bytes.allocateElasticDirect();

    public DefaultExecutionReportMergeHandler(final ChronicleMessageHandler<ExecutionReport> executionReportHandler,
                                              final int executionReportInitialPoolSize) {
        this(executionReportHandler,
                new Long2ObjectHashMap<>(),
                new ObjectPool<>(consumer -> new ExecutionReportMerger(), executionReportInitialPoolSize));
    }

    protected DefaultExecutionReportMergeHandler(final ChronicleMessageHandler<ExecutionReport> executionReportHandler,
                                                 final Long2ObjectHashMap<ExecutionReportMerger> clOrdIdToExecutionReportMap,
                                                 final ObjectPool<ExecutionReportMerger> executionReportMergerPool) {
        this.executionReportHandler = Objects.requireNonNull(executionReportHandler);
        this.clOrdIdToExecutionReportMap = Objects.requireNonNull(clOrdIdToExecutionReportMap);
        this.executionReportMergerPool = Objects.requireNonNull(executionReportMergerPool);
    }

    @Override
    public void onExecutionReport(final ExecutionReport executionReport) {
        if (executionReport != null) {
            long clOrdId = clOrdId(executionReport.clOrdID());
            ExecutionReportMerger executionReportMerger = clOrdIdToExecutionReportMap.get(clOrdId);

            if (executionReportMerger == null && executionReport.origClOrdID() != null) {
                clOrdId = clOrdId(executionReport.origClOrdID());
                executionReportMerger = clOrdIdToExecutionReportMap.get(clOrdId);
            }

            switch (executionReport.execType()) {
                case NEW:
                    final ExecutionReportMerger cacheInstance = clOrdIdToExecutionReportMap.computeIfAbsent(clOrdId, e -> executionReportMergerPool.borrowOrNew());
                    cacheInstance.copyFrom(executionReport);
                    LOGGER.debug("cached {}", cacheInstance);
                    forwardToExecutionReportHandler(executionReport);
                    break;

                case CANCELED:
                case TRIGGERED_OR_ACTIVATED_BY_SYSTEM:
                    LOGGER.info("Received Cancel ER: clOrdId={}, orderQty={}, cumQty={}, leavesQty={}", clOrdId, executionReport.orderQty(), executionReport.cumQty(), executionReport.leavesQty());
                    if (executionReportMerger != null && executionReportMerger.cancel(executionReport)) {
                        forwardToExecutionReportHandler(executionReportMerger.executionReport());
                    }
                    break;

                case REPLACE:
                    if (executionReportMerger != null) {
                        final long removeClOrdId = clOrdId(executionReportMerger.executionReport().clOrdID());
                        clOrdID_buffer.clear();
                        clOrdID_buffer.append(clOrdId);
                        executionReportMerger.updateClOrdId(clOrdID_buffer);
                        clOrdIdToExecutionReportMap.remove(removeClOrdId);
                        clOrdIdToExecutionReportMap.put(clOrdId, executionReportMerger);
                    }
                    break;

                case TRADE: // Ignore. Use NEW as base ER
                    LOGGER.info("Received Fill ER: clOrdId={}, orderQty={}, cumQty={}, leavesQty={}", clOrdId, executionReport.orderQty(), executionReport.cumQty(), executionReport.leavesQty());
                    break;

                default:
                    forwardToExecutionReportHandler(executionReport);
            }
            cleanAndRelease(clOrdId, executionReportMerger);
        }
    }

    @Override
    public void onTradeCaptureReport(final TradeCaptureReport tradeCaptureReport) {
        if (tradeCaptureReport != null) {
            LOGGER.debug("Received {}", tradeCaptureReport);
            final long clOrdId = clOrdId(tradeCaptureReport.tradeCaptureReport_SidesGrp_1(0).clOrdID());
            final ExecutionReportMerger executionReportMerger = clOrdIdToExecutionReportMap.get(clOrdId);
            if (executionReportMerger != null) {
                switch (tradeCaptureReport.matchStatus()) {
                    case PENDING_AWAITING_CONCLUSION:
                        executionReportMerger.savePendingDealQty((long)tradeCaptureReport.lastQty());
                        break;

                    case COMPARED_MATCHED_OR_AFFIRMED:
                        final ExecutionReport executionReport = executionReportMerger.merge(tradeCaptureReport);
                        if (executionReport != null) {
                            LOGGER.info("publishing ExecutionReport/TradeCaptureReport merged ER clOrdId(11)={}, execType(150)={}, execID(17)={}, lastQty(32)={}, leavesQty(151)={}",
                                    clOrdId, executionReport.execType(), executionReport.execID(), executionReport.lastQty(), executionReport.leavesQty());
                            forwardToExecutionReportHandler(executionReport);
                        }
                        final ExecutionReport executionReportCancel = executionReportMerger.sendCancel();
                        if (executionReportCancel != null) {
                            forwardToExecutionReportHandler(executionReportCancel);
                        }
                }
            } else {
                LOGGER.warn("TradeCaptureReport(573=0) did not find matching ExecutionReport(150=F): {}", tradeCaptureReport);
            }
            cleanAndRelease(clOrdId, executionReportMerger);
        }
    }

    private void cleanAndRelease(final long clOrdId, final ExecutionReportMerger executionReportMerger) {
        if (executionReportMerger != null && executionReportMerger.isComplete()) {
            executionReportMerger.reset();
            clOrdIdToExecutionReportMap.remove(clOrdId);
            executionReportMergerPool.release(executionReportMerger);
        }
    }

    private void forwardToExecutionReportHandler(final ExecutionReport executionReport) {
        executionReportHandler.accept(executionReport);
    }
    private long clOrdId(final Bytes clOrdID) {
        clOrdID_buffer.clear();
        clOrdID_buffer.append(clOrdID);
        return clOrdID_buffer.parseLong();
    }
}
