package com.anz.axle.lg.adapter.deut.quickfix;

import java.util.function.Consumer;
import java.util.function.Supplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import quickfix.Message;

import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.FixSide;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.FormattedTimeParser;
import com.anz.axle.lg.util.test.FixMessageFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DeutSnapshotFullRefreshHandlerTest {
    private static final String SENDER_COMP_ID = "GB:DEUT";
    private static final String COMP_ID = "GB:lg-deut";
    private static final FormattedTimeParser FORMATTED_TIME_PARSER = new FormattedTimeParser();
    private static final long CURRENT_TIME = 34523453;
    private static final long MSG_SEQ_NUM = 4319;
    private static final String MSG_SEQ_NUM_STRING = "4319";
    private static final String SENDING_TIME_STRING = "20161129-06:23:35.982";
    private static final long SENDING_TIME_NANOS = FORMATTED_TIME_PARSER.parseNanos(SENDING_TIME_STRING);
    private static final String SYMBOL = "AUD/JPY";
    private static final String NORMALISED_SYMBOL = "AUDJPY";
    private static final SecurityType SECURITY_TYPE = SecurityType.FXSPOT;
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(NORMALISED_SYMBOL, SECURITY_TYPE, Tenor.SP);
    private static final String MDR_ID = "1234567";
    private static final int MDR_ID_INT = Integer.parseInt(MDR_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(MDR_ID);
    private static final String QUOTE_ENTRY_ID = "75290169";
    private static final EntryType SIDE = EntryType.BID;
    private static final String QUANTITY_STRING = "550000.00";
    private static final String PRICE_STRING = "80.131";

    private MockitoPricingEncoder encoders = new MockitoPricingEncoder();
    private FixMessageFactory messageFactory;
    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderSupplier encoderSupplier = mock(PricingEncoderSupplier.class);
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    @Mock
    private Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private DeutSnapshotFullRefreshHandler deutSnapshotFullRefreshHandler;
    private InOrder inOrder;
    private Supplier<StringToIntCache> quteIdCacheSupplier = new StringToIntCacheFactory(100, 25, 100, 8, 1);
    private StringToIntCache quoteIdCache = quteIdCacheSupplier.get();
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    @Before
    public void setUp() throws Exception {
        deutSnapshotFullRefreshHandler = new DeutSnapshotFullRefreshHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, flagsAppender, sourceSequencer);
        messageFactory = new FixMessageFactory("/conf/FIX44-deut.xml");
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);
        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),


                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotEntries_next,
                encoders.snapshotEntries_body,

                encoders.snapshotEntries_body.mdEntryFlags(),

                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),
                encoders.messageEncoder);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY)).thenReturn(RequestKey.of(Venue.DEUT, INSTRUMENT_KEY));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(MDR_ID_INT)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        when(marketDataSubscription.symbol()).thenReturn(SYMBOL);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
        when(marketDataSubscription.stringToIntCache()).thenReturn(quoteIdCache);

    }


    @Test
    public void shouldProcessSnapshotWithOneEntry() throws Exception {
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "W",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "55=", SYMBOL,
                "262=", MDR_ID,
                "268=", "1",
                "269=", FixSide.to(SIDE),
                "270=", PRICE_STRING,
                "271=", QUANTITY_STRING,
                "299=", QUOTE_ENTRY_ID + "",
                "5020=", "20171122",
                "10=", "15");
        //when
        deutSnapshotFullRefreshHandler.accept(snapshotMessage);

        //then
        verifySnapshot( 1, quoteIdCache.put(QUOTE_ENTRY_ID), SIDE, QUANTITY_STRING, PRICE_STRING);
    }

    @Test
    public void shouldProcessSnapshotWithMultipleEntries() throws Exception {
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "W",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "55=", SYMBOL,
                "262=", MDR_ID,
                "268=", "3",
                "269=", FixSide.to(SIDE),
                "270=", PRICE_STRING,
                "271=", QUANTITY_STRING,
                "299=", QUOTE_ENTRY_ID + "",
                "5020=", "20171122",
                "269=", "1",
                "270=", "1.30418",
                "271=", "3000000",
                "299=", "2552825524",
                "5020=", "20171122",
                "269=", "0",
                "270=", "1.3118",
                "271=", "1000000",
                "299=", "2552825525",
                "5020=", "20171122",
                "10=", "188");
        //when
        deutSnapshotFullRefreshHandler.accept(snapshotMessage);

        //then
        verifySnapshot( 3, quoteIdCache.put(QUOTE_ENTRY_ID), SIDE, QUANTITY_STRING, PRICE_STRING);
    }

    @Test
    public void shouldProcessEmptySnapshot() throws Exception {
        // E.g. 8=FIX.4.4^A9=103^A35=W^A49=ABFX^A56=ANZ_MD_003^A52=20171120-11:58:17.980^A34=42896^A55=EUR/JPY^A262=20171120-04:41:24.30^A268=0^A10=128^A
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "W",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "55=", SYMBOL,
                "262=", MDR_ID,
                "268=", "0",
                "10=", "79");
        //when
        deutSnapshotFullRefreshHandler.accept(snapshotMessage);

        //then
        verifySnapshot( 0, 0, null, null, null);
    }



    private void verifySnapshot(final int entriesCount,
                                final int entryId,
                                final EntryType side,
                                final String quantityString,
                                final String priceString) {
        inOrder.verify(encoders.snapshotBody).marketId(Venue.DEUT);
        inOrder.verify(encoders.snapshotBody).instrumentId(INSTRUMENT_KEY.instrumentId());

        inOrder.verify(encoders.snapshotBody.senderCompId()).encode(COMP_ID);
        inOrder.verify(encoders.snapshotBody).messageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotBody).sendingTime(SENDING_TIME_NANOS);

        if (entriesCount == 0) {
            inOrder.verify(encoders.snapshotBody).entriesEmpty();
        } else {
            inOrder.verify(encoders.snapshotBody).entriesStart(entriesCount);
            inOrder.verify(encoders.snapshotEntries_body).mdMkt(Venue.DEUT);
            inOrder.verify(encoders.snapshotEntries_body).mdEntryType(side);
            inOrder.verify(encoders.snapshotEntries_body).mdEntrySize(Double.valueOf(quantityString));
            inOrder.verify(encoders.snapshotEntries_body).mdEntryPx(Double.valueOf(priceString));
            inOrder.verify(encoders.snapshotEntries_body).mdEntryId(entryId);
            inOrder.verify(encoders.snapshotEntries_body).quoteEntryId(entryId);
            inOrder.verify(encoders.snapshotEntries_next).entriesComplete();
        }

        inOrder.verify(encoders.snapshotHops).hopsStart(2);
        inOrder.verify(encoders.snapshotHops_next).next();
        inOrder.verify(encoders.snapshotHops_body.hopCompId()).encode(SENDER_COMP_ID);
        inOrder.verify(encoders.snapshotHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotHops_body).hopSendingTime(SENDING_TIME_NANOS);
        inOrder.verify(encoders.snapshotHops_body).next();
        inOrder.verify(encoders.snapshotHops_body.hopCompId()).encode(COMP_ID);
        inOrder.verify(encoders.snapshotHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotHops_body).hopReceivingTime(CURRENT_TIME);
        inOrder.verify(encoders.snapshotHops_body).hopSendingTime(CURRENT_TIME);
        inOrder.verify(encoders.snapshotHops_body).hopsComplete();
        inOrder.verify(encoders.messageEncoder).messageComplete();
    }
}