package com.anz.markets.prophet.atest.pricing._0a_pre_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1234})
public class FilteredMktDataSnapshotAggregatePricePointsTest extends BaseAcceptanceSpecification {
    /**
     *  AXPROPHET-1213:
     *  Aggregate price points when publishing FilteredMarketDataSnapshots. Occurs after BandedToStack conversion
     */
    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.AGGREGATE_PRICE_POINT_MARKETS, new Market[]{Market.CNX, Market.BARX}));

        return configuration;
    }

    @Test
    public void mktNotConfiguredDoNotAggregatePricePoints() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75030, 4_000_000),
                            new PriceAndQtyImpl(0.75024, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 2_000_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot mds = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.DEUT)).getLast();
            assertThat(mds.getBidEventList().size(), Matchers.is(3));
            assertThat(mds, isMarketPricePoint(0, Level.QTY_1M, 0.75030, Level.QTY_1M, 0.75050));
            assertThat(mds, isMarketPricePoint(1, Level.QTY_4M, 0.75030, Level.QTY_2M, 0.75055));
            assertThat(mds, isMarketPricePoint(2, Level.QTY_4M, 0.75024, Level.QTY_1M, 0.75055));
        }
    }

    @Test
    public void aggregatePricePoints() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75030, 4_000_000),
                            new PriceAndQtyImpl(0.75024, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 2_000_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot mds = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX)).getLast();
            assertThat(mds.getBidEventList().size(), Matchers.is(2));
            assertThat(mds, isMarketPricePoint(0, Level.QTY_5M, 0.75030, Level.QTY_1M, 0.75050));
            assertThat(mds, isMarketPricePoint(1, Level.QTY_4M, 0.75024, Level.QTY_3M, 0.75055));

            final FilteredMarketDataSnapshot mdsU = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX)).getLast();
            assertThat(mdsU, isMarketPricePoint(0, Level.QTY_5M, 0.75030, Level.QTY_1M, 0.75050));
        }
    }

    @Test
    public void aggregatePricePointstest() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75030, 4_000_000),
                            new PriceAndQtyImpl(0.75024, 4_000_000)),
                    Arrays.asList(QuoteType.FIRM,
                            QuoteType.INDICATIVE,
                            QuoteType.FIRM),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 2_000_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000)),
                    Arrays.asList(QuoteType.FIRM,
                            QuoteType.INDICATIVE,
                            QuoteType.FIRM),
                    tdd.now()));
        }
        then:
        // Do not aggregate Bid 1 & Bid 2.  Do not aggregate Offer 2 & Offer 3
        {
            final FilteredMarketDataSnapshot mds = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX)).getLast();
            assertThat(mds.getBidEventList().size(), Matchers.is(2));
            assertThat(mds.getOfferEventList().size(), Matchers.is(2));
            assertThat(mds, isMarketPricePoint(0, Level.QTY_1M, 0.75030, Level.QTY_1M, 0.75050));
            assertThat(mds, isMarketPricePoint(1, Level.QTY_4M, 0.75024, Level.QTY_1M, 0.75055));
        }
    }
}