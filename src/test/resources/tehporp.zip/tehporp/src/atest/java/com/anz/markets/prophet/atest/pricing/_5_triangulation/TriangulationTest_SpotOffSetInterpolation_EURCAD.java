package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.time.LocalDate;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class TriangulationTest_SpotOffSetInterpolation_EURCAD extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = {Ref.PRICING_4_6, Ref.PRICING_4_6_4})
    @DisplayName("Triangulation of cross pair where driver pair's Spot Date differ: EURCAD")
    public void given_driver_pairs_with_different_spot_dates_triangulate_cross_pair() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.USDCAD;
        final Instrument crossPair = Instrument.EURCAD;

        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(5)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(1)));

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(5)));

            // receive/send fwd points for driverPairB
            prophet.receive(tdd.forwardPoint(driverPairB, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(driverPairB, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.1),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            // receive driver pair EURUSD MID rate = 1.11455
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.11455, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.1145350, 1.1145650));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.1145275, 1.1145725));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.1145175, 1.1145825));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.1144850, 1.1146150));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.1144450, 1.1146550));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.1142850, 1.1148150));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.1142850, 1.1148150));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.1142250, 1.1148750));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 1.1141200, 1.1149800));
        }
        when:
        {
            // receive driver pair USDCAD MID Rate = 1.30525
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.30525, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(7));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.3052200, 1.3052800));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.3051975, 1.3053025));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.3051550, 1.3053450));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.3051550, 1.3053450));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.3050800, 1.3054200));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.3049800, 1.3055200));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.3046500, 1.305850));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPrice.getBids().size(), is(6));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.4546712297, 1.4548080489));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.4546316397, 1.4548476424));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.4545785223, 1.4549007612));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.4545189302, 1.4549603737));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.4543659723, 1.4551133814));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.4539290280, 1.4555507014));
        }
    }
}
