package com.anz.axle.lg.adapter.citi.quickfix;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.BidPx;
import quickfix.field.BidSize;
import quickfix.field.MsgSeqNum;
import quickfix.field.NoQuoteEntries;
import quickfix.field.OfferPx;
import quickfix.field.OfferSize;
import quickfix.field.QuoteEntryID;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteType;
import quickfix.field.SendingTime;
import quickfix.field.Symbol;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;


public final class CitiMassQuoteHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(CitiMassQuoteHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public CitiMassQuoteHandler(final VenueRequestKeyLookup requestKeyLookup,
                                final PricingEncoderLookup pricingEncoderLookup,
                                final PrecisionClock precisionClock,
                                final SubscriptionManager subscriptionManager,
                                final String senderCompId,
                                final String compId,
                                final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_MASS_QUOTE;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("MassQuote received: {}", message);
        final int quoteRequestId = message.getInt(QuoteReqID.FIELD);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = sequenceNumber; //FIXME prepend with uniquely generated session id
        final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
        final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());
        final List<Group> quoteEntryGroups = message.getGroups(NoQuoteEntries.FIELD);
        final String fixSymbol6 = uniqueSymbol(message);
        if (fixSymbol6 == null) {
            throw new IllegalArgumentException("Multi-currency mass quote is not supported. Message: " + message);
        }
        final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(quoteRequestId);
        subscription.validateInternalSymbol(fixSymbol6);
        final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
        final SnapshotFullRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        flagsAppender.accept(encoder.mdFlags());
        if (isQuoteIndicative(message)) {
            encoder.mdFlags().add(Flag.INDICATIVE);
        }
        final SnapshotFullRefreshEncoder.Body mdEntries = encoder
                .possResend(false)
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .sendingTime(sendingTimeNanos)
                .referenceSpotDate().encodeNull()
                .tradeDate().encodeNull()
                .settlDate().encodeNull();
        encodeEntries(sendingTimeNanos, quoteEntryGroups, requestKey, mdEntries, subscription.stringToIntCache())
            .hopsStart(2)
                .next()
                .hopCompId().encode(senderCompId)
                .hopMessageId(sequenceNumber)
                .hopSendingTime(sendingTimeNanos)
                .next()
                .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                .hopReceivingTime(receivingTimeNanos)
                .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
        .messageComplete();
    }

    private Hops.Encoder<MessageEncoder.Trailer> encodeEntries(final long sendingTimeNanos, final List<Group> quoteEntryGroups, final RequestKey requestKey, final SnapshotFullRefreshEncoder.Body mdEntries, final StringToIntCache mdEntryCache) throws FieldNotFound {
        final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = mdEntries.entriesStart(quoteEntryGroups.size() * 2);
        for (Group quoteEntryGroup : quoteEntryGroups) {
            final int quoteEntryID = mdEntryCache.put(quoteEntryGroup.getString(QuoteEntryID.FIELD));
            final double bidPrice = quoteEntryGroup.getDouble(BidPx.FIELD);
            final double bidSize = quoteEntryGroup.getDouble(BidSize.FIELD);
            final double offerPrice = quoteEntryGroup.getDouble(OfferPx.FIELD);
            final double offerSize = quoteEntryGroup.getDouble(OfferSize.FIELD);

            mdEntries_Next
                    .next()
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(EntryType.BID)
                        .mdEntrySize(bidSize)
                        .minQty(Double.NaN)
                        .mdEntryPx(bidPrice)
                        .mdEntryId(quoteEntryID)
                        .quoteEntryId(quoteEntryID)
                    .next()
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(EntryType.OFFER)
                        .mdEntrySize(offerSize)
                        .minQty(Double.NaN)
                        .mdEntryPx(offerPrice)
                        .mdEntryId(quoteEntryID)
                        .quoteEntryId(quoteEntryID);
        }
        return mdEntries_Next.entriesComplete();
    }

    private String uniqueSymbol(final Message message) throws FieldNotFound {
        final List<Group> quoteEntryGroups = message.getGroups(NoQuoteEntries.FIELD);

        String symbol = null;
        for (final Group quoteEntry : quoteEntryGroups) {
            final String entrySymbol = quoteEntry.getString(Symbol.FIELD);
            if (symbol == null) {
                symbol = entrySymbol;
            } else if (!symbol.equals(entrySymbol)) {
                throw new IllegalArgumentException("Multi-currency mass quote is not supported. Message: " + message);
            }
        }
        return symbol;
    }

    private boolean isQuoteIndicative(final Message message) throws FieldNotFound {
        if (message.isSetField(QuoteType.FIELD)){
            return QuoteType.INDICATIVE == message.getInt(QuoteType.FIELD);
        } else {
            return false;
        }
    }

}
