package com.anz.markets.efx.ngaro.codec;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Decoder of a message using the <i>stepped decoding</i> approach.
 * <p>
 * <b>Stepped decoding</b>
 * <br>
 * Decoders are {@link MessageDecoder.Factory#create(Handler, ForwardingLookup) created} with a handler.  Handlers define methods for
 * different decoding steps starting with {@link MessageDecoder.Handler#onMessageStart() onMessageStart()}.  Each step
 * (defined by handler subclasses) provides access to certain message elements of that step, other elements are decoded
 * in the next step and so on until decoding is completed via the final
 * {@link MessageDecoder.Handler#onMessageComplete() onMessageComplete()} step.  A stepped decoding approach is necessary
 * if the wire format constrains a certain encoding order.  Application code shall therefore not hold on to step
 * decoders and decode elements out of sequence as this would violate the encoding order and lead to exceptions.
 *
 * @param <M> the message type, or a buffer/medium containing messages
 */
public interface MessageDecoder<M> {
    /**
     * Decodes the given message and returns true if a compatible message is found.
     *
     * @param message the message to decode, or the buffer/medium containing the message
     * @return true if a compatible message was found, false otherwise
     * @throws NullPointerException if message or handler is null
     */
    boolean decode(M message);

    /**
     * Chains this decoder with the nextDecoder so that nextDecoder will be executed only if this decoder results in false.
     * @param nextDecoder
     * @return a new instance of MessageDecoder composing this and the nextDecoder
     */
    default MessageDecoder<M> orThen(final MessageDecoder<? super M> nextDecoder) {
        Objects.requireNonNull(nextDecoder);
        return message -> decode(message) || nextDecoder.decode(message);
    }

    /**
     * Chains this decoder with the nextDecoder so that nextDecoder will be executed only if this decoder results in true.
     * The final result is logical or of both decoders.
     * @param nextDecoder
     * @return a new instance of MessageDecoder composing this and the nextDecoder
     */
    default MessageDecoder<M> andThen(final MessageDecoder<? super M> nextDecoder) {
        Objects.requireNonNull(nextDecoder);
        return message -> {
            final boolean firstResult = decode(message);
            return (firstResult && nextDecoder.decode(message)) || firstResult;
        };
    }

    /**
     * Creates a new composite message decoder which stops if the first delegate decoder successfully
     * decodes the message.
     *
     * @param decoders  the delegate decoders
     * @param <M> the message type, or a buffer/medium containing messages
     * @return a composite decoder delegating to the specified decoders until one of them is successful
     */
    static <M> MessageDecoder<M> composite(final MessageDecoder<? super M>... decoders) {
        Objects.requireNonNull(decoders);
        return m -> {
            for (final MessageDecoder<? super M> decoder : decoders) {
                if (decoder.decode(m)) {
                    return true;
                }
            }
            return false;
        };
    }

    /**
     * Creates a new composite message decoder which stops if the first delegate decoder successfully
     * decodes the message.
     *
     * @param decoders  the delegate decoders
     * @param <M> the message type, or a buffer/medium containing messages
     * @return a composite decoder delegating to the specified decoders until one of them is successful
     */
    static <M> MessageDecoder<M> composite(final List<? extends MessageDecoder<? super M>> decoders) {
        Objects.requireNonNull(decoders);
        return m -> {
            for (int i = 0; i < decoders.size(); i++) {
                if (decoders.get(i).decode(m)) {
                    return true;
                }
            }
            return false;
        };
    }

    /**
     * Handler called when decoding a message.  Handlers for concrete messages will add more methods for
     * callback with actual message content (See for instance {@link Hops.Handler} for an example).
     */
    interface Handler {
        /**
         * First method that is called in the decoding process once message type has been determined.
         * <p>
         * The default implementation is NO-OP as most implementors don't need to handle this.
         * @param source - source decoded from header
         * @param sourceSeq - source sequence decoded from header
         */
        default void onMessageStart(final int source, final long sourceSeq) {
            //no op
        }

        /**
         * Second optional method that is called in the decoding process. It provides an underlying message forwarder
         * that can be used within the handler. As Handler is decoupled from actual message decoder, handler has no
         * control over the message being decoded. However messageForwarder can be used by a Handler to request the underlying
         * message to be processed by another MessageDecoder.
         * For example: One Handler decides that the content of the message being decoded should be forwarded to another decoder
         * that should persist to the message to an event store.
         * @param messageForwarder - message forwarder can only use destination name to forward the underlying message.
         */
        default void messageForwarder(final MessageForwarder messageForwarder) {
            //no op
        }

        /**
         * Third optional method that is called in the decoding process. It provides a message logger
         * that is implemented by the underlying decoder.
         * @param messageLogger
         */
        default void messageLogger(final Consumer<StringBuilder> messageLogger) {
            //no op
        }

        /**
         * Last method called upon completion of the message decoding process.
         * <p>
         * The default implementation is NO-OP as most implementors don't need to handle this.
         */
        default void onMessageComplete() {
            //no op
        }
    }

    /**
     * Forwarding lookup used by MessageForwarder implemented in MessageDecoder.
     * MessageForwarding may need to be used by some Handlers.
     * @param <M> the message type, or a buffer/medium containing messages
     */
    interface ForwardingLookup<M> extends Function<String, MessageDecoder<M>> {
        static <M> ForwardingLookup<M> noop() {
            final MessageDecoder<M> decoder = message -> false;
            return destination -> decoder;
        }
    }

    /**
     * Message decoder factory handling a single message type.
     *
     * @param <M> the message type, or a buffer/medium containing messages
     * @param <H> the handler called back with the decoded message elements
     */
    @FunctionalInterface
    interface Factory<M, H extends Handler> {
        /**
         * Returns a decoder that invokes the handler supplied by the given handler supplier.
         *
         * @param handlerSupplier supplier for handler called for every message found to be compatible with this decoder
         * @param forwardingLookup forwarding lookup that may be used by the decoder for forwarding purposes
         * @return a decoder invoking the specified handler for decoded messages
         * @throws NullPointerException if message or handler is null
         */
        MessageDecoder<M> create(Supplier<? extends H> handlerSupplier, ForwardingLookup<M> forwardingLookup);

        /**
         * Returns a decoder that invokes the specified {@code handler} for decoded messages.
         *
         * @param handler handler called for every message found to be compatible with this decoder
         * @param forwardingLookup forwarding lookup that may be used by the decoder for forwarding purposes
         * @return a decoder invoking the specified handler for decoded messages
         * @throws NullPointerException if message or handler is null
         */
        default MessageDecoder<M> create(final H handler, ForwardingLookup<M> forwardingLookup) {
            Objects.requireNonNull(handler);
            Objects.requireNonNull(forwardingLookup);
            return create(() -> handler, forwardingLookup);
        }

        /**
         * Returns a decoder that invokes the specified {@code handler} for decoded messages.
         *
         * @param handler handler called for every message found to be compatible with this decoder
         * @return a decoder invoking the specified handler for decoded messages
         * @throws NullPointerException if message or handler is null
         */
        default MessageDecoder<M> create(final H handler) {
            return create(handler, MessageDecoder.ForwardingLookup.noop());
        }

        /**
         * Returns a decoder that invokes the handler supplied by the given handler supplier.
         *
         * @param handlerSupplier supplier for handler called for every message found to be compatible with this decoder
         * @return a decoder invoking the specified handler for decoded messages
         * @throws NullPointerException if message or handler is null
         */
        default MessageDecoder<M> create(Supplier<? extends H> handlerSupplier) {
            return create(handlerSupplier, MessageDecoder.ForwardingLookup.noop());
        }

    }
}
