package com.anz.axle.lg.adapter.fast.chroniclefix;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.staticcode.context.FixSessionContext;

import com.anz.axle.lg.adapter.fast.chroniclefix.generated.generators.MessageGenerator;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.NewOrderSingle;

public class ServerMessageNotifier implements MessageNotifier {

    @Override
    public MessageGenerator onNewOrderSingle(final FixSessionContext session, final NewOrderSingle newOrderSingle) {
        final MessageGenerator messageGenerator = new MessageGenerator('8');
        messageGenerator.bytes(Bytes.elasticByteBuffer());
        messageGenerator.bytes().append(
                "37=ORDER_ID17=EXEC_ID20=020=0150=039=055=SYM54=1151=1014=166=1.511=clordid");

        return messageGenerator;
    }

}
