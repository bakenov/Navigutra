package com.anz.axle.direct.performance;

import com.anz.axle.direct.performance.metrics.BasicStats;
import com.anz.axle.direct.performance.metrics.Count;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.axle.direct.performance.metrics.Rates;
import com.anz.markets.prophet.status.Context;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

import static com.anz.axle.direct.performance.CsvMetricReporter.ReportStat.COUNTS;
import static com.anz.axle.direct.performance.CsvMetricReporter.ReportStat.HISTOGRAM;

public class CsvMetricReporter implements MetricReporter {
    private static final Logger LOGGER = LoggerFactory.getLogger(CsvMetricReporter.class);
    public static final String DATE_TIME_FORMAT = "yyyy.MM.dd'D'HH:mm:ss.SSS";
    private static DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern(DATE_TIME_FORMAT).withZone(DateTimeZone.UTC);
    private final NumberFormat numberFormat;
    private final BufferedWriter csvWriter;
    private final ReportStat reportStat;

    public enum ReportStat { HISTOGRAM, COUNTS }

    public CsvMetricReporter(final String csvFile, final ReportStat reportStat) throws IOException {
        numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setGroupingUsed(false);
        numberFormat.setMaximumFractionDigits(3);
        numberFormat.setMinimumFractionDigits(1);
        csvWriter = Files.newBufferedWriter(Paths.get(csvFile));
        this.reportStat = reportStat;
        if (reportStat == HISTOGRAM) {
            appendHistogramHeader();
        } else if (reportStat == COUNTS) {
            appendCountsHeader();
        }
    }


    private void appendCountsHeader() {
        StringBuilder sb = new StringBuilder();
        sb.append("time, ");
        sb.append("timeMS, ");
        sb.append("name, ");
        sb.append("count, ");
        sb.append("rate");
        try {
            csvWriter.append(sb);
            csvWriter.newLine();
        } catch (IOException e) {
            LOGGER.error("Cannot write header to csv", e);
        }
    }

    @Override
    public void appendCounts(final Collection<Count> counters) {
        if(reportStat != COUNTS) {
            return;
        }

        for (final Count counter : counters) {
            final long timeMS = TimeUnit.NANOSECONDS.toMillis(Context.context().header().getEventTimeStampNS());
            StringBuilder sb = new StringBuilder();
            sb.append(DATE_TIME_FORMATTER.print(timeMS)).append(',');
            sb.append(timeMS).append(',');
            sb.append(counter.getName()).append(',');
            sb.append(counter.getCount()).append(',');
            sb.append(numberFormat.format(counter.getRate()));
            try {
                csvWriter.append(sb);
                csvWriter.newLine();
            } catch (IOException e) {
                LOGGER.error("Cannot write counter to csv", e);
            }
        }
        try {
            csvWriter.flush();
        } catch (IOException e) {
            LOGGER.error("Cannot write to csv", e);
        }
    }


    private void appendHistogramHeader() {
        StringBuilder sb = new StringBuilder();
        sb.append("time, ");
        sb.append("timeMS, ");
        sb.append("name, ");
        sb.append("count, ");
        sb.append("min, ");
        sb.append("max, ");
        sb.append("mean, ");
        sb.append("median, ");
        sb.append("p75, ");
        sb.append("p95, ");
        sb.append("p98, ");
        sb.append("p99, ");
        sb.append("p999");
        try {
            csvWriter.append(sb);
            csvWriter.newLine();
        } catch (IOException e) {
            LOGGER.error("Cannot write header to csv", e);
        }
    }
    @Override
    public void appendHistograms(final Collection<Percentiles> percentilesList) {
        if(reportStat != HISTOGRAM) {
            return;
        }

        for (final Percentiles percentiles : percentilesList) {
            final long timeMS = TimeUnit.NANOSECONDS.toMillis(Context.context().header().getEventTimeStampNS());
            StringBuilder sb = new StringBuilder();
            sb.append(DATE_TIME_FORMATTER.print(timeMS)).append(',');
            sb.append(timeMS).append(',');
            sb.append(percentiles.getName()).append(',');
            sb.append(percentiles.getCount()).append(',');
            sb.append(convertToLong(percentiles.getMin())).append(',');
            sb.append(convertToLong(percentiles.getMax())).append(',');
            sb.append(convertToLong(percentiles.getMean())).append(',');
            sb.append(convertToLong(percentiles.getPercentile(50.0))).append(',');
            sb.append(convertToLong(percentiles.getPercentile(75.0))).append(',');
            sb.append(convertToLong(percentiles.getPercentile(95.0))).append(',');
            sb.append(convertToLong(percentiles.getPercentile(98.0))).append(',');
            sb.append(convertToLong(percentiles.getPercentile(99.0))).append(',');
            sb.append(convertToLong(percentiles.getPercentile(99.9)));
            try {
                csvWriter.append(sb);
                csvWriter.newLine();
            } catch (IOException e) {
                LOGGER.error("Cannot write histogram to csv", e);
            }
        }
        try {
            csvWriter.flush();
        } catch (IOException e) {
            LOGGER.error("Cannot write to csv", e);
        }
    }

    private long convertToLong(final double d) {
        return Double.isNaN(d) ? 0 : (long)(d);
    }


    @Override
    public void appendBasicStats(final Collection<BasicStats> basicStatsList) {
        // not implemented
    }

    @Override
    public void appendRates(final Collection<Rates> ratesList) {
        // not implemented
    }

    @Override
    public void beginReports() {
        // not implemented
    }

    @Override
    public void endReports() {
        // not implemented
    }

}
