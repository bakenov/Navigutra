package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsItemConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.domain.Currency;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EconNewsItemConfigImpl implements EconNewsItemConfig, ProphetMarshallable {
    private String code;
    private String currencies;
    private EconNewsWeight weight;

    private List<Currency> currenciesAsEnum = new ArrayList<>();

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public EconNewsItemConfigImpl() {
    }

    public EconNewsItemConfigImpl(final String code,
                                  final EconNewsWeight weight,
                                  final String currencies) {
        this.code = code;
        this.currencies = currencies;
        this.weight = weight;
        this.currenciesAsEnum = Currency.parseCsv(currencies);
    }

    public EconNewsItemConfigImpl(final String code,
                                  final EconNewsWeight weight,
                                  final List<Currency> currencies) {
        this.code = code;
        this.currencies = currencies.stream().map(e -> e.name()).collect(Collectors.joining(","));
        this.weight = weight;
        this.currenciesAsEnum = currencies;
    }

    public EconNewsItemConfigImpl(final String code,
                                  final EconNewsWeight weight,
                                  final Currency... currencies) {
        this(code, weight, Arrays.asList(currencies));
    }

    @Override
    public String getCode() {
        return code;
    }

    public String getCurrencies() {
        return currencies;
    }

    @Override
    public EconNewsWeight getWeight() {
        return weight;
    }

    @JsonIgnore
    @Override
    public List<Currency> getCurrenciesAsEnum() {
        if (currenciesAsEnum.size() == 0) {
            this.currenciesAsEnum.addAll(Currency.parseCsv(currencies));
        }
        return currenciesAsEnum;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        FieldReflectionBytesMarshallable.INSTANCE.read(in, this);
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        FieldReflectionBytesMarshallable.INSTANCE.write(this, out);
    }

    @Override
    public String toString() {
        return "EconNewsItemConfigImpl{" +
                "code='" + code + '\'' +
                ", currencies='" + currencies + '\'' +
                ", weight=" + weight +
                ", currenciesAsEnum=" + currenciesAsEnum +
                '}';
    }
}
