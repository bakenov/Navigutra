package com.anz.axle.lg.adapter.acceptance.utils;

import java.util.ArrayList;
import java.util.List;

import org.fix4j.spec.fix50sp2.FixSpec;
import org.fix4j.test.fixmodel.BaseFixMessageBuilder;
import org.fix4j.test.fixmodel.Field;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.fixspec.FieldType;

public class FixMessageBuilder {
    private final List<Field> fieldList;

    public FixMessageBuilder() {
        fieldList = new ArrayList<>();
    }

    public FixMessageBuilder withField(final FieldType type, final FixMessage fixMessage)
    {
        return withField(type, fixMessage.getField(type).getValue());
    }

    public FixMessageBuilder withField(final FieldType type, final Object value)
    {
        return withField(new Field(type, value.toString()));
    }

    public FixMessageBuilder withField(final Field field)
    {
        fieldList.add(field);
        return this;
    }

    public FixMessage build() {
        return new BaseFixMessageBuilder(FixSpec.INSTANCE)
                .withFields(fieldList)
                .build();
    }
}
