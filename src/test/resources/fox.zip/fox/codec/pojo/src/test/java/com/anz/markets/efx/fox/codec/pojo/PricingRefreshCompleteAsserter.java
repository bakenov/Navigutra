package com.anz.markets.efx.fox.codec.pojo;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PricingRefreshCompleteAsserter {
    private final PricingRefreshComplete message;

    public PricingRefreshCompleteAsserter(final PricingRefreshComplete message) {
        this.message = Objects.requireNonNull(message);
    }

    public static PricingRefreshCompleteAsserter expect(final PricingRefreshComplete message) {
        return new PricingRefreshCompleteAsserter(message);
    }

    public static PricingRefreshCompleteAsserter expect(final MessageHeader header, final PricingRefreshComplete.Body body) {
        return new PricingRefreshCompleteAsserter(SorMessage.pricingRefreshComplete(header, body));
    }

    public PricingRefreshComplete message() {
        return message;
    }

    public PricingRefreshComplete.Body body() {
        return message.body;
    }

    public PricingRefreshCompleteHandler assertingPricingRefreshCompleteHandler() {
        return new PricingRefreshCompleteHandler() {

            @Override
            public void onMessageStart(final int source, final long sourceSeq) {
                HeaderAsserter.assertHeader(header(), source, sourceSeq);
            }

            @Override
            public void onBody(final Body body) {
                assertEquals("instrumentId not as expected", PricingRefreshCompleteAsserter.this.body().instrumentId, body.instrumentId());
                assertEquals("forceSnapshot not as expected", PricingRefreshCompleteAsserter.this.body().forceSnapshot, body.forceSnapshot());
            }
        };
    }

    public MessageHeader header() {
        return message.header;
    }

    public void assertPricingMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a PricingRefreshComplete", sorMessage instanceof PricingRefreshComplete);
        assertPricingRefreshComplete((PricingRefreshComplete) sorMessage);
    }

    public void assertPricingRefreshComplete(final PricingRefreshComplete pricingRefreshComplete) {
        assertBody(pricingRefreshComplete.body);
    }

    public void assertBody(final PricingRefreshComplete.Body body) {
        assertEquals("instrumentId not as expected", body().instrumentId, body.instrumentId);
        assertEquals("forceSnapshot not as expected", body().forceSnapshot, body.forceSnapshot);
    }
}
