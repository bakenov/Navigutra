package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.domain.TradingTimeZone;

public interface MidHedgerConfig extends HedgeInstrumentConfig {

    double ZERO_RISK = 0d;
    double DEFAULT_ACTIVE_BELOW_RISK = -1d;

    MidHedgerConfig EMPTY = new MidHedgerConfigImpl();

    double getOrderQuantity();

    double getRiskTriggerHighWaterMark();

    double getRiskTriggerLowWaterMark();

    double getVarTriggerHighVar();

    boolean activeAtRisk(final double currentRisk);

    long getVarTriggerMaxTimeToLiveMS();

    TradingTimeZone getTradingTimeZone();
}
