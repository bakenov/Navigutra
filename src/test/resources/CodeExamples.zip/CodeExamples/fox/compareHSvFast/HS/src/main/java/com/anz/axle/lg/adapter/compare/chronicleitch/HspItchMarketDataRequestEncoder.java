package com.anz.axle.lg.adapter.hsp.chronicleitch;


import software.chronicle.itch.staticcode.Constants;
import software.chronicle.itchcboe.messages.client.MarketDataSubscribeRequest;
import software.chronicle.itchcboe.messages.client.MarketDataUnsubscribeRequest;
import software.chronicle.itchcboe.messages.datamodel.client.DefaultMarketDataSubscribeRequest;
import software.chronicle.itchcboe.messages.datamodel.client.DefaultMarketDataUnsubscribeRequest;

import com.anz.axle.lg.adapter.chronicleitch.MarketDataSubscribeRequestEncoder;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

public final class HspItchMarketDataRequestEncoder implements MarketDataSubscribeRequestEncoder<MarketDataSubscribeRequest, MarketDataUnsubscribeRequest> {
    private final MarketDataSubscribeRequest marketDataSubscribeRequest = new DefaultMarketDataSubscribeRequest();
    private final MarketDataUnsubscribeRequest marketDataUnSubscribeRequest = new DefaultMarketDataUnsubscribeRequest();

    @Override
    public MarketDataSubscribeRequest encodeSubscribe(final MarketDataSubscription subscription) {
        marketDataSubscribeRequest.ccyPair(subscription.symbol());
        marketDataSubscribeRequest.tLF(Constants.TLF);
        return marketDataSubscribeRequest;
    }

    @Override
    public MarketDataUnsubscribeRequest encodeUnsubscribe(final MarketDataSubscription subscription) {
        marketDataUnSubscribeRequest.ccyPair(subscription.symbol());
        marketDataUnSubscribeRequest.tLF(Constants.TLF);
        return marketDataUnSubscribeRequest;
    }
}
