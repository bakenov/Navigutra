package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;

import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.api.domain.ChildOrderState;
import com.anz.markets.efx.fox.api.domain.ChildOrderVisitor;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;

public class WaitingToWorkingTimerExpiryHandler implements TimerScheduler.ExpiryHandler {
    private final ChildOrder order;
    private CommandContext commandContext;

    public WaitingToWorkingTimerExpiryHandler(final ChildOrder order) {
        this.order = Objects.requireNonNull(order);
    }

    private final ChildOrderVisitor childOrderVisitor = new ChildOrderVisitor() {
        @Override
        public void visit(final ChildOrderState.WaitingOrderState order) {
            order.requestCancel(commandContext, null); //FIXME have requestCancel with optional orderCancelRequest
        }
    };

    @Override
    public TimerGroup timerGroup() {
        return TimerGroup.CHILD_ORDER_WAITING_TO_WORKING;
    }

    @Override
    public boolean onExpiryCommand(final long timerId, final long triggeredTime, final CommandContext commandContext) {
        this.commandContext = Objects.requireNonNull(commandContext);
        order.accept(childOrderVisitor);
        return true;
    }
}
