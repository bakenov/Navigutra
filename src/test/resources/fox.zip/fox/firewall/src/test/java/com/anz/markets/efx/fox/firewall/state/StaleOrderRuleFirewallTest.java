package com.anz.markets.efx.fox.firewall.state;

import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.firewall.FirewallTestContext;
import com.anz.markets.efx.fox.firewall.TestOrderFactory;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.rule.StaleOrderRule;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Tests for stale order rule in CustomRuleFirewall
 */
@RunWith(Spockito.class)
public class StaleOrderRuleFirewallTest {

    private static final String NAME = "NAME";
    private static final long TIMEOUT = 1000;

    private final static String[] USERS = new String[] {
            "| userName | desk   |",
            "|==========|========|",
            "| anufriea | Some   |",
            "| marsdenj | Some   |",
            "|----------|--------|"
    };


    @org.junit.Test
    @Spockito.Unroll({
            "| timeNanos        | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | lastUsdQty | markets   | result    |",
            "|==================|========|================|===========|==========|==============|=======|========|==========|============|===========|===========|",
            "| 1497338461000000 | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | true      |",
            "| 1497339461000000 | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | true      |",
            "| 1497339461000001 | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | false     |",
            "| 2497337461000000 | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | false     |",
    })
    public void stale_order_rule_firewall(final long timeNanos,
                                     final  String region,
                                     final  String targetStrategy,
                                     final  String portfolio,
                                     final  String username,
                                     final SecurityType securityType,
                                     final Tenor tenor,
                                     final  String symbol,
                                     final  double orderQty,
                                     final double lastUsdQty,
                                     final  String markets,
                                     final  boolean result
    ) {

        final String[] rules = new String[] {
                "| firewallName   | ruleId   | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period   | periodUnit    | local    | comment  | lastEditUsername | lastEditTime  | limitThreshold |",
                "|================|==========|===============|==================|=============|==================|=================|==============|=====================|==============|===============|==========|===============|==========|==========|==================|===============|================|",
        };

        String[] appliedExecutionReports = new String[] {
                "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | lastUsdQty | markets   | execType  | leavesQty  |",
                "|=============|========|================|===========|==========|==============|=======|========|==========|============|===========|===========|============|",
        };

        final InstrumentRepository instrumentRepository = mock(InstrumentRepository.class);
        final Instrument instrument = mock(Instrument.class);
        when(instrument.usdValue(orderQty)).thenReturn(lastUsdQty);

        final long instrumentId = InstrumentKey.instrumentId(symbol, securityType, tenor);
        when(instrumentRepository.lookup(instrumentId)).thenReturn(instrument);

        StaleOrderRule rule = new StaleOrderRule(TIMEOUT);

        final FirewallTestContext testContext = new FirewallTestContext((name, userRepository, errorHandler) ->
                Firewall.customRules(NAME, errorHandler, rule), "firewall1", rules, appliedExecutionReports, USERS);

        final TestOrderFactory.OrderStub orderStub = new TestOrderFactory.OrderStub(timeNanos, region, targetStrategy,
                portfolio, username, securityType, tenor, symbol, orderQty, markets);

        testContext.precisionClock.accept(timeNanos);

        final NewOrderSingleDecoder newOrderSingle = testContext.testOrderFactory.createOrder(orderStub);
        if (!result) {
            doAnswer((i) -> {
                assertThat(((StaleOrderRule)i.getArgument(2)).description().contains("Stale Order Firewall")).isTrue();
                return null;
            }).when(testContext.getErrorHandler()).accept(any(), any(), any());
        }
        assertThat(testContext.firewall.accept(newOrderSingle, testContext.commandContext)).isEqualTo(result);
    }
}
