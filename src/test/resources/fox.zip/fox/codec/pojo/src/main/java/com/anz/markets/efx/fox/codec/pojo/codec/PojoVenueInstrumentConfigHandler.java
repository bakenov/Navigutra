package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoVenueInstrumentConfigHandler implements VenueInstrumentConfigHandler {

    private final Consumer<? super VenueInstrumentConfig> messageConsumer;

    private VenueInstrumentConfig message = SorMessage.venueInstrumentConfig();

    public VenueInstrumentConfig message() {
        return message;
    }

    public PojoVenueInstrumentConfigHandler() {
        this(msg -> {});
    }

    public PojoVenueInstrumentConfigHandler(final Consumer<? super VenueInstrumentConfig> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.venueInstrumentConfig();
    }

    @Override
    public void onBody(final Body body) {
        message.body.venue = body.venue();
        message.body.instrumentId = body.instrumentId();
        message.body.priceIncrement = body.priceIncrement();
        message.body.sizeIncrement = body.sizeIncrement();
        message.body.clipSizeMultiple = body.clipSizeMultiple();
        message.body.maxAllowedParentOrderQty = body.maxAllowedParentOrderQty();
        message.body.minClipSize = body.minClipSize();
        message.body.maxClipSize = body.maxClipSize();
        message.body.staleDataTimeout = body.staleDataTimeout();
        message.body.priority = body.priority();
        message.body.proportion = body.proportion();
        message.body.enabled = body.enabled();
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
