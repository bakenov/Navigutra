package com.anz.markets.efx.fox.codec.api;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface FirewallConfigHandler  extends MessageDecoder.Handler {
    @Override
    default void onMessageStart(int source, long sourceSeq) {
    }

    void onBody(FirewallConfigHandler.Body body);

    @Override
    default void  onMessageComplete() {
    }

    interface Body {
        StringDecoder firewallName();
        long ruleId();
        StringDecoder regionPattern();
        StringDecoder orderTypePattern();
        StringDecoder deskPattern();
        StringDecoder portfolioPattern();
        StringDecoder usernamePattern();
        StringDecoder venuePattern();
        StringDecoder securityTypePattern();
        StringDecoder tenorPattern();
        StringDecoder symbolPattern();
        long period();
        StringDecoder periodUnit();
        boolean local();
        StringDecoder comment();
        StringDecoder lastEditUsername();
        long lastEditTime();
        double limitThreshold();
    }

    @FunctionalInterface
    interface DecoderFactory<M> extends MessageDecoder.Factory<M, FirewallConfigHandler>, SorDecoders.DecoderFactory<M> {
        @Override
        default MessageDecoder<M> create(final SorHandlerSupplier sorHandlerSupplier, final MessageDecoder.ForwardingLookup<M> forwardingLookup) {
            return create((Supplier<FirewallConfigHandler>) sorHandlerSupplier::firewallConfigHandler, forwardingLookup);
        }
    }
}
