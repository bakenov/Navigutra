package com.anz.markets.efx.fox.processor.command;

import com.anz.markets.efx.fox.processor.state.ParentExecutionReportPublisher;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class FirewallErrorHandler implements OrderConsumer.ErrorHandler {
    @Override
    public void accept(final NewOrderSingleDecoder newOrderSingle, final CommandContext commandContext, final Rule rule) {
        ParentExecutionReportPublisher.rejectedExecReport(commandContext, newOrderSingle, rule.description());
    }
}
