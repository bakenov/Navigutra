package com.anz.markets.efx.fox.receiver.pricing;

import java.util.Objects;
import java.util.function.LongFunction;

import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.fox.common.pricing.PricingRefresher;

public class MultipleInstrumentPricingRefresher implements PricingRefresher {
    private final Long2ObjectHashMap<Long[]> drivingInstrumentIdsMap;
    private final LongFunction<Long[]> drivingInstrumentIdsFactory;
    private final PricingRefresher pricingRefreshCompleter;
    private final PricingRefresher pricingRefresherWithCompleter;


    public MultipleInstrumentPricingRefresher(final PricingRefresher pricingRefresher,
                                              final PricingRefresher pricingRefreshCompleter,
                                              final LongFunction<Long[]> drivingInstrumentIdsFactory) {
        this.drivingInstrumentIdsFactory = Objects.requireNonNull(drivingInstrumentIdsFactory);
        this.pricingRefreshCompleter = Objects.requireNonNull(pricingRefreshCompleter);
        this.pricingRefresherWithCompleter = pricingRefresher.thenIfDoneOrForced(pricingRefreshCompleter);

        this.drivingInstrumentIdsMap = new Long2ObjectHashMap<>();
    }

    @Override
    public boolean refresh(final long instrumentId, final boolean forceSnapshot) {
        final Long[] drivingInstrumentIds = drivingInstrumentIdsMap.computeIfAbsent(instrumentId, drivingInstrumentIdsFactory);
        boolean drivingInstrumentsRefreshed = false;
        for (Long drivingInstrumentId : drivingInstrumentIds) {
            drivingInstrumentsRefreshed |= pricingRefresherWithCompleter.refresh(drivingInstrumentId, forceSnapshot);
        }
        final boolean instrumentRefreshed = pricingRefresherWithCompleter.refresh(instrumentId, forceSnapshot);
        if (!instrumentRefreshed && drivingInstrumentsRefreshed) {
            return pricingRefreshCompleter.refresh(instrumentId, forceSnapshot);
        }
        return instrumentRefreshed || drivingInstrumentsRefreshed;
    }
}
