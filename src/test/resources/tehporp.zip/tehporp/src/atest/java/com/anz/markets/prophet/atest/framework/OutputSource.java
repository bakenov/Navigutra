package com.anz.markets.prophet.atest.framework;

public enum OutputSource {
    STAR_IN(-1),
    CORE(0),
    CORE_PRICER(0),
    CORE_CROSS(0),
    CORE_HEDGER(1),
    STAR_OUT(2);

    // Output with higher value gets least priority when list of output is sorted
    private final int priority;

    OutputSource(final int priority) {
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }
}
