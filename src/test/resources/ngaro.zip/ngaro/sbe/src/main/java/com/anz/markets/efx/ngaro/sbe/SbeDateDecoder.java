package com.anz.markets.efx.ngaro.sbe;

import java.time.LocalDate;

import com.anz.markets.efx.ngaro.codec.DateDecoder;
import com.anz.markets.efx.ngaro.codec.FormattedDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

/**
 * Decoder for local date in a fixed length string.
 * <p/>
 * This class thread safe. NOTE however that the {@link FixedStringSource} passed to the constructor may not be thread
 * safe and hence this decoder instance may also not be thread safe.
 */
public final class SbeDateDecoder implements DateDecoder {

    private final FormattedDateDecoder<FixedStringSource> delegate;

    public SbeDateDecoder(final FixedStringSource source, final LocalDateFormat localDateFormat) {
        this.delegate = FormattedDateDecoder.forSourceAndFormat(source, FixedStringSource.BYTE_READER, localDateFormat);
    }
    public SbeDateDecoder(final FixedStringSource source, final LocalDateDecoder localDateDecoder) {
        this.delegate = FormattedDateDecoder.forSourceAndEncoder(source, FixedStringSource.BYTE_READER, localDateDecoder);
    }

    public LocalDate decodeLocalDateOrNull() {
        return delegate.decodeLocalDateOrNull();
    }

    public long decodeEpochMillis() {
        return delegate.decodeEpochMillis();
    }

    public long decodeEpochSeconds() {
        return delegate.decodeEpochSeconds();
    }

    public long decodeEpochDays() {
        return delegate.decodeEpochDays();
    }

    public int decodeYear() {
        return delegate.decodeYear();
    }

    public int decodeMonth() {
        return delegate.decodeMonth();
    }

    public int decodeDay() {
        return delegate.decodeDay();
    }
}