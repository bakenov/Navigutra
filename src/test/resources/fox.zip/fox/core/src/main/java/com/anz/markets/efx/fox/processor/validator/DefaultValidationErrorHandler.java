package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.ParentExecutionReportPublisher;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class DefaultValidationErrorHandler implements ParentOrderValidator.ErrorHandler {

    @Override
    public void onError(final String errorMessage,
                        final NewOrderSingleDecoder parentOrderDecoder,
                        final CommandContext commandContext) {
        // Just reject execution report
        ParentExecutionReportPublisher.rejectedExecReport(commandContext, parentOrderDecoder, errorMessage);
    }
}
