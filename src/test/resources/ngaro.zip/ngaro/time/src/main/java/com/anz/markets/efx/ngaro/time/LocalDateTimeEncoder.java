package com.anz.markets.efx.ngaro.time;

import java.time.LocalDateTime;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteWriter;

/**
 * Encoder for local date/time values with formats as defined by {@link LocalDateFormat} and {@link LocalTimeFormat}.
 * <br/>
 * All methods are zero garbage.
 * <p/>
 * This class is thread safe.
 *
 * @see LocalDateTimeDecoder
 */
public final class LocalDateTimeEncoder {

    public static final char DEFAULT_SEPARATOR = 'T';
    public static final char NO_SEPARATOR = Character.MAX_VALUE;

    private static Map<LocalDateFormat, Map<LocalTimeFormat, LocalDateTimeEncoder>> defaultEncoders = initDefaultEncoders();

    private final LocalDateEncoder dateEncoder;
    private final LocalTimeEncoder timeEncoder;
    private final char dateTimeSeparator;

    private LocalDateTimeEncoder(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat) {
        this(dateFormat.getDefaultEncoder(), timeFormat.getDefaultEncoder(), DEFAULT_SEPARATOR);
    }

    private LocalDateTimeEncoder(final LocalDateEncoder dateEncoder, final LocalTimeEncoder timeEncoder, final char dateTimeSeparator) {
        this.dateEncoder = Objects.requireNonNull(dateEncoder);
        this.timeEncoder = Objects.requireNonNull(timeEncoder);
        this.dateTimeSeparator = dateTimeSeparator;
        if (dateTimeSeparator > 127 && dateTimeSeparator != NO_SEPARATOR) {
            throw new IllegalArgumentException("Invalid date/time separator char: " + dateTimeSeparator);
        }
    }

    public static LocalDateTimeEncoder valueOf(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat) {
        return defaultEncoders.get(dateFormat).get(timeFormat);
    }

    public static LocalDateTimeEncoder valueOf(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat, final char dateTimeSeparator) {
        if (dateTimeSeparator == DEFAULT_SEPARATOR) {
            return valueOf(dateFormat, timeFormat);
        }
        return new LocalDateTimeEncoder(dateFormat.getDefaultEncoder(), timeFormat.getDefaultEncoder(), dateTimeSeparator);
    }

    public static LocalDateTimeEncoder valueOf(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat, final char dateTimeSeparator, final char dateDelimiter, final char timeDelimiter, final char fractionSymbol) {
        if (dateTimeSeparator == DEFAULT_SEPARATOR & dateDelimiter == LocalDateEncoder.DEFAULT_DELIMITER & timeDelimiter == LocalTimeEncoder.DEFAULT_DELIMITER & fractionSymbol == LocalTimeEncoder.DEFAULT_FRACTION_SYMBOL) {
            return valueOf(dateFormat, timeFormat);
        }
        return new LocalDateTimeEncoder(LocalDateEncoder.valueOf(dateFormat, dateDelimiter), LocalTimeEncoder.valueOf(timeFormat, timeDelimiter, fractionSymbol), dateTimeSeparator);
    }

    public static LocalDateTimeEncoder valueOf(final LocalDateEncoder dateEncoder, final LocalTimeEncoder timeEncoder) {
        return valueOf(dateEncoder, timeEncoder, DEFAULT_SEPARATOR);
    }

    public static LocalDateTimeEncoder valueOf(final LocalDateEncoder dateEncoder, final LocalTimeEncoder timeEncoder, final char dateTimeSeparator) {
        if (dateTimeSeparator == DEFAULT_SEPARATOR & dateEncoder == dateEncoder.getDateFormat().getDefaultEncoder() & timeEncoder == timeEncoder.getTimeFormat().getDefaultEncoder()) {
            return valueOf(dateEncoder.getDateFormat(), timeEncoder.getTimeFormat());
        }
        return new LocalDateTimeEncoder(dateEncoder, timeEncoder, dateTimeSeparator);
    }

    public LocalDateEncoder getDateEncoder() {
        return dateEncoder;
    }

    private LocalTimeEncoder getTimeEncoder() {
        return timeEncoder;
    }

    public LocalDateFormat getDateFormat() {
        return dateEncoder.getDateFormat();
    }

    public LocalTimeFormat getTimeFormat() {
        return timeEncoder.getTimeFormat();
    }

    public String getDateTimeFormatString() {
        return getDateFormat() + (dateTimeSeparator == NO_SEPARATOR ? "" : String.valueOf(dateTimeSeparator)) + getTimeFormat();
    }

    public char getDateTimeSeparator() {
        return dateTimeSeparator;
    }

    public int getTimeOffset() {
        return getDateFormat().getLength() + (dateTimeSeparator != NO_SEPARATOR ? 1 : 0);
    }

    public int getLength() {
        return getTimeOffset() + getTimeFormat().getLength();
    }

    public <T> void encodeEpochSeconds(final T target, final ByteWriter<? super T> writer, final long epochSeconds) {
        encodeEpochSeconds(target, writer, 0, epochSeconds);
    }
    public <T> void encodeEpochSeconds(final T target, final ByteWriter<? super T> writer, final int offset, final long epochSeconds) {
        dateEncoder.encodeEpochSeconds(target, writer, offset, epochSeconds);
        final int timeOffset = encodeDateTimeSeparatorAndReturnTimeOffset(target, writer, offset);
        timeEncoder.encodeEpochSeconds(target, writer, timeOffset, epochSeconds);
    }

    public <T> void encodeEpochMillis(final T target, final ByteWriter<? super T> writer, final long epochMillis) {
        encodeEpochMillis(target, writer, 0, epochMillis);
    }
    public <T> void encodeEpochMillis(final T target, final ByteWriter<? super T> writer, final int offset, final long epochMillis) {
        dateEncoder.encodeEpochMillis(target, writer, offset, epochMillis);
        final int timeOffset = encodeDateTimeSeparatorAndReturnTimeOffset(target, writer, offset);
        timeEncoder.encodeEpochMillis(target, writer, timeOffset, epochMillis);
    }

    public <T> void encodeEpochNanos(final T target, final ByteWriter<? super T> writer, final long epochNanos) {
        encodeEpochNanos(target, writer, 0, epochNanos);
    }
    public <T> void encodeEpochNanos(final T target, final ByteWriter<? super T> writer, final int offset, final long epochNanos) {
        dateEncoder.encodeEpochDays(target, writer, offset, Math.floorDiv(epochNanos, Epoch.NANOS_PER_DAY));
        final int timeOffset = encodeDateTimeSeparatorAndReturnTimeOffset(target, writer, offset);
        timeEncoder.encodeEpochNanos(target, writer, timeOffset, epochNanos);
    }

    public <T> void encode(final T target, final ByteWriter<? super T> writer, final LocalDateTime localDateTime) {
        encode(target, writer, 0, localDateTime);
    }
    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int offset, final LocalDateTime localDateTime) {
        if (localDateTime == null) {
            encodeNull(target, writer, offset);
        } else {
            encode(target, writer, offset,
                    localDateTime.getYear(), localDateTime.getMonthValue(), localDateTime.getDayOfMonth(),
                    localDateTime.getHour(), localDateTime.getMinute(), localDateTime.getSecond(), localDateTime.getNano());
        }
    }

    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int year, final int month, final int day, final int hour, final int minute, final int second) {
        encode(target, writer, year, month, day, hour, minute, second, 0);
    }
    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int year, final int month, final int day, final int hour, final int minute, final int second, final int nano) {
        encode(target, writer, 0, year, month, day, hour, minute, second, nano);
    }
    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int offset, final int year, final int month, final int day, final int hour, final int minute, final int second, final int nano) {
        dateEncoder.encode(target, writer, offset, year, month, day);
        final int timeOffset = encodeDateTimeSeparatorAndReturnTimeOffset(target, writer, offset);
        timeEncoder.encode(target, writer, timeOffset, hour, minute, second, nano);
    }

    public <T> void encodeNull(final T target, final ByteWriter<? super T> writer) {
        encodeNull(target, writer, 0);
    }
    public <T> void encodeNull(final T target, final ByteWriter<? super T> writer, final int offset) {
        dateEncoder.encodeNull(target, writer, offset);
        final int timeOffset = encodeDateTimeSeparatorAndReturnTimeOffset(target, writer, offset);
        timeEncoder.encodeNull(target, writer, timeOffset);
    }


    public <T> void encodeDateTimeSeparator(final T target, final ByteWriter<? super T> writer) {
        encodeDateTimeSeparator(target, writer, 0);
    }
    public <T> void encodeDateTimeSeparator(final T target, final ByteWriter<? super T> writer, final int offset) {
        encodeDateTimeSeparatorAndReturnTimeOffset(target, writer, offset);
    }

    private <T> int encodeDateTimeSeparatorAndReturnTimeOffset(final T target, final ByteWriter<? super T> writer, final int offset) {
        if (dateTimeSeparator != NO_SEPARATOR) {
            final int separatorOffset = offset + getDateFormat().getLength();
            writer.writeByte(target, separatorOffset, (byte) dateTimeSeparator);
            return separatorOffset + 1;
        } else {
            return offset + getDateFormat().getLength();
        }
    }


    private static Map<LocalDateFormat, Map<LocalTimeFormat, LocalDateTimeEncoder>> initDefaultEncoders() {
        final Map<LocalDateFormat, Map<LocalTimeFormat, LocalDateTimeEncoder>> map = new EnumMap<>(LocalDateFormat.class);
        LocalDateFormat.forEach(df -> {
            final Map<LocalTimeFormat, LocalDateTimeEncoder> timeFormatMap = new EnumMap<>(LocalTimeFormat.class);
            map.put(df, timeFormatMap);
            LocalTimeFormat.forEach(tf -> timeFormatMap.put(tf, new LocalDateTimeEncoder(df, tf)));
        });
        return map;
    }
}
