#!/bin/bash

#Correlator
ssh AxlSv@daxa004z "find ~/logs -type f -delete"
ssh AxlSv@daxa021z "find ~/logs -type f -delete"
ssh AxlSv@daxa029z "find ~/logs -type f -delete"


#Proxy broker
ssh AxlSv@daxa004z "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
ssh AxlSv@daxa021z "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
ssh AxlSv@daxa029z "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
