package com.anz.markets.efx.fox.codec.pojo.model;

import com.anz.markets.efx.ngaro.codec.Header;

public class MessageHeader implements Header {
    public int source;
    public long sourceSeq;

    public MessageHeader() {
    }

    public MessageHeader(final int source, final long sourceSeq) {
        this.source = source;
        this.sourceSeq = sourceSeq;
    }

    @Override
    public int source() {
        return this.source;
    }

    @Override
    public long sourceSeq() {
        return this.sourceSeq;
    }

    @Override
    public String toString() {
        return "Header{" +
                "source=" + source +
                ", sourceSeq=" + sourceSeq +
                '}';
    }
}
