// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

/**
 * A simple "do nothing" MessageFlowListener for command-line scripts.
 * 
 * @see FIXClientApplication
 */
public class ScriptMessageFlowListener implements IMessageFlowListener
{

    /**
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#messageReceived(com.thomsonreuters.trfx.referenceclients.fixclient.QuickFixSessionMessage)
     */
    public void messageReceived(final QuickFixSessionMessage message)
    {
        // Do nothing - not required for scripts mode
    }

    /**
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener
     *      #messageSent(com.thomsonreuters.trfx.referenceclients.fixclient.
     *      QuickFixSessionMessage)
     */
    public void messageSent(final QuickFixSessionMessage message)
    {
        // Do nothing - not required for scripts mode
    }

    /**
     * Logs the specified text/exception to stdout.
     * 
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener
     *      #logStatusText(java.lang.String)
     */
    public void logStatusText(final String statusText)
    {
        System.out.println(statusText);
    }

    /**
     * Logs the specified text/exception to stderr.
     * 
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#logError(java.lang.String,
     *      java.lang.Exception)
     */
    public void logError(final String errorText, final Exception exception)
    {
        System.err.println(errorText);
        if (exception != null)
        {
            System.err.print(exception.getMessage());
        }
    }

    /**
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener
     *      #stop()
     */
    public void stop()
    {
        // Do nothing - not required for scripts mode
    }

}
