package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.pricer.pfp.features.AdaptiveSkewFeatureSpecs;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Ignore("NOP skew has been removed")
@RestartBeforeTest(reason = "op cached")
public class Net_Open_Position_Risk_Skew extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration() {

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        // activeUSD is NaN so dynamic skewing is disabled
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, Double.NaN,
                specs.PARAM_MAX_SKEW_POSITION_USD, 7_500_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 1.0d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.25d,
                specs.PARAM_RR_INTERVAL_MS, 1_000L,
                specs.PARAM_RR_TARGET, 1_000_000d,
                specs.PARAM_SKEW_STEP_PIPS, 0.2d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 2_000L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 3_000L)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, Double.NaN,
                specs.PARAM_MAX_SKEW_POSITION_USD, Double.NaN,
                specs.PARAM_MIN_SKEW_FACTOR, Double.NaN,
                specs.PARAM_HIT_FRACTION, Double.NaN,
                specs.PARAM_HIT_STEP_FRACTION, Double.NaN,
                specs.PARAM_RR_INTERVAL_MS, 0L,
                specs.PARAM_RR_TARGET, Double.NaN,
                specs.PARAM_SKEW_STEP_PIPS, Double.NaN,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 0L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 0L)
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, false))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 1.0))  // set high Overall-skew threshold
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.38, 0.4),
                        new NetOpenPositionSkewRatioConfigImpl(0.50, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(8_500_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ));

        configuration.getPriceFormationPipelineConfigs().replaceAll(priceFormationPipelineConfig);

        return configuration;
    }


    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_3, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Apply Risk Position Skew on SHORT Optimal Position")
    public void apply_risk_position_skew_on_short_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration()
                            .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4))
                            , false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000_000, 103.875));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -10_000, 77.875));
        }
        then:
        {
            // Risk skew monitors equiv position
            OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(4), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(indirectPair, -5000000.0, -4765810.928569259, -3579124.0073555135, -6730902.96748313, -5054908.128579831, -0.1217002371560104, 0.75100)));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(directPair, -4774729.241877257, -4312801.5929432735, -4312801.5929432735, -4076756.4875139445, -4076756.4875139445, -0.04139732691453079, 103.875)));
            assertThat(optimalPositionsUpdates, isOptimalPosition(tdd.optimalPosition(crossPair, -85576.92307692308, -85576.92307692308, -94134.61538461539, -51960.912519316254, -57157.00377124788, -0.0011716434580605253, 9.1)));

            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3755000.0));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(-1000000.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), is(4774729.241877257));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(-11_000.0));

            assertThat(positionsUpdates.get(2).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(2).getPosition2().getPositionInSystemBase(), is(94134.61538461539));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Sum|PositionInSystemBase|  = 8634863.85726187239, USD NOP Limit = 20 mio, ratio = 0.43 => skew = 0.4 * (base spread 0.3)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.8712));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // AUD/USD SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Sum|PositionInSystemBase| = 8634863.85726187239, AUD NOP Limit = 22_806_762, ratio = 0.379 => skew = 0!
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75105));

            // AUDJPY cross generated from skewed drivers
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDJPY)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(78.0124648));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.1050, 0.003));
        }
        then:
        // EUR/NOK SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Sum|PositionInSystemBase| = 8634863.85726187239, EUR NOP Limit = 8.5 mio,  ratio = 1.016 => MAX skew of 0.3 * (base spread 40)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.1062));
        }
        and:
        {
            verify_pause_skewing();
        }
    }

    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1142})
    @DisplayName("AXPROPHET-1142 Pause MID SKEWING")
    public void verify_pause_skewing() {
        when:
        {
            // Pause skewing enabled on TERMS ccy on a driver CROSS
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setSkewingPause(Currency.NOK, true));
        }
        then:
        // EUR/NOK mid NOT SKEWED
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.1050));
        }
        when:
        // Pause Skewing on Driver pair also triggers new cross pair formation
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setSkewingPause(Currency.JPY, true));
        }
        then:
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.8700));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDJPY)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(78.0115635));
        }
        when:
        // After skewing pause expires on driver pair, should trigger new cross pair formation
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(4_000);
        }
        then:
        {
            prophet.expect(SkewCurrencyControl.class, isSkewCcyPaused(Currency.JPY, false));

            // Skewed USDJPY MID
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.8712));
            // AUDJPY cross generated from skewed drivers
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrument(Instrument.AUDJPY)).getLast();
            assertThat(clientPrice.getMidRate(), isRoundedTo(78.0124648));
        }
        when:
        // Global skew pause
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setSkewingPause(Currency.ANY, true));
        }
        then:
        {
            WholesaleBookFactors wbfCross = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wbfCross.getSkewedMidPrice(), new IsRoundedTo(9.1050));
            WholesaleBookFactors wbfDirect = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wbfDirect.getSkewedMidPrice(), new IsRoundedTo(103.8700));
        }
        and:
        // clean up!
        {
            prophet.receive(tdd.setSkewingPause(Currency.ANY, false));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_3, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Apply Risk Position Skew on LONG Optimal Position")
    public void apply_risk_position_skew_on_long_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0
            prophet.clearOutputBuffer();

            // send client deal to generate optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_500_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, 1_000_000, 103.875));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 10_000, 73.875));
        }

        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(3), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.get(2), isOptimalPosition(tdd.optimalPosition(indirectPair, 5500000.0, 5248596.85699272, 3941696.2396015325, 7427653.05612152, 5578167.445147261, 0.1225440536138196, 0.75100)));
            assertThat(optimalPositionsUpdates.get(2), isOptimalPosition(tdd.optimalPosition(directPair, 5152202.166064982, 4642434.075773014, 4642434.075773014, 4376886.55361051, 4376886.55361051, 0.04074299733549478, 103.875)));
            assertThat(optimalPositionsUpdates.get(2), isOptimalPosition(tdd.optimalPosition(crossPair, 81181.31868131868, 81181.31868131868, 89299.45054945056, 48835.12772124555, 53718.64049337011, 2.541116217497217E-4, 9.1)));

            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(4130500.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), is(-5152202.166064982));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(11_000.0));

            assertThat(positionsUpdates.get(2).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(2).getPosition2().getPositionInSystemBase(), is(-89299.45054945056));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }

        then:
        // USD/JPY LONG optimal position.  Apply -ve skew to improve OFFER(client buy)
        {
            // Sum|PositionInSystemBase| = 9383001.61661443256, USD NOP Limit = 20 mio, ratio = 0.469 => skew = 0.4 * (base spread 0.3)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.8688));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }

        then:
        {
            // Sum|PositionInSystemBase| = 9383001.61661443256, AUD NOP Limit = 22_806_762, ratio = 0.411 => skew = 0.4 * (base spread 0.3)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.751038));

            prophet.clearOutputBuffer();

        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.105, 0.003));
        }

        then:
        // EUR/NOK LONG optimal position.  Apply -ve skew to improve OFFER(client buy)
        {
            // Sum|PositionInSystemBase| = 9383001.61661443256, EUR NOP Limit = 8.5 mio,  ratio = 1.003 => MAX skew of 0.3 * (base spread 40)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.1038));
        }
    }

    @Test
    public void apply_risk_position_skew_on_tz_change() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000_000, 103.875));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -10_000, 77.875));
        }

        then:
        {
            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3755000.0));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(-1000000.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), is(4774729.241877257));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(-11_000.0));

            assertThat(positionsUpdates.get(2).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(2).getPosition2().getPositionInSystemBase(), is(94134.61538461539));

            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Sum|PositionInSystemBase|  = 8634863.85726187239, USD NOP Limit = 20 mio, ratio = 0.43 => skew = 0.4 * (base spread 0.3)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.8712));
        }
        when:
        // tz change resulting in a different base spread
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.SNG); // base spread = 0.5
        }
        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            // Sum|PositionInSystemBase|  = 8634863.85726187239, USD NOP Limit = 20 mio, ratio = 0.43 => skew = 0.4 * (base spread 0.5)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.872));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void apply_skew_given_biased_positions() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000_000, 103.875));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -10_000, 77.875));
        }

        then:
        {
            // NOP: Sum the absolute usd equiv positions(ignoring USD)
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3755000.0));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(-1000000.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), is(4774729.241877257));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(-11_000.0));

            assertThat(positionsUpdates.get(2).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(2).getPosition2().getPositionInSystemBase(), is(94134.61538461539));

            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.biasPosition(Currency.AUD, 3_000_000));
        }
        then:
        // AUD biased position updated
        {
            Positions biasedPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(biasedPosition.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(biasedPosition.getPosition1().getPositionInNotional(), is(-5_000_000.0 - (3_000_000)));
            assertThat(biasedPosition.getPosition1().getPositionInSystemBase(), is(-8_000_000 * 0.751)); // 6008000

            // USD/JPY still SHORT optimal position
            final OptimalPositions biasOptimalPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition op = biasOptimalPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == Instrument.USDJPY).findFirst().get();
            assertThat(op.getPositionInSystemBase() < 0, is(true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // Since USD/JPY SHORT optimal position Apply +ve skew to improve BID(client sell)
        {
            // Sum|BiasedPositionInSystemBase|  = 10986864, USD NOP Limit = 20 mio, ratio = 0.55 => skew = 0.2 * (base spread 0.3p)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.8706));
        }
        when:
        // tz change resulting in a different base spread
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.SNG); // base spread = 0.5
        }
        then:
        // Since USD/JPY SHORT optimal position Apply +ve skew to improve BID(client sell)
        {
            // Sum|BiasedPositionInSystemBase|  = 10986864, USD NOP Limit = 20 mio, ratio = 0.55 => skew = 0.2 * (base spread 0.5p)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.871));
        }
    }
}
