package com.anz.axle.lg.adapter.acceptance.utils;

import java.util.Objects;

import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.fixspec.FixSpecification;
import org.fix4j.test.integration.FixEngineSession;
import org.fix4j.test.integration.FixEngineSessionFactory;
import org.fix4j.test.integration.quickfix.QuickFixApplication;
import org.fix4j.test.integration.quickfix.QuickFixProperties;
import org.fix4j.test.integration.quickfix.QuickFixSessionIdConverter;
import org.fix4j.test.integration.quickfix.QuickFixTestSession;
import org.fix4j.test.plumbing.Consumer;
import org.fix4j.test.properties.ApplicationProperties;
import org.fix4j.test.session.FixConnectionMode;
import org.fix4j.test.session.FixSessionId;

import quickfix.Connector;
import quickfix.DefaultMessageFactory;
import quickfix.MemoryStoreFactory;
import quickfix.ScreenLogFactory;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketAcceptor;
import quickfix.SocketInitiator;

public class FixAssertQuickFixSessionFactory implements FixEngineSessionFactory {
    private final FixSpecification fixSpecification;

    public FixAssertQuickFixSessionFactory(final FixSpecification fixSpecification) {
        this.fixSpecification = Objects.requireNonNull(fixSpecification);
    }

    public FixEngineSession createSession(final FixSessionId sessionId, final FixConnectionMode fixConnectionMode, final Consumer<FixMessage> toTestClient) {
        QuickFixApplication app = new QuickFixApplication();
        SessionID quickfixSessionId = (new QuickFixSessionIdConverter()).fromFixSessionId(sessionId);
        Connector connector = this.create(quickfixSessionId, app, fixConnectionMode);
        return new QuickFixTestSession(toTestClient, quickfixSessionId, app, this.fixSpecification, connector);
    }

    private Connector create(final SessionID quickfixSessionId, final QuickFixApplication app, final FixConnectionMode fixConnectionMode) {
        try {
            final ApplicationProperties properties = ApplicationProperties.Singleton.instance();
            SessionSettings settings = new SessionSettings();
            settings.setString("ConnectionType", fixConnectionMode == FixConnectionMode.INITIATOR ? "initiator" : "acceptor");
            settings.setString("SenderCompID", quickfixSessionId.getSenderCompID());
            settings.setString("TargetCompID", quickfixSessionId.getTargetCompID());
            settings.setString("SocketConnectHost", properties.getAsString(QuickFixProperties.SOCKET_CONNECT_HOST, "localhost"));
            settings.setString("StartTime", properties.getAsString(QuickFixProperties.START_TIME, "00:00:00"));
            settings.setString("EndTime", properties.getAsString(QuickFixProperties.END_TIME, "00:00:00"));
            settings.setString("HeartBtInt", properties.getAsString(QuickFixProperties.HEART_BEAT_INTERVAL, "10"));
            settings.setString("BeginString", quickfixSessionId.getBeginString());
            settings.setString("ReconnectInterval", properties.getAsString(QuickFixProperties.RECONNECT_INTERVAL, "5"));
            settings.setString("UseDataDictionary", properties.getAsString(QuickFixProperties.USE_DATA_DICTIONARY, "Y"));
            settings.setString("DataDictionary", properties.getAsString("fix4j.quickfix.data.dictionary", ""));
            settings.setString("AllowUnknownMsgFields", properties.getAsString(QuickFixProperties.ALLOW_UNKNOWN_MSG_FIELDS, "Y"));
            settings.setString("ValidateFieldsOutOfOrder", properties.getAsString(QuickFixProperties.VALIDATE_FIELDS_OUT_OF_ORDER, "N"));
            settings.setString("ValidateFieldsHaveValues", properties.getAsString(QuickFixProperties.VALIDATE_FIELDS_HAVE_VALUES, "N"));
            settings.setString("ValidateUserDefinedFields", properties.getAsString(QuickFixProperties.VALIDATE_USER_DEFINED_FIELDS, "N"));
            settings.setString("ValidateUnorderedGroupFields", properties.getAsString("fix4j.quickfix.validate.unordered.group.fields", "Y"));

            if (fixConnectionMode == FixConnectionMode.INITIATOR) {
                settings.setString(quickfixSessionId, "SocketConnectPort", properties.getAsString(QuickFixProperties.SOCKET_CONNECT_PORT, "9880"));
            } else {
                settings.setString(quickfixSessionId, "SocketAcceptPort", properties.getAsString(QuickFixProperties.SOCKET_ACCEPT_PORT, "9880"));
            }

            boolean logHeartbeats = properties.getAsBoolean(QuickFixProperties.LOG_HEARTBEATS, true);
            final MemoryStoreFactory messageStoreFactory = new MemoryStoreFactory();
            final ScreenLogFactory logFactory = new ScreenLogFactory(true, true, true, logHeartbeats);
            final DefaultMessageFactory messageFactory = new DefaultMessageFactory();
            final Connector connector;
            if (fixConnectionMode == FixConnectionMode.INITIATOR) {
                connector = new SocketInitiator(app, messageStoreFactory, settings, logFactory, messageFactory);
            } else {
                connector = new SocketAcceptor(app, messageStoreFactory, settings, logFactory, messageFactory);
            }

            return connector;
        } catch (Exception var11) {
            throw new RuntimeException(var11);
        }
    }
}
