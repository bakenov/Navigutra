package com.anz.markets.efx.fox.receiver;

import java.io.InputStream;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallsConfig;

public class FirewallConfigLoader implements Runnable {
    private final FirewallsConfig firewallsConfig;
    private final SorEncoderSupplier encoderSupplier;

    public FirewallConfigLoader(final String fileName, final SorEncoderSupplier encoderSupplier) {
        final InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(Objects.requireNonNull(fileName));
        this.firewallsConfig = FirewallsConfig.yaml().load(inputStream);
        this.encoderSupplier = Objects.requireNonNull(encoderSupplier);
    }

    @Override
    public void run() {
        firewallsConfig.getFirewalls().forEach((categoryName, category) ->
                category.getFirewallTypeConfigs().forEach(firewallTypeConfig -> {
                    firewallTypeConfig.getConfiguredInstances().forEach(rule ->
                            encoderSupplier.firewallConfigEncoder().messageStart(0, 0)
                                    .firewallName().encode(firewallTypeConfig.getFirewallName())
                                    .ruleId(rule.getRuleId())
                                    .regionPattern().encode(rule.getRegionPattern())
                                    .orderTypePattern().encode(rule.getOrderTypePattern())
                                    .deskPattern().encode(rule.getDeskPattern())
                                    .portfolioPattern().encode(rule.getPortfolioPattern())
                                    .usernamePattern().encode(rule.getUsernamePattern())
                                    .venuePattern().encode(rule.getVenuePattern())
                                    .securityTypePattern().encode(rule.getSecurityTypePattern())
                                    .tenorPattern().encode(rule.getTenorPattern())
                                    .symbolPattern().encode(rule.getSymbolPattern())
                                    .period(rule.getPeriod())
                                    .periodUnit().encode(rule.getPeriodUnit())
                                    .local(rule.isLocal())
                                    .comment().encode(rule.getComment())
                                    .lastEditUsername().encode(rule.getLastEditUsername())
                                    .lastEditTime(rule.getLastEditTime().getTime())
                                    .limitThreshold(rule.getLimitThreshold())
                                    .messageComplete());
        }));
    }
}
