#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa005z "rm -rf ~/axle/datafabric/workspace/*"
ssh AxlSv@daxa020z "rm -rf ~/axle/datafabric/workspace/*"
ssh AxlSv@daxa002z "rm -rf ~/axle/datafabric/workspace/*"
