package com.anz.axle.lg.adapter.ebsu.config;

import com.anz.axle.lg.adapter.ebsu.SecurityInfoHolder;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementMessageNotifier;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementalMessageHandler;
import com.anz.axle.lg.adapter.ebsu.preview.PreviewMessageNotifier;
import com.anz.axle.lg.adapter.ebsu.trade.TradeMessageHandler;
import com.anz.axle.lg.adapter.fix.IncrementingNumberSupplier;
import com.anz.axle.lg.config.DefaultTopicRegistry;
import com.anz.axle.lg.config.SbeMessagePublisher;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.LongSupplier;

@Configuration
public class PricingConfig {
    private final String compId;
    private final String senderCompId;
    private final Venue venue;
    private final SecurityType securityType;

    public PricingConfig(@Value("${messaging.compId}") final String compId,
                         @Value("${messaging.senderCompId}") final String senderCompId,
                         @Value("${venue}") final Venue venue,
                         @Value("${securityType}") final SecurityType securityType) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
        this.securityType = Objects.requireNonNull(securityType);
    }

    @Bean
    public LongSupplier sequenceNumberSupplier() {
        // this was using an AtomicLong but as is only ever called on one thread...
        return new IncrementingNumberSupplier();
    }

    @Bean
    public TopicRegistry pricingTopicRegistry() {
        return new DefaultTopicRegistry();
    }

    @Bean
    public PricingEncoders<SbeMessage> sbePricingEncoders(@Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbePricingEncoders(() -> sbeMessage);
    }

    @Bean
    public Function<RequestKey, PricingEncoderSupplier> pricingEncoderLookup(final PricingEncoders<SbeMessage> sbePricingEncoders,
                                                                             final TopicRegistry pricingTopicRegistry,
                                                                             final MessageHandler publisher) {
        return requestKey -> PricingEncoderSupplier.create(sbePricingEncoders, SbeMessagePublisher.create(requestKey, pricingTopicRegistry, publisher));
    }

    @Bean
    public SecurityInfoHolder securityInfoHolder(
            final Function<RequestKey, PricingEncoderSupplier> pricingEncoderLookup,
            final @Value("#{${ebsu.symbol.mapping}}") Map<String, String> ebsuSymbolLookup) {
        return new SecurityInfoHolder(pricingEncoderLookup, venue, securityType, ebsuSymbolLookup);
    }

    @Bean
    public IncrementalMessageHandler incrementalMessageHandler(final SecurityInfoHolder securityInfoHolder,
                                                               final LongSupplier sequenceNumberSupplier,
                                                               final PrecisionClock precisionClock,
                                                               @Value("${encodeHops:false}") boolean encodeHops,
                                                               @Value("${dumpHistosEveryMillis:0}") int dumpHistosEveryMillis,
                                                               final SourceSequencer sourceSequencer) {
        return new IncrementalMessageHandler(securityInfoHolder, sequenceNumberSupplier, precisionClock, senderCompId, compId, venue, encodeHops, dumpHistosEveryMillis, sourceSequencer);
    }

    @Bean
    public TradeMessageHandler tradeMessageHandler(final SecurityInfoHolder securityInfoHolder,
                                                   final LongSupplier sequenceNumberSupplier,
                                                   final PrecisionClock precisionClock,
                                                   @Value("${encodeHops:false}") boolean encodeHops,
                                                   @Value("${dumpHistosEveryMillis:0}") int dumpHistosEveryMillis,
                                                   final SourceSequencer sourceSequencer) {
        return new TradeMessageHandler(securityInfoHolder, sequenceNumberSupplier, precisionClock, senderCompId, compId, venue, encodeHops, dumpHistosEveryMillis, sourceSequencer);
    }

    @Bean
    public IncrementMessageNotifier incrementMessageNotifier(final IncrementalMessageHandler incrementalMessageHandler,
                                                             final TradeMessageHandler tradeMessageHandler,
                                                             final PrecisionClock precisionClock) {
        return new IncrementMessageNotifier(incrementalMessageHandler, tradeMessageHandler, precisionClock);
    }

    @Bean
    public PreviewMessageNotifier previewMessageNotifier() {
        return new PreviewMessageNotifier();
    }
}
