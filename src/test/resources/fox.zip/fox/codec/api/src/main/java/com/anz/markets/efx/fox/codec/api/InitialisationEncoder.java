package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;

public interface InitialisationEncoder extends MessageEncoder<InitialisationEncoder.Body> {
    @Override
    Body messageStart(final int source, final long sourceSeq);

    interface Body {
        Trailer initStage(InitStage initStage);
    }
}
