package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceSpikeFirewallConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.LinkedList;

import static org.hamcrest.MatcherAssert.assertThat;

public class MultipleFirewallTriggeredTest extends BaseAcceptanceSpecification {

    /**
     Price pipeline is in this order:
     Wholesale price -> Firewalls -> CrossRateManager -> Throttler
     externalEventTimeNS for WSP_B/C is different to WSP_A because of the order in which Prophet does its processing...
     1.	Prophet receives a new piece of market data for EURDKK with externalEventTimeNS=1000750000000
     2.	Prophet calculates new wholesale price in a loop, starting with WSP_A
     a.	Price Barrier firewall is triggered for all DKK and publishes all DKK prices in its cache in a loop starting with EURDKK WSP_A
     i.	EURDKK WSP_A externalEventTimeNS=1000750000000 is published
     ii.	CrossRateManager triangulates USDDKK with externalEventTimeNS=1000750000000
     iii.EURDKK WSP_B externalEventTimeNS=1000000000000 from the FirewallManager’s cache is published – this is because the new wholesale
     price for WSP_B has not been recalculated yet from the market data in 1.
     **/

    /**
     * When both firewalls are triggered then you do not necessarily see both firewalls tagged on the ClientPrice
     * 1.	Prophet receives a new piece of market data for EURDKK with externalEventTimeNS=1000750000000
     * 2.	Price Spike firewall triggers for all and so publishes every price in the cache with pricingFirewallType=[PRICE_SPIKE]
     * 1.	All prices have now been republished by PriceSpike and so PriceBarrier is called for EURDKK WSP_A externalEventTimeNS=1000750000000.
     * PriceBarrier marks this ClientPrice as indicative but does not publish as it is already marked indicative by price spike
     * (and its logic is such that it only publishes on indicative change)
     * ==> However, after making change such that we publish on "list of Firewall types" change, the subsequent re-published client prices are
     * dropped by the throttler as mid is unchanged. Therefore the end result(of published client prices) is the same as before.
     * 2.	Wholesale price generation generates new price for WSP_B which is passed to...
     * 3.	Price Spike firewall which is already triggered so just marks the price as indicative...
     * 4.	And then price barrier which marks it as indicative and it is then published
     */

    @Test
    @Requirement(Ref.PRICING_4_7_8)
    @RelatedTest(PriceBarrierFirewallTest.class) // trigger_when_bid_over_ceiling(). Also PriceSpikeFirewallTest
    @DisplayName("Price Spike and Price Barrier Firewalls Triggered")
    public void priceSpikeAndPriceBarrierFirewallTest() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, true))
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 4, 750, 0.1, 0.02, 10000),
                            new PriceSpikeFirewallConfig(Instrument.EURDKK, 4, 750, 0.0001, 0.0002, 10))
                    );


            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48320, 0.00004));
        }

        then:
        {
            // No Firewalls triggered. All pairs FIRM
            ClientPrice clientPriceEURUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURUSD)).getFirst();
            assertThat(clientPriceEURUSD, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(750); // trigger Price Spike Firewall
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48536, 0.00004));
        }

        then:
        {
            // NOP FIREWALL TRIGGERED:
            // EUR/DKK BID price is GREATER then CEILING limit(7.4850). Firewall triggered on all DKK PAIRS
            //
            // GLOBAL Price Spike FIREWALL TRIGGERED:
            // (7.48520-7.48320)/7.48320 = 0.00027 > 0.0002  => firewall triggered on ALL pairs
            LinkedList<ClientPrice> clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK));
            assertThat(clientPriceEURDKK.getFirst(), isClientPricePoint(0, Level.QTY_1M, 7.48526, 7.48546));

            ClientPrice clientPriceEURDKKWSPA = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_A)).getFirst();
            checkFirewallTriggered(clientPriceEURDKKWSPA, PricingFirewallType.PRICE_SPIKE);

            // Since we start with WSP_A price generation when PriceSpike is triggered, the cached WSP_B and WSP_C are republished with firewall triggered
            LinkedList<ClientPrice> clientPriceEURDKKWSPB = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_B));
            checkFirewallTriggered(clientPriceEURDKKWSPB.get(0), PricingFirewallType.PRICE_SPIKE);

            LinkedList<ClientPrice> clientPriceEURDKKWSPC = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_C));
            checkFirewallTriggered(clientPriceEURDKKWSPC.get(0), PricingFirewallType.PRICE_SPIKE);
        }

        and:
        {   // Since we start with WSP_A price generation when PriceSpike is triggered, the cached WSP_B and WSP_C are republished with firewall PRICE SPIKE
            LinkedList<ClientPrice> clientPriceEURUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA));
            for (int i = 0; i < clientPriceEURUSD.size(); i++) {
                assertThat(clientPriceEURUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceEURUSD.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }

        and:
        {   // Since we start with WSP_A price generation when PriceSpike is triggered, USDDKK is only tagged with PRICE SPIKE
            LinkedList<ClientPrice> clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair));
            for (int i = 0; i < clientPriceUSDDKK.size(); i++) {
                assertThat(clientPriceUSDDKK.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceUSDDKK.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }

        and:
        {   // When WSP_B and WSP_C are next generated for EURDKK, they will be tagged with both FIREWALLS
            LinkedList<ClientPrice> clientPriceEURDKKWSPB = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_B));
            checkFirewallTriggered(clientPriceEURDKKWSPB.get(1), PricingFirewallType.PRICE_BARRIER, PricingFirewallType.PRICE_SPIKE);
            LinkedList<ClientPrice> clientPriceEURDKKWSPC = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_C));
            checkFirewallTriggered(clientPriceEURDKKWSPC.get(1), PricingFirewallType.PRICE_BARRIER, PricingFirewallType.PRICE_SPIKE);
        }
    }
}