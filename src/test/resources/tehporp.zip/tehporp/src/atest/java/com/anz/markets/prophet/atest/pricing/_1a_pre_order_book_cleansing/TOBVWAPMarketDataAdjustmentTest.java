package com.anz.markets.prophet.atest.pricing._1a_pre_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.marketdata.adjustment.TOBVWAPMarketDataAdjustment;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.anz.markets.prophet.domain.marketdata.impl.FilterDecision.PASS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1234})
public class TOBVWAPMarketDataAdjustmentTest extends BaseAcceptanceSpecification {
    /**
     *  AXPROPHET-1234:
     *  pre-orderbook adjustment per Market. Replace market orderbook with a new VWAP TOB price for each side.
     *  If not enough liquidity to perform VWAP, then clear that side.
     *  Does NOT apply to WSP_R book
     *  Occurs before Liquidity Filter logic.
     */
    private ConfigurationDataDefault setUpConfiguration(double vwapQty) {

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();

        // set up config for CNX ONLY
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(TOBVWAPMarketDataAdjustment.FEATURE_NAME,
                Market.CNX,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                TOBVWAPMarketDataAdjustment.FEATURE_PARAM_TARGET_TOB_VWAP_QTY, vwapQty)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(TOBVWAPMarketDataAdjustment.FEATURE_NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                TOBVWAPMarketDataAdjustment.FEATURE_PARAM_TARGET_TOB_VWAP_QTY, Double.NaN)
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
        configuration.getPriceFormationPipelineConfigs().replaceFeature(TOBVWAPMarketDataAdjustment.FEATURE_NAME,priceFormationPipelineConfig);

        return configuration;
    }


    @Test
    public void bidOfferTobContainsGreaterQty() {
        setup:
        {
            prophet.receive(setUpConfiguration(500_000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75024, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 4_000_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75050));
            assertThat(snapshot.getTopOfBookBid().getQuantity(), is(500_000d));
            assertThat(snapshot.getTopOfBookOffer().getQuantity(), is(500_000d));
        }
    }

    @Test
    public void bidOfferSideVWAP() {
        setup:
        {
            prophet.receive(setUpConfiguration(1_500_000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75027, 250_000),
                            new PriceAndQtyImpl(0.75026, 250_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 500_000),
                            new PriceAndQtyImpl(0.75053, 500_000),
                            new PriceAndQtyImpl(0.75055, 500_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.getTopOfBookBid().getPrice(), isRoundedTo(0.75028833));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), isRoundedTo(0.750526667));
            assertThat(snapshot.getTopOfBookBid().getQuantity(), is(1_500_000d));
            assertThat(snapshot.getTopOfBookOffer().getQuantity(), is(1_500_000d));
        }
        and:
        // no VWAP on WSP_R book
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_R)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.getTopOfBookBid().getPrice(), isRoundedTo(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), isRoundedTo(0.75050));
            assertThat(snapshot.getTopOfBookBid().getQuantity(), is(1_000_000d));
            assertThat(snapshot.getTopOfBookOffer().getQuantity(), is(500_000d));
        }
    }

    @Test
    public void notEnoughLiquidity() {
        setup:
        {
            prophet.receive(setUpConfiguration(2_000_000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75026, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000)),
                    tdd.now()));

            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75027, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75054, 1_000_000)),
                    tdd.now()));
        }
        then:
        // Since not enough CNX liquidity to perform VWAP on Bid side, CNX prices cleared on Bid Side
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(2), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) snapshot.getTopOfBookBid()).getMarket(), is(Market.DEUT));
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75027));
            assertThat(((MarketDataNewOrder) snapshot.getTopOfBookOffer()).getMarket(), is(Market.CNX));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.750525));

        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75026, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 900_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000)),
                    tdd.now()));
        }
        then:
        // Since not enough CNX liquidity to perform VWAP on Offer side, CNX prices cleared on Offer Side
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) snapshot.getTopOfBookBid()).getMarket(), is(Market.CNX));
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75028));
            assertThat(((MarketDataNewOrder) snapshot.getTopOfBookOffer()).getMarket(), is(Market.DEUT));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75054));

        }
    }

    @Test
    public void handleMultipleStackWithSamePrice() {
        setup:
        {
            prophet.receive(setUpConfiguration(2_000_000d));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75028, 500_000),
                            new PriceAndQtyImpl(0.75028, 500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75056, 500_000),
                            new PriceAndQtyImpl(0.75056, 500_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), isRoundedTo(0.75029));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), isRoundedTo(0.75053));
            assertThat(snapshot.getTopOfBookBid().getQuantity(), is(2_000_000d));
            assertThat(snapshot.getTopOfBookOffer().getQuantity(), is(2_000_000d));
        }
    }

    @Test
    public void noTOBNoWAP() {
        setup:
        {
            prophet.receive(setUpConfiguration(1_500_000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(-0.75030, 1_000_000),
                            new PriceAndQtyImpl(-0.75027, 250_000),
                            new PriceAndQtyImpl(-0.75026, 250_000)),
                    Arrays.asList(new PriceAndQtyImpl(-0.75050, 500_000),
                            new PriceAndQtyImpl(-0.75053, 500_000),
                            new PriceAndQtyImpl(-0.75055, 500_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.isEmpty(), is(true));
        }
    }


    @Test
    public void disabledViaConfig() {
        setup:
        {
            prophet.receive(setUpConfiguration(0d));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75026, 250_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 500_000),
                            new PriceAndQtyImpl(0.75055, 500_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), isRoundedTo(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), isRoundedTo(0.75050));
            assertThat(snapshot.getTopOfBookBid().getQuantity(), is(1_000_000d));
            assertThat(snapshot.getTopOfBookOffer().getQuantity(), is(500_000d));
        }
    }
}