package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import com.anz.axle.adapters.ndf2trep.enrichment.margin.MarginService;
import org.agrona.collections.Long2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.trep.publisher.TrepStreamableQueue;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;

public class TrepTopOfBookSnapshotFullRefreshHandler implements SnapshotFullRefreshHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrepTopOfBookSnapshotFullRefreshHandler.class);
    private final TrepStreamableQueue trepStreamableQueue;
    private final RicRepository ricRepository;
    private final MarginService marginService;
    private final TrepQuote.Builder trepQuoteBuilder;
    private String ricSubscribed = null;
    private final InstrumentCache instrumentCache = new InstrumentCache();
    private final InstrumentKey.Lookup instrumentKeyLookup = new DefaultInstrumentKeyLookup();

    public TrepTopOfBookSnapshotFullRefreshHandler(final TrepStreamableQueue trepStreamableQueue,
                                                   final RicRepository ricRepository,
                                                   final MarginService marginService) {
        this.trepStreamableQueue = Objects.requireNonNull(trepStreamableQueue);
        this.ricRepository = Objects.requireNonNull(ricRepository);
        this.marginService = Objects.requireNonNull(marginService);
        this.trepQuoteBuilder = new TrepQuote.Builder();
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        trepQuoteBuilder.reset();
        LOGGER.debug("onMessageStart");
    }

    @Override
    public void onBody(final Body body) {
        final InstrumentKey instrumentKey = instrumentKeyLookup.lookup(body.instrumentId());
        final Venue market = body.marketId();
        final String instrument = instrumentCache.lookup(market, body.instrumentId());
        final String serviceName = ricRepository.getServiceName();
        final String ricName = ricRepository.getRicName(instrument, instrumentKey.tenor().name());

        ricSubscribed = ricName;

        if (ricName != null) {
            trepQuoteBuilder.ricName(ricName);
            trepQuoteBuilder.serviceName(serviceName);
            final boolean isIndicative = body.mdFlags().containsAny();
            trepQuoteBuilder.isIndicative(isIndicative);
            LOGGER.debug("onBody: symbol={}, market={},  tenor={}, ricName={} isIndicative={}", instrumentKey.symbol(), market, instrumentKey.tenor(), ricName, isIndicative);
        }
        else {
            LOGGER.debug("onBody: Skipping un-subscribed instrument={} tenor={}", instrument, instrumentKey.tenor().name());
        }
    }

    @Override
    public void onMdEntries_Body(final MdEntries.Body entry, final int mdEntriesIndex, final int mdEntriesCount) {
        LOGGER.debug("onMdEntries_Body: {}, {}, {}, {}", mdEntriesIndex, mdEntriesCount, entry.mdEntryType(), entry.mdEntryPx());
        final boolean sideIndicative = entry.mdEntryFlags().containsAny();
        if (sideIndicative) { // override indicative state to true if any of the sides are indicative
            trepQuoteBuilder.isIndicative(sideIndicative);
        }
        double marginAppliedPrice = marginService.applyMargin(ricSubscribed, entry.mdEntryType(), entry.mdEntryPx());
        switch (entry.mdEntryType()) {
            case BID:
                trepQuoteBuilder.updateBid(marginAppliedPrice, entry.transactTime());
                break;
            case OFFER:
                trepQuoteBuilder.updateOffer(marginAppliedPrice, entry.transactTime());
                break;
        }
        LOGGER.debug("onMdEntries_Body: {}", trepQuoteBuilder.toString());
    }

    @Override
    public void onMessageComplete() {
        if (ricSubscribed != null) {
            final TrepQuote topOfBook = trepQuoteBuilder.build();
            trepStreamableQueue.enqueueItem(topOfBook);
            LOGGER.debug("onMessageComplete:enqueued topOfBook:" + topOfBook);
        }

        ricSubscribed = null;
        trepQuoteBuilder.reset();
    }

    protected static class InstrumentCache {
        private final Map<Venue, Long2ObjectHashMap<String>> cache = new EnumMap<>(Venue.class);

        public InstrumentCache() {
            Venue.forEach(venue -> cache.put(venue, new Long2ObjectHashMap<>()));
        }

        public String lookup(final Venue market, final long instrumentId) {
            if (instrumentId == 0 || market == null) {
                return null;
            }

            final Long2ObjectHashMap<String> byInstrumentId = cache.get(market);
            String instrument = byInstrumentId.get(instrumentId);

            if (instrument == null) {
                final InstrumentKey instrumentKey = InstrumentKey.of(instrumentId);
                instrument = instrumentKey.securityType().name() + "_" + market + "_" + instrumentKey.symbol();
                byInstrumentId.put(instrumentId, instrument);
            }
            return instrument;
        }
    }
}