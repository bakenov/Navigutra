package com.anz.axle.adapters.wssdeal.filter;

import anz.markets.canonical.model.v2.IdentifierType;
import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import com.anz.axle.common.filter.Filter;
import com.anz.axle.common.filter.FilterException;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * Created by talwarg on 24/02/2015.
 * <p/>
 * This filter will return true in case of XEFX trades.
 * <p/>
 * true - accept trades.
 * false - reject/filter out trades.
 */
public class NonXEFXFilter implements Filter<TradeMessageWrapperType> {
    private static final Logger LOG = Logger.getLogger(NonXEFXFilter.class);
    private String XEFX = "XEFX";
    private String AUTO = "AUTO";

    @Override
    public boolean accept(final TradeMessageWrapperType input) throws FilterException {
        try {
            // XEFXFilter removed
            return true;
        } catch (Exception e) {
            throw new FilterException("Not able to apply filter on trade message.", e);
        }
    }

    private boolean isSalesXEFXTrade(final TradeMessageWrapperType input) {
        return XEFX.equals(getPortfolio(input));
    }

    private boolean isInterbankMaxleXEFXTrade(final TradeMessageWrapperType input) {
        return AUTO.equals(getPortfolio(input));
    }

    private String getPortfolio(TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, "PARTY_1", "WSS_PORTFOLIO");
    }

    private String getPartyIdentifierValue(TradeMessageWrapperType tradeMessage,
                                           String party,
                                           String context) {
        final List<TradeMessageWrapperType.TradeParty> tradePartyList = tradeMessage.getTradeParty();
        for (TradeMessageWrapperType.TradeParty tradeParty : tradePartyList) {
            if (party.equals(tradeParty.getID())) {
                return getIdentifierValueFromList(tradeParty.getPartyIdentifier(), context);
            }
        }
        return "";
    }

    private String getIdentifierValueFromList(List<IdentifierType> identifierList,
                                              String context) {
        for (IdentifierType identifier : identifierList) {
            if (context.equals(identifier.getContext())) {
                return identifier.getValue();
            }
        }
        return "";
    }
}
