package com.anz.axle.adapters.ndf2trep.publisher;

import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.pricing.codec.api.PricingHandlerSupplier;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.Objects;

public class PricingSubscriber {

    private static final Logger LOGGER = LoggerFactory.getLogger(PricingSubscriber.class);
    private final Connection connection;
    private final PricingHandlerSupplier pricingHandlerSupplier;
    private final RicRepository ricRepository;

    public PricingSubscriber(
            final Connection connection,
            final PricingHandlerSupplier pricingHandlerSupplier,
            final RicRepository ricRepository) {
        this.connection = Objects.requireNonNull(connection);
        this.pricingHandlerSupplier = Objects.requireNonNull(pricingHandlerSupplier);
        this.ricRepository = Objects.requireNonNull(ricRepository);
    }

    @PostConstruct
    private void subscribe() {

        final SbePricingDecoders pricingDecoder = new SbePricingDecoders();
        final SbeMessageForReading sbeMessage = new SbeMessageForReading();
        final MessageDecoder<SbeMessage> messageDecoder = pricingDecoder.snapshotFullAndIncrementalRefresh().create(pricingHandlerSupplier, MessageDecoder.ForwardingLookup.noop());

        final MessageHandler messageHandler = (topic, buffer, offset, length, receiveTimeNanosSinceEpoch) -> {
            try {
                messageDecoder.decode(sbeMessage.wrap(buffer, offset, length));
            } catch (Exception e) {
                LOGGER.error("MessageHandler: {}, exception={}", topic, e, e);
            }
        };

        ricRepository.getTopicNames().forEach(topicName -> {
            final Topic topic = DefaultTopic.create(topicName);
            connection.openSubscription(topic, (event, topic1, o) -> LOGGER.info("EndPoint Event:{}-{}-Status:{}", event, topic1, o), messageHandler);
        });
    }
}
