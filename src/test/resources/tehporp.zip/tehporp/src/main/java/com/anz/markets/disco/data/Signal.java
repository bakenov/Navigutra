package com.anz.markets.disco.data;

import com.anz.markets.disco.utils.Symbol;

public interface Signal {
    SignalType getSignalType();

    double getValue();

    Symbol getConditionCode();
}
