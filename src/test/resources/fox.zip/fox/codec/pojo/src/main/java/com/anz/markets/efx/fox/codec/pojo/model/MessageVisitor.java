package com.anz.markets.efx.fox.codec.pojo.model;

public interface MessageVisitor {
    void onPricingRefreshComplete(PricingRefreshComplete pricingRefreshComplete);
    void onTimerExpiry(TimerExpiry timerExpiry);
    void onFirewallConfig(FirewallConfig firewallConfig);
    void onVenueConfig(VenueConfig venueConfig);
    void onUserConfig(UserConfig userConfig);
    void onInitialisation(Initialisation initialisation);
    void onInstrumentConfig(InstrumentConfig instrumentConfig);
    void onVenueInstrumentConfig(VenueInstrumentConfig venueInstrumentConfig);

    interface Silent extends MessageVisitor {
        @Override
        default void onPricingRefreshComplete(PricingRefreshComplete pricingRefreshComplete) {
        }

        @Override
        default void onTimerExpiry(TimerExpiry timerExpiry) {
        }

        @Override
        default void onFirewallConfig(FirewallConfig firewallConfig) {
        }

        @Override
        default void onVenueConfig(VenueConfig venueConfig) {
        }

        @Override
        default void onUserConfig(UserConfig userConfig) {
        }

        @Override
        default void onInitialisation(Initialisation initialisation) {
        }

        @Override
        default void onInstrumentConfig(InstrumentConfig instrumentConfig) {
        }

        @Override
        default void onVenueInstrumentConfig(VenueInstrumentConfig venueInstrumentConfig) {
        }
    }

    interface Exception extends MessageVisitor {
        @Override
        default void onPricingRefreshComplete(final PricingRefreshComplete pricingRefreshComplete) {
            throw new RuntimeException("Unexpected invocation");
        }

        @Override
        default void onTimerExpiry(TimerExpiry timerExpiry) {
            throw new RuntimeException("Unexpected invocation");
        }

        @Override
        default void onFirewallConfig(FirewallConfig firewallConfig) {
        }

        @Override
        default void onVenueConfig(VenueConfig venueConfig) {
            throw new RuntimeException("Unexpected invocation");
        }

        @Override
        default void onUserConfig(UserConfig userConfig) {
            throw new RuntimeException("Unexpected invocation");
        }

        @Override
        default void onInitialisation(Initialisation initialisation) {
            throw new RuntimeException("Unexpected invocation");
        }

        @Override
        default void onInstrumentConfig(InstrumentConfig instrumentConfig) {
            throw new RuntimeException("Unexpected invocation");
        }

        @Override
        default void onVenueInstrumentConfig(VenueInstrumentConfig venueInstrumentConfig) {
            throw new RuntimeException("Unexpected invocation");
        }
    }
}
