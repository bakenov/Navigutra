#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa021z "rm -rf ~/axle/datafabric/workspace/*"
ssh AxlSv@daxa004z "rm -rf ~/axle/datafabric/workspace/*"
ssh AxlSv@daxa029z "rm -rf ~/axle/datafabric/workspace/*"

