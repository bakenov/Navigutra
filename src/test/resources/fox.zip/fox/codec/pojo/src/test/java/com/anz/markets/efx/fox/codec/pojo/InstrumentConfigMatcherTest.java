package com.anz.markets.efx.fox.codec.pojo;

import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.pojo.matcher.InstrumentConfigMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class InstrumentConfigMatcherTest {
    private Predicate<InstrumentConfig> predicate = Matchers.isA(InstrumentConfig.class);
    private InstrumentConfigMatcher matcher = new InstrumentConfigMatcher() {
        @Override
        public Matcher<InstrumentConfigMatcher, InstrumentConfig.Body> body() {
            return matcher -> andThen(translate(instrumentConfig -> instrumentConfig.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof InstrumentConfig && predicate.test((InstrumentConfig) o);
        }

        private InstrumentConfigMatcher andThen(final Predicate<? super InstrumentConfig> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final InstrumentConfig instrumentConfig = SorMessage.instrumentConfig(
                new MessageHeader(),
                new InstrumentConfig.Body(3456, 10000, true));
        assertTrue(matcher.test(instrumentConfig));
        assertNotNull(matcher.body());
    }
}
