package com.anz.markets.efx.fox.processor.state;

import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class ChildOrderRepository {
    private final Long2ObjectHashMap<ChildOrder> activeChildOrders;
    private final ObjectPool<DefaultChildOrder> childOrderPool;

    public ChildOrderRepository(final int initialPoolSize, final TimeInForceTimer.Factory timeInForceTimerFactory, final VenueInstrumentRepository venueInstrumentRepository) {
        activeChildOrders = new Long2ObjectHashMap<>();

        childOrderPool = new ObjectPool<>(
                releaser -> new DefaultChildOrder(
                        releaser.andThen(childOrder -> {
                            removeByClOrdId(childOrder.details().origClOrdId());
                        }), timeInForceTimerFactory, venueInstrumentRepository),
                initialPoolSize);
    }

    public ChildOrder lookupByClOrdId(final long clOrdId) {
        return activeChildOrders.get(clOrdId);
    }

    private void removeByClOrdId(final long clOrdId) {
        activeChildOrders.remove(clOrdId);
    }

    public ChildOrder init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
        final DefaultChildOrder childOrder = childOrderPool.borrowOrNew();
        childOrder.init(eventContext, newOrderSingleDecoder, parentOrder);

        activeChildOrders.put(childOrder.details().origClOrdId(), childOrder);
        return childOrder;
    }
}
