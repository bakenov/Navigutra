package com.anz.markets.efx.fox.processor.pricing;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;

public class TopOfBookRule implements Consumer<VenueInstrument> {

    @Override
    public void accept(final VenueInstrument venueInstrument) {
        final MarketDataBook marketDataBook = venueInstrument.marketDataBook();

        if(marketDataBook.flagsIsEmpty()) {
            final MarketDataEntries bids = marketDataBook.bids();
            final MarketDataEntries asks = marketDataBook.asks();

            venueInstrument.topBidIndex(topEntryIdx(bids));
            venueInstrument.topAskIndex(topEntryIdx(asks));
        } else {
            venueInstrument.topBidIndex(VenueInstrument.NULL_MD_ENTRY_INDEX);
            venueInstrument.topAskIndex(VenueInstrument.NULL_MD_ENTRY_INDEX);
        }
    }

    private int topEntryIdx(final MarketDataEntries entries) {
        for (int idx = 0; idx < entries.size(); idx++) {
            final MarketDataEntry entry = entries.get(idx);
            if (entry.flagsIsEmpty()) {
                return idx;
            }
        }
        return VenueInstrument.NULL_MD_ENTRY_INDEX;
    }
}
