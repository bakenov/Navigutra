package com.anz.axle.acc.service;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertSame;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.jmock.Expectations;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

import com.anz.axle.acc.AbstractUnitTest;
import com.anz.axle.acc.dao.CreditUtilisationDAO;
import com.anz.axle.common.dao.CounterpartyDAO;
import com.anz.axle.common.dao.CurrencyHibernateDAO;
import com.anz.axle.common.dao.CurrencyPairHibernateDAO;
import com.anz.axle.common.dao.VenueDao;
import com.anz.axle.common.domain.Counterparty;
import com.anz.axle.common.domain.CounterpartyCreditPool;
import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.Currency;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditState;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import com.anz.axle.common.domain.Venue;
import com.anz.axle.datafabric.client.date.FXDateService;

public class DefaultCreditUtilisationProducerServiceTest extends AbstractUnitTest {

    private FXDateService fxDateService = null;
    private CreditUtilisationDAO creditUtilisationDAO = null;
    private CurrencyPairHibernateDAO currencyPairDAO = null;
    private CurrencyHibernateDAO currencyHibernateDAO = null;
    private CounterpartyDAO counterpartyDAO = null;
    private VenueDao venueDAO = null;

    private DefaultCreditUtilisationProducerService service = null;
    private StubService stubService = null;

    @Before
    public void beforeEachTest() {
        venueDAO = mock(VenueDao.class);
        currencyHibernateDAO = mock(CurrencyHibernateDAO.class);
        currencyPairDAO = mock(CurrencyPairHibernateDAO.class);
        creditUtilisationDAO = mock(CreditUtilisationDAO.class);
        counterpartyDAO = mock(CounterpartyDAO.class);
        fxDateService = mock(FXDateService.class);

        service = new DefaultCreditUtilisationProducerService();
        service.setCreditUtilisationDAO(creditUtilisationDAO);
        service.setCurrencyHibernateDAO(currencyHibernateDAO);
        service.setCurrencyPairDAO(currencyPairDAO);
        service.setCounterpartyDAO(counterpartyDAO);
        service.setFxDateService(fxDateService);
        service.setVenueDAO(venueDAO);

        stubService = new StubService();
        stubService.setCreditUtilisationDAO(creditUtilisationDAO);
        stubService.setCurrencyHibernateDAO(currencyHibernateDAO);
        stubService.setCurrencyPairDAO(currencyPairDAO);
        stubService.setCounterpartyDAO(counterpartyDAO);
        stubService.setFxDateService(fxDateService);
        stubService.setVenueDAO(venueDAO);
    }

    @Test
    public void test_find_counterparty_spot_date_credit_utilisations_since() {
        Counterparty counterparty = new Counterparty();
        CounterpartyCreditPool creditPool = new CounterpartyCreditPool();
        creditPool.setId(3l);
        Venue venue = new Venue();
        counterparty.setCreditPool(creditPool);
        counterparty.setVenue(venue);
        final List<Counterparty> counterparties = new ArrayList<Counterparty>();
        counterparties.add(counterparty);
        final CounterpartyCreditUtilisations results = new CounterpartyCreditUtilisations();

        final LocalDate start = new LocalDate();

        checking(new Expectations() {
            {
                oneOf(counterpartyDAO).findCreditLimitedCounterparties();
                will(returnValue(counterparties));
                oneOf(creditUtilisationDAO).getCounterpartySpotDateCreditUtilisations(start, counterparties);
                will(returnValue(results));
            }
        });
        CounterpartyCreditUtilisations utilisations = service.findCounterpartySpotDateCreditUtilisationsSince(start);
        assertSame(results, utilisations);
    }

    @Test
    public void find_current_venue_currency_credit_states_since() {
        Venue venue = new Venue();
        final List<Venue> tradingVenues = new ArrayList<Venue>();
        tradingVenues.add(venue);

        CounterpartyCreditPool creditPool = new CounterpartyCreditPool();
        creditPool.setEnabled(true);
        creditPool.setLimit(150d);
        creditPool.setMaxUtilisationPercentage(0.8d);

        final LocalDate tradeDate = new LocalDate(2010, 11, 1);
        final LocalDate spotDate = new LocalDate(2010, 11, 3);

        Double utilisationValue = new Double(123d);
        Collection<Venue> venues = new ArrayList<Venue>();
        venues.add(venue);
        CounterpartyCreditUtilisation utilisation = new CounterpartyCreditUtilisation(creditPool, spotDate, utilisationValue, venues, 0l);
        Collection<CounterpartyCreditUtilisation> utilisationCollection = new ArrayList<CounterpartyCreditUtilisation>();
        utilisationCollection.add(utilisation);
        CounterpartyCreditUtilisations utilisations = new CounterpartyCreditUtilisations(utilisationCollection);
        stubService.setReturnValue(utilisations);

        final List<CurrencyPair> pairs = new ArrayList<CurrencyPair>();
        final CurrencyPair pair = new CurrencyPair(new Currency(1l, "AUD", "AUD", 2), new Currency(2l, "CHF", "CHF", 2));
        pairs.add(pair);

        final Currency usd = new Currency(3l, "USD", "USD", 1);

        checking (new Expectations() {
            {
                oneOf(currencyPairDAO).findAllAxleTraded();
                will(returnValue(pairs));
                oneOf(venueDAO).findTradingVenues();
                will(returnValue(tradingVenues));
                oneOf(fxDateService).getTradeDate(with(pair), with(any(DateTime.class)));
                will(returnValue(tradeDate));
                oneOf(fxDateService).getSpotDate(tradeDate, pair);
                will(returnValue(spotDate));
            }
        });
        //run test
        CurrentVenueCurrencyCreditStates states = stubService.findCurrentVenueCurrencyCreditStatesSince(new LocalDate());
        assertEquals(1, states.findAll().size());
        CurrentVenueCurrencyCreditState state = states.findAll().iterator().next();
        assertEquals(pair, state.getPair());
        assertEquals(spotDate, state.getSpotDate());
        assertEquals(new Double(0.82d), state.getUtilisationPercentage());
        assertEquals(venue, state.getVenue());
        assertEquals(tradeDate, state.getTradeDate());
    }

    @Test
    public void find_current_venue_currency_credit_states_since_when_no_utilisation_found() {
        Venue venue = new Venue();
        final List<Venue> tradingVenues = new ArrayList<Venue>();
        tradingVenues.add(venue);

        CounterpartyCreditPool creditPool = new CounterpartyCreditPool();
        creditPool.setEnabled(true);
        creditPool.setLimit(150d);
        creditPool.setMaxUtilisationPercentage(0.8d);

        final LocalDate tradeDate = new LocalDate(2010, 11, 1);
        final LocalDate spotDate = new LocalDate(2010, 11, 3);
        CounterpartyCreditUtilisations utilisations = new CounterpartyCreditUtilisations(Collections.<CounterpartyCreditUtilisation>emptyList());
        stubService.setReturnValue(utilisations);

        final List<CurrencyPair> pairs = new ArrayList<CurrencyPair>();
        final CurrencyPair pair = new CurrencyPair(new Currency(1l, "AUD", "AUD", 2), new Currency(2l, "CHF", "CHF", 2));
        pairs.add(pair);

        final Currency usd = new Currency(3l, "USD", "USD", 1);

        checking (new Expectations() {
            {
                oneOf(currencyPairDAO).findAllAxleTraded();
                will(returnValue(pairs));
                oneOf(venueDAO).findTradingVenues();
                will(returnValue(tradingVenues));
                oneOf(fxDateService).getTradeDate(with(pair), with(any(DateTime.class)));
                will(returnValue(tradeDate));
                oneOf(fxDateService).getSpotDate(tradeDate, pair);
                will(returnValue(spotDate));
            }
        });
        //run test
        CurrentVenueCurrencyCreditStates states = stubService.findCurrentVenueCurrencyCreditStatesSince(new LocalDate());
        assertEquals(1, states.findAll().size());
        CurrentVenueCurrencyCreditState state = states.findAll().iterator().next();
        assertEquals(pair, state.getPair());
        assertEquals(spotDate, state.getSpotDate());
        assertEquals(new Double(0.0d), state.getUtilisationPercentage());
        assertEquals(venue, state.getVenue());
        assertEquals(tradeDate, state.getTradeDate());
    }

    private class StubService extends DefaultCreditUtilisationProducerService {
        private CounterpartyCreditUtilisations utilisations;

        @Override
        public CounterpartyCreditUtilisations findCounterpartySpotDateCreditUtilisationsSince(LocalDate startSpotDate) {
            return utilisations;
        }

        public void setReturnValue(CounterpartyCreditUtilisations utilisations) {
            this.utilisations = utilisations;
        }
    }
}
