#!/bin/bash
# -*- sh -*-
source ~/axle/environment/shell/axle.rc &> /dev/null

: << =cut

=head1 NAME

datafabric5 - Plugin to monitor the Datafabric

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=datafabric
 #%# capabilities=autoconf

=cut

HOME_DATACENTRE=${datafabric.node}
HOME_DATACENTRE_SHORT=`echo $HOME_DATACENTRE | awk -F. '{ print $(NF-1); }'`

if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Datafabric 5 -' $HOME_DATACENTRE '- Operation Frequency for Non-Trading Region (number of operations per second)'
    echo 'graph_category datafabric'
    echo 'graph_scale no'
    echo 'df5_1.label Account Config'
    echo 'df5_1.draw AREA'
    echo 'df5_2.label Currency Pair'
    echo 'df5_2.draw STACK'
    echo 'df5_3.label Currency Pair Config'
    echo 'df5_3.draw STACK'
    echo 'df5_4.label Currency Venue Exclusions'
    echo 'df5_4.draw STACK'
    echo 'df5_5.label General Config'
    echo 'df5_5.draw STACK'
    echo 'df5_6.label Trade Limit'
    echo 'df5_6.draw STACK'
    echo 'df5_7.label Venue Priority'
    echo 'df5_7.draw STACK'
    echo 'df5_8.label Counterparty Credit Utilisations'
    echo 'df5_8.draw STACK'
    echo 'df5_9.label Audit'
    echo 'df5_9.draw STACK'
    echo 'df5_10.label Component Status'
    echo 'df5_10.draw STACK'
    echo 'df5_11.label Invovation'
    echo 'df5_11.draw STACK'
    echo 'df5_12.label Ping'
    echo 'df5_12.draw STACK'
    echo 'df5_13.label Holiday'
    echo 'df5_13.draw STACK'
    echo 'df5_14.label Spot Date'
    echo 'df5_14.draw STACK'
    echo 'df5_15.label Symbol Config'
    echo 'df5_15.draw STACK'
    echo 'df5_16.label Venue Config'
    echo 'df5_16.draw STACK'
    echo 'df5_17.label Venue Symbol Config'
    echo 'df5_17.draw STACK'
    echo 'df5_18.label Channel Config'
    echo 'df5_18.draw STACK'
    echo 'df5_19.label Client'
    echo 'df5_19.draw STACK'
    echo 'df5_20.label Client Deal'
    echo 'df5_20.draw STACK'
    echo 'df5_21.label Client Order'
    echo 'df5_21.draw STACK'
    echo 'df5_22.label Quote Book'
    echo 'df5_22.draw STACK'
    echo 'df5_23.label Quote Book Config'
    echo 'df5_23.draw STACK'
    echo 'df5_24.label Wholesale Quote Page'
    echo 'df5_24.draw STACK'
    echo 'df5_25.label Agg Book'
    echo 'df5_25.draw STACK'
    echo 'df5_26.label Algo Status'
    echo 'df5_26.draw STACK'
    echo 'df5_27.label Deals'
    echo 'df5_27.draw STACK'
    echo 'df5_28.label Execution Order'
    echo 'df5_28.draw STACK'
    echo 'df5_29.label Position'
    echo 'df5_29.draw STACK'
    echo 'df5_30.label Trading Order'
    echo 'df5_30.draw STACK'
    echo 'df5_31.label Aggregated Performance Statistic'
    echo 'df5_31.draw STACK'
    echo 'df5_32.label Timed Job'
    echo 'df5_32.draw STACK'
    echo 'df5_33.label Pricing Band'
    echo 'df5_33.draw STACK'
    exit 0
fi

function emptyRecord() {
  echo "df5_1.value U"
  echo "df5_2.value U"
  echo "df5_3.value U"
  echo "df5_4.value U"
  echo "df5_5.value U"
  echo "df5_6.value U"
  echo "df5_7.value U"
  echo "df5_8.value U"
  echo "df5_9.value U"
  echo "df5_10.value U"
  echo "df5_11.value U"
  echo "df5_12.value U"
  echo "df5_13.value U"
  echo "df5_14.value U"
  echo "df5_15.value U"
  echo "df5_16.value U"
  echo "df5_17.value U"
  echo "df5_18.value U"
  echo "df5_19.value U"
  echo "df5_20.value U"
  echo "df5_21.value U"
  echo "df5_22.value U"
  echo "df5_23.value U"
  echo "df5_24.value U"
  echo "df5_25.value U"
  echo "df5_26.value U"
  echo "df5_27.value U"
  echo "df5_28.value U"
  echo "df5_29.value U"
  echo "df5_30.value U"
  echo "df5_31.value U"
  echo "df5_32.value U"
  echo "df5_33.value U"
}

GEMFIRE_HOME=~/gemfire
LOGS=~/axle/datafabric/logs
if [ -f /etc/redhat-release ] ; then
    DATEPATH=date
else
    DATEPATH=/opt/sfw/bin/date
fi

# Munin plugins are executed every 5 minutes (production setting as of 2015-06-02)
# In case this changes, be sure to adjust the extract reuse and the stat sweep windows below (in all fabric plugins)

LATEST_DAT=`ls -ltr $LOGS/ | grep .dat | grep "$HOME_DATACENTRE.statistics-" | tr -s ' ' | tail -1 | awk -F' ' '{ print $(NF); }'`
LATEST_DAT_FILE=$LOGS/$LATEST_DAT
# Reuse stat extract if it was created within the last 1.5 minutes - this number is based on below:
#  - the plugin is executed every 5 minutes (dictated by the master)
#  - it takes around 3 minutes to produce the file (in the lab)
#  - deduct a further half minute to not to overlap with the next schedule
STATS_FILE="`find -L $LOGS -cmin -1.5 -type f -name "${HOME_DATACENTRE}.statreport-*.txt" | sort | tail -1`"

if [ "$LATEST_DAT_FILE" == "" ] && [ "$STATS_FILE" == "" ]; then
  emptyRecord
  exit 0
fi

# Refresh the cache - this is a very resource intensive operation
if [ "$STATS_FILE" == "" ]; then
  TIME_STAMP=`$DATEPATH -u '+%Y-%m-%d_%H-%M-00'`
  STATS_FILE=$LOGS/$HOME_DATACENTRE.statreport-$TIME_STAMP.txt
  # use a 5 minute period up until the start of the present minute
  TIME_FROM=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC' --date '-5 min'`
  TIME_UNTIL=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC'`
  DF_STAT_EXTRACT_CMD="${GEMFIRE_HOME}/bin/gemfire stats -starttime=\"${TIME_FROM}\" -endtime=\"${TIME_UNTIL}\" -archive=\"${LATEST_DAT_FILE}\" -persec"

  $DF_STAT_EXTRACT_CMD > "$STATS_FILE"
fi

# If there are no data, bail out honouring semantics
if [ ! -s "$STATS_FILE" ]; then
  emptyRecord
  exit 0
fi

egrep "(Partitioned Region|createsCompleted|putsCompleted|destroysCompleted|getsCompleted|containsKeyCompleted|putAllsCompleted|containsValueForKeyCompleted|createTime|putTime|containsKeyTime|putAllsTime|containsValueForKeyTime)" $STATS_FILE | awk -F' ' '
BEGIN {
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:createsCompleted:average"] = "df5_1_1";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:putsCompleted:average"] = "df5_1_2";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:destroysCompleted:average"] = "df5_1_3";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:getsCompleted:average"] = "df5_1_4";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:containsKeyCompleted:average"] = "df5_1_5";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:putAllsCompleted:average"] = "df5_1_6";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:containsValueForKeyCompleted:average"] = "df5_1_7";

  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:createsCompleted:average"] = "df5_2_1";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:putsCompleted:average"] = "df5_2_2";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:destroysCompleted:average"] = "df5_2_3";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:getsCompleted:average"] = "df5_2_4";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:containsKeyCompleted:average"] = "df5_2_5";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:putAllsCompleted:average"] = "df5_2_6";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:containsValueForKeyCompleted:average"] = "df5_2_7";

  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:createsCompleted:average"] = "df5_3_1";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:putsCompleted:average"] = "df5_3_2";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:destroysCompleted:average"] = "df5_3_3";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:getsCompleted:average"] = "df5_3_4";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:containsKeyCompleted:average"] = "df5_3_5";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:putAllsCompleted:average"] = "df5_3_6";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:containsValueForKeyCompleted:average"] = "df5_3_7";

  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:createsCompleted:average"] = "df5_4_1";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:putsCompleted:average"] = "df5_4_2";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:destroysCompleted:average"] = "df5_4_3";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:getsCompleted:average"] = "df5_4_4";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:containsKeyCompleted:average"] = "df5_4_5";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:putAllsCompleted:average"] = "df5_4_6";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:containsValueForKeyCompleted:average"] = "df5_4_7";

  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:createsCompleted:average"] = "df5_5_1";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:putsCompleted:average"] = "df5_5_2";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:destroysCompleted:average"] = "df5_5_3";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:getsCompleted:average"] = "df5_5_4";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:containsKeyCompleted:average"] = "df5_5_5";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:putAllsCompleted:average"] = "df5_5_6";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:containsValueForKeyCompleted:average"] = "df5_5_7";

  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:createsCompleted:average"] = "df5_6_1";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:putsCompleted:average"] = "df5_6_2";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:destroysCompleted:average"] = "df5_6_3";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:getsCompleted:average"] = "df5_6_4";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:containsKeyCompleted:average"] = "df5_6_5";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:putAllsCompleted:average"] = "df5_6_6";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:containsValueForKeyCompleted:average"] = "df5_6_7";

  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:createsCompleted:average"] = "df5_7_1";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:putsCompleted:average"] = "df5_7_2";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:destroysCompleted:average"] = "df5_7_3";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:getsCompleted:average"] = "df5_7_4";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:containsKeyCompleted:average"] = "df5_7_5";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:putAllsCompleted:average"] = "df5_7_6";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:containsValueForKeyCompleted:average"] = "df5_7_7";

  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:createsCompleted:average"] = "df5_8_1";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:putsCompleted:average"] = "df5_8_2";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:destroysCompleted:average"] = "df5_8_3";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:getsCompleted:average"] = "df5_8_4";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:containsKeyCompleted:average"] = "df5_8_5";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:putAllsCompleted:average"] = "df5_8_6";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:containsValueForKeyCompleted:average"] = "df5_8_7";

  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:createsCompleted:average"] = "df5_9_1";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:putsCompleted:average"] = "df5_9_2";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:destroysCompleted:average"] = "df5_9_3";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:getsCompleted:average"] = "df5_9_4";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:containsKeyCompleted:average"] = "df5_9_5";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:putAllsCompleted:average"] = "df5_9_6";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:containsValueForKeyCompleted:average"] = "df5_9_7";

  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:createsCompleted:average"] = "df5_10_1";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:putsCompleted:average"] = "df5_10_2";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:destroysCompleted:average"] = "df5_10_3";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:getsCompleted:average"] = "df5_10_4";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:containsKeyCompleted:average"] = "df5_10_5";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:putAllsCompleted:average"] = "df5_10_6";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:containsValueForKeyCompleted:average"] = "df5_10_7";

  lookingfor["Partitioned Region /axle_util_Invocations Statistics:createsCompleted:average"] = "df5_11_1";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:putsCompleted:average"] = "df5_11_2";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:destroysCompleted:average"] = "df5_11_3";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:getsCompleted:average"] = "df5_11_4";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:containsKeyCompleted:average"] = "df5_11_5";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:putAllsCompleted:average"] = "df5_11_6";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:containsValueForKeyCompleted:average"] = "df5_11_7";

  lookingfor["Partitioned Region /axle_util_Ping Statistics:createsCompleted:average"] = "df5_12_1";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:putsCompleted:average"] = "df5_12_2";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:destroysCompleted:average"] = "df5_12_3";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:getsCompleted:average"] = "df5_12_4";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:containsKeyCompleted:average"] = "df5_12_5";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:putAllsCompleted:average"] = "df5_12_6";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:containsValueForKeyCompleted:average"] = "df5_12_7";
  
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:createsCompleted:average"] = "df5_13_1";
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:putsCompleted:average"] = "df5_13_2";
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:destroysCompleted:average"] = "df5_13_3";
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:getsCompleted:average"] = "df5_13_4";
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:containsKeyCompleted:average"] = "df5_13_5";
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:putAllsCompleted:average"] = "df5_13_6";
  lookingfor["Partitioned Region /axle_configuration_Holiday Statistics:containsValueForKeyCompleted:average"] = "df5_13_7";
  
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:createsCompleted:average"] = "df5_14_1";
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:putsCompleted:average"] = "df5_14_2";
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:destroysCompleted:average"] = "df5_14_3";
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:getsCompleted:average"] = "df5_14_4";
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:containsKeyCompleted:average"] = "df5_14_5";
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:putAllsCompleted:average"] = "df5_14_6";
  lookingfor["Partitioned Region /axle_configuration_SpotDate Statistics:containsValueForKeyCompleted:average"] = "df5_14_7";

  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:createsCompleted:average"] = "df5_15_1";
  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:putsCompleted:average"] = "df5_15_2";
  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:destroysCompleted:average"] = "df5_15_3";
  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:getsCompleted:average"] = "df5_15_4";
  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:containsKeyCompleted:average"] = "df5_15_5";
  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:putAllsCompleted:average"] = "df5_15_6";
  lookingfor["Partitioned Region /axle_configuration_SymbolConfig Statistics:containsValueForKeyCompleted:average"] = "df5_15_7";

  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:createsCompleted:average"] = "df5_16_1";
  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:putsCompleted:average"] = "df5_16_2";
  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:destroysCompleted:average"] = "df5_16_3";
  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:getsCompleted:average"] = "df5_16_4";
  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:containsKeyCompleted:average"] = "df5_16_5";
  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:putAllsCompleted:average"] = "df5_16_6";
  lookingfor["Partitioned Region /axle_configuration_VenueConfig Statistics:containsValueForKeyCompleted:average"] = "df5_16_7";

  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:createsCompleted:average"] = "df5_17_1";
  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:putsCompleted:average"] = "df5_17_2";
  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:destroysCompleted:average"] = "df5_17_3";
  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:getsCompleted:average"] = "df5_17_4";
  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:containsKeyCompleted:average"] = "df5_17_5";
  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:putAllsCompleted:average"] = "df5_17_6";
  lookingfor["Partitioned Region /axle_configuration_VenueSymbolConfig Statistics:containsValueForKeyCompleted:average"] = "df5_17_7";
    
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:createsCompleted:average"] = "df5_18_1";
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:putsCompleted:average"] = "df5_18_2";
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:destroysCompleted:average"] = "df5_18_3";
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:getsCompleted:average"] = "df5_18_4";
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:containsKeyCompleted:average"] = "df5_18_5";
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:putAllsCompleted:average"] = "df5_18_6";
  lookingfor["Partitioned Region /axle_pricing_ChannelConfig Statistics:containsValueForKeyCompleted:average"] = "df5_18_7";
    
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:createsCompleted:average"] = "df5_19_1";
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:putsCompleted:average"] = "df5_19_2";
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:destroysCompleted:average"] = "df5_19_3";
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:getsCompleted:average"] = "df5_19_4";
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:containsKeyCompleted:average"] = "df5_19_5";
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:putAllsCompleted:average"] = "df5_19_6";
  lookingfor["Partitioned Region /axle_pricing_Client Statistics:containsValueForKeyCompleted:average"] = "df5_19_7";
    
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:createsCompleted:average"] = "df5_20_1";
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:putsCompleted:average"] = "df5_20_2";
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:destroysCompleted:average"] = "df5_20_3";
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:getsCompleted:average"] = "df5_20_4";
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:containsKeyCompleted:average"] = "df5_20_5";
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:putAllsCompleted:average"] = "df5_20_6";
  lookingfor["Partitioned Region /axle_pricing_ClientDeal Statistics:containsValueForKeyCompleted:average"] = "df5_20_7";
    
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:createsCompleted:average"] = "df5_21_1";
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:putsCompleted:average"] = "df5_21_2";
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:destroysCompleted:average"] = "df5_21_3";
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:getsCompleted:average"] = "df5_21_4";
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:containsKeyCompleted:average"] = "df5_21_5";
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:putAllsCompleted:average"] = "df5_21_6";
  lookingfor["Partitioned Region /axle_pricing_ClientOrder Statistics:containsValueForKeyCompleted:average"] = "df5_21_7";
    
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:createsCompleted:average"] = "df5_22_1";
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:putsCompleted:average"] = "df5_22_2";
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:destroysCompleted:average"] = "df5_22_3";
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:getsCompleted:average"] = "df5_22_4";
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:containsKeyCompleted:average"] = "df5_22_5";
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:putAllsCompleted:average"] = "df5_22_6";
  lookingfor["Partitioned Region /axle_pricing_QuoteBook Statistics:containsValueForKeyCompleted:average"] = "df5_22_7";
    
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:createsCompleted:average"] = "df5_23_1";
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:putsCompleted:average"] = "df5_23_2";
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:destroysCompleted:average"] = "df5_23_3";
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:getsCompleted:average"] = "df5_23_4";
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:containsKeyCompleted:average"] = "df5_23_5";
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:putAllsCompleted:average"] = "df5_23_6";
  lookingfor["Partitioned Region /axle_pricing_QuoteBookConfig Statistics:containsValueForKeyCompleted:average"] = "df5_23_7";
    
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:createsCompleted:average"] = "df5_24_1";
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:putsCompleted:average"] = "df5_24_2";
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:destroysCompleted:average"] = "df5_24_3";
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:getsCompleted:average"] = "df5_24_4";
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:containsKeyCompleted:average"] = "df5_24_5";
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:putAllsCompleted:average"] = "df5_24_6";
  lookingfor["Partitioned Region /axle_pricing_WholesaleQuotePage Statistics:containsValueForKeyCompleted:average"] = "df5_24_7";
    
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:createsCompleted:average"] = "df5_25_1";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putsCompleted:average"] = "df5_25_2";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:destroysCompleted:average"] = "df5_25_3";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:getsCompleted:average"] = "df5_25_4";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsKeyCompleted:average"] = "df5_25_5";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putAllsCompleted:average"] = "df5_25_6";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsValueForKeyCompleted:average"] = "df5_25_7";
    
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:createsCompleted:average"] = "df5_26_1";
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:putsCompleted:average"] = "df5_26_2";
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:destroysCompleted:average"] = "df5_26_3";
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:getsCompleted:average"] = "df5_26_4";
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:containsKeyCompleted:average"] = "df5_26_5";
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:putAllsCompleted:average"] = "df5_26_6";
  lookingfor["Partitioned Region /axle_trading_AlgoStatus Statistics:containsValueForKeyCompleted:average"] = "df5_26_7";
    
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:createsCompleted:average"] = "df5_27_1";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putsCompleted:average"] = "df5_27_2";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:destroysCompleted:average"] = "df5_27_3";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:getsCompleted:average"] = "df5_27_4";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsKeyCompleted:average"] = "df5_27_5";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putAllsCompleted:average"] = "df5_27_6";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsValueForKeyCompleted:average"] = "df5_27_7";
    
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:createsCompleted:average"] = "df5_28_1";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putsCompleted:average"] = "df5_28_2";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:destroysCompleted:average"] = "df5_28_3";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:getsCompleted:average"] = "df5_28_4";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsKeyCompleted:average"] = "df5_28_5";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putAllsCompleted:average"] = "df5_28_6";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsValueForKeyCompleted:average"] = "df5_28_7";
    
  lookingfor["Partitioned Region /axle_trading_Position Statistics:createsCompleted:average"] = "df5_29_1";
  lookingfor["Partitioned Region /axle_trading_Position Statistics:putsCompleted:average"] = "df5_29_2";
  lookingfor["Partitioned Region /axle_trading_Position Statistics:destroysCompleted:average"] = "df5_29_3";
  lookingfor["Partitioned Region /axle_trading_Position Statistics:getsCompleted:average"] = "df5_29_4";
  lookingfor["Partitioned Region /axle_trading_Position Statistics:containsKeyCompleted:average"] = "df5_29_5";
  lookingfor["Partitioned Region /axle_trading_Position Statistics:putAllsCompleted:average"] = "df5_29_6";
  lookingfor["Partitioned Region /axle_trading_Position Statistics:containsValueForKeyCompleted:average"] = "df5_29_7";
    
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:createsCompleted:average"] = "df5_30_1";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putsCompleted:average"] = "df5_30_2";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:destroysCompleted:average"] = "df5_30_3";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:getsCompleted:average"] = "df5_30_4";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsKeyCompleted:average"] = "df5_30_5";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putAllsCompleted:average"] = "df5_30_6";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsValueForKeyCompleted:average"] = "df5_30_7";
    
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:createsCompleted:average"] = "df5_31_1";
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:putsCompleted:average"] = "df5_31_2";
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:destroysCompleted:average"] = "df5_31_3";
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:getsCompleted:average"] = "df5_31_4";
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:containsKeyCompleted:average"] = "df5_31_5";
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:putAllsCompleted:average"] = "df5_31_6";
  lookingfor["Partitioned Region /axle_util_AggregatedPerformanceStatistic Statistics:containsValueForKeyCompleted:average"] = "df5_31_7";
    
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:createsCompleted:average"] = "df5_32_1";
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:putsCompleted:average"] = "df5_32_2";
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:destroysCompleted:average"] = "df5_32_3";
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:getsCompleted:average"] = "df5_32_4";
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:containsKeyCompleted:average"] = "df5_32_5";
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:putAllsCompleted:average"] = "df5_32_6";
  lookingfor["Partitioned Region /axle_util_TimedJob Statistics:containsValueForKeyCompleted:average"] = "df5_32_7";  
  
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:createsCompleted:average"] = "df5_33_1";
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:putsCompleted:average"] = "df5_33_2";
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:destroysCompleted:average"] = "df5_33_3";
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:getsCompleted:average"] = "df5_33_4";
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:containsKeyCompleted:average"] = "df5_33_5";
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:putAllsCompleted:average"] = "df5_33_6";
  lookingfor["Partitioned Region /axle_pricing_PricingBand Statistics:containsValueForKeyCompleted:average"] = "df5_33_7";
}
/^[a-zA-Z]/ {
  section  = substr($0,1,index($0,",")-1);
}
/^  / {
  statistic = $1;
  for (i=2; i<=NF; i++) {
    fieldandvalue = $i;
    equals = index(fieldandvalue,"=");
    if (equals > 0) {
      fieldname = substr(fieldandvalue,1,equals-1);
      value = substr(fieldandvalue,equals+1);
      outputname = lookingfor[section ":" statistic ":" fieldname];
      if (outputname != "") {
        values[outputname] = value;
      }
    }
  }
}
END {
  print "df5_1.value " values["df5_1_1"] + values["df5_1_2"] + values["df5_1_3"] + values["df5_1_4"] + values["df5_1_5"] + values["df5_1_6"] + values["df5_1_7"];
  print "df5_2.value " values["df5_2_1"] + values["df5_2_2"] + values["df5_2_3"] + values["df5_2_4"] + values["df5_2_5"] + values["df5_2_6"] + values["df5_2_7"];
  print "df5_3.value " values["df5_3_1"] + values["df5_3_2"] + values["df5_3_3"] + values["df5_3_4"] + values["df5_3_5"] + values["df5_3_6"] + values["df5_3_7"];
  print "df5_4.value " values["df5_4_1"] + values["df5_4_2"] + values["df5_4_3"] + values["df5_4_4"] + values["df5_4_5"] + values["df5_4_6"] + values["df5_4_7"];
  print "df5_5.value " values["df5_5_1"] + values["df5_5_2"] + values["df5_5_3"] + values["df5_5_4"] + values["df5_5_5"] + values["df5_5_6"] + values["df5_5_7"];
  print "df5_6.value " values["df5_6_1"] + values["df5_6_2"] + values["df5_6_3"] + values["df5_6_4"] + values["df5_6_5"] + values["df5_6_6"] + values["df5_6_7"];
  print "df5_7.value " values["df5_7_1"] + values["df5_7_2"] + values["df5_7_3"] + values["df5_7_4"] + values["df5_7_5"] + values["df5_7_6"] + values["df5_7_7"];
  print "df5_8.value " values["df5_8_1"] + values["df5_8_2"] + values["df5_8_3"] + values["df5_8_4"] + values["df5_8_5"] + values["df5_8_6"] + values["df5_8_7"];
  print "df5_9.value " values["df5_9_1"] + values["df5_9_2"] + values["df5_9_3"] + values["df5_9_4"] + values["df5_9_5"] + values["df5_9_6"] + values["df5_9_7"];
  print "df5_10.value " values["df5_10_1"] + values["df5_10_2"] + values["df5_10_3"] + values["df5_10_4"] + values["df5_10_5"] + values["df5_10_6"] + values["df5_10_7"];
  print "df5_11.value " values["df5_11_1"] + values["df5_11_2"] + values["df5_11_3"] + values["df5_11_4"] + values["df5_11_5"] + values["df5_11_6"] + values["df5_11_7"];
  print "df5_12.value " values["df5_12_1"] + values["df5_12_2"] + values["df5_12_3"] + values["df5_12_4"] + values["df5_12_5"] + values["df5_12_6"] + values["df5_12_7"];
  print "df5_13.value " values["df5_13_1"] + values["df5_13_2"] + values["df5_13_3"] + values["df5_13_4"] + values["df5_13_5"] + values["df5_13_6"] + values["df5_13_7"];
  print "df5_14.value " values["df5_14_1"] + values["df5_14_2"] + values["df5_14_3"] + values["df5_14_4"] + values["df5_14_5"] + values["df5_14_6"] + values["df5_14_7"];
  print "df5_15.value " values["df5_15_1"] + values["df5_15_2"] + values["df5_15_3"] + values["df5_15_4"] + values["df5_15_5"] + values["df5_15_6"] + values["df5_15_7"];
  print "df5_16.value " values["df5_16_1"] + values["df5_16_2"] + values["df5_16_3"] + values["df5_16_4"] + values["df5_16_5"] + values["df5_16_6"] + values["df5_16_7"];
  print "df5_17.value " values["df5_17_1"] + values["df5_17_2"] + values["df5_17_3"] + values["df5_17_4"] + values["df5_17_5"] + values["df5_17_6"] + values["df5_17_7"];
  print "df5_18.value " values["df5_18_1"] + values["df5_18_2"] + values["df5_18_3"] + values["df5_18_4"] + values["df5_18_5"] + values["df5_18_6"] + values["df5_18_7"];
  print "df5_19.value " values["df5_19_1"] + values["df5_19_2"] + values["df5_19_3"] + values["df5_19_4"] + values["df5_19_5"] + values["df5_19_6"] + values["df5_19_7"];
  print "df5_20.value " values["df5_20_1"] + values["df5_20_2"] + values["df5_20_3"] + values["df5_20_4"] + values["df5_20_5"] + values["df5_20_6"] + values["df5_20_7"];
  print "df5_21.value " values["df5_21_1"] + values["df5_21_2"] + values["df5_21_3"] + values["df5_21_4"] + values["df5_21_5"] + values["df5_21_6"] + values["df5_21_7"];
  print "df5_22.value " values["df5_22_1"] + values["df5_22_2"] + values["df5_22_3"] + values["df5_22_4"] + values["df5_22_5"] + values["df5_22_6"] + values["df5_22_7"];
  print "df5_23.value " values["df5_23_1"] + values["df5_23_2"] + values["df5_23_3"] + values["df5_23_4"] + values["df5_23_5"] + values["df5_23_6"] + values["df5_23_7"];
  print "df5_24.value " values["df5_24_1"] + values["df5_24_2"] + values["df5_24_3"] + values["df5_24_4"] + values["df5_24_5"] + values["df5_24_6"] + values["df5_24_7"];
  print "df5_25.value " values["df5_25_1"] + values["df5_25_2"] + values["df5_25_3"] + values["df5_25_4"] + values["df5_25_5"] + values["df5_25_6"] + values["df5_25_7"];
  print "df5_26.value " values["df5_26_1"] + values["df5_26_2"] + values["df5_26_3"] + values["df5_26_4"] + values["df5_26_5"] + values["df5_26_6"] + values["df5_26_7"];
  print "df5_27.value " values["df5_27_1"] + values["df5_27_2"] + values["df5_27_3"] + values["df5_27_4"] + values["df5_27_5"] + values["df5_27_6"] + values["df5_27_7"];
  print "df5_28.value " values["df5_28_1"] + values["df5_28_2"] + values["df5_28_3"] + values["df5_28_4"] + values["df5_28_5"] + values["df5_28_6"] + values["df5_28_7"];
  print "df5_29.value " values["df5_29_1"] + values["df5_29_2"] + values["df5_29_3"] + values["df5_29_4"] + values["df5_29_5"] + values["df5_29_6"] + values["df5_29_7"];
  print "df5_30.value " values["df5_30_1"] + values["df5_30_2"] + values["df5_30_3"] + values["df5_30_4"] + values["df5_30_5"] + values["df5_30_6"] + values["df5_30_7"];
  print "df5_31.value " values["df5_31_1"] + values["df5_31_2"] + values["df5_31_3"] + values["df5_31_4"] + values["df5_31_5"] + values["df5_31_6"] + values["df5_31_7"];
  print "df5_32.value " values["df5_32_1"] + values["df5_32_2"] + values["df5_32_3"] + values["df5_32_4"] + values["df5_32_5"] + values["df5_32_6"] + values["df5_32_7"];
  print "df5_33.value " values["df5_33_1"] + values["df5_33_2"] + values["df5_33_3"] + values["df5_33_4"] + values["df5_33_5"] + values["df5_33_6"] + values["df5_33_7"];
}
'
