package com.anz.axle.acc.service;

import com.anz.axle.acc.AbstractUnitTest;
import com.anz.axle.acc.domain.CounterpartyCreditUtilisationValuesBuilder;
import com.anz.axle.acc.domain.CurrencyVenueExclusionsBuilder;
import com.anz.axle.common.domain.*;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionDAO;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionKey;
import com.anz.axle.datafabric.client.trading.*;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationKey;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import org.jmock.Expectations;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.*;

public class DatafabricCreditUtilisationConsumerServiceTest extends AbstractUnitTest {

    private CurrencyVenueExclusionDAO currencyVenueExclusionDao;
    private CounterpartyCreditUtilisationValueDAO counterpartyCreditUtilisationDao;
    private DatafabricCreditUtilisationConsumerService service;
    private CurrencyVenueExclusionsBuilder exclusionsBuilder;
    private CounterpartyCreditUtilisationValuesBuilder utilisationsBuilder;
    private CreditUtilisationConsumerServiceListener listener;

    @Before
    public void before() {
        currencyVenueExclusionDao = mock(CurrencyVenueExclusionDAO.class);
        counterpartyCreditUtilisationDao = mock(CounterpartyCreditUtilisationValueDAO.class);
        exclusionsBuilder = mock(CurrencyVenueExclusionsBuilder.class);
        utilisationsBuilder = mock(CounterpartyCreditUtilisationValuesBuilder.class);
        listener = mock(CreditUtilisationConsumerServiceListener.class);
        service = new DatafabricCreditUtilisationConsumerService();

        service.setExclusionsBuilder(exclusionsBuilder);
        service.setCurrencyVenueExclusionDAO(currencyVenueExclusionDao);
        service.setCounterpartyCreditUtilisationValueDAO(counterpartyCreditUtilisationDao);
        service.setExclusionsBuilder(exclusionsBuilder);
        service.setUtilisationsBuilder(utilisationsBuilder);
        service.setListener(listener);
    }

    @Test
    public void test_service_states_consume_sends_as_exclusions_to_datafabric_when_datafabric_doesnt_have_it() throws BuilderException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates();
        final Collection<CurrencyVenueExclusion> exclusions = new ArrayList<CurrencyVenueExclusion>();
        final CurrencyVenueExclusionKey key = new CurrencyVenueExclusionKey();
        key.setSource("FOO");
        key.setSymbol("AUD/CHF");
        key.setVenue("BARX");
        final CurrencyVenueExclusion exclusion = new CurrencyVenueExclusion();
        exclusion.setKey(key);
        exclusion.setExcluded(true);
        exclusion.setSource("FOO");
        exclusion.setSymbol("AUD/CHF");
        exclusions.add(exclusion);

        checking(new Expectations() {
            {
                oneOf(exclusionsBuilder).build(states);
                will(returnValue(exclusions));
                oneOf(currencyVenueExclusionDao).has(key);
                will(returnValue(false));
                oneOf(currencyVenueExclusionDao).save(exclusion);
                oneOf(listener).onConsume(exclusion);
            }
        });
        //run the test
        assertTrue(service.consume(states));
    }

    @Test
    public void test_service_states_consume_does_send_exclusion_to_datafabric_when_datafabric_does_have_it_and_is_different_excluded_value() throws BuilderException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates();
        final Collection<CurrencyVenueExclusion> localExclusions = new ArrayList<CurrencyVenueExclusion>();
        final CurrencyVenueExclusionKey localKey = new CurrencyVenueExclusionKey();
        localKey.setSource("FOO");
        localKey.setSymbol("AUD/CHF");
        localKey.setVenue("BARX");
        final CurrencyVenueExclusion localExclusion = new CurrencyVenueExclusion();
        localExclusion.setKey(localKey);
        localExclusion.setExcluded(true);
        localExclusion.setSource("FOO");
        localExclusion.setSymbol("AUD/CHF");
        localExclusions.add(localExclusion);

        final CurrencyVenueExclusion serverExclusion = new CurrencyVenueExclusion();
        serverExclusion.setExcluded(false);
        serverExclusion.setSource("FOO");
        serverExclusion.setSymbol("AUD/CHF");

        checking(new Expectations() {
            {
                oneOf(exclusionsBuilder).build(states);
                will(returnValue(localExclusions));
                oneOf(currencyVenueExclusionDao).has(localKey);
                will(returnValue(true));
                oneOf(currencyVenueExclusionDao).findByKey(localKey);
                will(returnValue(serverExclusion));
                oneOf(listener).onConsume(localExclusion);
                oneOf(currencyVenueExclusionDao).save(localExclusion);
            }
        });
        //run the test
        assertTrue(service.consume(states));
    }

    @Test
    public void test_service_states_consume_doesnt_send_exclusion_to_datafabric_when_datafabric_does_have_it_and_is_same_excluded_value() throws BuilderException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates();
        final Collection<CurrencyVenueExclusion> localExclusions = new ArrayList<CurrencyVenueExclusion>();
        final CurrencyVenueExclusionKey localKey = new CurrencyVenueExclusionKey();
        localKey.setSource("FOO");
        localKey.setSymbol("AUD/CHF");
        localKey.setVenue("BARX");
        final CurrencyVenueExclusion localExclusion = new CurrencyVenueExclusion();
        localExclusion.setKey(localKey);
        localExclusion.setExcluded(true);
        localExclusion.setSource("FOO");
        localExclusion.setSymbol("AUD/CHF");
        localExclusions.add(localExclusion);

        final CurrencyVenueExclusion serverExclusion = new CurrencyVenueExclusion();
        serverExclusion.setExcluded(true);
        serverExclusion.setSource("FOO");
        serverExclusion.setSymbol("AUD/CHF");

        checking(new Expectations() {
            {
                oneOf(exclusionsBuilder).build(states);
                will(returnValue(localExclusions));
                oneOf(currencyVenueExclusionDao).has(localKey);
                will(returnValue(true));
                oneOf(currencyVenueExclusionDao).findByKey(localKey);
                will(returnValue(serverExclusion));
                never(listener).onConsume(localExclusion);
                never(currencyVenueExclusionDao).save(localExclusion);
            }
        });
        //run the test
        assertTrue(service.consume(states));
        assertEquals(0, mockLogAppender.size());
    }

    @Test
    public void test_service_states_consume_returns_false_upon_exception() throws BuilderException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates();
        final Map<CurrencyVenueExclusionKey, CurrencyVenueExclusion> exclusions = new HashMap<CurrencyVenueExclusionKey, CurrencyVenueExclusion>();

        checking(new Expectations() {
            {
                oneOf(exclusionsBuilder).build(states);
                will(throwException(new BuilderException("foo")));
            }
        });
        //run the test
        assertFalse(service.consume(states));
        assertEquals(1, mockLogAppender.size());
        assertTrue(mockLogAppender.contains("There was an exception when saving exclusions to the datafabric."));
    }

    @Test
    public void test_service_utilisations_consume_sends_when_datafabric_has_no_copy() throws BuilderException {
        final CounterpartyCreditUtilisations utilisations = new CounterpartyCreditUtilisations();
        final Collection<CounterpartyCreditUtilisationValue> buildResult = new ArrayList<CounterpartyCreditUtilisationValue>();
        CounterpartyCreditPool creditPool = new CounterpartyCreditPool();
        creditPool.setId(1l);
        CounterpartyCreditUtilisationKey key = new CounterpartyCreditUtilisationKey(creditPool, new LocalDate(), "CREDIT_CHECK");
        final CounterpartyCreditUtilisationValue value = new CounterpartyCreditUtilisationValue(key, 0.8d, new ArrayList<Venue>(), 0l);
        buildResult.add(value);

        checking(new Expectations() {
            {
                oneOf(utilisationsBuilder).build(utilisations);
                will(returnValue(buildResult));
                oneOf(counterpartyCreditUtilisationDao).has(value.getKey());
                will(returnValue(false));

                oneOf(counterpartyCreditUtilisationDao).save(value);
                oneOf(listener).onConsume(value);
            }
        });
        //run the test
        assertEquals(0, mockLogAppender.size());
        assertTrue(service.consume(utilisations));
    }

    @Test
    public void test_service_utilisations_consume_sends_when_datafabric_different_value() throws BuilderException {
        final CounterpartyCreditUtilisations utilisations = new CounterpartyCreditUtilisations();
        final Collection<CounterpartyCreditUtilisationValue> buildResult = new ArrayList<CounterpartyCreditUtilisationValue>();

        CounterpartyCreditPool creditPoolOne = new CounterpartyCreditPool();
        creditPoolOne.setId(1l);
        CounterpartyCreditPool creditPoolTwo = new CounterpartyCreditPool();
        creditPoolTwo.setId(2l);
        CounterpartyCreditUtilisationKey keyOne = new CounterpartyCreditUtilisationKey(creditPoolOne, new LocalDate(), "CREDIT_CHECK");
        CounterpartyCreditUtilisationKey keyTwo = new CounterpartyCreditUtilisationKey(creditPoolTwo, new LocalDate(), "CREDIT_CHECK");

        final CounterpartyCreditUtilisationValue localValueOne = new CounterpartyCreditUtilisationValue(keyOne, 0.8d, new ArrayList<Venue>(), 0l);
        final CounterpartyCreditUtilisationKey localKeyOne = new CounterpartyCreditUtilisationKey(creditPoolOne, new LocalDate(), "CREDIT_CHECK");
        localValueOne.setKey(localKeyOne);
        buildResult.add(localValueOne);

        final CounterpartyCreditUtilisationValue localValueTwo = new CounterpartyCreditUtilisationValue(keyTwo, 0.8d, new ArrayList<Venue>(), 0l);
        final CounterpartyCreditUtilisationKey localKeyTwo = new CounterpartyCreditUtilisationKey(creditPoolTwo, new LocalDate(), "CREDIT_CHECK");
        localValueTwo.setKey(localKeyTwo);
        buildResult.add(localValueTwo);

        final CounterpartyCreditUtilisationValue datafabricValueOne = new CounterpartyCreditUtilisationValue(keyOne, 0.8d, new ArrayList<Venue>(), 0l);
        final CounterpartyCreditUtilisationValue datafabricValueTwo = new CounterpartyCreditUtilisationValue(keyTwo, 0.9d, new ArrayList<Venue>(), 0l);

        checking(new Expectations() {
            {
                oneOf(utilisationsBuilder).build(utilisations);
                will(returnValue(buildResult));
                oneOf(counterpartyCreditUtilisationDao).has(localKeyOne);
                will(returnValue(true));
                oneOf(counterpartyCreditUtilisationDao).findByKey(localKeyOne);
                will(returnValue(datafabricValueOne));

                oneOf(counterpartyCreditUtilisationDao).has(localKeyTwo);
                will(returnValue(true));
                oneOf(counterpartyCreditUtilisationDao).findByKey(localKeyTwo);
                will(returnValue(datafabricValueTwo));
                oneOf(counterpartyCreditUtilisationDao).save(localValueTwo);
                oneOf(listener).onConsume(localValueTwo);
            }
        });
        //run the test
        assertEquals(0, mockLogAppender.size());
        assertTrue(service.consume(utilisations));
    }

    @Test
    public void test_service_utilisations_consume_returns_false_upon_exception() throws BuilderException {
        final CounterpartyCreditUtilisations utilisations = new CounterpartyCreditUtilisations();
        final Collection<CounterpartyCreditUtilisationValue> buildResult = new ArrayList<CounterpartyCreditUtilisationValue>();
        CounterpartyCreditPool creditPool = new CounterpartyCreditPool();
        creditPool.setId(1l);
        CounterpartyCreditUtilisationKey key = new CounterpartyCreditUtilisationKey(creditPool, new LocalDate(), "CREDIT_CHECK");
        final CounterpartyCreditUtilisationValue value = new CounterpartyCreditUtilisationValue(key, 0.8d, new ArrayList<Venue>(), 0l);
        buildResult.add(value);

        checking(new Expectations() {
            {
                oneOf(utilisationsBuilder).build(utilisations);
                will(returnValue(buildResult));
                oneOf(counterpartyCreditUtilisationDao).has(value.getKey());
                will(returnValue(false));
                oneOf(counterpartyCreditUtilisationDao).save(value);
                will(throwException(new RuntimeException("foo")));
            }
        });
        //run the test
        assertFalse(service.consume(utilisations));
    }
}
