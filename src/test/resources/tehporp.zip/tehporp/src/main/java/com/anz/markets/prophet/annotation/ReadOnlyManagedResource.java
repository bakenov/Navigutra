package com.anz.markets.prophet.annotation;

public @interface ReadOnlyManagedResource {
}
