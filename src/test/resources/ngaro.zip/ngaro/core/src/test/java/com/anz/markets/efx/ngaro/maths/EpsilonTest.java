package com.anz.markets.efx.ngaro.maths;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class EpsilonTest {

    @Test
    public void test() {
        assertTrue(Epsilon.EPS_100.doesNotEqualEpsilon(1000, 800));
        assertFalse(Epsilon.EPS_100.equalsEpsilon(1000, 800));
        assertTrue(Epsilon.EPS_100.doesNotEqualEpsilon(1000, 900));
        assertFalse(Epsilon.EPS_100.equalsEpsilon(1000, 900));
        assertFalse(Epsilon.EPS_100.doesNotEqualEpsilon(1000, 900.001));
        assertTrue(Epsilon.EPS_100.equalsEpsilon(1000, 900.001));
        assertFalse(Epsilon.EPS_100.equalsEpsilon(Double.NaN, 900.001));
        assertFalse(Epsilon.EPS_100.equalsEpsilon(900.001, Double.NaN));
        assertTrue(Epsilon.EPS_100.equalsEpsilon(Double.NaN, Double.NaN));
    }
}
