// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;

/**
 * This class acts as a static interface to quickfix.cfg file.
 */
public class QuickFixConfig
{
    private static final Properties properties = new Properties();
    private static boolean          isLoaded   = false;

    static
    {
        try
        {
            synchronized (properties)
            {
                if (!isLoaded)
                {
                    final InputStream is = ClassLoader.getSystemResourceAsStream("config/quickfix.cfg");
                    if (is == null)
                    {
                        throw new FileNotFoundException("quickfix.cfg not found on classpath");
                    }
                    properties.load(is);
                    is.close();
                    isLoaded = true;
                }
            }
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * @return property
     */
    public static final String getDefaultApplVerID()
    {
        return properties.getProperty("DefaultApplVerID", "9");
    }

    /**
     * @return property
     */
    public static final Integer getDefaultApplExtID()
    {
        return Integer.valueOf(properties.getProperty("DefaultApplExtID", "100"));
    }

    /**
     * @return property
     */
    public static final String getSenderCompID()
    {
        return properties.getProperty("SenderCompID");
    }

    /**
     * @return property
     */
    public static final String getSenderLocationID()
    {
        return properties.getProperty("SenderLocationID");
    }
}
