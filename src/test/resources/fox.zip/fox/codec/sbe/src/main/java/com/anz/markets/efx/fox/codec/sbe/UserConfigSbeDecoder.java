package com.anz.markets.efx.fox.codec.sbe;

import com.anz.markets.efx.fox.codec.api.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringDecoders;

public class UserConfigSbeDecoder implements UserConfigDecoder {
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder userConfigDecoder = new com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder();
    private final SbeHeader header = new SbeHeader(headerDecoder);
    private final SbeBody body = new SbeBody();
    private EncodingOrder.UserConfig encodingOrder = EncodingOrder.UserConfig.INITIAL;


    private int bodyLimit;

    public boolean wrap(final SbeMessage sbeMessage) {
        headerDecoder.wrap(sbeMessage.buffer(), 0);
        if (headerDecoder.templateId() != com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder.TEMPLATE_ID) {
            clear();
            return false;
        }

        userConfigDecoder.wrap(sbeMessage.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        this.bodyLimit = userConfigDecoder.limit();
        encodingOrder = EncodingOrder.UserConfig.INITIAL;
        return true;
    }

    public void clear() {
        headerDecoder.wrap(null, 0);
        userConfigDecoder.wrap(null, 0, 0, 0);
    }

    @Override
    public Header header() {
        return header;
    }

    @Override
    public Body body() {
        encodingOrder = EncodingOrder.UserConfig.BODY;
        userConfigDecoder.limit(bodyLimit);
        return body;
    }

    @Override
    public void appendTo(final StringBuilder stringBuilder) {
        userConfigDecoder.appendTo(stringBuilder);
    }

    class SbeBody implements Body {
        private final EnumerableSetDecoder<UserGroup> userGroups = new SbeUserGroupSetDecoder(userConfigDecoder::userGroups);
        private final StringDecoder userName = StringDecoders.forFixedLength(
                userConfigDecoder::userName, com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder.userNameLength());
        private final StringDecoder location = StringDecoders.forFixedLength(
                userConfigDecoder::location, com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder.locationLength());

        @Override
        public StringDecoder userName() {
            encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
            return userName;
        }

        @Override
        public EnumerableSetDecoder<UserGroup> userGroups() {
            encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
            return userGroups;
        }

        @Override
        public StringDecoder location() {
            encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
            return location;
        }
    }
}