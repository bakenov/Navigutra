package com.anz.markets.prophet.config.business.doclet;

import static java.lang.String.format;

public class Markdown {

    public String em(final String s) {
        return format("*%s*", s);
    }

    public String strikeThrough(final String s) {
        return format("~~%s~~", s);
    }

    public String oneline(String text) {
        return text.replaceAll("\\n", "");
    }

    public String h1(String text) {
        return format("# %s\n", text);
    }

    public String h2(String text) {
        return format("## %s\n", text);
    }

    public String h3(String text) {
        return format("### %s\n", text);
    }

    public String localLink(final String label,
                            final String anchor) {
        return format("[%s](#%s)", label, anchor);
    }

    public String hr() {
        return "------\n";
    }

    public String code(final String s) {
        return format("`%s`", s);
    }

    public String quote(final String s) {
        return format("> %s", s);
    }

    public String tableHeader(final String... column) {
        final StringBuilder sb = new StringBuilder();
        sb.append(tableRow(column)).append("\n");
        for (int i = 0; i < column.length; i++) {
            column[i] = "---";
        }
        sb.append(tableRow(column));
        return sb.toString();
    }

    public String tableRow(final String... column) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < column.length; i++) {
            if (sb.length() == 0) {
                sb.append("|");
            }
            sb.append("%s|");
        }
        return format(sb.toString(), (Object[]) column);
    }

    public String escapeUnderScore(final String classNameInUnderScore) {
        return classNameInUnderScore.replaceAll("_", "\\_");
    }

}
