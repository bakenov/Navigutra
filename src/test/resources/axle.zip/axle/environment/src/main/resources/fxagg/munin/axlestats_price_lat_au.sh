#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_price_lat_au - Plugin to monitor the Price Update Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=z::deprecated
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Price Update Latency [DEPRECATED]'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category z::deprecated'
    echo 'graph_scale no'
    echo 'price1.label Venue Price Update (BARX)'
    echo 'price1.draw LINE2'
    echo 'price2.label Venue Price Update (CNX)'
    echo 'price2.draw LINE2'
    echo 'price3.label Venue Price Update (EBS)'
    echo 'price3.draw LINE2'
    echo 'price19.label Venue Price Update (EBSD)'
    echo 'price19.draw LINE2'
    echo 'price4.label Venue Price Update (RFX)'
    echo 'price4.draw LINE2'
    echo 'price6.label Venue Price Update (MSI)'
    echo 'price6.draw LINE2'
    echo 'price7.label Venue Price Update (CME)'
    echo 'price7.draw LINE2'
    echo 'price8.label Venue Price Update (DEUT)'
    echo 'price8.draw LINE2'
    echo 'price9.label Venue Price Update (GS)'
    echo 'price9.draw LINE2'
    echo 'price9.colour 0080ff'		# don't use red
    echo 'price10.label Venue Price Update (CMZ)'
    echo 'price10.draw LINE2'
    echo 'price14.label Venue Price Update (HSP)'
    echo 'price14.draw LINE2'
    echo 'price15.label Venue Price Update (UBS)'
    echo 'price15.draw LINE2'
    echo 'price16.label Venue Price Update (GCS)'
    echo 'price16.draw LINE2'
    echo 'price17.label Venue Price Update (CITI)'
    echo 'price17.draw LINE2'
    echo 'price20.label Venue Price Update (FXBK)'
    echo 'price20.draw LINE2'
    echo 'price18.label Venue Price Update (ANZD)'
    echo 'price18.draw LINE2'
    echo 'price5.label AggBooks Received from VAGs'
    echo 'price5.draw LINE2'
    echo 'price5.colour 000000'		# BLACK
    echo 'price11.label AggBooks Published to Algo'
    echo 'price11.draw LINE2'
    echo 'price11.colour D175A3'	# PINK
    echo 'price12.label AggBooks Published to GUI'
    echo 'price12.draw LINE2'
    echo 'price12.colour FF0000'	# RED
    exit 0
fi

echo "price1.value U"
echo "price2.value U"
echo "price3.value U"
echo "price19.value U"
echo "price4.value U"
echo "price5.value U"
echo "price6.value U"
echo "price7.value U"
echo "price8.value U"
echo "price9.value U"
echo "price10.value U"
echo "price14.value U"
echo "price15.value U"
echo "price16.value U"
echo "price17.value U"
echo "price20.value U"
echo "price18.value U"
echo "price11.value U"
echo "price12.value U"
exit 0