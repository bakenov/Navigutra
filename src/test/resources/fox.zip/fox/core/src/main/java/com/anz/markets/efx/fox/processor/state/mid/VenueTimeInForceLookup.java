package com.anz.markets.efx.fox.processor.state.mid;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public interface VenueTimeInForceLookup {
    TimeInForce lookup(TimeInForce parentTimeInForce, Venue venue);
}
