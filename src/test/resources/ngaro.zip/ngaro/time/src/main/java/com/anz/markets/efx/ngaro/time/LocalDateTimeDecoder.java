package com.anz.markets.efx.ngaro.time;

import java.time.LocalDateTime;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteReader;

/**
 * Decoder for local date/time values with formats as defined by {@link LocalDateFormat} and {@link LocalTimeFormat}.
 * <br/>
 * All methods are zero garbage.
 * <p/>
 * This class is thread safe.
 *
 * @see LocalDateTimeDecoder
 */
public final class LocalDateTimeDecoder {

    public static final char DEFAULT_SEPARATOR = LocalDateTimeEncoder.DEFAULT_SEPARATOR;
    public static final char NO_SEPARATOR = LocalDateTimeEncoder.NO_SEPARATOR;
    private static Map<LocalDateFormat, Map<LocalTimeFormat, LocalDateTimeDecoder>> defaultDecoders = initDefaultDecoders();

    private final LocalDateDecoder dateDecoder;
    private final LocalTimeDecoder timeDecoder;
    private final char dateTimeSeparator;

    private LocalDateTimeDecoder(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat) {
        this(dateFormat.getDefaultDecoder(), timeFormat.getDefaultDecoder(), DEFAULT_SEPARATOR);
    }

    private LocalDateTimeDecoder(final LocalDateDecoder dateDecoder, final LocalTimeDecoder timeDecoder, final char dateTimeSeparator) {
        this.dateDecoder = Objects.requireNonNull(dateDecoder);
        this.timeDecoder = Objects.requireNonNull(timeDecoder);
        this.dateTimeSeparator = dateTimeSeparator;
        if (dateTimeSeparator > 127 && dateTimeSeparator != NO_SEPARATOR) {
            throw new IllegalArgumentException("Invalid date/time separator char: " + dateTimeSeparator);
        }
    }

    public static LocalDateTimeDecoder valueOf(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat) {
        return defaultDecoders.get(dateFormat).get(timeFormat);
    }

    public static LocalDateTimeDecoder valueOf(final LocalDateFormat dateFormat, final LocalTimeFormat timeFormat, final char dateTimeSeparator) {
        if (dateTimeSeparator == DEFAULT_SEPARATOR) {
            return valueOf(dateFormat, timeFormat);
        }
        return new LocalDateTimeDecoder(dateFormat.getDefaultDecoder(), timeFormat.getDefaultDecoder(), dateTimeSeparator);
    }

    public static LocalDateTimeDecoder valueOf(final LocalDateDecoder dateDecoder, final LocalTimeDecoder timeDecoder) {
        return valueOf(dateDecoder, timeDecoder, DEFAULT_SEPARATOR);
    }

    public static LocalDateTimeDecoder valueOf(final LocalDateDecoder dateDecoder, final LocalTimeDecoder timeDecoder, final char dateTimeSeparator) {
        if (dateTimeSeparator == DEFAULT_SEPARATOR & dateDecoder == dateDecoder.getDateFormat().getDefaultDecoder() & timeDecoder == timeDecoder.getTimeFormat().getDefaultDecoder()) {
            return valueOf(dateDecoder.getDateFormat(), timeDecoder.getTimeFormat());
        }
        return new LocalDateTimeDecoder(dateDecoder, timeDecoder, dateTimeSeparator);
    }

    public LocalDateDecoder getDateDecoder() {
        return dateDecoder;
    }

    private LocalTimeDecoder getTimeDecoder() {
        return timeDecoder;
    }

    public LocalDateFormat getDateFormat() {
        return dateDecoder.getDateFormat();
    }

    public LocalTimeFormat getTimeFormat() {
        return timeDecoder.getTimeFormat();
    }

    public String getDateTimeFormatString() {
        return getDateFormat() + (dateTimeSeparator == NO_SEPARATOR ? "" : String.valueOf(dateTimeSeparator)) + getTimeFormat();
    }

    public char getDateTimeSeparator() {
        return dateTimeSeparator;
    }

    public int getTimeOffset() {
        return getDateFormat().getLength() + (dateTimeSeparator != NO_SEPARATOR ? 1 : 0);
    }

    public int getLength() {
        return getTimeOffset() + getTimeFormat().getLength();
    }

    public <S> long decodeEpochSeconds(final S source, final ByteReader<? super S> reader) {
        return decodeEpochSeconds(source, reader, 0);
    }
    
    public <S> long decodeEpochSeconds(final S source, final ByteReader<? super S> reader, final int offset) {
        return dateDecoder.decodeEpochSeconds(source, reader, offset) + timeDecoder.decodeEpochSeconds(source, reader, offset + getTimeOffset());
    }

    public <S> long decodeEpochMillis(final S source, final ByteReader<? super S> reader) {
        return decodeEpochMillis(source, reader, 0);
    }
    public <S> long decodeEpochMillis(final S source, final ByteReader<? super S> reader, final int offset) {
        return dateDecoder.decodeEpochMillis(source, reader, offset) + timeDecoder.decodeEpochMillis(source, reader, offset + getTimeOffset());
    }

    public <S> long decodeEpochNanos(final S source, final ByteReader<? super S> reader) {
        return decodeEpochNanos(source, reader, 0);
    }
    public <S> long decodeEpochNanos(final S source, final ByteReader<? super S> reader, final int offset) {
        return dateDecoder.decodeEpochSeconds(source, reader, offset) * Epoch.NANOS_PER_SECOND + timeDecoder.decodeEpochNanos(source, reader, offset + getTimeOffset());
    }

    public <S> LocalDateTime decodeLocalDateTime(final S source, final ByteReader<? super S> reader) {
        return decodeLocalDateTime(source, reader, 0);
    }
    public <S> LocalDateTime decodeLocalDateTime(final S source, final ByteReader<? super S> reader, final int offset) {
        final int timeOffset = offset + getTimeOffset();
        final int year = dateDecoder.decodeYear(source, reader, offset);
        final int month = dateDecoder.decodeMonth(source, reader, offset);
        final int day = dateDecoder.decodeDay(source, reader, offset);
        final int hh = timeDecoder.decodeHour(source, reader, timeOffset);
        final int mm = timeDecoder.decodeMinute(source, reader, timeOffset);
        final int ss = timeDecoder.decodeSecond(source, reader, timeOffset);
        final int nn = timeDecoder.decodeNano(source, reader, timeOffset);
        if (nn == 0) {
            if (ss == 0) {
                if (year == 0 & month == 0 & day == 0 & hh == 0 & mm == 0) {
                    return null;
                }
                return LocalDateTime.of(year, month, day, hh, mm);
            }
            return LocalDateTime.of(year, month, day, hh, mm, ss);
        }
        return LocalDateTime.of(year, month, day, hh, mm, ss, nn);
    }

    public <S> int decodeYear(final S source, final ByteReader<? super S> reader) {
        return dateDecoder.decodeYear(source, reader);
    }

    public <S> int decodeYear(final S source, final ByteReader<? super S> reader, final int offset) {
        return dateDecoder.decodeYear(source, reader, offset);
    }

    public <S> int decodeMonth(final S source, final ByteReader<? super S> reader) {
        return dateDecoder.decodeMonth(source, reader);
    }

    public <S> int decodeMonth(final S source, final ByteReader<? super S> reader, final int offset) {
        return dateDecoder.decodeMonth(source, reader, offset);
    }

    public <S> int decodeDay(final S source, final ByteReader<? super S> reader) {
        return dateDecoder.decodeDay(source, reader);
    }

    public <S> int decodeDay(final S source, final ByteReader<? super S> reader, final int offset) {
        return dateDecoder.decodeDay(source, reader, offset);
    }

    public <S> int decodeHour(final S source, final ByteReader<? super S> reader) {
        return decodeHour(source, reader, 0);
    }

    public <S> int decodeHour(final S source, final ByteReader<? super S> reader, final int offset) {
        return timeDecoder.decodeHour(source, reader, offset + getTimeOffset());
    }

    public <S> int decodeMinute(final S source, final ByteReader<? super S> reader) {
        return decodeMinute(source, reader, 0);
    }

    public <S> int decodeMinute(final S source, final ByteReader<? super S> reader, final int offset) {
        return timeDecoder.decodeMinute(source, reader, offset + getTimeOffset());
    }

    public <S> int decodeSecond(final S source, final ByteReader<? super S> reader) {
        return decodeSecond(source, reader, 0);
    }

    public <S> int decodeSecond(final S source, final ByteReader<? super S> reader, final int offset) {
        return timeDecoder.decodeSecond(source, reader, offset + getTimeOffset());
    }

    public <S> int decodeNano(final S source, final ByteReader<? super S> reader) {
        return decodeNano(source, reader, 0);
    }

    public <S> int decodeNano(final S source, final ByteReader<? super S> reader, final int offset) {
        return timeDecoder.decodeNano(source, reader, offset + getTimeOffset());
    }

    public <S> char decodeDateTimeSeparator(final S source, final ByteReader<? super S> reader) {
        return decodeDateTimeSeparator(source, reader, 0);
    }
    public <S> char decodeDateTimeSeparator(final S source, final ByteReader<? super S> reader, final int offset) {
        return (char) reader.readByte(source, offset + getDateFormat().getLength());
    }

    private static Map<LocalDateFormat, Map<LocalTimeFormat, LocalDateTimeDecoder>> initDefaultDecoders() {
        final Map<LocalDateFormat, Map<LocalTimeFormat, LocalDateTimeDecoder>> map = new EnumMap<>(LocalDateFormat.class);
        LocalDateFormat.forEach(df -> {
            final Map<LocalTimeFormat, LocalDateTimeDecoder> timeFormatMap = new EnumMap<>(LocalTimeFormat.class);
            map.put(df, timeFormatMap);
            LocalTimeFormat.forEach(tf -> timeFormatMap.put(tf, new LocalDateTimeDecoder(df, tf)));
        });
        return map;
    }
}
