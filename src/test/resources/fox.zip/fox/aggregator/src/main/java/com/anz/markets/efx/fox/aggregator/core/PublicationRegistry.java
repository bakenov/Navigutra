package com.anz.markets.efx.fox.aggregator.core;

import com.anz.markets.efx.messaging.transport.api.Topic;

public interface PublicationRegistry {
    void registerPublication(Topic topic);
}
