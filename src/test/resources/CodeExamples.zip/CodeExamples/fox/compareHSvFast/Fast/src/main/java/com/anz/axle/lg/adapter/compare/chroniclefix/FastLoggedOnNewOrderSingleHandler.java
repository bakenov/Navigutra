package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.LongSupplier;

import net.openhft.chronicle.bytes.Bytes;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.SecurityType;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public final class FastLoggedOnNewOrderSingleHandler implements NewOrderSingleHandler {

    private final FixMessageSender fixMessageSender;
    private final LongSupplier receivedTimeNanosSupplier;

    private final NewOrderSingle newOrderSingle;

    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);

    private final Map<String, String> symbol7Map = new HashMap<>();

    private final String account;

    public FastLoggedOnNewOrderSingleHandler(final FixMessageSender fixMessageSender,
                                             final LongSupplier receivedTimeNanosSupplier,
                                             final String account) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.receivedTimeNanosSupplier = Objects.requireNonNull(receivedTimeNanosSupplier);
        this.account = Objects.requireNonNull(account);
        this.newOrderSingle = NewOrderSingle.newNewOrderSingle(Bytes.allocateElasticDirect(), fixMessageSender.context());
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.reset();
    }

    @Override
    public void onBody(final Body body) {

        newOrderSingle.symbol(symbol7(body));
        newOrderSingle.securityType(SecurityType.FOREIGN_EXCHANGE_CONTRACT);
        newOrderSingle.clOrdID(body.clOrdId().decodeStringOrNull());
        //ClientID is skipped but supported.
        newOrderSingle.side(side(body.side()));
        newOrderSingle.orderQty(body.orderQty());
        newOrderSingle.ordType(orderType(body.ordType()));
        //QuoteID is recommended but not provided by the pricing
        newOrderSingle.timeInForce(timeInForce(body.timeInForce()));
        if (body.ordType() == OrderType.LIMIT) {
            newOrderSingle.price(body.price());
        }
        newOrderSingle.currency(currency(body));
        newOrderSingle.transactTime(body.transactTime());
        newOrderSingle.account(account);
    }

    private String symbol7(final Body body) {
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        return symbol7Map.computeIfAbsent(symbol, SymbolNormaliser::toSymbol7);
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT: return OrdType.LIMIT;
            case MARKET: return OrdType.MARKET;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case FOK: return com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.TimeInForce.FILL_OR_KILL;
            case IOC: return com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.TimeInForce.IMMEDIATE_OR_CANCEL;
            case DAY: return com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.TimeInForce.DAY;
            default: throw new IllegalArgumentException("Unsupported timeInForce" + timeInForce);
        }
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Side.BUY;
            case SELL: return com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
    }
}
