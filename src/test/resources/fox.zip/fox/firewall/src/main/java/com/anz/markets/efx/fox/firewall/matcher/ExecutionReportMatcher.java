package com.anz.markets.efx.fox.firewall.matcher;

import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

public class ExecutionReportMatcher implements Predicate<ExecutionReportDecoder> {
    private static final String UNKNOWN = "unknown";

    private final ByteValueCache<String> stringsCache;
    private final Function<String, String> deskByUsername;

    private RuleMatcher ruleMatcher;

    public ExecutionReportMatcher(final ByteValueCache<String> stringsCache,
                                  final Function<String, String> deskByUsername,
                                  final RuleMatcher ruleMatcher) {
        this.stringsCache = Objects.requireNonNull(stringsCache);
        this.deskByUsername = Objects.requireNonNull(deskByUsername);
        this.ruleMatcher = Objects.requireNonNull(ruleMatcher);
    }

    @Override
    public boolean test(final ExecutionReportDecoder executionReport) {
        final ExecutionReportDecoder.Body body = executionReport.body();

        final String targetStrategy = body.targetStrategyName().decodeAndCache(stringsCache);
        final SecurityType securityType = body.securityType();
        final Tenor tenor = body.settlType();
        final String symbol = body.symbol().decodeAndCache(stringsCache);

        String username = UNKNOWN;
        String portfolio = UNKNOWN;
        String region = UNKNOWN;
        String markets = UNKNOWN;

        final ExecutionReportDecoder.Party paties = executionReport.parties();

        for (ExecutionReportDecoder.Party party : paties) {
            switch (party.partyRole()){
                case USER_NAME:
                    username = party.partyId().decodeAndCache(stringsCache);
                    break;
                case PORTFOLIO:
                    portfolio = party.partyId().decodeAndCache(stringsCache);
                    break;
                case TARGET_REGION:
                    region = party.partyId().decodeAndCache(stringsCache);
                    break;
                default:
                    party.partyId().decodeToNull();
            }
        }
        final String desk = deskByUsername.apply(username);
        final ExecutionReportDecoder.StrategyParameter strategyParameters = executionReport.strategyParameters();

        for (ExecutionReportDecoder.StrategyParameter strategyParameter : strategyParameters) {
            final String paramName = strategyParameter.strategyParameterName().decodeAndCache(stringsCache);
            switch (paramName){
                case "Markets" :
                    markets = strategyParameter.strategyParameterValue().decodeAndCache(stringsCache);
                    break;
                default:
                    strategyParameter.strategyParameterValue().decodeToNull();
            }
        }

        return ruleMatcher.match(region, desk, targetStrategy, portfolio, username, markets, securityType, tenor, symbol);
    }
}
