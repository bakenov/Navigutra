package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import com.anz.markets.prophet.pricer.pfp.features.CapBankSkewFeatureSpecs;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_471})
public class ModelSpread_Bank_Skew_Feature_Test extends BaseAcceptanceSpecification {
    private ConfigurationDataDefault setUpConfiguration(double maxRisk, double offset, final Markets bankMarkets, final Markets refMarkets) {

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        CapBankSkewFeatureSpecs specs = CapBankSkewFeatureSpecs.INSTANCE;

        // set up config for WSP_B ONLY
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_B,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_BANK_MARKETS, bankMarkets,
                specs.PARAM_REF_MARKETS, refMarkets,
                specs.PARAM_GRADIENT_POS_THRESHOLD_USD, maxRisk,
                specs.PARAM_OUTSIDE_OFFSET_PIPS, offset)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_BANK_MARKETS, null,
                specs.PARAM_REF_MARKETS, null,
                specs.PARAM_GRADIENT_POS_THRESHOLD_USD, Double.NaN,
                specs.PARAM_OUTSIDE_OFFSET_PIPS, Double.NaN)
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET, new Instrument[]{Instrument.AUDUSD}))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.2, 0.5),
                        new NetOpenPositionSkewRatioConfigImpl(0.5, 0.7),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.9)
                ))
                .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(10_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(10_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(10_000_000)
                ))
                .setPricingModels(
                        Arrays.asList(
                                new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                        ));

        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME,priceFormationPipelineConfig);

        return configuration;
    }

    @Test
    public void shortPosition_positiveBankSkewWithImpact() {
        final String dominantFeature;
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(12_000_000.0, 0.1, Markets.getMarkets(Market.BARX), Markets.getMarkets(Market.RFX)), false);
        }
        when:
        {
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        {
            // send reference market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.RFX, Instrument.AUDUSD, 0.75098, 0.75107));
            // send bank market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75099, 0.75109));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // Bank skew is positive. (note, Bank Bid == Adjusted Ref Bid but due to double comparisons Bank Bid is > Adjusted Ref Bid)
        // WSP_B Offer < Banks offer 0.75109, so widen WSP_B offer(only) up to Banks offer
        {
            // WSP_A prices unchanged
            WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            // WSP_B wholesalebook factors impacted by bank skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.25));
            assertThat(wbf_wspB.getBidSpreadModelSpreadRatio(), isNear(0.375));
            assertThat(wbf_wspB.getOfferSpreadModelSpreadRatio(), isNear(0.625));
            assertThat(wbf_wspB.getOverallWideningFactor(), isNear(1.33333));

            FeatureTraceLine ftl = wbf_wspB.getPliableBookTrace().getFeatureTrace(CapBankSkewFeatureSpecs.NAME);
            dominantFeature = ftl.featureShortCode;
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.CAP_OFFER_VIA_SPREAD));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.OFFER_PRICE));
            assertThat(ftl.operations[0].oldVal, is(0.75108));
            assertThat(ftl.operations[0].newVal, is(0.75109));
            assertThat(ftl.data[0].var.toString(), is("refsBid"));
            assertThat(ftl.data[0].fx, is(0.75098));
            assertThat(ftl.data[1].var.toString(), is("refsAsk"));
            assertThat(ftl.data[1].fx, is(0.75107));
        }
        and:
        // new WSP_B client price
        {
            ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
            assertThat(clientPriceWSPB, isClientPricePoint(0, Level.QTY_1M, 0.7510500, 0.7510900));
            assertThat(clientPriceWSPB, isClientPricePoint(1, Level.QTY_2M, 0.7510350, 0.7511150));
            assertThat(clientPriceWSPB, isClientPricePoint(2, Level.QTY_2M, 0.7510275, 0.7511275));
            assertThat(clientPriceWSPB, isClientPricePoint(3, Level.QTY_5M, 0.7510150, 0.7511483));
            assertThat(clientPriceWSPB, isClientPricePoint(4, Level.QTY_5M, 0.7509575, 0.7512442));
            assertThat(clientPriceWSPB, isClientPricePoint(5, Level.QTY_5M, 0.7509125, 0.7513192));
            assertThat(clientPriceWSPB, isClientPricePoint(6, Level.QTY_10M, 0.7508450, 0.7514317));
            assertThat(clientPriceWSPB, isClientPricePoint(7, Level.QTY_10M, 0.7508150, 0.7514817));
            assertThat(clientPriceWSPB, isClientPricePoint(8, Level.QTY_10M, 0.7507175, 0.7516442));
            assertThat(clientPriceWSPB.getDominantFeatureBid().toString(), is(WholesaleBookFactorsImpl.INIT_FEATURE_NAME));
            assertThat(clientPriceWSPB.getDominantFeatureOffer().toString(), is(dominantFeature));
        }
    }

    @Test
    public void shortPosition_positiveBankSkewWithNoImpact() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(12_000_000.0, 0.1, Markets.getMarkets(Market.BARX), Markets.getMarkets(Market.RFX)), false);
        }
        when:
        {
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        {
            // send reference market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.RFX, Instrument.AUDUSD, 0.75097, 0.751068));
            // send bank market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75099, 0.751079));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00002));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // Bank skew is positive. Bank Bid is > Adjusted Ref Bid 0.75098, Bank Offer is > Adjusted Ref Offer 0.751078
        // WSP_B Offer > Banks offer 0.751079, so NO IMPACT
        {
            // WSP_A prices unchanged
            WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            // WSP_B wholesalebook factors not impacted by bank skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspB.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            FeatureTraceLine ftl = wbf_wspB.getPliableBookTrace().getFeatureTrace(CapBankSkewFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftl.getNumOperationLines(), is(0));

            assertThat(ftl.data[0].var.toString(), is("refsBid"));
            assertThat(ftl.data[0].fx, is(0.75097));
            assertThat(ftl.data[1].var.toString(), is("refsAsk"));
            assertThat(ftl.data[1].fx, is(0.751068));

            assertThat(ftl.data[2].var.toString(), is("banksBid"));
            assertThat(ftl.data[2].fx, is(0.75099));
            assertThat(ftl.data[3].var.toString(), is("banksAsk"));
            assertThat(ftl.data[3].fx, is(0.751079));
        }
        and:
        {
            ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
            assertThat(clientPriceWSPB.getDominantFeatureBid().toString(), is(WholesaleBookFactorsImpl.INIT_FEATURE_NAME));
            assertThat(clientPriceWSPB.getDominantFeatureOffer().toString(), is(WholesaleBookFactorsImpl.INIT_FEATURE_NAME));
        }
    }

    @Test
    public void shortPosition_positiveBankSkewBelowBidThresholdNoImpact() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(12_000_000.0, 0.11, Markets.getMarkets(Market.BARX), Markets.getMarkets(Market.RFX)), false);
            // ^^ threshold 0.11
        }
        when:
        {
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        {
            // send reference market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.RFX, Instrument.AUDUSD, 0.75098, 0.75107));
            // send bank market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75099, 0.75109));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // No positive bank skew: Bank Bid is < Adjusted Ref Bid 0.750991, Bank Offer is > Adjusted Ref Offer 0.751081
        // No negative bank skew: Bank Bid is > Adjusted Ref Bid 0.750969, Bank Offer is > Adjusted Ref Offer 0.751059
        {
            // WSP_A prices unchanged
            WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            // WSP_B wholesalebook factors and prices not impacted by bank skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspB.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            FeatureTraceLine ftl = wbf_wspB.getPliableBookTrace().getFeatureTrace(CapBankSkewFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.getNumOperationLines(), is(0));
        }

    }

    public void risk_position_skew_on_short_position() {
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003));
            prophet.clearOutputBuffer();
            // send client deal to generate SHORT AUD position
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -10_500_000, 78.420));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), is(-11_828_250.0)); // below PARAM_GRADIENT_POS_THRESHOLD_USD
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        {
            short_position_wsp_a_b_price_same();
        }
    }

    public void short_position_wsp_a_b_price_same() {
        WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
        assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751065));
        assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
        assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
        assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
        assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

        WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
        assertThat(wbf_wspA.getSkewedMidPrice() == wbf_wspB.getSkewedMidPrice(), is(true));
        assertThat(wbf_wspA.getOverallBidSpreadInPips() == wbf_wspB.getOverallBidSpreadInPips(), is(true));
        assertThat(wbf_wspA.getOverallOfferSpreadInPips() == wbf_wspB.getOverallOfferSpreadInPips(), is(true));
        assertThat(wbf_wspA.getBidSpreadModelSpreadRatio() == wbf_wspB.getBidSpreadModelSpreadRatio(), is(true));
        assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio() == wbf_wspB.getOfferSpreadModelSpreadRatio(), is(true));

        ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
        assertThat(clientPriceWSPB, isClientPricePoint(0, Level.QTY_1M, 0.7510500, 0.7510800));
        assertThat(clientPriceWSPB, isClientPricePoint(1, Level.QTY_2M, 0.7510350, 0.7510950));
        assertThat(clientPriceWSPB, isClientPricePoint(2, Level.QTY_2M, 0.7510275, 0.7511025));
        assertThat(clientPriceWSPB, isClientPricePoint(3, Level.QTY_5M, 0.7510150, 0.7511150));
        assertThat(clientPriceWSPB, isClientPricePoint(4, Level.QTY_5M, 0.7509350, 0.7511950));
        assertThat(clientPriceWSPB, isClientPricePoint(5, Level.QTY_5M, 0.7508750, 0.7512550));
        assertThat(clientPriceWSPB, isClientPricePoint(6, Level.QTY_10M, 0.7507850, 0.7513450));
        assertThat(clientPriceWSPB, isClientPricePoint(7, Level.QTY_10M, 0.7507450, 0.7513850));
        assertThat(clientPriceWSPB, isClientPricePoint(8, Level.QTY_10M, 0.7506150, 0.7515150));
    }

    @Test
    public void shortPosition_configChangePreservesListeners() {

        shortPosition_positiveBankSkewWithImpact();

        prophet.resetAllPricingState();
        shortPosition_positiveBankSkewWithImpact();

        prophet.resetAllPricingState();
        shortPosition_positiveBankSkewWithImpact();
    }



}
