#!/bin/bash

echo "Killing everything on Burgundy AU"
ssh AxlSv@daxa005z "ps -ef | egrep '(java|iaf|munin-node|corr|stunnel|mstats)' | egrep -v '(grep|delta|pdc|mahi/apps|prophet)' | awk '{ print \$2 }' | xargs -I {} kill -9 {}; echo 'Killed (java|iaf|munin-node|corr|stunnel|mstats)'"
ssh AxlSv@daxa005z "find ~/logs -type f -name '*pid*' -exec rm -rf {} \;; rm -f ~/apache-tomcat*/conf/pid;  echo Removed PID files"

