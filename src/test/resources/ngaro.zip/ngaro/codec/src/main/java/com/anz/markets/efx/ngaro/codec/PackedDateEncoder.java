package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.function.IntConsumer;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

public final class PackedDateEncoder<E> implements DateEncoder<E> {

    public interface Consumer {
        void set(LocalDatePacking packing, int value);
    }

    private final E enclosingEncoder;
    private final Consumer consumer;

    public PackedDateEncoder(final E enclosingEncoder, final Consumer consumer) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.consumer = Objects.requireNonNull(consumer);
    }

    public static <E> PackedDateEncoder<E> forPackedDateConsumer(final E enclosingEncoder, final Consumer packedDateConsumer) {
        return new PackedDateEncoder<>(enclosingEncoder, packedDateConsumer);
    }

    public static <E> PackedDateEncoder<E> forBinaryPackedConsumer(final E enclosingEncoder, final IntConsumer binaryPackedDateConsumer) {
        Objects.requireNonNull(binaryPackedDateConsumer);
        return forPackedDateConsumer(enclosingEncoder, (packing, value) -> binaryPackedDateConsumer.accept(
                LocalDatePacking.BINARY.repack(value, packing))
        );
    }

    public static <E> PackedDateEncoder<E> forDecimalPackedDateConsumer(final E enclosingEncoder, final IntConsumer decimalPackedDateConsumer) {
        Objects.requireNonNull(decimalPackedDateConsumer);
        return forPackedDateConsumer(enclosingEncoder, (packing, value) -> decimalPackedDateConsumer.accept(
                LocalDatePacking.DECIMAL.repack(value, packing))
        );
    }

    @Override
    public E encodeNull() {
        consumer.set(LocalDatePacking.BINARY, 0);
        return enclosingEncoder;
    }

    @Override
    public E encode(final int year, final int month, final int day) {
        if (year == 0 & month == 0 & day == 0) {
            return encodeNull();
        }
        consumer.set(LocalDatePacking.BINARY, LocalDatePacking.BINARY.pack(year, month, day));
        return enclosingEncoder;
    }

    @Override
    public E encodeEpochDays(final long epochDays) {
        if (epochDays == 0) {
            return encodeNull();
        }
        consumer.set(LocalDatePacking.BINARY, Epoch.fromEpochDays(LocalDatePacking.BINARY, epochDays));
        return enclosingEncoder;
    }
}