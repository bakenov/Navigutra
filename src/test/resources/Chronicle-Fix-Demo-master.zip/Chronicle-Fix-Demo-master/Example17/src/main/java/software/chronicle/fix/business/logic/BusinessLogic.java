package software.chronicle.fix.business.logic;

import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.NewOrderSingle;

public interface BusinessLogic {
    void onExecutionReport(ExecutionReport executionReport);

    void onNewOrderSingle(NewOrderSingle newOrderSingle);
}
