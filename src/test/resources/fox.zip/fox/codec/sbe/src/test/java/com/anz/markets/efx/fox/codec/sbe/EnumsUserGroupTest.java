package com.anz.markets.efx.fox.codec.sbe;

import java.lang.reflect.Method;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.UserGroupsDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserGroupsEncoder;
import static org.junit.Assert.assertEquals;

/**
 * Test consistency between {@link UserGroup} and UserGroups choice generated from SBE file.
 */
public class EnumsUserGroupTest {

    @Test
    public void userGroupCountMatches() {
        int count = 0;
        for (final Method method : UserGroupsEncoder.class.getMethods()) {
            if (method.getReturnType() == UserGroupsEncoder.class && method.getParameterCount() == 1 && method.getParameterTypes()[0] == boolean.class) {
                count++;
            }
        }
        assertEquals("userGroup count should be same", UserGroup.length(), count);
    }

    @Test
    public void userGroupEncodeDifferentValues() {
        //given
        final MutableDirectBuffer buf = new ExpandableArrayBuffer(8);
        final UserGroupsEncoder enc = new UserGroupsEncoder();
        enc.wrap(buf, 0);

        //when
        for (int i = 0; i < UserGroup.length(); i++) {
            Enums.userGroup(UserGroup.valueByOrdinal(i), enc, true);
        }

        //then
        assertEquals("each userGroup should set one bit", UserGroup.length(), bitCount(buf.byteArray()));

        //when
        for (int i = 0; i < UserGroup.length(); i++) {
            Enums.userGroup(UserGroup.valueByOrdinal(i), enc, false);
        }

        //then
        assertEquals("all bits should have been cleared", 0, bitCount(buf.byteArray()));
    }

    @Test
    public void encodeAndDecode() {
        //given
        final MutableDirectBuffer buf = new ExpandableArrayBuffer(8);
        final UserGroupsEncoder enc = new UserGroupsEncoder();
        final UserGroupsDecoder dec = new UserGroupsDecoder();
        enc.wrap(buf, 0);
        dec.wrap(buf, 0);

        for (int i = 0; i < UserGroup.length(); i++) {
            //when
            Enums.userGroup(UserGroup.valueByOrdinal(i), enc, true);

            //then
            assertEquals("1 bit should be set", 1, bitCount(buf.byteArray()));

            for (int j = 0; j < UserGroup.length(); j++) {
                //when
                final boolean set = Enums.userGroup(UserGroup.valueByOrdinal(j), dec);
                //then
                assertEquals("flag value not as expected", i==j, set);
            }

            //when
            Enums.userGroup(UserGroup.valueByOrdinal(i), enc, false);

            //then
            assertEquals("no bits should be set", 0, bitCount(buf.byteArray()));
        }
    }

    private static int bitCount(final byte[] bytes) {
        int count = 0;
        for (final byte b : bytes) {
            count += Integer.bitCount(b & 0xff);
        }
        return count;
    }
}
