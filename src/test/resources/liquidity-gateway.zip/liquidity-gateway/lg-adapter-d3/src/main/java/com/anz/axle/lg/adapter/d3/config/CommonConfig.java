package com.anz.axle.lg.adapter.d3.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MetricRepositoryFactory;
import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.metric.MetricRepository;

@Configuration
public class CommonConfig {
    @Bean
    public PrecisionClock precisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public SourceSequencer sourceSequencer(@Value("${messaging.${venue}.source.id}") final int sourceId) {
        return SourceSequencer.of(sourceId);
    }

    @Bean
    public MetricRepository<Metric, Venue> metricRepository() {
        return MetricRepositoryFactory.defaultMetricRepository();
    }
}
