package com.anz.markets.efx.ngaro.collections;

import org.junit.Test;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class EnumBooleanMapImplTest {

    @Test
    public void basic_operations() {
        final EnumBooleanMap<AnimalEnum> unit = new EnumBooleanMap<>(AnimalEnum.class);

        assertFalse(unit.containsKey(AnimalEnum.DOG));
        assertEquals(0, unit.size());

        // Default value test
        assertFalse(unit.get(AnimalEnum.DOG));

        // Put with no prior value
        assertNull(unit.put(AnimalEnum.DOG, true));
        assertTrue(unit.get(AnimalEnum.DOG));
        assertEquals(1, unit.size());

        // Put with new false value
        assertTrue(unit.put(AnimalEnum.DOG, false));
        assertFalse(unit.get(AnimalEnum.DOG));
        assertEquals(1, unit.size());

        // Put with new true value
        assertFalse(unit.put(AnimalEnum.DOG, true));
        assertEquals(1, unit.size());

        // Remove something
        assertTrue(unit.remove(AnimalEnum.DOG));
        assertEquals(0, unit.size());

        // Remove nothing
        assertFalse(unit.remove(AnimalEnum.DOG));
        assertEquals(0, unit.size());

        // Set more than 1 values
        unit.set(AnimalEnum.DOG, true);
        unit.set(AnimalEnum.CAT, false);
        assertTrue(unit.containsKey(AnimalEnum.DOG));
        assertTrue(unit.containsKey(AnimalEnum.CAT));
        assertFalse(unit.containsKey(AnimalEnum.HIPPO));
        assertEquals(2, unit.size());
        assertFalse(unit.isEmpty());

        // Clear
        unit.clear();
        assertEquals(0, unit.size());
        assertTrue(unit.isEmpty());

        // Set twice
        unit.set(AnimalEnum.DOG, true);
        unit.set(AnimalEnum.DOG, true);
        assertEquals(1, unit.size());

        // Key type
        assertEquals(AnimalEnum.class, unit.getKeyType());
    }

    @Test
    public void basic_operations_default_content_true() {
        final EnumBooleanMap<AnimalEnum> unit = new EnumBooleanMap<>(AnimalEnum.class, true);

        // Default true
        assertTrue(unit.get(AnimalEnum.HIPPO));

        for (AnimalEnum value : AnimalEnum.VALUES) {
            unit.set(value, false);
        }

        // Full size
        assertEquals(unit.size(), AnimalEnum.VALUES.length);
        assertFalse(unit.get(AnimalEnum.HIPPO));

        // Clear
        unit.clear();
        assertEquals(0, unit.size());

        // Back to default value
        assertTrue(unit.get(AnimalEnum.HIPPO));
    }

    @Test
    public void consumer() {
        final EnumBooleanMap<AnimalEnum> instrumentConfigMap = new EnumBooleanMap<>(AnimalEnum.class);
        instrumentConfigMap.set(AnimalEnum.CAT, true);
        instrumentConfigMap.set(AnimalEnum.DOG, true);
        instrumentConfigMap.set(AnimalEnum.HIPPO, false);

        final AtomicInteger consumeCount = new AtomicInteger(0);

        // For-each consumer
        instrumentConfigMap.forEach((instrument, value) -> {
            switch (instrument) {
                case CAT:
                    assertTrue(value);
                    break;
                case DOG:
                    assertTrue(value);
                    break;
                case HIPPO:
                    assertFalse(value);
                    break;
            }
            consumeCount.incrementAndGet();
        });
        assertEquals(3, consumeCount.get());
    }

    @Test
    public void equality() {
        final EnumBooleanMap<AnimalEnum> leftMap = new EnumBooleanMap<>(AnimalEnum.class);
        final EnumBooleanMap<AnimalEnum> rightMap = new EnumBooleanMap<>(AnimalEnum.class);

        assertTrue(leftMap.equals(rightMap));

        rightMap.set(AnimalEnum.DOG, true);
        assertFalse(leftMap.equals(rightMap));

        leftMap.set(AnimalEnum.DOG, true);
        assertTrue(leftMap.equals(rightMap));
    }
}