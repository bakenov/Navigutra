package com.anz.markets.efx.ngaro.core;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link ByteValueCache}
 */
public class ByteValueCacheTest {

    @Test
    public void lookupOrCache() throws Exception {
        //given
        final int cacheSize = 3;
        final int stringLength = 7;
        final int offset = 3;
        final CharSequence input1 = "abc123456jklmno";
        final CharSequence input2 = "abcXYZ\0\0\0jklmno";
        final CharSequence input3 = "abcHey\0\0jklmno";
        final CharSequence input4 = "abcJay\0\0jklmno";
        final int length1 = 6;
        final int length2 = 3;
        final int length3 = 3;
        final int length4 = 3;
        final ByteValueCache<String> byteValueCache = new ByteValueCache<>(AsciiString::toString, stringLength, cacheSize);

        //when
        final String output1 = byteValueCache.lookupOrCache(input1, ByteReader.CHAR_SEQUENCE, offset, length1);

        //then
        assertEquals("output1 should be 123456", "123456", output1);
        assertEquals("cache should contain 1 value", 1, byteValueCache.getCacheSize());
        assertTrue("cache contains value 123456", byteValueCache.isCached("123456"));

        //when
        final String output2 = byteValueCache.lookupOrCache(input2, ByteReader.CHAR_SEQUENCE, offset, length2);

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);
        assertEquals("cache should contain 2 values", 2, byteValueCache.getCacheSize());
        assertTrue("cache contains value XYZ", byteValueCache.isCached("XYZ"));

        //when
        final String output3 = byteValueCache.lookupOrCache(input1, ByteReader.CHAR_SEQUENCE, offset, length1);
        final String output4 = byteValueCache.lookupOrCache(input2, ByteReader.CHAR_SEQUENCE, offset, length2);

        //then
        assertEquals("cache should still contain 2 values", 2, byteValueCache.getCacheSize());
        assertSame("output3 should same instance as output1", output1, output3);
        assertSame("output4 should same instance as output2", output2, output4);

        //when
        final String output5 = byteValueCache.lookupOrCache(input3, ByteReader.CHAR_SEQUENCE, offset, length3);
        final String output6 = byteValueCache.lookupOrCache(input4, ByteReader.CHAR_SEQUENCE, offset, length4);

        //then
        assertEquals("output5 should be Hey", "Hey", output5);
        assertEquals("output6 should be Jay", "Jay", output6);
        assertEquals("cache should contain 3 values", 3, byteValueCache.getCacheSize());
        assertTrue("cache contains value Hey", byteValueCache.isCached("Hey"));
        assertTrue("cache contains value Jay", byteValueCache.isCached("Jay"));
    }

    @Test
    public void cacheAndClear() throws Exception {
        //given
        final int symbolLength = 7;
        final ByteValueCache<String> byteValueCache = new ByteValueCache<>(AsciiString::toString);

        //when: cache some values
        byteValueCache.lookupOrCache("AUD/USD", ByteReader.CHAR_SEQUENCE, symbolLength);
        byteValueCache.lookupOrCache("AUD/JPY", ByteReader.CHAR_SEQUENCE, symbolLength);
        byteValueCache.lookupOrCache("NZD/AUD", ByteReader.CHAR_SEQUENCE, symbolLength);

        //then
        assertEquals("cache size should be 3", 3, byteValueCache.getCacheSize());
        assertTrue("AUD/USD should be cached", byteValueCache.isCached("AUD/USD"));
        assertTrue("AUD/JPY should be cached", byteValueCache.isCached("AUD/JPY"));
        assertTrue("NZD/AUD should be cached", byteValueCache.isCached("NZD/AUD"));
        assertTrue("AUD/USD bytes should be cached", byteValueCache.isCached("AUD/USD", ByteReader.CHAR_SEQUENCE, symbolLength));
        assertTrue("AUD/JPY bytes should be cached", byteValueCache.isCached("AUD/JPY", ByteReader.CHAR_SEQUENCE, symbolLength));
        assertTrue("NZD/AUD bytes should be cached", byteValueCache.isCached("NZD/AUD", ByteReader.CHAR_SEQUENCE, symbolLength));

        //when
        byteValueCache.clearCache();

        //then
        assertEquals("cache size should be 0", 0, byteValueCache.getCacheSize());
        assertFalse("AUD/USD should not be cached", byteValueCache.isCached("AUD/USD"));
        assertFalse("AUD/JPY should not be cached", byteValueCache.isCached("AUD/JPY"));
        assertFalse("NZD/AUD should not be cached", byteValueCache.isCached("NZD/AUD"));
        assertFalse("AUD/USD bytes should not be cached", byteValueCache.isCached("AUD/USD", ByteReader.CHAR_SEQUENCE, symbolLength));
        assertFalse("AUD/JPY bytes should not be cached", byteValueCache.isCached("AUD/JPY", ByteReader.CHAR_SEQUENCE, symbolLength));
        assertFalse("NZD/AUD bytes should not be cached", byteValueCache.isCached("NZD/AUD", ByteReader.CHAR_SEQUENCE, symbolLength));
    }
}