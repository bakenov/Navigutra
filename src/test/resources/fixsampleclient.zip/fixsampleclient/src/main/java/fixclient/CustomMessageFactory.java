// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.IOException;

import quickfix.DefaultMessageFactory;
import quickfix.Message;
import quickfix.field.MsgType;
import quickfix.field.NewPassword;
import quickfix.field.Password;
import quickfix.field.Username;

/**
 * This class is inserted into the QuickFIX socket initiator in order to add
 * Branch LOGON credentials when they've been set in the FIXConfig properties.
 */
public class CustomMessageFactory extends DefaultMessageFactory
{
    /**
     * Overrides the default create method to add credentials.
     * 
     * @see quickfix.DefaultMessageFactory#create(java.lang.String,
     *      java.lang.String)
     */
    @Override
    public Message create(final String beginString, final String msgType)
    {
        final Message retval = super.create(beginString, msgType);
        if (msgType.equals(MsgType.LOGON))
        {
            try
            {
                // Set user name and password if this is an authenticated logon
                final String fixLogonUserName = FIXConfig.getAuthenticatedFixSessionUserName();
                if (fixLogonUserName != null && !fixLogonUserName.equals(""))
                {
                    retval.setString(Username.FIELD, fixLogonUserName);
                }

                final String fixLogonPassword = FIXConfig.getAuthenticatedFixSessionPassword();
                if (fixLogonPassword != null && !fixLogonPassword.equals(""))
                {
                    retval.setString(Password.FIELD, fixLogonPassword);
                }

                final String fixLogonNewPassword = FIXConfig.getAuthenticatedFixSessionNewPassword();
                if (fixLogonNewPassword != null
                        && !fixLogonNewPassword.equals(""))
                {
                    retval.setString(NewPassword.FIELD, fixLogonNewPassword);
                }

                // Set Default Application details.
                // QuickFix does not implement DefaultApplExtID so hard-code
                // the FIELD ID DefaultApplExtID.FIELD = 1407
                /*
                 * retval.setInt(1407, QuickFixConfig.getDefaultApplExtID()
                 * .intValue());
                 */

            }
            catch (final IOException e)
            {
                System.err.println("Could not retrieve credentials: " + e);
            }
        }
        return retval;
    }
}
