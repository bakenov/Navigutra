package com.anz.axle.lg.adapter.rfx.acceptance;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.fix.sessioncode.messages.Logout;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.FixSessionHandler;

import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.MarketDataRequest;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultExecutionReport;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultLogon;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultLogout;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultMarketDataRequest;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultReject;
import com.anz.axle.lg.adapter.rfx.chroniclefix.generated.messages.datamodel.DefaultUserRequest;

public class TestMessageNotifier implements MessageNotifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(TestMessageNotifier.class);
    private final BlockingQueue<StandardHeaderTrailer> queue = new ArrayBlockingQueue<>(1024);

    public BlockingQueue<StandardHeaderTrailer> queue() {
        return queue;
    }

    private void queue(final StandardHeaderTrailer original, final StandardHeaderTrailer copy) {
        copyTo(original, copy);
        LOGGER.info("Sending to client:  {}", copy);
        queue.add(copy);
    }

    private StandardHeaderTrailer copyTo(final StandardHeaderTrailer from, final StandardHeaderTrailer to) {
        from.copyTo(to);
        return to;
    }

    @Override
    public void onLogon(final FixSessionHandler session, final Logon logon) {
        LOGGER.info("onLogon()    {}", logon);
        queue(logon, new DefaultLogon());
    }

    @Override
    public void onExecutionReport(final FixSessionHandler session, final ExecutionReport executionReport) {
        LOGGER.info("onExecutionReport()    {}", executionReport);
        queue(executionReport, new DefaultExecutionReport());
    }

    @Override
    public void onReject(final FixSessionHandler session, final Reject reject) {
        LOGGER.info("onReject()    {}", reject);
        queue(reject, new DefaultReject());
    }

    @Override
    public void onNewOrderSingle(final FixSessionHandler session, final NewOrderSingle newOrderSingle) {
        LOGGER.info("onNewOrderSingle()    {}", newOrderSingle);
        queue(newOrderSingle, new DefaultNewOrderSingle());
    }

    @Override
    public void onLogout(final FixSessionHandler session, final Logout logout) {
        LOGGER.info("onLogout()    {}", logout);
        queue(logout, new DefaultLogout());
    }

    @Override
    public void onUserRequest(final FixSessionHandler session, final UserRequest userRequest) {
        LOGGER.info("onUserRequest()    {}", userRequest);
        queue(userRequest, new DefaultUserRequest());
    }

    @Override
    public void onMarketDataRequest(final FixSessionHandler session, final MarketDataRequest marketDataRequest) {
        queue(marketDataRequest, new DefaultMarketDataRequest());
    }

    @Override
    public void onOrderCancelRequest(final FixSessionHandler session, final OrderCancelRequest orderCancelRequest) {
        queue(orderCancelRequest, new DefaultOrderCancelRequest());
    }

    @Override
    public void onUnsupportedMessageType(final FixSessionHandler session, final int msgType) {
        LOGGER.error("onUnsupportedMessageType |{}| received!", msgType);
    }
}
