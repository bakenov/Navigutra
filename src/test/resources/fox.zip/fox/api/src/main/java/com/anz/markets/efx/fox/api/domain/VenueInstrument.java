package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface VenueInstrument {
    int NULL_MD_ENTRY_INDEX = -1;

    Instrument instrument();
    Venue venue();
    RequestKey requestKey();
    MarketDataBook marketDataBook();
    double priceIncrement();
    int sizeIncrement();
    int clipSizeMultiple();
    double maxAllowedParentOrderQty();
    int minClipSize();
    int maxClipSize();
    int staleDataTimeout();
    int priority();
    int proportion();
    boolean enabled();

    int topBidIndex();
    int topAskIndex();
    void topBidIndex(int index);
    void topAskIndex(int index);
    MarketDataEntry topBid();
    MarketDataEntry topAsk();
}
