package com.anz.axle.lg.adapter.apama.decoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDateTimeDecoder;
import com.anz.markets.efx.ngaro.time.LocalTimeFormat;

/**
 * Converts datetimestamp string into nanoseconds since the epoch.
 *
 * Input value must be a UTC date.
 *
 * Input value must be in either seconds format "yyyyMMdd-HH:mm:ss" or milliseconds format "yyyyMMdd-HH:mm:ss.SSS".
 *
 */
public final class UtcTimestampConverter {
    private static final Logger LOGGER = LoggerFactory.getLogger(UtcTimestampConverter.class);

    // support time formats with and without ms values
    private static LocalDateTimeDecoder TIMESTAMP_DECODER_SECONS = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYYMMDD, LocalTimeFormat.HH_MM_SS);
    private static LocalDateTimeDecoder TIMESTAMP_DECODER_MILLIS = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYYMMDD, LocalTimeFormat.HH_MM_SS_MMM);

    /**
     * Convert a timestamp string into nanoseconds since the epoch.
     *
     * @param value the timestamp String
     * @return nanoseconds, or zero if could not parse.
     */
    public static long dateTimeToNanos(String value) {
        try {
            final LocalDateTimeDecoder decoder = dateTimeDecoderFor(value);
            return decoder.decodeEpochNanos(value, ByteReader.CHAR_SEQUENCE);
        } catch (Exception ex) {
            LOGGER.warn("Exception occurred while converting timestamp string: " + value, ex);
            return 0;
        }
    }

    private static LocalDateTimeDecoder dateTimeDecoderFor(final String value) {
        return value.indexOf('.') > -1 ? TIMESTAMP_DECODER_MILLIS : TIMESTAMP_DECODER_SECONS;
    }

}
