package com.anz.markets.efx.fox.codec.api;

import java.util.function.Consumer;

public enum Region {
    GB, JP, AU;

    private static final Region[] VALUES = values();

    public static final int length() {
        return VALUES.length;
    }

    public static final Region valueByOrdinal(final int ordinal) {
        return VALUES[ordinal];
    }

    public static void forEach(final Consumer<? super Region> consumer) {
        for (final Region value : VALUES) {
            consumer.accept(value);
        }
    }
}
