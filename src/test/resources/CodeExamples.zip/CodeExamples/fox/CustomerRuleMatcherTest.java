package com.anz.markets.efx.fox.firewall.rule.customer;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.LongSupplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.api.PropertyProvider;
import com.anz.markets.efx.ngaro.codec.SimpleStringDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CustomerRuleMatcherTest {

    private static final long TIMEOUT = 1;
    private static final TimeUnit TIME_UNIT = TimeUnit.SECONDS;
    private static final String NAME = "Firewall";
    private static final String GENERAL_PATTERN = ".*";
    private static final String COMMENT_1 = "STALE_ORDER";
    private static final String COMMENT_2 = "STALE_ORDER ; DUMMY";
    private static final String COMMENT_3 = "Comment";
    private static final String COMMENT_4 = "Comment ; extra comment";
    private static final String COMMENT_5 = "stale_order   ;duMMY";

    @Mock
    private FirewallConfigDecoder ruleConfig;
    @Mock
    private EventContext eventContext;

    private LongSupplier timeSupplier;
    private PropertyProvider properties;
    private CustomerRuleMatcher ruleMatcher;
    private Function<String, String> deskByUsername;
    private CustomerRuleFactory factory;
    private FirewallConfigDecoder.Body body;

    @BeforeEach
    void setUp() {
        properties = (k) -> {
            switch (k) {
                case StaleOrderRule.TIMEOUT_THRESHOLD_PROPERTY_NAME:
                    return Long.toString(TIMEOUT);
                case StaleOrderRule.TIMEOUT_TIME_UNIT_PROPERTY_NAME:
                    return TIME_UNIT.name();
                default:
                    return null;
            }
        };
        timeSupplier = () -> System.nanoTime();
        deskByUsername = (n) -> n;

        factory = new CustomerRuleFactoryImpl(timeSupplier, properties);
        ruleMatcher = new CustomerRuleMatcher(NAME, deskByUsername, factory);

    }

    private void buildConfigBody(String comment) {
        body = new FirewallConfigBody(comment);
    }

    @Test
    void process_config_1_rule() {
        buildConfigBody(COMMENT_1);
        ruleConfig = mock(FirewallConfigDecoder.class);
        when(ruleConfig.body()).thenReturn(body);
        ruleMatcher.apply(ruleConfig, eventContext);
        List<CustomerRule> rules = ruleMatcher.getRules();
        assertThat(rules.size()).isEqualTo(1);
        assertThat(rules.get(0).getClass()).isEqualTo(StaleOrderRule.class);
    }

    @Test
    void process_config_2_rules() {
        buildConfigBody(COMMENT_2);
        ruleConfig = mock(FirewallConfigDecoder.class);
        when(ruleConfig.body()).thenReturn(body);
        ruleMatcher.apply(ruleConfig, eventContext);
        List<CustomerRule> rules = ruleMatcher.getRules();
        assertThat(rules.size()).isEqualTo(2);
        assertThat(rules.get(0).getClass()).isEqualTo(StaleOrderRule.class);
        assertThat(rules.get(1).getClass()).isEqualTo(DummyRule.class);
    }

    @Test
    void process_config_no_rules() {
        buildConfigBody(COMMENT_3);
        ruleConfig = mock(FirewallConfigDecoder.class);
        when(ruleConfig.body()).thenReturn(body);
        ruleMatcher.apply(ruleConfig, eventContext);
        assertThat(ruleMatcher.getRules().size()).isEqualTo(0);
    }

    private class FirewallConfigBody implements FirewallConfigDecoder.Body {

        private final String comment;

        private FirewallConfigBody(String comment) {
            this.comment = comment;
        }

        @Override
        public StringDecoder firewallName() {
            return SimpleStringDecoder.forString(NAME);
        }

        @Override
        public long ruleId() {
            return 0;
        }

        @Override
        public StringDecoder regionPattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder orderTypePattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder deskPattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder portfolioPattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder usernamePattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder venuePattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder securityTypePattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder tenorPattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public StringDecoder symbolPattern() {
            return SimpleStringDecoder.forString(GENERAL_PATTERN);
        }

        @Override
        public long period() {
            return 0;
        }

        @Override
        public StringDecoder periodUnit() {
            return null;
        }

        @Override
        public boolean local() {
            return false;
        }

        @Override
        public StringDecoder comment() {
            return SimpleStringDecoder.forString(comment);
        }

        @Override
        public StringDecoder lastEditUsername() {
            return null;
        }

        @Override
        public long lastEditTime() {
            return 0;
        }

        @Override
        public double limitThreshold() {
            return 0;
        }
    }

}
