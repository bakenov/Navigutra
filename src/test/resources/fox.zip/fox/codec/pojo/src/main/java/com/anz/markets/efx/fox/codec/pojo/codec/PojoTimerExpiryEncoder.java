package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoTimerExpiryEncoder implements TimerExpiryEncoder, TimerExpiryEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;

    private TimerExpiry message = SorMessage.timerExpiry();

    public PojoTimerExpiryEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
    }

    public TimerExpiry message() {
        return message;
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        message = SorMessage.timerExpiry();
        message.header.source = source;
        message.header.sourceSeq = sourceSeq;
        return this;
    }

    @Override
    public Body triggeredTime(final long triggeredTime) {
        message.body.triggeredTime = triggeredTime;
        return this;
    }

    @Override
    public Body timerId(final long timerId) {
        message.body.timerId = timerId;
        return this;
    }

    @Override
    public Trailer timerGroup(final TimerGroup timerGroup) {
        message.body.timerGroup = timerGroup;
        return this;
    }

    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
