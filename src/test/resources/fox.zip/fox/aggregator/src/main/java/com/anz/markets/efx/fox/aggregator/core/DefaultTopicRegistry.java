package com.anz.markets.efx.fox.aggregator.core;

import java.util.EnumMap;

import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;

/**
 * Topic lookup implementation which topic IDS based on {@link com.anz.markets.efx.messaging.transport.base.Hash}.
 * <p>
 * This class internally normalises symbol names to 6 character symbols and maps NDF symbols to ANZ's name. The lookup
 * map contains all variants of symbols (i.e. 6 and 7 character symbol, ANZ-normalized and un-normalized).
 * </p>
 */
public class DefaultTopicRegistry implements TopicRegistry {

    private final EnumMap<Venue, Long2ObjectHashMap<Topic>> typeToMarketToTopicBySymbol;

    public DefaultTopicRegistry() {
        this.typeToMarketToTopicBySymbol = new EnumMap<>(Venue.class);
        Venue.forEach(venue -> typeToMarketToTopicBySymbol.put(venue, new Long2ObjectHashMap<>()));
    }

    private static Topic createTopic(final SecurityType securityType, final Venue venue, final String symbol6) {
        return DefaultTopic.create(securityType + "_" + venue + "_" + symbol6);
    }

    @Override
    public Topic topic(final Venue market, final InstrumentKey instrumentKey) {
        final Long2ObjectHashMap<Topic> byInstrumentId = typeToMarketToTopicBySymbol.get(market);
        Topic topic = byInstrumentId.get(instrumentKey.instrumentId());

        if (topic == null) {
            topic = createTopic(instrumentKey.securityType(), market, instrumentKey.symbol());
            byInstrumentId.put(instrumentKey.instrumentId(), topic);
        }
        return topic;
    }
}
