package com.anz.markets.disco.config;

import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.config.business.domain.tabular.MITRConfigs;
import com.anz.markets.prophet.config.business.domain.tabular.MITRFeaturesConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class JamDetectorPFPConfig {

    private final Logger log = LoggerFactory.getLogger(JamDetectorPFPConfig.class);

    public static final String FEATURE_NAME = "PFP_JAM_DETECTOR";
    public static final String PARAM_TICK_COUNT = "tickCount";
    public static final String PARAM_TIME_PERIOD_SECONDS = "timePeriodSeconds";

    private final EnumObjTable<Market, Instrument, JamDetectorPFPRowConfig> configMap = new EnumObjTable(Market.class, Instrument.class);

    public class JamDetectorPFPRowConfig {
        public int tickCount;
        public long timePeriodNanos;
    }

    public JamDetectorPFPConfig(final MITRConfigs priceFormationPipelineConfigs) {
        if (!priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
            log.warn("{} will be disabled.  Config table does not exist.", FEATURE_NAME);
            return;
        }
        boolean hasConfig = false;
        for (Market market : Market.VALUES) {
            if (!market.isWildcard()) {
                for (Instrument instrument : Instrument.VALUES) {
                    if (!instrument.isWildcard()) {
                        if (priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
                            // Does not support timezones - ensure GLOBAL used in config.
                            final MITRFeaturesConfig c = priceFormationPipelineConfigs.getConfig(market, instrument, TradingTimeZone.LDN);
                            final int tickCount = (int) c.getLongParam(FEATURE_NAME, PARAM_TICK_COUNT).get();
                            final long timePeriodSeconds = c.getLongParam(FEATURE_NAME, PARAM_TIME_PERIOD_SECONDS).get();
                            final boolean activeConfig = tickCount > 0 || timePeriodSeconds > 0;
                            if (activeConfig) {
                                final JamDetectorPFPRowConfig config = new JamDetectorPFPRowConfig();
                                config.tickCount = tickCount;
                                config.timePeriodNanos = TimeUnit.SECONDS.toNanos(timePeriodSeconds);
                                configMap.put(market, instrument, config);
                                hasConfig = true;
                            }
                        }
                    }
                }
            }
        }
        if (hasConfig) {
            log.info("{} has valid config.", FEATURE_NAME);
        } else {
            log.info("{} is not configured.", FEATURE_NAME);
        }
    }

    public EnumObjTable<Market, Instrument, JamDetectorPFPRowConfig> getConfig() {
        return configMap;
    }

}
