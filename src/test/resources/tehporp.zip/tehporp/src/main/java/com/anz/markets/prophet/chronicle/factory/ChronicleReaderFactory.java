package com.anz.markets.prophet.chronicle.factory;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueReader;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.HeaderPredicates;
import com.anz.markets.prophet.chronicle.config.PauserFactory;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.ReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig.ChronicleType;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReader;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderDependant;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderMulti;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueReaderMulti;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.event.EndEventAppenderReader;
import com.anz.markets.prophet.kdb.KdbLastEventReader;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.tools.ToolsCommon;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.util.SystemProperties;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.threads.Pauser;

import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

public enum ChronicleReaderFactory {
    INSTANCE;

    public static ProphetReader createSimpleReader(final ExecutorService executorService,
                                                   final ChronicleObjectReader objectReader,
                                                   final String chroniclePath,
                                                   final StartAt startAt,
                                                   final RingBuffer ringBuffer) throws IOException {
        return createSimpleReader(executorService, objectReader, chroniclePath, startAt, ringBuffer, ChronicleHook.DO_NOTHING);
    }

    public static ProphetReader createSimpleReader(final ExecutorService executorService,
                                                   final ChronicleObjectReader objectReader,
                                                   final String chroniclePath,
                                                   final StartAt startAt,
                                                   final RingBuffer ringBuffer,
                                                   final ChronicleHook startReadHook) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                    .withStartAt(startAt)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.DO_NOTHING)
                    .withEndReadHook(ChronicleHook.DO_NOTHING)
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(HeaderPredicates.FILTER_ALLOW_ALL)
                    .withPauser(PauserFactory.create())
                    .withChronicleObjectReader(objectReader)
                    .withRingBuffer(ringBuffer)
                    .build();

            return new ChronicleQueueReader(executorService, chroniclePath, readerConfig);

        } else {
            final LegacyChronicleReaderConfig configReader = new LegacyChronicleReaderConfigBuilder(LegacyChronicleReaderConfig.readOnlyNotReallyUntilWeWorkOutTheProblem(chroniclePath, ChronicleType.INDEXED))
                    .setStartAt(startAt)
                    .setStartReadHook(startReadHook)
                    .createChronicleConfigReader();
            return new LegacyChronicleReader(executorService, objectReader, configReader);
        }
    }

    /**
     * Used by: StarfishIn process
     * Reads from: chronicle.df
     */
    public static ProphetReader createStarInReader(final ExecutorService executorService, final ChronicleObjectReaderMulti objectReaderMulti,
                                                   final String chroniclePath) throws IOException {
        return createStarInReader(executorService, objectReaderMulti, chroniclePath, ReaderConfig.NO_TAILER_ID);
    }

    public static ProphetReader createStarInReader(final ExecutorService executorService, final ChronicleObjectReaderMulti objectReaderMulti,
                                                   final String chroniclePath, final int tailerId) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                    .withStartAt(StartAt.END)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.START_READ)
                    .withEndReadHook(ChronicleHook.DO_NOTHING)
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(HeaderPredicates.FILTER_ALLOW_ALL)
                    .withPauser(PauserFactory.create())
                    .withChronicleObjectReader(objectReaderMulti)
                    .withTailerId(tailerId)
                    .build();

            return new ChronicleQueueReader(executorService, chroniclePath, readerConfig);

        } else {
            return new LegacyChronicleReader(executorService, objectReaderMulti, LegacyChronicleReaderConfig.fromDatafabric(chroniclePath, ChronicleType.INDEXED));
        }
    }

    /**
     * Used by: StarfishOut process
     * Reads from: chronicle.out
     */
    public static ProphetReader createStarOutReader(final ExecutorService executorService,
                                                    final ChronicleObjectReader multiReader,
                                                    final String path,
                                                    final long allowableLagFromRealTimeMS,
                                                    final EndEventAppenderReader hopAppender,
                                                    final RingBuffer ringBuffer,
                                                    final Pauser pauser) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                    .withStartAt(StartAt.END)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.START_READ)
                    .withEndReadHook(ChronicleHook.endEventHop(hopAppender))
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(new HeaderPredicates.TimelyDataFilter(allowableLagFromRealTimeMS))
                    .withPauser(pauser)
                    .withChronicleObjectReader(multiReader)
                    .withRingBuffer(ringBuffer)
                    .build();

            return new ChronicleQueueReader(executorService, path, readerConfig);
        } else {
            return new LegacyChronicleReader(executorService, multiReader, LegacyChronicleReaderConfig.starfishOut(path, ChronicleType.INDEXED, allowableLagFromRealTimeMS, hopAppender));
        }
    }

    /**
     * Used by: A core process
     * Reads from: chronicle.in
     */
    public static ProphetReader createCoreReaderForChronicleIn(final String[] chronicleInPaths, final int startIndex, final boolean thisCoreUsesPauser, final Consumer<EndEvent> endEventSink,
                                                               final RingBuffer ringBuffer, final int coreId, final EnumMap<MessageType, ChronicleObjectReader> map) throws IOException {
        GcFriendlyAssert.isTrue(chronicleInPaths.length > 0);
        final ChronicleObjectReaderMulti objectReader = new ChronicleObjectReaderMulti(map);

        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                    .withStartPosition(startIndex)
                    .withStartAt(StartAt.INDEX)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.START_READ)
                    .withEndReadHook(ChronicleHook.endEventInception(endEventSink))
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(HeaderPredicates.FILTER_ALLOW_ALL)
                    .withPauser(thisCoreUsesPauser ? PauserFactory.create() : PauserFactory.none())
                    .withRingBuffer(ringBuffer)
                    .withChronicleObjectReader(objectReader)
                    .withTailerId(coreId)
                    .build();

            return ChronicleQueueReaderMulti.create(chronicleInPaths, readerConfig);
        } else {
            final LegacyChronicleReaderConfig baseConfig = LegacyChronicleReaderConfig.core(chronicleInPaths[0], ChronicleType.INDEXED, startIndex, thisCoreUsesPauser, endEventSink);
            return LegacyChronicleReaderMulti.create(chronicleInPaths, objectReader, baseConfig);
        }
    }

    /**
     * Used by: A core process
     * Reads from: A queue other than chronicle.in(.cq4)
     */
    public static ProphetReader createCoreReader(final String[] chronicleInPaths,
                                                 final int startIndex,
                                                 final boolean thisCoreUsesPauser,
                                                 final EndEventAppenderReader hopAppender,
                                                 final RingBuffer ringBuffer,
                                                 EnumMap<MessageType, ChronicleObjectReader> map) throws IOException {
        GcFriendlyAssert.isTrue(chronicleInPaths.length > 0);
        final ChronicleObjectReaderMulti objectReader = new ChronicleObjectReaderMulti(map, true);

        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                    .withStartPosition(startIndex)
                    .withStartAt(StartAt.INDEX)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.START_READ)
                    .withEndReadHook(ChronicleHook.endEventHop(hopAppender))
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(HeaderPredicates.FILTER_ALLOW_ALL)
                    .withPauser(thisCoreUsesPauser ? PauserFactory.create() : PauserFactory.none())
                    .withChronicleObjectReader(objectReader)
                    .withRingBuffer(ringBuffer)
                    .build();

            return ChronicleQueueReaderMulti.create(chronicleInPaths, readerConfig);
        } else {
            final LegacyChronicleReaderConfig baseConfig = LegacyChronicleReaderConfig.core(chronicleInPaths[0], ChronicleType.INDEXED, startIndex, thisCoreUsesPauser, hopAppender);
            return LegacyChronicleReaderMulti.create(chronicleInPaths, objectReader, baseConfig);
        }
    }

    public static ProphetReader createCoreConflateReader(final String outboundChroniclePath, final String chronicleInPath, final ChronicleObjectReaderMulti objectReaderMulti) throws IOException {
        final long lastConflatedEventId = ToolsCommon.lastEventId(outboundChroniclePath);
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                    .withStartPosition(lastConflatedEventId)
                    .withStartAt(StartAt.EVENTID)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.START_READ)
                    .withEndReadHook(ChronicleHook.DO_NOTHING)
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(HeaderPredicates.FILTER_ALLOW_ALL)
                    .withPauser(PauserFactory.create())
                    .withChronicleObjectReader(objectReaderMulti)
                    .build();

            return new ChronicleQueueReader(chronicleInPath, readerConfig);
        } else {
            final LegacyChronicleReaderConfigBuilder builder = new LegacyChronicleReaderConfigBuilder(
                    LegacyChronicleReaderConfig.core(chronicleInPath, ChronicleType.INDEXED));
            builder.setStartAt(StartAt.EVENTID).setStartPosition(lastConflatedEventId);
            return new LegacyChronicleReader(objectReaderMulti, builder.createChronicleConfigReader());
        }
    }

    public static ProphetReader createEventIdBoundReader(final ExecutorService executorService, final String chronicleInPath, final EnumMap<MessageType, ChronicleObjectReader> map,
                                                         final KdbLastEventReader kdbLastEventReader, final long pricerStartEventIdOverride) {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final Map<MessageType, Long> eventIdsForMessageType = kdbLastEventReader.getEventIdsForMessageTypes(chronicleInPath);
            final Context.HeaderPredicate headerPredicate = LegacyChronicleReaderDependant.getHeaderPredicate(eventIdsForMessageType, pricerStartEventIdOverride, map);
            final Optional<Long> minimumEventId = eventIdsForMessageType.values().stream().filter(e -> e != 0).min(Long::compare);

            final ChronicleObjectReader readerMulti = new ChronicleObjectReaderMulti(map, true);
            final ReaderConfigBuilder configBuilder = ReaderConfigBuilder.create()
                    .withStartAt(StartAt.START)
                    .withWaitStrategy(WaitStrategy.PAUSE)
                    .withStartReadHook(ChronicleHook.DO_NOTHING)
                    .withEndReadHook(ChronicleHook.DO_NOTHING)
                    .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                    .withHeaderFilter(headerPredicate)
                    .withPauser(PauserFactory.create())
                    .withChronicleObjectReader(readerMulti);

            // use EVENTID_CLOSEST for weekend restarts
            minimumEventId.ifPresent(eventId -> configBuilder.withStartAt(StartAt.EVENTID_CLOSEST).withStartPosition(eventId));

            return new ChronicleQueueReader(executorService, chronicleInPath, configBuilder.build());
        } else {
            final LegacyChronicleReaderDependant LegacyChronicleReaderDependant = new LegacyChronicleReaderDependant(LegacyChronicleReaderConfig.metrics(chronicleInPath, ChronicleType.INDEXED), map, kdbLastEventReader, pricerStartEventIdOverride);
            executorService.submit(LegacyChronicleReaderDependant);
            return LegacyChronicleReaderDependant;
        }
    }

    public static ProphetReader createToolsCommonReader(final ExecutorService executorService,
                                                        final String chroniclePath,
                                                        final ChronicleObjectReader reader,
                                                        final Context.HeaderPredicate combinedFilter,
                                                        final StartAt startAt,
                                                        final long startPosition,
                                                        final ChronicleHook unknownMessageTypeStrategy,
                                                        final WaitStrategy waitStrategy) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final ReaderConfig config = ReaderConfigBuilder.create()
                    .withStartAt(startAt)
                    .withStartPosition(startPosition)
                    .withWaitStrategy(waitStrategy)
                    .withStartReadHook(ChronicleHook.DO_NOTHING)
                    .withEndReadHook(ChronicleHook.DO_NOTHING)
                    .withUnknownReadHook(unknownMessageTypeStrategy)
                    .withHeaderFilter(combinedFilter)
                    .withPauser(PauserFactory.create())
                    .withChronicleObjectReader(reader).build();

            return new ChronicleQueueReader(executorService, chroniclePath, config);

        } else {
            final LegacyChronicleReaderConfigBuilder config = new LegacyChronicleReaderConfigBuilder(LegacyChronicleReaderConfig.readOnly(chroniclePath, ChronicleType.INDEXED, combinedFilter, startAt, startPosition));
            config.setUnknownReadHook(unknownMessageTypeStrategy);
            config.setWaitStrategy(waitStrategy);
            return new LegacyChronicleReader(executorService, reader, config.createChronicleConfigReader());
        }
    }

    public static ProphetReader createReader(final ExecutorService executorService, final String basePath, final ReaderConfig readerConfig) {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            return new ChronicleQueueReader(executorService, basePath, readerConfig);
        } else {
            try {
                return new LegacyChronicleReader(executorService, readerConfig.chronicleObjectReader(), new LegacyChronicleReaderConfig(readerConfig, basePath));
            } catch (IOException e) {
                throw Jvm.rethrow(e);
            }
        }
    }

    public static ProphetReader multiReader(final String[] paths, final ChronicleObjectReader objectReader) throws IOException {
        final ProphetReader rv;
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            rv = ChronicleQueueReaderMulti.create(paths, ReaderConfigBuilder.create().withChronicleObjectReader(objectReader).build());
        } else {
            final LegacyChronicleReaderConfig baseConfig = LegacyChronicleReaderConfig.core("dummy", LegacyChronicleConfig.ChronicleType.INDEXED);
            rv = LegacyChronicleReaderMulti.create(paths, objectReader, baseConfig);
        }
        return rv;
    }
}
