package com.anz.markets.prophet.config.business.doclet;

import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.EnumValueDescriptor;
import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.Doc;
import com.sun.javadoc.DocErrorReporter;
import com.sun.javadoc.LanguageVersion;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.RootDoc;
import com.sun.javadoc.SeeTag;
import com.sun.javadoc.Tag;
import com.sun.javadoc.Type;
import com.sun.tools.doclets.formats.html.HtmlDoclet;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.lang.String.format;

/**
 * Custom doclet to generate config doc in markdown syntax.
 */
public class ConfigDoclet {
    private static final String TABLE_NAME_PREFIX = "PROPHET_";
    private static final String PACKAGE_NAME_PREFIX = "com.anz.markets.prophet.config.business.domain.tabular.";
    private static final String CONFIG_CLASS_NAME_SIFFIX = "Config";
    private static final String REFERENCE_BREAD_CRUMB = "reference";
    private static final String PROPHET_VERSION_PARAM = "-prophetversion";
    // omits generation of the document if this tag exists on the method.
    // useful for asList or asEnumList type of method
    public static final String METHOD_IGNORE_TAG = "JsonIgnore";
    private static String prophetVersion;
    private static Markdown md = new Markdown();

    public static boolean start(final RootDoc root) throws Exception {
        final PrintStream stream = createPrintStream();

        final List<ClassDoc> classes = Arrays.asList(root.classes());
        Collections.sort(classes, (o1, o2) -> {
            if (o1.isEnum() && o2.isEnum()) {
                // enums are put into single "reference" bucket
                return o1.simpleTypeName().compareTo(o2.simpleTypeName());
            } else if (o1.isEnum()) {
                // put enum at the bottom
                return 1;
            } else if (o2.isEnum()) {
                // put enum at the bottom
                return -1;
            } else {
                // configs are sorted into packages
                return o1.toString().compareTo(o2.toString());
            }
        });

        printTocSection(stream, classes);
        printPreampleSection(stream, root);
        printConfigTablesSection(stream, root, classes);
        printReferenceDataSection(stream, classes);
        return true;
    }

    @NotNull
    private static PrintStream createPrintStream() throws FileNotFoundException {
        final File outputDir = new File("build/configdoc");
        outputDir.mkdir();
        return new PrintStream(new File(outputDir, "config.md"));
    }

    private static void printTocSection(final PrintStream stream,
                                        final List<ClassDoc> classes) {
        String previousBreadCrumb = null;
        stream.print(md.h2("Table of contents"));
        for (final ClassDoc classDoc : classes) {
            if (isConfigTable(classDoc.name())) {
                final String tableName = getKdbTableName(classDoc.simpleTypeName());
                String previousBreadCrumb1 = previousBreadCrumb;
                final String currentBreadCrumb = formatBreadCrumbs(getBreadCrumbs(classDoc));
                if (!currentBreadCrumb.equals(previousBreadCrumb1)) {
                    stream.print(currentBreadCrumb);
                    previousBreadCrumb1 = currentBreadCrumb;
                }
                stream.println(md.localLink(md.escapeUnderScore(tableName), classDoc.toString()));
                previousBreadCrumb = previousBreadCrumb1;
            }
        }
        // put references last
        stream.println(md.code(REFERENCE_BREAD_CRUMB));

        for (final ClassDoc classDoc : classes) {
            if (classDoc.isEnum()) {
                stream.println(md.localLink(md.escapeUnderScore(classDoc.simpleTypeName()), classDoc.toString()));
            }
        }

        stream.println();
    }

    private static void printPreampleSection(final PrintStream stream,
                                             final RootDoc root) {
        final String packageInfo = root.packageNamed(ConfigurationData.class.getPackage().getName()).commentText();

        stream.println(md.h1("Configuration Tables"));
        stream.println(format("Prophet version %s generated at %tc", prophetVersion, new Date()));
        stream.println("   ");
        stream.println(packageInfo);
        stream.println("   ");
        stream.println(md.hr());
    }

    private static void printConfigTablesSection(final PrintStream stream,
                                                 final RootDoc root,
                                                 final List<ClassDoc> classes) {
        classes.forEach(classDoc -> {
            if (isConfigTable(classDoc.name())) {
                stream.println(convertToKdbConfigTableDescription(classDoc));
                stream.println();
                printSeeTags(stream, classDoc.asClassDoc().seeTags());
                stream.println(md.h3("Column descriptions"));

                stream.println(md.tableHeader("Type", "Column name", "Description", " "));
                Arrays.asList(classDoc.methods()).forEach(methodDoc -> {
                            if (methodDoc.isPublic() && shouldPrintMethod(methodDoc)) {
                                stream.println(md.tableRow(getColumnType(root, methodDoc), getMethodName(methodDoc), getColumnDescription(methodDoc), getDeprecation(methodDoc)));
                            }
                        }
                );
                stream.println("   ");
            }
        });
    }

    private static boolean shouldPrintMethod(final MethodDoc methodDoc) {
        return !Arrays.stream(methodDoc.annotations()).filter(annotationDesc -> annotationDesc.annotationType().name().contains(METHOD_IGNORE_TAG)).findAny().isPresent();
    }

    private static void printReferenceDataSection(final PrintStream stream,
                                                  final List<ClassDoc> classes) {
        stream.println(md.h1("Reference Data"));
        stream.println(md.hr());

        classes.forEach(classDoc -> {
            if (classDoc.isEnum()) {
                stream.println(formatQualifiedClassName(classDoc));
                stream.println(md.h2(classDoc.simpleTypeName()));
                stream.println(md.code(REFERENCE_BREAD_CRUMB));
                stream.println();
                stream.println(classDoc.commentText());
                stream.println();
                printSeeTags(stream, classDoc.asClassDoc().seeTags());
                stream.println();
                stream.println(md.tableHeader("Name", "Description", " "));

                boolean hasEnumConfigDocumentation = hasEnumConfigDocumentation(classDoc);
                Arrays.asList(classDoc.enumConstants()).forEach(fieldDoc -> {
                    StringBuilder description = new StringBuilder(fieldDoc.commentText());
                    if (hasEnumConfigDocumentation) {
                        if (description.length() > 0) {
                            // provides punctuation.
                            description.append(" ");
                        }

                        Enum e = Enum.valueOf(getClass(classDoc), fieldDoc.name());
                        description.append(((EnumValueDescriptor) e).getDocumentation());
                    }

                    stream.println(md.tableRow(fieldDoc.name(), md.oneline(description.toString()), getDeprecation(fieldDoc)));
                });
                stream.println();
            }
        });
    }

    private static void printSeeTags(final PrintStream stream,
                                     final SeeTag[] seeTags) {
        if (seeTags.length > 0) {
            stream.println(md.em("See related"));
        }
        Arrays.asList(seeTags).forEach(seeTag -> {
            stream.printf("<li> %s\n", md.localLink(getReferenceDisplayName(seeTag.referencedClass().simpleTypeName()), seeTag.referencedClassName()));
        });
    }


    private static String getReferenceDisplayName(String simpleTypeName) {
        if (isConfigTable(simpleTypeName)) {
            return getKdbTableName(simpleTypeName);
        } else {
            return simpleTypeName;
        }
    }

    private static Class getClass(ClassDoc classDoc) throws RuntimeException {
        try {
            return Class.forName(classDoc.toString());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static boolean hasEnumConfigDocumentation(final ClassDoc classDoc) {
        final Type[] types = classDoc.interfaceTypes();
        for (Type type : types) {
            if (type.qualifiedTypeName().equals(EnumValueDescriptor.class.getName())) {
                return true;
            }
        }
        return false;
    }


    private static String getDeprecation(final Doc m) {
        final StringBuilder sb = new StringBuilder(" ");
        final Tag[] deprecateds = m.tags("deprecated");
        if (deprecateds.length > 0) {
            if (deprecateds.length > 1) {
                throw new RuntimeException("You have duplicate deprecated tag at " + m.toString() + ". Delete one.");
            } else {
                sb.append(md.em("Deprecated"));
                final String text = deprecateds[0].text();
                if (!text.isEmpty()) {
                    sb.append(" - ").append(text);
                }
            }
        }
        return sb.toString();
    }

    private static String getMethodName(final MethodDoc m) {
        final String name = m.name();
        String columnName;

        if (name.equals("get")) {
            // cater for tz get
            columnName = "timezones";
        } else if (name.startsWith("get")) {
            columnName = name.substring(3);
        } else if (name.startsWith("is")) {
            columnName = name.substring(2);
        } else {
            columnName = name;
        }

        return Character.toLowerCase(columnName.charAt(0)) + columnName.substring(1);
    }

    private static String getColumnDescription(final MethodDoc m) {
        final StringBuilder sb = new StringBuilder(m.commentText());
        if (m.seeTags().length > 0) {
            sb.append("<br>See ");
        }
        Arrays.asList(m.seeTags()).forEach(seeTag -> {
            sb.append(md.localLink(getReferenceDisplayName(seeTag.referencedClass().simpleTypeName()), seeTag.referencedClassName()));
            sb.append(" ");
        });
        return md.oneline(sb.toString());
    }

    private static String getColumnType(final RootDoc root,
                                        final MethodDoc m) {
        final Optional<ClassDoc> isIncluded = Arrays.asList(root.classes()).stream().filter(classDoc -> classDoc.toString().equals(m.returnType().qualifiedTypeName())).findFirst();

        if (isIncluded.isPresent()) {
            return md.localLink(getReferenceDisplayName(m.returnType().simpleTypeName()), m.returnType().qualifiedTypeName());
        } else {
            if (m.returnType().qualifiedTypeName().contains("prophet")) {
                throw new RuntimeException(format("Could not create reference link to prophet return data type. Return type of %s must be included in the list of classes for doclet to process.", m.returnType()));
            }

            return m.returnType().simpleTypeName();
        }
    }


    private static String convertToKdbConfigTableDescription(final ClassDoc aClass) {
        final String simpleTypeName = aClass.simpleTypeName();
        final String classNameInUnderScore = getKdbTableName(simpleTypeName);
        final StringBuilder sb = new StringBuilder();
        sb.append(formatQualifiedClassName(aClass));
        sb.append(md.h2(md.escapeUnderScore(classNameInUnderScore)));
        sb.append(formatBreadCrumbs(getBreadCrumbs(aClass))).append("\n");
        sb.append(aClass.commentText());
        return sb.toString();
    }

    /**
     * This is used as a unique anchor in javascript later.
     * local reference can be made with qualified classname - e.g. #com.anz.markets.prophet.domain.Region will point to document section for Region.
     */
    private static String formatQualifiedClassName(final ClassDoc aClass) {
        return format("Class name: %s\n", aClass.toString());
    }

    private static String formatBreadCrumbs(final List<String> breadCrumbs) {
        return breadCrumbs.stream().map(groupName -> md.code(groupName)).collect(Collectors.joining(" / ")) + "\n";
    }

    /**
     * Breadcrumb is inferred from the package names and used to provide visual grouping in the document.
     */
    private static List<String> getBreadCrumbs(final ClassDoc aClass) {
        final int start = PACKAGE_NAME_PREFIX.length();
        final int end = aClass.toString().length() - aClass.simpleTypeName().length();
        return Arrays.asList(aClass.toString()
                .substring(start, end)
                .split("\\."));
    }

    /**
     * KDB config table is upper case with underscore.
     */
    private static String getKdbTableName(final String simpleTypeName) {
        return TABLE_NAME_PREFIX + simpleTypeName.replaceAll("([a-z])([A-Z]+)", "$1_$2").toUpperCase();
    }

    /**
     * Config class for this doc generation must ends with 'Config'
     */
    private static boolean isConfigTable(final String aClass) {
        return aClass.endsWith(CONFIG_CLASS_NAME_SIFFIX);
    }

    public static int optionLength(String option) {
        if (PROPHET_VERSION_PARAM.equalsIgnoreCase(option)) {
            return 2;
        } else {
            // to accomodate gradle plugin - it assumes Standard doclet.
            return HtmlDoclet.optionLength(option);
        }
    }

    // to accomodate gradle plugin - it assumes Standard doclet.
    public static boolean validOptions(final String[][] options,
                                       final DocErrorReporter reporter) {
        for (int i = 0; i < options.length; i++) {
            if (PROPHET_VERSION_PARAM.equalsIgnoreCase(options[i][0])) {
                prophetVersion = options[i][1];

            }
        }
        return HtmlDoclet.validOptions(options, reporter);
    }

    public static LanguageVersion languageVersion() {
        return HtmlDoclet.languageVersion();
    }
}
