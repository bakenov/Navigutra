package com.anz.markets.prophet.atest.risk._2_pnl;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.positionrisk.Positions;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static com.anz.markets.prophet.domain.Instrument.EURSEK;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.number.IsCloseTo.closeTo;

public class ProfitAndLossForTriangulatedMidTest extends BaseAcceptanceSpecification {

    private double EPSILON = 1e-6;

    @Test
    @Requirement(value = Ref.POSITION_4_1_5)
    @DisplayName("Test EUR base system base position needs to be triangulated for. Note all of mid that need to be triangulated for are triangulated via EUR")
    public void WHEN_receive_trade_for_EUR_ccy_that_require_triangulation() {
        setup:
        {

            prophet.receive(tdd.configuration_pricing_base()
                    .setMarketConfigs(Arrays.asList(
                            // define driver pairs for market
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURSEK).setEnabled(true),
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.EURSEK, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
        }
        when:
        {
            // cache and triangulate mid
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.1));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURSEK, 9.7));

            // process trade that requires mid rate triangulation
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.6));
        }
        then:
        {
            double eurPosInUSD = 1_000_000.0 * 1.1;
            double sekPosInUSD = -1_000_000 * 9.6 * 1.1 / 9.7;

            Positions positionsUpdate = prophet.expect(Positions.class, atLeast(1)).getLast();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.EUR));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(eurPosInUSD));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.SEK));
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), is(closeTo(sekPosInUSD, EPSILON)));

            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(closeTo(eurPosInUSD + sekPosInUSD, EPSILON)));
        }
    }
}