package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierClippingConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.ModifiedBookReason;
import com.anz.markets.prophet.domain.control.PricingFirewallResetImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Market.ANY;
import static com.anz.markets.prophet.domain.Market.WSP_A;
import static com.anz.markets.prophet.domain.Market.WSP_B;
import static com.anz.markets.prophet.domain.Market.WSP_C;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 *  Works in conjunction with PriceBarrier Firewall.
 *  If PriceBarrier not triggered then proceed with this new check. If PriceBarrier triggered, then no need to do any clipping
 *  - Sort PriceBarrierClippingConfig by activationDistance descending
 *  - See if Ref Price(if defined) or Client Price is within activation distance. If not, proceed to next config activationDistance
 *  - If within activationDistance, clip stacks such that total qty of stack does not exceed clipFromQty
 *  - To deactivate clipping, price must move back beyond activationDistance + deactivationDeltaPips
 */

@Requirement(Ref.PRICING_AXPROPHET_1281)
public class PriceBarrierClippingTest extends BaseAcceptanceSpecification {

    final Instrument driverPairA = Instrument.EURUSD;
    final Instrument driverPairB = Instrument.EURDKK;
    final Instrument crossPair = Instrument.USDDKK;

    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, true));
        return configuration;
    }

    @Test
    @DisplayName("Clip when Client BID approaches CEILING limit")
    public void clip_depth_when_client_bid_approaches_ceiling() throws Exception {
        given:
        {
            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration()
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(driverPairB, "", 7.41500, 7.48500, Currency.DKK)
                    ))
                    .setPriceBarrierClippingConfigs(Arrays.asList(
                            new PriceBarrierClippingConfig(driverPairB, WSP_A, 1.0, 10_000_000d, 0.5),
                            new PriceBarrierClippingConfig(driverPairB, WSP_A, 3.0, 6_000_000d, 0.5),
                            new PriceBarrierClippingConfig(driverPairB, WSP_A, 2.0, 1_000_000d, 0.5)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48475, 0.00004));
        }
        // EUR/DKK BID price is BEYOND furthest activation threshold from CEILING limit i.e 7.4850 - 3pip = 7.4847
        // Therefore NO clipping on EUR/DKK client price. Full Stack is 1mio/2mio/2mio/5mio/5imo
        then:
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(5));
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.48465, 7.48485));
            assertThat(clientPriceEURDKK.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(3).getQuantity(), is(Level.QTY_5M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(4).getQuantity(), is(Level.QTY_5M.getQty()));
            assertThat(clientPriceEURDKK.getModifiedBookReason(), is(ModifiedBookReason.NOT_DEFINED));
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48485, 0.00004));
        }
        then:
        // EUR/DKK BID price(7.48475) is WITHIN 1st(furthest) activation threshold from CEILING limit i.e 7.4850 - 3pip = 7.48470
        // Therefore max total we can stream is 6_000_000d
        // Stream levels 1,2,2
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(3));
            assertThat(clientPriceEURDKK.getOffers().size(), Matchers.is(3));
            assertThat(clientPriceEURDKK.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48491, 0.00004));
        }
        then:
        // EUR/DKK BID price(7.48481) is WITHIN middle activation threshold from CEILING limit i.e 7.48500 - 2pip = 7.48480
        // Therefore max total we can stream is 1mio
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(1));
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.48481, 7.48501));
            assertThat(clientPriceEURDKK.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(clientPriceEURDKK.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
        }
        and:
        // verify WSP_B prices NOT impacted
        {
            // WSP_B is NOT clipped(as clipping config is defined for WSP_A only)
            ClientPrice cpEURDKK_wspb = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(driverPairB, WSP_B)).getFirst();
            assertThat(cpEURDKK_wspb.getBids().size(), Matchers.is(5));
        }
        and:
        // verify triangulated pair depth is also limited
        {
            // Since EURDKK only has depth of 1, cross pair can only triangulate to depth of 1 also.
            ClientPrice crossPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, WSP_A)).getFirst();
            assertThat(crossPriceUSDDKK.getBids().size(), Matchers.is(1));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48501, 0.00004));
        }
        then:
        // EUR/DKK BID price(7.48491) is WITHIN closest activation threshold from CEILING limit i.e 7.48500 - 1pip = 7.48490
        // Therefore max total we can stream is 10mio
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(4));
            assertThat(clientPriceEURDKK.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(3).getQuantity(), is(Level.QTY_5M.getQty()));
            assertThat(clientPriceEURDKK.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48511, 0.00004));
        }
        then:
        // EUR/DKK BID price(7.48501) is ABOVE CEILING i.e 7.48500
        // Therefore PriceBarrier Triggers INDICATIVE (and NO clipping)
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(5));
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.48501, 7.48521));
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPriceEURDKK, PricingFirewallType.PRICE_BARRIER);
            assertThat(clientPriceEURDKK.getModifiedBookReason(), is(ModifiedBookReason.NOT_DEFINED));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48501, 0.00004));
        }
        then:
        // EUR/DKK BID price(7.48491) is WITHIN closest activation threshold from CEILING limit i.e 7.48500 - 1pip = 7.48490
        // Therefore max total we can stream is 10mio
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(4));
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.48491, 7.48511));
            assertThat(clientPriceEURDKK.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, WSP_A)).getFirst();
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));
            assertThat(clientPriceUSDDKK.getBids().size(), Matchers.is(4));
        }
    }

    @Test
    @DisplayName("Clip when Ref OFFER approaches FLOOR limit")
    public void clip_depth_when_ref_offer_approaches_floor() throws Exception {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(setUpConfiguration()
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "BARX,HSP,RFX", 7.41500, 7.48500, Currency.DKK)
                    ))
                    .setPriceBarrierClippingConfigs(Arrays.asList(
                            new PriceBarrierClippingConfig(Instrument.EURDKK, ANY, 3.0, 3_000_000d, 0.1),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, ANY, 1.0, 1_000_000d, 0.1),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_A, 3.0, 5_000_000d, 0.5),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_A, 2.0, 3_000_000d, 0.5)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            // send Ref market(not a primary mkt)
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41530, 0.0002));
            // trigger client price
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41530, 0.0004));
        }
        then:
        // Ref Market BARX OFFER (7.41540) is BEYOND activation threshold from FLOOR limit i.e 7.41500 + 3pip = 7.41530
        // Therefore NO clipping on EUR/DKK client price. Full Stack is 1mio/2mio/2mio/5mio/5imo
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41540));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41530, is(true));
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(5));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));

        }
        when:
        // DEUT OFFER(7.41520) is WITHIN activation threshold from FLOOR limit i.e 7.41500 + 3pip = 7.41530
        // DEUT is NOT a REF MARKET(or Primary) so No Clipping
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.DEUT, driverPairB, 7.41510, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41531, 0.0004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.DEUT)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41520));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41530, is(true));
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(5));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // Ref Market BARX OFFER (7.41529) is WITHIN activation threshold from FLOOR limit i.e 7.41500 + 3pip = 7.41530
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41519, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41530, 0.0004));  // trigger client price
        }
        then:
        // Therefore max total we can stream is 5mio
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41529)); // Ref is within activation limit

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41530, is(true)); // WSP_A offer is still beyond activation limit
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(3));
            assertThat(cpEURDKK_wspA.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(cpEURDKK_wspA.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        and:
        // Since WSP_B market not defined, verify use of ANY config. Within 3pip, max qty streamed is 3mio
        {
            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB.getBids().size(), Matchers.is(2));
        }
        when:
        // Now also Ref Market HSP OFFER (7.41529) is WITHIN activation threshold from FLOOR limit i.e 7.41500 + 3pip = 7.41530
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, driverPairB, 7.41519, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41531, 0.0004));  // trigger client price
        }
        then:
        // Therefore max total we can stream is 5mio
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41529));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41530, is(true)); // WSP_A offer is still beyond activation limit
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(3));
            assertThat(cpEURDKK_wspA.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(cpEURDKK_wspA.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // Ref Market BARX OFFER(7.41540) is beyond deactivation threshold(7.41500 + 3pip + 0.5pip) => Do not clip
        // But Ref Market HSP OFFER (7.41529) is still WITHIN activation threshold from FLOOR limit i.e 7.41500 + 3pip = 7.41530
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41530, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41530, 0.0004));
        }
        then:
        // Therefore max total we can stream remains at 5mio
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41540));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41530, is(true)); // WSP_A offer is still beyond activation limit
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(3));
            assertThat(cpEURDKK_wspA.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(cpEURDKK_wspA.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // Ref Market HSP OFFER (7.41509) is WITHIN WSP_A 2pip activation threshold from FLOOR limit i.e 7.41500 + 2pip = 7.41520
        // Ref Market HSP OFFER (7.41509) is WITHIN ANY 1pip activation threshold from FLOOR limit i.e 7.41500 + 1pip = 7.41510
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, driverPairB, 7.41505, 0.00008));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41531, 0.0004));  // trigger client price
        }
        then:
        // WSP_A: HSP OFFER is WITHIN 2pip threshold, max total we can stream is 3mio
        // ANY(e.g WSP_B): HSP OFFER is WITHIN 1pip threshold, max total we can stream is 1mio
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41509));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41530, is(true)); // WSP_A offer is still beyond activation limit
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(2));
            assertThat(cpEURDKK_wspA.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(cpEURDKK_wspA.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB.getBids().size(), Matchers.is(1));
            assertThat(cpEURDKK_wspB.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
        }

        when:
        // Ref Market HSP OFFER(7.41499) is BELOW FLOOR(7.41500) => Firewall triggered
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, driverPairB, 7.41497, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41530, 0.0004));  // trigger client price
        }
        then:
        // Price Barrier triggered so go INDICATIVE(but no clipping)
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41499));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() < 7.41500, is(false));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(5));
        }
    }

    @Test
    @DisplayName("Deactivate Clipping monitoring Client BID")
    public void deactivate_clipping_monitoring_client_bid() throws Exception {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration()
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ))
                    .setPriceBarrierClippingConfigs(Arrays.asList(
                            new PriceBarrierClippingConfig(Instrument.EURDKK, ANY, 2.0, 5_000_000d, 0.5),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, ANY, 1.0, 1_500_000d, 0.5),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_B, 3.0, 6_000_000d, 0.7),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_B, 2.0, 5_000_000d, 0.7),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_B, 1.0, 1_500_000d, 0.7)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48475, 0.00004));
        }
        // EUR/DKK BID price is BEYOND activation threshold from CEILING limit i.e 7.4850 - 3pip = 7.4847
        // Therefore NO clipping on EUR/DKK client price. Full Stack is 1mio/2mio/2mio/5mio/5imo/5mio
        then:
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getTopOfBookBid().getPrice(), is(7.48465));
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(5));
            assertThat(clientPriceEURDKK.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(3).getQuantity(), is(Level.QTY_5M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(4).getQuantity(), is(Level.QTY_5M.getQty()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48501, 0.00004));
        }
        then:
        // EUR/DKK BID price(7.48491) is WITHIN closest activation threshold from CEILING limit i.e 7.48500 - 1pip = 7.48490
        // Therefore max total we can stream is 1.5mio
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getTopOfBookBid().getPrice(), is(7.48491));
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(1)); // only one stack remaining

        }
        when:
        // Deactivation threshold 7.4850 - (1pip+0.5pip) = 7.48485
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48495, 0.0002));
        }
        then:
        // EUR/DKK BID price 7.48485 has NOT moved beyond Deactivation threshold
        // Therefore continue stream max total of 1.5mio
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getTopOfBookBid().getPrice(), isRoundedTo(7.48485));
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(1));

        }
        when:
        // Deactivation threshold 7.4850 - (1pip+0.5pip) = 7.48485
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48494, 0.0002));
        }
        then:
        // EUR/DKK BID price 7.48484 HAS moved beyond Deactivation threshold
        // Therefore deactivate max limit of 1_500_000d
        // But EUR/DKK BID price 7.48484 BEYOND MIDDLE activation threshold from CEILING limit i.e 7.4850 - 2pip = 7.48480
        // Therefore max total we can stream is 5mio
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getTopOfBookBid().getPrice(), is(7.48484));
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(3));
            assertThat(clientPriceEURDKK.getBids().get(0).getQuantity(), is(Level.QTY_1M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(1).getQuantity(), is(Level.QTY_2M.getQty()));
            assertThat(clientPriceEURDKK.getBids().get(2).getQuantity(), is(Level.QTY_2M.getQty()));
        }
        when:
        // Deactivation threshold 7.4850 - (2pip+0.5pip) = 7.48475
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48484, 0.0002));
        }
        then:
        // EUR/DKK BID price 7.48474 has moved beyond Deactivation threshold
        // Therefore deactivate max total of 5_000_000d
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getFirst();
            assertThat(clientPriceEURDKK.getTopOfBookBid().getPrice(), is(7.48474));
            assertThat(clientPriceEURDKK.getBids().size(), Matchers.is(5));
        }
    }

    @Test
    @DisplayName("Deactivate Clipping monitoring Reference OFFER")
    public void deactivate_clipping_monitoring_ref_offer() throws Exception {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(setUpConfiguration()
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "BARX,HSP,RFX", 7.41500, 7.48500, Currency.DKK)
                    ))
                    .setPriceBarrierClippingConfigs(Arrays.asList(
                            new PriceBarrierClippingConfig(Instrument.EURDKK, ANY, 3.0, 4_000_000d, 0.7),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, ANY, 2.0, 1_500_000d, 0.7),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_A, 3.0, 4_000_000d, 0.5),
                            new PriceBarrierClippingConfig(Instrument.EURDKK, WSP_A, 2.0, 1_500_000d, 0.5)
                    ))
            );
        }
        when:
        // Ref Market BARX OFFER (7.41529) is WITHIN furthest activation threshold from FLOOR limit i.e 7.41500 + 3pip = 7.41530
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41519, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41530, 0.0004));  // trigger client price
        }
        then:
        // Therefore max total we can stream is 4mio
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41529));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(2));
            assertThat(cpEURDKK_wspA.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
        }
        when:
        // Deactivation threshold 7.41500 + (3pip+0.5pip) = 7.41535
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41524, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41531, 0.0004));  // trigger client price
        }
        then:
        // EUR/DKK BID price 7.41534 has NOT moved beyond Deactivation threshold
        // Therefore max total we can stream 4mio continues
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41534));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(2));
            assertThat(cpEURDKK_wspA.getModifiedBookReason(), is(ModifiedBookReason.CLOSE_TO_PRICE_BARRIER));
        }
        when:
        // Ref Market BARX OFFER (7.41519) is WITHIN closest activation threshold from FLOOR limit i.e 7.41500 + 2pip = 7.41520
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41509, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41530, 0.0004));  // trigger client price
        }
        then:
        // Therefore max total we can stream is 1.5mio
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41519));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(1));
        }
        when:
        // Deactivation threshold 7.41500 + (3pip+0.5pip) = 7.41535
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41526, 0.0002));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41531, 0.0004));  // trigger client price
        }
        then:
        // EUR/DKK BID price 7.41536 has NOT moved beyond Deactivation threshold
        // Therefore remove clipping
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41536));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getBids().size(), Matchers.is(5));
            assertThat(cpEURDKK_wspA.getModifiedBookReason(), is(ModifiedBookReason.NOT_DEFINED));
        }
    }
}

