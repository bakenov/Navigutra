package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketsSnapshotImpl;

public class SnapshotBuilderModule extends AbstractModule {

    private final Symbol MARKET_DATA_SNAPSHOT_MESSAGE = MessageBus.getMessageType(MarketDataSnapshot.class);

    private final MarketsSnapshotImpl marketsSnapshot = new MarketsSnapshotImpl();

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.sub(this::consumeInc, MarketDataIncrement.class);
        messageBus.sub(this::consumeSnap, MarketDataSnapshot.class);
    }

    private void consumeInc(MarketDataIncrement inc) {
        consumeMarketData(inc, true);
    }

    private void consumeSnap(MarketDataSnapshot snap) {
        if (getStage().getMessageBus().isInputEvent()) {
            consumeMarketData(snap, false);
        } else {
            // ignore - we published the snapshot.
        }
    }

    private void consumeMarketData(MarketData newMarketData, boolean publish) {
        final FilteredMarketDataSnapshotImpl rawPoolInstance = (FilteredMarketDataSnapshotImpl) marketsSnapshot.getByMarketAndInstrumentAllocateIfAbsent(newMarketData.getMarket(), newMarketData.getInstrument());
        marketsSnapshot.updateWith(newMarketData, rawPoolInstance);
        if (publish) {
            getStage().getMessageBus().pub(MARKET_DATA_SNAPSHOT_MESSAGE, rawPoolInstance);
        }
    }

}
