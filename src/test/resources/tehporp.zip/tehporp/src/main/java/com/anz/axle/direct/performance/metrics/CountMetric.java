package com.anz.axle.direct.performance.metrics;

public class CountMetric implements Metric<Count> {
    private final String name;
    private final double frequancyScale;
    private long count;

    public CountMetric(final String name, final double frequencyScale) {
        this.name = name;
        this.frequancyScale = frequencyScale;
        this.count = 0;
    }

    public void record() {
        record(1);
    }

    @Override
    public void record(final long value) {
        count++;
    }

    @Override
    public Count snapshot() {
        return new CountSnapshot(name, count, frequancyScale);
    }

    @Override
    public void clear() {
        this.count = 0;
    }

    @Override
    public String getName() {
        return name;
    }

    private final class CountSnapshot implements Count {
        private final long count;
        private final double frequencyScale;
        private String name;

        public CountSnapshot(final String name, final long count, final double frequancyScale) {
            this.name = name;
            this.count = count;
            this.frequencyScale = frequancyScale;
        }

        @Override
        public long getCount() {
            return count;
        }

        @Override
        public double getRate() {
            return count * frequencyScale;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return "CountSnapshot" +
                    "name = '" + name + '\'' +
                    ", count = " + count +
                    ", frequencyScale = " + frequencyScale +
                    '}';
        }
    }
}
