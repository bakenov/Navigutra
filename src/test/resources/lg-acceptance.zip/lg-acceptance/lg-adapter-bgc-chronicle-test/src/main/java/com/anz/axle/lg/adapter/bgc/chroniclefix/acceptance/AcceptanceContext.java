package com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;

public interface AcceptanceContext extends SharedAcceptanceContext {
}
