package com.anz.axle.lg.adapter.bgc;

import java.util.Objects;

import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;

public class UpstreamSnapshotFullRefreshHandlerRouter implements SnapshotFullRefreshHandler {

    private final SnapshotterDecoderLookup snapshotterDecoderLookup;
    private SnapshotFullRefreshHandler handlerDelegate;
    private int source;
    private long sourceSeq;

    public UpstreamSnapshotFullRefreshHandlerRouter(final SnapshotterDecoderLookup snapshotterDecoderLookup) {
        this.snapshotterDecoderLookup = Objects.requireNonNull(snapshotterDecoderLookup);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        handlerDelegate = null;
        this.source = source;
        this.sourceSeq = sourceSeq;
    }

    @Override
    public void onBody(final Body body) {

        final SnapshotterDecoderSupplier supplier = snapshotterDecoderLookup.lookup(body);

        handlerDelegate = supplier.upstreamDecoderConnector().snapshotFullRefresh();
        handlerDelegate.onMessageStart(0, 0);
        handlerDelegate.onBody(body);
    }

    @Override
    public void onMdEntriesStart(final int maxEntryCount) {
        handlerDelegate.onMdEntriesStart(maxEntryCount);
    }

    @Override
    public void onMdEntries_Body(final MdEntries.Body entry, final int entryIndex, final int maxEntryCount) {
        handlerDelegate.onMdEntries_Body(entry, entryIndex, maxEntryCount);
    }

    @Override
    public void onMdEntriesComplete(final int entryCount) {
        handlerDelegate.onMdEntriesComplete(entryCount);
    }

    @Override
    public void onHopsStart(final int maxHopsCount) {
        handlerDelegate.onHopsStart(maxHopsCount);
    }

    @Override
    public void onHops_Body(final Hops.Handler.Body hop, final int hopsIndex, final int hopsCount) {
        handlerDelegate.onHops_Body(hop, hopsIndex, hopsCount);
    }

    @Override
    public void onHopsComplete(final int hopsCount) {
        handlerDelegate.onHopsComplete(hopsCount);
    }

    @Override
    public void onMessageComplete() {
        handlerDelegate.onMessageComplete();
        handlerDelegate = null;
    }
}
