package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.HeaderDecoder;

public interface PricingRefreshCompleteDecoder extends HeaderDecoder {

    Body body();
    void appendTo(StringBuilder stringBuilder);

    interface Body {
        long instrumentId();
        boolean forceSnapshot();
    }
}
