package com.anz.axle.adapters.ndf2trep.publisher;

public interface Scheduler {

    void submit(Runnable runnable);
}
