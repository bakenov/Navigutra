package com.anz.markets.efx.ngaro.collections;

public enum AnimalEnum {
    UNKNOWN,
    CAT,
    DOG,
    HIPPO,
    MOUSE,
    PENGUIN(true);

    private final boolean flag;

    AnimalEnum() {
        this(false);
    }

    AnimalEnum(final boolean flag) {
        this.flag = flag;
    }

    public boolean isFlag() {
        return flag;
    }

    public boolean isNot() {
        return false;
    }

    public static final AnimalEnum[] VALUES = AnimalEnum.values();
}
