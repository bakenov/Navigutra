package com.anz.axle.lg.adapter.d3.newsubscription;

import de.digitec.d3.pricing.streaming.UpdateMessage;

@FunctionalInterface
public interface UpdateProcessor {
    void processUpdate(final UpdateMessage updateMessage);
}
