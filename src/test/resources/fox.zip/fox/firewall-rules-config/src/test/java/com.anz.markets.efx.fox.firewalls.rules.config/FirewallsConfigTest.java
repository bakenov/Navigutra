package com.anz.markets.efx.fox.firewalls.rules.config;

import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import static org.assertj.core.api.Assertions.assertThat;

public class FirewallsConfigTest {

    SimpleDateFormat dateformat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @Test
    public void loadUnitTestLoadRulesYamlFileAssertValuesAreExpected() throws IOException, ParseException {
        dateformat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        final InputStream inputStream = this.getClass()
                .getClassLoader()
                .getResourceAsStream("conf/unitTestLoadRules.yaml");

        FirewallsConfig firewallsConfig = FirewallsConfig.yaml().load(inputStream);

        assertThat(firewallsConfig.getFirewalls()).isNotNull();
        assertThat(firewallsConfig.getFirewalls().size()).isEqualTo(1);

        FirewallRuleCategoryConfig firewallRuleCategoryConfig = firewallsConfig.getFirewalls().get("inbound-parent-order-rules");

        assertThat(firewallRuleCategoryConfig).isNotNull();
        List<FirewallTypeConfig> firewallTypeConfigs = firewallRuleCategoryConfig.getFirewallTypeConfigs();
        assertThat(firewallTypeConfigs).isNotNull();
        assertThat(firewallTypeConfigs.size()).isEqualTo(5);

        FirewallTypeConfig firstFirewall = firewallTypeConfigs.get(0);

        assertThat(firstFirewall).isNotNull();
        assertThat(firstFirewall.getFirewallName()).isEqualToIgnoringCase("Inbound Burst Submit Order Throughput");

        FirewallConfigInstance firstConfigInstance = firstFirewall.getConfiguredInstances().get(0);

        assertThat(firstConfigInstance).isNotNull();
        assertThat(firstConfigInstance.getRuleId()).isEqualTo(10);
        assertThat(firstConfigInstance.getRegionPattern()).isEqualToIgnoringCase("*");
        assertThat(firstConfigInstance.getOrderTypePattern()).isEqualToIgnoringCase("SWEEPER");
        assertThat(firstConfigInstance.getDeskPattern()).isEqualToIgnoringCase("EFX_UK");
        assertThat(firstConfigInstance.getPortfolioPattern()).isEqualToIgnoringCase("P_EFX");
        assertThat(firstConfigInstance.getUsernamePattern()).isEqualToIgnoringCase("autotrader-MidHedger");
        assertThat(firstConfigInstance.getVenuePattern()).isEqualToIgnoringCase("EBS");
        assertThat(firstConfigInstance.getSecurityTypePattern()).isEqualToIgnoringCase("FX_NDF");
        assertThat(firstConfigInstance.getTenorPattern()).isEqualToIgnoringCase("1M");
        assertThat(firstConfigInstance.getSymbolPattern()).isEqualToIgnoringCase("EUR/USD");
        assertThat(firstConfigInstance.getLimitThreshold()).isEqualTo(20);
        assertThat(firstConfigInstance.getPeriod()).isEqualTo(60);
        assertThat(firstConfigInstance.getPeriodUnit()).isEqualToIgnoringCase("s");
        assertThat(firstConfigInstance.getLastEditUsername()).isEqualToIgnoringCase("sawenkoa");
        assertThat(firstConfigInstance.getLastEditTime()).isEqualTo(dateformat2.parse("2019-04-01 12:58:25"));
        assertThat(firstConfigInstance.getComment()).isEqualTo("MidHedgerOrdersSubmitThroughput1s");
    }
}