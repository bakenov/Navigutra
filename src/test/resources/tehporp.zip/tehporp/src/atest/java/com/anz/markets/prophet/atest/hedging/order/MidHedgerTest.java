package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.pricing._8_sanity.OverallProfitVolumeFirewallTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTakeProfitHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.HedgePortfolioState;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.util.SystemProperties;
import org.apache.logging.log4j.Level;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerState.CANCELLING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.CANCEL_REQ;
import static com.anz.markets.prophet.domain.HedgeTriggerState.IDLE;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELLING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SLEEPING;
import static com.anz.markets.prophet.domain.HedgeTriggerType.AGR_AXL_TP;
import static com.anz.markets.prophet.domain.HedgeTriggerType.MID_BGC_EP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURGBP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCAD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.BGCMIDFX;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_ARBITRAGE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_RFX;
import static java.lang.Math.abs;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "As hedger states are left hanging")
public class MidHedgerTest extends BaseAcceptanceSpecification {
    NewOrder newOrder;
    NewOrder newOrder2;
    CancelOrder cancelOrder;

    @Test
    public void shouldNotEmitHedgingOrderWhenDisabled() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_700_000, 0.75005));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1));
            prophet.expect(HedgeDecision.class, exactly(0), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            assertThat(hedgeDecision.getQuantity(), is(1_000_000.));
            assertThat(hedgeDecision.getPrice(), is(Double.NaN));
            assertThat(hedgeDecision.getOrderId().length() == 0, is(true));
            prophet.expect(NewOrder.class, exactly(0));
        }
    }

    @Test
    public void shouldNotEmitHedgingOrderWhenEnabled() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_700_000, 0.75005));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1));
            prophet.expect(HedgeDecision.class, exactly(0), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
            final List<HedgeDecision> epDecisions = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(epDecisions.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ)); // from the client trade
            assertThat(epDecisions.get(1).getHedgeTriggerState(), is(HedgeTriggerState.IDLE)); // from the reset
            prophet.expect(NewOrder.class, exactly(0));
        }
    }

    @Test
    public void shouldNotEmitHedgingOrderWhenEnabledThroughOperatingHourChime() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(50_000.0)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "CLOSE Mon 01:00 GMT"));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_700_000, 0.75005));
            prophet.incrementTime(SystemProperties.OLD_ORDER_WARN_MS + 1);
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1));
            prophet.expect(HedgeDecision.class, exactly(0), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ)); // from the client trade
            prophet.expect(NewOrder.class, exactly(0));
        }
        when:
        {
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.HEDGER_MID_BGC, "OPEN Mon 01:00 GMT"));
        }
        then:
        {
            prophet.notExpect(Level.ERROR, matches(".*cancelling instead due to age.*"));
            prophet.expect(NewOrder.class, exactly(0));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3})
    public void highWatermarkLessThanOrdersizeValid() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(50000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(1_000_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        // send config where HighWaterMark is less than OrderSize Qty, this is a valid configuration
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(50000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(1_400_001.0)
                    )));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedger places order with new config i.e order qty 1.4ish mio
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
            assertThat(newOrder.getQuantity(), is(1_400_001.0));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3})
    public void checkHighWatermarkGreaterThanLowerWatermark() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(50000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(1_000_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        // send config where High-Watermark is just less than Lower-Watermark
        // => WARN in log "HedgeTriggerMidEqPos - riskTriggerHighWaterMark is < riskTriggerLowWaterMark for AUDUSD MID_BGC_EP"
        // But carry on using the new config (no config rollback)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(50000)
                                    .setRiskTriggerLowWaterMark(1_600_000.0)
                                    .setRiskTriggerHighWaterMark(1_599_999.9)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedger using new new config values does not place order(due to new HighWaterMark)
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            prophet.notExpect(NewOrder.class);
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        {
            // risk now at a level where the new values should place order
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
            assertThat(newOrder.getQuantity(), is(1_250_000.0));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3})
    public void operateWhenHighWatermarkBelowLowWatermark() {
        double lowWaterMarkTrigger = 1_900_000.0;
        double highWaterMarkTrigger = 800_000.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, USDCAD)
                                    .setVarTriggerHighVar(50000)
                                    .setRiskTriggerLowWaterMark(lowWaterMarkTrigger)
                                    .setRiskTriggerHighWaterMark(highWaterMarkTrigger)
                                    .setActiveBelowRisk(lowWaterMarkTrigger + 500_000)
                                    .setOrderQuantity(1_000_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDCAD, 700_000, 0.750000));
        }
        then:
        // above highWaterMark so eligible to place and order,
        // but also below lowWaterMark so risk is ok and this takes precedence
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(USDCAD, lowWaterMarkTrigger));
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(USDCAD, HedgeTriggerType.MID_BGC_EP));
            prophet.notExpect(NewOrder.class);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDCAD, 700_000, 0.750000));
        }
        then:
        {
            // above highWaterMark and lowWaterMark so eligible to place and order,
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(USDCAD, lowWaterMarkTrigger));
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(USDCAD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(USDCAD));
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(10_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDCAD, -300_000, 0.750000));
        }
        then:
        {
            // above highWaterMark so eligible to place and order,
            // but also below lowWaterMark so risk is ok and this takes precedence and no need to hedge
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(USDCAD, lowWaterMarkTrigger));
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(USDCAD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            prophet.expect(CancelOrder.class, exactly(1)).getFirst();
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3, Requirement.Ref.HEDGING_4_7_1})
    public void sendOrderWithCorrectOrderDetails() {
        double orderQty = 1_000_000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(orderQty)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // Risk highwatermark reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));
        }
        and:
        {
            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getQuantity(), is(orderQty));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
            assertThat(newOrder.getPrice(), is(Double.NaN));  // No price
            assertThat(newOrder.getId().length() > 0, is(true));
            assertThat(newOrder.getMarket(), is(Market.BGCMIDFX));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3, Requirement.Ref.HEDGING_4_7_1})
    public void sendOrderWhenLongPosReachesRiskHighWaterMark() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_001.5)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // Risk highwatermark not reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));
        }
        and:
        // no hedging order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1, 0.750000));
        }
        then:
        // GradientPosition EQUALS Risk highwatermark reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500001.5));
        }
        and:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void sendOrderWhenBiasedPosReachesRiskHighWaterMark() {
        double highWaterMark = 1_500_001;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // Risk highwatermark not reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));
        }
        and:
        // no hedging order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, 2_000_001.0));
        }
        then:
        // GradientPosition above Risk highwatermark. Send Hedge order
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1500001.5));
        }
        and:
        // since short biased position => BUY (unbiased pos is still long though)
        {
            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3, Requirement.Ref.HEDGING_4_7_1})
    public void sendOrderWhenShortPosReachesHighWaterMark() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_001.5)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // Risk highwatermark not reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1500000.0));
        }
        and:
        // no hedging order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1, 0.750000));
        }
        then:
        // GradientPosition EQUALS Risk highwatermark reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1500001.5));
        }
        and:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.BUYING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_7_2, Requirement.Ref.HEDGING_4_7_3})
    public void continueToSendEpHedgingOrderUntilBelowLowWaterMark() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still below LowWaterMark. No need to hedge
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(AUDUSD, lowWaterMark));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void canEmitMultipleEpHedgingOrdersMultiCcy() {
        double highWaterMark = 1_500_000.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(GBPUSD, -800_000, 1.25000));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(GBPUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 1_200_000, 0.85000));
        }
        then:
        // gradient position meets high watermark level for both currencies
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition eurGBPOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURGBP).findFirst().get();
            assertThat(Math.abs(eurGBPOp.getGradientPositionInNotional()) >= highWaterMark, is(true));

            final OptimalPosition gbpUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == GBPUSD).findFirst().get();
            assertThat(Math.abs(Math.abs(gbpUSDOp.getGradientPositionInNotional())) >= highWaterMark &&
                    gbpUSDOp.getGradientPositionInNotional() < 0, is(true));
        }
        and:
        // hedger places orders for both currencies
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
            assertThat(newOrder2.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void sendEpOrdersAdheringThrottleLimitsOnOneSecBoundary() {
        final long msOffset = 0;
        sendEpOrdersAdheringThrottleLimits(msOffset);
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void sendEpOrdersAdheringThrottleLimitsOffOneSecBoundary() {
        final long msOffset = 100;
        sendEpOrdersAdheringThrottleLimits(msOffset);
    }

    private void sendEpOrdersAdheringThrottleLimits(long initialTimeOffset) {
        int throttleLimitOrders = 2;
        long throttleLimitTimePeriod = 2000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1sec
        {
            prophet.incrementTime(initialTimeOffset);

            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
            prophet.receive(tdd.client_trade_001(GBPUSD, -1_000_000, 1.25000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
        }
        when:
        // t+2.999sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(999));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));
        }
        then:
        // Due to throttle limits of 2 orders in last 2 seconds, order is throttled(ie. only SELL_REQ)
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_BGC_EP)).getFirst();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+3.000sec
        {
            prophet.clearOutputBuffer();
            // note that hedger will make decisions on the 1 sec chime, so no need to send another order
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));

            if (initialTimeOffset != 0) {
                // send a small order in to trigger a hedge decision as can't rely on the Second tick
                prophet.receive(tdd.client_trade_001(EURUSD, 1, 1.05000));
            }
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void doNotSendThrottledEpOrderOnOneSecTick() {
        int throttleLimitOrders = 2;
        long throttleLimitTimePeriod = 2000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
            prophet.receive(tdd.client_trade_001(GBPUSD, -1_000_000, 1.25000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
        }
        when:
        // t+2.5sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));
        }
        then:
        // Due to throttle limits of 2 orders in last 2 seconds, order is throttled(ie. only SELL_REQ)
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_BGC_EP)).getFirst();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+2.9sec receive client trade to reduce gradOp baack to 0
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -1_500_000, 1.05000));
        }
        then:
        // hedgeStatus updated back to IDLE
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_BGC_EP)).getFirst();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+3.000sec
        {
            prophet.clearOutputBuffer();
            // note that hedger will make decisions on the 1 sec chime, so no need to send another order
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2, Requirement.Ref.HEDGING_4_7_2})
    public void sendEpOrdersAdheringRejectThrottleLimits() {
        int rejectThrottleLimit = 2;
        long rejectThrottleTimePeriod = 2000;
        NewOrder resendOrder1;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitRejectNumberOrder(rejectThrottleLimit)
                                    .setThrottleLimitRejectTimePeriodMS(rejectThrottleTimePeriod)
                                    .setThrottleLimitNumberOrder(3)
                                    .setThrottleLimitTimePeriodMS(2000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000), // large number to effectively turn off
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000), // large number to effectively turn off
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
        }
        when:
        // t+1sec order 1 sent
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+1.5sec. Fill order1(acked at t+1). Send out order2
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec. Reject order2. Send order 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(newOrder2));
        }
        then:
        {
            resendOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2.5sec. Reject order3. Resend order is throttled(ie. only BUY_REQ) since 2 reject received
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(resendOrder1));
        }
        then:
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        //t+4.0sec. First reject slides out. Hedger allowed to place order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1) + TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void doNotSendPrevTriggeredEpOrderAfterUpdatedEP() {
        int throttleLimitOrders = 2;
        long throttleLimitTimePeriod = 2000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // large number to effectively turn off
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
            prophet.receive(tdd.client_trade_001(GBPUSD, -1_000_000, 1.25000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
        }
        when:
        // t+2.99999sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(999));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));
        }
        then:
        // Due to throttle limits of 2 orders in last 2 seconds, order is throttled(ie. only SELL_REQ)
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_BGC_EP)).getFirst();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+3.99999sec
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -1_500_000, 1.05000));
        }
        then:
        // Latest GradientPos for EURUSD is 0, so no order placed
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(EURUSD, 0.0));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_4})
    public void epTriggeredOrderSupersedeVarTriggeredOrder() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // both Risk Triggered(High Watermark) level and VAR Trigger level breached.
        // Risk triggered order supersede Var trigger order so Risk Triggered order is sent
        {
            HedgeDecision varHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR)).getLast();
            assertThat(varHedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));

            HedgeDecision epHedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(epHedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.BUYING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3})
    public void cancelOrderWhenGradientPosReachesLowWaterMark() {
        double lowWaterMarkTrigger = 750_000.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(lowWaterMarkTrigger)
                                    .setRiskTriggerHighWaterMark(1_400_000)
                                    .setOrderQuantity(1_000_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        // t+5 receive client trade
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, -250_000, 0.750000));
        }
        then:
        // since gradient position still above Low-water mark trigger do NOT cancel open order
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMarkTrigger));

            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -250_000, 0.750000));
        }
        then:
        // gradient pos equals Low-Watermark
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 750_000.0));
        }
        and:
        // hedger cancels open order
        {
            final List<HedgeDecision> statuses = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(statuses.get(0).getHedgeTriggerState(), is(HedgeTriggerState.CANCEL_REQ));
            assertThat(statuses.get(1).getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            assertThat(cancelOrder.getInstrument(), is(AUDUSD));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void autoCancelOrderOnceMinimumTTLMet() {
        long minimumTTL = 3000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(750_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("MID_BGC_EP;posNotional=1000000;epNotional=1500000;epNotionalPeak=1500000"));
        }
        when:
        // t+1 ACK hedge order and receive client trade to reduce grad pos below low watermark which triggers hedger to cancel open order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // since minimumTTL not met, open hedge order not cancel
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCEL_REQ));

            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // t+4 i.e 3 secs since being acked, cancel open hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD));
            assertCancelComment("MID_BGC_EP;posNotional=0;epNotional=0;riskComfortable=true;riskSwitchedSides=false");
        }
    }

    @Test
    public void cancelOnceAckedAndMinTTLMet() {
        double varTriggerLevel = 5863;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(2_000).setMaximumOpenVarOrders(50).setCancelUnknownTimeoutMS(10_000),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
        }
        and:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, SELLING));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        // t+5 receive client trade to reduce var below trigger level
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // var(5862.84) below trigger level. Trigger wants to cancel, but since order not acked, cannot send cancel yet.
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() < varTriggerLevel, is(true));

            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // once order acked and minTTLive(2 sec) is met, then send cancel order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        then:
        // no cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, CANCELLING));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // tick time (time in market = 1 sec)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedger cancels open order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, CANCELLING));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // tick time (time in market = 2 sec)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedger cancels open order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, CANCELLING));
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
    }

    @Test
    public void retractCancelDecision() {
        double varTriggerLevel = 5863;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+5 receive client trade to reduce var below trigger level
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // var(5862.84) below trigger level. Since order not acked, cannot send cancel yet.
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() < varTriggerLevel, is(true));

            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // order acked. Must wait for minTTL before allowed to send cancel.  Meanwhile client trade received increases var above trigger level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 100, 0.75000));
        }
        then:
        // hedger retracts cancel request and returns to SELLING
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, SELLING));
        }
        when:
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74998));
        }
        then:
        {
            prophet.notExpect(CancelOrder.class);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void doNotAutoCancelOrderOnceMinimumTTLMet() {
        long minimumTTL = 3000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(750_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 ACK hedge order and receive client trade to reduce grad pos below low watermark which triggers hedger to cancel open order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // since minimumTTL not met, open hedge order not cancelled yet, but have requested intention to cancel the sell order
        {
            HedgeDecision hd = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hd.getHedgeTriggerState(), is(CANCEL_REQ));
        }
        when:
        // t+2 receive client trade to increase grad pos ABOVE low watermark so no need to cancel open order once minTTL met, so no longer need to cancel
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 600_000, 0.750000));
        }
        then:
        // hedgestate updated back to SELLING
        {
            HedgeDecision hd = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hd.getHedgeTriggerState(), is(SELLING));
        }
        when:
        // t+3 do NOT cancel open hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
        }
    }

    @Test
    public void cancelOrderWhenGradientPosOppositeSide() {
        double lowWaterMarkTrigger = 1.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(lowWaterMarkTrigger)
                                    .setRiskTriggerHighWaterMark(1_400_000)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        // t+5 receive client deal such that gradPos is now SHORT
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_005, 0.750000));
        }
        then:
        // gradient pos equals Low-Watermark
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -7.5));
        }
        and:
        // hedger cancels open order
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            assertThat(cancelOrder.getInstrument(), Matchers.is(AUDUSD));
            assertCancelComment("MID_BGC_EP;posNotional=-5;epNotional=-7;riskComfortable=false;riskSwitchedSides=true");
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_4})
    public void doNotReplaceOpenEpOrderWithVarOrder() {
        double varTriggerLevel = 5864;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 100, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
        }
        and:
        // Hedger does NOT send cancel for ep triggered AUD/USD open order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        and:
        // Hedger does place risk triggered AUD/USD order
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_4, Requirement.Ref.POSITION_AXPROPHET_964})
    public void sendOrderWhenVarReachesVarTriggeredLevel() {
        double varTriggerLevelEURGBP = 14872;
        double varTriggerLevelEURUSD = 14871;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP)
                                    .setVarTriggerHighVar(varTriggerLevelEURGBP)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setVarTriggerHighVar(varTriggerLevelEURUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }

        when:
        {
            prophet.clearOutputBuffer();
            // send bias - has NO impact on VAR calculations
            prophet.receive(tdd.biasPosition(Currency.EUR, 1_000_000.0));
            prophet.receive(tdd.client_trade_001(EURGBP, 2_000_000, 0.85000));
        }
        then:
        // VAR breaches EURUSD ONLY
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, exactly(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevelEURGBP, is(false));
            assertThat(var.getValue() >= varTriggerLevelEURUSD, is(true));
        }
        and:
        // only hedge EURUSD
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_BGC_VAR));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(EURUSD));

            prophet.notExpect(NewOrder.class, isOrderInstrument(EURGBP));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_6_1})
    public void sendVarOrdersForInstrumentWithSufficientRisk() {
        double varTriggerLevel = 11_140;
        double GBPUSDOrderQtyTooLarge = 1_900_000;
        double EURGBPOrderQty = 1_800_000;
        final OptimalPosition eurGBPOp;
        final OptimalPosition gbpUSDOp;
        final OptimalPosition eurUSDOp;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(GBPUSDOrderQtyTooLarge),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(EURGBPOrderQty),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(GBPUSD, -800_000, 1.25000));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(GBPUSD, HedgeTriggerType.MID_BGC_VAR));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 12_00_000, 0.85000));
        }
        then:
        // VAR greater than varTriggerLevel
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
        }
        and:
        // hedger places orders on instrument with GREATEST gradient pos.  |GBPUSD short| > EURGBP long > EURUSD long
        // instrument must also have sufficient risk i.e gradientPos >= orderQty
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            gbpUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == GBPUSD).findFirst().get();
            eurGBPOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURGBP).findFirst().get();
            eurUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURUSD).findFirst().get();

            // GBPUSD has highest gradientPos. Next highest is EURGBP
            assertThat(Math.abs(gbpUSDOp.getGradientPositionInNotional()) > eurGBPOp.getGradientPositionInNotional(), is(true));
            assertThat(eurGBPOp.getGradientPositionInNotional() > eurUSDOp.getGradientPositionInNotional(), is(true));
        }
        and:
        // GBPUSD has greatest gradient pos but does not have sufficient risk.
        // EURGBP and EURUSD have sufficient risk
        {
            assertThat(Math.abs(gbpUSDOp.getGradientPositionInNotional()) >= GBPUSDOrderQtyTooLarge, is(false));
            assertThat(Math.abs(eurGBPOp.getGradientPositionInNotional()) >= EURGBPOrderQty, is(true));
            assertThat(Math.abs(eurUSDOp.getGradientPositionInNotional()) >= 1_000_000, is(true));
        }
        and:
        // hedge EURGBP and EURUSD only
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(GBPUSD));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));

            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getFirst();
            assertThat(newOrder2.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void sendVarOrdersAdheringThrottleLimits() {
        int throttleLimitOrders = 4;
        long throttleLimitTimePeriod = 2000;
        NewOrder newOrder1;
        NewOrder newOrder2;
        NewOrder newOrder3;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDCAD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(500_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(AXL, USDCAD, 1.35000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, USDCAD, 1.35000));
        }
        when:
        // t+1sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -800_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(BGCMIDFX)).getLast();
        }
        when:
        // t+2sec
        {
            // order 1 acked at t+1 sec.  Only included in throttle count once confirmed
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(GBPUSD, -800_000, 1.25000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderMarket(BGCMIDFX));
        }
        when:
        // t+2.5
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 12_00_000, 0.85000));
        }
        then:
        {
            newOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getLast();
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP)).getLast();
            newOrder3 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+2.999 since 4 orders have been sent within last 2 secs, unable to send 5th order
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder2));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder3));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(499));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.client_trade_001(USDCAD, -800_000, 1.35000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(USDCAD));
        }
        // t+3 first order(acked at t+1) slides out of window.  Hedger able to place out order
        when:
        {
            prophet.clearOutputBuffer();
            // hedger will make decision on 1 sec chime
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
        }
        expect:
        {
            prophet.expect(NewOrder.class, isOrderInstrument(USDCAD));
        }
    }

    @Test
    public void placeOrdersInOrderOfHighestGradPosition() {
        int throttleLimitOrders = 3;
        long throttleLimitTimePeriod = 2000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -800_000, 0.75000));
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderMarket(BGCMIDFX)).getLast();
        }
        when:
        // t+2sec
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(GBPUSD, -800_000, 1.25000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderMarket(BGCMIDFX));
        }
        when:
        // t+2.99999sec
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(999));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 12_00_000, 0.85000));
        }
        then:
        // hedger places orders in order of highest gradient pos.  |GBPUSD short| > EURGBP long > EURUSD long
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition eurGBPOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURGBP).findFirst().get();
            final OptimalPosition gbpUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == GBPUSD).findFirst().get();
            final OptimalPosition eurUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURUSD).findFirst().get();

            assertThat(Math.abs(gbpUSDOp.getGradientPositionInNotional()) > eurGBPOp.getGradientPositionInNotional(), is(true));
            assertThat(eurGBPOp.getGradientPositionInNotional() > eurUSDOp.getGradientPositionInNotional(), is(true));
        }
        and:
        {
            LinkedList<NewOrder> newOrders = prophet.expect(NewOrder.class, exactly(3));
            assertThat(newOrders.get(0).getInstrument(), is(GBPUSD));
            assertThat(newOrders.get(1).getInstrument(), is(EURGBP));
            assertThat(newOrders.get(2).getInstrument(), is(EURUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_2})
    public void sendVarOrdersAdheringThrottleLimitsIgnoreRejects() {
        int throttleLimitOrders = 2;
        long throttleLimitTimePeriod = 1500;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setMaximumOpenVarOrders(50)
                                    .setThrottleLimitRejectNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitRejectTimePeriodMS(throttleLimitTimePeriod)
                                    .setThrottleLimitNumberOrder(3)
                                    .setThrottleLimitTimePeriodMS(5000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(5_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
        }
        when:
        // t+1 send hedging order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -800_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("MID_BGC_VAR;posNotional=-800000;epNotional=-1200000;var=4690"));
        }
        when:
        // t+1.5, hedge order REJECTED(first)
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("MID_BGC_VAR;posNotional=-800000;epNotional=-1200000;var=4690"));
        }
        when:
        // t+2, hedge order REJECTED(second).
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(newOrder2));
        }
        then:
        // Hedger unable to send another order due to REJECT throttle limit
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+3 first REJECT slides out. Hedger allowed to place order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("MID_BGC_VAR;posNotional=-800000;epNotional=-1200000;var=4690"));
        }
    }

    @Test
    public void doNotSendPrevRequestedVarOrderAfterUpdatedVarBelowTrigger() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()

                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
        }
        when:
        // t+1sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BOTH VAR order and EP order trigger level met.  Send EP order
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.BUYING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec hedge order filled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
        }
        then:
        // VAR is now 0. Do not send VAR order
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue(), is(0.0));
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_6_3})
    public void cancelVarOrderWhenVarBelowTriggerLevel() {
        double varTriggerLevel = 5863;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        // t+5 receive client trade to reduce var below trigger level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // var(5862.84) below trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() < varTriggerLevel, is(true));
        }
        and:
        // hedger cancels open order
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            assertThat(cancelOrder.getInstrument(), is(AUDUSD));
        }

        receiveFillReturnToIdle(newOrder); // prod issue of receiving fill while in cancel_req state
    }

    private void receiveFillReturnToIdle(NewOrder order) {
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(order, 0.75000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, IDLE)).getLast();
        }
    }

    @Test
    // Prod behaviour where hedger receives Trade first and then Order Event
    public void receiveOrderEventAfterTrade() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // receive Trade first(before order event)
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFillTrade(newOrder, 0.75);
        }
        then:
        // Trade reduces position below low water mark. Since trade is converted to OrderEvent, the hedger knows it caused the position change
        {
            prophet.notExpect(CancelOrder.class);
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
        when:
        // receive actual Order Event (this is a duplicate and should be ignored)
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFillOrderEvent(newOrder, 0.75);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            prophet.notExpect(NewOrder.class);
            prophet.notExpect(CancelOrder.class);
        }
    }

    @Test
    public void handleUnsolicitedOrderReject() {
        double varTriggerLevel = 5863;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level so send hedge order
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+5 receive order confirm and then order REJECT
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.hedgeUnsolicitedOrderReject(newOrder, 0, 0));
        }
        then:
        // hedger process order reject so decides to send hedge order out again
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
    }

    @Test
    public void handleCancelRejectAndContinueToCancel() {
        double varTriggerLevel = 5863;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        // t+5 receive client trade to reduce var below trigger level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // var(5862.84) below trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() < varTriggerLevel, is(true));
        }
        and:
        // hedger cancels open order
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void limitCancelRejectSentAndShutDown() {
        double varTriggerLevel = 5863;
        int maxCancelRejectLimit = 3;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setMaxNumberCancelRejects(maxCancelRejectLimit),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedgerFXALL").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)


                    )));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // t+5 receive client trade to reduce var below trigger level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // var(5862.84) below trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() < varTriggerLevel, is(true));
        }
        and:
        // hedger cancels open order
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            assertCancelComment("MID_BGC_VAR;posNotional=999900;epNotional=1499850;uncomfortableVar=false;timeToLiveExceeded=false");
        }
        when:
        // receive 1st CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            assertCancelComment("cancel retry 1");
        }
        when:
        // receive 2nd CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            assertCancelComment("cancel retry 2");
        }
        when:
        // receive 3rd CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            prophet.notExpect(CancelOrder.class);
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_MID_BGC, HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // t+10 receive client trade to reduce var below trigger level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            assertCancelComment("MID_BGC_VAR;posNotional=999900;epNotional=1499850;uncomfortableVar=false;timeToLiveExceeded=false");
        }
        when:
        // receive 1st CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        // hedger continues to cancel order and does NOT shut down
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(HEDGER_MID_BGC, HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    // prod behaviour where venues sends order confirm again instead of a cancelReject
    public void receivingOrderConfirmAfterCancelInfersCancelReject() {
        double varTriggerLevel = 5863;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(varTriggerLevel)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var equals var trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevel, is(true));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        // t+5 receive client trade to reduce var below trigger level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // var(5862.84) below trigger level
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() < varTriggerLevel, is(true));
        }
        and:
        // hedger cancels open order
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive Order Ack again(interpret as venue sending cancel reject)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        then:
        // should resent cancel
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3})
    public void varTriggeredOrderVarMaxTimeToLiveCancel() {
        long varTriggerMaxTtlMS = 10_000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerMaxTimeToLiveMS(varTriggerMaxTtlMS)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var trigger level reached
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= 1, is(true));
        }
        and:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        //t+5 order is acked. t+14 order is not cancelled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(9));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
        }
        when:
        //t+15 receive client trade to update var/op.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1, 0.75000));
        }
        then:
        // Hedger sends cancel for AUD/USD open order
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            assertThat(cancelOrder.getInstrument(), Matchers.is(AUDUSD));
            assertCancelComment("ttl exceeded 10000ms");
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3, Requirement.Ref.HEDGING_4_6_2})
    public void epTriggeredOrderNotCancelledAfterVarMaxTimeToLive() {
        long varTriggerMaxTtlMS = 10_000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerMaxTimeToLiveMS(varTriggerMaxTtlMS)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        {
            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
        when:
        //t+10 receive client trade to update var/op.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1, 0.75000));
        }
        then:
        // Hedger does NOT sends cancel for ep triggered AUD/USD open order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_4_5_3})
    public void doNotReplaceOpenVarOrderWithEpOrder() {
        Double highWaterMark = 1_500_001.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // receive client deal such that gradient position will be above high water-mark
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1, 0.75000));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, highWaterMark));
        }
        and:
        // Hedger does NOT send cancel for var triggered AUD/USD open order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        and:
        // Hedger does place risk triggered AUD/USD order
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void cancelOrderWhenHedgerManuallyTurnedOff() {
        long minimumTTL = 3000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        // t+0 hedging order sent
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 ACK hedge order and then hedger manually turned OFF
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_MID_BGC));
        }
        then:
        // since minimumTTL not met, cancel order not sent
        {
            // no hedge decision, HedgeOrderRule.stopTrading handles this internally (does not involve the HedgeTrigger)
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));

            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_MID_BGC, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        // t+4 i.e one minTTL is met, cancel open hedge order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_MID_BGC, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_MID_BGC, HedgePortfolioState.DISABLED));
        }
    }

    @Test
    // ensure hedger returns to IDLE
    public void cancelOrderWhenHedgerManuallyTurnedOffAndCancelTimeout() {
        long minimumTTL = 3000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true)
                                    .setHedgerName("autotrader-MidHedgerBGC")
                                    .setBookName("HEDGING_MODEL_M2")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL)
                                    .setCancelUnknownTimeoutMS(1_000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        // t+0 hedging order sent
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("MID_BGC_EP;posNotional=1500000;epNotional=2250000;epNotionalPeak=2250000"));
        }
        when:
        // t+1 ACK hedge order and then hedger manually turned OFF
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_MID_BGC));
        }
        then:
        // since minimumTTL not met, cancel order not sent
        {
            // no hedge decision, HedgeOrderRule.stopTrading handles this internally (does not involve the HedgeTrigger)
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));

            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_MID_BGC, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        // t+4 cancel open hedge order (as minimumTTL = 3sec)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            assertCancelComment("cancelled at min ttl 3000ms");

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_MID_BGC, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        // after one second the cancel order will timeout
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            // not sure why 2 of these??
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatus(HEDGER_MID_BGC, HedgePortfolioState.DISABLED));

            final List<HedgeDecision> status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(status.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            assertThat(status.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
        }
    }

    @Test
    public void sendEpOrderWhenHedgerManuallyTurnedOn() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        // t+0 receive client trade to generate gradpos
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+1 mid hedger is turned on
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        then:
        // hedger does not place order immediately on enable command
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // cause a new decision
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74995, 0.75000, now()));
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void continueToSendOnPartialFill() {
        double orderQty = 1_000_000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(orderQty)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }

        NewOrder newOrder;

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.750000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 50_000, 0.75);
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));
            OverallProfitVolumeFirewallTest.PositionsHelper positions = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsUpdates);
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(1_950_000.));

            final LinkedList<HedgeDecision> hedgeDecisions = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(hedgeDecisions.getFirst().getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            assertThat(hedgeDecisions.getLast().getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeInitialTradeEpTrigger() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(1_000_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));

            // Pause enabled(period set to 5 sec)
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // Risk highwatermark reached however PAUSE is active
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // PAUSE is manually disabled(HedgeCurrencyControl does not trigger order)
        {
            prophet.receive(tdd.setHedgingPause(Currency.AUD, false));
        }
        then:
        {
            prophet.expect(HedgeCurrencyControl.class, isHedgingCcyUnpaused(Currency.AUD));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // trigger hedge order via marketDataUpdate
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75000, now()));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeInitialTradeVarTrigger() {
        long DEFAULT_PAUSE_PERIOD_SEC = 5;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(3_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerMaxTimeToLiveMS(1_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));

            // Pause enabled(period set to 5 sec)
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // var trigger level reached, but PAUSE ACTIVE
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() >= 1, is(true));

            prophet.notExpect(NewOrder.class);
        }
        when:
        //t+5 PAUSE deactivated, HedgeCurrencyControl does not trigger hedge order
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), TimeUnit.SECONDS.toMillis(DEFAULT_PAUSE_PERIOD_SEC));
        }
        then:
        {
            prophet.expect(HedgeCurrencyControl.class, isHedgingCcyUnpaused(Currency.AUD));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // trigger hedge order via marketDataUpdate
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75000, now()));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_VAR));
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedToCancelOutstandingOrders() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_400_000.0)
                                    .setOrderQuantity(1_000_000)

                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));

            // PAUSE irrelevant ccy
            prophet.receive(tdd.setHedgingPause(Currency.EUR, true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // Risk highwatermark reached
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // PAUSE is ACTIVATED
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        then:
        // CANCEL outstanding order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, CANCELLING));
        }
        when:
        // minTTL met cancelOrder sent
        {
            prophet.incrementTime(1);
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // order cancelled
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        // return to SLEEPING
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, SLEEPING));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_1179})
    public void doNotHedgeOnEpTriggerIfTakeProfitIsActive() {
        double highWaterMarkTrigger = 1_600_000.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(100_000.)
                                    .setTriggeringTradeMultiplier(1.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(100_000.)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.)
                                    .setRiskTriggerHighWaterMark(highWaterMarkTrigger)
                                    .setOrderQuantity(1_000_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        // Take Profit hedger triggered.
        // (EP below highwatermark for mid hedger)
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(AUDUSD, highWaterMarkTrigger));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // EP above highwatermark so MID good to start hedging
        // however, since TP is still active MID DOES NOT HEDGE
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_200_000, 0.75000));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, highWaterMarkTrigger));
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, MID_BGC_EP, HedgeTriggerState.SELLING));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // TP order is filled
        // EP still above highWaterMark so Mid can hedge
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, highWaterMarkTrigger));
            prophet.expect(HedgeDecision.class, isHedgeDecision(AUDUSD, MID_BGC_EP, HedgeTriggerState.SELLING));
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_1179})
    public void doNotHedgeOnVarTriggerIfTakeProfitIsActive() {
        double varTriggerLevelEURUSD = 1;
        double highWaterMarkTrigger = 4_500_000.0;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.EURUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(100_000.)
                                    .setTriggeringTradeMultiplier(1.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(100_000.)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD)
                                    .setVarTriggerHighVar(varTriggerLevelEURUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(highWaterMarkTrigger)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // receive TP triggering counterparty trade
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_000, 0.85000, "TriggerClientCounterparty"));
        }
        then:
        // MID hedger VAR is breached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(EURUSD, highWaterMarkTrigger));
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, exactly(1)).getLast();
            assertThat(var.getValue() >= varTriggerLevelEURUSD, is(true));
        }
        and:
        // But TP takes precedence over MID. So only TP hedgers
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_BGC_VAR));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getPortfolio(), is(Portfolio.HEDGER_AGGRESSIVE));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_1170})
    public void hedgeWhenAboveHighWaterMarkAndBelowActiveBelowRisk() {
        double lowWaterMarkTrigger = 600_000.0;
        double highWaterMarkTrigger = 1_000_000.0;
        double activeBelowRisk = 1_450_000.0;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(lowWaterMarkTrigger)
                                    .setRiskTriggerHighWaterMark(highWaterMarkTrigger)
                                    .setActiveBelowRisk(activeBelowRisk)
                                    .setOrderQuantity(400_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        // EP above highwatermark BUT ABOVE activeBelowRisk.  Do not hedge
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, highWaterMarkTrigger));
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, activeBelowRisk));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // EP above highwatermark AND BELOW activeBelowRisk.  Therefore Hedge
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100_000, 0.75000));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, highWaterMarkTrigger));
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(AUDUSD, activeBelowRisk));
            prophet.expect(HedgeDecision.class, isHedgeDecision(AUDUSD, MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // EP moves ABOVE activeBelowRisk so cancel outstanding order
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 100_000, 0.75000));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, activeBelowRisk));
            final List<HedgeDecision> statuses = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(statuses.get(0).getHedgeTriggerState(), is(HedgeTriggerState.CANCEL_REQ));
            assertThat(statuses.get(1).getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getFirst();
        }
        when:
        // EP above highwatermark AND BELOW activeBelowRisk.  Therefore Hedge
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
            prophet.receive(tdd.client_trade_001(AUDUSD, -100_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // hedge order filled and EP still above LowWaterMark. Therefore Hedge
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMarkTrigger));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
    }

    private void assertCancelComment(final String cancelComment) {
        prophet.expect(Level.INFO, matches(".*CancelOrder.*comment=" + cancelComment + ".*"));
    }

}