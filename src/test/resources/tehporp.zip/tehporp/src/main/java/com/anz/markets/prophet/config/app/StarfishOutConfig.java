package com.anz.markets.prophet.config.app;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.um.OperationalModeValue;
import com.anz.markets.efx.messaging.transport.um.TransportValue;
import com.anz.markets.efx.messaging.transport.um.UmConfig;
import com.anz.markets.efx.messaging.transport.um.UmEndPointConfig;
import com.anz.markets.efx.messaging.transport.um.UmTransport;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.PauserFactory;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.event.EndEventAppenderReader;
import com.anz.markets.prophet.event.NoOpEndEventReader;
import com.anz.markets.prophet.marketdata.ClientPriceReader;
import com.anz.markets.prophet.marketdata.MarketDataReader;
import com.anz.markets.prophet.starfish.ClientPricePublisher;
import com.anz.markets.prophet.starfish.PublicationRegistry;
import com.anz.markets.prophet.starfish.UnskewedPricePublisher;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceRealTime;
import com.anz.markets.prophet.syscontrol.CoreMode;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.util.SystemProperties;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.function.Consumer;

@Configuration
@PropertySources({
        @PropertySource(value = "classpath:conf/starfish.out.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class StarfishOutConfig extends JmxConfig implements InitializingBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(StarfishOutConfig.class);

    @Autowired
    Environment env;

    @Value("${burnin.mode:false}")
    private boolean burnInMode = true;

    @Override
    public void afterPropertiesSet() throws Exception {
        if (burnInMode) {
            throw new Error("Running StarfishOut is not allowed in burn in mode. This error should have caused the process to shutdown.");
        }
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.starout:7}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    @Bean
    public ProphetPersister prophetPersister(
            @Value("${chronicle.star.out.path:./chronicle.star.out}") final String starOutChroniclePath,
            @Value("${chronicle.star.open.mode:APPEND}") final LegacyChroniclePersister.OpenMode openMode,
            @Value("${chronicle.ringBufferEnabled.starout_async:NO_RING}") final RingBuffer ringBuffer) throws IOException {

        Context.instance((byte) 0);
        Context.stage(Stage.STARFISHOUT);

        return ChroniclePersisterFactory.createStarOutPersister(starOutChroniclePath, openMode, ringBuffer);
    }

    @Bean
    public ProphetReader chronicleReader(@Value("${chronicle.starout.in.path:./chronicle.out}") final String path,
                                         @Value("${chronicle.ringBufferEnabled.core2starout:NO_RING}") final RingBuffer ringBuffer,
                                         final ThreadFactory threadFactory,
                                         final ChronicleObjectReader filteredMDSnapshotReader,
                                         final ChronicleObjectReader clientPriceReader,
                                         final ChronicleObjectReader hourChimeReader,
                                         final EndEventAppenderReader endEventAppenderReader,
                                         @Value("${allowable.lag.from.real.time.ms:1000}") final long allowableLagFromRealTimeMS) throws IOException {
        EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, filteredMDSnapshotReader);
        map.put(MessageType.CLIENT_PRICE, clientPriceReader);
        map.put(MessageType.HOUR_CHIME, hourChimeReader);
        map.put(MessageType.END_EVENT, endEventAppenderReader);

        final ChronicleObjectReader multiReader = new ChronicleObjectReaderMulti(map, true);
        return ChronicleReaderFactory.createStarOutReader(Executors.newSingleThreadExecutor(threadFactory), multiReader, path, allowableLagFromRealTimeMS, endEventAppenderReader, ringBuffer, PauserFactory.none());
    }

    @Bean
    public ProphetReader chronicleCrossDataReader(@Value("${chronicle.starout.cross.in.path:./chronicle.cross.out}") final String path,
                                                  final ThreadFactory threadFactory,
                                                  final ChronicleObjectReader crossClientPriceReader,
                                                  final EndEventAppenderReader crossEndEventAppenderReader,
                                                  @Value("${allowable.lag.from.real.time.ms:1000}") final long allowableLagFromRealTimeMS) throws IOException {
        EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CLIENT_PRICE, crossClientPriceReader);
        map.put(MessageType.END_EVENT, crossEndEventAppenderReader);

        final ChronicleObjectReader multiReader = new ChronicleObjectReaderMulti(map, true);
        return ChronicleReaderFactory.createStarOutReader(Executors.newSingleThreadExecutor(threadFactory), multiReader, path, allowableLagFromRealTimeMS, crossEndEventAppenderReader, RingBuffer.NO_RING, PauserFactory.create());
    }

    @Bean
    public EndEventAppenderReader endEventAppenderReader(final ProphetPersister prophetPersister,
                                                         @Value("${starout.write_star_out:true}") final boolean writeStarOut) {
        return createEndEventAppenderReader(prophetPersister, writeStarOut);
    }

    @Bean
    public EndEventAppenderReader crossEndEventAppenderReader(final ProphetPersister prophetPersister,
                                                              @Value("${starout.write_star_out:true}") final boolean writeStarOut) {
        return createEndEventAppenderReader(prophetPersister, writeStarOut);
    }

    private EndEventAppenderReader createEndEventAppenderReader(final ProphetPersister prophetPersister, final boolean writeStarOut) {
        return writeStarOut ? new EndEventAppenderReader(prophetPersister.sink(MessageType.END_EVENT)) : new NoOpEndEventReader();
    }

    @Bean
    public ChronicleReaderGeneric<HourChime> hourChimeReader() {
        final Consumer<HourChime> recalibrateTimeSource = (Context.context().timeSource() instanceof TimeSourceRealTime) ? ((TimeSourceRealTime) Context.context().timeSource()) : NoConsumer.instance();
        return new ChronicleReaderGeneric<>(HourChime.INSTANCE, recalibrateTimeSource);
    }

    @Bean
    public ClientPriceReader clientPriceReader(final ClientPricePublisher clientPricePublisher) throws IOException {
        return new ClientPriceReader(Arrays.asList(
                // all of the Consumer<ClientPrice> to receive every ClientPrice produced
                clientPricePublisher
        ));
    }

    @Bean
    public ClientPriceReader crossClientPriceReader(final ClientPricePublisher crossClientPricePublisher) throws IOException {
        return new ClientPriceReader(Arrays.asList(
                // all of the Consumer<ClientPrice> to receive every ClientPrice produced
                crossClientPricePublisher
        ));
    }

    @Bean
    public MarketDataReader filteredMDSnapshotReader(final UnskewedPricePublisher unskewedPricePublisher) {
        return new MarketDataReader(Arrays.asList(md -> unskewedPricePublisher.accept((FilteredMarketDataSnapshot)md)));
    }

    @Bean
    public ThreadFactory threadFactory() {
        return new ThreadFactoryBuilder().setNameFormat("chronicle-out-%d").build();
    }

    @Bean
    public ClientPricePublisher clientPricePublisher(final Connection connection,
                                                     final PublicationRegistry cppPublicationRegistry) {
        return new ClientPricePublisher(connection, cppPublicationRegistry, SystemProperties.CORE_MODE != CoreMode.TRIPLE);
    }

    @Bean
    public ClientPricePublisher crossClientPricePublisher(final Connection connection,
                                                          final PublicationRegistry ccppPublicationRegistry) {
        return new ClientPricePublisher(connection, ccppPublicationRegistry, false);
    }

    @Bean
    public UnskewedPricePublisher unskewedPricePublisher(final Connection connection,
                                                         final PublicationRegistry uppPublicationRegistry,
                                                         @Value("${um.subscribeAtStartup:true}") final boolean subscribeAtStartup) {
        return new UnskewedPricePublisher(connection, uppPublicationRegistry, subscribeAtStartup);
    }

    @Bean(destroyMethod = "close")
    public Connection connection(final UmConfig umConfig,
                                 @Value("${um.secondsToRetryEndpoint:10}") final long secondsToRetryEndpoint) {
        final PrecisionClock precisionClock = NanoClock.nanoClockUTC();
        final Transport transport = new UmTransport(precisionClock, umConfig);
        // creates another thread
        return transport.openConnection(() -> { /**/ });
    }

    @Bean
    public UmConfig umConfig(@Value("${um.transport}") final TransportValue transport,
                             @Value("${um.operational_mode}") final OperationalModeValue operationalMode,
                             @Value("#{${um.default.context.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultContextAttributes,
                             @Value("#{${um.default.source.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultSourceAttributes,
                             @Value("#{${um.default.receiver.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultReceiverAttributes,
                             @Value("#{'${um.unicast_resolvers}'.split(',')}") final Set<String> unicastResolvers) {
        final UmConfig config = new UmConfig() {

            @Override
            public UmEndPointConfig getEndPointConfig() {
                return UmEndPointConfig.forSingleTransport(transport);
            }

            @Override
            public OperationalModeValue getOperationalMode() {
                return operationalMode;
            }

            @Override
            public long getProcessEventsMillis() {
                return 0;
            }

            @Override
            public Map<String, ?> getDefaultContextAttributes() {
                return defaultContextAttributes;
            }

            @Override
            public Map<String, ?> getDefaultSourceAttributes() {
                return defaultSourceAttributes;
            }

            @Override
            public Map<String, ?> getDefaultReceiverAttributes() {
                return defaultReceiverAttributes;
            }

            @Override
            public Set<String> getResolverUnicastDaemons() {
                return unicastResolvers;
            }
        };
        config.logInfo(LOGGER);
        return config;
    }

    @Bean
    public PublicationRegistry cppPublicationRegistry(
            @Value("#{'${clientpricepublisher.models}'.split(',')}") final Set<Market> markets,
            @Value("#{'${clientpricepublisher.symbols}'.split(',')}") final Set<Instrument> instruments,
            @Value("#{'${clientpricepublisher.exclude.symbols:}'.split(',')}") final Set<Instrument> excludeInstruments,
            @Value("${clientpricepublisher.exclude.ndf:true}") final boolean excludeNDF,
            @Value("${clientpricepublisher.suffix:}") final String publisherSuffix
            ) {
        PublicationRegistry registry = new PublicationRegistry(publisherSuffix);
        registry.addAll(markets, instruments, excludeInstruments, excludeNDF);
        return registry;
    }

    @Bean
    public PublicationRegistry ccppPublicationRegistry(
            @Value("#{'${clientpricepublisher.models}'.split(',')}") final Set<Market> markets,
            @Value("#{'${clientpricepublisher.symbols}'.split(',')}") final Set<Instrument> instruments,
            @Value("#{'${clientpricepublisher.exclude.symbols:}'.split(',')}") final Set<Instrument> excludeInstruments,
            @Value("${clientpricepublisher.exclude.ndf:true}") final boolean excludeNDF,
            @Value("${clientpricepublisher.suffix:}") final String publisherSuffix
    ) {
        PublicationRegistry registry = new PublicationRegistry(publisherSuffix);
        registry.addAll(markets, instruments, excludeInstruments, excludeNDF);
        return registry;
    }

    @Bean
    public PublicationRegistry uppPublicationRegistry(
            @Value("#{'${unskewedpricepublisher.models}'.split(',')}") final Set<Market> markets,
            @Value("#{'${unskewedpricepublisher.symbols}'.split(',')}") final Set<Instrument> instruments,
            @Value("${unskewedpricepublisher.suffix:}") final String publisherSuffix
            ) {
        PublicationRegistry registry = new PublicationRegistry(publisherSuffix);
        registry.addAll(markets, instruments, Collections.emptySet(), false);
        return registry;
    }
}