package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

final class SbeTimerExpiryDecoder {
    private final TimerExpiryDecoder timerExpiryDecoder = new TimerExpiryDecoder();
    private final Consumer<StringBuilder> messageLogger = timerExpiryDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.TimerExpiry encodingOrder = EncodingOrder.TimerExpiry.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final TimerExpiryHandler timerExpiryHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.TimerExpiry.INITIAL;
        timerExpiryDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            timerExpiryHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            timerExpiryHandler.messageForwarder(messageForwarder);
            timerExpiryHandler.messageLogger(messageLogger);
            body.decode(timerExpiryHandler);
            timerExpiryHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.TimerExpiry.INITIAL;
            timerExpiryDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements TimerExpiryHandler.Body {
        void decode(final TimerExpiryHandler timerExpiryHandler) {
            encodingOrder = EncodingOrder.TimerExpiry.BODY;
            timerExpiryHandler.onBody(this);
        }

        @Override
        public long triggeredTime() {
            encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
            return timerExpiryDecoder.triggeredTime();
        }

        @Override
        public long timerId() {
            encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
            return timerExpiryDecoder.timerId();
        }

        @Override
        public TimerGroup timerGroup() {
            encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
            return Enums.timerGroup(timerExpiryDecoder.timerGroup());
        }
    }
}
