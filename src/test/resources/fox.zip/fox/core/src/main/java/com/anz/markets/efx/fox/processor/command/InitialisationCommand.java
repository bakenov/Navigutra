package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.sbe.InitialisationSbeDecoder;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class InitialisationCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(InitialisationCommand.class);

    private final CommandContext commandContext;
    private final InitialisationSbeDecoder initialisationDecoder = new InitialisationSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public InitialisationCommand(final CommandContext commandContext) {
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!initialisationDecoder.wrap(message)) return false;

        logMessage();
        commandContext.eventApplier().decode(message);
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        initialisationDecoder.appendTo(stringBuilder);
        LOGGER.info("Initialisation Command: {}", stringBuilder);
    }
}
