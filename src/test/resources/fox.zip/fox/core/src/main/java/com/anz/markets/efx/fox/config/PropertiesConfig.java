package com.anz.markets.efx.fox.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;
import java.util.Properties;

import com.anz.axle.applicationboot.EnvironmentResolver;
import com.anz.axle.spring.config.NestedPropertiesFactoryBean;

@Configuration
public class PropertiesConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(PropertiesConfig.class);

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer(@Qualifier("applicationProperties") final Properties properties) {
        final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        propertySourcesPlaceholderConfigurer.setProperties(properties);
        properties.forEach((key, value) -> LOGGER.info("           {}={}", key, value));

        return propertySourcesPlaceholderConfigurer;
    }

    @Bean
    NestedPropertiesFactoryBean applicationProperties() throws IOException {
        final NestedPropertiesFactoryBean propertiesFactoryBean = new NestedPropertiesFactoryBean();
        propertiesFactoryBean.setIgnoreResourceNotFound(true);
        propertiesFactoryBean.setEnv(EnvironmentResolver.environment());
        propertiesFactoryBean.setLocations(new String[]{
                "classpath:conf/fox-default.properties",
                "classpath:conf/fox-${env}.properties"
        });
        propertiesFactoryBean.setLoadSystemProperties(true);
        return propertiesFactoryBean;
    }
}
