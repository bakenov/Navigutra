package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.efx.ngaro.math.Epsilon;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.features.CapRiskLevelRefMarketFeatureSpecs;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_872})
public class ModelSpread_Ref_Mkt_Skew_Test extends BaseAcceptanceSpecification {

    private static final double EPSILON = Epsilon.EPS_1eNegative10.getValue();

    private ConfigurationDataDefault setUpConfiguration(double minRisk, double offset, final Market market) {

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        CapRiskLevelRefMarketFeatureSpecs specs = CapRiskLevelRefMarketFeatureSpecs.INSTANCE;

        // set up config for WSP_B ONLY
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_B,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_REF_MARKET, market,
                specs.PARAM_GRADIENT_POS_THRESOLD_USD, minRisk,
                specs.PARAM_OUTSIDE_OFFSET_PIPS, offset)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_B,
                Instrument.AUDUSD,
                TradingTimeZone.SNG,
                Region.ANY,
                specs.PARAM_REF_MARKET, Market.HSP,
                specs.PARAM_GRADIENT_POS_THRESOLD_USD, minRisk,
                specs.PARAM_OUTSIDE_OFFSET_PIPS, -0.5)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_REF_MARKET, null,
                specs.PARAM_GRADIENT_POS_THRESOLD_USD, Double.NaN,
                specs.PARAM_OUTSIDE_OFFSET_PIPS, Double.NaN)
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET, new Instrument[] { Instrument.AUDUSD }))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, false))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 1.0))  // set high Overall-skew threshold
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.2, 0.5),
                        new NetOpenPositionSkewRatioConfigImpl(0.5, 0.7),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.9)
                ))
                .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(10_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(10_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(10_000_000)
                ));

        final ArrayList<MarketConfig> marketConfigs = new ArrayList<>(configuration.getMarketConfigs());
        marketConfigs.add(
                        new MarketConfigImpl(Market.BARX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true));
        configuration.setMarketConfigs(marketConfigs);
        configuration.addAggBook(Market.WSP_U, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB, Market.BARX );
        configuration.addAggBook(Market.WSP_R, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB, Market.BARX );
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME,priceFormationPipelineConfig);

        return configuration;
    }

    @Test
    public void shortPosition_refMktWorsePrice() {
        final String dominantFeature;
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(506_000.0, 0.2, Market.BARX), false);
        }
        when:
        {
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        {
            // send reference market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75098, 0.75107));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // Ref mkt Offer + threshold = 0.75109 => worse than Current WSP_B Offer therefore apply skew
        {
            // WSP_A prices unchanged
            WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            // WSP_B wholesalebook factors impacted by risk/ref skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.25));
            assertThat(wbf_wspB.getBidSpreadModelSpreadRatio(), isNear(0.375));
            assertThat(wbf_wspB.getOfferSpreadModelSpreadRatio(), isNear(0.625));
            assertThat(wbf_wspB.getOverallWideningFactor(), isNear(1.33333));

            FeatureTraceLine ftl =  wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            dominantFeature = ftl.featureShortCode;
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.CAP_OFFER_VIA_SPREAD));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.OFFER_PRICE));
            assertThat(ftl.operations[0].oldVal, is(0.75108));
            assertThat(ftl.operations[0].newVal, is(0.75109));
            assertThat(ftl.data[0].var.toString(), is("refBid"));
            assertThat(ftl.data[0].fx, is(0.75098));
            assertThat(ftl.data[1].var.toString(), is("refAsk"));
            assertThat(ftl.data[1].fx, is(0.75107));
        }
        and:
        // new WSP_B client price
        {
            ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
            assertThat(clientPriceWSPB, isClientPricePoint(0, Level.QTY_1M, 0.7510500, 0.7510900));
            assertThat(clientPriceWSPB, isClientPricePoint(1, Level.QTY_2M, 0.7510350, 0.7511150));
            assertThat(clientPriceWSPB, isClientPricePoint(2, Level.QTY_2M, 0.7510275, 0.7511275));
            assertThat(clientPriceWSPB, isClientPricePoint(3, Level.QTY_5M, 0.7510150, 0.7511483));
            assertThat(clientPriceWSPB, isClientPricePoint(4, Level.QTY_5M, 0.7509575, 0.7512442));
            assertThat(clientPriceWSPB, isClientPricePoint(5, Level.QTY_5M, 0.7509125, 0.7513192));
            assertThat(clientPriceWSPB, isClientPricePoint(6, Level.QTY_10M, 0.7508450, 0.7514317));
            assertThat(clientPriceWSPB, isClientPricePoint(7, Level.QTY_10M, 0.7508150, 0.7514817));
            assertThat(clientPriceWSPB, isClientPricePoint(8, Level.QTY_10M, 0.7507175, 0.7516442));
            assertThat(clientPriceWSPB.getDominantFeatureBid().toString(), is(WholesaleBookFactorsImpl.INIT_FEATURE_NAME));
            assertThat(clientPriceWSPB.getDominantFeatureOffer().toString(), is(dominantFeature));
        }

        apply_ref_mkt_skew_given_biased_long_op_pos();
    }

    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void apply_ref_mkt_skew_given_biased_long_op_pos() {
        when:
        {
            prophet.receive(tdd.biasPosition(Currency.AUD, -10_500_000));
            // send reference market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75090, 0.75107));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75095, 0.00004));
        }
        then:
        // op position is now LONG. Therefore apply skew on BID side
        {
            final OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition op = optimalPositionsUpdates.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == Instrument.AUDUSD).findFirst().get();
            assertThat(op.getPositionInSystemBase(), is(750950.0));

            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.7509483908214286));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.684)); // 0.75094839 - (0.75090 - 0.00002)
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));
        }
    }

    @Test
    public void shortPosition_refMktBetterPrice_NegativeOffset() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(1_000_000.0, -0.2, Market.BARX), false);
        }
        when:
        {
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        // send reference market
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75098, 0.75109));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // Ref mkt Offer + (-threshold) = 0.75107 => better than Current WSP_B Offer therefore DO NOT apply skew
        // unchanged WSP_B client price
        {

            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            FeatureTraceLine ftl =  wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_NOIMPACT));

            // WSP_A and WSP_B same prices
            short_position_wsp_a_b_price_same();
        }
        and:
        // ref market updates while TOB agg book mid still unchanged
        {
            refMarketUpdateTriggersClientPriceCreation();
        }
    }

    // while agg book tob mid is unchanged after ref market updates, we still want to generate new client price
    // from no skew -> apply skew -> no skew
    public void refMarketUpdateTriggersClientPriceCreation() {
        when:
        // send reference market(to trigger skew) while agg book tob mid unchanged
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75098, 0.75111));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // Ref mkt Offer 0.75111 + (-threshold) = 0.75109 => worse than Current WSP_B Offer therefore APPLY skew
        {
            // WSP_B wholesalebook factors impacted by risk/ref skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.751065));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.25));
            assertThat(wbf_wspB.getBidSpreadModelSpreadRatio(), isNear(0.375));
            assertThat(wbf_wspB.getOfferSpreadModelSpreadRatio(), isNear(0.625));
            assertThat(wbf_wspB.getOverallWideningFactor(), isNear(1.33333));

            FeatureTraceLine ftl =  wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.CAP_OFFER_VIA_SPREAD));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.OFFER_PRICE));
            assertThat(ftl.operations[0].oldVal, is(0.75108));
            assertThat(ftl.operations[0].newVal, is(0.75109));
            assertThat(ftl.data[0].var.toString(), is("refBid"));
            assertThat(ftl.data[0].fx, is(0.75098));
            assertThat(ftl.data[1].var.toString(), is("refAsk"));
            assertThat(ftl.data[1].fx, is(0.75111));
        }
        when:
        // send reference market(to remove skew) while agg book tob mid unchanged
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75098, 0.75109));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // Ref mkt Offer 0.75109 + (-threshold) = 0.75107 => better than Current WSP_B Offer therefore NO skew
        {
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));

            FeatureTraceLine ftl =  wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_NOIMPACT));
        }
    }

    @Test
    public void shortPosition_notRefMktWorsePrice() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(1000000.0, 0.2, Market.BARX), false);
        }
        when:
        {
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        {
            // send market that is NOT reference market
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75098, 0.75107));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B Offer = 0.75108
        // non Ref mkt Offer + (threshold) = 0.75109 => worse than Current WSP_B Offer
        // unchanged WSP_B client price
        {
            short_position_wsp_a_b_price_same();
        }
    }

    @Test
    public void shortPosition_minRiskNotMet() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(10_750_000, 0.2, Market.BARX), false);
        }
        when:
        {
            // generate short gradient position of -10_701_750.0  i.e minRisk not Met
            risk_position_skew_on_short_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        {
            // send reference market
            // Current WSP_B Offer = 0.75108
            // Ref mkt Offer + threshold = 0.75109 => worse than Current WSP_B Offer
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75098, 0.75107));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // unchanged WSP_B client price
        {
            short_position_wsp_a_b_price_same();
        }
    }

    @Test
    public void longPosition_refMktWorsePrice() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(4_506_000.0, 0.1, Market.BARX), false);
        }
        when:
        {
            // generate long gradient position 6759000.0
            risk_position_skew_on_long_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        // send reference market
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75102, 0.75110));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B BID = 0.75102
        // Current Ref mkt BID = 0.75102
        // Ref mkt Bid 0.75102 - threshold = 0.75101 => worse than Current WSP_B BID therefore apply skew
        {
            // WSP_A prices unchanged
            WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751035));
            assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
            assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

            // WSP_B wholesalebook factors impacted by risk/ref skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getSkewedMidPrice(), is(0.751035));
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.25));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));
            assertThat(wbf_wspB.getBidSpreadModelSpreadRatio(), isNear(0.625));
            assertThat(wbf_wspB.getOfferSpreadModelSpreadRatio(), isNear(0.375));
            assertThat(wbf_wspB.getOverallWideningFactor(), isNear(1.33333));

            FeatureTraceLine ftl =  wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.CAP_BID_VIA_SPREAD));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.BID_PRICE));
            assertThat(ftl.operations[0].oldVal, is(0.75102));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.75101));
            assertThat(ftl.data[0].var.toString(), is("refBid"));
            assertThat(ftl.data[0].fx, is(0.75102));
            assertThat(ftl.data[1].var.toString(), is("refAsk"));
            assertThat(ftl.data[1].fx, is(0.75110));
        }
        and:
        // new WSP_B client price
        {
            ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
            assertThat(clientPriceWSPB, isClientPricePoint(0, Level.QTY_1M, 0.7510100, 0.7510500));
            assertThat(clientPriceWSPB, isClientPricePoint(1, Level.QTY_2M, 0.7509850, 0.7510650));
            assertThat(clientPriceWSPB, isClientPricePoint(2, Level.QTY_2M, 0.7509725, 0.7510725));
            assertThat(clientPriceWSPB, isClientPricePoint(3, Level.QTY_5M, 0.7509517, 0.7510850));
            assertThat(clientPriceWSPB, isClientPricePoint(4, Level.QTY_5M, 0.7508558, 0.7511425));
            assertThat(clientPriceWSPB, isClientPricePoint(5, Level.QTY_5M, 0.7507808, 0.7511875));
            assertThat(clientPriceWSPB, isClientPricePoint(6, Level.QTY_10M, 0.7506683, 0.7512550));
            assertThat(clientPriceWSPB, isClientPricePoint(7, Level.QTY_10M, 0.7506183, 0.7512850));
            assertThat(clientPriceWSPB, isClientPricePoint(8, Level.QTY_10M, 0.7504558, 0.7513825));
        }
    }

    @RestartBeforeTest(reason = "Volatility reset")
    @Test
    public void longPosition_refMktEqualPrice() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(1_000_000.0, 0.2, Market.BARX), false);
        }
        when:
        {
            risk_position_skew_on_long_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00008));
        }
        and:
        // send reference market
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75104, 0.75110));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00008));
        }
        then:
        // Current WSP_B BID = 0.75102
        // Current Ref mkt BID = 0.75103
        // Ref mkt Bid - (threshold) = 0.75102 =>  better than/equal to Current WSP_B Offer therefore NO skew
        {
            long_position_wsp_a_b_price_same();
        }
    }

    @Test
    public void longPosition_negativeThreshold() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(1_000_000.0, -0.1, Market.BARX), false);
        }
        when:
        {
            risk_position_skew_on_long_position();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
        }
        and:
        // send reference market
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75101, 0.75110));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        // Current WSP_B BID = 0.75102
        // Current Ref mkt BID = 0.75101
        // Ref mkt Bid - (threshold) = 0.75102 =>  better than/equal to Current WSP_B Offer therefore NO skew
        {
            long_position_wsp_a_b_price_same();
        }
    }

    public void risk_position_skew_on_short_position() {
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003));
            prophet.clearOutputBuffer();
            // send client deal to generate SHORT AUD position
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -9_500_000, 0.75100));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), is(-10_701_750.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        {
            short_position_wsp_a_b_price_same();
        }
    }

    public void short_position_wsp_a_b_price_same() {
        WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
        assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751065));
        assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
        assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
        assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
        assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

        WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
        assertThat(wbf_wspA.getSkewedMidPrice() == wbf_wspB.getSkewedMidPrice(), is(true));
        assertThat(wbf_wspA.getOverallBidSpreadInPips() == wbf_wspB.getOverallBidSpreadInPips(), is(true));
        assertThat(wbf_wspA.getOverallOfferSpreadInPips() == wbf_wspB.getOverallOfferSpreadInPips(), is(true));
        assertThat(wbf_wspA.getBidSpreadModelSpreadRatio() == wbf_wspB.getBidSpreadModelSpreadRatio(), is(true));
        assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio() == wbf_wspB.getOfferSpreadModelSpreadRatio(), is(true));

        ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
        assertThat(clientPriceWSPB, isClientPricePoint(0, Level.QTY_1M, 0.7510500, 0.7510800));
        assertThat(clientPriceWSPB, isClientPricePoint(1, Level.QTY_2M, 0.7510350, 0.7510950));
        assertThat(clientPriceWSPB, isClientPricePoint(2, Level.QTY_2M, 0.7510275, 0.7511025));
        assertThat(clientPriceWSPB, isClientPricePoint(3, Level.QTY_5M, 0.7510150, 0.7511150));
        assertThat(clientPriceWSPB, isClientPricePoint(4, Level.QTY_5M, 0.7509350, 0.7511950));
        assertThat(clientPriceWSPB, isClientPricePoint(5, Level.QTY_5M, 0.7508750, 0.7512550));
        assertThat(clientPriceWSPB, isClientPricePoint(6, Level.QTY_10M, 0.7507850, 0.7513450));
        assertThat(clientPriceWSPB, isClientPricePoint(7, Level.QTY_10M, 0.7507450, 0.7513850));
        assertThat(clientPriceWSPB, isClientPricePoint(8, Level.QTY_10M, 0.7506150, 0.7515150));
    }

    public void risk_position_skew_on_long_position() {
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003));
            prophet.clearOutputBuffer();
            // send client deal to generate LONG AUD position
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 9_500_000, 0.75100));
        }
        then:
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition op = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), is(10_701_750.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        then:
        {
            long_position_wsp_a_b_price_same();
        }
    }

    public void long_position_wsp_a_b_price_same() {
        WholesaleBookFactors wbf_wspA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
        assertThat(wbf_wspA.getSkewedMidPrice(), is(0.751035));
        assertThat(wbf_wspA.getOverallBidSpreadInPips(), isNear(0.15));
        assertThat(wbf_wspA.getOverallOfferSpreadInPips(), isNear(0.15));
        assertThat(wbf_wspA.getBidSpreadModelSpreadRatio(), isNear(0.5));
        assertThat(wbf_wspA.getOfferSpreadModelSpreadRatio(), isNear(0.5));

        WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
        assertEquals(wbf_wspA.getSkewedMidPrice(), wbf_wspB.getSkewedMidPrice(), EPSILON);
        assertEquals(wbf_wspA.getOverallBidSpreadInPips(), wbf_wspB.getOverallBidSpreadInPips(), EPSILON);
        assertEquals(wbf_wspA.getOverallOfferSpreadInPips(), wbf_wspB.getOverallOfferSpreadInPips(), EPSILON);
        assertEquals(wbf_wspA.getBidSpreadModelSpreadRatio(), wbf_wspB.getBidSpreadModelSpreadRatio(), EPSILON);
        assertEquals(wbf_wspA.getOfferSpreadModelSpreadRatio(), wbf_wspB.getOfferSpreadModelSpreadRatio(), EPSILON);

        ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getLast();
        assertThat(clientPriceWSPB, isClientPricePoint(0, Level.QTY_1M, 0.7510200, 0.7510500));
        assertThat(clientPriceWSPB, isClientPricePoint(1, Level.QTY_2M, 0.7510050, 0.7510650));
        assertThat(clientPriceWSPB, isClientPricePoint(2, Level.QTY_2M, 0.7509975, 0.7510725));
        assertThat(clientPriceWSPB, isClientPricePoint(3, Level.QTY_5M, 0.7509850, 0.7510850));
        assertThat(clientPriceWSPB, isClientPricePoint(4, Level.QTY_5M, 0.7509050, 0.7511650));
        assertThat(clientPriceWSPB, isClientPricePoint(5, Level.QTY_5M, 0.7508450, 0.7512250));
        assertThat(clientPriceWSPB, isClientPricePoint(6, Level.QTY_10M, 0.7507550, 0.7513150));
        assertThat(clientPriceWSPB, isClientPricePoint(7, Level.QTY_10M, 0.7507150, 0.7513550));
        assertThat(clientPriceWSPB, isClientPricePoint(8, Level.QTY_10M, 0.7505850, 0.7514850));
    }

    @Test
    public void updateConfigToApplyImmediately () {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(0.0, -0.2, Market.BARX), true);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        and:
        // send reference market
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75102, 0.75110));
        }
        then:
        // Current WSP_B BID = 0.751035
        // Current Ref mkt BID = 0.75102
        // Ref mkt Bid 0.75102 - (-threshold) = 0.75104 => not worse than Current WSP_B BID therefore NO skew
        {
            prophet.notExpect(WholesaleBookFactors.class, isWholesaleBookFactors(Market.WSP_B));
        }
        when:
        // update ref market to HSP
        // send HSP marketdata update to trigger skew
        {
            prophet.clearOutputBuffer();
            prophet.receive(setUpConfiguration(0.0, -0.2, Market.HSP), true);

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75099, 0.75110));
        }
        then:
        // Current WSP_B BID = 0.751035
        // Current Ref mkt BID = 0.75099
        // Ref mkt Bid 0.75099 - (-threshold) = 0.75101 => worse than Current WSP_B BID therefore apply skew
        {
            // WSP_B wholesalebook factors impacted by risk/ref skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.4));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));

            FeatureTraceLine ftl = wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.CAP_BID_VIA_SPREAD));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.BID_PRICE));
            assertThat(ftl.operations[0].oldVal, is(0.751035));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.75101));
            assertThat(ftl.data[0].var.toString(), is("refBid"));
            assertThat(ftl.data[0].fx, is(0.75099));
            assertThat(ftl.data[1].var.toString(), is("refAsk"));
            assertThat(ftl.data[1].fx, is(0.75110));
        }
        when:
        // Verify when TZ changes, uses correct config
        // SG threshold is -0.5pip
        {
            prophet.receive(TradingTimeZone.SNG);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75098, 0.75110));
        }
        then:
        // Current WSP_B BID = 0.751035
        // Current Ref mkt BID = 0.75099
        // Ref mkt Bid 0.75098 - (-threshold) = 0.75103 => worse than Current WSP_B BID therefore apply skew
        {
            // WSP_B wholesalebook factors impacted by risk/ref skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();


            FeatureTraceLine ftl = wbf_wspB.getPliableBookTrace().getFeatureTrace(CapRiskLevelRefMarketFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.CAP_BID_VIA_SPREAD));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.BID_PRICE));
            assertThat(ftl.operations[0].oldVal, is(0.751035));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.75103));
        }
    }

    @Test
    // AXPROPHET-1245
    public void updateConfigToApplyImmediatelyFromUM() throws Exception {
        precondition:
        {
            prophet.resetAllPositions();
            prophet.startUmProbes(setUpConfiguration(0.0, -0.2, Market.BARX), true);
            prophet.startUmOutSubscription(Market.WSP_U, Instrument.AUDUSD);
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(0.0, -0.2, Market.BARX), true, false);
        }
        when:
        {
            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75105, 0.00004));
        }
        and:
        // send reference market
        {
            prophet.clearOutputBuffer();
            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshotWithBidOffer(Market.BARX, Instrument.AUDUSD, 0.75102, 0.75110));
        }
        then:
        // Current WSP_B BID = 0.751035
        // Current Ref mkt BID = 0.75102
        // Ref mkt Bid 0.75102 - (-threshold) = 0.75104 => not worse than Current WSP_B BID therefore NO skew
        {
            prophet.notExpect(WholesaleBookFactors.class, isWholesaleBookFactors(Market.WSP_B));
        }
        when:
        // update ref market to HSP
        // send HSP marketdata update to trigger skew
        {
            prophet.receive(setUpConfiguration(0.0, -0.2, Market.HSP), true);
            prophet.clearOutputBuffers();

            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75099, 0.75110));
        }
        then:
        // Current WSP_B BID = 0.751035
        // Current Ref mkt BID = 0.75099
        // Ref mkt Bid 0.75099 - (-threshold) = 0.75101 => worse than Current WSP_B BID therefore apply skew
        {
            // WSP_B wholesalebook factors impacted by risk/ref skew
            WholesaleBookFactors wbf_wspB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wbf_wspB.getOverallBidSpreadInPips(), isNear(0.4));
            assertThat(wbf_wspB.getOverallOfferSpreadInPips(), isNear(0.15));
        }
        and:
        {
            prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U));
            prophet.expectFromUm(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U));
        }
    }
}
