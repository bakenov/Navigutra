package com.anz.axle.lg.adapter.apama.ebs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.change.EntriesChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.Side;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link EbsImplicitDeletionHandler}
 */
public class EbsImplicitDeletionHandlerTest {

    private static final double NO_TOLERANCE = 0.0;
    private static final String SYMBOL = "NZDJPY";
    private static final EbsBookRules.Config CONFIG = new DefaultEbsBookRules.DefaultConfig(3, 0.01, 5);

    //under test
    private EbsImplicitDeletionHandler ebsImplicitDeletionHandler;

    @Before
    public void beforeEach() {
        final PrecisionClock precisionClock = mock(PrecisionClock.class);
        final EbsBookRules ebsBookRules = mock(EbsBookRules.class);
        when(ebsBookRules.configFor(SYMBOL, SecurityType.FXSPOT)).thenReturn(CONFIG);
        ebsImplicitDeletionHandler = new EbsImplicitDeletionHandler(precisionClock, ebsBookRules);
    }

    @Test
    public void beforeForwardingIncrementalUpdate() throws Exception {
        //given
        final RequestKey requestKey = RequestKey.of(Venue.EBS, InstrumentKey.of(SYMBOL));
        final int initialEntriesCount = 10;
        final MarketDataBook book = new DefaultMarketDataBook(requestKey, initialEntriesCount);
        final MarketDataEntry[] bids = {bid(76.25), bid(76.21), bid(76.19), bid(76.15)};//last removed due to depth cutoff, second last due to price cutoff
        final MarketDataEntry[] asks = {ask(76.35), ask(76.37), ask(76.38), ask(76.39), ask(76.42), ask(76.47)};//last 3 removed due to depth cutoff
        Arrays.stream(bids).forEach(b -> book.bids().add(b, 0, EntriesChangedListener.NOOP));
        Arrays.stream(asks).forEach(a -> book.asks().add(a, 0, EntriesChangedListener.NOOP));
        final List<MarketDataEntry> removedEntries = new ArrayList<>();
        final EntriesChangedListener entriesChangedListener = new EntriesChangedListener() {
            @Override
            public void onEntryAdd(final MarketDataEntries entries, final int newIndex, final MarketDataEntry newEntry) {
                throw new AssertionError("Unexpected invocation");
            }

            @Override
            public void onEntryReplace(final MarketDataEntries entries, final int newIndex, final MarketDataEntry newEntry, final int oldIndex, final MarketDataEntry oldEntry) {
                throw new AssertionError("Unexpected invocation");
            }

            @Override
            public void onEntryRemove(final MarketDataEntries entries, final MarketDataEntry deletionEntry, final int removedIndex, final MarketDataEntry removedEntry) {
                //FIXME do we need to copy original transactTime here?
                final MarketDataEntry entry = new DefaultMarketDataEntry();
                //entry.entryId().set(removedEntry.entryId().toStringOrNull()); FIXME
                entry.side(removedEntry.side());
                entry.price(removedEntry.price());
                removedEntries.add(entry);
            }

            @Override
            public void onEntryNoOp(final MarketDataEntries entries, final MarketDataEntry noOpEntry) {
                throw new AssertionError("Unexpected invocation");
            }
        };

        //when
        ebsImplicitDeletionHandler.beforeBookChangeComplete(book, entriesChangedListener);

        //then
        assertEquals("Should cut off 2 bids + 3 asks", 5, removedEntries.size());
        int ind = 0;
        assertEquals("Cut off bid[3].side", Side.BID, removedEntries.get(ind).side());
        assertEquals("Cut off bid[3].price", 76.15, removedEntries.get(ind++).price(), NO_TOLERANCE);
        assertEquals("Cut off bid[2].side", Side.BID, removedEntries.get(ind).side());
        assertEquals("Cut off bid[2].price", 76.19, removedEntries.get(ind++).price(), NO_TOLERANCE);
        assertEquals("Cut off ask[5].side", Side.ASK, removedEntries.get(ind).side());
        assertEquals("Cut off ask[5].price", 76.47, removedEntries.get(ind++).price(), NO_TOLERANCE);
        assertEquals("Cut off ask[4].side", Side.ASK, removedEntries.get(ind).side());
        assertEquals("Cut off ask[4].price", 76.42, removedEntries.get(ind++).price(), NO_TOLERANCE);
        assertEquals("Cut off ask[3].side", Side.ASK, removedEntries.get(ind).side());
        assertEquals("Cut off ask[3].price", 76.39, removedEntries.get(ind++).price(), NO_TOLERANCE);
    }

    private static final MarketDataEntry bid(final double price) {
        return entry(Side.BID, price);
    }
    private static final MarketDataEntry ask(final double price) {
        return entry(Side.ASK, price);
    }
    private static final MarketDataEntry entry(final Side side, final double price) {
        final MarketDataEntry entry = new DefaultMarketDataEntry();
        final int entryId = (side == Side.BID ? 0 : 1) + (int)(price * 10000);
        return entry
                .entryId(entryId)
                .side(side)
                .price(price)
                .quantity(1000000);
    }

}