package com.anz.axle.lg.adapter.anz.quickfix;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.BidPx;
import quickfix.field.BidSize;
import quickfix.field.MsgSeqNum;
import quickfix.field.NoQuoteEntries;
import quickfix.field.NoQuoteSets;
import quickfix.field.OfferPx;
import quickfix.field.OfferSize;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteType;
import quickfix.field.SendingTime;
import quickfix.field.UnderlyingSymbol;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public final class AnzMassQuoteHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(AnzMassQuoteHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public AnzMassQuoteHandler(final VenueRequestKeyLookup requestKeyLookup,
                               final PricingEncoderLookup pricingEncoderLookup,
                               final PrecisionClock precisionClock,
                               final SubscriptionManager subscriptionManager,
                               final String senderCompId,
                               final String compId,
                               final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_MASS_QUOTE;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("MassQuote received: {}", message);
        final int quoteRequestId = message.getInt(QuoteReqID.FIELD);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = sequenceNumber;
        final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
        final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());

        final String fixSymbol6 = symbol6(message);
        final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(quoteRequestId);
        subscription.validateInternalSymbol(fixSymbol6);
        final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
        final SnapshotFullRefreshEncoder.Body bodyEncoder = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        flagsAppender.accept(bodyEncoder.mdFlags());
        if (isQuoteIndicative(message)) {
            bodyEncoder.mdFlags().add(Flag.INDICATIVE);
        }

        final SnapshotFullRefreshEncoder.Body mdEntries = bodyEncoder
                .possResend(false)
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .sendingTime(sendingTimeNanos)
                .referenceSpotDate().encodeNull()
                .tradeDate().encodeNull()
                .settlDate().encodeNull();

        encodeEntries(sendingTimeNanos, quoteEntryGroups(message), requestKey, mdEntries)
            .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(sequenceNumber)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
        .messageComplete();
    }

    private Hops.Encoder<MessageEncoder.Trailer> encodeEntries(final long sendingTimeNanos, final List<Group> quoteEntryGroups, final RequestKey requestKey, final SnapshotFullRefreshEncoder.Body mdEntries) throws FieldNotFound {
        final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = mdEntries.entriesStart(quoteEntryGroups.size() * 2);
        int entryId = 0;
        for (Group quoteEntryGroup : quoteEntryGroups) {
            final double bidPrice = quoteEntryGroup.getDouble(BidPx.FIELD);
            final double bidSize = quoteEntryGroup.getDouble(BidSize.FIELD);
            final double offerPrice = quoteEntryGroup.getDouble(OfferPx.FIELD);
            final double offerSize = quoteEntryGroup.getDouble(OfferSize.FIELD);

            mdEntries_Next
                .next()
                    .transactTime(sendingTimeNanos)
                    .mdMkt(requestKey.market())
                    .mdEntryType(EntryType.BID)
                    .mdEntrySize(bidSize)
                    .minQty(Double.NaN)
                    .mdEntryPx(bidPrice)
                    .mdEntryId(entryId++)
                    .quoteEntryId(0)
                .next()
                    .transactTime(sendingTimeNanos)
                    .mdMkt(requestKey.market())
                    .mdEntryType(EntryType.OFFER)
                    .mdEntrySize(offerSize)
                    .minQty(Double.NaN)
                    .mdEntryPx(offerPrice)
                    .mdEntryId(entryId++)
                    .quoteEntryId(0);
        }
        return mdEntries_Next.entriesComplete();
    }

    private String symbol6(final Message message) throws FieldNotFound {
        final List<Group> quoteEntryGroups = message.getGroups(NoQuoteSets.FIELD);
        String symbol = null;
        for (final Group quoteEntry : quoteEntryGroups) {
            symbol = quoteEntry.getString(UnderlyingSymbol.FIELD);
        }
        return SymbolNormaliser.toSymbol6(symbol);
    }

    private List<Group> quoteEntryGroups(final Message message) throws FieldNotFound {
        final List<Group> quoteSets = message.getGroups(NoQuoteSets.FIELD);
        if (quoteSets.size() != 1) {
            throw new IllegalArgumentException("ANZ MassQuote message contains one and only one QuoteSet " + message);
        }
        return quoteSets.get(0).getGroups(NoQuoteEntries.FIELD);
    }

    private boolean isQuoteIndicative(final Message message) throws FieldNotFound {
        return message.isSetField(QuoteType.FIELD) && message.getInt(QuoteType.FIELD) == QuoteType.INDICATIVE;
    }
}
