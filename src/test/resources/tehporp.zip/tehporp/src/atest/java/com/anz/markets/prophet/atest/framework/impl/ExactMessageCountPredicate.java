package com.anz.markets.prophet.atest.framework.impl;

import java.util.List;

public class ExactMessageCountPredicate implements MessageCountPredicate {

    private int count;

    public ExactMessageCountPredicate(final int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return String.format("Expect an exact count of %d message(s)", count);
    }

    @Override
    public boolean test(final List list) {
        return list != null && list.size() == count;
    }
}
