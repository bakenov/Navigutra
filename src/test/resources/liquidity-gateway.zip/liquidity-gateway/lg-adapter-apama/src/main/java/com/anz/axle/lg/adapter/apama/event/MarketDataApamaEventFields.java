package com.anz.axle.lg.adapter.apama.event;

import com.apama.event.parser.Field;
import com.apama.event.parser.FloatFieldType;
import com.apama.event.parser.StringFieldType;

/**
 * Declares market data fields, i.e. fields commonly occurring in market data full and market data incremental refresh apama event types
 */
public class MarketDataApamaEventFields {
    // MarketData fields
    public static final Field<String> FIELD_MD_REQ_ID = new Field<>("MDReqID", StringFieldType.TYPE);
    public static final MdEntryTypeField FIELD_MD_ENTRY_TYPE = new MdEntryTypeField();
    public static final Field<Double> FIELD_MD_ENTRY_PX = new Field<>("MDEntryPx", FloatFieldType.TYPE);
    public static final Field<Double> FIELD_MD_ENTRY_SIZE = new Field<>("MDEntrySize", FloatFieldType.TYPE);
    public static final Field<String> FIELD_MD_ORDER_ID = new Field<>("OrderID", StringFieldType.TYPE);
    public static final Field<String> FIELD_MD_ENTRY_ID = new Field<>("MDEntryID", StringFieldType.TYPE);
    public static final Field<String> FIELD_MD_UPDATE_ACTION = new Field<>("MDUpdateAction", StringFieldType.TYPE);
}
