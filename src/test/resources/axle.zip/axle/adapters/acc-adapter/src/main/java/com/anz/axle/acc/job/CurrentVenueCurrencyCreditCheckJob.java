package com.anz.axle.acc.job;

import com.anz.axle.acc.domain.BusinessLocalDate;
import com.anz.axle.acc.service.CreditUtilisationConsumerService;
import com.anz.axle.acc.service.CreditUtilisationProducerService;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Copyright (c) 2010, ANZ Banking Group Limited
 * 
 * <p>This job provides the consuming {@link com.anz.axle.acc.service.CreditUtilisationConsumerService} with information
 * on each currency pair on each venue and whether that current trading on that pair will result in a
 * spot date that has been breached from a credit perspective.</p>
 *
 * <p>The {@link CurrentVenueCurrencyCreditCheckJobListener} allows
 * the resulting {@link com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates} to be
 * used for other purposes.</p>
 *
 * @author jonesr18
 */
@Component("currentVenueCurrencyCreditCheckJob")
public class CurrentVenueCurrencyCreditCheckJob extends AbstractRecoverableJob implements Runnable {

    private static final Logger LOG = Logger.getLogger(CurrentVenueCurrencyCreditCheckJob.class);

    @Autowired
    @Qualifier("defaultCreditUtilisationProducerService")
    private CreditUtilisationProducerService creditUtilisationProducerService = null;

    @Autowired
    @Qualifier("datafabricCreditUtilisationConsumerService")
    private CreditUtilisationConsumerService creditUtilisationConsumerService = null;

    @Autowired
    @Qualifier ("doNothingCurrentVenueCurrencyCreditCheckJobListener")
    private CurrentVenueCurrencyCreditCheckJobListener listener = null;

    @Autowired
    @Qualifier("scheduler")
    private SchedulerFactoryBean schedulerFactory = null;

    /**
     * This property represents the number of days back trades should be used for
     * spot date utilisation. It should be around 1-7 days in order to cover the situation
     * where a currency pair's trade date would result in a spot date today.
     */
    public volatile int businessDaysBack = 7;
    
    private static final String TRIGGER_NAME = "currentVenueCurrencyCreditCheckJobTrigger";

    private AtomicLong runCount = new AtomicLong(0l);

    @Override
    public void run() {
        if(runCount.incrementAndGet() % 30 == 0) {
            LOG.info("running...");
        }
        LocalDate sinceWhen = new BusinessLocalDate(new LocalDate()).rollBack(businessDaysBack).getDate();
        LOG.debug("Start Venue Currency Credit Check job [since:" + sinceWhen + "]...");
        try {
            CurrentVenueCurrencyCreditStates states =
                creditUtilisationProducerService.findCurrentVenueCurrencyCreditStatesSince(sinceWhen);
            if(creditUtilisationConsumerService.consume(states)){
                listener.listen(states);
                awake();
            } else {
                sleep();
                LOG.error("Consumer service responded without success - no exception.");
            }
        } catch (Throwable th) {
            try {
                sleep();
            } catch (SchedulerException e) {
                LOG.error("There was a problem pausing the trigger after an exception", e);
            } finally {
                LOG.error("There was an issue sending data to the consumer service.", th);
            }
        } finally {
            LOG.debug("Venue Currency Credit Check job completed");
        }        
    }

    /**
     * For testing only.
     * @param creditUtilisationProducerService
     */
    protected void setCreditUtilisationProducerService(CreditUtilisationProducerService creditUtilisationProducerService) {
        this.creditUtilisationProducerService = creditUtilisationProducerService;
    }

    /**
     * For testing only.
     * @param creditUtilisationConsumerService
     */
    protected void setCreditUtilisationConsumerService(CreditUtilisationConsumerService creditUtilisationConsumerService) {
        this.creditUtilisationConsumerService = creditUtilisationConsumerService;
    }

    /**
     * For testing only.
     * @param listener
     */
    protected void setListener(CurrentVenueCurrencyCreditCheckJobListener listener) {
        this.listener = listener;
    }

    /**
     * For testing only.
     * @param schedulerFactory
     */
    protected void setSchedulerFactory(SchedulerFactoryBean schedulerFactory) {
        this.schedulerFactory = schedulerFactory;
    }

    @Override
    public String getTriggerName() {
        return TRIGGER_NAME;
    }

    @Override
    public Scheduler getScheduler() {
        return schedulerFactory.getScheduler();
    }

    public void setBusinessDaysBack(int businessDaysBack) {
        this.businessDaysBack = businessDaysBack;
    }
}
