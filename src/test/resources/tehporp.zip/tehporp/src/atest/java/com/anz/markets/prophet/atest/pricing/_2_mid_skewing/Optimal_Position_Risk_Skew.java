package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.hamcrest.core.Is;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static com.anz.markets.prophet.domain.Market.WSP_A;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "op cached")
public class Optimal_Position_Risk_Skew extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, false))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 1.0))  // set high Overall-skew threshold
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(WSP_A, Currency.EUR, 1_000_000.0),
                        new MaxSkewQuantities(WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(WSP_A, Currency.USD, 4_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.EUR, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.USD, 4_000_000.0)
                ));

        return configuration;
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_2, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Apply Risk Optimal Position Skew on SHORT Optimal Position")
    public void apply_risk_skew_on_short_optimal_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURNOK, 78.420, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDNOK, 75.420, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -1_000_000, 78.420));
        }

        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, -5_000_000, -4911918.564963378, -3688850.842287497, -7086070.556826882, -5321638.988176988, -0.12263134258501351, 0.75100)));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(directPair, -3774729.2418772564, -2922804.458288453, -2922804.458288453, -2954804.783957987, -2954804.783957987, -0.027428893624227683, 103.875)));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(crossPair, -1000000.0, -1000000.0, -1100000.0, -863659.9847409617, -950025.983215058, -0.039564879589153654, 78.42)));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }

        then:
        // USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.871096));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }

        then:
        // AUD/USD SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75106107));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.105, 0.003));
        }

        then:
        // EUR/NOK SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.107));
        }

    }

    @Test //AXPROPHET-1082 allow choice of P, EP or GP for use in mid skewing and Risk Adjusted spread widening
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1082})
    public void apply_risk_skew_on_short_gradient_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        // WSP_A to use GRADIENT POSITION (i.e OPTIMAL_POSITION)
        // WSP_B to use EQUIVALENT POSITION
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration()
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.GRADIENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
            );
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURNOK, 78.420, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDNOK, 75.420, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -1_000_000, 78.420));
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, -5_000_000, -4911918.564963378, -3688850.842287497, -7086070.556826882, -5321638.988176988, -0.12263134258501351, 0.75100)));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(directPair, -3774729.2418772564, -2922804.458288453, -2922804.458288453, -2954804.783957987, -2954804.783957987, -0.027428893624227683, 103.875)));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(crossPair, -1000000.0, -1000000.0, -1100000.0, -863659.9847409617, -950025.983215058, -0.039564879589153654, 78.42)));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY WSP_A SHORT GRADIENT position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, WSP_A)).getFirst();
            assertThat(wbfA.getSkewedMidPrice(), new IsRoundedTo(103.871108));
        }
        and:
        // USD/JPY WSP_B SHORT EQUIVALENT position results in a different skew to WSP_A
        {
            WholesaleBookFactors wbfB = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_B)).getFirst();
            assertThat(wbfB.getSkewedMidPrice(), new IsRoundedTo(103.871096));
        }
    }

    @Test //AXPROPHET-1082 allow choice of P, EP or GP for use in mid skewing and Risk Adjusted spread widening
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1082})
    public void apply_risk_skew_on_short_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        // WSP_A to use POSITION
        // WSP_B to use EQUIVALENT POSITION
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration()
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
            );
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURNOK, 78.420, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDNOK, 75.420, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -1_000_000, 78.420));
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(2), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(2));
            assertThat(optimalPositionsUpdates.get(1), isOptimalPosition(tdd.optimalPosition(indirectPair, -5_000_000, -4911918.564963378, -3688850.842287497, -7086070.556826882, -5321638.988176988, -0.12263134258501351, 0.75100)));
            assertThat(optimalPositionsUpdates.get(1), isOptimalPosition(tdd.optimalPosition(directPair, -3774729.2418772564, -2922804.458288453, -2922804.458288453, -2954804.783957987, -2954804.783957987, -0.027428893624227683, 103.875)));
            assertThat(optimalPositionsUpdates.get(1), isOptimalPosition(tdd.optimalPosition(crossPair, -1000000.0, -1000000.0, -1100000.0, -863659.9847409617, -950025.983215058, -0.039564879589153654, 78.42)));

            final List<Positions> pos = prophet.expect(Positions.class, atLeast(1), isPortfolio(Portfolio.CLIENTS_NET));
            assertThat(pos.get(0).getPosition1().getCcy(), is(Currency.AUD));
            assertThat(pos.get(0).getPosition1().getPositionInSystemBase(), is(-3_755_000.0));
            assertThat(pos.get(0).getPosition2().getCcy(), is(Currency.JPY));
            assertThat(pos.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(3_774_729.2));
            assertThat(pos.get(1).getPosition1().getCcy(), is(Currency.EUR));
            assertThat(pos.get(1).getPosition1().getPositionInSystemBase(), is(-1_100_000.0));
            assertThat(pos.get(1).getPosition2().getCcy(), is(Currency.NOK));
            assertThat(pos.get(1).getPosition2().getPositionInSystemBase(), is(1_100_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // USD/JPY WSP_A LONG JPY POSITION(vs short equiv & gradient pos).  Apply -ve skew
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, WSP_A)).getFirst();
            assertThat(wbfA.getSkewedMidPrice(), new IsRoundedTo(103.868584));
        }
        and:
        // USD/JPY WSP_B SHORT EQUIVALENT position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wbfB = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_B)).getFirst();
            assertThat(wbfB.getSkewedMidPrice(), new IsRoundedTo(103.871096));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // AUD/USD SHORT AUD position(-3_755_000).  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75106127));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.105, 0.003));
        }

        then:
        // EUR/NOK LONG NOK Position(vs short equiv & gradient pos).   Apply -ve skew
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.103));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_2, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Apply Risk Optimal Position Skew on LONG Optimal Position")
    public void apply_risk_skew_on_long_optimal_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration());
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
        }

        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));

            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, 5000000, 4822047.659692364, 3621357.792428965, 6976028.347724075, 5238997.28914078, 0.13059209393878018, 0.75100)));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(directPair, 3774729.2418772564, 3303784.8396822973, 3303784.8396822973, 3037880.6928662155, 3037880.6928662155, 0.033632205434654436, 103.875)));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(crossPair, Double.NaN, 0.0, 0.0, 0.0, 0.0, -0.006294434920085132, 9.1)));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }

        then:
        // USD/JPY LONG optimal position.  Apply -ve skew to improve OFFER(client buy)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.868761));

            prophet.clearOutputBuffer();

        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }

        then:
        // AUD/USD LONG optimal position.  Apply -ve skew to improve OFFER(client buy)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75103914));

            prophet.clearOutputBuffer();

        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.105, 0.003));
        }

        then:
        // EUR/SEK LONG optimal position.  Apply -ve skew to improve OFFER(client buy)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(9.105));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_2, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Apply MAXIMUM Risk Optimal Position Skew on LONG Optimal Position")
    public void apply_max_optimal_position_risk_skew_long_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.setMaxSkewQuantities(Arrays.asList(
                    new MaxSkewQuantities(WSP_A, Currency.AUD, 3_750_000.0),
                    new MaxSkewQuantities(WSP_A, Currency.USD, 4_000_000.0),
                    // not required but added here to prove we still do not skew mid for WSP_Z even if config is added
                    new MaxSkewQuantities(Market.WSP_Z, Currency.AUD, 3_750_000.0),
                    new MaxSkewQuantities(Market.WSP_Z, Currency.USD, 4_000_000.0)
            ));

            prophet.receive(configuration);
        }

        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(indirectPair, 5_000_000, 0.75100));
        }

        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));

            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, 5000000.0, 5000000.0, 3750000.0, 7500000.0, 5625000.0, 0.14920381668873167, 0.75000)));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75002, 0.00003));
        }

        then:
        // AUD/USD LONG optimal position is on MaxSkewQuantities limit.  Apply -ve skew to improve OFFER(client buy). Maximum skew of 0.5 * 0.00003(base spread)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750005));
            prophet.clearOutputBuffer();
        }

        when:
        {
            // send client deal to generate optimal positions beyond MaxSkewQuantities limit
            prophet.receive(tdd.client_trade_001(indirectPair, 1_000_000, 0.75100));
        }

        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, 6000000.0, 6000000.0, 4500120.0, 9000000.0, 6750180.0, 0.1492038166887317, 0.75002)));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003));
        }

        then:
        // AUD/USD LONG optimal position is beyond MaxSkewQuantities limit.  Apply -ve skew to improve OFFER(client buy). Maximum skew of 0.5 * 0.00003(base spread)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.749985));
        }

        and:
        {
            verify_wsp_z_mid_no_skewing(0.75000);
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.PRICING__4_2_2, Requirement.Ref.PRICING__4_2_5})
    @DisplayName("Apply MAXIMUM Risk Optimal Position Skew on SHORT Optimal Position")
    public void apply_max_optimal_position_risk_skew_short_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = setUpConfiguration();
            prophet.receive(configuration
                    .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(WSP_A, Currency.AUD, 3_750_000.0),
                        new MaxSkewQuantities(WSP_A, Currency.USD, 4_000_000.0))
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4)
                    )
            );
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(indirectPair, -5_000_000, 0.75100));
        }
        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, -5000000, -5000000.0, -3750000.0, -7500000.0, -5625000.0, -0.14920381668873167, 0.75000)));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75002, 0.00003));
        }
        then:
        // AUD/USD SHORT optimal position is on MaxSkewQuantities limit.  Apply +ve skew to improve OFFER(client buy). Maximum skew of 0.5 * 0.00003(base spread)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750035));
            prophet.clearOutputBuffer();
        }
        when:
        {
            // send client deal to generate optimal positions beyond MaxSkewQuantities limit
            prophet.receive(tdd.client_trade_001(indirectPair, -1_000_000, 0.75100));
        }
        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, -6000000, -6000000.0, -4500120.0, -9000000.0, -6750180.0, -0.1492038166887317, 0.75002)));

            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003));
        }
        then:
        // AUD/USD LONG optimal position is beyond MaxSkewQuantities limit.  Apply -ve skew to improve OFFER(client buy). Maximum skew of 0.5 * 0.00003(base spread)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750015));
        }
        and:
        {
            verify_wsp_z_mid_no_skewing(0.75000);
        }
        and:
        {
            verify_pause_skewing();
        }
    }

    @DisplayName("AXPROPHET-683 WSP_Z pricing model which is equivalent of WSP_A/B/C but with NO MID SKEWING")
    public void verify_wsp_z_mid_no_skewing(double unskewedMid) {

        WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_Z)).getFirst();
        assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(unskewedMid));

        prophet.clearOutputBuffer();
    }

    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1142})
    @DisplayName("AXPROPHET-1142 Pause MID SKEWING")
    public void verify_pause_skewing() {
        when:
        {
            // GLOBAL Pause skewing enabled
            prophet.receive(tdd.setSkewingPause(Currency.ANY, true));
        }
        then:
        // client price generated with UNSKEWED MID
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75000));

            prophet.notExpect(IllegalArgumentException.class);
            prophet.expect(SkewCurrencyControl.class, isSkewCcyPaused(Currency.ANY, true));
        }
        when:
        // GLOBAL Pause skewing disabled
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setSkewingPause(Currency.ANY, false));
        }
        then:
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750015));
        }
        when:
        // active skew pause and receive new marketDataSnapshots while pause is active
        {
            // Pause skewing enabled
            prophet.receive(tdd.setSkewingPause(Currency.AUD, true));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75020, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003));
        }
        then:
        // since Skew Pause is ACTIVE, do not SKEW MID
        {
            LinkedList<WholesaleBookFactors> wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(2), isWholesaleBookFactors(indirectPair));
            assertThat(wholesaleBookFactors.getFirst().getSkewedMidPrice(), new IsRoundedTo(0.75020));
            assertThat(wholesaleBookFactors.getLast().getSkewedMidPrice(), new IsRoundedTo(0.75000));
        }
        when:
        // t+4 wait for PAUSE SKEW period to expire.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(4_000);
        }
        then:
        // client price generated with SKEWED MID
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750015));
            prophet.expect(SkewCurrencyControl.class, isSkewCcyPaused(Currency.AUD, false));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void apply_risk_skew_on_biased_optimal_position() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURNOK, 78.420, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDNOK, 75.420, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -1_000_000, 78.420));

            // set biased offset positions
            prophet.receive(tdd.biasPosition(Currency.AUD, -1_000_000));
            prophet.receive(tdd.biasPosition(Currency.JPY, 500_000_000));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // AUD/USD SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getFirst();
            final OptimalPosition audUsdOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(audUsdOp.getPositionInSystemBase(), is(-3689100.842287497));

            // Risk skew uses BIASED optimal positions(USD)
            OptimalPositions biasedGradientPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getFirst();
            final OptimalPosition biasedAudUsdOp = biasedGradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(biasedAudUsdOp.getPositionInSystemBase(), is(-3108469.368960265));

            // OP skew = (3108469.368960265 / 5000000) * 0.5 = -0.3108469368960265
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.7510593254));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.865, 0.003));
        }

        then:
        // USD/JPY LONG BIASED optimal position(unbiased is short).  Apply -ve skew
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getFirst();
            final OptimalPosition usdJpyOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(usdJpyOp.getPositionInSystemBase(), is(-3689087.975372885));

            // Risk skew uses BIASED optimal positions(USD)
            OptimalPositions biasedGradientPositions = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getFirst();
            final OptimalPosition biasedUsdJpyOp = biasedGradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == directPair).findFirst().get();
            assertThat(biasedUsdJpyOp.getPositionInSystemBase(), is(1796609.4920110747));

            // OP skew = (1796609.4920110747 / 4000000) * 0.5 = 0.2245761865013843375
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.86433));
        }
    }

    @Test
    public void verify_skew_enabled_per_pricing_model() {
        ConfigurationDataDefault configuration = setUpConfiguration()
                .setClientSpreadConfigs(Lists.newArrayList(
                        new ClientSpreadConfigImpl(WSP_A, indirectPair, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(WSP_A, indirectPair, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(WSP_A, indirectPair, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(WSP_A, indirectPair, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(WSP_A, indirectPair, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),

                        new ClientSpreadConfigImpl(Market.WSP_API_6, indirectPair, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_API_6, indirectPair, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_API_6, indirectPair, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_API_6, indirectPair, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_API_6, indirectPair, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4)
                ))
                .setPricingModels(Arrays.asList(
                        new PricingModelImpl().setMarket(WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                        new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                        new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m"),
                        new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                        new PricingModelImpl().setMarket(Market.WSP_API_6).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION)
                ))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(WSP_A, Currency.AUD, 3_750_000.0),
                        new MaxSkewQuantities(WSP_A, Currency.USD, 4_000_000.0),
                        // not required but added here to prove we still do not skew mid for WSP_Z even if config is added
                        new MaxSkewQuantities(Market.WSP_API_6, Currency.AUD, 3_750_000.0),
                        new MaxSkewQuantities(Market.WSP_API_6, Currency.USD, 4_000_000.0)
                ));
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(indirectPair, 5_000_000, 0.75100));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75002, 0.00003));
        }
        then:
        // AUD/USD LONG optimal position is on MaxSkewQuantities limit.  Apply -ve skew to improve OFFER(client buy). Maximum skew of 0.5 * 0.00003(base spread)
        {
            WholesaleBookFactors wsbf_WSP_A = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(WSP_A)).getFirst();
            assertThat(wsbf_WSP_A.getSkewedMidPrice(), new IsRoundedTo(0.750005));

            WholesaleBookFactors wsbf_WSP_API_6 = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_API_6)).getFirst();
            assertThat(wsbf_WSP_API_6.getSkewedMidPrice(), new IsRoundedTo(0.750005));
        }
        when:
        // DISABLE WSP_API_6 skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003));
            prophet.receive(configuration
                    .setPricingModels(Arrays.asList(
                            new PricingModelImpl().setMarket(WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                            new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                            new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m"),
                            new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                            new PricingModelImpl().setMarket(Market.WSP_API_6).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false)
                    ))
            );
            prophet.clearOutputBuffer();

            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75002, 0.00003));
        }
        then:
        // only WSP_A is skewed. WSP_API_6 is NOT skewed
        {
            WholesaleBookFactors wsbf_WSP_A = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(WSP_A)).getFirst();
            assertThat(wsbf_WSP_A.getSkewedMidPrice(), new IsRoundedTo(0.750005));

            WholesaleBookFactors wsbf_WSP_API_6 = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_API_6)).getFirst();
            assertThat(wsbf_WSP_API_6.getSkewedMidPrice(), new IsRoundedTo(0.750000));
        }
    }

    @Test
    //AXPROPHET-1411
    public void manual_vol_impacts_skewedMid() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration
                    .setMaxSkewQuantities(Arrays.asList(
                    new MaxSkewQuantities(WSP_A, Currency.AUD, 3_750_000.0),
                    new MaxSkewQuantities(WSP_A, Currency.USD, 4_000_000.0),
                    // not required but added here to prove we still do not skew mid for WSP_Z even if config is added
                    new MaxSkewQuantities(Market.WSP_Z, Currency.AUD, 3_750_000.0),
                    new MaxSkewQuantities(Market.WSP_Z, Currency.USD, 4_000_000.0)
            ));

            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003)); // no OP change as position=0

            prophet.clearOutputBuffer();
            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(indirectPair, -7_000_000, 0.75100));
        }
        then:
        // Maximum skew of 0.5 * 0.00003(base spread)
        // max skew such that client Bid is on the unskewed Mid
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750015));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectPair, WSP_A)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.750000, 0.750030));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setManualGlobalVol(4d));
        }
        then:
        // Maximum skew of 0.5 * 0.00003(base spread) * 4
        // client Bid remains at the unskewed Mid
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75006));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectPair, WSP_A)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.75000, 0.75012));
        }
    }
}
