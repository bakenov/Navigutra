package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.hedging.volume.HedgePauseState;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.features.StanddownMidHedgersOnNoSkewFeatureSpecs;
import com.anz.markets.prophet.pricer.pfp.features.StanddownSkewFastFillRateFeatureSpecs;
import com.anz.markets.prophet.pricer.pfp.features.StanddownSkewSlowFillRateFeatureSpecs;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.matcher.LamdaMatcher.f;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 ** AXPROPHET-1285 Stand down skewing strategy
 *  Stand down skewing(SLOW FILL) when all conditions met:
 *  - minPos above PARAM_MIN_POSITION_USD
 *  - within window period ONCE min pos is met, total of risk reducing trade quantities(in USD using systemBaseMid) is
 *  below PARAM_RR_FILL_QUANTITY AND ratio of risk reducing trades to biasedPositionInSystemBase below PARAM_RR_FILL_RATIO
 *
 * If stand down is triggered, no skew for a period window(even if rr trade totals/ratios rise above thresholds during this period)
 * However Stand Down CAN be cancelled immediately during this period ONLY if either occurs:
 *  - the Position(usd) falls below PARAM_MIN_POSITION_USD
 *  - the Position(usd) changes side/sign
 *
 *  Again, MANUAL Skew will override any active Stand Down skew
 *
 *  AXPROPHET-1326 Stand down skewing strategies will now also send signal
 *  to PAUSE Mid Hedger
 **/
@RelatedTest(Optimal_Position_Risk_Skew_and_NOP_Skew_Combined.class)
@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1285})
public class Stand_Down_Skewing_Slow_Fill_Rate_Test extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration(boolean combinedTest) {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig2 = new ArrayList<>();
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig3 = new ArrayList<>();
        StanddownSkewSlowFillRateFeatureSpecs specs = StanddownSkewSlowFillRateFeatureSpecs.INSTANCE;

        // set up config for indirect pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.LDN,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, 1_126_000d,
                specs.PARAM_RR_FILL_RATIO, 0.89d,
                specs.PARAM_RR_FILL_INTERVAL_MS, 5_000L,
                specs.PARAM_STANDDOWN_PERIOD_MS, 1_000L,
                specs.PARAM_MIN_POSITION_USD, 500_000d)
        );
        // set up config for direct pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                directPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, 2_000_000d,
                specs.PARAM_RR_FILL_RATIO, 0.90d,
                specs.PARAM_RR_FILL_INTERVAL_MS, 5_000L,
                specs.PARAM_STANDDOWN_PERIOD_MS, 2_000L,
                specs.PARAM_MIN_POSITION_USD, 2_200_000d)
        );
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, Double.NaN,
                specs.PARAM_RR_FILL_RATIO, Double.NaN,
                specs.PARAM_RR_FILL_INTERVAL_MS, 0,
                specs.PARAM_STANDDOWN_PERIOD_MS, 0,
                specs.PARAM_MIN_POSITION_USD, Double.NaN)
        );

        StanddownSkewFastFillRateFeatureSpecs specs2 = StanddownSkewFastFillRateFeatureSpecs.INSTANCE;
        if(combinedTest) {
            priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                    Market.WSP_A,
                    indirectPair,
                    TradingTimeZone.LDN,
                    Region.ANY,
                    specs.PARAM_RR_FILL_QUANTITY, 1_126_000d,
                    specs.PARAM_RR_FILL_RATIO, 0.24d,
                    specs.PARAM_RR_FILL_INTERVAL_MS, 4_000L,
                    specs.PARAM_STANDDOWN_PERIOD_MS, 2_000L,
                    specs.PARAM_MIN_POSITION_USD, 500_000d)
            );
            priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                    Market.ANY,
                    Instrument.ANY,
                    TradingTimeZone.GLOBAL,
                    Region.ANY,
                    specs.PARAM_RR_FILL_QUANTITY, Double.NaN,
                    specs.PARAM_RR_FILL_RATIO, Double.NaN,
                    specs.PARAM_RR_FILL_INTERVAL_MS, 0,
                    specs.PARAM_STANDDOWN_PERIOD_MS, 0,
                    specs.PARAM_MIN_POSITION_USD, Double.NaN)
            );
        }

        StanddownMidHedgersOnNoSkewFeatureSpecs specs3 = StanddownMidHedgersOnNoSkewFeatureSpecs.INSTANCE;
        priceFormationPipelineConfig3.add(PriceFormationPipelineConfig.create(specs3.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs3.PARAM_TARGET_HEDGERS, "MID_BGC_EP")
        );

        priceFormationPipelineConfig3.add(PriceFormationPipelineConfig.create(specs3.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs3.PARAM_TARGET_HEDGERS, "")
        );
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_RISK_REDUCING_FLOW_PORTFOLIOS, new Portfolio[]{Portfolio.CLIENTS, Portfolio.HEDGER_MID_BGC}))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0)
                ))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(com.google.common.collect.Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ));

        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME,priceFormationPipelineConfig);
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs2.NAME,priceFormationPipelineConfig2);
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs3.NAME,priceFormationPipelineConfig3);

        return configuration;
    }

    @Test
    public void rr_window_interval_and_total_rr_amt() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(false), false);

            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));
        }
        when:
        // t+0.5s, receive risk increasing client trade. Below min position USD
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -500_000, 78.420));
        }
        and:
        // t+1.5s, receive risk increasing client trade. Now above min position USD
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -4_500_000, 78.420));
        }
        then:
        // standdown skew not active
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75106086));  // SKEWED MID
        }
        when:
        // after window period(5 sec) total risk reducing trades is 1_126_500 USD
        {
            // t+2.5, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 500_000, 0.75100));

            // t+6.5, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75100));
        }
        then:
        // since total risk reducing trades is 1_126_575 USD is ABOVE threshold, do NOT stand down
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105749));
        }
        when:
        // t+7.5 risk reducing trade @t+2.5 slides out
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
        }
        then:
        // total risk reducing trades is BELOW threshold(and rr ratio below threshold), STAND DOWN skewing for 1sec! (until t+8.5)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75100));  // UNSKEWED MID

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].oldVal, f(oldVal -> (oldVal > 0.0)));  // i.e skew existed
            assertThat(ftl.operations[0].newVal, is(0.0));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(751_050.0));
        }
        and:
        // send pause signal to hedger
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
        }
        when:
        // t+8 standdown period still active
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.0004));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105));  // UNSKEWED MID
        }
        when:
        // t+8.5 standdown skewing period concluded
        // Even though risk reducing total still unchanged(751_050) i.e BELOW threshold, must wait for another window period before we can stand down
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.0004));
        }
        then:
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbfA.getSkewedMidPrice(), new IsRoundedTo(0.751007485)); // skewed
        }
        and:
        // send pause signal to hedger
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
        }
        when:
        // t+9 during monitor window, receive risk reducing trade (375500 USD)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(indirectPair, 500_000, 0.75100));
        }
        then:
        // continue to skew
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbfA.getSkewedMidPrice(), new IsRoundedTo(0.751006358)); // skewed

            // position still above min threshold
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-2_253_000.0));
        }
        when:
        // t+13.5 end of monitor window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4_500));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.0004));
        }
        then:
        // total rr trade during current window 375500 is BELOW threshold => STAND DOWN
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbfA.getSkewedMidPrice(), new IsRoundedTo(0.75105));
            FeatureTraceLine ftl =  wbfA.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(375500));
        }
    }

    @Test
    public void risk_reducing_ratio_test() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(false), false);
        }
        when:
        // t+0.5s, receive client trade. Now above min position USD
        // must wait until t+5.5s( i.e 5 sec window) before we can decide to standdown skew or not
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generate positions
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -3_000_000, 78.420));
        }
        and:
        // t+1.5 receive rr trade (1_066_491 USD)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_420_000, 0.75105));
        }
        then:
        // rr trade ratio = 1_066_491 / 1_186_659 = 0.899  => ABOVE ratio!
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-1_186_659.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105332));
        }
        when:
        // t+5.5 rr window period(5 sec) over,
        // total risk reducing trades is 1_066_491 USD
        // rr trade ratio = 1_066_491 / 1_186_659 = 0.899  => above ratio, do NOT stand down
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75100332));
        }
        when:
        // t+6.0 risk increasing trade received
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -500_000, 0.75100));

        }
        then:
        // rr trade ratio = 1_066_491 / 1_562_080 = 0.68  => BELOW ratio, STAND DOWN!
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-1_562_080.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.751000));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(1_066_491.0));
        }
    }

    @Test
    public void sign_of_position_changed() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(false), false);
        }
        when:
        // t+0.5s, receive client trade. Now above min position USD
        // must wait until t+5.5s( i.e 5 sec window) before we can decide to standdown skew or not
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
        }
        then:
        // above min postion and mid is skewed
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(-3_774_729.2));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.87376));
        }
        when:
        // t+2.5 receive rr trade(1mio USD)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.client_trade_001(directPair, -1_000_000, 103.875));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(-2_774_729.2));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.874136));
        }
        when:
        // t+5.5 rr window period(5 sec) finished,
        // total risk reducing trades is 1mio(below threshold) => standdown for 2sec
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.870));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
        }
        when:
        // t+6.0 during stand down period rr trade received such that position changes side/sign!
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(directPair, -5_000_000, 103.870));
        }
        then:
        // abort stand down skew immediately
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(2_225_137.2));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.87101));
        }
    }

    @Test
    public void position_falls_below_min() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(false), false);
        }
        when:
        // t+0.5s, receive client trade. Now above min position USD
        // must wait until t+5.5s( i.e 5 sec window) before we can decide to standdown skew or not
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
        }
        then:
        // above min postion and mid is skewed
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(-3_774_729.2));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.87376));
        }
        when:
        // t+2.5 receive rr trade(1mio USD)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.client_trade_001(directPair, -1_000_000, 103.875));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(-2_774_729.2));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.874136));
        }
        when:
        // t+5.5 rr window period(5 sec) finished,
        // total risk reducing trades is 1mio(below threshold) => standdown for 2sec
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.870));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
        }
        when:
        // t+6.0 during stand down period rr trade received such that position falls below min threshold(2.5mio USD)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(directPair, -600_000, 103.870));
        }
        then:
        // abort stand down skew immediately
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(-2_174_862.8));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.86936));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // t+6.0 receive risk increasing trade. pos(usd) back above min.  Must wait till t+11 before evaluating stand down
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 4_000_000, 78.420));

            // t+8.0 receive rr trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.client_trade_001(directPair, -1_100_000, 103.875)); // rr trade

            // t+11 end of window.  Stand Down!
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
        }
        then:
        {
            LinkedList<WholesaleBookFactors> wbf = prophet.expect(WholesaleBookFactors.class, atLeast(3), isWholesaleBookFactors(directPair, Market.WSP_A));
            assertThat(wbf.get(1).getSkewedMidPrice(), new IsRoundedTo(103.86878)); // during rr trade window, mid still skewed
            assertThat(wbf.get(2).getSkewedMidPrice(), new IsRoundedTo(103.875)); // end of rr trade window, stand down skew
        }
    }

    @Test
    public void stand_down_skew_fast_and_slow() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(true), false);

            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));
        }
        when:
        // t+0, receive risk increasing client trade. usd pos above min.
        // (standdown skew slow fill must wait until 5sec period is over i.e t+5)
        {
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
        }
        and:
        // t+1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(indirectPair, 550_000, 0.75105));
        }
        and:
        // t+4, receive rr trade (1_164_127.5 USD)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
            prophet.receive(tdd.client_trade_001(indirectPair, 1_000_000, 0.75105));
        }
        then:
        // standdown skew fast fill ACTIVE for 2sec(t+6)
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-2_591_122.5));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105));  // SKEWED MID
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
        }
        when:
        // t+5 standdown skew slow fill rate monitoring period concluded. rr trades in this period 1_164_127.5 USD is OVER limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
        }
        then:
        // standdown skew slow fill rate NOT active
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_WARM));
        }
        when:
        // t+6, standdown period for skew fast fill ends. 751_050 rr trades in last 4 sec period. Therefore standdown skew(fast fill) not activated
        // standdown skew(slow fill): rr trades in last 5sec period 751_050 USD is UNDER limit -> stand down skewing
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewSlowFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            FeatureTraceLine ftl2 =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl2.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl2.offerStatus, is(FeatureStatus.DORMANT_WARM));
        }
    }
}