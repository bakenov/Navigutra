package com.anz.axle.lg.adapter.apama.transport;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.config.PricingEncoderLookup;

public class MarketDataBooksClearingConnectionStatusHandler implements ConnectionStatusHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(MarketDataBooksClearingConnectionStatusHandler.class);

    private final PricingEncoderLookup pricingEncoderLookup;

    public MarketDataBooksClearingConnectionStatusHandler(final PricingEncoderLookup pricingEncoderLookup) {
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
    }

    @Override
    public void onConnect(final Connection connection) {
        LOGGER.info("Connected {}", connection.connectionConfig());
    }

    @Override
    public void onDisconnect(final Connection connection) {
        LOGGER.warn("Disconnected {}", connection.connectionConfig());
        pricingEncoderLookup.clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_DISCONNECTED);
    }

    @Override
    public void onNotification(final Connection connection, final String notification) {
        LOGGER.info("Notification: {}, {}", notification, connection.connectionConfig());
    }
}
