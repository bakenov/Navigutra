// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.awt.EventQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JTextArea;

/**
 * This class provides a Runnable interface that reads from a supplied queue,
 * and posts the Strings it finds there onto a supplied JTextArea.
 */
public class StatusUpdater implements Runnable
{
    private final AtomicBoolean         running = new AtomicBoolean(true);
    protected final JTextArea           statusArea;
    private final BlockingQueue<String> dataQueue;

    /**
     * @param statusArea
     * @param dataQueue
     */
    public StatusUpdater(final JTextArea statusArea,
                         final BlockingQueue<String> dataQueue)
    {
        this.statusArea = statusArea;
        this.dataQueue = dataQueue;
    }

    /**
     * Basic Thread loop, reading String messages and placing them onto the
     * supplied JTextArea (invoked Later on the Swing EDT).
     * 
     * @see java.lang.Runnable#run()
     */
    public void run()
    {
        while (this.running.get())
        {
            try
            {
                // place new message onto the TOP of the TextArea.
                final String text = this.dataQueue.take();

                final JTextArea statusTextArea = this.statusArea;

                // Update the GUI in the Event Queue's thread
                EventQueue.invokeLater(new Runnable() {
                    public void run()
                    {
                        final String fullText = "\n-------------------------------------------------------------\n"
                                + text;
                        statusTextArea.append(fullText);
                    }
                });
            }
            catch (final InterruptedException ex)
            {
                // do nothing.
            }
            catch (final Exception ex)
            {
                System.out.println(ex.getMessage());
            }

        }

    }

    /**
     * Prevents further iterations of the message processing loop.
     */
    public void stop()
    {
        this.running.set(false);
    }

}
