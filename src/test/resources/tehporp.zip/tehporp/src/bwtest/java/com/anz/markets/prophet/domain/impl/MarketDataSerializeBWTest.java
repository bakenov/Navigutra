package com.anz.markets.prophet.domain.impl;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueWrappers;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataDeleteOrderImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataIncrementImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataReplaceOrderImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.util.MutableByteArrayCharSequence;
import org.junit.Test;

import java.lang.instrument.UnmodifiableClassException;

import static org.junit.Assert.assertEquals;

public class MarketDataSerializeBWTest {
    protected static final int REPS = 1_000_000;
    protected static final int THRESHOLD = 200;
    protected final MutableByteArrayCharSequence[] IDS = new MutableByteArrayCharSequence[REPS * 2];
    protected final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private final MarketDataSnapshotImpl marketDataSnapshot;
    protected final MarketDataIncrementImpl marketDataIncrement;
    protected ProphetBytes bytes1;
    protected int counter = 0;

    public MarketDataSerializeBWTest() {
        bytes1 = ChronicleQueueWrappers.wrapFixedSize();
        marketDataIncrement = MidRateTestHelper.createMarketDataIncrement();
        marketDataSnapshot = MidRateTestHelper.createMarketData(marketDataIncrement.getEventsList().size() / 2);
        for (int i = 0; i < REPS * 2; i++) {
            IDS[i] = new MutableByteArrayCharSequence(10);
            IDS[i].append(Integer.toString(i));
        }

        System.out.println("size of serialised NO=" + serialiseDeserialiseMarketDataNewOrderImpl());
        System.out.println("size of serialised MDS=" + serialiseDeserialiseMarketDataSnapshotImpl());
        System.out.println("size of serialised MDI=" + serialiseDeserialiseMarketDataIncrementImpl());
    }

    @Test
    public void testSerialiseDeserialiseMarketDataNewOrderImpl() {
        helper.testAllocationNotExceeded(
                this::serialiseDeserialiseMarketDataNewOrderImpl,
                REPS, REPS,
                THRESHOLD
        );
    }

    @Test
    public void testSerialiseDeserialiseMarketDataSnapshotImpl() {
        counter = 0;
        helper.testAllocationNotExceeded(
                this::serialiseDeserialiseMarketDataSnapshotImpl,
                REPS, REPS,
                THRESHOLD
        );
    }

    @Test
    public void testSerialiseDeserialiseMarketDataIncrementImpl() throws UnmodifiableClassException {
        counter = 0;
        // from the example at https://github.com/google/allocation-instrumenter/wiki.
        // You need to run with the java agent to enable this (see MarketDataSerializeBWTestWithAllocationInstrumentor)
        //        AllocationRecorder.addSampler(new Sampler() {
        //            public void sampleAllocation(int count, String desc, Object newObj, long size) {
        //                System.out.println("I just allocated the object " + newObj + " of type " + desc + " whose size is " + size);
        //                if (count != -1) { System.out.println("It's an array of size " + count); }
        //            }
        //        });
        helper.testAllocationNotExceeded(
                () -> serialiseDeserialiseMarketDataIncrementImpl(),
                REPS, REPS,
                THRESHOLD
        );
    }

    private long serialiseDeserialiseMarketDataNewOrderImpl() {
        MarketDataNewOrderImpl orderBid = (MarketDataNewOrderImpl) marketDataSnapshot.getBidEventList().get(0),
                orderAsk = (MarketDataNewOrderImpl) marketDataSnapshot.getOfferEventList().get(0);
        bytes1.writePosition(0);
        orderBid.writeMarshallable(bytes1);
        bytes1.readPosition(0);
        orderAsk.readMarshallable(bytes1);
        return bytes1.position();
    }

    private long serialiseDeserialiseMarketDataSnapshotImpl() {
        bytes1.writePosition(0);
        marketDataSnapshot.setEventId(IDS[counter++]);
        marketDataSnapshot.writeMarshallable(bytes1);
        bytes1.readPosition(0);
        marketDataSnapshot.readMarshallable(bytes1);
        return bytes1.position();
    }

    private long serialiseDeserialiseMarketDataIncrementImpl() {
        bytes1.writePosition(0);
        final CharSequence id = IDS[counter++];
        ((MarketDataReplaceOrderImpl) marketDataIncrement.getEventsList().get(0)).setOrderId(id);
        ((MarketDataDeleteOrderImpl) marketDataIncrement.getEventsList().get(1)).setOrderId(id);
        ((MarketDataNewOrderImpl) marketDataIncrement.getEventsList().get(2)).setOrderId(id);
        int eventsSize = marketDataIncrement.getEventsList().size();
        final Class<?> clazz1 = marketDataIncrement.getEventsList().get(1).getClass();
        marketDataIncrement.writeMarshallable(bytes1);
        bytes1.readPosition(0);
        marketDataIncrement.readMarshallable(bytes1);
        assertEquals(eventsSize, marketDataIncrement.getEventsList().size());
        assertEquals(clazz1, marketDataIncrement.getEventsList().get(1).getClass());
        assertEquals(id, marketDataIncrement.getEventsList().get(0).getOrderId());
        assertEquals(id, marketDataIncrement.getEventsList().get(1).getOrderId());
        assertEquals(id, marketDataIncrement.getEventsList().get(2).getOrderId());
        return bytes1.position();
    }
}
