package com.anz.markets.efx.ngaro.collections;

public @interface NotGcFriendly {
}
