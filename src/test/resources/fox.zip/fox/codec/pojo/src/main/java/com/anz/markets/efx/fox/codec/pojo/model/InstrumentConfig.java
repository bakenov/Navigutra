package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoInstrumentConfigHandler;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class InstrumentConfig implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public InstrumentConfig() {
        this(new MessageHeader(), new Body());
    }

    public InstrumentConfig(final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
    }

    public static final class Body {
        public long instrumentId;
        public int pipSizeDivisor;
        public boolean enabled;

        public Body() {
            super();
        }

        public Body(final long instrumentId,
                    final int pipSizeDivisor,
                    final boolean enabled) {
            this.instrumentId = instrumentId;
            this.pipSizeDivisor = pipSizeDivisor;
            this.enabled = enabled;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "instrumentId='" + instrumentId + '\'' +
                    ", pipSizeDivisor=" + pipSizeDivisor +
                    ", enabled=" + enabled +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "InstrumentConfig{" +
                "header=" + header +
                "body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.instrumentConfig());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.instrumentConfig().create(messageConsumer));
    }

    public void encode(final InstrumentConfigEncoder encoder) {
        encoder.messageStart(header.source,header.sourceSeq)
                .instrumentId(body.instrumentId)
                .pipSizeDivisor(body.pipSizeDivisor)
                .enabled(body.enabled)
                .messageComplete();
    }

    public static <M> InstrumentConfig decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoInstrumentConfigHandler handler = new PojoInstrumentConfigHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.instrumentConfig().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onInstrumentConfig(this);
    }
}
