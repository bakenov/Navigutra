package com.anz.markets.prophet.atest.framework;

import com.anz.markets.prophet.syscontrol.CoreMode;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Only run a test when running in specified CoreMode
 */
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface RunInCoreMode {
    CoreMode coreMode();
}
