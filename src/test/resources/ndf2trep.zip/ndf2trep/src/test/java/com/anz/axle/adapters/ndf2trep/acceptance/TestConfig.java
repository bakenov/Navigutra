package com.anz.axle.adapters.ndf2trep.acceptance;

import com.anz.axle.adapters.ndf2trep.config.ServerConfig;
import com.anz.axle.adapters.ndf2trep.enrichment.margin.MarginService;
import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.axle.trep.publisher.TrepStreamableQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Configuration
@Import({ServerConfig.class, NdfTrepSubscriptionConfig.class})
public class TestConfig {

    @Bean
    public TrepStreamableQueue trepStreamableQueue() {
        return new TrepStreamableQueue();
    }

    @Bean
    public RicRepository ricRepository(@Value("${ndf.trep.publish.destination.sourceId}") final String sourceId,
                                       @Value("${ndf.trep.publish.destination.servicename}") final String serviceName) {

        final Map<String, Set<String>> symbolVenuesFXSPOT = new HashMap<>();
        symbolVenuesFXSPOT.put("AUDCAD", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDCAD").add("EBS");
        symbolVenuesFXSPOT.get("AUDCAD").add("WSP_A");

        symbolVenuesFXSPOT.put("AUDNZD", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDNZD").add("EBS");
        symbolVenuesFXSPOT.get("AUDNZD").add("WSP_A");

        symbolVenuesFXSPOT.put("AUDJPY", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDJPY").add("EBS");
        symbolVenuesFXSPOT.get("AUDJPY").add("WSP_Z");

        symbolVenuesFXSPOT.put("USDJPY", new HashSet<>());
        symbolVenuesFXSPOT.get("USDJPY").add("EBS");
        symbolVenuesFXSPOT.get("USDJPY").add("WSP_Z");

        final Map<String, Map<String, Set<String>>> instrumentRics = new HashMap<>();
        instrumentRics.put("EBS", new HashMap<>());
        instrumentRics.get("EBS").put("USDCNS", new HashSet<>());
        instrumentRics.get("EBS").get("USDCNS").add("M1:CNS1M");
        instrumentRics.get("EBS").get("USDCNS").add("M3:CNS3M");
        instrumentRics.get("EBS").get("USDCNS").add("M6:CNS6M");
        instrumentRics.get("EBS").get("USDCNS").add("Y1:CNS12M");

        instrumentRics.get("EBS").put("USDCNY", new HashSet<>());
        instrumentRics.get("EBS").get("USDCNY").add("M1:CN11M");
        instrumentRics.get("EBS").get("USDCNY").add("M3:CN13M");
        instrumentRics.get("EBS").get("USDCNY").add("M6:CN16M");
        instrumentRics.get("EBS").get("USDCNY").add("Y1:CN112M");

        instrumentRics.get("EBS").put("USDTWS", new HashSet<>());
        instrumentRics.get("EBS").get("USDTWS").add("M1:TWS1M");

        final Map<String, String> publishSourceId = new HashMap<>();
        publishSourceId.put("EBS", sourceId);

        final Map<String, String> venueServiceNameMap = new HashMap<>();
        venueServiceNameMap.put("EBS", serviceName);


        return new RicRepository(symbolVenuesFXSPOT,
                                 instrumentRics,
                                 new HashMap<>(),
                                 publishSourceId,
                                 venueServiceNameMap,
                                 serviceName);
    }

    @Bean
    public MarginService marginService(@Value("${ndf.trep.publish.destination.servicename}") final String serviceName,
                                       final RicRepository ricRepository) {

        Map<String, Map<String, List<String>>> marginConfigMap = new HashMap<>();
        addData("AUDCAD", serviceName, "PERC,BID,-,0.009,ASK,+,0.008,4", marginConfigMap);
        addData("AUDJPY", serviceName, "PIPS ,BID,-,2, ASK ,+,1,4", marginConfigMap);
        addData("AUDNZD", serviceName, "PERC,BID,-,0.000,ASK,+,0.000,4", marginConfigMap);
        addData("USDJPY", serviceName, "PIPS ,BID,-,2, ASK ,+,5,3", marginConfigMap);

        Map<String, Long> symbolPipsMap = new HashMap<>();
        symbolPipsMap.put("AUDCAD", 10000L);
        symbolPipsMap.put("AUDJPY", 1000L);
        symbolPipsMap.put("AUDNZD", 10000L);
        symbolPipsMap.put("USDJPY", 10L);
        return new MarginService(marginConfigMap, symbolPipsMap, ricRepository);
    }

    private void addData(String instrument, String source, String params, Map<String, Map<String, List<String>>> marginConfigMap) {
        Map<String, List<String>> map = marginConfigMap.computeIfAbsent(instrument, (k) -> new HashMap<>());
        map.put(source, new ArrayList<>(Arrays.asList(params.split(","))));
    }

}
