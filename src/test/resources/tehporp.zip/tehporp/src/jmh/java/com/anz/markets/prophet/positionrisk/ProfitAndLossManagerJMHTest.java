package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

import static com.anz.markets.prophet.MidRateTestHelper.createPositions;

public class ProfitAndLossManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private Consumer<Positions> consumerOfPositions;
        private Positions positions;
        private TestStubConsumer<ProfitAndLoss> testConsumer;

        @Setup
        public void setup() throws IOException {
            testConsumer = new TestStubConsumer<>();
            positions = createPositions(Currency.AUD, 1_000_000.0, 0.5);
            final ProfitAndLossManager profitAndLossManager = new ProfitAndLossManager(testConsumer);
            consumerOfPositions = profitAndLossManager.consumerOfPositions();
        }
    }

    @Benchmark
    public long acceptPositions(@NotNull final Data data) throws Exception {
        data.consumerOfPositions.accept(data.positions);
        return data.testConsumer.getEvents().size();
    }
}
