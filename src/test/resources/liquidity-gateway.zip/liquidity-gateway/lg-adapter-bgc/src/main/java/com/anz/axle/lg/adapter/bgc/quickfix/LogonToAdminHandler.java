package com.anz.axle.lg.adapter.bgc.quickfix;

import java.util.Objects;

import quickfix.Message;
import quickfix.SessionID;
import quickfix.field.Password;
import quickfix.field.Username;

import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.ToAdminHandler;

public class LogonToAdminHandler implements ToAdminHandler {
    private final String username;
    private final String password;

    public LogonToAdminHandler(final String username, final String password) {
        this.username = Objects.requireNonNull(username);
        this.password = Objects.requireNonNull(password);
    }

    @Override
    public void handle(final MessageType messageType, final Message message, final SessionID sessionId) {
        if (messageType == MessageType.LOGON) {
            message.setString(Username.FIELD, username);
            message.setString(Password.FIELD, password);
        }
    }
}
