package com.anz.axle.lg.adapter.apama.ebs;

import java.util.function.Function;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.event.Event;

import com.anz.markets.efx.ngaro.api.Tenor;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EventToTenorTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Mock
    private Function<Event, String> eventToSettleDate;
    @Mock
    private Function<Event, String> eventToSettleType;
    @Mock
    private Function<String, Tenor> settleTypeToTenor;
    @Mock
    private Function<String, Tenor> settleDateToTenor;
    @Mock
    private Event event;

    //under test
    private EventToTenor eventToTenor;

    @Before
    public void setUp() throws Exception {
        eventToTenor = new EventToTenor(eventToSettleType, eventToSettleDate, settleTypeToTenor, settleDateToTenor);
    }

    @Test
    public void apply_null() throws Exception {
        //given
        final String settlType = null;
        when(eventToSettleType.apply(event)).thenReturn(settlType);

        //when + then
        assertThat(eventToTenor.apply(event)).isEqualTo(Tenor.SP);
    }

    @Test
    public void apply_broken_non_empty_date() throws Exception {
        //given
        final String settlType = "B";
        final String settlDate = "30042017";
        when(eventToSettleType.apply(event)).thenReturn(settlType);
        when(eventToSettleDate.apply(event)).thenReturn(settlDate);

        //when
        eventToTenor.apply(event);
        //then
        verify(settleDateToTenor).apply(settlDate);
    }

    @Test
    public void apply_broken_empty_date() throws Exception {
        //given
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage("empty settlement date for broken tenor");

        final String settlType = "B";
        final String settlDate = null;
        when(eventToSettleType.apply(event)).thenReturn(settlType);
        when(eventToSettleDate.apply(event)).thenReturn(settlDate);

        //when
        eventToTenor.apply(event);
    }

    @Test
    public void apply_non_broken() throws Exception {
        //given
        final String settlType = "M1";
        when(eventToSettleType.apply(event)).thenReturn(settlType);

        //when
        eventToTenor.apply(event);
        //then
        verify(settleTypeToTenor).apply(settlType);
    }

}