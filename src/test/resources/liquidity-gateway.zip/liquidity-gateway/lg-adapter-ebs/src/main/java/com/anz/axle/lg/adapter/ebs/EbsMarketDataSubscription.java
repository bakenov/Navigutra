package com.anz.axle.lg.adapter.ebs;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class EbsMarketDataSubscription implements MarketDataSubscription {

    private static final int DEFAULT_FULL_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK_TRUE = true;

    private final String symbol;
    private final Venue venue;
    private final InstrumentKey instrumentKey;
    private final StringToIntCache stringToIntCache;

    public EbsMarketDataSubscription(final Venue venue, final String symbol, final SecurityType securityType, final Tenor tenor, final StringToIntCache stringToIntCache) {
        this.venue = Objects.requireNonNull(venue);
        this.symbol = Objects.requireNonNull(symbol);
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), securityType, tenor);
        this.stringToIntCache = Objects.requireNonNull(stringToIntCache);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return venue;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public boolean fullRefresh() {
        return false;
    }

    @Override
    public boolean aggregateBook() {
        return DEFAULT_AGGREGATE_BOOK_TRUE;
    }

    @Override
    public int marketDepth() {
        return DEFAULT_FULL_MARKET_DEPTH;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return stringToIntCache;
    }

    @Override
    public String toString() {
        return "EbsMarketDataSubscription{" +
                "id=" + id() +
                ", venue=" + venue +
                ", symbol='" + symbol + '\'' +
                ", instrumentKey=" + instrumentKey +
                '}';
    }
}
