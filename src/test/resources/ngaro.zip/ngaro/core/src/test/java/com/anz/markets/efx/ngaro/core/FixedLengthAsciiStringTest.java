package com.anz.markets.efx.ngaro.core;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link FixedLengthAsciiString}
 */
@RunWith(Spockito.class)
public class FixedLengthAsciiStringTest {
    @Test
    public void set() {
        assertEquals("should set byte", "abc", new FixedLengthAsciiString(10).set(0, (byte)'a').set(2, (byte)'c').set(1, (byte)'b').toString());
        for(final String s : new String[] {"", "Hello", "Bla", "Blahblahbl"}) {
            assertEquals("should set string", s, new FixedLengthAsciiString(10).set(s).toString());
            assertEquals("should set char sequence", s, new FixedLengthAsciiString(10).set(new StringBuffer(s)).toString());
            assertEquals("should set ascii string", s, new FixedLengthAsciiString(10).set(AsciiString.immutable(s)).toString());
            assertEquals("should set source", s, new FixedLengthAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 0, s.length()).toString());
            assertEquals("should set nothing", "", new FixedLengthAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 0, 0).toString());
            if (!s.isEmpty()) {
                assertEquals("should set source[0]", s.substring(0, 1), new FixedLengthAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 0, 1).toString());
                assertEquals("should set source[1]", s.substring(1, 2), new FixedLengthAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 1, 1).toString());
            }
        }
    }

    @Test
    public void append() {
        final String prefix = "xyz";
        assertEquals("should set byte", prefix + "abc", new FixedLengthAsciiString(10).append(prefix).append((byte)'a').append((byte)'b').append((byte)'c').toString());
        for(final String s : new String[] {"", "Hello", "Bla", "Blahbla"}) {
            assertEquals("should append string", prefix + s, new FixedLengthAsciiString(10).set(prefix).append(s).toString());
            assertEquals("should append char sequence", prefix + s, new FixedLengthAsciiString(10).set(prefix).append(new StringBuffer(s)).toString());
            assertEquals("should append ascii string", prefix + s, new FixedLengthAsciiString(10).set(prefix).append(AsciiString.immutable(s)).toString());
            assertEquals("should append source", prefix + s, new FixedLengthAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 0, s.length()).toString());
            assertEquals("should append nothing", prefix, new FixedLengthAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 0, 0).toString());
            if (!s.isEmpty()) {
                assertEquals("should append source[0]", prefix + s.substring(0, 1), new FixedLengthAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 0, 1).toString());
                assertEquals("should append source[1]", prefix + s.substring(1, 2), new FixedLengthAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 1, 1).toString());
            }
        }
    }

    @Test
    public void clear() {
        assertEquals("should be empty after clear", true, new FixedLengthAsciiString(3).set("ABC").clear().isEmpty());
    }

    @Test
    public void isEmpty() {
        assertEquals("should not be empty", false, new FixedLengthAsciiString(3).set("Bla").isEmpty());
        assertEquals("should be empty", true, new FixedLengthAsciiString(3).isEmpty());
    }

    @Test
    public void capacity() {
        assertEquals("length should be 3", 10, new FixedLengthAsciiString(10).set("Bla").capacity());
        assertEquals("length should be 0", 0, new FixedLengthAsciiString(0).capacity());
        assertEquals("length should be 0", 10, new FixedLengthAsciiString(10).set("").capacity());
    }

    @Test
    public void length() {
        assertEquals("length should be 3", 3, new FixedLengthAsciiString(10).set("Bla").length());
        assertEquals("length should be 0", 0, new FixedLengthAsciiString(10).set("").length());
        assertEquals("length should be 4", 4, new FixedLengthAsciiString(10).set("ABCD\0\0\0\0").length());
        assertEquals("length should be 8", 8, new FixedLengthAsciiString(10).set("ABCD\1\1\1\1").length());
        assertEquals("length should be 4", 4, new FixedLengthAsciiString(10).append("ABCD\0\0\0\0").length());
        assertEquals("length should be 8", 8, new FixedLengthAsciiString(10).append("ABCD\1\1\1\1").length());
        assertEquals("length should be 0", 0, new FixedLengthAsciiString(10).set(0, AsciiString.NULL).length());
        assertEquals("length should be 0", 1, new FixedLengthAsciiString(10).set(0, (byte)1).length());
        assertEquals("length should be 0", 0, new FixedLengthAsciiString(10).append(AsciiString.NULL).length());
        assertEquals("length should be 0", 1, new FixedLengthAsciiString(10).append((byte)1).length());
    }

    @Test
    public void hash() {
        assertEquals("hash code should not be zero", true, 0 != new FixedLengthAsciiString(3).set("Bla").hashCode());
        assertEquals("hash code should be 0", 0, new FixedLengthAsciiString(3).hashCode());
    }

    @Test
    public void equals() {
        final FixedLengthAsciiString bla = new FixedLengthAsciiString(3).set("Bla");
        assertEquals("should equal itself", true, bla.equals(bla));
        assertEquals("should not equal null", false, bla.equals(null));
        assertEquals("should not equal other non AsciiString value", false, bla.equals("Bla"));
        assertEquals("should not equal other non-equal AsciiString", false, bla.equals(AsciiString.immutable("BlaBla")));
        assertEquals("should equal other equal AsciiString", true, bla.equals(AsciiString.immutable("Bla")));
        assertEquals("should equal other equal MutableAsciiString", true, bla.equals(AsciiString.expandable().set("Bla")));
    }

    @Test
    public void to_String() {
        assertEquals("should result in 'Bla' string", "Bla", new FixedLengthAsciiString(3).set("Bla").toString());
        assertEquals("should result in empty string", "", new FixedLengthAsciiString(3).set("").toString());
    }

    @Test
    public void get_charAt() {
        final String abc = "abcdefg";
        final AsciiString ascii = new FixedLengthAsciiString(10).set(abc);
        for (int i = 0; i < abc.length(); i++) {
            Assert.assertEquals("get(" + i + ") not as expected", (byte)abc.charAt(i), ascii.get(i));
            Assert.assertEquals("charAt(" + i + ") not as expected", abc.charAt(i), ascii.charAt(i));
        }
    }

    @Test
    public void get() {
        final String background = "0123456789";
        final String abc = "abcdefg";
        final AsciiString ascii = new FixedLengthAsciiString(10).set(abc);
        final StringBuilder sb = new StringBuilder();
        for (int maxLength = 0; maxLength < 20; maxLength++) {
            for (int i = 0; i < abc.length(); i++) {
                //given
                sb.setLength(0);
                sb.append(background);
                final int expLength = Math.min(maxLength, abc.length());
                final String expVal = ""
                        + background.substring(0, i)
                        + abc.substring(0, expLength)
                        + background.substring(Math.min(i + expLength, background.length()), background.length());
                Assert.assertEquals("return value from get(target, ..., " + i + ", " + maxLength +") not as expected",
                        expLength, ascii.get(sb, ByteWriter.STRING_BUILDER, i, maxLength));
                Assert.assertEquals("string written to target via get(target, ..., " + i + ", " + maxLength + ") is not as expected",
                        expVal, sb.toString());
            }
        }
    }

    @Test
    public void testEmpty() {
        //isEmpty
        assertEquals("should be empty", true, new FixedLengthAsciiString(3).isEmpty());
        assertEquals("length should be zero", 0, new FixedLengthAsciiString(3).length());
        //contains
        assertEquals("should not contain non-empty string", false, new FixedLengthAsciiString(3).contains(AsciiString.immutable("Bla")));
        assertEquals("should contain empty string", true, new FixedLengthAsciiString(3).contains(AsciiString.immutable("")));
        //indexOf
        assertEquals("indexOf(..) should return -1 for non-empty string", -1, new FixedLengthAsciiString(3).indexOf(AsciiString.immutable("Bla")));
        assertEquals("indexOf(..) should return 0 for empty string", 0, new FixedLengthAsciiString(3).indexOf(AsciiString.immutable("")));
        assertEquals("indexOf(..) should return 0 for empty string with fromIndex > 0", 0, new FixedLengthAsciiString(3).indexOf(AsciiString.immutable(""), 7));
        assertEquals("indexOf(..) should return 0 for empty string with fromIndex < 0", 0, new FixedLengthAsciiString(3).indexOf(AsciiString.immutable(""), -1));
        //hashCode
        assertEquals("hash code should be zero", 0, new FixedLengthAsciiString(3).hashCode());
        //equals
        assertEquals("should equal itself", true, new FixedLengthAsciiString(3).equals(new FixedLengthAsciiString(3)));
        assertEquals("should not equal null", false, new FixedLengthAsciiString(3).equals(null));
        assertEquals("should not equal other non AsciiString value", false, new FixedLengthAsciiString(3).equals("Bla"));
        assertEquals("should not equal other non-empty AsciiString", false, new FixedLengthAsciiString(3).equals(AsciiString.immutable("Bla")));
        assertEquals("should equal other empty AsciiString", true, new FixedLengthAsciiString(3).equals(AsciiString.EMPTY));
        assertEquals("should equal other empty MutableAsciiString", true, new FixedLengthAsciiString(3).equals(AsciiString.expandable().set("")));
        assertEquals("should equal with differences after string end", true, new FixedLengthAsciiString(10).set("1234567").set("89").equals(new FixedLengthAsciiString(10).set("89")));

        //compareTo
        assertEquals("should compare equal to itself", 0, new FixedLengthAsciiString(3).compareTo(new FixedLengthAsciiString(3)));
        assertEquals("should be smaller than any other non-empty string", -1, new FixedLengthAsciiString(3).compareTo(AsciiString.immutable("A")));
        assertEquals("should compare equal with differences after string end", 0, new FixedLengthAsciiString(10).set("1234567").set("89").compareTo(new FixedLengthAsciiString(10).set("89")));

        //toString
        assertEquals("should result in empty string", "", new FixedLengthAsciiString(3).toString());
        //toStringOrNull
        assertEquals("should result in null", null, new FixedLengthAsciiString(3).toStringOrNull());
        //get
        assertEquals("should copy zero bytes", 0, new FixedLengthAsciiString(3).get(null, ByteWriter.NULL, 0, Integer.MAX_VALUE));
        Assert.assertEquals("Must be NULL character if read after length but before capacity end",
                AsciiString.NULL, new FixedLengthAsciiString(3).get(0));
        try {
            new FixedLengthAsciiString(3).get(3);
        } catch (final IndexOutOfBoundsException e) {
            //expected, but not necessarily thrown
        }
    }


    @Test
    @Spockito.Unroll({
            "| value1      | value2   | value3  |",
            "|=============|==========|=========|",
            "| Bla1\0c     | Bla2\0b  | Bla3\0a |",
            "| Bla1\0c     | Bla2\0b  | Bla3\0a |",
            "| Bl\0aac     | Bla\0ac  | Blaa\0c |",
            "| Blaac       | Blaac    | Blaac   |"
    })
    @Spockito.Name("[{row}]: {value1} < {value2} < {value3}")
    public void compareTo_inequalities(final String value1, final String value2, final String value3) {
        final FixedLengthAsciiString bla1 = new FixedLengthAsciiString(5).set(value1);
        final FixedLengthAsciiString bla2 = new FixedLengthAsciiString(5).set(value2);
        final FixedLengthAsciiString bla3 = new FixedLengthAsciiString(5).set(value3);

        assertTrue("should compare to itself", bla1.compareTo(bla1) == 0);
        assertTrue("should compare to itself", bla2.compareTo(bla2) == 0);
        assertTrue("should compare to itself", bla3.compareTo(bla3) == 0);

        assertTrue("bla1 should be less than bla2", Integer.signum(bla1.compareTo(bla2)) == -Integer.signum(bla2.compareTo(bla1)));
        assertTrue("bla2 should be less than bla3", Integer.signum(bla2.compareTo(bla3)) == -Integer.signum(bla3.compareTo(bla2)));
        assertTrue("bla1 should be less than bla3", Integer.signum(bla1.compareTo(bla3)) == -Integer.signum(bla3.compareTo(bla1)));
    }

    @Test
    @Spockito.Unroll({
            "| value1      | value2   | value3  |",
            "|=============|==========|=========|",
            "| Bla1\0c     | Bla1\0b  | Bla1\0a |",
            "| \0Blaac     | \0Blaac  | \0Blaac |"
    })
    @Spockito.Name("[{row}]: {value1} == {value2} == {value3}")
    public void compareTo_equalities(final String value1, final String value2, final String value3) {
        final FixedLengthAsciiString bla1 = new FixedLengthAsciiString(5).set(value1);
        final FixedLengthAsciiString bla2 = new FixedLengthAsciiString(5).set(value2);
        final FixedLengthAsciiString bla3 = new FixedLengthAsciiString(5).set(value3);

        assertTrue("should compare to itself", bla1.compareTo(bla1) == 0 && bla1.equals(bla1));
        assertTrue("should compare to itself", bla2.compareTo(bla2) == 0 && bla2.equals(bla2));
        assertTrue("should compare to itself", bla3.compareTo(bla3) == 0 && bla3.equals(bla3));

        assertTrue("bla1 should equal to bla2", bla1.compareTo(bla2) == bla2.compareTo(bla1) && bla1.equals(bla2) && bla2.equals(bla1));
        assertTrue("bla2 should equal to bla3", bla2.compareTo(bla3) == bla3.compareTo(bla2) && bla2.equals(bla3) && bla3.equals(bla2));
        assertTrue("bla1 should equal to bla3", bla1.compareTo(bla3) == bla3.compareTo(bla1) && bla1.equals(bla3) && bla3.equals(bla1));
    }

}