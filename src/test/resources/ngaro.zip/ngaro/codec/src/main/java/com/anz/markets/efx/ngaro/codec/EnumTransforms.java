package com.anz.markets.efx.ngaro.codec;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;

/**
 * Class with factory methods for transform functions that can be used to decode strings directly to enum values and to
 * encode enum values to strings. The transform functions are compatible with
 * {@link StringDecoder#decodeAndTransform(Function)} and {@link StringEncoder#encode(Object, BiFunction)}, respectively.
 */
public final class EnumTransforms {

    public static final Comparator<Enum<?>> ENUM_NAME_COMPARATOR = (e1, e2) -> e1.name().compareTo(e2.name());

    /**
     * Returns a new transform function that can be passed to {@link StringEncoder#encode(Object, BiFunction)} to encode
     * an enum value directly to a string using the constant's {@link Enum#name() name}. The transform throws a
     * {@link NullPointerException} if null values are passed to the encode method.
     * <p>
     * The returned transform function is thread safe.
     *
     * @param <V>   the enum value type
     * @param <S>   the string encoder type
     * @param <E>   the enclosing encoder type
     * @return a transform function from enum to string encoder
     */
    public static <V extends Enum<V>, S extends StringEncoder<E>, E> BiFunction<V, S, E> fromEnum() {
        return (val, enc) -> enc.encode(val.name());
    }

    /**
     * Returns a new transform function that can be passed to {@link StringEncoder#encode(Object, BiFunction)} to encode
     * an enum value directly to a string using the constant's {@link Enum#name() name}. The transform accepts null
     * values which are encoded as empty strings.
     * <p>
     * The returned transform function is thread safe.
     *
     * @param <V>   the enum value type
     * @param <S>   the string encoder type
     * @param <E>   the enclosing encoder type
     * @return a transform function from enum (or null) to string encoder
     */
    public static <V extends Enum<V>, S extends StringEncoder<E>, E> BiFunction<V, S, E> fromEnumNullable() {
        return (val, enc) -> enc.encodeNullable(val != null ? val.name() : null);
    }

    /**
     * Returns a new transform function that can be passed to {@link StringDecoder#decodeAndTransform(Function)} to
     * decode a string directly into an enum constant. If the string value is empty or not a valid constant name,
     * the transformed value will be null.
     * <p>
     * The returned transform function is NOT thread safe!
     *
     * @param enumClass the enum class for which to create a transform function
     * @param <V> the enum value type
     * @return a transform function from string decoder to enum
     */
    public static <V extends Enum<V>> Function<StringDecoder, V> toEnumOrNull(final Class<V> enumClass) {
        return toEnum(enumClass, () -> null, s -> null);
    }

    /**
     * Returns a new transform function that can be passed to {@link StringDecoder#decodeAndTransform(Function)} to
     * decode a string directly into an enum constant. If the string value is empty, the transformed value will be null.
     * Other strings which are neither empty nor matching any of the constant's names will lead to an exception.
     * <p>
     * The returned transform function is NOT thread safe!
     *
     * @param enumClass the enum class for which to create a transform function
     * @param <V> the enum value type
     * @return a transform function from string decoder to enum
     */
    public static <V extends Enum<V>> Function<StringDecoder, V> toEnumOrException(final Class<V> enumClass) {
        return toEnum(enumClass, () -> null, s -> {
            throw new IllegalArgumentException("Enum " + enumClass.getName() + " has no constant whose name equals or starts with \"" + s + "\"");
        });
    }

    /**
     * Returns a new transform function that can be passed to {@link StringDecoder#decodeAndTransform(Function)} to
     * decode a string directly into an enum constant. If the string value is empty, {@code emptyStringValueSupplier} is
     * invoked to determine the translated null value. For other strings which are neither empty nor matching any of the
     * constant's names, {@code invalidNameValueSupplier} determines the value to be returned (or the behaviour if it throws
     * an exception).
     * <p>
     * The returned transform function is NOT thread safe!
     *
     * @param enumClass                 the enum class for which to create a transform function
     * @param emptyStringValueSupplier  supplier of the value in case of an empty string
     * @param invalidNameValueSupplier  supplier of the value in case of a non-empty string that does not match any of
     *                                  the enum constant's names; the argument passed to the function contains the
     *                                  decoded invalid string value (possibly truncated, i.e. a prefix of the true
     *                                  input string)
     * @param <V> the enum value type
     * @return a transform function from string decoder to enum
     */
    public static <V extends Enum<V>> Function<StringDecoder, V> toEnum(final Class<V> enumClass,
                                                                        final Supplier<? extends V> emptyStringValueSupplier,
                                                                        final Function<? super AsciiString, ? extends V> invalidNameValueSupplier) {
        final V[] nameSortedConstants = enumClass.getEnumConstants();
        Arrays.sort(nameSortedConstants, ENUM_NAME_COMPARATOR);
        //NOTE: we need to read (maxNameLength + 1) chars to detect illegal names that match a constant up and until maxNameLength
        final int maxReadLen = 1 + maxNameLength(nameSortedConstants);
        final MutableAsciiString asciiString = new FixedLengthAsciiString(maxReadLen);
        return dec -> {
            final int len = dec.decodeTo(asciiString, maxReadLen);
            if (len == 0) {
                return emptyStringValueSupplier.get();
            }
            final int index = binarySearch(nameSortedConstants, asciiString);
            if (index >= 0) {
                asciiString.clear();
                return nameSortedConstants[index];
            }
            try {
                return invalidNameValueSupplier.apply(asciiString);
            } finally {
                asciiString.clear();
            }
        };
    }

    private static int maxNameLength(final Enum<?>[] enums) {
        int len = 0;
        for (final Enum<?> e : enums) {
            len = Math.max(len, e.name().length());
        }
        return len;
    }

    private static int binarySearch(final Enum<?>[] enums, final CharSequence name) {
        int low = 0;
        int high = enums.length - 1;

        while (low <= high) {
            final int mid = (low + high) >>> 1;
            final int cmp = AsciiString.compare(enums[mid].name(), name);

            if (cmp < 0)
                low = mid + 1;
            else if (cmp > 0)
                high = mid - 1;
            else
                return mid; // name found
        }
        return -1;  // name not found.
    }

    private EnumTransforms() {
        throw new RuntimeException("No EnumTransform for you!");
    }
}
