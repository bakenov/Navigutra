package com.anz.axle.adapters.rmds.consumer.marketdata;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.anz.axle.adapters.rmds.consumer.ForwardPointSubscriber;

public class ConsumerDriver {
    private static final Logger logger = Logger.getLogger(ConsumerDriver.class);
    /**
     * Entrypoint
     * @param argv
     */
    public static void main(String argv[]) {
        
        String contextFile = argv.length == 0 ? "rmds-applicationContext.xml" : argv[0];

        logger.info("Initializing RFA consumer with context " + contextFile);
        ClassPathXmlApplicationContext context = null;

        try {
            context = new ClassPathXmlApplicationContext(contextFile);
        } catch (Exception e) {
            logger.error("Error initializing application context", e);
            System.exit(-1);
        }

        final ForwardPointSubscriber subscriber = context.getBean(ForwardPointSubscriber.class);
        
        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                logger.info("Executing shutdown hook");
                subscriber.cleanup();
            }
        });
        
        subscriber.run();
        
        while (true) {
            try {
                Thread.sleep(10000L);
            } catch (InterruptedException e) {
            }
        }
        
    }

}
