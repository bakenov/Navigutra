package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.LongSupplier;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.mockito.InOrder;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.ebs.EventToRequestKey;
import com.anz.axle.lg.adapter.apama.ebs.EventToTenor;
import com.anz.axle.lg.adapter.apama.ebs.EventToTranslatedSymbol;
import com.anz.axle.lg.adapter.apama.ebs.SettleTypeToTenor;
import com.anz.axle.lg.adapter.apama.event.EbsMarketDataSnapshotFullRefresh;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link EbsMarketDataSnapshotDecoder}
 */
@RunWith(Parameterized.class)
public class EbsMarketDataSnapshotDecoderTest {
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormat.forPattern("yyyyMMdd-HH:mm:ss.SSS").withZoneUTC();
    private static final EventParser APAMA_EVENT_PARSER = new EventParser(
            EbsMarketDataSnapshotFullRefresh.EVENT_TYPE);
    private static final long CURRENT_TIME = 34523453;

    private final DecoderTestMode mode;

    //mocks
    private String senderCompId = "GB:EBS";
    private String compId = "GB:lg-ebs";
    //mocks
    private VenueRequestKeyLookup requestKeyLookup;
    private PricingEncoderLookup pricingEncoderLookup;
    private MockitoPricingEncoder encoders;
    private PricingEncoderSupplier encoderSupplier;
    private LongSupplier messageIdSupplier;
    private InOrder inOrder;
    private PrecisionClock precisionClock;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    //under test
    private EbsMarketDataSnapshotDecoder ebsMarketDataSnapshotDecoder;

    public EbsMarketDataSnapshotDecoderTest(final DecoderTestMode mode) {
        this.mode = Objects.requireNonNull(mode);
    }

    @Parameterized.Parameters
    public static Collection<DecoderTestMode> testParameters() {
        return Arrays.asList(DecoderTestMode.values());
    }

    @Before
    public void beforeEach() {
        //initialise mocks
        encoders = new MockitoPricingEncoder();

        precisionClock = mock(PrecisionClock.class);
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);

        messageIdSupplier = mock(LongSupplier.class);
        when(messageIdSupplier.getAsLong()).thenReturn(10L);

        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.EBS);

        encoderSupplier = mock(PricingEncoderSupplier.class, RETURNS_MOCKS);
        when(encoderSupplier.incrementalRefresh()).thenReturn(encoders.incrementalEncoder);
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);

        final PricingEncoderSupplier modedEncoderSupplier = mode.encoderSupplier(encoderSupplier);

        pricingEncoderLookup = mock(PricingEncoderLookup.class);
        when(pricingEncoderLookup.lookup(any())).thenReturn(modedEncoderSupplier);

        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotEntries_next,
                encoders.snapshotEntries_body,
                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),

                encoders.messageEncoder);

        final SettleTypeToTenor settleTypeToTenor = new SettleTypeToTenor();
        final EventToTenor messageEventToTenor = EventToTenor.forMessageEvent(settleTypeToTenor);
        final Function<Event, String> ebsMessageEventToTranslatedSymbol = EventToTranslatedSymbol.forMessageEvent(Collections.emptyMap(), Collections.emptyMap());
        final EventToRequestKey messageEventToRequestKey = EventToRequestKey.forMessageEvent((securityType, s) -> true, requestKeyLookup, ebsMessageEventToTranslatedSymbol, messageEventToTenor);

        //under test
        ebsMarketDataSnapshotDecoder = new EbsMarketDataSnapshotDecoder(messageEventToRequestKey, pricingEncoderLookup, precisionClock, senderCompId, compId, messageIdSupplier, sourceSequencer);
    }

    @Test
    public void shouldDecode_Snapshot() throws Exception {
        //given
        final String evtStr = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"AUD/USD\",2," +
                "[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.78815,4e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7881,1e+07,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.788,9e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.78795,6e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7879,7e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.78785,3e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7878,9e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78845,4e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.7885,4e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78855,1e+07,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78865,9e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.7887,6e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78875,7e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.7888,3e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78885,9e+06,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"x\",.7882,0,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"w\",.78845,0,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150225-05:06:24.575").getMillis());

        //when
        ebsMarketDataSnapshotDecoder.decode(evt);

        //then:
        verifySnapshotBodyFields(Venue.EBS, "AUDUSD", 16, expectedSendingTimeNanos);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .7882, 4e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .78815, 4e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .7881, 1e+07);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .788, 9e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .78795, 6e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .7879, 7e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .78785, 3e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.BID, .7878, 9e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78845, 4e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .7885, 4e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78855, 1e+07);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78865, 9e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .7887, 6e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78875, 7e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .7888, 3e+06);
        verifyEntry(expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78885, 9e+06);
    }

    @Test
    public void shouldIgnore_WhenNonPriceDepthView() throws Exception {
        //given
        final String spreadViewTagValueStr = "1101";
        final String evtStr = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"USD/HKD\"," +
                spreadViewTagValueStr + ",[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22453,2e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22451,2e+06,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        ebsMarketDataSnapshotDecoder.decode(evt);

        //then:
        verifyZeroInteractions(encoders.pricingEncoders);
    }


    @Test
    public void shouldDecodeIntoEmptyBook_WhenNoDataAvailableQuoteCondition() throws Exception {
        //given
        final String evtStr = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"AUD/USD\",2," +
                "[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{276:\"1001\",277:\"1001\"})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78845,4e+06,\"\",{276:\"1001\",277:\"1001\"})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"x\",.7882,0,\"\",{})," +
                "com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"w\",.78845,0,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);
        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150225-05:06:24.575").getMillis());


        //when
        ebsMarketDataSnapshotDecoder.decode(evt);

        // then
        verifySnapshotBodyFields(Venue.EBS, "AUDUSD", 0, expectedSendingTimeNanos);
    }

    private void verifySnapshotBodyFields(final Venue venue,
                                          final String symbol,
                                          final int entriesCount,
                                          final long sendingTimeNanos) {
        inOrder.verify(encoders.snapshotBody).sendingTime(sendingTimeNanos);
        inOrder.verify(encoders.snapshotBody).instrumentId(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        inOrder.verify(encoders.snapshotBody).marketId(venue);
        if (entriesCount > 0) {
            inOrder.verify(encoders.snapshotBody).entriesStart(entriesCount);
        }
    }

    private void verifyEntry(final long transactTimeNanos,
                             final Venue venue,
                             final EntryType side,
                             final double price,
                             final double quantity) {

        inOrder.verify(encoders.snapshotEntries_body).transactTime(transactTimeNanos);
        inOrder.verify(encoders.snapshotEntries_body).mdMkt(venue);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryType(side);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryPx(price);
        inOrder.verify(encoders.snapshotEntries_body).mdEntrySize(quantity);
        inOrder.verify(encoders.snapshotEntries_body).minQty(quantity);
    }

}