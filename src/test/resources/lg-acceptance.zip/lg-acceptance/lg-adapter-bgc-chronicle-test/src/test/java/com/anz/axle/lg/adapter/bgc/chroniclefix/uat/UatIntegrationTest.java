package com.anz.axle.lg.adapter.bgc.chroniclefix.uat;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance.AcceptanceContext;
import com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance.TradingAcceptanceConfig;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.HandlInst;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import net.openhft.chronicle.bytes.Bytes;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.markets.efx.trading.codec.api.ExecType.CANCELED;
import static com.anz.markets.efx.trading.codec.api.ExecType.NEW;
import static com.anz.markets.efx.trading.codec.api.ExecType.PENDING_CANCEL;
import static com.anz.markets.efx.trading.codec.api.ExecType.PENDING_NEW;
import static com.anz.markets.efx.trading.codec.api.ExecType.TRADE;

@Category(UatTest.class)
public class UatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatIntegrationTest.class);

    public static final String GB_LG_BGC = "GB:lg-bgcc";
    public static final String GB_LG_ACC = "GB:lg-acc";

    private static final char BUY = com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.BUY;
    private static final char SELL = com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.SELL;

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private FixMessageSender fixTradingMessageSender;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());

        final String path = System.getProperty("bgc.fix.trading.logging.base_path", "target/fixlog");
        final String testFixLogsPath = path.replace("logs", "target");
        System.getProperties().put("bgc.fix.trading.logging.base_path", testFixLogsPath);

        System.getProperties().putAll(StringUtils.parseMap(
    "appName:lg-bgc" +
                ",default.log.appender:Console" +
                ",default.log.level:DEBUG" +
                ",appOptions:--reset" +
                ",chronicle.fix.logging:true" +
                ",bgc.fix.pricing.session.enable:false" +
                ",bgc.fix.log.queue.RollCycle:MINUTELY" +
                ",bgc.fix.trading.allowedLatencyMs:60000" +
                ",bgc.fix.trading.log_all:true" +

                ",bgc.fix.trading.sendercompid:ANZL_MID_TR1_BETA" +
                ",bgc.fix.trading.targetcompid:BGC_PARTNERS" +
                ",bgc.fix.trading.username:midanzt1" +
                ",bgc.fix.trading.password:espeed" +
                ",bgc.fix.trading.host:10.54.189.16" +
                ",bgc.fix.trading.port:64000"
                ));

        application = new Application("lg-bgc-acceptance", TradingAcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();

        fixTradingMessageSender = application.getApplicationContext().getBean("fixTradingMessageSender", FixMessageSender.class);
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void testSendOrderAndReceiveExecutionReport() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();

        final PriceEntry entry = new PriceEntry();
        entry.instrumentKey = InstrumentKey.of("USDCAD", SecurityType.FXSPOT, Tenor.SP);
        entry.side = Side.SELL;
        entry.price = 1d;
        entry.size = 1_000_000;

        Thread.sleep(10000); // wait for logon

        final NewOrderSingle newOrderSingle = newOrderSingle(entry, clOrdId, OrderType.LIMIT);
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        System.out.println("====Waiting for NEW===========================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, NEW, 1);
        System.out.println("====Waiting for TRADE========================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, TRADE, 5);
    }

    @Test
    public void testSendOrderAndReceivePendingNewThenCancel() throws Exception {
        String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();

        final PriceEntry entry = new PriceEntry();
        entry.instrumentKey = InstrumentKey.of("USDCAD", SecurityType.FXSPOT, Tenor.SP);
        entry.side = Side.SELL;
        entry.price = 1d;
        entry.size = 10000000;

        TimeUnit.SECONDS.sleep(10); // wait for logon

        final NewOrderSingle newOrderSingle = newOrderSingle(entry, clOrdId, OrderType.LIMIT);
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        System.out.println("====Wait 2 sec and Send Cancel================================");
        TimeUnit.SECONDS.sleep(2);
        clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final OrderCancelRequest orderCancelRequest = orderCancelRequest(clOrdId, newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequest);

        System.out.println("====Waiting for PENDING_CANCEL================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, PENDING_CANCEL, 2);
        System.out.println("====Waiting for CANCEL=======================================");
        assertExecutionReport(entry, clOrdId, OrderType.LIMIT, CANCELED);
    }

    private com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle chronicleNewOrderSingle(final String clOrdId, final PriceEntry entry) throws Exception {

        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle newOrderSingle = new DefaultNewOrderSingle();
        newOrderSingle.clOrdID(newOrderSingle.clOrdID_buffer());
        newOrderSingle.clOrdID().append(Bytes.from(clOrdId));
        newOrderSingle.handlInst(HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        newOrderSingle.account("DA-ANZ");
        newOrderSingle.ordType(OrdType.LIMIT);
        newOrderSingle.symbol(SymbolNormaliser.toSymbol7(entry.instrumentKey.symbol()));
        newOrderSingle.price(entry.price);
        newOrderSingle.orderQty(entry.size);
        newOrderSingle.side(entry.side.equals(Side.SELL) ? SELL : BUY);
        newOrderSingle.timeInForce(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.DAY);
        newOrderSingle.currency(entry.currency());
        newOrderSingle.transactTime(acceptanceContext.precisionClock().nanos());

        return newOrderSingle;
    }

    private com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle sendNewOrderSingle(final String clOrdId, final PriceEntry entry) throws Exception {

        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle newOrderSingle = chronicleNewOrderSingle(clOrdId, entry);
        fixTradingMessageSender.accept(newOrderSingle);
        return newOrderSingle;
    }

    private void chronicleSendOrderCancelRequest(final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle newOrderSingle) throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest orderCancelRequest = new DefaultOrderCancelRequest();
        orderCancelRequest.clOrdID(newOrderSingle.clOrdID_buffer());
        orderCancelRequest.clOrdID().append(Bytes.from(clOrdId));
        orderCancelRequest.origClOrdID(newOrderSingle.clOrdID());
        orderCancelRequest.symbol(newOrderSingle.symbol());
        orderCancelRequest.side(newOrderSingle.side());
        orderCancelRequest.transactTime(acceptanceContext.precisionClock().nanos());

        fixTradingMessageSender.accept(orderCancelRequest);
    }

    private NewOrderSingle newOrderSingle(final PriceEntry entry, final String clOrdId, final OrderType orderType) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.currency = entry.currency();
        newOrderSingle.body.symbol = entry.instrumentKey.symbol();
        newOrderSingle.body.price = entry.price;
        newOrderSingle.body.orderQty = entry.size;
        newOrderSingle.body.side = entry.side;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.timeInForce = TimeInForce.DAY;
        newOrderSingle.body.settlCurrency = entry.currency();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private OrderCancelRequest orderCancelRequest(final String clOrdId, final NewOrderSingle newOrderSingle) {
        final OrderCancelRequest orderCancelRequest = new OrderCancelRequest();
        orderCancelRequest.body.senderCompId = GB_LG_ACC;
        orderCancelRequest.body.clOrdId = clOrdId;
        orderCancelRequest.body.origClOrdId = newOrderSingle.body.clOrdId;
        orderCancelRequest.body.symbol = newOrderSingle.body.symbol;
        orderCancelRequest.body.side = newOrderSingle.body.side;
        orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
        return orderCancelRequest;
    }

    private void assertExecutionReport(final PriceEntry priceEntry, final String clOrdId, final OrderType orderType, final ExecType execType, final long sleepBefore) throws Exception {
        TimeUnit.SECONDS.sleep(sleepBefore);

        final ExecutionReportMatcher matcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_BGC))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.marketId().eq(Venue.BGCMIDFX.name()))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.symbol().eq(priceEntry.instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(priceEntry.currency()))
                .body().matches(ExecutionReportMatcher.side().eq(priceEntry.side))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0)
                .hops().countAtLeast(2);

        switch (execType) {
            case PENDING_NEW:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(PENDING_NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PENDING_NEW));
                break;
            case NEW:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW));
                break;
            case TRADE:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED));
                break;
            case CANCELED:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED));
                break;
        }

        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
            .matching(matcher)
            .awaitMatchAndGetLast(30, TimeUnit.SECONDS);
    }

    private void assertExecutionReport(final PriceEntry priceEntry, final String clOrdId, final OrderType orderType, final ExecType execType) throws Exception {
        assertExecutionReport(priceEntry, clOrdId, orderType, execType, 0L);
    }
}