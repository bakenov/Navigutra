package com.anz.markets.efx.fox.codec.api;


import org.junit.Test;

import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

public class InstrumentConfigEncoderTest {
    @Test
    public void encoderChaining() {
        final InstrumentConfigEncoder encoder = mock(InstrumentConfigEncoder.class, RETURNS_DEEP_STUBS);

        encoder.messageStart(0, 0)
                .instrumentId(353453)
                .pipSizeDivisor(10000)
                .enabled(true)
                .messageComplete();
    }
}