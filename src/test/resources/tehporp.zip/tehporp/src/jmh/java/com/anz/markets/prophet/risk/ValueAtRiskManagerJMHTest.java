package com.anz.markets.prophet.risk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.positionrisk.Positions;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.util.function.Consumer;


public class ValueAtRiskManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private final TestStubConsumer<ValueAtRisk> valueAtRiskTestStubConsumer = new TestStubConsumer<>();
        private final Positions positions = MidRateTestHelper.createPositions(Currency.AUD, 7200000, 1);
        private Consumer<Positions> consumerForPositions;

        @Setup
        public void setup() {
            final ValueAtRiskManager valueAtRiskManager = ValueAtRiskManagerTest.createValueAtRiskManager(valueAtRiskTestStubConsumer);
            consumerForPositions = valueAtRiskManager.consumerOfPositions();
        }
    }

    @Benchmark
    public long acceptPositionsAndOutputValueAtRisk(@NotNull final Data data) {
        data.consumerForPositions.accept(data.positions);
        return data.valueAtRiskTestStubConsumer.getEvents().size();
    }
}
