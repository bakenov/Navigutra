package com.anz.markets.prophet.atest.risk._1_position;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.positionrisk.Position;
import com.anz.markets.prophet.positionrisk.Positions;
import org.hamcrest.number.IsCloseTo;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Region.GB;
import static java.lang.Double.NaN;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "Not sure why! test should revert all trade.. at the start anyway.")
public class PositionAdjustmentTest extends BaseAcceptanceSpecification {

    @Test
    @DisplayName("Make sure that position is reset")
    public void should_reset_position() {
        precondition:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMarketConfigs(Arrays.asList(
                            // define driver pairs for market
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.resetAllPositions();
        }
        then:
        {
            // should only generate three position update.
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // position from trade
                assertThat(positionsUpdates.get(0).getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.get(0).getPosition1().getPositionInNotional(), is(1_000_000.0));
                assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(1_000_000 * 0.75));
                assertThat(positionsUpdates.get(0).getPosition1().getMidRate(), is(0.75));
                assertThat(positionsUpdates.get(0).getPosition1().getAvgRate(), is(0.9));

                assertThat(positionsUpdates.get(0).getPosition2().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.get(0).getPosition2().getPositionInNotional(), is(-1_000_000 * 0.9));
                assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(-1_000_000 * 0.9));
                assertThat(positionsUpdates.get(0).getPosition2().getAvgRate(), is(1.)); // usd to usd rate is always 1.0}
            }
            and:
            {
                // aud reset
                assertThat("A reset only have one.", positionsUpdates.get(1).countPositions(), is(1));
                assertThat(positionsUpdates.get(1).getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), is(0.0));
                assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(0.0));
                assertThat(positionsUpdates.get(1).getPosition1().getMidRate(), is(0.75));
                assertThat(positionsUpdates.get(1).getPosition1().getAvgRate(), is(Double.NaN));
            }
            and:
            {
                // usd reset
                assertThat("A reset only have one.", positionsUpdates.get(2).countPositions(), is(1));
                assertThat(positionsUpdates.get(2).getPosition1().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.get(2).getPosition1().getPositionInNotional(), is(0.0));
                assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(0.0));
                assertThat(positionsUpdates.get(2).getPosition1().getMidRate(), is(1.0));
                assertThat(positionsUpdates.get(2).getPosition1().getAvgRate(), is(1.0));

            }
        }
    }

    @Test
    @DisplayName("When adjusting positions in bulk, we will only send one pnl update at the end of the adjustment.")
    public void should_adjust_position_in_bulk_resulting_in_single_pnl_update() {
        precondition:
        {
            prophet.receive(tdd.configuration_pricing_base());

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.GBPUSD, 0.9000, 0.00040));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75));
            prophet.receive(tdd.client_trade_001(Instrument.GBPUSD, 1_000_000, 0.9));
        }
        when:
        // adjust position in batch
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.adjustments(tdd.adjustment(Currency.AUD, 1_000),
                    tdd.adjustment(Currency.USD, 2_000),
                    tdd.adjustment(Currency.GBP, 3_000)
            ));
        }
        then:
        {
            // should generate three position updates from adjustment  - AUD, USD and GBP.
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            final double audPosInSystemBase = (1_000_000 + 1000) * 0.75;
            and:
            {
                assertThat(positionsUpdates.get(0).getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.get(0).getPosition1().getPositionInNotional(), is(1_000_000.0 + 1000));
                assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(audPosInSystemBase));
                assertThat(positionsUpdates.get(0).getPosition1().getMidRate(), is(0.75));
                assertThat(positionsUpdates.get(0).getPosition1().getAvgRate(), is(0.75));
                assertThat(positionsUpdates.get(0).getOrderId(), is(Positions.ADJUSTMENT_IDENTIFIER));
            }
            final double usdPos = ((-1_000_000) * 0.75) + (-1_000_000 * .9) + 2000;
            and:
            {
                assertThat(positionsUpdates.get(1).getPosition1().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), is(usdPos));
                assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(usdPos));
                assertThat(positionsUpdates.get(1).getPosition1().getAvgRate(), is(1.)); // usd to usd rate is always 1.0}
                assertThat(positionsUpdates.get(1).getOrderId(), is(Positions.ADJUSTMENT_IDENTIFIER));

            }
            final double gbpPosInSystemBase = (1_000_000 + 3000.0) * .9;
            and:
            {
                assertThat(positionsUpdates.get(2).getPosition1().getCcy(), is(Currency.GBP));
                assertThat(positionsUpdates.get(2).getPosition1().getPositionInNotional(), is(1_000_000 + 3000.0));
                assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(gbpPosInSystemBase));
                assertThat(positionsUpdates.get(2).getPosition1().getMidRate(), is(.9));
                assertThat(positionsUpdates.get(2).getPosition1().getAvgRate(), is(.9));
                assertThat(positionsUpdates.get(2).getOrderId(), is(Positions.LAST_ADJUSTMENT_IDENTIFIER));
            }
            and:
            // only one pnl update
            {
                final ProfitAndLoss pnl = prophet.expect(ProfitAndLoss.class, exactly(1)).getFirst();
                assertThat(pnl.getValueSystemBaseCurrency(), is(audPosInSystemBase + gbpPosInSystemBase + usdPos));
            }
        }
    }

    @Test
    @DisplayName("Bulk adjustments resetting all positions to 0, we will only send one pnl update at the end of the adjustment.")
    public void should_adjust_positions_to_zero_in_bulk_resulting_in_single_pnl_update() {
        precondition:
        {
            prophet.receive(tdd.configuration_pricing_base());

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.GBPUSD, 0.90000, 0.00040));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75001));
            prophet.receive(tdd.client_trade_001(Instrument.GBPUSD, 1_000_000, 0.90001));
        }
        when:
        // adjust position in batch
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.adjustments(tdd.adjustment(Currency.AUD, -1_000_000),
                    tdd.adjustment(Currency.GBP, -1_000_000),
                    tdd.adjustment(Currency.USD, 1_650_020)
            ));
        }
        then:
        {
            // should generate three position updates from adjustment  - AUD, GBP and USD.
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(3), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                assertThat(positionsUpdates.get(0).getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.get(0).getPosition1().getPositionInNotional(), is(0.0));
                assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(0.0));
                assertThat(positionsUpdates.get(0).getPosition1().getMidRate(), is(0.75));
                assertThat(positionsUpdates.get(0).getPosition1().getAvgRate(), is(Double.NaN));
                assertThat(positionsUpdates.get(0).getOrderId(), is(Positions.ADJUSTMENT_IDENTIFIER));
            }
            and:
            {
                assertThat(positionsUpdates.get(1).getPosition1().getCcy(), is(Currency.GBP));
                assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), is(0.0));
                assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(0.0));
                assertThat(positionsUpdates.get(1).getPosition1().getAvgRate(), is(Double.NaN)); // usd to usd rate is always 1.0}
                assertThat(positionsUpdates.get(1).getOrderId(), is(Positions.ADJUSTMENT_IDENTIFIER));

            }
            and:
            {
                assertThat(positionsUpdates.get(2).getPosition1().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.get(2).getPosition1().getPositionInNotional(), is(0.0));
                assertThat(positionsUpdates.get(2).getPosition1().getPositionInSystemBase(), is(0.0));
                assertThat(positionsUpdates.get(2).getPosition1().getMidRate(), is(1.));
                assertThat(positionsUpdates.get(2).getPosition1().getAvgRate(), is(1.));
                assertThat(positionsUpdates.get(2).getOrderId(), is(Positions.LAST_ADJUSTMENT_IDENTIFIER));
            }
            and:
            // only one pnl update
            {
                final ProfitAndLoss pnl = prophet.expect(ProfitAndLoss.class, exactly(1)).getFirst();
                assertThat(pnl.getValueSystemBaseCurrency(), is(0.0));
            }
        }
    }

    @Test
    @DisplayName("Cannot adjust position without mid rate.")
    public void cannot_adjust_position_without_mid_rate() {
        when:
        {
            prophet.receive(tdd.adjustment(Currency.AUD, 1_000_000));
        }
        then:
        {
            // should generate no update.
            prophet.expect(Positions.class, exactly(0));
        }
    }

    @Test
    @DisplayName("Adjust position with mid rate.")
    public void should_adjust_position_with_mid_rate() {
        precondition:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMarketConfigs(Arrays.asList(
                            // define driver pairs for market
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.adjustment(Currency.AUD, 1_000_000));
        }
        then:
        {
            // should only generate one position update.
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();

            // position from adjustment
            assertThat(positionsUpdate.countPositions(), is(1));
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_4_6_10})
    @DisplayName("Process Adjustment with execution rate i.e from JMX")
    public void send_adjustment_with_execution_rate() {
        double averageExecutionRate;

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(2_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // posi change by second trade
                assertThat(positionsUpdates.getLast().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getLast().getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0));
                assertThat(positionsUpdates.getLast().getPosition1().getAvgRate(), is((0.9 + 0.8 * 2) / 3));
                averageExecutionRate = positionsUpdates.getLast().getPosition1().getAvgRate();

                assertThat(positionsUpdates.getLast().getPosition1().getPnl(), is(closeTo((((0.9 + 0.8 * 2) / 3) - 0.7500) * -3_000_000, 7)));
            }
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75005, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.adjustment(Currency.AUD, 2_000_000, 0.75010));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0 + 2_000_000.0));
            assertThat(positionsUpdate.getPosition1().getAvgRate(), is(closeTo(((3 * averageExecutionRate) + (2 * 0.7501)) / 5, 7)));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_4_6_10})
    @DisplayName("Adjustment with no execution rate i.e from GUI, will use current WSP_U mid")
    public void send_adjustment_with_no_execution_rate() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(2_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // posi change by second trade
                assertThat(positionsUpdates.getLast().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getLast().getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0));
                assertThat(positionsUpdates.getLast().getPosition1().getAvgRate(), is((0.9 + 0.8 * 2) / 3));
                assertThat(positionsUpdates.getLast().getPosition1().getPnl(), is(closeTo((((0.9 + 0.8 * 2) / 3) - 0.7500) * -3_000_000, 7)));
            }
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75005, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.adjustment(Currency.AUD, 2_000_000));
        }
        then:
        // adjustment is at current WSP_U mid
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0 + 2_000_000.0));
            assertThat(positionsUpdate.getPosition1().getAvgRate(), is((0.9 + (0.8 * 2) + (0.75005 * 2)) / 5));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_4_6_10})
    @DisplayName("Adjustment with no execution rate i.e from GUI, will use WSP_U mid if current Average Execution rate not available")
    public void send_adjustment_with_no_execution_rate_when_squared_position() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(-1_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            // posi change by second trade
            assertThat(positionsUpdates.getLast().getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdates.getLast().getPosition1().getPositionInNotional(), is(0.0));
            assertThat(positionsUpdates.getLast().getPosition1().getAvgRate(), is(NaN));
            assertThat(positionsUpdates.getLast().getPosition1().getPnl(), is(0.0));  // or NaN?
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75050, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.adjustment(Currency.AUD, 2_000_000));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            Position audPos = positionsUpdate.getPosition1();

            assertThat(audPos.getCcy(), is(Currency.AUD));
            assertThat(audPos.getPositionInNotional(), is(2_000_000.));
            assertThat(audPos.getAvgRate(), is(0.75050));
            // When not reset. Jira to be created
//            assertThat(audPos.getAvgRate(), is(((1_000_000 * 0.9) + (-1_000_000 * 0.8) + (2_000_000 * 0.75050)) / audPos.getPositionInNotional()));
            assertThat(audPos.getPnl(), is(IsCloseTo.closeTo((audPos.getAvgRate() - 0.75050) * -audPos.getPositionInNotional(), 7)));
        }
    }
}
