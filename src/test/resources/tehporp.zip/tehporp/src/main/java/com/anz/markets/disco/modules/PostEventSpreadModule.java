package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.config.DiscoPostEventSpreadConfig;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.pricer.PrecisionConfiguration;
import com.anz.markets.prophet.status.Context;

/**
 * This module publishes post event spread signals in pips.
 */
public class PostEventSpreadModule extends AbstractModule {

    public static class PESConfig {
        public long widenTauNanos;
        public long tightenTauNanos;
        public long maxTimeNanos;
        public long minTimeNanos;
        public double turnOffSpread;
    }

    private static class PESState {
        final EnumObjMap<TradingTimeZone, PESConfig> config = new EnumObjMap<>(TradingTimeZone.class);
        double spreadChangeEpsilon;

        double pes;
        double lastPesPublished;
        long lastUpdated;

        public boolean spreadChanged(double p1, double p2) {
            return (Double.isNaN(p1) ^ Double.isNaN(p2)) || Math.abs(p1 - p2) >= spreadChangeEpsilon;
        }

    }

    private final EnumObjTable<Market, Instrument, PESState> stateMap = new EnumObjTable<>(Market.class, Instrument.class);

    private PrecisionConfiguration precisionConfiguration;

    @Override
    public void sub(final MessageBus messageBus) {
        messageBus.sub(this::consumeConfig, IndexedConfigurationData.class);
        getStage().getProcessingModule(DiscoveryModule.class).addDerivedSignal(this::populate);
    }

    private void populate(final DiscoveryModule.DiscoState discoState) {
        final PESState state = stateMap.get(discoState.signals.getMarket(), discoState.signals.getInstrument());

        if (state == null) {
            // Has never been configured.
            return;
        }

        final long t = Context.context().timeSource().nowNanos();
        final double McSpreadersonInPips = precisionConfiguration.rateToPips(discoState.signals.getInstrument(), Math.abs(discoState.clusterAsk - discoState.clusterBid));

        if (state.pes > 0) {
            if (McSpreadersonInPips == state.pes) {
                ; // no change.
            } else {
                final PESConfig pesConfig = state.config.get(Context.context().tradingTimeZone());
                if (pesConfig != null) {
                    final long timeDelta = t - state.lastUpdated;
                    final double lambda;
                    if (McSpreadersonInPips > state.pes) {
                        // Widened
                        lambda = Math.exp(-1 * timeDelta / pesConfig.widenTauNanos);
                    } else {
                        // Tightened
                        lambda = Math.exp(-1 * timeDelta / pesConfig.tightenTauNanos);
                    }
                    state.pes = McSpreadersonInPips * (1 - lambda) + state.pes * lambda;
                } else {
                    state.pes = Double.NaN;
                }
            }
        } else {
            state.pes = McSpreadersonInPips;
        }

        state.lastUpdated = t;

        if (state.spreadChanged(state.lastPesPublished, state.pes)) {
            state.lastPesPublished = state.pes;
            discoState.signals.add(SignalType.PES, state.pes, Symbol.EMPTY);
        }
    }

    private void consumeConfig(final IndexedConfigurationData config) {
        clearConfigState();
        try {
            buildConfig(config);
        } catch (Exception e) {
            clearConfigState();   // clear config on error to prevent incomplete config operating.
            throw e;
        }
    }

    private void clearConfigState() {
        // Remove individual config but retain (market,instrument) state.
        stateMap.forEach((market, instrument, state) -> state.config.clear());
    }

    private void buildConfig(final IndexedConfigurationData config) {
        this.precisionConfiguration = config.getPrecisionConfiguration();

        final DiscoPostEventSpreadConfig discoPostEventSpreadConfig = new DiscoPostEventSpreadConfig(config.getPriceFormationPipelineConfigs());
        discoPostEventSpreadConfig.getConfig().forEach((market, tradingTimeZone, m) -> m.forEach((instrument, pesConfig) -> {
            final PESState state = stateMap.computeIfAbsent(market, instrument, () -> new PESState());
            state.config.put(tradingTimeZone, pesConfig);
        }));

        stateMap.forEach((market, instrument, pesState) -> {
            final double priceChangeEpsilon = config.getPrecisionConfiguration().getInstrumentRateEpsilon(instrument) / 10.0;
            final double spreadChangeEpsilon = config.getPrecisionConfiguration().rateToPips(instrument, priceChangeEpsilon);
            pesState.spreadChangeEpsilon = spreadChangeEpsilon;
        });
    }

}
