package com.anz.axle.lg.adapter.ebsu;

import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

import org.junit.Before;
import org.junit.Test;

import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.ebs.instrument.InstrumentDictionary;
import software.chronicle.ebs.instrument.VanillaInstrumentDictionary;
import software.chronicle.ebs.itch.generated.incremental.messages.server.PriceLevelUpdate;
import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;
import software.chronicle.itch.staticcode.IncrementalServerSessionHandler;

import com.anz.axle.lg.adapter.acceptance.shared.ControllableClock;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementMessageNotifier;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementalMessageHandler;
import com.anz.axle.lg.adapter.ebsu.trade.TradeMessageHandler;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoIncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class IncrementMessageNotifierNDFTest {

    private static final String SENDER_COMP_ID = "sender";
    private static final String COMP_ID = "compId";

    private final Venue VENUE = Venue.EBSU;
    private final Queue<PricingMessage> queue = new LinkedBlockingDeque<>(5);
    private final PricingEncoderSupplier encoderSupplier = new PojoPricingEncoderSupplier(m -> queue.add(m));
    private IncrementMessageNotifier messageNotifier;
    private IncrementalServerSessionHandler session;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    @Before
    public void setUp() {
        Map<String, String> ebsuSymbolLookup = new HashMap<>();
        SecurityInfoHolder pricingEncoderLookup = new SecurityInfoHolder(requestKey -> encoderSupplier, VENUE, SecurityType.FXNDF, ebsuSymbolLookup);
        PrecisionClock precisionClock = new ControllableClock();

        boolean encodeHops = false;
        final IncrementalMessageHandler handler = new IncrementalMessageHandler(pricingEncoderLookup, System::currentTimeMillis, precisionClock, SENDER_COMP_ID, COMP_ID, VENUE, encodeHops, 0, sourceSequencer);
        final TradeMessageHandler tradeHander = new TradeMessageHandler(pricingEncoderLookup, System::currentTimeMillis, precisionClock, SENDER_COMP_ID, COMP_ID, VENUE, encodeHops, 0, sourceSequencer);
        messageNotifier = new IncrementMessageNotifier(handler, tradeHander, precisionClock);

        InstrumentDictionary securityDictionary = new VanillaInstrumentDictionary();
        addSecurityDefinition(securityDictionary);

        session = new IncrementMessageNotifierTest.DummySession(securityDictionary);
    }

    private void addSecurityDefinition(InstrumentDictionary securityDictionary) {
        InstrumentDirectory securityDefinition = Marshallable.fromString(
        "!software.chronicle.ebs.itch.generated.preview.messages.datamodel.server.DefaultInstrumentDirectory {\n" +
                "  instrumentGroup: 4,\n" +
                "  locateCode: 31,\n" +
                "  instrumentId: 1900602,\n" +
                "  description: \"FXNDF.USDTWD.M1(EBSM_CLOB)              \",\n" +
                "  marketSegment: 1,\n" +
                "  securityId: 1900602,\n" +
                "  assetClass: 1,\n" +
                "  securityType: 2,\n" +
                "  baseAsset: USD,\n" +
                "  termAsset: TWD,\n" +
                "  tenorType: 5,\n" +
                "  tenorValue: 1,\n" +
                "  farTenorType: 0,\n" +
                "  farTenorValue: 0,\n" +
                "  reserved2: !!binary AAA=,\n" +
                "  pricePrecision: 3,\n" +
                "  priceIncrement: 5000000000,\n" +
                "  reserved3: !!binary AAA=,\n" +
                "  amountPrecision: 0,\n" +
                "  amountIncrement: 1000000000000,\n" +
                "  minOrderAmount: 1000000000000,\n" +
                "  maxOrderAmount: 50000000000000,\n" +
                "  maxPriceLevels: 5\n" +
                "}");
        securityDictionary.addOrReplace(securityDefinition);
    }

    @Test
    public void handleNewOrder() {
        //given
        final PriceLevelUpdate newOrder = Marshallable.fromString(
                "!software.chronicle.ebs.itch.generated.incremental.messages.datamodel.server.DefaultPriceLevelUpdate {\n" +
                        "  instrumentGroup: 4,\n" +
                        "  locateCode: 31,\n" +
                        "  sequenceNumber: 866532,\n" +
                        "  eventNumber: 109625707789038548,\n" +
                        "  timestamp: 1561618332881376437,\n" +
                        "  instrumentId: 1900602,\n" +
                        "  marketRegion: 0,\n" +
                        "  marketSide: S,\n" +
                        "  priceLevel: 30945000000000,\n" +
                        "  levelAmount: 1000000000000,\n" +
                        "  partyCount: 1,\n" +
                        "  updateFlags: 3\n" +
                        "}");

        //when
        messageNotifier.onPriceLevelUpdate(session, newOrder);

        //then
        assertThat(queue.size(), is(1));
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        InstrumentKey usdtwd = InstrumentKey.of("USDTWD", SecurityType.FXNDF, Tenor.M1);
        assertThat(body.instrumentId, is(usdtwd.instrumentId()));
        assertThat(body.marketId, is(VENUE));
        assertThat(body.sendingTime, is(newOrder.timestamp()));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.CHANGE));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.OFFER));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryPx, is(30.945));
        assertThat(pojoEncoder.message().entries.get(0).mdEntrySize, is(1000000.0));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(30945_2));
    }
}