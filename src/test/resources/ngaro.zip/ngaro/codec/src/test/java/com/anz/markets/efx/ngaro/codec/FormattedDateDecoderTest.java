package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.ImmutableAsciiString;
import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDateEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link FormattedDateDecoder}
 */
public class FormattedDateDecoderTest {

    @Test
    public void decodeLocalDateOrNull() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("20170314"), LocalDateFormat.YYYYMMDD);

        //when
        final LocalDate output = dec.decodeLocalDateOrNull();

        //then
        assertEquals("output not as expected", LocalDate.of(2017, 03, 14), output);
    }

    @Test
    public void decodeNull() {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new FixedLengthAsciiString(8), LocalDateFormat.YYYYMMDD);
        final StringBuilder formattedNull = new StringBuilder("abcdefg");

        //when + then
        assertEquals("localDate should be null", null, dec.decodeLocalDateOrNull());
        assertEquals("year should be 0", 0, dec.decodeYear());
        assertEquals("month should be 0", 0, dec.decodeMonth());
        assertEquals("day should be 0", 0, dec.decodeDay());
        assertEquals("epochDays should be 0", 0, dec.decodeEpochDays());
        assertEquals("epochSeconds should be 0", 0, dec.decodeEpochSeconds());
        assertEquals("epochMillis should be 0", 0, dec.decodeEpochMillis());
        assertEquals("binary packed value should be 0", 0, dec.decodePacked(LocalDatePacking.BINARY));
        assertEquals("decimal packed value should be 0", 0, dec.decodePacked(LocalDatePacking.DECIMAL));
        assertEquals("formatted value should be null", null, dec.decodeToFormattedStringOrNull(LocalDateFormat.YYYYMMDD));
        assertEquals("formatted value should be null", null, dec.decodeToFormattedStringOrNull(LocalDateEncoder.valueOf(LocalDateFormat.MM_DD_YYYY, '/')));
        assertEquals("result should be false indicating null", false,
                dec.decodeToFormatted(formattedNull, ByteWriter.STRING_BUILDER, 3, LocalDateFormat.YYYYMMDD.getDefaultEncoder()));
        assertEquals("formatted value should reflect null", "abc\0\0\0\0\0\0\0\0", formattedNull.toString());
    }

    @Test
    public void decodePacked() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("14032017"), LocalDateFormat.DDMMYYYY);

        //when
        final int packedBinary = dec.decodePacked(LocalDatePacking.BINARY);
        final int packedDecimal = dec.decodePacked(LocalDatePacking.DECIMAL);

        //then
        assertEquals("packed binary value not as expected", LocalDatePacking.BINARY.pack(2017, 03, 14), packedBinary);
        assertEquals("packed decimal value not as expected", 20170314, packedDecimal);
    }

    @Test
    public void decodeFormatted() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("14032017"), LocalDateFormat.DDMMYYYY);
        final StringBuilder formatted = new StringBuilder("abcdefg");

        //when
        final String formattedMMDDYYYY = dec.decodeToFormattedStringOrNull(LocalDateFormat.MMDDYYYY);
        final String formattedYYYY_MM_DD = dec.decodeToFormattedStringOrNull(LocalDateEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, '/'));
        dec.decodeToFormatted(formatted, ByteWriter.STRING_BUILDER, 3, LocalDateFormat.DDMMYYYY.getDefaultEncoder());

        //then
        assertEquals("formatted value not as expected", "03142017", formattedMMDDYYYY);
        assertEquals("formatted value not as expected", "2017/03/14", formattedYYYY_MM_DD);
        assertEquals("formatted value not as expected", "abc14032017", formatted.toString());
    }

    @Test
    public void decodeEpochMillis() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("14032017"), LocalDateFormat.DDMMYYYY);

        //when
        final long epochMillis = dec.decodeEpochMillis();

        //then
        assertEquals("epochMillis not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.MILLIS_PER_DAY, epochMillis);
    }

    @Test
    public void decodeEpochSeconds() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("20170314"), LocalDateFormat.YYYYMMDD);

        //when
        final long epochSeconds = dec.decodeEpochSeconds();

        //then
        assertEquals("epochSeconds not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.SECONDS_PER_DAY, epochSeconds);
    }

    @Test
    public void decodeEpochDays() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("20170314"), LocalDateFormat.YYYYMMDD);

        //when
        final long epochDays = dec.decodeEpochDays();

        //then
        assertEquals("epochDays not as expected", LocalDate.of(2017, 03, 14).toEpochDay(), epochDays);
    }

    @Test
    public void decodeYear() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("20170314"), LocalDateFormat.YYYYMMDD);

        //when
        final int year = dec.decodeYear();

        //then
        assertEquals("year not as expected", 2017, year);
    }

    @Test
    public void decodeMonth() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("20170314"), LocalDateFormat.YYYYMMDD);

        //when
        final int month = dec.decodeMonth();

        //then
        assertEquals("month not as expected", 03, month);
    }

    @Test
    public void decodeDay() throws Exception {
        final FormattedDateDecoder<AsciiString> dec = FormattedDateDecoder.forAsciiString(
                new ImmutableAsciiString("20170314"), LocalDateFormat.YYYYMMDD);

        //when
        final int day = dec.decodeDay();

        //then
        assertEquals("day not as expected", 14, day);
    }

}