package com.anz.axle.lg.adapter.ebs;

import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import com.anz.markets.efx.ngaro.api.Tenor;

public class TenorLookup {

    private final Map<String, Tenor> ebsToANZMap;
    private final Map<Tenor, String> anzToEBSMap;

    public TenorLookup(final Map<String, Tenor> ebsToANZMap) {
        this.ebsToANZMap = Objects.requireNonNull(ebsToANZMap);
        this.anzToEBSMap = ebsToANZMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));
    }

    public Tenor anzTenor(final String ebsTenor) {
        return ebsTenor == null ? null : ebsToANZMap.get(ebsTenor);
    }

    public String ebsTenor(final Tenor anzTenor) {
        return anzTenor == null ? null : anzToEBSMap.get(anzTenor);
    }
}
