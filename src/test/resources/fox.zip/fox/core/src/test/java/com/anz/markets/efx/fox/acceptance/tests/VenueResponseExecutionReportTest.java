package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;

@RunWith(Spockito.class)
public class VenueResponseExecutionReportTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueResponseExecutionReportTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }


    @Test
    @Spockito.Unroll({
            "| senderCompId | messageId | clOrdId | quoteId | symbol | currency |  orderType |  timeInForce |  side   |  securityType | marketId | price     | orderQty  |",
            "|==============|===========|=========|=========|========|==========|============|==============|=========|===============|==========|===========|===========|",
            "| GB:lg-fast   |    9876   | 3456    | 4564    | AUDUSD |  AUD     |   LIMIT    |   IOC        |  BUY    |   FXSPOT      | FAST     | 1.2320    | 1e6       |",
            "|--------------|-----------|---------|---------|--------|----------|------------|--------------|---------|---------------|----------|-----------|-----------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void receiver_should_forward_execution_report_to_command_queue_and_then_to_event_queue(
            final String senderCompId, final long messageId, final String clOrdId, final String quoteId,
            final String symbol, final String currency, final OrderType orderType, final TimeInForce timeInForce,
            final Side side, final SecurityType securityType, final String marketId, final double price, final double orderQty
    ) {

        final VenueEndpoint venueEndpoint = acceptanceContext.venueEndpointLookup()
                .lookup(Venue.valueOf(marketId));

        final ExecutionReport executionReport = venueEndpoint.createExecutionReport();
        executionReport.body.transactTime = acceptanceContext.precisionClock().nanos();
        executionReport.body.timeInForce = timeInForce;
        executionReport.body.marketId = marketId;
        executionReport.body.orderQty = orderQty;
        executionReport.body.orderId = clOrdId;
        executionReport.body.clOrdId = clOrdId;
        executionReport.body.origClOrdId = clOrdId;
        executionReport.body.clOrdLinkId = clOrdId;
        executionReport.body.execId = "4567";
        executionReport.body.quoteId = quoteId;
        executionReport.body.currency = currency;
        executionReport.body.ordType = orderType;
        executionReport.body.price = price;
        executionReport.body.securityType = securityType;
        executionReport.body.senderCompId = senderCompId;
        executionReport.body.settlCurrency = currency;
        executionReport.body.side = side;
        executionReport.body.symbol = symbol;

        venueEndpoint.tradingResponse().add(executionReport);

        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(senderCompId))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.quoteId().eq(quoteId))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(orderQty))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.securityType().eq(securityType))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.marketId().eq(marketId))
                .body().matches(ExecutionReportMatcher.symbol().eq(symbol));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

    }
}
