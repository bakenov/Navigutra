package com.anz.markets.efx.ngaro.sbe;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.function.Supplier;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link Lazy}.
 */
@RunWith(MockitoJUnitRunner.class)
public class LazyTest {

    @Mock
    private Supplier<String> stringSupplier;
    @Mock
    private Supplier<FixedStringSource> fixedStringSourceSupplier;
    @Mock
    private Supplier<FixedStringTarget> fixedStringTargetSupplier;
    @Mock
    private Supplier<VariableStringSource> variableStringSourceSupplier;
    @Mock
    private Supplier<VariableStringTarget> variableStringTargetSupplier;

    @Test
    public void cachingSupplier() throws Exception {
        //given
        final String value1 = "First String";
        when(stringSupplier.get()).thenReturn(value1, "Second String", null);
        final Supplier<String> cachingSupplier = Lazy.cachingSupplier(stringSupplier);

        //when
        final String actual1 = cachingSupplier.get();
        final String actual2 = cachingSupplier.get();

        //then
        assertSame("actual1 not as expected", value1, actual1);
        assertSame("actual2 not as expected", value1, actual2);
        verify(stringSupplier, times(1)).get();
        verifyNoMoreInteractions(stringSupplier);
    }

    @Test
    public void fixedStringSource() throws Exception {
        //given
        final int index1 = 0;
        final int index2 = 1;
        final byte byte1 = (byte)'A';
        final byte byte2 = (byte)'B';
        final FixedStringSource fixedStringSource = Mockito.mock(FixedStringSource.class);
        when(fixedStringSourceSupplier.get()).thenReturn(fixedStringSource, null);
        when(fixedStringSource.getByte(index1)).thenReturn(byte1);
        when(fixedStringSource.getByte(index2)).thenReturn(byte2);
        final FixedStringSource lazy = FixedStringSource.lazy(fixedStringSourceSupplier);

        //when
        final byte actual1 = lazy.getByte(index1);
        final byte actual2 = lazy.getByte(index2);

        //then
        assertSame("actual1 not as expected", byte1, actual1);
        assertSame("actual2 not as expected", byte2, actual2);
        verify(fixedStringSourceSupplier, times(1)).get();
        verify(fixedStringSource, times(1)).getByte(index1);
        verify(fixedStringSource, times(1)).getByte(index2);
        verifyNoMoreInteractions(fixedStringSourceSupplier, fixedStringSource);
    }

    @Test
    public void fixedStringTarget() throws Exception {
        //given
        final int index1 = 0;
        final int index2 = 1;
        final byte byte1 = (byte)'A';
        final byte byte2 = (byte)'B';
        final FixedStringTarget fixedStringTarget = Mockito.mock(FixedStringTarget.class);
        when(fixedStringTargetSupplier.get()).thenReturn(fixedStringTarget, null);
        final FixedStringTarget lazy = FixedStringTarget.lazy(fixedStringTargetSupplier);

        //when
        lazy.putByte(index1, byte1);
        lazy.putByte(index2, byte2);

        //then
        verify(fixedStringTargetSupplier, times(1)).get();
        verify(fixedStringTarget, times(1)).putByte(index1, byte1);
        verify(fixedStringTarget, times(1)).putByte(index2, byte2);
        verifyNoMoreInteractions(fixedStringTargetSupplier, fixedStringTarget);
    }

    @Test
    public void variableStringSource() throws Exception {
        //given
        final MutableDirectBuffer target1 = Mockito.mock(MutableDirectBuffer.class);
        final MutableDirectBuffer target2 = Mockito.mock(MutableDirectBuffer.class);
        final int targetOffset1 = 0;
        final int targetOffset2 = 1;
        final int length1 = 22;
        final int length2 = 33;
        final VariableStringSource variableStringSource = Mockito.mock(VariableStringSource.class);
        when(variableStringSource.getBytes(target1, targetOffset1, length1)).thenReturn(length1);
        when(variableStringSource.getBytes(target2, targetOffset2, length2)).thenReturn(length2);
        when(variableStringSourceSupplier.get()).thenReturn(variableStringSource, null);
        final VariableStringSource lazy = VariableStringSource.lazy(variableStringSourceSupplier);

        //when
        final int readLength1 = lazy.getBytes(target1, targetOffset1, length1);
        final int readLength2 = lazy.getBytes(target2, targetOffset2, length2);

        //then
        assertSame("readLength1 not as expected", length1, readLength1);
        assertSame("readLength2 not as expected", length2, readLength2);
        verify(variableStringSourceSupplier, times(1)).get();
        verify(variableStringSource, times(1)).getBytes(target1, targetOffset1, length1);
        verify(variableStringSource, times(1)).getBytes(target2, targetOffset2, length2);
        verifyNoMoreInteractions(variableStringSourceSupplier, variableStringSource);
    }

    @Test
    public void variableStringTarget() throws Exception {
        //given
        final DirectBuffer source1 = Mockito.mock(DirectBuffer.class);
        final DirectBuffer source2 = Mockito.mock(DirectBuffer.class);
        final int sourceOffset1 = 0;
        final int sourceOffset2 = 1;
        final int length1 = 22;
        final int length2 = 33;
        final VariableStringTarget variableStringTarget = Mockito.mock(VariableStringTarget.class);
        when(variableStringTarget.putBytes(any(DirectBuffer.class), anyInt(), anyInt())).thenReturn(variableStringTarget);
        when(variableStringTargetSupplier.get()).thenReturn(variableStringTarget, null);
        final VariableStringTarget lazy = VariableStringTarget.lazy(variableStringTargetSupplier);

        //when
        final Object self1 = lazy.putBytes(source1, sourceOffset1, length1);
        final Object self2 = lazy.putBytes(source2, sourceOffset2, length2);

        //then
        assertSame("self1 not as expected", variableStringTarget, self1);
        assertSame("self2 not as expected", variableStringTarget, self2);
        verify(variableStringTargetSupplier, times(1)).get();
        verify(variableStringTarget, times(1)).putBytes(source1, sourceOffset1, length1);
        verify(variableStringTarget, times(1)).putBytes(source2, sourceOffset2, length2);
        verifyNoMoreInteractions(variableStringTargetSupplier, variableStringTarget);
    }

    @Test(expected = InvocationTargetException.class)
    public void noInstances() throws Exception {
        //when
        final Constructor<Lazy> constructor = Lazy.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        constructor.newInstance();

        //then: expect exception
    }
}