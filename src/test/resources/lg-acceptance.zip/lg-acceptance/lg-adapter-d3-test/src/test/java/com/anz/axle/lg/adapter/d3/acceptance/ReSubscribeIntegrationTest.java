package com.anz.axle.lg.adapter.d3.acceptance;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.SubscriptionRequestType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.MarketDataRequest;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class ReSubscribeIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SubscribeUnsubscribeIntegrationTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;

    final private String senderCompId = "GB:lg-d3";
    final private Venue marketId = Venue.D3;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());

        System.setProperty("retry.task.millis", "200");
        System.setProperty("expire.task.millis", "200");
        System.setProperty("retry.subscription.seconds", "1");
        System.setProperty("appName", "lg-d3");

        application = new Application("lg-d3", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.throwableQueue().clear();
        acceptanceContext.updateMessageQueue().clear();
        acceptanceContext.pricingRequestMessageQueue().clear();
        acceptanceContext.errorMessageQueue().clear();
        acceptanceContext.subscriptionRequestQueue().clear();
        acceptanceContext.pricingMessageQueue().clear();
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void clear_logged_off_flag_on_resubscribe() throws Exception {
        //given
        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 2000;

        final MarketDataRequest marketDataRequest = new MarketDataRequest();
        marketDataRequest.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest.body.mdReqId = 1;
        marketDataRequest.body.marketId = marketId;
        marketDataRequest.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest.body.expireTime = exprireTime;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest);

        final SubscriptionRequest subscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Subscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(subscribeRequest, notNullValue());
        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        final UpdateMessage updateMessage = UpdateMessageBuilder.defaultMessage()
                .withSubscriptionId(subscribeRequest.subscriptionId())
                .withCurrencies(symbol.substring(0, 3), symbol.substring(3))
                .withTenor("")
                .withSettlementDate(settlmentDate)
                .build();

        acceptanceContext.updateMessageQueue().add(updateMessage);

        PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.mdFlags().eq(EnumSet.noneOf(Flag.class)))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                        .entries().countAtLeast(1)
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        LOGGER.info("======= {} ======", message);
        acceptanceContext.pricingMessageQueue().clear();

        final SubscriptionRequest unsubscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Unsubscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.UNSUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.subscriptionId().eq(subscribeRequest.subscriptionId())))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        PricingMessage emptySnapshot = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.mdFlags().eq(EnumSet.of(Flag.LOGGED_OFF)))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                        .entries().countEquals(0)
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        acceptanceContext.pricingMessageQueue().clear();
        acceptanceContext.pricingRequestMessageQueue().clear();

        // now re-subscribe
        final long exprireTime1 = System.currentTimeMillis() + 2000;

        final MarketDataRequest marketDataRequest1 = new MarketDataRequest();
        marketDataRequest1.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest1.body.mdReqId = 2;
        marketDataRequest1.body.marketId = marketId;
        marketDataRequest1.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest1.body.expireTime = exprireTime1;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest1);

        final SubscriptionRequest subscribeRequest1 = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Subscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(subscribeRequest1, notNullValue());
        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        final UpdateMessage updateMessage1 = UpdateMessageBuilder.defaultMessage()
                .withSubscriptionId(subscribeRequest1.subscriptionId())
                .withCurrencies(symbol.substring(0, 3), symbol.substring(3))
                .withTenor("")
                .withSettlementDate(settlmentDate)
                .build();

        acceptanceContext.updateMessageQueue().add(updateMessage1);

        PricingMessage message1 = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.mdFlags().eq(EnumSet.noneOf(Flag.class)))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                        .entries().countAtLeast(0)
                        .hops().hasAny()
                        .hops().countAtLeast(1)
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }
}