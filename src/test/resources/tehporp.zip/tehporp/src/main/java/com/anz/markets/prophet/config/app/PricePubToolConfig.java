package com.anz.markets.prophet.config.app;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.resilience.ResilientConnection;
import com.anz.markets.efx.messaging.transport.um.*;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.marketdata.ClientPriceReader;
import com.anz.markets.prophet.starfish.ClientPricePublisher;
import com.anz.markets.prophet.starfish.ClientPricePublisherTimeShaped;
import com.anz.markets.prophet.starfish.PublicationRegistry;
import com.anz.markets.prophet.util.TimeShaper;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;

@Configuration
@PropertySources({
        @PropertySource(value = "classpath:conf/starfish.out.properties"),
        @PropertySource(value = "classpath:conf/pricepub.out.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class PricePubToolConfig implements InitializingBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(PricePubToolConfig.class);

    @Autowired
    Environment env;

    @Override
    public void afterPropertiesSet() {
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public ProphetReader chronicleReader(@Value("${chronicle.starout.in.path:./chronicle.out}") final String path,
                                         final ThreadFactory threadFactory,
                                         final ChronicleObjectReader clientPriceReader) throws IOException {
        EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CLIENT_PRICE, clientPriceReader);

        final ChronicleObjectReader multiReader = new ChronicleObjectReaderMulti(map, true);
        return ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory), multiReader, path, StartAt.START, RingBuffer.NO_RING, ChronicleHook.START_READ);
    }

    @Bean
    public ClientPriceReader clientPriceReader(final ClientPricePublisher clientPricePublisher) throws IOException {
        return new ClientPriceReader(Arrays.asList(
                clientPricePublisher
        ));
    }

    @Bean
    public ThreadFactory threadFactory() {
        return new ThreadFactoryBuilder().setNameFormat("pricepub-out-%d").build();
    }

    @Bean
    public ClientPricePublisher clientPricePublisher(final Connection connection,
                                                     final PublicationRegistry cppPublicationRegistry,
                                                     @Value("${um.subscribeAtStartup:true}") final boolean subscribeAtStartup,
                                                     @Value("${clientpricepublisher.timeshaper:MAX100MS}") final TimeShaper timeShaper) {
        return new ClientPricePublisherTimeShaped(connection, cppPublicationRegistry, subscribeAtStartup, timeShaper);
    }

    @Bean(destroyMethod = "close")
    public Connection connection(final UmConfig umConfig,
                                 @Value("${um.secondsToRetryEndpoint:10}") final long secondsToRetryEndpoint) {
        final PrecisionClock precisionClock = NanoClock.nanoClockUTC();
        final Transport transport = new UmTransport(precisionClock, umConfig);
        final ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        return new ResilientConnection(transport, executorService, secondsToRetryEndpoint, () -> {});
    }

    @Bean
    public UmConfig umConfig(@Value("${um.transport}") final TransportValue transport,
                             @Value("${um.operational_mode}") final OperationalModeValue operationalMode,
                             @Value("#{${um.default.context.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultContextAttributes,
                             @Value("#{${um.default.source.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultSourceAttributes,
                             @Value("#{${um.default.receiver.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultReceiverAttributes,
                             @Value("#{'${um.unicast_resolvers}'.split(',')}") final Set<String> unicastResolvers) {
        final UmConfig config = new UmConfig() {

            @Override
            public UmEndPointConfig getEndPointConfig() {
                return UmEndPointConfig.forSingleTransport(transport);
            }

            @Override
            public OperationalModeValue getOperationalMode() {
                return operationalMode;
            }

            @Override
            public long getProcessEventsMillis() {
                return 0;
            }

            @Override
            public Map<String, ?> getDefaultContextAttributes() {
                return defaultContextAttributes;
            }

            @Override
            public Map<String, ?> getDefaultSourceAttributes() {
                return defaultSourceAttributes;
            }

            @Override
            public Map<String, ?> getDefaultReceiverAttributes() {
                return defaultReceiverAttributes;
            }

            @Override
            public Set<String> getResolverUnicastDaemons() {
                return unicastResolvers;
            }
        };
        config.logInfo(LOGGER);
        return config;
    }

    @Bean
    public PublicationRegistry cppPublicationRegistry(
            @Value("#{'${clientpricepublisher.models}'.split(',')}") final Set<Market> markets,
            @Value("#{'${clientpricepublisher.symbols}'.split(',')}") final Set<Instrument> instruments,
            @Value("#{'${clientpricepublisher.exclude.symbols:}'.split(',')}") final Set<Instrument> excludeInstruments,
            @Value("${clientpricepublisher.exclude.ndf:true}") final boolean excludeNDF,
            @Value("${clientpricepublisher.suffix:}") final String publisherSuffix
            ) {
        PublicationRegistry registry = new PublicationRegistry(publisherSuffix);
        registry.addAll(markets, instruments, excludeInstruments, excludeNDF);
        return registry;
    }
}
