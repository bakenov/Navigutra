package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.DocumentContext;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.WireIn;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * @author Rob Austin.
 */
public class FixLogConsumer implements Consumer<FixLog>, Marshallable {

    private transient final BlockingQueue<FixLog> q = new ArrayBlockingQueue<>(1024);

    private transient final SingleChronicleQueue log  = SingleChronicleQueueBuilder.binary("log").build();



    @Override
    public void accept(FixLog fixLog) {
        //System.out.println(" received=" + FixLogRenderer.toString(fixLog));
        Bytes msg = fixLog.msg();
        Bytes<ByteBuffer> copy = Bytes.elasticByteBuffer((int) msg.readRemaining());
        copy.write(msg);
        fixLog.msg(copy);
        q.add(fixLog.deepCopy());
        try (@NotNull DocumentContext documentContext = log.acquireAppender().writingDocument()) {
            try {
                documentContext.wire().getValueOut().marshallable(fixLog);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }

    }

    public FixLog poll(long timeout, TimeUnit timeUnit) throws InterruptedException {
        return q.poll(timeout, timeUnit);
    }
}
