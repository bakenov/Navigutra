package com.anz.markets.prophet.config.business.markets;


import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.TradingTimeZone;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.io.IOException;

@Ignore
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class StandardMarketSpreadConfigBWTest {

    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();

    private final ConfigurationDataDefault configurationData = StandardMarketSpreadTest.getStandardMarketsImplWithStandardSpread();
    //    private final ConfigurationData configurationData = StandardMarketSpreadTest.getStandardMarketsImplWithStandardSpreadMultiplerX2();

    private final TradingTimeZone TZ_LONDON = TradingTimeZone.LDN;
    private final TradingTimeZone TZ_LONDON_NEWYORK = TradingTimeZone.LDNNYK;
    private final TradingTimeZone TZ_NEWYORK = TradingTimeZone.NYK;

    public StandardMarketSpreadConfigBWTest() throws IOException {
    }

    public void getSpreadForAUDUSD_with_DifferentTimeZones() {
        for (int i = 0; i < REPS; i++) {
            for (int j = 0; j < configurationData.getStandardMarketSpreadConfigs().size(); j++) {
                configurationData.getStandardMarketSpreadConfigs().get(i);
            }
        }
    }

    @Test
    public void testAAA_AllocationNotExceeded_WarmUp() {
        getSpreadForAUDUSD_with_DifferentTimeZones();
    }

    @Test
    public void testAllocationNotExceeded() {
        helper.testAllocationNotExceeded(
                this::getSpreadForAUDUSD_with_DifferentTimeZones,
                0 // no allocation!
        );
    }
}