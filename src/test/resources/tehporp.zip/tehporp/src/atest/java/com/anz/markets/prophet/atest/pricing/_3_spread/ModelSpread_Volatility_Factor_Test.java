package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolatilityWideningConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.VolatilityType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.wholesale.spreads.ManualSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.VolatilitySpreadStrategy;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.matcher.LamdaMatcher.f;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class ModelSpread_Volatility_Factor_Test extends BaseAcceptanceSpecification {

    final Instrument driverPairA = Instrument.AUDUSD;

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                // Config for WSP_A ONLY
                .setClientSpreadConfigs(Lists.newArrayList(
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.SNG, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.SNG, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.SNG, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.SNG, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.7),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.1),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.9)
                ))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET, new Instrument[] { Instrument.ANY }))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, true));

        return configuration;
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_4_3, Ref.PRICING_4_5_2})
    @DisplayName("No model spread widening when volatility below lowest threshold")
    @RestartBeforeTest(reason = "Widening keeps state")
    public void no_model_spread_widening_when_volatility_below_lowest_threshold() throws Exception {
        given:
        {
            // AUTO volatility
            prophet.receive(tdd.setManualGlobalVol(0d));

            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.15),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.18),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 0.20),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 0.27)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }

        then:
        /** since volatility=0.141 is less than the lowest threshold of 0.15, no volatility widening factor is applied
         ** Thus benchmark model spread is equal to the model spread
         **/
        {
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(2)).getLast();
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(3), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(realisedVolatility.factorWindow(), is(FactorWindow.CAT_A));
            assertThat(realisedVolatility.volatility(), f(vol -> (vol < 0.15)));
            assertThat(realisedVolatility.instrument(), is(Instrument.AUDUSD));
            assertThat(wbf.getBaseSpread(), new IsRoundedTo(0.3));
            assertThat(wbf.getVolatility(), is(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorManual(), is(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorBid(), is(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorOffer(), is(Double.NaN));
            assertThat(wbf.getModelSpread(), new IsRoundedTo(0.3));
            assertThat(wbf.getOverallWideningFactor(), is(1.0));
            assertThat(wbf.getBenchmarkSpread(), new IsRoundedTo(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), new IsRoundedTo(0.0));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            //  client spread must be >= base spread
            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509950, 0.7510250));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7509800, 0.7510400));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7509725, 0.7510475));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7509600, 0.7510600));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7508800, 0.7511400));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7508200, 0.7512000));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7507300, 0.7512900));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7506900, 0.7513300));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7505600, 0.7514600));
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_4_3, Ref.PRICING_4_5_2})
    @DisplayName("Model spread widening is applied using correct widening factor")
    @RestartBeforeTest(reason = "Widening keeps state")
    public void model_spread_widening_applied_using_correct_widening_factor() throws Exception {
        given:
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000, 1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.05),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.10),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 0.14),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 0.27)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }

        then:
        /** since volatility=0.141 is >=0.14 threshold and <0.27 threshold, apply 3.0 volatility widening factor **/
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(3), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            //            assertThat(wbf.getVolatility(), new IsRoundedTo(0.141));
            assertThat(wbf.getVolatility() >= 0.14 && wbf.getVolatility() < 0.27, is(true));
            assertThat(wbf.getVolatilityWideningFactorManual(), is(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorBid(), is(3.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), is(3.0));
            assertThat(wbf.getModelSpread(), new IsRoundedTo(0.9));
            assertThat(wbf.getOverallWideningFactor(), is(3.0));
            assertThat(wbf.getBenchmarkSpread(), new IsRoundedTo(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), new IsRoundedTo(0.0));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(VolatilitySpreadStrategy.FEATURE_NAME);
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.BID_SPREAD_IN_PIPS));
            assertThat(ftl.operations[0].oldVal, Matchers.is(0.15));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.45));
            assertThat(ftl.operations[1].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftl.operations[1].var, Matchers.is(PliableBookVariable.OFFER_SPREAD_IN_PIPS));
            assertThat(ftl.operations[1].oldVal, Matchers.is(0.15));
            assertThat(ftl.operations[1].newVal, isRoundedTo(0.45));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(3), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            //  TOB client spread must be >= base spread
            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509650, 0.7510550));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7509200, 0.7511000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7508975, 0.7511225));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7508600, 0.7511600));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7508000, 0.7512200));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7507400, 0.7512800));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7506500, 0.7513700));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7506100, 0.7514100));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7504800, 0.7515400));
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_4_3, Ref.PRICING_4_5_2})
    @DisplayName("Model spread widening is applied using highest widening factor")
    @RestartBeforeTest(reason = "Widening keeps state")
    public void model_spread_widening_applied_using_highest_widening_factor() throws Exception {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000, 1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.05),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.08),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 0.10),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 0.14)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }

        then:
        /** since volatility=0.141 is >=0.14, apply 4.0 volatility widening factor **/
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(3), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            assertThat(wbf.getModelSpread(), isNear(1.2));
            //            assertThat(wbf.getVolatility(), new IsRoundedTo(0.141));
            assertThat(wbf.getVolatility() >= 0.14, is(true));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(4.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(4.0));
            assertThat(wbf.getOverallWideningFactor(), isNear(4.0));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));


            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(3), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.750950, 0.751070));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.750890, 0.751130));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.750860, 0.751160));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.750810, 0.751210));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.750760, 0.751260));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.750700, 0.751320));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.750610, 0.751410));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.750570, 0.751450));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.750440, 0.751580));
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_4_3, Ref.PRICING_4_5_2})
    @DisplayName("Model spread widening is applied using max of manual override and widening factor")
    @RestartBeforeTest(reason = "Widening keeps state")
    public void model_spread_widening_applied_using_max_manual_override_and_widening_factor() throws Exception {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000, 1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.05),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.08),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 0.14),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 0.18)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.setManualGlobalVol(4d));
        }

        then:
        /** volatility=0.141 is >=0.14 which translates to 3.0 volatility widening factor
         *  manual volatility factor = 4.0
         *  Therefore apply the maximum of the two factors i.e 4.0 **/
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            assertThat(wbf.getModelSpread(), isNear(1.2));
            assertThat(wbf.getVolatility() >= 0.14 && wbf.getVolatility() < 0.18, is(true));
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(4d));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(3d));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(3d));

            assertThat(wbf.getOverallWideningFactor(), isNear(4.0));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.750950, 0.751070));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.750890, 0.751130));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.750860, 0.751160));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.750810, 0.751210));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.750760, 0.751260));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.750700, 0.751320));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.750610, 0.751410));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.750570, 0.751450));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.750440, 0.751580));
        }

        and:
        // reset manual volatility to 0d
        {
            prophet.receive(tdd.setManualGlobalVol(Double.NaN));
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_4_3, Ref.PRICING_4_5_2})
    @DisplayName("Ensure correct widening config used based on Timezone changes")
    @RestartBeforeTest(reason = "Widening keeps state")
    public void use_correct_widening_config_on_tz_change() throws Exception {
        given:
        {
            // Set timezone as LDN
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000, 1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5)
                                    .set(TradingTimeZone.LDN, 0.05).set(TradingTimeZone.SNG, 0.05),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5)
                                    .set(TradingTimeZone.LDN, 0.10).set(TradingTimeZone.SNG, 0.08),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0)
                                    .set(TradingTimeZone.LDN, 0.14).set(TradingTimeZone.SNG, 0.10),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0)
                                    .set(TradingTimeZone.LDN, 0.27).set(TradingTimeZone.SNG, 0.14)
                    ));
            prophet.receive(config);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }
        then:
        /** since volatility=0.141 is >=0.14 threshold and <0.27 threshold, apply 3.0 volatility widening factor **/
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(3), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            //            assertThat(wbf.getVolatility(), new IsRoundedTo(0.141));
            assertThat(wbf.getVolatility() >= 0.14 && wbf.getVolatility() < 0.27, is(true));
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(3.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(3.0));
            assertThat(wbf.getModelSpread(), isNear(0.9));
            assertThat(wbf.getOverallWideningFactor(), isNear(3.0));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(3), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            //  TOB client spread must be >= base spread
            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509650, 0.7510550));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7509200, 0.7511000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7508975, 0.7511225));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7508600, 0.7511600));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7508000, 0.7512200));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7507400, 0.7512800));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7506500, 0.7513700));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7506100, 0.7514100));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7504800, 0.7515400));
        }
        when:
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));

            // Set timezone as SNG
            prophet.receive(TradingTimeZone.SNG);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75103, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }
        then:
        /** since volatility=0.155 is >=0.14, apply 4.0 volatility widening factor **/
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(3), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            assertThat(wbf.getModelSpread(), isNear(1.2));
            assertThat(wbf.getVolatility() >= 0.14, is(true));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(4.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(4.0));
            assertThat(wbf.getOverallWideningFactor(), isNear(4.0));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));


            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(3), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.750950, 0.751070));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.750890, 0.751130));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.750860, 0.751160));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.750810, 0.751210));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.750760, 0.751260));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.750700, 0.751320));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.750610, 0.751410));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.750570, 0.751450));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.750440, 0.751580));
        }
        when:
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);


            // Set timezone as LDN
            prophet.receive(TradingTimeZone.LDN);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }
        then:
        /** since volatility=0.155 is >=0.14 threshold and <0.27 threshold, apply 3.0 volatility widening factor **/
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            //            assertThat(wbf.getVolatility(), new IsRoundedTo(0.141));
            assertThat(wbf.getVolatility() >= 0.14 && wbf.getVolatility() < 0.27, is(true));
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(3.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(3.0));
            assertThat(wbf.getModelSpread(), isNear(0.9));
            assertThat(wbf.getOverallWideningFactor(), isNear(3.0));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            //  TOB client spread must be >= base spread
            assertThat((clientPrice.getTopOfBookOffer().getPrice() - clientPrice.getTopOfBookBid().getPrice()) / 0.00001 >= wbf.getBaseSpread(), is(true));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509650, 0.7510550));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7509200, 0.7511000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7508975, 0.7511225));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7508600, 0.7511600));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7508000, 0.7512200));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7507400, 0.7512800));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7506500, 0.7513700));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7506100, 0.7514100));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7504800, 0.7515400));
        }
    }

    @Test
    public void longVolGeneration() throws Exception {
        given:
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(
                    new RealisedVolatilityConfig(FactorWindow.CAT_B, 12, 6000, 60000, 1d, 0.7d, VolatilityType.LONG_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_B, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.05),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_B, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.10),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_B, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 0.14),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_B, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 0.27)
                    ));

            prophet.receive(config);
        }

        when:
        {
            // set up with vol, with returns over 6 minutes, at 6th min then should get vol
            for(int i=0; i<60; i++) {
                if(i%2==0) {
                    prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
                } else {
                    prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75120, 0.00001));
                }
                prophet.incrementTime(1000);
            }
            // now test vol changes, should trigger on every timescale period
            prophet.clearOutputBuffer();
            prophet.incrementTime(6000);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75103, 0.00001));

            prophet.incrementTime(6000);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75106, 0.00011));

            prophet.incrementTime(6000);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00004));
        }
        then:
        {
            RealisedVolatility realisedVol = prophet.expect(RealisedVolatility.class, exactly(3)).getLast();
            assertThat(realisedVol.volatility(), isRoundedTo(0.141));
            assertThat(realisedVol.bidVolatility() > 0.0, is(true));
            assertThat(realisedVol.offerVolatility() > 0.0, is(true));
        }
        when:
        // should trigger on every timescale period
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(6000);
        }
        then:
        {
            RealisedVolatility realisedVol = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(realisedVol.volatility(), isRoundedTo(0.146));
        }
        when:
        // should trigger on every timescale period.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(6000);
        }
        then:
        {
            RealisedVolatility realisedVol = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(realisedVol.volatility(), isRoundedTo(0.146));
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_4_3, Ref.PRICING_4_5_2})
    @DisplayName("AXPROPHET-919 allow config per pricing model")
    @RestartBeforeTest(reason = "Widening keeps state")
    public void test_config_per_market() throws Exception {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            // Also set only 2 vol levels to verify 4 level depth restriction removed
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.ANY, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.13),
                            new VolatilityWideningConfig(Instrument.ANY, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.18),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.13),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.18),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.WSP_A, 0, 1.5).set(TradingTimeZone.LDN, 0.15),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.WSP_A, 1, 2.5).set(TradingTimeZone.LDN, 0.18)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }

        then:
        /** since volatility=0.141 is less than the lowest threshold of 0.15(WSP_A), no volatility widening factor is applied
         ** Thus benchmark model spread is equal to the model spread
         **/
        {
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(2)).getLast();
            assertThat(realisedVolatility.factorWindow(), is(FactorWindow.CAT_A));
            assertThat(realisedVolatility.volatility(), f(vol -> (vol < 0.15)));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(3), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(realisedVolatility.instrument(), is(Instrument.AUDUSD));
            assertThat(wbf.getBaseSpread(), isNear(0.3));
            assertThat(wbf.getVolatility(), isNear(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorManual(), is(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorBid(), is(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorOffer(), is(Double.NaN));
            assertThat(wbf.getModelSpread(), isNear(0.3));
            assertThat(wbf.getOverallWideningFactor(), isNear(1.0));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));
        }
    }

    @Test
    public void maxOfManualVolatilities() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = setUpConfiguration();
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000, 1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 0.05),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 0.08),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 0.10),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 0.14)
                    ));

            prophet.receive(config);
        }
        when:
        // GLOBAL vol is max
        {
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, 1d));
            prophet.receive(tdd.setManualGlobalVol(4d));
            prophet.receive(tdd.setManualCcyVol(Currency.AUD, 2d));

            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
            prophet.incrementTime(2);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
            prophet.incrementTime(3);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(4.0));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(4.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(4.0));
        }
        when:
        // Manual USD vol is max for WSP_A market
        {
            prophet.receive(tdd.setManualMarketVol(Market.WSP_B, 6d));
            prophet.receive(tdd.setManualCcyVol(Currency.AUD, 3d));
            prophet.receive(tdd.setManualCcyVol(Currency.USD, 5d));
            prophet.receive(tdd.setManualGlobalVol(2d));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75105, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(5.0));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(4.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(4.0));
            assertThat(wbf.getOverallWideningFactor(), isNear(5.0));
        }
        when:
        // Market WSP_A vol is the max
        {
            prophet.receive(tdd.setManualCcyVol(Currency.AUD, 3d));
            prophet.receive(tdd.setManualCcyVol(Currency.USD, 2d));
            prophet.receive(tdd.setManualGlobalVol(2d));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_API_ANY, 7d));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, 6d));

            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(6.0));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(4.0));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(4.0));
            assertThat(wbf.getOverallWideningFactor(), isNear(6.0));
        }
        and:
        // reset manual volatility
        {
            prophet.receive(tdd.setManualGlobalVol(Double.NaN));
            prophet.receive(tdd.setManualCcyVol(Currency.AUD, Double.NaN));
            prophet.receive(tdd.setManualCcyVol(Currency.USD, Double.NaN));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, Double.NaN));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_B, Double.NaN));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_API_ANY, Double.NaN));
        }
    }

    @Test
    @RestartBeforeTest(reason = "Widening keeps state")
    // AXPROPHET-1198
    public void allowVolatilityWideningFactorBelowOne() {
        final ConfigurationDataDefault config = setUpConfiguration();
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            config.setRealisedVolatilityConfigs(Arrays.asList(new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000, 1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE,true, true)))
                    .setVolatilityWideningConfigs(Arrays.asList(
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 0, 1.5).set(TradingTimeZone.LDN, 5.5),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 1, 2.5).set(TradingTimeZone.LDN, 5.6),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 2, 3.0).set(TradingTimeZone.LDN, 5.7),
                            new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY, 3, 4.0).set(TradingTimeZone.LDN, 5.8)
                    ));

            prophet.receive(config);
        }
        when:
        // begin with Manual Vol Widening Factor 1.0
        {
            prophet.receive(tdd.setManualGlobalVol(1.0d));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75102, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(1.0d));
            assertThat(wbf.getOverallWideningFactor(), isNear(1.0d));
        }
        when:
        // send Manual Vol Widening Factor below default min of 1.0.
        {
            prophet.receive(tdd.setManualGlobalVol(0.7d));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00003));
        }
        then:
        {
            // manual vol of 0.7 is not applied
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorBid(), isNear(Double.NaN));
            assertThat(wbf.getVolatilityWideningFactorOffer(), isNear(Double.NaN));
            assertThat(wbf.getOverallWideningFactor(), isNear(1.0d));
        }
        when:
        // Send manual vol widening factor below default min(1.0)
        {
            prophet.receive(tdd.setManualGlobalVol(0.6d));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75105, 0.00003));
        }
        then:
        // manual vol of 0.6 is not applied
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(Double.NaN));
        }
        when:
        // set up key value config min manual vol widening factor 0.6
        {
            prophet.receive(config
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MANUAL_VOLATILITY_FACTOR_MINIMUM, 0.6d))
            );
            prophet.receive(tdd.setManualGlobalVol(0.6d));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75101, 0.00004));
        }
        then:
        // manual vol of 0.6 is not applied - can't go below 1.0
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getVolatilityWideningFactorManual(), isNear(0.6d));
            assertThat(wbf.getOverallWideningFactor(), isNear(1.0d));

            assertThat(wbf.getBaseSpread(), isNear(0.3));
            assertThat(wbf.getModelSpread(), isNear(0.3));
            assertThat(wbf.getBenchmarkSpread(), isNear(0.4));
            assertThat(wbf.getBenchmarkModelSpread(), isNear(0.0));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(ManualSpreadStrategy.SPECS.getFeatureName());
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));

            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getLast();
            assertThat(cp, isClientPricePoint(0, Level.QTY_1M, 0.750995, 0.751025));
        }
        and:
        // reset manual volatility
        {
            prophet.receive(tdd.setManualGlobalVol(Double.NaN));
        }
    }
}