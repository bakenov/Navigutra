package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Map;
import java.util.function.Function;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.decoder.FixNumericConstants;
import com.anz.axle.lg.adapter.apama.decoder.FixStringConstants;
import com.anz.axle.lg.adapter.apama.event.GeneralApamaEventFields;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;

public class EventFunctions {
    public static final Function<String, Tenor> SETTL_DATE_TO_TENOR  = new SettleDateToTenor();

    public static final Function<Event, String> ENTRY_TO_SETTL_TYPE = event -> {
        final Map<Long, String> extraParams = event.getField(GeneralApamaEventFields.FIELD_EXTRA_PARAMS);
        return extraParams.get(FixNumericConstants.TAG_SETTL_TYPE);
    };

    public static final Function<Event, String> MESSAGE_TO_SETTL_TYPE = event -> {
        final Map<String, String> payload = event.getField(GeneralApamaEventFields.FIELD_PAYLOAD);
        return payload.get(FixStringConstants.TAG_SETTL_TYPE);
    };

    public static final Function<Event, String> ENTRY_TO_SETTL_DATE = event -> {
        final Map<Long, String> extraParams = event.getField(GeneralApamaEventFields.FIELD_EXTRA_PARAMS);
        return extraParams.get(FixNumericConstants.TAG_SETTL_DATE);
    };

    public static final Function<Event, String> MESSAGE_TO_SETTL_DATE = event -> {
        final Map<String, String> payload = event.getField(GeneralApamaEventFields.FIELD_PAYLOAD);
        return payload.get(FixStringConstants.TAG_SETTL_DATE);
    };

    public static SecurityType securityType(final String cfiCode) {
        if (cfiCode == null) return SecurityType.FXSPOT;

        switch (cfiCode) {
            case "FFCNNO": return SecurityType.FXNDF;
            case "RCSXXX": return SecurityType.FXSPOT;
            default: return SecurityType.FXSPOT;
        }
    }

    public static final Function<Event, SecurityType> ENTRY_TO_SECURITY_TYPE = event -> {
        final Map<Long, String> extraParams = event.getField(GeneralApamaEventFields.FIELD_EXTRA_PARAMS);
        return securityType(extraParams.get(FixNumericConstants.TAG_CFI_CODE));
    };

    public static final Function<Event, SecurityType> MESSAGE_TO_SECURITY_TYPE = event -> {
        final Map<String, String> payload = event.getField(GeneralApamaEventFields.FIELD_PAYLOAD);
        return securityType(payload.get(FixStringConstants.TAG_CFI_CODE));
    };

    public static final Function<Event, String> EVENT_TO_SYMBOL = event -> event.getField(GeneralApamaEventFields.FIELD_SYMBOL);
}
