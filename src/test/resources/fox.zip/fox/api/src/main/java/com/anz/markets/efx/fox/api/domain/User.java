package com.anz.markets.efx.fox.api.domain;

import java.util.Objects;
import java.util.Set;

import com.anz.markets.efx.fox.codec.api.UserGroup;

public class User {
    private final String userName;
    private final Set<UserGroup> userGroups;
    private final String location;
    private final String desk;

    public User(final String userName,
                final Set<UserGroup> userGroups,
                final String location,
                final String desk) {
        this.userName = Objects.requireNonNull(userName);
        this.userGroups = Objects.requireNonNull(userGroups);
        this.location = Objects.requireNonNull(location);
        this.desk = Objects.requireNonNull(desk);
    }

    public String userName() {
        return userName;
    }

    public Set<UserGroup> userGroups() {
        return userGroups;
    }

    public String location() {
        return location;
    }

    public String desk() {
        return desk;
    }
}
