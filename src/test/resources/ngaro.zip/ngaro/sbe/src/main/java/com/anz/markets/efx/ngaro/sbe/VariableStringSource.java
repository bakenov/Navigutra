package com.anz.markets.efx.ngaro.sbe;

import java.util.function.Supplier;

import org.agrona.MutableDirectBuffer;

/**
 * Provides indexed read access to string bytes. Such methods are for instance found on SBE decoders for variable
 * length strings.
 */
@FunctionalInterface
public interface VariableStringSource {
    int getBytes(MutableDirectBuffer target, int targetOffset, int length);

    static VariableStringSource lazy(final Supplier<VariableStringSource> supplier) {
        return Lazy.variableStringSource(supplier);
    }
}
