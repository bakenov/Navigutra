package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;

public class Default_Client_Spread_Config_Test extends BaseAcceptanceSpecification {

    private Instrument driverA = Instrument.AUDUSD;
    private Instrument driverB = Instrument.USDJPY;

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1134})
    public void default_clientSpread_config() {

        // No explicit WSP_B config defined. Therefore use config defined for Market.ANY
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setClientSpreadConfigs(Lists.newArrayList(
                        new ClientSpreadConfigImpl(Market.WSP_A, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                        new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                        new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),

                        new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6)
                ))
                .setPricingModels(Arrays.asList(
                        new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m"),
                        new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m"),
                        new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m")
                ));
        given:
        {
            prophet.receive(configuration);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverA, 0.75000, 0.00003));
        }
        then:
        {
            ClientPrice clientPriceWspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverA, Market.WSP_A)).getFirst();
            ClientPrice clientPriceWspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverA, Market.WSP_B)).getFirst();
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverA, Market.WSP_C));

            assertThat(clientPriceWspA, isClientPricePoint(0, Level.QTY_1M, 0.7499850, 0.7500150));
            assertThat(clientPriceWspA, isClientPricePoint(1, Level.QTY_2M, 0.7499700, 0.7500300));
            assertThat(clientPriceWspA, isClientPricePoint(2, Level.QTY_2M, 0.7499625, 0.7500375));

            assertThat(clientPriceWspB, isClientPricePoint(0, Level.QTY_1M, 0.7499800, 0.7500200));
            assertThat(clientPriceWspB, isClientPricePoint(1, Level.QTY_2M, 0.7499575, 0.7500425));
            assertThat(clientPriceWspB, isClientPricePoint(2, Level.QTY_2M, 0.7499400, 0.7500600));
        }
        and:
        {
            prophet.notExpect(org.apache.logging.log4j.Level.ERROR, matches(".*"));
        }
        when:
        // Specify WSP_B spreads(same as WSP_A) so pricing will NOT use ANY spreads
        {
            prophet.receive(tdd.marketDataSnapshot(driverA, 0.75050, 0.00003));
            prophet.receive(configuration
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                            new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),

                            new ClientSpreadConfigImpl(Market.WSP_B, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6)
                    ))
            );
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverA, 0.75000, 0.00003));
        }
        then:
        // WSP_A and WSP_B are the same price
        {
            ClientPrice clientPriceWspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverA, Market.WSP_A)).getFirst();
            ClientPrice clientPriceWspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverA, Market.WSP_B)).getFirst();
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverA, Market.WSP_C));

            assertThat(clientPriceWspA, isClientPricePoint(0, Level.QTY_1M, 0.7499850, 0.7500150));
            assertThat(clientPriceWspA, isClientPricePoint(1, Level.QTY_2M, 0.7499700, 0.7500300));
            assertThat(clientPriceWspA, isClientPricePoint(2, Level.QTY_2M, 0.7499625, 0.7500375));

            assertThat(clientPriceWspB, isClientPricePoint(0, Level.QTY_1M, 0.7499850, 0.7500150));
            assertThat(clientPriceWspB, isClientPricePoint(1, Level.QTY_2M, 0.7499700, 0.7500300));
            assertThat(clientPriceWspB, isClientPricePoint(2, Level.QTY_2M, 0.7499625, 0.7500375));
        }
        when:
        // specify Diver A WSP_A -> ANY
        // specify DriverB spreads to verify triangulation works with Driver A ANY
        {
            prophet.receive(configuration
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.ANY, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_B, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),

                            new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_B, driverB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_C, driverB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6)
                    ))
            );
            prophet.receive(tdd.marketDataSnapshot(driverA, 0.75050, 0.00003));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverB, 85.555, 0.004));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDJPY, Market.WSP_A));
            prophet.notExpect(org.apache.logging.log4j.Level.ERROR, matches(".*"));
        }
    }
}
