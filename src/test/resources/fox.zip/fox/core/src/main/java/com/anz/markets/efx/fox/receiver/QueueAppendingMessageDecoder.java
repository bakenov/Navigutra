package com.anz.markets.efx.fox.receiver;

import java.util.Objects;

import org.tools4j.eventsourcing.api.ExecutionQueue;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.codec.sbe.SbeHeader;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class QueueAppendingMessageDecoder implements MessageDecoder<SbeMessage> {
    private final ExecutionQueue executionQueue;
    private final PrecisionClock precisionClock;
    private final SbeHeader header = new SbeHeader();

    public QueueAppendingMessageDecoder(final ExecutionQueue executionQueue,
                                        final PrecisionClock precisionClock) {
        this.executionQueue = Objects.requireNonNull(executionQueue);
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        header.wrap(message);
        executionQueue.appender().accept(
                header.source(),
                header.sourceSeq(),
                precisionClock.nanos(),
                message.buffer(), 0, message.messageLength());
        return true;
    }
}
