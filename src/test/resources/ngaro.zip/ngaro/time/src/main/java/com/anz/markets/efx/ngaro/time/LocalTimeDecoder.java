package com.anz.markets.efx.ngaro.time;

import java.time.LocalTime;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteReader;

/**
 * Decoder for local times with time formats as defined by {@link LocalTimeFormat}.
 * <br/>
 * All methods are zero garbage.
 * <p/>
 * This class is thread safe.
 *
 * @see LocalTimeDecoder
 */
public final class LocalTimeDecoder {

    public static final char NO_DELIMITER = Character.MAX_VALUE;
    public static final char NO_FRACTION_SYMBOL = Character.MAX_VALUE;

    private final LocalTimeFormat timeFormat;

    LocalTimeDecoder(final LocalTimeFormat timeFormat) {
        this.timeFormat = Objects.requireNonNull(timeFormat);
    }

    public static LocalTimeDecoder valueOf(final LocalTimeFormat format) {
        return format.getDefaultDecoder();
    }

    public LocalTimeFormat getTimeFormat() {
        return timeFormat;
    }

    public <S> long decodeEpochSeconds(final S source, final ByteReader<? super S> reader) {
        return decodeEpochSeconds(source, reader, 0);
    }

    public <S> long decodeEpochSeconds(final S source, final ByteReader<? super S> reader, final int offset) {
        final int hh = decodeHour(source, reader, offset);
        final int mm = decodeMinute(source, reader, offset);
        final int ss = decodeSecond(source, reader, offset);
        return ((hh * Epoch.MINUTES_PER_HOUR) + mm) * Epoch.SECONDS_PER_MINUTE + ss;
    }

    public <S> long decodeEpochMillis(final S source, final ByteReader<? super S> reader) {
        return decodeEpochMillis(source, reader, 0);
    }

    public <S> long decodeEpochMillis(final S source, final ByteReader<? super S> reader, final int offset) {
        final long epochSeconds = decodeEpochSeconds(source, reader, offset);
        final long milli = decodeMilli(source, reader, offset);
        return epochSeconds * Epoch.MILLIS_PER_SECOND + milli;
    }

    public <S> long decodeEpochNanos(final S source, final ByteReader<? super S> reader) {
        return decodeEpochNanos(source, reader, 0);
    }

    public <S> long decodeEpochNanos(final S source, final ByteReader<? super S> reader, final int offset) {
        final long epochSeconds = decodeEpochSeconds(source, reader, offset);
        final long nano = decodeNano(source, reader, offset);
        return epochSeconds * Epoch.NANOS_PER_SECOND + nano;
    }

    public <S> LocalTime decodeLocalTime(final S source, final ByteReader<? super S> reader) {
        return decodeLocalTime(source, reader, 0);
    }

    public <S> LocalTime decodeLocalTime(final S source, final ByteReader<? super S> reader, final int offset) {
        final int hh = decodeHour(source, reader, offset);
        final int mm = decodeMinute(source, reader, offset);
        final int ss = decodeSecond(source, reader, offset);
        final int nn = decodeNano(source, reader, offset);
        if (hh == 0 & mm == 0 & ss == 0 & nn == 0) {
            return null;
        }
        return nn == 0 ? LocalTime.of(hh, mm, ss) : LocalTime.of(hh, mm, ss, nn);
    }

    public <S> int decodeHour(final S source, final ByteReader<? super S> reader) {
        return decodeHour(source, reader, 0);
    }

    public <S> int decodeHour(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetHour = offset + timeFormat.getOffsetHour();
        final byte byte0 = reader.readByte(source, offsetHour + 0);
        final byte byte1 = reader.readByte(source, offsetHour + 1);
        if (byte0 == 0 & byte1 == 0) {
            return 0;
        }
        return 10 * digit(byte0) + digit(byte1);
    }

    public <S> int decodeMinute(final S source, final ByteReader<? super S> reader) {
        return decodeMinute(source, reader, 0);
    }

    public <S> int decodeMinute(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetMinute = offset + timeFormat.getOffsetMinute();
        final byte byte0 = reader.readByte(source, offsetMinute + 0);
        final byte byte1 = reader.readByte(source, offsetMinute + 1);
        if (byte0 == 0 & byte1 == 0) {
            return 0;
        }
        return 10 * digit(byte0) + digit(byte1);
    }

    public <S> int decodeSecond(final S source, final ByteReader<? super S> reader) {
        return decodeSecond(source, reader, 0);
    }

    public <S> int decodeSecond(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetSecond = timeFormat.getOffsetSecond();
        if (offsetSecond >= 0) {
            final byte byte0 = reader.readByte(source, offset + offsetSecond + 0);
            final byte byte1 = reader.readByte(source, offset + offsetSecond + 1);
            if (byte0 == 0 & byte1 == 0) {
                return 0;
            }
            return 10 * digit(byte0) + digit(byte1);
        }
        return 0;
    }

    public <S> int decodeMilli(final S source, final ByteReader<? super S> reader) {
        return decodeMilli(source, reader, 0);
    }

    public <S> int decodeMilli(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetFraction = timeFormat.getOffsetFraction();
        if (offsetFraction >= 0) {
            final byte byte0 = reader.readByte(source, offset + offsetFraction + 0);
            final byte byte1 = reader.readByte(source, offset + offsetFraction + 1);
            final byte byte2 = reader.readByte(source, offset + offsetFraction + 2);
            if (byte0 == 0 & byte1 == 0 & byte2 == 0) {
                return 0;
            }
            return 100 * digit(byte0) + 10 * digit(byte1) + digit(byte2);
        }
        return 0;
    }

    public <S> int decodeMicro(final S source, final ByteReader<? super S> reader) {
        return decodeMicro(source, reader, 0);
    }

    public <S> int decodeMicro(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetFraction = timeFormat.getOffsetFraction();
        if (offsetFraction >= 0) {
            final int fractionlength = timeFormat.getFractionLength();
            final byte byte0 = reader.readByte(source, offset + offsetFraction + 0);
            final byte byte1 = reader.readByte(source, offset + offsetFraction + 1);
            final byte byte2 = reader.readByte(source, offset + offsetFraction + 2);
            if (fractionlength <= 3) {
                if (byte0 == 0 & byte1 == 0 & byte2 == 0) {
                    return 0;
                }
                return 100_000 * digit(byte0) + 10_000 * digit(byte1) + 1_000 * digit(byte2);
            }
            final byte byte3 = reader.readByte(source, offset + offsetFraction + 3);
            final byte byte4 = reader.readByte(source, offset + offsetFraction + 4);
            final byte byte5 = reader.readByte(source, offset + offsetFraction + 5);
            if (byte0 == 0 & byte1 == 0 & byte2 == 0 & byte3 == 0 & byte4 == 0 & byte5 == 0) {
                return 0;
            }
            return 100_000 * digit(byte0) + 10_000 * digit(byte1) + 1_000 * digit(byte2)
                    + 100 * digit(byte3) + 10 * digit(byte4) + digit(byte5);
        }
        return 0;
    }

    public <S> int decodeNano(final S source, final ByteReader<? super S> reader) {
        return decodeNano(source, reader, 0);
    }

    public <S> int decodeNano(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetFraction = timeFormat.getOffsetFraction();
        if (offsetFraction >= 0) {
            final int fractionlength = timeFormat.getFractionLength();
            final byte byte0 = reader.readByte(source, offset + offsetFraction + 0);
            final byte byte1 = reader.readByte(source, offset + offsetFraction + 1);
            final byte byte2 = reader.readByte(source, offset + offsetFraction + 2);
            if (fractionlength <= 3) {
                if (byte0 == 0 & byte1 == 0 & byte2 == 0) {
                    return 0;
                }
                return 100_000_000 * digit(byte0) + 10_000_000 * digit(byte1) + 1_000_000 * digit(byte2);
            }
            final byte byte3 = reader.readByte(source, offset + offsetFraction + 3);
            final byte byte4 = reader.readByte(source, offset + offsetFraction + 4);
            final byte byte5 = reader.readByte(source, offset + offsetFraction + 5);
            if (fractionlength <= 6) {
                if (byte0 == 0 & byte1 == 0 & byte2 == 0 & byte3 == 0 & byte4 == 0 & byte5 == 0) {
                    return 0;
                }
                return 100_000_000 * digit(byte0) + 10_000_000 * digit(byte1) + 1_000_000 * digit(byte2)
                        + 100_000 * digit(byte3) + 10_000 * digit(byte4) + 1_000 * digit(byte5);
            }
            final byte byte6 = reader.readByte(source, offset + offsetFraction + 6);
            final byte byte7 = reader.readByte(source, offset + offsetFraction + 7);
            final byte byte8 = reader.readByte(source, offset + offsetFraction + 8);
            if (byte0 == 0 & byte1 == 0 & byte2 == 0 & byte3 == 0 & byte4 == 0 & byte5 == 0 & byte6 == 0 & byte7 == 0 & byte8 == 0) {
                return 0;
            }
            return 100_000_000 * digit(byte0) + 10_000_000 * digit(byte1) + 1_000_000 * digit(byte2)
                    + 100_000 * digit(byte3) + 10_000 * digit(byte4) + 1_000 * digit(byte5)
                    + 100 * digit(byte6) + 10 * digit(byte7) + digit(byte8);
        }
        return 0;
    }

    /**
     * Returns the first delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter1(final S source, final ByteReader<? super S> reader) {
        return decodeDelimiter1(source, reader, 0);
    }
    /**
     * Returns the first delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @param offset the read offset
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter1(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeDelimiterOrSymbol(0, source, reader, offset);
    }

    /**
     * Returns the second delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter2(final S source, final ByteReader<? super S> reader) {
        return decodeDelimiter2(source, reader, 0);
    }
    /**
     * Returns the second delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @param offset the read offset
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter2(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeDelimiterOrSymbol(1, source, reader, offset);
    }
    /**
     * Returns the fraction symbol, or {@link #NO_FRACTION_SYMBOL} if the format has no fraction symbol
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @return the fraction symbol or {@link #NO_FRACTION_SYMBOL} if the format has no fraction symbol
     */
    public <S> char decodeFractionSymbol(final S source, final ByteReader<? super S> reader) {
        return decodeFractionSymbol(source, reader, 0);
    }
    /**
     * Returns the fraction symbol, or {@link #NO_FRACTION_SYMBOL} if the format has no fraction symbol
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @param offset the read offset
     * @return the fraction symbol or {@link #NO_FRACTION_SYMBOL} if the format has no fraction symbol
     */
    public <S> char decodeFractionSymbol(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeDelimiterOrSymbol(2, source, reader, offset);
    }
    private <S> char decodeDelimiterOrSymbol(final int index, final S source, final ByteReader<? super S> reader, final int offset) {
        final int position;
        switch (index) {
            case 0:
                position = timeFormat.getPositionDelimiter1();
                break;
            case 1:
                position = timeFormat.getPositionDelimiter2();
                break;
            case 2:
                position = timeFormat.getPositionFractionSymbol();
                break;
            default:
                //should not happen
                throw new IllegalArgumentException("Invalid delimiter index: " + index);
        }
        if (position < 0) {
            return NO_DELIMITER;
        }
        return (char)reader.readByte(source, offset + position);
    }

    private static final int digit(final byte character) {
        return character - '0';
    }
}