package com.anz.markets.prophet.config.business.domain.tabular.general;

import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

/**
 * General bag of key value configuration.
 * See [KeyValueConfigType](#com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType) for possible keys that can be configure.
 */
public interface KeyValueConfig extends ProphetMarshallable {

    /**
     * Specify configuration key must exists in [KeyValueConfigType](#com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType).
     */
    String getKeyName();

    /**
     * Specify configuration value for given key.
     */
    String getValueName();

}
