package com.anz.axle.lg.adapter.anz.quickfix;

import quickfix.field.MsgType;
import quickfix.field.NoRelatedSym;
import quickfix.field.OrderQty;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteRequestType;
import quickfix.field.QuoteType;
import quickfix.field.Symbol;
import quickfix.field.TargetSubID;
import quickfix.fix44.QuoteRequest;

import com.anz.axle.lg.adapter.fix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

public class AnzMarketDataRequestEncoder implements MarketDataRequestEncoder<QuoteRequest> {
    private final QuoteRequest quoteRequest = new QuoteRequest();
    private final QuoteRequest.NoRelatedSym group = new QuoteRequest.NoRelatedSym();

    @Override
    public QuoteRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {

        quoteRequest.clear();
        quoteRequest.getHeader().setString(MsgType.FIELD, MsgType.QUOTE_REQUEST);
        quoteRequest.setString(QuoteReqID.FIELD, Long.toString(requestId));

        group.clear();
        group.setString(Symbol.FIELD, subscription.symbol());
        quoteRequest.addGroup(group);
        return quoteRequest;
    }

    @Override
    public QuoteRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        throw new UnsupportedOperationException("Unsubscribe: " + subscription);
    }
}
