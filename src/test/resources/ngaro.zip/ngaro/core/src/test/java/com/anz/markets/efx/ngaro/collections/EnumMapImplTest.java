package com.anz.markets.efx.ngaro.collections;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

public class EnumMapImplTest {

    private EnumObjMap<AnimalEnum, String> getInstrumentStringEnumMap() {
        EnumObjMap<AnimalEnum, String> map = new EnumObjMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        return map;
    }

    @Test
    public void testMap() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, "1-hello");
        assertThat(map.size(), is(1));
        assertThat(map.isEmpty(), is(false));
        assertThat(map.get(AnimalEnum.CAT), is("1-hello"));
        map.put(AnimalEnum.CAT, "2-hello");
        assertThat(map.size(), is(1));
        assertThat(map.isEmpty(), is(false));
        assertThat(map.get(AnimalEnum.CAT), is("2-hello"));
        map.put(AnimalEnum.HIPPO, "3-hello");
        assertThat(map.size(), is(2));
        assertThat(map.isEmpty(), is(false));
        assertThat(map.get(AnimalEnum.CAT), is("2-hello"));
        assertThat(map.get(AnimalEnum.HIPPO), is("3-hello"));
        map.clear();
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
    }

    @Test
    public void testRemoveIf() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, "1-hello");
        map.put(AnimalEnum.CAT, "2-hello");
        map.put(AnimalEnum.DOG, "3-hello");
        map.put(AnimalEnum.HIPPO, "4-hello");
        map.put(AnimalEnum.HIPPO, "5-hello");
        map.put(AnimalEnum.HIPPO, "6-hello");
        map.put(AnimalEnum.UNKNOWN, "2-hello");

        assertThat(map.get(AnimalEnum.CAT), is("2-hello"));
        assertThat(map.size(), is(4));

        map.removeIf((key, value) -> value.equals("2-hello"));

        assertThat(map.get(AnimalEnum.CAT), nullValue());
        assertThat(map.get(AnimalEnum.UNKNOWN), nullValue());
        assertThat(map.size(), is(2));

        map.removeIf((key, value) -> value.equals("1000d"));
        assertThat(map.remove(AnimalEnum.MOUSE), nullValue());
        assertThat(map.size(), is(2));
    }

    @Test
    public void testForEach() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, "1-hello");
        map.put(AnimalEnum.CAT, "2-hello");
        map.put(AnimalEnum.CAT, "3-hello");
        map.put(AnimalEnum.HIPPO, "4-hello");
        map.put(AnimalEnum.HIPPO, "5-hello");
        map.put(AnimalEnum.HIPPO, "6-hello");

        final AtomicInteger i = new AtomicInteger();
        map.forEach((k, v) -> {
            assertThat(map.get(k), is(v));
            i.incrementAndGet();
        });
        assertThat(i.get(), is(2));
    }

    @Test
    public void testkeys() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, "1-hello");
        map.put(AnimalEnum.CAT, "2-hello");
        map.put(AnimalEnum.HIPPO, "4-hello");
        map.put(AnimalEnum.DOG, "4-hello");
        map.put(AnimalEnum.MOUSE, "4-hello");
        map.put(AnimalEnum.HIPPO, "6-hello");

        final AtomicInteger i = new AtomicInteger(0);
        map.keys(k -> {
            if (i.get() == 0) {
                assertThat(k, is(AnimalEnum.CAT));
            }
            if (i.get() == 1) {
                assertThat(k, is(AnimalEnum.DOG));
            }
            if (i.get() == 2) {
                assertThat(k, is(AnimalEnum.HIPPO));
            }
            if (i.get() == 3) {
                assertThat(k, is(AnimalEnum.MOUSE));
            }
            i.incrementAndGet();
        });
        assertThat(i.get(), is(4));
    }


    @Test
    public void testForEachValue() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, "1-hello");
        map.put(AnimalEnum.CAT, "2-hello");
        map.put(AnimalEnum.CAT, "3-hello");
        map.put(AnimalEnum.HIPPO, "4-hello");
        map.put(AnimalEnum.HIPPO, "5-hello");
        map.put(AnimalEnum.HIPPO, "6-hello");

        Map<String, Boolean> values = new HashMap<>();
        values.put("3-hello", false);
        values.put("6-hello", false);

        map.forEach((k, v) -> {
            assertThat(values.containsKey(v), is(true));
            values.put(v, true);
        });
        assertThat(values.values().contains(false), is(false));
    }

    @Test
    public void testContains() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, "0-hello");
        map.put(AnimalEnum.CAT, "1-hello");
        map.put(AnimalEnum.DOG, "2-hello");
        map.put(AnimalEnum.MOUSE, "3-hello");
        map.put(AnimalEnum.HIPPO, "4-hello");
        map.put(AnimalEnum.PENGUIN, "5-hello");
        map.put(AnimalEnum.HIPPO, "6-hello");


        assertThat(map.containsKey(AnimalEnum.CAT), is(true));
        assertThat(map.containsKey(AnimalEnum.DOG), is(true));
        assertThat(map.containsKey(AnimalEnum.MOUSE), is(true));
        assertThat(map.containsKey(AnimalEnum.DOG), is(true));
        assertThat(map.containsKey(AnimalEnum.HIPPO), is(true));
        assertThat(map.containsValue("1-hello"), is(true));
        assertThat(map.containsValue("2-hello"), is(true));
        assertThat(map.containsValue("3-hello"), is(true));
        assertThat(map.containsValue("4-hello"), is(false));
        assertThat(map.containsValue("5-hello"), is(true));
        assertThat(map.containsValue("6-hello"), is(true));
        assertThat(map.size(), is(5));

        // remove 1
        map.remove(AnimalEnum.CAT);
        assertThat(map.containsKey(AnimalEnum.CAT), is(false));
        assertThat(map.containsKey(AnimalEnum.DOG), is(true));
        assertThat(map.containsKey(AnimalEnum.MOUSE), is(true));
        assertThat(map.containsKey(AnimalEnum.DOG), is(true));
        assertThat(map.containsKey(AnimalEnum.HIPPO), is(true));
        assertThat(map.containsValue("1-hello"), is(false));
        assertThat(map.containsValue("2-hello"), is(true));
        assertThat(map.containsValue("3-hello"), is(true));
        assertThat(map.containsValue("4-hello"), is(false));
        assertThat(map.containsValue("5-hello"), is(true));
        assertThat(map.containsValue("6-hello"), is(true));
        assertThat(map.size(), is(4));
    }

    @Test
    public void testComputeIf() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, AnimalEnum.CAT.name()); // to compute
        map.put(AnimalEnum.DOG, AnimalEnum.DOG.name());
        map.put(AnimalEnum.HIPPO, AnimalEnum.HIPPO.name()); // to compute
        map.put(AnimalEnum.MOUSE, AnimalEnum.MOUSE.name());
        map.put(AnimalEnum.PENGUIN, AnimalEnum.PENGUIN.name());

        List<String> result = new ArrayList<>();

        map.forEachIf(instrument -> instrument.isFlag(), (k, s) -> result.add(s));
        assertThat(result.size(), is(1));
        assertThat(result.get(0), is(AnimalEnum.PENGUIN.name()));
    }

    @Test
    public void testToString() {
        EnumObjMap<AnimalEnum, String> map = getInstrumentStringEnumMap();
        map.put(AnimalEnum.CAT, AnimalEnum.CAT.name()); // to compute
        map.put(AnimalEnum.DOG, AnimalEnum.DOG.name());
        assertThat(map.toString(), is("CAT=CAT,DOG=DOG"));
    }
}