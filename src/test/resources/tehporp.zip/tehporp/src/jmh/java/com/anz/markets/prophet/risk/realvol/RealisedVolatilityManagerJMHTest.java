package com.anz.markets.prophet.risk.realvol;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.impl.MidRateImpl;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;

public class RealisedVolatilityManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private NoOpConsumer<RealisedVolatility> consumerRealisedVolatility;
        private RealisedVolatilityManager realisedVolatilityManager;
        private MidRateImpl midRateAUDUSD, midRateUSDJPY;

        @Setup
        public void setup() throws IOException {
            consumerRealisedVolatility = new NoOpConsumer<>();
            realisedVolatilityManager = RealisedVolatilityManagerTest.createRealisedVolatilityManager(consumerRealisedVolatility.asList(), RealisedVolatilityCalculateTest.SAMPLES_DEFAULT, false);
            midRateAUDUSD = (MidRateImpl) MidRateTestHelper.createMidRate(Instrument.AUDUSD, 0.75000);
            midRateUSDJPY = (MidRateImpl) MidRateTestHelper.createMidRate(Instrument.USDJPY, 104);
        }
    }

    @Benchmark
    public long acceptChangedMidRate(@NotNull final Data data) throws Exception {
        mutateRate(data.midRateAUDUSD);
        data.realisedVolatilityManager.consumerOfMarketData().accept(data.midRateAUDUSD);
        mutateRate(data.midRateUSDJPY);
        data.realisedVolatilityManager.consumerOfMarketData().accept(data.midRateUSDJPY);
        return data.consumerRealisedVolatility.size();
    }

    private void mutateRate(final MidRateImpl midRate) {
        // change the rate a lot to force publish
        midRate.setRate(midRate.getMidRate() + (Math.random() - 0.5d));
    }
}
