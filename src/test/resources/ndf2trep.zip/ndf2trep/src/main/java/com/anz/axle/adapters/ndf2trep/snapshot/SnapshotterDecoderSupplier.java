package com.anz.axle.adapters.ndf2trep.snapshot;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.LongSupplier;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamDecoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface SnapshotterDecoderSupplier {
    UpstreamDecoderConnector upstreamDecoderConnector();
    Snapshotter snapshotter();


    static Function<RequestKey, SnapshotterDecoderSupplier> create(final PrecisionClock precisionClock,
                                                                   final LongSupplier messageIdSupplier,
                                                                   final Function<RequestKey, SnapshotterBuilder> snapshotterBuilderFactory,
                                                                   final UpdateTypeMismatchHandler updateTypeMismatchHandler,
                                                                   final String componentId) {
        return (RequestKey requestKey) -> {
            final SnapshotterBuilder builder = snapshotterBuilderFactory.apply(requestKey);

            final UpstreamDecoderConnector  upstreamDecoderConnector = builder.buildUpstreamDecoderConnector(updateTypeMismatchHandler);
            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock, messageIdSupplier, componentId, 0);

            return new SnapshotterDecoderSupplier() {
                @Override
                public UpstreamDecoderConnector upstreamDecoderConnector() {
                    return upstreamDecoderConnector;
                }
                @Override
                public Snapshotter snapshotter() {
                    return snapshotter;
                }
            };
        };
    }

    static Function<RequestKey, SnapshotterBuilder> createBuilder(final int initialBookEntries,
                                                                  final SnapshotFullRefreshHandler forwardTopOfBookSnapshotFullRefreshHandler,
                                                                  final PrecisionClock precisionClock,
                                                                  final long stalePriceTimestampOffsetMilliseconds) {
        Objects.requireNonNull(forwardTopOfBookSnapshotFullRefreshHandler);
        Objects.requireNonNull(precisionClock);

        return requestKey ->
             SnapshotterBuilder
                    .withMarketDataBook(requestKey, initialBookEntries)
                    .withDownstreamDecoder()
                    .forwardTopOfBookToDecoder(forwardTopOfBookSnapshotFullRefreshHandler)
                    .withTopOfBookFilter(marketDataEntry -> {
                        final long stalePriceThresholdTimeTimeNanos = precisionClock.nanos() - TimeUnit.MILLISECONDS.toNanos(stalePriceTimestampOffsetMilliseconds);
                        return marketDataEntry.transactTimeNanos() >= stalePriceThresholdTimeTimeNanos;
                    });
    }
}
