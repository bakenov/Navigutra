package com.anz.markets.efx.ngaro.codec;

import java.util.EnumSet;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link EnumSetEncoder}
 */
public class EnumSetEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    private enum MyEnum {
        BLUE, GREEN, ORANGE;
    }

    private EnumSet<MyEnum> backingSet;
    private EnumSetEncoder<Object, MyEnum> encoder;

    @Before
    public void init() {
        final MyEnum[] values = MyEnum.values();
        backingSet = EnumSet.noneOf(MyEnum.class);
        encoder = new EnumSetEncoder<>(ENCLOSING_ENCODER, () -> values.length, i -> values[i], backingSet);
    }

    @Test
    public void clear() throws Exception {
        //given
        backingSet.addAll(EnumSet.allOf(MyEnum.class));
        assertFalse("backing set should be non-empty", backingSet.isEmpty());

        //when
        encoder.clear();

        //then
        assertEquals("backing set should be empty now", 0, backingSet.size());
    }

    @Test
    public void add() throws Exception {
        //when
        encoder.add(MyEnum.ORANGE);
        encoder.add(MyEnum.GREEN);

        //then
        assertEquals("backing set should contain 2 elements", 2, backingSet.size());
        assertFalse("backing set should not contain BLUE", backingSet.contains(MyEnum.BLUE));
        assertTrue("backing set should contain ORANGE", backingSet.contains(MyEnum.ORANGE));
        assertTrue("backing set should contain GREEN", backingSet.contains(MyEnum.GREEN));
    }

    @Test
    public void addAll_Set() throws Exception {
        //given
        final EnumSet<MyEnum> toCopy = EnumSet.of(MyEnum.ORANGE, MyEnum.GREEN);

        //when
        encoder.addAll(toCopy);

        //then
        assertEquals("backing set should contain 2 elements", 2, backingSet.size());
        assertFalse("backing set should not contain BLUE", backingSet.contains(MyEnum.BLUE));
        assertTrue("backing set should contain ORANGE", backingSet.contains(MyEnum.ORANGE));
        assertTrue("backing set should contain GREEN", backingSet.contains(MyEnum.GREEN));
    }

    @Test
    public void addAll_BiPredicate() throws Exception {
        //given
        final EnumSet<MyEnum> toCopy = EnumSet.of(MyEnum.ORANGE, MyEnum.GREEN);

        //when
        encoder.addAll(toCopy, (src, flag) -> src.contains(flag));

        //then
        assertEquals("backing set should contain 2 elements", 2, backingSet.size());
        assertFalse("backing set should not contain BLUE", backingSet.contains(MyEnum.BLUE));
        assertTrue("backing set should contain ORANGE", backingSet.contains(MyEnum.ORANGE));
        assertTrue("backing set should contain GREEN", backingSet.contains(MyEnum.GREEN));
    }

    @Test
    public void addAll_Predicate() throws Exception {
        //given
        final EnumSet<MyEnum> toCopy = EnumSet.of(MyEnum.ORANGE, MyEnum.GREEN);

        //when
        encoder.addAll(flag -> toCopy.contains(flag));

        //then
        assertEquals("backing set should contain 2 elements", 2, backingSet.size());
        assertFalse("backing set should not contain BLUE", backingSet.contains(MyEnum.BLUE));
        assertTrue("backing set should contain ORANGE", backingSet.contains(MyEnum.ORANGE));
        assertTrue("backing set should contain GREEN", backingSet.contains(MyEnum.GREEN));
    }

    @Test
    public void addAllFrom() throws Exception {
        //given
        final MyEnum[] values = MyEnum.values();
        final EnumSet<MyEnum> toCopy = EnumSet.of(MyEnum.ORANGE, MyEnum.GREEN);
        final EnumSetDecoder<MyEnum> decoder = new EnumSetDecoder<>(() -> values.length, i -> values[i], toCopy);

        //when
        encoder.addAllFrom(decoder);

        //then
        assertEquals("backing set should contain 2 elements", 2, backingSet.size());
        assertFalse("backing set should not contain BLUE", backingSet.contains(MyEnum.BLUE));
        assertTrue("backing set should contain ORANGE", backingSet.contains(MyEnum.ORANGE));
        assertTrue("backing set should contain GREEN", backingSet.contains(MyEnum.GREEN));
    }
}