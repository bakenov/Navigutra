package com.anz.markets.efx.ngaro.sbe;

import java.io.IOException;
import java.util.Objects;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.LongCodec;

/**
 * Decoder for fixed length string.
 * <p/>
 * This class is NOT thread safe! More specifically {@link #decodeStringOrNull()} is not thread safe as it uses an internal
 * byte array for decoding. NOTE also that the {@link FixedStringSource} passed to the constructor may not be thread
 * safe and hence this decoder instance may also not be thread safe.
 */
public final class FixedStringDecoder implements StringDecoder {

    private static final byte NULL = 0;

    private final FixedStringSource source;
    private final byte[] buffer;

    public FixedStringDecoder(final FixedStringSource source, final int length) {
        Objects.requireNonNull(source);
        if (length < 0) {
            throw new IllegalArgumentException("Negative length: " + length);
        }
        this.source = source;
        this.buffer = new byte[length];
    }

    @Override
    public String decodeStringOrNull() {
        final int length = decodeToBuffer();
        return length == 0 ? null : new String(buffer, 0, length);
    }

    /**
     * Decode FixedStringSource to buffer
     * @return the actual length to the string
     */
    private int decodeToBuffer() {
        final int bufferLen = buffer.length;
        int index = 0;
        for (; index < bufferLen; index++) {
            final byte b = source.getByte(index);
            if (b == NULL) {
                break;
            }
            buffer[index] = b;
        }
        return index;
    }

    @Override
    public <T> T decodeAndCache(final ByteValueCache<T> cache) {
        final int length = decodeToBuffer();
        return length == 0 ? null : cache.lookupOrCache(buffer, ByteReader.BYTE_ARRAY, length);
    }

    @Override
    public <A extends Appendable> A decodeTo(final A target, final int maxTargetLength) {
        final int len = Math.min(maxTargetLength, buffer.length);
        for (int i = 0; i < len; i++) {
            final byte b = source.getByte(i);
            try {
                if (b == NULL) {
                    return target;
                }
                target.append((char)b);
            } catch (final IOException e) {
                throw new RuntimeException("append failed, e=" + e, e);
            }
        }
        return target;
    }

    @Override
    public <T> int decodeTo(final T target, final ByteWriter<? super T> writer, final int targetOffset, final int maxTargetLength) {
        final int len = Math.min(maxTargetLength, buffer.length);
        for (int i = 0; i < len; i++) {
            final byte b = source.getByte(i);
            if (b == NULL) {
                return i;
            }
            writer.writeByte(target, i + targetOffset, b);
        }
        return len;
    }

    @Override
    public int decodeToNull() {
        final int len = buffer.length;
        for (int i = 0; i < len; i++) {
            if (source.getByte(i) == NULL) {
                return i;
            }
        }
        return len;
    }

    @Override
    public long decodeLong(final long defaultValue) {
        final int length = decodeToBuffer();
        if (length == 0) {
            return defaultValue;
        }
        return LongCodec.decodeSigned(buffer, ByteReader.BYTE_ARRAY, length, 10);
    }
}