#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axle_pub_corr_metrics - Plugin to monitor the Axle Publishing Correlator Metrics 1 - Input queue

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=axle
 #%# capabilities=autoconf

=cut

. $MUNIN_LIBDIR/plugins/plugin.sh

. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Axle Publishing Correlator Metrics 1 - Input Queue'
    echo 'graph_args -l 0'
    echo 'graph_category axle'
    echo 'graph_scale no'
    echo 'pub_inputqueue.label input queue (Publisher)'
    echo 'pub_inputqueue.draw LINE2'
    exit 0
fi

PUB_CORRELATOR_PIDFILE=~/axle/fxagg-publisher/fxagg-core/logspublisher/Correlator-Publisher.pid
PUB_CORRELATOR_PORT=15904

# function parameters: PIDFILE PORT NAME
function getvalue {
	PIDFILE=$1
	PORT=$2
	NAME=$3
	# If there is no pidfile present OR there is a pidfile but no corresponding process then return undefined
	if [ ! -f ${PIDFILE} ] || [ ! -d /proc/`cat ${PIDFILE}` ]; then
		echo "${NAME}_inputqueue.value U"
	else
		# get new engine stats
		read uptime contexts monitors submonitors javaapps listeners sublisteners eventtypes inputqueue received routequeue routed consumers outputqueue created sent processed << DONE
		`${APAMA_HOME}/bin/engine_watch -r -o -p ${PORT} | sed 's/,/ /g'`
DONE
		echo "${NAME}_inputqueue.value $inputqueue"
	fi
}

# print the values for all the correlators
getvalue $PUB_CORRELATOR_PIDFILE $PUB_CORRELATOR_PORT pub
