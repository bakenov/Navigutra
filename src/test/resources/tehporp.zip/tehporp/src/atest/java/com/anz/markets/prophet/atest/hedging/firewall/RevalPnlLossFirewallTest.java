package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.Test;

import java.util.EnumSet;
import java.util.LinkedList;

import static com.anz.markets.prophet.atest.framework.Requirement.Ref.PROFIT_AND_LOSS_4_2_6;
import static com.anz.markets.prophet.atest.framework.Requirement.Ref.PROFIT_AND_LOSS_4_2_7;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Ref.HEDGING_FIREWALL_4_9_8, Ref.HEDGING_FIREWALL_4_9_9, Ref.HEDGING_FIREWALL_4_9_10, PROFIT_AND_LOSS_4_2_6, PROFIT_AND_LOSS_4_2_7})
public class RevalPnlLossFirewallTest extends ForEachHedgePortfolioBaseAcceptanceSpecification {

    // todo:
    // NaN pnl should update hedge firewall status as breached.

    @Test
    public void shouldNotEmitNotConfiguredWhenReceiveTradeButNoConfiguration() {
        when:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.94332, 0.00004, now()));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9));
        }
        then:
        // not expect hedge firewall status not configured straight away, until reval occurs.
        {
            final EnumSet<HedgeFirewallType> pnlFirewallTypes = EnumSet.of(
                    REVAL_PNL_LOSS_PER_MIN,
                    REVAL_PNL_LOSS_PER_HOUR,
                    REVAL_PNL_LOSS_PER_DAY,
                    REVAL_PNL_PROFIT_PER_DAY);

            for (final HedgeFirewallType hedgeFirewallType : pnlFirewallTypes) {
                prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(hedgeFirewallType, portfolio));
            }
        }
    }

    @Test
    public void shouldThrowExceptionWhenPnlLossConfigurationIsMoreThanZero() {
        setup:
        // prime the server first so that expects works.
        {
            prophet.receive(tdd.configuration_hedging_001());
        }

        final EnumSet<HedgeFirewallType> pnlLossFirewallTypes = EnumSet.of(
                REVAL_PNL_LOSS_PER_MIN,
                REVAL_PNL_LOSS_PER_HOUR,
                REVAL_PNL_LOSS_PER_DAY);

        for (final HedgeFirewallType pnlLossFirewallType : pnlLossFirewallTypes) {
            prophet.clearOutputBuffer();
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(pnlLossFirewallType, portfolio));

            when:
            // send in reval pnl loss config that is more than zero.
            {
                prophet.clearOutputBuffer();
                prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                        new HedgeFirewallConfigImpl(portfolio, GB, pnlLossFirewallType, 0.0001, true)
                )));
            }
            then:
            // exception should be thrown.
            {
                prophet.expect(IllegalArgumentException.class, matches(".*Loss pnl limit must be less than zero for.*"));
            }
        }
    }

    @Test
    public void shouldNotSendBreachedStatusUntilRevalTime1min() {
        final Instrument indirectPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -1099.99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9400));

            // AXPROPHET-927 Should have no impact on existing scenario
            prophet.receive(tdd.biasPosition(Currency.AUD, -3_000_000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9495)); // reval pnl = +500, cumulative pnl = 500, disp =  0
            prophet.incrementTime(1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9505)); // reval pnl = -500, cumulative pnl =   0, disp =  500
            prophet.incrementTime(1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9506)); // reval pnl = -600, cumulative pnl =-600, disp = -1100
        }
        then:
        {
            // not breached
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+10, rate change but still not breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(8 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9500));
        }
        then:
        {

            // not breached, not reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+32, realised with last rate and breached status is sent.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(22 * 1_000);
        }
        then:
        {
            final LinkedList<HedgeFirewallStatus> status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));

            // last trade will breached.
            assertThat(status.getLast(), isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -1100, -600, -600, 500, -1099.99));
        }
        when:
        // t+90, first reval slide out of window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(58 * 1_000);
        }
        then:
        // BUG AS THERE IS A BREACH AND NOTBREACHED TRIGGERING AT SAME TIME
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(2), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, NOT_BREACHED, -600, 0, -600, 0, -1099.99));
        }
    }

    @Test
    public void shouldNotSendBreachedStatusUntilRevalTime60min() {
        final Instrument indirectPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_HOUR, -1099.99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9400));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9495)); // trade pnl = +500, cumulative pnl = 500, disp =  0 when reval mid at .95 later
            prophet.incrementTime(1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9505)); // trade pnl = -500, cumulative pnl =   0, disp =  500
            prophet.incrementTime(1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9506)); // trade pnl = -600, cumulative pnl =-600, disp = -1100
        }
        then:
        {
            // not breached, not reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_HOUR, portfolio));
        }
        when:
        // t+10, rate change but still not breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(8 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9500));
        }
        then:
        {
            // not breached, not reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_HOUR, portfolio));
        }
        when:
        // t+32, realised with last rate and breached status is sent.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(22 * 1_000);
        }
        then:
        {
            final LinkedList<HedgeFirewallStatus> status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_HOUR, portfolio));

            // last trade will breached.
            assertThat(status.getLast(), isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_HOUR, portfolio, BREACHED, -1100.00, -600, -600, 500, -1099.99));
        }
        when:
        // t+30+3600, slide out of window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(3598 * 1_000);
        }
        then:
        // BUG AS THERE IS A BREACH AND NOTBREACHED TRIGGERING AT SAME TIME
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(2), isHedgeFirewallType(REVAL_PNL_LOSS_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_HOUR, portfolio, NOT_BREACHED, -600, 0, -600, 0, -1099.99));
        }
    }

    @Test
    public void multipleWindowsTriggered() {
        final Instrument indirectPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -1099.99, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_HOUR, -1000.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9400));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9495)); // trade pnl = +500, cumulative pnl = 500, disp =  0 when reval mid at .95 later
            prophet.incrementTime(1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9505)); // trade pnl = -500, cumulative pnl =   0, disp =  500
            prophet.incrementTime(1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9506)); // trade pnl = -600, cumulative pnl =-600, disp = -1100
        }
        then:
        {
            // not breached, not reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+10, rate change but still not breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(8 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9500));
        }
        then:
        {
            // not breached, not reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+32, realised with last rate and breached status is sent.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(22 * 1_000);
        }
        then:
        {
            final LinkedList<HedgeFirewallStatus> minuteFirewall = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
            final LinkedList<HedgeFirewallStatus> hourFirewall = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_HOUR, portfolio));

            // last trade will breached.
            assertThat(minuteFirewall.getLast(), isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -1100.00, -600, -600, 500, -1099.99));
            assertThat(hourFirewall.getLast(), isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_HOUR, portfolio, BREACHED, -1100.00, -600, -600, 500, -1000.00));
        }
    }

    @Test
    public void slidingWindowResultsInNewMax() {
        final Instrument ccyPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -129.00, true)
            )));

            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75010));
        }

        when:
        //t+0 receive hedge fill 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.7500));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        {   // t+20, receive hedge trade 2
            prophet.incrementTime(20 * 1_000);

            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, 1_000_000, 0.75000));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+30, trigger reval PnL for hedge trade 1
        {
            prophet.incrementTime(10 * 1_000);
        }
        then:
        // not_breached.
        {
            // AUD: -1mio AUD | -0.75010mio USD
            // USD: +0.75mio USD | +0.75mio USD
            // Reval PnL: -100
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+40, rate change not reval yet
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75015));
        }
        then:
        {   // no reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50, trigger reval for hedge fill 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            // AUD: +1mio AUD   | +0.75015mio USD
            // USD: -0.75mio USD| -0.75mio USD
            // Trade PnL = +150
            // Total PnL = -100 +150 = +50
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        {   // t+70, receive hedge trade 3
            prophet.incrementTime(20 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.75002));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+90, hedge trade 1 slides out
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // not breached
        {   // since window now only contains hedge trade 2, total PnL is now +150 (new HIGH)
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+100, reval hedge trade 3
        {
            prophet.incrementTime(10 * 1_000);
            // AUD: -1mio AUD       | -0.75015mio USD
            // USD: +0.75002mio USD | +0.75002mio USD
            // Trade PnL = -130
            // Total PnL = 150 -130 = +20 (LOW PnL)
        }
        then:
        {   // t+30 Total P/L = -100
            // t+50 Total P/L = +50
            // t+90 Total P/L = +150(HIGH)
            // t+100 Total P/L = +20 (LOW)
            // LOSS = 130  => Firewall triggered
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -130, 20, 20, 150, -129));
        }
    }

    @Test
    public void revalCalcZeroToLoss() {
        final Instrument indirectPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -499.99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.9510));
        }
        when:
        // t+0 receive hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.9510));
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+10 receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, indirectPair, 1_000_000, 0.95050));
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+30 reval hedge trade 1. Since TOB mkt price equals execution rate pnl = 0
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+35, rate change
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.95000));
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+40, reval hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
        }
        then:
        // t+30 Reval P/L = 0 (HIGH)
        // t+40 Reval P/L = (0.95000-0.95050) * 1mio = -500 (LOW)
        // LOSS = 500  => BREACHED
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -500.00, -500, -500, 0, -499.99));
        }
        when:
        // t+90, reval hedge trade 1 slide out of window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50 * 1_000);
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, NOT_BREACHED, NaN, 0, -500, -500, -499.99));
        }
    }

    @Test
    public void revalCalcProfitToLoss() {
        final Instrument ccyPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -149.99, true)
            )));

            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75010));
        }

        when:
        //t+0 receive hedge fill 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, 1_000_000, 0.75000));
            // AUD: 1mio AUD | 0.75mio USD
            // USD: -0.75mio USD | -0.75mio USD
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        {   // t+20, receive hedge fill 2
            prophet.incrementTime(20 * 1_000);

            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.75000));
            // AUD: -1mio AUD | -0.75mio USD
            // USD: 0.75mio USD | 0.75mio USD
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+30, trigger reval PnL for hedge trade 1
        {
            prophet.incrementTime(10 * 1_000);
        }
        then:
        // first event - from no status to not_breached.
        {
            // AUD: 1mio AUD | 0.75010mio USD
            // USD: -0.75mio USD | -0.75mio USD
            // Reval PnL: +100 (HIGH PnL)
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+40, rate change not reval yet
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75015));
        }
        then:
        {   // no reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50, trigger reval for hedge fill 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            // AUD: -1mio AUD | -0.75015mio USD
            // USD: 0.75mio USD | 0.75mio USD
            // Trade PnL = -150
            // Total PnL = 100 -150 = -50 (LOW PnL)
        }
        then:
        {   // t+30 Total P/L = +100(HIGH)
            // t+50 Total P/L = -50 (LOW)
            // LOSS = 150  => Firewall triggered
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -150, -50, -50, 100, -149.99));
        }
    }

    @Test
    public void revalCalcProfitToZero() {
        final Instrument ccyPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -99.99, true)
            )));

            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75000));
        }

        when:
        //t+0 receive hedge fill 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.75000));
        }
        and:
        // t+30 trigger reval.
        {
            prophet.incrementTime(30 * 1_000);
        }
        then:
        //mkt TOB equals fill rate. PnL is 0
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50 receive hedge trade 2 and mkt update
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75010));
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, 1_000_000, 0.75000));
            // AUD: +1mio AUD   | +0.75mio USD
            // USD: -0.75mio USD| -0.75mio USD
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+80 Reval hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(30 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
            // AUD: +1mio AUD   | +0.7501mio USD
            // USD: -0.75mio USD| -0.75mio USD
            // Reval PnL: +100 (HIGH PnL)
        }

        when:
        // t+90 hedge trade 1 slides out
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        {   // t+95, receive hedge trade 3
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, 1_000_000, 0.75010));
            // AUD: +1mio AUD       | +0.75mio USD
            // USD: -0.75mio USD    | -0.75mio USD
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+100, rate change not reval yet
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75000));
        }
        then:
        {   // no reval
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+125, trigger reval for hedge trade 3.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(25 * 1_000);
            // AUD: +1mio AUD   | +0.75010mio USD
            // USD: -0.75mio USD| -0.75mio USD
            // Reval PnL: -100
            // TOTAL PnL: 0  (LOW)
        }
        then:
        {   // t+80 Total P/L = +100(HIGH)
            // t+125 Total P/L = 0 (LOW)
            // LOSS = 100  => Firewall triggered
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -100, 0, 0, 100, -99.99));
        }
    }

    @Test
    public void revalCalcLossToLoss() {
        final Instrument ccyPair = Instrument.AUDUSD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -199.99, true)
            )));

            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75010));
        }

        when:
        //t+0 receive hedge fill 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.75010));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        //t+20 receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.75000));
            // AUD: -1mio AUD | -0.75mio USD
            // USD: 0.75mio USD | 0.75mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+30 trigger reval for hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
        }
        then:
        //mkt TOB equals fill rate. PnL is 0
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50, trigger reval for hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
            // AUD: -1mio AUD | -0.75010mio USD
            // USD: 0.75mio USD | 0.75mio USD
            // TOTAL PnL: -100
        }

        when:
        {   // t+65, receive hedge trade 3
            prophet.incrementTime(15 * 1_000);

            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, 1_000_000, 0.75020));
            // AUD: 1mio AUD | 0.75020mio USD
            // USD: -0.75020mio USD | -0.75020mio USD
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        //t+90 hedge trade 1 slides out.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(25 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 0.75000));
            // AUD: -1mio AUD | -0.75mio USD
            // USD: 0.75mio USD | 0.75mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+91, rate change.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 0.75000));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+95, trigger reval for hedge trade 3
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(4 * 1_000);
            // AUD: 1mio AUD        | +0.75000mio USD
            // USD: -0.75020mio USD | -0.75020mio USD
            // PnL = -200
            // Total PnL = -100 -200 = -300 (LOW PnL)
        }
        then:
        {   // t+50 Total P/L = -100(HIGH)
            // t+95 Total P/L = -300 (LOW)
            // LOSS = 200  => Firewall triggered
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -200, -300, -300, -100, -199.99));
        }
    }

    @Test
    public void revalCalcDirectPair() {
        final Instrument ccyPair = Instrument.USDCAD;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -461.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 1.30020));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 1.30020));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+20 receive hedge fill 2
        {
            prophet.incrementTime(20 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, ccyPair, -1_000_000, 1.30000));
            // USD: -1mio USD
            // CAD: 1.3mmio CAD | 1mio USD
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+30, trigger reval of hedge trade 1. PnL of 0 since mkt TOB same as fill rate(HIGH reval PnL)
        {
            prophet.incrementTime(10 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+40, rate change
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(ccyPair, 1.30060));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50, hedge trade 2 reval with last rate.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            // USD: -1mio USD | -1mio USD
            // CAD: +1.3mmio CAD | +0.99953867mio USD
            // PnL = -461.325  (LOW Reval PnL)
        }
        then:
        {   // t+30 Total P/L = 0(HIGH)
            // t+50 Total P/L = -461.325 (LOW)
            // LOSS = 461.325  => Firewall triggered
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -461.33, -461.33, -461.33, 0, -461.00));
        }
    }

    @Test
    public void revalCalcCrossPair() {
        final Instrument crosspair = Instrument.AUDJPY;
        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverpairB = Instrument.USDJPY;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -165.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.74500));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 113.780));
        }
        when:
        // t+0, receive hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, crosspair, 1_000_000, 84.700));
            // AUD: +1mio AUD     | +0.74500mio USD
            // JPY: -84.7mio JPY  | -84.7/113.78 mio USD
            // PnL = 580.95
        }
        then:
        {
            // not breached
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+20, receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, crosspair, -1_000_000, 84.720));
            // AUD: -1mio AUD   | -0.74500mio USD
            // JPY: 84.72mio JPY | 84.72/113.78 mio USD
            // PnL = -405.16786781508173668483037440675
        }
        then:
        {
            // not breached
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+30, trigger reval of hedge trade 1: PnL of 0 since TOB rates unchanged (HIGH reval PnL)
        {
            prophet.incrementTime(10 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+40 market rates updated
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.74510));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 113.790));
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50, trigger reval of hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            // AUD: -1mio AUD   | -0.74510mio USD
            // JPY: 84.72mio JPY | 84.72/113.79 mio USD
            // PnL = -570.60374373846559451621407856578
            // Change in PnL = -165.43587592338385783138370415903
        }
        then:
        // breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -165.44, -165.44, -165.44, 0, -165.00));
        }
    }

    // TODO: When triangulating USD/SEK, we should be using EUR/SEK fill rate and NOT the market mid
    @Test
    public void revalCalcCrossPairEUR() {
        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverpairB = Instrument.EURSEK;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -43.83, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.07185));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 9.78367));
        }

        firewallBreached();
    }

    // parameterised to allow test to be run twice with reset in between
    private void firewallBreached() {
        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverpairB = Instrument.EURSEK;
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.07185));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 9.78367));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, driverpairB, -1_000_000, 9.78300));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }

        when:
        // t+20, receive hedge trade 2
        {
            prophet.incrementTime(20 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, driverpairB, 1_000_000, 9.78400));
            // EUR: +1mio EUR       | +1.07185mio USD
            // SEK: -9.784mio SEK   | +9.784mio * (1.07185/9.78367) mio USD
            // PnL = -36.15
        }
        then:
        {
            // not breached
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }

        when:
        // t+30, trigger reval of hedge trade 1: PnL of 0(HIGH) since TOB rates unchanged (HIGH reval PnL)
        {
            prophet.incrementTime(10 * 1_000);
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }

        when:
        // t+40 market rates updated
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.07200));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 9.78327));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+50, trigger reval of hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            // EUR: +1mio EUR       | +1.072mio USD
            // SEK: -9.784mio SEK   | +9.784mio * (1.072/9.78327) mio USD
            // PnL = -79.98961492
            // Change in PnL = -43.83646381
        }
        then:
        // breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_LOSS_PER_MIN, portfolio, BREACHED, -43.84, -43.84, -43.84, 0, -43.83));
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, -43.83, true)
            )));
        }
        given:
        // first breached
        {
            firewallBreached();
        }
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, REVAL_PNL_LOSS_PER_MIN));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(REVAL_PNL_LOSS_PER_MIN, NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
        }
        and:
        // repeat first breached pattern - e.g., reset works
        {
            firewallBreached();
        }
    }

    @Test
    public void shouldResetWhenHedgerTurnedOn() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, -43.83, true),

                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false)
            )));
        }
        given:
        // first breached
        {
            firewallBreached();
        }
        when:
        // enable hedger which will reset firewall
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(portfolio));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
        }
        and:
        // repeat first breached pattern - e.g., reset works
        {
            firewallBreached();
        }
    }
}
