package com.anz.markets.prophet.atest.pricing._7_throttle;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Collections;

import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Ref.PRICING_4_8_2, Ref.PRICING_4_8_3})
@RestartBeforeTest(reason = "clear out config, upon config change possibility of empty clientPrice being sent via cross/inverse rate managers")
public class PriceThrottlerOverrideMidTest extends BaseAcceptanceSpecification {

    @Test
    @DisplayName("Client Mid positive change equals override min - price published")
    public void clientMidPositiveChangeEqualsMinPricePublished() {
        final double minimumPriceDeltaFractionOfMid = 0.00001;
        final int overrideFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 == min movement => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00001));
        }
    }

    @Test
    @DisplayName("Client Mid negative change equals override min - price published")
    public void clientMidNegativeChangeEqualsMinPricePublished() {
        final double minimumPriceDeltaFractionOfMid = 0.00001;
        final int overrideFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 0.99999, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 == min movement => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.99999));
        }
    }

    @Test
    @DisplayName("Client Mid change less than min - price not queued")
    public void clientMidChangeLessThanMinPriceNotQueued() {
        final double minimumPriceDeltaFractionOfMid = 0.00002;
        final int overrideFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01002, 0.00008));
        }

        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00002, last mid = 1.01000 => min movement = 0.00002 * 1.01000 = 0.0000202
            // Mid movement of 0.00002 < min movement => price not queued
            prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
        }

        then:
        // since previous price did not meet min movement, price was NOT queued.
        {
            prophet.notExpect(ClientPrice.class, isClientPriceMarket(Market.WSP_A));
        }
    }

    @Test
    @DisplayName("Price throttled and then pushed at start of new cycle")
    public void priceThrottledThenPushedAtStartNewPeriod() {
        final double minimumPriceDeltaFractionOfMid = 0.00001;
        final int overrideFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.10000, 0.00004));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            // significant price change
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.10005, 0.00005));
        }
        then:
        {
            prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            // another piece of market data kicks the time signal
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {
            // Since new time period push out queued price
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.AUDUSD)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.10005));
        }
    }

    @Test
    @DisplayName("Newest throttled price pushed at start of new cycle")
    public void newestThrottledPricePushedAtStartNewCycle() {
        final double minimumPriceDeltaFractionOfMid = 0.00001;
        final int overrideFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00000, 0.00004));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00002, 0.00003));
        }

        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last 'publishable' mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00002 > min movement => price queued
            prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {   // Min movement = 0.00001 * 1.00000(last PUBLISHED mid) = 0.00001
            // Mid movement from last PUBLISHED = 0.00001 == min movement => Price queued.
            prophet.incrementTime(25);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00001, 0.00004));
        }
        then:
        {
            prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(25);
            // another piece of market data kicks the time signal
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {
            // Since new overall time period push out queued price
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.AUDUSD)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00001));
        }
    }

    @Test
    @DisplayName("Queued price replaced with insignificant movement price")
    public void queuedPriceReplacedWithInsignificantPrice() {
        final double minimumPriceDeltaFractionOfMid = 0.00001;
        final int overrideFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.ANY, Currency.ANY, minimumPriceDeltaFractionOfMid, overrideFrequencyMS)
                    ))
            , true);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00001, 0.00004));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {   // Significant mid movement.  Price Queued
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.99999, 0.00003));
        }
        then:
        {
            prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {   // Min movement = 0.00001 * 1.00001(last PUBLISHED mid) = 0.0000100001
            // Mid movement from last PUBLISHED = 0.00001 => Insignificant mid movement. No Price queued.
            prophet.incrementTime(25);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00002, 0.00004));
        }
        then:
        {
            prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(25);
            // another piece of market data kicks the time signal
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {
            // Since no queued price, expect no client price
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
    }

    @Test
    @DisplayName("Override limit greater than 1")
    public void overrideLimitGreaterThanOne() {
        final double minimumPriceDeltaFractionOfMid = 0.00001;
        final int overrideFrequencyMS = 100;
        final int overrideLimit = 2;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS, overrideLimit),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS, overrideLimit),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS, overrideLimit),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minimumPriceDeltaFractionOfMid, overrideFrequencyMS, overrideLimit)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00002, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00002 > min movement => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00002));
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00002 => min movement = 0.00001 * 1.00002 = 0.0000100002
            // Mid movement of 0.00002 > min movement => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00000));
        }
    }

    private ClientPriceThrottleConfigImpl clientPriceConfigOverrideThrottle(final Market market,Currency baseCurrency, Currency termsCurrency,
                                                                            double minimumPriceDeltaFractionOfMid,
                                                                            int midRateFrequencyMS) {
        return new ClientPriceThrottleConfigImpl(market, baseCurrency, termsCurrency)
                .setNoActivityHeartbeatFrequencyMs(DONT_CARE_LARGE_LONG)
                .setLimit(1)
                .setTimePeriod(DONT_CARE_LARGE_LONG)
                .setMinimumPriceDeltaFractionOfSpread(DONT_CARE_LARGE_DOUBLE)
                .setOverrideLimit(1)
                .setOverrideTimePeriod(midRateFrequencyMS)
                .setOverrideMinimumPriceDeltaFractionOfMid(minimumPriceDeltaFractionOfMid)
                .setMinimumPriceDeltaFractionOfPreviousSpread(DONT_CARE_LARGE_DOUBLE);
    }

    private ClientPriceThrottleConfigImpl clientPriceConfigOverrideThrottle(final Market market, Currency baseCurrency, Currency termsCurrency,
                                                                            double minimumPriceDeltaFractionOfMid,
                                                                            int midRateFrequencyMS,
                                                                            int overridelimit) {
        return new ClientPriceThrottleConfigImpl(market, baseCurrency, termsCurrency)
                .setNoActivityHeartbeatFrequencyMs(DONT_CARE_LARGE_LONG)
                .setLimit(1)
                .setTimePeriod(DONT_CARE_LARGE_LONG)
                .setMinimumPriceDeltaFractionOfSpread(DONT_CARE_LARGE_DOUBLE)
                .setOverrideLimit(overridelimit)
                .setOverrideTimePeriod(midRateFrequencyMS)
                .setOverrideMinimumPriceDeltaFractionOfMid(minimumPriceDeltaFractionOfMid);
    }
}
