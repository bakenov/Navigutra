package com.anz.markets.efx.fox.receiver;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;

public class ConfigurationInitialiserBuilder {
    private static final Runnable NOOP = () -> {};

    private final SorEncoderSupplier sorEncoderSupplier;
    private final boolean resetAll;
    private final List<Runnable> initSteps = new ArrayList<>();

    public ConfigurationInitialiserBuilder(final SorEncoderSupplier sorEncoderSupplier, final boolean resetAll) {
        this.sorEncoderSupplier = Objects.requireNonNull(sorEncoderSupplier);
        this.resetAll = resetAll;
    }

    public static ConfigurationInitialiserBuilder create(final SorEncoderSupplier sorEncoderSupplier, final boolean resetAll) {
        return new ConfigurationInitialiserBuilder(sorEncoderSupplier, resetAll);
    }

    public ConfigurationInitialiserBuilder add(final Runnable runnable) {
        initSteps.add(runnable);
        return this;
    }

    public Runnable build() {
        if (!resetAll) return NOOP;
        return () -> {
            injectInitStage(InitStage.BEGIN);
            initSteps.forEach(Runnable::run);
            injectInitStage(InitStage.END);
        };
    }

    private void injectInitStage(final InitStage initStage) {
        sorEncoderSupplier.initialisation()
                .messageStart(0, 0)
                .initStage(initStage)
                .messageComplete();
    }
}
