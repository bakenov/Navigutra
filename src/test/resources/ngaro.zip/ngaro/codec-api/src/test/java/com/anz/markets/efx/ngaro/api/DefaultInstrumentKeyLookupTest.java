package com.anz.markets.efx.ngaro.api;

import java.time.LocalDate;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DefaultInstrumentKeyLookupTest {
    DefaultInstrumentKeyLookup instrumentKeyLookup = new DefaultInstrumentKeyLookup();

    @Test
    public void lookup() {

        final InstrumentKey instrumentKey1 = instrumentKeyLookup.lookup("AUDUSD", SecurityType.FXNDF, Tenor.M1, LocalDate.of(2018, 12, 11));
        final InstrumentKey instrumentKey2 = instrumentKeyLookup.lookup("AUDUSD", SecurityType.FXNDF, Tenor.M1, LocalDate.of(2018, 12, 11));
        final InstrumentKey instrumentKey3 = instrumentKeyLookup.lookup(instrumentKey2.instrumentId());
        assertThat(instrumentKey1).isSameAs(instrumentKey2);
        assertThat(instrumentKey2).isSameAs(instrumentKey3);
    }
}