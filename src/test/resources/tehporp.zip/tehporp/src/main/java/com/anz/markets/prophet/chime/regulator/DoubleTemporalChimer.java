package com.anz.markets.prophet.chime.regulator;

import com.anz.markets.prophet.domain.time.OneSecond;

import java.util.function.Consumer;
import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleConsumer;


/**
 * To summarise a double number stream into a regular update frequency
 */
public class DoubleTemporalChimer implements DoubleConsumer {
    private final double initialValue;
    private final DoubleBinaryOperator updateFunction;
    private final DoubleConsumer consumer;
    private double existing;

    public DoubleTemporalChimer(final double initialValue, final DoubleBinaryOperator updateFunction,
                                final DoubleConsumer consumer) {
        this.updateFunction = updateFunction;
        this.consumer = consumer;
        this.initialValue = initialValue;
        this.existing = initialValue;
    }

    @Override
    public void accept(double received) {
        if (Double.isNaN(existing)) {
            existing = received;
        } else {
            existing = updateFunction.applyAsDouble(existing, received);
        }
    }

    public Consumer<OneSecond> consumerOfOneSecond() {
        return sec -> {
            consumer.accept(existing);
            existing = initialValue;
        };
    }

}

