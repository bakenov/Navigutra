package com.anz.markets.prophet.pricer.inverse;

import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class InverseRateManagerJmhTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(InverseRateManagerJmhTest.class);

    @State(Scope.Benchmark)
    public static class Data extends AbstractInverseRateManagerForBwJmhTest {

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }

    @Benchmark
    public ClientPrice testProcessClientPrice(@NotNull final Data data) throws Exception {
        return data.calculateForInversePairs();
    }
}
