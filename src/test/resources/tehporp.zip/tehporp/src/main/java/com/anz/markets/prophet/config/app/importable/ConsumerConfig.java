package com.anz.markets.prophet.config.app.importable;


import com.anz.markets.disco.data.SignalRegisters;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.backtest.BackTestManager;
import com.anz.markets.prophet.chime.bespoke.RateChimer;
import com.anz.markets.prophet.config.app.CoreConfig;
import com.anz.markets.prophet.config.business.FailSafeConfigManager;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.CovCorrAvgs;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.PricingFirewallReset;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketrisk.CorrelatedRiskFactor;
import com.anz.markets.prophet.domain.marketrisk.CorrelatedRiskFactors;
import com.anz.markets.prophet.domain.marketrisk.impl.CorrelatedRiskFactorsImpl;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.domain.time.SpotDateRollChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.hedger.HedgeManager;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallManager;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.marketdata.FilteredMarketDataSnapshotManager;
import com.anz.markets.prophet.marketdata.FilteredMarketDataSnapshotPublishOnChangedTOB;
import com.anz.markets.prophet.marketdata.aggbook.AggregatedBookManager;
import com.anz.markets.prophet.marketdata.aggbook.AggregatedBooksManager;
import com.anz.markets.prophet.marketdata.aggbook.TriangulatedMidRateManager;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.LastValueStore;
import com.anz.markets.prophet.positionrisk.PositionAccumulator;
import com.anz.markets.prophet.positionrisk.PositionManager;
import com.anz.markets.prophet.positionrisk.PositionManager.PositionsUpdatePhase;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.ProfitAndLossManager;
import com.anz.markets.prophet.positionrisk.Volume;
import com.anz.markets.prophet.positionrisk.VolumeManager;
import com.anz.markets.prophet.positionrisk.hedging.pnl.HedgersRevalProfitAndLossManager;
import com.anz.markets.prophet.positionrisk.hedging.volume.SlidingWindowDealVolumeManager;
import com.anz.markets.prophet.pricer.ClientPriceEnricher;
import com.anz.markets.prophet.pricer.control.VolatilityControlManager;
import com.anz.markets.prophet.pricer.cross.CrossRateCalculator;
import com.anz.markets.prophet.pricer.cross.CrossRateManager;
import com.anz.markets.prophet.pricer.cross.ForwardPointManager;
import com.anz.markets.prophet.pricer.cross.MidRateToBaseCache;
import com.anz.markets.prophet.pricer.firewall.PricingFirewallManager;
import com.anz.markets.prophet.pricer.inverse.InverseRateManager;
import com.anz.markets.prophet.pricer.pfp.cache.ClientPriceDataRegisterDependencyManager;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.pricer.pfp.cache.RiskReducingFlowManager;
import com.anz.markets.prophet.pricer.pfp.features.ManualSkewFeature;
import com.anz.markets.prophet.pricer.pfp.features.PauseSkewFeature;
import com.anz.markets.prophet.pricer.pfp.features.StanddownMidHedgersOnNoSkewFeature;
import com.anz.markets.prophet.pricer.skew.SkewConfigProvider;
import com.anz.markets.prophet.pricer.throttle.ClientPriceThrottleManager;
import com.anz.markets.prophet.pricer.truethrottle.TrueThrottleManager;
import com.anz.markets.prophet.pricer.wholesale.BenchmarkSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.DriverInstrumentWholesaleBookManager;
import com.anz.markets.prophet.pricer.wholesale.DriverStackFromBandedCalculatorImpl;
import com.anz.markets.prophet.pricer.wholesale.DriverStackSpreadAndWeightCalculatorImpl;
import com.anz.markets.prophet.pricer.wholesale.NDFClientPriceManager;
import com.anz.markets.prophet.pricer.wholesale.spreads.ArbitrageSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.EconomicsNewsSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.ManualSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.MarketGapSpreadAdjustmentStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.OverallSpreadFormationStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.RiskAdjustedSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.VolatilitySpreadStrategy;
import com.anz.markets.prophet.risk.CorrelatedRiskFactorManager;
import com.anz.markets.prophet.risk.GradientOptimalPositionManager;
import com.anz.markets.prophet.risk.ParametricValueAtRiskCalculator;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.ValueAtRiskManager;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.risk.realvol.RealisedVolatilityManager;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.prophet.riskpath.RiskPathManager;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceRealTime;
import com.anz.markets.prophet.syscontrol.ActivationProcessor;
import com.anz.markets.prophet.syscontrol.MapNotifierDefault;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.syscontrol.Notifier;
import com.anz.markets.prophet.syscontrol.NotifierChecked;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import com.anz.markets.prophet.syscontrol.TableNotifierDefault;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.function.Consumer;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.syscontrol.NotifierDefault.asList;

@Configuration
@Import({BusinessConfig.class, BackTestConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class ConsumerConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ConsumerConfig.class);

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    // business functionality entry points - the below are wired in to CoreConfig ChronicleReaders
    @Bean
    public Consumer<Activate> activateConsumers(final ActivationProcessor activationProcessor) {
        return activationProcessor;
    }

    @Bean
    public Consumer<ConfigurationData> configurationDataConsumer(final FailSafeConfigManager failSafeConfigManager) {
        return failSafeConfigManager.consumerConfigurationData();
    }

    @Bean
    public Consumer<Adjustment> adjustmentConsumers(final PositionManager positionManager,
                                                    final RiskPathManager riskPathManager) {
        return new NotifierDefault(positionManager.consumerOfAdjustment(), riskPathManager.consumerOfAdjustment());
    }

    @Bean
    public Consumer<Adjustments> adjustmentsConsumers(final PositionManager positionManager,
                                                      final RiskPathManager riskPathManager) {
        return new NotifierDefault(positionManager.consumerOfAdjustments(), riskPathManager.consumerOfAdjustments());
    }

    @Bean
    public Consumer<SpotDate> spotDateConsumer(final ForwardPointManager forwardPointManager,
                                               final CrossRateManager crossRateManager,
                                               final ClientPriceEnricher clientPriceEnricher) {
        return new NotifierDefault(forwardPointManager.consumerOfSpotDate(), crossRateManager.consumerSpotDate(), clientPriceEnricher.consumerSpotDate());
    }

    @Bean
    public Consumer<ForwardPoint> forwardPointConsumer(final ForwardPointManager forwardPointManager,
                                                       final NDFClientPriceManager ndfClientPriceManager) {
        return new NotifierDefault<>(
                forwardPointManager.consumerOfForwardPoint(),
                ndfClientPriceManager.consumerForwardPoint()
        );
    }

    @Bean
    public Consumer<VolatilityControl> volatilityControlConsumer(final VolatilityControlManager volatilityControlManager) {
        return volatilityControlManager.consumerOfVolatilityControl();
    }

    @Bean
    public Consumer<BiasPositionControl> biasPositionControlConsumer(final PositionManager positionManager) {
        return positionManager.consumerOfBiasPositionControl();
    }

    @Bean
    public Consumer<EconNews> econNewsConsumer(final DriverInstrumentWholesaleBookManager wholesaleBookManager,
                                               final HedgeManager hedgeManager) {
        return new NotifierDefault(wholesaleBookManager.consumerOfEconNews(), hedgeManager.consumerOfEconNews());
    }

    @Bean
    public Consumer<CovCorrAvgs> covCorrAvgsConsumer(final CorrelatedRiskFactorManager correlatedRiskFactorManager) {
        return new NotifierDefault(correlatedRiskFactorManager.consumerOfCovCorrAvgs());
    }

    @Bean
    public Consumer<SkewCurrencyControl> skewCurrencyControlConsumer(final PauseSkewFeature pauseSkewFeature) {
        return pauseSkewFeature.consumerOfSkewCurrencyControl();
    }

    @Bean
    public Consumer<ManualSkewControl> manualSkewControlConsumer(final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager) {
        return driverInstrumentWholesaleBookManager.consumerOfManualSkewControl();
    }

    @Bean
    public Consumer<Trade> tradeConsumer(final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager,
                                         final PositionManager positionManager,
                                         final HedgeManager hedgeManager,
                                         final HedgeFirewallManager hedgeFirewallManager,
                                         final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
                                         final RiskPathManager riskPathManager,
                                         final SlidingWindowDealVolumeManager dvManager,
                                         final PauseSkewFeature pauseSkewFeature,
                                         final RiskReducingFlowManager riskReducingFlowManager) {
        // note: hedge manager must be called after positionManager
        return new NotifierChecked(
                dvManager.consumerTrade(), // SlidingWindowDealVolumeManager should be called first as sends control signals to the hedger
                pauseSkewFeature.timeDrivingMessageConsumer(),
                positionManager.consumerOfTrade(),
                riskReducingFlowManager.consumerOfTrade(),    // after position manager.
                hedgeFirewallManager.consumerOfTrade(),
                hedgersRevalProfitAndLossManager.consumerOfTrade(),
                hedgeManager.consumerOfTrade(),
                riskPathManager.consumerOfTrade(),
                clientPriceDataRegisterDependencyManager.consumerToTriggerPriceFormationAsNecessary()
        );
    }

    @Bean
    public Consumer<Volume> volumeConsumer(final PricingFirewallManager pricingFirewallManager) {
        return pricingFirewallManager.consumerOfVolume();
    }

    @Bean
    public Consumer<MarketData> marketDataConsumers(
            final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager) {
        return filteredMarketDataSnapshotManager.consumerOfMarketData();
    }

    @Bean
    public FilteredMarketDataSnapshotPublishOnChangedTOB marketDataPersistOnChange(
            @Qualifier("marketDataSink") final Consumer<MidRate> marketDataSink) {
        return new FilteredMarketDataSnapshotPublishOnChangedTOB(marketDataSink);
    }

    @Bean
    public Consumer<OneSecond> positionAndPnlChimer(
            @Value("${positionAndPnl.minimumRateSec:60}") final int minimumRateSec,
            final PositionAccumulator positionAccumulator,
            final LastValueStore<ProfitAndLoss> profitAndLossLastValueStore) {
        return new RateChimer(minimumRateSec, new NotifierDefault<>(positionAccumulator.consumerOfChime(), profitAndLossLastValueStore.consumerOfChime()));
    }

    @Bean
    public Consumer<OneSecond> oneSecondConsumer(final ClientPriceThrottleManager clientPriceThrottleManager,
                                                 final TrueThrottleManager trueThrottleManager,
                                                 final HedgeManager hedgeManager,
                                                 final PricingFirewallManager pricingFirewallManager,
                                                 final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager,
                                                 final RealisedVolatilityManager realisedVolatilityManager,
                                                 final HedgeFirewallManager hedgeFirewallManager,
                                                 final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
                                                 final ForwardPointManager forwardPointManager,
                                                 final NDFClientPriceManager ndfClientPriceManager,
                                                 final SlidingWindowDealVolumeManager dealVolumeManager,
                                                 final PauseSkewFeature pauseSkewFeature,
                                                 @Qualifier("positionAndPnlChimer") final Consumer<OneSecond> positionAndPnlChimer) {
        return new NotifierDefault<>(
                pauseSkewFeature.timeDrivingMessageConsumer(),
                clientPriceThrottleManager.consumerOneSecond(),
                trueThrottleManager.consumerOneSecond(),
                hedgeFirewallManager.consumerOfOneSecond(),
                hedgeManager.consumerOfOneSecond(),
                pricingFirewallManager.consumerOfOneSecond(),
                filteredMarketDataSnapshotManager.consumerOfOneSecond(),
                realisedVolatilityManager.consumerOfOneSecond(),
                hedgersRevalProfitAndLossManager.consumerOfOneSecond(),
                forwardPointManager.consumerOfOneSecond(),
                ndfClientPriceManager.consumerOneSecond(),
                dealVolumeManager.consumerOneSecond(),
                positionAndPnlChimer
        );
    }

    @Bean
    public Consumer<OperatingHourChime> operatingHourChimeConsumer(final PricingFirewallManager pricingFirewallManager,
                                                                   final HedgeManager hedgeManager) {
        return new NotifierDefault<>(
                pricingFirewallManager.consumerOfOperatingHourChime(),
                hedgeManager.consumerOfOperatingHourChime());
    }

    @Bean
    public Consumer<SpotDateRollChime> spotDateRollChimeConsumer (final HedgeManager hedgeManager) {
        return new NotifierDefault<>(hedgeManager.consumerOfSpotDateRollChimeConsumer());
    }

    @Bean
    public Consumer<OrderEvent> orderEventConsumer(final HedgeManager hedgeManager,
                                                   final HedgeFirewallManager hedgeFirewallManager) {
        return new NotifierDefault<>(hedgeManager.consumerOfOrderEvent(), hedgeFirewallManager.consumerOfOrderEvent());
    }

    @Bean
    public Consumer<PricePauseControl> pricePauseControl(final PricingFirewallManager pricingFirewallManager) {
        return new NotifierDefault<>(pricingFirewallManager.consumerOfPricePauseControl());
    }

    // the business consumers themselves
    @Bean
    public FailSafeConfigManager configProcessor(final ConfigurationData configurationDataDefault,
                                                 final DataRegisters dataRegisters,
                                                 final FilteredMarketDataSnapshotPublishOnChangedTOB filteredMarketDataSnapshotPublishOnChangedTOB,
                                                 final SkewConfigProvider skewConfigProvider,
                                                 final RiskReducingFlowManager riskReducingFlowManager,
                                                 final PositionManager positionManager,
                                                 final TriangulatedMidRateManager triangulatedMidRateManager,
                                                 final ValueAtRiskManager valueAtRiskManager,
                                                 final GradientOptimalPositionManager optimalPositionManager,
                                                 final HedgeManager hedgeManager,
                                                 final ProfitAndLossManager profitAndLossManager,
                                                 final AggregatedBooksManager aggregatedBooksManager,
                                                 final ClientPriceThrottleManager clientPriceThrottleManager,
                                                 final TrueThrottleManager trueThrottleManager,
                                                 final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager,
                                                 final RealisedVolatilityManager realisedVolatilityManager,
                                                 final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
                                                 final PricingFirewallManager pricingFirewallManager,
                                                 final CrossRateManager crossRateManager,
                                                 final HedgeFirewallManager hedgeFirewallManager,
                                                 final ForwardPointManager forwardPointManager,
                                                 final RiskPathManager riskPathManager,
                                                 final SlidingWindowDealVolumeManager slidingWindowDealVolumeManager,
                                                 final BackTestManager backTestManager,
                                                 final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager,
                                                 final CorrelatedRiskFactorManager correlatedRiskFactorManager,
                                                 final InverseRateManager inverseRateManager,
                                                 final NDFClientPriceManager ndfClientPriceManager,
                                                 final VolatilityControlManager volatilityControlManager,
                                                 @Qualifier("configurationSink") final Consumer<IndexedConfigurationData> configurationSink,
                                                 @Value("${business.config.json.file:/business.config.json}") final String jsonFile,
                                                 @Value("${fail.safe.config.manager.should.initialise.with.cache:true}") final boolean shouldInitialiseWithCache,
                                                 @Value("${fail.safe.config.manager.should.write.to.disk:true}") final boolean writeToDisk,
                                                 @Value("${core.instance}") final byte coreInstance,
                                                 @Value("${default.active.core.instance}") final int defaultActiveCoreInstance) throws IOException {


        final NotifierDefault<IndexedConfigurationData> consumers = new NotifierDefault<>(
                dataRegisters.consumerIndexedConfigurationData(),
                clientPriceDataRegisterDependencyManager.consumerIndexedConfigurationData(),  // do this early because clears listeners.
                filteredMarketDataSnapshotPublishOnChangedTOB.consumerOfIndexedConfigurationData(),
                skewConfigProvider.consumerIndexedConfigurationData(),
                riskReducingFlowManager.consumerOfIndexedConfigurationData(),
                positionManager.consumerIndexedConfigurationData(),
                triangulatedMidRateManager.consumerIndexedConfigurationData(),
                valueAtRiskManager.consumerIndexedConfigurationData(),
                optimalPositionManager.consumerOfIndexedConfigurationData(),
                hedgeManager.consumerIndexedConfigurationData(),
                profitAndLossManager.consumerIndexedConfigurationData(),
                aggregatedBooksManager.consumerOfIndexedConfigurationData(),
                filteredMarketDataSnapshotManager.consumerIndexedConfigurationData(),
                realisedVolatilityManager.consumerIndexedConfigurationData(),
                driverInstrumentWholesaleBookManager.consumerIndexedConfigurationData(),
                pricingFirewallManager.consumerIndexedConfigurationData(),
                crossRateManager.consumerIndexedConfigurationData(),
                hedgeFirewallManager.consumerOfConfiguration(),
                forwardPointManager.consumerIndexedConfigurationData(),
                ndfClientPriceManager.consumerIndexConfigurationData(),
                riskPathManager.consumerIndexedConfigurationData(),
                slidingWindowDealVolumeManager.consumerIndexedConfigurationData(),
                correlatedRiskFactorManager.consumerOfIndexedConfigurationData(),
                inverseRateManager.consumerIndexedConfigurationData(),
                clientPriceThrottleManager.consumerIndexedConfigurationData(),
                trueThrottleManager.consumerIndexedConfigurationData(),
                volatilityControlManager.consumerIndexedConfigurationData(),
                configurationSink);

        // make sure only one core writes config file. TODO: wire up FailSafeConfigManager to activate msg
        final boolean activeAndCanWrite = writeToDisk && (coreInstance == defaultActiveCoreInstance);
        // TODO: this pumps a config object to everything and is problematic in this thread (0 time for example)
        return FailSafeConfigManager.createInstance(shouldInitialiseWithCache, activeAndCanWrite, backTestManager.isBackTestEnabled(),
                (ConfigurationDataDefault) configurationDataDefault, jsonFile, consumers);
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManager(
            final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager,
            final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
            final CrossRateManager crossRateManager,
            final AggregatedBooksManager aggregatedBooksManager,
            final HedgeManager hedgeManager,
            @Qualifier(CoreConfig.TRADING_TIME_ZONE_CHIME_SINK) final Consumer<TradingTimeZoneChime> tradingTimeZoneChimeSink) {
        return new TradingTimeZoneManager(new NotifierDefault<>(
                filteredMarketDataSnapshotManager.consumerOfTradingTimeZoneChime(),
                driverInstrumentWholesaleBookManager.consumerTradingTimeZoneChime(),
                crossRateManager.consumerTradingTimeZoneChime(),
                aggregatedBooksManager.consumerTradingTimeZoneChime(),
                hedgeManager.consumerOfTradingTimeZoneChime(),
                tradingTimeZoneChimeSink));
    }

    @Bean
    public ActivationProcessor activationProcessor(@Value("${core.instance:0}") final int coreInstance,
                                                   final HedgeManager hedgeManager,
                                                   final SlidingWindowDealVolumeManager dealVolumeManager,
                                                   final PauseSkewFeature pauseSkewFeature,
                                                   @Qualifier("activateSink") final Consumer<Activate> activateSink) {
        final NotifierDefault<Activate> nfys = new NotifierDefault<>(
                hedgeManager.consumerOfActivate(),
                dealVolumeManager.consumerActivate(),
                pauseSkewFeature.timeDrivingMessageConsumer(),
                activateSink);
        return new ActivationProcessor(nfys, coreInstance);
    }

    @Bean
    public PositionManager calculatePosition(final DataRegisters dataRegisters,
                                             final RiskReducingFlowManager riskReducingFlowManager,
                                             final ValueAtRiskManager valueAtRiskManager,
                                             final GradientOptimalPositionManager optimalPositionManager,
                                             final ProfitAndLossManager profitAndLossManager,
                                             final PricingFirewallManager pricingFirewallManager,
                                             final VolumeManager volumeManager,
                                             final Consumer<Positions> positionsSink,
                                             final PositionAccumulator positionAccumulator,
                                             final HedgeManager hedgeManager,
                                             @Qualifier("biasAdjustmentSink") final Consumer<Adjustment> biasAdjustmentSink) {

        final TableNotifierDefault<PositionsUpdatePhase, Portfolio, Positions> notifier = new TableNotifierDefault<>(PositionsUpdatePhase.class, Portfolio.class);
        notifier.register(PositionsUpdatePhase.BASE, Portfolio.BIASED_CLIENTS_NET, dataRegisters.consumerOfPositions())
                .register(PositionsUpdatePhase.NOTIONAL, Portfolio.CLIENTS_NET, pricingFirewallManager.consumerOfPositions())
                .register(PositionsUpdatePhase.NOTIONAL, Portfolio.CLIENTS_NET, volumeManager.consumerOfPositions())
                .register(PositionsUpdatePhase.NOTIONAL, Portfolio.BIASED_CLIENTS_NET, riskReducingFlowManager.consumerOfNotionalClientsBiasedNetPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, optimalPositionManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.BIASED_CLIENTS_NET, optimalPositionManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, profitAndLossManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.BIAS_OFFSET, profitAndLossManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, valueAtRiskManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, hedgeManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.BIASED_CLIENTS_NET, hedgeManager.consumerOfPositions())
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, positionsSink)
                .register(PositionsUpdatePhase.BASE, Portfolio.BIASED_CLIENTS_NET, positionsSink)
                .register(PositionsUpdatePhase.BASE, Portfolio.BIAS_OFFSET, positionsSink)
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, positionAccumulator);

        return new PositionManager(notifier, biasAdjustmentSink);
    }

    @Bean
    public PositionAccumulator positionAccumulator(final Consumer<Positions> positionsSink) {
        return new PositionAccumulator(positionsSink);
    }

    @Bean
    public ProfitAndLossManager createCalculateProfitAndLoss(final Consumer<ProfitAndLoss> profitAndLossSink,
                                                             final PricingFirewallManager pricingFirewallManager,
                                                             final LastValueStore<ProfitAndLoss> profitAndLossLastValueStore,
                                                             final HedgeManager hedgeManager) {
        return new ProfitAndLossManager(new NotifierDefault<>(pricingFirewallManager.consumerOfProfitAndLoss(),
                profitAndLossLastValueStore,
                hedgeManager.consumerOfProfitAndLoss(),
                profitAndLossSink));
    }

    @Bean
    public LastValueStore<ProfitAndLoss> profitAndLossLastValueStore(final Consumer<ProfitAndLoss> profitAndLossSink) {
        return new LastValueStore<>(profitAndLossSink);
    }

    @Bean
    public Consumer<EndOfWeekChime> endOfWeekChimeConsumer(final RiskPathManager riskPathManager, final Consumer<EndOfWeekChime> endOfWeekChimeSink) {
        return new NotifierDefault<>(riskPathManager.consumerOfEndOfWeekChime(), endOfWeekChimeSink);
    }

    // Risk Management components
    @Bean
    public GradientOptimalPositionManager optimalPosition(
            final DataRegisters dataRegisters,
            final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
            final HedgeManager hedgeManager,
            final Consumer<OptimalPositions> optimalPositionsSink) {

        final MapNotifierDefault<OptimalPositionType, OptimalPositions> notifier = new MapNotifierDefault<>(OptimalPositionType.class);
        notifier.register(OptimalPositionType.PRICING_BIAS, dataRegisters.consumerOfOptimalPositions())
                .register(OptimalPositionType.PRICING_BIAS, driverInstrumentWholesaleBookManager.consumerOptimalPositions())
                .register(OptimalPositionType.PRICING, hedgeManager.consumerOfOptimalPositions())
                .register(OptimalPositionType.PRICING_BIAS, hedgeManager.consumerOfOptimalPositions())
                .register(OptimalPositionType.PRICING, optimalPositionsSink)
                .register(OptimalPositionType.PRICING_BIAS, optimalPositionsSink);

        return new GradientOptimalPositionManager(notifier);
    }

    @Bean
    public CorrelatedRiskFactorManager correlatedRiskFactorManager(
            @Value("${business.config.covar.file:/covar.properties}") final String covarFile,
            @Value("${business.config.hedgingcovar.file:/hedging-covar.properties}") final String hedgingCovarFile,
            final ValueAtRiskManager valueAtRiskManager,
            final GradientOptimalPositionManager optimalPositionManager) throws IOException {

        // EMPTY at this stage - note that a real correlation matrix should be used....
        final Consumer<CorrelatedRiskFactor> hedgingOptimalPositionConsumer = new NotifierDefault<>();

        final Consumer<CorrelatedRiskFactor> defaultOptimalPositionConsumer = new NotifierDefault<>(
                valueAtRiskManager.consumerCorrelatedRiskFactor(),
                optimalPositionManager.consumerOfCorrelatedRiskFactor());

        final InputStream covarInputStream = this.getClass().getResourceAsStream(covarFile);
        GcFriendlyAssert.notNull(covarInputStream, "business.config.covar.file is not configured or file cannot be found: %s", covarFile);
        CorrelatedRiskFactors defaultCorrelatedRiskFactors = CorrelatedRiskFactorsImpl.createInstance(OptimalPositionType.PRICING, covarInputStream);

        final InputStream hedgingCovarInputStream = this.getClass().getResourceAsStream(hedgingCovarFile);
        GcFriendlyAssert.notNull(hedgingCovarInputStream, "business.config.hedgingcovar.file is not configured or file cannot be found: %s", hedgingCovarFile);
        CorrelatedRiskFactors hedgingCorrelatedRiskFactors = CorrelatedRiskFactorsImpl.createInstance(OptimalPositionType.HEDGING, hedgingCovarInputStream);

        return new CorrelatedRiskFactorManager(defaultCorrelatedRiskFactors, hedgingCorrelatedRiskFactors, defaultOptimalPositionConsumer, hedgingOptimalPositionConsumer);
    }

    @Bean
    public Consumer<HourChime> hourChimeConsumer(final CorrelatedRiskFactorManager correlatedRiskFactorManager,
                                                 final HedgeManager hedgeManager,
                                                 final HedgeFirewallManager hedgeFirewallManager) {
        final Consumer<HourChime> recalibrateTimeSource = (Context.context().timeSource() instanceof TimeSourceRealTime) ?((TimeSourceRealTime) Context.context().timeSource()) : NoConsumer.instance();
        return new NotifierDefault<>(
                recalibrateTimeSource,
                correlatedRiskFactorManager.consumerOfUTCHourChime(),
                hedgeManager.consumerOfHourChime(),
                hedgeFirewallManager.consumerOfHourChime());
    }

    @Bean
    public SlidingWindowDealVolumeManager slidingWindowDealVolumeManager(final Consumer<HedgePauseSignal> hedgePauseSignalSink, final HedgeManager hedgeManager) {
        return new SlidingWindowDealVolumeManager(new NotifierDefault(hedgePauseSignalSink,hedgeManager.consumerOfHedgePauseSignal()));
    }

    @Bean
    public ValueAtRiskManager valueAtRiskManager(final DataRegisters dataRegisters,
                                                 final HedgeManager hedgeManager,
                                                 final Consumer<ValueAtRisk> varSink) throws IOException {
        final Notifier<ValueAtRisk> valueAtRiskNotifier = new NotifierDefault<>(dataRegisters.consumerOfValueAtRisk(), hedgeManager.consumerOfValueAtRisk(), varSink);
        ValueAtRiskManager valueAtRiskManager = new ValueAtRiskManager(valueAtRiskNotifier, new ParametricValueAtRiskCalculator());
        return valueAtRiskManager;
    }

    @Bean
    public RealisedVolatilityManager realisedVolatilityManager(
            final DataRegisters dataRegisters,
            final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
            final HedgeManager hedgeManager,
            final Consumer<RealisedVolatility> realisedVolatilitySink) throws IOException {
        final List<Consumer<RealisedVolatility>> realisedVolatilityConsumers = asList(dataRegisters.consumerOfRealisedVolatility(),driverInstrumentWholesaleBookManager.consumerRealisedVolatility(), hedgeManager.consumerOfRealisedVolatility(), realisedVolatilitySink);
        final RealisedVolatilityManager realisedVolatilityManager = new RealisedVolatilityManager(realisedVolatilityConsumers);
        return realisedVolatilityManager;
    }

    @Bean
    public SignalRegisters signalRegisters() {
        return new SignalRegisters();
    }

    // RawSnapshots
    @Bean
    public FilteredMarketDataSnapshotManager marketProviderPriceBookFilter(
            final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager,
            final AggregatedBooksManager aggregatedBooksManager,
            final HedgeManager hedgeManager,
            final SlidingWindowDealVolumeManager dealVolumeManager,
            final PauseSkewFeature pauseSkewFeature,
            final PricingFirewallManager pricingFirewallManager,
            @Qualifier("marketDataPersistOnChange") final FilteredMarketDataSnapshotPublishOnChangedTOB marketDataPersistOnChange,
            final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
            final SignalRegisters signalRegisters,
            final Consumer<Signals> signalsSink) {
        // order is important here
        final Consumer<FilteredMarketDataSnapshot> consumer = new NotifierDefault<>(
                clientPriceDataRegisterDependencyManager.getDataRegisters().consumerOfMarketData(),
                // HedgeManager should consume prior to AggregatedBookManager because AggBook feeds into position etc.
                // TODO: note that this is something that behaves a bit differently with the separated cores as
                // HedgeManager will only receive MD if it has changed
                hedgeManager.consumerOfMarketData(),
                aggregatedBooksManager.consumerOfMarketData(),
                dealVolumeManager.consumerMarketData(),
                marketDataPersistOnChange.consumerFilteredMarketData(),
                pauseSkewFeature.timeDrivingMessageConsumer(),
                clientPriceDataRegisterDependencyManager.consumerToTriggerPriceFormationAsNecessary(),
                pricingFirewallManager.consumerToTriggerPostPublishAsRequired()  // firewall check after price formation.
                );
        return new FilteredMarketDataSnapshotManager(consumer,new NotifierDefault<>(),signalRegisters,signalsSink);
    }

    @Bean
    public AggregatedBooksManager getAggregatedBooksManager(final DataRegisters dataRegisters,
                                                            @Qualifier("marketDataSink") final Consumer<MidRate> marketDataSink,
                                                            final AggregatedBookManager primaryAggregatedBookManager,
                                                            final AggregatedBookManager referenceAggregatedBookManager,
                                                            final HedgeManager hedgeManager) {
        return new AggregatedBooksManager(
                referenceAggregatedBookManager,
                new AggregatedBookManager(Market.WSP_BENCH, new NotifierDefault<>(dataRegisters.consumerOfMidRate(),hedgeManager.consumerOfAggregatedBookMidRate(), marketDataSink), NoConsumer.instance()),
                primaryAggregatedBookManager);
    }

    @Bean(name = "primaryAggregatedBookManager")
    public AggregatedBookManager getPrimaryAggregatedBookManager(
            final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager,
            final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
            final TriangulatedMidRateManager triangulatedMidRateManager,
            final HedgeManager hedgeManager,
            final GradientOptimalPositionManager optimalPositionManager,
            final PositionManager positionManager,
            final ClientPriceThrottleManager clientPriceThrottleManager,
            final TrueThrottleManager trueThrottleManager,
            final RealisedVolatilityManager realisedVolatilityManager,
            final HedgeFirewallManager hedgeFirewallManager,
            final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
            final RiskPathManager riskPathManager,
            @Qualifier("marketDataSink") final Consumer<MidRate> aggregatedBookSink) {

        final Consumer<MidRate> changedMidRateConsumers = new NotifierDefault<>(
                clientPriceDataRegisterDependencyManager.getDataRegisters().consumerOfMidRate(),
                driverInstrumentWholesaleBookManager.consumerOfAggBook(),
                triangulatedMidRateManager.consumerOfDriverMidRate(),
                hedgeManager.consumerOfAggregatedBookMidRate(),  // HedgeManager should consume prior to GradientOptimalPositionManager
                optimalPositionManager.consumerOfMidRate(), // GradientOptimalPositionManager to consume MidRate prior to PositionManager
                positionManager.consumerOfMidRate(),
                clientPriceDataRegisterDependencyManager.getDataRegisters().consumerOfMidRate(),
                realisedVolatilityManager.consumerOfMarketData(),
                hedgeFirewallManager.consumerOfMidRate(),
                hedgersRevalProfitAndLossManager.consumerOfMidRate(),
                clientPriceDataRegisterDependencyManager.consumerOfMidrateForTriggeringPriceFormation(),
                clientPriceThrottleManager.marketDataChimer(),
                trueThrottleManager.marketDataChimer(),
                riskPathManager.consumerOfMidRate(),
                aggregatedBookSink
        );

        return new AggregatedBookManager(Market.WSP_U, changedMidRateConsumers, NoConsumer.instance());
    }

    @Bean(name = "referenceAggregatedBookManager")
    public AggregatedBookManager getReferenceAggregatedBookManager(final DataRegisters dataRegisters,
                                                                   final PricingFirewallManager pricingFirewallManager,
                                                                   final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager,
                                                                   final HedgeManager hedgeManager,
                                                                   @Qualifier("marketDataSink") final Consumer<MidRate> aggregatedBookSink) {

        final Consumer<MidRate> changedMidRateConsumers = new NotifierDefault<>(
                dataRegisters.consumerOfMidRate(),
                pricingFirewallManager.consumerOfReferenceMidRate(),
                driverInstrumentWholesaleBookManager.consumerOfReferenceMidRate(),
                hedgeManager.consumerOfAggregatedBookMidRate(),
                aggregatedBookSink);

        return new AggregatedBookManager(Market.WSP_R, changedMidRateConsumers, NoConsumer.instance());
    }

    @Bean
    public TriangulatedMidRateManager triangulatedMidRateManager(final PositionManager positionManager,
                                                                 final HedgeFirewallManager hedgeFirewallManager,
                                                                 final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
                                                                 final RiskPathManager riskPathManager) {

        final NotifierDefault<MidRate> notifierDefault = new NotifierDefault<>(
                positionManager.consumerOfMidRate(),
                hedgeFirewallManager.consumerOfMidRate(),
                hedgersRevalProfitAndLossManager.consumerOfMidRate(),
                riskPathManager.consumerOfMidRate());
        return new TriangulatedMidRateManager(notifierDefault);
    }

    //###########
    // pricer components

    @Bean
    public RiskReducingFlowManager riskReducingFlowManager(final DataRegisters dataRegisters) {
        return new RiskReducingFlowManager(dataRegisters);
    }

    @Bean
    public StanddownMidHedgersOnNoSkewFeature standdownMidHedgersOnNoSkewFeature(final Consumer<HedgePauseSignal> hedgePauseSignalSink, final HedgeManager hedgeManager) {
        return new StanddownMidHedgersOnNoSkewFeature(new NotifierDefault(hedgePauseSignalSink,hedgeManager.consumerOfHedgePauseSignal()));
    }

    @Bean
    public PauseSkewFeature pauseSkewFeature(@Qualifier("skewCurrencyControlSink") final Consumer<SkewCurrencyControl> skewCurrencyControlSink) {
        return new PauseSkewFeature(skewCurrencyControlSink);
    }

    @Bean
    public ManualSkewFeature manualSkewFeature(SkewConfigProvider skewConfigProvider) {
        return new ManualSkewFeature(skewConfigProvider);
    }

    @Bean
    public SkewConfigProvider skewConfigProvider() {
        return new SkewConfigProvider();
    }

    @Bean
    public ForwardPointManager forwardPointManager(final DataRegisters dataRegisters, final CrossRateManager crossRateManager) {
        return new ForwardPointManager(dataRegisters, crossRateManager.consumerForwardPointCurve());
    }

    @Bean
    public DataRegisters dataRegisters() {
        return new DataRegisters();
    }

    @Bean
    public ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager(@NotNull final DataRegisters dataRegisters) {
        return new ClientPriceDataRegisterDependencyManager(dataRegisters);
    }

    @Bean
    public VolatilityControlManager volatilityControlManager(
            @Qualifier("volatilityControlSink") final Consumer<VolatilityControl> volatilityControlSink) {
        return new VolatilityControlManager(volatilityControlSink);
    }

    @Bean
    public NDFClientPriceManager ndfClientPriceManager(@NotNull final PricingFirewallManager pricingFirewallManager) {
        final NotifierDefault<ClientPrice> clientPriceNotifier = new NotifierDefault<ClientPrice>().register(pricingFirewallManager.consumerClientPrice());
        return new NDFClientPriceManager(clientPriceNotifier);
    }


    @Bean
    public DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager(
            final SkewConfigProvider skewConfigProvider,
            final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager,
            final StanddownMidHedgersOnNoSkewFeature standdownMidHedgersOnNoSkewFeature,
            final ManualSkewFeature manualSkewFeature,
            final PauseSkewFeature pauseSkewFeature,
            final VolatilityControlManager volatilityControlManager,
            final NDFClientPriceManager ndfClientPriceManager,
            final SignalRegisters signalRegisters,
            @Qualifier("wholesaleBookFactorsSink") final Consumer<WholesaleBookFactors> wholesaleBookFactorsSink,
            @Value("${data.collection.enabled:true}") final boolean calculationDataCollectionEnabledForThisEnv,
            @Value("${backtest.enabled:false}") final boolean backTestEnabled,
            @Value("${backtest.disable.pricing:false}") final boolean backtestDisablePricing) {
        final NotifierDefault<ClientPrice> clientPriceNotifier = new NotifierDefault<ClientPrice>().register(ndfClientPriceManager.consumerClientPrice());
        final NotifierDefault<WholesaleBookFactors> wholesaleBookFactorsNotifier = new NotifierDefault<WholesaleBookFactors>().register(wholesaleBookFactorsSink);
        DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager = new DriverInstrumentWholesaleBookManager(clientPriceNotifier, wholesaleBookFactorsNotifier,
                skewConfigProvider,
                standdownMidHedgersOnNoSkewFeature,
                manualSkewFeature,
                pauseSkewFeature,
                new ManualSpreadStrategy(volatilityControlManager.volatilityFactorCache()),
                new VolatilitySpreadStrategy(), //can initialise percentile factors from data file if needed
                new EconomicsNewsSpreadStrategy(),
                new RiskAdjustedSpreadStrategy(),
                new BenchmarkSpreadStrategy(),
                new MarketGapSpreadAdjustmentStrategy(),
                new ArbitrageSpreadStrategy(),
                new OverallSpreadFormationStrategy(),
                new DriverStackSpreadAndWeightCalculatorImpl(),
                new DriverStackFromBandedCalculatorImpl(),
                clientPriceDataRegisterDependencyManager,
                signalRegisters,
                calculationDataCollectionEnabledForThisEnv,
                backTestEnabled);
        driverInstrumentWholesaleBookManager.setDisablePriceFormation(backTestEnabled && backtestDisablePricing);
        pauseSkewFeature.setRecalculateConsumer(driverInstrumentWholesaleBookManager::recalculateOnCurrencyConfigChange);
        clientPriceDataRegisterDependencyManager.setDriverInstrumentWholesaleBookManager(driverInstrumentWholesaleBookManager);
        volatilityControlManager.setDriverInstrumentWholesaleBookManager(driverInstrumentWholesaleBookManager);
        return driverInstrumentWholesaleBookManager;
    }

    @Bean
    public CrossRateManager crossRateManager(@NotNull final InverseRateManager inverseRateManager,
                                             @Value("${backtest.enabled:false}") final boolean backTestEnabled,
                                             @Value("${backtest.disable.crossrates:false}") final boolean disableCrossRateFormation) {
        final MidRateToBaseCache midRateToBaseProvider = new MidRateToBaseCache();
        final CrossRateCalculator calculator = new CrossRateCalculator(midRateToBaseProvider,backTestEnabled);
        CrossRateManager crossRateManager = new CrossRateManager(calculator, midRateToBaseProvider, inverseRateManager.consumerOfClientPrice());
        crossRateManager.setDisableCrossRateFormation(backTestEnabled && disableCrossRateFormation);
        return crossRateManager;
    }

    @Bean
    public InverseRateManager inverseRateManager(@NotNull final ClientPriceThrottleManager clientPriceThrottleManager,
                                                 final TrueThrottleManager trueThrottleManager) {
        return new InverseRateManager(new NotifierDefault<>(clientPriceThrottleManager.consumerClientPrice(),trueThrottleManager.consumerClientPrice()));
    }

    @Bean
    public PricingFirewallManager pricingFirewallManager(@NotNull final CrossRateManager crossRateManager,
                                                         final DataRegisters dataRegisters,
                                                         @Value("${backtest.enabled:false}") final boolean backTestEnabled) {
        final NotifierDefault<ClientPrice> clientPriceNotifier = new NotifierDefault<ClientPrice>().register(crossRateManager.consumerClientPrice());
        return new PricingFirewallManager(clientPriceNotifier,dataRegisters,backTestEnabled);
    }

    @Bean
    public Consumer<PricingFirewallReset> firewallResetConsumer(
            @NotNull final PricingFirewallManager pricingFirewallManager) {
        return pricingFirewallManager.consumerFirewallReset();
    }

    @Bean
    public VolumeManager volumeManager(@NotNull final Consumer<Volume> volumeConsumer) {
        return new VolumeManager(volumeConsumer);
    }

    @Bean
    public ClientPriceThrottleManager clientPriceThrottleManager(@NotNull final ClientPriceEnricher clientPriceEnricher,
                                                                 @Value("${throttler.should.publish.all:true}") final boolean publishAll) {
        return new ClientPriceThrottleManager(clientPriceEnricher.consumerClientPrice(), publishAll);
    }

    @Bean
    public TrueThrottleManager trueThrottleManager(@NotNull final ClientPriceEnricher clientPriceEnricher,
                                                   @Value("${throttler.should.publish.all:true}") final boolean publishAll,
                                                   @Value("${backtest.enabled:false}") final boolean backTestEnabled) {
        return new TrueThrottleManager(clientPriceEnricher.consumerClientPrice(), publishAll, backTestEnabled);
    }

    @Bean
    public ClientPriceEnricher clientPriceEnricher(@NotNull final Consumer<ClientPrice> clientPriceSink) {
        return new ClientPriceEnricher(clientPriceSink);
    }

    //###########
    // hedging components
    @Bean
    public Consumer<Adjustment> biasAdjustmentSink(final RiskPathManager riskPathManager) {
        return riskPathManager.consumerOfAdjustment();
    }

    @Bean
    public RiskPathManager riskPathManager(final Consumer<RiskPath> riskPathSink) {
        return new RiskPathManager(riskPathSink);
    }

    @Bean
    public Consumer<HedgeControl> hedgeControlConsumer(final HedgeManager hedgeManager,
                                                       final HedgeFirewallManager hedgeFirewallManager) {
        return new NotifierDefault<>(hedgeFirewallManager.consumerOfHedgeControl(), hedgeManager.consumerOfHedgeControl());
    }

    @Bean
    public Consumer<HedgeCurrencyControl> hedgeCurrencyControlConsumer(final HedgeManager hedgeManager) {
        return hedgeManager.consumerOfHedgeCurrencyControl();
    }

    @Bean
    public HedgeManager hedgeManager(@Value("${hedger.canSendOrders:false}") final boolean canSendOrders,
                                     @Value("${hedger.autoAcknowledgeOrders:false}") final boolean autoAcknowledge,
                                     final Consumer<Order> orderSink,
                                     final Consumer<HedgeStatus> hedgeStatusSink,
                                     final Consumer<HedgeDecision> hedgeDecisionSink,
                                     @Qualifier("hedgeCurrencyControlSink") final Consumer<HedgeCurrencyControl> hedgeCurrencyControlSink) {
        return new HedgeManager(canSendOrders, autoAcknowledge, orderSink, hedgeStatusSink, hedgeDecisionSink, hedgeCurrencyControlSink);
    }

    // temporarily disable hedgefirewall - issues with nan rate firing 40k per sec in pink
    @Bean
    public HedgeFirewallManager hedgeFirewallManager(
            @Value("${hedger.firewall.maxTradeCountForRevalPnlLossPerMin:1000}") final int maxTradeCountForRevalPnlLossPerMin,
            @Value("${hedger.firewall.maxTradeCountForRevalPnlLossPerHour:5000}") final int maxTradeCountForRevalPnlLossPerHour,
            @Value("${hedger.firewall.maxTradeCountForRevalPnlLossPerDay:15000}") final int maxTradeCountForRevalPnlLossPerDay,
            @Value("${hedger.firewall.maxTradeCountForRevalPnlProfitPerDay:15000}") final int maxTradeCountForRevalPnlProfitPerDay,

            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlLossPerMin:1000}") final int maxTradeCountForAggregatedPnlLossPerMin,
            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlLossPerHour:5000}") final int maxTradeCountForAggregatedPnlLossPerHour,
            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlLossPerDay:15000}") final int maxTradeCountForAggregatedPnlLossPerDay,
            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlProfitPerDay:15000}") final int maxTradeCountForAggregatedPnlProfitPerDay,

            @Value("${hedger.firewall.maxTradeCountForRealisedPositionPer30Sec:1000}") final int maxTradeCountForRealisedPositionPerMin,
            @Value("${hedger.firewall.maxTradeCountForUnrealisedPositionPer30Sec:1000}") final int maxTradeCountForUnrealisedPositionPerMin,
            @Value("${hedger.firewall.maxTradeCountBeforeRevalTime:400}") final int maxTradeCountBeforeRevalTime,
            @Value("${hedger.firewall.maxTradeCountForVolumeInOneHour:400}") final int maxTradeCountForVolumeInOneHour,
            final HedgeManager hedgeManager,
            final Consumer<HedgeFirewallStatus> hedgeFirewallStatusSink) {

        final EnumDoubleMap<HedgeFirewallType> maxTradeCountByType = new EnumDoubleMap<>(HedgeFirewallType.class);
        maxTradeCountByType.put(REVAL_PNL_LOSS_PER_MIN, maxTradeCountForRevalPnlLossPerMin);
        maxTradeCountByType.put(REVAL_PNL_LOSS_PER_HOUR, maxTradeCountForRevalPnlLossPerHour);
        maxTradeCountByType.put(REVAL_PNL_LOSS_PER_DAY, maxTradeCountForRevalPnlLossPerDay);
        maxTradeCountByType.put(REVAL_PNL_PROFIT_PER_DAY, maxTradeCountForRevalPnlProfitPerDay);

        maxTradeCountByType.put(AGGREGATED_PNL_LOSS_PER_MIN, maxTradeCountForAggregatedPnlLossPerMin);
        maxTradeCountByType.put(AGGREGATED_PNL_LOSS_PER_HOUR, maxTradeCountForAggregatedPnlLossPerHour);
        maxTradeCountByType.put(AGGREGATED_PNL_LOSS_PER_DAY, maxTradeCountForAggregatedPnlLossPerDay);
        maxTradeCountByType.put(AGGREGATED_PNL_PROFIT_PER_DAY, maxTradeCountForAggregatedPnlProfitPerDay);

        maxTradeCountByType.put(REALISED_POSITION_PER_30_SEC, maxTradeCountForRealisedPositionPerMin);
        maxTradeCountByType.put(UNREALISED_POSITION_PER_30_SEC, maxTradeCountForUnrealisedPositionPerMin);
        maxTradeCountByType.put(MAXIMUM_TRADE_VOLUME_PER_HOUR, maxTradeCountForVolumeInOneHour);

        final NotifierDefault<HedgeFirewallStatus> hedgeFirewallStatusConsumer = new NotifierDefault<>(hedgeManager.consumerOfHedgeFirewallStatus(), hedgeFirewallStatusSink);
        // hedge manager consume firewall status, firewall manager consume order so can't register both in each constructor
        final HedgeFirewallManager hedgeFirewallManager = new HedgeFirewallManager(hedgeFirewallStatusConsumer, maxTradeCountByType, maxTradeCountBeforeRevalTime);

        hedgeManager.registerOrderConsumer(hedgeFirewallManager.consumerOfOrder());
        return hedgeFirewallManager;
    }

    @Bean
    public HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager(
            final Consumer<ProfitAndLoss> profitAndLossSink,
            @Value("${hedger.pnl.maxTradeCountBeforeRevalTime:400}") final int maxTradeCountBeforeRevalTime) {
        return new HedgersRevalProfitAndLossManager(profitAndLossSink, maxTradeCountBeforeRevalTime);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public Consumer<HedgerFirewallReset> hedgerFirewallResetConsumer(final HedgeFirewallManager hedgeFirewallManager) {
        return hedgeFirewallManager.consumerOfHedgerFirewallReset();
    }
}
