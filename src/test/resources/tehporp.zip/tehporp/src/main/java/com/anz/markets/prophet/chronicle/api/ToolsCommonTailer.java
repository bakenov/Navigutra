package com.anz.markets.prophet.chronicle.api;

public interface ToolsCommonTailer {
    long position();
    long index();
    void position(long position);
}