package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LatencyFilterConfig;
import com.anz.markets.prophet.domain.Market;
import org.jetbrains.annotations.NotNull;

public class LatencyFilterConfigImpl implements LatencyFilterConfig, ProphetMarshallable {

    private final Market market;
    private final long latencyMs;

    public LatencyFilterConfigImpl(final Market market,
                                   final long latencyMs) {
        this.market = market;
        this.latencyMs = latencyMs;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public long getLatencyMs() {
        return latencyMs;
    }

    public static ProphetMarshallable constructReadMarshallable(final ProphetBytes in) {
        return new LatencyFilterConfigImpl(in.readEnum(Market.class), in.readLong());
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        // no mutable fields
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        FieldReflectionBytesMarshallable.INSTANCE.write(this, out);
    }

    @Override
    public String toString() {
        return "LatencyFilterConfigImpl{" +
                "market=" + market +
                ", latencyMs=" + latencyMs +
                '}';
    }
}
