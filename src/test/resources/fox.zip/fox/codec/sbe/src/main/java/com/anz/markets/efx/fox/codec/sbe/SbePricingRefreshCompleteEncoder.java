package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringEncoders;

public final class SbePricingRefreshCompleteEncoder implements PricingRefreshCompleteEncoder, PricingRefreshCompleteEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteEncoder pricingRefreshCompleteEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();

    private EncodingOrder.PricingRefreshComplete encodingOrder = EncodingOrder.PricingRefreshComplete.INITIAL;

    SbePricingRefreshCompleteEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                                     final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public PricingRefreshCompleteEncoder.Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        pricingRefreshCompleteEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.PricingRefreshComplete.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        pricingRefreshCompleteEncoder.buffer().setMemory(offset, pricingRefreshCompleteEncoder.sbeBlockLength(), NULL);
    }


    @Override
    public Body instrumentId(final long instrumentId) {
        encodingOrder.checkStrict(EncodingOrder.PricingRefreshComplete.BODY);
        pricingRefreshCompleteEncoder.instrumentId(instrumentId);
        return this;
    }

    @Override
    public MessageEncoder.Trailer forceSnapshot(final boolean forceSnapshot) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.PricingRefreshComplete.TRAILER);
        pricingRefreshCompleteEncoder.forceSnapshot(forceSnapshot ? YesNo.YES : YesNo.NO);
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.PricingRefreshComplete.TRAILER);
                message.messageLength(headerLength + pricingRefreshCompleteEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.PricingRefreshComplete.INITIAL;
                headerEncoder.wrap(null, 0);
                pricingRefreshCompleteEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
