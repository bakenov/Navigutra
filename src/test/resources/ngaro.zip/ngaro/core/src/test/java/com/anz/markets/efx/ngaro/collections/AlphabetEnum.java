package com.anz.markets.efx.ngaro.collections;

public enum AlphabetEnum {
    A,
    B,
    C,
    D,
    X,
    Y,
    Z;
}
