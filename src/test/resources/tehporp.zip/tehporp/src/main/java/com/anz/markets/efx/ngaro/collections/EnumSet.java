package com.anz.markets.efx.ngaro.collections;

import java.util.function.Consumer;


public class EnumSet<K extends Enum<K>> extends EnumDoubleMap<K> {
    private final double IS_SET = 1;

    public EnumSet(final Class<K> keyType) {
        super(keyType);
    }

    public boolean contains(final K value) {
        return containsKey(value);
    }

    /**
     * adds value to set
     *
     * @param value
     * @return true if value was added, false if it was there before
     */
    public boolean add(final K value) {
        return put(value, IS_SET) != IS_SET;
    }

    public void addAll(EnumSet<K> other) {
        other.forEach((k, value) -> add(k));
    }

    public void forEach(Consumer<K> action) {
        forEach((k, value) -> action.accept(k));
    }

    @NotGcFriendly
    @Override
    public String toString() {
        final ToStringHelpers.CollectKeys toStringCollector = new ToStringHelpers.CollectKeys();
        forEach(toStringCollector);
        return toStringCollector.toString();
    }
}
