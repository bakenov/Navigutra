package com.anz.axle.lg.adapter.citi.quickfix;

import org.junit.Test;

import quickfix.DoubleField;
import quickfix.IntField;
import quickfix.StringField;
import quickfix.field.Currency;
import quickfix.field.OrderQty;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteRequestType;
import quickfix.field.QuoteType;
import quickfix.field.Symbol;
import quickfix.field.TargetSubID;
import quickfix.fix44.QuoteRequest;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CitiMarketDataRequestEncoderTest {
    private static final double TOLERANCE = 0.00000001;

    @Test
    public void citiFWTestMarketDataSubscription() throws Exception {
        final String requestId = "34214521";
        final CitiMarketDataRequestEncoder encoder = new CitiMarketDataRequestEncoder("", true);
        final MarketDataSubscription subscription = mock(MarketDataSubscription.class);
        when(subscription.instrumentKey()).thenReturn(InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP));
        when(subscription.symbol()).thenReturn("AUD/USD");

        final QuoteRequest quoteRequest = encoder.encodeSubscribe(Integer.parseInt(requestId), subscription);

        final QuoteReqID quoteReqId = quoteRequest.getQuoteReqID();
        final StringField targetSubID = quoteRequest.getHeader().getField(new TargetSubID());
        final QuoteRequest.NoRelatedSym noRelatedSymGroup = new QuoteRequest.NoRelatedSym();
        quoteRequest.getGroup(1, noRelatedSymGroup);
        final double quantityType = noRelatedSymGroup.getDouble(OrderQty.FIELD);
        final Symbol symbol = noRelatedSymGroup.getSymbol();
        final StringField currency = noRelatedSymGroup.getField(new Currency());
        final IntField quoteRequestType = noRelatedSymGroup.getField(new QuoteRequestType());
        final IntField quoteType = noRelatedSymGroup.getField(new QuoteType());
        
        assertEquals(quoteReqId.getValue(), requestId);
        assertEquals(-1d, quantityType, 0.000001); // TIERED_MASS_QUOTE = -1
        assertNotNull(targetSubID.getValue());
        assertEquals(quoteRequestType.getValue(), QuoteRequestType.AUTOMATIC);
        assertEquals(quoteType.getValue(), QuoteType.RESTRICTED_TRADEABLE);
        assertEquals(symbol.getValue(), "AUDUSD");
        assertEquals(currency.getValue(), "AUD");
    }

    @Test
    public void citiTestMarketDataSubscription() throws Exception {
        final String requestId = "34214521";
        final CitiMarketDataRequestEncoder encoder = new CitiMarketDataRequestEncoder("", false);
        final MarketDataSubscription subscription = mock(MarketDataSubscription.class);
        when(subscription.instrumentKey()).thenReturn(InstrumentKey.of("AUDUSD"));
        when(subscription.symbol()).thenReturn("AUD/USD");

        final QuoteRequest quoteRequest = encoder.encodeSubscribe(Integer.parseInt(requestId), subscription);

        final QuoteReqID quoteReqId = quoteRequest.getQuoteReqID();
        final StringField targetSubID = quoteRequest.getHeader().getField(new TargetSubID());
        final QuoteRequest.NoRelatedSym noRelatedSymGroup = new QuoteRequest.NoRelatedSym();
        quoteRequest.getGroup(1, noRelatedSymGroup);
        final Symbol symbol = noRelatedSymGroup.getSymbol();
        final StringField currency = noRelatedSymGroup.getField(new Currency());
        final IntField quoteRequestType = noRelatedSymGroup.getField(new QuoteRequestType());
        final IntField quoteType = noRelatedSymGroup.getField(new QuoteType());

        assertEquals(quoteReqId.getValue(), requestId);
        assertNotNull(targetSubID.getValue());
        assertEquals(false, noRelatedSymGroup.isSetField(OrderQty.FIELD));
        assertEquals(quoteRequestType.getValue(), QuoteRequestType.AUTOMATIC);
        assertEquals(quoteType.getValue(), QuoteType.RESTRICTED_TRADEABLE);
        assertEquals(symbol.getValue(), "AUDUSD");
        assertEquals(currency.getValue(), "AUD");
    }
}
