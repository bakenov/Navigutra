package com.anz.markets.disco.data;

public enum SignalType {
    CBID(0),
    CASK(1),
    TV1(2),
    TV2(3),
    TV3(4),
    TVS(5),
    PES(6);

    private final byte id;

    private static final SignalType[] VALUES = SignalType.values();

    SignalType(final int id) {
        this.id = (byte) id;
    }

    public byte getId() {
        return id;
    }

    public static SignalType valueOf(final byte value) {
        return VALUES[Byte.toUnsignedInt(value)];
    }

    public static SignalType[] getValues() {
        return VALUES;
    }
}