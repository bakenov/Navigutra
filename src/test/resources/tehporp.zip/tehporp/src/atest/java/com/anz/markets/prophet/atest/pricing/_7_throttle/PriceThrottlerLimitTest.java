package com.anz.markets.prophet.atest.pricing._7_throttle;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.pricing._3_spread.ModelSpread_Risk_Adjusted_Spread_Factor_Test;
import com.anz.markets.prophet.atest.pricing._8_sanity.PriceBarrierFirewallTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.RiskAdjustedFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.ThrottlerPublishReason;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.PricingFirewallTypeMatcher;
import com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

@Requirement({Ref.PRICING_4_8_2, Ref.PRICING_4_8_3})
@RestartBeforeTest(reason = "clear prices")
public class PriceThrottlerLimitTest extends BaseAcceptanceSpecification {

    @Test
    @DisplayName("Output price frequency equal to normal limit")
    public void outputPriceFrequencyAtLimit() {
        final double minPriceDeltaFractionOfSpread = 0.01;
        final int normalFrequencyMS = 100, reps = 20;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.USD, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.USD, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.USD, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
            );
        }
        when:
        {
            final double skew = 0.00001;
            for (int i = 0; i < reps; i++) {
                prophet.incrementTime(normalFrequencyMS);
                prophet.receive(tdd.skew(skew * i, tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75000, 0.00001)));
            }
        }
        then:
        {
            // expects at least $reps price heartbeat message
            LinkedList<ClientPrice> clientPriceList = prophet.expect(ClientPrice.class, exactly(reps), isPublishable(Market.WSP_C));

            // all prices are NOT the same.
            for (int i = 0; i < clientPriceList.size() - 1; i++) {
                assertThat(clientPriceList.get(i), not(isClientPrice(clientPriceList.get(i + 1))));
            }
        }
    }

    @Test
    @RelatedTest(ModelSpread_Risk_Adjusted_Spread_Factor_Test.class)
    // given_long_position_apply_risk_adjusted_spread_to_bid_side()
    @DisplayName("Client Spread changed but mid unchanged - price still published")
    public void clientSpreadChangeLessThanMinPrice() {
        /**
         *  AXPROPHET-990
         *  if spread WIDENS(only) while mid unchanged we will now PUBLISH.
         *  (prior to this we would drop the price)
         */
        Instrument driverPairA = Instrument.AUDUSD;
        Instrument driverPairB = Instrument.USDJPY;
        Instrument driverPairC = Instrument.AUDJPY;
        final double minimumPriceDeltaFractionOfSpread = 0.251;
        final int normalFrequencyMS = 100;

        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.USD, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.USD, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.USD, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.USD, Currency.JPY, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.USD, Currency.JPY, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.USD, Currency.JPY, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.JPY, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.JPY, minimumPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.JPY, minimumPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, true))
                    .setRiskAdjustedSpreadParams(Arrays.asList(
                            new RiskAdjustedFactor(0.0, 0.0),
                            new RiskAdjustedFactor(0.5, 1.25),
                            new RiskAdjustedFactor(1.0, 1.5),
                            new RiskAdjustedFactor(1.4, 2.0)
                    ))
                    .setMaxSkewQuantities(Arrays.asList(
                            new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 3000000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7000000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.USD, 7000000.0)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003)); // no OP change as position=0
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(3), isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getSpread() * 10000, isRoundedTo(0.3));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420)); // Trigger : position created
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));

            // LONG 3.6mio is between (3.0mio MaxSkewQuantities * 1 RiskAdjustedFactor) band and
            // and (3.0mio MaxSkewQuantities * 1.4 RiskAdjustedFactor) bands.
            // Therefore apply factor(1.5) to AUD base pairs
            // Since AUD/USD equiv USD position is LONG, apply factor to BID SIDE
            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 5000000, 4822047.659692364, 3621357.792428965, 6976028.347724075, 5238997.28914078, 0.13059209393878018, 0.75100)));

            // minimumPriceDeltaFractionOfSpread = 0.251, BaseSpread = 0.3pip => min movement = 0.251*0.3 = 0.0753 pip
            // New Client Price spread = 0.375
            // Spread Movement = 0.3 - 0.375 = |-0.0750|
            // Mid Movement < min movement  => price now published as of AXPROPHET-990
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Instrument.AUDUSD)).getFirst();
            assertThat(wholesaleBookFactors.getInstrument(), is(Instrument.AUDUSD));
            assertThat(wholesaleBookFactors.getModelSpread(), is(0.375));
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getThrottlerPublishReason(), is(ThrottlerPublishReason.TIME_PRICE));
        }
//        when:
//        // to prove price was not queued
//        {
//            prophet.clearOutputBuffer();
//            prophet.incrementTime(50);
//            // another piece of market data kicks the time signal
//            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
//        }
//        then:
//        {
//            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
//        }
    }

    @Test
    @DisplayName("Client Mid change less than min - price dropped")
    public void clientMidChangeLessThanMinPriceFiltered() {
        final double minPriceDeltaFractionOfSpread = 0.126;
        final int normalFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A, Instrument.USDCHF));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01001, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfSpread = 0.126, BaseSpread = 0.8pip, Min movement = 0.126*0.8 = 0.1008 pip
            // Mid movement of 0.1pip < 0.1008 pip => price dropped/not queued
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCHF, Market.WSP_A)).getFirst();
            // PriceThrottleState.UNPUBLISHED means that the price is throttled and will not be sent downstream
            // it is the responsibility of the price publisher gateway in  m3axle to adhere to this contract
            assertThat(clientPrice.getThrottlerPublishReason(), is(ThrottlerPublishReason.UNPUBLISHED));

            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50);
            // another piece of market data kicks the time signal
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCHF, Market.WSP_A));
        }
    }

    @Test
    @DisplayName("Client Mid positive change equals min - price published")
    public void clientMidPositiveChangeEqualsMinPricePublished() {
        final double minPriceDeltaFractionOfSpread = 0.125;
        final int normalFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_Z, Currency.CHF, Currency.JPY, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A, Instrument.USDCHF));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01001, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.125, BaseSpread = 0.8pip, Min movement = 0.128*0.8 = 0.1pip
            // Mid movement of 0.1pip == 0.1 pip  => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.01001));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50);
            // another piece of market data kicks the time signal
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF));
        }
    }

    @Test
    @DisplayName("Client Mid negative change equals min - price published")
    public void clientMidNegativeChangeEqualsMinPricePublished() {
        final double minPriceDeltaFractionOfSpread = 0.125;
        final int normalFrequencyMS = 100;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00999, 0.00008));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.125, BaseSpread = 0.8pip, Min movement = 0.128*0.8 = 0.1pip
            // Mid movement of 0.1pip == 0.1 pip  => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00999));
        }
    }

    @Test
    @RelatedTest(PriceBarrierFirewallTest.class) // trigger_when_bid_over_ceiling()
    @DisplayName("Change in quote type still publishable even when limit reached")
    public void limitReachedChangeInQuoteTypeStillPublishable() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, true))
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48510, 0.00004));
        }

        then:
        {
            // EUR/DKK BID price is EQUAL to CEILING limit(7.4850). Firewall NOT triggered
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.EURDKK)).getFirst();

            // DKK client prices still FIRM
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, atLeast(2), isClientPriceInstrument(crossPair)).getLast();
            assertThat(clientPriceUSDDKK.getBidQuoteType(), is(QuoteType.FIRM));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48520, 0.00004));
        }

        then:
        // expect firewall to be triggered for DKK pairs.
        {
            // EUR/DKK BID price is GREATER then CEILING limit(7.4850). Firewall triggered for DKK pairs
            // Even though we are still in the initial window, prices are still PUBLISHABLE as we have switched from FIRM TO INDICATIVE
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK.getBidQuoteType(), is(QuoteType.INDICATIVE));

            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDDKK)).getFirst();
            assertThat(clientPriceUSDDKK.getBidQuoteType(), is(QuoteType.INDICATIVE));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48510, 0.00004));
        }

        then:
        {
            // EUR/DKK BID price is EQUAL to CEILING limit(7.4850). Firewall NOT triggered
            // Even though we are still in the initial window, prices are still PUBLISHABLE as we have switched from INDICATIVE TO FIRM
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK.getBidQuoteType(), is(QuoteType.FIRM));

            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDDKK)).getFirst();
            assertThat(clientPriceUSDDKK.getBidQuoteType(), is(QuoteType.FIRM));
        }
    }

    @Test
    @DisplayName("cross pair uses tightest spread of the driver pairs - price NOT publishable")
    public void crossPairNotPublishableTest() throws Exception {
        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverPairB = Instrument.EURUSD;
        final Instrument crossPair = Instrument.EURAUD;
        final double minPriceDeltaFractionOfSpread = 0.33;
        final int normalFrequencyMS = 100;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.EUR, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.EUR, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.EUR, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.EUR, Currency.AUD, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.EUR, Currency.AUD, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.EUR, Currency.AUD, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
                    .setSyntheticInstrumentConfigs(Arrays.asList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.EURAUD).setMarkets("WSP_A|WSP_B|WSP_C"),
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDEUR).setMarkets("WSP_A|WSP_B|WSP_C")
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.EUR, Currency.AUD, Market.WSP_A, 1.0)

                    ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5)
                    ));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.12985, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.76105, 0.00004));
        }

        then:
        {
            ClientPrice clientPriceEURAUD = prophet.expect(ClientPrice.class, atLeast(2), isPublishable(Market.WSP_A, crossPair)).getLast();
            assertThat(clientPriceEURAUD.getMidRate(), isRoundedTo(1.484594));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.12984, 0.00004));
        }

        then:
        {   // AEURUSD publishable
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, driverPairB)).getFirst();

            // Driver pairs tightest spread = 0.00004
            // min movement required EUR/AUD = 0.33 * 0.00004 = 0.0000132
            // change in EUR/AUD mid = |1.484594 - 1.484581| = 0.000013 < 0.0000132  ==> NOT PUBLISHABLE
            ClientPrice clientPriceEURAUD = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A, crossPair)).getFirst();
            assertThat(clientPriceEURAUD.getMidRate(), isRoundedTo(1.484581));
        }
    }

    @Test
    @DisplayName("cross pair uses tightest spread of the driver pairs - price publishable")
    public void crossPairPublishableTest() throws Exception {
        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverPairB = Instrument.EURUSD;
        final Instrument crossPair = Instrument.EURAUD;
        final double minPriceDeltaFractionOfSpread = 0.32;
        final int normalFrequencyMS = 100;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.EUR, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.EUR, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.EUR, Currency.USD, 0.1, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_A, Currency.EUR, Currency.AUD, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_B, Currency.EUR, Currency.AUD, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            clientPriceConfigNormalThrottle(Market.WSP_C, Currency.EUR, Currency.AUD, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
                    .setSyntheticInstrumentConfigs(Arrays.asList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.EURAUD).setMarkets("WSP_A|WSP_B|WSP_C"),
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDEUR).setMarkets("WSP_A|WSP_B|WSP_C")
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.EUR, Currency.AUD, Market.WSP_A, 1.0)

                    ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5)
                    ));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.12985, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.76105, 0.00004));
        }

        then:
        {
            ClientPrice clientPriceEURAUD = prophet.expect(ClientPrice.class, atLeast(2), isPublishable(Market.WSP_A, crossPair)).getLast();
            assertThat(clientPriceEURAUD.getMidRate(), isRoundedTo(1.484594));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.12984, 0.00004));
        }

        then:
        {   // AEURUSD publishable
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, driverPairB)).getFirst();

            // Driver pairs tightest spread = 0.00004
            // min movement required EUR/AUD = 0.32 * 0.00004 = 0.0000128
            // change in EUR/AUD mid = |1.484594 - 1.484581| = 0.000013 > 0.0000128  ==> PUBLISHABLE

            ClientPrice clientPriceEURAUD = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, crossPair)).getFirst();
            assertThat(clientPriceEURAUD.getMidRate(), isRoundedTo(1.484581));
        }
    }

    @Test
    @DisplayName("AXPROPHET-706 config change results in pushing INDICATIVE price")
    public void postConfigChangeForcePushIndicative() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01000, 0.00008));

        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDCHF, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.01000));
            prophet.clearOutputBuffer();
        }
        when:
        // receive incremental update such that WSP_U TOB Bidd/Offer unchanged from previous
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.configuration_pricing_base(), false);
        }
        then:
        // publish previous client price
        {
            ClientPrice clientPriceWSPA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceMarket(Market.WSP_A)).getFirst();
            assertThat(clientPriceWSPA.getMidRate(), isRoundedTo(1.01000));

            assertThat("Quote type on BID side should be INDICATIVE", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPA, new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.CONFIGURATION_CHANGED));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPA, new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.CONFIGURATION_CHANGED));

            ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceMarket(Market.WSP_B)).getFirst();
            assertThat(clientPriceWSPB.getMidRate(), isRoundedTo(1.01000));

            assertThat("Quote type on BID side should be INDICATIVE", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPB, new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.CONFIGURATION_CHANGED));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPB, new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.CONFIGURATION_CHANGED));

            ClientPrice clientPriceWSPC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceMarket(Market.WSP_C)).getFirst();
            assertThat(clientPriceWSPC.getMidRate(), isRoundedTo(1.01000));

            assertThat("Quote type on BID side should be INDICATIVE", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPC, new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.CONFIGURATION_CHANGED));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPC, new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.CONFIGURATION_CHANGED));
        }
        when:
        {
            prophet.clearOutputBuffer();
//            // incremental update with wider OFFER price
//            prophet.receive(tdd.marketDataIncrementNew(Instrument.USDCHF, 1.01005, OrderSide.OFFER));

            // AXPROPHET-1300 TOB MID must change by 10th pip to trigger price formation
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.01001, 0.00008));
        }
        then:
        {
            ClientPrice clientPriceWSPA = prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A)).getFirst();
            assertThat(clientPriceWSPA.getMidRate(), isRoundedTo(1.01001));

            assertThat("Quote type on BID side should be FIRM", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.FIRM));
            assertThat(clientPriceWSPA, new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.FIRM));
            assertThat(clientPriceWSPA, new PricingFirewallTypeMatcher(OrderSide.OFFER));

            ClientPrice clientPriceWSPB = prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_B)).getFirst();
            assertThat(clientPriceWSPB.getMidRate(), isRoundedTo(1.01001));

            assertThat("Quote type on BID side should be FIRM", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.FIRM));
            assertThat(clientPriceWSPB, new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.FIRM));
            assertThat(clientPriceWSPB, new PricingFirewallTypeMatcher(OrderSide.OFFER));

            ClientPrice clientPriceWSPC = prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_C)).getFirst();
            assertThat(clientPriceWSPC.getMidRate(), isRoundedTo(1.01001));

            assertThat("Quote type on BID side should be FIRM", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.FIRM));
            assertThat(clientPriceWSPC, new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.FIRM));
            assertThat(clientPriceWSPC, new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    public static ClientPriceThrottleConfigImpl clientPriceConfigNormalThrottle(final Market market,
                                                                                Currency baseCurrency, Currency termsCurrency,
                                                                                final double minPriceDeltaFractionOfSpread,
                                                                                final int normalFrequencyMS) {
        return new ClientPriceThrottleConfigImpl(market, baseCurrency, termsCurrency)
                .setNoActivityHeartbeatFrequencyMs(DONT_CARE_LARGE_LONG)
                .setLimit(1)
                .setTimePeriod(normalFrequencyMS)
                .setMinimumPriceDeltaFractionOfSpread(minPriceDeltaFractionOfSpread)
                .setOverrideLimit(1)
                .setOverrideTimePeriod(DONT_CARE_LARGE_LONG)
                .setOverrideMinimumPriceDeltaFractionOfMid(DONT_CARE_LARGE_LONG);
    }
}
