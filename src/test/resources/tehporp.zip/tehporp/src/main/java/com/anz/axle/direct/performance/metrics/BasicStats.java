package com.anz.axle.direct.performance.metrics;

public interface BasicStats extends Count {
    double getMin();

    double getMean();

    double getMax();
}
