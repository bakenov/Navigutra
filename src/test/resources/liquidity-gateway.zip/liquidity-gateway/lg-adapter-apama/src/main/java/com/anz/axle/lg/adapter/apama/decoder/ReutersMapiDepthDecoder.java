package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.Depth;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

/**
 * Decodes Apama events as defined by {@link Depth} which comes out of Reuters MAPI adapter.
 */
public final class ReutersMapiDepthDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReutersMapiDepthDecoder.class);
    private static final DateTimeFormatter TIMESTAMP_FORMAT_MAPI = DateTimeFormat.forPattern("dd MMM yyyy").withZoneUTC();
    private static final String SERVICE_NAME = "SERVICE_NAME";
    private static final String MAPI_SERVICE = "MAPI";
    private static final String SCREENED_PRICE = "Screened_Price";
    private static final String MAPI_QUOTE_DATE_RIC = "QUOTE_DATE";
    private static final String MAPI_QUOTE_TIME_MS_RIC = "QUOTIM_MS";

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final Map<String, String> mapiSymbolMap;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdSupplier;
    private final SourceSequencer sourceSequencer;

    public ReutersMapiDepthDecoder(final VenueRequestKeyLookup requestKeyLookup,
                                   final PricingEncoderLookup pricingEncoderLookup,
                                   final PrecisionClock precisionClock,
                                   final Map<String, String> mapiSymbolMap,
                                   final String senderCompId,
                                   final String compId,
                                   final LongSupplier messageIdSupplier,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.mapiSymbolMap = Objects.requireNonNull(mapiSymbolMap);
        this.senderCompId = senderCompId;
        this.compId = Objects.requireNonNull(compId);
        this.messageIdSupplier = Objects.requireNonNull(messageIdSupplier);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void decode(final Event depth) {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("Apama event received: {}", depth);

        final Map<String, String> extraParams = depth.getField(Depth.FIELD_EXTRA_PARAMS);
        if (!MAPI_SERVICE.equals(extraParams.get(SERVICE_NAME)) ||
                !Boolean.parseBoolean(extraParams.get(SCREENED_PRICE))) {
            return;
        }

        final String symbol = translateAndNormaliseMapiSymbol(depth.getField(Depth.FIELD_SYMBOL));
        if (symbol == null) {
            LOGGER.warn("unable to find symbol for Reuters MAPI instrument: " + depth.getField(Depth.FIELD_SYMBOL));
            return;
        }

        final List<Double> bidPx = depth.getField(Depth.FIELD_BID_PRICES);
        final List<Long> bidQty = depth.getField(Depth.FIELD_BID_QUANTITIES);
        final int bidsCnt = bidPx.size() == bidQty.size() ? bidPx.size() : 0;
        if (bidsCnt == 0) {
            LOGGER.warn("unable to parse event as bid price and quantity arrays are empty or do not agree on length. BidPx={}, BidQty={}", bidPx, bidQty);
            return;
        }

        final List<Double> askPx = depth.getField(Depth.FIELD_ASK_PRICES);
        final List<Long> askQty = depth.getField(Depth.FIELD_ASK_QUANTITIES);
        final int asksCnt = askPx.size() == askQty.size() ? askPx.size() : 0;
        if (asksCnt == 0) {
            LOGGER.warn("unable to parse event as ask price and quantity arrays are empty or do not agree on length. AskPx={}, AskQty={}", askPx, askQty);
            return;
        }

        final RequestKey requestKey = requestKeyLookup.lookup(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        final long messageId = messageIdSupplier.getAsLong();

        final long sendingTimeNanos = getMapiSendingTimeNanos(extraParams.get(MAPI_QUOTE_DATE_RIC), extraParams.get(MAPI_QUOTE_TIME_MS_RIC));
        final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_next = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .possResend(false)
                .messageId(messageId)
                .sendingTime(sendingTimeNanos)
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .marketId(requestKey.market())
                .tradeDate().encodeNull()
                .settlDate().encodeNull()
                .referenceSpotDate().encodeNull()
                .entriesStart(bidsCnt + asksCnt);
        for (int i = 0; i < bidsCnt; i++) {
            mdEntries_next.next()
                    .transactTime(sendingTimeNanos)
                    .mdMkt(requestKey.market())
                    .mdEntryType(EntryType.BID)
                    .mdEntryPx(bidPx.get(i))
                    .mdEntrySize(bidQty.get(i))
                    .minQty(0)
                    .mdEntryId(0)
                    .quoteEntryId(0);
        }
        for (int i = 0; i < asksCnt; i++) {
            mdEntries_next.next()
                    .transactTime(sendingTimeNanos)
                    .mdMkt(requestKey.market())
                    .mdEntryType(EntryType.OFFER)
                    .mdEntryPx(askPx.get(i))
                    .mdEntrySize(askQty.get(i))
                    .minQty(0)
                    .mdEntryId(0)
                    .quoteEntryId(0);
        }
        mdEntries_next.entriesComplete()
            .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
            .messageComplete();
    }

    static long getMapiSendingTimeNanos(final String dateStr, final String msSinceMidnight) {
        try {
            return TimeUnit.MILLISECONDS.toNanos((TIMESTAMP_FORMAT_MAPI.parseDateTime(dateStr).withDurationAdded(Long.valueOf(msSinceMidnight), 1).getMillis()));
        } catch (Exception ex) {
            LOGGER.warn("unable to parse timestamp from MAPI message " + dateStr + " with ms: " + msSinceMidnight);
            return 0;
        }
    }

    private String translateAndNormaliseMapiSymbol(final String mapiSymbol) {
        final String conventionalSymbol = mapiSymbolMap.get(mapiSymbol);
        if (conventionalSymbol == null) {
            return null;
        }
        return SymbolNormaliser.toSymbol6(conventionalSymbol);
    }
}

