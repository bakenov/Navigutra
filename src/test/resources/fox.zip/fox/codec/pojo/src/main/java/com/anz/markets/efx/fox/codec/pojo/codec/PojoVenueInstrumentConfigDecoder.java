package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoVenueInstrumentConfigDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends VenueInstrumentConfigHandler> handlerSupplier;

    public PojoVenueInstrumentConfigDecoder(final Supplier<? extends VenueInstrumentConfigHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof VenueInstrumentConfig) {
            return decode((VenueInstrumentConfig) sorMessage);
        }
        return false;
    }

    public boolean decode(final VenueInstrumentConfig message) {
        final VenueInstrumentConfigHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source, message.header.sourceSeq);
        handler.onBody(new VenueInstrumentConfigHandler.Body() {
            @Override
            public Venue venue() {
                return message.body.venue;
            }

            @Override
            public long instrumentId() {
                return message.body.instrumentId;
            }

            @Override
            public double priceIncrement() {
                return message.body.priceIncrement;
            }

            @Override
            public int sizeIncrement() {
                return message.body.sizeIncrement;
            }

            @Override
            public int clipSizeMultiple() {
                return message.body.clipSizeMultiple;
            }

            @Override
            public double maxAllowedParentOrderQty() {
                return message.body.maxAllowedParentOrderQty;
            }

            @Override
            public int minClipSize() {
                return message.body.minClipSize;
            }

            @Override
            public int maxClipSize() {
                return message.body.maxClipSize;
            }

            @Override
            public int staleDataTimeout() {
                return message.body.staleDataTimeout;
            }

            @Override
            public int priority() {
                return message.body.priority;
            }

            @Override
            public int proportion() {
                return message.body.proportion;
            }

            @Override
            public boolean enabled() {
                return  message.body.enabled;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoVenueInstrumentConfigDecoder() {
        throw new RuntimeException("No PojoVenueInstrumentConfigDecoder for you!");
    }
}
