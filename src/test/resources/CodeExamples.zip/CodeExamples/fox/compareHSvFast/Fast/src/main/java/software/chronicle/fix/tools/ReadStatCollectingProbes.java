//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package software.chronicle.fix.tools;

import java.util.concurrent.TimeUnit;
import net.openhft.chronicle.core.time.TimeProvider;
import net.openhft.chronicle.core.util.Histogram;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.VoidFixSessionProbes;

public class ReadStatCollectingProbes extends VoidFixSessionProbes {
    private final Histogram sendToReadSocket = new Histogram();
    private final Histogram sendToProcessed = new Histogram();
    private final Histogram readToPreParse = new Histogram();
    private final Histogram preParseToParsed = new Histogram();
    private final Histogram parsedToProcessed = new Histogram();
    private final TimeUnit sessionTimeUnit;
    private long readTime;
    private long preParseComplete;
    private long messageParsed;
    private TimeProvider timeProvider;

    public ReadStatCollectingProbes(TimeUnit sessionTimeUnit) {
        this.sessionTimeUnit = sessionTimeUnit;
    }

    public ReadStatCollectingProbes timeProvider(TimeProvider timeProvider) {
        this.timeProvider = timeProvider;
        return this;
    }

    public void onReadTime(long readTimeNS) {
        this.readTime = this.timeProvider.currentTimeNanos();
    }

    public void onPreParseComplete() {
        this.preParseComplete = this.timeProvider.currentTimeNanos();
    }

    public void onMessageParsed(StandardHeaderTrailer parsedObject) {
        this.messageParsed = this.timeProvider.currentTimeNanos();
    }

    public void onMessageProcessed(StandardHeaderTrailer message) {
        long messageProcessed = this.timeProvider.currentTimeNanos();
        long sendingTime = this.sessionTimeUnit.toNanos(message.sendingTime());
        this.sendToReadSocket.sampleNanos(this.readTime - sendingTime);
        this.readToPreParse.sampleNanos(this.preParseComplete - this.readTime);
        this.preParseToParsed.sampleNanos(this.messageParsed - this.preParseComplete);
        this.parsedToProcessed.sampleNanos(messageProcessed - this.messageParsed);
        this.sendToProcessed.sampleNanos(messageProcessed - sendingTime);
    }

    public String dump() {
        return this.dump0("sendToReadSocket ", this.sendToReadSocket) + this.dump0("readToPreParse   ", this.readToPreParse) + this.dump0("preParseToParsed ", this.preParseToParsed) + this.dump0("parsedToProcessed", this.parsedToProcessed) + this.dump0("sendToProcessed  ", this.sendToProcessed);
    }

    private String dump0(String name, Histogram histo) {
        String msg = name + " count: " + histo.totalCount() + " histo: " + histo.toMicrosFormat() + System.lineSeparator();
        histo.reset();
        return msg;
    }
}
