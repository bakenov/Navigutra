package com.anz.markets.efx.fox.common.pricing;

import java.util.Queue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScheduledPriceRefreshExecutionStepTest {
    @Mock
    private Queue<InstrumentKey> requestQueue;
    @Mock
    private Queue<ScheduledPriceRefreshExecutionStep.RefreshHandler> scheduleQueue;
    @Mock
    private PricingRefresher pricingRefresher;
    @Mock

    private ScheduledPriceRefreshExecutionStep priceRefreshExecutionStep;

    @BeforeEach
    void setUp() {
        priceRefreshExecutionStep = new ScheduledPriceRefreshExecutionStep(requestQueue, scheduleQueue, pricingRefresher);
    }

    @Test
    void should_offer_to_deferred_queue_when_polled_instrument_could_NOT_be_refreshed() {
        //given
        final InstrumentKey instrumentKey = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);
        when(requestQueue.poll()).thenReturn(instrumentKey);
        when(pricingRefresher.refresh(instrumentKey.instrumentId(), false)).thenReturn(false);

        //when
        assertThat(priceRefreshExecutionStep.process()).isTrue();

        //then
        verify(scheduleQueue).offer(any());
    }

    @Test
    void should_NOT_offer_to_deferred_queue_when_polled_instrument_could_be_refreshed() {
        //given
        final InstrumentKey instrumentKey = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);
        when(requestQueue.poll()).thenReturn(instrumentKey);
        when(pricingRefresher.refresh(instrumentKey.instrumentId(), false)).thenReturn(true);

        //when
        assertThat(priceRefreshExecutionStep.process()).isTrue();

        //then
        verify(scheduleQueue, never()).offer(any());
    }

    @Test
    void should_NOT_refresh_when_no_request_polled() {
        //given
        when(requestQueue.poll()).thenReturn(null);

        //when
        assertThat(priceRefreshExecutionStep.process()).isFalse();

        //then
        verifyNoMoreInteractions(pricingRefresher);
    }

}