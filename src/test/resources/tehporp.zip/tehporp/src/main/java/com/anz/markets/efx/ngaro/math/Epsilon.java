package com.anz.markets.efx.ngaro.math;

public enum Epsilon {
    EPS_1eNegative10(1.0e-10),
    EPS_1eNegative9(1.0e-9),
    EPS_1eNegative8(1.0e-8),
    EPS_1eNegative7(1.0e-7),
    EPS_1eNegative6(1.0e-6),
    EPS_1eNegative5(1.0e-5),
    EPS_0_0001(0.0001),
    EPS_0_001(0.001),
    EPS_0_01(0.01),
    EPS_0_1(0.1),
    EPS_1(1),
    EPS_10(10),
    EPS_50(50),
    EPS_100(100),
    EPS_1000(1_000),
    EPS_10000(10_000);

    private final double value;

    Epsilon(final double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public boolean equalsEpsilon(final double value1, final double value2) {
        return (Double.isNaN(value1) && Double.isNaN(value2)) || Math.abs(value1 - value2) < value;
    }

    public boolean greaterThan(final double value1, final double value2) {
        return (Double.isNaN(value1) && Double.isNaN(value2)) || value1 >= value2 - value;
    }

    public boolean lessThan(final double value1, final double value2) {
        return (Double.isNaN(value1) && Double.isNaN(value2)) || value1 <= value2 + value;
    }

    public static boolean equalsZero(final double value1) {
        return equalsZeroWithPrecision(value1, EPS_1eNegative10);
    }

    public static boolean equalsZeroQuantity(final double value1) {
        return equalsZeroWithPrecision(value1, EPS_1eNegative6);
    }

    public static boolean equalsZeroWithPrecision(final double value1, final Epsilon epsilon) {
        return (Double.isNaN(value1)) || Math.abs(value1) < epsilon.value;
    }

    public static boolean lessThanZero(final double value1) {
        return !equalsZero(value1) && value1 < 0d;
    }

    public static boolean greaterThanZero(final double value1) {
        return !equalsZero(value1) && value1 > 0d;
    }

    public boolean doesNotEqualEpsilon(final double value1, final double value2) {
        return !equalsEpsilon(value1, value2);
    }

}
