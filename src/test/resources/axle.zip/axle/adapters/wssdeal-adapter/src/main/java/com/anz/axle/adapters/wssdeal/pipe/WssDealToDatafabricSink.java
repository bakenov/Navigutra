package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.messaging.endpoint.intf.AbstractSink;
import anz.markets.messaging.types.PDMessage;
import com.anz.axle.datafabric.client.wss.WssDealService;
import com.anz.axle.wss.domain.WssDeal;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by talwarg on 4/02/2015.
 */
public class WssDealToDatafabricSink extends AbstractSink<WssDeal> {
    private static final Logger LOG = Logger.getLogger(WssDealToDatafabricSink.class);

    @Autowired
    private WssDealService wssDealService;

    @Override
    public boolean onMessage(PDMessage<WssDeal> wssDealPDMessage) {
        try {
            wssDealService.validateAndSave(wssDealPDMessage.getContent());
            return true;
        }catch (RuntimeException re){
            LOG.warn(String.format("Failed to sink trade due to - "),re);
        }
        catch (Exception e){
            LOG.error(String.format("Not able to sink deal to datafabric. "),e);
        }
        return false;
    }

    public void setWssDealService( WssDealService wssDealService){
        this.wssDealService = wssDealService;
    }
}
