package com.anz.markets.efx.fox.processor.pricing;

import com.anz.markets.efx.pricing.codec.snapshot.change.BookChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.change.EntriesChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.change.HopsChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;

public class NoopBookChangedListener implements BookChangedListener {
    private final EntriesChangedListener entriesChangedListener = EntriesChangedListener.NOOP;
    private final HopsChangedListener hopsChangedListener = HopsChangedListener.NOOP;

    @Override
    public BookChangedListener onBookChangeStart(final MarketDataBook marketDataBook) {
        return this;
    }

    @Override
    public EntriesChangedListener onEntriesChangeStart(final MarketDataBook marketDataBook, final int i) {
        return entriesChangedListener;
    }

    @Override
    public BookChangedListener onEntriesChangeComplete(final MarketDataBook marketDataBook) {
        return this;
    }

    @Override
    public HopsChangedListener onHopsChangeStart(final MarketDataBook marketDataBook, final int i) {
        return hopsChangedListener;
    }

    @Override
    public BookChangedListener onHopsChangeComplete(final MarketDataBook marketDataBook) {
        return this;
    }

    @Override
    public BookChangedListener onBookChangeComplete(final MarketDataBook marketDataBook) {
        return this;
    }
}
