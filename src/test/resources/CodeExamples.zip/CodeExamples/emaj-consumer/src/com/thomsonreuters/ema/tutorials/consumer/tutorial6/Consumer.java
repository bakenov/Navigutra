/*
	EMA Consumer - Request & Decode Machine Readable News

	This Consumer.java is a stand alone tutorial with the goal of creating an advanced consumer application.
	
	The objective of this example is to request, retrieve and decode News Text Analytics (NTA)
    domain from a Machine Readable News (MRN) service.
	
	Please refer to an alternative one; basicConsumer.java which is the sixth part in a series of tutorials 
	with the goal of creating a basic consumer application.

	The series includes the following:

		o Tutorial 1 - Creating a barebones EMA consumer application
		o Tutorial 2 - Requesting and displaying MarketPrice data
		o Tutorial 3 - Parsing and Decoding MarketPrice data
		o Tutorial 4 - Requesting, parsing and decoding Level 2 data
		o Tutorial 5 - Dispatching messages within the user thread
		o Tutorial 6 - Request & Decode Machine Readable News
 */

package com.thomsonreuters.ema.tutorials.consumer.tutorial6;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.zip.GZIPInputStream;

import com.thomsonreuters.ema.access.AckMsg;
import com.thomsonreuters.ema.access.Data;
import com.thomsonreuters.ema.access.DataType;
import com.thomsonreuters.ema.access.DataType.DataTypes;
import com.thomsonreuters.ema.access.EmaFactory;
import com.thomsonreuters.ema.access.FieldEntry;
import com.thomsonreuters.ema.access.FieldList;
import com.thomsonreuters.ema.access.GenericMsg;
import com.thomsonreuters.ema.access.Msg;
import com.thomsonreuters.ema.access.OmmConsumer;
import com.thomsonreuters.ema.access.OmmConsumerClient;
import com.thomsonreuters.ema.access.OmmConsumerEvent;
import com.thomsonreuters.ema.access.OmmException;
import com.thomsonreuters.ema.access.RefreshMsg;
import com.thomsonreuters.ema.access.StatusMsg;
import com.thomsonreuters.ema.access.UpdateMsg;
import com.thomsonreuters.ema.rdm.EmaRdm;


class AppClient implements OmmConsumerClient
{
	// RefreshMsg contains feed specific metadata - will not contain NTA item fragment 
	public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event)
	{
		System.out.println("Item Name: " + (refreshMsg.hasName() ? refreshMsg.name() : "<not set>"));
		System.out.println("Service Name: " + (refreshMsg.hasServiceName() ? refreshMsg.serviceName() : "<not set>"));
		
		System.out.println("Item State: " + refreshMsg.state());
		
		// Confirm the payload and domain type and dump the metadata Fields to the console
		if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType() && 
				(EmaRdm.MMT_NEWS_TEXT_ANALYTICS == refreshMsg.domainType()))
			decode(refreshMsg.payload().fieldList());
		else System.out.println("Wrong Domain and/or Payload " + refreshMsg.domainType() + " " +
			refreshMsg.payload().dataType());
		
		System.out.println();
	}
	
	// UpdateMsg contains NTA item fragment and item related metadata 
	public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event) 
	{
		System.out.println("Item Name: " + (updateMsg.hasName() ? updateMsg.name() : "<not set>"));
		System.out.println("Service Name: " + (updateMsg.hasServiceName() ? updateMsg.serviceName() : "<not set>"));
		
		// Confirm the payload and domain type is as expected and then attempt to extract the NTA item 
		if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType() && 
				(EmaRdm.MMT_NEWS_TEXT_ANALYTICS == updateMsg.domainType()))
			decodeNTA(updateMsg.payload().fieldList());
		else System.out.println("Wrong Domain and/or Payload " + updateMsg.domainType() + " " +
				updateMsg.payload().dataType());
		
		System.out.println();
	}

	public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event) 
	{
		System.out.println("Item Name: " + (statusMsg.hasName() ? statusMsg.name() : "<not set>"));
		System.out.println("Service Name: " + (statusMsg.hasServiceName() ? statusMsg.serviceName() : "<not set>"));

		if (statusMsg.hasState())
			System.out.println("Item State: " +statusMsg.state());
		
		System.out.println();
	}
	
	public void onGenericMsg(GenericMsg genericMsg, OmmConsumerEvent consumerEvent){}
	public void onAckMsg(AckMsg ackMsg, OmmConsumerEvent consumerEvent){}
	public void onAllMsg(Msg msg, OmmConsumerEvent consumerEvent){}

	void decode(FieldList fieldList)
	{
		for (FieldEntry fieldEntry : fieldList)
		{
			System.out.print("\tFid: " + fieldEntry.fieldId() + " Name = " + fieldEntry.name() + " DataType: " + DataType.asString(fieldEntry.load().dataType()) + " Value: ");

			if (Data.DataCode.BLANK == fieldEntry.code())
				System.out.println(" blank");
			else
				switch (fieldEntry.loadType())
				{
				case DataTypes.REAL :
					System.out.println(fieldEntry.real().asDouble());
					break;
				case DataTypes.DATE :
					System.out.println(fieldEntry.date().day() + " / " + fieldEntry.date().month() + " / " + fieldEntry.date().year());
					break;
				case DataTypes.TIME :
					System.out.println(fieldEntry.time().hour() + ":" + fieldEntry.time().minute() + ":" + fieldEntry.time().second() + ":" + fieldEntry.time().millisecond());
					break;
				case DataTypes.INT :
					System.out.println(fieldEntry.intValue());
					break;
				case DataTypes.UINT :
					System.out.println(fieldEntry.uintValue());
					break;
				case DataTypes.ASCII :
					System.out.println(fieldEntry.ascii());
					break;
				case DataTypes.ENUM :
					System.out.println(fieldEntry.enumValue());
					break;
				case DataTypes.BUFFER :
					System.out.println( "<BUFFER>" 
							+ ", limit = " 
							+ fieldEntry.buffer().buffer().limit() 
							+ ", length = " 
							+ fieldEntry.buffer().buffer().array().length);
					break;
				case DataTypes.RMTES :
					System.out.println(fieldEntry.rmtes().toString());
					break;
				case DataTypes.ERROR :
					System.out.println("(" + fieldEntry.error().errorCodeAsString() + ")");
					break;
				default :
					System.out.println();
					break;
				}
		}
	}
	
	private NewsTextAnalyticsItem _multiFragItem;
	void decodeNTA(FieldList envelope)
	{
		decode(envelope); // Dump the FieldList first (for informational purposes)
		NewsTextAnalyticsItem item = new NewsTextAnalyticsItem();
		// Now let's extract the relevant fields into a NTA item - including the Fragment
		item.init(envelope);
		// Is this 1st fragment of a NTA item?
		if (item.getFragNum() == 1)
		{
			// Is it the complete NTA item?
			if (item.isComplete())	// i.e. check length of this single fragment buffer == expected total size of NTA item
			{
				System.out.println("<<Single Fragment>>");
				String unzipped;
				unzipped = unzip(item.getNTABuffer().array());	// decompress the buffer
				System.out.println("<Content>");
				System.out.print("\t");
				System.out.println(unzipped);					// Display the decompressed NTA item
				System.out.println("</Content>");
				return;
			}
			else
			{							// Start of a multi-fragment item
				_multiFragItem = item;	// so copy this first fragment into our pending item instance
			}
		}
		else
		{
			// FRAG_NUM > 1 so continue to build up NTA item
			try {
				// Add the newly received fragment to the collection of the pending item instance
				_multiFragItem.addFragment(item);
			} catch (Exception e) {
				System.out.println("Multi Fragment Error: " + e.getMessage());
				_multiFragItem = null;
			}
			if (_multiFragItem!= null && _multiFragItem.isComplete())	// Does length of the buffer now == expected total size of NTA item ?
			{
				System.out.println("<<Multi Fragment Completed>>");
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				for (ByteBuffer buffer: _multiFragItem.getFragmentCollection()) {
					// for debug only
					// System.out.println("limit: " + buffer.limit());
					baos.write(buffer.array(), 0, buffer.limit());
				}
				String unzipped;
				unzipped = unzip(baos.toByteArray());			// Decompress the complete buffer
				System.out.println("<Content>");
				System.out.print("\t");
				System.out.println(unzipped);					// Display the decompressed NTA item
				System.out.println("</Content>");
				
				_multiFragItem = null;
				unzipped = null;
				return;
			}
		}
	}
	
	public String unzip(byte[] bytes)
	{
		StringBuffer result = new StringBuffer();
		try {
			GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(bytes));
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(gis, "UTF-8"));

			String line = "";
            while ((line = bufferedReader.readLine()) != null) {
            	result.append(line);
            }
		} catch (Exception e) {
			System.out.println("Parse News error:" + e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}
}

public class Consumer 
{
	public static void main(String[] args)
	{
		OmmConsumer consumer = null;
		try
		{
			AppClient appClient = new AppClient();
			
			consumer  = EmaFactory.createOmmConsumer(EmaFactory.createOmmConsumerConfig().host("elektron:14002").username("user"));
			
			// Request NTA domain MRN_STORY type items 
			consumer.registerClient(EmaFactory.createReqMsg().serviceName( "ELEKTRON_DD" ).name( "MRN_STORY" ).domainType( EmaRdm.MMT_NEWS_TEXT_ANALYTICS ), appClient);
			
				Thread.sleep(60000);			// API calls onRefreshMsg(), onUpdateMsg() and onStatusMsg()
		}
		catch (InterruptedException | OmmException excp)
		{
			System.out.println(excp.getMessage());
		}
		finally 
		{
			 if (consumer != null) consumer.uninitialize();
		}
	}
}


class NewsTextAnalyticsItem
{
	public void init(FieldList fieldList)
	{ 
		int fidNum = 0;
		long tmpUint = 0;
		String tmpString;
		
		for (FieldEntry fieldEntry : fieldList)
		{
			// Get the Field ID for this field
			fidNum = fieldEntry.fieldId();
			// System.out.println("fidNum: " + fidNum + " " + fidToString(fidNum));
			// We are only interested in a few key fields 
			// so we only need to handle the corresponding field types
			
			switch (fieldEntry.loadType())
			{
				case DataTypes.UINT:
					tmpUint = fieldEntry.uintValue();
//					System.out.println("tmpUint: " + tmpUint);
					if (fidNum == FID_FRAG_NUM)
						_fragNum = tmpUint;
					else if (fidNum == FID_TOT_SIZE)
						_expectedSize = tmpUint;
					break;
				case DataTypes.RMTES:
					tmpString = fieldEntry.rmtes().toString();
					if (fidNum == FID_GUID)
						_guid = tmpString;
					else if (fidNum == FID_MRN_SRC)
						_mrnSource = tmpString;
					else if (fidNum == FID_MRN_TYPE)
						_mrnType = tmpString;
					break;
				case DataTypes.BUFFER:
					if (fidNum == FID_FRAGMENT) {
						_ntaBuffer = clone(fieldEntry.buffer().buffer());
					}
					break;
				default:
					break;
					
			}
		}
		
		if (_fragNum == 1)
			System.out.println("Init:: Expected total buffer size: " + _expectedSize + " current size: " + _ntaBuffer.limit());
		else
			System.out.println("Additional fragment size: " + _ntaBuffer.limit());
		
	}
	
	private ByteBuffer clone(ByteBuffer original) {
		ByteBuffer clone = ByteBuffer.allocate(original.capacity());
		original.rewind();		// copy from the beginning
		clone.put(original);
		original.rewind();
		clone.flip();
		return clone;
	}
	
	public void addFragment(NewsTextAnalyticsItem fragment)
	{
		if (!fragment._guid.equals(_guid))
			throw new RuntimeException("Cannot add fragment to item: mismatching GUID - " + fragment._guid + " : " + _guid);
		if (!fragment._mrnSource.equals(_mrnSource))
			throw new RuntimeException("Cannot add fragment to item: mismatching data source - " + fragment._mrnSource + " : " + _mrnSource);
		if (fragment._fragNum != _fragNum + 1)
			throw new RuntimeException("add fragment to item: fragment number is not in sequence");
		
		// Update an _fragNum field.
		_fragNum = fragment._fragNum;
		if (_fragmentCollection == null) {
			_fragmentCollection = new ArrayList<>();
			_fragmentCollection.add(_ntaBuffer);
			_fragmentCollection.add(fragment._ntaBuffer);
		} else {
			_fragmentCollection.add(fragment._ntaBuffer);
		}
	
		System.out.println("Add Fragment:: Expected total buffer:" + _expectedSize + " current " + getTotalSize());
	}
	
	public int getTotalSize() {
		if (_fragNum == 1) {
			// For a single fragment, return ByteBuffer limit.
			return _ntaBuffer.limit();
		} else {
			// For multi-fragment, return summation of all ByteBuffer in collection.
			int totalSize = 0;
			for (ByteBuffer buffer: _fragmentCollection) {
				totalSize+=buffer.limit();
			}
			return totalSize;
		}
	}
	
	public boolean isComplete() {
		return (_expectedSize > 0) && (_expectedSize == getTotalSize());
	}
	
	public ByteBuffer getNTABuffer() { return _ntaBuffer; }
	public String getGUID() { return _guid; }
	public String getMRNSource() { return _mrnSource; }
	public String getMRNType() { return _mrnType; }	
	public long getFragNum() { return _fragNum; }
	public long getExpectedSize() { return _expectedSize; }
	public ArrayList<ByteBuffer> getFragmentCollection() { return _fragmentCollection; }
	
	private ByteBuffer _ntaBuffer;
	private String _guid;
	private String _mrnSource;
	private String _mrnType;
	private long _fragNum;
	private long _expectedSize;
	private ArrayList<ByteBuffer> _fragmentCollection;
	
	static final int FID_GUID 		= 4271;
	static final int FID_MRN_TYPE 	= 8593;
	static final int FID_MRN_SRC 	= 12215;
	static final int FID_FRAG_NUM 	= 32479;
	static final int FID_TOT_SIZE 	= 32480;
	static final int FID_FRAGMENT 	= 32641;
	
	public static String fidToString(int fid) {
		switch (fid) {
		case FID_GUID:
			return "GUID";
		case FID_MRN_TYPE:
			return "MRN_TYPE";
		case FID_MRN_SRC:
			return "MRN_SRC";
		case FID_FRAG_NUM:
			return "FRAG_NUM";
		case FID_TOT_SIZE:
			return "TOT_SIZE";
		case FID_FRAGMENT:
			return "FRAGMENT";
		default:
			return "UNKNOWN";
		}
	}

}
