package com.anz.markets.prophet.atest.risk._1_position;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Position;
import com.anz.markets.prophet.positionrisk.Positions;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Instrument.AUDSEK;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURSEK;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.number.IsCloseTo.closeTo;

@RestartBeforeTest(reason = "Not sure why! test should revert all trade.. at the start anyway.")
public class PositionUpdateTriangulatedMidTest extends BaseAcceptanceSpecification {
    private double EPSILON = 1e-8;

    @Test
    @Requirement(value = Ref.POSITION_4_1_5)
    @DisplayName("Test EUR base system base position needs to be triangulated for. Note all of mid that need to be triangulated for are triangulated via EUR")
    public void WHEN_receive_trade_for_EUR_ccy_that_require_triangulation() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMarketConfigs(Arrays.asList(
                            // define driver pairs for market
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURSEK).setEnabled(true),
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.EURSEK, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
        }
        when:
        {
            // this trade should not be considered as missing appropriate rates to value
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.6));
            // provide a rate
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.1));
            // this trade should also not be considered still missing one rate
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.6));
            // provide the other rate
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURSEK, 9.7));
            // this trade should be successful
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.6));
        }
        then:
        {
            final LinkedList<Positions> expect = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));
            Positions positionsUpdate = expect.getLast();
            assertThat(positionsUpdate.countPositions(), is(2));
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.EUR));
            assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(1_000_000.0 * 1.1));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.SEK));
            assertThat(positionsUpdate.getPosition2().getPositionInNotional(), is(-1_000_000.0 * 9.6));
            // USDSEK - 9.7/1.1, system base rate is SEK against USD therefore 1.1/9.7
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), new IsRoundedTo((-1_000_000.0 * 9.6) * (1.1 / 9.7)));
        }
        when:
        {
            // another position arrives.
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.5));
        }
        then:
        {
            // immediately update position using cached triangulated mid rate.
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.countPositions(), is(2));
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.EUR));
            assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(2_000_000.0));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(2_000_000.0 * 1.1));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.SEK));
            assertThat(positionsUpdate.getPosition2().getPositionInNotional(), is((-1_000_000.0 * 9.6) + (-1_000_000.0 * 9.5)));
            // USDSEK - 9.7/1.1, system base rate is SEK against USD therefore 1.1/9.7
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), new IsRoundedTo(((-1_000_000.0 * 9.6) + (-1_000_000.0 * 9.5)) * (1.1 / 9.7)));
        }
    }

    @Test
    @Requirement(value = {Ref.POSITION_4_1_5, Ref.POSITION_4_6, Ref.POSITION_4_7})
    @DisplayName("Test non EUR base system base position needs to be triangulated for. USDSEK is not primary this we need to triangulate")
    public void WHEN_receive_trade_for_non_EUR_ccy_that_require_triangulation() {
        Position audPos;
        Position sekPos;

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMarketConfigs(Arrays.asList(
                            // define driver pairs for market
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(AUDUSD).setEnabled(true),
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURSEK).setEnabled(true),
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURSEK, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
        }
        when:
        {
            // start with a price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            // following client trade should be rejected as one rate is missing
            prophet.receive(tdd.client_trade_001(AUDSEK, 1_000_000, 6.7));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.1));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURSEK, 9.7));
            // now enough rates to value
            prophet.receive(tdd.client_trade_001(AUDSEK, 1_000_000, 6.7));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, atLeast(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();

            assertThat(positionsUpdate.countPositions(), is(2));
            audPos = positionsUpdate.getPosition1();
            sekPos = positionsUpdate.getPosition2();

            assertThat(audPos.getCcy(), is(Currency.AUD));
            assertThat(audPos.getPositionInNotional(), is(1_000_000.0));
            assertThat(audPos.getPositionInSystemBase(), is(750_000.));
            assertThat(audPos.getAvgRate(), is(0.75000));
            assertThat(audPos.getPnl(), is(0.0));

            assertThat(sekPos.getCcy(), is(Currency.SEK));
            assertThat(sekPos.getPositionInNotional(), is(-1_000_000.0 * 6.7));
            assertThat(sekPos.getPositionInSystemBase(), is(closeTo(sekPos.getPositionInNotional() / (9.7 / 1.1), EPSILON)));
            assertThat(sekPos.getAvgRate(), is(closeTo(9.7 / 1.1, 9)));
            assertThat(sekPos.getPnl(), is(0.0));
        }
        when:
        {
            // another position arrives.
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.11));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURSEK, 9.72));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDSEK, 1_000_000, 6.6));
        }
        then:
        {
            // immediately update position using cached triangulated mid rate.
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.countPositions(), is(2));
            audPos = positionsUpdate.getPosition1();
            sekPos = positionsUpdate.getPosition2();

            assertThat(audPos.getCcy(), is(Currency.AUD));
            assertThat(audPos.getPositionInNotional(), is(2_000_000.0));
            assertThat(audPos.getPositionInSystemBase(), is(1_500_000.));

            assertThat(sekPos.getCcy(), is(Currency.SEK));
            assertThat(sekPos.getPositionInNotional(), is((-1_000_000.0 * 6.7) + (-1_000_000.0 * 6.6)));
            assertThat(sekPos.getPositionInSystemBase(), is(sekPos.getPositionInNotional() / (9.72 / 1.11)));
            assertThat(sekPos.getAvgRate(), is(sekPos.getPositionInNotional() /
                    ((-1_000_000 * 6.7 / (9.7 / 1.1)) + (-1_000_000 * 6.6 / (9.72 / 1.11)))));
            assertThat(sekPos.getPnl(), is(closeTo((-sekPos.getPositionInNotional() * ((1 / sekPos.getAvgRate()) - (1 / (9.72 / 1.11)))), EPSILON)));
        }
    }
}
