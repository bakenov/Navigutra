package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.itch.staticcode.parsers.MessageParserBase;
import software.chronicle.itchcboe.components.MarketSnapshot_CcyPairsGrp_1;
import software.chronicle.itchcboe.components.MarketSnapshot_CcyPairsGrp_BidPricesGrp_1;
import software.chronicle.itchcboe.components.MarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1;
import software.chronicle.itchcboe.components.MarketSnapshot_CcyPairsGrp_OfferPricesGrp_1;
import software.chronicle.itchcboe.components.MarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1;
import software.chronicle.itchcboe.messages.MarketSnapshot;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import software.chronicle.itchcboe.messages.server.Sequenced;

public final class HspMarketSnapshotHandler implements ChronicleMessageHandler<MarketSnapshot> {
    private static final Logger LOGGER = LoggerFactory.getLogger(HspMarketSnapshotHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final LongSupplier sequenceNumberSupplier;
    private final String senderCompId;
    private final String compId;
    private final SymbolOrderIdSideLookUp symbolOrderIdSideLookUp;
    private final SequenceTimestampParser sequenceTimestampParser;
    private final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public HspMarketSnapshotHandler(final VenueRequestKeyLookup requestKeyLookup,
                                    final PricingEncoderLookup pricingEncoderLookup,
                                    final PrecisionClock precisionClock,
                                    final SubscriptionManager subscriptionManager,
                                    final LongSupplier sequenceNumberSupplier,
                                    final String senderCompId,
                                    final String compId,
                                    final SymbolOrderIdSideLookUp symbolOrderIdSideLookUp,
                                    final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> snapshotFullRefreshflagsAppender,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.sequenceNumberSupplier = Objects.requireNonNull(sequenceNumberSupplier);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.symbolOrderIdSideLookUp = Objects.requireNonNull(symbolOrderIdSideLookUp);
        this.sequenceTimestampParser = new SequenceTimestampParser(precisionClock);
        this.flagsAppender = Objects.requireNonNull(snapshotFullRefreshflagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final MarketSnapshot message) throws IllegalArgumentException {
        accept(message, precisionClock.nanos());
    }

    @Override
    public void accept(final MarketSnapshot message, final long receivedByAdapterTimestampNanos) throws IllegalArgumentException {

        final long sendingTimeNanos = sequenceTimestampParser.sendingTimeNanosOrNow((Sequenced) MessageParserBase.sequencedHolderTl.get());
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("MarketSnapshot received: {}", message);

        for (int i = 0; i < message.noCcyPairs(); i++) {

            final MarketSnapshot_CcyPairsGrp_1 marketSnapshot_CcyPairsGrp = message.marketSnapshot_CcyPairsGrp_1(i);
            final String symbol = marketSnapshot_CcyPairsGrp.ccyPair();
            final long sequenceNumber = sequenceNumberSupplier.getAsLong();
            final long messageId = sequenceNumber;

            final MarketDataSubscription subscription = subscriptionManager.lookupBySymbol(symbol);
            final StringToIntCache entryIdCache = subscription.stringToIntCache();

            subscription.validateSymbol(symbol);

            final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());

            final long bidPriceCount = marketSnapshot_CcyPairsGrp.noBidPrices();
            final long offerPriceCount = marketSnapshot_CcyPairsGrp.noOfferPrices();

            final SnapshotFullRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
            flagsAppender.accept(encoder.mdFlags());

            final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = encoder
                    .possResend(false)
                    .marketId(requestKey.market())
                    .instrumentId(requestKey.instrumentKey().instrumentId())
                    .senderCompId().encode(compId)
                    .messageId(messageId)
                    .sendingTime(sendingTimeNanos)
                    .referenceSpotDate().encodeNull()
                    .tradeDate().encodeNull()
                    .settlDate().encodeNull()
                    .entriesStart((int) (bidPriceCount + offerPriceCount));

            for (int j = 0; j < bidPriceCount; j++) {
                final MarketSnapshot_CcyPairsGrp_BidPricesGrp_1 bidPricesGrp = marketSnapshot_CcyPairsGrp.marketSnapshot_CcyPairsGrp_BidPricesGrp_1(j);
                final double bidPrice = bidPricesGrp.bidPrice();
                for (int k = 0; k < bidPricesGrp.noBidOrders(); k++) {
                    final MarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 bidOrdersGrp = bidPricesGrp.marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1(k);
                    int entryId = entryIdCache.put(bidOrdersGrp.orderId().toString());
                    addBidEntry(entryId, bidPrice, bidOrdersGrp.amount(), mdEntries_Next, sendingTimeNanos, requestKey);
                }
            }

            for (int j = 0; j < offerPriceCount; j++) {
                final MarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 offerPricesGrp = marketSnapshot_CcyPairsGrp.marketSnapshot_CcyPairsGrp_OfferPricesGrp_1(j);
                final double offerPrice = offerPricesGrp.offerPrice();
                for (int k = 0; k < offerPricesGrp.noOfferOrders(); k++) {
                    final MarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 offerOrdersGrp = offerPricesGrp.marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1(k);
                    int entryId = entryIdCache.put(offerOrdersGrp.orderId().toString());
                    addOfferEntry(entryId, offerPrice, offerOrdersGrp.amount(), mdEntries_Next, sendingTimeNanos, requestKey);
                }
            }

            mdEntries_Next.entriesComplete()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                        .hopsComplete()
                    .messageComplete();
        }
    }

    private void addBidEntry(final int entryId,
                             final double bidPrice,
                             final double amount,
                             final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next,
                             final long transactTime,
                             final RequestKey requestKey) {

        addEntry(bidPrice, amount, entryId, EntryType.BID, mdEntries_Next, transactTime, requestKey);
    }

    private void addOfferEntry(final int entryId,
                               final double offerPrice,
                               final double amount,
                               final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next,
                               final long transactTime,
                               final RequestKey requestKey) {

        addEntry(offerPrice, amount, entryId, EntryType.OFFER, mdEntries_Next, transactTime, requestKey);
    }

    private void addEntry(final double price,
                          final double size,
                          final int entryId,
                          final EntryType entryType,
                          final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next,
                          final long transactTime,
                          final RequestKey requestKey) {

        symbolOrderIdSideLookUp.cache(requestKey.instrumentKey().instrumentId(), entryId, entryType);
        mdEntries_Next.next()
            .transactTime(transactTime)
            .mdMkt(requestKey.market())
            .mdEntryType(entryType)
            .mdEntrySize(size)
            .mdEntryPx(price)
            .mdEntryId(entryId)
            .quoteEntryId(0);
    }

}
