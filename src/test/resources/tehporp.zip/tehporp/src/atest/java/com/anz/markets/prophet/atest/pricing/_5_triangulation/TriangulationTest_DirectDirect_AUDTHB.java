package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TriangulationTest_DirectDirect_AUDTHB extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_6)
    @DisplayName("Triangulation of new cross pair AUDTHB with minimal config")
    public void triangulate_cross_pair() throws Exception {

        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverPairB = Instrument.USDTHB;
        final Instrument crossPair = Instrument.AUDTHB;

        given:
        {
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_75M.getQty(), Region.GB).set(TradingTimeZone.LDN, 8.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_100M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_150M.getQty(), Region.GB).set(TradingTimeZone.LDN, 13.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_200M.getQty(), Region.GB).set(TradingTimeZone.LDN, 17.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_75M.getQty(), Region.GB).set(TradingTimeZone.LDN, 9.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_100M.getQty(), Region.GB).set(TradingTimeZone.LDN, 12.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_150M.getQty(), Region.GB).set(TradingTimeZone.LDN, 16.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_200M.getQty(), Region.GB).set(TradingTimeZone.LDN, 19.5)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            // To enable cross we need to add
            final List<InstrumentConfig> instrumentConfigs = new ArrayList<>(configurationDataDefault.getInstrumentConfigs());
            instrumentConfigs.add(new InstrumentConfigImpl(Instrument.AUDTHB).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1));
            configurationDataDefault.setInstrumentConfigs(instrumentConfigs);

            final List<SyntheticWideningFactor> syntheticConfigs = new ArrayList<>(configurationDataDefault.getSyntheticWideningFactors());
            syntheticConfigs.add(SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.THB, Market.WSP_A, 1.0));
            configurationDataDefault.setSyntheticWideningFactors(syntheticConfigs);

            final List<SyntheticInstrumentConfig> syntheticInstrumentConfigs = new ArrayList<>(configurationDataDefault.getSyntheticInstrumentConfigs());
            syntheticInstrumentConfigs.add(new SyntheticInstrumentConfigImpl().setInstrument(crossPair).setMarkets(Market.WSP_A.name()));
            configurationDataDefault.setSyntheticInstrumentConfigs(syntheticInstrumentConfigs);

            final List<ClientPriceThrottleConfig> throttleConfigs = new ArrayList<>(configurationDataDefault.getClientPriceThrottleConfigs());
            throttleConfigs.add(new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.THB).setNoActivityHeartbeatFrequencyMs(20000).
                    setStartStopTimePeriodMS(0).
                    setLimit(1).
                    setTimePeriod(1).
                    setMinimumPriceDeltaFractionOfSpread(0.01).
                    setOverrideLimit(1).
                    setOverrideTimePeriod(1).
                    setOverrideMinimumPriceDeltaFractionOfMid(0.000001).
                    setMinimumPriceDeltaFractionOfPreviousSpread(0.001));
            configurationDataDefault.setClientPriceThrottleConfigs(throttleConfigs);

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(2)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(2)));

            // set spot date crossPair
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00005));
        }

        then:
        {
            prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 33.095, 0.006));
        }
        then:
        {
            prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB));
        }
        and:
        {
            prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair));
        }
    }
}
