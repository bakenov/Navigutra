package com.anz.markets.efx.fox.api.domain;

import java.util.function.Consumer;
import java.util.function.Predicate;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;

public interface Instrument {
    InstrumentKey key();
    int pipSizeDivisor();
    boolean enabled();
    VenueInstrument venueInstrument(Venue venueId);
    void addVenueInstrument(VenueInstrument venueInstrument);
    void addDrivingInstrument(Instrument instrument);
    void forEach(Predicate<VenueInstrument> filter, Consumer<VenueInstrument> consumer);
    void forEachDrivingInstrument(Consumer<Instrument> consumer);
    Instrument drivingInstrument(String symbol);
    double consensusMidPrice();
    void consensusMidPrice(double consensusMidPrice);
    double usdValue(double nominalBaseAmount);
}
