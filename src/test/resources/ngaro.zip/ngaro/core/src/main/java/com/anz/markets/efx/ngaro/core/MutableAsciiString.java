package com.anz.markets.efx.ngaro.core;

public interface MutableAsciiString extends AsciiString {
    MutableAsciiString set(int index, byte b);
    <S> MutableAsciiString set(S source, ByteReader<? super S> reader, int offset, int length);
    MutableAsciiString append(byte b);
    <S> MutableAsciiString append(S source, ByteReader<? super S> reader, int offset, int length);
    MutableAsciiString clear();

    default MutableAsciiString set(final AsciiString value) {
        return set(value, ByteReader.ASCII_STRING, 0, value == null ? 0 : value.length());
    }
    default MutableAsciiString append(final AsciiString value) {
        return append(value, ByteReader.ASCII_STRING, 0, value == null ? 0 : value.length());
    }
    default MutableAsciiString set(final CharSequence value) {
        return set(value, ByteReader.CHAR_SEQUENCE, 0, value == null ? 0 : value.length());
    }
    default MutableAsciiString append(final CharSequence value) {
        return append(value, ByteReader.CHAR_SEQUENCE, 0, value == null ? 0 : value.length());
    }
}
