package com.anz.markets.efx.fox.processor.command;

import java.util.Arrays;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.LongSupplier;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.common.pricing.PricingFeed;
import com.anz.markets.efx.fox.processor.pricing.InstrumentCleansing;
import com.anz.markets.efx.fox.processor.pricing.InstrumentMidPriceCalculator;
import com.anz.markets.efx.fox.processor.pricing.SelfCrossingCleansingRule;
import com.anz.markets.efx.fox.processor.pricing.StalenessCleansingRule;
import com.anz.markets.efx.fox.processor.pricing.TopOfBookRule;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidatorRepository;
import org.agrona.collections.MutableLong;
import org.tools4j.eventsourcing.api.CommandExecutorFactory;
import org.tools4j.eventsourcing.api.MessageConsumer;
import org.tools4j.eventsourcing.api.ProgressState;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.sbe.SbeSorDecoderBuilder;
import com.anz.markets.efx.fox.codec.sbe.SbeSorDecoders;
import com.anz.markets.efx.fox.common.MessageConsumerToDecoderAdapter;
import com.anz.markets.efx.fox.common.MessageDecoderToConsumerAdapter;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.processor.state.UpdatableIdGenerator;
import com.anz.markets.efx.fox.api.eventsourcing.UpdatablePrecisionClock;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.domain.UserSessionRepository;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.processor.timer.TimerController;
import com.anz.markets.efx.fox.receiver.SingleDestinationMessageDecoderLookup;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingHandlerSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoderBuilder;

public class DefaultCommandExecutorFactory implements CommandExecutorFactory {
    private final static String APPENDING_EVENT_APPLIER = "appendingEventApplier";

    private final UpdatablePrecisionClock eventPrecisionClock;
    private final ParentOrderRepository.WithInit parentOrderRepository;
    private final ChildOrderRepository childOrderRepository;
    private final VenueRepository venueRepository;
    private final UserRepository userRepository;
    private final ParentOrderValidatorRepository parentOrderValidatorRepository;
    private final UserSessionRepository userSessionRepository;
    private final InstrumentRepository instrumentRepository;
    private final VenueInstrumentRepository venueInstrumentRepository;
    private final MutableLong idGeneratorOffset;
    private final SnapshotFullRefreshHandler snapshotterFullRefreshHandler;
    private final Function<MessageConsumer, TradingEncoderSupplier> tradingEncoderSupplierFactory;
    private final Function<MessageConsumer, SorEncoderSupplier> sorEncoderSupplierFactory;
    private final TimerController timerController;
    private final String senderCompId;
    private final int processorSourceId;
    private final Firewall inboundFirewall;
    private final PricingFeed.Request pricingFeedRequest;

    public DefaultCommandExecutorFactory(final UpdatablePrecisionClock eventPrecisionClock,
                                         final ParentOrderRepository.WithInit parentOrderRepository,
                                         final ChildOrderRepository childOrderRepository,
                                         final VenueRepository venueRepository,
                                         final UserRepository userRepository,
                                         final UserSessionRepository userSessionRepository,
                                         final ParentOrderValidatorRepository parentOrderValidatorRepository,
                                         final InstrumentRepository instrumentRepository,
                                         final VenueInstrumentRepository venueInstrumentRepository,
                                         final MutableLong idGeneratorOffset,
                                         final SnapshotFullRefreshHandler snapshotterFullRefreshHandler,
                                         final Function<MessageConsumer, TradingEncoderSupplier> tradingEncoderSupplierFactory,
                                         final Function<MessageConsumer, SorEncoderSupplier> sorEncoderSupplierFactory,
                                         final TimerController timerController,
                                         final String senderCompId,
                                         final int processorSourceId,
                                         final Firewall inboundFirewall,
                                         final PricingFeed.Request pricingFeedRequest) {
        this.eventPrecisionClock = Objects.requireNonNull(eventPrecisionClock);
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
        this.venueRepository = Objects.requireNonNull(venueRepository);
        this.userRepository = Objects.requireNonNull(userRepository);
        this.parentOrderValidatorRepository = Objects.requireNonNull(parentOrderValidatorRepository);
        this.userSessionRepository = Objects.requireNonNull(userSessionRepository);
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
        this.venueInstrumentRepository = Objects.requireNonNull(venueInstrumentRepository);
        this.idGeneratorOffset = Objects.requireNonNull(idGeneratorOffset);
        this.snapshotterFullRefreshHandler = Objects.requireNonNull(snapshotterFullRefreshHandler);
        this.tradingEncoderSupplierFactory = Objects.requireNonNull(tradingEncoderSupplierFactory);
        this.sorEncoderSupplierFactory = Objects.requireNonNull(sorEncoderSupplierFactory);
        this.timerController = Objects.requireNonNull(timerController);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.processorSourceId = processorSourceId;
        this.inboundFirewall = Objects.requireNonNull(inboundFirewall);
        this.pricingFeedRequest = Objects.requireNonNull(pricingFeedRequest);
    }

    @Override
    public MessageConsumer create(final MessageConsumer eventApplier,
                                  final ProgressState currentProgressState,
                                  final ProgressState completedProgressState) {
        final SbePricingDecoders sbePricingDecoders = new SbePricingDecoders();
        final SbeSorDecoders sbeSorDecoders = new SbeSorDecoders();

        final MessageDecoder<SbeMessage> eventApplyingDecoder = new MessageDecoderToConsumerAdapter(eventApplier);
        final MessageDecoder.ForwardingLookup<SbeMessage> eventAppendingDecoderLookup = new SingleDestinationMessageDecoderLookup(APPENDING_EVENT_APPLIER, eventApplyingDecoder);
        final TradingEncoderSupplier tradingEncoderSupplier = tradingEncoderSupplierFactory.apply(eventApplier);
        final SorEncoderSupplier sorEncoderSupplier = sorEncoderSupplierFactory.apply(eventApplier);

        final UpdatableIdGenerator updatableIdGenerator = new UpdatableIdGenerator();
        final CommandContext commandContext = new CommandContext() {
            @Override
            public String senderCompId() {
                return senderCompId;
            }

            @Override
            public int source() {
                return processorSourceId;
            }

            @Override
            public TradingEncoderSupplier tradingEncoderSupplier() {
                return tradingEncoderSupplier;
            }

            @Override
            public SorEncoderSupplier sorEncoderSupplier() {
                return sorEncoderSupplier;
            }

            @Override
            public MessageDecoder<SbeMessage> eventApplier() {
                return eventApplyingDecoder;
            }

            @Override
            public LongSupplier idGenerator() {
                return updatableIdGenerator;
            }

            @Override
            public PrecisionClock precisionClock() {
                return eventPrecisionClock;
            }

            @Override
            public UserSessionRepository userSessionRepository() {
                return userSessionRepository;
            }

            @Override
            public ParentOrderRepository parentOrderRepository() {
                return parentOrderRepository;
            }

            @Override
            public UserRepository userRepository() {
                return userRepository;
            }

            @Override
            public InstrumentRepository instrumentRepository() {
                return instrumentRepository;
            }

            @Override
            public VenueRepository venueRepository() {
                return venueRepository;
            }

            @Override
            public VenueInstrumentRepository venueInstrumentRepository() {
                return venueInstrumentRepository;
            }
        };

        final Consumer<Instrument> onInstrumentPriceRefreshHandler =
                new InstrumentCleansing(
                        new StalenessCleansingRule(commandContext)
                                .andThen(new SelfCrossingCleansingRule())
                                .andThen(new TopOfBookRule()))
                .andThen(new InstrumentMidPriceCalculator());


        final PricingRefreshCompleteHandler pricingRefreshCompleteHandler = new ExecutePricingRefreshCompleteHandler(commandContext, pricingFeedRequest, instrumentRepository, parentOrderRepository, onInstrumentPriceRefreshHandler);

        final MessageDecoder<SbeMessage> tradingCommand = SbeTradingDecoderBuilder.create()
                .newOrderSingle(new ParentNewOrderSingleCommand(commandContext, inboundFirewall))
                .orderCancelRequest(new ParentOrderCancelRequestCommand(parentOrderRepository, commandContext))
                .executionReport(new ChildExecutionReportCommand(childOrderRepository, commandContext))
                .orderCancelReject(new ChildOrderCancelRejectCommand(childOrderRepository, commandContext))
                .heartbeat(new HeartbeatCommand(commandContext, userRepository, venueRepository))
                .build();

        final MessageDecoder<SbeMessage> sorCommand = SbeSorDecoderBuilder.create()
                .timerExpiry(timerController.timerExpiryCommand(commandContext))
                .venueConfig(new VenueConfigCommand(venueRepository, commandContext))
                .instrumentConfig(new InstrumentConfigCommand(commandContext))
                .venueInstrumentConfig(new VenueInstrumentConfigCommand(commandContext))
                .userConfig(new UserConfigCommand(userRepository, commandContext))
                .firewallConfig(new FirewallConfigCommand(commandContext, inboundFirewall))
                .initialisation(new InitialisationCommand(commandContext))
                .build();

        final MessageDecoder<SbeMessage> snapshotFullRefresh = sbePricingDecoders.snapshotFullRefresh().create(PricingHandlerSupplier.snapshotFullRefresh(snapshotterFullRefreshHandler),
                eventAppendingDecoderLookup);

        final MessageDecoder<SbeMessage> pricingRefreshComplete = sbeSorDecoders.pricingRefreshComplete().create(pricingRefreshCompleteHandler);

        final MessageDecoder<SbeMessage> compositeMessageDecoder = MessageDecoder.composite(Arrays.asList(snapshotFullRefresh, sorCommand, tradingCommand, pricingRefreshComplete));

        final MessageConsumer clockUpdater = (directBuffer, i, i1) -> {
            eventPrecisionClock.accept(currentProgressState.eventTimeNanos());
            updatableIdGenerator.accept(idGeneratorOffset.get() + currentProgressState.id() * 100);
        };

        return clockUpdater.andThen(new MessageConsumerToDecoderAdapter(compositeMessageDecoder));
    }
}
