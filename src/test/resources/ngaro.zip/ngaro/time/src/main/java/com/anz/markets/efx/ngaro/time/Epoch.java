package com.anz.markets.efx.ngaro.time;

import java.time.chrono.IsoChronology;
import java.time.temporal.ChronoField;

/**
 * Utility with methods to convert from and to epoch values.
 */
public final class Epoch {
    /**
     * The number of hours in a day.
     */
    public static final int HOURS_PER_DAY = 24;
    /**
     * The number of minutes in an hour.
     */
    public static final int MINUTES_PER_HOUR = 60;
    /**
     * The number of minutes in an hour.
     */
    public static final int SECONDS_PER_MINUTE = 60;
    /**
     * The number of seconds in a day.
     */
    public static final int SECONDS_PER_DAY = HOURS_PER_DAY * MINUTES_PER_HOUR * SECONDS_PER_MINUTE;
    /**
     * The number of milliseconds in a second.
     */
    public static final int MILLIS_PER_SECOND = 1000;
    /**
     * The number of microseconds in a millisecond.
     */
    public static final int MICROS_PER_MILLI = 1000;
    /**
     * The number of nanoseconds in a second.
     */
    public static final int NANOS_PER_SECOND = 1000_000_000;
    /**
     * The number of nanoseconds in a millisecond.
     */
    public static final int NANOS_PER_MILLI = 1000_000;
    /**
     * The number of nanoseconds in a millisecond.
     */
    public static final int NANOS_PER_MICRO = 1000;
    /**
     * The number of milliseconds in a day.
     */
    public static final int MILLIS_PER_DAY = MILLIS_PER_SECOND * SECONDS_PER_DAY;
    /**
     * The number of seconds in a day.
     */
    public static final long NANOS_PER_DAY = SECONDS_PER_DAY * (long)NANOS_PER_SECOND;
    /**
     * The number of days in a 400 year cycle.
     */
    public static final int DAYS_PER_CYCLE = 146097;

    /**
     * The number of days from year zero to year 1970.
     * There are five 400 year cycles from year zero to 2000.
     * There are 7 leap years from 1970 to 2000.
     */
    public static final long DAYS_0000_TO_1970 = (DAYS_PER_CYCLE * 5L) - (30L * 365L + 7L);

    public static long toEpochMillis(final int year, final int month, final int day) {
        return toEpochDays(year, month, day) * MILLIS_PER_DAY;
    }

    public static long toEpochSeconds(final int year, final int month, final int day) {
        return toEpochDays(year, month, day) * SECONDS_PER_DAY;
    }

    public static long toEpochDays(final int year, final int month, final int day) {
        //see LocalDate.toEpochDay()
        ChronoField.YEAR.checkValidValue(year);
        ChronoField.MONTH_OF_YEAR.checkValidValue(month);
        ChronoField.DAY_OF_MONTH.checkValidValue(day);
        long total = 0;
        total += 365 * year;
        if (year >= 0) {
            total += (year + 3) / 4 - (year + 99) / 100 + (year + 399) / 400;
        } else {
            total -= year / -4 - year / -100 + year / -400;
        }
        total += ((367 * month - 362) / 12);
        total += day - 1;
        if (month > 2) {
            total--;
            if (IsoChronology.INSTANCE.isLeapYear(year) == false) {
                total--;
            }
        }
        return total - DAYS_0000_TO_1970;
    }

    public static int fromEpochMillis(final LocalDatePacking packing, final long epochMillis) {
        return fromEpochDays(packing, epochMillis / MILLIS_PER_DAY);
    }

    public static int fromEpochSeconds(final LocalDatePacking packing, final long epochSeconds) {
        return fromEpochDays(packing, epochSeconds / SECONDS_PER_DAY);
    }

    public static int fromEpochDays(final LocalDatePacking packing, final long epochDays) {
        //See LocalDate.ofEpochDay(long epochDay)
        long zeroDay = epochDays + DAYS_0000_TO_1970;
        // find the march-based year
        zeroDay -= 60;  // adjust to 0000-03-01 so leap day is at end of four year cycle
        long adjust = 0;
        if (zeroDay < 0) {
            // adjust negative years to positive for calculation
            long adjustCycles = (zeroDay + 1) / DAYS_PER_CYCLE - 1;
            adjust = adjustCycles * 400;
            zeroDay += -adjustCycles * DAYS_PER_CYCLE;
        }
        long yearEst = (400 * zeroDay + 591) / DAYS_PER_CYCLE;
        long doyEst = zeroDay - (365 * yearEst + yearEst / 4 - yearEst / 100 + yearEst / 400);
        if (doyEst < 0) {
            // fix estimate
            yearEst--;
            doyEst = zeroDay - (365 * yearEst + yearEst / 4 - yearEst / 100 + yearEst / 400);
        }
        yearEst += adjust;  // reset any negative year
        int marchDoy0 = (int) doyEst;

        // convert march-based values back to january-based
        final int marchMonth0 = (marchDoy0 * 5 + 2) / 153;
        final int month = (marchMonth0 + 2) % 12 + 1;
        final int dom = marchDoy0 - (marchMonth0 * 306 + 5) / 10 + 1;
        yearEst += marchMonth0 / 10;

        // check year now we are certain it is correct
        final int year = ChronoField.YEAR.checkValidIntValue(yearEst);
        return packing.pack(year, month, dom);
    }

    private Epoch() {
        throw new RuntimeException("No Epoch for you!");
    }
}
