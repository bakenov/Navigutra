package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.ngaro.codec.EnumSetEncoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.SimpleStringEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoUserConfigEncoder implements UserConfigEncoder, UserConfigEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;
    private final EnumerableSetEncoder<Body, UserGroup> userGroups;
    private final StringEncoder<Body> userName;
    private final StringEncoder<Trailer> location;

    private UserConfig message = SorMessage.userConfig();

    public PojoUserConfigEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
        this.userGroups = new EnumSetEncoder<>(this, UserGroup::length, UserGroup::valueByOrdinal, f -> message.body.userGroups.add(f), () -> message.body.userGroups.clear());
        this.userName = new SimpleStringEncoder<>(this, s -> message.body.userName = s);
        this.location = new SimpleStringEncoder<>(this, s -> message.body.location = s);
    }

    public UserConfig message() {
        return message;
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        message = SorMessage.userConfig();
        return this;
    }


    @Override
    public StringEncoder<Body> userName() {
        return userName;
    }

    @Override
    public EnumerableSetEncoder<Body, UserGroup> userGroups() {
        return userGroups;
    }

    @Override
    public StringEncoder<Trailer> location() {
        return location;
    }

    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
