package com.anz.markets.prophet.collections;

import com.anz.markets.prophet.domain.collections.AbstractFixSizeBufferBwJmhTest;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class FixSizeBufferJMHTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixSizeBufferJMHTest.class);

    @State(Scope.Benchmark)
    public static class Data extends AbstractFixSizeBufferBwJmhTest {

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }

    @Benchmark
    public boolean testAddAndRemove(@NotNull final Data data) throws Exception {
        return data.testAddAndRemove();
    }

    @Benchmark
    public boolean testAddAndRemoveIfOlder(@NotNull final Data data) throws Exception {
        return data.testAddAndRemoveIfOlder();
    }
}
