package com.anz.markets.efx.ngaro.sbe;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.junit.Test;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.ByteReader;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link VariableStringEncoder}
 */
public class VariableStringEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test(expected = NullPointerException.class)
    public void noNullSource() {
        StringEncoders.forVariableLength(ENCLOSING_ENCODER, null, 7);
    }

    @Test(expected = IllegalArgumentException.class)
    public void noNegativeLength() {
        StringEncoders.forVariableLength(ENCLOSING_ENCODER, (src, off, len) -> null, -1);
    }

    @Test
    public void encodeEmpty() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer directBuffer = new ExpandableArrayBuffer("abcdefghijklmno".length());
        directBuffer.putBytes(0, "abcdefghijklmno".getBytes());
        final VariableStringTarget target = (src, off, len) -> {
            directBuffer.putByte(offset, (byte)len);
            directBuffer.putBytes(offset + 1, src, off, len);
            return directBuffer;
        };
        final StringEncoder<?> enc = StringEncoders.forVariableLength(ENCLOSING_ENCODER, target, directBuffer.capacity());

        //when
        enc.encodeEmpty();

        //then
        assertEquals("result should contain 0 size at " + offset, 0, directBuffer.getByte(offset));
        assertEquals("result should contain original value at " + (offset+1), "abc\000efghijklmno", new String(directBuffer.byteArray()));
    }

    @Test
    public void encodeFromCharSequence() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer directBuffer = new ExpandableArrayBuffer("abcdefghijklmno".length());
        directBuffer.putBytes(0, "abcdefghijklmno".getBytes());
        final VariableStringTarget target = (src, off, len) -> {
            directBuffer.putByte(offset, (byte)len);
            directBuffer.putBytes(offset + 1, src, off, len);
            return directBuffer;
        };
        final StringEncoder<?> enc = StringEncoders.forVariableLength(ENCLOSING_ENCODER, target, directBuffer.capacity());

        //when
        enc.encode("123456");

        //then
        assertEquals("result should contain size at " + offset, "123456".length(), directBuffer.getByte(offset));
        assertEquals("result should contain 123456 at " + (offset+1), "abc\006123456klmno", new String(directBuffer.byteArray()));

        //when
        enc.encode("UVWXYZ", 3, 3);

        //then
        assertEquals("result should contain size at " + offset, 3, directBuffer.getByte(offset));
        assertEquals("result should contain 123456 at " + (offset+1), "abc\003XYZ456klmno", new String(directBuffer.byteArray()));
    }

    @Test
    public void encodeFromByteReader() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer directBuffer = new ExpandableArrayBuffer("abcdefghijklmno".length());
        directBuffer.putBytes(0, "abcdefghijklmno".getBytes());
        final VariableStringTarget target = (src, off, len) -> {
            directBuffer.putByte(offset, (byte)len);
            directBuffer.putBytes(offset + 1, src, off, len);
            return directBuffer;
        };
        final StringEncoder<?> enc = StringEncoders.forVariableLength(ENCLOSING_ENCODER, target, directBuffer.capacity());

        //when
        enc.encode("123456", ByteReader.CHAR_SEQUENCE, 6);

        //then
        assertEquals("result should contain size at " + offset, "123456".length(), directBuffer.getByte(offset));
        assertEquals("result should contain 123456 at " + (offset+1), "abc\006123456klmno", new String(directBuffer.byteArray()));

        //when
        enc.encode("UVWXYZ", ByteReader.CHAR_SEQUENCE, 3, 3);

        //then
        assertEquals("result should contain size at " + offset, 3, directBuffer.getByte(offset));
        assertEquals("result should contain 123456 at " + (offset+1), "abc\003XYZ456klmno", new String(directBuffer.byteArray()));
    }

    @Test
    public void encodeFromStringDecoder() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer directBuffer = new ExpandableArrayBuffer("abcdefghijklmno".length());
        directBuffer.putBytes(0, "abcdefghijklmno".getBytes());
        final VariableStringTarget target = (src, off, len) -> {
            directBuffer.putByte(offset, (byte)len);
            directBuffer.putBytes(offset + 1, src, off, len);
            return directBuffer;
        };
        final StringEncoder<?> enc = StringEncoders.forVariableLength(ENCLOSING_ENCODER, target, directBuffer.capacity());
        final String input = "123456";
        final StringDecoder dec = StringDecoders.forFixedLength(i -> (byte)input.charAt(i), input.length());

        //when
        enc.encodeFrom(dec);

        //then
        assertEquals("result should contain size at " + offset, "123456".length(), directBuffer.getByte(offset));
        assertEquals("result should contain 123456 at " + (offset+1), "abc\006123456klmno", new String(directBuffer.byteArray()));
    }

}