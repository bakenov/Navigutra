package com.anz.markets.prophet.atest.disco;

import com.anz.markets.disco.config.DiscoPFPConfig;
import com.anz.markets.disco.config.DiscoVolatilityPFPConfig;
import com.anz.markets.disco.config.JamDetectorPFPConfig;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.modules.DiscoveryModule;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.config.business.domain.indexed.AggregatedBookConfig;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.DiscoTightenByConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.EmptyBookReason;
import com.anz.markets.prophet.domain.clientprice.ModifiedBookReason;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import com.anz.markets.prophet.status.Context;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;


public class DiscoClientPriceTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault configuration1() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base();

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        // Test overrride of U, R, BENCH into normal pipeline
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_U, Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_R, Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_P, Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.EBS),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_BENCH, Instrument.EURUSD, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));

        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoPFPConfig.FEATURE_NAME, priceFormationPipelineConfig);

        priceFormationPipelineConfig.clear();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, ""));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.WSP_MU, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, "2|5|10",
                DiscoVolatilityPFPConfig.PARAM_INC_SPREAD, 0.3,
                DiscoVolatilityPFPConfig.PARAM_VOL_STEP, 0.5,
                DiscoVolatilityPFPConfig.PARAM_VOL_START, 0.5,
                DiscoVolatilityPFPConfig.PARAM_VOL_POWER, 1.0));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, priceFormationPipelineConfig);

        configuration.setDiscoTightenByConfigs(Arrays.asList(
                // spread config for driver pairs
                new DiscoTightenByConfigImpl(Market.WSP_A, Instrument.AUDUSD, Region.GB).set(TradingTimeZone.LDN, 0.2).set(TradingTimeZone.NYK, 0.1).set(TradingTimeZone.SNG, 1.0)
        ));

        priceFormationPipelineConfig.clear();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(JamDetectorPFPConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                JamDetectorPFPConfig.PARAM_TICK_COUNT, Long.MIN_VALUE, JamDetectorPFPConfig.PARAM_TIME_PERIOD_SECONDS, Long.MIN_VALUE));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(JamDetectorPFPConfig.FEATURE_NAME, Market.HSP, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.ANY,
                JamDetectorPFPConfig.PARAM_TICK_COUNT, 3L, JamDetectorPFPConfig.PARAM_TIME_PERIOD_SECONDS, Long.MIN_VALUE));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(JamDetectorPFPConfig.FEATURE_NAME, priceFormationPipelineConfig);

        return configuration;
    }

    @Test
    public void basico_disco_client_price() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // Check that only one MU price published and comes from DISCO.
            LinkedList<FilteredMarketDataSnapshot> uPrices = prophet.expect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.AUDUSD, Market.WSP_MU));
            assertThat(uPrices.size(), Matchers.is(1));
            assertThat(uPrices.getFirst().getTopOfBookBid().getPrice(), Matchers.is(0.75030));
            assertThat(uPrices.getFirst().getTopOfBookOffer().getPrice(), Matchers.is(0.75050));


            // WSP_A is DISCO PRICE (EMPTY DUE TO LACK OF VOL SIGNAL)
            {
                ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst();
                assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.DISCO_BASE));
                assertThat(clientPrice.getEmptyBookReason(), Matchers.is(EmptyBookReason.DISCO_TICK_VOLATILITY_INVALID));
                assertThat(clientPrice.isEmpty(), Matchers.is(true));
            }

            // Counterexample: WSP_B is not DISCO PRICE
            {
                ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getFirst();
                assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.NOT_DEFINED));
                assertThat(clientPrice.getEmptyBookReason(), Matchers.is(EmptyBookReason.NOT_DEFINED));
                assertThat(clientPrice.isEmpty(), Matchers.is(false));
            }

        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75060, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75070, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // Now we have a real DISCO price.
            {
                ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst();
                assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.DISCO_CS));
                assertThat(clientPrice.getEmptyBookReason(), Matchers.is(EmptyBookReason.NOT_DEFINED));
                assertThat(clientPrice.isEmpty(), Matchers.is(false));

                // cluster spread is 1
                // tightenBy is 0.2 (LDN)
                // base spread is 0.3
                // TVS is 0.22539334053276722

                assertThat(clientPrice.getUnskewedMid(), Matchers.closeTo(0.75065, 1E-7));
                assertThat(clientPrice.getSkewedMid(), Matchers.closeTo(0.75065, 1E-7));

                double spread = 1E-4 * ((1 - 0.2) + 0.3);
                assertThat(clientPrice.getTopOfBookBid().getPrice(), Matchers.closeTo(0.75065 - spread * 0.5, 1E-7));
                assertThat(clientPrice.getTopOfBookOffer().getPrice(), Matchers.closeTo(0.75065 + spread * 0.5, 1E-7));
            }
        }

        // Ensure can handle cluster negative spread.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);
            prophet.expect(Signals.class);

            {
                ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst();
                assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.DISCO_CS));
                assertThat(clientPrice.getEmptyBookReason(), Matchers.is(EmptyBookReason.NOT_DEFINED));
                assertThat(clientPrice.isEmpty(), Matchers.is(false));

                assertThat(clientPrice.getTopOfBookBid().getPrice() < clientPrice.getTopOfBookOffer().getPrice(), Matchers.is(true));
            }
        }

    }

    // Ensure DISCO not active in JP.
    @Test
    public void disco_client_price_region() {
        given:
        {
            Context.region(Region.JP);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // WSP_A is not a DISCO PRICE in JP
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.NOT_DEFINED));

        }

        // Restore region
        Context.region(Region.GB);
    }


    @Test
    public void testOverride() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // Check that only one U price published and comes from DISCO.
            LinkedList<FilteredMarketDataSnapshot> uPrices = prophet.expect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.EURUSD, Market.WSP_U));
            assertThat(uPrices.size(), Matchers.is(1));
            assertThat(uPrices.getFirst().getTopOfBookBid().getPrice(), Matchers.is(0.75030));
            assertThat(uPrices.getFirst().getTopOfBookOffer().getPrice(), Matchers.is(0.75050));
            assertThat(uPrices.getFirst().getBidEventList().size(), Matchers.is(1));
            assertThat(uPrices.getFirst().getOfferEventList().size(), Matchers.is(1));

            // WSP_A is based on DISCO WSP_U
            {
                ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURUSD, Market.WSP_A)).getFirst();
                assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.NOT_DEFINED));  // not DISCO price
                assertThat(clientPrice.getEmptyBookReason(), Matchers.is(EmptyBookReason.NOT_DEFINED));
            }
        }

        // Test that NaN prices generate no levels.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // Check that only one U price published and comes from DISCO.
            LinkedList<FilteredMarketDataSnapshot> uPrices = prophet.expect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.EURUSD, Market.WSP_U));
            assertThat(uPrices.size(), Matchers.is(1));
            assertThat(uPrices.getFirst().getTopOfBookBid().getPrice(), Matchers.is(Double.NaN));
            assertThat(uPrices.getFirst().getTopOfBookOffer().getPrice(), Matchers.is(Double.NaN));
            assertThat(uPrices.getFirst().getBidEventList().size(), Matchers.is(0));
            assertThat(uPrices.getFirst().getOfferEventList().size(), Matchers.is(0));


            // WSP_A is based on DISCO WSP_U
            {
                ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.EURUSD, Market.WSP_A)).getFirst();
                assertThat(clientPrice.getModifiedBookReason(), Matchers.is(ModifiedBookReason.NOT_DEFINED));  // not DISCO price
                assertThat(clientPrice.getEmptyBookReason(), Matchers.is(EmptyBookReason.NOT_DEFINED));
            }
        }

    }

    @Test
    public void testReferenceCanInvert() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // Check that WSP_R comes from DISCO and is inverted.
            LinkedList<FilteredMarketDataSnapshot> rPrices = prophet.expect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.EURUSD, Market.WSP_R));
            assertThat(rPrices.size(), Matchers.is(1));
            assertThat(rPrices.getFirst().getTopOfBookBid().getPrice(), Matchers.is(0.75050));
            assertThat(rPrices.getFirst().getTopOfBookOffer().getPrice(), Matchers.is(0.75030));
            assertThat(rPrices.getFirst().getBidEventList().size(), Matchers.is(1));
            assertThat(rPrices.getFirst().getOfferEventList().size(), Matchers.is(1));
        }

    }

    @Test
    public void testPrimary() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.EBS, Instrument.EURUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.expect(Signals.class);

            // Check that WSP_P comes from DISCO and is not inverted.
            LinkedList<FilteredMarketDataSnapshot> rPrices = prophet.expect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.EURUSD, Market.WSP_P));
            assertThat(rPrices.size(), Matchers.is(1));
            assertThat(rPrices.getFirst().getTopOfBookBid().getPrice(), Matchers.is(0.75030));
            assertThat(rPrices.getFirst().getTopOfBookOffer().getPrice(), Matchers.is(0.75050));
            assertThat(rPrices.getFirst().getBidEventList().size(), Matchers.is(1));
            assertThat(rPrices.getFirst().getOfferEventList().size(), Matchers.is(1));
        }

    }

    @Test
    public void testDiscoMarketDetectedAsDriver() {
        ConfigurationData configurationData = configuration1();
        configurationData.getPriceFormationPipelineConfigs().removeFeature(AggregatedBookConfig.FEATURE_NAME);
        IndexedConfigurationData indexedConfigurationData = new IndexedConfigurationData(configurationData);
        assertThat(indexedConfigurationData.getDriverInstruments().size(),Matchers.is(1));
        Assert.isTrue(indexedConfigurationData.getDriverInstruments().contains(Instrument.AUDUSD));
    }

    @Test
    public void testJamDetector() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    tdd.now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.OCX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75070, 1_000_000)),
                    tdd.now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.OCX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75041, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75071, 1_000_000)),
                    tdd.now()));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.OCX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75042, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75072, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Check that HSP is now jammed.
            LinkedList<Signals> rSignals = prophet.expect(Signals.class);
            assertThat(rSignals.getLast().getSignal(SignalType.CBID).getConditionCode().getValue(),Matchers.is("JXXC_JXXCXXX_C"));
            assertThat(rSignals.getLast().getSignal(SignalType.CASK).getConditionCode().getValue(),Matchers.is("JXXC_JXXCXXX_C"));

            LinkedList<FilteredMarketDataSnapshot> rPrices = prophet.expect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.AUDUSD, Market.WSP_MU));
            assertThat(rPrices.size(), Matchers.is(2));
            assertThat(rPrices.getLast().getTopOfBookBid().getPrice(), Matchers.is(0.75042));
            assertThat(rPrices.getLast().getTopOfBookOffer().getPrice(), Matchers.is(0.75072));
            assertThat(rPrices.getLast().getBidEventList().size(), Matchers.is(1));
            assertThat(rPrices.getLast().getOfferEventList().size(), Matchers.is(1));
        }

    }

}