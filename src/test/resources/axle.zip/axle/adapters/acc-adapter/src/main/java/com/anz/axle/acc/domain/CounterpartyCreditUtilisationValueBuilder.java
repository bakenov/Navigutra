package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.*;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationKey;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("counterpartyCreditUtilisationValueBuilder")
public class CounterpartyCreditUtilisationValueBuilder implements Builder<CounterpartyCreditUtilisationValue, CounterpartyCreditUtilisation> {

    @Autowired
    @Qualifier("counterpartyCreditUtilisationKeyBuilder")
    private Builder<CounterpartyCreditUtilisationKey, CounterpartyCreditUtilisation> keyBuilder;

    @Override
    public CounterpartyCreditUtilisationValue build(CounterpartyCreditUtilisation utilisation) throws BuilderException {
        CounterpartyCreditUtilisationKey key = keyBuilder.build(utilisation);
        Double utilisationValue = utilisation.getUtilisationValue();
        Collection<Venue> venues = utilisation.getAffectedVenues();
        return new CounterpartyCreditUtilisationValue(key, utilisationValue,  venues, utilisation.getLastChanged().toDate().getTime());
    }

    /**
     * Testing purposes only.
     * @param keyBuilder
     */
    public void setKeyBuilder(CounterpartyCreditUtilisationKeyBuilder keyBuilder) {
        this.keyBuilder = keyBuilder;
    }
}
