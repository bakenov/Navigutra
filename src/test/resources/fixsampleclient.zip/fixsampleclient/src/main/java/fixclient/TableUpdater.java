// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

// import java.util.Iterator;

import java.awt.EventQueue;
import java.util.Iterator;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.thomsonreuters.trfx.referenceclients.fixclient.util.MessageHelper;
import quickfix.Field;
import quickfix.FieldMap;
import quickfix.FieldNotFound;
import quickfix.Message;
import quickfix.SessionID;
import quickfix.field.ClOrdID;
import quickfix.field.MsgSeqNum;
import quickfix.field.MsgType;
import quickfix.field.OrdStatus;

/**
 * This class provides a Runnable interface that reads from a supplied queue,
 * and posts the QuickFixSessionMessages it finds there onto a supplied JTable,
 * picking out particular important fields, such as SeqNum and ClOrdId.
 */
public class TableUpdater implements Runnable
{
    private final AtomicBoolean                           running = new AtomicBoolean(true);

    protected final JTable                                table;
    protected final BlockingQueue<QuickFixSessionMessage> dataQueue;
    private final String                                  name;
    private final IMessageFlowListener                    messageFlowListener;

    private static class RowData
    {
        String msgType       = "";
        Long   seqNum        = Long.valueOf(0);
        String clientOrderId = "";
        String ordStatus     = "";
        String fullMessage;

        public RowData()
        {
            // Do nothing
        }

        /**
         * @return the msgType
         */
        public String getMsgType()
        {
            return this.msgType;
        }

        /**
         * @param msgType
         *            the msgType to set
         */
        public void setMsgType(final String msgType)
        {
            this.msgType = msgType;
        }

        /**
         * @return the seqNum
         */
        public Long getSeqNum()
        {
            return this.seqNum;
        }

        /**
         * @param seqNum
         *            the seqNum to set
         */
        public void setSeqNum(final Long seqNum)
        {
            this.seqNum = seqNum;
        }

        /**
         * @return the clientOrderId
         */
        public String getClientOrderId()
        {
            return this.clientOrderId;
        }

        /**
         * @param clientOrderId
         *            the clientOrderId to set
         */
        public void setClientOrderId(final String clientOrderId)
        {
            this.clientOrderId = clientOrderId;
        }

        /**
         * @return the ordStatus
         */
        public String getOrdStatus()
        {
            return this.ordStatus;
        }

        /**
         * @param ordStatus
         *            the ordStatus to set
         */
        public void setOrdStatus(final String ordStatus)
        {
            this.ordStatus = ordStatus;
        }

        /**
         * @return the fullMessage
         */
        public String getFullMessage()
        {
            return this.fullMessage;
        }

        /**
         * @param fullMessage
         *            the fullMessage to set
         */
        public void setFullMessage(final String fullMessage)
        {
            this.fullMessage = fullMessage;
        }
    }

    /**
     * @param name
     * @param table
     * @param dataQueue
     * @param messageFlowListener
     */
    public TableUpdater(final String name,
                        final JTable table,
                        final BlockingQueue<QuickFixSessionMessage> dataQueue,
                        final IMessageFlowListener messageFlowListener)
    {
        this.table = table;
        this.dataQueue = dataQueue;
        this.name = name;
        this.messageFlowListener = messageFlowListener;
    }

    /**
     * Basic Thread loop, reading FIX messages from the queue and placing them
     * onto the supplied JTable's model (Invoked Later on the Swing EDT).
     * 
     * @see java.lang.Runnable#run()
     */
    public void run()
    {
        System.out.println("[TableUpdater] "
                + this.name
                + " started by Thread"
                + Thread.currentThread().getName());
        while (this.running.get())
        {
            try
            {
                final QuickFixSessionMessage sessionMessage = this.dataQueue.take();
                final Message message = sessionMessage.getMessage();
                final SessionID sessionID = sessionMessage.getSessionID();
                final String messageStr = MessageHelper.convertToString(message,
                        sessionID);
                final Vector<String> dataVector = new Vector<String>();

                final RowData rowData = new RowData();
                retrieveFieldValues(message, rowData);
                retrieveFieldValues(message.getHeader(), rowData);
                rowData.setFullMessage(messageStr);

                dataVector.add(rowData.getMsgType());
                dataVector.add(rowData.getSeqNum().toString());
                dataVector.add(rowData.getClientOrderId());
                dataVector.add(rowData.getOrdStatus());
                dataVector.add(rowData.getFullMessage());

                // Update the GUI in the Event Queue's thread
                EventQueue.invokeLater(new Runnable() {
                    public void run()
                    {
                        // perform the actual changes on the EDT.
                        final DefaultTableModel model = (DefaultTableModel) TableUpdater.this.table.getModel();
                        model.addRow(dataVector);
                        model.fireTableDataChanged();
                    }
                });
            }
            catch (final InterruptedException ex)
            {
                // Do nothing - this is how we exit.
            }
            catch (final Exception ex)
            {
                this.messageFlowListener.logError("Error parsing message. Table will not be updated. See logs for more details.",
                        ex);
            }
        }
    }

    private void retrieveFieldValues(final FieldMap message,
            final RowData rowData)
    {
        try
        {
            final Iterator<Field<?>> itr = message.iterator();
            while (itr.hasNext())
            {
                final Field<?> field = itr.next();

                if (field.getField() == ClOrdID.FIELD)
                {
                    rowData.setClientOrderId(message.getString(field.getField()));
                }
                if (field.getField() == OrdStatus.FIELD)
                {
                    rowData.setOrdStatus(message.getString(field.getField()));
                }
                if (field.getField() == MsgType.FIELD)
                {
                    rowData.setMsgType(message.getString(field.getField()));
                }
                if (field.getField() == MsgSeqNum.FIELD)
                {
                    rowData.setSeqNum(Long.valueOf(message.getInt(field.getField())));
                }
            }
        }
        catch (final FieldNotFound fnf)
        {
            System.out.println(fnf.getMessage());
        }
    }

    /**
     * Prevents further iterations of the message processing loop.
     */
    public void stop()
    {
        this.running.set(false);
    }
}
