package com.anz.markets.efx.fox.acceptance.tests;

import java.io.InputStream;
import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallConfigInstance;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallRuleCategoryConfig;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallTypeConfig;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallsConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class SORStart_BurstOfOrders_ThroughputFirewallTriggers {
    private static final Logger LOGGER = LoggerFactory.getLogger(SORStart_BurstOfOrders_ThroughputFirewallTriggers.class);
    @Rule
    public final TestName testName = new TestName();
    public String rejectText ="";

    private Application application;
    private AcceptanceContext acceptanceContext;
    private MarketDataFactory marketDataFactory = new MarketDataFactory();

    private final String clOrdId = "3456";
    private final OrderType orderType = OrderType.LIMIT;
    private final String currency = "USD";
    private final Side side = Side.BUY;
    private final double price = 1.2320;
    private final double quantity = 1000000;
    private final TimeInForce timeInForce = TimeInForce.IOC;
    private final String sndrCompId = "FXTrader.GB.anufriea.XEFX";
    private final String targetCompId = "GB:fox";
    private final String marketId = "FOX";
    private final String symbol = "EURUSD";
    private final SecurityType securityType = SecurityType.FXSPOT;
    private final Tenor tenor = Tenor.SP;
    private PropertyApplier systemProperties = new SystemPropertyApplier();


    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void submit_more_than_burst_firewall_limit_worth_of_orders_expect_reject_execution_report() throws InterruptedException {
        final InputStream marketDataRequestStream = this.getClass().getClassLoader().getResourceAsStream("conf/firewall-rules.yaml");
        final FirewallsConfig firewallsConfig = FirewallsConfig.yaml().load(marketDataRequestStream);
        final FirewallRuleCategoryConfig inbound = firewallsConfig.getFirewalls().get("inbound-parent-order-rules");
        final FirewallTypeConfig firstFirewall = inbound.getFirewallTypeConfigs().get(0);
        final FirewallConfigInstance burstSubmitOrderThroughputConfig = firstFirewall.getConfiguredInstances().get(0);

        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, securityType, tenor);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();
        final String username = burstSubmitOrderThroughputConfig.getUsernamePattern();
        final Double limitThreshold = burstSubmitOrderThroughputConfig.getLimitThreshold();
        Heartbeat userHeartbeat = sorEndpoint.createHeartbeat();
        userHeartbeat.body.senderCompId = sndrCompId;
        sorEndpoint.tradingRequest().add(userHeartbeat);

        Heartbeat venueHeartbeat = sorEndpoint.createHeartbeat();
        venueHeartbeat.body.senderCompId = "GB:lg-fastc";
        sorEndpoint.tradingRequest().add(venueHeartbeat);

        rejectText = "firewallName=Inbound Burst Submit Order Throughput, ruleId=10(MidHedgerOrdersSubmitThroughput1s), limit="+ limitThreshold;
        assertThat(limitThreshold).isGreaterThan(0);

        Asserter.NextMatchBuilder<?> executionReportMatching = Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportNewMatcher(symbol, marketId, orderType, currency, side, price, quantity, targetCompId));

        for (int i = 0; i < limitThreshold + 1; i++) {
            final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
            order.body.senderCompId = sndrCompId;
            order.body.targetCompId = targetCompId;
            order.body.transactTime = acceptanceContext.precisionClock().nanos();
            order.body.timeInForce = timeInForce;
            order.body.orderQty = quantity;
            order.body.clOrdId = clOrdId;
            order.body.currency = currency;
            order.body.ordType = orderType;
            order.body.price = price;
            order.body.targetStrategyName = "Sweeper";
            order.body.securityType = instrumentKey.securityType();
            order.body.settlCurrency = currency;
            order.body.side = side;
            order.body.symbol = instrumentKey.symbol();
            order.body.settlType = instrumentKey.tenor();
            order.parties.add(new Party(PartyRole.USER_NAME, username));
            order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
            order.strategyParameters.add(new StrategyParameter("Markets", "FAST"));

            sorEndpoint.tradingRequest().add(order);
            if(i < limitThreshold -1){
                executionReportMatching.thenMatching(executionReportNewMatcher(symbol, marketId, orderType, currency, side, price, quantity, targetCompId));
            } else if(i == limitThreshold){
                executionReportMatching.thenMatching(executionReportBurstRejectedMatcher(symbol, marketId, orderType, currency, side, price, quantity, targetCompId));
            }
        }
        executionReportMatching.awaitMatchAndGetAll(10, TimeUnit.SECONDS);
    }

    protected ExecutionReportMatcher executionReportNewMatcher(final String symbol, final String marketId, final OrderType orderType,
                                                               final String currency, final Side side, final double price,
                                                               final double quantity, final String sndrCompId){
        final ExecutionReportMatcher newFoxOrderMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW));
        return appendCommonItems(newFoxOrderMatcher, symbol, marketId, orderType, currency, side, price, quantity, sndrCompId);
    }

    protected ExecutionReportMatcher executionReportBurstRejectedMatcher(final String symbol, final String marketId, final OrderType orderType,
                                                                         final String currency, final Side side,
                                                                         final double price, final double quantity,
                                                                         final String sndrCompId){
        final ExecutionReportMatcher rejectMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.rejectText().eq(rejectText))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.REJECTED))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.REJECTED));
        return appendCommonItems(rejectMatcher, symbol, marketId, orderType, currency, side, price, quantity, sndrCompId);
    }

    protected ExecutionReportMatcher appendCommonItems(ExecutionReportMatcher buildingMatcher,
                                                       final String symbol, final String marketId,
                                                       final OrderType orderType,
                                                       final String currency, final Side side,
                                                       final double price, final double quantity,
                                                       final String sndrCompId){
        return buildingMatcher.body().matches(ExecutionReportMatcher.senderCompId().eq(sndrCompId))
                .body().matches(ExecutionReportMatcher.marketId().eq(marketId))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity));
    }
}
