package com.anz.axle.lg.adapter.apama.transport;

import java.util.Objects;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.engine.beans.interfaces.EngineClientInterface;
import com.apama.event.Event;
import com.apama.event.parser.EventType;
import com.apama.net.beans.interfaces.BaseClientInterface;
import com.apama.services.event.IEventService;
import com.apama.services.event.IEventServiceChannel;

public class ApamaConnection implements Connection {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApamaConnection.class);

    private final EngineClientInterface engineClient;
    private final IEventService eventService;
    private final IEventServiceChannel serviceChannel;
    private final ConnectionConfig connectionConfig;

    public ApamaConnection(final EngineClientInterface engineClient,
                           final IEventService eventService,
                           final IEventServiceChannel serviceChannel,
                           final ConnectionStatusHandler connectionStatusHandler,
                           final ConnectionConfig connectionConfig) {
        this.engineClient = Objects.requireNonNull(engineClient);
        this.eventService = Objects.requireNonNull(eventService);
        this.serviceChannel = Objects.requireNonNull(serviceChannel);
        this.connectionConfig = Objects.requireNonNull(connectionConfig);

        this.engineClient.addPropertyChangeListener(BaseClientInterface.PROPERTY_BEAN_CONNECTED, evt -> {
            if ((Boolean) evt.getOldValue() && !(Boolean) evt.getNewValue()) {
                connectionStatusHandler.onDisconnect(this);
            } else if (!(Boolean) evt.getOldValue() && (Boolean) evt.getNewValue()) {
                connectionStatusHandler.onConnect(this);
            } else if (!(Boolean) evt.getOldValue() && !(Boolean) evt.getNewValue()) {
                connectionStatusHandler.onNotification(this, "Engine has notified connection attempt");
            }
        });
    }

    @Override
    public void close() {
        LOGGER.info("Closing apama connection {}", connectionConfig);
        eventService.dispose();
        engineClient.dispose();
    }

    @Override
    public Subscription openSubscription(final EventType eventType, final Consumer<Event> eventConsumer) {
        final EventListener eventListener = new EventListener(eventConsumer);

        final Runnable subscriptionCloser = () -> serviceChannel.removeEventListener(eventListener, eventType);
        serviceChannel.addEventListener(eventListener, eventType);

        return new ApamaSubscription(subscriptionCloser);
    }

    @Override
    public ConnectionConfig connectionConfig() {
        return connectionConfig;
    }
}
