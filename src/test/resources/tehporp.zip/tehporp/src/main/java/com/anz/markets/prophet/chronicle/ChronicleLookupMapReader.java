package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * ChronicleReader that reads in entities and ensures that there is a different object instance for each unique enum
 */
public class ChronicleLookupMapReader<KEY extends Enum<KEY>, VALUE extends ProphetMarshallable> implements ChronicleObjectReader {
    private final ProphetMarshallableCopier copier = new ProphetMarshallableCopier();

    private final Map<KEY, VALUE> entityMap;
    private final VALUE entity;
    private final Supplier<VALUE> supplier;
    private final Consumer<VALUE> consumer;
    private final Function<VALUE, KEY> keySupplier;
    private final Predicate<VALUE> predicate;

    public ChronicleLookupMapReader(final Supplier<VALUE> supplier,
                                    final Predicate<VALUE> predicate,
                                    final Consumer<VALUE> consumer,
                                    final Function<VALUE, KEY> keySupplier,
                                    final Class<KEY> keyType) {
        this.entity = supplier.get();
        this.supplier = supplier;
        this.predicate = predicate;
        this.consumer = consumer;
        this.keySupplier = keySupplier;
        this.entityMap = new EnumObjMap<>(keyType);
    }

    @Override
    public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
        entity.readMarshallable(bytes);
        Context.overrideStartTimeStamp();

        if (!predicate.test(entity)) {
            return;
        }

        final VALUE individualEntity = entityMap.computeIfAbsent(keySupplier.apply(entity), (k1) -> supplier.get());
        copier.copy(entity, individualEntity);
        consumer.accept(individualEntity);
    }
}
