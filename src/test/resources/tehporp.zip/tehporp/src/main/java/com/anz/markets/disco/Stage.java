package com.anz.markets.disco;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class Stage {

    private final Logger log = LoggerFactory.getLogger(Stage.class);

    private final MessageBus messageBus = new MessageBus();
    private final List<InputModule> inputModules = new ArrayList<>();
    private final List<Module> processingModules = new ArrayList<>();
    private final String name;

    public Stage(String name) {
        this.name = name;
        log.info("Created stage: {}", name);
    }

    public String getName() {
        return name;
    }

    public MessageBus getMessageBus() {
        return messageBus;
    }

    public List<InputModule> getInputModules() {
        return inputModules;
    }

    public List<Module> getProcessingModules() {
        return processingModules;
    }

    public void addInputModule(InputModule module) {
        log.info("[{}] Adding input module: {}", name, module.getName());
        module.init(this);
        inputModules.add(module);
    }

    public void addProcessingModule(Module module) {
        log.info("[{}] Adding processing module: {}", name, module.getName());
        module.init(this);
        processingModules.add(module);
    }

    public <T> T getProcessingModule(Class<T> clazz) {
        return (T) getProcessingModule(clazz.getSimpleName());
    }

    public Module getProcessingModule(String name) {
        for (int i = 0; i < processingModules.size(); i++) {
            final Module module = processingModules.get(i);
            if (module.getName().equals(name)) {
                return module;
            }
        }
        throw new RuntimeException("Module does not exist: " + name);
    }

    public void start() {
        log.info("[{}] Starting stage", name);
        for (int i = 0; i < inputModules.size(); i++) {
            final InputModule module = inputModules.get(i);
            log.info("[{}]   Starting input module: {}", name, module.getName());
            module.start();
        }
        log.info("[{}] Stage started", name);
    }

    public void cleanup() {
        log.info("[{}] Cleaning up stage", name);
        for (int i = 0; i < inputModules.size(); i++) {
            final InputModule module = inputModules.get(i);
            log.info("[{}]   Cleanup: {}", name, module.getName());
            module.finish();
        }
        for (int i = 0; i < processingModules.size(); i++) {
            final Module module = processingModules.get(i);
            log.info("[{}]   Cleanup: {}", name, module.getName());
            module.finish();
        }
        log.info("[{}] Stage cleanup complete", name);
    }

    public void run() {
        start();
        while(true) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                ;
            }
            boolean isFinished = true;
            for (int i = 0; i < inputModules.size(); i++) {
                isFinished &= inputModules.get(i).isFinished();
            }
            if (isFinished) {
                break;
            }
        }
        cleanup();
    }
}
