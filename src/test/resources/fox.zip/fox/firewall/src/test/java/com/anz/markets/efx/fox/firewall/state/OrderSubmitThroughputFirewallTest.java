package com.anz.markets.efx.fox.firewall.state;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.firewall.FirewallTestContext;
import com.anz.markets.efx.fox.firewall.TestOrderFactory;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import static org.assertj.core.api.Assertions.assertThat;


@RunWith(Spockito.class)
public class OrderSubmitThroughputFirewallTest {

    private final static String[] USERS = new String[] {
            "| userName | desk   |",
            "|==========|========|",
            "| anufriea | Some   |",
            "| marsdenj | Some   |",
            "|----------|--------|"
    };


    @Test
    @Spockito.Unroll({
            "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | markets   | result    |",
            "|=============|========|================|===========|==========|==============|=======|========|==========|===========|===========|",
            "| 1000007     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | false     |",
            "| 1000010     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | false     |",
            "| 3000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | true      |",
            "| 4000010     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | true      |",
    })
    public void orderSubmitThroughput_username_specific(final long timeNanos,
                                                        final  String region,
                                                        final  String targetStrategy,
                                                        final  String portfolio,
                                                        final  String username,
                                                        final  SecurityType securityType,
                                                        final  Tenor tenor,
                                                        final  String symbol,
                                                        final  double orderQty,
                                                        final  String markets,
                                                        final  boolean result
    ) {

        final String[] rules = new String[] {
                "| firewallName   | ruleId   | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period   | periodUnit    | local    | comment  | lastEditUsername | lastEditTime  | limitThreshold |",
                "|================|==========|===============|==================|=============|==================|=================|==============|=====================|==============|===============|==========|===============|==========|==========|==================|===============|================|",
                "| firewall1      | 10       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 3              |",
                "| firewall1      | 20       | .*            | .*               | .*          | .*               | anuf.*          | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 4              |",
                "| firewall1      | 30       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 5              |",
                "| firewall1      | 40       | .*            | .*               | .*          | .*               | marsdenj        | .*           | .*                  | .*           | .*            | 1        | ms            | true     | blah     | anufriea         | 3456          | 1              |",
                // should not be applied:
                "| firewall2      | 50       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 1              |",
                "| firewall2      | 60       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 1              |"
        };

        String[] appliedExecutionReports = new String[] {
                "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | lastUsdQty | markets   | execType  | leavesQty  |",
                "|=============|========|================|===========|==========|==============|=======|========|==========|============|===========|===========|============|",
                "| 1000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000001     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000002     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000003     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000004     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "|-------------|--------|----------------|-----------|----------|--------------|-------|--------|----------|------------|-----------|-----------|------------|"
        };

        final FirewallTestContext testContext = new FirewallTestContext(Firewall::orderSubmitThroughput, "firewall1", rules, appliedExecutionReports, USERS);

        final TestOrderFactory.OrderStub orderStub = new TestOrderFactory.OrderStub(timeNanos, region, targetStrategy,
                portfolio, username, securityType, tenor, symbol, orderQty, markets);

        testContext.precisionClock.accept(timeNanos);

        final NewOrderSingleDecoder newOrderSingle = testContext.testOrderFactory.createOrder(orderStub);
        assertThat(testContext.firewall.accept(newOrderSingle, testContext.commandContext)).isEqualTo(result);
    }


    @Test
    @Spockito.Unroll({
            "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | markets   | result    |",
            "|=============|========|================|===========|==========|==============|=======|========|==========|===========|===========|",
            "| 1000007     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | false     |",
            "| 3000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | true      |",
    })
    public void orderSubmitThroughput_portfolio_specific(final long timeNanos,
                                                         final  String region,
                                                         final  String targetStrategy,
                                                         final  String portfolio,
                                                         final  String username,
                                                         final  SecurityType securityType,
                                                         final  Tenor tenor,
                                                         final  String symbol,
                                                         final  double orderQty,
                                                         final  String markets,
                                                         final  boolean result
    ) {

        final String[] rules = new String[] {
                "| firewallName   | ruleId   | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period   | periodUnit    | local    | comment  | lastEditUsername | lastEditTime  | limitThreshold |",
                "|================|==========|===============|==================|=============|==================|=================|==============|=====================|==============|===============|==========|===============|==========|==========|==================|===============|================|",
                "| firewall1      | 10       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 3              |",
                "| firewall1      | 20       | .*            | .*               | .*          | X.*              | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 4              |",
                "| firewall1      | 30       | .*            | .*               | .*          | XEFX             | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 5              |",
        };

        String[] appliedExecutionReports = new String[] {
                "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | lastUsdQty | markets   | execType  | leavesQty  |",
                "|=============|========|================|===========|==========|==============|=======|========|==========|============|===========|===========|============|",
                "| 1000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000001     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000002     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000003     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000004     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "|-------------|--------|----------------|-----------|----------|--------------|-------|--------|----------|------------|-----------|-----------|------------|"
        };

        final FirewallTestContext testContext = new FirewallTestContext(Firewall::orderSubmitThroughput, "firewall1", rules, appliedExecutionReports, USERS);

        final TestOrderFactory.OrderStub orderStub = new TestOrderFactory.OrderStub(timeNanos, region, targetStrategy,
                portfolio, username, securityType, tenor, symbol, orderQty, markets);

        testContext.precisionClock.accept(timeNanos);

        final NewOrderSingleDecoder newOrderSingle = testContext.testOrderFactory.createOrder(orderStub);
        assertThat(testContext.firewall.accept(newOrderSingle, testContext.commandContext)).isEqualTo(result);
    }
}