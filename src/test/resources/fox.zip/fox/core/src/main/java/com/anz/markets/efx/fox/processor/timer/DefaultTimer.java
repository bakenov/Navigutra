package com.anz.markets.efx.fox.processor.timer;

import java.util.Objects;

/**
 * Non-thread-safe
 */
public class DefaultTimer implements Timer {
    private final TimerScheduler timerScheduler;
    private final TimerScheduler.ExpiryHandler expiryHandler;

    private long timerId = -1;

    public DefaultTimer(final TimerScheduler timerScheduler,
                        final TimerScheduler.ExpiryHandler expiryHandler) {
        this.timerScheduler = Objects.requireNonNull(timerScheduler);
        this.expiryHandler = Objects.requireNonNull(expiryHandler);
    }

    @Override
    public void schedule(final long timeoutMillis) {
        timerId = timerScheduler.schedule(timeoutMillis, expiryHandler);
    }

    @Override
    public void cancel() {
        if (timerId >= 0) {
            if (timerScheduler.cancel(timerId)) {
                timerId = -1;
            }
        }
    }
}
