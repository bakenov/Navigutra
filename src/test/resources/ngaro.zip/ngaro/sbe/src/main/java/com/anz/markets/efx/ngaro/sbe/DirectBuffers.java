package com.anz.markets.efx.ngaro.sbe;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteWriter;

/**
 * Class with static methods and constants dealing with {@link org.agrona.DirectBuffer}s.
 */
public final class DirectBuffers {

    public static final ByteReader<DirectBuffer> BYTE_READER = (s, i) -> s.getByte(i);
    public static final ByteWriter<MutableDirectBuffer> BYTE_WRITER = (s, i, b) -> s.putByte(i, b);

    private DirectBuffers() {
        throw new RuntimeException("no DirectBuffers for you!");
    }
}
