package com.anz.markets.efx.fox.processor.event;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.UserSession;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.api.domain.UserSessionRepository;
import com.anz.markets.efx.fox.api.domain.Venue;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.processor.state.usersession.UserSessionKeyFactory;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.HeartbeatSbeDecoder;

public class HeartbeatEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(HeartbeatEvent.class);

    private final String foxSenderCompId;
    private final UserSessionRepository userSessionRepository;
    private final VenueRepository venueRepository;


    private final HeartbeatSbeDecoder heartbeatDecoder = new HeartbeatSbeDecoder();
    private final Map<String, UserSessionKey> userSessionKeyMap = new HashMap<>();
    private final UserSessionKeyFactory userSessionKeyFactory = new UserSessionKeyFactory();
    private final ByteValueCache<String> senderCompIdCache = new ByteValueCache<>(AsciiString::toString);

    private final StringBuilder stringBuilder = new StringBuilder();

    public HeartbeatEvent(final String foxSenderCompId,
                          final UserSessionRepository userSessionRepository,
                          final VenueRepository venueRepository) {
        this.foxSenderCompId = Objects.requireNonNull(foxSenderCompId);
        this.userSessionRepository = Objects.requireNonNull(userSessionRepository);
        this.venueRepository = Objects.requireNonNull(venueRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!heartbeatDecoder.wrap(message)) return false;

        final String senderCompId = heartbeatDecoder.body().senderCompId().decodeAndCache(senderCompIdCache);
        if (senderCompId.equals(foxSenderCompId)) return true;

        final UserSessionKey userSessionKey = userSessionKeyMap.computeIfAbsent(senderCompId, userSessionKeyFactory);

        logMessage();

        if (userSessionKey != UserSessionKey.UNKNOWN) {
            final UserSession userSession = userSessionRepository.userSession(userSessionKey);
            if (userSession != null) {
                userSession.updateOnline();
            }
        } else {
            final Venue venue = venueRepository.lookup(senderCompId);
            if (venue != null) {
                venue.updateOnline();
            }
        }
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        heartbeatDecoder.appendTo(stringBuilder);
        LOGGER.info("Heartbeat event: {}", stringBuilder);
    }
}
