package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

@Configuration
public class PricingSubscriptionConfig {

    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final AsyncMarketDataSubscriber asyncMarketDataSubscriber;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory;
    private final Venue venue;

    public PricingSubscriptionConfig(final TopicRegistry pricingTopicRegistry,
                                     final PublicationRegistry publicationRegistry,
                                     final AsyncMarketDataSubscriber asyncMarketDataSubscriber,
                                     @Value ("${venue}") final Venue venue,
                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                     final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory) {
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.asyncMarketDataSubscriber = Objects.requireNonNull(asyncMarketDataSubscriber);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.stringToIntQuoteIdCacheFactory = Objects.requireNonNull(stringToIntQuoteIdCacheFactory);
        this.venue = Objects.requireNonNull(venue);
    }

    @PostConstruct
    void init() {
        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol));

            publicationRegistry.registerPublication(topic);

            final HspItchMarketDataSubscription itchSubscription = new HspItchMarketDataSubscription(venue, SymbolNormaliser.toSymbol7(symbol), stringToIntQuoteIdCacheFactory.get());
            asyncMarketDataSubscriber.schedule(itchSubscription);
        });
    }
}
