package com.anz.axle.lg.adapter.dbs.chroniclefix.uat;

import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.dbs.chroniclefix.acceptance.AcceptanceConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;

@Category(UatTest.class)
@RunWith(Spockito.class)
public class UatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatIntegrationTest.class);
    public static final String GB_LG_DBS = "GB:lg-dbs";
    public static final String GB_LG_ACC = "GB:lg-acc";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private PriceListener priceListener;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(StringUtils.parseMap(
                "appName:lg-dbs" +
                        ",default.log.appender:Console" +
                        ",default.log.level:DEBUG" +
//                        ",appOptions:--reset" +
//                        ",appOptions:--resetseqnum-R-W" +
                        ",chronicle.fix.logging:true" +
                        ",dbs.fix.trading.allowedLatencyMs:60000" +

                        ",dbs.fix.pricing.sendercompid:ANZ_FLEX" +
                        ",dbs.fix.pricing.targetcompid:FLEXECNP" +
                        ",dbs.fix.pricing.host:10.54.189.56" +
                        ",dbs.fix.pricing.port:23115" +

                        ",dbs.fix.trading.sendercompid:ANZ_FLEX" +
                        ",dbs.fix.trading.targetcompid:FLEXECN" +
                        ",dbs.fix.trading.host:10.54.189.56" +
                        ",dbs.fix.trading.port:23015" +

                        ",dbs.fix.pricing.log_all:true" +
                        ",dbs.fix.trading.log_all:true"
        ));

        application = new Application("lg-dbs-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        priceListener = new PriceListener(acceptanceContext.pricingMessageQueue());
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void testSendOrderAndReceiveExecutionReport() throws Exception {
        testSendSPOTOrderAndReceiveExecutionReport();
//        testSendNDFOrderAndReceiveExecutionReport();
    }

    public void testSendSPOTOrderAndReceiveExecutionReport() throws Exception {

        final IncrementalRefreshMatcher spotPriceMatcher = IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(GB_LG_DBS))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.DBS))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT, Tenor.SP)))
                .entries().anyMatches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                .entries().anyMatches(IncrementalRefreshMatcher.mdEntryPx().gt(0.0))
                .hops().hasAny();

        sendOrderAndReceiveExecutionReport(priceListener.awaitPrice(spotPriceMatcher));
    }

    public void testSendNDFOrderAndReceiveExecutionReport() throws Exception {

        final IncrementalRefreshMatcher matcher = IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(GB_LG_DBS))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.DBS))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDKRW", SecurityType.FXNDF, Tenor.M1)))
                .entries().anyMatches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                .entries().anyMatches(IncrementalRefreshMatcher.mdEntryPx().gt(0.0))
                .hops().hasAny();

        sendOrderAndReceiveExecutionReport(priceListener.awaitPrice(matcher));
    }

    private void sendOrderAndReceiveExecutionReport(final PriceEntry priceEntry) throws Exception {

        System.out.println(priceEntry);
        System.out.println("==============================================================");

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final NewOrderSingle newOrderSingle = newOrderSingle(priceEntry, clOrdId, priceEntry.side, priceEntry.price,
                priceEntry.quoteId, priceEntry.size, priceEntry.currency(), OrderType.LIMIT);
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertSingleFill(priceEntry, clOrdId);
    }


    private NewOrderSingle newOrderSingle(final PriceEntry entry, final String clOrdId, final Side side, final double price, final int quoteId,
                                          final double size, final String currency, final OrderType orderType) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.quoteId = String.valueOf(quoteId);
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.settlDate = entry.settlDate;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.symbol = entry.instrumentKey.symbol();
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.side = side;
        newOrderSingle.body.timeInForce = TimeInForce.IOC;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.securityType = entry.instrumentKey.securityType();
        return newOrderSingle;
    }

    private void assertSingleFill(final PriceEntry priceEntry, final String clOrdId) throws Exception {

        TimeUnit.SECONDS.sleep(5);
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_DBS))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.symbol().eq(priceEntry.instrumentKey.symbol()))
                        .body().matches(ExecutionReportMatcher.side().eq(priceEntry.side))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(30, TimeUnit.SECONDS);
    }
}