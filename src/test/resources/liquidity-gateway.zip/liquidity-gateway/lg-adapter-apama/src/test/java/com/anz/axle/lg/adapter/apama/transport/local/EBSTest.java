package com.anz.axle.lg.adapter.apama.transport.local;

import java.util.List;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.marketId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.mdEntryPx;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.mdEntryType;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.mdUpdateAction;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.senderCompId;
import static org.assertj.core.api.Assertions.assertThat;


public class EBSTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(EBSTest.class);
    private Application application;
    private Queue<PricingMessage> messageQueue;

    private static final String INTI_SNAPSHOT =
        "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"AUD/USD\",2,[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.78815,4e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7881,1e+07,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.788,9e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.78795,6e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7879,7e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.78785,3e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7878,9e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78845,4e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.7885,4e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78855,1e+07,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78865,9e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.7887,6e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78875,7e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.7888,3e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"1\",.78885,9e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"x\",.7882,0,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"w\",.78845,0,\"\",{})],{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})";

    @Rule
    public final TestName testName = new TestName();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.setProperty("appName", "lgt-ebs");
        application = new Application("lgt-ebs", EBSTestConfig.class);
        application.startAndAwaitStarted();

        messageQueue = (Queue<PricingMessage>) application.getApplicationContext().getBean("messageQueue");

    }

    @After
    public void afterEach() {
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }


    @Test
    public void testInitialSnapshot() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");
        final List<String> messages = Lists.newArrayList(
                INTI_SNAPSHOT
                //print snapshot and then clean it
                , "com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
        );

        messages.forEach(eventStringConsumer::accept);

        Asserter.of(messageQueue)
            .matching(SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                .entries().countEquals(16)
                .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(0.7882))
                .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(0.78815))
                .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(0.7881))

                .entries().atIndex(8).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                .entries().atIndex(8).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(0.78845))
                .hops().hasAny()
                .hops().countAtLeast(2))
            .awaitMatchAndGetAll(10, TimeUnit.SECONDS);
    }

    @Test
    public void shouldTranslateCorrectly() throws Exception {
        //given
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");
        final List<String> messages = Lists.newArrayList(
                INTI_SNAPSHOT
                // Receive update with new/replace/delete
                ,"com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"USD/RUB\",.7884,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"USD/RUB\",.7884,4e+06,\"\",{461:\"FFCNNO\",63:\"M1\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/USD\",.7884,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.78845,6e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,1e+07,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"AUD/USD\",.78855,1e+07,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"w\",\"\",\"AUD/USD\",.7884,0,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:06:52.091\",\"20203\":\"1\"})"
                ,"com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
                // Receive update with new/replace/delete
                ,"com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7884,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.78845,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/USD\",.7886,9e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"AUD/USD\",.78865,9e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:06:52.341\",\"20203\":\"1\"})"
                ,"com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
                // Receive update with replace/delete
                ,"com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"AUD/USD\",.7882,2.7e+07,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"AUD/USD\",.78815,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"AUD/USD\",.7881,1e+07,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"AUD/USD\",.788,9e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7884,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"AUD/USD\",.78845,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,2.5e+07,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"AUD/USD\",.7886,9e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.091\",\"20203\":\"1\"})"
                ,"com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
                // Receive update with replace
                ,"com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"AUD/USD\",.7884,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,2.7e+07,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"w\",\"\",\"AUD/USD\",.7885,0,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})"
                //print snapshot and then clean it
                ,"com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
        );

        //when
        messageQueue.clear();
        messages.forEach(eventStringConsumer::accept);

        //then
        Asserter.of(messageQueue)
                // snapshot
                .matching(SnapshotFullRefreshMatcher.build()
                    .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                    .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                    .entries().countEquals(16)
                    .hops().hasAny()
                    .hops().countAtLeast(2))
                // Receive update with new/replace/delete
                .thenMatching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.EBS))
                        .entries().countEquals(4)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(1).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(2).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(3).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                // Receive update with new/replace/delete
                .thenMatching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.EBS))
                        .entries().countEquals(4)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(1).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(2).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(3).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                // Receive update with replace/delete
                .thenMatching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.EBS))
                        .entries().countEquals(8)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(1).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(2).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(3).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(4).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(5).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(6).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(7).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                // Receive update with replace
                .thenMatching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.EBS))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(1).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetLast(15, TimeUnit.SECONDS);
    }

    @Test
    public void usdrub() throws Exception {
        //given
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");
        final List<String> messages = Lists.newArrayList(
                // Receive new for USD/RUB FXSPOT, USD/RUB NDF, AUD/USD SPOT
                "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[" +
                        "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"USD/RUB\",0.7884,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                        "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"USD/RUB\",0.7884,1e+06,\"\",{461:\"FFCNNO\",63:\"M1\"})," +
                        "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/USD\",.7884,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"})]," +
                        "{},{\"35\":\"X\",\"52\":\"20150225-05:06:52.091\",\"20203\":\"1\"})"
        );

        //when
        messageQueue.clear();
        messages.forEach(eventStringConsumer::accept);

        //then
        Asserter.of(messageQueue)
                // snapshot
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDRUB", SecurityType.FXSPOT, Tenor.SP)))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                //Ignore USDRUB NDF
                .thenMatching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT,Tenor.SP)))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(15, TimeUnit.SECONDS);
    }


    @Test
    public void shouldClearBookOnNoDataQuoteStatus() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        final List<String> messages = Lists.newArrayList(
                "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NZD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NZD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/HKD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/HKD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/HKD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/HKD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/SEK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/SEK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/NOK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/NOK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/SGD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/SGD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SGD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SGD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"CHF/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"CHF/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"CHF/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"CHF/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NOK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NOK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/NZD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/NZD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/AUD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/AUD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/ZAR\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/ZAR\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/ZAR\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/ZAR\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/DKK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/DKK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/DKK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/DKK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SEK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SEK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/GBP\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/GBP\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/GBP\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/GBP\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/AUD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/AUD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/CNH\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/CNH\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CNH\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CNH\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/NZD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/NZD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})],{},{\"35\":\"X\",\"52\":\"20150305-21:11:09.859\",\"20203\":\"1\"})"
                //print snapshot and then clean it
                , "com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
        );

        messages.forEach(eventStringConsumer::accept);

        final SnapshotFullRefreshMatcher emptySnapshotFullRefreshMatcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                .entries().hasNone()
                .hops().hasAny()
                .hops().countAtLeast(1);

        Asserter.NextMatchBuilder<PricingMessage> nextMatchBuilder = Asserter.of(messageQueue).matching(emptySnapshotFullRefreshMatcher);
        for (int i = 0; i < 67; i++) {
            nextMatchBuilder = nextMatchBuilder.thenMatching(emptySnapshotFullRefreshMatcher);
        }

        final List<PricingMessage> pricingMessages = nextMatchBuilder.awaitMatchAndGetAll(5, TimeUnit.SECONDS);

        assertThat(pricingMessages.size()).isEqualTo(68).as("Receive all empty entries");
    }

    @Test
    public void shouldClearBookOnNoMarketQuoteStatus() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        final List<String> messages = Lists.newArrayList(
                "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1000\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1000\",277:\"1001\"})],{},{\"35\":\"X\",\"52\":\"20150305-21:11:09.859\",\"20203\":\"1\"})"
                //print snapshot and then clean it
                , "com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
        );

        messages.forEach(eventStringConsumer::accept);

        final SnapshotFullRefreshMatcher emptySnapshotFullRefreshMatcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                .entries().hasNone()
                .hops().hasAny()
                .hops().countAtLeast(1);

        List<PricingMessage> pricingMessages = Asserter.of(messageQueue)
                .matching(emptySnapshotFullRefreshMatcher)
                .thenMatching(emptySnapshotFullRefreshMatcher)
                .awaitMatchAndGetAll(10, TimeUnit.SECONDS);

        assertThat(pricingMessages.size()).isEqualTo(2).as("Receive all empty entries");
    }

    @Test
    public void shouldHandleMultipleInstrumentRefresh() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        final List<String> messages = Lists.newArrayList(
                "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/HKD\",1.22453,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/USD\",1.22451,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})"
                //print snapshot and then clean it
                , "com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
        );

        messages.forEach(eventStringConsumer::accept);

        final SnapshotFullRefreshMatcher snapshotFullRefreshMatcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                .entries().countEquals(1)
                .hops().hasAny()
                .hops().countAtLeast(1);

        final IncrementalRefreshMatcher incrementalRefreshMatcher = IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                .entries().countEquals(1)
                .hops().hasAny()
                .hops().countAtLeast(2);

        List<PricingMessage> pricingMessages = Asserter.of(messageQueue)
                .matching(incrementalRefreshMatcher)
                .thenMatching(incrementalRefreshMatcher)
                .thenMatching(snapshotFullRefreshMatcher)
                .thenMatching(snapshotFullRefreshMatcher)
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);

        assertThat(pricingMessages.size()).isEqualTo(4).as("Receive 2 increments and snapshot for each from hearbeat");
    }

    @Test
    public void shouldDropNonPriceDepthUpdates() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        final List<String> messages = Lists.newArrayList(
                "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"USD/HKD\",1,[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22453,2e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22451,2e+06,\"\",{})],{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})"
                , "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",1,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NAN/INF\",1.22454,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})"
                //print snapshot and then clean it
                , "com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)"
        );

        messages.forEach(eventStringConsumer::accept);

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .entries().hasAny()
                        .hops().hasAny())
                .thenMatching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .entries().hasAny()
                        .hops().hasAny())
                .awaitNotMatching(1, TimeUnit.SECONDS);
    }

    @Test
    public void shouldIgnoreUpdateForUnknownInstrument() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        // Establish initial snapshot
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"USD/HKD\",2,[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22453,2e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22451,2e+06,\"\",{})],{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})");

        Asserter.of(messageQueue)
            .matching(SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                .entries().countEquals(2)
                .hops().hasAny()
                .hops().countAtLeast(2))
            .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test update for unknown instrument "NAN/INF"
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NAN/INF\",1.22454,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .entries().hasAny()
                        .hops().hasAny())
                .thenMatching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .entries().hasAny()
                        .hops().hasAny())
                .awaitNotMatching(1, TimeUnit.SECONDS);

        // Test update for known and unknown instrument
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_ORANGE_GB_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"USD/HKD\",1.22453,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"NAN/INF\",8.8945,1.8e+07,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150327-02:45:11.746\",\"20203\":\"1\"})");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22453))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test delete for known and update unknown instrument
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_ORANGE_GB_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"USD/HKD\",1.22453,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"NAN/INF\",8.8945,1.8e+07,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150327-02:45:11.746\",\"20203\":\"1\"})");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22453))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test delete for known and unknown instrument
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_ORANGE_GB_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"USD/HKD\",1.22453,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"x\",\"\",\"USD/HKD\",1.22453,0,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"NAN/INF\",8.8945,1.8e+07,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150327-02:45:11.746\",\"20203\":\"1\"})");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().hasNone() // emptyBook
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
    }

    @Test
    public void shouldMatchDocumentedExample() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        // This sequence of events come from the EBS Ai 6.6 FIX 1.6 Message Spec.pdf
        // Note that USDHKD is used for this test as has properties:
        // - depth of 3 (see apama-ebsconfig-context.xml) and
        // - price increment of 0.00001 (see client-adapter-PricingConfiguration.properties)
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"USD/HKD\",2,[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22453,2e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22451,2e+06,\"\",{})],{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"RCSXXX\",\"52\":\"20150225-05:06:24.575\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22453))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");


        // Test add new level
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/HKD\",1.22454,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22454))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test update at existing level
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"0\",\"\",\"USD/HKD\",1.22451,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");


        // Test implicit delete
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/HKD\",1.22452,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22452))
                        .entries().atIndex(1).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(1).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test explicit delete and new
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"USD/HKD\",1.22453,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/HKD\",1.22451,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22453))
                        .entries().atIndex(1).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(1).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test delete TOB
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"USD/HKD\",1.22454,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22454))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
    }

    @Test
    public void shouldSupportNDFNonBrokenPrices() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"USD/INR\",2,[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22453,2e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22451,2e+06,\"\",{})],{},{\"35\":\"W\",\"63\":\"M1\",\"461\":\"FFCNNO\",\"52\":\"20150225-05:06:24.575\"})");

        Asserter.of(messageQueue)
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.M1)))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22453))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test add new level
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/INR\",1.22454,1e+06,\"\",{461:\"FFCNNO\",63:\"M1\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.M1)))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22454))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // heartbeat to trigger snapshot
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.M1)))
                        .entries().countEquals(3)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22454))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22453))
                        .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
    }

    @Test
    public void shouldSupportNDFWithSettlementDatePrices() throws Exception {
        final Consumer<String> eventStringConsumer = (Consumer<String>) application.getApplicationContext().getBean("eventStringConsumer");

        // This sequence of events come from the EBS Ai 6.6 FIX 1.6 Message Spec.pdf
        // Note that USDHKD is used for this test as has properties:
        // - depth of 3 (see apama-ebsconfig-context.xml) and
        // - price increment of 0.00001 (see client-adapter-PricingConfiguration.properties)

        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"USD/INR\",2,[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22451,2e+06,\"\",{}),com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",1.22453,2e+06,\"\",{})],{},{\"35\":\"W\",\"63\":\"B\",\"64\":\"20150327\",\"461\":\"FFCNNO\",\"52\":\"20150225-05:06:24.575\"})");

        Asserter.of(messageQueue)
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.EOM3)))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22453))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22451))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test add new level
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/INR\",1.22456,1e+06,\"\",{461:\"FFCNNO\",63:\"B\",64:\"20150327\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.EOM3)))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22456))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .thenMatching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.EOM3)))
                        .entries().countEquals(3)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22453))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22451))
                        .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22456))
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);
        messageQueue.clear();
        assertThat(messageQueue.size()).isEqualTo(0).describedAs("Should be cleared/drained");

        // Test add new level
        eventStringConsumer.accept("com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2,[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/INR\",1.22455,1e+06,\"\",{461:\"FFCNNO\",63:\"B\",64:\"20150327\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})");
        eventStringConsumer.accept("com.apama.fix.HeartbeatResponse(\"EBS_FIX_MARKETDATA_AND_TRADING\",5060,true)");

        Asserter.of(messageQueue)
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(marketId().eq(Venue.EBS))
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.EOM3)))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(0).matches(mdEntryPx().eq(1.22455))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .thenMatching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lgt-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.EBS))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.EOM3)))
                        .entries().countEquals(4)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22453))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22451))
                        .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(2).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22455))
                        .entries().atIndex(3).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(3).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.22456))
                        .hops().hasAny()
                        .hops().countAtLeast(1))
                .awaitMatchAndGetAll(5, TimeUnit.SECONDS);

    }
}
