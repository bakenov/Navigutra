package com.anz.markets.efx.ngaro.codec;

public interface MessageForwarder {
    MessageForwarder NO_OP = destination -> false;

    boolean forward(String destination);
}
