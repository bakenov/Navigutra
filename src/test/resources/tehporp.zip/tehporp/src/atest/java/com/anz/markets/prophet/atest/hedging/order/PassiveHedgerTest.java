package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PassiveHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerState.CANCELLING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.CANCEL_REQ;
import static com.anz.markets.prophet.domain.HedgeTriggerState.IDLE;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELLING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELL_REQ;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Market.EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_ARBITRAGE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_RFX;
import static java.lang.Math.abs;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "As hedger states are left hanging")
public class PassiveHedgerTest extends BaseAcceptanceSpecification {
    private NewOrder newOrder;
    private CancelOrder cancelOrder;

    @Test
    public void shouldNotEmitHedgingOrderWhenDisabled() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75005));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, HedgeTriggerState.SELL_REQ));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void sendOrderWhenLongPosReachesMinRisk() {
        double minimumRisk = 1_500_001.5d;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(minimumRisk)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // Min risk not reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));
        }
        and:
        // no hedging order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1, 0.750000));
        }
        then:
        // GradientPosition EQUALS Risk min risk
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, minimumRisk));
        }
        and:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(), is(1_250_000d));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    public void sendOrderWhenShortPosReachesMinRisk() {
        double minimumRisk = 1_500_001.5d;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(minimumRisk)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // Min Risk not reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1500000.0));
        }
        and:
        // no hedging order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1, 0.750000));
        }
        then:
        // GradientPosition EQUALS Min Risk
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1500001.5));
        }
        and:
        {
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.BUY_REQ));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.BUYING));

            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(1_250_000d));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void sendOrderWhenBiasedPosReachesMinRisk() {
        double minimumRisk = 1_500_000.0;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(minimumRisk)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
            // set up position bias
            prophet.receive(tdd.biasPosition(Currency.AUD, -1.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // Min Risk not reached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1499998.5));
        }
        and:
        // no hedging order
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
        }
        when:
        // set bias to 0
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.biasPosition(Currency.AUD, 0.0));
        }
        then:
        // Biased GradientPosition EQUALS Min Risk => hedge
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, -1500000.0));
        }
        and:
        {
            final NewOrder newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(1_250_000d));
            assertThat(newOrder.getInstrument(), is(AUDUSD));
        }
    }

    @Test
    public void sendOrdersAdheringThrottleLimits() {
        int throttleLimitOrders = 2;
        long throttleLimitTimePeriod = 2000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_M3")
                                    .setMaximumOpenOrders(5)
                                    .setMaximumOpenQuantity(0d)
                                    .setMaximumOpenVarOrders(0)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.GBPUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_250_000),
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.EURUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_250_000),
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_250_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(EBS, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(EBS, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(EBS, GBPUSD, 1.25000));
        }
        when:
        // t+1sec
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.receive(tdd.client_trade_001(GBPUSD, -1_000_000, 1.25000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
        }
        when:
        // t+2.999sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(999));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));
        }
        then:
        // Due to throttle limits of 2 orders in last 2 seconds, order is throttled(ie. only SELL_REQ)
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, HedgeTriggerType.PAS_EBS_EP)).getFirst();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+3.000sec
        {
            prophet.clearOutputBuffer();
            // note that hedger will make decisions on the 1 sec chime, so no need to send another order
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void doNotSendPrevThrottledOrderAfterUpdatedEP() {
        int throttleLimitOrders = 2;
        long throttleLimitTimePeriod = 2000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_M3")
                                    .setMaximumOpenOrders(5)
                                    .setMaximumOpenQuantity(0d)
                                    .setMaximumOpenVarOrders(0)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(1)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(throttleLimitOrders)
                                    .setThrottleLimitTimePeriodMS(throttleLimitTimePeriod)
                                    .setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.GBPUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_250_000),
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.EURUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_250_000),
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_250_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(EBS, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(EBS, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(EBS, GBPUSD, 1.25000));
        }
        when:
        // t+1sec
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        // t+2sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.receive(tdd.client_trade_001(GBPUSD, -1_000_000, 1.25000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD)).getFirst();
        }
        when:
        // t+2.5sec
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));
        }
        then:
        // Due to throttle limits of 2 orders in last 2 seconds, order is throttled(ie. only SELL_REQ)
        {
            HedgeDecision hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(EURUSD, HedgeTriggerType.PAS_EBS_EP)).getFirst();
            assertThat(hedgeDecision.getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+2.9sec receive client deal
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400));
            prophet.receive(tdd.client_trade_001(EURUSD, -1_500_000, 1.05000));
        }
        then:
        // Latest GradientPos for EURUSD is 0. Hedger returns to IDLE
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(EURUSD, 0.0));

            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(EURUSD, HedgeTriggerType.PAS_EBS_EP, HedgeTriggerState.IDLE)).getFirst();
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+3.0sec. First order slides out of window but no need to hedge anymore
        {
            prophet.clearOutputBuffer();
            // note that hedger will make decisions on the 1 sec chime, so no need to send another order
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void cancelOrderWhenGradientPosBelowMinRisk() {
        double minRisk = 1_500_000d;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(minRisk)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPosition(AUDUSD, 1500000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        //  t+5ms gradient position below min risk so cancel open order
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1, 0.750000));
        }
        then:
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(AUDUSD, minRisk));
        }
        and:
        // hedger cancels open order
        {
            final List<HedgeDecision> statuses = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            assertThat(statuses.get(0).getHedgeTriggerState(), is(HedgeTriggerState.CANCEL_REQ));
            assertThat(statuses.get(1).getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            assertThat(cancelOrder.getInstrument(), is(AUDUSD));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // prod issue of receiving fill while in cancel_req state
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, IDLE)).getLast();
        }
    }

    @Test
    public void autoCancelOrderOnceMinimumTTLMet() {
        long minimumTTL = 3000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_M3")
                                    .setMaximumOpenOrders(5)
                                    .setMaximumOpenQuantity(0d)
                                    .setMaximumOpenVarOrders(0)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(minimumTTL)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(10)
                                    .setThrottleLimitTimePeriodMS(1000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 ACK hedge order and receive client trade to reduce grad pos below min risk which triggers hedger to cancel open order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        // since minimumTTL not met, open hedge order not cancelled yet
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCEL_REQ));

            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // t+4 i.e 3 secs since being acked, cancel open hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void cancelOnceAckedAndMinTTLMet() {
        long minTTL = 2_000L;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(minTTL).setMaximumOpenVarOrders(50).setCancelUnknownTimeoutMS(10_000).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 receive client trade to reduce op pos below trigger level
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // Trigger wants to cancel, but since order not acked, cannot send cancel yet.
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // once order acked and minTTLive(2 sec) is met, then send cancel order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        then:
        // no cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCELLING));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // tick time (time in market = 1 sec)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedger does not cancels since minTTL not met
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCELLING));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // tick time (time in market = 2 sec)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // minTTL met so hedger cancels open order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCELLING));
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
    }

    @Test
    public void retractCancelDecision() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // min risk reached
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+5ms receive client trade to reduce op below min risk
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // Since order not acked, cannot send cancel yet.
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // order acked. Must wait for minTTL before allowed to send cancel.  Meanwhile client trade received increases op pos meeting min risk level
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.client_trade_001(AUDUSD, 100, 0.75000));
        }
        then:
        // hedger retracts cancel request and returns to SELLING
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, SELLING));
        }
        when:
        // t+6ms
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74998));
        }
        then:
        {
            prophet.notExpect(CancelOrder.class);
        }
    }

    @Test
    // Prod behaviour for Mid Hedger where hedger receives Trade first and then Order Event
    public void receiveOrderEventAfterTrade() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // receive Trade first(before order event)
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFillTrade(newOrder, 0.75);
        }
        then:
        // Trade reduces position below min risk level. Since trade is converted to OrderEvent, the hedger knows it caused the position change
        {
            prophet.notExpect(CancelOrder.class);
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
        }
        when:
        // receive actual Order Event (this is a duplicate and should be ignored)
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFillOrderEvent(newOrder, 0.75);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            prophet.notExpect(NewOrder.class);
            prophet.notExpect(CancelOrder.class);
        }
    }

    @Test
    public void handleUnsolicitedOrderReject() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+5 receive order confirm and then order REJECT
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.hedgeUnsolicitedOrderReject(newOrder, 0, 0));
        }
        then:
        // hedger process order reject so decides to send hedge order out again
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
    }

    @Test
    public void handleCancelRejectAndContinueToCancel() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+5 receive client trade to reduce op pos below min risk level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void limitCancelRejectSentAndShutDown() {
        int maxCancelRejectLimit = 3;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedgerFXALL").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setMaxNumberCancelRejects(maxCancelRejectLimit).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)


                    )));
            prophet.receive(tdd.enableHedger(HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // t+5 receive client trade to reduce op pos below min risk level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // hedger cancels open order
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive 1st CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive 2nd CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive 3rd CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        {
            prophet.notExpect(CancelOrder.class);
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_PASSIVE_EBS, HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
        }
        when:
        // t+10 receive client trade to reduce op pos below min risk level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive 1st CANCEL REJECT
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderRejectCancel(newOrder, cancelOrder));
        }
        then:
        // hedger continues to cancel order and does NOT shut down
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(HEDGER_PASSIVE_EBS, HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    // prod behaviour where venues sends order confirm again instead of a cancelReject
    public void receivingOrderConfirmAfterCancelInfersCancelReject() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+5 receive client trade to reduce op below min risk level
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -100, 0.75000));
        }
        then:
        // hedger cancels open order
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive Order Ack again(interpret as venue sending cancel reject)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        then:
        // should resent cancel
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
    }

    @Test
    public void cancelOrderWhenTargetMktEmptyBookReceived() {
        long minimumTTL = 3000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_P1")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        // t+0 hedging order sent
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 ACK hedge order and then Target Mkt(EBS) EMPTY BOOK received
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.emptyMarketDataSnapshot(EBS, AUDUSD));
        }
        then:
        // Decide to cancel. But since minimumTTL not met, cancel order not sent
        {
            prophet.expect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // t+4 i.e one minTTL is met, cancel open hedge order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCELLING));
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, IDLE));
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, SELL_REQ));
        }
    }

    @Test
    public void cancelOrderWhenHedgerManuallyTurnedOff() {
        long minimumTTL = 3000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_P1")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        // t+0 hedging order sent
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 ACK hedge order and then hedger manually turned OFF
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_PASSIVE_EBS));
        }
        then:
        // since minimumTTL not met, cancel order not sent
        {
            // no hedge decision, HedgeOrderRule.stopTrading handles this internally (does not involve the HedgeTrigger)
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));

            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_PASSIVE_EBS, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        // t+4 i.e one minTTL is met, cancel open hedge order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            // no hedge decision, HedgeOrderRule.stopTrading handles this internally (does not involve the HedgeTrigger)
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_PASSIVE_EBS, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_PASSIVE_EBS, HedgePortfolioState.DISABLED));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, IDLE));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, SELL_REQ));
        }
    }

    @Test
    // ensure hedger returns to IDLE after cancel timout
    public void cancelOrderWhenHedgerManuallyTurnedOffAndCancelTimeout() {
        long minimumTTL = 3000;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_P1")
                                    .setMaximumOpenOrders(5)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMaximumOpenVarOrders(50)
                                    .setMinimumTimeToLiveMS(minimumTTL)
                                    .setCancelUnknownTimeoutMS(1000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }

        when:
        // t+0 hedging order sent
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        // hedge order placed
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+1 ACK hedge order and then hedger manually turned OFF
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_PASSIVE_EBS));
        }
        then:
        // since minimumTTL not met, cancel order not sent
        {
            // no hedge decision, HedgeOrderRule.stopTrading handles this internally (does not involve the HedgeTrigger)
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));

            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_PASSIVE_EBS, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        // t+4 cancel open hedge order (as minimumTTL = 3sec)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getLast();

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatus(HEDGER_PASSIVE_EBS, HedgePortfolioState.PENDING_DISABLED));
        }
        when:
        // after one second the cancel order will timeout
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            // not sure why 2 of these??
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatus(HEDGER_PASSIVE_EBS, HedgePortfolioState.DISABLED));

            final List<HedgeDecision> status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            assertThat(status.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            assertThat(status.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SELL_REQ));
        }
    }

    @Test
    public void sendOrderWhenHedgerManuallyTurnedOn() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        // t+0 receive client trade to generate gradpos
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+1 mid hedger is turned on
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
        }
        then:
        // hedger does not place order immediately when enabled
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75000, now()));
        }
        then:
        // hedger places order
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void continueToSendOnPartialFill() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.750000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 50_000, 0.75);
        }
        then:
        {
            final LinkedList<HedgeDecision> hedgeDecisions = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.PAS_EBS_EP));
            assertThat(hedgeDecisions.getFirst().getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            assertThat(hedgeDecisions.getLast().getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1));
        }
    }

    @Test
    public void noTargetMarketPriceAvailable() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.3)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-1.2)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void sellPriceCappedAtReferenceRateGreaterThanTarget() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.3)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-1.2)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_001, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75030 + (-0.00012) = 0.75018
        // Target = 0.75020 + (-0.00003) = 0.75017 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75018));
        }
    }

    @Test
    public void sellPriceUsingBenchMarkAsReference() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.WSP_BENCH)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.3)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-1.2)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.DEUT,Market.FASTMATCH,Market.GS,Market.HSP,Market.RFX,Market.EBS)
                    .addAggBook(Market.WSP_BENCH,Instrument.AUDUSD, TradingTimeZone.GLOBAL,Region.GB,Market.HSP)
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, AUDUSD, 0.75000, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_001, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75030 + (-0.00012) = 0.75018
        // Target = 0.75020 + (-0.00003) = 0.75017 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75018));
        }
    }

    @Test
    public void sellPriceCappedAtReferenceRateLessThanTarget() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-1.2)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.1)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (-0.0001) = 0.75019
        // Target = 0.75030 + (-0.00012) = 0.75018 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75019));
        }
    }

    @Test
    public void sellTargetPriceGreaterThanReferenceNegativeImprovement() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-1.0)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.1)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (-0.0001) = 0.75019
        // Target = 0.75030 + (-0.0001) = 0.75020
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75020));
        }
    }

    @Test
    public void sellTargetPriceEqualsReferencePositiveImprovement() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.5)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(1.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (0.00015) = 0.75035
        // Target = 0.75030 + (0.00005) = 0.75035
        // Arb Protection = 0.74995 + 0.00001 = 0.74996  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75035));
        }
    }

    @Test
    public void sellTargetPriceGreaterThanReferenceZeroImprovement() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.0)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-2.0)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (-0.0002) = 0.75000
        // Target = 0.75030 + (0) = 0.75030
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75030));
        }
    }

    @Test
    public void sellPriceTargetCappedByArbitrage() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-2.5)
                                    .setArbitrageProtectionDistancePips(1.1)
                                    .setAdditionalSpreadPips(-2.0)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (-0.0002) = 0.75000
        // Target = 0.75030 + (-0.000025) = 0.75005
        // Arb Protection = 0.74995 + 0.00011 = 0.75006  <= Target price capped at this price
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75006));  // before rounding fix, had to use isRoundedTo to remove trailing digits/noise
        }
    }

    @Test
    public void sellPriceReferenceCappedByArbitrage() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-2.6)
                                    .setArbitrageProtectionDistancePips(1.1)
                                    .setAdditionalSpreadPips(-1.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (-0.00015) = 0.75005
        // Target = 0.75030 + (-0.000026) = 0.75004 <= capped at Ref Price
        // Arb Protection = 0.74995 + 0.00011 = 0.75006  <= Ref Price therefore capped at this price
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75006));
        }
    }

    @Test
    public void buyPriceCappedAtReferenceRateLessThanTarget() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.6)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-1.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74950, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74960, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74950 - (-0.00015) = 0.74965
        // Target = 0.74960 - (-0.00006) = 0.74966 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74965));
        }
    }

    @Test
    public void buyPriceCappedAtReferenceRateGreaterThanTarget() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-1.6)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00016) = 0.74966 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74965));
        }
    }

    @Test
    public void buyTargetPriceLessThanReferenceNegativeImprovement() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-1.4)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00014) = 0.74964
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74964)); // before rounding fix, had to use isRoundedTo to remove trailing digits/noise
        }
    }

    @Test
    public void buyTargetPriceEqualsReferencePositiveImprovement() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.9)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74950, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74960, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74950 - (-0.00009) = 0.74959
        // Target = 0.74960 - (0.00001) = 0.74959
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74959));
        }
    }

    @Test
    public void buyTargetPriceLessThanReferenceZeroImprovement() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.0)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-1.1)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74950, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74960, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74950 - (-0.00011) = 0.74961
        // Target = 0.74960 = 0.74960
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74960));
        }
    }

    @Test
    public void buyPriceTargetCappedByArbitrage() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-1.4)
                                    .setArbitrageProtectionDistancePips(5.0)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75010, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00014) = 0.74964
        // Arb Protection = 0.75010 - 0.00050 = 0.74950  <= Target price capped to this price
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74960));
        }
    }

    @Test
    public void buyPriceReferenceCappedByArbitrage() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-1.5)
                                    .setArbitrageProtectionDistancePips(5.0)
                                    .setAdditionalSpreadPips(-0.4)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75010, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00004) = 0.74964
        // Target = 0.74950 - (-0.00015) = 0.74965  <= capped at Reference Price
        // Arb Protection = 0.75010 - 0.00050 = 0.74960  <= Reference Price then capped to this price
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74960));
        }
    }

    @Test
    public void sellRefMktMovementSignificantHedgeRateUnchanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.5)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(0.1)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (0.00001) = 0.75021
        // Target = 0.75030 + (0.00005) = 0.75035
        // Arb Protection = 0.74995 + 0.00001 = 0.74996  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75035));
        }
        when:
        // original Reference = 0.75020
        // Reference MA = (0.75020 + 0.75005 + 0.75015) / 3 = 0.7501333
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75005, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75015, now()));

        }
        then:
        // Based on latest Reference Rate, hedging order rate would be the same.  Therefore do not cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void sellTargetMktMovementSignificantHedgeRateUnchanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.5)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(0.1)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (0.00001) = 0.75021
        // Target = 0.75030 + (0.00005) = 0.75035
        // Arb Protection = 0.74995 + 0.00001 = 0.74996  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75035));
        }
        when:
        // original Target = 0.75030
        // Target MA = (0.75030 + 0.75050 + 0.75030) / 3 = 0.750367
        // |Difference| is >= step size(0.5pip)  => REPEG
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75050, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));

        }
        then:
        // However, based on latest Target Rate, hedging order rate would be the same as existing order.  Therefore do not cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void sellRefMktMovementSignificantHedgeRateChanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.3)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-1.4)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_001, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75030 + (-0.00014) = 0.75016
        // Target = 0.75020 + (-0.00003) = 0.75017
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75017));
        }
        when:
        // original Reference = 0.75030
        // Reference MA = (0.75030 + 0.75035 + 0.75040) / 3 = 0.75035
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75035, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75040, now()));

        }
        then:
        // SELLING
        // Reference = 0.75040 + (-0.00014) = 0.75026
        // Target = 0.75020 + (-0.00003) = 0.75017 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75026));
        }
    }

    @Test
    public void sellTargetMktMovementSignificantHedgeRateChanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(0.5)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(0.1)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_500_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.75000, 0.75020, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75030, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        then:
        // SELLING
        // Reference = 0.75020 + (0.00001) = 0.75021
        // Target = 0.75030 + (0.00005) = 0.75035
        // Arb Protection = 0.74995 + 0.00001 = 0.74996  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75035));
        }
        when:
        // original Target = 0.75030
        // Target MA = (0.75030 + 0.75040 + 0.75036) / 3 = 0.750353
        // |Difference| is >= step size(0.5pip)  => REPEG
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75040, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74995, 0.75036, now()));

        }
        then:
        // SELLING
        // Reference = 0.75020 + (0.00001) = 0.75021
        // Target = 0.75036 + (0.00005) = 0.75041
        // Arb Protection = 0.74995 + 0.00001 = 0.74996  <= Target price passes Arb Protection
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(0.75041));
        }
    }

    @Test
    public void buyRefMktMovementSignificantHedgeRateUnchanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Reference = 0.74960
        // Reference MA = (0.74960 + 0.74950 + 0.74954) / 3 = 0.7495467
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74950, 0.75030, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74954, 0.75030, now()));

        }
        then:
        // Based on latest Reference Rate, hedging order rate would be the same.  Therefore do not cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void buyTargetMktMovementSignificantHedgeRateUnchanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Target = 0.74950
        // Target MA = (0.74950 + 0.74970 + 0.74950) / 3 = 0.7495667
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74970, 0.75020, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));

        }
        then:
        // Based on latest Target Rate, hedging order rate would be the same.  Therefore do not cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void buyRefMktMovementSignificantNewHedgeRateNotSignificant() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.1)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00001) = 0.74961
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Reference = 0.74960
        // Reference MA = (0.74960 + 0.74955 + 0.74949) / 3 = 0.7495467
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74955, 0.75030, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74949, 0.75030, now()));
        }
        then:
        // BUYING
        // Reference = 0.74949 - (-0.00001) = 0.74950
        // Target = 0.74950 - (-0.00001) = 0.74951 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        // Current order price = 0.74951
        // New order price = 0.74950  => difference is NOT >= step size.
        {
            prophet.notExpect(CancelOrder.class);
        }
    }

    @Test
    public void buyRefMktMovementSignificantHedgeRateChangeSignificant() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.1)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00001) = 0.74961
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Reference = 0.74960
        // Reference MA = (0.74960 + 0.74959 + 0.74945) / 3 = 0.7495467
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74959, 0.75030, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74945, 0.75030, now()));
        }
        then:
        // BUYING
        // Reference = 0.74945 - (-0.00001) = 0.74946
        // Target = 0.74950 - (-0.00001) = 0.74951 <= Target Price will be CAPPED to Reference
        // Arb Protection = 0.74995 + 0.00001 = 0.74995  <= Target price passes Arb Protection
        // Current order price = 0.74951
        // New order price = 0.74946  => difference IS >= step size.
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74946));
        }
    }

    @Test
    public void buyTargetMktMovementSignificantHedgeRateChanged() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Target = 0.74950
        // Target MA = (0.74950 + 0.74956 + 0.74960) / 3 = 0.749553
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74956, 0.75020, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74960, 0.75020, now()));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74960 - (-0.00001) = 0.74961
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74961));
        }
    }

    @Test
    public void repeggingMustWaitForMinTTL() {
        long minimumTTL = 3000L;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_M3")
                                    .setMaximumOpenOrders(5)
                                    .setMaximumOpenQuantity(0d)
                                    .setMaximumOpenVarOrders(0)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(minimumTTL)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(10)
                                    .setThrottleLimitTimePeriodMS(1000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Target = 0.74950
        // Target MA = (0.74950 + 0.74956 + 0.74961) / 3 = 0.7495567
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74956, 0.75020, now()));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74961, 0.75021, now()));
        }
        then:
        // must wait for MinTTL 3000L
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCELLING));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74960, 0.75020, now()));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74960 - (-0.00001) = 0.74961
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74961));
        }
    }

    @Test
    public void movingAverageSamplingTargetVenue() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74940, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // original Target = 0.74950
        // Target MA = (0.74950 + 0.74956 + 0.74955) / 3 = 0.7495367
        // |Difference| is NOT >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74956, 0.75020, now()));

            // Not considered in MA calc
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74960, 0.75020, now()));

            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74955, 0.75020, now()));
        }
        then:
        // Based on latest Target Rate, hedging order rate would be different.
        // However MA |Difference| is NOT >= step size(0.5pip). Therefore do not cancel
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, CANCEL_REQ));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // original Target = 0.74950
        // Target MA = (0.74956 + 0.74955 + 0.74956) / 3 = 0.7495567
        // |Difference| is >= step size(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74956, 0.75020, now()));
        }
        then:
        {
            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void panicStateCancelPassiveOrder() {
        // default AUDUSD Standard Spread LDN 1.5pip
        long spikePriceStandardSpreadFactor = 2L;
        long panicStateDurationMS = 2000L;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setPanicStateDurationMS(panicStateDurationMS)
                                    .setSpikePriceStandardSpreadFactor(spikePriceStandardSpreadFactor)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
                    .setStandardMarketSpreadConfigs(Arrays.asList(
                            new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 1.50E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74955, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));  // mid 0.74985
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target Mkt = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // Threshold: Standard Spread * factor = 1.5 * 2 = 3pip
        // Lastest/Last Target Mid = (0.74950 + 0.75115) / 2 = 0.750325
        // Target Mkt Mid MA = (0.74985 + 0.749875 + 0.750325) / 3 = 0.750016667
        // |Difference| 0.0003083 > Threshold(3pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75025, now())); // Mid 0.749875

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75115, now())); // Mid 0.750325
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        // must wait for panic period(2000ms) to end before hedger can place order
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
    }

    @Test
    public void panicStateCancelMustWaitForMinTTL() {
        // default AUDUSD Standard Spread LDN 1.5pip
        long spikePriceStandardSpreadFactor = 2L;
        long panicStateDurationMS = 2000L;
        long minimumTTL = 3000L;
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setPanicStateDurationMS(panicStateDurationMS)
                                    .setSpikePriceStandardSpreadFactor(spikePriceStandardSpreadFactor)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.1)
                                    .setArbitrageProtectionDistancePips(0.1)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(3)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000d)
                                    .setOrderQuantity(1_000_000d)
                    ))
                    .setStandardMarketSpreadConfigs(Arrays.asList(
                            new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 1.50E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true)
                                    .setHedgerName("autotrader-ChillaxHedger")
                                    .setBookName("HEDGING_MODEL_M3")
                                    .setMaximumOpenOrders(5)
                                    .setMaximumOpenQuantity(0d)
                                    .setMaximumOpenVarOrders(0)
                                    .setOrderType(OrderType.LIMIT)
                                    .setOrderTimeInForce(TimeInForce.GTC)
                                    .setMinimumTimeToLiveMS(minimumTTL)
                                    .setThrottleLimitRejectNumberOrder(100)
                                    .setThrottleLimitRejectTimePeriodMS(2000)
                                    .setThrottleLimitNumberOrder(10)
                                    .setThrottleLimitTimePeriodMS(1000),
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74960, 0.75030, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74955, 0.75025, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75020, now()));  // mid 0.74985
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target Mkt = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
        when:
        // Threshold: Standard Spread * factor = 1.5 * 2 = 3pip
        // Lastest/Last Target Mid = (0.74950 + 0.75115) / 2 = 0.750325
        // Target Mkt Mid MA = (0.74985 + 0.749875 + 0.750325) / 3 = 0.750016667
        // |Difference| 0.0003083 > Threshold(3pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75025, now())); // Mid 0.749875

            // panic period starts *now*, not when the cancel order is sent
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74950, 0.75115, now())); // Mid 0.750325
        }
        then:
        // must wait for minTTL(3000ms) before hedger cancel
        {
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // minTTL met
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        // must wait for panic period(2000ms) to end before hedger can place order
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        // BUYING
        // Reference = 0.74960 - (-0.00005) = 0.74965
        // Target = 0.74950 - (-0.00001) = 0.74951
        // Arb Protection = 0.75020 - 0.00001 = 0.75019  <= Target price passes Arb Protection
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(0.74951));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeHedgerEnabled() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(900_000)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));

            // Pause enabled(period set to 5 sec)
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        when:
        // enable Hedger - CLEARS ALL STATE i.e PAUSE is removed
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // PAUSE is manually disabled
        {
            prophet.receive(tdd.setHedgingPause(Currency.AUD, false));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            prophet.notExpect(IllegalArgumentException.class, matches(".*IGNORED_INVALID_TRANSITION.*"));
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeTriggeringTrade() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(900_000)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));

            // Pause enabled(period set to 5 sec)
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.750000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // PAUSE is manually disabled(HedgeCurrencyControl does not trigger order)
        {
            prophet.receive(tdd.setHedgingPause(Currency.AUD, false));
        }
        then:
        {
            prophet.expect(HedgeCurrencyControl.class, isHedgingCcyUnpaused(Currency.AUD));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // trigger hedge order via marketDataUpdate
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75000, now()));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }
}