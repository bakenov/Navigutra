package com.anz.markets.efx.fox.codec.pojo;

import java.util.EnumSet;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class UserConfigAsserter {
    private final UserConfig message;

    public UserConfigAsserter(final UserConfig message) {
        this.message = Objects.requireNonNull(message);
    }

    public static UserConfigAsserter expect(final UserConfig message) {
        return new UserConfigAsserter(message);
    }

    public static UserConfigAsserter expect(final MessageHeader header, final UserConfig.Body body) {
        return new UserConfigAsserter(SorMessage.userConfig(header, body));
    }

    public UserConfig message() {
        return message;
    }

    public UserConfig.Body body() {
        return message.body;
    }

    public UserConfigHandler assertingUserConfigHandler() {
        return body -> {
            assertEquals("userName not as expected", body().userName, body.userName().decodeStringOrNull());
            assertEquals("userGroups not as expected", body().userGroups, body.userGroups().decodeTo(EnumSet.noneOf(UserGroup.class)));
            assertEquals("location not as expected", body().location, body.location().decodeStringOrNull());
        };
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a UserConfig", sorMessage instanceof UserConfig);
        assertUserConfig((UserConfig) sorMessage);
    }

    public void assertUserConfig(final UserConfig userConfig) {
        assertBody(userConfig.body);
    }

    public void assertBody(final UserConfig.Body body) {
        assertEquals("userName not as expected", body().userName, body.userName);
        assertEquals("userGroups not as expected", body().userGroups, body.userGroups);
        assertEquals("location not as expected", body().location, body.location);
    }
}
