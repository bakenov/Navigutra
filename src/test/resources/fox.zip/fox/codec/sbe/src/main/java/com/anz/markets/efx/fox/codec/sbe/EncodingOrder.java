package com.anz.markets.efx.fox.codec.sbe;

final class EncodingOrder {
    enum PricingRefreshComplete implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<PricingRefreshComplete> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum TimerExpiry implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<TimerExpiry> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum FirewallConfig implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<FirewallConfig> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum VenueConfig implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<VenueConfig> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum UserConfig implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<UserConfig> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum Initialisation implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<Initialisation> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum InstrumentConfig implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<InstrumentConfig> {
        INITIAL,
        BODY,
        TRAILER
    }

    enum VenueInstrumentConfig implements com.anz.markets.efx.ngaro.sbe.EncodingOrder<VenueInstrumentConfig> {
        INITIAL,
        BODY,
        TRAILER
    }
    private EncodingOrder() {
        throw new RuntimeException("No EncodingOrder for you!");
    }
}
