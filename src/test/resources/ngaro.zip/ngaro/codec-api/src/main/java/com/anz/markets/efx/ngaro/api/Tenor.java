package com.anz.markets.efx.ngaro.api;

import java.util.function.Consumer;

public enum Tenor {
    /** Today */
    TD,
    /** Overnight */
    ON,
    /** Tomorrow */
    TM,
    /** Tomorrow Next */
    TN,
    /** Spot */
    SP,
    /** Spot Next */
    SN,
    /** 1 Week */
    W1,
    /** 2 Weeks */
    W2,
    /** 3 Weeks */
    W3,
    /** 1 Month */
    M1,
    /** 2 Months */
    M2,
    /** 3 Months */
    M3,
    /** 4 Months */
    M4,
    /** 5 Months */
    M5,
    /** 6 Months */
    M6,
    /** 7 Months */
    M7,
    /** 8 Months */
    M8,
    /** 9 Months */
    M9,
    /** 10 Months */
    M10,
    /** 11 Months */
    M11,
    /** 1 Year */
    Y1,
    /** 2 Years */
    Y2,
    /** 3 Years */
    Y3,
    /** 15 Months */
    M15,
    /** 18 Months */
    M18,
    /** 21 Months */
    M21,
    /** End of January */
    EOM1,
    /** Beginning of February */
    BOM2,
    /** End of February */
    EOM2,
    /** Beginning of March */
    BOM3,
    /** End of March */
    EOM3,
    /** Beginning of April */
    BOM4,
    /** End of April */
    EOM4,
    /** Beginning of May */
    BOM5,
    /** End of May */
    EOM5,
    /** Beginning of June */
    BOM6,
    /** End of June */
    EOM6,
    /** Beginning of July */
    BOM7,
    /** End of July */
    EOM7,
    /** Beginning of August */
    BOM8,
    /** End of August */
    EOM8,
    /** Beginning of September */
    BOM9,
    /** End of September */
    EOM9,
    /** Beginning of October */
    BOM10,
    /** End of October */
    EOM10,
    /** Beginning of November */
    BOM11,
    /** End of November */
    EOM11,
    /** Beginning of December */
    BOM12,
    /** End of Year 1 */
    EOY1,
    /** Beginning of Year 2 */
    BOY2,
    /** End of Financial Year */
    EOFY,
    /** Beginning of Financial Year */
    BOFY,
    /** Nearest International Monetary Market delivery date */
    IMM1,
    /** Subsequent International Monetary Market delivery date */
    IMM2,
    /** Third nearest International Monetary Market delivery date */
    IMM3,
    /** Forth nearest International Monetary Market delivery date */
    IMM4,
    /** Null tenor, broken date */
    BROKEN;

    private static final Tenor[] VALUES = values();

    public static int length() {
        return VALUES.length;
    }

    public static Tenor valueByOrdinal(final int ordinal) {
        return VALUES[ordinal];
    }

    public static void forEach(final Consumer<? super Tenor> consumer) {
        for (final Tenor value : VALUES) {
            consumer.accept(value);
        }
    }
}
