package com.anz.markets.efx.fox.codec.api;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;

public interface VenueInstrumentConfigHandler extends MessageDecoder.Handler {
    @Override
    default void onMessageStart(final int source, final long sourceSeq) {
    }

    void onBody(Body body);

    @Override
    default void onMessageComplete() {
    }

    interface Body {
        Venue venue();
        long instrumentId();
        double priceIncrement();
        int sizeIncrement();
        int clipSizeMultiple();
        double maxAllowedParentOrderQty();
        int minClipSize();
        int maxClipSize();
        int staleDataTimeout();
        int priority();
        int proportion();
        boolean enabled();
    }

    @FunctionalInterface
    interface DecoderFactory<M> extends MessageDecoder.Factory<M, VenueInstrumentConfigHandler>, SorDecoders.DecoderFactory<M> {
        @Override
        default MessageDecoder<M> create(final SorHandlerSupplier sorHandlerSupplier, final MessageDecoder.ForwardingLookup<M> forwardingLookup) {
            return create((Supplier<VenueInstrumentConfigHandler>) sorHandlerSupplier::venueInstrumentConfigHandler, forwardingLookup);
        }
    }
}
