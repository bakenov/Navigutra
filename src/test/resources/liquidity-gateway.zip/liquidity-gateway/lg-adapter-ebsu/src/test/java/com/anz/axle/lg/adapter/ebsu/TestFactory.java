package com.anz.axle.lg.adapter.ebsu;

import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import quickfix.field.MDUpdateAction;
import software.chronicle.ebs.itch.generated.incremental.fields.MarketSide;
import software.chronicle.ebs.itch.generated.incremental.fields.UpdateFlags;
import software.chronicle.ebs.itch.generated.incremental.messages.datamodel.server.DefaultPriceLevelUpdate;
import software.chronicle.ebs.itch.generated.incremental.messages.datamodel.server.DefaultTradePrice;
import software.chronicle.ebs.itch.generated.incremental.messages.server.PriceLevelUpdate;
import software.chronicle.ebs.itch.generated.incremental.messages.server.TradePrice;
import software.chronicle.ebs.itch.generated.preview.fields.InstrumentGroup;
import software.chronicle.ebs.util.DecodeUtil;

public class TestFactory {
    static final long SENDING_TIME_NANOS = 8888888888888L;
    static final int SECURITY_ID = 0;
    static final int SECURITY_ID_2 = 1;
    static final String[] SYMBOL_6 = new String[]{"AUDNZD", "AUDUSD"};
    static final InstrumentKey[] INSTRUMENT_KEY = new InstrumentKey[]{InstrumentKey.of(SymbolNormaliser.toSymbol6(SYMBOL_6[0])), InstrumentKey.of(SymbolNormaliser.toSymbol6(SYMBOL_6[1]))};
    static final double NO_VALUE = -1;

    static PriceLevelUpdate cancelOrder(final double price) {
        return priceLevelUpdate(SECURITY_ID, MDUpdateAction.DELETE, MarketSide.BUY, price, 0);
    }

    static PriceLevelUpdate modifyOrder(int securityId, char updateAction, final double price, final double amount) {
        return priceLevelUpdate(securityId, MDUpdateAction.CHANGE, updateAction, price, amount);
    }

    static PriceLevelUpdate newOrder(final char updateAction, final char buySell, final double price, final double amount) {
        return priceLevelUpdate(SECURITY_ID, updateAction, buySell, price, amount);
    }

    static PriceLevelUpdate priceLevelUpdate(int securityId, char updateAction, char buySell, double price, double amount) {
        PriceLevelUpdate priceLevelUpdate = new DefaultPriceLevelUpdate();
        priceLevelUpdate.locateCode(securityId);
        priceLevelUpdate.timestamp(SENDING_TIME_NANOS);
        priceLevelUpdate.marketSide(buySell);
        if (updateAction == MDUpdateAction.NEW) {
            priceLevelUpdate.updateFlags(UpdateFlags.PRICE_LEVEL_BACK_IN_SCOPE);
        }
        if (price != NO_VALUE) {
            priceLevelUpdate.priceLevel(DecodeUtil.price(price));
        }
        if (amount != NO_VALUE) {
            priceLevelUpdate.levelAmount(DecodeUtil.amount(amount));
        }
        return priceLevelUpdate;
    }

    public static TradePrice trade(int securityId, char buySell, double price) {
        DefaultTradePrice trade = new DefaultTradePrice();
        trade.eventNumber(1);
        trade.instrumentGroup(InstrumentGroup.Spot);
        trade.locateCode(securityId);
        trade.marketSide(buySell);
        trade.timestamp(SENDING_TIME_NANOS);
        trade.sequenceNumber(33);
        trade.takePrice(DecodeUtil.price(price));
        return trade;
    }
}
