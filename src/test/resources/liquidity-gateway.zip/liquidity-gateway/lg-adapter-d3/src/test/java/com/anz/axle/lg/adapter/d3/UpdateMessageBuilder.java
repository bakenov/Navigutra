package com.anz.axle.lg.adapter.d3;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import de.digitec.d3.pricing.streaming.Field;
import de.digitec.d3.pricing.streaming.UpdateMessage;
import de.digitec.d3.pricing.streaming.impl.FieldConstants;
import de.digitec.d3.pricing.streaming.impl.FieldImpl;
import de.digitec.d3.pricing.streaming.impl.UpdateMessageImpl;

import com.anz.axle.lg.adapter.d3.model.D3Codec;
import com.anz.axle.microtime.NanoClock;

public final class UpdateMessageBuilder {

    private String curveName;

    private String currency1;

    private String currency2;

    private String tenorName;

    private String status;

    private LocalDate settlementDate;

    private LocalDate tradeDate;

    private LocalDate referenceSpotDate;

    private String updateTime;

    private int pip;

    private boolean holidayWarningFlag;

    private double spotBid;

    private double spotAsk;

    private double forwardBid;

    private double forwardAsk;

    private double allInBid;

    private double allInAsk;

    public final UpdateMessageBuilder withCurveName(final String curveName) {
        this.curveName = curveName;
        return this;
    }

    public final UpdateMessageBuilder withCurrencies(final String currency1, final String currency2) {
        this.currency1 = currency1;
        this.currency2 = currency2;
        return this;
    }

    public final UpdateMessageBuilder withTenor(final String d3TenorName) {
        this.tenorName = d3TenorName;
        return this;
    }

    public final UpdateMessageBuilder withStatus(final String status) {
        this.status = status;
        return this;
    }

    public final UpdateMessageBuilder withSettlementDate(final LocalDate settlementDate) {
        this.settlementDate = settlementDate;
        return this;
    }

    public final UpdateMessageBuilder withTradeDate(final LocalDate tradeDate) {
        this.tradeDate = tradeDate;
        return this;
    }


    public final UpdateMessageBuilder withUpdateTime(final String updateTime) {
        this.updateTime = updateTime;
        return this;
    }

    public final UpdateMessageBuilder withReferenceSpotDate(final LocalDate referenceSpotDate) {
        this.referenceSpotDate = referenceSpotDate;
        return this;
    }


    public final UpdateMessageBuilder withPip(final int pip) {
        this.pip = pip;
        return this;
    }

    public final UpdateMessageBuilder withHolidayWarningFlag(final boolean holidayWarningFlag) {
        this.holidayWarningFlag = holidayWarningFlag;
        return this;
    }

    public final UpdateMessageBuilder withSpotBid(final double spotBid) {
        this.spotBid = spotBid;
        return this;
    }

    public final UpdateMessageBuilder withSpotAsk(final double spotAsk) {
        this.spotAsk = spotAsk;
        return this;
    }

    public final UpdateMessageBuilder withForwardBid(final double forwardBid) {
        this.forwardBid = forwardBid;
        return this;
    }

    public final UpdateMessageBuilder withForwardAsk(final double forwardAsk) {
        this.forwardAsk = forwardAsk;
        return this;
    }

    public final UpdateMessageBuilder withAllInBid(final double allInBid) {
        this.allInBid = allInBid;
        return this;
    }

    public final UpdateMessageBuilder withAllInAsk(final double allInAsk) {
        this.allInAsk = allInAsk;
        return this;
    }


    public UpdateMessage build() {
        final List<Field> updateFields = new ArrayList<>();
        updateFields.add(new FieldImpl(FieldConstants.Symbol, currency1 + currency2));
        updateFields.add(new FieldImpl(FieldConstants.SeqNo, "100"));
        updateFields.add(new FieldImpl(FieldConstants.Source, "ACCEPTANCE"));
        updateFields.add(new FieldImpl(D3Codec.CURVE_NAME, curveName));
        updateFields.add(new FieldImpl(D3Codec.STATUS, status));
        if (tenorName != null) {
            updateFields.add(new FieldImpl(D3Codec.NEAR_TENOR, tenorName));
        }
        updateFields.add(new FieldImpl(D3Codec.NEAR_DATE, D3Codec.formatDate(settlementDate)));
        if (tradeDate != null) {
            updateFields.add(new FieldImpl(D3Codec.TRADING_DATE, D3Codec.formatDate(tradeDate)));
        }
        if (referenceSpotDate != null) {
            updateFields.add(new FieldImpl(D3Codec.SPOT_DATE, D3Codec.formatDate(referenceSpotDate)));
        }
        updateFields.add(new FieldImpl(D3Codec.PIP, "" + pip));
        updateFields.add(new FieldImpl(D3Codec.HOLIDAY_WARNING, "" + holidayWarningFlag));
        updateFields.add(new FieldImpl(D3Codec.CLASSIFICATION, "API"));
        updateFields.add(new FieldImpl(D3Codec.CURRENCY1, currency1));
        updateFields.add(new FieldImpl(D3Codec.CURRENCY2, currency2));
        updateFields.add(new FieldImpl(D3Codec.UPDATE_TIME, updateTime));

        updateFields.add(new FieldImpl(D3Codec.SPOT_BID, "" + spotBid));
        updateFields.add(new FieldImpl(D3Codec.SPOT_ASK, "" + spotAsk));
        updateFields.add(new FieldImpl(D3Codec.NEAR_FORWARD_POINT_BID, "" + forwardBid));
        updateFields.add(new FieldImpl(D3Codec.NEAR_FORWARD_POINT_ASK, "" + forwardAsk));
        updateFields.add(new FieldImpl(D3Codec.NEAR_ALL_IN_BID, "" + allInBid));
        updateFields.add(new FieldImpl(D3Codec.NEAR_ALL_IN_ASK, "" + allInAsk));

        return new UpdateMessageImpl(currency1 + currency2 + NanoClock.nanoClockDefault().nanos(), updateFields);
    }

    public static UpdateMessageBuilder defaultMessage() {
        final LocalDate referenceSpotDate = LocalDate.of(2017, 2, 28);
        final LocalDate tenorDate = LocalDate.of(2017, 3, 3);
        final LocalDate tradeDate = LocalDate.of(2017, 3, 1);
        return new UpdateMessageBuilder()
                .withCurrencies("AUD", "USD")
                .withCurveName("AUDUSD1M")
                .withStatus("FIRM")
                .withTenor("1M")
                .withUpdateTime("21:00:00")
                .withSettlementDate(tenorDate)
                .withTradeDate(tradeDate)
                .withReferenceSpotDate(referenceSpotDate)
                .withPip(100)
                .withHolidayWarningFlag(false)
                .withSpotBid(21.888)
                .withSpotAsk(22.999)
                .withForwardBid(-0.0152)
                .withForwardAsk(0.0235)
                .withAllInBid(21.777)
                .withAllInAsk(23.012);
    }
}
