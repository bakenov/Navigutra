package com.anz.axle.lg.adapter.ebsd.acceptance;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceConfig;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.ebsd.ServerConfig;
import com.anz.axle.lg.adapter.quickfix.FixMessageSender;

@Configuration
@Import({ServerConfig.class, SharedAcceptanceConfig.class})
public class AcceptanceConfig {
    @Bean
    public AcceptanceContext acceptanceContext(final SharedAcceptanceContext sharedAcceptanceContext,
                                               final FixMessageSender fixMessageSender) {
        final class AcceptanceContextImpl extends SharedAcceptanceContext.Delegate implements AcceptanceContext {
            public AcceptanceContextImpl() {
                super(sharedAcceptanceContext);
            }
            @Override
            public FixMessageSender fixMessageSender() {
                return fixMessageSender;
            }
        }
        return new AcceptanceContextImpl();
    }
}
