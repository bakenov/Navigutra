package com.anz.markets.efx.fox.receiver;

import java.util.Objects;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class SingleDestinationMessageDecoderLookup implements MessageDecoder.ForwardingLookup<SbeMessage> {
    private static final MessageDecoder<SbeMessage> NOOP_DECODER = sbeMessage -> true;
    private final String destination;
    private final MessageDecoder<SbeMessage> decoder;

    public SingleDestinationMessageDecoderLookup(final String destination, final MessageDecoder<SbeMessage> decoder) {
        this.destination = Objects.requireNonNull(destination);
        this.decoder = Objects.requireNonNull(decoder);
    }

    @Override
    public MessageDecoder<SbeMessage> apply(final String destination) {
        if (this.destination.equals(destination)) return decoder;
        return null;
    }
}
