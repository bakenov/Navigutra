package com.anz.axle.direct.performance.metrics;

// Sourced from the excellent com.anz.axle.direct.performance.metrics (SPDEE)

public interface Metric<T> {

    String getName();

    void record(long value);

    T snapshot();

    void clear();

}
