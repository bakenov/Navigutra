package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.codec.api.VenueConfigDecoder;

public interface VenueRepository {
    Venue lookup(com.anz.markets.efx.ngaro.api.Venue venueId);
    Venue lookup(String compId);
    Venue apply(VenueConfigDecoder venueConfigDecoder);
}