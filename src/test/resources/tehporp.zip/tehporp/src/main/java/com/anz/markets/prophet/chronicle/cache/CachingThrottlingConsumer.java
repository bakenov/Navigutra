package com.anz.markets.prophet.chronicle.cache;

import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import com.anz.markets.prophet.util.ExtractKeyValue;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Keeps an in-memory cache of the entities that pass through. When receives an entity, will only
 * pass it on to the next consumer in the chain if is different to what is in the cache.
 *
 * @param <T> entity type
 */
public class CachingThrottlingConsumer<T> implements Consumer<T> {
    private final ProphetMarshallableCopier copier;
    private final Map<String, T> cache;
    private final Supplier<T> supplier;
    private final ExtractKeyValue.KeyGetter<String, T> keyGetter;
    private final BiPredicate<T, T> valuesEqual;
    private final Consumer<T> consumer;

    public CachingThrottlingConsumer(final Supplier<T> supplier,
                                     final ExtractKeyValue.KeyGetter<String, T> keyGetter,
                                     final BiPredicate<T, T> valuesEqual,
                                     final Consumer<T> consumer) {
        this.cache = new HashMap<>();
        this.supplier = supplier;
        this.keyGetter = keyGetter;
        this.valuesEqual = valuesEqual;
        this.consumer = consumer;
        this.copier = new ProphetMarshallableCopier();
    }

    @Override
    public void accept(final T entity) {
        if (isChanged(entity)) {
            consumer.accept(entity);
        }
    }

    private boolean isChanged(final T entity) {
        final String key = keyGetter.get(entity);
        final T previous = cache.get(key);
        if (previous == null) {
            final T newValue = supplier.get();
            copier.copy((ProphetMarshallable) entity, (ProphetMarshallable) newValue);
            cache.put(key, newValue);
            return true;
        } else if (!valuesEqual.test(previous, entity)) {
            copier.copy((ProphetMarshallable) entity, (ProphetMarshallable) previous);
            return true;
        }
        return false;
    }
}
