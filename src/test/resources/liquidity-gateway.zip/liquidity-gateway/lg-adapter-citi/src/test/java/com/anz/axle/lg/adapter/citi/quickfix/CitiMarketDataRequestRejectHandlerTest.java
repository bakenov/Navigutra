package com.anz.axle.lg.adapter.citi.quickfix;

import org.junit.Test;

import quickfix.field.MDReqID;
import quickfix.field.MDReqRejReason;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteRequestRejectReason;
import quickfix.field.Text;
import quickfix.fix42.MarketDataRequestReject;
import quickfix.fix44.QuoteRequestReject;

import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class CitiMarketDataRequestRejectHandlerTest {

    private final SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy = mock(SubscriptionRequestRejectStrategy.class);
    private final CitiMarketDataRequestRejectHandler quoteRejectHandler = new CitiMarketDataRequestRejectHandler(subscriptionManager, subscriptionRequestRejectStrategy);

    @Test
    public void shouldProcessReject() throws Exception {
        final String requestId = "34214521";
        final int rejectReasonCode = 3;
        final String rejectReasonText = "No Permissions Set for QuoteRequest";

        final QuoteRequestReject quoteRequestReject = new QuoteRequestReject();
        final QuoteReqID quoteRequestId = new QuoteReqID(requestId);
        final QuoteRequestRejectReason quoteRequestRejectReasonCode = new QuoteRequestRejectReason(rejectReasonCode);
        final Text text = new Text(rejectReasonText);
        quoteRequestReject.setField(quoteRequestId);
        quoteRequestReject.set(quoteRequestRejectReasonCode);
        quoteRequestReject.set(text);
        quoteRejectHandler.accept(quoteRequestReject);
        verify(subscriptionManager).rejectRequest(Integer.parseInt(requestId), subscriptionRequestRejectStrategy);
    }
}