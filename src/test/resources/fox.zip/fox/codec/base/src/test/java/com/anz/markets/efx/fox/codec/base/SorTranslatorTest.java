package com.anz.markets.efx.fox.codec.base;

import java.util.EnumSet;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.pojo.FirewallConfigAsserter;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.pojo.InitialisationAsserter;
import com.anz.markets.efx.fox.codec.pojo.PricingRefreshCompleteAsserter;
import com.anz.markets.efx.fox.codec.pojo.TimerExpiryAsserter;
import com.anz.markets.efx.fox.codec.pojo.UserConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.InstrumentConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.VenueConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.VenueInstrumentConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoSorDecoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoSorEncoderSupplier;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import static org.junit.Assert.assertTrue;

@RunWith(Spockito.class)
public class SorTranslatorTest {
    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | instrumentId  | forceSnapshot |",
            "|===========|===========|===============|===============|",
            "| 4         | 34        | 4             | false         |",
            "| 4         | 56        | 4             | false         |",
            "| 5         | 89        | 5             | false         |",
            "|-----------|-----------|---------------|---------------|"
    })
    @Spockito.Name("[{row}]: {instrumentKeys}")
    public void translatePricingRefreshComplete(final int sourceId, final long sourceSeq,
                                                final long instrumentId,
                                                final boolean forceSnapshot) {
        //given
        final PricingRefreshComplete pricingRefreshComplete = SorMessage.pricingRefreshComplete(
                new MessageHeader(sourceId, sourceSeq),
                new PricingRefreshComplete.Body(instrumentId, forceSnapshot));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().pricingRefreshComplete(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(pricingRefreshComplete);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().pricingRefreshComplete().create(
                        PricingRefreshCompleteAsserter.expect(pricingRefreshComplete).assertingPricingRefreshCompleteHandler()
                ).decode(messageHolder.get())
        );
        PricingRefreshCompleteAsserter.expect(pricingRefreshComplete).assertPricingMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | triggeredTime | orderId | timerId | timerGroup |",
            "|===========|===========|===============|=========|=========|============|",
            "| 4         | 34        | 4352345345    | 454     | 6546434 | PARENT_ORDER_RELEASE |",
            "| 4         | 56        | 23452345      | 756     | 7634563 | PARENT_ORDER_RELEASE |",
            "| 5         | 89        | 56653454      | 785     | 4567346 | PARENT_ORDER_RELEASE |",
            "|-----------|-----------|---------------|---------|---------|------------|"
    })
    @Spockito.Name("[{row}]: {instrumentKeys}")
    public void translateTimerExpiry(final int sourceId, final long sourceSeq, final long triggeredTime,
                                     final long orderId, final long timerId, final TimerGroup timerGroup) {
        //given
        final TimerExpiry timerExpiry = SorMessage.timerExpiry( new MessageHeader(sourceId, sourceSeq),
                new TimerExpiry.Body(triggeredTime, orderId, timerId, timerGroup));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().timerExpiry(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(timerExpiry);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().timerExpiry().create(
                        TimerExpiryAsserter.expect(timerExpiry).assertingTimerExpiryHandler()
                ).decode(messageHolder.get())
        );
        TimerExpiryAsserter.expect(timerExpiry).assertSorMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | firewallName  | ruleId               | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period | periodUnit | local | comment                    | lastEditUsername | lastEditTime | limitThreshold |",
            "|===========|===========|===============|======================|===============|==================|=============|==================|=================|==============|=====================|==============|===============|========|============|=======|============================|==================|==============|================|",
            "| 4         | 34        | UserThroughput| 1                    |  regionPat1   |  orderTypePat1   | deskPat1    |  portfolioPat1   |   usernamePat1  |  venuePat1   |   securityTypePat1  |   tenorPat1  |  symbolPat1   |  10    |     s      | false | deny all users             | sawenko1         | 12345678     | 0              |",
            "| 4         | 56        | UserThroughput| 2                    |  regionPat2   |  orderTypePat2   | deskPat2    |  portfolioPat2   |   usernamePat2  |  venuePat2   |   securityTypePat2  |   tenorPat2  |  symbolPat2   |  20    |     ms     | false | allow all EFX Traders      | marsden2         | 23456678     | 100000000      |",
            "| 5         | 89        | UserThroughput| 3                    |  regionPat3   |  orderTypePat3   | deskPat3    |  portfolioPat3   |   usernamePat3  |  venuePat3   |   securityTypePat3  |   tenorPat3  |  symbolPat3   |  30    |     m      | false | joel head of EFX gets more | marsden3         | 23444344     | 500000000      |",
            "|-----------|-----------|---------------|----------------------|---------------|------------------|-------------|------------------|-----------------|--------------|---------------------|--------------|---------------|--------|------------|-------|----------------------------|------------------|--------------|----------------|"
    })
    @Spockito.Name("[{row}]: {ruleId}")
    public void translateFirewallConfig(final int sourceId, final long sourceSeq, final String firewallName,
                                        final long ruleId, final String regionPattern, final String orderTypePattern,
                                        final String deskPattern, final String portfolioPattern,
                                        final String userNamePattern, final String venuePattern,
                                        final String securityTypePattern, final String tenorPattern,
                                        final String symbolPattern, final long period, final boolean local,
                                        final String periodUnit,
                                        final String comment, final String lastEditUsername, final long lastEditTime,
                                        final double limitThreshold) {
        //given
        final FirewallConfig firewallConfig = SorMessage.firewallConfig( new MessageHeader(sourceId, sourceSeq),
                new FirewallConfig.Body(firewallName, ruleId, regionPattern,
                        orderTypePattern, deskPattern, portfolioPattern, userNamePattern, venuePattern, securityTypePattern,
                        tenorPattern, symbolPattern, period, periodUnit, local, comment, lastEditUsername, lastEditTime, limitThreshold));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().firewallConfig(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(firewallConfig);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().firewallConfig().create(
                        FirewallConfigAsserter.expect(firewallConfig).assertingFirewallConfigHandler()
                ).decode(messageHolder.get())
        );
        FirewallConfigAsserter.expect(firewallConfig).assertSorMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | venue         | compId        | venueCategories            | enabled |",
            "|===========|===========|===============|===============|============================|=========|",
            "| 4         | 34        | EBS           | lg-ebs        | [INTERBANK;MATCHING_AGENT] | true    |",
            "| 4         | 56        | RFX           | lg-rfx        | [INTERBANK;MATCHING_AGENT] | true    |",
            "| 5         | 89        | CITI          | lg-citi       | [BANK]                     | false   |",
            "|-----------|-----------|---------------|---------------|----------------------------|---------|"
    })
    @Spockito.Name("[{row}]: {venue}")
    public void translateVenueConfig(final int sourceId, final long sourceSeq, final Venue venue, final String compId, final EnumSet<VenueCategory> venueCategories, final boolean enabled) {
        //given
        final VenueConfig venueConfig = SorMessage.venueConfig(
                new MessageHeader(sourceId, sourceSeq),
                new VenueConfig.Body(venue, compId, venueCategories, enabled));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().venueConfig(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(venueConfig);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().venueConfig().create(
                        VenueConfigAsserter.expect(venueConfig).assertingVenueConfigHandler()
                ).decode(messageHolder.get())
        );
        VenueConfigAsserter.expect(venueConfig).assertSorMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | userName      | userGroups            | location  |",
            "|===========|===========|===============|=======================|===========|",
            "| 4         | 34        | user1         | [TRADER;ADMIN]        | Melbourne |",
            "| 4         | 56        | user2         | [TRADER;ADMIN]        | Tokyo     |",
            "| 5         | 89        | user3         | [TRADER]              | London    |",
            "|-----------|-----------|---------------|-----------------------|-----------|"
    })
    @Spockito.Name("[{row}]: {userName}")
    public void translateUserConfig(final int sourceId, final long sourceSeq, final String userName, final EnumSet<UserGroup> userGroups, final String location) {
        //given
        final UserConfig userConfig = SorMessage.userConfig(
                new MessageHeader(sourceId, sourceSeq),
                new UserConfig.Body(userName, userGroups, location));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().userConfig(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(userConfig);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().userConfig().create(
                        UserConfigAsserter.expect(userConfig).assertingUserConfigHandler()
                ).decode(messageHolder.get())
        );
        UserConfigAsserter.expect(userConfig).assertSorMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | initStage     |",
            "|===========|===========|===============|",
            "| 4         | 34        | BEGIN         |",
            "| 4         | 56        | END           |",
            "|-----------|-----------|---------------|"
    })
    @Spockito.Name("[{row}]: {initStage}")
    public void translateInitialisation(final int sourceId, final long sourceSeq, final InitStage initStage) {
        //given
        final Initialisation initialisation = SorMessage.initialisation(
                new MessageHeader(sourceId, sourceSeq),
                new Initialisation.Body(initStage));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().initialisation(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(initialisation);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().initialisation().create(
                        InitialisationAsserter.expect(initialisation).assertingInitialisationHandler()
                ).decode(messageHolder.get())
        );
        InitialisationAsserter.expect(initialisation).assertSorMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | instrumentId  | pipSizeDivisor | enabled      |",
            "|===========|===========|===============|================|===========|",
            "| 4         | 34        | 23423523      | 10000          | true      |",
            "| 4         | 56        | 23423524      | 100            | false     |",
            "| 5         | 89        | 23423525      | 1000           | true      |",
            "|-----------|-----------|---------------|----------------|-----------|"
    })
    @Spockito.Name("[{row}]: {userName}")
    public void translateInstrumentConfig(final int sourceId, final long sourceSeq, final long instrumentId, final int pipSizeDivisor, final  boolean enabled) {
        //given
        final InstrumentConfig instrumentConfig = SorMessage.instrumentConfig(
                new MessageHeader(sourceId, sourceSeq),
                new InstrumentConfig.Body(instrumentId, pipSizeDivisor, enabled));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().instrumentConfig(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(instrumentConfig);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().instrumentConfig().create(
                        InstrumentConfigAsserter.expect(instrumentConfig).assertingInstrumentConfigHandler()
                ).decode(messageHolder.get())
        );
        InstrumentConfigAsserter.expect(instrumentConfig).assertSorMessage(messageHolder.get());
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | venue    | instrumentId  | priceIncrement | sizeIncrement  | clipSizeMultiple | maxAllowedParentOrderQty | minClipSize | maxClipSize | staleDataTimeout | priority | proportion | enabled   |",
            "|===========|===========|==========|===============|================|================|==================|==========================|=============|=============|==================|==========|============|===========|",
            "| 4         | 34        | EBS      | 23423523      | 0.0005         | 100000         | 100000           | 30000000                 | 100000      | 200000      | 30               | 10       | 50         | true      |",
            "| 4         | 56        | RFX      | 23423524      | 0.0006         | 200000         | 50000            | 20000000                 | 300000      | 400000      | 60               | 20       | 25         | false     |",
            "| 5         | 89        | CITI     | 23423525      | 0.0003         | 300000         | 60000            | 50000000                 | 1000000     | 1000000     | 3600             | 30       | 100        | true      |",
            "|-----------|-----------|----------|---------------|----------------|----------------|------------------|--------------------------|-------------|-------------|------------------|----------|------------|-----------|"
    })
    @Spockito.Name("[{row}]: {instrumentId}")
    public void translateVenueInstrumentConfig(final int sourceId, final long sourceSeq,
                                               final Venue venue, final long instrumentId,
                                               final double priceIncrement, final int sizeIncrement,
                                               final int clipSizeMultiple, final double maxAllowedParentOrderQty,
                                               final int minClipSize, final int maxClipSize, final int staleDataTimeout,
                                               final int priority, final int proportion, final  boolean enabled) {
        //given
        final VenueInstrumentConfig venueInstrumentConfig = SorMessage.venueInstrumentConfig(
                new MessageHeader(sourceId, sourceSeq),
                new VenueInstrumentConfig.Body(venue, instrumentId, priceIncrement,
                        sizeIncrement, clipSizeMultiple, maxAllowedParentOrderQty,
                        minClipSize, maxClipSize, staleDataTimeout, priority, proportion, enabled));
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> translator = SorTranslator.create(
                new PojoSorDecoders().venueInstrumentConfig(), new PojoSorEncoderSupplier(messageHolder::set));

        //when
        translator.decode(venueInstrumentConfig);

        //then: decode & assert
        assertTrue(
                new PojoSorDecoders().venueInstrumentConfig().create(
                        VenueInstrumentConfigAsserter.expect(venueInstrumentConfig).assertingVenueInstrumentConfigHandler()
                ).decode(messageHolder.get())
        );
        VenueInstrumentConfigAsserter.expect(venueInstrumentConfig).assertSorMessage(messageHolder.get());
    }

}