package com.anz.axle.lg.adapter.ebsu;

import com.anz.axle.lg.adapter.acceptance.shared.ControllableClock;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementMessageNotifier;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementalMessageHandler;
import com.anz.axle.lg.adapter.ebsu.trade.TradeMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.AggressorAction;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoIncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoLastMarketTradeEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoSnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.LastMarketTrade;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import net.openhft.chronicle.bytes.Bytes;
import org.jetbrains.annotations.NotNull;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import quickfix.field.MDUpdateAction;
import software.chronicle.ebs.adapter.moldudp64.ConnectionStatus;
import software.chronicle.ebs.instrument.InstrumentDictionary;
import software.chronicle.ebs.instrument.VanillaInstrumentDictionary;
import software.chronicle.ebs.itch.generated.incremental.fields.MarketSide;
import software.chronicle.ebs.itch.generated.incremental.messages.server.PriceLevelUpdate;
import software.chronicle.ebs.itch.generated.incremental.messages.server.TradePrice;
import software.chronicle.ebs.itch.generated.preview.fields.SecurityType;
import software.chronicle.ebs.itch.generated.preview.messages.datamodel.server.DefaultInstrumentDirectory;
import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;
import software.chronicle.fix.staticcode.FixNetworkContext;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.parsers.SessionMessageNotifierBase;
import software.chronicle.itch.staticcode.AdminMessage;
import software.chronicle.itch.staticcode.AppMessage;
import software.chronicle.itch.staticcode.IncrementalServerSessionHandler;
import software.chronicle.itch.staticcode.InnerMessage;

import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class IncrementMessageNotifierTest {

    private static final String SENDER_COMP_ID = "sender";
    private static final String COMP_ID = "compId";

    private final Venue VENUE = Venue.EBSU;
    private final Queue<PricingMessage> queue = new LinkedBlockingDeque<>(5);
    private final PricingEncoderSupplier encoderSupplier = new PojoPricingEncoderSupplier(m -> queue.add(m));
    private IncrementMessageNotifier messageNotifier;
    private IncrementalServerSessionHandler session;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    @Before
    public void setUp() {

        Map<String, String> ebsuSymbolLookup = new HashMap<>();
        SecurityInfoHolder pricingEncoderLookup = new SecurityInfoHolder(requestKey -> encoderSupplier, VENUE, com.anz.markets.efx.ngaro.api.SecurityType.FXSPOT, ebsuSymbolLookup);
        PrecisionClock precisionClock = new ControllableClock();

        boolean encodeHops = false;
        final IncrementalMessageHandler handler = new IncrementalMessageHandler(pricingEncoderLookup, System::currentTimeMillis, precisionClock, SENDER_COMP_ID, COMP_ID, VENUE, encodeHops, 0, sourceSequencer);
        final TradeMessageHandler tradeHander = new TradeMessageHandler(pricingEncoderLookup, System::currentTimeMillis, precisionClock, SENDER_COMP_ID, COMP_ID, VENUE, encodeHops, 0, sourceSequencer);
        messageNotifier = new IncrementMessageNotifier(handler, tradeHander, precisionClock);

        InstrumentDictionary securityDictionary = new VanillaInstrumentDictionary();
        addSecurityDefinition(securityDictionary, TestFactory.SECURITY_ID);
        addSecurityDefinition(securityDictionary, TestFactory.SECURITY_ID_2);

        session = new DummySession(securityDictionary);
    }

    private void addSecurityDefinition(InstrumentDictionary securityDictionary, int securityId) {
        InstrumentDirectory securityDefinition = new DefaultInstrumentDirectory();
        securityDefinition.locateCode(securityId);
        securityDefinition.securityType(SecurityType.FX_SPOT);
        String ebsDesc = "FXSPOT." + TestFactory.SYMBOL_6[securityId];
        securityDefinition.description(ebsDesc);
        securityDefinition.pricePrecision(5);
        securityDictionary.addOrReplace(securityDefinition);
    }

    @Test
    public void handleNewOrder() {
        //given
        final PriceLevelUpdate newOrder = TestFactory.newOrder(MDUpdateAction.NEW, MarketSide.BUY, 1.08108, (long) 1E6);

        //when
        messageNotifier.onPriceLevelUpdate(session, newOrder);

        //then
        assertThat(queue.size(), is(1));
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(TestFactory.INSTRUMENT_KEY[TestFactory.SECURITY_ID].instrumentId()));
        assertThat(body.marketId, is(VENUE));
        assertThat(body.sendingTime, is(TestFactory.SENDING_TIME_NANOS));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.NEW));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryPx, is(1.08108));
        assertThat(pojoEncoder.message().entries.get(0).mdEntrySize, is(1000000.0));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(108108_1));
    }

    @Test
    public void handleModifyOrder() {
        checkModifyOrder(TestFactory.SECURITY_ID);
    }

    private void checkModifyOrder(int securityId) {
        //given
        final PriceLevelUpdate modifyOrder = TestFactory.modifyOrder(securityId, MarketSide.BUY, 1.08108, 1000000);

        //when
        messageNotifier.onPriceLevelUpdate(session, modifyOrder);

        //then
        assertThat(queue.size(), is(1));
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(TestFactory.INSTRUMENT_KEY[securityId].instrumentId()));
        assertThat(body.marketId, is(VENUE));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.CHANGE));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntrySize, is(1000000.0));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(108108_1));
    }

    @Test
    public void handleCancelOrder() {
        //given
        final PriceLevelUpdate cancelOrder = TestFactory.cancelOrder(1.08108);

        //when
        messageNotifier.onPriceLevelUpdate(session, cancelOrder);

        //then
        assertThat(queue.size(), is(1));
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(TestFactory.INSTRUMENT_KEY[TestFactory.SECURITY_ID].instrumentId()));
        assertThat(body.marketId, is(VENUE));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.DELETE));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(108108_1));
    }

    @Test
    public void handleInterrupt() {
        checkModifyOrder(TestFactory.SECURITY_ID);
        assertThat(queue.size(), is(1));

        // nothing should happen if we remain connected
        messageNotifier.onConnectionStatusChange(ConnectionStatus.CONNECTED);
        assertThat(queue.size(), is(1));

        queue.clear();
        checkModifyOrder(TestFactory.SECURITY_ID_2);
        assertThat(queue.size(), is(1));

        // now disconnect
        queue.clear();
        messageNotifier.onConnectionStatusChange(ConnectionStatus.ASYNC_CLOSED);

        assertThat(queue.size(), is(2));
        final PojoSnapshotFullRefreshEncoder pojoEncoder = (PojoSnapshotFullRefreshEncoder) encoderSupplier.snapshotFullRefresh();
        final SnapshotFullRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(TestFactory.INSTRUMENT_KEY[TestFactory.SECURITY_ID_2].instrumentId()));
        assertThat(body.marketId, is(VENUE));
        assertThat(body.mdFlags, is(PricingEncoderLookup.MD_FLAGS_DISCONNECTED));
        assertThat(pojoEncoder.message().entries.size(), is(0));
    }

    @Test
    public void handleTrade() {
        final TradePrice trade = TestFactory.trade(TestFactory.SECURITY_ID, MarketSide.BUY, 0.8888);

        messageNotifier.onTradePrice(session, trade);

        assertThat(queue.size(), is(1));
        final PojoLastMarketTradeEncoder pojoEncoder = (PojoLastMarketTradeEncoder) encoderSupplier.lastMarketTrade();
        final LastMarketTrade.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(TestFactory.INSTRUMENT_KEY[TestFactory.SECURITY_ID].instrumentId()));
        assertThat(body.marketId, is(VENUE));
        assertThat(body.aggressorAction, is(AggressorAction.PAID));
        assertThat(body.mdEntryPx, is(0.8888));
    }

    static class DummySession implements IncrementalServerSessionHandler {
        private final InstrumentDictionary securityDictionary;

        public DummySession(InstrumentDictionary securityDictionary) {
            this.securityDictionary = securityDictionary;
        }

        @Override
        public InstrumentDictionary instrumentDictionary() {
            return securityDictionary;
        }

        @Override
        public void onConnectionStatusChange(ConnectionStatus connectionStatus) {
        }

        @Override
        public void sendMessage(AdminMessage adminMessage) {
        }

        @Override
        public void sendMessage(AppMessage appMessage) {
        }

        @Override
        public void sendMessage(InnerMessage innerMessage) {
        }

        @Override
        public void logout(@NotNull String s) {
        }

        @Override
        public SessionMessageNotifierBase messageNotifier() {
            return null;
        }

        @Override
        public void networkContext(@NotNull FixNetworkContext nc) {
        }

        @Override
        public FixNetworkContext networkContext() {
            return null;
        }

        @Override
        public FixSessionContext context() {
            return null;
        }

        @Override
        public String sessionID() {
            return null;
        }

        @Override
        public void logon() {
        }

        @Override
        public void onReadITCH(Bytes bytes, boolean b) {
        }

        @Override
        public Logger logger() {
            return null;
        }

        @Override
        public boolean isActive() {
            return false;
        }

        @Override
        public void setActive(boolean active) {
        }

        @Override
        public void start() {
        }

        @Override
        public void stop() {
        }
    }
}