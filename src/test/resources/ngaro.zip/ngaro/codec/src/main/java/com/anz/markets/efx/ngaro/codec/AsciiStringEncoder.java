package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.ExpandableAsciiString;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.LongCodec;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;

/**
 * String encoder backed by a supplier of {@link MutableAsciiString}.
 */
public final class AsciiStringEncoder<E> implements StringEncoder<E> {

    private final E enclosingEncoder;
    private final Supplier<? extends MutableAsciiString> asciiStringSupplier;
    private final int maxLength;

    public AsciiStringEncoder(final E enclosingEncoder,
                              final Supplier<? extends MutableAsciiString> asciiStringSupplier,
                              final int maxLength) {
        if (maxLength < 0) {
            throw new IllegalArgumentException("Max length must be non negative: " + maxLength);
        }
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.asciiStringSupplier = Objects.requireNonNull(asciiStringSupplier);
        this.maxLength = maxLength;
    }

    public static <E> AsciiStringEncoder<E> forSupplier(final E enclosingEncoder,
                                                        final Supplier<? extends MutableAsciiString> asciiStringSupplier,
                                                        final int maxLength) {
        return new AsciiStringEncoder<>(enclosingEncoder, asciiStringSupplier, maxLength);
    }

    public static <E> AsciiStringEncoder<E> forExpandableAsciiString(final E enclosingEncoder) {
        return forExpandableAsciiString(enclosingEncoder, new ExpandableAsciiString());
    }

    public static <E> AsciiStringEncoder<E> forExpandableAsciiString(final E enclosingEncoder, final ExpandableAsciiString asciiString) {
        return forMutableAsciiString(enclosingEncoder, asciiString, Integer.MAX_VALUE);
    }

    public static <E> AsciiStringEncoder<E> forFixedLengthAsciiString(final E enclosingEncoder, final int length) {
        return forFixedLengthAsciiString(enclosingEncoder, new FixedLengthAsciiString(length));
    }

    public static <E> AsciiStringEncoder<E> forFixedLengthAsciiString(final E enclosingEncoder, final FixedLengthAsciiString asciiString) {
        return forMutableAsciiString(enclosingEncoder, asciiString, asciiString.capacity());
    }

    public static <E> AsciiStringEncoder<E> forMutableAsciiString(final E enclosingEncoder, final MutableAsciiString asciiString, final int maxLength) {
        Objects.requireNonNull(asciiString);
        return forSupplier(enclosingEncoder, () -> asciiString, maxLength);
    }

    public MutableAsciiString asciiString() {
        return asciiStringSupplier.get();
    }

    @Override
    public E encodeEmpty() {
        asciiString().clear();
        return enclosingEncoder;
    }

    @Override
    public E encodeFrom(final StringDecoder stringDecoder) {
        stringDecoder.decodeTo(asciiString(), ByteWriter.MUTABLE_ASCII_STRING, 0, maxLength);
        return enclosingEncoder;
    }

    @Override
    public <S> E encode(final S source, final ByteReader<? super S> reader, final int sourceOffset, final int length) {
        asciiString().set(source, reader, sourceOffset, Math.min(length, maxLength));
        return enclosingEncoder;
    }

    @Override
    public E encodeLong(final long value) {
        LongCodec.encodeSigned(value, asciiString());
        return enclosingEncoder;
    }
}
