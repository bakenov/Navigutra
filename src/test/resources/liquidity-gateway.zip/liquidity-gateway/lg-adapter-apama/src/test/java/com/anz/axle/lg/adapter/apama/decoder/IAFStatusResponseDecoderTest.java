package com.anz.axle.lg.adapter.apama.decoder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.event.IAFStatusResponse;
import com.anz.axle.lg.config.PricingEncoderLookup;

import static org.mockito.Mockito.verify;

/**
 * Unit test for {@link IAFStatusResponseDecoder}
 */
@RunWith(MockitoJUnitRunner.class)
public class IAFStatusResponseDecoderTest {

    private static final EventParser EVENT_PARSER = new EventParser(IAFStatusResponse.EVENT_TYPE);

    @Mock
    private PricingEncoderLookup pricingEncoderLookup;
    private String transport = "ReutersRFATransport";

    private IAFStatusResponseDecoder iafStatusResponseDecoder;

    @Before
    public void setUp() throws Exception {
        iafStatusResponseDecoder = new IAFStatusResponseDecoder(pricingEncoderLookup, transport);
    }

    @Test
    public void should_forward_snapshot_when_heartbeat_is_connected() throws Exception {
        //given
        final String iafStatusResponseMessage = "com.apama.adapters.IAFStatusResponse_1(5116,1,16927,\"adapters/iaf_ReutersMAPI-RFA.xml\",\"ReutersRFACodec\",\"ReutersRFATransport\",true,false,{},{\"CONFIG_VERSION\":\"4.3.0-10_hf1\",\"CONNECTION\":\"1377863658887\",\"VERSION\":\"4.3.0-10_hf1\"})";
        final Event iafStatusResponseMessageEvent = EVENT_PARSER.parse(iafStatusResponseMessage);

        //when
        iafStatusResponseDecoder.decode(iafStatusResponseMessageEvent);

        //then
        verify(pricingEncoderLookup).forwardCurrentSnapshots();
    }

    @Test
    public void should_clean_all_books_when_heartbeat_is_disconnected() throws Exception {
        //given
        final String iafStatusResponseMessage = "com.apama.adapters.IAFStatusResponse_1(5116,1,16927,\"adapters/iaf_ReutersMAPI-RFA.xml\",\"ReutersRFACodec\",\"ReutersRFATransport\",false,false,{},{\"CONFIG_VERSION\":\"4.3.0-10_hf1\",\"CONNECTION\":\"1377863658887\",\"VERSION\":\"4.3.0-10_hf1\"})";
        final Event iafStatusResponseMessageEvent = EVENT_PARSER.parse(iafStatusResponseMessage);

        //when
        iafStatusResponseDecoder.decode(iafStatusResponseMessageEvent);

        //then
        verify(pricingEncoderLookup).clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_DISCONNECTED);
    }
}