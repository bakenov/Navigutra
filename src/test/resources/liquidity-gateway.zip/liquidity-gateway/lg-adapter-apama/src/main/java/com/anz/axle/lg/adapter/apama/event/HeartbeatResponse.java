package com.anz.axle.lg.adapter.apama.event;

import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;

public class HeartbeatResponse {
    public static final String EVENT_NAME = "com.apama.fix.HeartbeatResponse";
    public static final Field<String> FIELD_TRANSPORT = GeneralApamaEventFields.FIELD_TRANSPORT;
    public static final Field<Long> FIELD_SEQUENCE_NUMBER = GeneralApamaEventFields.FIELD_SEQUENCE_NUMBER;
    public static final Field<Boolean> FIELD_CONNECTED = GeneralApamaEventFields.FIELD_CONNECTED;
    public static final EventType EVENT_TYPE = initEventType();

    private static EventType initEventType() {
        return new EventType(EVENT_NAME,
                FIELD_TRANSPORT,
                FIELD_SEQUENCE_NUMBER,
                FIELD_CONNECTED);
    }
}
