#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa013z "rm -rf ~/axle/datafabric/workspace/*"
