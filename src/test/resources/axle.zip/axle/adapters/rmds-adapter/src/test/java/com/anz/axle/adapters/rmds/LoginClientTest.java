package com.anz.axle.adapters.rmds;

import com.anz.markets.adapters.trep.consumer.LoginClient;
import com.anz.markets.adapters.trep.consumer.RdmClient;
import com.anz.markets.adapters.trep.util.OMMUtils;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.rdm.RDMUser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LoginClientTest {

    @Mock
    RdmClient rdmClient;
    
    @Test
    public void testLoginMessage() {
        when(rdmClient.getOMMPool()).thenReturn(OMMPool.create());
        
        LoginClient client = new LoginClient(rdmClient);
        
        String user = "axle";
        String appId = "AXLE";
        String position = "0.0.0.0";

        OMMMsg message = client.encodeLoginReqMsg(user, appId, position);
        assertNotNull(message);
        assertEquals(RDMMsgTypes.LOGIN, message.getMsgModelType());
        assertNotNull(message.getAttribInfo());
        
        assertNotNull(OMMUtils.getAttributeValue(RDMUser.Attrib.ApplicationId, message.getAttribInfo()));
        assertEquals(appId, OMMUtils.getAttributeValue(RDMUser.Attrib.ApplicationId, message.getAttribInfo()));
        
        assertNotNull(OMMUtils.getAttributeValue(RDMUser.Attrib.Position, message.getAttribInfo()));
        assertEquals(position,  OMMUtils.getAttributeValue(RDMUser.Attrib.Position, message.getAttribInfo()));

    }

}
