#!/bin/bash
source ~/axle/environment/shell/axle.rc

# Create archive filename
DATE_TODAY=`date +%Y%m%d`
DATE_NOW=`date +%Y%m%d_%H%M%S`

# prepare for archive run here
echo "*********************************************"
echo "PREPARING FOR ARCHIVE SCRIPT RUN $DATE_NOW"
echo "*********************************************"

PATH=$PATH:/opt/csw/bin
export PATH

AXLE=$HOME/axle
LOGS=$HOME/logs
ARCHIVE=$HOME/archive
ARCHIVE_LOGS=$ARCHIVE/logs

# Create destination directories if they do not exist
if [ ! -d $ARCHIVE ]
then
        echo "Creating $ARCHIVE directory..."
        mkdir -p $ARCHIVE
fi
if [ ! -d $ARCHIVE_LOGS ]
then
        echo "Creating $ARCHIVE_LOGS directory..."
        mkdir -p $ARCHIVE_LOGS
fi

cd $ARCHIVE_LOGS
# Move/Rename previous folder to the date specified in the previous.date file
if [ -f $ARCHIVE_LOGS/previous.date ]
then
	echo "previous.date file exists. "
	if [ -d $ARCHIVE_LOGS/previous ]
	then
		echo "Rename previous folder with the correct date"
		DIR=`cat previous.date`
		NEW_DIR=$DIR
		if [ -d $DIR ]
		then
			echo "Directory $NEW_DIR already exists"
		        #if the directory already exists, increment the directory name with a counter
		        count=0
		        while :
		        do
				        #increment counter
		                count=`echo $count+1 | bc`
		                NEW_DIR="$DIR"_"$count"
		                if [ ! -d $NEW_DIR ]
		                then
					break;
                		fi
        		done
		fi
		echo "Rename previous folder with $NEW_DIR"
		mv previous $NEW_DIR
	fi
else
	echo "previous.date file does not exist. Do nothing..."
fi

# Create date file
echo "Create previous.date file..."
echo $DATE_TODAY > $ARCHIVE_LOGS/previous.date
mkdir -p $ARCHIVE_LOGS/previous
