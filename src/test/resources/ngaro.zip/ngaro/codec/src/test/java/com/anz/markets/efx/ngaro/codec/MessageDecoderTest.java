package com.anz.markets.efx.ngaro.codec;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test for static and default methods in {@link MessageDecoder}.
 */
@RunWith(MockitoJUnitRunner.class)
public class MessageDecoderTest {

    @Mock
    private MessageDecoder<String> decoderForHello;
    @Mock
    private MessageDecoder<String> decoderForWorld;
    @Mock
    private MessageDecoder.Handler handler;

    @Mock
    private MessageDecoder.ForwardingLookup<String> forwardingLookup;

    private List<MessageDecoder<String>> decoders;

    private static class MyFactory implements MessageDecoder.Factory<String, MessageDecoder.Handler> {
        @Override
        public MessageDecoder<String> create(final Supplier<? extends MessageDecoder.Handler> handlerSupplier, final MessageDecoder.ForwardingLookup<String> forwardingLookup) {
            Objects.requireNonNull(handlerSupplier);
            Objects.requireNonNull(forwardingLookup);
            return mock(MessageDecoder.class);
        }
    }

    @Before
    public void init() {
        when(decoderForHello.decode("Hello")).thenReturn(true);
        when(decoderForWorld.decode("World")).thenReturn(true);
        decoders = Arrays.asList(decoderForHello, decoderForWorld);
    }

    @Test
    public void composite_hello_world() {
        composite(MessageDecoder.composite(decoderForHello, decoderForWorld));
    }

    @Test
    public void composite_world_hello() {
        composite(MessageDecoder.composite(decoderForWorld, decoderForHello));
    }

    @Test
    public void composite_list() {
        composite(MessageDecoder.composite(decoders));
    }

    private void composite(final MessageDecoder<String> decoder) {
        String message;
        boolean result;

        //when
        message = "Hello";
        result = decoder.decode(message);

        //then
        verify(decoderForHello).decode(message);
        assertEquals("Should successfully decode: " + message, true, result);

        //when
        message = "World";
        result = decoder.decode(message);

        //then
        verify(decoderForWorld).decode(message);
        assertEquals("Should successfully decode: " + message, true, result);

        //when
        message = "Other";
        result = decoder.decode(message);

        //then
        verify(decoderForHello).decode(message);
        verify(decoderForWorld).decode(message);
        assertEquals("Should fail to decode: " + message, false, result);
    }

    @Test
    public void composite_empty() {
        assertEquals("Should always fail to decode for no decoders", false,
                MessageDecoder.composite().decode("Anything"));
        assertEquals("Should always fail to decode for empty list", false,
                MessageDecoder.composite(Collections.emptyList()).decode("Anything"));
    }

    @Test(expected = NullPointerException.class)
    public void composite_null_varargs() {
        MessageDecoder.composite((MessageDecoder<String>[])null);
    }

    @Test(expected = NullPointerException.class)
    public void composite_null_list() {
        MessageDecoder.composite((List<MessageDecoder<String>>)null);
    }

    @Test
    public void factory_create_by_handler() {
        final MessageDecoder<?> decoder = new MyFactory().create(handler, forwardingLookup);
        assertNotNull("decoder should not be null", decoder);
    }

    @Test
    public void factory_create_by_supplier() {
        final MessageDecoder<?> decoder = new MyFactory().create(() -> handler, forwardingLookup);
        assertNotNull("decoder should not be null", decoder);
    }

    @Test(expected = NullPointerException.class)
    public void factory_create_null_handler() {
        new MyFactory().create((MessageDecoder.Handler)null, null);
    }

    @Test
    public void orThen_should_execute_next_decoder_when_first_decoder_results_in_false() {
        //given
        final MessageDecoder<String> first = message -> false;
        final MessageDecoder<String> next = mock(MessageDecoder.class);

        //when
        first.orThen(next).decode("some");

        //then
        verify(next).decode("some");
    }

    @Test
    public void orThen_should_not_execute_next_decoder_when_first_decoder_results_in_true() {
        //given
        final MessageDecoder<String> first = message -> true;
        final MessageDecoder<String> next = mock(MessageDecoder.class);

        //when
        first.orThen(next).decode("some");

        //then
        verify(next, never()).decode("some");
    }


    @Test
    public void andThen_should_execute_next_decoder_and_result_in_true_when_first_decoder_results_in_true_and_next_results_in_false() {
        //given
        final MessageDecoder<String> first = message -> true;
        final MessageDecoder<String> next = mock(MessageDecoder.class);
        when(next.decode("some")).thenReturn(false);

        //when
        assertThat(first.andThen(next).decode("some")).isTrue();

        //then
        verify(next).decode("some");
    }

    @Test
    public void andThen_should_execute_next_decoder_and_result_in_true_when_first_decoder_results_in_true_and_next_results_in_true() {
        //given
        final MessageDecoder<String> first = message -> true;
        final MessageDecoder<String> next = mock(MessageDecoder.class);
        when(next.decode("some")).thenReturn(true);

        //when
        assertThat(first.andThen(next).decode("some")).isTrue();

        //then
        verify(next).decode("some");
    }

    @Test
    public void andThen_should_not_execute_next_decoder_and_result_in_false_when_first_decoder_results_in_false() {
        //given
        final MessageDecoder<String> first = message -> false;
        final MessageDecoder<String> next = mock(MessageDecoder.class);

        //when
        assertThat(first.andThen(next).decode("some")).isFalse();

        //then
        verify(next, never()).decode("some");
    }

}