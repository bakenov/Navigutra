package com.anz.axle.direct.performance;

import org.joda.time.Duration;
import org.slf4j.Logger;

public final class LoggingProgressReporter implements ProgressReporter {

    private final Logger logger;

    public LoggingProgressReporter(final Logger logger) {
        this.logger = logger;
    }

    @Override
    public void beginTest(final String testName,
                          final Duration expectedDuration) {
        logger.info("Running test {} for {}", testName, expectedDuration);
    }

    @Override
    public void progress(final String testName,
                         final int step,
                         final int totalSteps) {
        logger.info("Test {} progress {}/" + totalSteps, testName, step + 1);
    }

    @Override
    public void completed(final String testName) {
        logger.info("Completed {}", testName);
    }
}
