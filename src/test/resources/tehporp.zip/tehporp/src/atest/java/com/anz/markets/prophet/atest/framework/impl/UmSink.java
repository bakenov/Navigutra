package com.anz.markets.prophet.atest.framework.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.agrona.DirectBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.microtime.NanoClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.PricingDecoders;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.prophet.atest.framework.Output;
import com.anz.markets.prophet.atest.framework.OutputSource;
import com.anz.markets.prophet.atest.framework.UmEndPoint;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.IndicativeReason;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;
import com.anz.markets.prophet.messaging.converters.MarketConverter;
import com.anz.markets.prophet.messaging.InstrumentLookup;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;

public class UmSink extends UmEndPoint {
    private static final Logger LOGGER = LoggerFactory.getLogger(UmSink.class);

    private final Connection connection;
    private final PricingDecoders<SbeMessage> pricingDecoders = new SbePricingDecoders();
    private final SbeMessageForReading sbeMessageForReading = new SbeMessageForReading();
    private final ProphetMarshallableCopier headerCopier = new ProphetMarshallableCopier();
    private final List<PreTopic> cpSubscriptionPreTopics = new ArrayList<>();
    private final List<PreTopic> fdmsSubscriptionPreTopics = new ArrayList<>();
    private final List<PreTopic> preTopicsForSubscription = new ArrayList<>();

    public UmSink(final Connection connection,
                  final List<Market> cppMarkets,
                  final List<Instrument> cppInstruments,
                  final String cppPublisherSuffix,
                  final List<Market> uppMarkets,
                  final List<Instrument> uppInstruments,
                  final String uppPublisherSuffix) {
        this.connection = connection;

        createTopics(cppMarkets, cppInstruments, cppPublisherSuffix, new ClientPriceMessageHandler(), cpSubscriptionPreTopics);
        createTopics(uppMarkets, uppInstruments, uppPublisherSuffix, new FilteredMarketDataMessageHandler(), fdmsSubscriptionPreTopics);
    }

    @Override
    public void openSubscriptions(final Market market, final Instrument instrument) {
        openSubscriptionsFromPreTopics(market, instrument, cpSubscriptionPreTopics);
        openSubscriptionsFromPreTopics(market, instrument, fdmsSubscriptionPreTopics);
    }

    @Override
    public void consumeIndexConfigurationData(final IndexedConfigurationData indexedConfigurationData) {
        // do nothing
    }

    private void createTopics(final List<Market> markets, final List<Instrument> instruments, final String publisherSuffix, final MessageHandler messageHandler,
                              final List<PreTopic> subscriptionsPreTopics) {
        final Iterable<Instrument> instrumentsToTraverse = instruments.contains(Instrument.ANY) ? Arrays.asList(Instrument.values()) : instruments;

        for (Market market : markets) {
            for (Instrument instrument : instrumentsToTraverse) {
                subscriptionsPreTopics.add(new PreTopic(instrument.isNDF1M() ? SecurityType.FXNDF : SecurityType.FXSPOT, market, instrument, publisherSuffix, messageHandler));
            }
        }
    }

    private void openSubscriptionsFromPreTopics(final Market market, final Instrument instrument, final List<PreTopic> preTopicList) {
        preTopicsForSubscription.addAll(
                preTopicList.stream()
                    .filter(preTopic -> preTopic.getMarket().equals(market) && preTopic.getInstrument().equals(instrument))
                    .collect(Collectors.toList()));
        preTopicList.removeAll(preTopicsForSubscription);
        preTopicsForSubscription.stream().forEach(pt -> {
            LOGGER.info("Opening Subscription {}: {}", ++totalOpenSubscriptions, pt.sinkTopicOf());
            connection.openSubscription(pt.sinkTopicOf(),UmEndPointStatusHandler.INSTANCE, pt.getMessageHandler());
        });
        preTopicsForSubscription.clear();
    }

    @Override
    public void close() {
        connection.close();
    }

    private abstract class SimpleMessageHander implements MessageHandler, SnapshotFullRefreshHandler {

        private final MessageDecoder<SbeMessage> messageDecoder = pricingDecoders.snapshotFullRefresh().create(this);
        protected final InstrumentLookup instrumentLookup = new InstrumentLookup();
        protected long receptionNanos;

        @Override
        public void onMessage(final Topic topic, final DirectBuffer buffer, final int offset, final int length, final long receiveTimeNanosSinceEpoch){
            receptionNanos = Context.context().timeSource().nowNanosRealTime();
            sbeMessageForReading.wrap(buffer, offset, length);
            try {
                messageDecoder.decode(sbeMessageForReading);
            }
            finally {
                sbeMessageForReading.unwrap();
            }
        }
    }

    private class ClientPriceMessageHandler extends SimpleMessageHander  {

        private ClientPriceImpl mutableClientPrice;
        private PriceAndQtyImpl currentEntry;
        private boolean indicative;

        @Override
        public void onBody(final Body body) {
            mutableClientPrice.setMarket(MarketConverter.toProphet(body.marketId()));
            mutableClientPrice.setInstrument(instrumentLookup.apply(body.instrumentId()));
            mutableClientPrice.setBookId(body.messageId());
            indicative = body.mdFlags().contains(Flag.INDICATIVE);
        }

        @Override
        public void onMdEntries_Body(final MdEntries.Body mdEntries_body, final int i, final int i1) {
            switch (mdEntries_body.mdEntryType()) {
                case BID:
                    currentEntry = (PriceAndQtyImpl) mutableClientPrice.getBids().addFromSupplier();
                    break;
                case OFFER:
                    currentEntry = (PriceAndQtyImpl) mutableClientPrice.getOffers().addFromSupplier();
                    break;
                default:
                    throw new IllegalArgumentException("Only expecting BID or OFFER entries");
            }

            currentEntry.setQty(mdEntries_body.mdEntrySize());
            currentEntry.setPrice(mdEntries_body.mdEntryPx());
        }


        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            receptionNanos = NanoClock.nanoClockUTC().nanos();
            mutableClientPrice = new ClientPriceImpl();
            mutableClientPrice.setExternalSourceId(sourceSeq);
            indicative = false;
        }

        @Override
        public void onMessageComplete() {
            if (indicative) {
                // can't specifically set an firewall type, so the presence of a reason should be tested
                mutableClientPrice.setBidAndOfferIndicative(true, PricingFirewallType.MINIMUM_MARKETS);
            }
            umBuffer.add(new Output(copyCurrentContextHeader(), mutableClientPrice, OutputSource.STAR_OUT));
        }

    }

    private Header copyCurrentContextHeader() {
        final Header header = new Header();
        headerCopier.copy(Context.context().header(), header);
        return header;
    }

    private class FilteredMarketDataMessageHandler extends SimpleMessageHander {

        private FilteredMarketDataSnapshotImpl mutableFmds;
        private MarketDataNewOrderImpl currentEntry;

        @Override
        public void onBody(final Body body) {
            mutableFmds.setMarket(MarketConverter.toProphet(body.marketId()));
            mutableFmds.setInstrument(instrumentLookup.apply(body.instrumentId()));
            mutableFmds.setEventId(String.valueOf(body.messageId()));
            if (body.mdFlags().contains(Flag.INDICATIVE)) {
                // can't specifically set an indicative reason, so the presence of a reason should be tested
                mutableFmds.setIndicativeReason(IndicativeReason.MINIMUM_MARKETS_NOT_AVAILABLE);
            }
        }

        @Override
        public void onMdEntries_Body(final MdEntries.Body mdEntries_body, final int i, final int i1) {
            switch (mdEntries_body.mdEntryType()) {
                case BID:
                    currentEntry = (MarketDataNewOrderImpl) mutableFmds.getBidEventList().addFromSupplier();
                    break;
                case OFFER:
                    currentEntry = (MarketDataNewOrderImpl) mutableFmds.getOfferEventList().addFromSupplier();
                    break;
                default:
                    throw new IllegalArgumentException("Only expecting BID or OFFER entries");
            }

            currentEntry.setQuantity(mdEntries_body.mdEntrySize());
            currentEntry.setPrice(mdEntries_body.mdEntryPx());
            if (mdEntries_body.mdEntryFlags().contains(Flag.INDICATIVE)) {
                currentEntry.setQuoteType(QuoteType.INDICATIVE);
            }
        }

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            receptionNanos = NanoClock.nanoClockUTC().nanos();
            mutableFmds = FilteredMarketDataSnapshotImpl.forMarket();
        }

        @Override
        public void onMessageComplete() {
            umBuffer.add(new Output(copyCurrentContextHeader(), mutableFmds, OutputSource.STAR_OUT));
        }
    }
}
