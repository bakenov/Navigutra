package com.anz.axle.lg.adapter.deut.quickfix;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.MDEntryID;
import quickfix.field.MDEntryPx;
import quickfix.field.MDEntrySize;
import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateAction;
import quickfix.field.MsgSeqNum;
import quickfix.field.NoMDEntries;
import quickfix.field.QuoteEntryID;
import quickfix.field.SendingTime;
import quickfix.field.Symbol;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.FixSide;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class DeutIncrementalRefreshHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeutIncrementalRefreshHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public DeutIncrementalRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                         final PricingEncoderLookup pricingEncoderLookup,
                                         final PrecisionClock precisionClock,
                                         final SubscriptionManager subscriptionManager,
                                         final String senderCompId,
                                         final String compId,
                                         final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender,
                                         final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_INCREMENTAL;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("MarketDataIncrementalRefresh received: {}", message);
        final int mdRequestId = message.getInt(MDReqID.FIELD);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = sequenceNumber; //FIXME prepend with uniquely generated session id
        final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
        final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());
        final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);
        final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
        final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        flagsAppender.accept(encoder.mdFlags());
        final IncrementalRefreshEncoder.Body mdEntries = encoder
                .senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .sendingTime(sendingTimeNanos)
                .referenceSpotDate().encodeNull()
                .tradeDate().encodeNull()
                .settlDate().encodeNull();
        final List<Group> groups = message.getGroups(NoMDEntries.FIELD);
        final Hops.Encoder<MessageEncoder.Trailer> hops;
        if (groups.size() > 0) {
            hops = encodeEntries(sendingTimeNanos, subscription, requestKey, mdEntries, groups, subscription.stringToIntCache());
        } else {
            hops = mdEntries.entriesEmpty();
        }
        hops
            .hopsStart(2)
            .next()
            .hopCompId().encode(senderCompId)
            .hopMessageId(sequenceNumber)
            .hopReceivingTime(0)
            .hopSendingTime(sendingTimeNanos)
            .next()
            .hopCompId().encode(compId)
            .hopMessageId(messageId)
            .hopReceivingTime(receivingTimeNanos)
            .hopSendingTime(precisionClock.nanos())
            .hopsComplete()
            .messageComplete();
        }

    private Hops.Encoder<MessageEncoder.Trailer> encodeEntries(final long sendingTimeNanos, final MarketDataSubscription subscription, final RequestKey requestKey, final IncrementalRefreshEncoder.Body mdEntries, final List<Group> groups, final StringToIntCache quoteIdCache) throws FieldNotFound {
        final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next = mdEntries.entriesStart(groups.size());
        for (Group priceEntryGroup : groups) {
            final char mdUpdateAction = priceEntryGroup.getChar(MDUpdateAction.FIELD);
            final char mdEntryType = priceEntryGroup.getChar(MDEntryType.FIELD);
            final EntryType side = FixSide.from(mdEntryType);
            final String fixSymbol = priceEntryGroup.getString(Symbol.FIELD);
            subscription.validateSymbol(fixSymbol);
            final int quoteEntryID = quoteEntryId(quoteIdCache, priceEntryGroup);
            if (MDUpdateAction.NEW == mdUpdateAction) {
                final int mdEntryId = quoteIdCache.put(priceEntryGroup.getString(MDEntryID.FIELD));
                newEntry(sendingTimeNanos, requestKey, mdEntries_Next, priceEntryGroup, side, mdEntryId, quoteEntryID);
            } else if (MDUpdateAction.CHANGE == mdUpdateAction) {
                final int mdEntryId = quoteIdCache.put(priceEntryGroup.getString(MDEntryID.FIELD));
                changeEntry(sendingTimeNanos, requestKey, mdEntries_Next, priceEntryGroup, side, mdEntryId, quoteEntryID);
            } else if (MDUpdateAction.DELETE == mdUpdateAction) {
                final int mdEntryId = quoteIdCache.remove(priceEntryGroup.getString(MDEntryID.FIELD));
                deleteEntry(sendingTimeNanos, requestKey, mdEntries_Next, side, mdEntryId, quoteEntryID);
            }
        }
        return mdEntries_Next.entriesComplete();
    }

    private int quoteEntryId(StringToIntCache stringToIntCache, final Group priceEntryGroup) throws FieldNotFound {
        final String quoteEntryIdStr  = priceEntryGroup.getString(QuoteEntryID.FIELD);
        if (quoteEntryIdStr != null && !quoteEntryIdStr.isEmpty()) {
            return stringToIntCache.put(quoteEntryIdStr);
        }
        return 0;
    }

    private void newEntry(final long sendingTimeNanos, final RequestKey requestKey, final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next, final Group priceEntryGroup, final EntryType side, final int mdEntryId, final int quoteEntryID) throws FieldNotFound {
        final double mdEntryPx = priceEntryGroup.getDouble(MDEntryPx.FIELD);
        final double mdEntrySize = priceEntryGroup.getDouble(MDEntrySize.FIELD);
        mdEntries_Next.next()
                .mdUpdateAction(UpdateAction.NEW)
                .transactTime(sendingTimeNanos)
                .mdMkt(requestKey.market())
                .mdEntryType(side)
                .mdEntrySize(mdEntrySize)
                .minQty(Double.NaN)
                .mdEntryPx(mdEntryPx)
                .mdEntryId(mdEntryId)
                .mdEntryRefId(0)
                .quoteEntryId(quoteEntryID);
    }

    private void changeEntry(final long sendingTimeNanos, final RequestKey requestKey, final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next, final Group priceEntryGroup, final EntryType side, final int mdEntryId, final int quoteEntryID) throws FieldNotFound {
        final double mdEntryPx = priceEntryGroup.getDouble(MDEntryPx.FIELD);
        final double mdEntrySize = priceEntryGroup.getDouble(MDEntrySize.FIELD);
        mdEntries_Next.next()
                .mdUpdateAction(UpdateAction.CHANGE)
                .transactTime(sendingTimeNanos)
                .mdMkt(requestKey.market())
                .mdEntryType(side)
                .mdEntrySize(mdEntrySize)
                .minQty(Double.NaN)
                .mdEntryPx(mdEntryPx)
                .mdEntryId(mdEntryId)
                .mdEntryRefId(0)
                .quoteEntryId(quoteEntryID);
    }

    private void deleteEntry(final long sendingTimeNanos, final RequestKey requestKey, final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next, final EntryType side, final int mdEntryId, final int quoteEntryID) {
        mdEntries_Next.next()
                .mdUpdateAction(UpdateAction.DELETE)
                .transactTime(sendingTimeNanos)
                .mdMkt(requestKey.market())
                .mdEntryType(side)
                .mdEntrySize(Double.NaN)
                .mdEntryPx(Double.NaN)
                .mdEntryId(mdEntryId)
                .mdEntryRefId(0)
                .quoteEntryId(quoteEntryID);
    }
}

