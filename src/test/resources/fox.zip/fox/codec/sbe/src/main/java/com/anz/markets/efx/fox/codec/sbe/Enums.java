package com.anz.markets.efx.fox.codec.sbe;


import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.InitStage;
import com.anz.markets.efx.fox.codec.sbe.raw.TimerGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.UserGroupsDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserGroupsEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.Venue;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueCategoriesDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueCategoriesEncoder;

final class Enums {

    static TimerGroup timerGroup(final com.anz.markets.efx.fox.codec.api.TimerGroup apiType) {
        if (apiType == null) {
            return TimerGroup.NULL_VAL;
        }

        switch (apiType) {
            case PARENT_ORDER_RELEASE:
                return TimerGroup.PARENT_ORDER_RELEASE;
            case CHILD_ORDER_PENDING_CANCEL_TO_DEAD:
                return TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD;
            case CHILD_ORDER_WAITING_TO_DEAD:
                return TimerGroup.CHILD_ORDER_WAITING_TO_DEAD;
            case CHILD_ORDER_WAITING_TO_WORKING:
                return TimerGroup.CHILD_ORDER_WAITING_TO_WORKING;
            case SYSTEM_HEARTBEAT:
                return TimerGroup.SYSTEM_HEARTBEAT;
            case USER_SESSION_MISSED_HEARTBEAT:
                return TimerGroup.USER_SESSION_MISSED_HEARTBEAT;
            case VENUE_MISSED_HEARTBEAT:
                return TimerGroup.VENUE_MISSED_HEARTBEAT;
            default:
                throw new IllegalArgumentException("TimerGroup not supported: " + apiType);
        }
    }

    static com.anz.markets.efx.fox.codec.api.TimerGroup timerGroup(final TimerGroup sbeType) {
        if (sbeType == null) {
            return null;
        }
        switch (sbeType) {
            case PARENT_ORDER_RELEASE:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.PARENT_ORDER_RELEASE;
            case CHILD_ORDER_PENDING_CANCEL_TO_DEAD:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.CHILD_ORDER_PENDING_CANCEL_TO_DEAD;
            case CHILD_ORDER_WAITING_TO_DEAD:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.CHILD_ORDER_WAITING_TO_DEAD;
            case CHILD_ORDER_WAITING_TO_WORKING:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.CHILD_ORDER_WAITING_TO_WORKING;
            case SYSTEM_HEARTBEAT:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.SYSTEM_HEARTBEAT;
            case USER_SESSION_MISSED_HEARTBEAT:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.USER_SESSION_MISSED_HEARTBEAT;
            case VENUE_MISSED_HEARTBEAT:
                return com.anz.markets.efx.fox.codec.api.TimerGroup.VENUE_MISSED_HEARTBEAT;
            case NULL_VAL:
                return null;
            default:
                throw new IllegalArgumentException("TimerGroup not supported: " + sbeType);
        }
    }

    static Venue venue(final com.anz.markets.efx.ngaro.api.Venue apiType) {
        if (apiType == null) {
            return Venue.NULL_VAL;
        }
        switch (apiType) {
            case FAST:
                return Venue.FAST;
            case FASTMD:
                return Venue.FASTMD;
            case KGI:
                return Venue.KGI;
            case DEUT:
                return Venue.DEUT;
            case UBS:
                return Venue.UBS;
            case CNX:
                return Venue.CNX;
            case HSP:
                return Venue.HSP;
            case HSPMD:
                return Venue.HSPMD;
            case BARX:
                return Venue.BARX;
            case MSI:
                return Venue.MSI;
            case GS:
                return Venue.GS;
            case GCS:
                return Venue.GCS;
            case RFX:
                return Venue.RFX;
            case CITI:
                return Venue.CITI;
            case CITIFW:
                return Venue.CITIFW;
            case CMZ:
                return Venue.CMZ;
            case FXBK:
                return Venue.FXBK;
            case D3:
                return Venue.D3;
            case EBS:
                return Venue.EBS;
            case EBSD:
                return Venue.EBSD;
            case JPM:
                return Venue.JPM;
            case AXL:
                return Venue.AXL;
            case LMAX:
                return Venue.LMAX;
            case LMAXP:
                return Venue.LMAXP;
            case ANZD:
                return Venue.ANZD;
            case D3NDF:
                return Venue.D3NDF;
            case D3BLEND:
                return Venue.D3BLEND;
            case BGCMIDFX:
                return Venue.BGCMIDFX;
            case DBS:
                return Venue.DBS;
            case OCX:
                return Venue.OCX;
            case FOX:
                return Venue.FOX;
            case WSP_A:
                return Venue.WSP_A;
            case WSP_API_1:
                return Venue.WSP_API_1;
            case WSP_API_2:
                return Venue.WSP_API_2;
            case WSP_API_3:
                return Venue.WSP_API_3;
            case WSP_API_4:
                return Venue.WSP_API_4;
            case WSP_API_5:
                return Venue.WSP_API_5;
            case WSP_API_6:
                return Venue.WSP_API_6;
            case WSP_B:
                return Venue.WSP_B;
            case WSP_C:
                return Venue.WSP_C;
            case WSP_MU:
                return Venue.WSP_MU;
            case WSP_R:
                return Venue.WSP_R;
            case WSP_U:
                return Venue.WSP_U;
            case WSP_Z:
                return Venue.WSP_Z;
            case MAHI1:
                return Venue.MAHI1;
            case MAHI2:
                return Venue.MAHI2;
            case MAHI3:
                return Venue.MAHI3;
            case CMEJMP:
                return Venue.CMEJMP;
            case EBSHEDGE:
                return Venue.EBSHEDGE;
            case FXALLMB:
                return Venue.FXALLMB;
            case TRSBE:
                return Venue.TRSBE;
            case EBSU:
                return Venue.EBSU;
            case EBSUNS:
                return Venue.EBSUNS;
            default:
                throw new IllegalArgumentException("Venue not supported: " + apiType);
        }
    }

    static com.anz.markets.efx.ngaro.api.Venue venue(final Venue sbeType) {
        if (sbeType == null) {
            return null;
        }
        switch (sbeType) {
            case FAST:
                return com.anz.markets.efx.ngaro.api.Venue.FAST;
            case FASTMD:
                return com.anz.markets.efx.ngaro.api.Venue.FASTMD;
            case KGI:
                return com.anz.markets.efx.ngaro.api.Venue.KGI;
            case DEUT:
                return com.anz.markets.efx.ngaro.api.Venue.DEUT;
            case UBS:
                return com.anz.markets.efx.ngaro.api.Venue.UBS;
            case CNX:
                return com.anz.markets.efx.ngaro.api.Venue.CNX;
            case HSP:
                return com.anz.markets.efx.ngaro.api.Venue.HSP;
            case HSPMD:
                return com.anz.markets.efx.ngaro.api.Venue.HSPMD;
            case BARX:
                return com.anz.markets.efx.ngaro.api.Venue.BARX;
            case MSI:
                return com.anz.markets.efx.ngaro.api.Venue.MSI;
            case GS:
                return com.anz.markets.efx.ngaro.api.Venue.GS;
            case GCS:
                return com.anz.markets.efx.ngaro.api.Venue.GCS;
            case RFX:
                return com.anz.markets.efx.ngaro.api.Venue.RFX;
            case CITI:
                return com.anz.markets.efx.ngaro.api.Venue.CITI;
            case CITIFW:
                return com.anz.markets.efx.ngaro.api.Venue.CITIFW;
            case CMZ:
                return com.anz.markets.efx.ngaro.api.Venue.CMZ;
            case FXBK:
                return com.anz.markets.efx.ngaro.api.Venue.FXBK;
            case D3:
                return com.anz.markets.efx.ngaro.api.Venue.D3;
            case EBS:
                return com.anz.markets.efx.ngaro.api.Venue.EBS;
            case EBSD:
                return com.anz.markets.efx.ngaro.api.Venue.EBSD;
            case JPM:
                return com.anz.markets.efx.ngaro.api.Venue.JPM;
            case AXL:
                return com.anz.markets.efx.ngaro.api.Venue.AXL;
            case LMAX:
                return com.anz.markets.efx.ngaro.api.Venue.LMAX;
            case LMAXP:
                return com.anz.markets.efx.ngaro.api.Venue.LMAXP;
            case ANZD:
                return com.anz.markets.efx.ngaro.api.Venue.ANZD;
            case D3NDF:
                return com.anz.markets.efx.ngaro.api.Venue.D3NDF;
            case D3BLEND:
                return com.anz.markets.efx.ngaro.api.Venue.D3BLEND;
            case BGCMIDFX:
                return com.anz.markets.efx.ngaro.api.Venue.BGCMIDFX;
            case DBS:
                return com.anz.markets.efx.ngaro.api.Venue.DBS;
            case OCX:
                return com.anz.markets.efx.ngaro.api.Venue.OCX;
            case FOX:
                return com.anz.markets.efx.ngaro.api.Venue.FOX;
            case WSP_A:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_A;
            case WSP_API_1:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_API_1;
            case WSP_API_2:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_API_2;
            case WSP_API_3:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_API_3;
            case WSP_API_4:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_API_4;
            case WSP_API_5:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_API_5;
            case WSP_API_6:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_API_6;
            case WSP_B:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_B;
            case WSP_C:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_C;
            case WSP_MU:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_MU;
            case WSP_R:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_R;
            case WSP_U:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_U;
            case WSP_Z:
                return com.anz.markets.efx.ngaro.api.Venue.WSP_Z;
            case MAHI1:
                return com.anz.markets.efx.ngaro.api.Venue.MAHI1;
            case MAHI2:
                return com.anz.markets.efx.ngaro.api.Venue.MAHI2;
            case MAHI3:
                return com.anz.markets.efx.ngaro.api.Venue.MAHI3;
            case CMEJMP:
                return com.anz.markets.efx.ngaro.api.Venue.CMEJMP;
            case EBSHEDGE:
                return com.anz.markets.efx.ngaro.api.Venue.EBSHEDGE;
            case FXALLMB:
                return com.anz.markets.efx.ngaro.api.Venue.FXALLMB;
            case TRSBE:
                return com.anz.markets.efx.ngaro.api.Venue.TRSBE;
            case EBSU:
                return com.anz.markets.efx.ngaro.api.Venue.EBSU;
            case EBSUNS:
                return com.anz.markets.efx.ngaro.api.Venue.EBSUNS;
            case NULL_VAL:
                return null;
            default:
                throw new IllegalArgumentException("Venue not supported: " + sbeType);
        }
    }

    static void venueCategory(final VenueCategory value, final VenueCategoriesEncoder encoder, final boolean set) {
        switch (value) {
            case BANK:
                encoder.bank(set);
                break;
            case INTERBANK:
                encoder.interbank(set);
                break;
            case MATCHING_AGENT:
                encoder.matchingAgent(set);
                break;
            default:
                throw new IllegalArgumentException("VenueCategory not supported: " + value);
        }
    }

    static boolean venueCategory(final VenueCategory value, final VenueCategoriesDecoder decoder) {
        switch (value) {
            case BANK:
                return decoder.bank();
            case INTERBANK:
                return decoder.interbank();
            case MATCHING_AGENT:
                return decoder.matchingAgent();
            default:
                throw new IllegalArgumentException("VenueCategory not supported: " + value);
        }
    }

    static void userGroup(final UserGroup value, final UserGroupsEncoder encoder, final boolean set) {
        switch (value) {
            case TRADER:
                encoder.trader(set);
                break;
            case ADMIN:
                encoder.admin(set);
                break;
            case SUPER_ADMIN:
                encoder.superAdmin(set);
                break;
            case READ_ONLY:
                encoder.readOnly(set);
                break;
            default:
                throw new IllegalArgumentException("UserGroup not supported: " + value);
        }
    }

    static boolean userGroup(final UserGroup value, final UserGroupsDecoder decoder) {
        switch (value) {
            case TRADER:
                return decoder.trader();
            case ADMIN:
                return decoder.admin();
            case SUPER_ADMIN:
                return decoder.superAdmin();
            case READ_ONLY:
                return decoder.readOnly();
            default:
                throw new IllegalArgumentException("UserGroup not supported: " + value);
        }
    }

    static InitStage initStage(final com.anz.markets.efx.fox.codec.api.InitStage apiType) {
        if (apiType == null) {
            return InitStage.NULL_VAL;
        }
        switch (apiType) {
            case BEGIN:
                return InitStage.BEGIN;
            case END:
                return InitStage.END;
            default:
                throw new IllegalArgumentException("InitStage not supported: " + apiType);
        }
    }

    static com.anz.markets.efx.fox.codec.api.InitStage initStage(final InitStage sbeType) {
        if (sbeType == null) {
            return null;
        }
        switch (sbeType) {
            case BEGIN:
                return com.anz.markets.efx.fox.codec.api.InitStage.BEGIN;
            case END:
                return com.anz.markets.efx.fox.codec.api.InitStage.END;
            case NULL_VAL:
                return null;
            default:
                throw new IllegalArgumentException("InitStage not supported: " + sbeType);
        }
    }

// I expect we will soon have a region in SOR codec, so
// it might be better for this code to stay commented out
//
//    static Region region(final com.anz.markets.efx.fox.codec.api.Region apiType) {
//        if (apiType == null) {
//            return Region.NULL_VAL;
//        }
//        switch (apiType) {
//            case GB:
//                return Region.GB;
//            case AU:
//                return Region.AU;
//            case JP:
//                return Region.JP;
//            default:
//                throw new IllegalArgumentException("Region not supported: " + apiType);
//        }
//    }
//
//    static com.anz.markets.efx.fox.codec.api.Region region(final Region sbeType) {
//        if (sbeType == null) {
//            return null;
//        }
//        switch (sbeType) {
//            case GB:
//                return com.anz.markets.efx.fox.codec.api.Region.GB;
//            case AU:
//                return com.anz.markets.efx.fox.codec.api.Region.AU;
//            case JP:
//                return com.anz.markets.efx.fox.codec.api.Region.JP;
//            case NULL_VAL:
//                return null;
//            default:
//                throw new IllegalArgumentException("Region not supported: " + sbeType);
//        }
//    }

    private Enums() {
        throw new RuntimeException("No Enums for you!");
    }
}
