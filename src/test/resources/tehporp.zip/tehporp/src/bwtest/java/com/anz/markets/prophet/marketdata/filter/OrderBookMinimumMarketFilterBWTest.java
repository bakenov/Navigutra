package com.anz.markets.prophet.marketdata.filter;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBook;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.status.Context;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class OrderBookMinimumMarketFilterBWTest {

    private static final int REPS = 100_000, THRESHOLD = 0;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private OrderBookMinimumMarketFilter orderBookMinimumMarketFilter;
    private AggregatedBook aggBook;

    @BeforeClass
    public static void warmup() {
        Context.region(Region.GB);
        final OrderBookMinimumMarketFilterBWTest test = new OrderBookMinimumMarketFilterBWTest();
        test.setUp();
        test.moreThanTwoMarkets();
    }

    @Before
    public void setUp() {
        orderBookMinimumMarketFilter = new OrderBookMinimumMarketFilter();
        orderBookMinimumMarketFilter.accept(OrderBookMinimumMarketFilterTest.createConfigurationData());
        aggBook = OrderBookDispersionFilterTest.createAggBook();
    }

    @Test
    public void testWithMoreThanTwoMarkets() {
        helper.testAllocationNotExceeded(
                () -> moreThanTwoMarkets(),
                REPS, REPS,
                THRESHOLD
        );
    }

    public void moreThanTwoMarkets() {
        final FilterDecision filterDecision = orderBookMinimumMarketFilter.perform(aggBook).getFilterOutcome();
        if (filterDecision != FilterDecision.PASS) {
            throw new AssertionError("not PASS");
        }
    }
}