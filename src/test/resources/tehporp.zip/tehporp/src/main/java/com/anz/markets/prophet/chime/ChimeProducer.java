package com.anz.markets.prophet.chime;


import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Consumer;

public class ChimeProducer {

    private final List<Consumer<TradingTimeZoneChime>> chimeConsumers;
    private final List<Consumer<HourChime>> hourChimeConsumers;
    private final List<Consumer<EndOfWeekChime>> endOfWeekChimeConsumers;

    public ChimeProducer(@NotNull final List<Consumer<TradingTimeZoneChime>> tradingTimeZoneChimeConsumers,
                         @NotNull final List<Consumer<HourChime>> hourChimeConsumers,
                         @NotNull final List<Consumer<EndOfWeekChime>> endOfWeekChimeConsumers) {
        this.chimeConsumers = tradingTimeZoneChimeConsumers;
        this.hourChimeConsumers = hourChimeConsumers;
        this.endOfWeekChimeConsumers = endOfWeekChimeConsumers;
    }

    public Consumer<TradingTimeZoneChime> consumerOfTradingTimeZoneChime() {
        return this::accept;
    }

    public void accept(final TradingTimeZoneChime tradingTimeZoneChime) {
        chimeConsumers.forEach(consumer -> consumer.accept(tradingTimeZoneChime));
    }

    public Consumer<HourChime> consumerOfHourChime() {
        return this::accept;
    }

    public void accept(final HourChime hourChime) {
        hourChimeConsumers.forEach(consumer -> consumer.accept(hourChime));
    }

    public Consumer<EndOfWeekChime> consumerOfEndOfWeekChime() {
        return this::accept;
    }

    public void accept(final EndOfWeekChime endOfWeekChime) {
        endOfWeekChimeConsumers.forEach(consumer -> consumer.accept(endOfWeekChime));
    }
}
