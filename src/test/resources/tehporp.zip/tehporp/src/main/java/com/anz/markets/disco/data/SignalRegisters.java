package com.anz.markets.disco.data;

import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.marketdata.InstrumentAndMarket;

import java.util.ArrayList;
import java.util.List;

public class SignalRegisters {

    private final EnumObjTable<Market, Instrument, Signals> map = new EnumObjTable<>(Market.class, Instrument.class);

    private final EnumObjMap<SignalType,List<ListenerState>> signalTypeListeners = new EnumObjMap<>(SignalType.class);
    private final List<ListenerState> listenersToNotify = new ArrayList();

    private static class ListenerState {
        SignalRegistersListener listener;
        boolean queued;

        public ListenerState(final SignalRegistersListener listener) {
            this.listener = listener;
        }
    }

    public interface SignalRegistersListener {
        void changed(Signals updates, Signals curr);
    }

    public void addListener(final SignalRegistersListener listener, SignalType... signalTypes) {
        if (signalTypes.length == 0) {
            signalTypes = SignalType.getValues();
        }
        final ListenerState listenerState = new ListenerState(listener);
        for (SignalType signalType : signalTypes) {
            signalTypeListeners.computeIfAbsent(signalType,x -> new ArrayList<>()).add(listenerState);
        }
    }

    public void addSignals(final Signals signals) {
        listenersToNotify.clear();

        final Signals curr = getSignals(signals.getMarket(), signals.getInstrument());

        try {
            for (int i = 0; i < signals.getSize(); i++) {
                final Signal signal = signals.getSignal(i);
                final MutableSignal mutableSignal = (MutableSignal) curr.getSignal(signal.getSignalType());
                mutableSignal.setValue(signal.getValue());
                mutableSignal.setConditionCode(signal.getConditionCode());

                final List<ListenerState> toNotify = signalTypeListeners.get(signal.getSignalType());
                if (toNotify != null) {
                    for (int j = 0; j < toNotify.size(); j++) {
                        final ListenerState listenerState = toNotify.get(j);
                        // Ensure only notify once per signal set even if registered for multiple signal types.
                        if (!listenerState.queued) {
                            listenerState.queued = true;
                            listenersToNotify.add(listenerState);
                        }
                    }
                }
            }
        } finally {
            for (int i = 0; i < listenersToNotify.size(); i++) {
                final ListenerState listenerState = listenersToNotify.get(i);
                try {
                    listenerState.listener.changed(signals, curr);
                } finally {
                    listenerState.queued = false;
                }
            }
        }
    }

    public Signals getSignals(InstrumentAndMarket instrumentAndMarket) {
        return getSignals(instrumentAndMarket.getMarket(), instrumentAndMarket.getInstrument());
    }

    public Signals getSignals(Market market, Instrument instrument) {
        GcFriendlyAssert.notNull(market);
        GcFriendlyAssert.notNull(instrument);
        return map.computeIfAbsent(market, instrument, () -> {
            final MutableSignals signals = new MutableSignals(market,instrument);
            for (SignalType signalType : SignalType.values()) {
                signals.add(signalType,Double.NaN, Symbol.EMPTY);
            }
            return signals;
        });
    }

}
