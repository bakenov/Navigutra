#!/bin/bash

ssh AxlSv@daxa004z 'cd /app/apama/axle/environment/correlator/scripts && ./stop.sh'
ssh axle@daxa011z 'cd /app/apama/axle/environment/correlator/scripts && ./stop.sh'

ssh AxlSv@daxa004z 'ps -ef | grep "iaf" | grep -v 'grep' | awk '{ print $2 }' | xargs -l kill -9'
ssh axle@daxa011z 'ps -ef | grep "iaf" | grep -v 'grep' | awk '{ print $2 }' | xargs -l kill -9'

ssh axle@daxa015z 'cd /app/apama/axle/environment/proxy/scripts && ./stop.sh'
ssh AxlSv@daxa004z 'cd /app/apama/axle/environment/proxy/scripts && ./stop.sh'

ssh axle@daxa011z 'rm -rf ~axle/axle/datafabric/workspace/*'
ssh AxlSv@daxa004z 'rm -rf ~axle/axle/datafabric/workspace/*'

ssh axle@daxa011z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'
ssh AxlSv@daxa004z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh && sleep 5 && ./stop-datafabric.sh && sleep 5 && ./start-datafabric.sh'

ssh axle@daxa015z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'
ssh AxlSv@daxa004z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'

