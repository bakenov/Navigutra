package com.anz.axle.lg.adapter.apama.transport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingConnectionStatusHandler implements ConnectionStatusHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingConnectionStatusHandler.class);

    @Override
    public void onConnect(final Connection connection) {
        LOGGER.info("Connected {}", connection.connectionConfig());
    }

    @Override
    public void onDisconnect(final Connection connection) {
        LOGGER.warn("Disconnected {}", connection.connectionConfig());
    }

    @Override
    public void onNotification(final Connection connection, final String notification) {
        LOGGER.info("Notification: {}, {}", notification, connection.connectionConfig());
    }
}
