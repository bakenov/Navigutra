package com.anz.markets.prophet.config.business.domain.tabular.impl;


import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByMonitorHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpHedgerConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class AggressiveSpeedUpByMonitorHedgerConfigImpl extends AggressiveSpeedUpHedgerConfigImpl implements AggressiveSpeedUpByMonitorHedgerConfig, AggressiveSpeedUpHedgerConfig, ProphetMarshallable {

    protected static final Logger LOGGER = LoggerFactory.getLogger(AggressiveSpeedUpByMonitorHedgerConfigImpl.class);

    private String hedgeMonitor;
    private transient Set<Portfolio> hedgeMonitorPortfolios;
    private long hedgeMonitorWindowSeconds;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public AggressiveSpeedUpByMonitorHedgerConfigImpl() {
    }

    public AggressiveSpeedUpByMonitorHedgerConfigImpl(final Market market, final Instrument instrument) {
        super(market, instrument);
    }

    @Override
    public String getHedgeMonitor() {
        return this.hedgeMonitor;
    }

    @JsonIgnore
    @Override
    public Set<Portfolio> getHedgeMonitorPortfolios() {
        if (hedgeMonitorPortfolios == null) {
            hedgeMonitorPortfolios = new HashSet<>();
            Arrays.stream(this.hedgeMonitor.split(",|;|\\|")).map(String::trim).forEach(portfolioName -> {
                if (Portfolio.isValidName(portfolioName)) {
                    hedgeMonitorPortfolios.add(Portfolio.valueOf(portfolioName));
                } else if (portfolioName.equals("ANY")) {
                    for (Portfolio p : Portfolio.values()) {
                        if (p.isMidHedger()) {
                            hedgeMonitorPortfolios.add(p);
                        }
                    }
                } else {
                    LOGGER.warn("'{}' not a valid portfolio.", portfolioName);
                }
            });
        }
        return hedgeMonitorPortfolios;
    }

    @Override
    public long getHedgeMonitorWindowSeconds() {
        return this.hedgeMonitorWindowSeconds;
    }

    public AggressiveSpeedUpByMonitorHedgerConfigImpl setHedgeMonitor(final String hedgeMonitor) {
        this.hedgeMonitorPortfolios = null;
        this.hedgeMonitor = hedgeMonitor;
        return this;
    }

    public AggressiveSpeedUpByMonitorHedgerConfigImpl setHedgeMonitorWindowSeconds(final long hedgeMonitorWindowSeconds) {
        this.hedgeMonitorWindowSeconds = hedgeMonitorWindowSeconds;
        return this;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        super.readMarshallable(in);
        this.hedgeMonitor = in.readUTF8();
        this.hedgeMonitorWindowSeconds = in.readLong();
        this.hedgeMonitorPortfolios = null;
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        super.writeMarshallable(out);
        out.writeUTF8(this.hedgeMonitor);
        out.writeLong(this.hedgeMonitorWindowSeconds);
    }

    @Override
    public String toString() {
        return "AggressiveSpeedUpByMonitorHedgerConfigImpl{" +
                "market=" + getMarket() +
                ", instrument=" + getInstrument() +
                ", pnLThreshold=" + getPnLThreshold() +
                ", minimumRisk=" + getMinimumRisk() +
                ", hedgeMonitor='" + hedgeMonitor + '\'' +
                ", hedgeMonitorWindowSeconds=" + hedgeMonitorWindowSeconds +
                ", tradingTimeZone=" + getTradingTimeZone() +
                ", maximumSpread=" + getMaximumSpread() +
                ", minimumOrderQuantity=" + getMinimumOrderQuantity() +
                '}';
    }
}
