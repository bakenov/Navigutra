package software.chronicle.fix.cfg;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import quickfix.SessionSettings;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.QuickFIXUtils;

/**
 * Created by peter on 26/01/2017.
 */
public class QuickFIXUtilsTest {

    public static void main(String[] args) throws Exception
    {
        new QuickFIXUtilsTest().engineCfgFor();
    }

    private void engineCfgFor() throws Exception {
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        SessionSettings settings = new SessionSettings(getClass().getResourceAsStream("/acceptorSettings.txt"));
        FixEngineCfg engineCfg = QuickFIXUtils.engineCfgFor(settings);
        assert engineCfg.toString().equals( "!software.chronicle.fix.cfg.FixEngineCfg {\n" +
                "  \"FIX.4.2:MY-ACCEPTOR-SERVICE->MY-INITIATOR-SERVICE\": {\n" +
                "    connectionType: acceptor,\n" +
                "    reconnectInterval: 6030,\n" +
                "    senderCompID: MY-ACCEPTOR-SERVICE,\n" +
                "    fixVersion: V4_2,\n" +
                "    heartBtInt: 30,\n" +
                "    targetCompID: MY-INITIATOR-SERVICE,\n" +
                "    fileStorePath: quickfixj/store,\n" +
                "    startDay: SUNDAY,\n" +
                "    startTime: 00:00,\n" +
                "    endDay: SUNDAY,\n" +
                "    endTime: 00:00,\n" +
                "    timezone: Australia/Melbourne,\n" +
                "    socketAcceptorHostPort: \"12002\",\n" +
                "    resetOnLogon: false\n" +
                "  }\n" +
                "}\n" );

        SessionSettings settings2 = new SessionSettings(getClass().getResourceAsStream("/sessionSettings50.txt"));
        FixEngineCfg engineCfg2 = QuickFIXUtils.engineCfgFor(settings2);
        assert engineCfg2.toString().equals( "!software.chronicle.fix.cfg.FixEngineCfg {\n" +
                "  \"FIX.5.0:FIX_CLIENT50->CHRONICLE_FIX\": {\n" +
                "    connectionType: initiator,\n" +
                "    reconnectInterval: 5,\n" +
                "    senderCompID: FIX_CLIENT50,\n" +
                "    fixVersion: V5_0,\n" +
                "    heartBtInt: 30,\n" +
                "    targetCompID: CHRONICLE_FIX,\n" +
                "    fileStorePath: quickfixj/store,\n" +
                "    startTime: 00:00,\n" +
                "    endTime: 00:00,\n" +
                "    socketConnectHostPort: [ \"localhost:9999\" ],\n" +
                "    resetOnLogon: true\n" +
                "  }\n" +
                "}\n" );
    }

}