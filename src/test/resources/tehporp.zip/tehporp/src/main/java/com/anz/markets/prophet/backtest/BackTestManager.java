package com.anz.markets.prophet.backtest;


import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.efx.ngaro.collections.EnumLongMap;

import java.util.function.Predicate;

public class BackTestManager {

    private final MessageTypeFilterPredicate messageTypeFilterPredicate;
    private final boolean isBackTestEnabled;

    private BackTestManager(final boolean isBackTestEnabled, final boolean writeDownAll) {
        this.isBackTestEnabled = isBackTestEnabled;
        this.messageTypeFilterPredicate = new MessageTypeFilterPredicate(writeDownAll? Enabled.ON : Enabled.OFF);
    }

    public static BackTestManager create(final boolean writeDownAll) {
        return new BackTestManager(false, writeDownAll);
    }

    public static BackTestManager createWithBackTestEnabled(final boolean writeDownAll) {
        return new BackTestManager(true, writeDownAll);
    }

    public boolean isBackTestEnabled() {
        return isBackTestEnabled;
    }

    public void enablePersistableMessageType(final MessageType...messageTypes) {
        this.messageTypeFilterPredicate.setPersistableMessageType(Enabled.ON, messageTypes);
    }

    public void disablePersistableMessageType(final MessageType...messageTypes) {
        this.messageTypeFilterPredicate.setPersistableMessageType(Enabled.OFF, messageTypes);
    }

    public Predicate<MessageType> messageTypeFilterPredicate() {
        return messageTypeFilterPredicate;
    }

    private enum Enabled {
        ON(0L),
        OFF(1L);

        private final long code;

        Enabled(final long code) {
            this.code = code;
        }
    }

    private class MessageTypeFilterPredicate implements Predicate<MessageType> {

        private final EnumLongMap messageTypes = new EnumLongMap<>(MessageType.class);

        public MessageTypeFilterPredicate(final Enabled defaultValue) {
            setPersistableMessageType(defaultValue, MessageType.values());
        }

        private void setPersistableMessageType(final Enabled enabled, final MessageType...messageTypes) {
            for(MessageType messageType : messageTypes) {
                this.messageTypes.put(messageType, enabled.code);
            }
        }

        @Override
        public boolean test(final MessageType messageType) {
            return this.messageTypes.get(messageType) == Enabled.ON.code;
        }
    }
}
