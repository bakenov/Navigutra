package com.anz.markets.efx.fox.processor.state;

import com.anz.markets.efx.fox.api.domain.ParentOrderDetails;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectEncoder;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

public class ChildOrderCancelRejectLinkedToParentOrderPublisher {
    public static void publish(final TradingEncoderSupplier encoderSupplier,
                               final OrderCancelRejectDecoder orderCancelRejectDecoder,
                               final ParentOrderDetails parentOrderDetails) {
        final Header header = orderCancelRejectDecoder.header();
        final OrderCancelRejectDecoder.Body body = orderCancelRejectDecoder.body();
        final OrderCancelRejectEncoder.Body orderCancelRejectEncoderBody = encoderSupplier.orderCancelReject()
                .messageStart(header.source(), header.sourceSeq())
                .senderCompId().encodeFrom(body.senderCompId())
                .targetCompId().encodeFrom(body.targetCompId())
                .messageId(body.messageId())
                .orderId().encodeFrom(body.orderId())
                .clOrdId().encodeFrom(body.clOrdId())
                .origClOrdId().encodeFrom(body.origClOrdId())
                .clOrdLinkId().encodeLong(parentOrderDetails.orderId())
                .marketId().encodeFrom(body.marketId())
                .ordStatus(body.ordStatus())
                .transactTime(body.transactTime())
                .cxlRejReason(body.cxlRejReason())
                .cxlRejResponseTo(body.cxlRejResponseTo());

        final OrderCancelRejectDecoder.Party parties = orderCancelRejectDecoder.parties();
        final int partiesCount = parties.count();
        final OrderCancelRejectEncoder.Parties partiesGroup  = orderCancelRejectEncoderBody.partiesStart(partiesCount);
        for (OrderCancelRejectDecoder.Party party : parties) {
            partiesGroup.next().partyRole(party.partyRole()).partyId().encodeFrom(party.partyId());
        }
        final OrderCancelRejectDecoder.Hop hops = orderCancelRejectDecoder.hops();
        final int hopsCount = hops.count();
        final Hops.Encoder.Next<OrderCancelRejectEncoder.Text> hopsGroup = partiesGroup.partiesComplete().hopsStart(hopsCount);
        for (OrderCancelRejectDecoder.Hop hop : hops) {
            hopsGroup.next().hopReceivingTime(hop.hopReceivingTime())
                    .hopSendingTime(hop.hopSendingTime())
                    .hopMessageId(hop.hopMessageId())
                    .hopCompId().encodeFrom(hop.hopCompId());
        }
        hopsGroup.hopsComplete()
                .text().encodeFrom(orderCancelRejectDecoder.trailer().text())
                .messageComplete();
    }

    private ChildOrderCancelRejectLinkedToParentOrderPublisher() {
        throw new IllegalStateException("No ChildOrderCancelRejectLinkedToParentOrderPublisher for you");
    }
}
