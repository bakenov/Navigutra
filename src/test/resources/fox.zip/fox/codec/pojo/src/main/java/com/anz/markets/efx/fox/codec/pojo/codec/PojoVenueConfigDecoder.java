package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumSetDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.SimpleStringDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoVenueConfigDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends VenueConfigHandler> handlerSupplier;

    public PojoVenueConfigDecoder(final Supplier<? extends VenueConfigHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof VenueConfig) {
            return decode((VenueConfig) sorMessage);
        }
        return false;
    }

    public boolean decode(final VenueConfig message) {
        final VenueConfigHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source,message.header.sourceSeq);
        handler.onBody(new VenueConfigHandler.Body() {
            final EnumerableSetDecoder<VenueCategory> venueCategories = new EnumSetDecoder<>(VenueCategory::length, VenueCategory::valueByOrdinal, message.body.venueCategories);
            final StringDecoder compId = new SimpleStringDecoder(() -> message.body.compId);


            @Override
            public Venue venue() {
                return message.body.venue;
            }

            @Override
            public StringDecoder compId() {
                return compId;
            }

            @Override
            public EnumerableSetDecoder<VenueCategory> venueCategories() {
                return venueCategories;
            }

            @Override
            public boolean enabled() {
                return message.body.enabled;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoVenueConfigDecoder() {
        throw new RuntimeException("No PojoTimerExpiryDecoder for you!");
    }
}
