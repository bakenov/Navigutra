package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.GeneralApamaEventFields;
import com.anz.axle.lg.adapter.apama.event.MarketDataIncrementalRefresh_MDEntry;
import com.anz.axle.lg.adapter.apama.event.MarketDataSnapshotFullRefresh_MDEntry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static com.anz.axle.lg.adapter.apama.decoder.FixNumericConstants.QUOTE_CONDITION;
import static com.anz.axle.lg.adapter.apama.decoder.FixNumericConstants.QUOTE_TYPE;
import static com.anz.axle.lg.adapter.apama.decoder.FixStringConstants.QUOTE_CONDITION_INDICATIVE;
import static com.anz.axle.lg.adapter.apama.decoder.FixStringConstants.QUOTE_TYPE_INDICATIVE;

public final class MdEntries {

    public static final BiPredicate<RequestKey, Event> BID_OR_ASK_MATCHING_ALL = (key, entry) -> isBidOrOffer(entry);

    public static int count(final RequestKey requestKey,
                            final List<? extends Event> mdEntries,
                            final int startIndex,
                            final BiPredicate<? super RequestKey, ? super Event> entryAcceptor) {
        int count = 0;
        for (int i = startIndex; i < mdEntries.size(); i++) {
            final Event mdEntry = mdEntries.get(i);
            if (entryAcceptor.test(requestKey, mdEntry)) {
                count++;
            }
        }
        return count;
    }

    public static String getNormalisedSymbolOrNull(final Iterable<? extends Event> mdEntries) {
        String symbol = null;
        for (final Event entry : mdEntries) {
            final String entrySymbol = getEntryNormalisedSymbol(entry);
            if (symbol == null) {
                symbol = entrySymbol;
            } else if (!symbol.equals(entrySymbol)) {
                return null;
            }
        }
        return symbol;
    }

    public static boolean isBidOrOffer(final Event mdEntry) {
        final EntryType entryTypeSide = MarketDataSnapshotFullRefresh_MDEntry.FIELD_MD_ENTRY_TYPE.getSide(mdEntry);
        return entryTypeSide == EntryType.BID || entryTypeSide == EntryType.OFFER;
    }

    public static boolean hasIndicative(final Iterable<? extends Event> mdEntries) {
        for (final Event mdEntry : mdEntries) {
            final Map<Long, String> extraParams = mdEntry.getField(MarketDataIncrementalRefresh_MDEntry.FIELD_EXTRA_PARAMS);
            if (QUOTE_CONDITION_INDICATIVE.equals(extraParams.get(QUOTE_CONDITION)) ||
                    QUOTE_TYPE_INDICATIVE.equals(extraParams.get(QUOTE_TYPE))) {
                return true;
            }
        }
        return false;
    }

    public static String getEntryNormalisedSymbol(final Event mdEntry) {
        final String entrySymbol = mdEntry.getField(GeneralApamaEventFields.FIELD_SYMBOL);
        return (entrySymbol != null) ? SymbolNormaliser.toSymbol6(entrySymbol) : null;
    }
}
