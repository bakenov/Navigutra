package com.anz.markets.efx.ngaro.sbe;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.ByteReader;

/**
 * Provides indexed read access to string bytes. Such methods are for instance found on SBE decoders for fixed length
 * strings.
 */
@FunctionalInterface
public interface FixedStringSource {
    byte getByte(int index);

    static FixedStringSource lazy(final Supplier<FixedStringSource> supplier) {
        return Lazy.fixedStringSource(supplier);
    }

    ByteReader<FixedStringSource> BYTE_READER = (src, idx) -> src.getByte(idx);
}
