# Usage exmaple :  ./fetch_all.sh 'find ~/axle -name " hs_err_pid*" -print'


hostList='daxa001z daxa018z daxa019z daxa003z daxa006z daxa009s daxa010z daxa021z daxa012z daxa013z daxa016z daxa035z daxa004z daxa031z daxa032z daxa036z auq4000s auq4016s auq4002s auq4003s auq4005s qaxb4100z qaxb4201z qaxb4300z qaxc4201z qaxs4201z'


#hostList='daxa014z'


startTime=`date +"%Y%m%d%H%M%S"`
parentDir=$startTime
mkdir $parentDir

for i in $hostList
  do
    echo --------------------------------------------------
    echo host: $i
    echo --------------------------------------------------
    fetchList=`ssh axle@${i} $1`
   
    outdir=${parentDir}/${i} 
    for f in $fetchList
      do
        mkdir ${outdir}
        scp -r axle@${i}:${f} ${outdir}
      done
  done

