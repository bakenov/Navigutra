package com.anz.markets.efx.fox.processor.validator;


public interface ParentOrderValidatorRepository {
    ParentOrderValidator    lookupByStrategyName(String strategyName);
}
