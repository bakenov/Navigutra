package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.mockito.InOrder;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.ebs.EventRequestKeyMatcher;
import com.anz.axle.lg.adapter.apama.ebs.EventToRequestKey;
import com.anz.axle.lg.adapter.apama.ebs.EventToTenor;
import com.anz.axle.lg.adapter.apama.ebs.EventToTranslatedSymbol;
import com.anz.axle.lg.adapter.apama.ebs.SettleTypeToTenor;
import com.anz.axle.lg.adapter.apama.event.EbsMarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.apama.event.MarketDataIncrementalRefresh_MDEntry;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link com.anz.axle.lg.adapter.apama.decoder.EbsMarketDataIncrementalRefreshDecoder}
 */
@RunWith(Parameterized.class)
public class EbsMarketDataIncrementalRefreshDecoderTest {
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormat.forPattern("yyyyMMdd-HH:mm:ss.SSS").withZoneUTC();
    private static final EventParser APAMA_EVENT_PARSER = new EventParser(
            MarketDataIncrementalRefresh_MDEntry.EVENT_TYPE,
            EbsMarketDataIncrementalRefresh.EVENT_TYPE);
    private static final int MAX_ENTRIES_USED_IN_TEST = 34;
    private static final int MD_ENCODERS_SIZE = MAX_ENTRIES_USED_IN_TEST;
    private static final long CURRENT_TIME = 34523453;

    private final DecoderTestMode mode;

    //mocks
    private String senderCompId = "GB:EBS";
    private String compId = "GB:lg-ebs";
    //mocks
    private VenueRequestKeyLookup requestKeyLookup;
    private PricingEncoderLookup pricingEncoderLookup;
    private MockitoPricingEncoder encoders;
    private PricingEncoderSupplier encoderSupplier;
    private LongSupplier messageIdSupplier;
    private InOrder inOrder;
    private PrecisionClock precisionClock;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    //under test
    private EbsMarketDataIncrementalRefreshDecoder ebsMarketDataIncrementalRefreshDecoder;

    public EbsMarketDataIncrementalRefreshDecoderTest(final DecoderTestMode mode) {
        this.mode = Objects.requireNonNull(mode);
    }

    @Parameterized.Parameters
    public static Collection<DecoderTestMode> testParameters() {
        return Arrays.asList(DecoderTestMode.values());
    }

    @Before
    public void beforeEach() {
        //initialise mocks
        encoders = new MockitoPricingEncoder();

        precisionClock = mock(PrecisionClock.class);
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);

        messageIdSupplier = mock(LongSupplier.class);
        when(messageIdSupplier.getAsLong()).thenReturn(10L);

        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.EBS);

        encoderSupplier = mock(PricingEncoderSupplier.class, RETURNS_MOCKS);
        when(encoderSupplier.incrementalRefresh()).thenReturn(encoders.incrementalEncoder);
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);

        final PricingEncoderSupplier modedEncoderSupplier = mode.encoderSupplier(encoderSupplier);

        pricingEncoderLookup = mock(PricingEncoderLookup.class);
        when(pricingEncoderLookup.lookup(any())).thenReturn(modedEncoderSupplier);

        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.incrementalEncoder,
                encoders.incrementalEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.incrementalBody.senderCompId(),
                encoders.incrementalBody.tradeDate(),
                encoders.incrementalBody.settlDate(),
                encoders.incrementalBody.referenceSpotDate(),
                encoders.incrementalBody.mdFlags(),
                encoders.incrementalEntries_next,
                encoders.incrementalEntries_body,

                encoders.incrementalHops,
                encoders.incrementalHops_next,
                encoders.incrementalHops_body,
                encoders.incrementalHops_body.hopCompId(),

                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotEntries_next,
                encoders.snapshotEntries_body,

                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),

                encoders.messageEncoder);


        final SettleTypeToTenor settleTypeToTenor = new SettleTypeToTenor();
        final EventToTenor entryEventToTenor = EventToTenor.forEntryEvent(settleTypeToTenor);
        final EventToTranslatedSymbol ebsEntryEventToTranslatedSymbol = EventToTranslatedSymbol.forEntryEvent(Collections.emptyMap(), Collections.emptyMap());
        final EventToRequestKey entryEventToRequestKey = EventToRequestKey.forEntryEvent((securityType, s) -> true, requestKeyLookup, ebsEntryEventToTranslatedSymbol, entryEventToTenor);
        final EventRequestKeyMatcher entryEventRequestKeyMatcher = EventRequestKeyMatcher.forEntryEvent(ebsEntryEventToTranslatedSymbol, entryEventToTenor);

        //under test
        ebsMarketDataIncrementalRefreshDecoder = new EbsMarketDataIncrementalRefreshDecoder(entryEventToRequestKey, entryEventRequestKeyMatcher, pricingEncoderLookup, precisionClock, senderCompId, compId, messageIdSupplier, sourceSequencer);
    }

    @Test
    public void shouldDecode_incrementalRefresh() throws Exception {


        // Receive update with new/replace/delete
        // note: MarketDataIncrementalRefresh_MDEntry(string MDUpdateAction {0=New,1=Upd,2=Del}, string MDEntryType {0=Bid,1=Offer,w=BestOffer,x=BestBid}, string MDEntryID, string Symbol, float MDEntryPx, float MDEntrySize)
        final String evtStr = "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2," +
                "[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/USD\",.7884,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.78845,6e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,1e+07,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"1\",\"\",\"AUD/USD\",.78855,1e+07,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"w\",\"\",\"AUD/USD\",.7884,0,\"\",{461:\"RCSXXX\",63:\"0\"})]," +
                "{},{\"35\":\"X\",\"52\":\"20150225-05:06:52.091\",\"20203\":\"1\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);
        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150225-05:06:52.091").getMillis());


        //when
        ebsMarketDataIncrementalRefreshDecoder.decode(evt);

        //then:
        verifyIncrementBodyFields(Venue.EBS, "AUDUSD", 4, expectedSendingTimeNanos);

        verifyEntry(UpdateAction.NEW, expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .7884, 2e+06);
        verifyEntry(UpdateAction.CHANGE, expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78845, 6e+06);
        verifyEntry(UpdateAction.CHANGE, expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .7885, 10e+06);
        verifyEntry(UpdateAction.DELETE, expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, .78855, 1e+07);
    }

    @Test
    public void shouldIgnore_WhenNonPriceDepthView() throws Exception {
        //given
        final String spreadViewTagValueStr = "1101";
        final String evtStr = "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\"," +
                spreadViewTagValueStr + ",[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NAN/INF\",1.22454,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})]," +
                "{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        ebsMarketDataIncrementalRefreshDecoder.decode(evt);

        //then:
        verifyZeroInteractions(encoders.pricingEncoders);
    }


    @Test
    public void shouldDecodeIntoEmptySnapshot_WhenNoMarketQuoteStatus() throws Exception {
        // The same test as the old translator test 'shouldClearBookOnNoMarketQuoteStatus'

        //given
        String evtStr = "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2," +
                "[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1000\",277:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1000\",277:\"1001\"})]," +
                "{},{\"35\":\"X\",\"52\":\"20150305-21:11:09.859\",\"20203\":\"1\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);
        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150305-21:11:09.859").getMillis());

        //when
        ebsMarketDataIncrementalRefreshDecoder.decode(evt);

        //then:
        verifySnapshotBodyFields(Venue.EBS, "NZDCAD", 0, expectedSendingTimeNanos);
    }

    @Test
    public void shouldDecode_MultipleCurrency() throws Exception {
        // Receive update with new/replace/delete
        // note: MarketDataIncrementalRefresh_MDEntry(string MDUpdateAction {0=New,1=Upd,2=Del}, string MDEntryType {0=Bid,1=Offer,w=BestOffer,x=BestBid}, string MDEntryID, string Symbol, float MDEntryPx, float MDEntrySize)
        final String evtStr = "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2," +
                "[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/USD\",1.0753,2e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                " com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/CAD\",0.9650,1e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                " com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/USD\",1.0754,3e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                " com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"EUR/USD\",1.0755,5e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                " com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"2\",\"0\",\"\",\"NZD/CAD\",0.9654,4e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                " com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/USD\",0.7654,5e+06,\"\",{461:\"RCSXXX\",63:\"0\"})," +
                "],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})";
        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150225-05:07:04.341").getMillis());
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        ebsMarketDataIncrementalRefreshDecoder.decode(evt);

        //then:
        verifyIncrementBodyFields(Venue.EBS, "EURUSD", 3, expectedSendingTimeNanos);
        verifyEntry(UpdateAction.NEW, expectedSendingTimeNanos, Venue.EBS, EntryType.BID, 1.0753, 2e+06);
        verifyEntry(UpdateAction.NEW, expectedSendingTimeNanos, Venue.EBS, EntryType.BID, 1.0754, 3e+06);
        verifyEntry(UpdateAction.CHANGE, expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, 1.0755, 5e+06);

        verifyIncrementBodyFields(Venue.EBS, "NZDCAD", 2, expectedSendingTimeNanos);
        verifyEntry(UpdateAction.NEW, expectedSendingTimeNanos, Venue.EBS, EntryType.OFFER, 0.9650, 1e+06);
        verifyEntry(UpdateAction.DELETE, expectedSendingTimeNanos, Venue.EBS, EntryType.BID, 0.9654, 4e+06);

        verifyIncrementBodyFields(Venue.EBS, "AUDUSD", 1, expectedSendingTimeNanos);
        verifyEntry(UpdateAction.NEW, expectedSendingTimeNanos, Venue.EBS, EntryType.BID, 0.7654, 5e+06);
    }

    @Test
    public void shouldDecodeIntoEmptySnapshots_MultipleCurrency_WhenNoDataAvailableQuoteCondition() throws Exception {
        // Receive update with new/replace/delete
        // note: MarketDataIncrementalRefresh_MDEntry(string MDUpdateAction {0=New,1=Upd,2=Del}, string MDEntryType {0=Bid,1=Offer,w=BestOffer,x=BestBid}, string MDEntryID, string Symbol, float MDEntryPx, float MDEntrySize)
        final String evtStr = "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2," +
                "[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/USD\",1.0753,2e+06,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1000\",277:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/USD\",0.7654,4e+06,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1000\",277:\"1001\"})],{},{\"35\":\"X\",\"52\":\"20150225-05:07:04.341\",\"20203\":\"1\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);
        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150225-05:07:04.341").getMillis());

        //when
        ebsMarketDataIncrementalRefreshDecoder.decode(evt);

        //then:
        verifySnapshotBodyFields(Venue.EBS, "EURUSD", 0, expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "AUDUSD", 0, expectedSendingTimeNanos);
    }

    @Test
    public void shouldDecodeIntoEmptySnapshots_MultipleCurrency_WhenNoDataQuoteStatus() throws Exception {
        // The same test as the old translator test 'shouldClearBookOnNoDataQuoteStatus'

        // Receive update with new/replace/delete
        // note: MarketDataIncrementalRefresh_MDEntry(string MDUpdateAction {0=New,1=Upd,2=Del}, string MDEntryType {0=Bid,1=Offer,w=BestOffer,x=BestBid}, string MDEntryID, string Symbol, float MDEntryPx, float MDEntrySize)
        String evtStr = "com.apama.fix.ebs.MarketDataIncrementalRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"\",2," +
                "[com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NZD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NZD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/HKD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/HKD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/HKD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/HKD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/SEK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/SEK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/NOK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/NOK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/SGD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/SGD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SGD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SGD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"CHF/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"CHF/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"CHF/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"CHF/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/NOK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NOK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/NOK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/NZD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/NZD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/AUD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/AUD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/ZAR\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/ZAR\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/ZAR\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/ZAR\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/DKK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/DKK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/DKK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/DKK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"NZD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"NZD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"NZD/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/SEK\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SEK\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/SEK\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/CHF\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CHF\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/CHF\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/GBP\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/GBP\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/GBP\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/GBP\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"EUR/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"EUR/AUD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/AUD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"EUR/AUD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/USD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/USD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/USD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/CNH\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/CNH\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CNH\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/CNH\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"GBP/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"GBP/CAD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CAD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"GBP/CAD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"USD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"USD/JPY\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/JPY\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"USD/JPY\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})," +
                "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"0\",\"\",\"AUD/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"1\",\"\",\"AUD/NZD\",0,0,\"\",{461:\"RCSXXX\",63:\"0\",276:\"1001\",277:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/NZD\",0,0,\"\",{5450:\"11\",461:\"RCSXXX\",63:\"0\",276:\"1001\"}),com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"0\",\"2\",\"\",\"AUD/NZD\",0,0,\"\",{5450:\"12\",461:\"RCSXXX\",63:\"0\",276:\"1001\"})]," +
                "{},{\"35\":\"X\",\"52\":\"20150305-21:11:09.859\",\"20203\":\"1\"})";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);
        final long expectedSendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_FORMAT.parseDateTime("20150305-21:11:09.859").getMillis());

        //when
        ebsMarketDataIncrementalRefreshDecoder.decode(evt);

        //then:
        verifySnapshotBodyFields(Venue.EBS, "NZDCAD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "EURNZD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "NZDUSD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "EURUSD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "EURCAD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "USDCHF", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "USDHKD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "EURSEK", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "USDNOK", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields(Venue.EBS, "USDSGD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "CHFJPY", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "AUDCAD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "EURNOK", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "AUDCHF", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "GBPCHF", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "GBPNZD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "GBPJPY", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "GBPAUD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "AUDUSD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "USDZAR", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "EURDKK", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "AUDJPY", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "NZDJPY", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "USDSEK", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "EURCHF", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "EURGBP", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "EURJPY", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "EURAUD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "GBPUSD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "USDCAD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "USDCNH", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "GBPCAD", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "USDJPY", 0,expectedSendingTimeNanos);
        verifySnapshotBodyFields( Venue.EBS, "AUDNZD", 0,expectedSendingTimeNanos);
    }

//    public static int eq(int value) {
//        return reportMatcher(new Equals(Integer.valueOf(value))).returnZero();
//    }

    private void verifyIncrementBodyFields(final Venue venue,
                                           final String symbol,
                                           final int entriesCount,
                                           final long sendingTimeNanos) {
        inOrder.verify(encoders.incrementalBody).sendingTime(sendingTimeNanos);
        inOrder.verify(encoders.incrementalBody).instrumentId(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        inOrder.verify(encoders.incrementalBody).marketId(venue);
        if (entriesCount > 0) {
            inOrder.verify(encoders.incrementalBody).entriesStart(entriesCount * (mode == DecoderTestMode.SBE ? 1 : 2));
        } else {
            inOrder.verify(encoders.incrementalBody).entriesEmpty();
        }
    }

    private void verifySnapshotBodyFields(final Venue venue,
                                           final String symbol,
                                           final int entriesCount,
                                           final long sendingTimeNanos) {
        inOrder.verify(encoders.snapshotBody).sendingTime(sendingTimeNanos);
        inOrder.verify(encoders.snapshotBody).instrumentId(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        inOrder.verify(encoders.snapshotBody).marketId(venue);
        if (entriesCount > 0) {
            inOrder.verify(encoders.snapshotBody).entriesStart(entriesCount * (mode == DecoderTestMode.SBE ? 1 : 2));
        }
    }

    private void verifyEntry(final UpdateAction updateAction,
                             final long transactTimeNanos,
                             final Venue venue,
                             final EntryType side,
                             final double price,
                             final double quantity) {

        inOrder.verify(encoders.incrementalEntries_body).transactTime(transactTimeNanos);
        inOrder.verify(encoders.incrementalEntries_body).mdUpdateAction(updateAction);
        inOrder.verify(encoders.incrementalEntries_body).mdMkt(venue);
        inOrder.verify(encoders.incrementalEntries_body).mdEntryType(side);
        inOrder.verify(encoders.incrementalEntries_body).mdEntryPx(price);
        inOrder.verify(encoders.incrementalEntries_body).mdEntrySize(quantity);
        inOrder.verify(encoders.incrementalEntries_body).minQty(0);
    }
}