package com.anz.axle.adapters.ndf2trep.snapshot;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKeyLookup;

public final class UpstreamIncrementalRefreshHandlerRouter implements IncrementalRefreshHandler {

    private final SnapshotterDecoderLookup snapshotterDecoderLookup;
    private final RequestKeyLookup requestKeyLookup;

    private IncrementalRefreshHandler handlerDelegate;
    private MessageForwarder messageForwarder;
    private Consumer<StringBuilder> messageLogger;

    public UpstreamIncrementalRefreshHandlerRouter(final SnapshotterDecoderLookup snapshotterDecoderLookup, final RequestKeyLookup requestKeyLookup) {
        this.snapshotterDecoderLookup = Objects.requireNonNull(snapshotterDecoderLookup);
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        handlerDelegate = null;
        messageForwarder = null;
        messageLogger = null;
    }

    @Override
    public void messageForwarder(final MessageForwarder messageForwarder) {
        this.messageForwarder = messageForwarder;
    }

    @Override
    public void messageLogger(final Consumer<StringBuilder> messageLogger) {
        this.messageLogger = messageLogger;
    }

    @Override
    public void onBody(final Body body) {
        final RequestKey requestKey = requestKeyLookup.lookup(body.marketId(), body.instrumentId());
        final SnapshotterDecoderSupplier supplier = snapshotterDecoderLookup.lookup(requestKey);

        handlerDelegate = supplier.upstreamDecoderConnector().incrementalRefresh();
        handlerDelegate.onMessageStart(0, 0);
        handlerDelegate.messageForwarder(messageForwarder);
        handlerDelegate.messageLogger(messageLogger);
        handlerDelegate.onBody(body);
    }

    @Override
    public void onMdEntriesStart(final int mdEntriesCount) {
        handlerDelegate.onMdEntriesStart(mdEntriesCount);
    }

    @Override
    public void onMdEntries_Body(final MdEntries.Body entry, final int mdEntriesIndex, final int mdEntriesCount) {
        handlerDelegate.onMdEntries_Body(entry, mdEntriesIndex, mdEntriesCount);
    }

    @Override
    public void onMdEntriesComplete(final int entryCount) {
        handlerDelegate.onMdEntriesComplete(entryCount);
    }

    @Override
    public void onHopsComplete(final int hopsCount) {
        handlerDelegate.onHopsComplete(hopsCount);
    }

    @Override
    public void onHopsStart(final int hopsCount) {
        handlerDelegate.onHopsStart(hopsCount);
    }

    @Override
    public void onHops_Body(final Hops.Handler.Body hop, final int hopsIndex, final int hopsCount) {
        handlerDelegate.onHops_Body(hop, hopsIndex, hopsCount);
    }

    @Override
    public void onMessageComplete() {

        handlerDelegate.onMessageComplete();
        handlerDelegate = null;
        messageForwarder = null;
        messageLogger = null;
    }
}
