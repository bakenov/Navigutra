package com.anz.axle.direct.performance;

import com.anz.axle.direct.performance.metrics.BasicStats;
import com.anz.axle.direct.performance.metrics.Count;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.axle.direct.performance.metrics.Rates;

import java.util.Collection;

public interface MetricReporter {
    void beginReports();

    void appendCounts(Collection<Count> counters);

    void appendBasicStats(Collection<BasicStats> basicStatsList);

    void appendHistograms(Collection<Percentiles> samplings);

    void appendRates(Collection<Rates> ratesList);

    void endReports();
}
