package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@SuppressWarnings("CPD-START")
@Deprecated
public class ClientPriceConfigImpl implements ProphetMarshallable {

    private Region region;
    private Market market;
    private Instrument instrument;
    private BenchmarkCalculationType benchmarkCalculationType;
    private double overrideMinimumPriceDeltaFractionOfMid;
    private double minimumPriceDeltaFractionOfSpread;
    private double tooTightThresholdAsProportionOfBaseSpread;
    private double widenedSpreadAsProportionOfBenchmarkSpread;

    private long noActivityHeartbeatFrequencyMs;
    private long limit;

    private long timePeriod; // milliseconds
    private long overrideLimit;
    private long overrideTimePeriod;
    private long startStopTimePeriodMS;
    private String benchmarkSpreadMarkets;
    private transient List<Market> benchmarkSpreadMarketAsEnumList;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public ClientPriceConfigImpl() {
    }


    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        FieldReflectionBytesMarshallable.INSTANCE.read(in, this);
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        FieldReflectionBytesMarshallable.INSTANCE.write(this, out);
    }

    @Override
    public String toString() {
        return "ClientPriceConfigImpl{" +
                "benchmarkCalculationType=" + benchmarkCalculationType +
                ", region=" + region +
                ", market=" + market +
                ", instrument=" + instrument +
                ", overrideMinimumPriceDeltaFractionOfMid=" + overrideMinimumPriceDeltaFractionOfMid +
                ", minimumPriceDeltaFractionOfSpread=" + minimumPriceDeltaFractionOfSpread +
                ", tooTightThresholdAsProportionOfBaseSpread=" + tooTightThresholdAsProportionOfBaseSpread +
                ", widenedSpreadAsProportionOfBenchmarkSpread=" + widenedSpreadAsProportionOfBenchmarkSpread +
                ", noActivityHeartbeatFrequencyMs=" + noActivityHeartbeatFrequencyMs +
                ", limit=" + limit +
                ", timePeriod=" + timePeriod +
                ", overrideLimit=" + overrideLimit +
                ", overrideTimePeriod=" + overrideTimePeriod +
                ", benchmarkSpreadMarkets='" + benchmarkSpreadMarketAsEnumList + '\'' +
                '}';
    }
}