package com.anz.markets.prophet.config.app;

import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.chronicle.ChronicleLookupTableReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.ConsumerCrossConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.business.ConfigReader;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.event.EndEventAppenderReader;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;
import java.util.EnumMap;
import java.util.function.Consumer;

@Configuration
@Import({BusinessConfig.class, ConsumerCrossConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class CoreCrossConfig extends JmxConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(CoreCrossConfig.class);

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.core:9}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    // chronicle in & out
    @Bean
    public ProphetPersister outboundChroniclePersister(
            @Value("${chronicle.cross.out.path:./chronicle.cross.out}") final String outboundChroniclePath,
            @Value("${chronicle.open.mode:APPEND}") final LegacyChroniclePersister.OpenMode openMode,
            @Value("${core.instance}") final byte crossInstance,
            @Value("${default.active.core.instance}") final int defaultActiveCrossInstance,
            @Value("${chronicle.out.activation:YES}") final ActivationAware activationMode) throws IOException {

        Context.instance(crossInstance);
        Context.stage(Stage.CROSS);

        return ChroniclePersisterFactory.createCorePersister(outboundChroniclePath,
                openMode, activationMode, crossInstance == defaultActiveCrossInstance,
                Predicates.alwaysTrue(), RingBuffer.NO_RING);
    }

    // tell Main to run this in main thread
    @Bean(name = Main.RUNNER_BEAN)
    public ProphetReader chronicleReader(
            @Value("#{'${chronicle.cross.in.path:./chronicle.out.conflated,./chronicle.out}'.split(',')}") final String[] chronicleInPaths,
            final ChronicleObjectReader configReader,
            final ChronicleObjectReader marketDataSnapshotReader,
            final ChronicleObjectReader oneSecondReader,
            final ChronicleObjectReader forwardPointReader,
            final ChronicleObjectReader spotDateReader,
            final ChronicleObjectReader clientPriceReader,
            final EndEventAppenderReader endEventAppenderReader,
            final ChronicleObjectReader tradingTimeZoneChimeReader,
            @Value("${chronicle.in.start.index}") final int startIndex,
            final ChronicleReaderGeneric<Activate> activationReader) throws IOException {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.ACTIVATE, activationReader);
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, marketDataSnapshotReader);
        map.put(MessageType.CONFIGURATION, configReader);
        map.put(MessageType.SPOT_DATE, spotDateReader);
        map.put(MessageType.FORWARD_POINT, forwardPointReader);
        map.put(MessageType.ONE_SECOND, oneSecondReader);
        map.put(MessageType.CLIENT_PRICE, clientPriceReader);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneChimeReader);
        map.put(MessageType.END_EVENT, endEventAppenderReader);

        return ChronicleReaderFactory.createCoreReader(chronicleInPaths, startIndex, true, endEventAppenderReader, RingBuffer.NO_RING, map);

    }

    @Bean
    public EndEventAppenderReader endEventAppenderReader(final ProphetPersister prophetPersister) {
        return new EndEventAppenderReader(prophetPersister.sink(MessageType.END_EVENT));
    }

    // chronicle readers. These deserialise their types from the inbound chronicle and pass on to their consumers
    @Bean
    public ChronicleReaderGeneric<Activate> activationReader(
            @Qualifier("activateConsumers") final Consumer<Activate> activateConsumers) {
        return new ChronicleReaderGeneric<>(new Activate(), activateConsumers);
    }

    @Bean
    public ChronicleObjectReader marketDataSnapshotReader(final Consumer<MarketDataSnapshot> midRateConsumer) {
        final Consumer<FilteredMarketDataSnapshot> consumer = fmds -> {
            if (fmds.getMarket() == Market.WSP_U) {
                midRateConsumer.accept(fmds);
            }
        };
        return new ChronicleLookupTableReader<>(FilteredMarketDataSnapshotImpl::forAggBook, consumer,
                FilteredMarketDataSnapshot::getInstrument,
                FilteredMarketDataSnapshot::getMarket,
                Instrument.class, Market.class);
    }

    @Bean
    public ConfigReader configReader(final Consumer<ConfigurationData> configurationDataConsumer) {
        return new ConfigReader(new NotifierDefault<>(configurationDataConsumer));
    }

    @Bean
    public ChronicleReaderGeneric spotDateReader(final Consumer<SpotDate> spotDateConsumer) {
        return new ChronicleReaderGeneric(new SpotDateImpl(), spotDateConsumer);
    }

    @Bean
    public ChronicleReaderGeneric forwardPointReader(final Consumer<ForwardPoint> forwardPointConsumer) {
        return new ChronicleReaderGeneric(new ForwardPointImpl(), forwardPointConsumer);
    }

    @Bean
    public ChronicleReaderGeneric clientPriceReader(final Consumer<ClientPrice> clientPriceConsumer) {
        return new ChronicleReaderGeneric(new ClientPriceImpl(), clientPriceConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> oneSecondReader(final Consumer<OneSecond> oneSecondConsumer) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, oneSecondConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneChimeReader(final Consumer<TradingTimeZoneChime> tradingTimeZoneManager) {
        return new ChronicleReaderGeneric<>(TradingTimeZoneChime.INSTANCE, tradingTimeZoneManager);
    }

    // chronicle persister consumers AKA sinks. These are the very last things in the consumer chain, and write to out chronicle

    @Bean
    public Consumer<Activate> activateSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ACTIVATE);
    }

    @Bean
    public Consumer<EndEvent> endEventSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.END_EVENT);
    }

}
