package com.anz.axle.lg.adapter.anz.quickfix;

import java.util.Objects;

import quickfix.Message;
import quickfix.SessionID;
import quickfix.field.Password;

import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.ToAdminHandler;

public final class LogonToAdminHandler implements ToAdminHandler {
    private final SessionID pricingSessionId;
    private final String pricingPassword;

    private final SessionID tradingSessionId;
    private final String tradingPassword;

    public LogonToAdminHandler(final SessionID pricingSessionId, final String pricingPassword,
                               final SessionID tradingSessionId, final String tradingPassword) {
        this.pricingSessionId = Objects.requireNonNull(pricingSessionId);
        this.pricingPassword = Objects.requireNonNull(pricingPassword);
        this.tradingSessionId = Objects.requireNonNull(tradingSessionId);
        this.tradingPassword = Objects.requireNonNull(tradingPassword);
    }

    @Override
    public void handle(final MessageType messageType, final Message message, final SessionID sessionId) {
        if (MessageType.LOGON.equals(messageType)) {
            if (pricingSessionId.equals(sessionId)) {
                message.setString(Password.FIELD, pricingPassword);
            }
            else if (tradingSessionId.equals(sessionId)) {
                message.setString(Password.FIELD, tradingPassword);
            } else {
                throw new UnsupportedOperationException("Unknown sessionId " + sessionId);
            }
        }
    }
}
