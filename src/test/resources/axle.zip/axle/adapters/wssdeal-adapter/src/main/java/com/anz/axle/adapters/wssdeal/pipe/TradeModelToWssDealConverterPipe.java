package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import anz.markets.messaging.pipes.intf.AbstractPipe;
import anz.markets.messaging.types.PDMessage;

import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.wss.domain.WssDeal;
import org.apache.log4j.Logger;

public class TradeModelToWssDealConverterPipe extends AbstractPipe<TradeMessageWrapperType,WssDeal> {
    private static final Logger LOG = Logger.getLogger(TradeModelToWssDealConverterPipe.class);

    private  Builder<WssDeal, TradeMessageWrapperType> builder;

    TradeModelToWssDealConverterPipe(Builder<WssDeal, TradeMessageWrapperType> builder){
        this.builder = builder;
    }

    @Override
    public boolean onMessage(PDMessage<TradeMessageWrapperType> message) {
        try{
            final WssDeal wssDeal = builder.build(message.getContent());
            return getSink().onMessage(new PDMessage<WssDeal>(message.getId(),wssDeal));
        }catch (BuilderException be){
            LOG.error(String.format("Not able to convert object %s", message.getContent()), be);
        }
        return false;
    }
}
