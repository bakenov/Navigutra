package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.efx.ngaro.math.Epsilon;
import com.anz.markets.efx.ngaro.math.DoubleTools;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import static com.anz.markets.prophet.util.DoubleUtil.toNonNaN;
import static com.anz.markets.prophet.util.DoubleUtil.toNonNegativeZero;

public class RiskPathMatcher extends BaseMatcher<RiskPath> {

    private final RiskPath expected;
    private StringBuilder message;

    public RiskPathMatcher(final RiskPath expected) {
        this.expected = expected;
    }

    static double valueQty(final double v) {
        return DoubleTools.round(toNonNegativeZero(toNonNaN(v)), 2);
    }

    static double valuePrice(final double v) {
        return DoubleTools.round(toNonNegativeZero(toNonNaN(v)), 2);
    }

    private void checkValue(final EqualsBuilder builder, Object actual, Object expected, String name) {
        builder.append(expected, actual);
        if (!expected.equals(actual)) {
            message.append(String.format(", [%s expected[%s] actual[%s]]", name, actual, expected));
        }
    }

    private void checkQty(final EqualsBuilder builder, double actual, double expected, String name) {
        builder.append(valueQty(expected), valueQty(actual));
        if (!Epsilon.EPS_1eNegative6.equalsEpsilon(valueQty(expected), valueQty(actual))) {
            message.append(String.format(", [%s expected[%s] actual[%s]]", name, actual, expected));
        }
    }

    private void checkPrice(final EqualsBuilder builder, double actual, double expected, String name) {
        builder.append(valuePrice(expected), valuePrice(actual));
        if (!Epsilon.EPS_1eNegative6.equalsEpsilon(valuePrice(expected), valuePrice(actual))) {
            message.append(String.format(", [%s expected[%s] actual[%s]]", name, actual, expected));
        }
    }

    @Override
    public boolean matches(Object o) {
        final RiskPath riskPath = (RiskPath) o;
        message = new StringBuilder();
        EqualsBuilder builder = new EqualsBuilder();
        checkValue(builder, expected.getTradeId().toString(), riskPath.getTradeId().toString(), "tradeId");
        checkValue(builder, expected.getOrderId().toString(), riskPath.getOrderId().toString(), "orderId");
        checkValue(builder, expected.getCounterparty().toString(), riskPath.getCounterparty().toString(), "counterparty");
        checkValue(builder, expected.getLastOffsetTradeId().toString(), riskPath.getLastOffsetTradeId().toString(), "lastOffsetTradeId");
        checkValue(builder, expected.getTradingTimeZone(), riskPath.getTradingTimeZone(), "tradingTimeZone");
        checkValue(builder, expected.getCurrency(), riskPath.getCurrency(), "currency");
        checkQty(builder, expected.getStartPositionInNotional(), riskPath.getStartPositionInNotional(), "StartPositionInNotional");
        checkQty(builder, expected.getStartPositionInSystemBase(), riskPath.getStartPositionInSystemBase(), "StartPositionInSystemBase");
        checkValue(builder, expected.getOpenTimeInNanos(), riskPath.getOpenTimeInNanos(), "openTimeInNanos");
        checkValue(builder, expected.getCloseTimeInNanos(), riskPath.getCloseTimeInNanos(), "closeTimeInNanos");
        checkValue(builder, expected.getFullLifeInMillis(), riskPath.getFullLifeInMillis(), "fullLifeInMillis");
        checkPrice(builder, expected.getBaseRate(), riskPath.getBaseRate(), "baseRate");
        checkPrice(builder, expected.getMtmRate(), riskPath.getMtmRate(), "mtmRate");
        checkValue(builder, expected.isRiskIncreasing(), riskPath.isRiskIncreasing(), "isRiskIncreasing");
        checkQty(builder, expected.getRiskIncreasingRatio(), riskPath.getRiskIncreasingRatio(), "riskIncreasingRatio");
        checkValue(builder, expected.getStatus(), riskPath.getStatus(), "status");
        checkValue(builder, expected.getTradeType(), riskPath.getTradeType(), "tradeType");
        checkValue(builder, expected.getInstrument().toString(), riskPath.getInstrument().toString(), "instrument");
        checkQty(builder, expected.getQty(), riskPath.getQty(), "qty");
        checkPrice(builder, expected.getPrice(), riskPath.getPrice(), "price");
        checkQty(builder, expected.getBaseQty(), riskPath.getBaseQty(), "baseQty");
        checkValue(builder, expected.getCounterQty(), riskPath.getCounterQty(), "counterQty");
        checkValue(builder, expected.getDirection(), riskPath.getDirection(), "direction");
        checkValue(builder, expected.getSide(), riskPath.getSide(), "side");
        checkValue(builder, expected.getMarket(), riskPath.getMarket(), "market");
        checkValue(builder, expected.getParty(), riskPath.getParty(), "party");
        checkQty(builder, expected.getProfitAndLoss(), riskPath.getProfitAndLoss(), "profitAndLoss");
        checkQty(builder, expected.getTradeProfitAndLoss(), riskPath.getTradeProfitAndLoss(), "tradeProfitAndLoss");
        checkQty(builder, expected.getPositionInNotional(), riskPath.getPositionInNotional(), "positionInNotional");
        checkQty(builder, expected.getPositionInSystemBase(), riskPath.getPositionInSystemBase(), "positionInSystemBase");
        checkQty(builder, expected.getRiskAdjustment(), riskPath.getRiskAdjustment(), "riskAdjustment");
        checkQty(builder, expected.getMtmRateAtInception(), riskPath.getMtmRateAtInception(), "mtmRateAtInception");
        checkQty(builder, expected.getInceptionPnl(), riskPath.getInceptionPnl(), "inceptionPnl");
        checkQty(builder, expected.getHoldingPnl(), riskPath.getHoldingPnl(), "holdingPnl");
        checkQty(builder, expected.getMtmPnl(), riskPath.getMtmPnl(), "mtmPnl");
        return builder.isEquals();
    }


    @Override
    public void describeTo(Description description) {
        description.appendValue(expected);
    }

    @Override
    public void describeMismatch(final Object item, final Description description) {
        description.appendValue(item).appendText(message.toString());
    }

}
