package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.VolatilityType;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.features.AdaptiveSkewFeatureSpecs;
import com.anz.markets.prophet.pricer.pfp.features.SkewExperimentFeature;
import com.anz.markets.prophet.pricer.pfp.features.SkewExperimentFeatureSpecs;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1443})
public class Skew_Experiments_Test extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Double activeUSD = 60_000.0;
    private SkewExperimentFeatureSpecs skewExperimentsSpecs = SkewExperimentFeatureSpecs.INSTANCE;
    private PriceFormationPipelineConfig defaultConfig = PriceFormationPipelineConfig.create(skewExperimentsSpecs.NAME,
            Market.ANY,
            Instrument.ANY,
            TradingTimeZone.GLOBAL,
            Region.ANY,
            skewExperimentsSpecs.PARAM_PRE_CONDITION_PERIOD_MS, 0L,
            skewExperimentsSpecs.PARAM_PRE_CONDITION_VOL, Double.NaN,
            skewExperimentsSpecs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
            skewExperimentsSpecs.PARAM_PRE_CONDITION_POS_USD, Double.NaN,
            skewExperimentsSpecs.PARAM_PRE_CONDITION_VAR, Double.NaN,
            skewExperimentsSpecs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, Double.NaN,
            skewExperimentsSpecs.PARAM_TERMINATE_POS_USD, Double.NaN,
            skewExperimentsSpecs.PARAM_TERMINATE_VAR, Double.NaN,
            skewExperimentsSpecs.PARAM_MIN_TIME_UNIT_MS, 0L,
            skewExperimentsSpecs.PARAM_MAX_TIME_UNIT_MS, 0L,
            skewExperimentsSpecs.PARAM_MAX_SKEW, Double.NaN,
            skewExperimentsSpecs.PARAM_SKEW_SIGNATURES, "",
            skewExperimentsSpecs.PARAM_COOL_OFF_PERIOD_MS, 0L);

    private AdaptiveSkewFeatureSpecs adaptiveSkewSpecs = AdaptiveSkewFeatureSpecs.INSTANCE;
    private PriceFormationPipelineConfig adaptiveSkewConfig = PriceFormationPipelineConfig.create(adaptiveSkewSpecs.NAME,
            Market.ANY,
            Instrument.ANY,
            TradingTimeZone.GLOBAL,
            Region.ANY,
            adaptiveSkewSpecs.PARAM_ACTIVE_USD, Double.NaN,
            adaptiveSkewSpecs.PARAM_MAX_SKEW_POSITION_USD, Double.NaN,
            adaptiveSkewSpecs.PARAM_MIN_SKEW_FACTOR, Double.NaN,
            adaptiveSkewSpecs.PARAM_HIT_FRACTION, Double.NaN,
            adaptiveSkewSpecs.PARAM_HIT_STEP_FRACTION, Double.NaN,
            adaptiveSkewSpecs.PARAM_RR_INTERVAL_MS, 0L,
            adaptiveSkewSpecs.PARAM_RR_TARGET, Double.NaN,
            adaptiveSkewSpecs.PARAM_SKEW_STEP_PIPS, Double.NaN,
            adaptiveSkewSpecs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 0L,
            adaptiveSkewSpecs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 0L,
            adaptiveSkewSpecs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
            adaptiveSkewSpecs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L
    );

    private ConfigurationDataDefault setUpConfiguration() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig2 = new ArrayList<>();

        // set up AdaptiveSkew but set activeUSD high such that it is not active and skew will be 0(and linear skew not active)
        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(adaptiveSkewSpecs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                adaptiveSkewSpecs.PARAM_ACTIVE_USD, activeUSD + 200_000d,
                adaptiveSkewSpecs.PARAM_MAX_SKEW_POSITION_USD, 7_500_000d,
                adaptiveSkewSpecs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                adaptiveSkewSpecs.PARAM_HIT_FRACTION, 0.5d,
                adaptiveSkewSpecs.PARAM_HIT_STEP_FRACTION, 0.35d,
                adaptiveSkewSpecs.PARAM_RR_INTERVAL_MS, 2_000L,
                adaptiveSkewSpecs.PARAM_RR_TARGET, 0.9d,
                adaptiveSkewSpecs.PARAM_SKEW_STEP_PIPS, 0.001d,
                adaptiveSkewSpecs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 100L,
                adaptiveSkewSpecs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 200L,
                adaptiveSkewSpecs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                adaptiveSkewSpecs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(adaptiveSkewSpecs.NAME,
                Market.WSP_A,
                Instrument.USDJPY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                adaptiveSkewSpecs.PARAM_ACTIVE_USD, activeUSD + 200_000d,
                adaptiveSkewSpecs.PARAM_MAX_SKEW_POSITION_USD, 7_500_000d,
                adaptiveSkewSpecs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                adaptiveSkewSpecs.PARAM_HIT_FRACTION, 0.5d,
                adaptiveSkewSpecs.PARAM_HIT_STEP_FRACTION, 0.35d,
                adaptiveSkewSpecs.PARAM_RR_INTERVAL_MS, 2_000L,
                adaptiveSkewSpecs.PARAM_RR_TARGET, 0.9d,
                adaptiveSkewSpecs.PARAM_SKEW_STEP_PIPS, 0.001d,
                adaptiveSkewSpecs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 100L,
                adaptiveSkewSpecs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 200L,
                adaptiveSkewSpecs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                adaptiveSkewSpecs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig.add(defaultConfig);
        priceFormationPipelineConfig2.add(adaptiveSkewConfig);

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setRealisedVolatilityConfigs(Arrays.asList(
                        new RealisedVolatilityConfig(FactorWindow.CAT_A, 5, 1000,1000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true)
                ))
                .setClientSpreadConfigs(Arrays.asList(
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0)
                ));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(skewExperimentsSpecs.NAME, priceFormationPipelineConfig);
        configuration.getPriceFormationPipelineConfigs().replaceFeature(adaptiveSkewSpecs.NAME, priceFormationPipelineConfig2);
        return configuration;
    }

    @Test
    public void preconditionVarNotMet() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 15d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 312d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5d,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 150d,
                specs.PARAM_MIN_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.-.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 4000L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_000_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-59_999.3));
            assertThat(Math.abs(op.getGradientPositionInSystemBase()) <= activeUSD, is(true));

            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue(), is(312.71207070972156));
        }
        when:
        // since Var is ABOVE PRE_CONDITION_VAR(312), do not skew
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(101);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
        }
    }

    @Test
    public void preConditionPosUSDNotMet() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 15d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 312d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5d,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.-.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 4000L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_001, 0.79999));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_000_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-60_000.4));
            assertThat(Math.abs(op.getGradientPositionInSystemBase()) > activeUSD, is(true));
        }
        when:
        // since opPos(USD) is ABOVE PRE_CONDITION_POS_USD(60_000), do not skew
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(101);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
        }
    }

    @RestartBeforeTest(reason="clear vol state)")
    @Test
    public void preconditionVolNotMet() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 0.59d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5d,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.-.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 4000L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // since Vol is ABOVE PRE_CONDITION_VOL(0.59), do not skew
        {
            RealisedVolatility vol = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(vol.volatility(), isRoundedTo(0.592));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
        }
    }

    @Test
    public void preconditionPeriodNotMet() {
        long preConditionPeriodMS = 100L;

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, preConditionPeriodMS,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.-.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 4000L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(preConditionPeriodMS);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // since PRE_CONDITION_PERIOD_MS(100) has not elapsed, do not skew
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
        }
    }

    @Test
    public void preconditionSpreadNotMet() {
        double preConditionMinSpreadDP = 11;

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, preConditionMinSpreadDP,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_TIME_UNIT_MS, 1000L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.-.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 4000L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // since spread is below PRE_CONDITION_MIN_SPREAD_DP(11) i.e 1.1p, do not skew
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getOverallSpreadInPips() < preConditionMinSpreadDP, is(true));
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
        }
    }

    @RestartBeforeTest(reason = "reset state")
    @Test
    public void preconditionsMetPositiveSkew() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.^.-",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "+.^.-"
        // i.e add 1 deci-pip of skew, wait one timeUnit(randomised between min/maxTimeUnit), skew to max, wait one timeUnit, remove 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // Add 1 deci-pip(0.1p) from current skew(0.0p)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79990));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.1));
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+300ms
        // one timeUnit(200ms) NOT elapsed. Skew remains at 0.1p
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(199L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80000));
        }
        when:
        // t+301ms
        // one timeUnit(200ms) elapsed since t+101ms.
        // skew to max skew: maxSkew(0.5) * spread(1pip)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.80035));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.5));
            assertThat(ftl.data[1].sx.toString(), is("R")); // running
        }
        when:
        // t+501ms
        // one timeUnit(200ms) elapsed since t+301ms.
        // Remove 1 deci-pip(0.1p) from current skew(0.5pip)
        // USDJPY Triggers AUD/USD
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(200L);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 80.505, 0.05));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80034));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.4));
            assertThat(ftl.data[1].sx.toString(), is("E")); // end
        }
        and:
        {
            coolOffPeriod();
        }
    }

    // a new skew experiment cannot commence until after a pause period of COOL_OFF_PERIOD_MS(300ms)
    // a new skew experiment can only be triggered by the actual instrument marketdata
    public void coolOffPeriod() {
        when:
        // t+299ms
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(299L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80010));
        }
        when:
        // t+301ms
        // new skew experiment can begin.
        // AUDUSD skew experiment is NOT triggered by USDJPY marketdata
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(2L);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.05));
        }
        then:
        {
            prophet.notExpect(WholesaleBookFactors.class, isWholesaleBookFactors(indirectPair));
        }
        when:
        // new skew experiment. This time skew sign is -ve
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80020, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80019));
        }
    }

    @Test
    // Note: skew sign is randomly determined.
    // When whole class is run, skew in this test is determined as -ve. When run individually, skew is +ve
    public void preconditionsMetNegativeSkew() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.-.+",
                specs.PARAM_COOL_OFF_PERIOD_MS, 200L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "^.-.+".
        // i.e skew to max, wait one timeUnit(randomised between min/maxTimeUnit), remove 1 deci-pip of skew, wait one timeUnit, add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, 50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        // skew to max skew: maxSkew(0.5) * spread(1pip)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.80005));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.5));
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+300ms
        // one timeUnit(200ms) NOT elapsed. Skew remains at maxSkew(0.5p)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(199L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79994));
        }
        when:
        // t+301ms
        // one timeUnit(200ms) elapsed since t+101ms.
        // Remove 1 deci-pip(0.1p) from current skew(0.5pip)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.80026));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.4));
            assertThat(ftl.data[1].sx.toString(), is("R")); // running
        }
        when:
        // t+501ms
        // one timeUnit(200ms) elapsed since t+301ms.
        // Add 1 deci-pip(0.1p) from current skew(0.4pip)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(200L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80000, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79995));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.5));
            assertThat(ftl.data[1].sx.toString(), is("E")); // end
        }
    }

    @RestartBeforeTest(reason="clear states")
    @Test
    public void terminateEarlyOnVAR() {
        double terminateOnVar = 312d;
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, terminateOnVar,
                specs.PARAM_MIN_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.^.-",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "+.^.-".
        // i.e add 1 deci-pip of skew, wait one timeUnit(randomised between min/maxTimeUnit), skew to max, wait one timeUnit, remove 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // Add 1 deci-pip(0.1p) from current skew(0.0p)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79990));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.1));
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+301ms
        // one timeUnit(200ms) elapsed since t+101ms.
        // skew to max skew: maxSkew(0.5) * spread(1pip)
        // However VAR is above TERMINATE_VAR(312) -> EXIT skew experiment
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(200L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            ValueAtRisk var = prophet.expect(ValueAtRisk.class, atLeast(1)).getLast();
            assertThat(var.getValue() > terminateOnVar, is(true));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.80030));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.data[1].sx.toString(), is("V")); // terminated by VaR
        }
        and:
        {
            coolOffPeriod();
        }
    }

    @Test
    // Note: skew sign is randomly determined.
    // When whole class is run, skew in this test is determined as -ve. When run individually, skew is +ve
    public void terminateEarlyOnPosition() {
        double terminatePosUSD = activeUSD + 100_000d;

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, terminatePosUSD,
                specs.PARAM_TERMINATE_VAR, 10_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_TIME_UNIT_MS, 200L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.^.-",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "^.-.+".
        // i.e add 1 deci-pip of skew, wait one timeUnit(randomised between min/maxTimeUnit), skew to max, wait one timeUnit, remove 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // Add 1 deci-pip(0.1p) from current skew(0.0p)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79988));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.1));
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+301ms
        // one timeUnit(200ms) elapsed since t+101ms.
        // skew to max skew: maxSkew(0.5) * spread(1pip)
        // However Position is above TERMINATE_POS -> EXIT skew experiment
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(200L);
            prophet.receive(tdd.client_trade_001(indirectPair, -84_000, 0.79999));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_000_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-160_777.9));
            assertThat(Math.abs(op.getGradientPositionInSystemBase()) > terminatePosUSD, is(true));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.data[1].sx.toString(), is("P")); // terminated by Position
        }
    }

    @Test
    public void skewMustMaintainPositiveSign() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "-.+",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "-.+".
        // i.e remove 1 deci-pip of skew, wait one timeUnit(randomised between min/maxTimeUnit), add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // Since current skew is 0, cannot remove 1 deci-pip of skew. Skew stays at 0
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79989));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+151ms
        // one timeUnit(50ms) elapsed since t+101ms.
        // add 1 deci-pip of skew
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.80031));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.1));
            assertThat(ftl.data[1].sx.toString(), is("E")); // end
        }
    }

    @Test
    public void skewMustMaintainNegativeSign() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "-.+",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "-.+".
        // i.e remove 1 deci-pip of skew, wait one timeUnit(randomised between min/maxTimeUnit), add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // Since current skew is 0, cannot remove 1 deci-pip of skew. Skew stays at 0
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79989));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+151ms
        // one timeUnit(50ms) elapsed since t+101ms.
        // add 1 deci-pip of skew
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80029));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.1));
            assertThat(ftl.data[1].sx.toString(), is("E")); // end
        }
    }

    @Test
    public void negativeSkewCappedAtMaxSkew() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.+",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // start skew experiment "^.+".
        // i.e skew to maxSkew, wait one timeUnit(randomised between min/maxTimeUnit), add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // skew to max skew: maxSkew(0.5) * spread(1pip)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79984));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.5));
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+151ms
        // one timeUnit(50ms) elapsed since t+101ms.
        // add 1 deci-pip of skew. However since already at maxSkew, cannot increase beyond max.
        // Skew remains at max skew: maxSkew(0.5) * spread(1pip)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80025));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.5));
            assertThat(ftl.data[1].sx.toString(), is("E")); // end
        }
    }

    @Test
    public void positiveSkewCappedAtMaxSkew() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "^.+.0",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        // t+101ms
        // i.e skew to maxSkew, wait one timeUnit(randomised between min/maxTimeUnit), add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        // skew to max skew: maxSkew(0.5) * spread(1pip)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.79994));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.5));
            assertThat(ftl.data[1].sx.toString(), is("S")); // started
        }
        when:
        // t+151ms
        // one timeUnit(50ms) elapsed since t+101ms.
        // add 1 deci-pip of skew. However since already at maxSkew, cannot increase beyond max.
        // Skew remains at max skew: maxSkew(0.5) * spread(1pip)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80035));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.5));
            assertThat(ftl.data[1].sx.toString(), is("R")); // running
        }
        when:
        // t+201ms
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80040, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.80040));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.data[1].sx.toString(), is("E")); // end
        }
    }

    @Test
    public void simultaneousSkewExperiments() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.USDJPY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SIMULTANEOUS_SKEW_EXPERIMENTS, 2));
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 110.850, 0.04));
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -50_000, 110.850));
        }
        when:
        // t+101ms
        // START AUDUSD skew experiment: add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice() == 0.79989, is(false));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.data[1].sx.toString(), is("S")); // start
        }
        when:
        // While AUDUSD skew experiment is still active, start skew experiment for USDJPY
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 110.860, 0.04));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Instrument.USDJPY)).getFirst();
            assertThat(wbf.getSkewedMidPrice() == 110.860, is(false));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.data[1].sx.toString(), is("S")); //start
        }
    }

    @Test
    public void simultaneousSkewExperimentsCapped() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        SkewExperimentFeatureSpecs specs = SkewExperimentFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.USDJPY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_PRE_CONDITION_PERIOD_MS, 100L,
                specs.PARAM_PRE_CONDITION_VOL, 10d,
                specs.PARAM_PRE_CONDITION_VOL_FACTOR, FactorWindow.CAT_A.name(),
                specs.PARAM_PRE_CONDITION_POS_USD, activeUSD,
                specs.PARAM_PRE_CONDITION_VAR, 10_000d,
                specs.PARAM_PRE_CONDITION_MIN_SPREAD_DP, 0.5,
                specs.PARAM_TERMINATE_POS_USD, activeUSD + 1_000_000d,
                specs.PARAM_TERMINATE_VAR, 15_000d,
                specs.PARAM_MIN_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_TIME_UNIT_MS, 50L,
                specs.PARAM_MAX_SKEW, 0.5d,
                specs.PARAM_SKEW_SIGNATURES, "+.",
                specs.PARAM_COOL_OFF_PERIOD_MS, 300L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpConfiguration()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SIMULTANEOUS_SKEW_EXPERIMENTS, 1));
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 110.850, 0.04));
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -50_000, 110.850));
        }
        when:
        // t+101ms
        // START AUDUSD skew experiment: add 1 deci-pip of skew
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -50_000, 0.79999));
            prophet.clearOutputBuffer();
            prophet.incrementTime(101L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice() == 0.79989, is(false));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(SkewExperimentFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.data[1].sx.toString(), is("S")); // start
        }
        when:
        // Since AUDUSD skew experiment is still active, unable to start skew experiment for USDJPY since max simultaneous config is 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 110.860, 0.04));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Instrument.USDJPY)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(110.860));
        }
    }
}