package com.anz.axle.adapters.ndf2trep.acceptance;

public interface MessageProcessor<T> {

    void process(T payload, String description);
}
