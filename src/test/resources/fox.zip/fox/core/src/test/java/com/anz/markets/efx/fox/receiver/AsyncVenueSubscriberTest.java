package com.anz.markets.efx.fox.receiver;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.Queue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AsyncVenueSubscriberTest {

    @Mock
    private VenueSubscriber venueSubscriber;

    private Queue<Runnable> queue;
    private AsyncVenueSubscriber asyncVenueSubscriber;

    @BeforeEach
    void setUp() {
        queue = new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(10));
        asyncVenueSubscriber = new AsyncVenueSubscriber(queue, venueSubscriber);
    }

    @Test
    void runnable_subscription_should_be_scheduled() {
        //when
        asyncVenueSubscriber.subscribe(Venue.FAST);

        //then
        queue.poller().processNext(Runnable::run);
        verify(venueSubscriber).subscribe(Venue.FAST);
    }
}