package com.anz.markets.prophet.pricer.wholesale.spreads;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.pricer.wholesale.WholesaleBook;
import com.anz.markets.prophet.status.Context;
import org.junit.Test;

import java.io.IOException;

import static com.anz.markets.prophet.marketdata.TestConfigurationDataFactory.withDefaults;


public class VolumeSkewStrategyBWTest {

    private static final int REPS = 1_000_000;
    private static final int THRESHOLD = 1_000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private WholesaleBook wholesaleBook = new WholesaleBook(Market.WSP_A, Instrument.AUDUSD);
    private WholesaleBookFactorsImpl wholesaleBookFactors;
    final VolumeSkewStrategy volumeSkewStrategy = new VolumeSkewStrategy();

    public VolumeSkewStrategyBWTest() throws IOException {
        Context.context().region(Region.GB);
        Context.context().tradingTimeZone(TradingTimeZone.LDN);
        final ConfigurationDataDefault configurationDataDefault = withDefaults(new ConfigurationDataDefault());
        configurationDataDefault.setVolumeSkewConfigs(VolumeSkewStrategyTest.createDefaultVolumeSkewConfigs());
        final IndexedConfigurationData configuration = new IndexedConfigurationData(configurationDataDefault);
        volumeSkewStrategy.applyConfiguration(configuration);
        wholesaleBookFactors = wholesaleBook.getWholesaleBookFactors();
    }

    public void scenario_test() {
        VolumeSkewStrategyTest.addModelSpread(wholesaleBook, Level.QTY_1M, 0.2, 0.1);
        VolumeSkewStrategyTest.addModelSpread(wholesaleBook, Level.QTY_3M, 0.25, 0.15);
        VolumeSkewStrategyTest.addModelSpread(wholesaleBook, Level.QTY_5M, 0.35, 0.25);
        wholesaleBookFactors.setNotionalEquivPosition(10_000_000);
        volumeSkewStrategy.execute(wholesaleBook);
    }

    @Test
    public void test_SpreadBasedBookFormation() {
        helper.testAllocationNotExceeded(
                this::scenario_test,
                REPS, REPS,
                THRESHOLD
        );
    }
}
