package com.anz.markets.efx.fox.aggregator.core;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.agrona.collections.Long2ObjectHashMap;
import org.agrona.collections.Object2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

public class Aggregator implements Runnable {
    private static final Logger LOGGER = LoggerFactory.getLogger(Aggregator.class);

    private final PricingEncoderLookup pricingEncoderLookup;
    private final PricingClient<MarketDataBook> pricingClient;
    private final Consumer<MarketDataBook> polledMarketDataBookConsumer;
    private final PrecisionClock precisionClock;
    private final List<InstrumentKey> publishableInstruments;
    private final LongSupplier messageIdGenerator;
    private final String compId;
    private final int foxSource;

    private final Long2ObjectHashMap<Object2ObjectHashMap<RequestKey, MarketDataBook>> marketDataBooks;
    private final VenueRequestKeyLookup requestKeyLookup;
    private final MarketDataBookCurrentLevelEncoder currentLevelEncoder;
    private final AllMarketDataBooksSize allMarketDataBooksSize;

    public Aggregator(final PricingEncoderLookup pricingEncoderLookup,
                      final PricingClient<MarketDataBook> pricingClient,
                      final ObjectPool<MarketDataBook> marketDataBookPool,
                      final PrecisionClock precisionClock,
                      final List<InstrumentKey> publishableInstruments,
                      final LongSupplier messageIdGenerator,
                      final String compId,
                      final int foxSource) {
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.pricingClient = Objects.requireNonNull(pricingClient);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.publishableInstruments = Objects.requireNonNull(publishableInstruments);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.compId = Objects.requireNonNull(compId);
        this.foxSource = foxSource;
        Objects.requireNonNull(marketDataBookPool);

        marketDataBooks = new Long2ObjectHashMap<>();
        polledMarketDataBookConsumer = marketDataBook -> {
            Object2ObjectHashMap<RequestKey, MarketDataBook> byRequestKey = marketDataBooks.computeIfAbsent(marketDataBook.requestKey().instrumentKey().instrumentId(), instrumentId -> new Object2ObjectHashMap<>());
            final MarketDataBook oldBook = byRequestKey.put(marketDataBook.requestKey(), marketDataBook);
            if (oldBook != null) {
                marketDataBookPool.release(oldBook);
            }
        };

        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.FOX);
        allMarketDataBooksSize = new AllMarketDataBooksSize();
        currentLevelEncoder = new MarketDataBookCurrentLevelEncoder();
    }

    @Override
    public void run() {

        for(int i = 0; i < publishableInstruments.size(); i++) {
            final InstrumentKey publishableInstrument = publishableInstruments.get(i);

            final long beforePollTimeNanos = precisionClock.nanos();

            if (pricingClient.poller().pollAll(polledMarketDataBookConsumer, publishableInstrument.instrumentId())) {
                final long afterPollTimeNanos = precisionClock.nanos();

                LOGGER.debug("... aggregating {}",  publishableInstrument);

                final RequestKey requestKey = requestKeyLookup.lookup(publishableInstrument.instrumentId());
                final PricingEncoderSupplier pricingEncoderSupplier = pricingEncoderLookup.lookup(requestKey);

                final Object2ObjectHashMap<RequestKey, MarketDataBook>.ValueCollection values = marketDataBooks.get(publishableInstrument.instrumentId()).values();

                values.iterator().forEachRemaining(allMarketDataBooksSize.reset());

                final long messageId = messageIdGenerator.getAsLong();
                final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = pricingEncoderSupplier.snapshotFullRefresh().messageStart(foxSource, messageId)
                        .possResend(false)
                        .senderCompId().encode(compId)
                        .messageId(messageId)
                        .marketId(requestKey.market())
                        .instrumentId(requestKey.instrumentKey().instrumentId())
                        .sendingTime(precisionClock.nanos())
                        .referenceSpotDate().encodeNull()
                        .tradeDate().encodeNull()
                        .settlDate().encodeNull()
                        .entriesStart(allMarketDataBooksSize.totalBidsSize + allMarketDataBooksSize.totalAsksSize);

                currentLevelEncoder.mdEntriesNext(mdEntries_Next);
                encodeSide(EntryType.BID, allMarketDataBooksSize.maxBidsSize, values);
                encodeSide(EntryType.OFFER, allMarketDataBooksSize.maxAsksSize, values);

                final long currentTimeNanos = precisionClock.nanos();

                mdEntries_Next.entriesComplete()
                        .hopsStart(2)
                            .next()
                                .hopCompId().encode(compId)
                                .hopMessageId(messageId)
                                .hopReceivingTime(beforePollTimeNanos)
                            .next()
                                .hopCompId().encode(compId)
                                .hopMessageId(messageId)
                                .hopReceivingTime(afterPollTimeNanos)
                                .hopSendingTime(currentTimeNanos)
                            .hopsComplete()
                        .messageComplete();

            }
        }
    }

    private void encodeSide(final EntryType entryType, final int entriesSize, final Object2ObjectHashMap<RequestKey, MarketDataBook>.ValueCollection values) {
        currentLevelEncoder.entryType(entryType);
        for (int i = 0; i < entriesSize; i++) {
            currentLevelEncoder.currentEntryIndex(i);
            values.iterator().forEachRemaining(currentLevelEncoder);
        }
    }

    class MarketDataBookCurrentLevelEncoder implements Consumer<MarketDataBook> {
        private SnapshotFullRefreshEncoder.MdEntries.Next mdEntriesNext;
        private EntryType entryType;
        private int currentEntryIndex;

        @Override
        public void accept(final MarketDataBook marketDataBook) {
            final MarketDataEntries entries = (entryType == EntryType.BID ? marketDataBook.bids() : marketDataBook.asks());
            if (currentEntryIndex < entries.size()) {
                MarketDataEntry currentEntry = entries.get(currentEntryIndex);
                addEntry(currentEntry);
            }
        }

        private void addEntry(final MarketDataEntry entry) {
            mdEntriesNext.next()
                    .transactTime(entry.transactTimeNanos())
                    .mdMkt(entry.market())
                    .mdEntryType(entryType)
                    .mdEntrySize(entry.quantity())
                    .minQty(entry.minQuantity())
                    .mdEntryPx(entry.price())
                    .mdEntryId(currentEntryIndex)
                    .quoteEntryId(entry.quoteId());
        }

        public MarketDataBookCurrentLevelEncoder mdEntriesNext(final SnapshotFullRefreshEncoder.MdEntries.Next mdEntriesNext) {
            this.mdEntriesNext = Objects.requireNonNull(mdEntriesNext);
            return this;
        }

        public MarketDataBookCurrentLevelEncoder entryType(final EntryType entryType) {
            this.entryType = Objects.requireNonNull(entryType);
            return this;
        }

        public MarketDataBookCurrentLevelEncoder currentEntryIndex(final int currentEntryIndex) {
            this.currentEntryIndex = Objects.requireNonNull(currentEntryIndex);
            return this;
        }
    }

    class AllMarketDataBooksSize implements Consumer<MarketDataBook> {
        int maxBidsSize = 0;
        int maxAsksSize = 0;
        int totalBidsSize = 0;
        int totalAsksSize = 0;

        @Override
        public void accept(final MarketDataBook marketDataBook) {
            maxBidsSize = Math.max(maxBidsSize, marketDataBook.bids().size());
            maxAsksSize = Math.max(maxAsksSize, marketDataBook.asks().size());
            totalBidsSize += marketDataBook.bids().size();
            totalAsksSize += marketDataBook.asks().size();
        }

        AllMarketDataBooksSize reset() {
            maxBidsSize = 0;
            maxAsksSize = 0;
            totalBidsSize = 0;
            totalAsksSize = 0;

            return this;
        }
    }
}
