package com.anz.markets.prophet.atest.framework;

public @interface RelatedTest {
    Class value();
}
