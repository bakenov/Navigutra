package com.anz.markets.disco.config;

import com.anz.markets.disco.modules.PostEventSpreadModule;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.config.business.domain.tabular.MITRConfigs;
import com.anz.markets.prophet.config.business.domain.tabular.MITRFeaturesConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MarketType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumMap;

public class DiscoPostEventSpreadConfig {

    private final Logger log = LoggerFactory.getLogger(DiscoPostEventSpreadConfig.class);

    public static final String FEATURE_NAME = "PFP_DISCO_POST_EVENT_SPREAD";
    public static final String PARAM_WIDEN_TAU_SECONDS = "widenTauSeconds";
    public static final String PARAM_TIGHTEN_TAU_SECONDS = "tightenTauSeconds";
    public static final String PARAM_MIN_TIME_SECONDS = "minTimeSeconds";
    public static final String PARAM_MAX_TIME_SECONDS = "maxTimeSeconds";
    public static final String PARAM_TURN_OFF_SPREAD = "turnOffSpread";

    private final EnumObjTable<Market, TradingTimeZone, EnumMap<Instrument, PostEventSpreadModule.PESConfig>> configMap = new EnumObjTable(Market.class, TradingTimeZone.class);

    public DiscoPostEventSpreadConfig(final MITRConfigs priceFormationPipelineConfigs) {
        if (!priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
            log.warn("{} will be disabled.  Config table does not exist.", FEATURE_NAME);
            return;
        }
        boolean hasConfig = false;
        for (Market discoMarket : Market.VALUES) {
            if (discoMarket.getMarketType() == MarketType.INTERNAL_AGG) {
                for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                    final EnumMap<Instrument, PostEventSpreadModule.PESConfig> instrumentMap = new EnumMap<>(Instrument.class);
                    configMap.put(discoMarket, ttz, instrumentMap);
                    for (Instrument instrument : Instrument.VALUES) {
                        if (priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
                            final MITRFeaturesConfig c = priceFormationPipelineConfigs.getConfig(discoMarket, instrument, ttz);
                            final PostEventSpreadModule.PESConfig pesConfig = new PostEventSpreadModule.PESConfig();
                            final double tightenTauSeconds = c.getDoubleParamOrNaN(FEATURE_NAME, PARAM_TIGHTEN_TAU_SECONDS).get();
                            final double widenTauSeconds = c.getDoubleParamOrNaN(FEATURE_NAME, PARAM_WIDEN_TAU_SECONDS).get();
                            if (tightenTauSeconds > 0 || widenTauSeconds > 0) {
                                pesConfig.tightenTauNanos = (long) (tightenTauSeconds * 1_000_000_000);
                                pesConfig.widenTauNanos = (long) (widenTauSeconds * 1_000_000_000);
                                pesConfig.minTimeNanos = (long) (c.getDoubleParamOrNaN(FEATURE_NAME, PARAM_MIN_TIME_SECONDS).get() * 1_000_000_000);
                                pesConfig.maxTimeNanos = (long) (c.getDoubleParamOrNaN(FEATURE_NAME, PARAM_MAX_TIME_SECONDS).get() * 1_000_000_000);
                                pesConfig.turnOffSpread = c.getDoubleParamOrNaN(FEATURE_NAME, PARAM_TURN_OFF_SPREAD).get();
                                instrumentMap.put(instrument, pesConfig);
                                hasConfig = true;
                            }
                        }
                    }
                }
            }
        }
        if (hasConfig) {
            log.info("{} has valid config.", FEATURE_NAME);
        } else {
            log.info("{} is not configured.", FEATURE_NAME);
        }
    }

    public EnumObjTable<Market, TradingTimeZone, EnumMap<Instrument, PostEventSpreadModule.PESConfig>> getConfig() {
        return configMap;
    }

}
