package com.anz.axle.lg.adapter.ebsu;

import org.junit.Test;

import software.chronicle.ebs.itch.generated.preview.fields.TenorType;
import software.chronicle.ebs.itch.generated.preview.messages.datamodel.server.DefaultInstrumentDirectory;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TenorFilterTest {

    @Test
    public void testFXSPOT() {
        DefaultInstrumentDirectory instrumentDirectory = new DefaultInstrumentDirectory();
        instrumentDirectory.securityType(software.chronicle.ebs.itch.generated.preview.fields.SecurityType.FX_SPOT);
        assertTrue(TenorFilter.canPublish(instrumentDirectory));
    }

    @Test
    public void testNdf() {
        DefaultInstrumentDirectory instrumentDirectory = new DefaultInstrumentDirectory();
        instrumentDirectory.securityType(software.chronicle.ebs.itch.generated.preview.fields.SecurityType.FX_NDF);
        instrumentDirectory.tenorType(TenorType.MONTHS);
        instrumentDirectory.tenorValue(1);
        assertTrue(TenorFilter.canPublish(instrumentDirectory));

        instrumentDirectory.tenorValue(2);
        assertFalse(TenorFilter.canPublish(instrumentDirectory));

        instrumentDirectory.tenorType(TenorType.DAYS);
        assertFalse(TenorFilter.canPublish(instrumentDirectory));
    }
}