package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.HeaderDecoder;

public interface VenueInstrumentConfigDecoder extends HeaderDecoder {
    Body body();
    void appendTo(StringBuilder stringBuilder);

    interface Body {
        Venue venue();
        long instrumentId();
        double priceIncrement();
        int sizeIncrement();
        int clipSizeMultiple();
        double maxAllowedParentOrderQty();
        int minClipSize();
        int maxClipSize();
        int staleDataTimeout();
        int priority();
        int proportion();
        boolean enabled();
    }
}