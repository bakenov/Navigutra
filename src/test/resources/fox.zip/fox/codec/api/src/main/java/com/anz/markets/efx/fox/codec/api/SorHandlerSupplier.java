package com.anz.markets.efx.fox.codec.api;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.fox.codec.api.UnsupportedException.supplierThrowingUnsupported;

/**
 * Provides handlers for the decoding of SOR messages.  Handlers or handler suppliers are used to construct a
 * SOR handler supplier object.  Handlers that are not provided at construction time of the handler supplier cause
 * an {@link UnsupportedException} when an attempt is made to access unsupported handlers.
 */

public interface SorHandlerSupplier {
    PricingRefreshCompleteHandler pricingRefreshComplete();
    TimerExpiryHandler timerExpiryHandler();
    FirewallConfigHandler firewallConfigHandler();
    VenueConfigHandler venueConfigHandler();
    UserConfigHandler userConfigHandler();
    InitialisationHandler initialisationHandler();
    InstrumentConfigHandler instrumentConfigHandler();
    VenueInstrumentConfigHandler venueInstrumentConfigHandler();

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier create(final PricingRefreshCompleteHandler pricingRefreshCompleteHandler,
                                     final TimerExpiryHandler timerExpiryHandler,
                                     final FirewallConfigHandler firewallConfigHandler,
                                     final VenueConfigHandler venueConfigHandler,
                                     final UserConfigHandler userConfigHandler,
                                     final InitialisationHandler initialisationHandler,
                                     final InstrumentConfigHandler instrumentConfigHandler,
                                     final VenueInstrumentConfigHandler venueInstrumentConfigHandler
    ) {
        Objects.requireNonNull(pricingRefreshCompleteHandler);
        Objects.requireNonNull(timerExpiryHandler);
        Objects.requireNonNull(firewallConfigHandler);
        Objects.requireNonNull(venueConfigHandler);
        Objects.requireNonNull(userConfigHandler);
        Objects.requireNonNull(initialisationHandler);
        Objects.requireNonNull(instrumentConfigHandler);
        Objects.requireNonNull(venueInstrumentConfigHandler);
        return create(() -> pricingRefreshCompleteHandler,
                      () -> timerExpiryHandler,
                      () -> firewallConfigHandler,
                      ()-> venueConfigHandler,
                      ()-> userConfigHandler,
                      () -> initialisationHandler,
                      () -> instrumentConfigHandler,
                      () -> venueInstrumentConfigHandler
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier create(final Supplier<? extends PricingRefreshCompleteHandler> pricingRefreshCompleteHandler,
                                     final Supplier<? extends TimerExpiryHandler> timerExpiryHandler,
                                     final Supplier<? extends FirewallConfigHandler> firewallConfigHandler,
                                     final Supplier<? extends VenueConfigHandler> venueConfigHandler,
                                     final Supplier<? extends UserConfigHandler> userConfigHandler,
                                     final Supplier<? extends InitialisationHandler> initialisationHandler,
                                     final Supplier<? extends InstrumentConfigHandler> instrumentConfigHandler,
                                     final Supplier<? extends VenueInstrumentConfigHandler> venueInstrumentConfigHandler
    ) {
        Objects.requireNonNull(pricingRefreshCompleteHandler);
        Objects.requireNonNull(timerExpiryHandler);
        Objects.requireNonNull(firewallConfigHandler);
        Objects.requireNonNull(venueConfigHandler);
        Objects.requireNonNull(userConfigHandler);
        Objects.requireNonNull(initialisationHandler);
        Objects.requireNonNull(instrumentConfigHandler);
        Objects.requireNonNull(venueInstrumentConfigHandler);
        return new SorHandlerSupplier() {
            @Override
            public PricingRefreshCompleteHandler pricingRefreshComplete() {
                return pricingRefreshCompleteHandler.get();
            }

            @Override
            public TimerExpiryHandler timerExpiryHandler() {
                return timerExpiryHandler.get();
            }

            @Override
            public FirewallConfigHandler firewallConfigHandler() {
                return firewallConfigHandler.get();
            }

            @Override
            public VenueConfigHandler venueConfigHandler() {
                return venueConfigHandler.get();
            }

            @Override
            public UserConfigHandler userConfigHandler() {
                return userConfigHandler.get();
            }

            @Override
            public InitialisationHandler initialisationHandler() {
                return initialisationHandler.get();
            }

            @Override
            public InstrumentConfigHandler instrumentConfigHandler() {
                return instrumentConfigHandler.get();
            }

            @Override
            public VenueInstrumentConfigHandler venueInstrumentConfigHandler() {
                return venueInstrumentConfigHandler.get();
            }
        };
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier pricingRefreshComplete(final PricingRefreshCompleteHandler pricingRefreshCompleteHandler) {
        Objects.requireNonNull(pricingRefreshCompleteHandler);
        return pricingRefreshComplete(() -> pricingRefreshCompleteHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier pricingRefreshComplete(final Supplier<? extends PricingRefreshCompleteHandler> pricingRefreshCompleteHandler) {
        return create(pricingRefreshCompleteHandler,
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                supplierThrowingUnsupported(FirewallConfigHandler.class),
                supplierThrowingUnsupported(VenueConfigHandler.class),
                supplierThrowingUnsupported(UserConfigHandler.class),
                supplierThrowingUnsupported(InitialisationHandler.class),
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
                );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier timerExpiry(final TimerExpiryHandler timerExpiryHandler) {
        Objects.requireNonNull(timerExpiryHandler);
        return timerExpiry(() -> timerExpiryHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier timerExpiry(final Supplier<? extends TimerExpiryHandler> timerExpiryHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                timerExpiryHandler,
                supplierThrowingUnsupported(FirewallConfigHandler.class),
                supplierThrowingUnsupported(VenueConfigHandler.class),
                supplierThrowingUnsupported(UserConfigHandler.class),
                supplierThrowingUnsupported(InitialisationHandler.class),
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier firewallConfig(final FirewallConfigHandler firewallConfigHandler) {
        Objects.requireNonNull(firewallConfigHandler);
        return firewallConfig(() -> firewallConfigHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier firewallConfig(final Supplier<? extends FirewallConfigHandler> firewallConfigHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                firewallConfigHandler,
                supplierThrowingUnsupported(VenueConfigHandler.class),
                supplierThrowingUnsupported(UserConfigHandler.class),
                supplierThrowingUnsupported(InitialisationHandler.class),
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
                );
 
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier venueConfig(final VenueConfigHandler venueConfigHandler) {
        Objects.requireNonNull(venueConfigHandler);
        return venueConfig(() -> venueConfigHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier venueConfig(final Supplier<? extends VenueConfigHandler> venueConfigHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                supplierThrowingUnsupported(FirewallConfigHandler.class), 
                venueConfigHandler,
                supplierThrowingUnsupported(UserConfigHandler.class),
                supplierThrowingUnsupported(InitialisationHandler.class),
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier userConfig(final UserConfigHandler userConfigHandler) {
        Objects.requireNonNull(userConfigHandler);
        return userConfig(() -> userConfigHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier userConfig(final Supplier<? extends UserConfigHandler> userConfigHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                supplierThrowingUnsupported(FirewallConfigHandler.class),
                supplierThrowingUnsupported(VenueConfigHandler.class),
                userConfigHandler,
                supplierThrowingUnsupported(InitialisationHandler.class),
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier initialisation(final InitialisationHandler initialisationHandler) {
        Objects.requireNonNull(initialisationHandler);
        return initialisation(() -> initialisationHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier initialisation(final Supplier<? extends InitialisationHandler> initialisationHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                supplierThrowingUnsupported(FirewallConfigHandler.class),
                supplierThrowingUnsupported(VenueConfigHandler.class),
                supplierThrowingUnsupported(UserConfigHandler.class),
                initialisationHandler,
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier instrumentConfig(final InstrumentConfigHandler instrumentConfigHandler) {
        Objects.requireNonNull(instrumentConfigHandler);
        return instrumentConfig(() -> instrumentConfigHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier instrumentConfig(final Supplier<? extends InstrumentConfigHandler> instrumentConfigHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                supplierThrowingUnsupported(FirewallConfigHandler.class),
                supplierThrowingUnsupported(VenueConfigHandler.class),
                supplierThrowingUnsupported(UserConfigHandler.class),
                supplierThrowingUnsupported(InitialisationHandler.class),
                instrumentConfigHandler,
                supplierThrowingUnsupported(VenueInstrumentConfigHandler.class)
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier venueInstrumentConfig(final VenueInstrumentConfigHandler venueInstrumentConfigHandler) {
        Objects.requireNonNull(venueInstrumentConfigHandler);
        return venueInstrumentConfig(() -> venueInstrumentConfigHandler);
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier venueInstrumentConfig(final Supplier<? extends VenueInstrumentConfigHandler> venueInstrumentConfigHandler) {
        return create(supplierThrowingUnsupported(PricingRefreshCompleteHandler.class),
                supplierThrowingUnsupported(TimerExpiryHandler.class),
                supplierThrowingUnsupported(FirewallConfigHandler.class),
                supplierThrowingUnsupported(VenueConfigHandler.class),
                supplierThrowingUnsupported(UserConfigHandler.class),
                supplierThrowingUnsupported(InitialisationHandler.class),
                supplierThrowingUnsupported(InstrumentConfigHandler.class),
                venueInstrumentConfigHandler
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier threadLocal(final Supplier<? extends PricingRefreshCompleteHandler> pricingRefreshCompleteHandlerSupplier,
                                          final Supplier<? extends TimerExpiryHandler> timerExpiryHandlerSupplier,
                                          final Supplier<? extends FirewallConfigHandler> firewallConfigHandlerSupplier,
                                          final Supplier<? extends VenueConfigHandler> venueConfigHandlerSupplier,
                                          final Supplier<? extends UserConfigHandler> userConfigHandlerSupplier,
                                          final Supplier<? extends InitialisationHandler> initialisationHandlerSupplier,
                                          final Supplier<? extends InstrumentConfigHandler> instrumentConfigHandlerSupplier,
                                          final Supplier<? extends VenueInstrumentConfigHandler> venueInstrumentConfigHandlerSupplier
                                          ) {
        final ThreadLocal<PricingRefreshCompleteHandler> pricingRefreshCompleteHandler = ThreadLocal.withInitial(pricingRefreshCompleteHandlerSupplier);
        final ThreadLocal<TimerExpiryHandler> timerExpiryHandler = ThreadLocal.withInitial(timerExpiryHandlerSupplier);
        final ThreadLocal<FirewallConfigHandler> firewallConfigHandler = ThreadLocal.withInitial(firewallConfigHandlerSupplier);
        final ThreadLocal<VenueConfigHandler> venueConfigHandler = ThreadLocal.withInitial(venueConfigHandlerSupplier);
        final ThreadLocal<UserConfigHandler> userConfigHandler = ThreadLocal.withInitial(userConfigHandlerSupplier);
        final ThreadLocal<InitialisationHandler> initialisationHandler = ThreadLocal.withInitial(initialisationHandlerSupplier);
        final ThreadLocal<InstrumentConfigHandler> instrumentConfigHandler = ThreadLocal.withInitial(instrumentConfigHandlerSupplier);
        final ThreadLocal<VenueInstrumentConfigHandler> venueInstrumentConfigHandler = ThreadLocal.withInitial(venueInstrumentConfigHandlerSupplier);

        return create(pricingRefreshCompleteHandler::get,
                      timerExpiryHandler::get,
                      firewallConfigHandler::get,
                      venueConfigHandler::get,
                      userConfigHandler::get,
                      initialisationHandler::get,
                      instrumentConfigHandler::get,
                      venueInstrumentConfigHandler::get
                );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorHandlerSupplier threadLocal(final Supplier<? extends SorHandlerSupplier> supplierSupplier) {
        final ThreadLocal<SorHandlerSupplier> handlerSupplier = ThreadLocal.withInitial(supplierSupplier);
        return create(
                () -> handlerSupplier.get().pricingRefreshComplete(),
                () -> handlerSupplier.get().timerExpiryHandler(),
                () -> handlerSupplier.get().firewallConfigHandler(),
                () -> handlerSupplier.get().venueConfigHandler(),
                () -> handlerSupplier.get().userConfigHandler(),
                () -> handlerSupplier.get().initialisationHandler(),
                () -> handlerSupplier.get().instrumentConfigHandler(),
                () -> handlerSupplier.get().venueInstrumentConfigHandler()
        );
    }

}