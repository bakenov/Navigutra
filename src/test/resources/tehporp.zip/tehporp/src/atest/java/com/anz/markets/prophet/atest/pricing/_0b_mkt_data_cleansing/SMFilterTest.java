package com.anz.markets.prophet.atest.pricing._0b_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.BenchmarkSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.StandardMarketSpreadConfig;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;

/**
 * SM-Filter : Filter incoming Market Data prices if crossed beyond acceptable threshold
 */
@RestartBeforeTest(reason = "clear prices")
public class SMFilterTest extends BaseAcceptanceSpecification {

    // given threshold of 1.5(LDN std mkt spread) * 2(spread multiplier = 3 pips
    private ConfigurationDataDefault smFilterConfig() {

        ConfigurationDataDefault config = tdd.configuration_pricing_base()
                .setInstrumentConfigs(Lists.newArrayList(
                        new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(2).setSpotDecimalPlaces(4.0).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                ))
                .setStandardMarketSpreadConfigs(Lists.newArrayList(
                        new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 1.5E-4, 0.0, 0.0, 0.0, 0.0, 1.25E-4, 0.0, 0.0, 0.0)
                ))
                .setFilterEnabledConfigs(union(
                        tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                        tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY),
                        tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET),
                        tdd.disableFilter(MarketDataFilterType.AGG_BOOK_CROSSED),
                        tdd.disableFilter(MarketDataFilterType.AGG_BOOK_DISPERSION),
                        tdd.disableFilter(MarketDataFilterType.AGG_BOOK_MINIMUM_MARKET)
                ))
                .setBenchmarkSpreadConfigs(Lists.newArrayList(
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(10.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.CNX))
                ));

        return config;
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_7)
    @DisplayName("Allow choice price.")
    public void allow_choice_market_data_price() {
        setup:
        {
            // given threshold of 3 pips
            prophet.receive(smFilterConfig());

        }
        when:
        {
            // spread is within the threshold (0 pips).
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.94300, 0.94300));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.PASS));
        }
        and:
        {
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.942985, 0.943015));
        }

    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_7)
    @DisplayName("Allow crossed book for a market when it is crossed at the threshold.")
    public void allow_crossed_market_data_prices_at_threshold() {
        setup:
        {
            prophet.receive(smFilterConfig());
        }
        when:
        {
            // spread is within the threshold (-3 pips).
            // note that this is a special number because the computed spread will have
            // floating point artifacts - e.g., 3.00000000000078E-4
            // the code must cater for this
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.9433, 0.9430));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.PASS));
        }
        and:
        {
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.943135, 0.943165));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_7)
    @DisplayName("Filter market data price when it is crossed above the threshold.")
    public void do_not_allow_crossed_market_data_prices_above_threshold() {
        setup:
        {
            // given threshold of 3 pips
            prophet.receive(smFilterConfig());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.94331, 0.9430));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.FAIL));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_7)
    @DisplayName("Market is excluded from price formation when its incoming price is crossed above the threshold.")
    public void excluded_market_when_incoming_prices_above_threshold() {
        setup:
        {
            // given threshold of 3 pips
            prophet.receive(smFilterConfig());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75010, 0.75014));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75009, 0.75017));
        }
        then:
        {
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.750105, 0.750135));
            prophet.clearOutputBuffer();
        }
        when:
        {
            // CNX spread is -4 pips which is over the threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75140, 0.7510));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.FAIL));
        }
        and:
        {
            // CNX is removed from WSP_U.  TOB is now HSP
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));

            // Since WSP_U TOB has changed, new client price pushed
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.750115, 0.750145));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_7)
    @DisplayName("use correct mkt spread config on TZ change")
    public void use_correct_config_based_on_timezone() {
        setup:
        {
            // given threshold of 1.5(LDN std mkt spread) * 2(spread multiplier = 3 pips
            // given threshold of 1.25(SNG std mkt spread) * 2(spread multiplier = 2.5 pips
            prophet.receive(smFilterConfig());

            // LDN TIMEZONE
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            // spread crossed by 2.6 pip
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.94326, 0.94300));
        }
        then:
        {
            // filter passes
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.PASS));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // SNG TIMEZONE
            prophet.receive(TradingTimeZone.SNG);

            // spread crossed by 2.6 pip
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.94327, 0.94301));
        }
        then:
        {
            // filter fails
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.FAIL));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // LDN TIMEZONE
            prophet.receive(TradingTimeZone.LDN);

            // spread crossed by 2.6 pip
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.94326, 0.94300));
        }
        then:
        {
            // filter passes
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.PASS));
        }
    }

    @Test
    // AXPROPHET-1189
    @DisplayName("Spread Multiplier defaults to 0 when Instrument Config not defined")
    public void do_not_allow_crossed_market_when_spread_multiplier_not_defined() {
        setup:
        {
            ConfigurationDataDefault configuration = smFilterConfig();

            final List<StandardMarketSpreadConfig> stdMktSpreads = new ArrayList<>(configuration.getStandardMarketSpreadConfigs());
            stdMktSpreads.add(new StandardMarketSpreadConfigImpl(Instrument.USDSG2, 0.00025, 0.0, 0.0, 0.0, 0.0, 0.00025, 0.0, 0.0, 0.0));
            configuration.setStandardMarketSpreadConfigs(stdMktSpreads);

            prophet.receive(configuration);
        }
        when:
        // spread multiplier not defined for USDSG2 as InstrumentConfig does not exist
        // NOTE: USDSG2 not configured to generate Client Price
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.D3, Instrument.USDSG2, 1.28331, 0.28330));
        }
        then:
        {
            prophet.notExpect(org.apache.logging.log4j.Level.ERROR, matches(".*"));

            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.D3)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.FAIL));
        }
    }
}
