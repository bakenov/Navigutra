package com.anz.axle.acc.domain;

import com.anz.axle.common.dao.VenueDao;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CreditCheckLogEntry;
import com.anz.axle.common.domain.Venue;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("creditCheckLogEntryBuilder")
public class CreditCheckLogEntryBuilder implements Builder<CreditCheckLogEntry, CurrencyVenueExclusion> {

    @Autowired
    private VenueDao venueDao;

    @Override
    public CreditCheckLogEntry build(CurrencyVenueExclusion input) throws BuilderException {
        Venue venue = venueDao.findByAggregatorCode(input.getVenue());
        return new CreditCheckLogEntry(venue, input.getSymbol(), input.isExcluded(), input.getMessage());
    }
}
