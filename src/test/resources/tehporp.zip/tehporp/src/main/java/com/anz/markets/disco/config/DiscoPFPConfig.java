package com.anz.markets.disco.config;

import com.anz.markets.disco.modules.DiscoveryModule;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.config.business.domain.tabular.MITRConfigs;
import com.anz.markets.prophet.config.business.domain.tabular.MITRFeaturesConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MarketType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumMap;

public class DiscoPFPConfig {

    private final Logger log = LoggerFactory.getLogger(DiscoPFPConfig.class);

    public static final String FEATURE_NAME = "PFP_DISCO";
    public static final String PARAM_CONSTITUENTS = "constituentMarkets2D";
    public static final String PARAM_PROTECTION = "protectionMarkets2D";
    public static final String PARAM_TWO_PRICE_MODE = "twoPriceMode";

    @Deprecated  //remove down track once migrated.
    private static final String PARAM_CONSTITUENTS_LEGACY = "constituentMarkets";
    @Deprecated  //remove down track once migrated.
    private static final String PARAM_PROTECTION_LEGACY = "protectionMarkets";


    private final EnumObjTable<Market, TradingTimeZone, EnumMap<Instrument, DiscoPFPRowConfig>> configMap = new EnumObjTable(Market.class, TradingTimeZone.class);

    public class DiscoPFPRowConfig {
        public Markets constituents[];
        public Markets protection[];
        public DiscoveryModule.TwoPriceMode twoPriceMode;
    }

    public DiscoPFPConfig(final MITRConfigs priceFormationPipelineConfigs) {
        if (!priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
            log.warn("{} will be disabled.  Config table does not exist.",FEATURE_NAME);
            return;
        }
        boolean hasConfig = false;
        for (Market discoMarket : Market.VALUES) {
            if (discoMarket.getMarketType() == MarketType.INTERNAL_AGG) {
                for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                    final EnumMap<Instrument, DiscoPFPRowConfig> instrumentMap = new EnumMap<>(Instrument.class);
                    configMap.put(discoMarket, ttz, instrumentMap);
                    for (Instrument instrument : Instrument.VALUES) {
                        if (priceFormationPipelineConfigs.hasFeature(FEATURE_NAME)) {
                            final MITRFeaturesConfig c = priceFormationPipelineConfigs.getConfig(discoMarket, instrument, ttz);
                            final Markets[] cons = getMarkets2D(c,PARAM_CONSTITUENTS,PARAM_CONSTITUENTS_LEGACY);
                            if (cons.length > 0) {
                                final Markets[] pros = getMarkets2D(c,PARAM_PROTECTION,PARAM_PROTECTION_LEGACY);
                                final DiscoPFPRowConfig rowConfig = new DiscoPFPRowConfig();
                                rowConfig.constituents = cons;
                                rowConfig.protection = pros;
                                rowConfig.twoPriceMode = DiscoveryModule.TwoPriceMode.valueOf(c.getStringParam(FEATURE_NAME, PARAM_TWO_PRICE_MODE).get());
                                instrumentMap.put(instrument,rowConfig);
                                hasConfig = true;
                            }
                        }
                    }
                }
            }
        }
        if (hasConfig) {
            log.info("{} has valid config.",FEATURE_NAME);
        } else {
            log.info("{} is not configured.",FEATURE_NAME);
        }
    }

    private Markets[] getMarkets2D(final MITRFeaturesConfig c, final String param, final String paramLegacy) {
        Markets[] m = c.getMarkets2DParam(FEATURE_NAME,param);
        if (m == null) {
            // try old column name.
            final Markets old = c.getMarketsParam(FEATURE_NAME, paramLegacy);
            // reshape.
            m = new Markets[old.get().length];
            for (int i = 0; i < m.length; i++) {
                m[i] = Markets.getMarkets(old.get()[i]);
            }
        }
        return m;
    }

    public EnumObjTable<Market, TradingTimeZone, EnumMap<Instrument, DiscoPFPRowConfig>> getConfig() {
        return configMap;
    }

}
