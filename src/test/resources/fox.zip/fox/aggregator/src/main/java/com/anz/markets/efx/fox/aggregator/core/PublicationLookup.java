package com.anz.markets.efx.fox.aggregator.core;

import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Topic;

public interface PublicationLookup {
    Publication publication(Topic topic);
}
