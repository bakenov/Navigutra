package com.anz.markets.efx.fox.firewall.metric;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.firewall.matcher.RegexpRuleMatcher;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import static org.assertj.core.api.Assertions.assertThat;


@RunWith(Spockito.class)
public class RegexpRuleMatcherTest {

    @Test
    @Spockito.Unroll({
            "| regionPattern | region | deskPattern | desk   | orderTypePattern | orderType | portfolioPattern | portfolio | usernamePattern | username | venuePattern | markets    | securityTypePattern | securityType | tenorPattern | tenor | symbolPattern | symbol | matchResult |",
            "|===============|========|=============|========|==================|===========|==================|===========|=================|==========|==============|===========|=====================|==============|==============|=======|===============|========|=============|",
            "| .*            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| JP            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | false       |",
            "| G             | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | false       |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | M.*              | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | MID.*            | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | MID              | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | XE.*             | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | P_.*             | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | false       |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | anuf.*          | anufriea | .*           | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | FXALLMB      | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | FXALL        | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | false       |",
            "| GB            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | FXALL.*      | FXALLMB   | .*                  | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| .*            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*SPOT              | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| .*            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*SPOT              | FXSPOT       | .*           | SP    | .*            | AUDUSD | true        |",
            "| .*            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*SPOT              | FXSPOT       | .*           | SP    | AUD.*         | AUDUSD | true        |",
            "| .*            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*SPOT              | FXSPOT       | .*           | SP    | .*USD         | AUDUSD | true        |",
            "| .*            | GB     | .*          | Some   | .*               | MID       | .*               | XEFX      | .*              | anufriea | .*           | FXALLMB   | .*SPOT              | FXSPOT       | .*           | SP    | USD.*         | AUDUSD | false       |",
            "|---------------|--------|-------------|--------|------------------|-----------|------------------|-----------|-----------------|----------|--------------|-----------|---------------------|--------------|--------------|-------|---------------|--------|-------------|"
    })
    public void match(
            final String regionPattern,
            final String region,
            final String deskPattern,
            final String desk,
            final String orderTypePattern,
            final String orderType,
            final String portfolioPattern,
            final String portfolio,
            final String usernamePattern,
            final String username,
            final String venuePattern,
            final String venues,
            final String securityTypePattern,
            final SecurityType securityType,
            final String tenorPattern,
            final Tenor tenor,
            final String symbolPattern,
            final String symbol,
            final boolean matchResult) {
        final RegexpRuleMatcher regexpRuleMatcher = new RegexpRuleMatcher(regionPattern, deskPattern, orderTypePattern, portfolioPattern, usernamePattern, venuePattern, securityTypePattern, tenorPattern, symbolPattern);
        assertThat(regexpRuleMatcher.match(region, desk, orderType, portfolio, username, venues, securityType, tenor, symbol)).isEqualTo(matchResult);
    }

    @Test
    @Spockito.Unroll({
            "| regionPattern1 | regionPattern2 | deskPattern1 | deskPattern2 | orderTypePattern1 | orderTypePattern2 | portfolioPattern1 | portfolioPattern2 | usernamePattern1 | usernamePattern2 | venuePattern1 | venuePattern2 | securityTypePattern1 | securityTypePattern2 | tenorPattern1 | tenorPattern2 | symbolPattern1 | symbolPattern2 | compare1and2 |",
            "|================|================|==============|==============|===================|===================|===================|===================|==================|==================|===============|===============|======================|======================|===============|===============|================|================|==============|",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| JP             | JP             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| G              | G              | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | M.*               | M.*               | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | MID.*             | MID.*             | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | MID               | MID               | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | XE.*              | XE.*              | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | P_.*              | P_.*              | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | .*                | .*                | anuf.*           | anuf.*           | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | FXALLMB       | FXALLMB       | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| GB             | GB             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | FXALL         | FXALL         | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*SPOT               | .*SPOT               | .*            | .*            | .*             | .*             | 0            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*SPOT               | .*SPOT               | .*            | .*            | .*             | .*             | 0            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*SPOT               | .*SPOT               | .*            | .*            | AUD.*          | AUD.*          | 0            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*SPOT               | .*SPOT               | .*            | .*            | .*USD          | .*USD          | 0            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*SPOT               | .*SPOT               | .*            | .*            | USD.*          | USD.*          | 0            |",
            "| GB             | .*             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | -1           |",
            "| .*             | GB             | .*           | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 1            |",
            "| .*             | GB             | desk1        | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | -1           |",
            "| .*             | GB             | desk1        | .*           | .*                | MID               | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 1            |",
            "| GB             | .*             | desk1        | .*           | .*                | MID               | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 1            |",
            "| .*             | .*             | desk1        | .*           | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | -1           |",
            "| .*             | .*             | .*           | desk2        | .*                | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 1            |",
            "| .*             | .*             | .*           | .*           | MID               | .*                | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | -1           |",
            "| .*             | .*             | .*           | .*           | .*                | MID               | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 1            |",
            "| .*             | .*             | .*           | .*           | XXX               | MID               | .*                | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 0            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | .*                | XEFX              | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | 1            |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | XEFX              | .*                | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | -1           |",
            "| .*             | .*             | .*           | .*           | .*                | .*                | XEFX              | XEF               | .*               | .*               | .*            | .*            | .*                   | .*                   | .*            | .*            | .*             | .*             | -1           |",
            "|----------------|----------------|--------------|--------------|-------------------|-------------------|-------------------|-------------------|------------------|------------------|---------------|---------------|----------------------|----------------------|---------------|---------------|----------------|----------------|--------------|"
    })
    public void compareTo(
            final String regionPattern1,
            final String regionPattern2,
            final String deskPattern1,
            final String deskPattern2,
            final String orderTypePattern1,
            final String orderTypePattern2,
            final String portfolioPattern1,
            final String portfolioPattern2,
            final String usernamePattern1,
            final String usernamePattern2,
            final String venuePattern1,
            final String venuePattern2,
            final String securityTypePattern1,
            final String securityTypePattern2,
            final String tenorPattern1,
            final String tenorPattern2,
            final String symbolPattern1,
            final String symbolPattern2,
            final int compare1and2
            ) {
        final RegexpRuleMatcher regexpRuleMatcher1 = new RegexpRuleMatcher(regionPattern1, deskPattern1, orderTypePattern1, portfolioPattern1, usernamePattern1, venuePattern1, securityTypePattern1, tenorPattern1, symbolPattern1);
        final RegexpRuleMatcher regexpRuleMatcher2 = new RegexpRuleMatcher(regionPattern2, deskPattern2, orderTypePattern2, portfolioPattern2, usernamePattern2, venuePattern2, securityTypePattern2, tenorPattern2, symbolPattern2);

        assertThat(Math.signum(regexpRuleMatcher1.compareTo(regexpRuleMatcher2))).isEqualTo(compare1and2);
    }
}