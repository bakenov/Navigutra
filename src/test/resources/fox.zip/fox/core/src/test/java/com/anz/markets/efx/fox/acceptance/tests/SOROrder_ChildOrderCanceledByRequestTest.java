package com.anz.markets.efx.fox.acceptance.tests;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.NewOrderSingleMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRequestMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

@RunWith(Spockito.class)
public class SOROrder_ChildOrderCanceledByRequestTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SOROrder_ChildOrderCanceledByRequestTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private MarketDataFactory marketDataFactory = new MarketDataFactory();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_1 = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|0             |   BARX         |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   []         |    1      |     1        | 0                 |",
            "|0             |   CNX          |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 |   []         |    2      |     2        | 0                 |",
            "|0             |   EBS          |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   [LATENT]   |    1      |     1        | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_2 = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|0             |   BARX         |      BID    |   1.3345  |        0.0           |     1e6     |  500000 |   []         |     1     |       1      | 0                 |",
            "|0             |   CNX          |     OFFER   |   1.3320  |        0.0001        |     2e6     |  800000 |   []         |     2     |       2      | 0                 |",
    });

    private static final List<SnapshotFullRefresh.Entry[]> snapshotEntries() {
        return Arrays.asList(SNAP_ENTRIES_1, SNAP_ENTRIES_2);
    }

    private static final Hop[] HOPS = Table.parse(Hop.class, new String[] {
            "|   hopCompId  | hopMessageId | hopReceivingTime | hopSendingTime |",
            "|==============|==============|==================|================|",
            "| GB:HopName:1 |   1234567789  |    66655556666   |  66655557777   |",
            "| AU:HopName:2 |   123123123  |    66556655666   |  66556655777   |",
    });

    @Test
    @Spockito.Unroll({
            "| source | sourceSeq | idx | senderCompId | messageId | possResend | origSendingTime | symbol |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|========|===========|=====|==============|===========|============|=================|========|===============|==========|============|===========|============|===================|===================|",
            "|  34    | 45678     |  0  | GB:Sender:01 |    9876   |    false   |    1122334000   | AUDUSD |   FXSPOT      | FAST     | 2016-01-14 |    SP     | 2016-01-16 |     2016-01-06    | []                |",
            "|--------|-----------|-----|--------------|-----------|------------|-----------------|--------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void fox_should_handle_order_cancel_response_from_venue(
            final int source, final long sourceSeq, final int idx, final String senderCompId, final long messageId,
            final boolean possResend, final long origSendingTime,
            final String symbol, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags
    ) throws Exception {
        final SnapshotFullRefresh.Entry[] snapShotEntry = snapshotEntries().get(idx);
        final long currentTimeNanos = acceptanceContext.precisionClock().nanos();
        Arrays.stream(snapShotEntry).forEach(e -> e.transactTime = currentTimeNanos);

        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, securityType, settlType);

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(source, sourceSeq),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, currentTimeNanos, origSendingTime,
                        instrumentKey.instrumentId(), marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                snapShotEntry, HOPS);

        final VenueEndpoint venueEndpoint = acceptanceContext.venueEndpointLookup()
                .lookup(marketId);

        venueEndpoint.pricingQueue(symbol, securityType)
                 .add(snapshot);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "GB:lg-fastc";
        sorEndpoint.tradingRequest().add(heartbeat);

        final String clOrdId = "34567";
        final OrderType orderType = OrderType.LIMIT;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 1.2320;
        final double quantity = 1000000;
        final TimeInForce timeInForce = TimeInForce.IOC;
        final String sndrCompId = "FXTrader.GB.anufriea.XEFX";
        final String targetCompId = "GB:fox";

        final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
        order.body.senderCompId = sndrCompId;
        order.body.targetCompId = targetCompId;
        order.body.transactTime = acceptanceContext.precisionClock().nanos();
        order.body.timeInForce = timeInForce;
        order.body.orderQty = quantity;
        order.body.clOrdId = clOrdId;
        order.body.currency = currency;
        order.body.ordType = orderType;
        order.body.price = price;
        order.body.targetStrategyName = "Sweeper";
        order.body.securityType = instrumentKey.securityType();
        order.body.settlCurrency = currency;
        order.body.side = side;
        order.body.symbol = instrumentKey.symbol();
        order.body.settlType = instrumentKey.tenor();
        order.parties.add(new Party(PartyRole.USER_NAME, "autotrader-MidHedger"));
        order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
        order.strategyParameters.add(new StrategyParameter("Markets", "FAST"));

        sorEndpoint.tradingRequest().add(order);

        snapshots.forEach((venue, snapshotFullRefresh) -> {
            Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                    .matching(SnapshotFullRefreshMatcher.build()
                            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(snapshotFullRefresh.body.senderCompId))
                            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(venue))
                            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId())))
                    .awaitMatchAndGetLast(15, TimeUnit.SECONDS);
        });

        final VenueEndpoint fastVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.FAST);

        final TradingMessage venueNos = Asserter.of(fastVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(orderType))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
        fastVenue.tradingRequest().clear();

        final TradingMessage sorNewER = Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.targetCompId().eq(sndrCompId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.price().eq(order.body.price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(ExecutionReportMatcher.currency().eq(order.body.currency))
                        .body().matches(ExecutionReportMatcher.side().eq(order.body.side))
                        .body().matches(ExecutionReportMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        sorNewER.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onExecutionReport(final ExecutionReport parentER) {
                //send an order cancel request
                final OrderCancelRequest orderCancelRequest = sorEndpoint.createOrderCancelRequest();
                orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
                orderCancelRequest.body.orderQty = quantity;
                orderCancelRequest.body.clOrdId = clOrdId;
                orderCancelRequest.body.orderId = parentER.body.orderId;
                orderCancelRequest.body.origClOrdId = parentER.body.clOrdId;
                orderCancelRequest.body.clOrdLinkId = parentER.body.clOrdId;
                orderCancelRequest.body.securityType = securityType;
                orderCancelRequest.body.senderCompId = sndrCompId;
                orderCancelRequest.body.targetCompId = targetCompId;
                orderCancelRequest.body.side = side;
                orderCancelRequest.body.symbol = symbol;

                LOGGER.info(orderCancelRequest.toString());
                LOGGER.info("==============================================================");
                sorEndpoint.tradingRequest().add(orderCancelRequest);

            }
        });

        //Expect orderCancelRequest on FAST venue
        final TradingMessage venueOcr = Asserter.of(fastVenue.tradingRequest())
                .matching(OrderCancelRequestMatcher.build()
                        .body().matches(OrderCancelRequestMatcher.senderCompId().eq("GB:fox"))
                        .body().matches(OrderCancelRequestMatcher.marketId().eq("FAST"))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueOcr.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onOrderCancelRequest(final OrderCancelRequest ocr) {

                final ExecutionReport executionReport1 = fastVenue.createExecutionReport();
                executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport1.body.marketId = ocr.body.marketId;
                executionReport1.body.orderQty = ocr.body.orderQty;
                executionReport1.body.orderId = "907";
                executionReport1.body.clOrdId = ocr.body.clOrdId;
                executionReport1.body.origClOrdId = ocr.body.origClOrdId;
                executionReport1.body.clOrdLinkId = ocr.body.clOrdLinkId;
                executionReport1.body.execId = "4568";
                executionReport1.body.securityType = ocr.body.securityType;
                executionReport1.body.senderCompId = "GB:lg-fast";
                executionReport1.body.side = ocr.body.side;
                executionReport1.body.symbol = ocr.body.symbol;
                executionReport1.body.execType = ExecType.CANCELED;
                executionReport1.body.ordStatus = OrderStatus.CANCELED;
                executionReport1.body.leavesQty = 0;
                executionReport1.body.cumQty = 0;
                executionReport1.body.lastQty = 0;
                executionReport1.body.lastPx = 0;

                fastVenue.tradingResponse().add(executionReport1);
            }
        });


        final TradingMessage parentPendingCancel = Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                    .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                    .body().matches(ExecutionReportMatcher.marketId().eq("FOX"))
                    .body().matches(ExecutionReportMatcher.execType().eq(ExecType.PENDING_CANCEL))
                    .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PENDING_CANCEL)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);


        Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }
}
