package com.anz.markets.efx.ngaro.sbe;

/**
 * Interface implemented by enums to enforce the correct order when encoding or decoding SBE messages.
 * Groups and Data elements must be encoded and decoded in the definition order in SBE.
 */
public interface EncodingOrder<E extends Enum<E> & EncodingOrder<E>> {

    int ordinal();

    default void checkStrict(final E requiredSegment) {
        if (this == requiredSegment) {
            return;
        }
        throw new IllegalStateException("Out of order encoding or decoding, current is " + this + " but strictly required is " + requiredSegment);
    }

    default E checkAllowMoveToNext(final E requiredSegment) {
        if (this == requiredSegment) {
            return requiredSegment;
        }
        //allow transition to next
        if (this.ordinal() + 1 == requiredSegment.ordinal()) {
            return requiredSegment;
        }
        throw new IllegalStateException("Out of order encoding or decoding, current is " + this + " but required is " + requiredSegment);
    }
}
