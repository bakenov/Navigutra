package com.anz.markets.efx.fox.receiver;

import java.io.InputStream;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.instrument.config.InstrumentConfig;
import com.anz.markets.efx.ngaro.api.InstrumentKey;

public class InstrumentConfigLoader implements Runnable {
    private final InstrumentConfig instrumentConfig;
    private final SorEncoderSupplier encoderSupplier;

    public InstrumentConfigLoader(final String fileName, final SorEncoderSupplier encoderSupplier) {
        final InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(Objects.requireNonNull(fileName));
        this.instrumentConfig = InstrumentConfig.yaml().load(inputStream);
        this.encoderSupplier = Objects.requireNonNull(encoderSupplier);
    }

    @Override
    public void run() {
        instrumentConfig.getSecurityTypes().forEach((securityType, instrumentGroups) -> {
            instrumentGroups.getInstrumentGroups().forEach(instrumentGroup -> {
                instrumentGroup.getSymbols().forEach(symbol -> {
                    instrumentGroup.getTenors().forEach(tenor -> {
                        encoderSupplier.instrumentConfig().messageStart(0,0)
                                .instrumentId(InstrumentKey.instrumentId(symbol, securityType, tenor))
                                .pipSizeDivisor(instrumentGroup.getPipSizeDivisor())
                                .enabled(instrumentGroup.isEnabled())
                                .messageComplete();
                    });
                });
            });
        });
    }
}
