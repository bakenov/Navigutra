package software.chronicle.fix;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.ClientMessageNotifier;
import software.chronicle.fix.ServerMessageNotifier;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.FixInstance;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created by Rob Austin
 */
public class ConnectorMain {

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                ClientMessageNotifier.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main(String[] args) throws IOException, InterruptedException {

        // clean up from the last run
        IOTools.deleteDirWithFiles("connector");

        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        TCPRegistry.reset();
        TCPRegistry.setAlias("host.port", "localhost", 8090);

        /// --- initiator

        final FixEngineCfg initiatorCfg = Marshallable.fromFile("fix-initiator-config.yaml");

        // check we receive an execution report with senderCompID of CLIENT1
        check(initiatorCfg, "CLIENT1");

        // check we receive an execution report with senderCompID of CLIENT2
        check(initiatorCfg, "CLIENT2");

        // check we receive an execution report with senderCompID of CLIENT2
        check(initiatorCfg, "CLIENT3");
    }

    private static void check(final FixEngineCfg cfg, String senderCompID) throws InterruptedException, IOException {
        FixSessionCfg fixSessionCfg = getFixSessionCfg(cfg, senderCompID);
        try (final Closeable ignore = FixInstance.fixEngineMain(fixSessionCfg.hostId(), cfg)) {
            String executionReport = ((ClientMessageNotifier) fixSessionCfg.messageNotifier()).queue().poll(15, TimeUnit.SECONDS);
            assert executionReport.contains("targetCompID: " + senderCompID);
        }
    }

    @NotNull
    private static FixSessionCfg getFixSessionCfg(FixEngineCfg cfg, String senderCompID) {
        return cfg.fixSessionCfgs().stream().filter(c -> senderCompID.equals(c.senderCompID())).findFirst().get();
    }

}

