#!/bin/bash

scp clean-olddata-functions.sh axle@$1:/var/tmp
ssh axle@$1 "/var/tmp/clean-olddata-functions.sh $2"

