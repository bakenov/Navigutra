package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public interface Rule {
    Rule NOT_FOUND = new Rule() {
        @Override
        public boolean validate(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
            return false;
        }

        @Override
        public String description() {
            return "Rule not found";
        }
    };

    boolean validate(NewOrderSingleDecoder newOrderSingle, long currentTimeNanos);

    String description();

    interface Matcher {
        Rule match(NewOrderSingleDecoder newOrderSingle);
    }
}
