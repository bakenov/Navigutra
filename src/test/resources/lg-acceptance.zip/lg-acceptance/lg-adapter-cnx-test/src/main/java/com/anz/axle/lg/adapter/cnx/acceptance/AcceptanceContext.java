package com.anz.axle.lg.adapter.cnx.acceptance;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.quickfix.FixMessageSender;

public interface AcceptanceContext extends SharedAcceptanceContext {
    FixMessageSender fixMessageSender();
}
