package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class DbsMarketDataSubscription implements MarketDataSubscription {
    private final String symbol;
    private final Venue venue;
    private final InstrumentKey instrumentKey;
    private final StringToIntCache stringToIntCache;

    public DbsMarketDataSubscription(final String symbol,
                                     final SecurityType securityType,
                                     final Tenor tenor,
                                     final Venue venue,
                                     final StringToIntCache stringToIntCache) {
        this.symbol = Objects.requireNonNull(symbol);
        this.venue = Objects.requireNonNull(venue);
        this.stringToIntCache = Objects.requireNonNull(stringToIntCache);
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), securityType, tenor);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return venue;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public boolean fullRefresh() {
        return false;
    }

    @Override
    public boolean aggregateBook() {
        return false;
    }

    @Override
    public int marketDepth() {
        return 0;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return stringToIntCache;
    }

    @Override
    public String toString() {
        return "DbsMarketDataSubscription{" +
                "id=" + id() +
                ", instrumentKey=" + instrumentKey +
                ", venue='" + venue + '\'' +
                '}';
    }
}
