package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;

import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

/**
 * Non-thread-safe
 */
public class DefaultTimeInForceTimer implements TimeInForceTimer {
    private final TimerScheduler timerScheduler;
    private final TimeInForceTimerConfig timeInForceTimerConfig;
    private final TimerScheduler.ExpiryHandler expiryHandler;

    private long timerId = -1;
    private long timeoutMillis = 0;

    public DefaultTimeInForceTimer(final TimerScheduler timerScheduler,
                                   final TimeInForceTimerConfig timeInForceTimerConfig,
                                   final TimerScheduler.ExpiryHandler expiryHandler) {
        this.timerScheduler = Objects.requireNonNull(timerScheduler);
        this.timeInForceTimerConfig = Objects.requireNonNull(timeInForceTimerConfig);
        this.expiryHandler = Objects.requireNonNull(expiryHandler);
    }

    @Override
    public void schedule() {
        if (timeoutMillis > 0) {
            timerId = timerScheduler.schedule(timeoutMillis, expiryHandler);
        }
    }

    @Override
    public void cancel() {
        if (timerId >= 0) {
            if (timerScheduler.cancel(timerId)) {
                timerId = -1;
            }
        }
    }

    @Override
    public void reset(final TimeInForce timeInForce) {
        cancel();
        timeoutMillis = timeInForceTimerConfig.millis(expiryHandler.timerGroup(), timeInForce);
    }
}
