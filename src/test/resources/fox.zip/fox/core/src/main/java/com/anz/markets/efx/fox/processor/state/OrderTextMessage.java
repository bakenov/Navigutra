package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;

public enum OrderTextMessage {

    EMPTY(0, ""),
    UNKNOWN_ORDER(1, "Unknown order"),
    FILLED_WHILE_BEING_CANCELED(2, "Filled while being canceled"),
    UNSOLICITED_CANCEL(3, "Unsolicited cancel"),
    CANCEL_REQUESTED_BY_USER(4, "Cancel requested by client"),
    UNKNOWN_STRATEGY(5, "Unknown strategy"),
    DISABLED_INSTRUMENT(6, "Disabled instrument"),
    UNKNOWN_INSTRUMENT(7, "Unknown instrument"),
    NO_ENABLED_VENUES(8, "There is no at least 1 configured, enabled and online venue in Markets strategy parameter"),
    INVALID_QUANTITY(9, "Invalid order quantity"),
    INVALID_ORDER_TYPE(10,"Invalid OrderType"),
    INVALID_TIMEINFORCE(11,"Invalid TimeInForce"),
    INVALID_SENDERCOMPID(12,"Invalid senderCompId"),
    UNKNOWN_USER_IN_SENDERCOMPID(13,"Unknown userName in senderCompId");

    private final int       messageId;
    private final String    messageText;


    OrderTextMessage(final int id, final String text) {
        this.messageId = Objects.requireNonNull(id);
        this.messageText = Objects.requireNonNull(text);
    }

    public int  getId() { return messageId; }

    public String getText() { return messageText; }
}
