package com.anz.axle.lg.adapter.bgc.quickfix;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Sets;
import quickfix.Message;
import quickfix.field.BidPx;
import quickfix.field.OfferPx;
import quickfix.field.Symbol;

import com.anz.axle.lg.adapter.PriceRounder;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BgcSnapshotFullRefreshHandlerTest {
    private PriceRounder priceRounder;

    final private List<Message> quotes = new ArrayList<>();
    private BgcSnapshotFullRefreshHandler bgcSnapshotFullRefreshHandler;

    @Before
    public void setUp() throws Exception {

        final Map<Integer, Set<String>> symbolDecimalPlaceToRound = new HashMap<>();
        symbolDecimalPlaceToRound.put(3, Sets.newHashSet("EURJPY", "USDJPY", "EURHUF"));
        priceRounder = new PriceRounder(symbolDecimalPlaceToRound, 5);

        bgcSnapshotFullRefreshHandler = new BgcSnapshotFullRefreshHandler(m -> quotes.add(m), priceRounder, new DefaultInstrumentKeyLookup());
    }

    @Test
    public void round_price_to_3_decimal_place() throws Exception {
        final InstrumentKey instrumentKey = InstrumentKey.of("EURJPY", SecurityType.FXSPOT, Tenor.SP);

        final SnapshotFullRefreshHandler.Body body = mock(SnapshotFullRefreshHandler.Body.class);
        when(body.instrumentId()).thenReturn(instrumentKey.instrumentId());
        when(body.sendingTime()).thenReturn(0l);

        final SnapshotFullRefreshHandler.MdEntries.Body entry0 = mock(SnapshotFullRefreshHandler.MdEntries.Body.class);
        when(entry0.mdEntryType()).thenReturn(EntryType.BID);
        when(entry0.mdEntryPx()).thenReturn(0.12345d);
        when(entry0.mdEntrySize()).thenReturn(1.0d);

        final SnapshotFullRefreshHandler.MdEntries.Body entry1 = mock(SnapshotFullRefreshHandler.MdEntries.Body.class);
        when(entry1.mdEntryType()).thenReturn(EntryType.OFFER);
        when(entry1.mdEntryPx()).thenReturn(0.13345d);
        when(entry1.mdEntrySize()).thenReturn(2.0d);

        bgcSnapshotFullRefreshHandler.onMessageStart(0, 0);
        bgcSnapshotFullRefreshHandler.onBody(body);
        bgcSnapshotFullRefreshHandler.onMdEntries_Body(entry0, 0, 2);
        bgcSnapshotFullRefreshHandler.onMdEntries_Body(entry1, 1, 2);

        bgcSnapshotFullRefreshHandler.onMdEntriesComplete(2);
        bgcSnapshotFullRefreshHandler.onMessageComplete();

        assertThat(quotes.size(), is(1));
        final Message quote = quotes.get(0);

        assertThat(quote.getString(Symbol.FIELD), is("EUR/JPY"));

        assertThat(quote.getDouble(BidPx.FIELD), is(0.123d));
        assertThat(quote.getDouble(OfferPx.FIELD), is(0.134d));
    }

    @Test
    public void round_price_to_default_5_decimal_place() throws Exception {
        final InstrumentKey instrumentKey = InstrumentKey.of("USDAUD", SecurityType.FXSPOT, Tenor.SP);

        final SnapshotFullRefreshHandler.Body body = mock(SnapshotFullRefreshHandler.Body.class);
        when(body.instrumentId()).thenReturn(instrumentKey.instrumentId());
        when(body.sendingTime()).thenReturn(0l);

        final SnapshotFullRefreshHandler.MdEntries.Body entry0 = mock(SnapshotFullRefreshHandler.MdEntries.Body.class);
        when(entry0.mdEntryType()).thenReturn(EntryType.BID);
        when(entry0.mdEntryPx()).thenReturn(0.12345678d);
        when(entry0.mdEntrySize()).thenReturn(1.0d);

        final SnapshotFullRefreshHandler.MdEntries.Body entry1 = mock(SnapshotFullRefreshHandler.MdEntries.Body.class);
        when(entry1.mdEntryType()).thenReturn(EntryType.OFFER);
        when(entry1.mdEntryPx()).thenReturn(0.12345678d);
        when(entry1.mdEntrySize()).thenReturn(2.0d);

        bgcSnapshotFullRefreshHandler.onMessageStart(0, 0);
        bgcSnapshotFullRefreshHandler.onBody(body);
        bgcSnapshotFullRefreshHandler.onMdEntries_Body(entry0, 0, 2);
        bgcSnapshotFullRefreshHandler.onMdEntries_Body(entry1, 1, 2);

        bgcSnapshotFullRefreshHandler.onMdEntriesComplete(2);
        bgcSnapshotFullRefreshHandler.onMessageComplete();

        assertThat(quotes.size(), is(1));
        final Message quote = quotes.get(0);

        assertThat(quote.getString(Symbol.FIELD), is("USD/AUD"));

        assertThat(quote.getDouble(BidPx.FIELD), is(0.12345d));
        assertThat(quote.getDouble(OfferPx.FIELD), is(0.12346d));
    }
}