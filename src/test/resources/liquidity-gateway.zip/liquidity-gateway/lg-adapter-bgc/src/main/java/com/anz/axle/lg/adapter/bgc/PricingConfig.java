package com.anz.axle.lg.adapter.bgc;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingHandlerSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;

@Configuration
public class PricingConfig {

    @Bean
    public VenueRequestKeyLookup requestKeyLookup(@Value("${bgc.subscription.market}") final Venue market) {
        return new DefaultVenueRequestKeyLookup(market);
    }

    @Bean
    public PricingHandlerSupplier pricingHandlerSupplier(@Value("${stale.price.timestamp.offset.milliseconds}") final long stalePriceTimestampOffsetMilliseconds,
                                                         @Value("${initial.book.entries:100}") final int initialBookEntries,
                                                         final VenueRequestKeyLookup requestKeyLookup,
                                                         final PrecisionClock precisionClock,
                                                         final SnapshotFullRefreshHandler bgcSnapshotFullRefreshHandler) {

        final SnapshotterDecoderLookup snapshotterDecoderLookup = new DefaultSnapshotterDecoderLookup(
                requestKeyLookup,
                SnapshotterDecoderSupplier.create(
                        SnapshotterDecoderSupplier.createBuilder(initialBookEntries, bgcSnapshotFullRefreshHandler, precisionClock, stalePriceTimestampOffsetMilliseconds),
                        UpdateTypeMismatchHandler.IGNORE_REPLACE_ON_ADD_AND_NOOP_ON_REMOVE)
        );

        return PricingHandlerSupplier.snapshotFullRefresh(() -> new UpstreamSnapshotFullRefreshHandlerRouter(snapshotterDecoderLookup));
    }
}
