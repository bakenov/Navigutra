package com.anz.axle.lg.adapter.ebs.acceptance;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceConfig;
import com.anz.axle.lg.adapter.ebs.ServerConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({ServerConfig.class, SharedAcceptanceConfig.class})
public class AcceptanceConfig {
}