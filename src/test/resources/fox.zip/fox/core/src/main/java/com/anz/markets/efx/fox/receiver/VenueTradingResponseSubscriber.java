package com.anz.markets.efx.fox.receiver;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Subscription;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.api.Venue;

public class VenueTradingResponseSubscriber implements VenueSubscriber {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueTradingResponseSubscriber.class);

    private final Connection connection;
    private final EndPointStatusHandler endPointStatusHandler;
    private final MessageHandler messageHandler;
    private final String venueTradingResponseTopicSuffix;

    public VenueTradingResponseSubscriber(final Connection connection,
                                          final EndPointStatusHandler endPointStatusHandler,
                                          final MessageHandler messageHandler,
                                          final String venueTradingResponseTopicSuffix) {
        this.connection = Objects.requireNonNull(connection);
        this.messageHandler = Objects.requireNonNull(messageHandler);
        this.endPointStatusHandler = Objects.requireNonNull(endPointStatusHandler);
        this.venueTradingResponseTopicSuffix = venueTradingResponseTopicSuffix;
    }

    @Override
    public Subscription subscribe(final Venue venue) {
        final Topic tradingResponsesTopic = DefaultTopic.create(venue.name() + venueTradingResponseTopicSuffix);
        final Subscription subscription = connection.openSubscription(tradingResponsesTopic, endPointStatusHandler, messageHandler);
        LOGGER.info("Subscribed for {}", tradingResponsesTopic);
        return subscription;
    }
}
