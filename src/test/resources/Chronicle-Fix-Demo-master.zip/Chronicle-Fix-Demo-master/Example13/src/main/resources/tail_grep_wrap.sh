IFS=$'\n'
tail -f ingest_splunk.json | grep --line-buffered "$1" | while read LINE0
do
  # wrap with { } to make valid json to keep splunk happy
  echo "{ $LINE0 }" >> ingest_splunk_$2.json
done