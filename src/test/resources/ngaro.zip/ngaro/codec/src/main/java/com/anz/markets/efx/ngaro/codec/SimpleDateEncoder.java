package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

@Garbage(Garbage.Type.ANY)
public final class SimpleDateEncoder<E> implements DateEncoder<E> {

    private final E enclosingEncoder;
    private final Consumer<? super LocalDate> setter;

    public SimpleDateEncoder(final E enclosingEncoder, final Consumer<? super LocalDate> setter) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.setter = Objects.requireNonNull(setter);
    }

    @Override
    public E encodeNull() {
        setter.accept(null);
        return enclosingEncoder;
    }

    @Override
    public E encode(final int year, final int month, final int day) {
        return encodeNullable(year == 0 & month == 0 & day == 0 ? null : LocalDate.of(year, month, day));
    }

    @Override
    public E encodeEpochDays(final long epochDays) {
        return epochDays == 0 ? encodeNull() : encode(LocalDatePacking.BINARY, Epoch.fromEpochDays(LocalDatePacking.BINARY, epochDays));
    }

    @Override
    public E encodeNullable(final LocalDate localDate) {
        setter.accept(localDate);
        return enclosingEncoder;
    }

    @Override
    public E encodeFrom(final DateDecoder localDateDecoder) {
        return encodeNullable(localDateDecoder.decodeLocalDateOrNull());
    }
}
