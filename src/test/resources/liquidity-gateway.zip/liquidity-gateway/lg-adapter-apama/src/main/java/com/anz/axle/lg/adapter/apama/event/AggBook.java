package com.anz.axle.lg.adapter.apama.event;

import java.util.List;

import com.apama.event.Event;
import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;
import com.apama.event.parser.FloatFieldType;
import com.apama.event.parser.IntegerFieldType;
import com.apama.event.parser.SequenceFieldType;
import com.apama.event.parser.StringFieldType;

public class AggBook {
    public static final String AGG_BOOK_EVENT_NAME = "anz.AggBook";
    public static final String AGG_BOOK_ENTRY_EVENT_NAME = "anz.Entry";

    public static final Field<Double> FIELD_TRANSACT_TIME = new Field<>("transactTime", FloatFieldType.TYPE);
    public static final Field<Long> FIELD_MARKET_INDEX = new Field("marketIndex", IntegerFieldType.TYPE);
    public static final Field<Double> FIELD_PRICE = new Field("price", FloatFieldType.TYPE);
    public static final Field<Double> FIELD_QUANTITY = new Field("quantity", FloatFieldType.TYPE);
    public static final Field<Long> FIELD_FLAGS = new Field<>("flags", IntegerFieldType.TYPE);
    public static final Field<String> FIELD_QUOTE_ID = new Field("quoteId", StringFieldType.TYPE);

    public static final EventType ENTRY_EVENT_TYPE = aggBookEntry();

    public static final Field<String> FIELD_SENDER_COMP_ID = new Field<>("senderCompId", StringFieldType.TYPE);
    public static final Field<Long> FIELD_MESSAGE_ID = new Field<>("messageId", IntegerFieldType.TYPE);
    public static final Field<Double> FIELD_SENDING_TIME = new Field<>("sendingTime", FloatFieldType.TYPE);
    public static final Field<String> FIELD_SYMBOL = new Field<>("symbol", StringFieldType.TYPE);
    public static final Field<List<String>> FIELD_MARKETS = new Field<>("markets", new SequenceFieldType<>(StringFieldType.TYPE));
    public static final Field<List<Event>> FIELD_BIDS = new Field<>("bids", new SequenceFieldType<>(ENTRY_EVENT_TYPE));
    public static final Field<List<Event>> FIELD_ASKS = new Field<>("asks", new SequenceFieldType<>(ENTRY_EVENT_TYPE));

    public static final EventType EVENT_TYPE = aggBook();

    private static EventType aggBook() {
        return new EventType(AGG_BOOK_EVENT_NAME,
                FIELD_SENDER_COMP_ID,
                FIELD_MESSAGE_ID,
                FIELD_SENDING_TIME,
                FIELD_SYMBOL,
                FIELD_MARKETS,
                FIELD_FLAGS,
                FIELD_BIDS,
                FIELD_ASKS
                );
    }

    private static EventType aggBookEntry() {
        return new EventType(AGG_BOOK_ENTRY_EVENT_NAME,
                FIELD_TRANSACT_TIME,
                FIELD_MARKET_INDEX,
                FIELD_PRICE,
                FIELD_QUANTITY,
                FIELD_FLAGS,
                FIELD_QUOTE_ID
                );
    }
}
