package com.anz.markets.prophet.config.business.domain.tabular.impl;


import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MarketType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
public class MarketConfigImpl implements MarketConfig, ProphetMarshallable {

    private Market market;
    private Instrument instrument;
    private boolean enabled;
    private Region region;
    private double stepSizePips = 0.1d;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public MarketConfigImpl() {
    }

    public MarketConfigImpl(final Market market) {
        this.market = market;
    }

    public MarketConfigImpl setInstrument(final Instrument instrument) {
        this.instrument = instrument;
        return this;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public Region getRegion() {
        return region;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public double getStepSizePips() {
        return stepSizePips;
    }

    public MarketConfigImpl setEnabled(final boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public MarketConfigImpl setRegion(final Region region) {
        this.region = region;
        return this;
    }

    public MarketConfigImpl setStepSizePips(final double stepSizePips) {
        this.stepSizePips = stepSizePips;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        // old style FieldReflectionBytesMarshallable.
        Context.context().header().before(MessageVersion.VERSION_0_25, () -> {
            market = in.readEnum(Market.class);
            instrument = in.readEnum(Instrument.class);
            enabled = in.readBoolean();
            in.readBoolean();  // was primary
            in.readEnum(MarketType.class);  // was marketType
            region = in.readEnum(Region.class);
        });

        // new style
        Context.context().header().sinceButBefore(MessageVersion.VERSION_0_25,MessageVersion.VERSION_0_86,
                () -> {
                    market = Market.valueOf(in.readByte());
                    instrument = Instrument.valueOf(in.readByte());
                    enabled = in.readBoolean();
                    in.readBoolean();  // was primary
                    MarketType.valueOf(in.readByte());  // was marketType
                    region = Region.valueOf(in.readByte());
                    in.readBoolean();  // was reference
                }
        );

        Context.context().header().since(MessageVersion.VERSION_0_86, () -> {
            market = Market.valueOf(in.readByte());
            instrument = Instrument.readMarshallableValueOf(in);
            enabled = in.readBoolean();
            region = Region.valueOf(in.readByte());
            stepSizePips = in.readDouble();
        });

    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(market.getValue());
        out.writeShort(instrument.getValue());
        out.writeBoolean(enabled);
        out.writeByte(region.getValue());
        out.writeDouble(stepSizePips);
    }

    @Override
    public String toString() {
        return "MarketConfigImpl{" +
                "enabled=" + enabled +
                ", market=" + market +
                ", instrument=" + instrument +
                ", region=" + region +
                ", stepSizePips=" + stepSizePips +
                '}';
    }
}
