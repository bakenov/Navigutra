#!/bin/bash
# -*- sh -*-
source ~/axle/environment/shell/axle.rc &> /dev/null

: << =cut

=head1 NAME

datafabric9 - Plugin to monitor the Datafabric

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=datafabric
 #%# capabilities=autoconf

=cut

HOME_DATACENTRE=${datafabric.node}
REMOTE_DATACENTRE1=${datafabric.remote1.node}
REMOTE_DATACENTRE2=${datafabric.remote2.node}

HOME_DATACENTRE_SHORT=`echo $HOME_DATACENTRE | awk -F. '{ print $1"."$2 }'`
REMOTE_DATACENTRE1_SHORT=`echo $REMOTE_DATACENTRE1 | awk -F. '{ print $(NF); }'`
REMOTE_DATACENTRE2_SHORT=`echo $REMOTE_DATACENTRE2 | awk -F. '{ print $(NF); }'`

if [ "$1" = "autoconf" ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Datafabric 9 -' $HOME_DATACENTRE '- Gateway Distributed Events Timers (ms)'
    echo 'graph_category datafabric'
    echo 'graph_scale no'
    echo 'df9_1.label '$HOME_DATACENTRE_SHORT ' - ' $REMOTE_DATACENTRE1_SHORT ' Batch Distribution'
    echo 'df9_1.draw LINE2'
    echo 'df9_2.label '$HOME_DATACENTRE_SHORT ' - ' $REMOTE_DATACENTRE2_SHORT ' Batch Distribution'
    echo 'df9_2.draw LINE2'
    exit 0
fi

function emptyRecord() {
  echo 'df9_1.value U'
  echo 'df9_2.value U'
}

GEMFIRE_HOME=~/gemfire
LOGS=~/axle/datafabric/logs
if [ -f /etc/redhat-release ] ; then
    DATEPATH=date
    AWKPATH=awk
else
    DATEPATH=/opt/sfw/bin/date
    AWKPATH=/usr/xpg4/bin/awk
fi

LATEST_DAT=`ls -ltr $LOGS/ | grep .dat | grep "$HOME_DATACENTRE.statistics-" | tr -s ' ' | tail -1 | awk -F' ' '{ print $(NF); }'`
LATEST_DAT_FILE=$LOGS/$LATEST_DAT

if [ "$LATEST_DAT_FILE" == "" ]; then
  emptyRecord
  exit 0
fi

# Munin plugins are executed every 5 minutes (production setting as of 2015-06-02)
# In case this changes, be sure to adjust the extract reuse and the stat sweep windows below (in all fabric plugins)

LATEST_DAT=`ls -ltr $LOGS/ | grep .dat | grep "$HOME_DATACENTRE.statistics-" | tr -s ' ' | tail -1 | awk -F' ' '{ print $(NF); }'`
LATEST_DAT_FILE=$LOGS/$LATEST_DAT
# Reuse stat extract if it was created within the last 1.5 minutes - this number is based on below:
#  - the plugin is executed every 5 minutes (dictated by the master)
#  - it takes around 3 minutes to produce the file (in the lab)
#  - deduct a further half minute to not to overlap with the next schedule
STATS_FILE="`find -L $LOGS -cmin -1.5 -type f -name "${HOME_DATACENTRE}.statreport-*.txt" | sort | tail -1`"

if [ "$LATEST_DAT_FILE" == "" ] && [ "$STATS_FILE" == "" ]; then
  emptyRecord
  exit 0
fi

# Refresh the cache - this is a very resource intensive operation
if [ "$STATS_FILE" == "" ]; then
  TIME_STAMP=`$DATEPATH -u '+%Y-%m-%d_%H-%M-00'`
  STATS_FILE=$LOGS/$HOME_DATACENTRE.statreport-$TIME_STAMP.txt
  # use a 5 minute period up until the start of the present minute
  TIME_FROM=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC' --date '-5 min'`
  TIME_UNTIL=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC'`
  DF_STAT_EXTRACT_CMD="${GEMFIRE_HOME}/bin/gemfire stats -starttime=\"${TIME_FROM}\" -endtime=\"${TIME_UNTIL}\" -archive=\"${LATEST_DAT_FILE}\" -persec"

  $DF_STAT_EXTRACT_CMD > "$STATS_FILE"
fi

# If there are no data, bail out honouring semantics
if [ ! -s "$STATS_FILE" ]; then
  emptyRecord
  exit 0
fi

egrep "(gatewayStats|batchDistributionTime|batchesDistributed)" $STATS_FILE | $AWKPATH -F' ' -v HOME_DATACENTRE_SHORT="$HOME_DATACENTRE_SHORT" -v REMOTE_DATACENTRE1="$REMOTE_DATACENTRE1" -v REMOTE_DATACENTRE2="$REMOTE_DATACENTRE2" -v REMOTE_DATACENTRE3="$REMOTE_DATACENTRE3" '
BEGIN {
  lookingfor["gatewayStats-"HOME_DATACENTRE_SHORT"-"REMOTE_DATACENTRE1".rollup:batchDistributionTime:average"] = "df9_1bdt";
  lookingfor["gatewayStats-"HOME_DATACENTRE_SHORT"-"REMOTE_DATACENTRE2".rollup:batchDistributionTime:average"] = "df9_2bdt";
  lookingfor["gatewayStats-"HOME_DATACENTRE_SHORT"-"REMOTE_DATACENTRE1".rollup:batchesDistributed:average"] = "df9_1bd";
  lookingfor["gatewayStats-"HOME_DATACENTRE_SHORT"-"REMOTE_DATACENTRE2".rollup:batchesDistributed:average"] = "df9_2bd";
}
/^[a-zA-Z]/ {
  section  = substr($0,1,index($0,",")-1);
}
/^  / {
  statistic = $1;
  for (i=2; i<=NF; i++) {
    fieldandvalue = $i;
    equals = index(fieldandvalue,"=");
    if (equals > 0) {
      fieldname = substr(fieldandvalue,1,equals-1);
      value = substr(fieldandvalue,equals+1);
      outputname = lookingfor[section ":" statistic ":" fieldname];
      if (outputname != "") {
        values[outputname] = value;
      }
    }
  }
}
END {
  if (values["df9_1bd"] > 0) { print "df9_1.value " (values["df9_1bdt"] / 1000000) / values["df9_1bd"] } else { print "df9_1.value U"; }
  if (values["df9_2bd"] > 0) { print "df9_2.value " (values["df9_2bdt"] / 1000000) / values["df9_2bd"] } else { print "df9_2.value U"; }
  if (values["df9_3bd"] > 0) { print "df9_3.value " (values["df9_3bdt"] / 1000000) / values["df9_3bd"] } else { print "df9_3.value U"; }
}
'
