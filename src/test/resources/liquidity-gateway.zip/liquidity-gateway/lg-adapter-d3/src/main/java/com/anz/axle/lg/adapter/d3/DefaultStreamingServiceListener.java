package com.anz.axle.lg.adapter.d3;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.StreamingServiceListener;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.lg.adapter.d3.newsubscription.SubscriptionRegistry;
import com.anz.markets.efx.queue.Queue;

public final class DefaultStreamingServiceListener implements StreamingServiceListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultStreamingServiceListener.class);

    private final Queue.Appender<Runnable> runnableEventAppender;
    private final Queue.Appender<UpdateMessage> updateMessageAppender;
    private final SubscriptionRegistry subscriptionRegistry;

    public DefaultStreamingServiceListener(final Queue.Appender<Runnable> runnableEventAppender,
                                           final Queue.Appender<UpdateMessage> updateMessageAppender,
                                           final SubscriptionRegistry subscriptionRegistry) {
        this.runnableEventAppender = Objects.requireNonNull(runnableEventAppender);
        this.updateMessageAppender = Objects.requireNonNull(updateMessageAppender);
        this.subscriptionRegistry = Objects.requireNonNull(subscriptionRegistry);
    }

    @Override
    public void processUpdate(final UpdateMessage updateMessage) {
        updateMessageAppender.enqueue(updateMessage);
    }

    @Override
    public void processError(final ErrorMessage errorMessage) {
        runnableEventAppender.enqueue(() -> subscriptionRegistry.byIdLookup().lookup(Long.valueOf(errorMessage.getSubscriptionId())).processError(errorMessage));
    }

    @Override
    public void processServiceException(final Throwable throwable) {
        runnableEventAppender.enqueue(() -> subscriptionRegistry.errorAll(throwable.getMessage()));
    }
}
