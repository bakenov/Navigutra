package com.anz.markets.efx.fox.firewall.api;

public interface PropertyProvider {
}
