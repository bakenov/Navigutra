package com.anz.axle.lg.adapter.apama.transport;

public interface Transport {
    Connection openConnection(ConnectionConfig connectionConfig, ConnectionStatusHandler connectionStatusHandler);
}
