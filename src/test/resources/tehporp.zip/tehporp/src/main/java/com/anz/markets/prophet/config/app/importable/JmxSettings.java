package com.anz.markets.prophet.config.app.importable;

public class JmxSettings {
    final int portOffset;

    public JmxSettings(final int portOffset) {
        this.portOffset = portOffset;
    }
}
