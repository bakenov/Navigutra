package com.anz.markets.efx.fox.config;

import java.util.Queue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.BusySpinIdleStrategy;
import org.agrona.concurrent.OneToOneConcurrentArrayQueue;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.eventloop.IdleStrategyId;
import com.anz.markets.efx.fox.common.LoggingEndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.ngaro.api.InstrumentKey;

@Configuration
public class CommonConfig {
    @Bean
    public PrecisionClock systemPrecisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("async-%d").build());
    }

    @Bean
    public EndPointStatusHandler transportEndPointStatusHandler() {
        return new LoggingEndPointStatusHandler(LoggerFactory.getLogger(Transport.class));
    }

    public static Supplier<IdleStrategy> idleStrategyFactory(final IdleStrategyId idleStrategyId,
                                                      final long backOffMaxSpins,
                                                      final long backOffMaxYields,
                                                      final long backOffMaxParkPeriodUs) {
        return () -> {
            switch (idleStrategyId) {
                case BUSY_SPIN:
                    return adaptIdleStrategy(new BusySpinIdleStrategy());
                case BACK_OFF:
                    return adaptIdleStrategy(new BackoffIdleStrategy(backOffMaxSpins, backOffMaxYields, 1, TimeUnit.MICROSECONDS.toNanos(backOffMaxParkPeriodUs)));
                default:
                    throw new IllegalArgumentException("Unsupported idle strategy " + idleStrategyId);
            }
        };
    }

    static com.anz.markets.efx.eventloop.IdleStrategy adaptIdleStrategy(final org.agrona.concurrent.IdleStrategy strategy) {
        return com.anz.markets.efx.eventloop.IdleStrategy.create(strategy::idle, strategy::reset);
    }

    @Bean
    public Queue<InstrumentKey> pricingFeedRequestQueue(@Value("${pricing.feed.queue.size}") final int queueSize) {
        return new OneToOneConcurrentArrayQueue<>(queueSize);
    }
}
