package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.HeaderDecoder;

public interface InitialisationDecoder extends HeaderDecoder {
    Body body();
    void appendTo(StringBuilder stringBuilder);

    interface Body {
        InitStage initStage();
    }
}