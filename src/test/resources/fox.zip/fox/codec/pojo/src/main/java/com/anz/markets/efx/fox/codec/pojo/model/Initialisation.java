package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoInitialisationHandler;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class Initialisation implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public Initialisation() {
        this(new MessageHeader(), new Body());
    }

    public Initialisation(final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
    }

    public static final class Body {
        public InitStage initStage;

        public Body() {
            super();
        }

        public Body(final InitStage initStage) {
            this.initStage = initStage;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "initStage=" + initStage +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "Initialisation{" +
                "header=" + header +
                "body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.initialisation());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.initialisation().create(messageConsumer));
    }

    public void encode(final InitialisationEncoder encoder) {
        encoder.messageStart(header.source,header.sourceSeq)
                .initStage(body.initStage)
                .messageComplete();
    }

    public static <M> Initialisation decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoInitialisationHandler handler = new PojoInitialisationHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.initialisation().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onInitialisation(this);
    }
}
