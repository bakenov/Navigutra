package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chime.ChimeManager;
import com.anz.markets.prophet.chime.ChimeProducer;
import com.anz.markets.prophet.chime.OperatingHourChimeManager;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.starfish.StartTimeStamper;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceRealTime;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Arrays;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@EnableScheduling
@Configuration
public class SchedulingConfig {

    protected static final Logger LOGGER = LoggerFactory.getLogger(SchedulingConfig.class);

    @Autowired
    private Environment env;

    @Autowired
    @Qualifier("chimeManager")
    private ChimeManager chimeManagerLocal;

    @Bean
    public ScheduledExecutorService scheduledExecutions(
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister,
            final OperatingHourChimeManager operatingHourChimeManager) {
        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        final Main.RunProfile profile = Main.getProfile(env);
        if (!Main.RunProfile.ACCEPTANCE_TEST.equals(profile)) {
            final Consumer<OneSecond> oneSecondConsumer = new NotifierDefault<>(operatingHourChimeManager.consumerOfOneSecond(), StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.ONE_SECOND)));
            scheduler.scheduleAtFixedRate(() -> oneSecondConsumer.accept(OneSecond.INSTANCE), 0, 1, TimeUnit.SECONDS);
        }
        return scheduler;
    }

    @Bean
    public ChimeProducer tradingChimeProducer(
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister) {
        final Consumer<HourChime> recalibrateTimeSource = (Context.context().timeSource() instanceof TimeSourceRealTime) ?((TimeSourceRealTime) Context.context().timeSource()) : NoConsumer.instance();
        final ChimeProducer chimeProducer = new ChimeProducer(
                Arrays.asList(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.TIMEZONE_CHIME))),
                Arrays.asList(recalibrateTimeSource, StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.HOUR_CHIME))),
                Arrays.asList(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.END_OF_WEEK_CHIME))));
        return chimeProducer;
    }

    @Bean
    public ChimeManager chimeManager(final ChimeProducer chimeProducer) {
        return new ChimeManager(chimeProducer.consumerOfTradingTimeZoneChime(), chimeProducer.consumerOfHourChime(), chimeProducer.consumerOfEndOfWeekChime());
    }

    @NotGcFriendly("Creates new datetime each hour")
    @Scheduled(cron = "0 0 * * * ?", zone = "UTC")
    public void fireOneHourChime() {
        chimeManagerLocal.triggerUTCHourChime();
    }

    @Scheduled(cron = "0 0 17 * * FRI", zone = "America/New_York")
    public void fireEndOfWeekChime() {
        chimeManagerLocal.triggerEndOfWeekChime();
    }

    @Scheduled(cron = "0 0 17 * * TUE-THU", zone = "America/New_York")
    public void fireSpotDateRoll() {
        chimeManagerLocal.triggerSpotDateRollChime();
    }

    @Scheduled(cron = TradingTimeZone.CRON_SNG_MONDAY, zone = TradingTimeZone.CRON_SNG_MONDAY_TZ)
    public void fireSingaporeMondayTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneSingaporeMonday();
    }

    @Scheduled(cron = TradingTimeZone.CRON_SNG, zone = TradingTimeZone.CRON_SNG_TZ)
    public void fireSingaporeTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneSingapore();
    }

    @Scheduled(cron = TradingTimeZone.CRON_SNG_LDN, zone = TradingTimeZone.CRON_SNG_LDN_TZ)
    public void fireSingaporeLondonTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneSingaporeLondon();
    }

    @Scheduled(cron = TradingTimeZone.CRON_LDN, zone = TradingTimeZone.CRON_LDN_TZ)
    public void fireLondonTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneLondon();
    }

    @Scheduled(cron = TradingTimeZone.CRON_LDN_NYK, zone = TradingTimeZone.CRON_LDN_NYK_TZ)
    public void fireLondonNewYorkTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneLondonNewYork();
    }

    @Scheduled(cron = TradingTimeZone.CRON_NYK, zone = TradingTimeZone.CRON_NYK_TZ)
    public void fireNewYorkTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneNewYork();
    }

    @Scheduled(cron = TradingTimeZone.CRON_TWILIGHT_1, zone = TradingTimeZone.CRON_TWILIGHT_1_TZ)
    public void fireTwilightOneTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneTwilight();
    }

    @Scheduled(cron = TradingTimeZone.CRON_ROLL, zone = TradingTimeZone.CRON_ROLL_TZ)
    public void fireRollTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneRoll();
    }

    @Scheduled(cron = TradingTimeZone.CRON_TWILIGHT_2, zone = TradingTimeZone.CRON_TWILIGHT_2_TZ)
    public void fireTwilightTwoTradingTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneTwilight();
    }

    @Scheduled(cron = TradingTimeZone.CRON_NYC_FRI_ARVO, zone = TradingTimeZone.CRON_NYC_FRI_ARVO_TZ)
    public void fireSingaporeMondayTradingTimeZoneChimeOnFridayAfternoon() {
        chimeManagerLocal.triggerTimeZoneSingaporeMonday();
    }

    @Scheduled(cron = TradingTimeZone.CRON_WEEKEND, zone = TradingTimeZone.CRON_WEEKEND_TZ)
    public void fireWeekendTimeZoneChime() {
        chimeManagerLocal.triggerTimeZoneWeekend();
    }

    @Bean
    public OperatingHourChimeManager operatingHourChimeManager(final ConfigurationDataDefault configurationDataDefault,
                                                               final ProphetPersister prophetPersister) {
        final OperatingHourChimeManager manager = new OperatingHourChimeManager(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.OPERATING_HOUR_CHIME)));
        manager.consumerOfIndexedConfigurationData().accept(new IndexedConfigurationData(configurationDataDefault));
        return manager;
    }
}
