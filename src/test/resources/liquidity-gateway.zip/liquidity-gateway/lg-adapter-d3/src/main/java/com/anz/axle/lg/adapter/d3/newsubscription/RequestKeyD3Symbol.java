package com.anz.axle.lg.adapter.d3.newsubscription;

import java.util.Objects;
import java.util.function.Function;

import com.anz.axle.lg.adapter.d3.model.D3Codec;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class RequestKeyD3Symbol implements Function<RequestKey, String> {
    private final Function<Tenor, String> tenor2D3TenorName;
    private final String classification;

    public RequestKeyD3Symbol(final Function<Tenor, String> tenor2D3TenorName, final String classification) {
        this.tenor2D3TenorName = Objects.requireNonNull(tenor2D3TenorName);
        this.classification = Objects.requireNonNull(classification);
    }

    @Override
    public String apply(final RequestKey requestKey) {
        final String symbol = requestKey.instrumentKey().symbol();
        if (requestKey.instrumentKey().tenor() != Tenor.BROKEN) {
            return symbol + tenor2D3TenorName.apply(requestKey.instrumentKey().tenor() ) + "=" + classification;
        } else {
            if (requestKey.instrumentKey().settlementDate().isPresent()) {
                return symbol + D3Codec.formatDate(requestKey.instrumentKey().settlementDate().get()) + "=" + classification;
            } else {
                throw new IllegalStateException("No tenor and settlement date");
            }
        }
    }
}
