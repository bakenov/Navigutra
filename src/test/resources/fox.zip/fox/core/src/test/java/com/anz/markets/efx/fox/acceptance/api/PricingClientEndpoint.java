package com.anz.markets.efx.fox.acceptance.api;

import java.util.Queue;

import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;

public interface PricingClientEndpoint {
    boolean pollAll(long instrumentId);
    Queue<PricingMessage> polledSnapshots();
}
