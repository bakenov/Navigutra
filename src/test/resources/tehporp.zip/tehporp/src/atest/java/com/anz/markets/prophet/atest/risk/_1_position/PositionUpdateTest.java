package com.anz.markets.prophet.atest.risk._1_position;

import com.anz.markets.efx.ngaro.math.DoubleTools;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.positionrisk.Position;
import com.anz.markets.prophet.positionrisk.Positions;
import org.junit.Test;

import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.CADCHF;
import static com.anz.markets.prophet.domain.Instrument.EURAUD;
import static com.anz.markets.prophet.domain.Instrument.EURJPY;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCAD;
import static com.anz.markets.prophet.domain.Instrument.USDCHF;
import static com.anz.markets.prophet.domain.Instrument.USDJPY;
import static java.lang.Double.NaN;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.number.IsCloseTo.closeTo;

public class PositionUpdateTest extends BaseAcceptanceSpecification {
    private double EPSILON = 1e-6;

    @Test
    @Requirement(value = {Ref.POSITION_4_1, Ref.POSITION_4_6})
    @DisplayName("Make sure that position is updated when receive one trade.")
    public void S1_WHEN_receive_one_trade_SHOULD_compute_position() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));

            // receive Deals from datafabric.  Side is from ANZ perspective
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
        }
        then:
        {
            // should only generate on position update.
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInNotional(), is(1_000_000.0));
            assertThat(positionsUpdate.getPosition1().getAvgRate(), is(0.9));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.USD));
            assertThat(positionsUpdate.getPosition2().getPositionInNotional(), is(-1_000_000 * 0.9));
            assertThat(positionsUpdate.getPosition2().getAvgRate(), is(1.));
        }
    }

    @Test
    @Requirement(value = {Ref.POSITION_4_1, Ref.POSITION_4_6})
    @DisplayName("Make sure that position is updated when receive two bid trades.")
    public void S1_WHEN_receive_two_trades_on_bid_SHOULD_compute_position() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(2_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // posi change by first trade
                assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(1_000_000.0));
                assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(0.9));
                assertThat((int) positionsUpdates.getFirst().getPosition1().getPnl(), is((int)((0.75 - 0.9) * 1_000_000)));

                assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(-1_000_000 * 0.9));
                assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
                assertThat(positionsUpdates.getFirst().getPosition2().getPnl(), is(0.0));
            }
            and:
            {
                // posi change by second trade
                assertThat(positionsUpdates.getLast().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getLast().getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0));
                assertThat(positionsUpdates.getLast().getPosition1().getAvgRate(), is((0.9 + 0.8 * 2) / 3));
                assertThat((int) (positionsUpdates.getLast().getPosition1().getPnl()), is((int) (((((0.9 + 0.8 * 2) / 3) - 0.7500) * 3_000_000. * -1))));

                assertThat(positionsUpdates.getLast().getPosition2().getCcy(), is(Currency.USD));
                assertThat((int) (positionsUpdates.getLast().getPosition2().getPositionInNotional()), is((int) ((-1_000_000 * 0.9) + (-2_000_000 * 0.8))));
                assertThat(positionsUpdates.getLast().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
                assertThat(positionsUpdates.getLast().getPosition2().getPnl(), is(0.)); // pnl for USD itself is always 0.0
            }
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75050, 0.00040));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));
            assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(3_000_000.0));
            assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is((0.9 + 0.8 * 2) / 3));
            assertThat((int) positionsUpdates.getFirst().getPosition1().getPnl(), is((int) (((((0.9 + 0.8 * 2) / 3) - 0.7505) * 3_000_000. * -1))));
        }
    }

    @Test
    // AXPROPHET-1541
    public void compute_pnl_using_midrate() {
        setup:
        {
            ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
            configuration.putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.POSITION_IN_SYSTEM_BASE_USE_MIDRATE_ENABLED, true));
            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(2_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // posi change by first trade
                assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(1_000_000.0));
                assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(0.75));
                assertThat((int) positionsUpdates.getFirst().getPosition1().getPnl(), is((int)((0.75 - 0.75) * 1_000_000)));

                assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(-1_000_000 * 0.9));
                assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
                assertThat(positionsUpdates.getFirst().getPosition2().getPnl(), is(0.0));
            }
            and:
            {
                // posi change by second trade
                assertThat(positionsUpdates.getLast().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getLast().getPosition1().getPositionInNotional(), is(1_000_000.0 + 2_000_000.0));
                assertThat(positionsUpdates.getLast().getPosition1().getAvgRate(), is(0.75));
                assertThat(positionsUpdates.getLast().getPosition1().getPnl(), is((((0.75 - 0.7500) * 3_000_000.))));

                assertThat(positionsUpdates.getLast().getPosition2().getCcy(), is(Currency.USD));
                assertThat((int) (positionsUpdates.getLast().getPosition2().getPositionInNotional()), is((int) ((-1_000_000 * 0.9) + (-2_000_000 * 0.8))));
                assertThat(positionsUpdates.getLast().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
                assertThat(positionsUpdates.getLast().getPosition2().getPnl(), is(0.)); // pnl for USD itself is always 0.0
            }
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75050, 0.00040));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));
            assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(3_000_000.0));
            assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(0.75));
            assertThat(positionsUpdates.getFirst().getPosition1().getPnl(), is(DoubleTools.round((0.75 - 0.7505) * 3_000_000. * -1,0)));
        }
    }

    @Test
    @Requirement(value = {Ref.POSITION_4_1, Ref.POSITION_4_6})
    @DisplayName("Make sure that position is updated when receive bid and then offer trades.")
    public void S1_WHEN_receive_two_trades_on_bid_and_offer_SHOULD_compute_position() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(-2_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // posi change by first trade
                assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(1_000_000.0));
                assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(0.9));

                assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(-1_000_000 * 0.9));
                assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
            }
            and:
            {
                Position audPos = positionsUpdates.getLast().getPosition1();
                Position usdPos = positionsUpdates.getLast().getPosition2();

                // posi change by second trade
                assertThat(audPos.getCcy(), is(Currency.AUD));
                assertThat(audPos.getPositionInNotional(), is(1_000_000.0 - 2_000_000.0));
                assertThat(audPos.getAvgRate(), is(0.8));  // since position sign flipped avg rate is just the rate of the trade
                // When not reset. Jira to be created
//                assertThat(audPos.getAvgRate(), is(((1000000 * 0.9) + (-2000000 * 0.8)) / -1000000 ));
                assertThat(audPos.getPnl(), is(closeTo((audPos.getAvgRate() - 0.75) * -audPos.getPositionInNotional(),EPSILON)));

                assertThat(usdPos.getCcy(), is(Currency.USD));
                assertThat(usdPos.getPositionInNotional(), is(closeTo((-1_000_000 * 0.9) + (2_000_000 * 0.8), EPSILON)));
                assertThat(usdPos.getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
                assertThat(usdPos.getPnl(), is(0.)); // pnl for USD itself is always 0.0
            }
        }
    }

    // TODO: known bug. Need to triangulate terms/USD using cross fill rate and base/USD wsp_u mid
    @Test
    @Requirement(value = {Ref.POSITION_4_6, Ref.POSITION_4_7})
    public void avgExecutionRatePnLIndirectDirectCrossPair() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, EURUSD, 1.11900, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDJPY, 111.850, 0.004));
            prophet.receive(tdd.client_trade_001(EURJPY, 2_000_000, 125.115));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.EUR));
            assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(2_000_000.0));
            assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(1.11900));

            assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.JPY));
            assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(-2_000_000 * 125.115));
            // existing bug: execution rate should be triangulated from trade rate and base ccy's mid
            assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(111.850));
            // assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(125.115 / 1.11900));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, EURUSD, 1.11950, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDJPY, 111.855, 0.004));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURJPY, 3_000_000, 125.117));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();

            Position eurPos = positionsUpdate.getPosition1();
            Position jpyPos = positionsUpdate.getPosition2();

            assertThat(eurPos.getCcy(), is(Currency.EUR));
            assertThat(eurPos.getPositionInNotional(), is(2_000_000.0 + 3_000_000.0));
            assertThat(eurPos.getAvgRate(), is(((2_000_000.0 * 1.1190) + (3_000_000.0* 1.1195)) / eurPos.getPositionInNotional() ));
            assertThat((eurPos.getPnl()), is(closeTo((-eurPos.getPositionInNotional() * (eurPos.getAvgRate() - 1.11950)), EPSILON)));

            assertThat(jpyPos.getCcy(), is(Currency.JPY));
            assertThat(jpyPos.getPositionInNotional(), is((-2_000_000 * 125.115) + (-3_000_000 * 125.117)));
            // existing bug: execution rate should be triangulated from trade rate and base ccy's mid
            assertThat(jpyPos.getAvgRate(), is(closeTo(jpyPos.getPositionInNotional() /
             (((-2_000_000 * 125.115) / (111.850)) + ((-3_000_000 * 125.117) / (111.855))), EPSILON)));
            // assertThat(jpyPos.getAvgRate(), is(closeTo(positionsUpdate.getPosition2().getPositionInNotional() /
            //      (((-2_000_000 * 125.115) / (125.115 / 1.11900)) + ((-3_000_000 * 125.117) / (125.117 / 1.11950))), EPSILON)));
            assertThat((jpyPos.getPnl()), is(closeTo((-jpyPos.getPositionInNotional() * ((1 / jpyPos.getAvgRate()) - (1 / 111.855))), EPSILON)));
        }
    }

    // TODO: known bug. Need to triangulate terms/USD using cross fill rate and base/USD wsp_u mid
    @Test
    @Requirement(value = {Ref.POSITION_4_6, Ref.POSITION_4_7})
    public void avgExecutionRatePnLDirectDirectCrossPair() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDCAD, 1.34050, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDCHF, 0.97730, 0.00040));
            prophet.receive(tdd.client_trade_001(CADCHF, 2_000_000, 0.72705));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.CAD));
            assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(2_000_000.0));
            assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(1.34050));

            assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.CHF));
            assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(-2_000_000 * 0.72705));
            // existing bug: execution rate should be triangulated from trade rate and base ccy's mid
            assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(0.97730));
            // assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(1.34050 / 0.72705));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDCAD, 1.34010, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, USDCHF, 0.97700, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(CADCHF, 3_000_000, 0.72715));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();

            Position cadPos = positionsUpdate.getPosition1();
            Position chfPos = positionsUpdate.getPosition2();

            assertThat(cadPos.getCcy(), is(Currency.CAD));
            assertThat(cadPos.getPositionInNotional(), is(2_000_000.0 + 3_000_000.0));
            assertThat(cadPos.getAvgRate(), is(cadPos.getPositionInNotional() / ((2_000_000.0 / 1.34050) + (3_000_000.0 / 1.34010))));
            assertThat((cadPos.getPnl()), is(closeTo((-cadPos.getPositionInNotional() * ((1 / cadPos.getAvgRate()) - (1 / 1.34010))), EPSILON)));

            assertThat(chfPos.getCcy(), is(Currency.CHF));
            assertThat(chfPos.getPositionInNotional(), is((-2_000_000 * 0.72705) + (-3_000_000 * 0.72715)));
            // existing bug: execution rate should be triangulated from trade rate and base ccy's mid
            assertThat(chfPos.getAvgRate(), is(closeTo(chfPos.getPositionInNotional() /
                    (((-2_000_000 * 0.72705) / (0.97730)) + ((-3_000_000 * 0.72715) / (0.97700))), EPSILON)));
            // assertThat(chfPos.getAvgRate(), is(closeTo(positionsUpdate.getPosition2().getPositionInNotional() /
            //      (((-2_000_000 * 0.72705) / (0.72705 * 1.34050)) + ((-3_000_000 * 0.72715) / (0.72715 * 1.34010))), EPSILON)));
            assertThat((chfPos.getPnl()), is(closeTo((-chfPos.getPositionInNotional() * ((1 / chfPos.getAvgRate()) - (1 / 0.97700))), EPSILON)));
        }
    }

    // TODO: known bug. Need to triangulate terms/USD using cross fill rate and base/USD wsp_u mid
    @Test
    @Requirement(value = {Ref.POSITION_4_6, Ref.POSITION_4_7})
    public void avgExecutionRatePnLIndirectIndirectCrossPair() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, EURUSD, 1.11900, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75020, 0.00040));
            prophet.receive(tdd.client_trade_001(EURAUD, -2_000_000, 1.49750));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.EUR));
            assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(-2_000_000.0));
            assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(1.11900));

            assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(2_000_000 * 1.49750));
            // existing bug: execution rate should be triangulated from trade rate and base ccy's mid
            assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(0.75020));
            // assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(1.11900 / 1.49750));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, EURUSD, 1.11950, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75050, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURAUD, -3_000_000, 1.49740));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();

            Position eurPos = positionsUpdate.getPosition1();
            Position audPos = positionsUpdate.getPosition2();

            assertThat(eurPos.getCcy(), is(Currency.EUR));
            assertThat(eurPos.getPositionInNotional(), is(-2_000_000.0 - 3_000_000.0));
            assertThat(eurPos.getAvgRate(), is(((-2 * 1.1190) + (-3 * 1.1195)) / -5 ));
            assertThat((eurPos.getPnl()), is(closeTo((-eurPos.getPositionInNotional() * (eurPos.getAvgRate() - 1.11950)), EPSILON)));

            assertThat(audPos.getCcy(), is(Currency.AUD));
            assertThat(audPos.getPositionInNotional(), is((2_000_000 * 1.49750) + (3_000_000 * 1.49740)));
            assertThat(audPos.getAvgRate(), is(((2_000_000 * 1.49750 * 0.75020) + (3_000_000 * 1.49740 * 0.75050)) / audPos.getPositionInNotional()));
            // existing bug: execution rate should be triangulated from trade rate and base ccy's mid
//            assertThat(audPos.getAvgRate(), is(((2_000_000 * 1.49750 * 1.11900 / 1.49750) + (3_000_000 * 1.49740 * 1.11950 / 1.49740)) / audPos.getPositionInNotional()));
            assertThat((audPos.getPnl()), is(closeTo((-audPos.getPositionInNotional() * (audPos.getAvgRate() - 0.75050)), EPSILON)));
        }
    }

    @Test
    @Requirement(value = {Ref.POSITION_4_6})
    @DisplayName("When notional position is zero then avg execution rate is NaN")
    public void zero_notional_pos_avg_execution_rate_nan() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.7500, 0.00040));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.client_trade_001(-1_000_000, 0.8));
        }
        then:
        {
            // should only generate on position update for incoming trade
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));

            and:
            {
                // posi change by first trade
                assertThat(positionsUpdates.getFirst().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getFirst().getPosition1().getPositionInNotional(), is(1_000_000.0));
                assertThat(positionsUpdates.getFirst().getPosition1().getAvgRate(), is(0.9));

                assertThat(positionsUpdates.getFirst().getPosition2().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.getFirst().getPosition2().getPositionInNotional(), is(-1_000_000 * 0.9));
                assertThat(positionsUpdates.getFirst().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
            }
            and:
            {
                // posi change by second trade
                assertThat(positionsUpdates.getLast().getPosition1().getCcy(), is(Currency.AUD));
                assertThat(positionsUpdates.getLast().getPosition1().getPositionInNotional(), is(0.0));
                assertThat(positionsUpdates.getLast().getPosition1().getAvgRate(), is(NaN));
                assertThat(positionsUpdates.getLast().getPosition1().getPnl(), is(0.0));  // or NaN

                assertThat(positionsUpdates.getLast().getPosition2().getCcy(), is(Currency.USD));
                assertThat(positionsUpdates.getLast().getPosition2().getPositionInNotional(), is(((-1_000_000 * 0.9) + (1_000_000 * 0.8))));
                assertThat(positionsUpdates.getLast().getPosition2().getAvgRate(), is(1.0)); // usd to usd rate is always 1.0
                assertThat(positionsUpdates.getLast().getPosition2().getPnl(), is(0.)); // pnl for USD itself is always 0.0
            }
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, AUDUSD, 0.75050, 0.00040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(500_000, 0.82));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            Position audPos = positionsUpdate.getPosition1();

            assertThat(audPos.getCcy(), is(Currency.AUD));
            assertThat(audPos.getPositionInNotional(), is(500_000.));
            assertThat(audPos.getAvgRate(), is((500_000 * 0.82) / audPos.getPositionInNotional()));
            // When not reset. Jira to be created
//            assertThat(audPos.getAvgRate(), is(((1_000_000 * 0.9) + (-1_000_000 * 0.8) + (500_000 * 0.82)) / audPos.getPositionInNotional()));
            assertThat(audPos.getPnl(), is(closeTo((audPos.getAvgRate() - 0.75050) * -audPos.getPositionInNotional(),EPSILON)));
        }
    }
}
