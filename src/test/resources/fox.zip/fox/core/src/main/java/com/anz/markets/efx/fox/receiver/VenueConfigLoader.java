package com.anz.markets.efx.fox.receiver;

import java.io.InputStream;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.venue.config.VenueConfig;

public class VenueConfigLoader implements Runnable {
    private final VenueConfig venueConfig;
    private final SorEncoderSupplier encoderSupplier;

    public VenueConfigLoader(final String fileName, final SorEncoderSupplier encoderSupplier) {
        final InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(Objects.requireNonNull(fileName));
        this.venueConfig = VenueConfig.yaml().load(inputStream);
        this.encoderSupplier = Objects.requireNonNull(encoderSupplier);
    }

    @Override
    public void run() {
        venueConfig.getVenues().forEach((venue, venueEntry) -> {
            encoderSupplier.venueConfig().messageStart(0,0)
                    .venueCategories().addAll(venueEntry.getVenueCategories())
                    .venue(venue)
                    .compId().encode(venueEntry.getCompId())
                    .enabled(venueEntry.isEnabled())
                    .messageComplete();
        });
    }
}
