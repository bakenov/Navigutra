package com.anz.markets.prophet.pricer.firewall;


import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;

public class NOPProtectionFirewallJMHTest {

    @State(Scope.Benchmark)
    public static class Data extends AbstractNOPProtectionFirewallForBwJmhTest {

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }

    @Benchmark
    public IndexedConfigurationData testApplyPosition(@NotNull final Data data) throws Exception {
        return data.testApplyPosition();
    }

    @Benchmark
    public ClientPrice testProcessClientPrice(@NotNull final Data data) throws Exception {
        return data.testPerformClientPrice();
    }
}
