package com.anz.markets.prophet.hedger.firewall.threshold;

import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.SecureRandom;

public class MaxDisplacementThresholdJmhTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MaxDisplacementThresholdJmhTest.class);

    @Benchmark
    public double testAddAndRemove(@NotNull final Data data) throws Exception {
        return data.testAcceptValueAndCalculateDisplacement(data.random.nextDouble());
    }

    @State(Scope.Benchmark)
    public static class Data extends AbstractMaxDisplacementThresholdForBwJmhTest {
        final SecureRandom random = new SecureRandom();

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }
}
