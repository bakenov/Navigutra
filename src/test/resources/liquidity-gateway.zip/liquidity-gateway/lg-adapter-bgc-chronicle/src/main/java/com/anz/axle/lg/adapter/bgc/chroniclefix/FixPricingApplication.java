package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;

import java.util.Objects;

public class FixPricingApplication extends FixSessionApplication implements MessageNotifier {
    public FixPricingApplication(final ApplicationLogonHandler applicationLogonHandler) {
        super(Objects.requireNonNull(applicationLogonHandler));
    }
}
