package com.anz.markets.efx.fox.firewalls.rules.config;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class FirewallConfigInstance {
    private long ruleId;
    private String regionPattern =  "*";
    private String orderTypePattern =  "*";
    private String deskPattern =  "*";
    private String portfolioPattern =  "*";
    private String usernamePattern =  "*";
    private String venuePattern =  "*";
    private String securityTypePattern =  "*";
    private String tenorPattern =  "*";
    private String symbolPattern =  "*";
    private double limitThreshold =  0d;
    private  long  period = 0L;
    private String periodUnit = "?";
    private boolean local;
    private String lastEditUsername;
    private Date lastEditTime;
    private String comment;

    public long getRuleId() {
        return ruleId;
    }

    public void setRuleId(final long ruleId) {
        this.ruleId = ruleId;
    }

    public String getRegionPattern() {
        return regionPattern;
    }

    public void setRegionPattern(final String regionPattern) {
        this.regionPattern = regionPattern;
    }

    public String getOrderTypePattern() {
        return orderTypePattern;
    }

    public void setOrderTypePattern(final String orderTypePattern) {
        this.orderTypePattern = orderTypePattern;
    }

    public String getDeskPattern() {
        return deskPattern;
    }

    public void setDeskPattern(final String deskPattern) {
        this.deskPattern = deskPattern;
    }

    public String getPortfolioPattern() {
        return portfolioPattern;
    }

    public void setPortfolioPattern(final String portfolioPattern) {
        this.portfolioPattern = portfolioPattern;
    }

    public String getUsernamePattern() {
        return usernamePattern;
    }

    public void setUsernamePattern(final String usernamePattern) {
        this.usernamePattern = usernamePattern;
    }

    public String getVenuePattern() {
        return venuePattern;
    }

    public void setVenuePattern(final String venuePattern) {
        this.venuePattern = venuePattern;
    }

    public String getSecurityTypePattern() {
        return securityTypePattern;
    }

    public void setSecurityTypePattern(final String securityTypePattern) {
        this.securityTypePattern = securityTypePattern;
    }

    public String getTenorPattern() {
        return tenorPattern;
    }

    public void setTenorPattern(final String tenorPattern) {
        this.tenorPattern = tenorPattern;
    }

    public String getSymbolPattern() {
        return symbolPattern;
    }

    public void setSymbolPattern(final String symbolPattern) {
        this.symbolPattern = symbolPattern;
    }

    public double getLimitThreshold() {
        return limitThreshold;
    }

    public void setLimitThreshold(final double limitThreshold) {
        this.limitThreshold = limitThreshold;
    }

    public long getPeriod() {
        return period;
    }

    public void setPeriod(final long period) {
        this.period = period;
    }

    public String getPeriodUnit() {
        return periodUnit;
    }

    public void setPeriodUnit(final String periodUnit) {
        this.periodUnit = periodUnit;
    }

    public boolean isLocal() {
        return local;
    }

    public void setLocal(final boolean local) {
        this.local = local;
    }

    public String getLastEditUsername() {
        return lastEditUsername;
    }

    public void setLastEditUsername(final String lastEditUsername) {
        this.lastEditUsername = lastEditUsername;
    }

    public Date getLastEditTime() {
        return lastEditTime;
    }

    public void setLastEditTime(final Date lastEditTime) {
        this.lastEditTime = lastEditTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(final String comment) {
        this.comment = comment;
    }

    private static final Map<Class, Function<String, ?>> parsers = new HashMap<>();

    static {
        parsers.put(Long.class, Long::parseLong);
        parsers.put(long.class, Integer::parseInt);
        parsers.put(Integer.class, Integer::parseInt);
        parsers.put(int.class, Integer::parseInt);
        parsers.put(Double.class, Double::parseDouble);
        parsers.put(double.class, Double::parseDouble);
        parsers.put(boolean.class, Boolean::parseBoolean);
        parsers.put(Float.class, Float::parseFloat);
        parsers.put(float.class, Float::parseFloat);
        parsers.put(Date.class, Date::parse);
        parsers.put(String.class, String::toString);
    }

    /**
     * @param fieldName name of the property to set (setFieldName(value)
     * @param value to set
     * @param rule line being parsed in case of problems
     */
    void callSetter(final String fieldName, final Object value, final String firewallName, final List<Object> rule){
        PropertyDescriptor pd;
        try {
            pd = new PropertyDescriptor(fieldName, this.getClass());
            //Class<?> propertyType = pd.getPropertyType();
            pd.getWriteMethod().invoke(this, value);
        } catch (IntrospectionException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            throw new IllegalArgumentException("Rule " + rule.get(0) + " found in firewallName '" + firewallName + "' does not contain the setter for '" + fieldName + "' of the compatible type " + value.getClass().getName());
        } catch (NullPointerException nullPExcp) {
            throw new IllegalArgumentException("Error trying to set field '" + fieldName + "' with value " + value + " on FirewallConfigInstance.  Got null pointer exception.");
        }
    }
}
