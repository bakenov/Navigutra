package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;

public interface FirewallConfigEncoder extends MessageEncoder<FirewallConfigEncoder.Body> {
    @Override
    Body messageStart(int source, long sourceSeq);

    interface Body {
        StringEncoder<Body> firewallName();
        Body ruleId(long ruleId);
        StringEncoder<Body> regionPattern();
        StringEncoder<Body> orderTypePattern();
        StringEncoder<Body> deskPattern();
        StringEncoder<Body> portfolioPattern();
        StringEncoder<Body> usernamePattern();
        StringEncoder<Body> venuePattern();
        StringEncoder<Body> securityTypePattern();
        StringEncoder<Body> tenorPattern();
        StringEncoder<Body> symbolPattern();
        Body period(long period);
        StringEncoder<Body> periodUnit();
        Body local(boolean local);
        StringEncoder<Body> comment();
        StringEncoder<Body> lastEditUsername();
        Body lastEditTime(long lastEditTime);

        Trailer limitThreshold(double limitThreshold);
    }
}
