package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.components.Parties_PartyIDsGrp_1;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.CharSequenceBuilder;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Parties;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.staticcode.messages.FixMessage;

import java.util.Objects;
import java.util.function.LongSupplier;

import static com.anz.axle.lg.adapter.chroniclefix.ChronicleFixUtils.zeroIfUnSet;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.FOK;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.GTC;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.GTD;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.IOC;

public final class BgcExecutionReportHandler implements ChronicleMessageHandler<ExecutionReport> {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcExecutionReportHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    private final TradingEncoderSupplier tradingEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;

    private final CachedFunction<String, String> symbol6Lookup = CachedFunction.of(SymbolNormaliser::toSymbol6);
    private final CharSequenceBuilder charSequenceBuilder = new CharSequenceBuilder();
    private final SourceSequencer sourceSequencer;

    public BgcExecutionReportHandler(final TradingEncoderSupplier tradingEncoderSupplier,
                                     final PrecisionClock precisionClock,
                                     final String senderCompId,
                                     final String compId,
                                     final LongSupplier messageIdGenerator,
                                     final SourceSequencer sourceSequencer) {
        this.tradingEncoderSupplier = Objects.requireNonNull(tradingEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final ExecutionReport message) throws IllegalArgumentException {

        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("ExecutionReport received: {}", message);

        if (message.execType() == com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.TRADE) {
            LOGGER.info(charSequenceBuilder.clear()
                    .append("Received ExecutionReport Trade: clOrdID=").append(message.clOrdID())
                    .append(", execId=").append(message.execID())
                    .append(", symbol=").append(message.symbol())
                    .append(", lastPx=").append(message.lastPx())
                    .append(", lastQty=").append(message.lastQty())
                    .append(". Skipped").toString());
            return;
        }

        final long sequenceNumber = message.msgSeqNum();
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = zeroIfUnSet(message.sendingTime());

        final char bgcOrdStatus = message.ordStatus() == OrdStatus.CALCULATED ? OrdStatus.FILLED : message.ordStatus();
        final OrderStatus orderStatus = orderStatus(bgcOrdStatus);

        final char bgcExecType = message.execType() == com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.CALCULATED ? com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.FILL : message.execType();
        final ExecType execType = execType(bgcExecType);

        final ExecutionReportEncoder.Body bodyEncoder = tradingEncoderSupplier.executionReport()
                .messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .orderId().encode(message.orderID())
                .clOrdId().encode(message.clOrdID())
                .origClOrdId().encode(message.origClOrdID() != null ? message.origClOrdID() : message.clOrdID())
                .clOrdLinkId().encodeEmpty()
                .marketId().encode(Venue.BGCMIDFX.name())
                .execId().encodeNullable(message.execID())
                .execType(execType)
                .settlDate().encodeFormatted(message.settlDate(), DATE_DECODER)
                .ordStatus(orderStatus)
                .symbol().encode(symbol6Lookup.apply((message.symbol())))
                .securityType(SecurityType.FXSPOT)
                .settlType(Tenor.SP)
                .ordType(OrderType.LIMIT)
                .orderQty(unsetToZero(message.orderQty()))
                .targetStrategyName().encodeEmpty()
                .price(unsetToZero(message.price()))
                .side(side(message.side()))
                .currency().encodeNullable(message.currency())
                .timeInForce(timeInForce(message.timeInForce()))
                .lastPx(unsetToZero(message.lastPx()))
                .lastQty(unsetToZero(message.lastQty()))
                .leavesQty(orderStatus == OrderStatus.REJECTED ? 0.0 : unsetToZero(message.leavesQty()))
                .cumQty(unsetToZero(message.cumQty()))
                .avgPx(unsetToZero(message.avgPx()))
                .tradeDate().encodeFormatted(message.tradeDate(), DATE_DECODER)
                .settlCurrency().encodeNullable(message.settlCurrency())
                .transactTime(zeroIfUnSet(message.transactTime()))
                .expireTime(zeroIfUnSet(message.expireTime()));

        addParties(bodyEncoder, message)
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .quoteId().encodeEmpty()
                .rejectText().encodeNullable(message.text())
                .messageComplete();
    }

    private ExecutionReportEncoder.StrategyParameters addParties(final ExecutionReportEncoder.Body bodyEncoder, final ExecutionReport message) {

        final Parties.Encoder.Next<ExecutionReportEncoder.StrategyParameters> partiesNext = bodyEncoder.partiesStart((int)message.noPartyIDs());

        for (int i = 0; i < message.noPartyIDs(); i++) {
            final Parties_PartyIDsGrp_1 partiesPartyIDsGrp = message.parties_PartyIDsGrp_1(i);
            partiesNext.next()
                    .partyRole(partyRole(partiesPartyIDsGrp.partyRole()))
                    .partyId().encodeNullable(partiesPartyIDsGrp.partyID());

        }
        return partiesNext.partiesComplete();
    }

    private ExecType execType(final char execType) {
        switch (execType) {
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.NEW: return ExecType.NEW;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.DONE_FOR_DAY: return ExecType.DONE_FOR_DAY;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.CANCELED: return ExecType.CANCELED;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.REPLACE: return ExecType.REPLACED;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.PENDING_CANCEL: return ExecType.PENDING_CANCEL;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.REJECTED: return ExecType.REJECTED;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.PENDING_NEW: return ExecType.PENDING_NEW;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.EXPIRED: return ExecType.EXPIRED;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.PENDING_REPLACE: return ExecType.PENDING_REPLACE;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.TRADE: return ExecType.TRADE;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.ExecType.FILL: return ExecType.TRADE;
            default: throw new IllegalArgumentException("Unsupported execType " + execType);
        }
    }

    private TimeInForce timeInForce(final char timeInForce) {
        switch (timeInForce) {
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.DAY: return TimeInForce.DAY;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_CANCEL: return GTC;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.IMMEDIATE_OR_CANCEL: return IOC;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.FILL_OR_KILL: return FOK;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_DATE: return GTD;
            default: return null;
        }
    }

    private Side side(final char side) throws IllegalArgumentException {
        switch (side) {
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.BUY : return Side.BUY;
            case com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.SELL : return Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side " + side);
        }
    }

    private OrderStatus orderStatus(final char ordStatus) throws IllegalArgumentException {
        switch (ordStatus) {
            case OrdStatus.NEW: return OrderStatus.NEW;
            case OrdStatus.PARTIALLY_FILLED: return OrderStatus.PARTIALLY_FILLED;
            case OrdStatus.FILLED: return OrderStatus.FILLED;
            case OrdStatus.DONE_FOR_DAY: return OrderStatus.DONE_FOR_DAY;
            case OrdStatus.CANCELED: return OrderStatus.CANCELED;
            case OrdStatus.PENDING_CANCEL: return OrderStatus.PENDING_CANCEL;
            case OrdStatus.REJECTED : return OrderStatus.REJECTED;
            case OrdStatus.PENDING_NEW: return OrderStatus.PENDING_NEW;
            case OrdStatus.EXPIRED: return OrderStatus.EXPIRED;
            case OrdStatus.PENDING_REPLACE: return OrderStatus.PENDING_REPLACE;
            case OrdStatus.REPLACED: return OrderStatus.REPLACED;
            // what about U = Undefined?
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private PartyRole partyRole(final long partyRole) {
        final String strPartyRole = com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.PartyRole.asString((int)partyRole);
        switch (strPartyRole) {
            case "CLIENT_ID": return PartyRole.CLIENT_ID;
            case "BUYER_SELLER": return PartyRole.BUYER;
            case "CONTRA_FIRM": return PartyRole.CONTRA_FIRM;
            default: throw new IllegalArgumentException("Unsupported partyRole " + partyRole);
        }
    }

    private double unsetToZero(final double value) {
        return value == FixMessage.UNSET_DOUBLE || Double.isNaN(value) ? 0.0 : value;
    }
}
