package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.status.Context;
import net.openhft.chronicle.threads.Pauser;

public class ReaderConfigBuilder {
    private long startPosition = 0;
    private StartAt startAt = StartAt.START;
    private WaitStrategy waitStrategy = WaitStrategy.LOG_START_MESSAGE;
    private ChronicleHook startReadHook = ChronicleHook.DO_NOTHING;
    private ChronicleHook endReadHook = ChronicleHook.DO_NOTHING;
    private ChronicleHook unknownReadHook = ChronicleHook.DO_NOTHING;
    private Context.HeaderPredicate headerFilter = HeaderPredicates.FILTER_ALLOW_ALL;
    private Pauser pauser = PauserFactory.create();
    private ChronicleObjectReader chronicleObjectReader;
    private RingBuffer ringBuffer = RingBuffer.NO_RING;
    private int tailerId = ReaderConfig.NO_TAILER_ID;

    public static ReaderConfigBuilder create(final ReaderConfig config) {
        return new ReaderConfigBuilder()
                .withStartPosition(config.startPosition())
                .withStartAt(config.startAt())
                .withWaitStrategy(config.waitStrategy())
                .withStartReadHook(config.startReadHook())
                .withEndReadHook(config.endReadHook())
                .withUnknownReadHook(config.unknownReadHook())
                .withHeaderFilter(config.headerFilter())
                .withPauser(config.pauser())
                .withRingBuffer(config.ringBuffer())
                .withTailerId(config.tailerId())
                .withChronicleObjectReader(config.chronicleObjectReader());
    }

    public static ReaderConfigBuilder create() {
        return new ReaderConfigBuilder();
    }

    public ReaderConfigBuilder withChronicleObjectReader(final ChronicleObjectReader chronicleObjectReader) {
        this.chronicleObjectReader = chronicleObjectReader;
        return this;
    }

    public ReaderConfigBuilder withStartPosition(final long startPosition) {
        this.startPosition = startPosition;
        return this;
    }

    public ReaderConfigBuilder withStartAt(final StartAt startAt) {
        this.startAt = startAt;
        return this;
    }

    public ReaderConfigBuilder withWaitStrategy(final WaitStrategy waitStrategy) {
        this.waitStrategy = waitStrategy;
        return this;
    }

    public ReaderConfigBuilder withStartReadHook(final ChronicleHook startReadHook) {
        this.startReadHook = startReadHook;
        return this;
    }

    public ReaderConfigBuilder withEndReadHook(final ChronicleHook endReadHook) {
        this.endReadHook = endReadHook;
        return this;
    }

    public ReaderConfigBuilder withUnknownReadHook(final ChronicleHook unknownReadHook) {
        this.unknownReadHook = unknownReadHook;
        return this;
    }

    public ReaderConfigBuilder withHeaderFilter(final Context.HeaderPredicate headerFilter) {
        this.headerFilter = headerFilter;
        return this;
    }

    public ReaderConfigBuilder withPauser(final Pauser pauser) {
        this.pauser = pauser;
        return this;
    }

    public ReaderConfigBuilder withRingBuffer(final RingBuffer ringBuffer) {
        this.ringBuffer = ringBuffer;
        return this;
    }

    public ReaderConfigBuilder withTailerId(final int tailerId) {
        this.tailerId = tailerId;
        return this;
    }

    public ReaderConfig build() {
        return new ReaderConfigImpl(startPosition, startAt, waitStrategy, startReadHook, endReadHook, unknownReadHook, headerFilter, pauser, chronicleObjectReader, ringBuffer, tailerId);
    }

    public static class ReaderConfigImpl implements ReaderConfig {

        private final long startPosition;
        private final StartAt startAt;
        private final WaitStrategy waitStrategy;
        private final ChronicleHook startReadHook;
        private final ChronicleHook endReadHook;
        private final ChronicleHook unknownReadHook;
        private final Context.HeaderPredicate headerFilter;
        private final Pauser pauser;
        private final ChronicleObjectReader chronicleObjectReader;
        private final RingBuffer ringBuffer;
        private final int tailerId;

        ReaderConfigImpl(final long startPosition, final StartAt startAt, final WaitStrategy waitStrategy, final ChronicleHook startReadHook, final ChronicleHook endReadHook,
                         final ChronicleHook unknownReadHook, final Context.HeaderPredicate headerFilter, final Pauser pauser,
                         final ChronicleObjectReader chronicleObjectReader, final RingBuffer ringBuffer, final int tailerId) {
            this.startPosition = startPosition;
            this.startAt = startAt;
            this.waitStrategy = waitStrategy;
            this.startReadHook = startReadHook;
            this.endReadHook = endReadHook;
            this.unknownReadHook = unknownReadHook;
            this.headerFilter = headerFilter;
            this.pauser = pauser;
            this.chronicleObjectReader = chronicleObjectReader;
            this.ringBuffer = ringBuffer;
            this.tailerId = tailerId;
        }

        @Override
        public long startPosition() {
            return startPosition;
        }

        @Override
        public StartAt startAt() {
            return startAt;
        }

        @Override
        public WaitStrategy waitStrategy() {
            return waitStrategy;
        }

        @Override
        public Pauser pauser() {
            return pauser;
        }

        @Override
        public ChronicleHook startReadHook() {
            return startReadHook;
        }

        @Override
        public ChronicleHook endReadHook() {
            return endReadHook;
        }

        @Override
        public ChronicleHook unknownReadHook() {
            return unknownReadHook;
        }

        @Override
        public Context.HeaderPredicate headerFilter() {
            return headerFilter;
        }

        @Override
        public ChronicleObjectReader chronicleObjectReader() {
            return chronicleObjectReader;
        }

        @Override
        public RingBuffer ringBuffer() {
            return ringBuffer;
        }

        @Override
        public int tailerId() {
            return tailerId;
        }

        @Override
        public String toString() {
            return "ReaderConfig{" +
                    "startReadHook=" + startReadHook +
                    ", endReadHook=" + endReadHook +
                    ", unknownReadHook=" + unknownReadHook +
                    ", headerFilter=" + headerFilter +
                    ", pauser=" + pauser +
                    ", startAt=" + startAt +
                    ", startPosition=" + startPosition +
                    ", waitStrategy=" + waitStrategy +
                    ", ringBuffer=" + ringBuffer +
                    '}';
        }
    }
}