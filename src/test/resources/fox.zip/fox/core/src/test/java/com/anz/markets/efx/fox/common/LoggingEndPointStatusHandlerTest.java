package com.anz.markets.efx.fox.common;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.common.LoggingEndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import static org.mockito.Mockito.mock;

@RunWith(Spockito.class)
public class LoggingEndPointStatusHandlerTest {
    public enum LogLevel {
        DEBUG() {
            @Override
            void verify(final Logger logger, final String message, final String topicName, final Object status) {
                org.mockito.Mockito.verify(logger).debug(message, topicName, status);
            }
        },
        INFO() {
            @Override
            void verify(final Logger logger, final String message, final String topicName, final Object status) {
                org.mockito.Mockito.verify(logger).info(message, topicName, status);
            }
        },
        WARN() {
            @Override
            void verify(final Logger logger, final String message, final String topicName, final Object status) {
                org.mockito.Mockito.verify(logger).warn(message, topicName, status);
            }
        },
        ERROR() {
            @Override
            void verify(final Logger logger, final String message, final String topicName, final Object status) {
                org.mockito.Mockito.verify(logger).error(message, topicName, status, status);
            }

        };

        abstract void verify(final Logger logger, final String message, final String topicName, final Object status);
    }
    private Logger logger;
    private LoggingEndPointStatusHandler handler;

    @Before
    public void setUp() {
        logger = mock(Logger.class);
        handler = new LoggingEndPointStatusHandler(logger);
    }

    @Test
    @Spockito.Unroll({
            "| event        | message                                         | logLevel |",
            "|==============|=================================================|==========|",
            "| INFO         | Status: event=INFO, topic={}, status={}         | DEBUG    |",
            "|--------------|-------------------------------------------------|----------|",
            "| CLOSE        | Status: event=CLOSE, topic={}, status={}        | INFO     |",
            "|--------------|-------------------------------------------------|----------|",
            "| NOTIFICATION | Status: event=NOTIFICATION, topic={}, status={} | WARN     |",
            "|--------------|-------------------------------------------------|----------|",
            "| EXCEPTION    | Status: event=EXCEPTION, topic={}, status={}    | ERROR    |",
            "|--------------|-------------------------------------------------|----------|",
    })
    @Spockito.Name("[{row}]: {message}")
    public void onStatus(final EndPointStatusHandler.Event event,
                  final String message, final LogLevel logLevel) {
        final Topic topic = DefaultTopic.create("someTopic");
        final String status = "someStatus";
        handler.onStatus(event, topic, status);
        logLevel.verify(logger, message, topic.name(), status);
    }
}