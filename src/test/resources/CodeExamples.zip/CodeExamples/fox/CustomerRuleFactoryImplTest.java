package com.anz.markets.efx.fox.firewall.rule.customer;

import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.firewall.api.PropertyProvider;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for class CustomerRuleFactoryImpl
 */
@ExtendWith(MockitoExtension.class)
public class CustomerRuleFactoryImplTest {

    private static final long TIMEOUT = 1;
    private static final TimeUnit TIME_UNIT = TimeUnit.SECONDS;

    @Mock
    private NewOrderSingleDecoder newOrderSingle;
    private CustomerRuleFactory factory;
    private LongSupplier timeSupplier;
    private PropertyProvider properties;


    @BeforeEach
    void setUp() {
        properties = (k) -> {
            switch(k) {
                case StaleOrderRule.TIMEOUT_THRESHOLD_PROPERTY_NAME:
                    return Long.toString(TIMEOUT);
                case StaleOrderRule.TIMEOUT_TIME_UNIT_PROPERTY_NAME:
                    return TIME_UNIT.name();
                default:
                    return null;
            }
        };

        timeSupplier = () -> System.nanoTime();
        factory = new CustomerRuleFactoryImpl(timeSupplier, properties);
    }

    private long getOrderTransactionTime(long delay) {
        return timeSupplier.getAsLong() - delay;
    }

    @Test
    void build_rule_and_validate_should_succeed() {
        Rule rule = factory.buildRule(CustomerRuleType.STALE_ORDER);
        assertThat(rule instanceof StaleOrderRule).isTrue();
        StaleOrderRule staleRule = (StaleOrderRule) rule;
        assertThat(staleRule.description()).isEqualTo(CustomerRuleType.STALE_ORDER.getDescription());
        assertThat(staleRule.priority()).isEqualTo(CustomerRuleType.STALE_ORDER.getPriority());

        final long orderTransactionTime = getOrderTransactionTime(100);
        assertThat(rule.validate(newOrderSingle, orderTransactionTime)).isTrue();
    }

}
