package com.anz.axle.lg.adapter.ebs;

import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import com.anz.axle.lg.adapter.config.HealthConfig;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.CommonConfig;
import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
@Import({
        CommonConfig.class,
        EbsCommonConfig.class,
        PropertiesConfig.class,
        PricingConfig.class,
        TradingConfig.class,
        MessagingConfig.class,
        LastMarketTradeConfig.class,
        FixConfig.class,
        HealthConfig.class
})
public class ServerConfig {

    private final Service ebsFixEngine;
    private final Connection connection;
    private final Service mainEventLoop;

    public ServerConfig(@Qualifier("ebsFixEngine") final Service ebsFixEngine,
                        final Connection connection,
                        final Service mainEventLoop) {
        this.ebsFixEngine = Objects.requireNonNull(ebsFixEngine);
        this.connection = Objects.requireNonNull(connection);
        this.mainEventLoop = Objects.requireNonNull(mainEventLoop);
    }

    @PostConstruct
    public void init() {
        mainEventLoop.start();
        ebsFixEngine.start();
    }

    @PreDestroy
    public void destroy() {
        ebsFixEngine.stop();
        mainEventLoop.stop();
        connection.close();
    }
}
