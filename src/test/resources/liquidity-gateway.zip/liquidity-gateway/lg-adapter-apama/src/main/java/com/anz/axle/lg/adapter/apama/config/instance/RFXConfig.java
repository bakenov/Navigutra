package com.anz.axle.lg.adapter.apama.config.instance;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.apama.config.core.EnablePublishing;
import com.anz.axle.lg.adapter.apama.config.venue.RFXVenueSubscribingConfig;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
@EnablePublishing
@Import(RFXVenueSubscribingConfig.class)
public class RFXConfig {

    @Bean
    public String instanceName() {
        return Venue.RFX.name();
    }
}
