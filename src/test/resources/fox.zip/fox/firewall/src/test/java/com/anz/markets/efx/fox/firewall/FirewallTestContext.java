package com.anz.markets.efx.fox.firewall;

import java.util.Arrays;
import java.util.EnumSet;

import org.tools4j.spockito.Table;

import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.api.eventsourcing.UpdatablePrecisionClock;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.sbe.SorCodecUtil;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class FirewallTestContext {
    public interface FirewallFactory {
        Firewall create(final String name,
                        final UserRepository userRepository,
                        final OrderConsumer.ErrorHandler errorHandler);
    }

    private final SorCodecUtil.Codec sorCodec = SorCodecUtil.create();
    public final UserRepository userRepository = mock(UserRepository.class);
    public final OrderConsumer.ErrorHandler errorHandler =  mock(OrderConsumer.ErrorHandler.class);
    public final EventContext eventContext = mock(EventContext.class);
    public final CommandContext commandContext = mock(CommandContext.class);
    public final Firewall firewall;
    public final TestOrderFactory testOrderFactory = new TestOrderFactory();
    public final UpdatablePrecisionClock precisionClock = new UpdatablePrecisionClock();
    public final TestExecutionReportFactory testExecutionReportFactory = new TestExecutionReportFactory();

    public FirewallTestContext(final FirewallFactory firewallFactory, final String firewallName, final String[] ruleConfigStrings, final String[] executionReportStubStrings, final String[] usersStrings) {


        final FirewallConfig.Body[] ruleConfigs = Table.parse(FirewallConfig.Body.class, ruleConfigStrings);
        final TestExecutionReportFactory.ExecutionReportStub[] executionReportStubs = Table.parse(TestExecutionReportFactory.ExecutionReportStub.class, executionReportStubStrings);
        final User[] users = Table.parse(User.class, usersStrings);

        Arrays.stream(users).forEach(user -> when(userRepository.lookup(user.userName)).thenReturn(new com.anz.markets.efx.fox.api.domain.User(user.userName, EnumSet.noneOf(UserGroup.class), "GB", user.desk)));

        when(eventContext.precisionClock()).thenReturn(precisionClock);
        when(commandContext.precisionClock()).thenReturn(precisionClock);

        this.firewall = firewallFactory.create(firewallName, userRepository, errorHandler);

        Arrays.stream(ruleConfigs).forEach(body -> {
            final FirewallConfig firewallConfig = new FirewallConfig(new MessageHeader(), body);
            firewallConfig.encode(sorCodec.encoderSupplier());

            firewall.applyFirewallConfigRuleResponse(eventContext, sorCodec.firewallConfigSbeDecoder());
        });

        Arrays.stream(executionReportStubs).forEach(executionReportStub -> {
            final ExecutionReportDecoder executionReport = testExecutionReportFactory.createExecutionReport(executionReportStub);
            precisionClock.accept(executionReportStub.timeNanos);
            firewall.applyExecutionReport(eventContext, executionReport);
        });
    }

    public static class User {
        public String userName;
        public String desk;
    }

    public  OrderConsumer.ErrorHandler getErrorHandler() {
        return errorHandler;
    }
}
