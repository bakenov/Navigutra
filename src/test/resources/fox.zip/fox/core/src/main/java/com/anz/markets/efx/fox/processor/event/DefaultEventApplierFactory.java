package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.agrona.collections.MutableLong;
import org.tools4j.eventsourcing.api.EventApplierFactory;
import org.tools4j.eventsourcing.api.MessageConsumer;
import org.tools4j.eventsourcing.api.ProgressState;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.sbe.SbeSorDecoderBuilder;
import com.anz.markets.efx.fox.codec.sbe.SbeSorDecoders;
import com.anz.markets.efx.fox.common.MessageConsumerToDecoderAdapter;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.common.pricing.PricingFeed;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.fox.processor.state.health.Health;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.eventsourcing.UpdatablePrecisionClock;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.api.domain.UserSessionRepository;
import com.anz.markets.efx.fox.processor.timer.TimerController;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingHandlerSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoderBuilder;

public class DefaultEventApplierFactory implements EventApplierFactory {
    private final UpdatablePrecisionClock updatablePrecisionClock;
    private final MessageDecoder<SbeMessage> compositeMessageDecoder;

    public DefaultEventApplierFactory(final SnapshotFullRefreshHandler stateUpdatingSnapshotterFullRefreshHandler,
                                      final ParentOrderRepository.WithInit parentOrderRepository,
                                      final ChildOrderRepository childOrderRepository,
                                      final VenueRepository venueRepository,
                                      final InstrumentRepository instrumentRepository,
                                      final VenueInstrumentRepository venueInstrumentRepository,
                                      final UserRepository userRepository,
                                      final UserSessionRepository userSessionRepository,
                                      final MutableLong idGeneratorOffset,
                                      final UpdatablePrecisionClock updatablePrecisionClock,
                                      final TimerController timerController,
                                      final Health health,
                                      final String foxSenderCompId,
                                      final Firewall inboundFirewall,
                                      final PricingFeed.OpenOrdersObserver pricingFeedOpenOrders) {
        Objects.requireNonNull(stateUpdatingSnapshotterFullRefreshHandler);
        Objects.requireNonNull(parentOrderRepository);
        Objects.requireNonNull(childOrderRepository);
        Objects.requireNonNull(venueRepository);
        Objects.requireNonNull(userRepository);
        Objects.requireNonNull(userSessionRepository);
        Objects.requireNonNull(timerController);
        Objects.requireNonNull(inboundFirewall);
        Objects.requireNonNull(health);
        Objects.requireNonNull(foxSenderCompId);
        this.updatablePrecisionClock = Objects.requireNonNull(updatablePrecisionClock);

        final SbePricingDecoders sbePricingDecoders = new SbePricingDecoders();
        final SorDecoders sorDecoders = new SbeSorDecoders();

        final EventContext eventContext = () -> updatablePrecisionClock;

        final MessageDecoder<SbeMessage> newOrderSingleEvent =
                new ChildNewOrderSingleEvent(eventContext, childOrderRepository, parentOrderRepository);

        final MessageDecoder<SbeMessage> venueConfigEvent =
                new VenueConfigEvent(venueRepository);

        final MessageDecoder<SbeMessage> instrumentConfigEvent =
                new InstrumentConfigEvent(instrumentRepository);

        final MessageDecoder<SbeMessage> venueInstrumentConfigEvent =
                new VenueInstrumentConfigEvent(venueInstrumentRepository);

        final MessageDecoder<SbeMessage> userConfigEvent =
                new UserConfigEvent(userRepository);

        final MessageDecoder<SbeMessage> initialisationEvent =
                new InitialisationEvent(eventContext, idGeneratorOffset, health);

        final MessageDecoder<SbeMessage> heartbeatEvent =
                new HeartbeatEvent(foxSenderCompId, userSessionRepository, venueRepository);

        final FirewallConfigEvent firewallConfigEvent =
                new FirewallConfigEvent(eventContext, inboundFirewall);

        final MessageDecoder<SbeMessage> orderCancelRequestEvent = new ChildOrderCancelRequestEvent(childOrderRepository);

        final MessageDecoder<SbeMessage> executionReportEvent =
                new ParentExecutionReportEvent(eventContext, parentOrderRepository, inboundFirewall, pricingFeedOpenOrders::applyExecutionReport)
                        .orThen(new ChildExecutionReportEvent(updatablePrecisionClock, childOrderRepository));

        final MessageDecoder<SbeMessage> orderCancelRejectEvent = new ParentOrderCancelRejectEvent(updatablePrecisionClock, parentOrderRepository)
                .orThen(new ChildOrderCancelRejectEvent(childOrderRepository));

        final MessageDecoder<SbeMessage> tradingEvent = SbeTradingDecoderBuilder.create()
                .orderCancelRequest(orderCancelRequestEvent)
                .orderCancelReject(orderCancelRejectEvent)
                .executionReport(executionReportEvent)
                .newOrderSingle(newOrderSingleEvent)
                .heartbeat(heartbeatEvent)
                .build();

        final MessageDecoder<SbeMessage> sorEvent = SbeSorDecoderBuilder.create()
                .timerExpiry(timerController.timerExpiryEvent())
                .venueConfig(venueConfigEvent)
                .instrumentConfig(instrumentConfigEvent)
                .venueInstrumentConfig(venueInstrumentConfigEvent)
                .userConfig(userConfigEvent)
                .initialisation(initialisationEvent)
                .firewallConfig(firewallConfigEvent)
                .build();

        final MessageDecoder<SbeMessage> snapshotFullRefresh = sbePricingDecoders.snapshotFullRefresh().create(PricingHandlerSupplier.snapshotFullRefresh(stateUpdatingSnapshotterFullRefreshHandler),
                MessageDecoder.ForwardingLookup.noop());
        compositeMessageDecoder = tradingEvent.orThen(snapshotFullRefresh).orThen(sorEvent);
    }

    @Override
    public MessageConsumer create(final ProgressState currentEventApplyingState,
                                  final ProgressState completedEventApplyingState) {

        final MessageConsumer clockUpdater = (directBuffer, i, i1) -> {
            updatablePrecisionClock.accept(currentEventApplyingState.eventTimeNanos());
        };
        return clockUpdater.andThen(new MessageConsumerToDecoderAdapter(compositeMessageDecoder));
    }
}
