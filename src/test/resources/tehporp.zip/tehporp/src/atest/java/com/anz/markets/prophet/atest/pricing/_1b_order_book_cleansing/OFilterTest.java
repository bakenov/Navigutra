package com.anz.markets.prophet.atest.pricing._1b_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.junit.Ignore;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * O-Filter : Order book dispersion filter (if crossed exclude market with highest variance)
 */
public class OFilterTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault disabledOtherFilters() {

        ConfigurationDataDefault config = tdd.configuration_pricing_base()
                .setFilterEnabledConfigs(union(
                        tdd.disableFilter(MarketDataFilterType.MARKET_BOOK_CROSSED),
                        tdd.disableFilter(MarketDataFilterType.AGG_BOOK_CROSSED),
                        tdd.enableFilter(MarketDataFilterType.AGG_BOOK_DISPERSION)
                ));

        return config;
    }


    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_8)
    @DisplayName("TOB inverted equal to threshold - no market filtered")
    public void WHEN_TOB_inverted_within_threshold_SHOULD_not_remove_market_with_highest_variance() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = disabledOtherFilters();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1.5
             * threshold = 0.2 * 1.5 = 0.3 pips / 0.00003
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.5).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75011, 0.75015));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75012));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75015, 0.75018));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75015, 0.75012));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_8)
    @DisplayName("Remove market with highest variance - latest market update removed")
    public void TOB_inverted_beyond_threshold_THEN_latest_market_update_removed_since_highest_variance() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = disabledOtherFilters();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1.25
             * threshold = 0.2 * 1.25= 0.25 pips / 0.000025
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.25).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75007, 0.75016)); // mid 0.750115
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75011, 0.75015)); // mid 0.75013
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75012)); // mid 0.75011
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75012));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB(-0.3pip) which is greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75015, 0.75018)); // mid 0.750165
        }

        then:
        {
            // Since crossed TOB is beyond threshold then outlier market is removed, no changed in price.
            // AVERAGE MID 0.75013
            // CNX MID FURTHEST from AVG MID => CNX MKT REMOVED
            prophet.notExpect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U));

            // todo: check cnx has ofilter failed for wspu filters.
        }

    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_8)
    @DisplayName("Remove market with highest variance - previous market removed")
    public void TOB_inverted_beyond_threshold_THEN_previous_market_removed_since_highest_variance() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = disabledOtherFilters();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1.25
             * threshold = 0.2 * 1.25= 0.25 pips / 0.000025
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.25).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75009, 0.75014)); // mid 0.750115
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75009, 0.75015)); // mid 0.75012
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75007, 0.75010)); // mid 0.750085
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(2), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_2M, 0.75009, Level.QTY_1M, 0.75010));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB(-0.3pip) which is greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75013, 0.75014)); // mid 0.750135
        }

        then:
        {
            // Since crossed TOB is beyond threshold, outlier market is removed:
            // AVERAGE MID 0.75011375
            // HSP MID FURTHEST from AVG MID BY 0.0000287  => HSP MKT REMOVED
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75013, 0.75014));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_8)
    @DisplayName("removal of outlier market results in TOB spread greater than std spread")
    public void abort_remove_outlier_if_resultant_tob_spread_too_wide() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = disabledOtherFilters();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1.25
             * threshold = 0.2 * 1.25= 0.25 pips / 0.000025
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.25).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75007, 0.75016)); // mid 0.750115
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75011, 0.75015)); // mid 0.75013
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75014)); // mid 0.75012
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75014));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75017, 0.75018)); // mid 0.750175
        }

        then:
        {
            // With CNX the TOB is crossed beyond threshold.
            // AVERAGE MID 0.750135
            // CNX MID FURTHEST from AVG MID BY 0.00004
            // If CNX removed, TOB[1.00011, 1.00014] spread[0.3] is greater than standard-spread[0.2]
            // Therefore CNX is not excluded
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(), is(FilterDecision.PASS)); // AXPROPHET-1055
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75017, 0.75014));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_8)
    @DisplayName("removal of outlier market results in TOB spread equal to std spread")
    public void remove_outlier_if_resultant_tob_spread_equals_std_spread() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = disabledOtherFilters();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 0.5
             * threshold = 0.2 * 0.5 = 0.1 pips / 0.00001
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(0.5).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75007, 0.75016)); // mid 0.750115
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75012, 0.75015)); // mid 0.750135
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75014)); // mid 0.75012
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75014));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75016, 0.75018)); // mid 0.75017
        }

        then:
        {
            // With CNX the TOB is crossed beyond threshold.
            // AVERAGE MID 0.750135
            // CNX MID FURTHEST from AVG MID BY 0.000035
            // If CNX removed, TOB[1.00012, 1.00014] spread[0.2] is equal to standard-spread[0.2]
            // Therefore proceed with CNX removal, mid price remain the same and does not get published.
            prophet.notExpect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U));
        }
    }

    @Ignore("see comments in final then step")
    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_8)
    @DisplayName("outlier market tie - do not remove any market")
    public void do_not_remove_mkt_if_outlier_tie_exists() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = disabledOtherFilters();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1.25
             * threshold = 0.2 * 1.25= 0.25 pips / 0.000025
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.25).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75007, 0.75019)); // mid 0.75013
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75010, 0.75015)); // mid 0.750125
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75011)); // mid 0.750105
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75010, 0.75011));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75015, 0.75015)); // mid 0.75015
        }

        then:
        {
            // With CNX the TOB is crossed beyond threshold.
            // AVERAGE MID 0.7501275. SD = 0.00001848  => SQRT (SUM(|mkt mid - avg mid|)/(no. mkt -1))
            // Only  CNX and HSP outside (AVG_Mid +/- SD)
            // BOTH CNX and HSP MID EQUAL FURTHEST from AVG MID BY |0.00002250| (Since tie, no market is excluded)
            // However code calculates distance to boundaries (AVG_Mid +/- SD) and thus the diff are not 100% equal
            // i.e 0.000004015772489207590 vs 0.00000401577248931861
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75015, 0.75011));
        }
    }

}
