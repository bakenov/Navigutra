package com.anz.axle.adapters.rmds.consumer.filtering;

import com.anz.axle.adapters.rmds.consumer.D3ForwardQuote;
import com.anz.axle.common.util.Decision;
import com.anz.markets.adapters.trep.Item;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISOPeriodFormat;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class MaturityFilterTest {
    private static final DateTimeFormatter dd_MMM_yyyy = DateTimeFormat.forPattern("dd MMM yyyy");
    private static final String MATURITY = "MATUR_DATE";
    private static final String SPOT_DATE = "GV1_DATE";

    @Test
    public void shouldPassItemWithMaturityDateWithinTheLimit() {
        MaturityFilter filter = new MaturityFilter();
        Decision decision = filter.filter(new D3ForwardQuote(item(today(), today()), true));

        assertTrue(decision.get());
    }

    @Test
    public void shouldPassItemWithMaturityDateAtTheLimit() {
        MaturityFilter filter = new MaturityFilter();

        Decision decision = filter.filter(new D3ForwardQuote(item(today(), twoYearsOneMonthAfterToday()), true));

        assertTrue(decision.get());
    }

    @Test
    public void shouldNotPassItemWithMaturityDateOverTheLimit() {
        MaturityFilter filter = new MaturityFilter();

        Decision decision = filter.filter(new D3ForwardQuote(item(today(), twoYearsOneMonthOneDayAfterToday()), true));

        assertFalse(decision.get());
    }

    @Test
    public void shouldNotPassItemWithEmptySpotDate() {
        MaturityFilter filter = new MaturityFilter();

        Decision decision = filter.filter(new D3ForwardQuote(item(null, twoYearsOneMonthOneDayAfterToday()), true));
        assertFalse(decision.get());

        decision = filter.filter(new D3ForwardQuote(item(today(), null), true));
        assertFalse(decision.get());
    }

    private String today() {
        return LocalDate.now().toString(dd_MMM_yyyy);
    }

    private String twoYearsOneMonthAfterToday() {
        return LocalDate.now().plus(Period.parse("P2Y1M", ISOPeriodFormat.standard())).toString(dd_MMM_yyyy);
    }

    private String twoYearsOneMonthOneDayAfterToday() {
        return LocalDate.now().plus(Period.parse("P2Y1M1D", ISOPeriodFormat.standard())).toString(dd_MMM_yyyy);
    }

    private Item item(String tradeDate, String maturityDate) {
        Map<String, String> fields = new HashMap<String, String>();
        fields.put(SPOT_DATE, tradeDate);
        fields.put(MATURITY, maturityDate);

        Item item = new Item();
        item.setFields(fields);

        return item;
    }

}
