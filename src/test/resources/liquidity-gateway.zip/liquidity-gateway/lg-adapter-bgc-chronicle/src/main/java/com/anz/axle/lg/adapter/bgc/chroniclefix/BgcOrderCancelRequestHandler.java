package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import static com.anz.axle.lg.adapter.quickfix.FixSide.side;

public class BgcOrderCancelRequestHandler implements OrderCancelRequestHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcOrderCancelRequestHandler.class);

    private final FixMessageSender fixMessageSender;
    private final OrderCancelRequest orderCancelRequest;

    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));

    public BgcOrderCancelRequestHandler(final FixMessageSender fixMessageSender) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.orderCancelRequest = new DefaultOrderCancelRequest();
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        orderCancelRequest.reset();
    }

    @Override
    public void onBody(final OrderCancelRequestHandler.Body body) {
        final String symbol7 = body.symbol().decodeAndCache(symbol7Cache);
        final String origClOrdId = body.origClOrdId().decodeStringOrNull();
        orderCancelRequest.clOrdID(orderCancelRequest.clOrdID_buffer());
        orderCancelRequest.clOrdID().append(body.clOrdId().decodeLongOrZero());

        orderCancelRequest.origClOrdID(orderCancelRequest.origClOrdID_buffer());
        orderCancelRequest.origClOrdID().append(body.origClOrdId().decodeLongOrZero());

        orderCancelRequest.symbol(symbol7);
        orderCancelRequest.side(side(body.side()));
        orderCancelRequest.transactTime(body.transactTime());
        LOGGER.info("Sending Cancel origClOrdID={} symbol={}", origClOrdId, symbol7);
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(orderCancelRequest);
    }
}
