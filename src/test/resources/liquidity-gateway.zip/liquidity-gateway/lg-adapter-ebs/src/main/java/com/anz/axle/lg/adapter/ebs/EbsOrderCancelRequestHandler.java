package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.util.CharSequenceBuilder;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectEncoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.function.Consumer;

import static com.anz.axle.lg.adapter.ebs.EbsTranslator.orderType;
import static com.anz.axle.lg.adapter.ebs.EbsTranslator.timeInForce;
import static com.anz.axle.lg.adapter.quickfix.FixSide.side;
import static com.anz.markets.efx.trading.codec.api.TradingConstants.VAR_STRING_MAX_LENGTH;

public class EbsOrderCancelRequestHandler implements Consumer<OrderCancelRequestDecoder> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsOrderCancelRequestHandler.class);

    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));

    private final TradingEncoderSupplier tradingEncoderSupplier;
    private final FixMessageSender fixMessageSender;
    private final SessionState tradingSessionState;
    private final TenorLookup tenorLookup;
    private final LongIdFactory messageIdGenerator;
    private final PrecisionClock precisionClock;
    private final String compId;
    private final SourceSequencer sourceSequencer;

    private final OrderCancelRequest orderCancelRequest;
    private final CharSequenceBuilder charSequenceBuilder = new CharSequenceBuilder();
    private final FixedLengthAsciiString fixedLengthRejectText = new FixedLengthAsciiString(VAR_STRING_MAX_LENGTH);

    public EbsOrderCancelRequestHandler(final TradingEncoderSupplier tradingEncoderSupplier,
                                        final FixMessageSender fixMessageSender,
                                        final SessionState tradingSessionState,
                                        final TenorLookup tenorLookup,
                                        final LongIdFactory messageIdGenerator,
                                        final PrecisionClock precisionClock,
                                        final String compId,
                                        final SourceSequencer sourceSequencer) {
        this.tradingEncoderSupplier = Objects.requireNonNull(tradingEncoderSupplier);
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.tradingSessionState = Objects.requireNonNull(tradingSessionState);
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.compId = Objects.requireNonNull(compId);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
        this.orderCancelRequest = new DefaultOrderCancelRequest();
    }

    @Override
    public void accept(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
        LOGGER.info("OrderCancelRequest received: {}", toString(orderCancelRequestDecoder));

        if (!tradingSessionState.getAsBoolean()) {
            sendOrderCancelReject(orderCancelRequestDecoder, fixedLengthRejectText.set("Session logged off"));
        } else {
            try {
                if (validateOrderCancelRequest(orderCancelRequestDecoder)) {
                    sendOrderCancelRequest(orderCancelRequestDecoder);
                }
            } catch (final RuntimeException e) {
                LOGGER.warn("Unexpected Exception:", e);
                sendOrderCancelReject(orderCancelRequestDecoder, fixedLengthRejectText.set(e.getMessage()));
            }
        }
    }

    private void reset() {
        orderCancelRequest.reset();
    }

    private void sendOrderCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
        reset();
        final OrderCancelRequestDecoder.Body body = orderCancelRequestDecoder.body();
        final String symbol7 = body.symbol().decodeAndCache(symbol7Cache);
        final String origClOrdId = body.origClOrdId().decodeStringOrEmpty();

        orderCancelRequest.clOrdID(orderCancelRequest.clOrdID_buffer());
        orderCancelRequest.clOrdID().append(body.clOrdId().decodeStringOrEmpty());

        orderCancelRequest.origClOrdID(orderCancelRequest.origClOrdID_buffer());
        orderCancelRequest.origClOrdID().append(origClOrdId);

        orderCancelRequest.orderID(orderCancelRequest.orderID_buffer());
        orderCancelRequest.orderID().append(body.orderId().decodeStringOrEmpty());

        orderCancelRequest.symbol(symbol7);
        orderCancelRequest.cFICode(FixCFICode.to(body.securityType()));
        final String settlType = tenorLookup.ebsTenor(body.settlType());
        if (settlType != null) {
            orderCancelRequest.settlType(settlType);
        }
        orderCancelRequest.side(side(body.side()));
        orderCancelRequest.ordType(orderType(body.ordType()));
        orderCancelRequest.orderQty(body.orderQty());
        orderCancelRequest.timeInForce(timeInForce(body.timeInForce()));
        orderCancelRequest.transactTime(body.transactTime());
        LOGGER.info("Sending Cancel origClOrdID={} symbol={}", origClOrdId, symbol7);

        fixMessageSender.accept(orderCancelRequest);
    }

    private boolean validateOrderCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {

        final OrderCancelRequestDecoder.Body body = orderCancelRequestDecoder.body();
        final String symbol7 = body.symbol().decodeAndCache(symbol7Cache);
        final OrderType orderType = body.ordType();
        final TimeInForce timeInForce = body.timeInForce();

        fixedLengthRejectText.clear();
        if (symbol7 == null) {
            fixedLengthRejectText.append("Symbol is Required.");
        }

        if (body.side() == null) {
            fixedLengthRejectText.append("Side is Required.");
        }

        if (!OrderType.LIMIT.equals(orderType) && !OrderType.FIXING_ORDER.equals(orderType)) {
            fixedLengthRejectText.append("OrdType must be LIMIT or FIXING_ORDER.");
        }

        if (!TimeInForce.GTC.equals(timeInForce) && !TimeInForce.IOC.equals(timeInForce) && !TimeInForce.FOK.equals(timeInForce)) {
            fixedLengthRejectText.append("TimeInForce must be GTC, IOC or FOX.");
        }

        if (OrderType.FIXING_ORDER.equals(orderType) && !TimeInForce.GTC.equals(timeInForce)) {
            fixedLengthRejectText.append("OrdType.FIXING_ORDER must have TimeInForce.GTC.");
        }

        if (fixedLengthRejectText.length() > 0) {
            sendOrderCancelReject(orderCancelRequestDecoder, fixedLengthRejectText);
            return false;
        }
        return true;
    }

    private void sendOrderCancelReject(final OrderCancelRequestDecoder orderCancelRequestDecoder, final CharSequence rejectText) {
        final long messageId = messageIdGenerator.get();
        final long sendingTimeNanos = precisionClock.nanos();
        final OrderCancelRequestDecoder.Body body = orderCancelRequestDecoder.body();
        final String symbol7 = body.symbol().decodeAndCache(symbol7Cache);
        final String origClOrdId = body.origClOrdId().decodeStringOrEmpty();

        final OrderCancelRejectEncoder.Body bodyEncoder = tradingEncoderSupplier.orderCancelReject().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(body.messageId())
                .orderId().encodeFrom(body.orderId())
                .clOrdId().encodeFrom(body.clOrdId())
                .origClOrdId().encodeFrom(body.origClOrdId())
                .clOrdLinkId().encodeFrom(body.clOrdLinkId())
                .ordStatus(OrderStatus.REJECTED)
                .transactTime(body.transactTime())
                .cxlRejResponseTo(OrderCancelRequestType.ORDER_CANCEL_REQUEST)
                .cxlRejReason(OrderCancelRejectReason.OTHER);

        final OrderCancelRequestDecoder.Hop hops = orderCancelRequestDecoder.hops();
        final Hops.Encoder.Next<OrderCancelRejectEncoder.Text> hopsGroup = bodyEncoder.partiesEmpty().hopsStart(hops.count() + 1);
        for (OrderCancelRequestDecoder.Hop hop : hops) {
            hopsGroup.next().hopReceivingTime(hop.hopReceivingTime())
                    .hopSendingTime(hop.hopSendingTime())
                    .hopMessageId(hop.hopMessageId())
                    .hopCompId().encodeFrom(hop.hopCompId());
        }

        hopsGroup.next()
                .hopCompId().encode(compId)
                .hopMessageId(messageId)
                .hopReceivingTime(sendingTimeNanos)
                .hopSendingTime(sendingTimeNanos)
                .hopsComplete()
                .text().encode(rejectText)
                .messageComplete();
        LOGGER.info("Rejected OrderCancelRequest origClOrdID={} symbol={} rejectText={}", origClOrdId, symbol7, rejectText);
    }

    private CharSequence toString(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
        return charSequenceBuilder.clear().append(orderCancelRequestDecoder::appendTo).get();
    }
}
