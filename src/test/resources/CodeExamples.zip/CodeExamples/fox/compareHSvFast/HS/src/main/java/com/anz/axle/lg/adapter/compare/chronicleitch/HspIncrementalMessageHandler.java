package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.itch.staticcode.parsers.MessageParserBase;
import software.chronicle.itchcboe.messages.CancelOrder;
import software.chronicle.itchcboe.messages.ModifyOrder;
import software.chronicle.itchcboe.messages.NewOrder;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import software.chronicle.itchcboe.messages.server.Sequenced;

public final class HspIncrementalMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(HspIncrementalMessageHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final LongSupplier sequenceNumberSupplier;
    private final String senderCompId;
    private final String compId;
    private final SymbolOrderIdSideLookUp symbolOrderIdSideLookUp;
    private final SequenceTimestampParser sequenceTimestampParser;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public HspIncrementalMessageHandler(final VenueRequestKeyLookup requestKeyLookup,
                                        final PricingEncoderLookup pricingEncoderLookup,
                                        final PrecisionClock precisionClock,
                                        final SubscriptionManager subscriptionManager,
                                        final LongSupplier sequenceNumberSupplier,
                                        final String senderCompId,
                                        final String compId,
                                        final SymbolOrderIdSideLookUp symbolOrderIdSideLookUp,
                                        final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshflagsAppender,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.sequenceNumberSupplier = Objects.requireNonNull(sequenceNumberSupplier);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.symbolOrderIdSideLookUp = Objects.requireNonNull(symbolOrderIdSideLookUp);
        this.sequenceTimestampParser = new SequenceTimestampParser(precisionClock);
        this.flagsAppender = Objects.requireNonNull(incrementalRefreshflagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    public ChronicleMessageHandler<NewOrder> newOrderHandler() {
        return (message) -> {
            final long sendingTime = sequenceTimestampParser.sendingTimeNanosOrNow((Sequenced) MessageParserBase.sequencedHolderTl.get());
            final long receivingTimeNanos = precisionClock.nanos();
            LOGGER.debug("NewOrder received: {}", message);

            final String symbol7 = message.ccyPair();
            final EntryType side = side(message.buySell());
            final double amount = message.amount();
            final double price = message.price();
            final Bytes orderId = message.orderId();

            final MarketDataSubscription subscription = subscriptionManager.lookupBySymbol(symbol7);

            final StringToIntCache entryIdCache = subscription.stringToIntCache();
            final int entryId = entryIdCache.put(orderId.toString());
            symbolOrderIdSideLookUp.cache(subscription.instrumentKey().instrumentId(), entryId, side);
            encode(sendingTime, receivingTimeNanos, UpdateAction.NEW , subscription, side, amount, price, entryId);
        };
    }

    public ChronicleMessageHandler<ModifyOrder> modifyOrderHandler() {
        return (message) -> {
            final long sendingTime = sequenceTimestampParser.sendingTimeNanosOrNow((Sequenced) MessageParserBase.sequencedHolderTl.get());
            final long receivingTimeNanos = precisionClock.nanos();
            LOGGER.debug("ModifyOrder received: {}", message);

            final String symbol7 = message.ccyPair();
            final double amount = (message.amount() == 0.0 ? Double.NaN : message.amount());
            final double price = Double.NaN;
            final Bytes orderId = message.orderId();
            final MarketDataSubscription subscription = subscriptionManager.lookupBySymbol(symbol7);

            final StringToIntCache entryIdCache = subscription.stringToIntCache();
            final int entryId = entryIdCache.put(orderId.toString());
            final int entryRefId = 0;

            final EntryType side = symbolOrderIdSideLookUp.lookUpSide(subscription.instrumentKey().instrumentId(), entryId);
            if (side == null) {
                LOGGER.info("Received ModifyOrder {} orderId={} ignored.", symbol7, orderId);
            }

            encode(sendingTime, receivingTimeNanos, UpdateAction.CHANGE, subscription, side, amount, price, entryId, entryRefId);
        };
    }

    public ChronicleMessageHandler<CancelOrder> cancelOrderHandler() {
        return (message) -> {
            final long sendingTime = sequenceTimestampParser.sendingTimeNanosOrNow((Sequenced) MessageParserBase.sequencedHolderTl.get());
            final long receivingTimeNanos = precisionClock.nanos();
            LOGGER.debug("CancelOrder received: {}", message);

            final String symbol7 = message.ccyPair();
            final Bytes orderId = message.orderId();

            final MarketDataSubscription subscription = subscriptionManager.lookupBySymbol(symbol7);

            final StringToIntCache entryIdCache = subscription.stringToIntCache();
            final int entryId = entryIdCache.remove(orderId.toString());

            final EntryType side = symbolOrderIdSideLookUp.remove(subscription.instrumentKey().instrumentId(), entryId);
            if (side != null) {
                encode(sendingTime, receivingTimeNanos, UpdateAction.DELETE, subscription, side, 0.0, 0.0, entryId);
            } else {
                LOGGER.info("Received CancelOrder {} orderId={} ignored.", symbol7, orderId);
            }
        };
    }

    private void encode(final long sendingTimeNanos, final long receivingTimeNanos, final UpdateAction updateAction, final MarketDataSubscription subscription, final EntryType side, final double amount, final double price, final int entryId) {
        encode(sendingTimeNanos, receivingTimeNanos, updateAction, subscription, side, amount, price, entryId, 0);
    }

    private void encode(final long sendingTimeNanos, final long receivingTimeNanos, final UpdateAction updateAction, final MarketDataSubscription subscription, final EntryType side, final double amount, final double price, final int entryId, final int entryRefId) {

        final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
        final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        flagsAppender.accept(encoder.mdFlags());

        final long messageId = sequenceNumberSupplier.getAsLong();

        final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next = encoder
            .senderCompId().encode(compId)
            .messageId(messageId)
            .marketId(requestKey.market())
            .instrumentId(requestKey.instrumentKey().instrumentId())
            .sendingTime(sendingTimeNanos)
            .referenceSpotDate().encodeNull()
            .tradeDate().encodeNull()
            .settlDate().encodeNull()
            .entriesStart(1);

        mdEntries_Next.next()
            .mdUpdateAction(updateAction)
            .transactTime(sendingTimeNanos)
            .mdMkt(requestKey.market())
            .mdEntryType(side)
            .mdEntrySize(amount)
            .mdEntryPx(price)
            .mdEntryId(entryId)
            .mdEntryRefId(entryRefId)
            .quoteEntryId(0);

        mdEntries_Next.entriesComplete()
            .hopsStart(2)
            .next()
            .hopCompId().encode(senderCompId)
            .hopMessageId(messageId)
            .hopReceivingTime(0)
            .hopSendingTime(receivingTimeNanos)
            .next()
            .hopCompId().encode(compId)
            .hopMessageId(messageId)
            .hopReceivingTime(receivingTimeNanos)
            .hopSendingTime(precisionClock.nanos())
            .hopsComplete()
            .messageComplete();
    }

    private EntryType side(final char side) {
        switch(side) {
            case 'B':
                return EntryType.BID;
            case 'S':
                return EntryType.OFFER;
            default:
                throw new IllegalArgumentException(side + " is not recognised");
        }
    }
}
