package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.hedging.volume.HedgePauseState;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.features.StanddownMidHedgersOnNoSkewFeatureSpecs;
import com.anz.markets.prophet.pricer.pfp.features.StanddownSkewPnLFeatureSpecs;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import org.hamcrest.CoreMatchers;
import org.hamcrest.core.Is;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static com.anz.markets.prophet.matcher.LamdaMatcher.f;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 ** AXPROPHET-1143 Stand down skewing strategy
 *  Stand down skewing when all 3 conditions met:
 *  1) Vol is below maxVolatility
 *  2) UnrealisedPnLPips is between minUnrealisedPnLPips and maxUnrealisedPnLPips AND
 *  3) UnrealisedPnLUSD is between minUnrealisedPnLUSD and maxUnrealisedPnLUSD
 *  4) ccy Position(USD) above  minPositionUSD
 *
 *  MANUAL Skew will override any active Stand Down skew
 *
 *  AXPROPHET-1326 Stand down skewing strategies will now also send signal
 *  to PAUSE Mid Hedger
 **/
public class Stand_Down_Skewing_PnL_Test extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig2 = new ArrayList<>();
        StanddownSkewPnLFeatureSpecs specs = StanddownSkewPnLFeatureSpecs.INSTANCE;
        StanddownMidHedgersOnNoSkewFeatureSpecs specs2 = StanddownMidHedgersOnNoSkewFeatureSpecs.INSTANCE;

        // set up config for indirect pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, 1.0,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, -100.0,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, 100.0,
                specs.PARAM_MIN_UNREALISED_PNL_USD, -100_000.0,
                specs.PARAM_MAX_UNREALISED_PNL_USD, 100_000.0,
                specs.PARAM_MIN_POSITION_USD, 4004000.0)
        );

        // set up config for direct pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                directPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, 0.2,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, -0.4,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, 0.5,
                specs.PARAM_MIN_UNREALISED_PNL_USD, -100_000.0,
                specs.PARAM_MAX_UNREALISED_PNL_USD, 182.0,
                specs.PARAM_MIN_POSITION_USD, 2600000.0)
        );

        // set up config for cross driver pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                crossPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, 0.093,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, -100.0,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, 100.0,
                specs.PARAM_MIN_UNREALISED_PNL_USD, -100_000.0,
                specs.PARAM_MAX_UNREALISED_PNL_USD, 100_000.0,
                specs.PARAM_MIN_POSITION_USD, 100.0)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.EURUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, 5.0,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, -0.4,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, 0.6,
                specs.PARAM_MIN_UNREALISED_PNL_USD, -26.0,
                specs.PARAM_MAX_UNREALISED_PNL_USD, 24.9,
                specs.PARAM_MIN_POSITION_USD, 100.0)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, Double.NaN,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, Double.NaN,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, Double.NaN,
                specs.PARAM_MIN_UNREALISED_PNL_USD, Double.NaN,
                specs.PARAM_MAX_UNREALISED_PNL_USD, Double.NaN,
                specs.PARAM_MIN_POSITION_USD, Double.NaN)
        );

        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                Market.WSP_A,
                directPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs2.PARAM_TARGET_HEDGERS, "MID_BGC_EP|MID_BGC_VAR")
        );

        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs2.PARAM_TARGET_HEDGERS, "")
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0)
                ))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(com.google.common.collect.Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ));

        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME,priceFormationPipelineConfig);
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs2.NAME,priceFormationPipelineConfig2);

        return configuration;
    }

    @Test
    @RestartBeforeTest(reason="reset vol")
    @RelatedTest(Optimal_Position_Risk_Skew_and_NOP_Skew_Combined.class)
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1143})
    public void stand_down_skew() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generated optimal positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 500_000, 78.420));
        }
        and:
        // receive USDJPY
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // STAND DOWN SKEWING
        {
            // unrealised pnl = 103.875 - 103.870 = +0.5 pip is between min(-0.4) and max(0.5) AND
            // unrealised pnl usd is between -100 and +182
            // Therefore STAND DOWN
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(3774910.946375277));
            assertThat(positionsUpdate.getPosition1().getAvgRate(), is(103.875));
            assertThat(positionsUpdate.getPosition1().getMidRate(), is(103.870));
            assertThat(positionsUpdate.getPosition1().getPnl(), f(pnl -> (pnl> 0 & pnl < 182))); // profit

            // usd position above min_usd_pos(2600000) => stand down
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, atLeast(1),isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition usdJpyOp = optimalPositionsUpdate.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == directPair).findFirst().get();
            assertThat(Math.abs(usdJpyOp.getGradientPositionInSystemBase()), f(gradPosUsd -> (gradPosUsd > 2_600_000)));

            // vol below max vol(0.2) => stand down
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(realisedVolatility.factorWindow(), Is.is(FactorWindow.CAT_A));
            assertThat(realisedVolatility.volatility(), f(vol -> (vol < 0.11)));

            // Stand down skew is ACTIVE!! Mid is UNSKEWED
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.870));  // UNSKEWED MID

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].oldVal, f(oldVal -> (oldVal > 0.0)));  // i.e skew existed
            assertThat(ftl.operations[0].newVal, is(0.0));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewPnLFeatureSpecs.DATA_UNREALISED_PNL_PIPS));
            assertThat(ftl.data[0].fx, isRoundedTo(0.5));
            assertThat(ftl.data[1].var.toString(), is(StanddownSkewPnLFeatureSpecs.DATA_UNREALISED_PNL_USD));
            assertThat(ftl.data[1].fx, isRoundedTo(181.7));

            // Client Price is unskewed
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(directPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getUnskewedMid(), isRoundedTo(103.870));
            assertThat(clientPrice.getSkewedMid(), is(clientPrice.getUnskewedMid()));
            assertThat(clientPrice.getMidRate(), isRoundedTo(103.870));
        }
        and:
        // send pause signal to hedger
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.PAUSED));
        }
        when:
        // receive USDJPY manual skew - overrides stand down skew
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.JPY, 0.1));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.869)); // 103.870 - 0.001
        }
        and:
        // since SKEWING state changed, send NOT PAUSED signal to Hedgers
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.NOT_PAUSED));
        }
        when:
        // receive USDJPY (and reset manual skew)
        {
            prophet.receive(tdd.manualSkew(Currency.JPY, 0.0));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.869, 0.004));
        }
        then:
        {
            // unrealised pnl = 103.875 - 103.870 = +0.6 pip is oustide of min(-0.4) and max(0.5) => do NOT stand down
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdate.getPosition1().getAvgRate(), is(103.875));
            assertThat(positionsUpdate.getPosition1().getMidRate(), is(103.869));
            assertThat(positionsUpdate.getPosition1().getPnl(), f(pnl -> (pnl > 0.0))); // profit

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.870068));  // OP SKEWED MID
        }
        and:
        // since SKEWING state changed, send PAUSED signal to Hedgers
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.NOT_PAUSED));
        }
        when:
        // receive EURUSD
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.09995, 0.0005));
        }
        // unrealised pnl = 1.09995 - 1.1000 = -0.5 pip is NOT between min(-0.4) and max(0.6) => DO NOT stand down skew
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));
            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(1).getPosition1().getAvgRate(), is(1.10000));
            assertThat(positionsUpdates.get(1).getPosition1().getMidRate(), is(1.09995));
            assertThat(positionsUpdates.get(1).getPosition1().getPnl(), is(-25.0)); // loss

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Instrument.EURUSD, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(1.0999524)); // skewed
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewPnLFeatureSpecs.DATA_UNREALISED_PNL_PIPS));
            assertThat(ftl.data[0].fx, isRoundedTo(-0.5));
        }
        when:
        // receive EURUSD
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10005, 0.0005));
        }
        then:
        // unrealised pnl = 1.10005 - 1.1000 = 0.5 pip IS between min(-0.4) and max(0.6) BUT
        // unrealised pnl USD = +25 is NOT between -26 -> 24 => do NOT stand down skewing
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));
            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(1).getPosition1().getAvgRate(), is(1.10000));
            assertThat(positionsUpdates.get(1).getPosition1().getMidRate(), is(1.10005));
            assertThat(positionsUpdates.get(1).getPosition1().getPnl(), is(25.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Instrument.EURUSD, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(1.1000524)); // skewed
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewPnLFeatureSpecs.DATA_UNREALISED_PNL_PIPS));
            assertThat(ftl.data[0].fx, isRoundedTo(0.5));
            assertThat(ftl.data[1].var.toString(), is(StanddownSkewPnLFeatureSpecs.DATA_UNREALISED_PNL_USD));
            assertThat(ftl.data[1].fx, isRoundedTo(25.0));
        }
        when:
        // receive EURNOK
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.10040, 0.0006));
        }
        then:
        // realisedVol ABOVE maxVol(0.093) => do NOT stand down skewing
        {
            RealisedVolatility realisedVolatility = prophet.expect(RealisedVolatility.class, exactly(1)).getLast();
            assertThat(realisedVolatility.factorWindow(), Is.is(FactorWindow.CAT_A));
            assertThat(realisedVolatility.volatility(), f(vol -> (vol > 0.093)));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(9.09850));  // skewed
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_WARM));
        }
        when:
        // receive AUDUSD
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // AUDUSD gradientPosition is NOT above minPositionUSD(4004000)
        {
            final OptimalPositions optimalPositionsUpdate = prophet.expect(OptimalPositions.class, atLeast(1),isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition op = optimalPositionsUpdate.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), f(pos -> (pos < 4_004_000d)));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.7510619));  // skewed
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_COLD));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_COLD));
        }
        when:
        // activate skew pause to verify Pause overrides
        {
            // Pause skewing enabled
            prophet.receive(tdd.setSkewingPause(Currency.AUD, true));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
        }
        then:
        // since Skew Pause is ACTIVE, do not SKEW MID
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.75100));
        }
    }
}