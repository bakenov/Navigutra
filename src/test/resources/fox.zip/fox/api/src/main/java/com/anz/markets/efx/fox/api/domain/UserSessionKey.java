package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.codec.api.Region;

public interface UserSessionKey {
    UserSessionKey UNKNOWN = new UserSessionKey() {
        @Override
        public String sessionId() {
            return null;
        }

        @Override
        public String userName() {
            return null;
        }

        @Override
        public String portfolio() {
            return null;
        }

        @Override
        public Region region() {
            return null;
        }
    };

    String sessionId();
    String userName();
    String portfolio();
    Region region();

    static UserSessionKey of(final String sessionId, final String userName, final String portfolio, final Region region) {
        return new DefaultUserSessionKey(sessionId, userName, portfolio, region);
    }
}
