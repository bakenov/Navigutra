package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.HeartbeatResponse;
import com.anz.axle.lg.config.PricingEncoderLookup;

/**
 * Decodes Apama events as defined by {@link com.anz.axle.lg.adapter.apama.event.HeartbeatResponse}
 */
public final class HeartbeatResponseDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(HeartbeatResponseDecoder.class);


    private final PricingEncoderLookup pricingEncoderLookup;
    private final String transport;

    public HeartbeatResponseDecoder(final PricingEncoderLookup pricingEncoderLookup, final String transport) {
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.transport = Objects.requireNonNull(transport);
    }

    @Override
    public void decode(final Event event) {
        final String eventTransport = event.getField(HeartbeatResponse.FIELD_TRANSPORT);
        if (transport.equals(eventTransport)) {
            final boolean connected = event.getField(HeartbeatResponse.FIELD_CONNECTED);
            if (connected) {
                LOGGER.info("Received connected heartbeat for {}", eventTransport);
                pricingEncoderLookup.forwardCurrentSnapshots();
            } else {
                LOGGER.info("Received disconnected heartbeat for {}", eventTransport);
                pricingEncoderLookup.clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_DISCONNECTED);
            }
        }
    }
}
