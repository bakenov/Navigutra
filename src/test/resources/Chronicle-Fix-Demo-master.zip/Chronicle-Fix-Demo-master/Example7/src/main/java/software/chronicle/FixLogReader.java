package software.chronicle;

import net.openhft.chronicle.core.Mocker;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.DocumentContext;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.staticcode.msgseq.fixlog.VanillaFixLog;
import software.chronicle.generated.code.messages.HeaderTrailer;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.function.Consumer;

public class FixLogReader implements Runnable {

    private final BlockingQueue<HeaderTrailer> queue;
    private final MessageNotifier deserialiser;
    private final MessageParser messageParser;
    private final ExcerptTailer tailer;
    private final FixLog fixLog;
    private final Consumer<HeaderTrailer> messageConsumer;

    public FixLogReader(Consumer<HeaderTrailer> messageConsumer) {
        final SingleChronicleQueue log = SingleChronicleQueueBuilder.binary("log").build();
        this.queue = new ArrayBlockingQueue<>(1);
        this.deserialiser = Mocker.intercepting(
                MessageNotifier.class,
                (s, objects) -> messageConsumer.accept((HeaderTrailer) objects[1]),
                null);
        this.messageParser = new MessageParser();
        this.tailer = log.createTailer();
        this.fixLog = new VanillaFixLog();
        this.messageConsumer = messageConsumer;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try (@NotNull DocumentContext dc = tailer.readingDocument()) {
                if (!dc.isPresent())
                    continue;
                // read from FixLog, deserialise FIX message and pass to messageConsumer
                dc.wire().getValueIn().marshallable(fixLog);
                messageParser.parse(fixLog.msg(), deserialiser);
            }
        }
    }
}