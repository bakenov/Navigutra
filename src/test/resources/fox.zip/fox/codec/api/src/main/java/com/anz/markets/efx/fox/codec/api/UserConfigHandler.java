package com.anz.markets.efx.fox.codec.api;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface UserConfigHandler extends MessageDecoder.Handler {
    @Override
    default void onMessageStart(final int source, final long sourceSeq) {
    }

    void onBody(Body body);

    @Override
    default void onMessageComplete() {
    }

    interface Body {
        StringDecoder userName();
        EnumerableSetDecoder<UserGroup> userGroups();
        StringDecoder location();
    }

    @FunctionalInterface
    interface DecoderFactory<M> extends MessageDecoder.Factory<M, UserConfigHandler>, SorDecoders.DecoderFactory<M> {
        @Override
        default MessageDecoder<M> create(final SorHandlerSupplier sorHandlerSupplier, final MessageDecoder.ForwardingLookup<M> forwardingLookup) {
            return create((Supplier<UserConfigHandler>) sorHandlerSupplier::userConfigHandler, forwardingLookup);
        }
    }
}
