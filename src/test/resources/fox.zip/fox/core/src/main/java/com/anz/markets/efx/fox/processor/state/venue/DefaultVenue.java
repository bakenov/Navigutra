package com.anz.markets.efx.fox.processor.state.venue;

import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.Venue;
import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.processor.timer.Timer;

public class DefaultVenue implements Venue {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultVenue.class);

    private final com.anz.markets.efx.ngaro.api.Venue venueId;
    private final String compId;
    private final EnumSet<VenueCategory> venueCategories;
    private final Timer missedHeartbeatTimer;
    private final long missedHeartbeatTimeoutMillis;

    private boolean enabled;
    private boolean online;

    public DefaultVenue(final com.anz.markets.efx.ngaro.api.Venue venueId,
                        final String compId,
                        final EnumSet<VenueCategory> venueCategories,
                        final boolean enabled,
                        final Timer.Factory timerFactory,
                        final long missedHeartbeatTimeoutMillis) {
        this.venueId = Objects.requireNonNull(venueId);
        this.compId = Objects.requireNonNull(compId);
        this.venueCategories = Objects.requireNonNull(venueCategories);
        this.enabled = enabled;
        this.online = false;
        this.missedHeartbeatTimeoutMillis = missedHeartbeatTimeoutMillis;
        this.missedHeartbeatTimer = timerFactory.create(new VenueMissedHeartbeatHandler(this));
    }

    @Override
    public com.anz.markets.efx.ngaro.api.Venue venueId() {
        return venueId;
    }

    @Override
    public String compId() {
        return compId;
    }

    @Override
    public Set<VenueCategory> venueCategories() {
        return venueCategories;
    }

    @Override
    public boolean enabled() {
        return enabled;
    }

    @Override
    public void updateOffline() {
        if (online()) {
            LOGGER.info("Venue {} goes offline", venueId);
            online = false;
        }
    }

    @Override
    public void updateOnline() {
        if(!online()) {
            LOGGER.info("Venue {} goes online", venueId);
            online = true;
        }
        missedHeartbeatTimer.cancel();
        missedHeartbeatTimer.schedule(missedHeartbeatTimeoutMillis);
    }

    @Override
    public boolean online() {
        return online;
    }

    public DefaultVenue enabled(final boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    @Override
    public String toString() {
        return "DefaultVenue{" +
                "venueId=" + venueId +
                ", compId='" + compId + '\'' +
                ", venueCategories=" + venueCategories +
                ", missedHeartbeatTimeoutMillis=" + missedHeartbeatTimeoutMillis +
                ", enabled=" + enabled +
                ", online=" + online +
                '}';
    }
}
