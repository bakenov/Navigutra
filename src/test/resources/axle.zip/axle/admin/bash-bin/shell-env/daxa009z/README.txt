Certain contents of this folder (in particular the dot-files and bin) are managed from SVN.

The process for updating dot files is either:

A) make changes in ~/bin/shell-env/daxa009z and check in to SVN
B) update ~/bin/shell-env/daxa009z from SVN

The process for updating bin is either:
A) make changes in ~/bin and check in to SVN
B) update ~/bin from SVN
