package com.anz.markets.prophet.pricer.wholesale;


import com.anz.markets.disco.data.SignalRegisters;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.pricer.control.VolatilityFactorCache;
import com.anz.markets.prophet.pricer.pfp.cache.ClientPriceDataRegisterDependencyManager;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.pricer.pfp.features.ManualSkewFeature;
import com.anz.markets.prophet.pricer.pfp.features.PauseSkewFeature;
import com.anz.markets.prophet.pricer.pfp.features.StanddownMidHedgersOnNoSkewFeature;
import com.anz.markets.prophet.pricer.skew.SkewConfigProvider;
import com.anz.markets.prophet.pricer.wholesale.spreads.ArbitrageSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.EconomicsNewsSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.ManualSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.MarketGapSpreadAdjustmentStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.OverallSpreadFormationStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.RiskAdjustedSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.VolatilitySpreadStrategy;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.io.IOException;
import java.util.function.Consumer;

import static com.anz.markets.prophet.pricer.wholesale.DriverInstrumentWholesaleBookManagerTest.MIDRATE_AUDUSD_075;
import static org.junit.Assert.assertTrue;

@Ignore("see MarketGapSpreadAdjustmentStrategyBWTest, there is some GC that needs to be addressed...")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DriverInstrumentWholesaleBookManagerBWTest {

    private final NoOpConsumer<ClientPrice> noOpConsumer = new NoOpConsumer<>();
    private final NotifierDefault notifierDefault = new NotifierDefault<ClientPrice>().register(noOpConsumer);

    private final NoOpConsumer<WholesaleBookFactors> noOpConsumerWholesaleBookFactors = new NoOpConsumer<>();
    private final NotifierDefault notifierWholesaleBookFactors = new NotifierDefault<WholesaleBookFactors>().register(noOpConsumerWholesaleBookFactors);

    private final Consumer<MidRate> midRateConsumer;

    private final DataRegisters dataRegisters = new DataRegisters();
    private final SkewConfigProvider skewConfigProvider = new SkewConfigProvider();
    private final StanddownMidHedgersOnNoSkewFeature standdownMidHedgersOnNoSkewFeature = new StanddownMidHedgersOnNoSkewFeature(new NotifierDefault<>());
    private final ManualSkewFeature manualSkewFeature = new ManualSkewFeature(new SkewConfigProvider());
    private final PauseSkewFeature pauseSkewFeature = new PauseSkewFeature(skewCurrencyControl -> {
    });
    private final ManualSpreadStrategy manualSpreadStrategy = new ManualSpreadStrategy((market, instrument) -> VolatilityFactorCache.UNSET_VOL_FACTOR);
    private final VolatilitySpreadStrategy volatilitySpreadStrategy = new VolatilitySpreadStrategy();
    private final EconomicsNewsSpreadStrategy economicsNewsSpreadStrategy = new EconomicsNewsSpreadStrategy();
    private final RiskAdjustedSpreadStrategy riskAdjustedSpreadStrategy = new RiskAdjustedSpreadStrategy();
    private final BenchmarkSpreadStrategy benchmarkSpreadStrategy = new BenchmarkSpreadStrategy();
    private final MarketGapSpreadAdjustmentStrategy marketGapSpreadAdjustmentStrategy = new MarketGapSpreadAdjustmentStrategy();
    private final ArbitrageSpreadStrategy arbitrageSpreadStrategy = new ArbitrageSpreadStrategy();
    private final OverallSpreadFormationStrategy overallSpreadFormationStrategy = new OverallSpreadFormationStrategy();
    private final DriverStackSpreadAndWeightCalculatorImpl driverStackFormationStrategy = new DriverStackSpreadAndWeightCalculatorImpl();
    private final DriverStackFromBandedCalculator driverStackFromBandedCalculator = new DriverStackFromBandedCalculatorImpl();
    private final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager = new ClientPriceDataRegisterDependencyManager(dataRegisters);

    private final DriverInstrumentWholesaleBookManager driverInstrumentWholesaleBookManager;

    // this intermittently causes issue at 100_000 reps
    private static final int REPS = 200_000, THRESHOLD = 1000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private int counter = 0;

    public DriverInstrumentWholesaleBookManagerBWTest() throws IOException {
        driverInstrumentWholesaleBookManager = new DriverInstrumentWholesaleBookManager(notifierDefault, notifierWholesaleBookFactors, skewConfigProvider,
                standdownMidHedgersOnNoSkewFeature, manualSkewFeature, pauseSkewFeature, manualSpreadStrategy, volatilitySpreadStrategy, economicsNewsSpreadStrategy,
                riskAdjustedSpreadStrategy, benchmarkSpreadStrategy, marketGapSpreadAdjustmentStrategy, arbitrageSpreadStrategy,
                overallSpreadFormationStrategy, driverStackFormationStrategy, driverStackFromBandedCalculator, clientPriceDataRegisterDependencyManager, new SignalRegisters(),true, true);
        driverInstrumentWholesaleBookManager.consumerIndexedConfigurationData().accept(new DriverInstrumentWholesaleBookManagerTest().indexedConfigurationData);
        clientPriceDataRegisterDependencyManager.setDriverInstrumentWholesaleBookManager(driverInstrumentWholesaleBookManager);
        midRateConsumer = dataRegisters.consumerOfMidRate();
    }

    public void scenario_SpreadBasedBookFormation() {
        midRateConsumer.accept(MIDRATE_AUDUSD_075);
        clientPriceDataRegisterDependencyManager.triggerPriceFormationAsNecessary();
        assertTrue(counter + 1 == noOpConsumer.size());
        ++counter;
    }

    @Test
    public void test_SpreadBasedBookFormation() {
        helper.testAllocationNotExceeded(
                this::scenario_SpreadBasedBookFormation,
                REPS, REPS,
                THRESHOLD
        );
    }

}
