package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MassCancelRequestType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderMassCancelRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultOrderMassCancelRequest;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public class EbsOrderMassCancelRequestHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsOrderMassCancelRequestHandler.class);
    private final FixMessageSender fixMessageSender;
    private final LongIdFactory messageIdGenerator;
    private final PrecisionClock precisionClock;
    private final OrderMassCancelRequest orderMassCancelRequest;

    public EbsOrderMassCancelRequestHandler(final FixMessageSender fixMessageSender,
                                            final LongIdFactory messageIdGenerator,
                                            final PrecisionClock precisionClock) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.orderMassCancelRequest = new DefaultOrderMassCancelRequest();
    }

    public void sendCancelAll() {
        orderMassCancelRequest.reset();

        orderMassCancelRequest.clOrdID(orderMassCancelRequest.clOrdID_buffer());
        orderMassCancelRequest.clOrdID().append(messageIdGenerator.get());

        orderMassCancelRequest.transactTime(precisionClock.millis());
        orderMassCancelRequest.massCancelRequestType(MassCancelRequestType.CANCEL_ALL_ORDERS);

        LOGGER.info("Sending OrderMassCancelRequest: {}", orderMassCancelRequest);
        fixMessageSender.accept(orderMassCancelRequest);
    }
}
