package com.anz.markets.efx.fox.receiver.pricing;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.LongFunction;

import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;

public class DrivingInstrumentIdFactory implements LongFunction<Long[]> {
    private final Map<String, List<String>> crossSymbolToDrivingSymbols;
    private final InstrumentKey.Lookup instrumentKeyLookup;

    public DrivingInstrumentIdFactory(final Map<String, List<String>> crossSymbolToDrivingSymbols) {
        this.crossSymbolToDrivingSymbols = Objects.requireNonNull(crossSymbolToDrivingSymbols);
        this.instrumentKeyLookup = new DefaultInstrumentKeyLookup();
    }

    @Override
    public Long[] apply(final long instrumentId) {
        final InstrumentKey instrumentKey = instrumentKeyLookup.lookup(instrumentId);
        final List<String> drivingSymbols = crossSymbolToDrivingSymbols.get(instrumentKey.symbol());
        final Long[] drivingInstruments;
        if (drivingSymbols != null) {
            drivingInstruments = new Long[drivingSymbols.size()];
            for (int i = 0; i < drivingSymbols.size(); i++) {
                final String drivingSymbol = drivingSymbols.get(i);
                drivingInstruments[i] = InstrumentKey.instrumentId(drivingSymbol, instrumentKey.securityType(), instrumentKey.tenor());
            }
        } else {
            drivingInstruments = new Long[0];
        }
        return drivingInstruments;
    }
}
