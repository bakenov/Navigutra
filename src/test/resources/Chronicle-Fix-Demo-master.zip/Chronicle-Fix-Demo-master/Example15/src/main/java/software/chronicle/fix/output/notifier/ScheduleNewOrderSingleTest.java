package software.chronicle.fix.output.notifier;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.DocumentContext;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.staticcode.msgseq.fixlog.VanillaFixLog;
import software.chronicle.generated.code.fields.HandlInst;
import software.chronicle.generated.code.fields.OrdType;
import software.chronicle.generated.code.fields.Side;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;
import software.chronicle.generated.code.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import static software.chronicle.fix.staticcode.FixInstance.fixEngineMain;

/**
 * @author Rob Austin.
 */
public class ScheduleNewOrderSingleTest {

    public static void main( String args[] ) throws Exception {
        new ScheduleNewOrderSingleTest().sendTestExecutionReportTest();
    }

    public void sendTestExecutionReportTest() throws Exception {

        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        FixEngineCfg cfg = Marshallable.fromFile("fix-config.yaml");
        TCPRegistry.reset();

        TCPRegistry.createServerSocketChannelFor("host.port");

        // this will be triggered when we have receieved the notification from the
        // outputMessageNotifier
        CountDownLatch latch = new CountDownLatch(1);

        // this is the message notifier for output messages [ in other words messages sent ]
        final MessageNotifier outputMessageNotifier = new MessageNotifier() {
            @Override
            public MessageGenerator onNewOrderSingle(final NewOrderSingle newOrderSingle) {
                System.out.println("OutputMessageNotifier : read=" + newOrderSingle);
                latch.countDown();
                return null;
            }
        };

        try (SingleChronicleQueue outputQueue = outputQueue(cfg)) {

            final ExecutorService es = setupOutputMessageNotifier(outputMessageNotifier, outputQueue);

            try (final ChronicleFixEngine acceptor = fixEngineMain(1, cfg)) {

                FixSessionHandler session = acceptor.sessions().stream().findFirst().get();
                NewOrderSingle orderSingle = new DefaultNewOrderSingle();

                orderSingle.account(Bytes.from("XYZ"));
                orderSingle.clOrdID(Bytes.from("orderId"));
                orderSingle.price(101.45676);
                orderSingle.side(Side.BUY);
                orderSingle.ordType(OrdType.LIMIT);
                orderSingle.symbol(Bytes.from("ICI.L"));
                orderSingle.handlInst(HandlInst.MANUAL_ORDER_BEST_EXECUTION);
                orderSingle.transactTime(System.currentTimeMillis());
                session.sendMessage(orderSingle);

                // wait for one message to be consumed by the OutputMessageNotifier
                latch.await();
                es.shutdownNow();
            }
        }
    }

    private ScheduledExecutorService setupOutputMessageNotifier(MessageNotifier messageNotifier, SingleChronicleQueue outputQueue) {

        final MessageParser messageParser = new MessageParser();
        final FixLog fixLog = new VanillaFixLog();
        final ExcerptTailer tailer = outputQueue.createTailer().toEnd();
        final ScheduledExecutorService es = Executors.newSingleThreadScheduledExecutor();
        Bytes output = Bytes.elasticByteBuffer();
        es.submit(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try (@NotNull DocumentContext dc = tailer.readingDocument()) {
                    if (!dc.isData())
                        continue;
                    fixLog.copyMsg(dc.wire().bytes(), output);
                    messageParser.parse(output, messageNotifier);
                }
            }
        });

        return es;
    }

    private SingleChronicleQueue outputQueue(final FixEngineCfg cfg) {
        FixSessionCfg sc = cfg.fixSessionCfgs().iterator().next();
        SessionID sessionID = SessionID.create(sc);
        @NotNull final String dataDir = sc.fileStorePath() + "/" + sessionID.localCompID() + "/" + sessionID.remoteCompID();
        return SingleChronicleQueueBuilder.binary(dataDir).build();
    }

}

