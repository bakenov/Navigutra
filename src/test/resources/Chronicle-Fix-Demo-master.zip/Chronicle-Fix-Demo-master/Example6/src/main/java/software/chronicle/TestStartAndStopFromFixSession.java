package software.chronicle;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.*;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * @author Rob Austin.
 */
public class TestStartAndStopFromFixSession {

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(
                FixEngineCfg.class,
                FixSessionCfg.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                LoggingMode.class,
                MessageParser.class,
                MessageGenerator.class,
                FixLogConsumer.class,
                VanillaSessionMessageProvider.class,
                SendAfterLogonClientMessageNotifier.class,
                SendAfterLogonServerMessageNotifier.class,
                VanillaMsgSequenceHandle.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);

    }

    private final FixSessionCfg sessionCfg = Marshallable.fromString("!FixSessionCfg {\n" +
            "    AllowSequenceResetDecrease: true,\n" +
            "    HostId: 2,\n" +
            "    FileStorePath: test-send-msg-after-logon/initiator2,\n" +
            "    ConnectionType: initiator,\n" +
            "    MessageNotifier: !software.chronicle.SendAfterLogonClientMessageNotifier { },\n" +
            "    ConnectionStrategy: !AlwaysStartOnPrimaryConnectionStrategy { },\n" +
            "    TargetCompID: CHRONICLE_FIX_ACCEPTOR, #  localCompID\n" +
            "    SenderCompID: CF_FIX_CLIENT,\n" +
            "    FixVersion: V4_2,\n" +
            "    HeartBtInt: 1,\n" +
            "    MessageGenerator: !MessageGenerator { },\n" +
            "    Consumer: !FixLogConsumer { },\n" +
            "    LoggingMode: !LoggingMode UNBUFFERED,   # it's only the MASTER than must have the ACKNOWLEDGED logging mode\n" +
            "    SocketAcceptorHostPort: hostname.12345,     # change to <hostname>:<port> if you want to use a real host port\n" +
            "    SocketConnectHostPort: [ hostname.12345 ],  # change to <hostname>:<port> if you want to use a real host port\n" +
            "    AutoLogon: true,    # must be set to true if using failover\n" +
            "    LoggingMode: !LoggingMode UNBUFFERED,   # its only the MASTER than must have the ACKNOWLEDGED logging mode\n" +
            "    MessageGenerator: !MessageGenerator { },\n" +
            "    MsgSequenceHandler: !VanillaMsgSequenceHandle { },\n" +
            "    MessageParser: !MessageParser {  },\n" +
            "    AutoStart: false,\n" +
            "    TimestampResolution: !TimeUnit MILLISECONDS\n" +
            "}\n");

    public static void main(String[] args) throws IOException, InterruptedException, TimeoutException
    {
        new TestStartAndStopFromFixSession().test();
    }

    /**
     * tests send data as a response to a login message
     */
    public void test() throws IOException, InterruptedException, TimeoutException {

        IOTools.deleteDirWithFiles("test-send-msg-after-logon", 10);

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("hostname.12345");

        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("test-send-msg-after-logon-without-autostart.yaml");

        try (ChronicleFixEngine acceptor = FixInstance.fixEngineMain(1, fixEngineCfg)) {
            final SendAfterLogonServerMessageNotifier serverMessageNotifier = (SendAfterLogonServerMessageNotifier) acceptor.sessions().iterator().next().messageNotifier();

            final ChronicleFixEngine fixEngine = new ChronicleFixEngine(); // starts the engine without connecting to anything

            final FixSessionHandler session = fixEngine.add(sessionCfg); // creates a session without connecting to anything
            final SendAfterLogonClientMessageNotifier clientMessageNotifier = (SendAfterLogonClientMessageNotifier) session.messageNotifier();
            {
                session.start(); // starts the session and initiates connection

                // time passes.....
                final String actual = clientMessageNotifier.queue().poll(10, TimeUnit.SECONDS);
                assert actual.contains("price: 200.0");
                assert serverMessageNotifier.sessionAlive();
                assert clientMessageNotifier.sessionAlive();

                session.stop(); // disconnects and stops the session

                Thread.sleep(100);
                assert !serverMessageNotifier.sessionAlive();
                assert !clientMessageNotifier.sessionAlive();
            }

            clientMessageNotifier.queue().clear();

            {
                session.start(); // starts the session and initiates connection

                // time passes.....
                final String actual = clientMessageNotifier.queue().poll(10, TimeUnit.SECONDS);
                assert actual.contains("price: 200.0");
                assert serverMessageNotifier.sessionAlive();
                assert clientMessageNotifier.sessionAlive();

                session.stop(); // disconnects and stops the session

                Thread.sleep(100);
                assert !serverMessageNotifier.sessionAlive();
                assert !clientMessageNotifier.sessionAlive();
            }
        }
    }
}
