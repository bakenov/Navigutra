package software.chronicle.fix.sendasync;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.threads.EventHandler;
import net.openhft.chronicle.core.threads.HandlerPriority;
import net.openhft.chronicle.core.threads.InvalidEventHandlerException;
import net.openhft.chronicle.core.time.SetTimeProvider;
import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.WireIn;
import net.openhft.chronicle.wire.Wires;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import static software.chronicle.generated.code.messages.NewOrderSingle.newNewOrderSingle;

/**
 * @author Rob Austin.
 */
public class ClientMessageNotifier implements EventHandler, MessageNotifier, Demarshallable {

    private final BlockingQueue<String> q;

    private FixSessionHandler fixSessionHandler;

    private long triggerTimeNanos = Long.MAX_VALUE;

    private ClientMessageNotifier(WireIn w) {
        q = new ArrayBlockingQueue<String>(1);
    }

    @NotNull
    private static NewOrderSingle newOrderSingle(FixSessionContext context) {
        final NewOrderSingle serverExpects = newNewOrderSingle(Wires.acquireBytes(), context);
        serverExpects.ordType('2');
        serverExpects.side('1');
        serverExpects.symbol(Bytes.from("LCOM1"));
        serverExpects.clOrdID(Bytes.allocateDirect("CL_ORD_ID".getBytes()));
        serverExpects.handlInst('3');
        serverExpects.transactTime(context.timeProvider().currentTimeMillis());
        serverExpects.orderQty(1);
        serverExpects.price(200.0);
        serverExpects.timeInForce('0');
        serverExpects.maturityMonthYear("201106");
        serverExpects.securityType("FUT");
        serverExpects.idSource("5");
        serverExpects.securityID(Bytes.from("LCOM1"));
        serverExpects.account(Bytes.from("ABCTEST1"));
        return serverExpects;
    }

    public void triggerTimeNanos(long triggerTimeNanos) {
        this.triggerTimeNanos = triggerTimeNanos;
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }

    @Override
    public MessageGenerator onExecutionReport(ExecutionReport executionReport) {
        System.out.println("received - onExecutionReport=" + executionReport);
        String e = executionReport.toString();
        q.add(e);
        return null;
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        this.fixSessionHandler = session;
        if (session.context().timeProvider() instanceof SetTimeProvider) {
            //testing only.
            ((SetTimeProvider) session.context().timeProvider()).advanceNanos(500_000);
        }
    }

    public BlockingQueue<String> queue() {
        return q;
    }

    @Override
    public boolean action() throws InvalidEventHandlerException, InterruptedException {
        if (fixSessionHandler != null && fixSessionHandler.context().timeProvider().currentTimeNanos() >= triggerTimeNanos) {
            fixSessionHandler.sendMessage(newOrderSingle(fixSessionHandler.context()));
            throw new InvalidEventHandlerException("Done");
        } else {
            return false;
        }
    }

    @NotNull
    public HandlerPriority priority() {
        return HandlerPriority.TIMER;
    }
}
