#!/bin/bash

set -e

function display_help {
    echo "Usage: ./suffix-artifacts-version-with-revision-number.sh -r <svn_revision>"
    exit -1
}

while [[ $# > 1 ]]
do
key="$1"
value="$2"
case $key in
    -r|--svnrevision)
    SVN_REVISION="$value"
    shift
    ;;
    *)
      # unknown option
      display_help
    ;;
 esac
 shift
done

if [ -z "${SVN_REVISION}" ] ; then
  display_help
fi


echo "INFO:  This script will suffix pom versions with given svn revision number. e.g., 4.7-SNAPSHOT will become 4.7-342343 "
echo "INFO:  This is done for the purpose of building artifacts that is non snapshot and has svn revision in the file name of the artifact."
echo "INFO:  The modified poms are not intended to be checked in but can be deployed into all environments."
echo "INFO:"
echo "INFO:  Checking that ~/teamcity/setenv.sh exists. If it does it will be executed. This is for when the script runs within teamcity."

if [ -e ~/teamcity/setenv.sh ] ; then
  echo "INFO:  Sourcing ~/teamcity/setenv.sh"
  source ~/teamcity/setenv.sh
fi

echo "INFO:  Checking that working copy is pristine and up-to-date."

# Note: changing artifact name can be done differently (by specifying artifacts name directly - finalname) but this is a much more generic way to control the artifacts name.
#       the modified pom are not intended to be checked in.

echo "INFO:  Appending poms with revision number. Note this will not be checked in."

RELEASE_VERSION=`mvn help:evaluate --no-snapshot-updates -Dexpression=project.version -Dhttps.protocols=TLSv1 -Dmaven.wagon.http.ssl.insecure=true -Dmaven.wagon.http.ssl.allowall=true | egrep -v '(^\[|Download\w+:)' | sed 's/^branch\.//; s/\([0-9.]*\).*/\1/'`
if [ -z $RELEASE_VERSION ] ; then  
  echo "ERROR: Could not extract release version from pom. Perhaps mvn is not working?" && exit -1
fi

RELEASE_VERSION_WITH_SVN_REVISION=$RELEASE_VERSION-$SVN_REVISION

echo Updating all poms with current SVN Revision: $RELEASE_VERSION_WITH_SVN_REVISION

# release plugin doesn't allow you to update pom version to be non snapshot
mvn versions:set -DgenerateBackupPoms=false -Dhttps.protocols=TLSv1 -Dmaven.wagon.http.ssl.insecure=true -Dmaven.wagon.http.ssl.allowall=true -DnewVersion=$RELEASE_VERSION_WITH_SVN_REVISION -q || (echo "ERROR: Could not update poms to Release Candidate version." && exit -1)

echo "INFO:  Done! All poms have been updated to $RELEASE_VERSION_WITH_SVN_REVISION"

