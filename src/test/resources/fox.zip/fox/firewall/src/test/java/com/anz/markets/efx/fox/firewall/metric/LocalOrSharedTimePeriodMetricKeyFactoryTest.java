package com.anz.markets.efx.fox.firewall.metric;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.codec.sbe.SorCodecUtil;
import com.anz.markets.efx.fox.firewall.metric.LocalOrSharedTimePeriodMetricKeyFactory;
import static org.assertj.core.api.Assertions.assertThat;



@RunWith(Spockito.class)
public class LocalOrSharedTimePeriodMetricKeyFactoryTest {
    private final SorCodecUtil.Codec sorCodec = SorCodecUtil.create();

    @Test
    @Spockito.Unroll({
            "| ruleId   | local    | periodUnit    | period   | metricKey |",
            "|==========|==========|===============|==========|===========| ",
            "| 10       | false    | ms            | 86400000 | 86400000  | ",
            "| 20       | false    | s             | 86400    | 86400000  | ",
            "| 30       | false    | m             | 1440     | 86400000  | ",
            "| 40       | false    | hr            | 24       | 86400000  | ",
            "| 50       | false    | d             | 1        | 86400000  | ",
            "| 60       | true     | d             | 1        | -60       | ",
            "| 100      | true     | d             | 1        | -100      | ",
            "|----------|----------|---------------|----------|-----------| "
    })
    public void applyAsLong(final long ruleId, final boolean local, final String periodUnit, final long period, final long metricKey) {
        //given
        sorCodec.encoderSupplier().firewallConfigEncoder().messageStart(1, 2)
                .firewallName().encode("someFirewall")
                .ruleId(ruleId)
                .period(period)
                .periodUnit().encode(periodUnit)
                .local(local)
                .limitThreshold(0)
                .messageComplete();

        final LocalOrSharedTimePeriodMetricKeyFactory factory = new LocalOrSharedTimePeriodMetricKeyFactory();
        //when and then
        assertThat(factory.applyAsLong(sorCodec.firewallConfigSbeDecoder())).isEqualTo(metricKey);
    }
}