package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.DefaultApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.EncodingSubscriptionSender;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.FixEngine;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.UserRequestEncoder;
import com.anz.axle.lg.adapter.chroniclefix.tools.FixLogConsumer;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestSender;
import com.anz.axle.lg.adapter.fix.UserRequestData;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.google.common.collect.ImmutableMap;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static com.anz.axle.lg.adapter.fix.UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER;
import static com.anz.axle.lg.adapter.fix.UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_LOGOFFUSER;
import static com.anz.axle.lg.adapter.fix.UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_LOGONUSER;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    private final String compId;
    private final String senderCompId;
    private final Venue venue;

    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId,
                     @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public SessionID ebsSessionId(@Value("${ebs.fix.sendercompid}") final String ebsSenderCompid,
                                  @Value("${ebs.fix.targetcompid}") final String ebsTargetCompid) {
        return new SessionID(ebsSenderCompid, ebsTargetCompid);
    }

    @Bean
    public SubscriptionRequestSender ebsEncodingSubscriptionSender(final FixMessageSender ebsMessageSender,final TenorLookup tenorLookup) {
        return new EncodingSubscriptionSender(new EbsMarketDataRequestEncoder(tenorLookup), ebsMessageSender);
    }

    @Bean
    public SessionState ebsSessionState() {
        return new SessionState("EBS_Session");
    }

    @Bean
    public Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> ebsIncrementalRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState ebsSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(ebsSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public EbsUserResponseHandler ebsUserResponseHandler(final UserRequestHandler ebsUserRequestHandler,
                                                         final PricingSubscription ebsPricingSubscription,
                                                         final PasswordManager ebsPasswordManager,
                                                         final EbsBookRules ebsBookRules) {
        return new EbsUserResponseHandler(venue, ebsUserRequestHandler, ebsPricingSubscription, ebsPasswordManager, ebsBookRules);
    }

    @Bean
    public FixMessageSender ebsMessageSender(final SessionID ebsSessionId, @Lazy final FixEngine ebsFixEngine) {
        return new FixMessageSender(() ->
                ebsFixEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(ebsSessionId)).findFirst().get());
    }

    @Bean
    public EventLoop ebsChronicleEventLoop() {
        final EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false, venue.name()+"-");
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter ebsEventLoopStep(final EventLoop ebsChronicleEventLoop) {
        return new EventLoopAdapter(ebsChronicleEventLoop);
    }

    @Bean
    public FixEngineCfg fixEngineCfg(final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/ebs-chroniclefix.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final FixEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

    @Bean
    public TradingSessionRepository tradingSessionRepository() {
        return new DefaultTradingSessionRepository();
    }

    @Bean
    public TradingSessionParser tradingSessionParser(@Value("#{${ebs.fix.session.source.value.mapping}}") final Map<String, String> sourceMap,
                                                     @Value("#{${ebs.fix.session.timezone.value.mapping}}") final Map<String, String> timeZoneMap) {
        return new TradingSessionParser(sourceMap, timeZoneMap);
    }

    @Bean
    public EbsExecutionReportMergeHandler ebsFillExecutionReportHandler(final TradingEncoderSupplier ebsTradingEncoderSupplier,
                                                                        final PrecisionClock precisionClock,
                                                                        final LongIdFactory messageIdGenerator,
                                                                        final TenorLookup tenorLookup,
                                                                        final SourceSequencer sourceSequencer,
                                                                        final MetricRepository<Metric, Venue> metricRepository,
                                                                        @Value("${ebs.ExecutionReport.object.pool.initial.size}") final int executionReportObjectPoolInitialSize) {

        final EbsExecutionReportHandler executionReportHandler = new EbsExecutionReportHandler(ebsTradingEncoderSupplier, precisionClock, senderCompId, compId, messageIdGenerator::get, tenorLookup, venue, sourceSequencer);
        final MonitoredQueue.MetricRecorder<Venue> tradingMetricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);

        return new DefaultExecutionReportMergeHandler(new MonitoredChronicleMessageHandler<>(executionReportHandler, tradingMetricRecorder), executionReportObjectPoolInitialSize);
    }

    @Bean
    public FixEngine ebsFixEngine(final FixEngineCfg fixEngineCfg,
                                  final ApplicationLogonHandler applicationLogonHandler,
                                  @Value("${appOptions:}") final String appOptions,
                                  final Consumer<FixLog> ebsFixLogConsumer,
                                  final VenueRequestKeyLookup ebsRequestKeyLookup,
                                  final PricingEncoderLookup pricingEncoderLookup,
                                  final PricingEncoderSupplier lastMarketTradePricingEncoderSupplier,
                                  final PrecisionClock precisionClock,
                                  final SubscriptionManager ebsSubscriptionManager,
                                  final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy,
                                  final EbsUserResponseHandler ebsUserResponseHandler,
                                  final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> ebsIncrementalRefreshEncoderFlagsAppender,
                                  final TradingSessionRepository tradingSessionRepository,
                                  final EventLoopAdapter ebsEventLoopStep,
                                  final MetricRepository<Metric, Venue> metricRepository,
                                  final TradingEncoderSupplier ebsTradingEncoderSupplier,
                                  final LongIdFactory messageIdGenerator,
                                  final TenorLookup tenorLookup,
                                  @Value("${ebs.fix.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                  final TradingSessionParser tradingSessionParser,
                                  final UserRequestHandler ebsUserRequestHandler,
                                  final SourceSequencer sourceSequencer,
                                  final EbsExecutionReportMergeHandler ebsFillExecutionReportHandler) throws Exception {

        final FixSessionCfg ebsFixSessionCfg = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("ebs")).findFirst().get();
        ebsFixSessionCfg.sessionMessageProvider(new EbsSessionMessageProvider(venue.name(), OptionMatcher.HAS_RESET.test(appOptions), ebsFixSessionCfg));

        final EbsIncrementalRefreshHandler incrementalRefreshHandler =
                new EbsIncrementalRefreshHandler(ebsRequestKeyLookup, pricingEncoderLookup, lastMarketTradePricingEncoderSupplier, precisionClock, senderCompId, compId, ebsIncrementalRefreshEncoderFlagsAppender, tenorLookup, sourceSequencer);
        final EbsSnapshotFullRefreshHandler snapshotFullRefreshHandler =
                new EbsSnapshotFullRefreshHandler(ebsRequestKeyLookup, pricingEncoderLookup, precisionClock, ebsSubscriptionManager, senderCompId, compId, sourceSequencer);
        final DefaultMarketDataRequestRejectHandler marketDataRequestRejectHandler = new DefaultMarketDataRequestRejectHandler(ebsSubscriptionManager, subscriptionRequestRejectStrategy);

        final EbsOrderCancelRejectHandler orderCancelRejectHandler = new EbsOrderCancelRejectHandler(ebsTradingEncoderSupplier, precisionClock, senderCompId, compId, messageIdGenerator::get, tenorLookup, venue, sourceSequencer);
        final EbsTradingSessionListHandler tradingSessionListHandler = new EbsTradingSessionListHandler(tradingSessionRepository, tradingSessionParser);
        final EbsTradingSessionStatusHandler tradingSessionStatusHandler = new EbsTradingSessionStatusHandler(tradingSessionRepository);

        final MonitoredQueue.MetricRecorder<Venue> pricingMetricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value);
        final MonitoredQueue.MetricRecorder<Venue> tradingMetricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);

        final FixSessionApplication fixPricingApplication = new EbsFixSessionApplication(
                ebsUserResponseHandler,
                new MonitoredChronicleMessageHandler<>(incrementalRefreshHandler, pricingMetricRecorder),
                new MonitoredChronicleMessageHandler<>(snapshotFullRefreshHandler, pricingMetricRecorder),
                new MonitoredChronicleMessageHandler<>(marketDataRequestRejectHandler, pricingMetricRecorder),
                new MonitoredChronicleMessageHandler<>(orderCancelRejectHandler, tradingMetricRecorder),
                tradingSessionListHandler,
                tradingSessionStatusHandler,
                ebsFillExecutionReportHandler,
                applicationLogonHandler);
        ebsFixSessionCfg.messageNotifier(fixPricingApplication);

        ebsFixSessionCfg.consumer(ebsFixLogConsumer);

        final Consumer<FixSessionHandler> fixEngineLogoutHandler = f -> {
            ebsUserRequestHandler.send(USER_REQUEST_TYPE_LOGOFFUSER);
            for (int i = 0; i < waitForLogoutTimeoutInSec*2; i++) {
                LOGGER.info("Waiting for Application Session Logout Response and any messages after logout request...: {}", i+1);
                Jvm.pause(500);
            }
        };
        return FixEngine.create(venue.name()+"-FIX-ENGINE", fixEngineCfg.createInstance(ebsFixSessionCfg.hostId(), ebsEventLoopStep), fixEngineLogoutHandler, waitForLogoutTimeoutInSec);
    }

    @Bean
    public Consumer<FixLog> ebsFixLogConsumer(@Value("${ebs.fix.log_all}") final boolean enableLogging,
                                              @Value("${ebs.fix.file.log.path}") final String logPath,
                                              @Value("${ebs.fix.logging.base_path}") final String bashPath,
                                              @Value("${ebs.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public Supplier<String> passwordProvider(@Value("${ebs.fix.user.request.password}") final String password,
                                             @Value("${ebs.fix.user.password.file}") final String passwordPropertiesFileName) throws Exception {

        return new PasswordProvider(password, passwordPropertiesFileName);
    }

    @Bean
    public PasswordManager ebsPasswordManager(@Value("${ebs.fix.user.request.username}") final String userName,
                                              final Supplier<String> passwordProvider,
                                              @Value("${ebs.fix.user.password.file}") final String passwordPropertiesFileName) {
        return new PasswordManager(userName, passwordProvider.get(), venue, passwordPropertiesFileName);
    }

    @Bean
    public Supplier<UserRequestData> ebsLogonUserRequestData(final PasswordManager ebsPasswordManager,
                                                             @Value("#{${ebs.fix.user.request.custom.tag.values}}") final Map<Integer, String> customerTagValues,
                                                             @Value("#{${ebs.fix.user.request.name.values}}") final Map<String, String> userDataNameValues) {
        return () -> UserRequestData.logonUser(ebsPasswordManager.userName(), ebsPasswordManager.password(), customerTagValues, userDataNameValues);
    }

    @Bean
    public Supplier<UserRequestData> ebsLogoffUserRequestData(final PasswordManager ebsPasswordManager) {
        return () -> UserRequestData.logoffUser(ebsPasswordManager.userName(), ebsPasswordManager.password(), Collections.EMPTY_MAP, Collections.EMPTY_MAP);
    }

    @Bean
    public Supplier<UserRequestData> ebsChangePasswordUserRequestData(final PasswordManager ebsPasswordManager) {
        return () -> UserRequestData.changePasswordForUser(ebsPasswordManager.userName(), ebsPasswordManager.password(), ebsPasswordManager.generatePasswordAndSaveNewPassword());
    }

    @Bean
    public Map<UserRequestData.UserRequestDataType, Supplier<UserRequestData>> ebsUserRequestDataLookUp(final Supplier<UserRequestData> ebsLogonUserRequestData,
                                                                                                        final Supplier<UserRequestData> ebsLogoffUserRequestData,
                                                                                                        final Supplier<UserRequestData> ebsChangePasswordUserRequestData) {
        return ImmutableMap.of(
                USER_REQUEST_TYPE_LOGONUSER, ebsLogonUserRequestData,
                USER_REQUEST_TYPE_LOGOFFUSER, ebsLogoffUserRequestData,
                USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER, ebsChangePasswordUserRequestData
        );
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler(final SessionID ebsSessionId,
                                                           final Supplier<LogonHandler> ebsSessionLogonHandlerSupplier) {

        return new DefaultApplicationLogonHandler(sessionID -> {
            if (sessionID.equals(ebsSessionId)) {
                return ebsSessionLogonHandlerSupplier.get();
            } else {
                return LogonHandler.NO_OP;
            }
        });
    }

    @Bean
    public UserRequestEncoder<UserRequest> userRequestEncoder() {
        return new EbsUserRequestEncoder();
    }

    @Bean
    public BooleanSupplier readyToSendHeartbeat(final SessionState ebsSessionState, final MarketDataSubscriber marketDataSubscriber) {
        return () -> ebsSessionState.getAsBoolean() && marketDataSubscriber.loggedOn();
    }
}
