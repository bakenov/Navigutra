package com.anz.axle.lg.adapter.deut;

import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.LongConsumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.agrona.concurrent.UnsafeBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import quickfix.Message;

import com.anz.axle.lg.adapter.deut.quickfix.DeutLoggedOnNewOrderSingleHandler;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.trading.LoggedOffNewOrderSingleHandler;
import com.anz.axle.lg.adapter.trading.LoggedOffOrderCancelRequestHandler;
import com.anz.axle.lg.adapter.trading.LoggedOnOrderCancelRequestHandler;
import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.axle.lg.config.LongConsumerSupplier;
import com.anz.axle.lg.decoder.TradingRequestMessageHandler;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.CurrentMillisIdFactory;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Subscription;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestHandler;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.api.TradingHandlerSupplier;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoders;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingEncoders;

@Configuration
public class TradingConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(TradingConfig.class);

    private final String compId;

    public TradingConfig(@Value("${messaging.compId}") final String compId) {
        this.compId = Objects.requireNonNull(compId);
    }

    @Bean
    public Topic tradingResponseTopic(final PublicationRegistry publicationRegistry) {
        final Topic tradingResponseTopic = DefaultTopic.create("DEUT_TRADING_RESPONSE");
        publicationRegistry.registerPublication(tradingResponseTopic);
        return tradingResponseTopic;
    }

    @Bean
    public Topic tradingRequestTopic() {
        return DefaultTopic.create("DEUT_TRADING_REQUEST");
    }

    @Bean
    public CurrentMillisIdFactory tradingMessageIdGenerator() {
        return new CurrentMillisIdFactory();
    }

    @Bean
    public TradingEncoderSupplier tradingEncoderSupplier(@Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity,
                                                         final MessageHandler publisher,
                                                         final Topic tradingResponseTopic) {
        final Consumer<SbeMessage> tradingResponseConsumer = sbeMessage -> publisher.onMessage(
                tradingResponseTopic, sbeMessage.buffer(), 0, sbeMessage.messageLength(), 0
        );
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbeTradingEncoders(() -> sbeMessage).toTradingEncoderSupplier(tradingResponseConsumer);
    }

    @Bean
    public LongConsumerSupplier receivedTimeConsumerSupplier() {
        return new LongConsumerSupplier();
    }

    @Bean
    public Supplier<? extends NewOrderSingleHandler> newOrderSingleHandlerSupplier(final PrecisionClock precisionClock,
                                                                                   final SessionState tradingSessionState,
                                                                                   final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                                                                   final Consumer<Message> fixMessageSender,
                                                                                   @Qualifier("receivedTimeConsumerSupplier") final LongSupplier receivedTimeSupplier,
                                                                                   final LongIdFactory tradingMessageIdGenerator,
                                                                                   @Value("${deut.fix.trading.account}") final String fixAccount,
                                                                                   final SubscriptionManager subscriptionManager,
                                                                                   final SourceSequencer sourceSequencer) {

        final LoggedOffNewOrderSingleHandler loggedOffNewOrderSingleHandler = new LoggedOffNewOrderSingleHandler(tradingResponseEncoderSupplier, receivedTimeSupplier, precisionClock, compId, tradingMessageIdGenerator, sourceSequencer);
        final DeutLoggedOnNewOrderSingleHandler loggedOnNewOrderSingleHandler = new DeutLoggedOnNewOrderSingleHandler(fixMessageSender, subscriptionManager, fixAccount);
        return () -> tradingSessionState.select(loggedOnNewOrderSingleHandler, loggedOffNewOrderSingleHandler);
    }

    @Bean
    public Supplier<? extends OrderCancelRequestHandler> orderCancelRequestHandlerSupplier(final PrecisionClock precisionClock,
                                                                                           final SessionState tradingSessionState,
                                                                                           final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                                                                           @Qualifier("receivedTimeConsumerSupplier") final LongSupplier receivedTimeSupplier,
                                                                                           final LongIdFactory tradingMessageIdGenerator) {
        final LoggedOffOrderCancelRequestHandler loggedOffOrderCancelRequestHandler = new LoggedOffOrderCancelRequestHandler(tradingResponseEncoderSupplier, receivedTimeSupplier, precisionClock, compId, tradingMessageIdGenerator);
        return () -> tradingSessionState.select(new LoggedOnOrderCancelRequestHandler(), loggedOffOrderCancelRequestHandler);
    }

    @Bean
    public TradingRequestMessageHandler tradingRequestMessageHandler(@Qualifier("receivedTimeConsumerSupplier") final LongConsumer receivedTimeConsumer,
                                                                     final Supplier<? extends NewOrderSingleHandler> newOrderSingleHandlerSupplier,
                                                                     final Supplier<? extends OrderCancelRequestHandler> orderCancelRequestHandlerSupplier) {
        final MessageDecoder<SbeMessage> sbeMessageTradingDecoder = new SbeTradingDecoders()
                .newOrderSingleAndOrderCancelRequest()
                .create(TradingHandlerSupplier.newOrderSingleAndOrderCancelRequest(newOrderSingleHandlerSupplier, orderCancelRequestHandlerSupplier), MessageDecoder.ForwardingLookup.noop());
        return new TradingRequestMessageHandler(receivedTimeConsumer, sbeMessageTradingDecoder);
    }

    @Bean
    EndPointStatusHandler endPointStatusHandler() {
        return new LoggingStatusHandler(LOGGER);
    }

    @Bean
    public Subscription tradingRequestSubscription(final Connection connection,
                                                   final Topic tradingRequestTopic,
                                                   final EndPointStatusHandler endPointStatusHandler,
                                                   final MessageHandler tradingRequestMessageHandler) {
        return connection.openSubscription(tradingRequestTopic, endPointStatusHandler, tradingRequestMessageHandler);
    }
}
