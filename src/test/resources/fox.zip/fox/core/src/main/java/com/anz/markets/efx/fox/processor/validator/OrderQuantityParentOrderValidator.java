package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import java.util.Objects;

public class OrderQuantityParentOrderValidator implements ParentOrderValidator {
    private final ErrorHandler errorHandler;

    public OrderQuantityParentOrderValidator(final ErrorHandler handler) {
        this.errorHandler = Objects.requireNonNull(handler);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
        if (parentOrderDecoder.body().orderQty() > 0.0) {
            return true;
        }

        errorHandler.onError(OrderTextMessage.INVALID_QUANTITY.getText(), parentOrderDecoder, commandContext);
        return false;
    }
}
