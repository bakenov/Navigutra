package com.anz.markets.prophet.atest.framework;


import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Util {

    public static Map<Market, ClientPrice> intoMap(LinkedList<ClientPrice> prices) {
        Map<Market, ClientPrice> clientPriceMap = new HashMap<>();
        prices.forEach(clientPrice -> clientPriceMap.put(clientPrice.getMarket(), clientPrice));
        return clientPriceMap;
    }
}
