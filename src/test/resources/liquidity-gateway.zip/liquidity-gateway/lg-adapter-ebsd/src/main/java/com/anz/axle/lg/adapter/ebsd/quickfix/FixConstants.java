package com.anz.axle.lg.adapter.ebsd.quickfix;

public class FixConstants {
    public static final int MARKET_SEGMENT_ID_FIELD = 1300;
    public static final String MARKET_SEGMENT_ID_DIRECT = "D";
    public static final String SECURITY_TYPE_FXSPOT = "FXSPOT";
    private FixConstants() {}
}
