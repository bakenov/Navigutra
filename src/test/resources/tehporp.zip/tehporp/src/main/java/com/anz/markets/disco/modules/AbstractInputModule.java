package com.anz.markets.disco.modules;

import com.anz.markets.disco.InputModule;
import com.anz.markets.disco.Stage;

public abstract class AbstractInputModule extends Thread implements InputModule {

    private Stage stage;

    private boolean isFinished;

    public AbstractInputModule(String moduleName) {
        setName(moduleName);
        setDaemon(false);
    }

    public abstract Runnable createInputRunnable();

    @Override
    public void init(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }

    @Override
    public void run() {
        try {
            isFinished = false;
            createInputRunnable().run();
        } finally {
            isFinished = true;
        }
    }

    @Override
    public boolean isFinished() {
        return isFinished;
    }

    @Override
    public void finish() {
        ;
    }
}
