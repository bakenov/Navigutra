package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;
import com.reuters.rfa.common.Token;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.session.omm.OMMItemCmd;
import com.reuters.rfa.session.omm.OMMProvider;

import com.anz.axle.trep.TrepConstants;
import com.anz.axle.trep.TrepMessageBuilder;
import com.anz.axle.trep.publisher.MessageEncoder;
import com.anz.axle.trep.publisher.TrepStreamable;
import com.anz.axle.trep.publisher.TrepStreamingMessageType;
import com.anz.axle.trep.publisher.TrepStreamingUpdateType;

public final class TrepQuote implements TrepStreamable {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrepQuote.class);

    public enum QuoteType {
        INDICATIVE(1, "INDIC"),
        EXECUTABLE(2, "LIVE");

        private final int code;
        private final String display;

        QuoteType(final int code, final String display) {
            this.code = code;
            this.display = display;
        }

        @Override
        public String toString() {
            return "QuoteType{" +
                    "code=" + code +
                    ", display='" + display + '\'' +
                    '}';
        }

        public int getCode() {
            return code;
        }

        public String getDisplay() {
            return display;
        }
    }

    private final String name;
    private final String serviceName;
    private final double bid;
    private final double ask;
    private final QuoteType quoteType;
    private final long triggerTime;
    private final TrepStreamingUpdateType trepStreamingUpdateType;

    public static TrepQuote createUpdateQuote(final QuoteType quoteType, final String publishServiceName, final String publishRicName, final double bid, final double ask, final long triggerTime) {
        return new TrepQuote(quoteType, publishServiceName, publishRicName, bid, ask, TrepStreamingUpdateType.UPDATE, triggerTime);
    }

    public static TrepQuote createEmptyUpdateQuote(final String serviceName, final String ricName) {
        return createUpdateQuote(QuoteType.INDICATIVE, serviceName, ricName, Double.NaN, Double.NaN, System.currentTimeMillis());
    }

    public static TrepQuote createIndicativeRefreshQuote(final String publishServiceName, final String publishRicName){
        return new TrepQuote(QuoteType.INDICATIVE, publishServiceName, publishRicName, Double.NaN, Double.NaN, TrepStreamingUpdateType.REFRESH, System.currentTimeMillis());
    }

    private TrepQuote(final QuoteType quoteType, final String publishServiceName, final String publishRicName, final double bid, final double ask, final TrepStreamingUpdateType trepStreamingUpdateType, final long triggerTime) {
        this.serviceName = Objects.requireNonNull(publishServiceName);
        this.name = Objects.requireNonNull(publishRicName);
        this.bid = formatPx(bid);
        this.ask = formatPx(ask);
        this.trepStreamingUpdateType = Objects.requireNonNull(trepStreamingUpdateType);
        this.quoteType = Objects.requireNonNull(quoteType);
        this.triggerTime = Objects.requireNonNull(triggerTime);
    }

    @Override
    public String getName() {
        return name;
    }

    public String toString() {
        return String.format("%s|%s|%s/%s|%s|%s", serviceName, name, bid, ask, quoteType, triggerTime);
    }

    @Override
    public int submitAsOMMCmdTo(final OMMProvider provider,
                                final TrepMessageBuilder messageBuilder,
                                final Token token,
                                final Object rfaClosure) {
        final TrepStreamingMessageType messageType = trepStreamingUpdateType.getMessageType();
        return messageBuilder.withOMMMsg(new Function<OMMMsg, Integer>() {
            @Override
            public Integer apply(final OMMMsg ommMsg) {
                messageType.setMessageFields(ommMsg, serviceName, name);
                ommMsg.setMsgModelType(RDMMsgTypes.MARKET_PRICE);
                return messageBuilder.withMessageEncoder(new Function<MessageEncoder, Integer>() {
                    @Override
                    public Integer apply(final MessageEncoder messageEncoder) {
                        // Initialize message encoding with the update response message.
                        // No data is contained in the OMMAttribInfo, so use NO_DATA for the data type of OMMAttribInfo
                        // There will be data encoded in the update response message (and we know it is FieldList), so
                        // use FIELD_List for the data type of the update response message.
                        messageEncoder.encodeMsgInit(ommMsg, OMMTypes.NO_DATA, OMMTypes.FIELD_LIST);

                        messageType.encodeFieldListInit(messageEncoder);
                        messageEncoder.encodeAsStringField(TrepConstants.X_RIC_NAME, name);
                        messageEncoder.encodeAsLongField(TrepConstants.QUOTIM_MS, System.currentTimeMillis());
                        messageEncoder.encodeAsRealField(TrepConstants.BID, bid);
                        messageEncoder.encodeAsRealField(TrepConstants.ASK, ask);
                        messageEncoder.encodeAsEnumField(TrepConstants.QUOTE_TYPE, quoteType.getCode());
                        messageEncoder.encodeAsStringField(TrepConstants.GEN_TEXT16, quoteType.getDisplay());

                        messageEncoder.encodeAsUTCTimeField(TrepConstants.TIMACT, new DateTime(triggerTime));
                        messageEncoder.encodeAsLongField(TrepConstants.TIME_TRACKER_1, triggerTime);
                        messageEncoder.encodeAggregateComplete();

                        final OMMMsg encodedObject = messageEncoder.getEncodedObject();

                        final OMMItemCmd itemCommand = new OMMItemCmd();
                        itemCommand.setToken(token);
                        itemCommand.setMsg(encodedObject);
                        return provider.submit(itemCommand, rfaClosure);
                    }
                });
            }
        });
    }

    public String getServiceName() {
        return serviceName;
    }

    private double formatPx(final double px) {
        return Double.isNaN(px) ? 0 : px;
    }

    public double getBid() {
        return bid;
    }

    public double getAsk() {
        return ask;
    }

    public QuoteType getQuoteType() {
        return quoteType;
    }

    public long getTriggerTime() {
        return triggerTime;
    }

    public static class Builder {
        private String serviceName;
        private String ricName;
        private double bid = Double.NaN;
        private double offer = Double.NaN;
        private long bidTimeStamp;
        private long offerTimeStamp;
        private boolean isIndicative;

        public Builder serviceName(final String serviceName) {
            this.serviceName = serviceName;
            return this;
        }

        public Builder updateBid(final double price, final long bidTimeStamp) {
            this.bid = price;
            this.bidTimeStamp = bidTimeStamp;
            return this;
        }

        public Builder updateOffer(final double price, final long offerTimeStamp) {
            this.offer = price;
            this.offerTimeStamp = offerTimeStamp;
            return this;
        }

        public Builder ricName(final String ricName) {
            this.ricName = ricName;
            return this;
        }

        public Builder isIndicative(final boolean isIndicative) {
            this.isIndicative = isIndicative;
            return this;
        }

        public Builder reset() {
            serviceName = null;
            ricName = null;
            bid = Double.NaN;
            offer = Double.NaN;
            bidTimeStamp = 0;
            offerTimeStamp = 0;
            isIndicative = true;
            return this;
        }

        public TrepQuote build() {
            return TrepQuote.createUpdateQuote((this.isIndicative ? QuoteType.INDICATIVE : QuoteType.EXECUTABLE), this.serviceName, this.ricName, this.bid, this.offer, TimeUnit.NANOSECONDS.toMillis(Math.max(this.bidTimeStamp, this.offerTimeStamp)));
        }

        public String toString() {
            return "Builder[" + serviceName + "|" + ricName + "(" + bid + "/" + offer + ")]";
        }
    }
}
