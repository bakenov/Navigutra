package com.anz.markets.efx.ngaro.codec;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiFunction;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteReader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Unit test for {@link SimpleStringEncoder}
 */
public class SimpleStringEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    enum Color {
        RED, BLUE, YELLOW;
    }

    @Test(expected = NullPointerException.class)
    public void noNullEnclosingEncoder() {
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        new SimpleStringEncoder<>(null, stringHolder::set);
    }

    @Test(expected = NullPointerException.class)
    public void noNullConsumer() {
        new SimpleStringEncoder<>(ENCLOSING_ENCODER, null);
    }

    @Test
    public void encodeEmpty() throws Exception {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringEncoder<?> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);

        //when
        enc.encodeEmpty();

        //then
        assertEquals("result should be null", null, stringHolder.get());
    }

    @Test
    public void encodeFromCharSequence() throws Exception {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringEncoder<?> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);

        //when
        enc.encode("1234567");

        //then
        assertEquals("result should contain 1234567", "1234567", stringHolder.get());

        //when
        enc.encode("1234567", 0, 6);

        //then
        assertEquals("result should contain 123456", "123456", stringHolder.get());

        //when
        enc.encode("UVWXYZ", 3, 3);

        //then
        assertEquals("result should contain XYZ", "XYZ", stringHolder.get());
    }

    @Test
    public void encodeNullable() throws Exception {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringEncoder<?> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);

        //when
        enc.encodeNullable((String)null);

        //then
        assertEquals("result should be null", null, stringHolder.get());
    }

    @Test
    public void encodeEnum() throws Exception {
        //given
        final String blablabla = "blablabla";
        final BiFunction<Color, StringEncoder<Object>, Object> transformNullable = EnumTransforms.fromEnumNullable();
        final BiFunction<Color, StringEncoder<Object>, Object> transform = EnumTransforms.fromEnum();
        final AtomicReference<String> stringHolder = new AtomicReference<>(blablabla);
        final SimpleStringEncoder<Object> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);

        for (final Color color : Color.values()) {
            //when
            stringHolder.set(blablabla);
            enc.encode(color, transformNullable);

            //then
            assertEquals("result should be constant name", color.name(), stringHolder.get());

            //when
            stringHolder.set(blablabla);
            enc.encode(color, transform);

            //then
            assertEquals("result should be constant name", color.name(), stringHolder.get());
        }

        //SPECIAL: null values

        //when
        stringHolder.set(blablabla);
        enc.encode(null, transformNullable);

        //then
        assertEquals("result should be null", null, stringHolder.get());

        try {
            //when
            stringHolder.set(blablabla);
            enc.encode(null, transform);

            //then: expecte exception
            fail("encoding null should throw an exception");
        } catch (final NullPointerException e) {
            //as expected
        }
    }

    @Test
    public void encodeFromByteReader() throws Exception {
        //given
        final int length = 6;
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringEncoder<?> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);

        //when
        enc.encode("1234567", ByteReader.CHAR_SEQUENCE, length);

        //then
        assertEquals("result should contain 123456", "123456", stringHolder.get());

        //when
        enc.encode("UVWXYZ", ByteReader.CHAR_SEQUENCE, 3, 3);

        //then
        assertEquals("result should contain XYZ", "XYZ", stringHolder.get());

        //when
        enc.encode("", ByteReader.CHAR_SEQUENCE, 0, 0);

        //then
        assertEquals("result should be null", null, stringHolder.get());
    }

    @Test
    public void encodeFromStringDecoder() throws Exception {
        //given
        final int length = 6;
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringEncoder<?> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);
        final StringDecoder dec = SimpleStringDecoder.forString("123456");

        //when
        enc.encodeFrom(dec);

        //then
        assertEquals("result should contain 123456", "123456", stringHolder.get());
    }

    @Test
    public void encodeLong() {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringEncoder<?> enc = new SimpleStringEncoder<>(ENCLOSING_ENCODER, stringHolder::set);

        //when
        enc.encodeLong(536345634453L);

        //then
        assertEquals("result should contain 536345634453", "536345634453", stringHolder.get());
    }
}