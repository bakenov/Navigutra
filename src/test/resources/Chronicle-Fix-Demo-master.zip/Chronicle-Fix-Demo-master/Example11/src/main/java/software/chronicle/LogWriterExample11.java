package software.chronicle;

import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.AbstractMarshallable;
import net.openhft.chronicle.wire.DocumentContext;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog.ReadWrite;

import java.util.function.Consumer;

public class LogWriterExample11 extends AbstractMarshallable implements Consumer<FixLog> {
    public static final String DIR_NAME = "log-file";

    private final SingleChronicleQueue log = SingleChronicleQueueBuilder.binary(DIR_NAME).build();
    ;

    @Override
    public void accept(FixLog fixLog) {
        // this will log all the messages read
        if (fixLog.rw() == ReadWrite.W)
            return;

        try (DocumentContext dc = log.acquireAppender().writingDocument()) {
            dc.wire().getValueOut().text(fixLog.msg());
        }
    }
}