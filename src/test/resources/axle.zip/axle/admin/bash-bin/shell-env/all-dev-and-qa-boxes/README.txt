Certain contents of this folder (in particular the dot-files and bin) are managed from SVN and synchronized from daxa009s.

The process for distributing these files across our environments is:

on daxa009s
1) make changes (in ~/bash-bin/shell-env/all-dev-and-qa-boxes) or update from SVN
2) run distribute-shell-env
3) ensure changes are checked in to SVN

