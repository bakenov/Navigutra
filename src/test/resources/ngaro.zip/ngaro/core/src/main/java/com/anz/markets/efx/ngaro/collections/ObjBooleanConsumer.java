package com.anz.markets.efx.ngaro.collections;

/**
 * Primitive version of boolean object consumer (jdk version is a wrap around).
 */
public interface ObjBooleanConsumer<T> {
    void accept(T t, boolean value);
}
