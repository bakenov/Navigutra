package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.SUSPICIOUS_DISCREPANCY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "Firewall keeps states and there is no normal operational mechanism to clear it. Therefore it needs to be restarted.")
@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_7})
public class MaximumTradeVolumeHedgeFirewallTest extends BaseAcceptanceSpecification {
    Portfolio portfolio = HEDGER_AGGRESSIVE;

    @Test
    public void shouldNotTriggeredWhenDisabled() throws Exception {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, 0.0, false)
            )));
            // mid rate is used to calculate volume.
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.9500));
        }
        when:
        // t+0, first trade not breached.
        {
            prophet.clearOutputBuffer();
            // instantaneous pnl of 100
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 1_000_000, 0.9));
        }
        then:
        // no message.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio));
        }
    }

    public void shouldTriggerWhenFirstBreached() throws Exception {
        NewOrder newOrder;

        when:
        // t+1, receive client trade
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallTradeVolumeStatus(portfolio, BREACHED, 1_900_000.0, 950_000.0, 1_899_999));

            prophet.expect(HedgeStatus.class, hedgeStatusIsOff(portfolio));
        }
    }

    @Test
    public void shouldResetViaTurningOnHedger() throws Exception {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, 1_899_999d, true),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, SUSPICIOUS_DISCREPANCY, NaN, false)
            )));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            // mid rate is used to calculate volume.
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.9500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.9500));
        }

        shouldTriggerWhenFirstBreached();

        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(MAXIMUM_TRADE_VOLUME_PER_HOUR, NOT_BREACHED, portfolio));
        }

        shouldTriggerWhenFirstBreached();
    }

    @Test
    public void shouldResetViaManualResetFacility() throws Exception {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, 949_000, true)
            )));
            // mid rate is used to calculate volume.
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.9500));
        }
        when:
        // t+0, first trade not breached.
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 500_000, 0.9));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(MAXIMUM_TRADE_VOLUME_PER_HOUR, BREACHED, portfolio));
        }
        when:
        // Manual RESET prior to receiving next hedge trade which would have breached firewall
        {
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, MAXIMUM_TRADE_VOLUME_PER_HOUR));
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 500_000, 0.9));
        }
        then:
        // breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(MAXIMUM_TRADE_VOLUME_PER_HOUR, BREACHED, portfolio));
        }
    }

    @Test
    public void shouldBreachUnbreachSlidingWindow() throws Exception {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, 950_000.0, true)
            )));
            // mid rate is used to calculate volume.
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.9500));
        }
        when:
        // t+1sec, first trade not breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 1_000_000, 0.96000));
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio));
        }
        when:
        // t+1hr, second trade breached.
        {
            prophet.incrementTime(TimeUnit.HOURS.toMillis(1) - TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, -1, 0.96000));
        }
        then:
        // breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallTradeVolumeStatus(portfolio, BREACHED, 950_000.95, 0.95, 950_000.0));
        }

        when:
        // t+1hr+1sec, first trade slide out of window.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // not breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallTradeVolumeStatus(portfolio, NOT_BREACHED, 0.95, -950_000, 950_000.0));
        }
    }

    @Test
    public void volUsdCalcCrossPair() {
        final Instrument crosspair = Instrument.AUDJPY;
        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverpairB = Instrument.USDJPY;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, 1_490_000.0, true)
            )));

            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.74500));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 113.780));
        }
        when:
        // t+1sec, receive first hedge trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(portfolio, crosspair, 2_000_000, 84.700));
            // AUD: +2mio AUD     | +1.49mio USD
        }
        then:
        {
            // not breached
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio));
        }
        when:
        // t+2sec, receive second hedge trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(portfolio, driverpairB, -1, 84.700));
        }
        then:
        // breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_TRADE_VOLUME_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallTradeVolumeStatus(portfolio, BREACHED, 1_490_001.00, 1.00, 1_490_000.0));
        }
    }

}
