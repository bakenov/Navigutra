package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.chronicle.MessageType;

public class ChronicleObjectReaderNoOp implements ChronicleObjectReader {
    @Override
    public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
        // do nothing
    }
}
