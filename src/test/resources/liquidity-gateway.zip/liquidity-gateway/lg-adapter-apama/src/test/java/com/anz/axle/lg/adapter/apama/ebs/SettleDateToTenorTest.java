package com.anz.axle.lg.adapter.apama.ebs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.ngaro.api.Tenor;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class SettleDateToTenorTest {

    private SettleDateToTenor settleDateToTenor = new SettleDateToTenor();

    @Test
    @Spockito.Unroll({
            "| settleDate | Tenor |",
            "| 20170130   | EOM1  |",
            "| 20170225   | EOM2  |",
            "| 20170330   | EOM3  |",
            "| 20170430   | EOM4  |",
            "| 20170530   | EOM5  |",
            "| 20170630   | EOM6  |",
            "| 20170730   | EOM7  |",
            "| 20170830   | EOM8  |",
            "| 20170930   | EOM9  |",
            "| 20171030   | EOM10 |",
            "| 20171130   | EOM11 |",
            "| 20171230   | EOY1  |"
    })
    @Spockito.Name("[{settleDate}]: {Tenor}")
    public void apply(final String settleDate, final Tenor tenor) throws Exception {
        assertThat(settleDateToTenor.apply(settleDate)).isEqualTo(tenor);
    }

    @Test
    public void applyNull() throws Exception {
        assertThat(settleDateToTenor.apply(null)).isEqualTo(Tenor.SP);
    }

}