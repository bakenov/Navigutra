package com.anz.markets.efx.fox.codec.pojo;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class VenueInstrumentConfigAsserter {
    private final VenueInstrumentConfig message;

    public VenueInstrumentConfigAsserter(final VenueInstrumentConfig message) {
        this.message = Objects.requireNonNull(message);
    }

    public static VenueInstrumentConfigAsserter expect(final VenueInstrumentConfig message) {
        return new VenueInstrumentConfigAsserter(message);
    }

    public static VenueInstrumentConfigAsserter expect(final MessageHeader header, final VenueInstrumentConfig.Body body) {
        return new VenueInstrumentConfigAsserter(SorMessage.venueInstrumentConfig(header, body));
    }

    public VenueInstrumentConfig message() {
        return message;
    }

    public VenueInstrumentConfig.Body body() {
        return message.body;
    }

    public VenueInstrumentConfigHandler assertingVenueInstrumentConfigHandler() {
        return body -> {
            assertEquals("venue not as expected", body().venue, body.venue());
            assertEquals("instrumentId not as expected", body().instrumentId, body.instrumentId());
            assertEquals("priceIncrement not as expected", body().priceIncrement, body.priceIncrement(), 0);
            assertEquals("sizeIncrement not as expected", body().sizeIncrement, body.sizeIncrement());
            assertEquals("clipSizeMultiple not as expected", body().clipSizeMultiple, body.clipSizeMultiple());
            assertEquals("maxAllowedParentOrderQty not as expected", body().maxAllowedParentOrderQty, body.maxAllowedParentOrderQty(), 0);
            assertEquals("minClipSize not as expected", body().minClipSize, body.minClipSize());
            assertEquals("maxClipSize not as expected", body().maxClipSize, body.maxClipSize());
            assertEquals("staleDataTimeout not as expected", body().staleDataTimeout, body.staleDataTimeout());
            assertEquals("priority not as expected", body().priority, body.priority());
            assertEquals("proportion not as expected", body().proportion, body.proportion());
            assertEquals("enabled not as expected", body().enabled, body.enabled());
        };
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a VenueInstrumentConfig", sorMessage instanceof VenueInstrumentConfig);
        assertVenueInstrumentConfig((VenueInstrumentConfig) sorMessage);
    }

    public void assertVenueInstrumentConfig(final VenueInstrumentConfig venueInstrumentConfig) {
        assertBody(venueInstrumentConfig.body);
    }

    public void assertBody(final VenueInstrumentConfig.Body body) {
        assertEquals("venue not as expected", body().venue, body.venue);
        assertEquals("instrumentId not as expected", body().instrumentId, body.instrumentId);
        assertEquals("priceIncrement not as expected", body().priceIncrement, body.priceIncrement,0);
        assertEquals("sizeIncrement not as expected", body().sizeIncrement, body.sizeIncrement);
        assertEquals("clipSizeMultiple not as expected", body().clipSizeMultiple, body.clipSizeMultiple);
        assertEquals("maxAllowedParentOrderQty not as expected", body().maxAllowedParentOrderQty, body.maxAllowedParentOrderQty, 0);
        assertEquals("minClipSize not as expected", body().minClipSize, body.minClipSize);
        assertEquals("maxClipSize not as expected", body().maxClipSize, body.maxClipSize);
        assertEquals("staleDataTimeout not as expected", body().staleDataTimeout, body.staleDataTimeout);
        assertEquals("priority not as expected", body().priority, body.priority);
        assertEquals("proportion not as expected", body().proportion, body.proportion);
        assertEquals("enabled not as expected", body().enabled, body.enabled);
    }
}
