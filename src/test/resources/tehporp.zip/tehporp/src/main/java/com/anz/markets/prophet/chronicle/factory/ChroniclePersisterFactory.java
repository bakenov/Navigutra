package com.anz.markets.prophet.chronicle.factory;

import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.Append;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.PersisterConfig;
import com.anz.markets.prophet.chronicle.config.PersisterConfigBuilder;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig.ChronicleType;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersisterConfig;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueuePersister;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.util.SystemProperties;

import java.io.IOException;
import java.util.function.Predicate;

public enum ChroniclePersisterFactory {
    INSTANCE;

    public static ProphetPersister createCorePersister(final String outboundChroniclePath,
                                                       final LegacyChroniclePersister.OpenMode openMode,
                                                       final ActivationAware activationMode,
                                                       final boolean active,
                                                       final Predicate<MessageType> messageTypePredicate) throws IOException {
        return createCorePersister(outboundChroniclePath, openMode, activationMode, active, messageTypePredicate, RingBuffer.NO_RING);
    }

    public static ProphetPersister coreConflate(final String basePath, final LegacyChroniclePersister.OpenMode openMode, final boolean active) throws IOException {
        return createCorePersister(basePath, openMode, ActivationAware.NO, active, Predicates.alwaysTrue());
    }

    public static ProphetPersister createCorePersister(final String outboundChroniclePath,
                                                       final LegacyChroniclePersister.OpenMode openMode,
                                                       final ActivationAware activationMode,
                                                       final boolean active,
                                                       final Predicate<MessageType> messageTypePredicate,
                                                       final RingBuffer ringBuffer) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final PersisterConfig config = PersisterConfigBuilder.create()
                    .withActiveFlag(active)
                    .withMessageTypePredicate(messageTypePredicate)
                    .withAppend(Append.ONLY_AFTER_LAST_EVENTID)
                    .withActivationAware(activationMode)
                    .withBeforeWrite(ChronicleHook.COMMON_BEFORE_WRITE.then(ChronicleHook.CORE_BEFORE_WRITE))
                    .withAfterWrite(ChronicleHook.CORE_AFTER_WRITE)
                    .withRingBuffer(ringBuffer)
                    .build();

            return new ChronicleQueuePersister(outboundChroniclePath, config);
        } else {
            return new LegacyChroniclePersister(LegacyChroniclePersisterConfig.core(outboundChroniclePath, openMode, ChronicleType.INDEXED, activationMode), active, messageTypePredicate);
        }
    }

    public static ProphetPersister createStarInPersister(final String inChroniclePath, final LegacyChroniclePersister.OpenMode openMode) throws IOException {
        return createStarInPersister(inChroniclePath, openMode, RingBuffer.NO_RING);
    }

    public static ProphetPersister createStarInPersister(final String inChroniclePath, final LegacyChroniclePersister.OpenMode openMode, final RingBuffer ringBuffer) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final PersisterConfig config = PersisterConfigBuilder.create()
                    .withActiveFlag(true)
                    .withMessageTypePredicate(Predicates.alwaysTrue())
                    .withAppend(Append.ALL)
                    .withActivationAware(ActivationAware.NO)
                    .withBeforeWrite(ChronicleHook.eventInception())
                    .withAfterWrite(ChronicleHook.DO_NOTHING)
                    .withRingBuffer(ringBuffer)
                    .withMultipleWriterThreads(true)
                    .build();

            return new ChronicleQueuePersister(inChroniclePath, config);
        } else {
            return new LegacyChroniclePersister(LegacyChroniclePersisterConfig.starfishIn(inChroniclePath, openMode, ChronicleType.INDEXED), true);
        }
    }

    public static ProphetPersister createStarOutPersister(final String starOutChroniclePath, final LegacyChroniclePersister.OpenMode openMode, final RingBuffer ringBuffer) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final PersisterConfig config = PersisterConfigBuilder.create()
                    .withActiveFlag(true)
                    .withMessageTypePredicate(Predicates.alwaysTrue())
                    .withAppend(Append.ALL)
                    .withActivationAware(ActivationAware.NO)
                    .withBeforeWrite(ChronicleHook.COMMON_BEFORE_WRITE.then(ChronicleHook.BEFORE_WRITE))
                    .withAfterWrite(ChronicleHook.DO_NOTHING)
                    .withRingBuffer(ringBuffer)
                    .build();

            return new ChronicleQueuePersister(starOutChroniclePath, config);
        } else {
            return new LegacyChroniclePersister(LegacyChroniclePersisterConfig.starfishOut(starOutChroniclePath, openMode, ChronicleType.INDEXED), true);
        }
    }

    public static ProphetPersister createToolsCommonPersister(final String outPath) throws IOException {
        return createToolsCommonPersister(outPath, ChronicleHook.DO_NOTHING, RingBuffer.NO_RING);
    }

    public static ProphetPersister createToolsCommonPersister(final String outPath, final ChronicleHook beforeWrite, final RingBuffer ringBuffer) throws IOException {
        if (SystemProperties.CHRONICLE_API_VERSION.isCQ()) {
            final PersisterConfig config = PersisterConfigBuilder.create()
                    .withActiveFlag(true)
                    .withMessageTypePredicate(Predicates.alwaysTrue())
                    .withAppend(Append.ALL)
                    .withActivationAware(ActivationAware.NO)
                    .withRingBuffer(ringBuffer)
                    .withBeforeWrite(beforeWrite)
                    .withAfterWrite(ChronicleHook.DO_NOTHING)
                    .build();

            return new ChronicleQueuePersister(outPath, config);
        } else {
            return new LegacyChroniclePersister(LegacyChroniclePersisterConfig.unchanged(outPath, ChronicleType.INDEXED), true);
        }
    }
}
