package com.anz.markets.efx.fox.processor.state.usersession;

import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.UserSession;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.MutableParentOrderDetails;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.eventsourcing.UpdatablePrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingCodecUtil;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserSessionMissedHeartbeatHandlerTest {
    @Mock
    private CommandContext commandContext;
    @Mock
    private ParentOrderRepository parentOrderRepository;
    @Mock
    private ParentOrder parentOrder;
    @Mock
    private Instrument instrument;
    @Mock
    private LongSupplier idGenerator;
    private MutableParentOrderDetails parentOrderDetails = new MutableParentOrderDetails();

    @Mock
    private UserSession userSession;
    private UserSessionMissedHeartbeatHandler expiryHandler;

    @BeforeEach
    void setUp() {
        expiryHandler = new UserSessionMissedHeartbeatHandler(userSession);
    }

    @Test
    void timerGroup() {
        assertThat(expiryHandler.timerGroup()).isEqualTo(TimerGroup.USER_SESSION_MISSED_HEARTBEAT);
    }

    @Test
    void onExpiryCommand_noop_when_session_is_offline() {
        //given
        when(userSession.online()).thenReturn(false);

        //when
        expiryHandler.onExpiryCommand(123, 1234, commandContext);

        //then
        verifyNoMoreInteractions(userSession);
        verifyNoMoreInteractions(commandContext);
    }

    @Test
    void onExpiryCommand_noop_when_session_is_online_and_portfolio_has_one_online_userSession() {
        //given
        final String portfolio = "XEFX";
        final UserSessionKey key = UserSessionKey.of("id1", "user1", portfolio, Region.GB);
        final String senderCompId = "GB:fox";
        final long sourceSeq = 1234;
        final long clOrdId = 1235;
        final long currentTime = 345345;
        when(instrument.key()).thenReturn(InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP));

        parentOrderDetails = new MutableParentOrderDetails()
                .portfolio(portfolio)
                .origClOrdId(34)
                .clOrdLinkId(45)
                .orderId(76)
                .orderQty(4567)
                .orderType(OrderType.LIMIT)
                .timeInForce(TimeInForce.IOC)
                .instrument(instrument)
                .side(Side.SELL);

        when(parentOrder.details()).thenReturn(parentOrderDetails);

        final UpdatablePrecisionClock precisionClock = new UpdatablePrecisionClock();
        precisionClock.accept(currentTime);

        final SbeTradingCodecUtil.Codec codec = SbeTradingCodecUtil.create();

        when(userSession.online()).thenReturn(true);
        when(userSession.onlinePortfolioSessions()).thenReturn(1);
        when(userSession.userSessionKey()).thenReturn(key);
        when(commandContext.parentOrderRepository()).thenReturn(parentOrderRepository);
        when(commandContext.source()).thenReturn(100);
        when(commandContext.idGenerator()).thenReturn(idGenerator);
        when(commandContext.tradingEncoderSupplier()).thenReturn(codec.encoderSupplier());
        when(commandContext.senderCompId()).thenReturn(senderCompId);
        when(commandContext.precisionClock()).thenReturn(precisionClock);

        when(idGenerator.getAsLong()).thenReturn(sourceSeq, clOrdId);

        doAnswer(answer -> {
            Consumer<ParentOrder> messageConsumer = answer.getArgument(0);
            messageConsumer.accept(parentOrder);
            return null;
        }).when(parentOrderRepository).forEach(any(Consumer.class));

        //when
        expiryHandler.onExpiryCommand(123, 1234, commandContext);

        //then
        final OrderCancelRequestDecoder.Body decoderBody = codec.decoderSupplier().orderCancelRequest().body();
        assertThat(decoderBody.origClOrdId().decodeLongOrZero()).isEqualTo(parentOrderDetails.origClOrdId());
        assertThat(decoderBody.orderId().decodeLongOrZero()).isEqualTo(parentOrderDetails.orderId());
        assertThat(decoderBody.clOrdLinkId().decodeLongOrZero()).isEqualTo(parentOrderDetails.clOrdLinkId());
        assertThat(decoderBody.orderQty()).isEqualTo(parentOrderDetails.orderQty());
        assertThat(decoderBody.ordType()).isEqualTo(parentOrderDetails.orderType());
        assertThat(decoderBody.timeInForce()).isEqualTo(parentOrderDetails.timeInForce());
        assertThat(decoderBody.securityType()).isEqualTo(parentOrderDetails.instrument().key().securityType());
        assertThat(decoderBody.settlType()).isEqualTo(parentOrderDetails.instrument().key().tenor());
        assertThat(decoderBody.symbol().decodeStringOrNull()).isEqualTo(parentOrderDetails.instrument().key().symbol());
        assertThat(decoderBody.side()).isEqualTo(parentOrderDetails.side());
    }

    @Test
    void onExpiryEvent_should_update_userSession_offline() {
        //when
        expiryHandler.onExpiryEvent(123, 1234);

        //then
        verify(userSession).updateOffline();
    }
}