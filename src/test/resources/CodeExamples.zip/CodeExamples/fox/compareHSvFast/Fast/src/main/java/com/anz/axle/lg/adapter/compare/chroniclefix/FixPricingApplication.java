package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.util.Objects;

import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.staticcode.FixSessionHandler;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.PerformanceProbes;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MarketDataRequestReject;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MessageNotifier;


public class FixPricingApplication extends FixSessionApplication implements MessageNotifier {

    private final FixMessageHandler incrementalRefreshHandler;
    private final FixMessageHandler snapshotFullRefreshHandler;
    private final FixMessageHandler marketDataRequestRejectHandler;

    public FixPricingApplication(final FixMessageHandler incrementalRefreshHandler,
                                 final FixMessageHandler snapshotFullRefreshHandler,
                                 final FixMessageHandler marketDataRequestRejectHandler,
                                 final ApplicationLogonHandler applicationLogonHandler) {
        super(Objects.requireNonNull(applicationLogonHandler));
        this.incrementalRefreshHandler = Objects.requireNonNull(incrementalRefreshHandler);
        this.snapshotFullRefreshHandler = Objects.requireNonNull(snapshotFullRefreshHandler);
        this.marketDataRequestRejectHandler = Objects.requireNonNull(marketDataRequestRejectHandler);
    }

    @Override
    public void onMarketDataRequestReject(final FixSessionHandler session, final MarketDataRequestReject marketDataRequestReject) {
        marketDataRequestRejectHandler.accept((AbstractDataModel) marketDataRequestReject);
   }

    @Override
    public void onMarketDataSnapshotFullRefresh(final FixSessionHandler session, final MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh) {
        if (session.probes() instanceof PerformanceProbes) {
            final PerformanceProbes probes = (PerformanceProbes) session.probes();
            snapshotFullRefreshHandler.accept((AbstractDataModel) marketDataSnapshotFullRefresh, probes.readTimeNS());
        } else {
            snapshotFullRefreshHandler.accept((AbstractDataModel) marketDataSnapshotFullRefresh);
        }
    }

    @Override
    public void onMarketDataIncrementalRefresh(final FixSessionHandler session, final MarketDataIncrementalRefresh marketDataIncrementalRefresh) {
        if (session.probes() instanceof PerformanceProbes) {
            final PerformanceProbes probes = (PerformanceProbes) session.probes();
            incrementalRefreshHandler.accept((AbstractDataModel) marketDataIncrementalRefresh, probes.readTimeNS());
        } else {
            incrementalRefreshHandler.accept((AbstractDataModel) marketDataIncrementalRefresh);
        }
    }
}