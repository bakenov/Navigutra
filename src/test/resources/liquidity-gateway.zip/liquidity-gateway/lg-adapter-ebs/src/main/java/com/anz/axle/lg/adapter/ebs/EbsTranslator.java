package com.anz.axle.lg.adapter.ebs;

import java.util.Objects;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.SecurityType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce;
import com.anz.markets.efx.trading.codec.api.OrderType;

public class EbsTranslator {

    private EbsTranslator() {
        throw new UnsupportedOperationException("No EbsTranslator for you");
    }

    public static char timeInForce(final com.anz.markets.efx.trading.codec.api.TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case GTC: return TimeInForce.GOOD_TILL_CANCEL;
            case IOC: return TimeInForce.IMMEDIATE_OR_CANCEL;
            case FOK: return TimeInForce.FILL_OR_KILL;
            default: throw new IllegalArgumentException("Unsupported timeInForce: " + timeInForce);
        }
    }

    public static char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT:         return OrdType.LIMIT;
            case FIXING_ORDER:  return OrdType.FIXING_ORDER;
            default: throw new IllegalArgumentException("Unsupported orderType: " + orderType);
        }
    }
}
