package com.anz.markets.prophet.atest.framework.impl;

import com.anz.axle.falcon.MillenniumFalcon;
import com.anz.axle.falcon.body.ClientDeal;
import com.anz.axle.falcon.types.Currency;
import com.anz.axle.falcon.types.Side;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.LongCodec;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.prophet.atest.framework.UmEndPoint;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.marketdata.MarketDataDeleteOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataReplaceOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.messaging.converters.MarketConverter;
import com.anz.markets.prophet.messaging.converters.TenorConverter;
import com.anz.markets.prophet.pricer.wholesale.BaseSpreadConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

import static com.anz.markets.efx.ngaro.core.GcFriendlyAssert.fail;

public class UmSource extends UmEndPoint {
    private static final Logger LOGGER = LoggerFactory.getLogger(UmSource.class);

    private final Connection connection;
    private final MillenniumFalcon falcon;
    private final String publisherSuffix;
    private final String dealTopic;
    private final List<PublicationTopic> publicationsRegister = new ArrayList<>();
    private BaseSpreadConfiguration baseSpreadConfiguration;

    /** the details we keep for every registered topic - we have one of these objects per market/instrument */
    private class PublicationTopic {
        public final PreTopic preTopic;
        private boolean successfulPublish = false;

        /** we record nothing but the Topic when we are created (although we do initialise some other members */
        public PublicationTopic(final PreTopic preTopic) {
            this.preTopic = Objects.requireNonNull(preTopic);
        }

        /** the Publication we have registered for that topic - this is created when the price publisher is created */
        public Publication publication = null;

        /** the SbeMessage to encode messages into - basically a single buffer for this market/instrument */
        final MutableSbeMessage message = new SbeMessageForWriting(8192);

        /** the Consumer for the encoded SbeMessage - passed to the encoders to consumer the completed encoding */
        final Consumer<SbeMessage> consumer = sbeMessage -> {
            if (publication != null) {
                successfulPublish = publication.publish(sbeMessage.buffer(), 0, sbeMessage.messageLength());
                if (successfulPublish) {
                    LOGGER.info("Successfully published message for topic {}", topic().name());
                } else {
                    LOGGER.error("Could not publish on topic {}", topic().name());
                }
            }
        };

        /** the SBE encoders for our message - it is given the same message buffer every time */
        final SbePricingEncoders encoders = new SbePricingEncoders(() -> message);
        final SnapshotFullRefreshEncoder snapshotEncoder = encoders.snapshotFullRefresh().create(consumer);
        final IncrementalRefreshEncoder incrementalEncoder = encoders.incrementalRefresh().create(consumer);

        public Topic topic() {
            return preTopic.sourceTopicOf();
        }

        /** get the encoder for a snapshot message */
        public SnapshotFullRefreshEncoder getEncoder() {
            return snapshotEncoder;
        }

        public IncrementalRefreshEncoder getIncrementalEncoder() {
            return incrementalEncoder;
        }
    }

    public UmSource(final Connection connection,
                    final MillenniumFalcon falcon,
                    final String publisherSuffix,
                    final String dealTopic) {
        this.connection = connection;
        this.falcon = falcon;
        this.publisherSuffix = publisherSuffix;
        this.dealTopic = dealTopic;
    }

    @Override
    public void close() {
        connection.close();
        publicationsRegister.clear();
    }

    @Override
    public void consumeIndexConfigurationData(final IndexedConfigurationData indexedConfigurationData) {
        this.baseSpreadConfiguration = indexedConfigurationData.getBaseSpreadConfiguration();
    }

    private PublicationTopic getOrAddPublicationTopic(final SecurityType securityType, final Market market, final Instrument instrument) {
        return getPublicationTopic(securityType, market, instrument)
                .orElseGet(() -> {
                    LOGGER.info("No predefined publication topic for {}_{}_{}, creating one", securityType, market, instrument);
                    // add it if not there
                    final PublicationTopic pt = new PublicationTopic(new PreTopic(securityType, market, instrument, publisherSuffix));
                    publicationsRegister.add(pt);
                    openPublication(pt);
                    return pt;
                });
    }

    private SnapshotFullRefreshEncoder getEncoder(final SecurityType securityType, final Market market, final Instrument instrument) {
        LOGGER.info("Getting encoders for {}_{}_{}_{}", securityType, market, instrument, publisherSuffix);
        return getOrAddPublicationTopic(securityType, market, instrument).getEncoder();
    }

    private IncrementalRefreshEncoder getIncrementalEncoder(final SecurityType securityType, final Market market, final Instrument instrument) {
        LOGGER.info("Getting incremental encoders for {}_{}_{}_{}", securityType, market, instrument, publisherSuffix);
        return getOrAddPublicationTopic(securityType, market, instrument).getIncrementalEncoder();
    }

    private Optional<PublicationTopic>  getPublicationTopic(final SecurityType securityType, final Market market, final Instrument instrument) {
        return publicationsRegister.stream()
                .filter(pt -> pt.preTopic.getSecurityType() == securityType)
                .filter(pt -> pt.preTopic.getMarket() == market)
                .filter(pt -> pt.preTopic.getInstrument() == instrument)
                .peek(this::openPublication)
                .findFirst();
    }

    private void openPublication(final PublicationTopic publicationTopic) {
        if (publicationTopic.publication == null) {
            LOGGER.info("Opening Publication {}: {}", ++totalOpenPublications, publicationTopic.topic());
            publicationTopic.publication = connection.openPublication(publicationTopic.topic(), UmEndPointStatusHandler.INSTANCE);
        }
    }

    @Override
    public <T> void pushToUm(final T object, final SecurityType securityType, final Tenor tenor) {
        if (object instanceof ForwardPoint) {
            pushForwardPoint((ForwardPoint)object, securityType);
        } else if (object instanceof MarketDataSnapshot) {
            pushSnapshotFullRefreshOntoUM((MarketDataSnapshot) object, securityType, tenor);
        } else if (object instanceof MarketDataIncrement) {
            pushIncrementalRefreshOntoUM((MarketDataIncrement) object, securityType, tenor);
        } else if (object instanceof Trade) {
            pushClientDealOntoUm((Trade)object);
        } else {
            fail("Sink not configured to send " + object.getClass().getSimpleName());
        }
    }

    private void pushClientDealOntoUm(final Trade trade) {
        final ClientDeal clientDeal = new ClientDeal()
                .orderId(trade.getOrderId())
                .counterDealId(trade.getCounterDealId())
                .counterPartyId(trade.getCounterparty())
                .clOrderId(trade.getClientOrderId())

                .termsCurrency(Currency.valueOf(trade.getTermsCurrency().toString()))
                .dealtCurrency(Currency.valueOf(trade.getDealtCurrency().toString()))
                .lastPx(trade.getFilledPrice())
                .lastQty(trade.getFilledQuantity())
                .transactTime(trade.getInceptionTimeNanos())
                .venue(com.anz.axle.falcon.types.Venue.valueOf(trade.getMarket().toString()))
                .side(trade.getSide() == OrderSide.OFFER ? Side.BUY : Side.SELL);

        falcon.registerSender(dealTopic + "_" + publisherSuffix, ClientDeal.class).send(clientDeal);
    }

    private void pushForwardPoint(final ForwardPoint forwardPoint, final SecurityType securityType) {
        final SnapshotFullRefreshEncoder encoder = getEncoder(securityType, Market.valueOf(forwardPoint.getSource().name()), forwardPoint.getInstrument());

        encoder.messageStart(0, 0)
               .possResend(false)
               .marketId(Venue.valueOf(forwardPoint.getSource().name()))
               .instrumentId(InstrumentKey.instrumentId(forwardPoint.getInstrument().getExternalCode(), securityType, TenorConverter.toApiTenor(forwardPoint.getTenor())))
               .referenceSpotDate().encodeEpochDays(forwardPoint.getReferenceSpotDate().getDaysSinceEpoch())
               .settlDate().encodeEpochDays(forwardPoint.getTenorDate().getDaysSinceEpoch())
               .sendingTime(0L)
               .entriesStart(2)
               .next()
                    .mdEntryType(EntryType.BID)
                    .mdEntryForwardPoints(baseSpreadConfiguration.pipsToRate(forwardPoint.getInstrument(),forwardPoint.getBidPoints()))
                    .mdEntryId(0)
                    .quoteEntryId(0)
               .next()
                    .mdEntryType(EntryType.OFFER)
                    .mdEntryForwardPoints(baseSpreadConfiguration.pipsToRate(forwardPoint.getInstrument(),forwardPoint.getOfferPoints()))
                    .mdEntryId(0)
                    .quoteEntryId(0)
                .entriesComplete()
                .hopsEmpty()
                .messageComplete();
    }

    private void pushSnapshotFullRefreshOntoUM(final MarketDataSnapshot marketDataSnapshot, final SecurityType securityType, final Tenor tenor) {
        final SnapshotFullRefreshEncoder encoder = getEncoder(securityType, marketDataSnapshot.getMarket(), marketDataSnapshot.getInstrument());

        SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_next = encoder.messageStart(0, marketDataSnapshot.getExternalSourceId())
                .possResend(false)
                .marketId(MarketConverter.toApi(marketDataSnapshot.getMarket()))
                .instrumentId(InstrumentKey.instrumentId(marketDataSnapshot.getInstrument().getExternalCode(), securityType, tenor))
                .messageId(convertEventIdToLong(marketDataSnapshot))
                .sendingTime(marketDataSnapshot.getExternalEventTimeNS())
                .entriesStart(marketDataSnapshot.getBidEventList().size() + marketDataSnapshot.getOfferEventList().size());

        SnapshotFullRefreshEncoder.MdEntries.Body mdEntries_body;
        for (MarketDataNewOrder bidEntry : marketDataSnapshot.getBidEventList()) {
            mdEntries_body = mdEntries_next.next()
                    .mdEntryPx(bidEntry.getPrice())
                    .mdEntrySize(bidEntry.getQuantity())
                    .mdEntryType(EntryType.BID);
            if (bidEntry.isIndicative()) {
                mdEntries_body.mdEntryFlags().add(Flag.INDICATIVE);
            }
            mdEntries_body.transactTime(bidEntry.getExternalEventTimeNS())
                    .mdEntryId(0)
                    .quoteEntryId(0);
        }

        for (MarketDataNewOrder offerEntry : marketDataSnapshot.getOfferEventList()) {
            mdEntries_body = mdEntries_next.next()
                    .mdEntryPx(offerEntry.getPrice())
                    .mdEntrySize(offerEntry.getQuantity())
                    .mdEntryType(EntryType.OFFER);
            if (offerEntry.isIndicative()) {
                mdEntries_body.mdEntryFlags().add(Flag.INDICATIVE);
            }
            mdEntries_body.transactTime(offerEntry.getExternalEventTimeNS())
                    .mdEntryId(0)
                    .quoteEntryId(0);
        }

        final Hops.Encoder.Next<MessageEncoder.Trailer> hopsNext = mdEntries_next.entriesComplete().hopsStart(0);
        hopsNext.hopsComplete().messageComplete();
    }

    private long convertEventIdToLong(final MarketDataSnapshot marketDataSnapshot) {
        if (marketDataSnapshot.getEventId().length() > 0) {
            return Long.parseLong(marketDataSnapshot.getEventId().toString());
        }
        return 0L;
    }

    private void pushIncrementalRefreshOntoUM(final MarketDataIncrement marketDataIncrement, final SecurityType securityType, final Tenor tenor) {
        final IncrementalRefreshEncoder encoder = getIncrementalEncoder(securityType, marketDataIncrement.getMarket(), marketDataIncrement.getInstrument());

        IncrementalRefreshEncoder.MdEntries.Next mdEntries_next = encoder.messageStart(0, marketDataIncrement.getExternalSourceId())
                .marketId(MarketConverter.toApi(marketDataIncrement.getMarket()))
                .instrumentId(InstrumentKey.instrumentId(marketDataIncrement.getInstrument().getExternalCode(), securityType, tenor))
                .entriesStart(marketDataIncrement.getEventsList().size());

        for (MarketDataOrder entry : marketDataIncrement.getEventsList()) {
            mdEntries_next = encodeEntry(mdEntries_next, entry);
        }

        final Hops.Encoder.Next<MessageEncoder.Trailer> hopsNext = mdEntries_next.entriesComplete().hopsStart(0);
        hopsNext.hopsComplete().messageComplete();
    }

    private IncrementalRefreshEncoder.MdEntries.Next encodeEntry(final IncrementalRefreshEncoder.MdEntries.Next mdEntries_next, final MarketDataOrder entry) {
        if (entry instanceof MarketDataNewOrder) {
            if (entry instanceof MarketDataReplaceOrder) {
                return encodeReplaceEntry(mdEntries_next.next(), (MarketDataReplaceOrder) entry);
            } else {
                return encodeNewEntry(mdEntries_next.next(), (MarketDataNewOrder) entry);
            }
        } else if (entry instanceof MarketDataDeleteOrder) {
            return encodeDeleteEntry(mdEntries_next.next(), (MarketDataDeleteOrder) entry);
        } else {
            throw new IllegalArgumentException(entry.getClass().getName() + " not a valid type for possible update actions");
        }
    }

    private IncrementalRefreshEncoder.MdEntries.Body encodeNewEntry(final IncrementalRefreshEncoder.MdEntries.Body mdEntry, final MarketDataNewOrder entry) {
        mdEntry.mdUpdateAction(UpdateAction.NEW)
                .mdMkt(MarketConverter.toApi(entry.getMarket()))
                .mdEntryPx(entry.getPrice())
                .mdEntrySize(entry.getQuantity())
                .mdEntryType(entry.getSide().getEntryType());
        if (entry.isIndicative()) {
            mdEntry.mdEntryFlags().add(Flag.INDICATIVE);
        }
        return mdEntry.transactTime(entry.getExternalEventTimeNS())
                .mdEntryId((int) LongCodec.decodeSigned(entry.getOrderId(), ByteReader.CHAR_SEQUENCE, entry.getOrderId().length(), 10))
                .mdEntryRefId(0)
                .quoteEntryId(0);
    }

    private IncrementalRefreshEncoder.MdEntries.Body encodeReplaceEntry(final IncrementalRefreshEncoder.MdEntries.Body mdEntry, final MarketDataReplaceOrder entry) {
        mdEntry.mdUpdateAction(UpdateAction.CHANGE)
                .mdMkt(MarketConverter.toApi(entry.getMarket()))
                .mdEntryPx(entry.getPrice())
                .mdEntrySize(entry.getQuantity())
                .mdEntryType(entry.getSide().getEntryType());
        if (entry.isIndicative()) {
            mdEntry.mdEntryFlags().add(Flag.INDICATIVE);
        }
        return mdEntry.transactTime(entry.getExternalEventTimeNS())
                .mdEntryId((int) LongCodec.decodeSigned(entry.getOrderId(), ByteReader.CHAR_SEQUENCE, entry.getOrderId().length(), 10))
                .mdEntryRefId((int) LongCodec.decodeSigned(entry.getPreviousOrderId(), ByteReader.CHAR_SEQUENCE, entry.getPreviousOrderId().length(), 10))
                .quoteEntryId(0);
    }

    private IncrementalRefreshEncoder.MdEntries.Body encodeDeleteEntry(final IncrementalRefreshEncoder.MdEntries.Body mdEntry, final MarketDataDeleteOrder entry) {
        return mdEntry.mdUpdateAction(UpdateAction.DELETE)
                .mdMkt(MarketConverter.toApi(entry.getMarket()))
                .mdEntryType(entry.getSide().getEntryType())
                .transactTime(entry.getExternalEventTimeNS())
                .mdEntryId((int) LongCodec.decodeSigned(entry.getOrderId(), ByteReader.CHAR_SEQUENCE, entry.getOrderId().length(), 10))
                .mdEntryRefId(0)
                .quoteEntryId(0);
    }
}


