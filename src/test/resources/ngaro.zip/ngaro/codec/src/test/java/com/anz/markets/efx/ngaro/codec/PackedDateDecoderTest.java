package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;

import org.junit.Test;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link PackedDateDecoder}
 */
public class PackedDateDecoderTest {

    @Test(expected = NullPointerException.class)
    public void noNullPackedDateSupplier() {
        PackedDateDecoder.forPackedDateSupplier(null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullBinaryPackedDateSupplier() {
        PackedDateDecoder.forBinaryPackedDateSupplier(null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullDecimalPackedDateSupplier() {
        PackedDateDecoder.forDecimalPackedDateSupplier(null);
    }

    @Test
    public void decodeLocalDateOrNull() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final LocalDate output = dec.decodeLocalDateOrNull();

        //then
        assertEquals("output not as expected", LocalDate.of(2017, 03, 14), output);
    }

    @Test
    public void decodeNull() {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 0);

        //when + then
        assertEquals("localDate should be null", null, dec.decodeLocalDateOrNull());
        assertEquals("year should be 0", 0, dec.decodeYear());
        assertEquals("month should be 0", 0, dec.decodeMonth());
        assertEquals("day should be 0", 0, dec.decodeDay());
        assertEquals("epochDays should be 0", 0, dec.decodeEpochDays());
        assertEquals("epochSeconds should be 0", 0, dec.decodeEpochSeconds());
        assertEquals("epochMillis should be 0", 0, dec.decodeEpochMillis());
        assertEquals("binary packed value should be 0", 0, dec.decodePacked(LocalDatePacking.BINARY));
        assertEquals("decimal packed valueshould be 0", 0, dec.decodePacked(LocalDatePacking.DECIMAL));
    }

    @Test
    public void decodePacked() throws Exception {
        final int binaryPacked = LocalDatePacking.BINARY.pack(2017, 03, 14);
        final PackedDateDecoder binaryDecoder = PackedDateDecoder.forBinaryPackedDateSupplier(() -> binaryPacked);
        final PackedDateDecoder decimalDecoder = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final int packedBinaryFromBinary = binaryDecoder.decodePacked(LocalDatePacking.BINARY);
        final int packedDecimalFromBinary = binaryDecoder.decodePacked(LocalDatePacking.DECIMAL);
        final int packedBinaryFromDecimal = decimalDecoder.decodePacked(LocalDatePacking.BINARY);
        final int packedDecimalFromDecimal = decimalDecoder.decodePacked(LocalDatePacking.DECIMAL);

        //then
        assertEquals(binaryPacked, packedBinaryFromBinary);
        assertEquals(binaryPacked, packedBinaryFromDecimal);
        assertEquals(20170314, packedDecimalFromBinary);
        assertEquals(20170314, packedDecimalFromDecimal);
    }

    @Test
    public void decodeEpochMillis() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final long epochMillis = dec.decodeEpochMillis();

        //then
        assertEquals("epochMillis not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.MILLIS_PER_DAY, epochMillis);
    }

    @Test
    public void decodeEpochSeconds() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final long epochSeconds = dec.decodeEpochSeconds();

        //then
        assertEquals("epochSeconds not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.SECONDS_PER_DAY, epochSeconds);
    }

    @Test
    public void decodeEpochDays() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final long epochDays = dec.decodeEpochDays();

        //then
        assertEquals("epochDays not as expected", LocalDate.of(2017, 03, 14).toEpochDay(), epochDays);
    }

    @Test
    public void decodeYear() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final int year = dec.decodeYear();

        //then
        assertEquals("year not as expected", 2017, year);
    }

    @Test
    public void decodeMonth() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final int month = dec.decodeMonth();

        //then
        assertEquals("month not as expected", 03, month);
    }

    @Test
    public void decodeDay() throws Exception {
        final PackedDateDecoder dec = PackedDateDecoder.forDecimalPackedDateSupplier(() -> 20170314);

        //when
        final int day = dec.decodeDay();

        //then
        assertEquals("day not as expected", 14, day);
    }

}