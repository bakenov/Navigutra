package com.anz.markets.efx.ngaro.time;

import java.util.function.Consumer;

/**
 * Very simplistic time formats with 2 digits for hour, minutes and optionally seconds and a fractional
 * seconds. Formats with and without delimiters are available.
 */
public enum LocalTimeFormat {
    /** Time format reading like 1715 for a quarter past 5pm */
    HHMM(0, 2, -1, -1, 0, -1, -1, -1),
    /** Time format reading like 171530 for 15 and a half minutes past 5pm */
    HHMMSS(0, 2, 4, -1, 0, -1, -1, -1),
    /** Time format reading like 171530234 for 15 minutes, 30 seconds and 234 milliseconds past 5pm */
    HHMMSSMMM(0, 2, 4, 6, 3, -1, -1, -1),
    /** Time format reading like 171530234567 for 15 minutes, 30 seconds and 234567 microseconds past 5pm */
    HHMMSSUUUUUU(0, 2, 4, 6, 6, -1, -1, -1),
    /** Time format reading like 171530234567890 for 15 minutes, 30 seconds and 234567890 nanoseconds past 5pm */
    HHMMSSNNNNNNNNN(0, 2, 4, 6, 9, -1, -1, -1),
    /**
     * Time format reading like 17:15 for a quarter past 5pm.
     * Delimter is ':' or any other character
     */
    HH_MM(0, 3, -1, -1, 0, 2, -1, -1),
    /**
     * Time format reading like 17:15:30 15 and a half minutes past 5pm.
     * Delimter is ':' or any other character
     */
    HH_MM_SS(0, 3, 6, -1, 0, 2, 5, -1),
    /**
     * Time format reading like 17:15:30 for 15 and a half minutes past 5pm.
     * Delimiter and fraction symbol are ':' and '.', respectively, or any other character.
     */
    HH_MM_SS_MMM(0, 3, 6, 9, 3, 2, 5, 8),
    /**
     * Time format reading like 17:15:30.234567 for 15 minutes, 30 seconds and 234567 microseconds past 5pm.
     * Delimiter and fraction symbol are ':' and '.', respectively, or any other character.
     */
    HH_MM_SS_UUUUUU(0, 3, 6, 9, 6, 2, 5, 8),
    /**
     * Time format reading like 17:15:30.234567890 for 15 minutes, 30 seconds and 234567890 nanoseconds past 5pm.
     * Delimiter and fraction symbol are ':' and '.', respectively, or any other character.
     */
    HH_MM_SS_NNNNNNNNN(0, 3, 6, 9, 9, 2, 5, 8);

    private static final LocalTimeFormat[] VALUES = values();

    private final int offsetHour;
    private final int offsetMinute;
    private final int offsetSecond;
    private final int offsetFraction;
    private final int fractionLength;
    private final int positionDelimiter1;
    private final int positionDelimiter2;
    private final int positionFractionSymbol;
    private final LocalTimeEncoder defaultEncoder;
    private final LocalTimeDecoder defaultDecoder;

    LocalTimeFormat(final int offsetHour, final int offsetMinute, final int offsetSecond,
                    final int offsetFraction, final int fractionLength,
                    final int positionDelimiter1, final int positionDelimiter2, final int positionFractionSymbol) {
        this.offsetHour = offsetHour;
        this.offsetMinute = offsetMinute;
        this.offsetSecond = offsetSecond;
        this.offsetFraction = offsetFraction;
        this.fractionLength = fractionLength;
        this.positionDelimiter1 = positionDelimiter1;
        this.positionDelimiter2 = positionDelimiter2;
        this.positionFractionSymbol = positionFractionSymbol;
        this.defaultEncoder = new LocalTimeEncoder(this);
        this.defaultDecoder = new LocalTimeDecoder(this);
    }

    public final int getOffsetHour() {
        return offsetHour;
    }

    public final int getOffsetMinute() {
        return offsetMinute;
    }

    public final int getOffsetSecond() {
        return offsetSecond;
    }

    public final int getOffsetFraction() {
        return offsetFraction;
    }

    public final int getFractionLength() {
        return fractionLength;
    }

    public final int getPositionDelimiter1() {
        return positionDelimiter1;
    }

    public final int getPositionDelimiter2() {
        return positionDelimiter2;
    }

    public final int getPositionFractionSymbol() {
        return positionFractionSymbol;
    }

    public final int getLength() {
        return 2 + 2 + (getOffsetSecond() >= 0 ? 2 : 0) + getFractionLength() +
                (getPositionDelimiter1() >= 0 ? 1 : 0) + (getPositionDelimiter2() >= 0 ? 1 : 0) +
                (getPositionFractionSymbol() >= 0 ? 1 : 0);
    }

    /**
     * @return the default encoder using ':' and '.' as delimiter and fraction symbol, respectively, for formats with such symbols.
     */
    public final LocalTimeEncoder getDefaultEncoder() {
        return defaultEncoder;
    }

    /**
     * @return the default decoder for this format
     */
    public final LocalTimeDecoder getDefaultDecoder() {
        return defaultDecoder;
    }

    public static void forEach(final Consumer<? super LocalTimeFormat> consumer) {
        for (final LocalTimeFormat value : VALUES) {
            consumer.accept(value);
        }
    }
}
