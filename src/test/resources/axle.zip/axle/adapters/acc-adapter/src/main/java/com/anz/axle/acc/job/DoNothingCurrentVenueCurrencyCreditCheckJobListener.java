package com.anz.axle.acc.job;

import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("doNothingCurrentVenueCurrencyCreditCheckJobListener")
public class DoNothingCurrentVenueCurrencyCreditCheckJobListener implements CurrentVenueCurrencyCreditCheckJobListener {
    @Override
    public void listen(CurrentVenueCurrencyCreditStates state) {
    }
}
