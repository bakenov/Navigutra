package com.anz.axle.lg.adapter.barx.uat;

import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.barx.acceptance.AcceptanceConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;

@Category(UatTest.class)

@RunWith(Spockito.class)
public class UatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatIntegrationTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);

    public static final String GB_LG_BARX = "GB:lg-barx";
    public static final String GB_LG_ACC = "GB:lg-acc";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private PriceListener priceListener;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-barx" +
                                ",default.log.level:DEBUG" +
                                ",barx.fix.log.destination:FILE" +
                                ",barx.fix.trading.reset.on.logon:Y" +
                                ",barx.fix.trading.reset.on.logout:Y" +
                                ",barx.fix.trading.reset.on.disconnect:Y" +

                                ",barx.fix.pricing.sendercompid:ANZDEV-PRICES-TEST" +
                                ",barx.fix.pricing.targetcompid:BARX-PRICES-TEST" +
                                ",barx.fix.pricing.host:10.54.180.193" +
                                ",barx.fix.pricing.port:55589" +

                                ",barx.fix.trading.sendercompid:ANZDEV-TRADES-TEST" +
                                ",barx.fix.trading.targetcompid:BARX-TRADES-TEST" +
                                ",barx.fix.trading.host:10.54.180.193" +
                                ",barx.fix.trading.port:55590"
                ));

        application = new Application("lg-barx-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        priceListener = new PriceListener(acceptanceContext.pricingMessageQueue());
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void testSendOrderAndReceiveExecutionReport() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final IncrementalRefreshMatcher matcher = IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(GB_LG_BARX))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.BARX))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().anyMatches(IncrementalRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                .entries().anyMatches(IncrementalRefreshMatcher.mdEntrySize().eq(5000000.0))
                .hops().hasAny();

        final PriceEntry priceEntry = priceListener.awaitPrice(matcher, EntryType.OFFER);

        System.out.println(priceEntry);
        System.out.println("==============================================================");

        final NewOrderSingle newOrderSingle = newOrderSingle(priceEntry.instrumentKey.symbol(), clOrdId, priceEntry.side, priceEntry.price,
                priceEntry.quoteId, priceEntry.size, priceEntry.currency(), OrderType.PREVIOUSLY_QUOTED);
        System.out.println("====Placing order=============================================");
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertSingleFill(priceEntry, clOrdId, OrderType.PREVIOUSLY_QUOTED);
    }

    private NewOrderSingle newOrderSingle(final String symbol, final String clOrdId, final Side side, final double price, final int quoteId,
                                          final double size, final String currency, final OrderType orderType) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.quoteId = String.valueOf(quoteId);
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.symbol = symbol;
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = 3000000.0;
        newOrderSingle.body.side = side;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.settlType = Tenor.SP;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private void assertSingleFill(final PriceEntry priceEntry, final String clOrdId, final OrderType orderType) throws Exception {

        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
            .matching(ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_BARX))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                .body().matches(ExecutionReportMatcher.marketId().eq(Venue.BARX.name()))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.symbol().eq(priceEntry.instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(priceEntry.currency()))
                .body().matches(ExecutionReportMatcher.side().eq(priceEntry.side))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0)
                .hops().countAtLeast(2))
            .awaitMatchAndGetLast(20, TimeUnit.SECONDS);
    }
}