package com.anz.axle.lg.adapter.apama.transport.local;

import java.util.function.Consumer;

import com.apama.event.Event;
import com.apama.event.parser.EventType;

import com.anz.axle.lg.adapter.apama.transport.Subscription;

public class LocalApamaSubscription implements Subscription {
    private final EventType eventType;
    private final Consumer<? super Event> eventConsumer;
    private final Runnable subscriptionCloser;

    public LocalApamaSubscription(final EventType eventType,
                                  final Consumer<? super Event> eventConsumer,
                                  final Runnable subscriptionCloser) {
        this.eventType = eventType;
        this.eventConsumer = eventConsumer;
        this.subscriptionCloser = subscriptionCloser;
    }

    @Override
    public void close() {
        subscriptionCloser.run();
    }

    public EventType eventType() {
        return eventType;
    }

    public Consumer<? super Event> eventConsumer() {
        return eventConsumer;
    }
}
