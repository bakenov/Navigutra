package com.anz.markets.prophet.atest.pricing._0b_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.framework.impl.TestDataDictionaryImpl;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.FilterEnabledConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.domain.CurrencyGroup;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.marketdata.filter.LatencyMarketDataFilter;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.MINUTES;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

/**
 * S-Filter : stale price filter (for any stale price in order book, exclude stale MARKET from order book)
 */
public class SFilterTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_1_5)
    @DisplayName("Don't remove market data that is not stale.")
    public void Should_not_remove_market_WHEN_is_not_stale() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setStaleFilterConfigs(TestDataDictionaryImpl.getStaleFilterConfigs(Integer.MAX_VALUE))
                    .setFilterEnabledConfigs(Arrays.asList(
                            new FilterEnabledConfig(new LatencyMarketDataFilter().getMarketDataFilterType().name(), Instrument.AUDUSD, Market.CNX, false)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94332, 0.00004, now()));
            prophet.receive(OneSecond.INSTANCE);
        }
        and:
        // cnx is not marked as stale - note market will only be marked as stale when it is actually stale.
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat("Assert for MARKET_STAKE not invoked.", marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.PASS));
        }
    }

    @Test
    @RestartBeforeTest(reason="flakey")
    @Requirement(value = Ref.PRICING_4_1_5)
    @DisplayName("Should remove market data that is stale with given timezone")
    public void should_remove_market_WHEN_is_stale_with_given_timezone() {
        setup:
        {
            // Set timezone as SNG
            prophet.receive(TradingTimeZone.SNG);

            ConfigurationData configurationData = tdd.configuration_pricing_001()
                    .setStaleFilterConfigs(TestDataDictionaryImpl.getStaleFilterConfigsWithTimezoneOverride(CurrencyGroup.MAJOR, TradingTimeZone.SNG, 2, 5))
                    .setFilterEnabledConfigs(Arrays.asList(
                            new FilterEnabledConfig(new LatencyMarketDataFilter().getMarketDataFilterType().name(), Instrument.AUDUSD, Market.CNX, false)
                    ));
            configurationData.getClientSpreadConfigs().addAll(
                    Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.1),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_2M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.11),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.12),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.13),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.14),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.15),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.16),

                            new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.11),

                            new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.12)
                    ));

            prophet.receive(configurationData);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94340, 0.00004, now()));
        }
        then:
        // first market data should not be marked as stale.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX));
            assertThat("Assert for MARKET_STAKE not invoked when market first arrived as stale market is only trigged by one second chime.",
                    marketDataSnapshotList.getLast().getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.PASS));
        }
        when:
        // increment time by 119 seconds
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(119));
        }
        then:
        {
            prophet.notExpect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX));
        }
        when:
        // second market data (triggered by one second chime) should then be marked as stale.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isInstrumentAndMarket(Instrument.AUDUSD, Market.CNX));
            assertThat("Market should be mark as stale.",
                    marketDataSnapshotList.getLast().getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.FAIL));
        }
        when:
        // change to LDN Timezone
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94336, 0.00004, now()));
        }
        then:
        // first market data should not be marked as stale.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX));
            assertThat("Assert for MARKET_STAKE not invoked when market first arrived as stale market is only trigged by one second chime.",
                    marketDataSnapshotList.getLast().getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.PASS));
        }
        when:
        // increment time by 299 seconds
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(299));
        }
        then:
        {
            prophet.notExpect(FilteredMarketDataSnapshot.class, isInstrumentAndMarket(Instrument.AUDUSD, Market.CNX));
        }
        when:
        // second market data (triggered by one second chime) should then be marked as stale.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isInstrumentAndMarket(Instrument.AUDUSD, Market.CNX));
            assertThat("Market should be mark as stale.",
                    marketDataSnapshotList.getLast().getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.FAIL));
        }
    }

    @Test
    @Requirement(value = Ref.PRICING_4_1_5)
    @DisplayName("Should remove market data that is stale using largest stale timeout. This test for staleness above the lower time out as well as larger timeout.")
    public void should_remove_market_WHEN_is_stale_using_largest_stale_timeout() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDMXN).setSpotDecimalPlaces(4.0).setSpotFractionalPip(1.0).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0.0).setAllInDecimalPlaces(5.0)
                    ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDMXN, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.1)
                    ))
                    .setStaleFilterConfigs(TestDataDictionaryImpl.getStaleFilterConfigs(new HashMap<CurrencyGroup, Long>() {
                        {
                            put(CurrencyGroup.MAJOR, MINUTES.toMinutes(10));
                            put(CurrencyGroup.EMERGING_MARKET, MINUTES.toMinutes(30));
                            put(CurrencyGroup.LOCAL_MARKET, MINUTES.toMinutes(30));
                            put(CurrencyGroup.NON_DELIVERABLE_FORWARD, MINUTES.toMinutes(40));
                            put(CurrencyGroup.PRECIOUS_METAL, MINUTES.toMinutes(50));
                        }

                    }))
                    .setFilterEnabledConfigs(Arrays.asList(
                            new FilterEnabledConfig(new LatencyMarketDataFilter().getMarketDataFilterType().name(), Instrument.AUDMXN, Market.CNX, false)
                    ))
            );
        }
        when:
        {
            // received market data that is 11mins ago
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDMXN, 0.94332, 0.00004, now() - MINUTES.toMillis(11)));
            // stale market is only triggered by one second chime
            prophet.receive(OneSecond.INSTANCE);
        }
        then:
        // market data should not be marked as stale as it is under the largest of two - 30 mins.
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX)).getFirst();
            assertThat("Should not marked as stale because it is less than the largest - 30 mins",
                    marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.PASS));
        }
        when:
        {
            // received market data that is 31mins ago
            prophet.clearOutputBuffer();
            // price is moved so that it regonised as significant change
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDMXN, 0.95332, 0.00004, now() - MINUTES.toMillis(31)));
            // stale market is only triggered by one second chime
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // first market data should not be marked as stale. second market data (triggered by one second chime) should then be marked as stale.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(2), isMarket(Market.CNX));
            assertThat("Assert for MARKET_STAKE not invoked when market first arrived as stale market is only trigged by one second chime.",
                    marketDataSnapshotList.getFirst().getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.PASS));
            assertThat("Market should be mark as stale.",
                    marketDataSnapshotList.getLast().getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.FAIL));
        }
    }


    @Test
    @Requirement(value = Ref.PRICING_4_1_5)
    @DisplayName("Should remove market data that is stale.")
    public void should_recover_market_from_stale_WHEN_new_market_data_arrives() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setStaleFilterConfigs(TestDataDictionaryImpl.getStaleFilterConfigs(30))
                    .setFilterEnabledConfigs(Arrays.asList(
                            new FilterEnabledConfig(new LatencyMarketDataFilter().getMarketDataFilterType().name(), Instrument.AUDUSD, Market.CNX, false)
                    ))
            );
        }
        when:
        {
            // received market data that is 30mins ago
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94332, 0.00004, now() - MINUTES.toMillis(30)));
            // stale market is only triggered by one second chime
            prophet.receive(OneSecond.INSTANCE);
            // received new market data that is not stale
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.94332, 0.00004));
        }
        then:
        // first market data should not be marked as stale. second market data (triggered by one second chime) should then be marked as stale.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.CNX));
            assertThat("Assert for MARKET_STAKE not invoked when market first arrived as stale market is only trigged by one second chime.",
                    marketDataSnapshotList.get(0).getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.PASS));
            assertThat("Market should be mark as stale.",
                    marketDataSnapshotList.get(1).getFilterOutcome(MarketDataFilterType.MARKET_STALE), is(FilterDecision.FAIL));
            assertThat("Assert for MARKET_STAKE not invoked when market first arrived as stale market is only trigged by one second chime.",
                    marketDataSnapshotList.get(2).getFilterOutcome(MarketDataFilterType.MARKET_STALE), not(FilterDecision.FAIL));
        }
    }

    @Test
    @Requirement(value = Ref.PRICING_4_1_5)
    @DisplayName("Testing removal of stale market and ensure market is added back when it become unstale.")
    public void should_remove_market_WHEN_is_stale_and_reaggregated_when_new_data_arrives() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setStaleFilterConfigs(TestDataDictionaryImpl.getStaleFilterConfigs(30))
            );
        }
        when:
        {
            // received market data that is stale
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94332, 0.00004, now() - MINUTES.toMillis(30)));
            // stale market is only triggered by one second chime
            prophet.receive(OneSecond.INSTANCE);
            // received new market data that is not stale
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.94332, 0.00004));
        }
        and:
        { // first agg book should be generated with market data, second agg book should be empty as stale market should be removed from agg book.
            // third should restore to the first state.
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U));
            assertThat("First agg book is formed when event was first received, agg book so agg book should not be empty.",
                    marketDataSnapshotList.get(0).isEmpty(), is(false));
            assertThat(marketDataSnapshotList.get(0), isMarketPricePoint(0, Level.QTY_1M, 0.94330, 0.94334));
            // todo: to assert time - this time is used for latency calc downstream
            //            assertThat(marketDataSnapshotList.get(0).getExternalEventTimeNS(), is(prophet.getCommand(MfxCompassProtomap.MarketDataMessage.class).get(0).getMarketDataSnapshot().getTriggerTime()));

            assertThat("Market is removed from agg book so it should now be empty.",
                    marketDataSnapshotList.get(1).isEmpty(), is(true));

            assertThat("First agg book is formed when event was first received, agg book so agg book should not be empty.",
                    marketDataSnapshotList.get(2).isEmpty(), is(false));
            assertThat(marketDataSnapshotList.get(2), isMarketPricePoint(0, Level.QTY_1M, 0.94330, 0.94334));

            // assert time stamp.

        }
    }
}
