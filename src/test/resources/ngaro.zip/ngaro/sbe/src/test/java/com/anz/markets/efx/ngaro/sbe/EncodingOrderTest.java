package com.anz.markets.efx.ngaro.sbe;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for {@link EncodingOrder}.
 */
public class EncodingOrderTest {

    private enum Order implements EncodingOrder<Order> {
        STEP_1, STEP_2, STEP_3;
    }

    @Test
    public void checkStrict_correctOrder() throws Exception {
        for (final Order order : Order.values()) {
            order.checkStrict(order);
        }
    }

    @Test
    public void checkStrict_incorrectOrder() throws Exception {
        for (final Order order1 : Order.values()) {
            for (final Order order2 : Order.values()) {
                if (order1 != order2) {
                    try {
                        order1.checkStrict(order2);
                        Assert.fail(order1 + ".checkStrict(" + order2 + ") should cause an exception");
                    } catch (final IllegalStateException e) {
                        //as expected
                    }
                }
            }
        }
    }

    @Test
    public void checkAllowMoveToNext() throws Exception {
        for (final Order order1 : Order.values()) {
            for (final Order order2 : Order.values()) {
                if (order1 == order2 || order1.ordinal() + 1 == order2.ordinal()) {
                    order1.checkAllowMoveToNext(order2);
                } else {
                    try {
                        order1.checkAllowMoveToNext(order2);
                        Assert.fail(order1 + ".checkAllowMoveToNext(" + order2 + ") should cause an exception");
                    } catch (final IllegalStateException e) {
                        //as expected
                    }
                }
            }
        }
    }

}