package com.anz.axle.lg.adapter.ebsu.preview;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.ebs.itch.generated.preview.messages.MessageNotifier;
import software.chronicle.ebs.itch.generated.preview.messages.client.LoginRequest;
import software.chronicle.ebs.itch.generated.preview.messages.server.*;
import software.chronicle.itch.staticcode.PreviewClientSessionHandler;
import software.chronicle.itch.staticcode.PreviewServerSessionHandler;

public class PreviewMessageNotifier implements MessageNotifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(PreviewMessageNotifier.class);

    @Override
    public void onChannelInformation(final PreviewServerSessionHandler session, final ChannelInformation channelInformation) {
        LOGGER.info("onChannelInformation {}", channelInformation);
    }

    @Override
    public void onInstrumentDirectory(final PreviewServerSessionHandler session, final InstrumentDirectory instrumentDirectory) {
        LOGGER.debug("onInstrumentDirectory {}", instrumentDirectory);
    }

    @Override
    public void onPriceLevelUpdate(final PreviewServerSessionHandler session, final PriceLevelUpdate priceLevelUpdate) {
        LOGGER.debug("onPriceLevelUpdate {}", priceLevelUpdate);
    }

    @Override
    public void onEndOfSnapshot(final PreviewServerSessionHandler session, final EndOfSnapshot endOfSnapshot) {
        LOGGER.info("onEndOfSnapshot {}", endOfSnapshot);
    }

    @Override
    public void onPreviewEnd(final PreviewServerSessionHandler session, final PreviewEnd previewEnd) {
        LOGGER.info("onPreviewEnd {}", previewEnd);
    }

    @Override
    public void onLoginRequest(final PreviewClientSessionHandler session, final LoginRequest loginRequest) {
        LOGGER.info("onLoginRequest {}", loginRequest);
    }
}
