package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public final class SbeInstrumentConfigEncoder implements InstrumentConfigEncoder, InstrumentConfigEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigEncoder instrumentConfigEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();

    private EncodingOrder.InstrumentConfig encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;

    SbeInstrumentConfigEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                               final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        instrumentConfigEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.InstrumentConfig.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        instrumentConfigEncoder.buffer().setMemory(offset, instrumentConfigEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public Body instrumentId(final long instrumentId) {
        encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
        instrumentConfigEncoder.instrumentId(instrumentId);
        return this;
    }

    @Override
    public Body pipSizeDivisor(final int pipSizeDivisor) {
        encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
        instrumentConfigEncoder.pipSizeDivisor(pipSizeDivisor);
        return this;
    }

    @Override
    public Trailer enabled(final boolean enabled) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.InstrumentConfig.TRAILER);
        instrumentConfigEncoder.enabled(enabled ? YesNo.YES : YesNo.NO);
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.TRAILER);
                message.messageLength(headerLength + instrumentConfigEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;
                headerEncoder.wrap(null, 0);
                instrumentConfigEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
