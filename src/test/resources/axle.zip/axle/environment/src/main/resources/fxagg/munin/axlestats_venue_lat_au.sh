#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_venue_lat_au - Plugin to monitor the Venue Trading Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=axlestats
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Venue Trading Latency (ms)'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category axlestats'
    echo 'graph_scale no'
    echo 'venue1.label Trading Orders (BARX)'
    echo 'venue1.draw LINE2'
    echo 'venue2.label Trading Orders (CNX)'
    echo 'venue2.draw LINE2'
    echo 'venue3.label Trading Orders (EBS)'
    echo 'venue3.draw LINE2'
    echo 'venue20.label Trading Orders (EBSD)'
    echo 'venue20.draw LINE2'
    echo 'venue4.label Trading Orders (RFX)'
    echo 'venue4.draw LINE2'
    echo 'venue6.label Trading Orders (MSI)'
    echo 'venue6.draw LINE2'
    echo 'venue7.label Trading Orders (CME)'
    echo 'venue7.draw LINE2'
    echo 'venue8.label Trading Orders (DEUT)'
    echo 'venue8.draw LINE2'
    echo 'venue9.label Trading Orders (GS)'
    echo 'venue9.draw LINE2'
    echo 'venue9.colour 0080ff'		# don't use red
    echo 'venue10.label Trading Orders (CMZ)'
    echo 'venue10.draw LINE2'
    echo 'venue14.label Trading Orders (HSP)'
    echo 'venue14.draw LINE2'
    echo 'venue15.label Trading Orders (UBS)'
    echo 'venue15.draw LINE2'
    echo 'venue16.label Trading Orders (CITI)'
    echo 'venue16.draw LINE2'
    echo 'venue21.label Trading Orders (FXBK)'
    echo 'venue21.draw LINE2'
    echo 'venue17.label Trading Orders (ANZD)'
    echo 'venue17.draw LINE2'
    echo 'venue18.label Trading Orders (FXALLMB)'
    echo 'venue18.draw LINE2'
    echo 'venue19.label Trading Orders (BGCMIDFX)'
    echo 'venue19.draw LINE2'
    exit 0
fi

CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logs/Correlator-FxAgg.pid

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ ! -f ${CORRELATOR_PIDFILE} ] ; then
        echo "venue1.value U"
        echo "venue2.value U"
        echo "venue3.value U"
        echo "venue20.value U"
        echo "venue4.value U"
        echo "venue6.value U"
        echo "venue7.value U"
        echo "venue8.value U"
        echo "venue9.value U"
        echo "venue10.value U"
        echo "venue14.value U"
        echo "venue15.value U"
        echo "venue16.value U"
        echo "venue21.value U"
        echo "venue17.value U"
        echo "venue18.value U"
        echo "venue19.value U"
        exit 0
fi

CORRELATOR_PID=$(cat ${CORRELATOR_PIDFILE})
if [ ! -d /proc/${CORRELATOR_PID} ] ; then
        echo "venue1.value U"
        echo "venue2.value U"
        echo "venue3.value U"
        echo "venue20.value U"
        echo "venue4.value U"
        echo "venue6.value U"
        echo "venue7.value U"
        echo "venue8.value U"
        echo "venue9.value U"
        echo "venue10.value U"
        echo "venue14.value U"
        echo "venue15.value U"
        echo "venue16.value U"
        echo "venue21.value U"
        echo "venue17.value U"
        echo "venue18.value U"
        echo "venue19.value U"
        exit 0
fi
LOGS=~/axle/fxagg/fxagg-core/logs
LOGFILE=`ls -altr $LOGS/AggregateTechPerformanceReports_[0-9]*.log | awk '{file=$9} END {print file}'`

if [ -f "$LOGFILE" ]; then
# Awk program for processing AggregateTechPerformanceReports.log
tail -3000 $LOGFILE | awk -F, '
BEGIN {
        venue1_count=0; venue1_perf=0;
        venue2_count=0; venue2_perf=0;
        venue3_count=0; venue3_perf=0;
        venue20_count=0; venue19_perf=0;
        venue4_count=0; venue4_perf=0;
        venue6_count=0; venue6_perf=0;
        venue7_count=0; venue7_perf=0;
        venue8_count=0; venue8_perf=0;
        venue9_count=0; venue9_perf=0;
        venue10_count=0; venue10_perf=0;
        venue14_count=0; venue14_perf=0;
        venue15_count=0; venue15_perf=0;
        venue16_count=0; venue16_perf=0;
        venue21_count=0; venue21_perf=0;
        venue17_count=0; venue17_perf=0;
        venue18_count=0; venue18_perf=0;
        venue19_count=0; venue19_perf=0;
}
/"Server-Venue:NewOrderRequest","","","[^\"]+"/ {
    if ($6 ~ /BARX/) {
	    venue1_perf=$13;
    }
    else if ($6 ~ /CNX/) {
	    venue2_perf=$13;
    }
    else if ($6 ~ /EBSD/) {
    	venue20_perf=$13;
    }
    else if ($6 ~ /EBS/) {
    	venue3_perf=$13;
    }
    else if ($6 ~ /RFX/) {
    	venue4_perf=$13;
    }
    else if ($6 ~ /MSI/) {
    	venue6_perf=$13;
    }
    else if ($6 ~ /CME/) {
    	venue7_perf=$13;
    }
    else if ($6 ~ /DEUT/) {
    	venue8_perf=$13;
    }
    else if ($6 ~ /GS/) {
    	venue9_perf=$13;
    }
    else if ($6 ~ /CMZ/) {
    	venue10_perf=$13;
    }
    else if ($6 ~ /HSP/) {
    	venue14_perf=$13;
    }
    else if ($6 ~ /UBS/) {
    	venue15_perf=$13;
    }
    else if ($6 ~ /CITI/) {
    	venue16_perf=$13;
    }
    else if ($6 ~ /FXBK/) {
    	venue21_perf=$13;
    }
    else if ($6 ~ /ANZD/) {
    	venue17_perf=$13;
    }
    else if ($6 ~ /FXALLMB/) {
    	venue18_perf=$13;
    }
    else if ($6 ~ /BGCMIDFX/) {
        venue19_perf=$13;
    }
}
END {
        print "venue1.value " venue1_perf;
        print "venue2.value " venue2_perf;
        print "venue3.value " venue3_perf;
        print "venue20.value " venue20_perf;
        print "venue4.value " venue4_perf;
        print "venue6.value " venue6_perf;
        print "venue7.value " venue7_perf;
        print "venue8.value " venue8_perf;
        print "venue9.value " venue9_perf;
        print "venue10.value " venue10_perf;
        print "venue14.value " venue14_perf;
        print "venue15.value " venue15_perf;
        print "venue16.value " venue16_perf;
        print "venue21.value " venue21_perf;
        print "venue17.value " venue17_perf;
        print "venue18.value " venue18_perf;
        print "venue19.value " venue19_perf;
}
'
fi
