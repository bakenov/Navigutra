package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteEncoder;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

/**
 * Note that all encoders returned by factories available through this class are allocated, that is, their methods
 * qualify for {@link Garbage} type {@link Garbage.Type#RESULT RESULT}
 */
@Garbage(Garbage.Type.RESULT)
public final class SbeSorEncoders implements SorEncoders<SbeMessage> {

    private final MessageEncoder.Factory<SbeMessage, PricingRefreshCompleteEncoder> pricingRefreshComplete;
    private final MessageEncoder.Factory<SbeMessage, TimerExpiryEncoder> timerExpiry;
    private final MessageEncoder.Factory<SbeMessage, FirewallConfigEncoder> firewallConfig;
    private final MessageEncoder.Factory<SbeMessage, VenueConfigEncoder> venueConfig;
    private final MessageEncoder.Factory<SbeMessage, UserConfigEncoder> userConfig;
    private final MessageEncoder.Factory<SbeMessage, InitialisationEncoder> initialisation;
    private final MessageEncoder.Factory<SbeMessage, InstrumentConfigEncoder> instrumentConfig;
    private final MessageEncoder.Factory<SbeMessage, VenueInstrumentConfigEncoder> venueInstrumentConfig;

    public SbeSorEncoders(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier) {
        Objects.requireNonNull(mutableMessageSupplier);
        this.pricingRefreshComplete = messageConsumerSupplier ->
                new SbePricingRefreshCompleteEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.timerExpiry = messageConsumerSupplier ->
                new SbeTimerExpiryEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.firewallConfig = messageConsumerSupplier ->
                new SbeFirewallConfigEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.venueConfig = messageConsumerSupplier ->
                new SbeVenueConfigEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.userConfig = messageConsumerSupplier ->
                new SbeUserConfigEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.initialisation = messageConsumerSupplier ->
                new SbeInitialisationEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.instrumentConfig = messageConsumerSupplier ->
                new SbeInstrumentConfigEncoder(mutableMessageSupplier, messageConsumerSupplier);
        this.venueInstrumentConfig = messageConsumerSupplier ->
                new SbeVenueInstrumentConfigEncoder(mutableMessageSupplier, messageConsumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, PricingRefreshCompleteEncoder> pricingRefreshComplete() {
        return pricingRefreshComplete;
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, TimerExpiryEncoder> timerExpiry() {
        return timerExpiry;
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, FirewallConfigEncoder> firewallConfig() {
        return firewallConfig;
    }

    @Override 
    public MessageEncoder.Factory<SbeMessage, VenueConfigEncoder> venueConfig() {
        return venueConfig;
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, UserConfigEncoder> userConfig() {
        return userConfig;
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, InitialisationEncoder> initialisation() {
        return initialisation;
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, InstrumentConfigEncoder> instrumentConfig() {
        return instrumentConfig;
    }

    @Override
    public MessageEncoder.Factory<SbeMessage, VenueInstrumentConfigEncoder> venueInstrumentConfig() {
        return venueInstrumentConfig;
    }

}