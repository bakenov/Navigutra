package com.anz.markets.efx.fox.firewall.state;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.firewall.FirewallTestContext;
import com.anz.markets.efx.fox.firewall.TestOrderFactory;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@RunWith(Spockito.class)
public class OrderTotalUsdQuantityThroughputFirewallTest {

    private final static String[] USERS = new String[] {
            "| userName | desk   |",
            "|==========|========|",
            "| anufriea | Some   |",
            "| marsdenj | Some   |",
            "|----------|--------|"
    };

    @Test
    @Spockito.Unroll({
            "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | lastUsdQty | markets   | result    |",
            "|=============|========|================|===========|==========|==============|=======|========|==========|============|===========|===========|",
            "| 1000007     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | false     |",
            "| 1000010     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | false     |",
            "| 3000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | true      |",
            "| 4000010     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | true      |",
    })
    public void orderTotalQuantityThroughput(final long timeNanos,
                                             final  String region,
                                             final  String targetStrategy,
                                             final  String portfolio,
                                             final  String username,
                                             final  SecurityType securityType,
                                             final  Tenor tenor,
                                             final  String symbol,
                                             final  double orderQty,
                                             final double lastUsdQty,
                                             final  String markets,
                                             final  boolean result
    ) {

        final String[] rules = new String[] {
                "| firewallName   | ruleId   | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period   | periodUnit    | local    | comment  | lastEditUsername | lastEditTime  | limitThreshold |",
                "|================|==========|===============|==================|=============|==================|=================|==============|=====================|==============|===============|==========|===============|==========|==========|==================|===============|================|",
                "| firewall1      | 10       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 3000000        |",
                "| firewall1      | 20       | .*            | .*               | .*          | .*               | anuf.*          | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 4000000        |",
                "| firewall1      | 30       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 5000000        |",
                "| firewall1      | 40       | .*            | .*               | .*          | .*               | marsdenj        | .*           | .*                  | .*           | .*            | 1        | ms            | true     | blah     | anufriea         | 3456          | 1000000        |",
                // should not be applied:
                "| firewall2      | 50       | .*            | .*               | .*          | .*               | .*              | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 1000000        |",
                "| firewall2      | 60       | .*            | .*               | .*          | .*               | anufriea        | .*           | .*                  | .*           | .*            | 1        | ms            | false    | blah     | anufriea         | 3456          | 1000000        |"
        };

        String[] appliedExecutionReports = new String[] {
                "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | lastUsdQty | markets   | execType  | leavesQty  |",
                "|=============|========|================|===========|==========|==============|=======|========|==========|============|===========|===========|============|",
                "| 1000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000001     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000002     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000003     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "| 1000004     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | 1000000    | FXALLMB   | NEW       | 1000000    |",
                "|-------------|--------|----------------|-----------|----------|--------------|-------|--------|----------|------------|-----------|-----------|------------|"
        };

        final InstrumentRepository instrumentRepository = mock(InstrumentRepository.class);
        final Instrument instrument = mock(Instrument.class);
        when(instrument.usdValue(orderQty)).thenReturn(lastUsdQty);

        final long instrumentId = InstrumentKey.instrumentId(symbol, securityType, tenor);
        when(instrumentRepository.lookup(instrumentId)).thenReturn(instrument);

        final FirewallTestContext testContext = new FirewallTestContext((name, userRepository, errorHandler) ->
                    Firewall.orderTotalUsdQuantityThroughput(name, userRepository, instrumentRepository, errorHandler), "firewall1", rules, appliedExecutionReports, USERS);


        final TestOrderFactory.OrderStub orderStub = new TestOrderFactory.OrderStub(timeNanos, region, targetStrategy,
                portfolio, username, securityType, tenor, symbol, orderQty, markets);

        testContext.precisionClock.accept(timeNanos);

        final NewOrderSingleDecoder newOrderSingle = testContext.testOrderFactory.createOrder(orderStub);
        assertThat(testContext.firewall.accept(newOrderSingle, testContext.commandContext)).isEqualTo(result);
    }
}