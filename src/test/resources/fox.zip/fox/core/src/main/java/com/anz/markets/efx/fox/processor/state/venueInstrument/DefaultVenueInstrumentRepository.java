package com.anz.markets.efx.fox.processor.state.venueInstrument;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

import org.agrona.collections.Long2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class DefaultVenueInstrumentRepository implements VenueInstrumentRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultVenueInstrumentRepository.class);

    public static final Function<Venue, Long2ObjectHashMap<DefaultVenueInstrument>> INSTRUMENTS_FACTORY = venueId -> new Long2ObjectHashMap<>();

    private final InstrumentRepository instrumentRepository;
    private final VenueRepository venueRepository;
    private final Consumer<VenueInstrument> onEnabledConsumer;
    private final Consumer<VenueInstrument> onDisabledConsumer;
    private final int initialBookSize;

    private final Map<Venue, Long2ObjectHashMap<DefaultVenueInstrument>> venueInstruments = new EnumMap<>(Venue.class);

    public DefaultVenueInstrumentRepository(final InstrumentRepository instrumentRepository,
                                            final VenueRepository venueRepository,
                                            final int initialBookSize,
                                            final Consumer<VenueInstrument> onEnabledConsumer,
                                            final Consumer<VenueInstrument> onDisabledConsumer) {
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
        this.venueRepository = Objects.requireNonNull(venueRepository);
        this.onEnabledConsumer = onEnabledConsumer;
        this.onDisabledConsumer = onDisabledConsumer;
        this.initialBookSize = initialBookSize;
    }

    @Override
    public VenueInstrument lookup(final Venue venueId, final long instrumentId) {
        final Long2ObjectHashMap<DefaultVenueInstrument> instruments = venueInstruments.get(venueId);
        if (instruments == null) return null;

        return instruments.get(instrumentId);
    }

    @Override
    public VenueInstrument lookup(final RequestKey requestKey) {
        return lookup(requestKey.market(), requestKey.instrumentKey().instrumentId());
    }

    @Override
    public VenueInstrument apply(final VenueInstrumentConfigDecoder venueInstrumentConfigDecoder) {
        final VenueInstrumentConfigDecoder.Body body = venueInstrumentConfigDecoder.body();
        final long instrumentId = body.instrumentId();
        final Venue venueId = body.venue();

        final Long2ObjectHashMap<DefaultVenueInstrument> instruments = venueInstruments.computeIfAbsent(venueId, INSTRUMENTS_FACTORY);
        DefaultVenueInstrument venueInstrument = instruments.get(instrumentId);

        if (venueInstrument == null) {
            final Instrument instrument = instrumentRepository.lookup(instrumentId);
            if (instrument == null) {
                throw new RuntimeException("Unknown instrument for instrumentKey " + InstrumentKey.of(instrumentId));
            }

            final com.anz.markets.efx.fox.api.domain.Venue venue = venueRepository.lookup(venueId);
            if (venue == null) {
                throw new RuntimeException("Unknown venue for venueId " + venueId);
            }

            venueInstrument = new DefaultVenueInstrument(instrument, venue, initialBookSize, onEnabledConsumer, onDisabledConsumer);
            instrument.addVenueInstrument(venueInstrument);
            instruments.put(instrumentId, venueInstrument);

            update(venueInstrument, body);
            //LOGGER.info("Created {}", venueInstrument);
        } else {
            update(venueInstrument, body);
            //LOGGER.info("Updated {}", venueInstrument);
        }

        return venueInstrument;
    }

    private static void update(final DefaultVenueInstrument venueInstrument, final VenueInstrumentConfigDecoder.Body body) {
        venueInstrument.priceIncrement(body.priceIncrement())
                .sizeIncrement(body.sizeIncrement())
                .clipSizeMultiple(body.clipSizeMultiple())
                .maxAllowedParentOrderQty(body.maxAllowedParentOrderQty())
                .minClipSize(body.minClipSize())
                .maxClipSize(body.maxClipSize())
                .staleDataTimeout(body.staleDataTimeout())
                .priority(body.priority())
                .proportion(body.proportion())
                .enabled(body.enabled());
    }
}
