package com.anz.markets.efx.fox.config;

import java.io.IOException;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.tools4j.eventsourcing.api.CommandExecutorFactory;
import org.tools4j.eventsourcing.api.EventApplierFactory;
import org.tools4j.eventsourcing.api.ExecutionQueue;
import org.tools4j.eventsourcing.mmap.MmapBuilder;
import org.tools4j.mmap.region.api.RegionRingFactory;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.eventloop.IdleStrategyId;
import static com.anz.markets.efx.fox.config.CommonConfig.idleStrategyFactory;

@Configuration
public class EventSourcingConfig {

    @Bean
    public RegionRingFactory regionRingFactory(final @Value("${event.sourcing.region.ring.factory}") RegionRingFactory.Provider provider) {
        return provider.get();
    }

    @Bean(destroyMethod = "close")
    public ExecutionQueue executionQueue(
            final CommandExecutorFactory commandExecutorFactory,
            final EventApplierFactory eventApplierFactory,
            final PrecisionClock systemPrecisionClock,
            final RegionRingFactory regionRingFactory,
            final @Value("${event.sourcing.directory}") String directory,
            final @Value("${event.sourcing.max.file.size.bytes}") long maxFileSizeBytes,
            final @Value("${event.sourcing.encoding.buffer.size}") int encodingBufferSize,
            final @Value("${event.sourcing.commands.file.prefix}") String commandsFilePrefix,
            final @Value("${event.sourcing.events.file.prefix}") String eventsFilePrefix,
            final @Value("${reset.all}") boolean resetAll,
            final @Value("${reset.events}") boolean resetEvents) throws IOException {

        final LongSupplier systemNanoClock = systemPrecisionClock::micros;

        return ExecutionQueue.builder()
                .commandQueue(
                        MmapBuilder.create()
                                .directory(directory)
                                .filePrefix(commandsFilePrefix)
                                .regionRingFactory(regionRingFactory)
                                .clearFiles(resetAll)
                                .maxFileSize(maxFileSizeBytes)
                                .buildQueue())
                .eventQueue(
                        MmapBuilder.create()
                                .directory(directory)
                                .filePrefix(eventsFilePrefix)
                                .regionRingFactory(regionRingFactory)
                                .clearFiles(resetAll || resetEvents)
                                .maxFileSize(maxFileSizeBytes)
                                .buildQueue())
                .commandExecutorFactory(commandExecutorFactory)
                .eventApplierFactory(eventApplierFactory)
                .transactionBufferSize(encodingBufferSize)
                .systemNanoClock(systemNanoClock)
                .build();
    }

    @Bean
    public Supplier<IdleStrategy> eventSourcingIdleStrategyFactory(final @Value("${event.sourcing.idle.strategy}") IdleStrategyId processorIdleStrategyId,
                                                                final @Value("${idle.strategy.backoff.maxSpins}") long backOffMaxSpins,
                                                                final @Value("${idle.strategy.backoff.maxYields}") long backOffMaxYields,
                                                                final @Value("${idle.strategy.backoff.maxParkPeriodUs}") long backOffMaxParkPeriodUs) {
        return idleStrategyFactory(processorIdleStrategyId, backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs);
    }
}
