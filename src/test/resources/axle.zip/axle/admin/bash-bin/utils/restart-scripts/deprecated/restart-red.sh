#!/bin/bash

ssh AxlSv@daxa020z 'cd /app/apama/axle/environment/correlator/scripts && ./stop.sh'
ssh axle@daxa003z 'cd /app/apama/axle/environment/correlator/scripts && ./stop.sh'

ssh axle@daxa007z 'cd /app/apama/axle/environment/proxy/scripts && ./stop.sh'
ssh AxlSv@daxa017z 'cd /app/apama/axle/environment/proxy/scripts && ./stop.sh'

ssh axle@daxa003z 'rm -rf ~axle/axle/datafabric/workspace/*'
ssh AxlSv@daxa020z 'rm -rf ~axle/axle/datafabric/workspace/*'

ssh axle@daxa003z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'
ssh AxlSv@daxa020z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh && sleep 5 && ./stop-datafabric.sh && sleep 5 && ./start-datafabric.sh'

ssh axle@daxa007z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'
ssh AxlSv@daxa017z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'

