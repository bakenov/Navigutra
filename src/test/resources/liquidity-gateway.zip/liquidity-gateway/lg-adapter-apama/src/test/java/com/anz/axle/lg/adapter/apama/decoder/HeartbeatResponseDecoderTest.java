package com.anz.axle.lg.adapter.apama.decoder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.event.HeartbeatResponse;
import com.anz.axle.lg.config.PricingEncoderLookup;

import static org.mockito.Mockito.verify;

/**
 * Unit test for {@link HeartbeatResponseDecoder}
 */
@RunWith(MockitoJUnitRunner.class)
public class HeartbeatResponseDecoderTest {
    private static final EventParser EVENT_PARSER = new EventParser(HeartbeatResponse.EVENT_TYPE);

    @Mock
    private PricingEncoderLookup pricingEncoderLookup;
    private String transport = "TRANSPORT";

    private HeartbeatResponseDecoder heartbeatResponseDecoder;

    @Before
    public void setUp() throws Exception {
        heartbeatResponseDecoder = new HeartbeatResponseDecoder(pricingEncoderLookup, transport);
    }

    @Test
    public void should_forward_snapshot_when_heartbeat_is_connected() throws Exception {
        //given
        final String heartbeatResponseMessage = "com.apama.fix.HeartbeatResponse(\"TRANSPORT\",5060,true)";
        final Event heartbeatResponseEvent = EVENT_PARSER.parse(heartbeatResponseMessage);

        //when
        heartbeatResponseDecoder.decode(heartbeatResponseEvent);

        //then
        verify(pricingEncoderLookup).forwardCurrentSnapshots();
    }

    @Test
    public void should_clean_all_books_when_heartbeat_is_disconnected() throws Exception {
        //given
        final String heartbeatResponseMessage = "com.apama.fix.HeartbeatResponse(\"TRANSPORT\",5060,false)";
        final Event heartbeatResponseEvent = EVENT_PARSER.parse(heartbeatResponseMessage);

        //when
        heartbeatResponseDecoder.decode(heartbeatResponseEvent);

        //then
        verify(pricingEncoderLookup).clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_DISCONNECTED);
    }
}