package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.IntPredicate;

import com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InitialisationDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.fox.codec.api.SorHandlerSupplier;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForwarder;

final class SbeMessageDecoder implements MessageDecoder<SbeMessage> {

    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final SbePricingRefreshCompleteDecoder pricingRefreshComplete = new SbePricingRefreshCompleteDecoder();
    private final SbeTimerExpiryDecoder timerExpiryDecoder = new SbeTimerExpiryDecoder();
    private final SbeFirewallConfigDecoder firewallConfigDecoder = new SbeFirewallConfigDecoder();
    private final SbeVenueConfigDecoder venueConfigDecoder = new SbeVenueConfigDecoder();
    private final SbeUserConfigDecoder userConfigDecoder = new SbeUserConfigDecoder();
    private final SbeInitialisationDecoder initialisationDecoder = new SbeInitialisationDecoder();
    private final SbeInstrumentConfigDecoder instrumentConfigDecoder = new SbeInstrumentConfigDecoder();
    private final SbeVenueInstrumentConfigDecoder venueInstrumentConfigDecoder = new SbeVenueInstrumentConfigDecoder();

    private final SorHandlerSupplier sorHandlerSupplier;
    private final IntPredicate templateIdPredicate;
    private final SbeMessageForwarder sbeMessageForwarder;

    public SbeMessageDecoder(final SorHandlerSupplier sorHandlerSupplier,
                             final IntPredicate templateIdPredicate,
                             final ForwardingLookup<SbeMessage> forwarderLookup) {
        this.sorHandlerSupplier = Objects.requireNonNull(sorHandlerSupplier);
        this.templateIdPredicate = Objects.requireNonNull(templateIdPredicate);
        this.sbeMessageForwarder = new SbeMessageForwarder(forwarderLookup);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        headerDecoder.wrap(message.buffer(), 0);
        sbeMessageForwarder.wrap(message);
        try {
            final int templateId = headerDecoder.templateId();
            if (templateIdPredicate.test(templateId)) {
                decode(message, templateId, sbeMessageForwarder);
                return true;
            }
            return false;
        } finally {
            headerDecoder.wrap(null, 0);
            sbeMessageForwarder.wrap(null);
        }
    }

    private void decode(final SbeMessage message, final int templateId, final MessageForwarder messageForwarder) {
        switch (templateId) {
            case PricingRefreshCompleteDecoder.TEMPLATE_ID:
                pricingRefreshComplete.decode(message, headerDecoder, sorHandlerSupplier.pricingRefreshComplete(), messageForwarder);
                break;
            case TimerExpiryDecoder.TEMPLATE_ID:
                timerExpiryDecoder.decode(message, headerDecoder, sorHandlerSupplier.timerExpiryHandler(), messageForwarder);
                break;
            case FirewallConfigDecoder.TEMPLATE_ID:
                firewallConfigDecoder.decode(message, headerDecoder, sorHandlerSupplier.firewallConfigHandler(), messageForwarder);
                break;
            case VenueConfigDecoder.TEMPLATE_ID:
                venueConfigDecoder.decode(message, headerDecoder, sorHandlerSupplier.venueConfigHandler(), messageForwarder);
                break;
            case UserConfigDecoder.TEMPLATE_ID:
                userConfigDecoder.decode(message, headerDecoder, sorHandlerSupplier.userConfigHandler(), messageForwarder);
                break;
            case InitialisationDecoder.TEMPLATE_ID:
                initialisationDecoder.decode(message, headerDecoder, sorHandlerSupplier.initialisationHandler(), messageForwarder);
                break;
            case InstrumentConfigDecoder.TEMPLATE_ID:
                instrumentConfigDecoder.decode(message, headerDecoder, sorHandlerSupplier.instrumentConfigHandler(), messageForwarder);
                break;
            case VenueInstrumentConfigDecoder.TEMPLATE_ID:
                venueInstrumentConfigDecoder.decode(message, headerDecoder, sorHandlerSupplier.venueInstrumentConfigHandler(), messageForwarder);
                break;
            default:
                throw new IllegalArgumentException("Unsupported template ID: " + templateId);
        }
    }

}
