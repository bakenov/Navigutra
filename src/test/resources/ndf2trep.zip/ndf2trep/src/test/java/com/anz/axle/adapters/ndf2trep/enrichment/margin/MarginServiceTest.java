package com.anz.axle.adapters.ndf2trep.enrichment.margin;

import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.markets.efx.ngaro.maths.Epsilon;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class MarginServiceTest {

    private static final double BID = 1.2345;
    private static final double ASK = 1.2347;

    private Map<String, Map<String, List<String>>> marginConfigMap;
    private Map<String, Long> symbolPipsMap;
    private Map<String, Set<String>> symbolVenuesFXSPOT;
    private Map<String, Map<String, Set<String>>> instrumentRics;
    private Map<String, String> publishSourceId;
    private Map<String, String> venueServiceNameMap;
    private Map<String, String> venuePublishSourceId;
    private RicRepository ricRepository;

    @Before
    public void beforeEach() {

        symbolVenuesFXSPOT = new HashMap<>();
        symbolVenuesFXSPOT.put("AUDCAD", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDCAD").add("WSP_A");
        symbolVenuesFXSPOT.get("AUDCAD").add("WSP_Z");
        symbolVenuesFXSPOT.put("AUDEUR", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDEUR").add("WSP_A");
        symbolVenuesFXSPOT.get("AUDEUR").add("WSP_Z");
        symbolVenuesFXSPOT.put("AUDJPY", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDJPY").add("WSP_Z");
        symbolVenuesFXSPOT.put("AUDNOK", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDNOK").add("WSP_A");
        symbolVenuesFXSPOT.put("AUDZAR", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDZAR").add("WSP_A");

        symbolPipsMap = new HashMap<>();
        symbolPipsMap.put("AUDCAD", 10000L);
        symbolPipsMap.put("AUDEUR", 10000L);
        symbolPipsMap.put("AUDGBP", 10000L);
        symbolPipsMap.put("AUDNZD", 10000L);
        symbolPipsMap.put("AUDIDR", 10L);
        symbolPipsMap.put("AUDJPY", 100L);
        symbolPipsMap.put("AUDNOK", 10000L);
        symbolPipsMap.put("AUDUSD", 10000L);
        symbolPipsMap.put("AUDZAR", 100L);

        instrumentRics = new HashMap<>();
        instrumentRics.put("EBS", new HashMap<>());
        instrumentRics.get("EBS").put("USDCNS", new HashSet<>());

        publishSourceId = new HashMap<>();
        publishSourceId.put("EBS", "AXLE_DEV");
        publishSourceId.put("WSP_A", "WHOLESALE");
        publishSourceId.put("WSP_Z", "SPDEE_DEV");

        venueServiceNameMap = new HashMap<>();
        venueServiceNameMap.put("EBS", "AXLE_DEV");
        venueServiceNameMap.put("WSP_A", "WHOLESALE");
        venueServiceNameMap.put("WSP_Z", "SPDEE_DEV");

        venuePublishSourceId = new HashMap<>();
        venuePublishSourceId.put("EBS", "AXLE_DEV");
        venuePublishSourceId.put("WSP_A", "WHOLESALE");
        venuePublishSourceId.put("WSP_Z", "SPDEE_DEV");

        marginConfigMap = new HashMap<>();
        addMarginConfig("AUDCAD", "SPDEE_DEV", "PERC,BID,-,0.009,ASK,+,0.008,4");
        addMarginConfig("AUDCAD", "WHOLESALE", "PERC,BID,-,0.009,ASK,+,0.008,4");
        addMarginConfig("AUDEUR", "SPDEE_DEV", "PIPS ,BID,-,2, ask ,+,3,4");
        addMarginConfig("AUDEUR", "WHOLESALE", "PIPS ,BID,-,1, ask ,+,0,4");
        addMarginConfig("AUDJPY", "SPDEE_DEV", "PERC,BID,-,0.009,ASK,+,0.000,2");
        addMarginConfig("AUDNOK", "WHOLESALE", "PERC,BID,-,0.005,ASK,+,0.006,3");
        addMarginConfig("AUDZAR", "WHOLESALE", "PIPS,BID,-,1,ASK,+,2,3");
    }

    private MarginService buildMarginService(String serviceName) {
        ricRepository =  new RicRepository(symbolVenuesFXSPOT,        // symbol.venues.FXSPOT
                instrumentRics,                             // venue.symbol.tenors.FXNDF
                new HashMap<>(),                            // venue.subscription.sourceId
                publishSourceId,                            // venue.publish.sourceId
                venueServiceNameMap,                        // venue.publish.serviceName
                serviceName);                               // ndf.trep.publish.destination.servicename
        return new MarginService(marginConfigMap, symbolPipsMap, ricRepository);
    }

    private void addMarginConfig(String instrument, String source, String params) {
        Map<String, List<String>> map = marginConfigMap.computeIfAbsent(instrument, (k) -> new HashMap<>());
        map.put(source, new ArrayList<>(Arrays.asList(params.split(","))));
    }

    private String getRicName(String symbol) {
        return symbol + "=" + ricRepository.getServiceName();
    }

    private void testBidMarginForSymbol(MarginService marginService, String symbol, double inputBid, double expectedBid) {
        double test = marginService.applyMargin(getRicName(symbol), EntryType.BID, inputBid);
        assertEquals(expectedBid, test, Epsilon.EPS_1eNegative7.getValue());
    }

    private void testAskMarginForSymbol(MarginService marginService, String symbol, double inputAsk, double expectedAsk) {
        double test = marginService.applyMargin(getRicName(symbol), EntryType.OFFER, inputAsk);
        assertEquals(expectedAsk, test, Epsilon.EPS_1eNegative7.getValue());
    }

    @Test
    public void testMarginConfigForSpdee() {
        MarginService marginService = buildMarginService("SPDEE_DEV");

        // not configured instrument
        testBidMarginForSymbol(marginService,"AUDKRW", BID, BID);
        testAskMarginForSymbol(marginService,"AUDKRW", ASK, ASK);

        testBidMarginForSymbol(marginService,"AUDCAD", BID, 1.2233);
        testAskMarginForSymbol(marginService,"AUDCAD", ASK, 1.2446);

        testBidMarginForSymbol(marginService,"AUDEUR", BID, 1.2343);
        testAskMarginForSymbol(marginService,"AUDEUR", ASK, 1.2350);

        testBidMarginForSymbol(marginService,"AUDGBP", BID, BID);
        testAskMarginForSymbol(marginService,"AUDGBP", ASK, ASK);

        testBidMarginForSymbol(marginService,"AUDJPY", 123.45, 122.33);
        testAskMarginForSymbol(marginService,"AUDJPY", 123.47, 123.47);

        testBidMarginForSymbol(marginService,"AUDIDR", BID, BID);
        testAskMarginForSymbol(marginService,"AUDIDR", ASK, ASK);

        assertTrue(marginService.isSpotMarginConfigured("AUDCAD=SPDEE_DEV"));
        assertTrue(marginService.isSpotMarginConfigured("AUDEUR=SPDEE_DEV"));
        assertFalse(marginService.isSpotMarginConfigured("AUDGBP=SPDEE_DEV"));
        assertFalse(marginService.isSpotMarginConfigured("AUDNZD=SPDEE_DEV"));
        assertFalse(marginService.isSpotMarginConfigured("AUDIDR=SPDEE_DEV"));
        assertTrue(marginService.isSpotMarginConfigured("AUDJPY=SPDEE_DEV"));
        assertFalse(marginService.isSpotMarginConfigured("AUDNOK=SPDEE_DEV"));
        assertFalse(marginService.isSpotMarginConfigured("AUDUSD=SPDEE_DEV"));
    }

    @Test
    public void testMarginConfigForWholesale() {
        MarginService marginService = buildMarginService("WHOLESALE");

        // not configured instrument
        testBidMarginForSymbol(marginService,"AUDNOK", BID, 1.228);
        testAskMarginForSymbol(marginService,"AUDNOK", ASK, 1.243);

        testBidMarginForSymbol(marginService,"AUDCAD", BID, 1.2233);
        testAskMarginForSymbol(marginService,"AUDCAD", ASK, 1.2446);

        testBidMarginForSymbol(marginService,"AUDEUR", BID, 1.2344);
        testAskMarginForSymbol(marginService,"AUDEUR", ASK, 1.2347);

        testBidMarginForSymbol(marginService,"AUDZAR", BID, 1.224);
        testAskMarginForSymbol(marginService,"AUDZAR", ASK, 1.255);
    }

}
