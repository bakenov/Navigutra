#!/bin/bash
# (c) 2016 ANZ

TITLE="Depth Latency (MSG-IAF)"
GREPSTR="LatencyDepthPerVag.MSG_CHANNEL"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_lat.common