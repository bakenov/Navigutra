package com.anz.markets.prophet.atest.pricing._1b_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.marketdata.adjustment.TOBVWAPMarketDataAdjustment;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * E-Filter : Order book oldest(aka Slowest) market/venue filter
 */

public class EFilterTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault enableEFilter() {
        ConfigurationDataDefault config = tdd.configuration_pricing_base()
                .setFilterEnabledConfigs(union(
                        tdd.enableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET),
                        tdd.enableFilter(MarketDataFilterType.MARKET_BOOK_CROSSED)
                ))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKET_ORDER_BOOK_SLOWEST_MARKET_TOLERANCE_MS, 100L)
                );
        return config;
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_9)
    @DisplayName("TOB BID market oldest - removed")
    public void tob_bid_market_oldest_removed() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);
            ConfigurationDataDefault config = enableEFilter();
            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75012, 0.75017));

            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75011, 0.75015));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(2), isMarket(Market.WSP_U)).getLast();

            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75015));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceMarket(Market.WSP_A));
            assertThat(clientPrice.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.75012, 0.75015));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75010, 0.75018));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(), is(FilterDecision.PASS)); // AXPROPHET-1055
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75015));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.750115, 0.750145));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_9)
    @DisplayName("TOB OFFER market oldest - removed")
    public void tob_offer_market_oldest_removed() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);
            ConfigurationDataDefault config = enableEFilter();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75011, 0.75015));

            prophet.incrementTime(100); // t+100
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75012, 0.75017));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(2), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75015));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceMarket(Market.WSP_A));
            assertThat(clientPrice.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.75012, 0.75015));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75010, 0.75018));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75017));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.75013, 0.75016));
        }
    }

    @Test
    @DisplayName("TOB BID and OFFER market oldest - removed")
    public void tob_bid_and_offer_market_oldest_removed() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = enableEFilter();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75011, 0.75014));

            prophet.incrementTime(100); // t+100
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75016));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75014));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            assertThat(clientPrice.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.75011, 0.75014));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75010, 0.75018));
        }

        then:
        {   // CNX BID/OFFER OLDEST => REMOVED
            // AXPROPHET-1369 GS and HSP aggregated on the BID side. Dont care which venue is reported
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_2M, 0.75010, Level.QTY_1M, 0.75016));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.750115, 0.750145));
        }
    }

    @Test
    @DisplayName("Multiple market breaches threshold - oldest removed")
    public void multiple_mkt_breach_threshold_oldest_removed() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);
            ConfigurationDataDefault config = enableEFilter();
            prophet.receive(config);
        }

        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75011, 0.75014));

            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75012, 0.75015));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(2), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75014));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceMarket(Market.WSP_A));
            assertThat(clientPrice.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.750115, 0.750145));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(101);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75010, 0.75018));
        }

        then:
        {   // CNX and HSP breach threshold. CNX is oldest out of the two so remove
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75015));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.75012, 0.75015));
        }
    }

    @Test
    @DisplayName("AXPROPHET-999 do not reduce to less than minimumMarket constraint")
    public void do_not_remove_oldest_market_minMarket_constraint() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);
            ConfigurationDataDefault config = enableEFilter();
            prophet.receive(config
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 2)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75012, 0.75017));
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75011, 0.75015));
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75018));
        }
        then:
        // CNX MARKET is NOT filtered out by E-filter as this would reduce total markets to 1 i.e below minMarket config value(2)
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(3), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75017));
        }
        when:
        // set minMarkets to 1
        {
            ConfigurationDataDefault config = enableEFilter();
            prophet.receive(config
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
            prophet.clearOutputBuffer();
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75011, 0.75019));
        }
        then:
        // CNX MARKET is filtered out by E-filter
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75019));
        }
    }

    @Test
    @DisplayName("AXPROPHET-1282 only consider markets that have passed all market filters")
    public void only_consider_mkts_with_no_failed_filters() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();

        // set up config for CNX ONLY
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(TOBVWAPMarketDataAdjustment.FEATURE_NAME,
                Market.CNX,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                TOBVWAPMarketDataAdjustment.FEATURE_PARAM_TARGET_TOB_VWAP_QTY, 1_000_000d)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(TOBVWAPMarketDataAdjustment.FEATURE_NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                TOBVWAPMarketDataAdjustment.FEATURE_PARAM_TARGET_TOB_VWAP_QTY, Double.NaN)
        );

        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);
            ConfigurationDataDefault config = enableEFilter();
            config.getPriceFormationPipelineConfigs().replaceFeature(TOBVWAPMarketDataAdjustment.FEATURE_NAME,priceFormationPipelineConfig);
            prophet.receive(config
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75013, 0.75015));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75015, 0.75000));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.GS)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED), Matchers.is(FilterDecision.FAIL));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(100);
            // CNX on BID side does not have enough liquidity(2mio) so bid side is cleared
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75013, 500_000),
                            new PriceAndQtyImpl(0.75010, 400_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75014, 2_500_000)),
                    tdd.now()));
        }
        then:
        // GS is crossed, and CNX is one sided(OFFER). So only HSP has no failed filters.
        // HSP is oldest market but since MinMarkets is set to 1, do NOT filter HSP
        //(previously, CNX was still considered viable, so HSP being oldest market was filtered out
        // which resulted in empty WSP_U)
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75013, 0.75014));
        }
    }
}
