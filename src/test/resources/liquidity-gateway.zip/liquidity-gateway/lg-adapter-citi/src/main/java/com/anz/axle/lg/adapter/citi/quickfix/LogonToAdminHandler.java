package com.anz.axle.lg.adapter.citi.quickfix;

import org.agrona.Strings;

import java.util.Objects;

import quickfix.Message;
import quickfix.SessionID;
import quickfix.field.Password;
import quickfix.field.TargetSubID;

import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.ToAdminHandler;
import com.anz.markets.efx.ngaro.api.Venue;

public class LogonToAdminHandler implements ToAdminHandler {
    private final Venue venue;
    private final SessionID pricingSessionId;
    private final String pricingPassword;
    private final SessionID tradingSessionId;
    private final String tradingPassword;
    private final String citiXConnectCoLoFixSpecVersion;

    private static final int FIX_VERSION_TAG_ID = 1408;


    public LogonToAdminHandler(final Venue venue, final SessionID pricingSessionId, final String pricingPassword,
                               final SessionID tradingSessionId, final String tradingPassword,
                               final String citiXConnectCoLoFixSpecVersion) {
        this.venue = venue;
        this.pricingSessionId = Objects.requireNonNull(pricingSessionId);
        this.pricingPassword = Objects.requireNonNull(pricingPassword);
        this.tradingSessionId = Objects.requireNonNull(tradingSessionId);
        this.tradingPassword = Objects.requireNonNull(tradingPassword);

        this.citiXConnectCoLoFixSpecVersion = citiXConnectCoLoFixSpecVersion;
    }

    @Override
    public void handle(final MessageType messageType, final Message message, final SessionID sessionId) {
        if (messageType == MessageType.LOGON) {
            if(!Strings.isEmpty(citiXConnectCoLoFixSpecVersion) && !citiXConnectCoLoFixSpecVersion.trim().isEmpty()) {
                message.setString(FIX_VERSION_TAG_ID, citiXConnectCoLoFixSpecVersion);
                message.setString(TargetSubID.FIELD, "FXSPOT");
            }
            if (pricingSessionId.equals(sessionId)) {
                message.setString(Password.FIELD, pricingPassword);
            } else if (tradingSessionId.equals(sessionId)) {
                message.setString(Password.FIELD, tradingPassword);
            } else {
                throw new UnsupportedOperationException("Unknown sessionId " + sessionId);
            }
        }
    }
}
