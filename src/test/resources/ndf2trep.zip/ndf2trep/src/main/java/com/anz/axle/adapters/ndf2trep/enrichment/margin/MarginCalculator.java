package com.anz.axle.adapters.ndf2trep.enrichment.margin;

import com.anz.markets.efx.ngaro.maths.DoubleTools;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.DoubleBinaryOperator;

class MarginCalculator {
    private static final Logger LOGGER = LoggerFactory.getLogger(MarginCalculator.class);

    private static final String BID = "BID";
    private static final String ASK = "ASK";

    private MarginType marginType;
    private long pips;
    private double bidMargin;
    private double offerMargin;
    private Operation bidOperation;
    private Operation offerOperation;
    private int decimalPlaceToRound;

    private enum MarginType {
        PERC,
        PIPS
    }

    // margin config fields in order
    private enum MarginConfigField implements BiConsumer<String, MarginCalculator> {
        MARGIN_TYPE {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                marginCalculator.marginType = MarginType.valueOf(s);
            }
        },
        BID_SIDE {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                EntryType bidSide = getSide(s.toUpperCase());
                if (bidSide != EntryType.BID) {
                    throw new IllegalArgumentException("Margin type should be BID: " + s);
                }
            }
        },
        BID_OPERATION {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                marginCalculator.bidOperation = Operation.fromOp(s);
                if (marginCalculator.bidOperation == null) {
                    throw new IllegalArgumentException(("Invalid margin operation: " + marginCalculator));
                }
            }
        },
        BID_MARGIN {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                marginCalculator.bidMargin = Double.parseDouble(s);
                if (Double.isNaN(marginCalculator.bidMargin) || DoubleTools.isLessThan(marginCalculator.bidMargin, 0.0)) {
                    throw new IllegalArgumentException("Invalid bid margin: " + s);
                }
            }
        },
        ASK_SIDE {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                EntryType offerSide =  getSide(s);
                if (offerSide != EntryType.OFFER) {
                    throw new IllegalArgumentException("Margin type should be ASK: " + s);
                }
            }
        },
        ASK_OPERATION {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                marginCalculator.offerOperation = Operation.fromOp(s);
                if (marginCalculator.offerOperation == null) {
                    throw new IllegalArgumentException(("Invalid margin operation: " + s));
                }
            }
        },
        ASK_MARGIN {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                marginCalculator.offerMargin = Double.parseDouble(s);
                if (Double.isNaN(marginCalculator.offerMargin) || DoubleTools.isLessThan(marginCalculator.offerMargin, 0.0)) {
                    throw new IllegalArgumentException("Invalid offer margin: " + s);
                }
            }
        },
        ROUNDING {
            @Override
            public void accept(String s, MarginCalculator marginCalculator) {
                marginCalculator.decimalPlaceToRound = Integer.parseInt(s);
                if (marginCalculator.decimalPlaceToRound < 1) {
                    throw new IllegalArgumentException("Invalid rounding decimal place: " + s);
                }
            }
        }
    }

    private enum Operation implements DoubleBinaryOperator {
        PLUS{
            public double applyAsDouble(double a, double b) { return a + b; }
        },
        MINUS {
            public double applyAsDouble(double a, double b) { return a - b; }
        };

        private static final String PLUS_OP = "+";
        private static final String MINUS_OP = "-";

        static Operation fromOp(String op) {
            switch (op) {
                case PLUS_OP :
                    return PLUS;
                case MINUS_OP :
                    return MINUS;
                default :
                    return null;
            }
        }
    }

    /**
     * @param params in the format of PERC/PIPS, BID, +/-, bidMarginValue(double), ASK, +/-, askMarginValue(double), roundingDecimalPlaces(integer)
     *               e.g. 'PERC','BID','-','0.0099','ASK','+','0','3'
     *                    'PIPS','BID','-','3','ASK','+','2','4'
     * @param pips indicates which decimal place to apply pips, in the power of 10, e.g. 10, 100, 1000, 10000, etc.
     * @return
     */
    public static MarginCalculator createFromMarginConfig(final List<String> params, final long pips) {
        if (!isPowerOfTen(pips)) {
            throw new IllegalArgumentException("Invalid pips: " + pips);
        }
        if (params.size() != MarginConfigField.values().length) {
            throw new IllegalArgumentException("Margin config with wrong number of parameters: " + params);
        }

        MarginCalculator calc = new MarginCalculator();
        calc.pips = pips;
        for(MarginConfigField field: MarginConfigField.values()) {
            String param = params.get(field.ordinal()).trim();
            try {
                field.accept(param, calc);
            } catch (Exception e) {
                LOGGER.error("Invalid margin parameter: {} ", param, e);
                throw new IllegalArgumentException("Invalid margin config: " + params);
            }
        }

        return calc;
    }

    private MarginCalculator() {}

    private static boolean isPowerOfTen(long number) {
        if (number < 10L) return false;

        while (number > 9 && number % 10 == 0)
            number /= 10;
        return number == 1;
    }

    private static EntryType getSide(String side) {
        switch (side.toUpperCase()) {
            case BID:
                return EntryType.BID;
            case ASK:
                return EntryType.OFFER;
            default:
                return null;
        }
    }

    public double applyMargin(final EntryType side, final double price) {
        switch (side) {
            case BID:
                return round(side, doApplyMargin(bidOperation, price, bidMargin));
            case OFFER:
                return round(side, doApplyMargin(offerOperation, price, offerMargin));
            default:
                return price;
        }
    }

    private double doApplyMargin(final Operation operation, final double price, final double marginValue) {
        if (marginType == MarginType.PERC) {
            return operation.applyAsDouble(price, price * marginValue);
        } else {
            // this a pips margin type
            return operation.applyAsDouble(price, marginValue / pips);
        }
    }

    private double round(final EntryType side, final double price) {
        return EntryType.BID.equals(side) ? DoubleTools.roundDown(price, decimalPlaceToRound) : DoubleTools.roundUp(price, decimalPlaceToRound);
    }

    @Override
    public String toString() {
        return "[" + marginType + "|" + decimalPlaceToRound + "|" + pips + "|" + bidMargin + "|" + offerMargin + "]";
    }
}
