package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeTriggerType.AGR_AXL_TWAP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;

@RestartBeforeTest(reason = "Firewall keeps state")
@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_3})
public class IOCOrderStatusTimeoutTest extends BaseAcceptanceSpecification {

    private NewOrder hedgingOrder1;
    private NewOrder hedgingOrder2;

    private ConfigurationDataDefault setUpConfiguration(long orderCompleteTimeout) {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setHedgePortfolioConfigs(asList(
                        new HedgePortfolioConfigImpl(Market.AXL, Portfolio.HEDGER_AGGRESSIVE).setEnabled(true).setOrderCompleteTimeoutMS(orderCompleteTimeout).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC),
                        new HedgePortfolioConfigImpl(Market.BGCMIDFX, Portfolio.HEDGER_MID_BGC).setEnabled(true).setOrderCompleteTimeoutMS(10000L).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.FXALLMB, Portfolio.HEDGER_MID_FXALL).setEnabled(true).setOrderCompleteTimeoutMS(10000L).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.EBSHEDGE, Portfolio.HEDGER_MID_EBS).setEnabled(true).setOrderCompleteTimeoutMS(10000L).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.EBS, Portfolio.HEDGER_PASSIVE_EBS).setEnabled(true).setOrderCompleteTimeoutMS(10000L).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.RFX, Portfolio.HEDGER_PASSIVE_RFX).setEnabled(true).setOrderCompleteTimeoutMS(10000L).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.AXL, Portfolio.HEDGER_ARBITRAGE).setEnabled(true).setOrderCompleteTimeoutMS(10000L).setOrderUnknownTimeoutMS(10000L).setCancelUnknownTimeoutMS(10000L).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC)
                ));

        return configuration;
    }

    @Test
    public void hedgerDisabledIOCOrderTimeout() {
        setup:
        {
            long orderCompleteTimeout = 3000L;
            prophet.receive(setUpConfiguration(orderCompleteTimeout));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0.5, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(EURUSD, -5_000_100, 1.05000));
        }
        and:
        // t+2 after orderRateTimePeriod - needs to line up with one second  interval.
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_500);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+5s, order still not in final state
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT)), 3_000);
        }
        then:
        // hedger disabled due to IOC order complete timeout (no cancel is sent)
        {
            // todo: for some reason it is sending out two hedgestatus at t+5
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
            prophet.notExpect(CancelOrder.class);
        }
        when:
        {
            prophet.clearOutputBuffer();
            // due to the order timing out, the trigger has been returned to IDLE
            // normally an order which remains unfilled at completion causes an immediate reassessment
            // but because the whole hedger was disabled, all triggers are set back to idle
            // (The DISABLED_TIMEOUT state could do with some more work perhaps.)
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        and:
        // TWAP Hedger does not fire immediately on enable. After 1 sec tick it will decide to hedge at end of its time window of 1 sec
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_000);
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD));
        }
    }

    @Test
    public void hedgerDisabledIOCOrderTimeout1SecChime() {
        setup:
        {
            long orderCompleteTimeout = 3000L;
            prophet.receive(setUpConfiguration(orderCompleteTimeout));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -5_000_100, 1.05000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+3s, order ack
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        // t+4s, order still not in final state
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedger disabled due to IOC order complete timeout (no cancel is sent)
        {
            // two messages: one caused by the timeout and one caused by the second chime
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    public void iocTimeoutClearedFromActiveOrderFirewall() {
        double maxActiveOrder = 1;
        setup:
        {
            long orderCompleteTimeout = 3000L;
            prophet.receive(setUpConfiguration(orderCompleteTimeout)
                    .setHedgeFirewallConfigs(asList(
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, 1, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, maxActiveOrder, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),

                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -5_000_100, 1.05000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(EURUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+3s, order ack
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        // t+4s, order still not in final state
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedger disabled due to IOC order complete timeout (no cancel is sent)
        {
            // two messages: one caused by the timeout and one caused by the second chime
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -5_000_100, 0.75));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));  // clears the previous active order from MAX ACTIVE ORDER FIREWALL
        }
        and:
        // as state is cleared, t+1 to decide and t+2 to place (given orderRateTimePeriod)
        {
            prophet.incrementTime(2_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ACTIVE_ORDER, HEDGER_AGGRESSIVE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
        }
        then:
        {
            prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(MAXIMUM_ACTIVE_ORDER, BREACHED, HEDGER_AGGRESSIVE));
        }
    }

    @Test
    public void orderFilledHedgerNotDisabled() {
        setup:
        {
            long orderCompleteTimeout = 3000L;
            prophet.receive(setUpConfiguration(orderCompleteTimeout));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -5_000_100, 1.05000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+3s, order ack
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        // t+3.9 sec order filled
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(900));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1, 1.05);
        }
        then:
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        // t+4s, hedger not disabled
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
        }
        then:
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    public void orderRejectedHedgerNotDisabled() {
        setup:
        {
            long orderCompleteTimeout = 3000L;
            prophet.receive(setUpConfiguration(orderCompleteTimeout));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -5_000_100, 1.05000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+3s, order rejected
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(hedgingOrder1));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        when:
        // t+4s, hedger not disabled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    public void disableIOCOrderTimeoutViaConfig() {
        setup:
        {
            long orderCompleteTimeout = 0L;  // do not perform/disable order complete timeout
            prophet.receive(setUpConfiguration(orderCompleteTimeout));
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, -5_000_100, 1.05000));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
        }
        when:
        // t+3s, order ack
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_AGGRESSIVE));
        }
        when:
        // t+4s, hedger still not in final state
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // hedger still enabled
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOn(HEDGER_AGGRESSIVE));
        }
    }

}
