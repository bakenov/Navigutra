package com.anz.axle.lg.adapter.apama.config.venue;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.SecurityType;

final class VenuePublications {
    private final Venue venue;
    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final VenueSymbolMatrix fxNdfVenueSymbolMatrix;

    public VenuePublications(final Venue venue,
                             final TopicRegistry pricingTopicRegistry,
                             final PublicationRegistry publicationRegistry,
                             final Map<String, Set<Venue>> fxSpotSymbolMarkets,
                             final Map<String, Set<Venue>> fxNdfSymbolMarkets) {
        this.venue = Objects.requireNonNull(venue);
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolMarkets));
        this.fxNdfVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxNdfSymbolMarkets));
    }

    public void init() {
        registerPublications(fxSpotVenueSymbolMatrix, SecurityType.FXSPOT);
        registerPublications(fxNdfVenueSymbolMatrix, SecurityType.FXNDF);
    }

    private void registerPublications(final VenueSymbolMatrix venueSymbolMatrix, final SecurityType securityType) {
        venueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            Tenor.forEach(tenor -> {
                final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol, securityType, tenor));
                publicationRegistry.registerPublication(topic);
            });
        });
    }

}
