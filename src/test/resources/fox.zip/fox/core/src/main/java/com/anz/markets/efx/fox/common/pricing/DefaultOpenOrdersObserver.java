package com.anz.markets.efx.fox.common.pricing;

import java.util.Objects;

import org.agrona.collections.Long2LongHashMap;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

public class DefaultOpenOrdersObserver implements PricingFeed.OpenOrdersObserver {
    private final static long MISSING_COUNTER_VALUE = -1;

    private Long2LongHashMap openOrdersCounters;
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);

    public DefaultOpenOrdersObserver(final Long2LongHashMap openOrdersCounters) {
        this.openOrdersCounters = Objects.requireNonNull(openOrdersCounters);
    }

    public DefaultOpenOrdersObserver() {
        this(new Long2LongHashMap(MISSING_COUNTER_VALUE));
    }

    @Override
    public void applyExecutionReport(final ExecutionReportDecoder executionReport) {
        final ExecutionReportDecoder.Body body = executionReport.body();
        final String marketId = body.marketId().decodeAndCache(marketIdCache);

        if (Venue.FOX.name().equals(marketId)) {
            final String symbol = body.symbol().decodeAndCache(symbolCache);
            final SecurityType securityType = body.securityType();
            final Tenor tenor = body.settlType();
            final long instrumentId = InstrumentKey.instrumentId(symbol, securityType, tenor);
            final long openOrders = count(instrumentId);

            if (body.execType() == ExecType.NEW) {
                openOrdersCounters.put(instrumentId, openOrders + 1);
            } else if(body.execType() != ExecType.REJECTED && body.leavesQty() <= 0 && openOrders > 0) {
                openOrdersCounters.put(instrumentId, openOrders - 1);
            }
        }
    }

    @Override
    public int count(final long instrumentId) {
        final int count = (int) openOrdersCounters.get(instrumentId);
        return count == MISSING_COUNTER_VALUE ? 0 : count;
    }

    @Override
    public void clear() {
        openOrdersCounters.clear();
    }
}
