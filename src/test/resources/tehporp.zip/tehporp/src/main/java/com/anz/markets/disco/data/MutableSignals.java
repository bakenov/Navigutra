package com.anz.markets.disco.data;

import com.anz.markets.disco.utils.DateUtils;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;

public class MutableSignals implements Signals, ProphetMarshallable {

    private long signalsId;
    private long externalEventTimeNS;
    private long externalSourceId;
    private Market market;
    private Instrument instrument;
    private final MutableSignal signals[] = new MutableSignal[SignalType.getValues().length];
    private final EnumObjMap<SignalType,Signal> signalsMap = new EnumObjMap<>(SignalType.class);
    private int size;

    public MutableSignals() {
        for (int i = 0; i < signals.length; i++) {
            signals[i] = new MutableSignal();
        }
    }

    public MutableSignals(final Market market, final Instrument instrument) {
        this();
        this.instrument = instrument;
        this.market = market;
    }

    public void add(SignalType type, double value, Symbol cc) {
        signals[size].setSignalType(type);
        signals[size].setValue(value);
        signals[size].setConditionCode(cc);
        final Signal prev = signalsMap.put(type,signals[size]);
        if (prev != null) {
            throw new RuntimeException("Signal already exists: " + type);
        }
        size++;
    }

    public void setInstrument(final Instrument instrument) {
        this.instrument = instrument;
    }

    public Instrument getInstrument() {
        return instrument;
    }

    public void setMarket(final Market market) {
        this.market = market;
    }

    public Market getMarket() {
        return market;
    }

    @Override
    public Signal getSignal(final int i) {
        return signals[i];
    }

    @Override
    public int getSize() {
        return size;
    }

    public void clear() {
        for (int i = 0; i < size; i++) {
            signalsMap.remove(signals[i].getSignalType());
        }
        size = 0;
    }

    @Override
    public long getSignalsId() {
        return signalsId;
    }

    public void setSignalsId(final long signalsId) {
        this.signalsId = signalsId;
    }

    @Override
    public long getExternalEventTimeNS() {
        return externalEventTimeNS;
    }

    public void setExternalEventTimeNS(final long externalEventTimeNS) {
        this.externalEventTimeNS = externalEventTimeNS;
    }

    @Override
    public long getExternalSourceId() {
        return externalSourceId;
    }

    public void setExternalSourceId(final long externalSourceId) {
        this.externalSourceId = externalSourceId;
    }

    @Override
    public Signal getSignal(final SignalType signalType) {
        return signalsMap.get(signalType);
    }

    @Override
    public boolean containsSignal(final SignalType signalType) {
        return signalsMap.containsKey(signalType);
    }

    @Override
    public void readMarshallable(final ProphetBytes in) {
        clear();  // for signalsMap.
        signalsId = in.readLong();
        externalEventTimeNS = in.readLong();
        instrument = Instrument.readMarshallableValueOf(in);
        market = Market.valueOf(in.readByte());
        size = in.readByte();
        for (int i = 0; i < size; i++) {
            signals[i].readMarshallable(in);
            signalsMap.put(signals[i].getSignalType(),signals[i]);
        }
        Context.context().header().since(MessageVersion.VERSION_0_91, () -> {
            externalSourceId = in.readLong();
        });

    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeLong(signalsId);
        out.writeLong(externalEventTimeNS);
        out.writeShort(instrument.getValue());
        out.writeByte(market.getValue());
        out.writeByte((byte) size);
        for (int i = 0; i < size; i++) {
            signals[i].writeMarshallable(out);
        }
        out.writeLong(externalSourceId);
    }

    @Override
    public String toString() {
        String s = "Signals{" +
                "signalsId=" + signalsId +
                ", externalEventTimeNS=" + externalEventTimeNS + " (" + DateUtils.getDateStr(externalEventTimeNS) + ")" +
                ", externalSourceId=" + externalSourceId +
                ", market=" + market +
                ", instrument=" + instrument +
                ", signals=[";
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                s += ", ";
            }
            s += signals[i];
        }
        s += "]}";
        return s;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        final MutableSignals signals1 = (MutableSignals) o;
        boolean res = signalsId == signals1.signalsId &&
                externalEventTimeNS == signals1.externalEventTimeNS &&
                externalSourceId == signals1.externalSourceId &&
                size == signals1.size &&
                market == signals1.market &&
                instrument == signals1.instrument;
        if (!res) { return false; }
        for (int i = 0; i < size; i++) {
            if (!signals[i].equals(signals1.signals[i])) { return false; }
        }
        return true;
    }

}