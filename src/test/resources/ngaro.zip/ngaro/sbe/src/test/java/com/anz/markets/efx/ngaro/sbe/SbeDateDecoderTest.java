package com.anz.markets.efx.ngaro.sbe;

import java.time.LocalDate;

import org.junit.Test;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Unit test for {@link SbeDateDecoder}
 */
public class SbeDateDecoderTest {

    @Test
    public void decodeLocalDate() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final LocalDate output = dec.decodeLocalDateOrNull();

        //then
        assertEquals("output not as expected", LocalDate.of(2017, 03, 14), output);
    }

    public void decodeLocalDate_null() {
        final FixedStringSource source = (i) -> (byte)"\0\0\0\0\0\0\0\0xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final LocalDate output = dec.decodeLocalDateOrNull();

        //then
        assertNull("output should be null", output);
    }

    @Test
    public void decodeEpochMillis() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final long epochMillis = dec.decodeEpochMillis();

        //then
        assertEquals("epochMillis not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.MILLIS_PER_DAY, epochMillis);
    }

    @Test
    public void decodeEpochSeconds() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final long epochSeconds = dec.decodeEpochSeconds();

        //then
        assertEquals("epochSeconds not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.SECONDS_PER_DAY, epochSeconds);
    }

    @Test
    public void decodeEpochDays() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final long epochDays = dec.decodeEpochDays();

        //then
        assertEquals("epochDays not as expected", LocalDate.of(2017, 03, 14).toEpochDay(), epochDays);
    }

    @Test
    public void decodeYear() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final int year = dec.decodeYear();

        //then
        assertEquals("year not as expected", 2017, year);
    }

    @Test
    public void decodeMonth() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final int month = dec.decodeMonth();

        //then
        assertEquals("month not as expected", 03, month);
    }

    @Test
    public void decodeDay() throws Exception {
        final FixedStringSource source = (i) -> (byte)"20170314xxxxxxxx".charAt(i);
        final SbeDateDecoder dec = new SbeDateDecoder(source, LocalDateFormat.YYYYMMDD);

        //when
        final int day = dec.decodeDay();

        //then
        assertEquals("day not as expected", 14, day);
    }

}