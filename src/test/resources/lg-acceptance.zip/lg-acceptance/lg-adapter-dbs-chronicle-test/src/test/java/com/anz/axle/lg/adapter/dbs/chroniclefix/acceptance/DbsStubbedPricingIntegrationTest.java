package com.anz.axle.lg.adapter.dbs.chroniclefix.acceptance;

import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MDEntryType;
import org.fix4j.spec.fix50sp2.fieldtype.MDUpdateAction;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.PricingFixSessionHelper;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.instrumentId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.marketId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.senderCompId;

public class DbsStubbedPricingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbsStubbedPricingIntegrationTest.class);

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private MatchingSession pricingServer;
    private SharedAcceptanceContext acceptanceContext;
    private PricingFixSessionHelper pricingFixSessionHelper;

    final private String senderCompId = "GB:lg-dbs";
    final private Venue marketId = Venue.DBS;
    private static final String FIX_DATA_DICTIONARY_FILE = "conf/FIX42-dbs.xml";

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        setPersistStorePath("dbs", testName.getMethodName());
        System.getProperties().put("venue", marketId);

        pricingFixSessionHelper = new PricingFixSessionHelper("dbs", "GB_DBS_MD_S", "GB_DBS_MD_T", "FIX.4.2", FIX_DATA_DICTIONARY_FILE);

        application = new Application("lg-dbs-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        if (pricingServer != null) pricingServer.shutdown();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private Predicate<Object> defaultIncrementalRefreshMessageMatcher() {
        return IncrementalRefreshMatcher.build()
                .body().matches(senderCompId().eq(senderCompId))
                .body().matches(marketId().eq(marketId))
                .body().matches(instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.M1)))
                .entries().countAtLeast(1)
                .hops().hasAny()
                .hops().countAtLeast(2);
    }

    private Predicate<Object> emptySnapshotMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.M1)))
                .entries().hasNone();
    }

    private final FixMessage defaultIncrementalRefreshFixMessage(String requestId) {
        final String symbol = "USD/INR";
        final String newEntryId1 = "B#-1388272055";
        final String newEntryQuoteId1 = "5356345634";
        final String newEntryQuantityString1 = "16863000000.00";
        final String newEntryPriceString1 = "1.33627";

        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATAINCREMENTALREFRESH.getOrdinal())
                .withField(FieldTypes.MDReqID, requestId)
                .withField(FieldTypes.NoMDEntries, 1)
                .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.NEW.getOrdinal())
                .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
                .withField(FieldTypes.MDEntryID, newEntryId1)
                .withField(FieldTypes.Symbol, symbol)
                .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
                .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
                .withField(FieldTypes.MDEntryDate, "20170221")
                .withField(FieldTypes.QuoteEntryID, newEntryQuoteId1)
                .withField(FieldTypes.MDEntryForwardPoints, 22.456)
                .build();
    }

    @Test
    public void should_receive_pricing_information_for_the_registered_ccy_pair() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|9301=1M|55=USD/INR");
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataIncrementalRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultIncrementalRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataIncrementalRefresh processed message is available in pricing queue.
        PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
            public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                LOGGER.info(incrementalRefresh.toString());
                Assert.assertEquals(marketId, incrementalRefresh.body.marketId);
                Assert.assertEquals(InstrumentKey.instrumentId("USDINR", SecurityType.FXNDF, Tenor.M1), incrementalRefresh.body.instrumentId);
                Assert.assertEquals(senderCompId, incrementalRefresh.body.senderCompId);
                Assert.assertNull(incrementalRefresh.body.tradeDate);
                Assert.assertEquals(1, incrementalRefresh.entries.size());
                Assert.assertEquals(1, incrementalRefresh.entries.get(0).mdEntryId);
                Assert.assertEquals(UpdateAction.NEW, incrementalRefresh.entries.get(0).mdUpdateAction);
                Assert.assertEquals(EntryType.BID, incrementalRefresh.entries.get(0).mdEntryType);
                Assert.assertEquals(1.33627, incrementalRefresh.entries.get(0).mdEntryPx,1e-6);
                Assert.assertEquals(22.456, incrementalRefresh.entries.get(0).mdEntryForwardPoints, 1e-6);
                Assert.assertEquals(16863000000.00, incrementalRefresh.entries.get(0).mdEntrySize, 1e-6);
                Assert.assertEquals(0.0, incrementalRefresh.entries.get(0).minQty, 1e-6);
                Assert.assertEquals(2, incrementalRefresh.hops.size());
                Assert.assertEquals("GB:DBS", incrementalRefresh.hops.get(0).hopCompId);
                Assert.assertEquals(0, incrementalRefresh.hops.get(0).hopReceivingTime);
                Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(0).hopMessageId);
                Assert.assertEquals(incrementalRefresh.body.sendingTime, incrementalRefresh.hops.get(0).hopSendingTime);
                Assert.assertEquals(senderCompId, incrementalRefresh.hops.get(1).hopCompId);
                Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(1).hopMessageId);
                Assert.assertEquals(acceptanceContext.precisionClock().nanos(), incrementalRefresh.hops.get(1).hopReceivingTime);
                Assert.assertEquals(acceptanceContext.precisionClock().nanos(), incrementalRefresh.hops.get(1).hopSendingTime);
            }
        });
    }

    @Test
    public void market_data_request_rejected() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|9301=1M|55=USD/INR");
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataRequestReject is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(pricingFixSessionHelper.marketDataRequestRejectFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build())
                .awaitNotMatching(5, TimeUnit.SECONDS);

        LOGGER.info("==============================================================");
    }

    @Test
    public void should_send_empty_snapshot_when_marketdata_fix_disconnects() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataIncrementalRefresh processed message is available in pricing queue.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|9301=1M|55=USD/INR");

        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        LOGGER.info("Sending back price.");
        pricingServer.send(defaultIncrementalRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        LOGGER.info("==============================================================");

        //When pricingServer (venue simulator) is shutdown
        pricingServer.shutdown();

        //Then empty snapshot messages should be available in pricing queue
        final PricingMessage pricingSnapShotMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(emptySnapshotMessageMatcher())
                .awaitMatchAndGetLast(10000, TimeUnit.SECONDS);

        LOGGER.info(pricingSnapShotMessage.toString());

        LOGGER.info("==============================================================");
    }

    @Test
    public void should_not_send_empty_snapshot_when_not_logged_on() throws Exception {

        //Given pricingServer (venue simulator) is down
        // When adapter is not connected
        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build())
                .awaitNotMatching(5, TimeUnit.SECONDS);

        LOGGER.info("==============================================================");
   }

}
