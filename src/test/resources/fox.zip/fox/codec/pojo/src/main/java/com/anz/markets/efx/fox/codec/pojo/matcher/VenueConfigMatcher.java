package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.Set;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.matcher.ValueMatcher;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface VenueConfigMatcher extends Predicate<Object> {

    Matcher<VenueConfigMatcher, VenueConfig.Body> body();

    static VenueConfigMatcher build() {
        return new VenueConfigMatcher() {
            private Predicate<VenueConfig> predicate = Matchers.isA(VenueConfig.class);

            @Override
            public Matcher<VenueConfigMatcher, VenueConfig.Body> body() {
                return matcher -> andThen(translate(venueConfig -> venueConfig.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof VenueConfig && predicate.test((VenueConfig) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private VenueConfigMatcher matcher() {
                return this;
            }

            private VenueConfigMatcher andThen(final Predicate<? super VenueConfig> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<VenueConfig.Body, Venue> venue() {
        return ComparisonMatcher.create("venue", b -> b.venue);
    }

    static ComparisonMatcher<VenueConfig.Body, String> compId() {
        return ComparisonMatcher.create("compId", b -> b.compId);
    }

    static ValueMatcher<VenueConfig.Body, Set<VenueCategory>> venueCategories() {
        return ValueMatcher.create("venueCategories", b -> b.venueCategories);
    }

    static ValueMatcher<VenueConfig.Body, Boolean> enabled() {
        return ValueMatcher.create("enabled", b -> b.enabled);
    }
}
