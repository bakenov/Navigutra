package com.anz.axle.lg.adapter.ebs;

import java.io.File;
import java.io.FileInputStream;
import java.util.Objects;
import java.util.Properties;
import java.util.function.Supplier;

public class PasswordProvider implements Supplier<String> {
    private final String password;

    public PasswordProvider(final String password,
                            final String passwordPropertiesFileName) throws Exception {

        Objects.requireNonNull(password);
        Objects.requireNonNull(passwordPropertiesFileName);

        final File passwordPropertiesFile = new File(passwordPropertiesFileName);
        final Properties properties = new Properties();

        if (passwordPropertiesFile.exists()) {
            try (final FileInputStream inputStream = new FileInputStream(passwordPropertiesFile)) {
                properties.load(inputStream);
            }
        }

        this.password = properties.getProperty("ebs.fix.user.request.password", password);
    }

    public String get() {
        return this.password;
    }
}
