package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.syscontrol.CoreMode;
import com.anz.markets.prophet.util.SystemProperties;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class TriangulationTest_Timezone_Changes extends BaseAcceptanceSpecification {

    @Test
    @DisplayName("AXPROPHET-774 defect")
    public void applyClientSpreadConfigWhenTimeZoneChanges() throws Exception {

        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverPairB = Instrument.USDJPY;
        final Instrument crossPair = Instrument.AUDJPY;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.8),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.8)
                    ));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75555, 0.0004));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 115.555, 0.04));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.SNG);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 115.550, 0.04));
        }
        then:
        {
            ClientPrice crossPairCp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(crossPairCp.getBids().size(), is(4));

            ClientPrice driverPairBCp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getFirst();
            assertThat(driverPairBCp.getBids().size(), is(4));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75550, 0.0004));
        }
        then:
        {
            ClientPrice driverPairACp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(driverPairACp.getBids().size(), is(9));

            ClientPrice crossPairCp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getFirst();
            assertThat(crossPairCp.getBids().size(), is(SystemProperties.CORE_MODE == CoreMode.TRIPLE ? 4 : 9));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 115.555, 0.04));
        }
        then:
        {
            ClientPrice driverPairACp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(driverPairACp.getBids().size(), is(9));

            ClientPrice crossPairCp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getFirst();
            assertThat(crossPairCp.getBids().size(), is(9));
        }
    }
}
