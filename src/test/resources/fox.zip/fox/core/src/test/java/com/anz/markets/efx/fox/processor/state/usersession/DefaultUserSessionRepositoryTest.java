package com.anz.markets.efx.fox.processor.state.usersession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.api.domain.UserSession;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.fox.processor.timer.Timer;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DefaultUserSessionRepositoryTest {
    @Mock
    private Timer timer;
    @Mock
    private Timer.Factory timerFactory;
    private int missedHeartbeatTimeoutMillis = 1000;
    private DefaultUserSessionRepository userSessionRepository;

    @BeforeEach
    void setUp() {
        userSessionRepository = new DefaultUserSessionRepository(timerFactory, missedHeartbeatTimeoutMillis);
        when(timerFactory.create(any())).thenReturn(timer);
    }

    @Test
    void userSessions_created_in_repository() {
        //given
        final String portfolio = "XEFX";
        final UserSessionKey key1 = UserSessionKey.of("id1", "user1", portfolio, Region.GB);
        final UserSessionKey key2 = UserSessionKey.of("id2", "user2", portfolio, Region.JP);
        assertThat(userSessionRepository.onlinePortfolioSessions(portfolio)).isEqualTo(0);
        //when
        final UserSession userSession1 = userSessionRepository.userSession(key1);

        //then
        assertThat(userSessionRepository.onlinePortfolioSessions(portfolio)).isEqualTo(0);

        //when
        userSession1.updateOnline();
        final UserSession userSession2 = userSessionRepository.userSession(key2);

        //then
        assertThat(userSessionRepository.onlinePortfolioSessions(portfolio)).isEqualTo(1);

        //when
        userSession2.updateOnline();

        //then
        assertThat(userSessionRepository.onlinePortfolioSessions(portfolio)).isEqualTo(2);

        //then
        userSession2.updateOffline();
        assertThat(userSessionRepository.onlinePortfolioSessions(portfolio)).isEqualTo(1);

        userSession1.updateOffline();
        assertThat(userSessionRepository.onlinePortfolioSessions(portfolio)).isEqualTo(0);
    }
}