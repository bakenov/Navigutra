package com.anz.markets.efx.fox.config;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.function.IntFunction;
import java.util.function.LongFunction;
import java.util.function.Supplier;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.agrona.concurrent.OneToOneConcurrentArrayQueue;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.tools4j.nobark.queue.EvictConflationQueue;
import org.tools4j.nobark.queue.ExchangeConflationQueue;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.IdleStrategyId;
import com.anz.markets.efx.fox.metric.Metric;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.client.api.ConflatingPartition;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.client.api.SnapshotterDecoderLookup;
import com.anz.markets.efx.pricing.client.api.metric.QueueAppenderMetricHandler;
import com.anz.markets.efx.pricing.client.api.metric.QueuePollerMetricHandler;
import com.anz.markets.efx.pricing.client.conflator.ConflatingPricingClient;
import com.anz.markets.efx.pricing.client.conflator.DefaultConflatingPartitionFactory;
import com.anz.markets.efx.pricing.client.conflator.DefaultSnapshotterDecoderLookupFactory;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import static com.anz.markets.efx.fox.config.CommonConfig.idleStrategyFactory;

public class PricingConfig {
    @Bean
    public QueueAppenderMetricHandler queueAppenderMetricHandler() {
        return (key, conflation) -> {
        }; // todo
    }

    @Bean
    public QueuePollerMetricHandler queuePollerMetricHandler() {
        return (key, polled) -> {
        }; // todo
    }

    @Bean
    public PricingClient<MutableSbeMessage> pricingClient(
                                       final @Value("${price.conflator.compId}") String compId,
                                       final @Value("${messaging.sbe.buffer.capacity:8192}") int sbeMessageBufferCapacity,
                                       final @Value("${initial.book.entries}") int initialBookEntries,
                                       final @Value("${price.conflator.max.downstream.book.side.entries}") int maxDownstreamBookSideEntries,
                                       final @Value("${runnable.queue.capacity}") int runnableQueueCapacity,
                                       final @Value("#{${price.conflator.partition.idle.strategies}}") List<IdleStrategyId> idleStrategyIds,
                                       final @Value("${idle.strategy.backoff.maxSpins}") long backOffMaxSpins,
                                       final @Value("${idle.strategy.backoff.maxYields}") long backOffMaxYields,
                                       final @Value("${idle.strategy.backoff.maxParkPeriodUs}") long backOffMaxParkPeriodUs,
                                       final @Value("${conflation.queue.capacity}") int conflatingQueueCapacity,
                                       final @Value("#{${price.conflator.partitions}}") List<? extends List<String>> partitions,
                                       final PrecisionClock systemPrecisionClock,
                                       final Transport transport,
                                       final EndPointStatusHandler transportEndPointStatusHandler,
                                       final QueueAppenderMetricHandler queueAppenderMetricHandler,
                                       final QueuePollerMetricHandler queuePollerMetricHandler,
                                       final MetricRepository<Metric, Venue> metricRepository,
                                       final ScheduledExecutorService scheduledExecutorService,
                                       final @Value("${metrics.reporting.period.sec}") int metricReportingDelaySeconds,
                                       final @Value("${fox.pricing.client.source.id}") int foxPricingClientSourceId) {

        final LongFunction<ExchangeConflationQueue<RequestKey, MutableSbeMessage>> instrumentKeyConflationQueueFactory = instrumentConflationQueueFactory(conflatingQueueCapacity,
                queueAppenderMetricHandler,
                queuePollerMetricHandler);

        final SnapshotterDecoderLookup.Factory<MutableSbeMessage> snapshotterDecoderLookupFactory =
                new DefaultSnapshotterDecoderLookupFactory(
                        compId,
                        sbeMessageFactory(sbeMessageBufferCapacity),
                        systemPrecisionClock,
                        initialBookEntries,
                        MetricsConfig.latencyMetricRecorderLookup(metricRepository),
                        foxPricingClientSourceId,
                        maxDownstreamBookSideEntries);
        final IntFunction<? extends Queue<Runnable>> runnableQueueFactory = runnableQueueFactory(runnableQueueCapacity, metricRepository, scheduledExecutorService, metricReportingDelaySeconds);

        final ConflatingPartition.Factory<MutableSbeMessage> pricePartitionConflatorFactory =
                new DefaultConflatingPartitionFactory<>(
                        snapshotterDecoderLookupFactory,
                        runnableQueueFactory,
                        () -> transport.openConnection(() -> {}),
                        transportEndPointStatusHandler,
                        idleStratedyLookup(idleStrategyIds, backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs),
                        instrumentKeyConflationQueueFactory);


        return new ConflatingPricingClient<>(partitions, pricePartitionConflatorFactory,
                "PriceConflator", "ConflatingPartition");
    }

    static LongFunction<ExchangeConflationQueue<RequestKey, MutableSbeMessage>> instrumentConflationQueueFactory(final int conflatingQueueCapacity,
                                                                                                                 final QueueAppenderMetricHandler queueAppenderMetricHandler,
                                                                                                                 final QueuePollerMetricHandler queuePollerMetricHandler) {
        return instrumentId -> new EvictConflationQueue<>(
                () -> new OneToOneConcurrentArrayQueue<>(conflatingQueueCapacity),
                HashMap::new,
                () -> (queue, key, newValue, oldValue, conflation) -> {
                    switch (conflation) {
                        case UNCONFLATED:
                            queueAppenderMetricHandler.record(key, QueueAppenderMetricHandler.Conflation.UNCONFLATED);
                            break;
                        case EVICTED:
                            queueAppenderMetricHandler.record(key, QueueAppenderMetricHandler.Conflation.EVICTED);
                            break;
                        case MERGED:
                            queueAppenderMetricHandler.record(key, QueueAppenderMetricHandler.Conflation.MERGED);
                            break;
                        default:
                            throw new IllegalArgumentException("Unsupported conflation type: " + conflation);
                    }
                },
                () -> (queue, key, value) -> queuePollerMetricHandler.record(key));
    }

    static Supplier<MutableSbeMessage> sbeMessageFactory(final int sbeMessageBufferCapacity) {
        return () -> {
            final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
            final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
            return new SbeMessageForWriting(buffer);
        };
    }

    static IntFunction<? extends Queue<Runnable>> runnableQueueFactory(final int runnableQueueCapacity,
                                                                       final MetricRepository<Metric, Venue> metricRepository,
                                                                       final ScheduledExecutorService scheduledExecutorService,
                                                                       final int metricReportingDelaySeconds) {
        return partitionIndex -> {
            final Queue<Runnable> runnableQueue = new MonitoredQueue<>(
                    new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(runnableQueueCapacity)),
                    (metric, value, element) -> {
                    });// todo: runnable queue metrics
            MetricsConfig.createMetricReporterJob(
                    MetricsConfig.metricDomain(partitionIndex),
                    metricRepository,
                    runnableQueue,
                    scheduledExecutorService,
                    metricReportingDelaySeconds);
            return runnableQueue;
        };
    }

    static IntFunction<com.anz.markets.efx.eventloop.IdleStrategy> idleStratedyLookup(final List<IdleStrategyId> idleStrategyIds,
                                                                                      final long backOffMaxSpins,
                                                                                      final long backOffMaxYields,
                                                                                      final long backOffMaxParkPeriodUs) {
        final IntFunction<IdleStrategyId> idleStrategyIdFactory = index -> {
            if (index >= idleStrategyIds.size())
                throw new IllegalArgumentException("No idleStrategyId for index " + index);
            return idleStrategyIds.get(index);
        };

        return partitionIndex -> idleStrategyFactory(idleStrategyIdFactory.apply(partitionIndex), backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs).get();
    }
}
