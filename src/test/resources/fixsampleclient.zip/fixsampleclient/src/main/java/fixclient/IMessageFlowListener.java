// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

/**
 * Generic interface for message recorders. Provides separate methods for sent
 * and received FIX messages, and status messages and errors.
 */
public interface IMessageFlowListener
{
    /**
     * Logs a received message.
     * 
     * @param message
     */
    public void messageReceived(QuickFixSessionMessage message);

    /**
     * Logs a sent message.
     * 
     * @param message
     */
    public void messageSent(QuickFixSessionMessage message);

    /**
     * Logs some status text.
     * 
     * @param statusText
     *            the text to log.
     */
    public void logStatusText(String statusText);

    /**
     * Logs the supplied text as an error, with optional exception.
     * 
     * @param errorText
     *            the text to log.
     * @param exception
     *            an exception to log, or null.
     */
    public void logError(String errorText, Exception exception);

    /**
     * Notification that no more messages/status will come this way.
     */
    public void stop();
}
