package com.anz.axle.ant;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/*
 * An Ant task that generates properties containing the difference of hour-of-day for
 * predefined timezones. Values are generated for every hour, starting from 0 to 23.
 * 
 * A reference date for which the difference is calculated can be provided in two ways:
 * either a fixed date through the `targetDate' parameter formatted as `yyyy-MM-dd', or
 * using the actual date of the task execution by omitting this parameter. The second
 * method can further be adjusted with a `targetDayOfWeek' parameter which contains a
 * day-of-week value. If the requested day has already passed, the same day on the
 * following week will be used. The `targetDayOfWeek' parameter is optional, if not
 * specified, the actual date will be used without any change.
 * 
 * For convenience, warnings are issued in case differences occur between values for
 * the reference date and a week before that.
 * 
 * The name of the generated property follows the convention:
 *   tzc_<HOUR_OF_DAY>_<FROM_TIMEZONE_TZ_DATABASE_CODE>_TO_<TO_TIMEZONE_TZ_DATABASE_CODE>
 *
 * Predefined timezone stacks:
 *      FROM_TIMEZONE  TO_TIMEZONE
 *   -------------------------------------
 *   America/New_York  Australia/Melbourne
 *   America/New_York  UTC
 *        New Zealand  Australia/Melbourne
 *        New Zealand  UTC
 *
 * For example, ${tzc_17_est_to_utc} results `21' on `2014-03-11', and `22' on `2014-11-04'.
 * ${tzc_7_nzst_to_aest} will give `5' on `2014-04-07' and so on.
 * 
 * Intended usage in a build file:
 *   <!-- Include the task definition. The classpath should include the 'Axle Environment'
 *        and 'Joda Time' libraries. -->
 *   <taskdef name="timezone-config-generator"
 *            classname="com.anz.axle.ant.TimezoneConfigGeneratorTask"
 *            classpath="<CLASSPATH>" />
 *   :
 *   <!-- Execute the task and make the variables available for normal property substitution.
 *        Use the actual date as a reference point. -->
 *   <timezone-config-generator />
 * or
 *   <!-- Execute the task and make the variables available for normal property substitution.
 *        Use the actual date adjusted to Monday - following rules explained above -,
 *        as a reference point. -->
 *   <timezone-config-generator targetDayOfWeek="monday" />
 * or
 *   <!-- Execute the task and make the variables available for normal property substitution.
 *        Use the provided date as a reference point. -->
 *   <timezone-config-generator targetDate="2014-10-15" />
 * 
 * As an alternative to using the values in a dynamic manner, the generated properties
 * can be saved to a file by defining the `outputPath' attribute. The `backupExistingOutput'
 * parameter controls whether backups of existing files should be created or not - default
 * value is `false'.
 *   <timezone-config-generator outputPath="${basedir}/${conf.dir}" backupExistingOutput="false" />
 */
public class TimezoneConfigGeneratorTask extends Task {
    private static final String TIMEZONE_PROPERTIES_FILENAME = "timezones.properties";
    private static final String YYYY_MM_DD = "yyyy-MM-dd";

    private String targetDate;
    private DateTime parsedTargetDate;
    private String targetDayOfWeek;
    private Integer parsedTargetDayOfWeek;
    private String outputPath;
    private boolean backupExistingOutput;
    private File outputPathFile;

    public String getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(String targetDate) {
        this.targetDate = targetDate;
        this.parsedTargetDate = parseDateStringToDateTime(targetDate);
    }

    public String getTargetDayOfWeek() {
        return targetDayOfWeek;
    }

    public void setTargetDayOfWeek(String targetDayOfWeek) {
        this.targetDayOfWeek = targetDayOfWeek;
        this.parsedTargetDayOfWeek = getDayLiteralAsDayOfWeek(targetDayOfWeek);
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPathString) {
        if (outputPathString != null && !outputPathString.isEmpty()) {
            this.outputPath = outputPathString;

            File outputPathFile = new File(outputPathString).getAbsoluteFile();
            if (outputPathFile.isDirectory() && outputPathFile.canWrite()) {
                this.outputPathFile = outputPathFile;
            } else {
                throw new IllegalStateException(String.format("Path is not writable or not a directory [%s]", outputPathString));
            }
        }
    }

    public boolean isBackupExistingOutput() {
        return backupExistingOutput;
    }

    public void setBackupExistingOutput(boolean backupExistingOutput) {
        this.backupExistingOutput = backupExistingOutput;
    }

    @Override
    public void execute() {
        DateTime baseDate = parsedTargetDate;

        if (baseDate == null) {
            baseDate = DateTime.now();

            if (parsedTargetDayOfWeek != null) {
                if (baseDate.getDayOfWeek() > parsedTargetDayOfWeek) {
                    baseDate = baseDate.plusWeeks(1);
                }

                baseDate = baseDate.withDayOfWeek(parsedTargetDayOfWeek);
            }
        }

        TimeZoneHourOfDayStack[] predefinedHourOfDayStacks = getHourOfDayStacks();
        Map<String, String> allStackValues = new LinkedHashMap<String, String>();

        for (TimeZoneHourOfDayStack hourOfDayStack : predefinedHourOfDayStacks) {
            Map<String, String> stackValues = hourOfDayStack.getShiftedHourOfDayValuesForBaseTime(baseDate);

            for (Entry<String, String> stackValue : stackValues.entrySet()) {
                log(String.format("Setting property [%s=%s]", stackValue.getKey(), stackValue.getValue()), Project.MSG_VERBOSE);

                getProject().setProperty(stackValue.getKey(), stackValue.getValue());
            }

            allStackValues.putAll(stackValues);

            checkForDifference(baseDate, hourOfDayStack, stackValues);
        }

        saveMapToFile(allStackValues, getMapFileComment(baseDate));
    }

    private TimeZoneHourOfDayStack[] getHourOfDayStacks() {
        return new TimeZoneHourOfDayStack[] { new TimeZoneHourOfDayStack("nzst", "NZ", "utc", "UTC"),
                new TimeZoneHourOfDayStack("nzst", "NZ", "aest", "Australia/Melbourne"),
                new TimeZoneHourOfDayStack("est", "America/New_York", "utc", "UTC"),
                new TimeZoneHourOfDayStack("est", "America/New_York", "aest", "Australia/Melbourne"),
                new TimeZoneHourOfDayStack("aest", "Australia/Melbourne", "utc", "UTC")};
    }

    private Integer getDayLiteralAsDayOfWeek(String targetDayOfWeek) {
        Integer retval = null;

        if (targetDayOfWeek != null && !targetDayOfWeek.isEmpty()) {
            String dayLiteral = targetDayOfWeek.toLowerCase().trim();

            if ("sunday".equals(dayLiteral)) {
                retval = DateTimeConstants.SUNDAY;
            } else if ("monday".equals(dayLiteral)) {
                retval = DateTimeConstants.MONDAY;
            } else if ("tuesday".equals(dayLiteral)) {
                retval = DateTimeConstants.TUESDAY;
            } else if ("wednesday".equals(dayLiteral)) {
                retval = DateTimeConstants.WEDNESDAY;
            } else if ("thursday".equals(dayLiteral)) {
                retval = DateTimeConstants.THURSDAY;
            } else if ("friday".equals(dayLiteral)) {
                retval = DateTimeConstants.FRIDAY;
            } else if ("saturday".equals(dayLiteral)) {
                retval = DateTimeConstants.SATURDAY;
            } else {
                throw new IllegalArgumentException(String.format("Day of week value [%s] is not recognised", targetDayOfWeek));
            }
        }

        return retval;
    }

    private DateTime parseDateStringToDateTime(String dateString) {
        DateTime retval = null;

        if (dateString != null && !dateString.isEmpty()) {
            DateTimeFormatter formatter = DateTimeFormat.forPattern(YYYY_MM_DD);

            retval = formatter.parseDateTime(dateString);
        }

        return retval;
    }

    private void checkForDifference(DateTime baseTime, TimeZoneHourOfDayStack hourOfDayStack, Map<String, String> referenceStack) {
        Map<String, String> previousWeeksStack = hourOfDayStack.getShiftedHourOfDayValuesForBaseTime(baseTime.minusWeeks(1));

        if (!previousWeeksStack.equals(referenceStack)) {
            log(String.format(
                    "Difference was noticed in zone [%s] compared to the previous week. Please review the following variables:",
                    hourOfDayStack.getFromTimezoneName()), Project.MSG_WARN);

            for (Entry<String, String> previousEntry : previousWeeksStack.entrySet()) {
                log(String.format("[%s=%s] changed to [%s=%s]", previousEntry.getKey(), previousEntry.getValue(),
                        previousEntry.getKey(), referenceStack.get(previousEntry.getKey())), Project.MSG_WARN);
            }
        }
    }

    private String getMapFileComment(DateTime baseDate) {
        DateTimeFormatter currentTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd hh:mm:ss");
        DateTimeFormatter baseDateFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");

        return String.format("# Static definition of differences in hour-of-day between timezones.\n"
                + "# This file is generated by `~/axle/environment/bin/generate-install-cron.sh'\n"
                + "# The preferred way is to execute the script, instead of editing this file!\n"
                + "# createdDate[%s], withBaseTime[%s]", currentTimeFormatter.print(System.currentTimeMillis()),
                baseDateFormatter.print(baseDate));
    }

    private void saveMapToFile(Map<String, String> map, String comment) {
        if (outputPathFile != null) {
            File tempFile = new File(outputPathFile.getAbsolutePath() + File.separator + TIMEZONE_PROPERTIES_FILENAME + "."
                    + UUID.randomUUID());

            BufferedWriter writer = null;

            try {
                try {
                    writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFile)));

                    writer.write(comment);
                    writer.newLine();

                    for (Entry<String, String> entry : map.entrySet()) {
                        writer.write(entry.getKey() + "=" + entry.getValue());
                        writer.newLine();
                    }
                } finally {
                    if (writer != null) {
                        writer.close();
                    }
                }
            } catch (IOException e) {
                throw new IllegalStateException(String.format("Could not save properties to [%s]", tempFile.getAbsoluteFile()), e);
            }

            File finalFile = new File(outputPathFile.getAbsolutePath() + File.separator + TIMEZONE_PROPERTIES_FILENAME);

            if (finalFile.exists() && backupExistingOutput) {
                File bakFile = new File(outputPathFile.getAbsolutePath() + File.separator + TIMEZONE_PROPERTIES_FILENAME + "."
                        + System.currentTimeMillis());

                if (!finalFile.renameTo(bakFile)) {
                    throw new IllegalStateException(String.format("Could not backup file [%s] to [%s]",
                            finalFile.getAbsoluteFile(), bakFile.getAbsoluteFile()));
                }

                log(String.format("Backed up timezone config as [%s]", bakFile.getAbsoluteFile()), Project.MSG_INFO);
            } else if (finalFile.exists() && !finalFile.delete()) {
                throw new IllegalStateException(String.format("Could not delete file [%s]", finalFile.getAbsoluteFile()));
            }

            if (!tempFile.renameTo(finalFile)) {
                throw new IllegalStateException(String.format("Could not rename temp file [%s] to [%s]",
                        tempFile.getAbsoluteFile(), finalFile.getAbsoluteFile()));
            }

            log(String.format("Saved timezone config to [%s]", finalFile.getAbsoluteFile()), Project.MSG_INFO);
        }
    }

}
