package com.anz.markets.efx.fox.firewall.state;

import java.util.function.Predicate;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

public class ParentOrderExecutionReportFilter implements Predicate<ExecutionReportDecoder> {
    private final ByteValueCache<String> stringsCache = new ByteValueCache<>(AsciiString::toString);

    @Override
    public boolean test(final ExecutionReportDecoder executionReport) {
        final ExecutionReportDecoder.Body body = executionReport.body();
        return Venue.FOX.name().equals(body.marketId().decodeAndCache(stringsCache));
    }
}
