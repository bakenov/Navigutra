package com.anz.axle.lg.adapter.cnx.quickfix;

import java.util.Date;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Message;
import quickfix.field.ClOrdID;
import quickfix.field.ClientID;
import quickfix.field.MsgType;
import quickfix.field.OrigClOrdID;
import quickfix.field.TransactTime;
import quickfix.fix42.OrderCancelRequest;

import com.anz.axle.lg.adapter.cnx.HealthCheckFailActionState;
import com.anz.axle.microtime.PrecisionClock;

public class CnxMassOrderCancelRequestHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(CnxMassOrderCancelRequestHandler.class);

    private static final String OPEN_ORDER = "OPEN_ORDER";
    private static final int OPEN_ORDERS_FIELD = 7559;
    private static final String OPEN_ORDERS_YES = "Y";
    private static final boolean INCLUDE_MILLISECONDS = false;

    private final Consumer<Message> fixMessageSender;
    private final HealthCheckFailActionState healthCheckFailActionState;
    private final PrecisionClock precisionClock;
    private final OrderCancelRequest orderCancel = new OrderCancelRequest();
    private final Date transactTime = new Date();

    public CnxMassOrderCancelRequestHandler(final Consumer<Message> fixMessageSender,
                                            final HealthCheckFailActionState healthCheckFailActionState,
                                            final PrecisionClock precisionClock) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.healthCheckFailActionState = Objects.requireNonNull(healthCheckFailActionState);
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    public void cancelAll() {
        healthCheckFailActionState.executeAction(this::cancel);
        cancel(null);
    }

    private void cancel(final String clientId) {
        orderCancel.clear();
        orderCancel.getHeader().setString(MsgType.FIELD, MsgType.ORDER_CANCEL_REQUEST);

        orderCancel.setString(ClOrdID.FIELD, OPEN_ORDER);
        orderCancel.setString(OrigClOrdID.FIELD, OPEN_ORDER);
        orderCancel.setString(OPEN_ORDERS_FIELD, OPEN_ORDERS_YES);
        if (clientId != null || "".equals(clientId)) orderCancel.setString(ClientID.FIELD, clientId);
        orderCancel.setUtcTimeStamp(TransactTime.FIELD, transactTime(), INCLUDE_MILLISECONDS);

        LOGGER.info("Request cancel for clientId: {}", clientId);
        fixMessageSender.accept(orderCancel);
    }

    private Date transactTime() {
        transactTime.setTime(precisionClock.millis());
        return transactTime;
    }
}
