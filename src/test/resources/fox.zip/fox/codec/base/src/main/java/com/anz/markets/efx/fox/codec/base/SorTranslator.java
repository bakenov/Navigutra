package com.anz.markets.efx.fox.codec.base;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorHandlerSupplier;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteEncoder;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;

/**
 * A sor decoder which translates the read messages into another format delegating to a target encoder.
 */
public final class SorTranslator<M> implements MessageDecoder<M> {

    private final MessageDecoder<M> messageDecoder;
    private final SorEncoderSupplier sorEncoderSupplier;

    private MessageEncoder.Trailer messageEncoder;

    private final SorHandlerSupplier translatingSorHandlerSupplier = SorHandlerSupplier.create(
            new TranslatingPricingRefreshCompleteHandler(),
            new TranslatingTimerExpiryHandler(),
            new TranslatingFirewallConfigHandler(),
            new TranslatingVenueConfigHandler(),
            new TranslatingUserConfigHandler(),
            new TranslatingInitialisationHandler(),
            new TranslatingInstrumentConfigHandler(),
            new TranslatingVenueInstrumentConfigHandler()
    );

    private SorTranslator(final SorDecoders.DecoderFactory<M> decoderFactory,
                          final SorEncoderSupplier sorEncoderSupplier,
                          final ForwardingLookup<M> forwardingLookup) {
        this.messageDecoder = decoderFactory.create(translatingSorHandlerSupplier, forwardingLookup);
        this.sorEncoderSupplier = Objects.requireNonNull(sorEncoderSupplier);
    }


    public static <M> SorTranslator<M> create(final SorDecoders.DecoderFactory<M> decoderFactory,
                                              final SorEncoderSupplier sorEncoderSupplier) {
        return new SorTranslator<>(decoderFactory, sorEncoderSupplier, ForwardingLookup.noop());
    }

    @Override
    public boolean decode(final M message) {
        return messageDecoder.decode(message);
    }

    private final class TranslatingPricingRefreshCompleteHandler implements PricingRefreshCompleteHandler {
        private PricingRefreshCompleteEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.pricingRefreshCompleteEncoder().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .instrumentId(body.instrumentId())
                    .forceSnapshot(body.forceSnapshot());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingTimerExpiryHandler implements TimerExpiryHandler {
        private TimerExpiryEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.timerExpiryEncoder().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .triggeredTime(body.triggeredTime())
                    .timerId(body.timerId())
                    .timerGroup(body.timerGroup());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingFirewallConfigHandler implements FirewallConfigHandler {
        private FirewallConfigEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(int source, long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.firewallConfigEncoder().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .firewallName().encodeFrom(body.firewallName())
                    .ruleId(body.ruleId())
                    .regionPattern().encodeFrom(body.regionPattern())
                    .orderTypePattern().encodeFrom(body.orderTypePattern())
                    .deskPattern().encodeFrom(body.deskPattern())
                    .portfolioPattern().encodeFrom(body.portfolioPattern())
                    .usernamePattern().encodeFrom(body.usernamePattern())
                    .venuePattern().encodeFrom(body.venuePattern())
                    .securityTypePattern().encodeFrom(body.securityTypePattern())
                    .tenorPattern().encodeFrom(body.tenorPattern())
                    .symbolPattern().encodeFrom(body.symbolPattern())
                    .period(body.period())
                    .periodUnit().encodeFrom(body.periodUnit())
                    .local(body.local())
                    .comment().encodeFrom(body.comment())
                    .lastEditUsername().encodeFrom(body.lastEditUsername())
                    .lastEditTime(body.lastEditTime())
                    .limitThreshold(body.limitThreshold());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingVenueConfigHandler implements VenueConfigHandler {
        private VenueConfigEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.venueConfig().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .venue(body.venue())
                    .compId().encodeFrom(body.compId())
                    .venueCategories().addAllFrom(body.venueCategories())
                    .enabled(body.enabled());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingUserConfigHandler implements UserConfigHandler {
        private UserConfigEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.userConfig().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .userName().encodeFrom(body.userName())
                    .userGroups().addAllFrom(body.userGroups())
                    .location().encodeFrom(body.location());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingInitialisationHandler implements InitialisationHandler {
        private InitialisationEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.initialisation().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .initStage(body.initStage());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingInstrumentConfigHandler implements InstrumentConfigHandler {
        private InstrumentConfigEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.instrumentConfig().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .instrumentId(body.instrumentId())
                    .pipSizeDivisor(body.pipSizeDivisor())
                    .enabled(body.enabled());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }

    private final class TranslatingVenueInstrumentConfigHandler implements VenueInstrumentConfigHandler {
        private VenueInstrumentConfigEncoder.Body bodyEncoder;

        @Override
        public void onMessageStart(final int source, final long sourceSeq) {
            bodyEncoder = sorEncoderSupplier.venueInstrumentConfig().messageStart(source, sourceSeq);
        }

        @Override
        public void onBody(final Body body) {
            messageEncoder = bodyEncoder
                    .venue(body.venue())
                    .instrumentId(body.instrumentId())
                    .clipSizeMultiple(body.clipSizeMultiple())
                    .maxAllowedParentOrderQty(body.maxAllowedParentOrderQty())
                    .minClipSize(body.minClipSize())
                    .maxClipSize(body.maxClipSize())
                    .priceIncrement(body.priceIncrement())
                    .sizeIncrement(body.sizeIncrement())
                    .staleDataTimeout(body.staleDataTimeout())
                    .priority(body.priority())
                    .proportion(body.proportion())
                    .enabled(body.enabled());
        }

        @Override
        public void onMessageComplete() {
            messageEncoder.messageComplete();
            messageEncoder = null;
        }
    }
}
