package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

public class IsMarketPricePoint extends BaseMatcher<MarketDataSnapshot> {
    private final int level;
    private final double expectedLevelBidQty;
    private final double expectedLevelOfferQty;
    private final double expectedBidPx;
    private final double expectedOffersPx;
    private MarketDataSnapshot actualMarketDataSnapshot;
    private MarketDataNewOrder actualBid;
    private MarketDataNewOrder actualOffers;

    public IsMarketPricePoint(final int level,
                              final double expectedLevelBidQty,
                              final double expectedBidPx,
                              final double expectedLevelOfferQty,
                              final double expectedOffersPx) {
        this.level = level;
        this.expectedLevelBidQty = expectedLevelBidQty;
        this.expectedBidPx = expectedBidPx;
        this.expectedLevelOfferQty = expectedLevelOfferQty;
        this.expectedOffersPx = expectedOffersPx;
    }

    @Override
    public boolean matches(final Object o) {
        actualMarketDataSnapshot = (MarketDataSnapshot) o;
        if (actualMarketDataSnapshot.getBidEventList().size() <= level) {
            throw new IllegalArgumentException("Client price does not have bid at " + expectedLevelBidQty);
        }
        actualBid = actualMarketDataSnapshot.getBidEventList().get(level);

        if (actualMarketDataSnapshot.getOfferEventList().size() <= level) {
            throw new IllegalArgumentException("Client price does not have offers at " + expectedLevelOfferQty);
        }
        actualOffers = actualMarketDataSnapshot.getOfferEventList().get(level);
        if (!new IsRoundedTo(expectedBidPx).matches(actualBid.getPrice()) || actualBid.getQuantity() != expectedLevelBidQty) {
            return false;
        } else {
            return new IsRoundedTo(expectedOffersPx).matches(actualOffers.getPrice()) || actualOffers.getQuantity() == expectedLevelOfferQty;
        }
    }

    @Override
    public void describeTo(final Description description) {
        description.appendText("level: ").appendValue(level).appendText(", qty: ").appendValue(expectedLevelBidQty).appendText(", bid: ").appendValue(expectedBidPx).appendText(", qty: ").appendValue(expectedLevelOfferQty).appendText(", offer: ").appendValue(expectedOffersPx);
    }

    @Override
    public void describeMismatch(final Object item,
                                 final Description description) {
        description.appendText("level: ").appendValue(level).appendText(", qty: ").appendValue(expectedLevelBidQty).appendText(", bid: ").appendValue(actualBid.getPrice()).appendText(", qty: ").appendValue(expectedLevelOfferQty).appendText(", offer: ").appendValue(actualOffers.getPrice());
    }

}
