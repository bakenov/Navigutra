package com.anz.markets.prophet.atest.disco;

import com.anz.markets.disco.config.DiscoPFPConfig;
import com.anz.markets.disco.config.DiscoPostEventSpreadConfig;
import com.anz.markets.disco.data.Signal;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.modules.DiscoveryModule;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


public class DiscoPostEventSpreadTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault configuration1() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base();

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.GBPUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoPFPConfig.FEATURE_NAME, priceFormationPipelineConfig);

        priceFormationPipelineConfig.clear();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPostEventSpreadConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPostEventSpreadConfig.PARAM_TIGHTEN_TAU_SECONDS, Double.NaN,
                DiscoPostEventSpreadConfig.PARAM_WIDEN_TAU_SECONDS, Double.NaN,
                DiscoPostEventSpreadConfig.PARAM_MIN_TIME_SECONDS, Double.NaN,
                DiscoPostEventSpreadConfig.PARAM_MAX_TIME_SECONDS, Double.NaN,
                DiscoPostEventSpreadConfig.PARAM_TURN_OFF_SPREAD, Double.NaN
        ));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPostEventSpreadConfig.FEATURE_NAME, Market.ANY, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPostEventSpreadConfig.PARAM_TIGHTEN_TAU_SECONDS, 0.1,
                DiscoPostEventSpreadConfig.PARAM_WIDEN_TAU_SECONDS, 1.0,
                DiscoPostEventSpreadConfig.PARAM_MIN_TIME_SECONDS, Double.NaN,
                DiscoPostEventSpreadConfig.PARAM_MAX_TIME_SECONDS, Double.NaN,
                DiscoPostEventSpreadConfig.PARAM_TURN_OFF_SPREAD, Double.NaN
        ));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoPostEventSpreadConfig.FEATURE_NAME, priceFormationPipelineConfig);

        return configuration;
    }

    @Test
    public void basico() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75070, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(3));

            final Signal signalPES = signals.getSignal(2);
            assertThat(signalPES.getSignalType(), is(SignalType.PES));
            assertThat(signalPES.getValue(), isNear(4.0));
            assertThat(signalPES.getConditionCode(), is(Symbol.EMPTY));
        }

        // No change, no output.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75070, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(800);
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(3));

            final Signal signal = signals.getSignal(2);
            assertThat(signal.getSignalType(), is(SignalType.PES));
            final double w = Math.exp(-8);
            assertThat(signal.getValue(), Matchers.closeTo(4.0 * w + 3.0 * (1 - w),1E-9));
            assertThat(signal.getConditionCode(), is(Symbol.EMPTY));
        }

    }

}
