package com.anz.markets.efx.fox.codec.api;

import java.util.function.Consumer;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;

public interface SorEncoders<M> {
    MessageEncoder.Factory<M, PricingRefreshCompleteEncoder> pricingRefreshComplete();
    MessageEncoder.Factory<M, TimerExpiryEncoder> timerExpiry();
    MessageEncoder.Factory<M, FirewallConfigEncoder> firewallConfig();
    MessageEncoder.Factory<M, VenueConfigEncoder> venueConfig();
    MessageEncoder.Factory<M, UserConfigEncoder> userConfig();
    MessageEncoder.Factory<M, InitialisationEncoder> initialisation();
    MessageEncoder.Factory<M, InstrumentConfigEncoder> instrumentConfig();
    MessageEncoder.Factory<M, VenueInstrumentConfigEncoder> venueInstrumentConfig();

    default SorEncoderSupplier toSorEncoderSupplier(final Consumer<? super M> messageConsumer) {
        return SorEncoderSupplier.create(this, messageConsumer);
    }
}
