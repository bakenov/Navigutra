package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.config.StartAtSeeker;
import com.anz.markets.prophet.domain.chronicle.Header;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.impl.single.BinarySearch;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.wire.DocumentContext;
import net.openhft.chronicle.wire.Wire;
import net.openhft.chronicle.wire.WireType;

import java.text.ParseException;
import java.util.Comparator;
import java.util.function.ToLongFunction;

public class ChronicleQueueStartAtSeeker implements StartAtSeeker {

    private final ExcerptTailer tailer;

    // NOTE: Depending on the StartAt type, the config start position could be a queue INDEX, or any attribute of Header
    private final long configStartPosition;

    // For unmarshalling of headers while searching
    private final Header header = new Header();

    ChronicleQueueStartAtSeeker(final ExcerptTailer excerptTailer, final long startConfig) {
        this.tailer = excerptTailer;
        this.configStartPosition = startConfig;
    }

    @Override
    public void firstIndex() {
        tailer.toStart();
    }

    @Override
    public void lastIndex() {
        tailer.toEnd();
    }

    @Override
    public void configIndex() {
        verifyIndex(configStartPosition);
    }

    @Override
    public void findIndex(final ToLongFunction<Header> headerToLongFunction, final boolean exactMatch) {
        if (configStartPosition <= 0) {
            verifyIndex(configStartPosition);
            return;
        }

        firstIndex();
        final long firstIndex = tailer.index();
        long matchIndex = -1L;
        try {
            matchIndex = findMatch(headerToLongFunction);
            if (matchIndex < 0L) {
                if (exactMatch) {
                    throw new SeekException("Could not seek to exact match", configStartPosition);
                } else {
                    // handle nearest match (but floor with firstIndex)
                    matchIndex = Math.max(-(matchIndex + 2L), firstIndex);
                }
            } else {
                if (headerToLongFunction.applyAsLong(header) != configStartPosition) {
                    throw new SeekException("Lying about exact match", configStartPosition);
                }
                // exact match. As there can be >1 rows with the same eventId, wind back to the first
                while (headerToLongFunction.applyAsLong(header) == configStartPosition && tailer.moveToIndex(--matchIndex)) {
                    readHeader(header);
                }
                ++matchIndex;
            }
            verifyIndex(matchIndex);
        } catch (ArrayIndexOutOfBoundsException a) {
            throw new SeekException(a.getMessage() + " for index " + matchIndex, configStartPosition);
        }
    }

    private long findMatch(final ToLongFunction<Header> headerToLongFunction) {
        final Wire dummyWireKey = WireType.BINARY.apply(Bytes.elasticHeapByteBuffer(0));
        final Comparator<Wire> comparator = (queueWire, keyWire) -> {
            ChronicleObjectReader.readHeader(ChronicleQueueWrappers.wrapBytes(queueWire.bytes()), header);
            final long qValue = headerToLongFunction.applyAsLong(header);
            int cmp = Long.compare(qValue, configStartPosition);
            return cmp;
        };
        try {
            return BinarySearch.search((SingleChronicleQueue) tailer.queue(), dummyWireKey, comparator);
        } catch (ParseException e) {
            throw Jvm.rethrow(e);
        }
    }

    private Header readHeader(final Header header) {
        try (final DocumentContext dc = tailer.readingDocument()) {
            ChronicleObjectReader.readHeader(ChronicleQueueWrappers.wrapReader(dc), header);
        }
        return header;
    }

    private void verifyIndex(final long index) {
        if (index <= 0) { // No need to verify
            return;
        }

        final boolean ok = tailer.moveToIndex(index);
        if (!ok) {
            throw new SeekException("Cannot seek by index", index);
        }
    }
}