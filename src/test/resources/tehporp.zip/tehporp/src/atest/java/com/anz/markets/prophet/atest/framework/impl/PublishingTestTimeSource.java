package com.anz.markets.prophet.atest.framework.impl;

import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * TimeSource that can be incremented by tests and is smart enough to send down a OneSecond
 * chime if a we have incremented the time sufficiently.
 */
public class PublishingTestTimeSource extends TestTimeSource {
    private final long startTimeNS;
    private Consumer<OneSecond> consumerOneSecond;
    private Consumer<HourChime> consumerHourChime;

    public PublishingTestTimeSource(final long nowInMillis) {
        super(nowInMillis);
        GcFriendlyAssert.isTrue(nowInMillis > 0);
        this.startTimeNS = TimeUnit.MILLISECONDS.toNanos(nowInMillis);
    }

    @Override
    public void setNanos(final long nowNanos) {
        final long beforeNS = nowNanos();
        if (beforeNS > 0) {
            long secondsBefore = TimeUnit.NANOSECONDS.toSeconds(beforeNS - startTimeNS);
            long secondsAfter = TimeUnit.NANOSECONDS.toSeconds(nowNanos - startTimeNS);
            for (long i = secondsBefore; i < secondsAfter; i++) {
                super.setNanos(startTimeNS + TimeUnit.SECONDS.toNanos(i + 1));
                this.consumerOneSecond.accept(OneSecond.INSTANCE);

                if (i > 0 && offsetNowInHour() == 0) {
                    this.consumerHourChime.accept(HourChime.INSTANCE);
                }
            }
        }
        super.setNanos(nowNanos);
    }

    public void setConsumerOneSecond(final Consumer<OneSecond> consumerOneSecond) {
        this.consumerOneSecond = consumerOneSecond;
    }

    public void setConsumerHourChime(final Consumer<HourChime> consumerHourChime) {
        this.consumerHourChime = consumerHourChime;
    }

    private long offsetNowInHour() {
        return TimeUnit.NANOSECONDS.toSeconds(nowNanos() - startTimeNS) % TimeUnit.HOURS.toSeconds(1);
    }
}
