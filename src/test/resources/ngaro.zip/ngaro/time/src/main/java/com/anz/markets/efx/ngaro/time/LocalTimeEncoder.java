package com.anz.markets.efx.ngaro.time;

import java.time.LocalTime;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteWriter;

/**
 * Encoder for local times with time formats as defined by {@link LocalTimeFormat}.
 * <br/>
 * All methods are zero garbage.
 * <p/>
 * This class is thread safe.
 *
 * @see LocalTimeDecoder
 */
public final class LocalTimeEncoder {

    public static final char DEFAULT_DELIMITER = ':';
    public static final char DEFAULT_FRACTION_SYMBOL = '.';
    private static final byte NULL = 0;

    private final LocalTimeFormat timeFormat;
    private final char delimiter;
    private final char fractionSymbol;

    LocalTimeEncoder(final LocalTimeFormat timeFormat) {
        this(timeFormat, DEFAULT_DELIMITER, DEFAULT_FRACTION_SYMBOL);
    }
    private LocalTimeEncoder(final LocalTimeFormat timeFormat, final char delimiter, final char fractionSymbol) {
        this.timeFormat = Objects.requireNonNull(timeFormat);
        this.delimiter = delimiter;
        this.fractionSymbol = fractionSymbol;
        if (delimiter > 127) {
            throw new IllegalArgumentException("Invalid delimiter char: " + delimiter);
        }
        if (fractionSymbol > 127) {
            throw new IllegalArgumentException("Invalid fraction symbol: " + fractionSymbol);
        }
    }

    public static LocalTimeEncoder valueOf(final LocalTimeFormat format) {
        return format.getDefaultEncoder();
    }

    public static LocalTimeEncoder valueOf(final LocalTimeFormat format, final char delimiter, final char fractionSymbol) {
        if (delimiter == DEFAULT_DELIMITER & fractionSymbol == DEFAULT_FRACTION_SYMBOL) {
            return valueOf(format);
        }
        return new LocalTimeEncoder(format, delimiter, fractionSymbol);
    }

    public LocalTimeFormat getTimeFormat() {
        return timeFormat;
    }

    public char getDelimiter() {
        return delimiter;
    }

    public char getFractionSymbol() {
        return fractionSymbol;
    }

    public <T> void encodeEpochSeconds(final T target, final ByteWriter<? super T> writer, final long epochSeconds) {
        encodeEpochSeconds(target, writer, 0, epochSeconds);
    }
    public <T> void encodeEpochSeconds(final T target, final ByteWriter<? super T> writer, final int offset, final long epochSeconds) {
        encodeEpochSecondsWithoutFractional(target, writer, offset, epochSeconds);
        encodeNano(target, writer, offset, 0);
    }

    private <T> void encodeEpochSecondsWithoutFractional(final T target, final ByteWriter<? super T> writer, final int offset, final long epochSeconds) {
        long value = epochSeconds;
        final int ss = timeFormat.getOffsetSecond() >= 0 ? (int)Math.floorMod(value, Epoch.SECONDS_PER_MINUTE) : 0;
        value = Math.floorDiv(value, Epoch.SECONDS_PER_MINUTE);
        final int mm= (int)Math.floorMod(value, Epoch.MINUTES_PER_HOUR);
        value = Math.floorDiv(value, Epoch.MINUTES_PER_HOUR);
        final int hh = (int)Math.floorMod(value, Epoch.HOURS_PER_DAY);
        encodeWithoutFractionalSeconds(target, writer, offset, hh, mm, ss);
    }

    public <T> void encodeEpochMillis(final T target, final ByteWriter<? super T> writer, final long epochMillis) {
        encodeEpochMillis(target, writer, 0, epochMillis);
    }
    public <T> void encodeEpochMillis(final T target, final ByteWriter<? super T> writer, final int offset, final long epochMillis) {
        if (timeFormat.getOffsetFraction() >= 0) {
            encodeMilli(target, writer, offset, (int)Math.floorMod(epochMillis, Epoch.MILLIS_PER_SECOND));
        }
        encodeEpochSecondsWithoutFractional(target, writer, offset, Math.floorDiv(epochMillis, Epoch.MILLIS_PER_SECOND));
    }

    public <T> void encodeEpochNanos(final T target, final ByteWriter<? super T> writer, final long epochNanos) {
        encodeEpochNanos(target, writer, 0, epochNanos);
    }
    public <T> void encodeEpochNanos(final T target, final ByteWriter<? super T> writer, final int offset, final long epochNanos) {
        if (timeFormat.getOffsetFraction() >= 0) {
            encodeNano(target, writer, offset, (int)Math.floorMod(epochNanos, Epoch.NANOS_PER_SECOND));
        }
        encodeEpochSecondsWithoutFractional(target, writer, offset, Math.floorDiv(epochNanos, Epoch.NANOS_PER_SECOND));
    }

    public <T> void encode(final T target, final ByteWriter<? super T> writer, final LocalTime localTime) {
        encode(target, writer, 0, localTime);
    }
    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int offset, final LocalTime localTime) {
        if (localTime == null) {
            encodeNull(target, writer, offset);
        } else {
            encode(target, writer, offset, localTime.getHour(), localTime.getMinute(), localTime.getSecond(), localTime.getNano());
        }
    }

    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int hour, final int minute, final int second) {
        encode(target, writer, hour, minute, second, 0);
    }
    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int hour, final int minute, final int second, final int nano) {
        encode(target, writer, 0, hour, minute, second, nano);
    }
    public <T> void encode(final T target, final ByteWriter<? super T> writer, final int offset, final int hour, final int minute, final int second, final int nano) {
        encodeWithoutFractionalSeconds(target, writer, offset, hour, minute, second);
        encodeNano(target, writer, offset, nano);
    }

    private <T> void encodeWithoutFractionalSeconds(final T target, final ByteWriter<? super T> writer, final int offset, final int hour, final int minute, final int second) {
        encodeHour(target, writer, offset, hour);
        encodeMinute(target, writer, offset, minute);
        encodeSecond(target, writer, offset, second);
        encodeDelimitersAndFractionSymbol(target, writer, offset);
    }

    public <T> void encodeNull(final T target, final ByteWriter<? super T> writer) {
        encodeNull(target, writer, 0);
    }
    public <T> void encodeNull(final T target, final ByteWriter<? super T> writer, final int offset) {
        final int offsetHour = timeFormat.getOffsetHour();
        final int offsetMinute = timeFormat.getOffsetMinute();
        final int offsetSecond = timeFormat.getOffsetSecond();
        final int offsetFraction = timeFormat.getOffsetFraction();
        writer.writeByte(target, offset + offsetHour + 1, NULL);
        writer.writeByte(target, offset + offsetHour + 0, NULL);
        writer.writeByte(target, offset + offsetMinute + 1, NULL);
        writer.writeByte(target, offset + offsetMinute + 0, NULL);
        if (offsetSecond >= 0) {
            writer.writeByte(target, offset + offsetSecond + 1, NULL);
            writer.writeByte(target, offset + offsetSecond + 0, NULL);
        }
        if (offsetFraction >= 0) {
            for (int i = timeFormat.getFractionLength() - 1; i >= 0; i--) {
                writer.writeByte(target, offset + offsetFraction + i, NULL);
            }
        }
        encodeDelimitersAndFractionSymbol(target, writer, offset);
    }

    public <T> void encodeHour(final T target, final ByteWriter<? super T> writer, final int hour) {
        encodeHour(target, writer, 0, hour);
    }
    public <T> void encodeHour(final T target, final ByteWriter<? super T> writer, final int offset, final int hour) {
        if (hour < 0 | hour > 23) {
            throw new IllegalArgumentException("Hour is out of the valid range [0,23]: " + hour);
        }
        final int offsetHour = offset + timeFormat.getOffsetHour();
        int val = hour;
        writer.writeByte(target, offsetHour + 1, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetHour + 0, ascii(val));
    }

    public <T> void encodeMinute(final T target, final ByteWriter<? super T> writer, final int minute) {
        encodeMinute(target, writer, 0, minute);
    }
    public <T> void encodeMinute(final T target, final ByteWriter<? super T> writer, final int offset, final int minute) {
        if (minute < 0 | minute > 59) {
            throw new IllegalArgumentException("Minute is out of the valid range [0,59]: " + minute);
        }
        final int offsetMinute = offset + timeFormat.getOffsetMinute();
        int val = minute;
        writer.writeByte(target, offsetMinute + 1, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetMinute + 0, ascii(val));
    }

    public <T> void encodeSecond(final T target, final ByteWriter<? super T> writer, final int second) {
        encodeSecond(target, writer, 0, second);
    }
    public <T> void encodeSecond(final T target, final ByteWriter<? super T> writer, final int offset, final int second) {
        if (second < 0 | second > 59) {
            throw new IllegalArgumentException("Second is out of the valid range [0,59]: " + second);
        }
        final int offsetSecond = timeFormat.getOffsetSecond();
        if (offsetSecond >= 0) {
            int val = second;
            writer.writeByte(target, offset + offsetSecond + 1, ascii(val % 10));
            val /= 10;
            writer.writeByte(target, offset + offsetSecond + 0, ascii(val));
        }
    }

    public <T> void encodeMilli(final T target, final ByteWriter<? super T> writer, final int milli) {
        encodeMilli(target, writer, 0, milli);
    }
    public <T> void encodeMilli(final T target, final ByteWriter<? super T> writer, final int offset, final int milli) {
        if (milli < 0 | milli > 999) {
            throw new IllegalArgumentException("Milli is out of the valid range [0,999]: " + milli);
        }
        encodeSubSecond(target, writer, offset, milli, 3);
    }

    public <T> void encodeMicro(final T target, final ByteWriter<? super T> writer, final int micro) {
        encodeMicro(target, writer, 0, micro);
    }
    public <T> void encodeMicro(final T target, final ByteWriter<? super T> writer, final int offset, final int micro) {
        if (micro < 0 | micro > 999999) {
            throw new IllegalArgumentException("Micro is out of the valid range [0,999999]: " + micro);
        }
        encodeSubSecond(target, writer, offset, micro, 6);
    }

    public <T> void encodeNano(final T target, final ByteWriter<? super T> writer, final int nano) {
        encodeNano(target, writer, 0, nano);
    }
    public <T> void encodeNano(final T target, final ByteWriter<? super T> writer, final int offset, final int nano) {
        if (nano < 0 | nano > 999999999) {
            throw new IllegalArgumentException("Nano is out of the valid range [0,999999999]: " + nano);
        }
        encodeSubSecond(target, writer, offset, nano, 9);
    }

    private <T> void encodeSubSecond(final T target, final ByteWriter<? super T> writer, final int offset, final int timeValue, final int digitsTimeValue) {
        final int offsetFraction = timeFormat.getOffsetFraction();
        if (offsetFraction >= 0) {
            final int fractionLength = timeFormat.getFractionLength();

            //divide timeValue as long as it exceeds our fraction precision
            long value = timeValue;
            for (int pos = digitsTimeValue; pos > fractionLength & value != 0 ; pos--) {
                value /= 10;
            }
            //write '0' digits of fraction where it exceed precision of our timeValue
            int pos = fractionLength - 1;
            while (pos >= digitsTimeValue) {
                writer.writeByte(target, offset + offsetFraction + pos, (byte)'0');
                pos--;
            }
            //write digits of time Value now as long as timeValue is not zero
            while (pos >= 0 & value != 0) {
                writer.writeByte(target, offset + offsetFraction + pos, ascii(value % 10));
                value /= 10;
                pos--;
            }
            //if anything left then timeValue is zero hence remaining digits are zero
            while (pos >= 0) {
                writer.writeByte(target, offset + offsetFraction + pos, (byte)'0');
                pos--;
            }
        }
    }

    public <T> void encodeDelimitersAndFractionSymbol(final T target, final ByteWriter<? super T> writer) {
        encodeDelimitersAndFractionSymbol(target, writer, 0);
    }
    public <T> void encodeDelimitersAndFractionSymbol(final T target, final ByteWriter<? super T> writer, final int offset) {
        final int posDelim1 = timeFormat.getPositionDelimiter1();
        if (posDelim1 >= 0) {
            writer.writeByte(target, offset + posDelim1, (byte)delimiter);
        }
        final int posDelim2 = timeFormat.getPositionDelimiter2();
        if (posDelim2 >= 0) {
            writer.writeByte(target, offset + posDelim2, (byte)delimiter);
        }
        final int posFracSymbol = timeFormat.getPositionFractionSymbol();
        if (posFracSymbol >= 0) {
            writer.writeByte(target, offset + posFracSymbol, (byte)fractionSymbol);
        }
    }

    private static final byte ascii(final long digit) {
        return (byte)('0' + digit);
    }}
