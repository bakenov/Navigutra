package com.anz.markets.efx.fox.codec.sbe;

import com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.sbe.Lazy;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringDecoders;

public class FirewallConfigSbeDecoder  implements com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder  {
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final FirewallConfigDecoder firewallConfigDecoder = new FirewallConfigDecoder();

    private final SbeHeader header = new SbeHeader(headerDecoder);
    private final SbeBody body = new SbeBody();
    private int bodyLimit;
    private EncodingOrder.FirewallConfig encodingOrder = EncodingOrder.FirewallConfig.INITIAL;

    public boolean wrap(final SbeMessage sbeMessage) {
        headerDecoder.wrap(sbeMessage.buffer(), 0);
        if (headerDecoder.templateId() != com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.TEMPLATE_ID) {
            clear();
            return false;
        }
        firewallConfigDecoder.wrap(sbeMessage.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        this.bodyLimit = firewallConfigDecoder.limit();
        encodingOrder = EncodingOrder.FirewallConfig.INITIAL;
        return true;
    }

    public void clear() {
        headerDecoder.wrap(null, 0);
        firewallConfigDecoder.wrap(null, 0, 0, 0);
    }

    @Override
    public Header header() {
        return header;
    }

    @Override
    public Body body() {
        encodingOrder = EncodingOrder.FirewallConfig.BODY;
        firewallConfigDecoder.limit(bodyLimit);
        return body;
    }


    class SbeBody implements Body {
        private final StringDecoder firewallName = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::firewallName), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.firewallNameLength());
        private final StringDecoder regionPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::regionPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.regionPatternLength());
        private final StringDecoder orderTypePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::orderTypePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.orderTypePatternLength());
        private final StringDecoder deskPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::deskPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.deskPatternLength());
        private final StringDecoder portfolioPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::portfolioPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.portfolioPatternLength());
        private final StringDecoder usernamePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::usernamePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.usernamePatternLength());
        private final StringDecoder venuePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::venuePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.venuePatternLength());
        private final StringDecoder securityTypePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::securityTypePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.securityTypePatternLength());
        private final StringDecoder tenorPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::tenorPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.tenorPatternLength());
        private final StringDecoder symbolPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::symbolPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.symbolPatternLength());
        private final StringDecoder periodUnit = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::periodUnit), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.periodUnitLength());
        private final StringDecoder comment = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::comment), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.commentLength());
        private final StringDecoder lastEditUsername = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::lastEditUsername), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.lastEditUsernameLength());

        @Override
        public StringDecoder firewallName() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallName;
        }

        @Override
        public long ruleId() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.ruleId();
        }

        @Override
        public StringDecoder regionPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return regionPattern;
        }

        @Override
        public StringDecoder orderTypePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return orderTypePattern;
        }

        @Override
        public StringDecoder deskPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return deskPattern;
        }

        @Override
        public StringDecoder portfolioPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return portfolioPattern;
        }

        @Override
        public StringDecoder usernamePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return usernamePattern;
        }

        @Override
        public StringDecoder venuePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return venuePattern;
        }

        @Override
        public StringDecoder securityTypePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return securityTypePattern;
        }

        @Override
        public StringDecoder tenorPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return tenorPattern;
        }

        @Override
        public StringDecoder symbolPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return symbolPattern;
        }

        @Override
        public long period() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.period();
        }

        @Override
        public StringDecoder periodUnit() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return periodUnit;
        }

        @Override
        public boolean local() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.local() == YesNo.YES;
        }

        @Override
        public StringDecoder comment() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return comment;
        }

        @Override
        public StringDecoder lastEditUsername() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return lastEditUsername;
        }

        @Override
        public long lastEditTime() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.lastEditTime();
        }

        @Override
        public double limitThreshold() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.limitThreshold();
        }
    }

    @Override
    public void appendTo(final StringBuilder stringBuilder) {
        firewallConfigDecoder.appendTo(stringBuilder);
    }
}
