package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.impl.MidRateImpl;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.positionrisk.PositionManager.PositionsUpdatePhase;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.syscontrol.TableNotifierDefault;
import org.junit.Test;

import java.util.function.Consumer;

import static junit.framework.TestCase.assertEquals;

public class PositionManagerBWTest {
    private static final int REPS = 1_000_000, THRESHOLD = 1000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private final Consumer<Trade> consumerTrade;
    private final Consumer<MidRate> consumerMidRate;
    private final TradeImpl trade = (TradeImpl) PositionManagerTest.TRADE_AUDUSD_BUY;
    private final MidRateImpl midRateUsdBase = (MidRateImpl) PositionManagerTest.MIDRATE_AUDUSD;
    private final MidRateImpl midRate = (MidRateImpl) PositionManagerTest.MIDRATE_EURGBP;
    private final NoOpConsumer<Positions> positionNotionalNfy = new NoOpConsumer<>();
    private final NoOpConsumer<Positions> positionBaseNfy = new NoOpConsumer<>();
    private int counter = 1;

    public PositionManagerBWTest() {
        final Consumer<Adjustment> adjustmentSink = NoConsumer.instance();
        final TableNotifierDefault<PositionsUpdatePhase, Portfolio, Positions> positionsNotifierTable = new TableNotifierDefault<PositionsUpdatePhase, Portfolio, Positions>(PositionsUpdatePhase.class, Portfolio.class)
                .register(PositionsUpdatePhase.NOTIONAL, Portfolio.CLIENTS_NET, positionNotionalNfy)
                .register(PositionsUpdatePhase.BASE, Portfolio.CLIENTS_NET, positionBaseNfy);

        final PositionManager positionManager = new PositionManager(positionsNotifierTable, adjustmentSink);

        consumerTrade = positionManager.consumerOfTrade();
        consumerMidRate = positionManager.consumerOfMidRate();
    }

    @Test
    public void testAcceptTrade() {

        helper.testAllocationNotExceeded(
                this::acceptTrade,
                REPS, REPS,
                THRESHOLD
        );
    }

    @Test
    public void testAcceptMidRateUSDBase() {
        helper.testAllocationNotExceeded(
                this::acceptMidRateUSDBase,
                REPS, REPS,
                THRESHOLD
        );
    }

    @Test
    public void testAcceptMidRate() {
        helper.testAllocationNotExceeded(
                this::acceptMidRate,
                REPS, REPS,
                THRESHOLD
        );
    }

    private void acceptTrade() {
        consumerMidRate.accept(midRateUsdBase);
        final int start = positionNotionalNfy.size();
        trade.setInceptionTimeNanos(counter);
        trade.setFilledPrice(counter);
        trade.setFilledQuantity(counter);
        consumerTrade.accept(trade);
        final int nfys = positionNotionalNfy.size() - start;
        assertEquals(1, nfys);
        ++counter;
    }

    private void acceptMidRateUSDBase() {
        consumerMidRate.accept(midRateUsdBase);
        consumerTrade.accept(trade);
        final int start = positionBaseNfy.size();
        midRateUsdBase.setRate(getIncrementedRate());
        consumerMidRate.accept(midRateUsdBase);
        final int nfys = positionBaseNfy.size() - start;
        assertEquals(1, nfys);
        ++counter;
    }

    private void acceptMidRate() {
        consumerMidRate.accept(midRate);
        consumerMidRate.accept(midRateUsdBase);
        consumerTrade.accept(trade);
        final int start = positionBaseNfy.size();
        midRateUsdBase.setRate(getIncrementedRate());
        consumerMidRate.accept(midRate);
        final int nfys = positionBaseNfy.size() - start;
        assertEquals(0, nfys);
        ++counter;
    }

    private double getIncrementedRate() {
        // so that rate is greater than 1%
        return (midRateUsdBase.getMidRate() * 1.02) % 100;
    }
}
