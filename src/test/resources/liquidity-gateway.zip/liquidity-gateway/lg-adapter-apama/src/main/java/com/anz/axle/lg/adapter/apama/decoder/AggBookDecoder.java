package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.AggBook;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;


/**
 * Decodes Apama events as defined by {@link AggBook}
 */
public final class AggBookDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(AggBookDecoder.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final SourceSequencer sourceSequencer;


    public AggBookDecoder(final VenueRequestKeyLookup requestKeyLookup,
                          final PricingEncoderLookup pricingEncoderLookup,
                          final PrecisionClock precisionClock,
                          final String senderCompId,
                          final String compId,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void decode(final Event aggBook) {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("Apama event received: {}", aggBook);

        final String senderCompId = aggBook.getField(AggBook.FIELD_SENDER_COMP_ID);
        final long messageId = aggBook.getField(AggBook.FIELD_MESSAGE_ID);
        final long sendingTimeNanos = toNanos(aggBook.getField(AggBook.FIELD_SENDING_TIME));
        final String symbol = SymbolNormaliser.toSymbol6(aggBook.getField(AggBook.FIELD_SYMBOL));
        final List<String> markets = aggBook.getField(AggBook.FIELD_MARKETS);
        final long flags = aggBook.getField(AggBook.FIELD_FLAGS);
        final List<Event> bids = aggBook.getField(AggBook.FIELD_BIDS);
        final List<Event> asks = aggBook.getField(AggBook.FIELD_ASKS);

        final RequestKey requestKey = requestKeyLookup.lookup(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_next = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .possResend(false)
                .sendingTime(sendingTimeNanos)
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .marketId(requestKey.market())
                .tradeDate().encodeNull()
                .settlDate().encodeNull()
                .referenceSpotDate().encodeNull()
                .entriesStart(bids.size() + asks.size())
                ;

        //FIXME enc.marketDataFlag() from flags
        encodeEntries(mdEntries_next, markets, EntryType.BID, bids);
        encodeEntries(mdEntries_next, markets, EntryType.OFFER, asks);
        mdEntries_next.entriesComplete()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .messageComplete();
    }

    private void encodeEntries(final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_next,
                               final List<String> markets,
                               final EntryType side,
                               final List<Event> entries) {
        for (int i = 0; i < entries.size(); i++) {
            final Event entry = entries.get(i);
             final SnapshotFullRefreshEncoder.MdEntries.Body mdEntries_quoteEntryId = mdEntries_next.next()
                    .transactTime(toNanos(entry.getField(AggBook.FIELD_TRANSACT_TIME)))
                    .mdMkt(Venue.valueOf(market(markets, entry.getField(AggBook.FIELD_MARKET_INDEX))))
                    .mdEntryType(side)
                    .mdEntryPx(entry.getField(AggBook.FIELD_PRICE))
                    .mdEntrySize(entry.getField(AggBook.FIELD_QUANTITY))
                    .minQty(0)
                    .mdEntryId(0);
            final String quoteId = emptyToNull(entry.getField(AggBook.FIELD_QUOTE_ID));
            if (quoteId != null) {
                mdEntries_quoteEntryId.quoteEntryId(Integer.parseInt(quoteId));
            } else {
                mdEntries_quoteEntryId.quoteEntryId(0);
            }
        }
    }

    private static long toNanos(final double apamaMicroTime) {
        return 1000 * (long)(1000000 * apamaMicroTime);
    }

    private static String market(final List<String> markets, final long index) {
        return index >= 0 && index < markets.size() ? markets.get((int) index) : "XXX";
    }

    private static String emptyToNull(final String s) {
        return s == null || s.isEmpty() ? null : s;
    }
}
