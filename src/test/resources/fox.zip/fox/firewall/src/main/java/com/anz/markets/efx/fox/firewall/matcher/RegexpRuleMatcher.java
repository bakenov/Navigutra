package com.anz.markets.efx.fox.firewall.matcher;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;

public class RegexpRuleMatcher implements RuleMatcher {
    private static final String DEFAULT_MATCH_ALL_WILDCARD = ".*";

    private final Matcher regionMatcher;
    private final Matcher deskMatcher;
    private final Matcher orderTypeMatcher;
    private final Matcher portfolioMatcher;
    private final Matcher usernameMatcher;
    private final Matcher venueMatcher;
    private final Matcher securityTypeMatcher;
    private final Matcher tenorMatcher;
    private final Matcher symbolMatcher;

    private final String regionPattern;
    private final String deskPattern;
    private final String orderTypePattern;
    private final String portfolioPattern;
    private final String usernamePattern;
    private final String venuePattern;
    private final String securityTypePattern;
    private final String tenorPattern;
    private final String symbolPattern;

    private final int specicifityFlags;

    public RegexpRuleMatcher(final String regionPattern,
                             final String deskPattern,
                             final String orderTypePattern,
                             final String portfolioPattern,
                             final String usernamePattern,
                             final String venuePattern,
                             final String securityTypePattern,
                             final String tenorPattern,
                             final String symbolPattern) {
        this.regionPattern = Objects.requireNonNull(regionPattern);
        this.deskPattern = Objects.requireNonNull(deskPattern);
        this.orderTypePattern = Objects.requireNonNull(orderTypePattern);
        this.portfolioPattern = Objects.requireNonNull(portfolioPattern);
        this.usernamePattern = Objects.requireNonNull(usernamePattern);
        this.venuePattern = Objects.requireNonNull(venuePattern);
        this.securityTypePattern = Objects.requireNonNull(securityTypePattern);
        this.tenorPattern = Objects.requireNonNull(tenorPattern);
        this.symbolPattern = Objects.requireNonNull(symbolPattern);


        this.regionMatcher = Pattern.compile(regionPattern).matcher("");
        this.deskMatcher = Pattern.compile(deskPattern).matcher("");
        this.orderTypeMatcher = Pattern.compile(orderTypePattern).matcher("");
        this.usernameMatcher = Pattern.compile(usernamePattern).matcher("");
        this.portfolioMatcher = Pattern.compile(portfolioPattern).matcher("");
        this.venueMatcher = Pattern.compile(venuePattern).matcher("");
        this.securityTypeMatcher = Pattern.compile(securityTypePattern).matcher("");
        this.tenorMatcher = Pattern.compile(tenorPattern).matcher("");
        this.symbolMatcher = Pattern.compile(symbolPattern).matcher("");

        this.specicifityFlags = (regionPattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 : 0)
                          | (deskPattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 1 : 0)
                          | (orderTypePattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 2 : 0)
                          | (portfolioPattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 3 : 0)
                          | (usernamePattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 4 : 0)
                          | (venuePattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 5 : 0)
                          | (securityTypePattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 6 : 0)
                          | (tenorPattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 7 : 0)
                          | (symbolPattern.equals(DEFAULT_MATCH_ALL_WILDCARD) ? 1 << 8 : 0);
    }

    @Override
    public boolean match(final String region,
                         final String desk,
                         final String targetStrategyName,
                         final String portfolio,
                         final String username,
                         final String venue,
                         final SecurityType securityType,
                         final Tenor tenor,
                         final String symbol) {

        return regionMatcher.reset(region).matches() &&
               orderTypeMatcher.reset(targetStrategyName).matches() &&
               deskMatcher.reset(desk).matches() &&
               portfolioMatcher.reset(portfolio).matches() &&
               usernameMatcher.reset(username).matches() &&
               venueMatcher.reset(venue).matches() &&
               securityTypeMatcher.reset(securityType.name()).matches() &&
               tenorMatcher.reset(tenor.name()).matches() &&
               symbolMatcher.reset(symbol).matches();
    }

    @Override
    public int compareTo(final RuleMatcher other) {
        if (other instanceof RegexpRuleMatcher) {
            final RegexpRuleMatcher otherRuleMatcher = (RegexpRuleMatcher) other;
            if (specicifityFlags != otherRuleMatcher.specicifityFlags)
                return specicifityFlags - otherRuleMatcher.specicifityFlags;

            return compareFieldSpecificity(otherRuleMatcher);
        } else {
            return 1; // RegexpRuleMatcher always come first
        }
    }

    private int compareFieldSpecificity(final RegexpRuleMatcher other){
        if(this.symbolPattern.length() != other.symbolPattern.length()){
            return other.symbolPattern.length() - this.symbolPattern.length();
        }
        if(this.tenorPattern.length() != other.tenorPattern.length()){
            return other.tenorPattern.length() - this.tenorPattern.length();
        }
        if(this.securityTypePattern.length() != other.securityTypePattern.length()){
            return other.securityTypePattern.length() - this.securityTypePattern.length();
        }
        if(this.venuePattern.length() != other.venuePattern.length()){
            return other.venuePattern.length() - this.venuePattern.length();
        }
        if(this.usernamePattern.length() != other.usernamePattern.length()){
            return other.usernamePattern.length() - this.usernamePattern.length();
        }
        if(this.portfolioPattern.length() != other.portfolioPattern.length()){
            return other.portfolioPattern.length() - this.portfolioPattern.length();
        }
        if(this.orderTypePattern.length() != other.orderTypePattern.length()){
            return other.orderTypePattern.length() - this.orderTypePattern.length();
        }
        if(this.deskPattern.length() != other.deskPattern.length()){
            return other.deskPattern.length() - this.deskPattern.length();
        }
        if(this.regionPattern.length() != other.regionPattern.length()){
            return other.regionPattern.length() - this.regionPattern.length();
        }
        return 0;
    }
}
