package com.anz.axle.lg.adapter.apama.ebs;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Function;

import com.apama.event.Event;

import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

public final class EventToRequestKey implements Function<Event, RequestKey> {
    private final BiPredicate<SecurityType, String> symbolValidator;
    private final Function<Event, String> eventToSymbol;
    private final Function<Event, String> eventToTranslatedSymbol;
    private final Function<Event, SecurityType> eventToSecurityType;
    private final Function<Event, Tenor> eventToTenor;
    private final VenueRequestKeyLookup requestKeyLookup;
    private final Map<String, String> externalSymbolToSymbol6Cache = new HashMap<>();

    public EventToRequestKey(final BiPredicate<SecurityType, String> symbolValidator,
                             final Function<Event, String> eventToSymbol,
                             final Function<Event, String> eventToTranslatedSymbol,
                             final Function<Event, SecurityType> eventToSecurityType,
                             final Function<Event, Tenor> eventToTenor,
                             final VenueRequestKeyLookup requestKeyLookup) {
        this.symbolValidator = Objects.requireNonNull(symbolValidator);
        this.eventToSymbol = Objects.requireNonNull(eventToSymbol);
        this.eventToTranslatedSymbol = Objects.requireNonNull(eventToTranslatedSymbol);
        this.eventToSecurityType = Objects.requireNonNull(eventToSecurityType);
        this.eventToTenor = Objects.requireNonNull(eventToTenor);
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
    }

    public static EventToRequestKey forEntryEvent(final BiPredicate<SecurityType, String> symbolValidator,
                                                  final VenueRequestKeyLookup requestKeyLookup,
                                                  final Function<Event, String> ebsEntryEventToTranslatedSymbol,
                                                  final Function<Event, Tenor> eventToTenor) {
        return new EventToRequestKey(symbolValidator,
                                     EventFunctions.EVENT_TO_SYMBOL,
                                     ebsEntryEventToTranslatedSymbol,
                                     EventFunctions.ENTRY_TO_SECURITY_TYPE,
                                     eventToTenor,
                                     requestKeyLookup);
    }

    public static EventToRequestKey forMessageEvent(final BiPredicate<SecurityType, String> symbolValidator,
                                                    final VenueRequestKeyLookup requestKeyLookup,
                                                    final Function<Event, String> ebsMessageEventToTranslatedSymbol,
                                                    final Function<Event, Tenor> eventToTenor) {
        return new EventToRequestKey(symbolValidator, EventFunctions.EVENT_TO_SYMBOL, ebsMessageEventToTranslatedSymbol, EventFunctions.MESSAGE_TO_SECURITY_TYPE, eventToTenor, requestKeyLookup);
    }

    @Override
    public RequestKey apply(final Event event) {
        final String externalSymbol6 = externalSymbolToSymbol6Cache.computeIfAbsent(eventToSymbol.apply(event), SymbolNormaliser::toSymbol6);
        final SecurityType securityType = eventToSecurityType.apply(event);
        if (symbolValidator.test(securityType, externalSymbol6)) {
            final String translatedSymbol = eventToTranslatedSymbol.apply(event);
            if (securityType == SecurityType.FXNDF) {
                final Tenor tenor = eventToTenor.apply(event);
                return requestKeyLookup.lookup(InstrumentKey.instrumentId(translatedSymbol, securityType, tenor));
            } else {
                return requestKeyLookup.lookup(InstrumentKey.instrumentId(translatedSymbol, securityType, Tenor.SP));
            }
        } else {
            return null;
        }
    }
}
