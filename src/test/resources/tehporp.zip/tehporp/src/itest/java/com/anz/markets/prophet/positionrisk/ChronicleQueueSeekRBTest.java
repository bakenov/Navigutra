package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueuePersister;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.Append;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.PersisterConfig;
import com.anz.markets.prophet.chronicle.config.PersisterConfigBuilder;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.ReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.threads.EventLoop;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

public class ChronicleQueueSeekRBTest {
    private static final long START_EVENT_ID = 111_111_111;
    private static final long TWO_EVENT_ID = 222_222_222;
    private static final long MID_EVENT_ID = 333_333_333;
    private static final long END_EVENT_ID = 444_444_444;
    private static final long START_TIME = TimeUnit.MINUTES.toNanos(1000);
    private static final long TWO_TIME = TimeUnit.MINUTES.toNanos(1009);
    private static final long MID_TIME = TimeUnit.MINUTES.toNanos(1020);
    private static final long END_TIME = TimeUnit.MINUTES.toNanos(1030);
    private long firstIndex;
    private String basePath;
    private KeepTrack track;

    private ApiVersion previousApiVersion;
    private boolean previousRBEnabled;

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
        SystemProperties.CQ_RING_BUFFER_ENABLED = previousRBEnabled;
    }

    @Before
    public void setup() throws IOException {
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        previousRBEnabled = SystemProperties.CQ_RING_BUFFER_ENABLED;
        SystemProperties.CHRONICLE_API_VERSION = ApiVersion.CHRONICLE_QUEUE;
        SystemProperties.CQ_RING_BUFFER_ENABLED = true;

        basePath = FileUtil.tmpFile(this.getClass().getSimpleName());

        Context.set(new Context(new TimeSourceChronicle()));
        final Header header = Context.context().header();
        try (ProphetPersister persister = createPersister(basePath)) {
            header.setEventId(START_EVENT_ID);
            header.setStartTimeStampNS(START_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(TWO_EVENT_ID);
            header.setStartTimeStampNS(TWO_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(MID_EVENT_ID);
            header.setStartTimeStampNS(MID_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(END_EVENT_ID);
            header.setStartTimeStampNS(END_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);

            firstIndex = 0;

            track = new KeepTrack();
        }
    }

    private void check(final StartAt start,
                       final long where,
                       final long expectedIndex,
                       final long expectedEventId) {
        final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                .withStartAt(start)
                .withStartPosition(where)
                .withWaitStrategy(WaitStrategy.STOP_ON_STALL)
                .withChronicleObjectReader(track)
                .withRingBuffer(RingBuffer.RING)
                .build();

        try {
            try (final ProphetReader cr = ChronicleReaderFactory.createReader(ThreadUtils.SameThreadExecutor.INSTANCE, basePath, readerConfig)) {
                if (expectedEventId > 0) {
                    assertEquals(expectedEventId, track.eventIds.get(0).longValue());
                } else {
                    assertEquals(0, track.eventIds.size());
                }
            }
        } catch (IOException e) {
            throw Jvm.rethrow(e);
        }
    }

    @Test
    public void testStartAtFirstEventId() {
        check(StartAt.EVENTID, START_EVENT_ID, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtMidEventId() {
        check(StartAt.EVENTID, MID_EVENT_ID, firstIndex + 2, MID_EVENT_ID);
    }

    @Test
    public void testStartAtLastEventId() {
        check(StartAt.EVENTID, END_EVENT_ID, firstIndex + 3, END_EVENT_ID);
    }

    @Test
    public void testStartAtLastEventIdPlus1Approx() {
        check(StartAt.EVENTID_CLOSEST, END_EVENT_ID+1, firstIndex + 3, 0);
    }

    @Test
    public void testStartAtLastEventIdMinus1Approx() {
        check(StartAt.EVENTID_CLOSEST, END_EVENT_ID-1, firstIndex + 3, END_EVENT_ID);
    }

    @Test(expected = SeekException.class)
    public void testStartAtInvalidEventId() {
        check(StartAt.EVENTID, START_EVENT_ID - 1, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtFirstEventIdApprox() {
        check(StartAt.EVENTID_CLOSEST, START_EVENT_ID - 1, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtCoreRxTimeApprox() {
        check(StartAt.CORE_RX_TIMESTAMP_CLOSEST, MID_TIME, firstIndex + 2, MID_EVENT_ID);
    }

    private static class KeepTrack implements ChronicleObjectReader {
        final List<MessageVersion> versions = new ArrayList<>();
        final List<Long> indexes = new ArrayList<>();
        final List<Long> eventIds = new ArrayList<>();

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            versions.add(Context.context().header().getMessageVersion());
            eventIds.add(Context.context().header().getEventId());
            indexes.add(bytes.getTailer().index());
        }
    }

    static ProphetPersister createPersister(final String basePath) {
        return createPersister(basePath, null);
    }

    static ProphetPersister createPersister(final String basePath, final EventLoop eventLoop) {
        final PersisterConfig config = PersisterConfigBuilder.create()
                .withActiveFlag(true)
                .withMessageTypePredicate(Predicates.alwaysTrue())
                .withAppend(Append.ALL)
                .withActivationAware(ActivationAware.NO)
                .withBeforeWrite(ChronicleHook.DO_NOTHING)
                .withAfterWrite(ChronicleHook.DO_NOTHING)
                .withRingBuffer(RingBuffer.RING)
                .withEventLoop(eventLoop)
                .build();
        return new ChronicleQueuePersister(basePath, config);
    }
}
