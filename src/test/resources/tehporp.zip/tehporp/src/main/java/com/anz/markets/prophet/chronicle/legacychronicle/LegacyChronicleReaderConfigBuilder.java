package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.status.Context;
import net.openhft.chronicle.threads.Pauser;

public class LegacyChronicleReaderConfigBuilder {
    public String chroniclePath;
    private LegacyChronicleConfig.ChronicleType chronicleType;
    private ChronicleHook startReadHook;
    private ChronicleHook endReadHook;
    private ChronicleHook unknownReadHook;
    private Context.HeaderPredicate headerFilter;
    private Pauser pauser;
    private StartAt startAt;
    private LegacyChronicleConfig.ReadWrite readOnly;
    private long startPosition = -1;
    private WaitStrategy waitStrategy;


    public LegacyChronicleReaderConfigBuilder(final LegacyChronicleReaderConfig config) {
        this.chroniclePath = config.chroniclePath;
        this.chronicleType = config.chronicleType;
        this.startReadHook = config.startReadHook;
        this.endReadHook = config.endReadHook;
        this.headerFilter = config.headerFilter;
        this.pauser = config.pauser;
        this.startAt = config.startAt;
        this.readOnly = config.readOnly;
        this.startPosition = config.startPosition;
        this.waitStrategy = config.waitStrategy;
        this.unknownReadHook = config.unknownReadHook;
    }

    public LegacyChronicleReaderConfigBuilder setChroniclePath(final String chroniclePath) {
        this.chroniclePath = chroniclePath;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setChronicleType(final LegacyChronicleConfig.ChronicleType chronicleType) {
        this.chronicleType = chronicleType;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setStartReadHook(final ChronicleHook startReadHook) {
        this.startReadHook = startReadHook;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setEndReadHook(final ChronicleHook endReadHook) {
        this.endReadHook = endReadHook;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setHeaderFilter(final Context.HeaderPredicate headerFilter) {
        this.headerFilter = headerFilter;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setPauser(final Pauser pauser) {
        this.pauser = pauser;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setStartAt(final StartAt startAt) {
        this.startAt = startAt;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setReadOnly(final LegacyChronicleConfig.ReadWrite readOnly) {
        this.readOnly = readOnly;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setStartPosition(final long startPosition) {
        this.startPosition = startPosition;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setWaitStrategy(final WaitStrategy waitStrategy) {
        this.waitStrategy = waitStrategy;
        return this;
    }

    public LegacyChronicleReaderConfigBuilder setUnknownReadHook(
            final ChronicleHook unknownReadHook) {
        this.unknownReadHook = unknownReadHook;
        return this;
    }

    public LegacyChronicleReaderConfig createChronicleConfigReader() {
        return new LegacyChronicleReaderConfig(chroniclePath, chronicleType, startReadHook, endReadHook, unknownReadHook, headerFilter,
                pauser, startAt, readOnly, startPosition, waitStrategy);
    }
}