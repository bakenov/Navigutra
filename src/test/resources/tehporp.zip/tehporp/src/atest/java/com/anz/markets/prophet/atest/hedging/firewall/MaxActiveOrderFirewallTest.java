package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderEventType;
import com.anz.markets.prophet.domain.order.impl.OrderEventImpl;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.jetbrains.annotations.NotNull;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.SUSPICIOUS_DISCREPANCY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURGBP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_6})
@RestartBeforeTest(reason = "open orders remain")
public class MaxActiveOrderFirewallTest extends BaseAcceptanceSpecification {

    private NewOrder hedgingOrder1;
    private NewOrder hedgingOrder2;
    private NewOrder hedgingOrder3;
    private CancelOrder cancelOrder;

    @Test
    public void shouldTriggerWhenOverOrderLimit() {
        setup:
        {
            double openOrderLimit = 2;
            prophet.receive(setUpConfiguration(openOrderLimit));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));

            prophet.clearOutputBuffer();
        }
        when:
        // t+1, receive EURUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }

        when:
        // t+5 receive EURGBP client deal to generate op pos and MID_BGC hedger sends hedge trade 2
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.client_trade_001(EURGBP, 14_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder2.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        // expect no change to the firewall
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+10 receive AUDUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_200_000, 0.75000));  // AUDUSD gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder3.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+15 hedge trade is confirmed/acked
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder3));
        }
        then:
        // firewall breached
        {
            prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getFirewallType(), BREACHED, HEDGER_MID_BGC));
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() {
        shouldTriggerWhenOverOrderLimit();
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(HEDGER_MID_BGC, getFirewallType()));
        }
        then:
        {
            prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getFirewallType(), NOT_BREACHED, HEDGER_MID_BGC));
        }
    }

    @Test
    public void firewallHandlesFullFillOrderEvents() {
        setup:
        {
            double openOrderLimit = 2;
            prophet.receive(setUpConfiguration(openOrderLimit));

            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));

            prophet.clearOutputBuffer();
        }
        when:
        // t+1, receive EURUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }

        when:
        // t+5 receive EURGBP client deal to generate op pos and MID_BGC hedger sends hedge trade 2
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.client_trade_001(EURGBP, 14_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder2.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        // no change to firewall status
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+10 receive AUDUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_200_000, 0.75000));  // AUDUSD gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder3.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+15 hedge trade is confirmed/acked
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder3));
        }
        then:
        // firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));
        }
        when:
        // t+20 hedge trade 1 is fully filled
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(hedgingOrder1, 1.05000);
        }
        then:
        // firewall UN-breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));
        }
    }

    @Test
    public void firewallHandlesPartialFillOrderEvents() {
        setup:
        {
            double openOrderLimit = 2;
            prophet.receive(setUpConfiguration(openOrderLimit));

            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));

            prophet.clearOutputBuffer();
        }
        when:
        // t+1, receive EURUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }

        when:
        // t+5 receive EURGBP client deal to generate op pos and MID_BGC hedger sends hedge trade 2
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.client_trade_001(EURGBP, 14_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder2.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        // no change to firewall status
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+10 receive AUDUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_200_000, 0.75000));  // AUDUSD gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder3.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+15 hedge trade is confirmed/acked
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder3));
        }
        then:
        // firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));
        }
        when:
        // t+20 hedge trade 1 is partially filled
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderPartialFill(hedgingOrder1, 100_000, 1.05000);
        }
        then:
        // firewall UN-breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
    }

    @Test
    public void firewallHandlesCancelOrderEvents() {
        setup:
        {
            double openOrderLimit = 2;
            prophet.receive(setUpConfiguration(openOrderLimit));

            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));

            prophet.clearOutputBuffer();
        }
        when:
        // t+1, receive EURUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }

        when:
        // t+5 receive EURGBP client deal to generate op pos and MID_BGC hedger sends hedge trade 2
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.client_trade_001(EURGBP, 14_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder2.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        // no change to firewall status
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+10 receive AUDUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_200_000, 0.75000));  // AUDUSD gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), is(2_000_000.0));
            assertThat(hedgingOrder3.getMarket(), is(Market.BGCMIDFX));
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+15 hedge trade is confirmed/acked
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder3));
        }
        then:
        // firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));

            // hedger cancels first two orders as they have met MinTTL(1ms)
            cancelOrder = prophet.expect(CancelOrder.class, exactly(2)).getLast();
            assertThat(cancelOrder.getInstrument(), is(EURGBP));
        }
        when:
        // t+20 hedger receives cancel ack
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder2, cancelOrder, 0, 0));
        }
        and:
        // firewall Un-breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));
        }
    }

    @Test
    public void firewallHandlesRejectOrderEvents() {
        // in prod we can receive REJECT after an order has been confirmed.
        // Test to ensure REJECT removes order from active order list
        setup:
        {
            double openOrderLimit = 2;
            prophet.receive(setUpConfiguration(openOrderLimit));

            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));

            prophet.clearOutputBuffer();
        }
        when:
        // t+1, receive EURUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }

        when:
        // t+5 receive EURGBP client deal to generate op pos and MID_BGC hedger sends hedge trade 2
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.client_trade_001(EURGBP, 14_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        and:
        // no change to firewall status
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+10 receive AUDUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_200_000, 0.75000));  // AUDUSD gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+15 hedge trade is confirmed/acked
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder3));
        }
        then:
        // firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));

            // hedger cancels first two orders as they have met MinTTL(1ms)
            cancelOrder = prophet.expect(CancelOrder.class, exactly(2)).getLast();
            assertThat(cancelOrder.getInstrument(), is(EURGBP));
        }
        when:
        // t+20 hedger receives REJECT for hedge 3
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(hedgingOrder3));
        }
        and:
        // firewall Un-breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));
        }
    }

    @Test
    // Max active order per instrument set to 1. Note this firewall should never be triggered if the hedger itself is behaving correctly
    public void multipleActiveOrdersOnSameInstrumentSamePortfolio() {
        OrderEventImpl dummySecondActiveOrderConfirm;

        setup:
        {
            double openOrderLimit = 2;
            prophet.receive(setUpConfiguration(openOrderLimit));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));

            prophet.clearOutputBuffer();
        }
        when:
        // t+1, receive EURUSD client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            dummySecondActiveOrderConfirm = createOrderEvent(OrderEventType.CONFIRMED, hedgingOrder1);
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+5 receive confirm order event for dummy 2nd order on same instrument
        {
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.receive(dummySecondActiveOrderConfirm);
        }
        then:
        // firewall breached and hedger pending disable
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(HEDGER_MID_BGC));

            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsPendingDisable(HEDGER_MID_BGC, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    private OrderEventImpl createOrderEvent(final OrderEventType orderEventType, final NewOrder order) {
        final OrderEventImpl orderEvent = new OrderEventImpl();
        orderEvent.setOrderEventType(orderEventType);
        orderEvent.setOrderId("P_HEDGER_MID_BGC_dummyid");
        orderEvent.setMarket(order.getMarket());
        orderEvent.setInstrument(order.getInstrument());
        orderEvent.setMarketOrderId("dummyid-" + order.getId());
        orderEvent.setPortfolio(order.getPortfolio());
        orderEvent.setFilledQuantity(0);
        orderEvent.setRemainingQuantity(order.getQuantity());
        return orderEvent;
    }

    @NotNull
    protected HedgeFirewallType getFirewallType() {
        return MAXIMUM_ACTIVE_ORDER;
    }

    private ConfigurationDataDefault setUpConfiguration(double maxActiveOrders) {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setHedgeFirewallConfigs(asList(
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, 1, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_ACTIVE_ORDER, maxActiveOrders, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, SUSPICIOUS_DISCREPANCY, NaN, true)
                ))
                .setMidHedgerConfigs(Lists.newArrayList(
                        new MidHedgerConfigImpl(Market.BGCMIDFX, AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0),
                        new MidHedgerConfigImpl(Market.BGCMIDFX, EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0),
                        new MidHedgerConfigImpl(Market.BGCMIDFX, EURGBP).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0)
                ));

        return configuration;
    }
}
