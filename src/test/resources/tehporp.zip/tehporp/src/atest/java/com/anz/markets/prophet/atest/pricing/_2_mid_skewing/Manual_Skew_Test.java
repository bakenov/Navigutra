package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 ** AXPROPHET-472 Manual Skew factor received from AXLE GUI.
 *  Value in pips and any non-zero value overrides OP/NOP skew.
 *  instrument skew = baseCcy skew - termsCcy skew
 *  instrument skew limited to maxSkewAsProportionalOfBaseSpread * basespread
 *
 *  PAUSE SKEW control will override any Manual Skew
 **/
public class Manual_Skew_Test extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4))
                .setPricingModels(
                        Arrays.asList(
                                new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                                        .setInstrument(Instrument.ANY)
                                        .setSkewed(true)
                                        .setMaxSkewAsProportionOfBaseSpread(0.5)
                                        .setOverallMaxSkewAsProportionOfBaseSpread(1.0),
                                new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                                        .setInstrument(Instrument.ANY)
                                        .setSkewed(true)
                                        .setMaxSkewAsProportionOfBaseSpread(0.7)
                                        .setOverallMaxSkewAsProportionOfBaseSpread(1.0),
                                new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m")
                                        .setInstrument(Instrument.ANY)
                                        .setSkewed(false)
                                        .setMaxSkewAsProportionOfBaseSpread(0.1)
                                        .setOverallMaxSkewAsProportionOfBaseSpread(1.0),
                                new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                        ))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0)
                ))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(com.google.common.collect.Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ));

        return configuration;
    }

    @RestartBeforeTest(reason="reset")
    @Test
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_472})
    @RelatedTest(Optimal_Position_Risk_Skew_and_NOP_Skew_Combined.class)
    public void manual_skew() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generated optimal positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 500_000, 78.420));
        }
        and:
        // receive manual skew of 0 therefore OP skew is in play
        {
            prophet.receive(tdd.manualSkew(Currency.JPY, 0.0));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.870, 0.003));
        }
        then:
        // OP skew on USD/JPY SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.87106802));
        }
        when:
        // receive positive manual skew to trigger indirectPair client price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.AUD, 0.1));
        }
        then:
        // manual skew applied on ALL Skew enabled models(WSP_A and WSP_B)
        // Since skew NOT enabled on WSP_C and WSP_Z hardcoded to NOT skew, do not expect change in price on those markets
        {
            LinkedList<WholesaleBookFactors> wbf = prophet.expect(WholesaleBookFactors.class, exactly(2), isWholesaleBookFactors(indirectPair));
            assertThat(wbf.get(0).getMarket(), is(Market.WSP_A));
            assertThat(wbf.get(0).getSkewedMidPrice(), new IsRoundedTo(0.75101));
            assertThat(wbf.get(1).getMarket(), is(Market.WSP_B));
            assertThat(wbf.get(1).getSkewedMidPrice(), new IsRoundedTo(0.75101));
        }
        when:
        // receive negative manual skew
        // receive mktdatasnapshot to trigger skewed client price
        {
            prophet.receive(tdd.manualSkew(Currency.AUD, -0.1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75104));
        }
        when:
        // receive positive manual skew to trigger directPair client price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.JPY, 0.15));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.8685)); // 103.870 - 0.0015
        }
        when:
        // cross driver pair containing skew on each ccy
        {
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.10500, 0.0040));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.EUR, -0.2));
            prophet.receive(tdd.manualSkew(Currency.NOK, -0.5));
        }
        then:
        {
            LinkedList<WholesaleBookFactors> wbf = prophet.expect(WholesaleBookFactors.class, atLeast(2), isWholesaleBookFactors(crossPair, Market.WSP_A));
            assertThat(wbf.get(0).getSkewedMidPrice(), new IsRoundedTo(9.10498));
            assertThat(wbf.get(1).getSkewedMidPrice(), new IsRoundedTo(9.10503)); // total skew of -0.2 - (-0.5) = 0.3pip
        }
        when:
        // verify total skew cap
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.NOK, 21.0));
        }
        then:
        // WSP_A manual skew cap = maxSkewAsProportionalOfBaseSpread(0.5) * basespread(40pip) = 20pip
        // WSP_B manual skew cap = maxSkewAsProportionalOfBaseSpread(0.7) * basespread(40pip) = 28pip
        // total skew -0.2 - 21 = -21.2pip
        // only WSP_A capped to 20pip
        {
            WholesaleBookFactors wbfa = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(crossPair, Market.WSP_A)).getFirst();
            assertThat(wbfa.getSkewedMidPrice(), new IsRoundedTo(9.10300));

            WholesaleBookFactors wbfb = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(crossPair, Market.WSP_B)).getFirst();
            assertThat(wbfb.getSkewedMidPrice(), new IsRoundedTo(9.10288));
        }
        when:
        // skew removed, NOP/OP skew to take effect
        {
            prophet.receive(tdd.manualSkew(Currency.EUR, 0.0));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.NOK, 0.0));
        }
        then:
        // Apply OP skew on EUR/SEK SHORT optimal position.  Apply +ve skew to improve BID(client sell)
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(9.1031052));
        }
        when:
        // receive positive manual skew to trigger directPair client price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.JPY, 0.1));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.869)); // 103.870 - 0.001
        }
        when:
        // active skew pause and receive new marketDataSnapshots while pause is active
        {
            // Pause skewing enabled
            prophet.receive(tdd.setSkewingPause(Currency.JPY, true));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.872, 0.00003));
        }
        then:
        // since Skew Pause is ACTIVE, do not SKEW MID
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.872));
        }
        when:
        // t+4 wait for PAUSE SKEW period to expire.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(4_000);
        }
        then:
        // client price generated with MANUAL SKEWED MID
        {
            prophet.expect(SkewCurrencyControl.class, isSkewCcyPaused(Currency.JPY, false));
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(103.871));  // 103.872 - 0.001
        }
    }
}