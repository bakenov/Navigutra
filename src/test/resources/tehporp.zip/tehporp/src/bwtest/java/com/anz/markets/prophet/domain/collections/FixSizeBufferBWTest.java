package com.anz.markets.prophet.domain.collections;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;

public class FixSizeBufferBWTest extends AbstractFixSizeBufferBwJmhTest {
    private static final int REPS = 200_000;
    private static final int THRESHOLD = 200;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    private void scenario_addAndRemove() {
        this.testAddAndRemove();
    }

    private void scenario_addAndRemoveIfOlder() {
        this.testAddAndRemoveIfOlder();
    }

    @Test
    public void test_addAndRemove() {
        helper.testAllocationNotExceeded(
                this::scenario_addAndRemove, REPS, REPS,
                THRESHOLD
        );
    }

    @Test
    public void test_addAndRemoveIfOlder() {
        helper.testAllocationNotExceeded(
                this::scenario_addAndRemoveIfOlder, REPS, REPS,
                THRESHOLD
        );
    }
}
