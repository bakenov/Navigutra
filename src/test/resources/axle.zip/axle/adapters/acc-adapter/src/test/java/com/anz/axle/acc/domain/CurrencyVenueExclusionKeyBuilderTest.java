package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.*;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionKey;
import org.joda.time.LocalDate;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;


public class CurrencyVenueExclusionKeyBuilderTest {
    @Test
    public void test_that_exclusion_is_built() throws BuilderException {
        Currency aud = new Currency(1l, "AUD", "AUD", 2);
        Currency usd = new Currency(2l, "USD", "USD", 2);
        CurrencyPair audusd = new CurrencyPair(aud, usd);
        Venue venue = new Venue();
        venue.setAggregatorCode("BARX");

        CurrentVenueCurrencyCreditState state = new CurrentVenueCurrencyCreditState(true, audusd, venue, new LocalDate(), new LocalDate(), 0.83d);
        CurrencyVenueExclusionKey exclusion = new CurrencyVenueExclusionKeyBuilder().build(state);

        assertEquals("BARX", exclusion.getVenue());
        assertEquals("AUD/USD", exclusion.getSymbol());
        assertEquals("CREDIT_CHECK", exclusion.getSource());
    }
}
