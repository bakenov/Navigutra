package com.anz.axle.adapters.rmds.consumer;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ListItemProviderTest {

    @Test
    public void testSetItems() {
       final ListItemProvider provider = new ListItemProvider();
       provider.setItems(Arrays.asList("EUR=","AUD=","GBP="));
       assertNotNull(provider.getItems());
       assertEquals(3, provider.getItems().size());
    }

}
