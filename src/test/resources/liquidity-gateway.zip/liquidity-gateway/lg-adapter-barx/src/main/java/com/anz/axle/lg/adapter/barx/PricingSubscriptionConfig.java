package com.anz.axle.lg.adapter.barx;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.BandedSubscriptionRepository;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Configuration
public class PricingSubscriptionConfig {

    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final AsyncMarketDataSubscriber asyncMarketDataSubscriber;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final List<Integer> priceBands;
    private final BandedSubscriptionRepository bandedSubscriptionRepository;
    private final Venue venue;


    public PricingSubscriptionConfig(final TopicRegistry pricingTopicRegistry,
                                     final PublicationRegistry publicationRegistry,
                                     final AsyncMarketDataSubscriber asyncMarketDataSubscriber,
                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                     @Value("${barx.fix.pricing.bands}") final List<Integer> priceBands,
                                     final BandedSubscriptionRepository bandedSubscriptionRepository) {
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.asyncMarketDataSubscriber = Objects.requireNonNull(asyncMarketDataSubscriber);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.priceBands = Objects.requireNonNull(priceBands);
        this.bandedSubscriptionRepository = Objects.requireNonNull(bandedSubscriptionRepository);
        this.venue = Venue.BARX;
    }

    @PostConstruct
    void init() {
        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            final InstrumentKey instrumentKey = InstrumentKey.of(symbol);
            final Topic topic = pricingTopicRegistry.topic(venue, instrumentKey);
            publicationRegistry.registerPublication(topic);

            for (int bandIndex = 0; bandIndex < priceBands.size(); bandIndex++) {
                asyncMarketDataSubscriber.schedule(bandedSubscriptionRepository.create(instrumentKey, priceBands, bandIndex));
            }
        });
    }
}
