package com.anz.axle.lg.adapter.apama.config.venue;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.apama.decoder.AggBookDecoder;
import com.anz.axle.lg.adapter.apama.decoder.ApamaEventDecoder;
import com.anz.axle.lg.adapter.apama.event.AggBook;
import com.anz.axle.lg.adapter.apama.transport.Connection;
import com.anz.axle.lg.adapter.apama.transport.ConnectionConfig;
import com.anz.axle.lg.adapter.apama.transport.ConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.MarketDataBooksClearingConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.Subscription;
import com.anz.axle.lg.adapter.apama.transport.Transport;
import com.anz.axle.lg.config.DefaultPricingEncoderLookup;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.config.SbeMessagePublisher;
import com.anz.axle.lg.config.SnapshotterAccessor;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamEncoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;

@Configuration
public class AXLVenueSubscribingConfig {
    private static final Venue VENUE = Venue.AXL;

    private final String compId;
    private final String senderCompId;
    private final int source;

    public AXLVenueSubscribingConfig(final @Value("${messaging.compId}") String compId,
                                     final @Value("${messaging.BARX.compId}") String senderCompId,
                                     final @Value("${messaging.source}") int source) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.source = source;
    }

    @Bean
    public SourceSequencer sourceSequencer(@Value("${messaging.source.id}") final int sourceId) {
        return SourceSequencer.of(sourceId);
    }

    @Bean
    protected ConnectionConfig axlConnectionConfig(final @Value("${apama.fxagg.host.AXL}") String host,
                                                   final @Value("${apama.fxagg.port.AXL}") int port,
                                                   final @Value("${apama.fxagg.channel.AXL}") String channelName,
                                                   final @Value("${apama.connectionPollingInterval:30000}") int connectionPollingInterval) {
        return new DefaultConnectionConfig(VENUE, host, port, channelName, connectionPollingInterval);
    }

    @Bean
    protected VenueRequestKeyLookup axlVenueRequestKeyLookup() {
        return new DefaultVenueRequestKeyLookup(VENUE);
    }

    @Bean(destroyMethod = "clearAllBooksAndForwardEmptySnapshots")
    protected PricingEncoderLookup axlPricingEncoderLookup(final Function<Consumer<SbeMessage>, PricingEncoderSupplier> pricingEncoderSupplierFactory,
                                                           final PrecisionClock precisionClock,
                                                           final @Value("${market.data.book.initial.size:10}") int marketDataBookInitialSize,
                                                           final LongIdFactory messageIdFactory,
                                                           final TopicRegistry pricingTopicRegistry,
                                                           final MessageHandler publisher) {
        return new DefaultPricingEncoderLookup(pricingTopicRegistry, requestKey -> {
            final SnapshotterBuilder builder = SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, marketDataBookInitialSize))
                    .withDownstreamEncoder()
                    .forwardSnapshotsAndIncrementsTo(
                            pricingEncoderSupplierFactory.apply(SbeMessagePublisher.create(requestKey, pricingTopicRegistry, publisher)));

            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock,  messageIdFactory::get, compId, source);
            final UpstreamEncoderConnector upstreamEncoderConnector = builder.buildUpstreamEncoderConnector(UpdateTypeMismatchHandler.WARN);
            return SnapshotterAccessor.create(snapshotter, upstreamEncoderConnector);
        });
    }


    @Bean
    public MarketDataBooksClearingConnectionStatusHandler axlConnectionStatusHandler(final PricingEncoderLookup axlPricingEncoderLookup) {
        return new MarketDataBooksClearingConnectionStatusHandler(axlPricingEncoderLookup);
    }

    @Bean
    protected Connection axlApamaConnection(final Transport apamaTransport,
                                            final ConnectionConfig axlConnectionConfig,
                                            final ConnectionStatusHandler axlConnectionStatusHandler) {
        return apamaTransport.openConnection(axlConnectionConfig, axlConnectionStatusHandler);
    }

    @Bean
    protected ApamaEventDecoder axlApamaSnapshotEventDecoder(final VenueRequestKeyLookup axlVenueRequestKeyLookup,
                                                             final PricingEncoderLookup axlPricingEncoderLookup,
                                                             final PrecisionClock precisionClock,
                                                             final SourceSequencer sourceSequencer) {
        return new AggBookDecoder(axlVenueRequestKeyLookup, axlPricingEncoderLookup, precisionClock, senderCompId, compId, sourceSequencer);
    }

    @Bean
    protected Subscription axlSnapshotSubscription(final Connection axlApamaConnection,
                                                   final ApamaEventDecoder axlApamaSnapshotEventDecoder) {
        return axlApamaConnection.openSubscription(AggBook.EVENT_TYPE, axlApamaSnapshotEventDecoder::decode);
    }

    @Bean
    protected VenuePublications axlVenuePublications(final TopicRegistry pricingTopicRegistry,
                                                     final PublicationRegistry publicationRegistry,
                                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues) {

        return new VenuePublications(VENUE, pricingTopicRegistry, publicationRegistry, fxSpotSymbolVenues, Collections.emptyMap());
    }

    @Autowired
    @Qualifier("axlVenuePublications")
    private VenuePublications axlVenuePublications;

    @PostConstruct
    public void init() {
        axlVenuePublications.init();
    }

}
