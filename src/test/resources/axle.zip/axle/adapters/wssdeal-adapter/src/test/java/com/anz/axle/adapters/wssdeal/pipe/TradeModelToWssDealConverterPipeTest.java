package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import anz.markets.messaging.endpoint.intf.DataSink;
import anz.markets.messaging.endpoint.intf.DataSource;
import anz.markets.messaging.types.PDMessage;
import com.anz.axle.adapters.wssdeal.builder.WssDealBuilder;
import com.anz.axle.common.AbstractUnitTest;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.wss.domain.WssDeal;
import org.jmock.Expectations;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by talwarg on 9/02/2015.
 */
public class TradeModelToWssDealConverterPipeTest extends AbstractUnitTest {

    private TradeModelToWssDealConverterPipe tradeModelToWssDealConverterPipe;
    private Builder<WssDeal, TradeMessageWrapperType> builder;

    @Before
    public void setUp(){
        builder = mock(WssDealBuilder.class);
        tradeModelToWssDealConverterPipe = new TradeModelToWssDealConverterPipe(builder);
    }

    @Test
    public void testOnMessage(){
        final TradeMessageWrapperType tradeMessage = new TradeMessageWrapperType();
        final WssDeal wssDeal = new WssDeal();
        final DataSink<WssDeal> dataSink = mock(DataSink.class);

        checking(new Expectations() {
            {
                try {
                    oneOf(builder).build(tradeMessage);
                    will(returnValue(wssDeal));
                    oneOf(dataSink).setSource(with(any(DataSource.class)));

                    oneOf(dataSink).onMessage(with(any(PDMessage.class)));
                    will(returnValue(true));
                } catch (Exception e) {

                }
            }
        });

        tradeModelToWssDealConverterPipe.setSink(dataSink);
        tradeModelToWssDealConverterPipe.onMessage(new PDMessage<TradeMessageWrapperType>("1", tradeMessage));
    }
}
