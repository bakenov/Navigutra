package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.Objects;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HealthCheckService {

    private static final Logger LOGGER = LoggerFactory.getLogger(HealthCheckService.class);
    private final Runnable healthCheckJob;
    private final ScheduledExecutorService scheduledExecutorService;
    private final Scheduler scheduler;
    private final long delay;
    private ScheduledFuture checkMissingHeartbeatsJob;

    public HealthCheckService(final Runnable healthCheckJob, final ScheduledExecutorService scheduledExecutorService, final Scheduler scheduler, final long delay) {
        this.healthCheckJob = Objects.requireNonNull(healthCheckJob);
        this.scheduledExecutorService = Objects.requireNonNull(scheduledExecutorService);
        this.scheduler = Objects.requireNonNull(scheduler);
        this.delay = delay;
    }

    @PostConstruct
    public void start() {
        LOGGER.info("Scheduling async health check job with delay {} ms", delay);
        checkMissingHeartbeatsJob = scheduledExecutorService.scheduleAtFixedRate(this::submitAsyncJob, delay, delay, TimeUnit.MILLISECONDS);
    }

    private void submitAsyncJob() {
        LOGGER.info("submitAsyncJob {}", healthCheckJob);
        scheduler.submit(healthCheckJob);
    }

    @PreDestroy
    public void stop() {
        checkMissingHeartbeatsJob.cancel(true);
    }
}
