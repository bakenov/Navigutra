package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;

import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.api.domain.ChildOrderState;
import com.anz.markets.efx.fox.api.domain.ChildOrderVisitor;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;

public class WaitingToDeadTimerExpiryHandler implements TimerScheduler.ExpiryHandler {
    private final ChildOrder order;
    private CommandContext commandContext;

    public WaitingToDeadTimerExpiryHandler(final ChildOrder order) {
        this.order = Objects.requireNonNull(order);
    }

    private final ChildOrderVisitor childOrderVisitor = new ChildOrderVisitor() {
        @Override
        public void visit(final ChildOrderState.WaitingOrderState order) {
            order.sendExecutionReport(commandContext, ExecType.ORDER_STATUS, OrderStatus.UNKNOWN);
        }

        @Override
        public void visit(final ChildOrderState.WorkingOrderState order) {
            order.sendExecutionReport(commandContext, ExecType.ORDER_STATUS, OrderStatus.UNKNOWN);
        }
    };

    @Override
    public TimerGroup timerGroup() {
        return TimerGroup.CHILD_ORDER_WAITING_TO_DEAD;
    }

    @Override
    public boolean onExpiryCommand(final long timerId, final long triggeredTime, final CommandContext commandContext) {
        this.commandContext = Objects.requireNonNull(commandContext);
        order.accept(childOrderVisitor);
        return true;
    }
}
