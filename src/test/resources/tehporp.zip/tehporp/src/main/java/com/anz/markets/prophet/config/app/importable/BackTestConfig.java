package com.anz.markets.prophet.config.app.importable;


import com.anz.markets.prophet.backtest.BackTestManager;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BackTestConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(BackTestConfig.class);

    @Bean
    public BackTestManager backTestManager(@Value("${backtest.enabled:false}") final boolean isBackTestEnabled,
                                           @Value("${backtest.messages:ANY}") final String messages) {
        LOGGER.info("backtest.enabled="+isBackTestEnabled+",messages=" + messages);
        final BackTestManager backTestManager = isBackTestEnabled? BackTestManager.createWithBackTestEnabled(false) : BackTestManager.create(false);
        backTestManager.enablePersistableMessageType(MessageType.parse(messages).toArray(new MessageType[] {}));
        return backTestManager;
    }
}
