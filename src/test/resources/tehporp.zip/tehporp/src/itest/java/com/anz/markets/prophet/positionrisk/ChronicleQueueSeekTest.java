package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.ReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import net.openhft.chronicle.core.Jvm;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class ChronicleQueueSeekTest {
    private static final long START_EVENT_ID = 111_111_111;
    private static final long TWO_EVENT_ID = 222_222_222;
    private static final long MID_EVENT_ID = 333_333_333;
    private static final long END_EVENT_ID = 444_444_444;
    private static final long START_TIME = TimeUnit.MINUTES.toNanos(1000);
    private static final long TWO_TIME = TimeUnit.MINUTES.toNanos(1009);
    private static final long MID_TIME = TimeUnit.MINUTES.toNanos(1020);
    private static final long END_TIME = TimeUnit.MINUTES.toNanos(1030);
    private long firstIndex;
    private String basePath;
    private KeepTrack track;

    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    @Before
    public void setup() throws IOException {
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;

        basePath = FileUtil.tmpFile(this.getClass().getSimpleName());

        Context.set(new Context(new TimeSourceChronicle()));
        final Header header = Context.context().header();
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePath)) {
            header.setEventId(START_EVENT_ID);
            header.setStartTimeStampNS(START_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(TWO_EVENT_ID);
            header.setStartTimeStampNS(TWO_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(MID_EVENT_ID);
            header.setStartTimeStampNS(MID_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(END_EVENT_ID);
            header.setStartTimeStampNS(END_TIME);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);

            firstIndex = persister.firstIndex();

            track = new KeepTrack();
        }
    }

    private void check(final StartAt start,
                       final long where,
                       final long expectedIndex,
                       final long expectedEventId) {
        final ReaderConfig readerConfig = ReaderConfigBuilder.create()
                .withStartAt(start)
                .withStartPosition(where)
                .withWaitStrategy(WaitStrategy.STOP_ON_STALL)
                .withChronicleObjectReader(track)
                .build();

        try {
            try (final ProphetReader cr = ChronicleReaderFactory.createReader(ThreadUtils.SameThreadExecutor.INSTANCE, basePath, readerConfig)) {
                assertEquals(expectedIndex, track.indexes.get(0).longValue());
                assertEquals(expectedEventId, track.eventIds.get(0).longValue());
            }
        } catch (IOException e) {
            throw Jvm.rethrow(e);
        }
    }

    @Test
    public void testStartAtStart() {
        check(StartAt.START, -99, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtFirstIndex() {
        check(StartAt.INDEX, firstIndex, firstIndex, START_EVENT_ID);
    }

    @Test(expected = SeekException.class)
    public void testStartAtInvalidIndex() {
        check(StartAt.INDEX, firstIndex + 99999, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtFirstEventId() {
        check(StartAt.EVENTID, START_EVENT_ID, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtMidEventId() {
        check(StartAt.EVENTID, MID_EVENT_ID, firstIndex + 2, MID_EVENT_ID);
    }

    @Test
    public void testStartAtLastEventId() {
        check(StartAt.EVENTID, END_EVENT_ID, firstIndex + 3, END_EVENT_ID);
    }

    @Test(expected = SeekException.class)
    public void testStartAtInvalidEventId() {
        check(StartAt.EVENTID, START_EVENT_ID - 1, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtFirstEventIdApprox() {
        check(StartAt.EVENTID_CLOSEST, START_EVENT_ID - 1, firstIndex, START_EVENT_ID);
    }

    @Test
    public void testStartAtCoreRxTimeApprox() {
        check(StartAt.CORE_RX_TIMESTAMP_CLOSEST, MID_TIME, firstIndex + 2, MID_EVENT_ID);
    }

    private static class KeepTrack implements ChronicleObjectReader {
        final List<MessageVersion> versions = new ArrayList<>();
        final List<Long> indexes = new ArrayList<>();
        final List<Long> eventIds = new ArrayList<>();

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            versions.add(Context.context().header().getMessageVersion());
            eventIds.add(Context.context().header().getEventId());
            indexes.add(bytes.getTailer().index());
        }
    }
}
