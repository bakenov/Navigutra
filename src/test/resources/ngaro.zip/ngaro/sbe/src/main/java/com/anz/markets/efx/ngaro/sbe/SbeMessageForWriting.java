package com.anz.markets.efx.ngaro.sbe;

import java.util.Objects;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;

public final class SbeMessageForWriting implements MutableSbeMessage {

    private final MutableDirectBuffer buffer;
    private int length;

    public SbeMessageForWriting(final int initialCapacity) {
        this(new ExpandableArrayBuffer(initialCapacity));
    }

    public SbeMessageForWriting(final MutableDirectBuffer buffer) {
        this.buffer = Objects.requireNonNull(buffer);
    }

    @Override
    public MutableDirectBuffer buffer() {
        return buffer;
    }

    @Override
    public int messageLength() {
        return length;
    }

    @Override
    public void messageLength(final int length) {
        this.length = length;
    }
}
