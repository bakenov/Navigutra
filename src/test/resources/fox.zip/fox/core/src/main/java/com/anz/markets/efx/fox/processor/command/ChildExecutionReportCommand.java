package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.ExecutionReportSbeDecoder;

public class ChildExecutionReportCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChildExecutionReportCommand.class);

    private final ChildOrderRepository childOrderRepository;
    private final CommandContext commandContext;

    private final ExecutionReportSbeDecoder executionReportDecoder = new ExecutionReportSbeDecoder();

    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);
    private final StringBuilder stringBuilder = new StringBuilder();

    public ChildExecutionReportCommand(final ChildOrderRepository childOrderRepository,
                                       final CommandContext commandContext) {
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!executionReportDecoder.wrap(message)) return false;

        final String marketId = executionReportDecoder.body().marketId().decodeAndCache(marketIdCache);
        if (!Venue.FOX.name().equals(marketId)) {
            logMessage();

            final long childOrigClOrdId = executionReportDecoder.body().origClOrdId().decodeLongOrZero();

            if (childOrigClOrdId > 0) {
                final ChildOrder childOrder = childOrderRepository.lookupByClOrdId(childOrigClOrdId);
                if (childOrder != null) {
                    childOrder.parentOrder().onChildExecutionReport(commandContext, executionReportDecoder);
                } else {
                    LOGGER.error("Could not find child order by childOrigClOrdId {}", childOrigClOrdId);
                }
            } else {
                LOGGER.error("ExecutionReport must provide clOrdId");
            }
            return true;
        }

        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        executionReportDecoder.appendTo(stringBuilder);
        LOGGER.info("Action child ER: {}", stringBuilder);
    }
}
