package com.anz.markets.disco.modules;

import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;

import java.util.function.Consumer;

/**
 * Publish cluster prices as market snapshot.
 */
public class DiscoSnapshotGeneratorModule extends AbstractSignalRegistersCalculationModule {

    final EnumObjTable<Market, Instrument, FilteredMarketDataSnapshotImpl> midRateMap = new EnumObjTable(Market.class,Instrument.class);

    private final Consumer<FilteredMarketDataSnapshot> tobChangedConsumer;

    public DiscoSnapshotGeneratorModule(Consumer<FilteredMarketDataSnapshot> tobChangedConsumer) {
        super(SignalType.CBID, SignalType.CASK);
        this.tobChangedConsumer = tobChangedConsumer;
    }

    @Override
    public void changed(final Signals update, final Signals curr) {
        if (update.getMarket().isInternalAgg()) {  // Allow U,MU,R,BENCH,P
            final double _clusterBid = curr.getSignal(SignalType.CBID).getValue();
            final double _clusterAsk = curr.getSignal(SignalType.CASK).getValue();

            // Ensure positive spread if inverted (but not for WSP_R).
            final boolean shouldInvert = update.getMarket() != Market.WSP_R;
            final boolean inverted = _clusterAsk < _clusterBid;
            final double clusterBid = (inverted && shouldInvert) ? _clusterAsk : _clusterBid;
            final double clusterAsk = (inverted && shouldInvert) ? _clusterBid : _clusterAsk;

            final FilteredMarketDataSnapshotImpl midRate = midRateMap.computeIfAbsent(update.getMarket(),update.getInstrument(),()->FilteredMarketDataSnapshotImpl.forTOB());
            midRate.setMarket(update.getMarket());
            midRate.setInstrument(update.getInstrument());
            midRate.setExternalEventTimeNS(update.getExternalEventTimeNS());
            midRate.setExternalSourceId(update.getExternalSourceId());

            if (clusterBid > 0 && clusterAsk > 0) {
                final MarketDataNewOrderImpl bid = (MarketDataNewOrderImpl) (midRate.getBidEventList().size() == 0 ? midRate.getBidEventList().addFromSupplier() : midRate.getBidEventList().get(0));
                final MarketDataNewOrderImpl ask = (MarketDataNewOrderImpl) (midRate.getOfferEventList().size() == 0 ? midRate.getOfferEventList().addFromSupplier() : midRate.getOfferEventList().get(0));
                bid.setMarket(update.getMarket());
                bid.setPrice(clusterBid);
                bid.setQuantity(1_000_000);
                ask.setMarket(update.getMarket());
                ask.setPrice(clusterAsk);
                ask.setQuantity(1_000_000);
            } else {
                midRate.getBidEventList().clear();
                midRate.getOfferEventList().clear();
            }

            GcFriendlyAssert.isTrue(midRate.getBidEventList().size() <= 1);
            GcFriendlyAssert.isTrue(midRate.getOfferEventList().size() <= 1);

            tobChangedConsumer.accept(midRate);
        }
    }

}
