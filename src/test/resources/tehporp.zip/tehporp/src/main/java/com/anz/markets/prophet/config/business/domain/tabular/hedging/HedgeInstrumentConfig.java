package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

// todo: would be nice if this interface is removed so that the config type heirarchy is simple.
// current code logic relies on HedgeRuleType.
public interface HedgeInstrumentConfig extends ProphetMarshallable {

    /**
     * Target market i.e. market to send order to, for hedging purposes
     */
    Market getMarket();

    Instrument getInstrument();

}
