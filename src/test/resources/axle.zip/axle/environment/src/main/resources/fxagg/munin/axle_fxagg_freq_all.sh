#!/bin/bash
# (c) 2016 ANZ

# Common part of all Munin plugins monitoring price update frequencies

TITLE="Price Update Frequency (All Venues)"
VENUES="EBSD|EBS|RFX|HSP|FAST|CNX|LMAX|FXBK|BARX|CITI|CMZ|DEUT|GS|GCS|MSI|JPM|UBS|ANZD|OCX|DBS|CMEJMP"
COLORS="60BD68|264D00|FF751A|B276B2|5DA5DA|FAA43A|B30000|B3B3B3|004D99|5900B3|B2912F|DECF3F|F17CB0|00B386|4D3319|4863A0|F15854|0091C8|00308F|004D99|B276B2"

# For colors see here: http://www.mulinblog.com/a-color-palette-optimized-for-data-visualization/
# 5DA5DA (blue)         FAST
# FAA43A (pale orange)  CNX
# 60BD68 (green)        EBSD
# F17CB0 (pink)         GS
# B2912F (brown)        CMZ
# B276B2 (purple)       HSP
# DECF3F (yellow)       DEUT
# F15854 (red)          UBS

# Some additional colors
# B3B3B3 (light gray)   FXKB
# 004D99 (dark blue)    BARX
# 264D00 (dark green)   EBS
# 4D3319 (dark brown)   MSI
# FF751A (orange)       RFX
# 5900B3 (dark purple)  CITI
# 00B386 (turkis)       GCS
# 4863A0 (steel blue)   JPM
# B30000 (dark red)     LMAX
# 00308F (dark blue)    OCX

# ANZ BLUE Colors
# 007DBA (light blue)
# 005F90 (darker blue)
# 004165 (dark blue)
# 0091C8 (icon blue)    ANZD

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_freq.common