package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;

import org.junit.Test;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link SimpleDateDecoder}
 */
public class SimpleDateDecoderTest {

    @Test(expected = NullPointerException.class)
    public void noNullSupplier() {
        SimpleDateDecoder.forSupplier(null);
    }

    @Test
    public void decodeLocalDateOrNull() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final LocalDate output = dec.decodeLocalDateOrNull();

        //then
        assertEquals("output not as expected", LocalDate.of(2017, 03, 14), output);
    }

    @Test
    public void decodeNull() {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(null);

        //when + then
        assertEquals("localDate should be null", null, dec.decodeLocalDateOrNull());
        assertEquals("year should be 0", 0, dec.decodeYear());
        assertEquals("month should be 0", 0, dec.decodeMonth());
        assertEquals("day should be 0", 0, dec.decodeDay());
        assertEquals("epochDays should be 0", 0, dec.decodeEpochDays());
        assertEquals("epochSeconds should be 0", 0, dec.decodeEpochSeconds());
        assertEquals("epochMillis should be 0", 0, dec.decodeEpochMillis());
        assertEquals("binary packed value should be 0", 0, dec.decodePacked(LocalDatePacking.BINARY));
        assertEquals("decimal packed valueshould be 0", 0, dec.decodePacked(LocalDatePacking.DECIMAL));
    }

    @Test
    public void decodePacked() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final int packedBinary = dec.decodePacked(LocalDatePacking.BINARY);
        final int packedDecimal = dec.decodePacked(LocalDatePacking.DECIMAL);

        //then
        assertEquals("packed binary value not as expected", LocalDatePacking.BINARY.pack(2017, 03, 14), packedBinary);
        assertEquals("packed decimal value not as expected", 20170314, packedDecimal);
    }

    @Test
    public void decodeEpochMillis() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final long epochMillis = dec.decodeEpochMillis();

        //then
        assertEquals("epochMillis not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.MILLIS_PER_DAY, epochMillis);
    }

    @Test
    public void decodeEpochSeconds() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final long epochSeconds = dec.decodeEpochSeconds();

        //then
        assertEquals("epochSeconds not as expected", LocalDate.of(2017, 03, 14).toEpochDay() * Epoch.SECONDS_PER_DAY, epochSeconds);
    }

    @Test
    public void decodeEpochDays() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final long epochDays = dec.decodeEpochDays();

        //then
        assertEquals("epochDays not as expected", LocalDate.of(2017, 03, 14).toEpochDay(), epochDays);
    }

    @Test
    public void decodeYear() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final int year = dec.decodeYear();

        //then
        assertEquals("year not as expected", 2017, year);
    }

    @Test
    public void decodeMonth() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final int month = dec.decodeMonth();

        //then
        assertEquals("month not as expected", 03, month);
    }

    @Test
    public void decodeDay() throws Exception {
        final SimpleDateDecoder dec = SimpleDateDecoder.forLocalDate(LocalDate.of(2017, 03, 14));

        //when
        final int day = dec.decodeDay();

        //then
        assertEquals("day not as expected", 14, day);
    }

}