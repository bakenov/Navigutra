package com.anz.markets.efx.fox.codec.api;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface VenueConfigHandler extends MessageDecoder.Handler {
    @Override
    default void onMessageStart(final int source, final long sourceSeq) {
    }

    void onBody(Body body);

    @Override
    default void onMessageComplete() {
    }

    interface Body {
        Venue venue();
        StringDecoder compId();
        EnumerableSetDecoder<VenueCategory> venueCategories();
        boolean enabled();
    }

    @FunctionalInterface
    interface DecoderFactory<M> extends MessageDecoder.Factory<M, VenueConfigHandler>, SorDecoders.DecoderFactory<M> {
        @Override
        default MessageDecoder<M> create(final SorHandlerSupplier sorHandlerSupplier, final MessageDecoder.ForwardingLookup<M> forwardingLookup) {
            return create((Supplier<VenueConfigHandler>) sorHandlerSupplier::venueConfigHandler, forwardingLookup);
        }
    }
}
