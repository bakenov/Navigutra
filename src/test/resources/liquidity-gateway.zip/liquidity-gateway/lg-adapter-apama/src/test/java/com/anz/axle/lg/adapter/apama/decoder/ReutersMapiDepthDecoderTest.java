package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.LongSupplier;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.mockito.InOrder;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.event.Depth;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;

import static com.anz.axle.lg.adapter.apama.decoder.ReutersMapiDepthDecoder.getMapiSendingTimeNanos;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link ReutersMapiDepthDecoder}
 */
@RunWith(Parameterized.class)
public class ReutersMapiDepthDecoderTest {
    private static final EventParser APAMA_EVENT_PARSER = new EventParser(
            Depth.EVENT_TYPE);

    private final DecoderTestMode mode;

    //mocks
    private String senderCompId = "GB:XXX";
    private String compId = "GB:lg-xxx";
    //mocks
    private VenueRequestKeyLookup requestKeyLookup;
    private PricingEncoderLookup pricingEncoderLookup;
    private MockitoPricingEncoder encoders;
    private PricingEncoderSupplier encoderSupplier;
    private LongSupplier messageIdSupplier;
    private InOrder inOrder;
    private PrecisionClock precisionClock;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    //under test
    private ReutersMapiDepthDecoder reutersMapiDepthDecoder;

    @Parameterized.Parameters
    public static Collection<DecoderTestMode> testParameters() {
        return Arrays.asList(DecoderTestMode.values());
    }

    private static final Map<String, String> MAPI_SYMBOL_MAP = new HashMap<>();

    static {
        MAPI_SYMBOL_MAP.put("AUDCAD=", "AUD/CAD");
        MAPI_SYMBOL_MAP.put("AUDJPY=", "AUD/JPY");
        MAPI_SYMBOL_MAP.put("AUD=", "AUD/USD");
        MAPI_SYMBOL_MAP.put("CAD=", "USD/CAD");
    }

    private static final long CURRENT_TIME = 34523453;

    public ReutersMapiDepthDecoderTest(final DecoderTestMode mode) {
        this.mode = Objects.requireNonNull(mode);
    }

    @Before
    public void beforeEach() {
        //initialise mocks
        encoders = new MockitoPricingEncoder();

        precisionClock = mock(PrecisionClock.class);
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);

        messageIdSupplier = mock(LongSupplier.class);
        when(messageIdSupplier.getAsLong()).thenReturn(10L);

        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.EBS);

        encoderSupplier = mock(PricingEncoderSupplier.class, RETURNS_MOCKS);
        when(encoderSupplier.incrementalRefresh()).thenReturn(encoders.incrementalEncoder);
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);

        final PricingEncoderSupplier modedEncoderSupplier = mode.encoderSupplier(encoderSupplier);

        pricingEncoderLookup = mock(PricingEncoderLookup.class);
        when(pricingEncoderLookup.lookup(any())).thenReturn(modedEncoderSupplier);

        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotEntries_next,
                encoders.snapshotEntries_body,

                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),

                encoders.messageEncoder);

        //under test
        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.RFX);
        reutersMapiDepthDecoder = new ReutersMapiDepthDecoder(requestKeyLookup, pricingEncoderLookup, precisionClock, MAPI_SYMBOL_MAP, senderCompId, compId, messageIdSupplier, sourceSequencer);
    }

    @Test
    public void shouldDecode_ReutersMapiDepth() throws Exception {
        //given
        final String dateStr = "27 AUG 2013";
        final String msSinceMidnight = "15596503";
        final String evtStr = "com.apama.marketdata.Depth(\"CAD=\"," +
                "[1.0511,1.051,1.0509]," +
                "[1.0513,1.0514,1.0515]," +
                "[1.0512,1.0511999,1.0511999]," +
                "[7000000,12000000,8000000]," +
                "[6000000,24000000,35000000]," +
                "{\"Screened_Price\":\"true\",\"TCID\":\"NNHC\",\"BID\":\"1.0509\",\"QUOTE_DATE\":\"" +
                dateStr + "\",\"REG_AMOUNT\":\"35\",\"PRIMACT_1\":\"1.0502\",\"QUOTIM_MS\":\"" +
                msSinceMidnight + "\",\"ASK\":\"1.0514\",\"SEQ_NO\":\"126813\",\"VALUE_TS1\":\"00:04:36:501\",\"ACT_TP_1\":\" B\",\"PRICETHOLD\":\"0.002\",\"STD_AMOUNT\":\"20\",\"BOOK_DEPTH\":\"3\",\"VALUE_DT1\":\"27 AUG 2013\",\"Market\":\"ReutersRFATransport\",\"SERVICE_NAME\":\"MAPI\"})\n";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        reutersMapiDepthDecoder.decode(evt);

        //then:
        long sendingTime = getMapiSendingTimeNanos(dateStr, msSinceMidnight);
        assertThat(Long.valueOf(sendingTime), Matchers.greaterThan(0L));
        verifySnapshotBodyFields(Venue.RFX, "USDCAD", 6, sendingTime);
        verifyEntry(sendingTime, Venue.RFX, EntryType.BID, 1.0511, 7000000);
        verifyEntry(sendingTime, Venue.RFX, EntryType.BID,   1.0510, 12000000);
        verifyEntry(sendingTime, Venue.RFX, EntryType.BID,   1.0509, 8000000);
        verifyEntry(sendingTime, Venue.RFX, EntryType.OFFER, 1.0513, 6000000);
        verifyEntry(sendingTime, Venue.RFX, EntryType.OFFER, 1.0514, 24000000);
        verifyEntry(sendingTime, Venue.RFX, EntryType.OFFER, 1.0515, 35000000);
    }

    @Test
    public void shouldDecode_WhenBrokenDate() throws Exception {
        //given
        final String dateStr = "RUBBISH";
        final String evtStr = "com.apama.marketdata.Depth(\"CAD=\"," +
                "[1.0511,1.051,1.0509]," +
                "[1.0513,1.0514,1.0515]," +
                "[1.0512,1.0511999,1.0511999]," +
                "[7000000,12000000,8000000]," +
                "[6000000,24000000,35000000]," +
                "{\"Screened_Price\":\"true\",\"TCID\":\"NNHC\",\"BID\":\"1.0509\",\"QUOTE_DATE\":\"" +
                dateStr + "\",\"REG_AMOUNT\":\"35\",\"PRIMACT_1\":\"1.0502\",\"ASK\":\"1.0514\",\"SEQ_NO\":\"126813\",\"VALUE_TS1\":\"00:04:36:501\",\"ACT_TP_1\":\" B\",\"PRICETHOLD\":\"0.002\",\"STD_AMOUNT\":\"20\",\"BOOK_DEPTH\":\"3\",\"VALUE_DT1\":\"27 AUG 2013\",\"Market\":\"ReutersRFATransport\",\"SERVICE_NAME\":\"MAPI\"})\n";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        reutersMapiDepthDecoder.decode(evt);

        //then:
        verifySnapshotBodyFields(Venue.RFX, "USDCAD", 6, 0L);
        verifyEntry(0L, Venue.RFX, EntryType.BID, 1.0511, 7000000);
        verifyEntry(0L, Venue.RFX, EntryType.BID,   1.0510, 12000000);
        verifyEntry(0L, Venue.RFX, EntryType.BID,   1.0509, 8000000);
        verifyEntry(0L, Venue.RFX, EntryType.OFFER, 1.0513, 6000000);
        verifyEntry(0L, Venue.RFX, EntryType.OFFER, 1.0514, 24000000);
        verifyEntry(0L, Venue.RFX, EntryType.OFFER, 1.0515, 35000000);
    }

    @Test
    public void shouldDoNothing_BidsAsksArraysSizesMismatch() throws Exception {
        //given
        final String evtStr = "com.apama.marketdata.Depth(\"CAD=\"," +
                "[1.0511,1.051,1.0509]," +
                "[1.0513,1.0514,1.0515]," +
                "[1.0512,1.0511,1.0511]," +
                "[7000000]," +
                "[6000000,24000000]," +
                "{\"Screened_Price\":\"true\",\"TCID\":\"NNHC\",\"BID\":\"1.0509\",\"QUOTE_DATE\":\"27 AUG 2013\",\"REG_AMOUNT\":\"35\",\"PRIMACT_1\":\"1.0502\",\"QUOTIM_MS\":\"15596503\",\"ASK\":\"1.0514\",\"SEQ_NO\":\"126813\",\"VALUE_TS1\":\"00:04:36:501\",\"ACT_TP_1\":\" B\",\"PRICETHOLD\":\"0.002\",\"STD_AMOUNT\":\"20\",\"BOOK_DEPTH\":\"3\",\"VALUE_DT1\":\"27 AUG 2013\",\"Market\":\"ReutersRFATransport\",\"SERVICE_NAME\":\"MAPI\"})\n";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        reutersMapiDepthDecoder.decode(evt);

        //then:
        verifyZeroInteractions(encoders.pricingEncoders);
    }

    @Test
    public void shouldDoNothing_NonReutersMapiDepth() throws Exception {
        //given
        final String serviceName = "NOT_MAPI";
        final String evtStr = "com.apama.marketdata.Depth(\"CAD=\",[1.0511,1.051,1.0509],[1.0513,1.0514,1.0515],[1.0512,1.0511999,1.0511999],[7000000,12000000,8000000],[6000000,24000000,35000000],{\"Screened_Price\":\"true\",\"TCID\":\"NNHC\",\"BID\":\"1.0509\",\"QUOTE_DATE\":\"27 AUG 2013\",\"REG_AMOUNT\":\"35\",\"PRIMACT_1\":\"1.0502\",\"QUOTIM_MS\":\"15596503\",\"ASK\":\"1.0514\",\"SEQ_NO\":\"126813\",\"VALUE_TS1\":\"00:04:36:501\",\"ACT_TP_1\":\" B\",\"PRICETHOLD\":\"0.002\",\"STD_AMOUNT\":\"20\",\"BOOK_DEPTH\":\"3\",\"VALUE_DT1\":\"27 AUG 2013\",\"Market\":\"ReutersRFATransport\",\"SERVICE_NAME\":\"" + serviceName + "\"})\n";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        reutersMapiDepthDecoder.decode(evt);

        //then:
        verifyZeroInteractions(encoders.pricingEncoders);
    }

    @Test
    public void shouldDoNothing_NonCreditCheckedPrices() throws Exception {
        //given
        final String screenedPrice = "false";
        final String evtStr = "com.apama.marketdata.Depth(\"CAD=\",[1.0511,1.051,1.0509],[1.0513,1.0514,1.0515],[1.0512,1.0511999,1.0511999],[7000000,12000000,8000000],[6000000,24000000,35000000],{\"Screened_Price\":\"" + screenedPrice + "\",\"TCID\":\"NNHC\",\"BID\":\"1.0509\",\"QUOTE_DATE\":\"27 AUG 2013\",\"REG_AMOUNT\":\"35\",\"PRIMACT_1\":\"1.0502\",\"QUOTIM_MS\":\"15596503\",\"ASK\":\"1.0514\",\"SEQ_NO\":\"126813\",\"VALUE_TS1\":\"00:04:36:501\",\"ACT_TP_1\":\" B\",\"PRICETHOLD\":\"0.002\",\"STD_AMOUNT\":\"20\",\"BOOK_DEPTH\":\"3\",\"VALUE_DT1\":\"27 AUG 2013\",\"Market\":\"ReutersRFATransport\",\"SERVICE_NAME\":\"MAPI\"})\n";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        reutersMapiDepthDecoder.decode(evt);

        //then:
        verifyZeroInteractions(encoders.pricingEncoders);
    }

    @Test
    public void shouldDoNothing_UnknownCurrency() throws Exception {
        //given
        final String symbol = "DUDE=";
        final String evtStr = "com.apama.marketdata.Depth(\"" + symbol + "\",[1.0511],[1.0513],[1.0512],[7000000],[6000000],{\"Screened_Price\":\"true\",\"TCID\":\"NNHC\",\"BID\":\"1.0509\",\"QUOTE_DATE\":\"27 AUG 2013\",\"REG_AMOUNT\":\"35\",\"PRIMACT_1\":\"1.0502\",\"QUOTIM_MS\":\"15596503\",\"ASK\":\"1.0514\",\"SEQ_NO\":\"126813\",\"VALUE_TS1\":\"00:04:36:501\",\"ACT_TP_1\":\" B\",\"PRICETHOLD\":\"0.002\",\"STD_AMOUNT\":\"20\",\"BOOK_DEPTH\":\"3\",\"VALUE_DT1\":\"27 AUG 2013\",\"Market\":\"ReutersRFATransport\",\"SERVICE_NAME\":\"MAPI\"})\n";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        reutersMapiDepthDecoder.decode(evt);

        //then:
        verifyZeroInteractions(encoders.pricingEncoders);
    }

    private void verifySnapshotBodyFields(final Venue venue,
                                          final String symbol,
                                          final int entriesCount,
                                          final long sendingTimeNanos) {
        inOrder.verify(encoders.snapshotBody).sendingTime(sendingTimeNanos);
        inOrder.verify(encoders.snapshotBody).instrumentId(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        inOrder.verify(encoders.snapshotBody).marketId(venue);
        if (entriesCount > 0) {
            inOrder.verify(encoders.snapshotBody).entriesStart(entriesCount);
        } else {
            inOrder.verify(encoders.snapshotBody).entriesEmpty();
        }
    }

    private void verifyEntry(final long transactTimeNanos,
                             final Venue venue,
                             final EntryType side,
                             final double price,
                             final double quantity) {

        inOrder.verify(encoders.snapshotEntries_body).transactTime(transactTimeNanos);
        inOrder.verify(encoders.snapshotEntries_body).mdMkt(venue);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryType(side);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryPx(price);
        inOrder.verify(encoders.snapshotEntries_body).mdEntrySize(quantity);
        inOrder.verify(encoders.snapshotEntries_body).minQty(0);
    }

}