package com.anz.axle.adapters.ndf2trep.acceptance;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.collect.Lists;
import com.reuters.rfa.config.ConfigProvider;

import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.markets.adapters.trep.Item;
import com.anz.markets.adapters.trep.config.ConfigElement;
import com.anz.markets.adapters.trep.config.Connection;
import com.anz.markets.adapters.trep.config.MapConfigProvider;
import com.anz.markets.adapters.trep.config.SSLConnection;
import com.anz.markets.adapters.trep.config.Session;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.stub.Source;
import com.anz.markets.efx.messaging.transport.stub.StubbedTransport;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingDecoders;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.base.PricingTranslator;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingDecoders;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;

@Configuration
public class NdfTrepSubscriptionConfig {

    @Bean
    ArrayBlockingQueue<PricingMessage> pricingMessageQueue() {
        return new ArrayBlockingQueue<>(100);
    }

    @Bean
    public Transport transport(final ArrayBlockingQueue<PricingMessage> pricingMessageQueue) {

        final LongSupplier nanoTimeSource = () -> 0L;
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final PricingTranslator<PricingMessage> pojo2SbeTranslator = pricingMessagePojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), nanoTimeSource.getAsLong())
        );
        final Source pricingSource = (topic, messageHandler) -> {
            final PricingMessage pojoPricingMessage = pricingMessageQueue.poll();
            if (pojoPricingMessage != null) {
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoPricingMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };

        return StubbedTransport.builder()
                .sources(subscriptionTopic -> pricingSource)
                .build();
    }

    @Bean
    public Connection testTrepSubscriberConnection(@Value("${ndf.trep.subscription.host}") final String hostName,
                                                   @Value("${ndf.trep.subscription.port}") final int port,
                                                   @Value("${ndf.trep.subscription.ipcTrace:0x10}") final int ipcTraceFlags,
                                                   @Value("${ndf.trep.subscription.dacsCbeEnabled:false}") final boolean dacsCbeEnabled,
                                                   @Value("${ndf.trep.subscription.dacsGenerateLocks:false}") final boolean dacsGenerateLocks,
                                                   @Value("${ndf.trep.subscription.dacsSbePubEnabled:false}") final boolean dacsSbePubEnabled,
                                                   @Value("${ndf.trep.subscription.dacsSbeSubEnabled:false}") final boolean dacsSbeSubEnabled,

                                                   @Value("${ndf.trep.subscription.downloadDataDictionary:true}") final boolean downloadDataDict
    ) {
        final SSLConnection connection = new SSLConnection("MarketDataSubscriberConnection");
        connection.setConnectionType("SSL");
        connection.setPortNumber(port);
        connection.setDacsCbeEnabled(dacsCbeEnabled);
        connection.setDacsGenerateLocks(dacsGenerateLocks);
        connection.setDacsSbePubEnabled(dacsSbePubEnabled);
        connection.setDacsSbeSubEnabled(dacsSbeSubEnabled);
        connection.setServerList(hostName);
        connection.setIpcTraceFlags(ipcTraceFlags);
        connection.setLogFileName("test-ndf-trep-subscriber.log");
        connection.setDownloadDataDict(downloadDataDict);
        connection.setMountTrace(true);
        return connection;
    }

    @Bean
    public Session testTrepSubscriberSession() {
        final Session session = new Session("MarketDataSubscriberSession");
        session.setConnectionList("MarketDataSubscriberConnection");
        return session;
    }

    @Bean
    public ConfigProvider testTrepSubscriberConfigProvider(@Qualifier("testTrepSubscriberConnection") final Connection trepSubscriberConnection,
                                                           @Qualifier("testTrepSubscriberSession") final Session trepSubscriberSession) {
        List<ConfigElement> config = new ArrayList<>();
        config.add(trepSubscriberSession);
        config.add(trepSubscriberConnection);
        return new MapConfigProvider(config);
    }

    @Bean
    public MessageProcessor<Item> testRateProcessor() {
        return new TestMessageProcessor();
    }

    @Bean
    @Autowired
    public TrepRateSubscriber testTrepNdfSubscriber (
            @Value("${ndf.trep.subscription.ndf.user}") final String subscribingUser,
            @Qualifier("testTrepSubscriberConfigProvider") final ConfigProvider configProvider,
            final RicRepository ricRepository,
            @Value("${ndf.trep.publish.destination.servicename}") final String publishServiceName,
            final MessageProcessor<Item> testRateProcessor) {
        final TrepRateSubscriber trepRateSubscriber = new TrepRateSubscriber(publishServiceName, testRateProcessor);
        trepRateSubscriber.setSessionName("MarketDataSubscriberSession");
        trepRateSubscriber.setServiceName(publishServiceName);

        trepRateSubscriber.setUser(subscribingUser);
        trepRateSubscriber.setItemProvider(() -> Lists.newArrayList(ricRepository.getRicNames(publishServiceName)));
        trepRateSubscriber.setConfigProvider(configProvider);
        return trepRateSubscriber;
    }

    private PricingTranslator<PricingMessage> pricingMessagePojo2SbeTranslator(final Consumer<? super SbeMessage> pojoMessageConsumer) {
        final PricingDecoders<PricingMessage> pojoPricingDecoders = new PojoPricingDecoders();

        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final PricingEncoders<SbeMessage> sbePricingMessageEncoders = new SbePricingEncoders(() -> sbeMessage);

        return PricingTranslator.create(pojoPricingDecoders.snapshotFullAndIncrementalRefresh(), sbePricingMessageEncoders.toPricingEncoderSupplier(pojoMessageConsumer));
    }

    @Bean
    public ExecutorService connectionPoller(final com.anz.markets.efx.messaging.transport.api.Connection connection) {
        final ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(() -> connection.pollingStrategy().processNext(), 100, 100, TimeUnit.MILLISECONDS);
        return scheduledExecutorService;
    }

}
