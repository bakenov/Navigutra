package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.HeaderDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface FirewallConfigDecoder extends HeaderDecoder {
    Body body();
    void appendTo(StringBuilder stringBuilder);

    interface Body {
        StringDecoder firewallName();
        long ruleId();
        StringDecoder regionPattern();
        StringDecoder orderTypePattern();
        StringDecoder deskPattern();
        StringDecoder portfolioPattern();
        StringDecoder usernamePattern();
        StringDecoder venuePattern();
        StringDecoder securityTypePattern();
        StringDecoder tenorPattern();
        StringDecoder symbolPattern();
        long period();
        StringDecoder periodUnit();
        boolean local();
        StringDecoder comment();
        StringDecoder lastEditUsername();
        long lastEditTime();
        double limitThreshold();
    }
}
