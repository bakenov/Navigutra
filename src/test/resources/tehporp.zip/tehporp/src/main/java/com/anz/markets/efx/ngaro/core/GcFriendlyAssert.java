package com.anz.markets.efx.ngaro.core;

import com.anz.markets.efx.ngaro.math.DoubleTools;

import java.util.Collection;
import java.util.function.DoublePredicate;
import java.util.function.IntPredicate;
import java.util.function.LongPredicate;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * Alternative "implementation" of Assert functionality that uses varargs to defer the string formatting util the assertion fails.
 */
public class GcFriendlyAssert {
    private static final RangeExceptionDesciption rangeExceptionDesciption = new RangeExceptionDesciption();

    /**
     * Assert that an object is not null .
     *
     * @param value  - the object to check
     * @param format - format string
     * @param arg1   - format string parameters
     * @return value so that you can use it again
     * @throws IllegalArgumentException - if the object is null
     */
    public static <R> R notNull(final R value,
                                final String format,
                                final Object arg1) {
        if (value == null) {
            throwExceptionIfAssertionIsEnabled(format, arg1);
        }
        return value;
    }

    public static <R> R notNull(final R value,
                                final String format,
                                final Object arg1,
                                final Object arg2) {
        if (value == null) {
            throwExceptionIfAssertionIsEnabled(format, arg1, arg2);
        }
        return value;
    }

    public static <R> R notNull(final R value,
                                final Supplier<String> message) {
        if (value == null) {
            throwExceptionIfAssertionIsEnabled(message.get());
        }
        return value;
    }

    /**
     * Assert that an object is not null .
     *
     * @return value so that you can use it again
     * @throws IllegalArgumentException - if the object is null
     */
    public static <R> R notNull(final R value,
                                final String message) {
        if (value == null) {
            throwExceptionIfAssertionEnabled(message);
        }
        return value;
    }

    /**
     * Assert that an object is not null .
     *
     * @param value - the object to check
     * @return value so that you can use it again
     * @throws IllegalArgumentException - if the object is null
     */
    public static <R> R notNull(final R value) {
        if (value == null) {
            throwExceptionIfAssertionIsEnabled();
        }
        return value;
    }

    /**
     * Assert that an object is null .
     *
     * @throws IllegalArgumentException - if the object is not null
     */
    public static void isNull(final Object value,
                              final String format,
                              final Object... varargs) {
        if (value != null) {
            throwExceptionIfAssertionIsEnabled(format, varargs);
        }
    }

    /**
     * Assert that an object is null .
     *
     * @throws IllegalArgumentException - if the object is not null
     */
    public static void isNull(final Object value,
                              final String message) {
        if (value != null) {
            throwExceptionIfAssertionEnabled(message);
        }
    }

    /**
     * Assert a boolean expression is true, throwing IllegalArgumentException if the test fails.
     *
     * @param expression - a boolean expression
     * @param format     - the exception message format to use if the assertion fails
     * @param arg        - format parameter
     */
    public static boolean isTrue(final boolean expression,
                                 final String format,
                                 final Object arg) {
        if (!expression) {
            throwExceptionIfAssertionIsEnabled(format, arg);
        }
        return true;
    }

    /**
     * Assert a boolean expression is true, throwing IllegalArgumentException if the test fails.
     *
     * @param expression - a boolean expression
     * @param format     - the exception message format to use if the assertion fails
     * @param arg1       - format parameter
     * @param arg2       - format parameter
     */
    public static boolean isTrue(final boolean expression,
                                 final String format,
                                 final Object arg1,
                                 final Object arg2) {
        if (!expression) {
            throwExceptionIfAssertionIsEnabled(format, arg1, arg2);
        }
        return true;
    }

    public static boolean isTrue(final boolean expression,
                                 final String format,
                                 final Object arg1,
                                 final Object arg2,
                                 final Object arg3,
                                 final Object arg4) {
        if (!expression) {
            throwExceptionIfAssertionIsEnabled(format, arg1, arg2, arg3, arg4);
        }
        return true;
    }

    public static void fail(final String format, final Object... varargs) {
        throwExceptionIfAssertionIsEnabled(format, varargs);
    }

    /**
     * Assert a boolean expression is true, throwing IllegalArgumentException if the test fails.
     *
     * @param expression - a boolean expression
     * @param format     - the exception message format to use if the assertion fails
     * @param varargs    - format parameters
     */
    public static boolean isTrue(final boolean expression,
                                 final String format,
                                 final Object... varargs) {
        if (!expression) {
            throwExceptionIfAssertionIsEnabled(format, varargs);
        }
        return true;
    }

    public static void withinRange(final double lowerBound, final double upperBound, final double value, final String format, final Object... varargs) {
        final boolean expressionGreaterThan = DoubleTools.isGreaterThanOrEqual(value, lowerBound);
        final boolean expressionLessThan = DoubleTools.isLessThanOrEqual(value, upperBound);
        if (!(expressionGreaterThan && expressionLessThan)) {
            rangeExceptionDesciption.set(lowerBound, upperBound, value, format, varargs);
            throw new IllegalArgumentException(rangeExceptionDesciption.toString());
        }
    }

    private static class RangeExceptionDesciption {
        double lowerBound;
        double upperBound;
        double value;
        String format;
        Object varargs[];

        public void set(final double lowerBound, final double upperBound, final double value, String format, Object...varargs) {
            this.lowerBound = lowerBound;
            this.upperBound = upperBound;
            this.value = value;
            this.format = format;
            this.varargs = varargs;
        }

        @Override
        public String toString() {
            return "not within range: lowerBound<=number<=upperBound is :(" + lowerBound + "<=" + value + "<=" + upperBound + ")"  + String.format(format, varargs);
        }
    }

    /**
     * Assert a boolean expression is true, throwing IllegalArgumentException if the test fails.
     */
    public static boolean isTrue(final boolean expression,
                                 final String message) {
        if (!expression) {
            throwExceptionIfAssertionEnabled(message);
        }
        return true;
    }

    /**
     * Assert a boolean expression is true, throwing IllegalArgumentException if the test fails.
     */
    public static boolean isTrue(final boolean expression) {
        if (!expression) {
            throwExceptionIfAssertionIsEnabled();
        }
        return true;
    }

    /**
     * Assert a boolean expression is false, throwing IllegalArgumentException if the test fails.
     */
    public static boolean isFalse(final boolean expression,
                                  final String format,
                                  final Object arg1) {
        if (expression) {
            throwExceptionIfAssertionIsEnabled(format, arg1);
        }
        return false;
    }

    /**
     * Assert a boolean expression is false, throwing IllegalArgumentException if the test fails.
     */
    public static boolean isFalse(final boolean expression,
                                  final String format,
                                  final Object arg1,
                                  final Object arg2) {
        if (expression) {
            throwExceptionIfAssertionIsEnabled(format, arg1, arg2);
        }
        return false;
    }

    /**
     * Assert a boolean expression is false, throwing IllegalArgumentException if the test fails.
     */
    public static boolean isFalse(final boolean expression,
                                  final String format,
                                  final Object arg1,
                                  final Object arg2,
                                  final Object arg3) {
        if (expression) {
            throwExceptionIfAssertionIsEnabled(format, arg1, arg2, arg3);
        }
        return false;
    }

    /**
     * Assert a boolean expression is false, throwing IllegalArgumentException if the test fails.
     */
    public static boolean isFalse(final boolean expression,
                                  final String message) {
        if (expression) {
            throwExceptionIfAssertionEnabled(message);
        }
        return false;
    }

    /**
     * Assert a boolean expression is false, throwing IllegalArgumentException if the test fails.
     *
     * @param expression - a boolean expression
     */
    public static boolean isFalse(final boolean expression) {
        if (expression) {
            throwExceptionIfAssertionIsEnabled();
        }
        return false;
    }

    /**
     * Assert that a collection has elements; that is, it must not be null and must have at least one element.
     *
     * @param collection - the collection to check
     * @param format     - format string
     * @param varargs    - format string parameters
     * @return collection so that you can use it again
     * @throws IllegalArgumentException - if the collection is null or has no elements
     */
    public static <R extends Collection> R notEmpty(final R collection,
                                                    final String format,
                                                    final Object... varargs) {
        if (collection == null || collection.isEmpty()) {
            throwExceptionIfAssertionIsEnabled(format, varargs);
        }
        return collection;
    }

    /**
     * Assert that a collection has elements; that is, it must not be null and must have at least one element.
     *
     * @throws IllegalArgumentException - if the collection is null or has no elements
     */
    public static <R extends Collection> R notEmpty(final R collection,
                                                    final String message) {
        if (collection == null || collection.isEmpty()) {
            throwExceptionIfAssertionEnabled(message);
        }
        return collection;
    }

    /**
     * Assert that a collection has elements; that is, it must not be null and must have at least one element.
     *
     * @param collection - the collection to check
     * @return collection so that you can use it again
     * @throws IllegalArgumentException - if the collection is null or has no elements
     */
    public static <R extends Collection> R notEmpty(final R collection) {
        if (collection == null || collection.isEmpty()) {
            throwExceptionIfAssertionIsEnabled();
        }
        return collection;
    }

    /**
     * Assert that a string is not blank (null, empty, or contains nothing but whitespace).
     *
     * @param value   - the string to check
     * @param format  - format string
     * @param varargs - format string parameters
     * @return value so that you can use it again
     * @throws IllegalArgumentException - if the string is blank
     */
    public static String notBlank(final String value,
                                  final String format,
                                  final Object... varargs) {
        if (value == null || "".equals(value)) {
            throwExceptionIfAssertionIsEnabled(format, varargs);
        }
        return value;
    }

    public static String hasMaxLength(final int maxLength,
                                      final String value) {
        if (value != null) {
            if (value.length() > maxLength) {
                throwExceptionIfAssertionIsEnabled();
            }
        }
        return value;
    }

    public static <T> T is(final T t,
                           final Predicate<? super T> rule) {
        if (!rule.test(t)) {
            throwExceptionIfAssertionIsEnabled();
        }
        return t;
    }

    public static double isDouble(final double d, final DoublePredicate predicate) {
        if (!predicate.test(d)) {
            throwExceptionIfAssertionIsEnabled();
        }
        return d;
    }

    public static long isLong(final long l, final LongPredicate predicate) {
        if (!predicate.test(l)) {
            throwExceptionIfAssertionIsEnabled();
        }
        return l;
    }

    public static int isInt(final int i, final IntPredicate predicate) {
        if (!predicate.test(i)) {
            throwExceptionIfAssertionIsEnabled();
        }
        return i;
    }

    public static DoublePredicate greaterThanDouble(final double minimum) {
        return value -> value > minimum;
    }

    public static LongPredicate greaterThanLong(final long minimum) {
        return value -> value > minimum;
    }

    public static LongPredicate greaterEqualThanLong(final long minimum) {
        return value -> value >= minimum;
    }

    public static IntPredicate greaterThanInt(final int minimum) {
        return value -> value > minimum;
    }

    /**
     * Assert a double is not NaN, throwing IllegalArgumentException if the test fails.
     *
     * @param expression - a double
     * @param format     - the exception message format to use if the assertion fails
     * @param arg        - format parameter
     */
    public static double notNaN(final double expression,
                                final String format,
                                final Object arg) {
        if (Double.isNaN(expression)) {
            throwExceptionIfAssertionIsEnabled(format, arg);
        }
        return expression;
    }

    public static double notNaN(final double expression,
                                final String format,
                                final Object arg1, final Object arg2) {
        if (Double.isNaN(expression)) {
            throwExceptionIfAssertionIsEnabled(format, arg1, arg2);
        }
        return expression;
    }

    /**
     * Assert a double is not NaN, throwing IllegalArgumentException if the test fails.
     *
     * @param expression - a double
     * @param message    - the exception message
     */
    public static double notNaN(final double expression,
                                final String message) {
        if (Double.isNaN(expression)) {
            throwExceptionIfAssertionIsEnabled(message);
        }
        return expression;
    }

    @SuppressWarnings("unchecked")
    public static <E> E isClass(Object o, Class<E> target) throws IllegalArgumentException {
        // throw ClassCastException if it can't cast
        return target.cast(o);
    }

    private static void throwExceptionIfAssertionIsEnabled() {
        throw new IllegalArgumentException();
    }

    private static void throwExceptionIfAssertionEnabled(final String message) {
        throw new IllegalArgumentException(message);
    }

    private static void throwExceptionIfAssertionIsEnabled(final String format, final Object... varargs) {
        throw new IllegalArgumentException(String.format(format, varargs));
    }

}
