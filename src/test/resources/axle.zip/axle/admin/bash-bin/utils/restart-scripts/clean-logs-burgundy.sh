#!/bin/bash

#Correlator
ssh AxlSv@daxa020z "find ~/logs -type f -delete"
ssh AxlSv@daxa005z "find ~/logs -type f -delete"
ssh AxlSv@daxa002z "find ~/logs -type f -delete"

#Proxy broker
ssh AxlSv@daxa020z "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
ssh AxlSv@daxa005z "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
ssh AxlSv@daxa002z "rm -rf ~/apache-tomcat/logs/* ~/apache-tomcat/bin/*.log ~/apache-tomcat/bin/*.dat"
