package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.Parties_PartyIDsGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.TradeCaptureReport_SidesGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.TradeCaptureReport_SidesGrp_PartyIDsGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradeCaptureReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultExecutionReport;
import net.openhft.chronicle.bytes.Bytes;
import org.agrona.collections.LongArrayList;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.TRIGGERED_OR_ACTIVATED_BY_SYSTEM;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdStatus.FILLED;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdStatus.PARTIALLY_FILLED;

public class ExecutionReportMerger {

    private final LongArrayList pendingDealsQuantities = new LongArrayList();
    private final DefaultExecutionReport executionReport = new DefaultExecutionReport();
    private char resetExecTypeToCancelled = ExecType.NEW;

    public ExecutionReport merge(final TradeCaptureReport tradeCaptureReport) {

        removePendingDealQty((long)tradeCaptureReport.lastQty());
        executionReport.msgSeqNum(tradeCaptureReport.msgSeqNum());
        executionReport.sendingTime(tradeCaptureReport.sendingTime());

        executionReport.execID(tradeCaptureReport.execID());
        executionReport.lastPx(tradeCaptureReport.lastPx());
        executionReport.lastQty(tradeCaptureReport.lastQty());
        executionReport.transactTime(tradeCaptureReport.transactTime());
        executionReport.settlDate(tradeCaptureReport.settlDate());
        executionReport.tradeDate(tradeCaptureReport.tradeDate());

        final double cumQty = executionReport.cumQty() + tradeCaptureReport.lastQty();
        executionReport.cumQty(cumQty);
        executionReport.leavesQty(executionReport.orderQty() - cumQty);

        if (executionReport.execType() == ExecType.CANCELED || executionReport.execType() == TRIGGERED_OR_ACTIVATED_BY_SYSTEM) {
            if (havePendingDeals()) {
                resetExecTypeToCancelled = executionReport.execType();
                executionReport.ordStatus(OrdStatus.PARTIALLY_FILLED);
            } else {
                executionReport.ordStatus(OrdStatus.CANCELED);
                clearPendingDeals();
            }
        } else {
            executionReport.ordStatus(executionReport.leavesQty() == 0.0 ? FILLED : PARTIALLY_FILLED);
        }

        executionReport.execType(ExecType.TRADE);

        final TradeCaptureReport_SidesGrp_1 partyID = tradeCaptureReport.tradeCaptureReport_SidesGrp_1(0);
        executionReport.noPartyIDs(partyID.noPartyIDs());

        for (int i = 0; i < partyID.noPartyIDs(); i++) {
            final TradeCaptureReport_SidesGrp_PartyIDsGrp_1 tcrPartyIDsGrp = partyID.tradeCaptureReport_SidesGrp_PartyIDsGrp_1(i);
            final Parties_PartyIDsGrp_1 erPartyIDsGrp = executionReport.parties_PartyIDsGrp_1(i);
            erPartyIDsGrp.partyID(tcrPartyIDsGrp.partyID());
            erPartyIDsGrp.partyIDSource(tcrPartyIDsGrp.partyIDSource());
            erPartyIDsGrp.partyRole(tcrPartyIDsGrp.partyRole());
        }

        return executionReport;
    }

    public boolean cancel(final ExecutionReport executionReport) {
        /*
            ○ If (cumQty == 0.0 or cached.cumQty == cumQty) and no pendingDeals then send cancel and cleanup
		    ○ Else cache/update execType to cancel(4) - wait for remaining TCRs
         */
        if ((executionReport.cumQty() == 0.0 || executionReport.cumQty() == this.executionReport.cumQty()) && !havePendingDeals()) {
            this.executionReport.ordStatus(OrdStatus.CANCELED);
            this.executionReport.execType(ExecType.CANCELED);
            return true;
        }

        this.executionReport.execType(executionReport.execType());
        return false;
    }

    public void copyFrom(final ExecutionReport executionReport) {
        reset();
        executionReport.copyTo(this.executionReport);
    }

    public void reset() {
        resetExecTypeToCancelled = ExecType.NEW;
        executionReport.reset();
        pendingDealsQuantities.clear();
    }

    @Override
    public String toString() {
        return "ExecutionReportMerger{" +
                "resetExecTypeToCancelled=" + ExecType.asString(resetExecTypeToCancelled) +
                "pendingDealsQuantities=" + pendingDealsQuantities +
                ", executionReport=" + executionReport +
                '}';
    }

    public void updateClOrdId(final Bytes clOrdId) {
        executionReport.clOrdID_buffer().clear();
        executionReport.clOrdID_buffer().append(clOrdId);
    }

    public void savePendingDealQty(final long lastQty) {
        pendingDealsQuantities.addLong(lastQty);
    }

    private void removePendingDealQty(final long lastQty) {
        final int index = pendingDealsQuantities.indexOf(lastQty);
        if (index != -1) {
            pendingDealsQuantities.remove(index);
        }
    }

    private boolean havePendingDeals() {
        return pendingDealsQuantities.size() > 0;
    }

    private void clearPendingDeals() {
        pendingDealsQuantities.clear();
    }

    public ExecutionReport executionReport() {
        return executionReport;
    }

    public boolean isComplete() {
        return executionReport.leavesQty() == 0.0 || (executionReport.execType() == ExecType.CANCELED && !havePendingDeals());
    }

    public ExecutionReport sendCancel() {
        if (!havePendingDeals() && isCancelled()) {
            executionReport.execType(ExecType.CANCELED);
            executionReport.ordStatus(OrdStatus.CANCELED);
            return executionReport;
        }
        return null;
    }

    private boolean isCancelled() {
        return resetExecTypeToCancelled == ExecType.CANCELED || resetExecTypeToCancelled == TRIGGERED_OR_ACTIVATED_BY_SYSTEM;
    }
}
