package com.anz.markets.prophet.status;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.State;

public class TimeSourceJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        public final TimeSource timeSourceRealTime = new TimeSourceRealTime();
        public final TimeSource timeSourceMicroTime = new TimeSourceMicroTime();
    }

    @Benchmark
    public double nowNanosRealTime(final Data data) {
        return data.timeSourceRealTime.nowNanos();
    }

    @Benchmark
    public double nowNanosMicroTime(final Data data) {
        return data.timeSourceMicroTime.nowNanos();
    }
}
