package example;

import net.openhft.chronicle.wire.AbstractMarshallable;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.yaml.InvokeFromTestFunction;

import java.util.regex.Pattern;

/**
 * Created by Jerry Shea on 25/10/18.
 */
public class WaitForValue extends AbstractMarshallable implements InvokeFromTestFunction {
    private String regex;

    @Override
    public boolean test(FixLog fixLog) {
        String msg = fixLog.msg().toString();
        return Pattern.compile(regex).matcher(msg).find();
    }
}
