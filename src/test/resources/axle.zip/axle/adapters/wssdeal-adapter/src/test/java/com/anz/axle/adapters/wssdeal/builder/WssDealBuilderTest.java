package com.anz.axle.adapters.wssdeal.builder;

import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.wss.domain.WssDeal;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * Created by talwarg on 9/02/2015.
 */
public class WssDealBuilderTest {

    private Builder<WssDeal, TradeMessageWrapperType> builder;
    private JAXBContext jc = null;

    @Before
    public void setUp(){
        builder = new WssDealBuilder();
        try {
            jc = JAXBContext.newInstance(TradeMessageWrapperType.class);
        } catch (JAXBException e) {
        }
    }

    @Test
    public void testV104() throws BuilderException, JAXBException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildV104();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("083594925000005", wssDeal.getId());
        Assert.assertEquals("RET-AD", wssDeal.getSourceSystem());
        Assert.assertEquals("083594925000005", wssDeal.getWssTransactionId());
        Assert.assertEquals("FORWARD", wssDeal.getCounterDealType());
        Assert.assertEquals("08/01/2016 16:30:06", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("AUDUSD", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("SYDIVS.1601080000289", wssDeal.getDealId());
        Assert.assertEquals("BUY", wssDeal.getSide().getCode());
        Assert.assertEquals("1244026.8", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("1770000", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("USD", wssDeal.getTermsCurrency());
        Assert.assertEquals("AUD", wssDeal.getBaseCurrency());
        Assert.assertEquals("RET-AD_14407117",wssDeal.getRealtedDealId());
        Assert.assertEquals("RET-AD", wssDeal.getSourceSystem());
        Assert.assertEquals("14407117", wssDeal.getCounterDealId());
        Assert.assertEquals("SYHUNTHHIL", wssDeal.getCounterparty());
        Assert.assertEquals("HUHAIGFXMEL", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("WSS", wssDeal.getPositionParty());
        Assert.assertEquals("XEFX", wssDeal.getPositionAccount());
        Assert.assertEquals("SYDIVS", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("AUDUSD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("0.70284", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("12/01/2016 00:00:00",  simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("10/02/2016 00:00:00", simpleDateFormat.format(wssDeal.getValueDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("DIRECT", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("AMENDMENT",wssDeal.getDealStatus());
        Assert.assertEquals("C02 CUST ERR-VALUE DATE",wssDeal.getCancelReason());
        Assert.assertEquals("1601080000279",wssDeal.getOrigDealId());

    }

    @Test
    public void testBuildTakerMemo() throws BuilderException, JAXBException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildV104WithTakerMemo();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("083594925000005", wssDeal.getId());
        Assert.assertEquals("RET-AD", wssDeal.getSourceSystem());
        Assert.assertEquals("083594925000005", wssDeal.getWssTransactionId());
        Assert.assertEquals("FORWARD", wssDeal.getCounterDealType());
        Assert.assertEquals("08/01/2016 16:30:06", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("AUDUSD", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("SYDIVS.1601080000289", wssDeal.getDealId());
        Assert.assertEquals("BUY", wssDeal.getSide().getCode());
        Assert.assertEquals("1244026.8", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("1770000", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("USD", wssDeal.getTermsCurrency());
        Assert.assertEquals("AUD", wssDeal.getBaseCurrency());
        Assert.assertEquals("SPDEE:1ilgu8nfg",wssDeal.getRealtedDealId());
        Assert.assertEquals("RET-AD", wssDeal.getSourceSystem());
        Assert.assertEquals("14407117", wssDeal.getCounterDealId());
        Assert.assertEquals("SYHUNTHHIL", wssDeal.getCounterparty());
        Assert.assertEquals("HUHAIGFXMEL", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("WSS", wssDeal.getPositionParty());
        Assert.assertEquals("XEFX", wssDeal.getPositionAccount());
        Assert.assertEquals("SYDIVS", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("AUDUSD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("0.70284", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("12/01/2016 00:00:00",  simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("10/02/2016 00:00:00", simpleDateFormat.format(wssDeal.getValueDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("DIRECT", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("AMENDMENT",wssDeal.getDealStatus());
        Assert.assertEquals("C02 CUST ERR-VALUE DATE",wssDeal.getCancelReason());
        Assert.assertEquals("1601080000279",wssDeal.getOrigDealId());

    }

    private TradeMessageWrapperType buildV104() throws JAXBException {
        String xml = "<tradeMessage>" +
                "    <messageHeader>" +
                "        <sourceSystemMessageID>083594925000005" +
                "        </sourceSystemMessageID>" +
                "        <sourceSystemCreationDateTime>2016-01-08T16:30:06.000Z</sourceSystemCreationDateTime>" +
                "        <basedOnMessageForm>" +
                "            <name>tradeMessage</name>" +
                "            <version>1.03</version>" +
                "        </basedOnMessageForm>" +
                "        <emittedBySourceSystemInstance>" +
                "            <countryCode>AU</countryCode>" +
                "            <name>WSS</name>" +
                "            <version>5.0.1</version>" +
                "            <ownedByDomain>" +
                "                <name>INSTITUTIONAL_MARKETS</name>" +
                "            </ownedByDomain>" +
                "        </emittedBySourceSystemInstance>" +
                "    </messageHeader>" +
                "    <tradeHeader>" +
                "        <tradeIdentifier>" +
                "            <party partyReference=\"PARTY_1\"/>" +
                "            <arrangement>" +
                "                <arrangementIdentifier context=\"WSS_TRANSACTION_ID\">083594925000005</arrangementIdentifier>" +
                "                <arrangementIdentifier context=\"WSS_DEAL_NUMBER\">SYDIVS.1601080000289</arrangementIdentifier>" +
                "                <arrangementIdentifier context=\"WSS_TRADE_TYPE\">B</arrangementIdentifier>" +
                "                <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/>" +
                "                <arrangementIdentifier context=\"WSS_OTC_USI\"/>" +
                "            </arrangement>" +
                "        </tradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>UNKNOWN</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"/>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>ORIGINAL_TRADE</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_ORIGINAL_DEAL\">SYDIVS.1601080000279</arrangementIdentifier>" +
                "            <arrangementIdentifier context=\"WSS_ORIGINAL_TID\">083594912000001</arrangementIdentifier>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>PREVIOUS_TRADE</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/>" +
                "            <arrangementIdentifier context=\"WSS_OTC_USI\"/>" +
                "            <arrangementIdentifier context=\"WSS_PREV_DEAL\">1601080000279</arrangementIdentifier>" +
                "            <arrangementIdentifier context=\"WSS_PREV_TID\">083594912000001" +
                "            </arrangementIdentifier>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>LINK_TRADE</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>UNKNOWN" +
                "            </tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_AUX_TID\"/>" +
                "            <arrangementIdentifier context=\"WSS_AUX_MST_TID\"/>" +
                "            <arrangementIdentifier context=\"WSS_AUX_DEAL\"/>" +
                "            <arrangementIdentifier context=\"WSS_AUX_MST_DEAL\"/>" +
                "        </relatedTradeIdentifier>" +
                "        <productIdentifier>" +
                "            <identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier>" +
                "            <identifier context=\"FX_PRODUCT_CODE\">FORWARD</identifier>" +
                "            <identifier" +
                "                    context=\"SWAP_TID\"/>" +
                "            <identifier context=\"QUOTE_PAIR\">AUDUSD</identifier>" +
                "        </productIdentifier>" +
                "        <channelIdentifier>" +
                "            <identifier context=\"WSS_SOURCESYSTEM\">RET-AD</identifier>" +
                "            <identifier context=\"WSS_SOURCEDEALID\">14407117</identifier>" +
                "            <identifier context=\"WSS_NEWREFERENCECOPY\">RET-AD_14407117</identifier>" +
                "            <identifier context=\"WSS_CHANNELDEALID\"/>" +
                "            <identifier context=\"WSS_TAKERMEMO\"/>" +
                "        </channelIdentifier>" +
                "        <isMultitradeComponent>false</isMultitradeComponent>" +
                "        <sourceSystemOperation>MODIFY</sourceSystemOperation>" +
                "        <tradeBusinessEvent>" +
                "            <eventIdentifier context=\"FX_TRADE_EVENT\">AMENDMENT</eventIdentifier>" +
                "            <eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false" +
                "            </eventIdentifier>" +
                "            <reason context=\"WSS_CANCEL_AMEND_REASON\">C02 CUST ERR-VALUE DATE</reason>" +
                "        </tradeBusinessEvent>" +
                "        <authorisation>NOT_SPECIFIED</authorisation>" +
                "        <arrangementDate>2016-01-0" +
                "            8T00:00:00.000Z" +
                "        </arrangementDate>" +
                "        <regulatoryEnvironment reportingRegime=\"\">" +
                "            <executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/>" +
                "            <supervisoryEntity>" +
                "                <partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/>" +
                "            </supervisoryEntity>" +
                "        </regulatoryEnvironment>" +
                "        <reallocationRequired>false</reallocationRequired>" +
                "        <tradeDateStamp event=\"WSS_SPOT_DATE\">2016-01-12T00:00:00.000Z</tradeDateStamp>" +
                "        <tradeDateStamp event=\"OTC_Execution_DateTime\">2016-01-08T05:28:39.000Z" +
                "        </tradeDateStamp>" +
                "        <tradeDateStamp event=\"Trade_Entry_DateTime\">2016-01-08T16:30:06.000Z</tradeDateStamp>" +
                "        <tradeDateStamp event=\"WSS_SYSTEM_DATE\">2016-01-08T00:00:00.000Z" +
                "        </tradeDateStamp><initiationMethod>UNKNOWN</initiationMethod>" +
                "    </tradeHeader>" +
                "    <tradeParty ID=\"PARTY_1\">" +
                "        <partyIdentifier context=\"WSS_PORTFOLIO\">XEFX</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_AREA\">SYDIVS</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CITY_CODE\">SYDOPS</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_2\">" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">SYHUNTHHIL</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">HUNTER HALL INTERNATIONAL LTD</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_COUNTERPARTY_CODE\">HUHAIGF</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_SHORT_NAME\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"CUSTACCOUNTSTRING\">C057M269514I3788#INF</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_3\">" +
                "        <partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_BROKER_NAME\">REUTERS</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_4\">" +
                "        <partyIdentifier context=\"WSS_TRADER\">WSS</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_TRADER_NAME\">WSS (Do not delete)</partyIdentifier>" +
                "        <partyIdentifier context=\"CAF_CODE\">INF</partyIdentifier>" +
                "        <partyLocation>" +
                "            <locationIdentifier context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier>" +
                "        </partyLocation>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_5\">" +
                "        <partyIdentifier context=\"WSS_MOD_TRADER\"/>" +
                "        <partyIdentifier context=\"WSS_MOD_TRADER_NAME\"/>" +
                "        <partyLocation>" +
                "            <locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"/>" +
                "        </partyLocation>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_6\">" +
                "        <partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/>" +
                "        <partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_7\">" +
                "        <partyIdentifier context=\"WSS_ORIGINAL_TRADER\">WSS (Do not delete)</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeDetail xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"SimpleArrangement_Type\">" +
                "        <tradePrice xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\">" +
                "            <fixedRate>" +
                "                <value>0.70284</value>" +
                "            </fixedRate>" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                <quoteStyle>DIRECT</quoteStyle>" +
                "                <termsCurrency>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </termsCurrency>" +
                "                <unitCurrency>" +
                "                    <identifier context=\"ISO4217\">AUD</identifier>" +
                "                </unitCurrency>" +
                "            </priceSpecification>" +
                "        </tradePrice>" +
                "        <referencePrice xsi:type=\"FixedRate_Type\">" +
                "            <purpose>MARKET_MID</purpose>" +
                "            <fixedRate>" +
                "                <value>0.70437</value>" +
                "            </fixedRate>" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                <quoteStyle>DIRECT" +
                "                </quoteStyle>" +
                "                <termsCurrency>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </termsCurrency>" +
                "                <unitCurrency>" +
                "                    <identifier context=\"ISO4217\">AUD</identifier>" +
                "                </unitCurrency>" +
                "            </priceSpecification>" +
                "        </referencePrice>" +
                "        <referencePrice xsi:type=\"FixedRate_Type\">" +
                "            <purpose>MARKET_BID</purpose>" +
                "            <fixedRate>" +
                "                <value>0.70427</value>" +
                "            </fixedRate>" +
                "            <spotRate>" +
                "                <value>0.7048</value>" +
                "            </spotRate>" +
                "            <forwardMargin>" +
                "                <value measure=\"Points\">-5.3" +
                "                </value>" +
                "            </forwardMargin>" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                <quoteStyle>DIRECT</quoteStyle>" +
                "                <termsCurrency>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </termsCurrency>" +
                "                <unitCurrency>" +
                "                    <identifier context=\"ISO4217\">AUD" +
                "                    </identifier>" +
                "                </unitCurrency>" +
                "            </priceSpecification>" +
                "        </referencePrice>" +
                "        <Commitment xsi:type=\"DeliverableCommitment_Type\">" +
                "            <delivererParty partyReference=\"PARTY_2\"/>" +
                "            <receiverParty partyReference=\"PARTY_1\"/>" +
                "            <deliverable xsi:type=\"SimpleResourceParcel_Type\">" +
                "                <asset>" +
                "                    <identifier context=\"ISO4217\">AUD</identifier>" +
                "                </asset>" +
                "                <quantity>1770000</quantity>" +
                "            </deliverable>" +
                "            <deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "                <dateTime>2016-02-10T00:00:00.000Z</dateTime>" +
                "            </deliveryPeriod>" +
                "        </Commitment>" +
                "        <Commitment xsi:type=\"DeliverableCommitment_Type\">" +
                "            <delivererParty partyReference=\"PARTY_1\"/>" +
                "            <receiverParty partyReference=\"PARTY_2\"/>" +
                "            <deliverable xsi:type=\"SimpleResourceParcel_Type\">" +
                "                <asset>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </asset>" +
                "                <quantity>1244026.8</quantity>" +
                "            </deliverable>" +
                "            <deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "                <dateTime>2016-02-10T00:00:00.000Z</dateTime>" +
                "            </deliveryPeriod>" +
                "        </Commitment>" +
                "        <margin>" +
                "            <marginType>SALES_MARGIN_SPOT</marginType>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value measure=\"Points\">14</value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"DifferentialPrice_Type\">" +
                "                    <referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </margin>" +
                "        <margin>" +
                "            <marginType>SALES_MARGIN_FWD</marginType>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value measure=\"Points\">0.3</value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"DifferentialPrice_Type\">" +
                "                    <referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </margin>" +
                "        <margin>" +
                "            <marginType>SALES_MARGIN_TOTAL</marginType>" +
                "            <amount>" +
                "                <asset>" +
                "                    <identifier context=\"ISO4217\">USD" +
                "                    </identifier>" +
                "                </asset>" +
                "                <quantity>2531.1</quantity>" +
                "            </amount>" +
                "        </margin>" +
                "        <relatedComponent>" +
                "            <relationship>RATE_TO_BASE_BOUGHTCCY</relationship>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value>0.70284</value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                    <quoteStyle>DIRECT</quoteStyle>" +
                "                    <termsCurrency>" +
                "                        <identifier context=\"ISO4217\">USD</identifier>" +
                "                    </termsCurrency>" +
                "                    <unitCurrency>" +
                "                        <identifier context=\"ISO4217\">AUD</identifier>" +
                "                    </unitCurrency>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </relatedComponent>" +
                "        <relatedComponent>" +
                "            <relationship>RATE_TO_BASE_SOLDCCY</relationship>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value>1" +
                "                    </value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                    <quoteStyle>DIRECT</quoteStyle>" +
                "                    <termsCurrency>" +
                "                        <identifier context=\"ISO4217\">USD</identifier>" +
                "                    </termsCurrency>" +
                "                    <unitCurrency>" +
                "                        <identifier context=\"ISO4217\">USD" +
                "                        </identifier>" +
                "                    </unitCurrency>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </relatedComponent>" +
                "    </tradeDetail>" +
                "</tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage= (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;

    }

    private TradeMessageWrapperType buildV104WithTakerMemo() throws JAXBException {
        String xml = "<tradeMessage>" +
                "    <messageHeader>" +
                "        <sourceSystemMessageID>083594925000005" +
                "        </sourceSystemMessageID>" +
                "        <sourceSystemCreationDateTime>2016-01-08T16:30:06.000Z</sourceSystemCreationDateTime>" +
                "        <basedOnMessageForm>" +
                "            <name>tradeMessage</name>" +
                "            <version>1.03</version>" +
                "        </basedOnMessageForm>" +
                "        <emittedBySourceSystemInstance>" +
                "            <countryCode>AU</countryCode>" +
                "            <name>WSS</name>" +
                "            <version>5.0.1</version>" +
                "            <ownedByDomain>" +
                "                <name>INSTITUTIONAL_MARKETS</name>" +
                "            </ownedByDomain>" +
                "        </emittedBySourceSystemInstance>" +
                "    </messageHeader>" +
                "    <tradeHeader>" +
                "        <tradeIdentifier>" +
                "            <party partyReference=\"PARTY_1\"/>" +
                "            <arrangement>" +
                "                <arrangementIdentifier context=\"WSS_TRANSACTION_ID\">083594925000005</arrangementIdentifier>" +
                "                <arrangementIdentifier context=\"WSS_DEAL_NUMBER\">SYDIVS.1601080000289</arrangementIdentifier>" +
                "                <arrangementIdentifier context=\"WSS_TRADE_TYPE\">B</arrangementIdentifier>" +
                "                <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/>" +
                "                <arrangementIdentifier context=\"WSS_OTC_USI\"/>" +
                "            </arrangement>" +
                "        </tradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>UNKNOWN</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"/>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>ORIGINAL_TRADE</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_ORIGINAL_DEAL\">SYDIVS.1601080000279</arrangementIdentifier>" +
                "            <arrangementIdentifier context=\"WSS_ORIGINAL_TID\">083594912000001</arrangementIdentifier>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>PREVIOUS_TRADE</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/>" +
                "            <arrangementIdentifier context=\"WSS_OTC_USI\"/>" +
                "            <arrangementIdentifier context=\"WSS_PREV_DEAL\">1601080000279</arrangementIdentifier>" +
                "            <arrangementIdentifier context=\"WSS_PREV_TID\">083594912000001" +
                "            </arrangementIdentifier>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>LINK_TRADE</tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "        </relatedTradeIdentifier>" +
                "        <relatedTradeIdentifier>" +
                "            <tradeRelationship>UNKNOWN" +
                "            </tradeRelationship>" +
                "            <arrangementIdentifier context=\"WSS_AUX_TID\"/>" +
                "            <arrangementIdentifier context=\"WSS_AUX_MST_TID\"/>" +
                "            <arrangementIdentifier context=\"WSS_AUX_DEAL\"/>" +
                "            <arrangementIdentifier context=\"WSS_AUX_MST_DEAL\"/>" +
                "        </relatedTradeIdentifier>" +
                "        <productIdentifier>" +
                "            <identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier>" +
                "            <identifier context=\"FX_PRODUCT_CODE\">FORWARD</identifier>" +
                "            <identifier" +
                "                    context=\"SWAP_TID\"/>" +
                "            <identifier context=\"QUOTE_PAIR\">AUDUSD</identifier>" +
                "        </productIdentifier>" +
                "        <channelIdentifier>" +
                "            <identifier context=\"WSS_SOURCESYSTEM\">RET-AD</identifier>" +
                "            <identifier context=\"WSS_SOURCEDEALID\">14407117</identifier>" +
                "            <identifier context=\"WSS_NEWREFERENCECOPY\">RET-AD_14407117</identifier>" +
                "            <identifier context=\"WSS_CHANNELDEALID\"/>" +
                "            <identifier context=\"WSS_TAKERMEMO\">SPDEE:1ilgu8nfg</identifier>" +
                "        </channelIdentifier>" +
                "        <isMultitradeComponent>false</isMultitradeComponent>" +
                "        <sourceSystemOperation>MODIFY</sourceSystemOperation>" +
                "        <tradeBusinessEvent>" +
                "            <eventIdentifier context=\"FX_TRADE_EVENT\">AMENDMENT</eventIdentifier>" +
                "            <eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false" +
                "            </eventIdentifier>" +
                "            <reason context=\"WSS_CANCEL_AMEND_REASON\">C02 CUST ERR-VALUE DATE</reason>" +
                "        </tradeBusinessEvent>" +
                "        <authorisation>NOT_SPECIFIED</authorisation>" +
                "        <arrangementDate>2016-01-0" +
                "            8T00:00:00.000Z" +
                "        </arrangementDate>" +
                "        <regulatoryEnvironment reportingRegime=\"\">" +
                "            <executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/>" +
                "            <supervisoryEntity>" +
                "                <partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/>" +
                "            </supervisoryEntity>" +
                "        </regulatoryEnvironment>" +
                "        <reallocationRequired>false</reallocationRequired>" +
                "        <tradeDateStamp event=\"WSS_SPOT_DATE\">2016-01-12T00:00:00.000Z</tradeDateStamp>" +
                "        <tradeDateStamp event=\"OTC_Execution_DateTime\">2016-01-08T05:28:39.000Z" +
                "        </tradeDateStamp>" +
                "        <tradeDateStamp event=\"Trade_Entry_DateTime\">2016-01-08T16:30:06.000Z</tradeDateStamp>" +
                "        <tradeDateStamp event=\"WSS_SYSTEM_DATE\">2016-01-08T00:00:00.000Z" +
                "        </tradeDateStamp><initiationMethod>UNKNOWN</initiationMethod>" +
                "    </tradeHeader>" +
                "    <tradeParty ID=\"PARTY_1\">" +
                "        <partyIdentifier context=\"WSS_PORTFOLIO\">XEFX</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_AREA\">SYDIVS</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CITY_CODE\">SYDOPS</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_2\">" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">SYHUNTHHIL</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">HUNTER HALL INTERNATIONAL LTD</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_COUNTERPARTY_CODE\">HUHAIGF</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_SHORT_NAME\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">HUHAIGFXMEL</partyIdentifier>" +
                "        <partyIdentifier context=\"CUSTACCOUNTSTRING\">C057M269514I3788#INF</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_3\">" +
                "        <partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_BROKER_NAME\">REUTERS</partyIdentifier>" +
                "        <partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_4\">" +
                "        <partyIdentifier context=\"WSS_TRADER\">WSS</partyIdentifier>" +
                "        <partyIdentifier context=\"WSS_TRADER_NAME\">WSS (Do not delete)</partyIdentifier>" +
                "        <partyIdentifier context=\"CAF_CODE\">INF</partyIdentifier>" +
                "        <partyLocation>" +
                "            <locationIdentifier context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier>" +
                "        </partyLocation>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_5\">" +
                "        <partyIdentifier context=\"WSS_MOD_TRADER\"/>" +
                "        <partyIdentifier context=\"WSS_MOD_TRADER_NAME\"/>" +
                "        <partyLocation>" +
                "            <locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"/>" +
                "        </partyLocation>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_6\">" +
                "        <partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/>" +
                "        <partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/>" +
                "    </tradeParty>" +
                "    <tradeParty ID=\"PARTY_7\">" +
                "        <partyIdentifier context=\"WSS_ORIGINAL_TRADER\">WSS (Do not delete)</partyIdentifier>" +
                "    </tradeParty>" +
                "    <tradeDetail xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"SimpleArrangement_Type\">" +
                "        <tradePrice xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\">" +
                "            <fixedRate>" +
                "                <value>0.70284</value>" +
                "            </fixedRate>" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                <quoteStyle>DIRECT</quoteStyle>" +
                "                <termsCurrency>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </termsCurrency>" +
                "                <unitCurrency>" +
                "                    <identifier context=\"ISO4217\">AUD</identifier>" +
                "                </unitCurrency>" +
                "            </priceSpecification>" +
                "        </tradePrice>" +
                "        <referencePrice xsi:type=\"FixedRate_Type\">" +
                "            <purpose>MARKET_MID</purpose>" +
                "            <fixedRate>" +
                "                <value>0.70437</value>" +
                "            </fixedRate>" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                <quoteStyle>DIRECT" +
                "                </quoteStyle>" +
                "                <termsCurrency>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </termsCurrency>" +
                "                <unitCurrency>" +
                "                    <identifier context=\"ISO4217\">AUD</identifier>" +
                "                </unitCurrency>" +
                "            </priceSpecification>" +
                "        </referencePrice>" +
                "        <referencePrice xsi:type=\"FixedRate_Type\">" +
                "            <purpose>MARKET_BID</purpose>" +
                "            <fixedRate>" +
                "                <value>0.70427</value>" +
                "            </fixedRate>" +
                "            <spotRate>" +
                "                <value>0.7048</value>" +
                "            </spotRate>" +
                "            <forwardMargin>" +
                "                <value measure=\"Points\">-5.3" +
                "                </value>" +
                "            </forwardMargin>" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                <quoteStyle>DIRECT</quoteStyle>" +
                "                <termsCurrency>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </termsCurrency>" +
                "                <unitCurrency>" +
                "                    <identifier context=\"ISO4217\">AUD" +
                "                    </identifier>" +
                "                </unitCurrency>" +
                "            </priceSpecification>" +
                "        </referencePrice>" +
                "        <Commitment xsi:type=\"DeliverableCommitment_Type\">" +
                "            <delivererParty partyReference=\"PARTY_2\"/>" +
                "            <receiverParty partyReference=\"PARTY_1\"/>" +
                "            <deliverable xsi:type=\"SimpleResourceParcel_Type\">" +
                "                <asset>" +
                "                    <identifier context=\"ISO4217\">AUD</identifier>" +
                "                </asset>" +
                "                <quantity>1770000</quantity>" +
                "            </deliverable>" +
                "            <deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "                <dateTime>2016-02-10T00:00:00.000Z</dateTime>" +
                "            </deliveryPeriod>" +
                "        </Commitment>" +
                "        <Commitment xsi:type=\"DeliverableCommitment_Type\">" +
                "            <delivererParty partyReference=\"PARTY_1\"/>" +
                "            <receiverParty partyReference=\"PARTY_2\"/>" +
                "            <deliverable xsi:type=\"SimpleResourceParcel_Type\">" +
                "                <asset>" +
                "                    <identifier context=\"ISO4217\">USD</identifier>" +
                "                </asset>" +
                "                <quantity>1244026.8</quantity>" +
                "            </deliverable>" +
                "            <deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "                <dateTime>2016-02-10T00:00:00.000Z</dateTime>" +
                "            </deliveryPeriod>" +
                "        </Commitment>" +
                "        <margin>" +
                "            <marginType>SALES_MARGIN_SPOT</marginType>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value measure=\"Points\">14</value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"DifferentialPrice_Type\">" +
                "                    <referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </margin>" +
                "        <margin>" +
                "            <marginType>SALES_MARGIN_FWD</marginType>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value measure=\"Points\">0.3</value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"DifferentialPrice_Type\">" +
                "                    <referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </margin>" +
                "        <margin>" +
                "            <marginType>SALES_MARGIN_TOTAL</marginType>" +
                "            <amount>" +
                "                <asset>" +
                "                    <identifier context=\"ISO4217\">USD" +
                "                    </identifier>" +
                "                </asset>" +
                "                <quantity>2531.1</quantity>" +
                "            </amount>" +
                "        </margin>" +
                "        <relatedComponent>" +
                "            <relationship>RATE_TO_BASE_BOUGHTCCY</relationship>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value>0.70284</value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                    <quoteStyle>DIRECT</quoteStyle>" +
                "                    <termsCurrency>" +
                "                        <identifier context=\"ISO4217\">USD</identifier>" +
                "                    </termsCurrency>" +
                "                    <unitCurrency>" +
                "                        <identifier context=\"ISO4217\">AUD</identifier>" +
                "                    </unitCurrency>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </relatedComponent>" +
                "        <relatedComponent>" +
                "            <relationship>RATE_TO_BASE_SOLDCCY</relationship>" +
                "            <rate xsi:type=\"FixedRate_Type\">" +
                "                <fixedRate>" +
                "                    <value>1" +
                "                    </value>" +
                "                </fixedRate>" +
                "                <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "                    <quoteStyle>DIRECT</quoteStyle>" +
                "                    <termsCurrency>" +
                "                        <identifier context=\"ISO4217\">USD</identifier>" +
                "                    </termsCurrency>" +
                "                    <unitCurrency>" +
                "                        <identifier context=\"ISO4217\">USD" +
                "                        </identifier>" +
                "                    </unitCurrency>" +
                "                </priceSpecification>" +
                "            </rate>" +
                "        </relatedComponent>" +
                "    </tradeDetail>" +
                "</tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage= (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;

    }

    @Test
    public void testBuild() throws BuilderException, JAXBException{
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildTradeMessage();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("022415025000001", wssDeal.getId());
        Assert.assertEquals("AXLE", wssDeal.getSourceSystem());
        Assert.assertEquals("022415025000001", wssDeal.getWssTransactionId());
        Assert.assertEquals("FORWARD", wssDeal.getCounterDealType());
        Assert.assertEquals("24/02/2015 15:14:22", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("AUDEUR", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("SYDIVS.1502240000366", wssDeal.getDealId());
        Assert.assertEquals("SELL", wssDeal.getSide().getCode());
        Assert.assertEquals("6731.79", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("10000", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("EUR", wssDeal.getTermsCurrency());
        Assert.assertEquals("AUD", wssDeal.getBaseCurrency());
        Assert.assertEquals("AXLE_12345",wssDeal.getRealtedDealId());
        Assert.assertEquals("AXLE", wssDeal.getSourceSystem());
        Assert.assertEquals("FXC13453871_", wssDeal.getCounterDealId());
        Assert.assertEquals("ABDM2GFXMEL", wssDeal.getCounterparty());
        Assert.assertEquals("ABDM2GFXMEL", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("XAU", wssDeal.getPositionParty());
        Assert.assertEquals("FXC", wssDeal.getPositionAccount());
        Assert.assertEquals("SYDIVS", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("EURAUD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("0.673179", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("26/02/2015 00:00:00",  simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("24/04/2015 00:00:00", simpleDateFormat.format(wssDeal.getValueDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("INVERSE", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("NEW",wssDeal.getDealStatus());
        Assert.assertEquals("",wssDeal.getCancelReason());
        Assert.assertEquals("",wssDeal.getOrigDealId());

    }


    @Test
    public void testBuildForCancellation() throws BuilderException, JAXBException{
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildTradeMessageForCancellation();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("022415025000001", wssDeal.getId());
        Assert.assertEquals("AXLE", wssDeal.getSourceSystem());
        Assert.assertEquals("022415025000001", wssDeal.getWssTransactionId());
        Assert.assertEquals("FORWARD", wssDeal.getCounterDealType());
        Assert.assertEquals("24/02/2015 15:14:22", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("AUDEUR", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("SYDIVS.1502240000366", wssDeal.getDealId());
        Assert.assertEquals("SELL", wssDeal.getSide().getCode());
        Assert.assertEquals("6731.79", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("10000", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("EUR", wssDeal.getTermsCurrency());
        Assert.assertEquals("AUD", wssDeal.getBaseCurrency());
        Assert.assertEquals("AXLE_12345",wssDeal.getRealtedDealId());
        Assert.assertEquals("AXLE", wssDeal.getSourceSystem());
        Assert.assertEquals("FXC13453871_", wssDeal.getCounterDealId());
        Assert.assertEquals("ABDM2GFXMEL", wssDeal.getCounterparty());
        Assert.assertEquals("ABDM2GFXMEL", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("XAU", wssDeal.getPositionParty());
        Assert.assertEquals("FXC", wssDeal.getPositionAccount());
        Assert.assertEquals("SYDIVS", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("EURAUD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("0.673179", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("26/02/2015 00:00:00",  simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("24/04/2015 00:00:00", simpleDateFormat.format(wssDeal.getValueDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("INVERSE", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("CANCELLATION",wssDeal.getDealStatus());
        Assert.assertEquals("C02 CUST ERR-VALUE DATE",wssDeal.getCancelReason());
        Assert.assertEquals("",wssDeal.getOrigDealId());

    }

    @Test
    public void testBuildForModification() throws BuilderException, JAXBException{
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildTradeMessageForModification();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("022415025000001", wssDeal.getId());
        Assert.assertEquals("AXLE", wssDeal.getSourceSystem());
        Assert.assertEquals("022415025000001", wssDeal.getWssTransactionId());
        Assert.assertEquals("FORWARD", wssDeal.getCounterDealType());
        Assert.assertEquals("24/02/2015 15:14:22", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("AUDEUR", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("SYDIVS.1502240000366", wssDeal.getDealId());
        Assert.assertEquals("SELL", wssDeal.getSide().getCode());
        Assert.assertEquals("6731.79", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("10000", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("EUR", wssDeal.getTermsCurrency());
        Assert.assertEquals("AUD", wssDeal.getBaseCurrency());
        Assert.assertEquals("AXLE_12345",wssDeal.getRealtedDealId());
        Assert.assertEquals("AXLE", wssDeal.getSourceSystem());
        Assert.assertEquals("FXC13453871_", wssDeal.getCounterDealId());
        Assert.assertEquals("ABDM2GFXMEL", wssDeal.getCounterparty());
        Assert.assertEquals("ABDM2GFXMEL", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("XAU", wssDeal.getPositionParty());
        Assert.assertEquals("FXC", wssDeal.getPositionAccount());
        Assert.assertEquals("SYDIVS", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("EURAUD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("0.673179", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("26/02/2015 00:00:00",  simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("24/04/2015 00:00:00", simpleDateFormat.format(wssDeal.getValueDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("INVERSE", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("AMENDMENT",wssDeal.getDealStatus());
        Assert.assertEquals("1505260000053",wssDeal.getOrigDealId());
    }

    @Test (expected = BuilderException.class)
    public void testBuildWithException() throws BuilderException, JAXBException{
        builder = new WssDealBuilder();
        TradeMessageWrapperType tradeMessage = buildTradeMessage();
        tradeMessage.setTradeHeader(null);
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals(wssDeal.getId(), "AXLE_12345");
    }

    private TradeMessageWrapperType buildTradeMessage() throws JAXBException{
        String xml= "<?xml version=\"1.0\" encoding=\"UTF-8\" " +
                "standalone=\"yes\"?><tradeMessage><messageHeader><sourceSystemMessageID>022415025000001" +
                "</sourceSystemMessageID><sourceSystemCreationDateTime>2015-02-24T15:14:22.000Z</sourceSystemCreationDateTime><basedOnMessageForm>" +
                "<name>tradeMessage</name><version>1.03</version></basedOnMessageForm><emittedBySourceSystemInstance><countryCode>AU</countryCode><name>WSS</name><version>5.0.1</version><ownedByDomain><name>INSTITUTIONAL_MARKETS</name></ownedByDomain></emittedBySourceSystemInstance>" +
                "</messageHeader><tradeHeader><tradeIdentifier><party partyReference=\"PARTY_1\"/><arrangement><arrangementIdentifier context=\"WSS_TRANSACTION_ID\">022415025000001</arrangementIdentifier><arrangementIdentifier context=\"WSS_DEAL_NUMBER\">SYDIVS.1502240000366" +
                "</arrangementIdentifier><arrangementIdentifier context=\"WSS_TRADE_TYPE\">S</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\">TGEMMWANRL</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI\">12679922</arrangementIdentifier>" +
                "</arrangement></tradeIdentifier><relatedTradeIdentifier><tradeRelationship></tradeRelationship><arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>PREVIOUS_TRADE" +
                "</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/><arrangementIdentifier context=\"WSS_OTC_USI\"/></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>LINK_TRADE</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "</relatedTradeIdentifier><productIdentifier><identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier><identifier context=\"FX_PRODUCT_CODE\">FORWARD</identifier></productIdentifier><channelIdentifier><identifier context=\"WSS_SOURCESYSTEM\">AXLE</identifier>" +
                "<identifier context=\"WSS_SOURCEDEALID\">FXC13453871_</identifier><identifier context=\"WSS_NEWREFERENCECOPY\">AXLE_12345</identifier></channelIdentifier><isMultitradeComponent>false</isMultitradeComponent><sourceSystemOperation>CREATE</sourceSystemOperation><tradeBusinessEvent>" +
                "<eventIdentifier context=\"FX_TRADE_EVENT\">NEW</eventIdentifier><eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier><reason context=\"WSS_CANCEL_AMEND_REASON\"/></tradeBusinessEvent><authorisation>NOT_SPECIFIED</authorisation><arrangementDate>2015-02-24T00:00:00Z</arrangementDate><reallocationRequired>false</reallocationRequired>" +
                "<tradeDateStamp event=\"WSS_SPOT_DATE\">2015-02-26T00:00:00Z</tradeDateStamp><tradeDateStamp event=\"OTC_Execution_DateTime\">2015-02-24T05:12:46.000+00:00Z</tradeDateStamp><tradeDateStamp event=\"Trade_Entry_DateTime\">2015-02-24T15:14:22.000+00:00Z</tradeDateStamp>" +
                "<regulatoryEnvironment reportingRegime=\"\"><executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/><supervisoryEntity><partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/></supervisoryEntity></regulatoryEnvironment></tradeHeader><tradeParty ID=\"PARTY_1\">" +
                "<partyIdentifier context=\"WSS_PORTFOLIO\">FXC</partyIdentifier><partyIdentifier context=\"WSS_AREA\">SYDIVS</partyIdentifier><partyIdentifier context=\"WSS_CITY_CODE\"/><partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_2\">" +
                "<partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">ABDM2GFXMEL</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">ABDM2GFXMEL</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">ABDM2GFXMEL</partyIdentifier>" +
                "<partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\"/><partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier><partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/><partyIdentifier context=\"MIDANZ_SHORT_NAME\">ABDM2GFXMEL</partyIdentifier>" +
                "<partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">ABDM2GFXMEL</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_3\"><partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier><partyIdentifier context=\"WSS_BROKER_NAME\"/><partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU" +
                "</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_4\"><partyIdentifier " +
                "context=\"WSS_TRADER\">XAU</partyIdentifier><partyIdentifier " +
                "context=\"WSS_TRADER_NAME\"/><partyLocation><locationIdentifier " +
                "context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier>" +
                "</partyLocation></tradeParty><tradeParty ID=\"PARTY_5\"><partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier><partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier><partyLocation><location locationType=\"WSS_MOD_TRADER_LOCATION\"></location></partyLocation></tradeParty><tradeParty ID=\"PARTY_6\">" +
                "<partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/><partyIdentifier " +
                "context=\"WSS_OTC_PARTY_OVERRIDE\"/></tradeParty><tradeDetail xmlns:xsi=\"http://www.w3" +
                ".org/2001/XMLSchema-instance\" xsi:type=\"SimpleArrangement_Type\"><tradePrice " +
                "xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\"><fixedRate><value>.673179</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>INVERSE</quoteStyle><termsCurrency>" +
                "<identifier context=\"ISO4217\">AUD</identifier></termsCurrency><unitCurrency><identifier " +
                "context=\"ISO4217\">EUR</identifier></unitCurrency></priceSpecification></tradePrice><referencePrice" +
                " xsi:type=\"FixedRate_Type\"><fixedRate><value>0.6858</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "<quoteStyle>INVERSE</quoteStyle><termsCurrency><identifier " +
                "context=\"ISO4217\">AUD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">EUR</identifier></unitCurrency></priceSpecification></referencePrice><Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_2\"/>" +
                "<receiverParty partyReference=\"PARTY_1\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier " +
                "context=\"ISO4217\">EUR</identifier></asset><quantity>6731" +
                ".79</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2015-04-24T00:00:00Z</dateTime></deliveryPeriod></Commitment>" +
                "<Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_1\"/><receiverParty " +
                "partyReference=\"PARTY_2\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier " +
                "context=\"ISO4217\">AUD</identifier></asset><quantity>10000</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "<dateTime>2015-04-24T00:00:00Z</dateTime></deliveryPeriod></Commitment></tradeDetail></tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage= (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;
    }


    private TradeMessageWrapperType buildTradeMessageForCancellation() throws JAXBException{
        String xml= "<?xml version=\"1.0\" encoding=\"UTF-8\" " +
                "standalone=\"yes\"?><tradeMessage><messageHeader><sourceSystemMessageID>022415025000001</sourceSystemMessageID><sourceSystemCreationDateTime>2015-02-24T15:14:22.000Z</sourceSystemCreationDateTime><basedOnMessageForm>" +
                "<name>tradeMessage</name><version>1.03</version></basedOnMessageForm><emittedBySourceSystemInstance><countryCode>AU</countryCode><name>WSS</name><version>5.0.1</version><ownedByDomain><name>INSTITUTIONAL_MARKETS</name></ownedByDomain></emittedBySourceSystemInstance>" +
                "</messageHeader><tradeHeader><tradeIdentifier><party partyReference=\"PARTY_1\"/><arrangement><arrangementIdentifier context=\"WSS_TRANSACTION_ID\">022415025000001</arrangementIdentifier><arrangementIdentifier context=\"WSS_DEAL_NUMBER\">SYDIVS.1502240000366" +
                "</arrangementIdentifier><arrangementIdentifier context=\"WSS_TRADE_TYPE\">S</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\">TGEMMWANRL</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI\">12679922</arrangementIdentifier>" +
                "</arrangement></tradeIdentifier><relatedTradeIdentifier><tradeRelationship></tradeRelationship><arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>PREVIOUS_TRADE" +
                "</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/><arrangementIdentifier context=\"WSS_OTC_USI\"/></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>LINK_TRADE</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "</relatedTradeIdentifier><productIdentifier><identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier><identifier context=\"FX_PRODUCT_CODE\">FORWARD</identifier></productIdentifier><channelIdentifier><identifier context=\"WSS_SOURCESYSTEM\">AXLE</identifier>" +
                "<identifier context=\"WSS_SOURCEDEALID\">FXC13453871_</identifier><identifier context=\"WSS_NEWREFERENCECOPY\">AXLE_12345</identifier></channelIdentifier><isMultitradeComponent>false</isMultitradeComponent><sourceSystemOperation>CREATE</sourceSystemOperation><tradeBusinessEvent>" +
                "<eventIdentifier context=\"FX_TRADE_EVENT\">CANCELLATION</eventIdentifier><eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier><reason context=\"WSS_CANCEL_AMEND_REASON\">C02 CUST ERR-VALUE DATE</reason></tradeBusinessEvent><authorisation>NOT_SPECIFIED</authorisation><arrangementDate>2015-02-24T00:00:00Z</arrangementDate><reallocationRequired>false</reallocationRequired>" +
                "<tradeDateStamp event=\"WSS_SPOT_DATE\">2015-02-26T00:00:00Z</tradeDateStamp><tradeDateStamp event=\"OTC_Execution_DateTime\">2015-02-24T05:12:46.000+00:00Z</tradeDateStamp><tradeDateStamp event=\"Trade_Entry_DateTime\">2015-02-24T15:14:22.000+00:00Z</tradeDateStamp>" +
                "<regulatoryEnvironment reportingRegime=\"\"><executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/><supervisoryEntity><partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/></supervisoryEntity></regulatoryEnvironment></tradeHeader><tradeParty ID=\"PARTY_1\">" +
                "<partyIdentifier context=\"WSS_PORTFOLIO\">FXC</partyIdentifier><partyIdentifier context=\"WSS_AREA\">SYDIVS</partyIdentifier><partyIdentifier context=\"WSS_CITY_CODE\"/><partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_2\">" +
                "<partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">ABDM2GFXMEL</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">ABDM2GFXMEL</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">ABDM2GFXMEL</partyIdentifier>" +
                "<partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\"/><partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier><partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/><partyIdentifier context=\"MIDANZ_SHORT_NAME\">ABDM2GFXMEL</partyIdentifier>" +
                "<partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">ABDM2GFXMEL</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_3\"><partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier><partyIdentifier context=\"WSS_BROKER_NAME\"/><partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU" +
                "</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_4\"><partyIdentifier " +
                "context=\"WSS_TRADER\">XAU</partyIdentifier><partyIdentifier " +
                "context=\"WSS_TRADER_NAME\"/><partyLocation><locationIdentifier " +
                "context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier></partyLocation></tradeParty><tradeParty " +
                "ID=\"PARTY_5\">" +
                "<partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier><partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier><partyLocation><location locationType=\"WSS_MOD_TRADER_LOCATION\"></location></partyLocation></tradeParty><tradeParty ID=\"PARTY_6\">" +
                "<partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/><partyIdentifier " +
                "context=\"WSS_OTC_PARTY_OVERRIDE\"/></tradeParty><tradeDetail xmlns:xsi=\"http://www.w3" +
                ".org/2001/XMLSchema-instance\" xsi:type=\"SimpleArrangement_Type\"><tradePrice " +
                "xsi:type=\"FixedRate_Type\"><fixedRate><value>.673179</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>INVERSE</quoteStyle><termsCurrency>" +
                "<identifier context=\"ISO4217\">AUD</identifier></termsCurrency><unitCurrency><identifier " +
                "context=\"ISO4217\">EUR</identifier></unitCurrency></priceSpecification></tradePrice><referencePrice" +
                " xsi:type=\"FixedRate_Type\"><fixedRate><value>0.6858</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "<quoteStyle>INVERSE</quoteStyle><termsCurrency><identifier " +
                "context=\"ISO4217\">AUD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">EUR</identifier></unitCurrency></priceSpecification></referencePrice><Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_2\"/>" +
                "<receiverParty partyReference=\"PARTY_1\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier " +
                "context=\"ISO4217\">EUR</identifier></asset><quantity>6731" +
                ".79</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2015-04-24T00:00:00Z</dateTime></deliveryPeriod></Commitment>" +
                "<Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_1\"/><receiverParty " +
                "partyReference=\"PARTY_2\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier " +
                "context=\"ISO4217\">AUD</identifier></asset><quantity>10000</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "<dateTime>2015-04-24T00:00:00Z</dateTime></deliveryPeriod></Commitment></tradeDetail></tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage= (TradeMessageWrapperType)JAXBIntrospector.getValue(unmarshaller
                .unmarshal(reader));
        return tradeMessage;
    }

    private TradeMessageWrapperType buildTradeMessageForModification() throws JAXBException{
        String xml= "<?xml version=\"1.0\" encoding=\"UTF-8\" " +
                "standalone=\"yes\"?><tradeMessage><messageHeader><sourceSystemMessageID>022415025000001</sourceSystemMessageID><sourceSystemCreationDateTime>2015-02-24T15:14:22.000Z</sourceSystemCreationDateTime><basedOnMessageForm>" +
                "<name>tradeMessage</name><version>1.03</version></basedOnMessageForm><emittedBySourceSystemInstance><countryCode>AU</countryCode><name>WSS</name><version>5.0.1</version><ownedByDomain><name>INSTITUTIONAL_MARKETS</name></ownedByDomain></emittedBySourceSystemInstance>" +
                "</messageHeader><tradeHeader><tradeIdentifier><party partyReference=\"PARTY_1\"/><arrangement><arrangementIdentifier context=\"WSS_TRANSACTION_ID\">022415025000001</arrangementIdentifier><arrangementIdentifier context=\"WSS_DEAL_NUMBER\">SYDIVS.1502240000366" +
                "</arrangementIdentifier><arrangementIdentifier context=\"WSS_TRADE_TYPE\">S</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\">TGEMMWANRL</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI\">12679922</arrangementIdentifier>" +
                "</arrangement></tradeIdentifier><relatedTradeIdentifier><tradeRelationship></tradeRelationship><arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>PREVIOUS_TRADE" +
                "</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/><arrangementIdentifier context=\"WSS_OTC_USI\"/><arrangementIdentifier context=\"WSS_PREV_DEAL\">1505260000053</arrangementIdentifier></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>LINK_TRADE</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "</relatedTradeIdentifier><productIdentifier><identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier><identifier context=\"FX_PRODUCT_CODE\">FORWARD</identifier></productIdentifier><channelIdentifier><identifier context=\"WSS_SOURCESYSTEM\">AXLE</identifier>" +
                "<identifier context=\"WSS_SOURCEDEALID\">FXC13453871_</identifier><identifier context=\"WSS_NEWREFERENCECOPY\">AXLE_12345</identifier></channelIdentifier><isMultitradeComponent>false</isMultitradeComponent><sourceSystemOperation>CREATE</sourceSystemOperation><tradeBusinessEvent>" +
                "<eventIdentifier context=\"FX_TRADE_EVENT\">AMENDMENT</eventIdentifier><eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier><reason context=\"WSS_CANCEL_AMEND_REASON\"/></tradeBusinessEvent><authorisation>NOT_SPECIFIED</authorisation><arrangementDate>2015-02-24T00:00:00Z</arrangementDate><reallocationRequired>false</reallocationRequired>" +
                "<tradeDateStamp event=\"WSS_SPOT_DATE\">2015-02-26T00:00:00Z</tradeDateStamp><tradeDateStamp event=\"OTC_Execution_DateTime\">2015-02-24T05:12:46.000+00:00Z</tradeDateStamp><tradeDateStamp event=\"Trade_Entry_DateTime\">2015-02-24T15:14:22.000+00:00Z</tradeDateStamp>" +
                "<regulatoryEnvironment reportingRegime=\"\"><executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/><supervisoryEntity><partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/></supervisoryEntity></regulatoryEnvironment></tradeHeader><tradeParty ID=\"PARTY_1\">" +
                "<partyIdentifier context=\"WSS_PORTFOLIO\">FXC</partyIdentifier><partyIdentifier context=\"WSS_AREA\">SYDIVS</partyIdentifier><partyIdentifier context=\"WSS_CITY_CODE\"/><partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_2\">" +
                "<partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">ABDM2GFXMEL</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">ABDM2GFXMEL</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">ABDM2GFXMEL</partyIdentifier>" +
                "<partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\"/><partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier><partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/><partyIdentifier context=\"MIDANZ_SHORT_NAME\">ABDM2GFXMEL</partyIdentifier>" +
                "<partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">ABDM2GFXMEL</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_3\"><partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier><partyIdentifier context=\"WSS_BROKER_NAME\"/><partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU" +
                "</partyIdentifier></tradeParty><tradeParty ID=\"PARTY_4\"><partyIdentifier " +
                "context=\"WSS_TRADER\">XAU</partyIdentifier><partyIdentifier " +
                "context=\"WSS_TRADER_NAME\"/><partyLocation><locationIdentifier " +
                "context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier></partyLocation></tradeParty><tradeParty " +
                "ID=\"PARTY_5\">" +
                "<partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier><partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier><partyLocation><location locationType=\"WSS_MOD_TRADER_LOCATION\"></location></partyLocation></tradeParty><tradeParty ID=\"PARTY_6\">" +
                "<partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/><partyIdentifier " +
                "context=\"WSS_OTC_PARTY_OVERRIDE\"/></tradeParty><tradeDetail xmlns:xsi=\"http://www.w3" +
                ".org/2001/XMLSchema-instance\" xsi:type=\"SimpleArrangement_Type\"><tradePrice " +
                "xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\"><fixedRate><value>.673179</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>INVERSE</quoteStyle><termsCurrency>" +
                "<identifier context=\"ISO4217\">AUD</identifier></termsCurrency><unitCurrency><identifier " +
                "context=\"ISO4217\">EUR</identifier></unitCurrency></priceSpecification></tradePrice><referencePrice" +
                " xsi:type=\"FixedRate_Type\"><fixedRate><value>0.6858</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">" +
                "<quoteStyle>INVERSE</quoteStyle><termsCurrency><identifier " +
                "context=\"ISO4217\">AUD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">EUR</identifier></unitCurrency></priceSpecification></referencePrice><Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_2\"/>" +
                "<receiverParty partyReference=\"PARTY_1\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier " +
                "context=\"ISO4217\">EUR</identifier></asset><quantity>6731.79</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2015-04-24T00:00:00Z</dateTime></deliveryPeriod></Commitment>" +
                "<Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_1\"/><receiverParty " +
                "partyReference=\"PARTY_2\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier " +
                "context=\"ISO4217\">AUD</identifier></asset><quantity>10000</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">" +
                "<dateTime>2015-04-24T00:00:00Z</dateTime></deliveryPeriod></Commitment></tradeDetail></tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage= (TradeMessageWrapperType)JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;
    }


    @Test
    public void testBuildSwapTradeMessage_NearLeg() throws BuilderException, JAXBException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildSwapTradeMessage_NearLeg();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("100599276000001", wssDeal.getId());
        Assert.assertEquals("FXALL_RFS", wssDeal.getSourceSystem());
        Assert.assertEquals("100599276000001", wssDeal.getWssTransactionId());
        Assert.assertEquals("SWAP", wssDeal.getCounterDealType());
        Assert.assertEquals("14/03/2016 00:58:23", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("GBPUSD", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("NYKCRP.1603146901519", wssDeal.getDealId());
        Assert.assertEquals("2397954.62", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("1674947", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("USD", wssDeal.getTermsCurrency());
        Assert.assertEquals("GBP", wssDeal.getBaseCurrency());
        Assert.assertEquals("SPDEE:1ilqubioz", wssDeal.getRealtedDealId());
        Assert.assertEquals("14666234", wssDeal.getCounterDealId());
        Assert.assertEquals("MARINGFXNYK", wssDeal.getCounterparty());
        Assert.assertEquals("MARINGFXNYK", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("XGB", wssDeal.getPositionParty());
        Assert.assertEquals("STP", wssDeal.getPositionAccount());
        Assert.assertEquals("NYKCRP", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("GBPUSD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("1.43166", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("16/03/2016 00:00:00", simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("DIRECT", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("NEW", wssDeal.getDealStatus());
        Assert.assertEquals("", wssDeal.getCancelReason());
        Assert.assertEquals("", wssDeal.getOrigDealId());
        Assert.assertEquals("BUY", wssDeal.getSide().getCode());
    }

    @Test
    public void testBuildRelatedDealIFromNewReferenceCopyForFXEasy() throws BuilderException, JAXBException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildSwapTradeMessageForFXEasy();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("100599276000001", wssDeal.getId());
        Assert.assertEquals("FXALL_RFS", wssDeal.getSourceSystem());
        Assert.assertEquals("100599276000001", wssDeal.getWssTransactionId());
        Assert.assertEquals("SWAP", wssDeal.getCounterDealType());
        Assert.assertEquals("14/03/2016 00:58:23", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("GBPUSD", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("NYKCRP.1603146901519", wssDeal.getDealId());
        Assert.assertEquals("2397954.62", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("1674947", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("USD", wssDeal.getTermsCurrency());
        Assert.assertEquals("GBP", wssDeal.getBaseCurrency());
        Assert.assertEquals("RET-AD_14666234", wssDeal.getRealtedDealId());
        Assert.assertEquals("14666234", wssDeal.getCounterDealId());
        Assert.assertEquals("MARINGFXNYK", wssDeal.getCounterparty());
        Assert.assertEquals("MARINGFXNYK", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("XGB", wssDeal.getPositionParty());
        Assert.assertEquals("STP", wssDeal.getPositionAccount());
        Assert.assertEquals("NYKCRP", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("GBPUSD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("1.43166", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("16/03/2016 00:00:00", simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("DIRECT", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("NEW", wssDeal.getDealStatus());
        Assert.assertEquals("", wssDeal.getCancelReason());
        Assert.assertEquals("", wssDeal.getOrigDealId());
        Assert.assertEquals("BUY", wssDeal.getSide().getCode());
    }


    private TradeMessageWrapperType buildSwapTradeMessage_NearLeg() throws JAXBException {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<tradeMessage>" +
                "       <messageHeader>" +
                "           <sourceSystemMessageID>100599276000001</sourceSystemMessageID>" +
                "           <sourceSystemCreationDateTime>2016-03-14T00:58:23.000Z</sourceSystemCreationDateTime>" +
                "           <basedOnMessageForm>" +
                "               <name>tradeMessage</name>" +
                "               <version>2.03.1</version>" +
                "           </basedOnMessageForm>" +
                "           <emittedBySourceSystemInstance><countryCode>AU</countryCode><name>WSS</name><version>5.0.1</version><ownedByDomain><name>INSTITUTIONAL_MARKETS</name></ownedByDomain></emittedBySourceSystemInstance>" +
                "       </messageHeader>" +
                "       <tradeHeader>" +
                "           <tradeIdentifier>" +
                "               <party partyReference=\"PARTY_1\"/>" +
                "                   <arrangement>" +
                "                       <arrangementIdentifier context=\"WSS_TRANSACTION_ID\">100599276000001</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_DEAL_NUMBER\">NYKCRP.1603146901519</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_TRADE_TYPE\">B</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\">YCDYZNMZ3J</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_OTC_USI\">86138426L0A0</arrangementIdentifier>" +
                "                   </arrangement>" +
                "           </tradeIdentifier>" +
                "           <relatedTradeIdentifier>" +
                "               <tradeRelationship>UNKNOWN</tradeRelationship>" +
                "                   <arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>ORIGINAL_TRADE</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_ORIGINAL_DEAL\"></arrangementIdentifier>" +
                "               <arrangementIdentifier context=\"WSS_ORIGINAL_TID\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>PREVIOUS_TRADE</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/><arrangementIdentifier context=\"WSS_OTC_USI\"/><arrangementIdentifier context=\"WSS_PREV_DEAL\"/>" +
                "               <arrangementIdentifier context=\"WSS_PREV_TID\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>LINK_TRADE</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>UNKNOWN</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_AUX_TID\"/><arrangementIdentifier context=\"WSS_AUX_MST_TID\"/>" +
                "               <arrangementIdentifier context=\"WSS_AUX_DEAL\"/><arrangementIdentifier context=\"WSS_AUX_MST_DEAL\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <productIdentifier>" +
                "               <identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier>" +
                "               <identifier context=\"FX_PRODUCT_CODE\">SWAP</identifier>" +
                "               <identifier context=\"FX_SWAP_LEG\">1</identifier>" +
                "               <identifier context=\"SWAP_TID\">100599276000002</identifier>" +
                "               <identifier context=\"QUOTE_PAIR\">GBPUSD</identifier>" +
                "           </productIdentifier>" +
                "           <channelIdentifier>" +
                "               <identifier context=\"WSS_SOURCESYSTEM\">FXALL_RFS</identifier>" +
                "               <identifier context=\"WSS_SOURCEDEALID\">14666234</identifier>" +
                "               <identifier context=\"WSS_NEWREFERENCECOPY\">RET-AD_14666234</identifier>" +
                "               <identifier context=\"WSS_CHANNELDEALID\"/>" +
                "               <identifier context=\"WSS_TAKERMEMO\">SPDEE:1ilqubioz</identifier>" +
                "           </channelIdentifier>" +
                "           <isMultitradeComponent>true</isMultitradeComponent>" +
                "           <sourceSystemOperation>CREATE</sourceSystemOperation>" +
                "           <tradeBusinessEvent><eventIdentifier context=\"FX_TRADE_EVENT\">NEW</eventIdentifier><eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier><reason context=\"WSS_CANCEL_AMEND_REASON\"/></tradeBusinessEvent><authorisation>NOT_SPECIFIED</authorisation><arrangementDate>2016-03-14T00:00:00.000Z</arrangementDate><regulatoryEnvironment reportingRegime=\"\"><executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/><supervisoryEntity><partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/></supervisoryEntity></regulatoryEnvironment><reallocationRequired>false</reallocationRequired><tradeDateStamp event=\"WSS_SPOT_DATE\">2016-03-16T00:00:00.000Z</tradeDateStamp><tradeDateStamp event=\"OTC_Execution_DateTime\">2016-03-15T00:58:22.000Z</tradeDateStamp><tradeDateStamp event=\"Trade_Entry_DateTime\">2016-03-14T00:58:23.000Z</tradeDateStamp><tradeDateStamp event=\"WSS_SYSTEM_DATE\">2016-03-14T00:00:00.000Z</tradeDateStamp><initiationMethod>UNKNOWN</initiationMethod>" +
                "       </tradeHeader>" +
                "       <tradeParty ID=\"PARTY_1\"><partyIdentifier context=\"WSS_PORTFOLIO\">STP</partyIdentifier><partyIdentifier context=\"WSS_AREA\">NYKCRP</partyIdentifier><partyIdentifier context=\"WSS_CITY_CODE\">SYDOPS</partyIdentifier><partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier><partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier></tradeParty>" +
                "       <tradeParty ID=\"PARTY_2\"><partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">MARS INCORPORATED</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier><partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/><partyIdentifier context=\"MIDANZ_SHORT_NAME\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"CUSTACCOUNTSTRING\"/></tradeParty>" +
                "       <tradeParty ID=\"PARTY_3\"><partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier><partyIdentifier context=\"WSS_BROKER_NAME\">REUTERS</partyIdentifier><partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU</partyIdentifier></tradeParty>" +
                "       <tradeParty ID=\"PARTY_4\"><partyIdentifier context=\"WSS_TRADER\">XGB</partyIdentifier><partyIdentifier context=\"WSS_TRADER_NAME\">GB FXCORP API</partyIdentifier><partyIdentifier context=\"CAF_CODE\">CRS</partyIdentifier><partyLocation><locationIdentifier context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier></partyLocation></tradeParty>" +
                "       <tradeParty ID=\"PARTY_5\"><partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier><partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier><partyLocation><locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"></locationIdentifier></partyLocation></tradeParty>" +
                "       <tradeParty ID=\"PARTY_6\"><partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/><partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/></tradeParty>" +
                "       <tradeParty ID=\"PARTY_7\"><partyIdentifier context=\"WSS_ORIGINAL_TRADER\">GB FXCORP API</partyIdentifier></tradeParty>" +
                "       <tradeDetail xsi:type=\"SimpleArrangement_Type\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                "           <tradePrice xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\"><fixedRate><value>1.43166</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></tradePrice>" +
                "           <referencePrice xsi:type=\"FixedRate_Type\"><purpose>MARKET_MID</purpose><fixedRate><value>1.43172</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></referencePrice>" +
                "           <referencePrice xsi:type=\"FixedRate_Type\"><purpose>MARKET_BID</purpose><fixedRate><value>1.43166</value></fixedRate><spotRate><value>1.43166</value></spotRate><forwardMargin><value measure=\"Points\">0</value></forwardMargin><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></referencePrice>" +
                "           <Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_2\"/><receiverParty partyReference=\"PARTY_1\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier context=\"ISO4217\">GBP</identifier></asset><quantity>1674947</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2016-03-16T00:00:00.000Z</dateTime></deliveryPeriod></Commitment>" +
                "           <Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_1\"/><receiverParty partyReference=\"PARTY_2\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier context=\"ISO4217\">USD</identifier></asset><quantity>2397954.62</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2016-03-16T00:00:00.000Z</dateTime></deliveryPeriod></Commitment>" +
                "           <margin><marginType>SALES_MARGIN_SPOT</marginType><rate xsi:type=\"FixedRate_Type\"><fixedRate><value measure=\"Points\">0</value></fixedRate><priceSpecification xsi:type=\"DifferentialPrice_Type\"><referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/></priceSpecification></rate></margin>" +
                "           <margin><marginType>SALES_MARGIN_FWD</marginType><rate xsi:type=\"FixedRate_Type\"><fixedRate><value measure=\"Points\">0</value></fixedRate><priceSpecification xsi:type=\"DifferentialPrice_Type\"><referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/></priceSpecification></rate></margin>" +
                "           <margin><marginType>SALES_MARGIN_TOTAL</marginType><amount><asset><identifier context=\"ISO4217\">USD</identifier></asset><quantity>0</quantity></amount></margin>" +
                "           <relatedComponent><relationship>RATE_TO_BASE_BOUGHTCCY</relationship><rate xsi:type=\"FixedRate_Type\"><fixedRate><value>1.4316599988</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle></quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></rate></relatedComponent>" +
                "           <relatedComponent><relationship>RATE_TO_BASE_SOLDCCY</relationship><rate xsi:type=\"FixedRate_Type\"><fixedRate><value>1</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle></quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">USD</identifier></unitCurrency></priceSpecification></rate></relatedComponent>" +
                "       </tradeDetail>" +
                "</tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage = (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;
    }

    private TradeMessageWrapperType buildSwapTradeMessageForFXEasy() throws JAXBException {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<tradeMessage>" +
                "       <messageHeader>" +
                "           <sourceSystemMessageID>100599276000001</sourceSystemMessageID>" +
                "           <sourceSystemCreationDateTime>2016-03-14T00:58:23.000Z</sourceSystemCreationDateTime>" +
                "           <basedOnMessageForm>" +
                "               <name>tradeMessage</name>" +
                "               <version>2.03.1</version>" +
                "           </basedOnMessageForm>" +
                "           <emittedBySourceSystemInstance><countryCode>AU</countryCode><name>WSS</name><version>5.0.1</version><ownedByDomain><name>INSTITUTIONAL_MARKETS</name></ownedByDomain></emittedBySourceSystemInstance>" +
                "       </messageHeader>" +
                "       <tradeHeader>" +
                "           <tradeIdentifier>" +
                "               <party partyReference=\"PARTY_1\"/>" +
                "                   <arrangement>" +
                "                       <arrangementIdentifier context=\"WSS_TRANSACTION_ID\">100599276000001</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_DEAL_NUMBER\">NYKCRP.1603146901519</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_TRADE_TYPE\">B</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\">YCDYZNMZ3J</arrangementIdentifier>" +
                "                       <arrangementIdentifier context=\"WSS_OTC_USI\">86138426L0A0</arrangementIdentifier>" +
                "                   </arrangement>" +
                "           </tradeIdentifier>" +
                "           <relatedTradeIdentifier>" +
                "               <tradeRelationship>UNKNOWN</tradeRelationship>" +
                "                   <arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>ORIGINAL_TRADE</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_ORIGINAL_DEAL\"></arrangementIdentifier>" +
                "               <arrangementIdentifier context=\"WSS_ORIGINAL_TID\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>PREVIOUS_TRADE</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/><arrangementIdentifier context=\"WSS_OTC_USI\"/><arrangementIdentifier context=\"WSS_PREV_DEAL\"/>" +
                "               <arrangementIdentifier context=\"WSS_PREV_TID\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>LINK_TRADE</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_OTC_LINKID\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <relatedTradeIdentifier><tradeRelationship>UNKNOWN</tradeRelationship>" +
                "               <arrangementIdentifier context=\"WSS_AUX_TID\"/><arrangementIdentifier context=\"WSS_AUX_MST_TID\"/>" +
                "               <arrangementIdentifier context=\"WSS_AUX_DEAL\"/><arrangementIdentifier context=\"WSS_AUX_MST_DEAL\"/>" +
                "           </relatedTradeIdentifier>" +
                "           <productIdentifier>" +
                "               <identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier>" +
                "               <identifier context=\"FX_PRODUCT_CODE\">SWAP</identifier>" +
                "               <identifier context=\"FX_SWAP_LEG\">1</identifier>" +
                "               <identifier context=\"SWAP_TID\">100599276000002</identifier>" +
                "               <identifier context=\"QUOTE_PAIR\">GBPUSD</identifier>" +
                "           </productIdentifier>" +
                "           <channelIdentifier>" +
                "               <identifier context=\"WSS_SOURCESYSTEM\">FXALL_RFS</identifier>" +
                "               <identifier context=\"WSS_SOURCEDEALID\">14666234</identifier>" +
                "               <identifier context=\"WSS_NEWREFERENCECOPY\">RET-AD_14666234</identifier>" +
                "               <identifier context=\"WSS_CHANNELDEALID\"/>" +
                "               <identifier context=\"WSS_TAKERMEMO\">Submitted via ANZ Australia FX Easy instance.</identifier>" +
                "           </channelIdentifier>" +
                "           <isMultitradeComponent>true</isMultitradeComponent>" +
                "           <sourceSystemOperation>CREATE</sourceSystemOperation>" +
                "           <tradeBusinessEvent><eventIdentifier context=\"FX_TRADE_EVENT\">NEW</eventIdentifier><eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier><reason context=\"WSS_CANCEL_AMEND_REASON\"/></tradeBusinessEvent><authorisation>NOT_SPECIFIED</authorisation><arrangementDate>2016-03-14T00:00:00.000Z</arrangementDate><regulatoryEnvironment reportingRegime=\"\"><executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/><supervisoryEntity><partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/></supervisoryEntity></regulatoryEnvironment><reallocationRequired>false</reallocationRequired><tradeDateStamp event=\"WSS_SPOT_DATE\">2016-03-16T00:00:00.000Z</tradeDateStamp><tradeDateStamp event=\"OTC_Execution_DateTime\">2016-03-15T00:58:22.000Z</tradeDateStamp><tradeDateStamp event=\"Trade_Entry_DateTime\">2016-03-14T00:58:23.000Z</tradeDateStamp><tradeDateStamp event=\"WSS_SYSTEM_DATE\">2016-03-14T00:00:00.000Z</tradeDateStamp><initiationMethod>UNKNOWN</initiationMethod>" +
                "       </tradeHeader>" +
                "       <tradeParty ID=\"PARTY_1\"><partyIdentifier context=\"WSS_PORTFOLIO\">STP</partyIdentifier><partyIdentifier context=\"WSS_AREA\">NYKCRP</partyIdentifier><partyIdentifier context=\"WSS_CITY_CODE\">SYDOPS</partyIdentifier><partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier><partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier></tradeParty>" +
                "       <tradeParty ID=\"PARTY_2\"><partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">MARS INCORPORATED</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier><partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/><partyIdentifier context=\"MIDANZ_SHORT_NAME\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"CUSTACCOUNTSTRING\"/></tradeParty>" +
                "       <tradeParty ID=\"PARTY_3\"><partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier><partyIdentifier context=\"WSS_BROKER_NAME\">REUTERS</partyIdentifier><partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU</partyIdentifier></tradeParty>" +
                "       <tradeParty ID=\"PARTY_4\"><partyIdentifier context=\"WSS_TRADER\">XGB</partyIdentifier><partyIdentifier context=\"WSS_TRADER_NAME\">GB FXCORP API</partyIdentifier><partyIdentifier context=\"CAF_CODE\">CRS</partyIdentifier><partyLocation><locationIdentifier context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier></partyLocation></tradeParty>" +
                "       <tradeParty ID=\"PARTY_5\"><partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier><partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier><partyLocation><locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"></locationIdentifier></partyLocation></tradeParty>" +
                "       <tradeParty ID=\"PARTY_6\"><partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/><partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/></tradeParty>" +
                "       <tradeParty ID=\"PARTY_7\"><partyIdentifier context=\"WSS_ORIGINAL_TRADER\">GB FXCORP API</partyIdentifier></tradeParty>" +
                "       <tradeDetail xsi:type=\"SimpleArrangement_Type\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                "           <tradePrice xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\"><fixedRate><value>1.43166</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></tradePrice>" +
                "           <referencePrice xsi:type=\"FixedRate_Type\"><purpose>MARKET_MID</purpose><fixedRate><value>1.43172</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></referencePrice>" +
                "           <referencePrice xsi:type=\"FixedRate_Type\"><purpose>MARKET_BID</purpose><fixedRate><value>1.43166</value></fixedRate><spotRate><value>1.43166</value></spotRate><forwardMargin><value measure=\"Points\">0</value></forwardMargin><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></referencePrice>" +
                "           <Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_2\"/><receiverParty partyReference=\"PARTY_1\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier context=\"ISO4217\">GBP</identifier></asset><quantity>1674947</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2016-03-16T00:00:00.000Z</dateTime></deliveryPeriod></Commitment>" +
                "           <Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_1\"/><receiverParty partyReference=\"PARTY_2\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier context=\"ISO4217\">USD</identifier></asset><quantity>2397954.62</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2016-03-16T00:00:00.000Z</dateTime></deliveryPeriod></Commitment>" +
                "           <margin><marginType>SALES_MARGIN_SPOT</marginType><rate xsi:type=\"FixedRate_Type\"><fixedRate><value measure=\"Points\">0</value></fixedRate><priceSpecification xsi:type=\"DifferentialPrice_Type\"><referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/></priceSpecification></rate></margin>" +
                "           <margin><marginType>SALES_MARGIN_FWD</marginType><rate xsi:type=\"FixedRate_Type\"><fixedRate><value measure=\"Points\">0</value></fixedRate><priceSpecification xsi:type=\"DifferentialPrice_Type\"><referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/></priceSpecification></rate></margin>" +
                "           <margin><marginType>SALES_MARGIN_TOTAL</marginType><amount><asset><identifier context=\"ISO4217\">USD</identifier></asset><quantity>0</quantity></amount></margin>" +
                "           <relatedComponent><relationship>RATE_TO_BASE_BOUGHTCCY</relationship><rate xsi:type=\"FixedRate_Type\"><fixedRate><value>1.4316599988</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle></quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></rate></relatedComponent>" +
                "           <relatedComponent><relationship>RATE_TO_BASE_SOLDCCY</relationship><rate xsi:type=\"FixedRate_Type\"><fixedRate><value>1</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle></quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">USD</identifier></unitCurrency></priceSpecification></rate></relatedComponent>" +
                "       </tradeDetail>" +
                "</tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage = (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;
    }


    @Test
    public void testBuildSwapTradeMessage_FarLeg() throws BuilderException, JAXBException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildSwapTradeMessage_FarLeg();
        WssDeal wssDeal = builder.build(tradeMessage);
        Assert.assertEquals("100599276000002", wssDeal.getId());
        Assert.assertEquals("FXALL_RFS", wssDeal.getSourceSystem());
        Assert.assertEquals("100599276000002", wssDeal.getWssTransactionId());
        Assert.assertEquals("SWAP", wssDeal.getCounterDealType());
        Assert.assertEquals("14/03/2016 00:58:23", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("GBPUSD", wssDeal.getSymbol());
        Assert.assertEquals("CORP", wssDeal.getDealType());
        Assert.assertEquals("NYKCRP.1603146901519", wssDeal.getDealId());
        Assert.assertEquals("1591728.04", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("1109354.98", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("USD", wssDeal.getTermsCurrency());
        Assert.assertEquals("GBP", wssDeal.getBaseCurrency());
        Assert.assertEquals("SPDEE:1ilqubioz", wssDeal.getRealtedDealId());
        Assert.assertEquals("14666234", wssDeal.getCounterDealId());
        Assert.assertEquals("MARINGFXNYK", wssDeal.getCounterparty());
        Assert.assertEquals("MARINGFXNYK", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("XGB", wssDeal.getPositionParty());
        Assert.assertEquals("STP", wssDeal.getPositionAccount());
        Assert.assertEquals("NYKCRP", wssDeal.getWssArea());
        Assert.assertEquals("AU", wssDeal.getWssTraderLocation());
        Assert.assertEquals("USDGBP", wssDeal.getOriginalSymbol());
        Assert.assertEquals("1.434823", wssDeal.getClientPrice().getPlainString());
        Assert.assertEquals("16/03/2016 00:00:00", simpleDateFormat.format(wssDeal.getSpotDate()));
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("INVERSE", wssDeal.getQuoteStyle());
        Assert.assertEquals("REU", wssDeal.getProxyId());
        Assert.assertEquals("NEW", wssDeal.getDealStatus());
        Assert.assertEquals("", wssDeal.getCancelReason());
        Assert.assertEquals("", wssDeal.getOrigDealId());
        Assert.assertEquals("SELL", wssDeal.getSide().getCode());

    }

    private TradeMessageWrapperType buildSwapTradeMessage_FarLeg() throws JAXBException {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<tradeMessage>" +
                "           <messageHeader>" +
                "               <sourceSystemMessageID>100599276000002</sourceSystemMessageID>" +
                "               <sourceSystemCreationDateTime>2016-03-14T00:58:23.000Z</sourceSystemCreationDateTime>" +
                "               <basedOnMessageForm>" +
                "                   <name>tradeMessage</name>" +
                "                   <version>2.03.1</version>" +
                "               </basedOnMessageForm>" +
                "               <emittedBySourceSystemInstance>" +
                "                   <countryCode>AU</countryCode><name>WSS</name><version>5.0.1</version><ownedByDomain><name>INSTITUTIONAL_MARKETS</name></ownedByDomain>" +
                "               </emittedBySourceSystemInstance>" +
                "           </messageHeader>" +
                "           <tradeHeader><tradeIdentifier><party partyReference=\"PARTY_1\"/><arrangement><arrangementIdentifier context=\"WSS_TRANSACTION_ID\">100599276000002</arrangementIdentifier><arrangementIdentifier context=\"WSS_DEAL_NUMBER\">NYKCRP.1603146901519</arrangementIdentifier><arrangementIdentifier context=\"WSS_TRADE_TYPE\">S</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\">YCDYZNMZ3J</arrangementIdentifier><arrangementIdentifier context=\"WSS_OTC_USI\">86138426L1A0</arrangementIdentifier></arrangement></tradeIdentifier><relatedTradeIdentifier><tradeRelationship>UNKNOWN</tradeRelationship><arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>ORIGINAL_TRADE</tradeRelationship><arrangementIdentifier context=\"WSS_ORIGINAL_DEAL\"></arrangementIdentifier><arrangementIdentifier context=\"WSS_ORIGINAL_TID\"/></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>PREVIOUS_TRADE</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/><arrangementIdentifier context=\"WSS_OTC_USI\"/><arrangementIdentifier context=\"WSS_PREV_DEAL\"/><arrangementIdentifier context=\"WSS_PREV_TID\"/></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>LINK_TRADE</tradeRelationship><arrangementIdentifier context=\"WSS_OTC_LINKID\"/></relatedTradeIdentifier><relatedTradeIdentifier><tradeRelationship>UNKNOWN</tradeRelationship><arrangementIdentifier context=\"WSS_AUX_TID\"/><arrangementIdentifier context=\"WSS_AUX_MST_TID\"/><arrangementIdentifier context=\"WSS_AUX_DEAL\"/><arrangementIdentifier context=\"WSS_AUX_MST_DEAL\"/></relatedTradeIdentifier><productIdentifier><identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier><identifier context=\"FX_PRODUCT_CODE\">SWAP</identifier><identifier context=\"FX_SWAP_LEG\">2</identifier><identifier context=\"SWAP_TID\">100599276000002</identifier><identifier context=\"QUOTE_PAIR\">GBPUSD</identifier></productIdentifier><channelIdentifier><identifier context=\"WSS_SOURCESYSTEM\">FXALL_RFS</identifier><identifier context=\"WSS_SOURCEDEALID\">14666234</identifier><identifier context=\"WSS_NEWREFERENCECOPY\">RET-AD_14666234</identifier><identifier context=\"WSS_CHANNELDEALID\"/><identifier context=\"WSS_TAKERMEMO\">SPDEE:1ilqubioz</identifier></channelIdentifier><isMultitradeComponent>true</isMultitradeComponent><sourceSystemOperation>CREATE</sourceSystemOperation><tradeBusinessEvent><eventIdentifier context=\"FX_TRADE_EVENT\">NEW</eventIdentifier><eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier><reason context=\"WSS_CANCEL_AMEND_REASON\"/></tradeBusinessEvent><authorisation>NOT_SPECIFIED</authorisation><arrangementDate>2016-03-14T00:00:00.000Z</arrangementDate><regulatoryEnvironment reportingRegime=\"\"><executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/><supervisoryEntity><partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/></supervisoryEntity></regulatoryEnvironment><reallocationRequired>false</reallocationRequired><tradeDateStamp event=\"WSS_SPOT_DATE\">2016-03-16T00:00:00.000Z</tradeDateStamp><tradeDateStamp event=\"OTC_Execution_DateTime\">2016-03-14T13:58:22.000Z</tradeDateStamp><tradeDateStamp event=\"Trade_Entry_DateTime\">2016-03-14T00:58:23.000Z</tradeDateStamp><tradeDateStamp event=\"WSS_SYSTEM_DATE\">2016-03-14T00:00:00.000Z</tradeDateStamp><initiationMethod>UNKNOWN</initiationMethod></tradeHeader>" +
                "           <tradeParty ID=\"PARTY_1\"><partyIdentifier context=\"WSS_PORTFOLIO\">STP</partyIdentifier><partyIdentifier context=\"WSS_AREA\">NYKCRP</partyIdentifier><partyIdentifier context=\"WSS_CITY_CODE\">SYDOPS</partyIdentifier><partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier><partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier></tradeParty>" +
                "           <tradeParty ID=\"PARTY_2\"><partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">MARS INCORPORATED</partyIdentifier><partyIdentifier context=\"WSS_CUSTOMER_TYPE\">CORP</partyIdentifier><partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/><partyIdentifier context=\"MIDANZ_SHORT_NAME\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">MARINGFXNYK</partyIdentifier><partyIdentifier context=\"CUSTACCOUNTSTRING\"/></tradeParty>" +
                "           <tradeParty ID=\"PARTY_3\"><partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier><partyIdentifier context=\"WSS_BROKER_NAME\">REUTERS</partyIdentifier><partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU</partyIdentifier></tradeParty>" +
                "           <tradeParty ID=\"PARTY_4\"><partyIdentifier context=\"WSS_TRADER\">XGB</partyIdentifier><partyIdentifier context=\"WSS_TRADER_NAME\">GB FXCORP API</partyIdentifier><partyIdentifier context=\"CAF_CODE\">CRS</partyIdentifier><partyLocation><locationIdentifier context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier></partyLocation></tradeParty>" +
                "           <tradeParty ID=\"PARTY_5\"><partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier><partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier><partyLocation><locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"></locationIdentifier></partyLocation></tradeParty>" +
                "           <tradeParty ID=\"PARTY_6\"><partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/><partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/></tradeParty>" +
                "           <tradeParty ID=\"PARTY_7\"><partyIdentifier context=\"WSS_ORIGINAL_TRADER\">GB FXCORP API</partyIdentifier></tradeParty>" +
                "           <tradeDetail xsi:type=\"SimpleArrangement_Type\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><tradePrice xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\"><fixedRate><value>1.434823</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>INVERSE</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></tradePrice><referencePrice xsi:type=\"FixedRate_Type\"><purpose>MARKET_MID</purpose><fixedRate><value>1.434821</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></referencePrice><referencePrice xsi:type=\"FixedRate_Type\"><purpose>MARKET_BID</purpose><fixedRate><value>1.43166</value></fixedRate><spotRate><value>1.43166</value></spotRate><forwardMargin><value measure=\"Points\">0</value></forwardMargin><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle>DIRECT</quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></referencePrice><Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_2\"/><receiverParty partyReference=\"PARTY_1\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier context=\"ISO4217\">USD</identifier></asset><quantity>1591728.04</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2016-12-21T00:00:00.000Z</dateTime></deliveryPeriod></Commitment><Commitment xsi:type=\"DeliverableCommitment_Type\"><delivererParty partyReference=\"PARTY_1\"/><receiverParty partyReference=\"PARTY_2\"/><deliverable xsi:type=\"SimpleResourceParcel_Type\"><asset><identifier context=\"ISO4217\">GBP</identifier></asset><quantity>1109354.98</quantity></deliverable><deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\"><dateTime>2016-12-21T00:00:00.000Z</dateTime></deliveryPeriod></Commitment><margin><marginType>SALES_MARGIN_SPOT</marginType><rate xsi:type=\"FixedRate_Type\"><fixedRate><value measure=\"Points\">0</value></fixedRate><priceSpecification xsi:type=\"DifferentialPrice_Type\"><referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/></priceSpecification></rate></margin><margin><marginType>SALES_MARGIN_FWD</marginType><rate xsi:type=\"FixedRate_Type\"><fixedRate><value measure=\"Points\">0</value></fixedRate><priceSpecification xsi:type=\"DifferentialPrice_Type\"><referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/></priceSpecification></rate></margin><margin><marginType>SALES_MARGIN_TOTAL</marginType><amount><asset><identifier context=\"ISO4217\">USD</identifier></asset><quantity>0</quantity></amount></margin><relatedComponent><relationship>RATE_TO_BASE_BOUGHTCCY</relationship><rate xsi:type=\"FixedRate_Type\"><fixedRate><value>1.4316599988</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle></quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">GBP</identifier></unitCurrency></priceSpecification></rate></relatedComponent><relatedComponent><relationship>RATE_TO_BASE_SOLDCCY</relationship><rate xsi:type=\"FixedRate_Type\"><fixedRate><value>1</value></fixedRate><priceSpecification xsi:type=\"ExchangeRateSpecification_Type\"><quoteStyle></quoteStyle><termsCurrency><identifier context=\"ISO4217\">USD</identifier></termsCurrency><unitCurrency><identifier context=\"ISO4217\">USD</identifier></unitCurrency></priceSpecification></rate></relatedComponent></tradeDetail>" +
                "</tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage = (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;
    }


    @Test
    public void testBuildCLSTradeMessage() throws BuilderException, JAXBException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        TradeMessageWrapperType tradeMessage = buildCLSTradeMessage();
        WssDeal wssDeal = builder.build(tradeMessage);

        Assert.assertEquals("102538390000000", wssDeal.getId());
        Assert.assertEquals("CLS", wssDeal.getSourceSystem());
        Assert.assertEquals("102538390000000", wssDeal.getWssTransactionId());
        Assert.assertEquals("FORWARD", wssDeal.getCounterDealType());
        Assert.assertEquals("03/08/2016 17:05:41", simpleDateFormat.format(wssDeal.getTradeDateTime()));
        Assert.assertEquals("EURHKD", wssDeal.getSymbol());
        Assert.assertEquals("BANK", wssDeal.getDealType());
        Assert.assertEquals("SYDCLS.1608030000070", wssDeal.getDealId());
        Assert.assertEquals("491219400", wssDeal.getTermsQuantity().getPlainString());
        Assert.assertEquals("58000000", wssDeal.getQuantity().getPlainString());
        Assert.assertEquals("HKD", wssDeal.getTermsCurrency());
        Assert.assertEquals("EUR", wssDeal.getBaseCurrency());
        Assert.assertEquals("CLS2016O_199234597", wssDeal.getRealtedDealId());
        Assert.assertEquals("CLS2016O_199234597", wssDeal.getCounterDealId());
        Assert.assertEquals("INGBNL2A", wssDeal.getCounterparty());
        Assert.assertEquals("INGBNL2A", wssDeal.getCounterpartyGroup());
        Assert.assertEquals("CL_", wssDeal.getPositionParty());
        Assert.assertEquals("CLS", wssDeal.getPositionAccount());
        Assert.assertEquals("SYDCLS", wssDeal.getWssArea());
        Assert.assertEquals("EURHKD", wssDeal.getOriginalSymbol());
        Assert.assertEquals("AU", wssDeal.getSettlementRegion());
        Assert.assertEquals("NEW", wssDeal.getDealStatus());
        Assert.assertEquals("", wssDeal.getCancelReason());
        Assert.assertEquals("", wssDeal.getOrigDealId());
        Assert.assertEquals("BUY", wssDeal.getSide().getCode());
    }

    private TradeMessageWrapperType buildCLSTradeMessage() throws JAXBException {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<tradeMessage>\n" +
                "    <messageHeader>\n" +
                "        <sourceSystemMessageID>102538390000000</sourceSystemMessageID>\n" +
                "        <sourceSystemCreationDateTime>2016-08-03T17:05:41.000Z</sourceSystemCreationDateTime>\n" +
                "        <basedOnMessageForm>\n" +
                "            <name>tradeMessage</name>\n" +
                "            <version>2.04.1</version>\n" +
                "        </basedOnMessageForm>\n" +
                "        <emittedBySourceSystemInstance>\n" +
                "            <countryCode>AU</countryCode>\n" +
                "            <name>WSS</name>\n" +
                "            <version>5.0.1</version>\n" +
                "            <ownedByDomain>\n" +
                "                <name>INSTITUTIONAL_MARKETS</name>\n" +
                "            </ownedByDomain>\n" +
                "        </emittedBySourceSystemInstance>\n" +
                "    </messageHeader>\n" +
                "    <tradeHeader>\n" +
                "        <tradeIdentifier>\n" +
                "            <party partyReference=\"PARTY_1\"/>\n" +
                "            <arrangement>\n" +
                "                <arrangementIdentifier context=\"WSS_TRANSACTION_ID\">102538390000000</arrangementIdentifier>\n" +
                "                <arrangementIdentifier context=\"WSS_DEAL_NUMBER\">SYDCLS.1608030000070</arrangementIdentifier>\n" +
                "                <arrangementIdentifier context=\"WSS_TRADE_TYPE\">B</arrangementIdentifier>\n" +
                "                <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/>\n" +
                "                <arrangementIdentifier context=\"WSS_OTC_USI\"/>\n" +
                "            </arrangement>\n" +
                "        </tradeIdentifier>\n" +
                "        <relatedTradeIdentifier>\n" +
                "            <tradeRelationship>UNKNOWN</tradeRelationship>\n" +
                "            <arrangementIdentifier context=\"WSS_COMMON_ALLOCATION_ID\"></arrangementIdentifier>\n" +
                "        </relatedTradeIdentifier>\n" +
                "        <relatedTradeIdentifier>\n" +
                "            <tradeRelationship>ORIGINAL_TRADE</tradeRelationship>\n" +
                "            <arrangementIdentifier context=\"WSS_ORIGINAL_DEAL\"></arrangementIdentifier>\n" +
                "            <arrangementIdentifier context=\"WSS_ORIGINAL_TID\"/>\n" +
                "        </relatedTradeIdentifier>\n" +
                "        <relatedTradeIdentifier>\n" +
                "            <tradeRelationship>PREVIOUS_TRADE</tradeRelationship>\n" +
                "            <arrangementIdentifier context=\"WSS_OTC_USI_NAMESPACE\"/>\n" +
                "            <arrangementIdentifier context=\"WSS_OTC_USI\"/>\n" +
                "            <arrangementIdentifier context=\"WSS_PREV_DEAL\"/>\n" +
                "            <arrangementIdentifier context=\"WSS_PREV_TID\"/>\n" +
                "        </relatedTradeIdentifier>\n" +
                "        <relatedTradeIdentifier>\n" +
                "            <tradeRelationship>LINK_TRADE</tradeRelationship>\n" +
                "            <arrangementIdentifier context=\"WSS_OTC_LINKID\"/>\n" +
                "        </relatedTradeIdentifier>\n" +
                "        <relatedTradeIdentifier>\n" +
                "            <tradeRelationship>UNKNOWN</tradeRelationship>\n" +
                "            <arrangementIdentifier context=\"WSS_AUX_TID\"/>\n" +
                "            <arrangementIdentifier context=\"WSS_AUX_MST_TID\"/>\n" +
                "            <arrangementIdentifier context=\"WSS_AUX_DEAL\"/>\n" +
                "            <arrangementIdentifier context=\"WSS_AUX_MST_DEAL\"/>\n" +
                "        </relatedTradeIdentifier>\n" +
                "        <productIdentifier>\n" +
                "            <identifier context=\"FX_PRODUCT_CLASS\">FOREIGN_EXCHANGE</identifier>\n" +
                "            <identifier context=\"FX_PRODUCT_CODE\">FORWARD</identifier>\n" +
                "            <identifier context=\"SWAP_TID\"/>\n" +
                "            <identifier context=\"QUOTE_PAIR\">EURHKD</identifier>\n" +
                "        </productIdentifier>\n" +
                "        <channelIdentifier>\n" +
                "            <identifier context=\"WSS_SOURCESYSTEM\">CLS</identifier>\n" +
                "            <identifier context=\"WSS_SOURCEDEALID\">CLS2016O_199234597</identifier>\n" +
                "            <identifier context=\"WSS_NEWREFERENCECOPY\">CLS2016O_199234597</identifier>\n" +
                "            <identifier context=\"WSS_CHANNELDEALID\"/>\n" +
                "            <identifier context=\"WSS_TAKERMEMO\"/>\n" +
                "        </channelIdentifier>\n" +
                "        <isMultitradeComponent>false</isMultitradeComponent>\n" +
                "        <sourceSystemOperation>CREATE</sourceSystemOperation>\n" +
                "        <tradeBusinessEvent>\n" +
                "            <eventIdentifier context=\"FX_TRADE_EVENT\">NEW</eventIdentifier>\n" +
                "            <eventIdentifier context=\"WSS_BACKVALUE_FLAG\">false</eventIdentifier>\n" +
                "            <reason context=\"WSS_CANCEL_AMEND_REASON\"/>\n" +
                "        </tradeBusinessEvent>\n" +
                "        <authorisation>NOT_SPECIFIED</authorisation>\n" +
                "        <arrangementDate>2016-08-03T00:00:00.000Z</arrangementDate>\n" +
                "        <regulatoryEnvironment reportingRegime=\"\">\n" +
                "            <executionVenue context=\"WSS_OTC_EXECUTION_VENUE_TYPE\"/>\n" +
                "            <supervisoryEntity>\n" +
                "                <partyIdentifier context=\"WSS_OTC_SUPERVISORY_BODY\"/>\n" +
                "            </supervisoryEntity>\n" +
                "        </regulatoryEnvironment>\n" +
                "        <reallocationRequired>false</reallocationRequired>\n" +
                "        <tradeDateStamp event=\"WSS_SPOT_DATE\">2016-08-05T00:00:00.000Z</tradeDateStamp>\n" +
                "        <tradeDateStamp event=\"OTC_Execution_DateTime\">2016-08-02T20:05:34.000Z</tradeDateStamp>\n" +
                "        <tradeDateStamp event=\"Trade_Entry_DateTime\">2016-08-03T17:05:41.000Z</tradeDateStamp>\n" +
                "        <tradeDateStamp event=\"WSS_SYSTEM_DATE\">2016-08-03T00:00:00.000Z</tradeDateStamp>\n" +
                "        <initiationMethod>MATCH - NON-AGGRESSOR</initiationMethod>\n" +
                "    </tradeHeader>\n" +
                "    <tradeParty ID=\"PARTY_1\">\n" +
                "        <partyIdentifier context=\"WSS_PORTFOLIO\">CLS</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_AREA\">SYDCLS</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_CITY_CODE\">SYDOPS</partyIdentifier>\n" +
                "        <partyIdentifier context=\"MIDANZ_BOOK_CODE\">AUG</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier>\n" +
                "    </tradeParty>\n" +
                "    <tradeParty ID=\"PARTY_2\">\n" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">INGBNL2A</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">INGBNL2A</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">INGBNL2A</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">ING BANK N.V.</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_CUSTOMER_TYPE\">BANK</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_COUNTERPARTY_CODE\"/>\n" +
                "        <partyIdentifier context=\"MIDANZ_SHORT_NAME\">INGBNL2A</partyIdentifier>\n" +
                "        <partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">INGBNL2A</partyIdentifier>\n" +
                "        <partyIdentifier context=\"CUSTACCOUNTSTRING\">INXS</partyIdentifier>\n" +
                "    </tradeParty>\n" +
                "    <tradeParty ID=\"PARTY_3\">\n" +
                "        <partyIdentifier context=\"WSS_BROKER_CODE\">REU</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_BROKER_NAME\">REUTERS</partyIdentifier>\n" +
                "        <partyIdentifier context=\"MIDANZ_BROKER_CODE\">REU</partyIdentifier>\n" +
                "    </tradeParty>\n" +
                "    <tradeParty ID=\"PARTY_4\">\n" +
                "        <partyIdentifier context=\"WSS_TRADER\">CL_</partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_TRADER_NAME\">CLS I/O SWAPS CREATOR</partyIdentifier>\n" +
                "        <partyIdentifier context=\"CAF_CODE\"/>\n" +
                "        <partyLocation>\n" +
                "            <locationIdentifier context=\"WSS_TRADER_LOCATION\"></locationIdentifier>\n" +
                "        </partyLocation>\n" +
                "    </tradeParty>\n" +
                "    <tradeParty ID=\"PARTY_5\">\n" +
                "        <partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier>\n" +
                "        <partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier>\n" +
                "        <partyLocation>\n" +
                "            <locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"></locationIdentifier>\n" +
                "        </partyLocation>\n" +
                "    </tradeParty>\n" +
                "    <tradeParty ID=\"PARTY_6\">\n" +
                "        <partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/>\n" +
                "        <partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/>\n" +
                "    </tradeParty>\n" +
                "    <tradeParty ID=\"PARTY_7\">\n" +
                "        <partyIdentifier context=\"WSS_ORIGINAL_TRADER\">CLS I/O SWAPS CREATOR</partyIdentifier>\n" +
                "    </tradeParty>\n" +
                "    <settlementInstructions ID=\"SETTLEMENT_1\">\n" +
                "        <settlementMethod>BILATERAL</settlementMethod>\n" +
                "    </settlementInstructions>\n" +
                "    <settlementInstructions ID=\"SETTLEMENT_2\">\n" +
                "        <settlementMethod>BILATERAL</settlementMethod>\n" +
                "    </settlementInstructions>\n" +
                "    <tradeDetail xsi:type=\"SimpleArrangement_Type\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                "        <tradePrice xsi:type=\"FixedRate_Type\" ID=\"TRADE_PRICE\">\n" +
                "            <fixedRate>\n" +
                "                <value>8.4693</value>\n" +
                "            </fixedRate>\n" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">\n" +
                "                <quoteStyle>DIRECT</quoteStyle>\n" +
                "                <termsCurrency>\n" +
                "                    <identifier context=\"ISO4217\">HKD</identifier>\n" +
                "                </termsCurrency>\n" +
                "                <unitCurrency>\n" +
                "                    <identifier context=\"ISO4217\">EUR</identifier>\n" +
                "                </unitCurrency>\n" +
                "            </priceSpecification>\n" +
                "        </tradePrice>\n" +
                "        <referencePrice xsi:type=\"FixedRate_Type\">\n" +
                "            <purpose>MARKET_MID</purpose>\n" +
                "            <fixedRate>\n" +
                "                <value>0</value>\n" +
                "            </fixedRate>\n" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">\n" +
                "                <quoteStyle>DIRECT</quoteStyle>\n" +
                "                <termsCurrency>\n" +
                "                    <identifier context=\"ISO4217\">HKD</identifier>\n" +
                "                </termsCurrency>\n" +
                "                <unitCurrency>\n" +
                "                    <identifier context=\"ISO4217\">EUR</identifier>\n" +
                "                </unitCurrency>\n" +
                "            </priceSpecification>\n" +
                "        </referencePrice>\n" +
                "        <referencePrice xsi:type=\"FixedRate_Type\">\n" +
                "            <purpose>MARKET_BID</purpose>\n" +
                "            <fixedRate>\n" +
                "                <value>8.4693</value>\n" +
                "            </fixedRate>\n" +
                "            <spotRate>\n" +
                "                <value>8.4693</value>\n" +
                "            </spotRate>\n" +
                "            <forwardMargin>\n" +
                "                <value measure=\"Points\">0</value>\n" +
                "            </forwardMargin>\n" +
                "            <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">\n" +
                "                <quoteStyle>DIRECT</quoteStyle>\n" +
                "                <termsCurrency>\n" +
                "                    <identifier context=\"ISO4217\">HKD</identifier>\n" +
                "                </termsCurrency>\n" +
                "                <unitCurrency>\n" +
                "                    <identifier context=\"ISO4217\">EUR</identifier>\n" +
                "                </unitCurrency>\n" +
                "            </priceSpecification>\n" +
                "        </referencePrice>\n" +
                "        <Commitment xsi:type=\"DeliverableCommitment_Type\">\n" +
                "            <delivererParty partyReference=\"PARTY_2\"/>\n" +
                "            <receiverParty partyReference=\"PARTY_1\"/>\n" +
                "            <deliverable xsi:type=\"SimpleResourceParcel_Type\">\n" +
                "                <asset>\n" +
                "                    <identifier context=\"ISO4217\">EUR</identifier>\n" +
                "                </asset>\n" +
                "                <quantity>58000000</quantity>\n" +
                "            </deliverable>\n" +
                "            <deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">\n" +
                "                <dateTime>2016-08-03T00:00:00.000Z</dateTime>\n" +
                "            </deliveryPeriod>\n" +
                "            <settlementReference>SETTLEMENT_1</settlementReference>\n" +
                "        </Commitment>\n" +
                "        <Commitment xsi:type=\"DeliverableCommitment_Type\">\n" +
                "            <delivererParty partyReference=\"PARTY_1\"/>\n" +
                "            <receiverParty partyReference=\"PARTY_2\"/>\n" +
                "            <deliverable xsi:type=\"SimpleResourceParcel_Type\">\n" +
                "                <asset>\n" +
                "                    <identifier context=\"ISO4217\">HKD</identifier>\n" +
                "                </asset>\n" +
                "                <quantity>491219400</quantity>\n" +
                "            </deliverable>\n" +
                "            <deliveryPeriod xsi:type=\"TimeInstant_Type\" isAdjusted=\"true\">\n" +
                "                <dateTime>2016-08-03T00:00:00.000Z</dateTime>\n" +
                "            </deliveryPeriod>\n" +
                "            <settlementReference>SETTLEMENT_2</settlementReference>\n" +
                "        </Commitment>\n" +
                "        <margin>\n" +
                "            <marginType>SALES_MARGIN_SPOT</marginType>\n" +
                "            <rate xsi:type=\"FixedRate_Type\">\n" +
                "                <fixedRate>\n" +
                "                    <value measure=\"Points\">0</value>\n" +
                "                </fixedRate>\n" +
                "                <priceSpecification xsi:type=\"DifferentialPrice_Type\">\n" +
                "                    <referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/>\n" +
                "                </priceSpecification>\n" +
                "            </rate>\n" +
                "        </margin>\n" +
                "        <margin>\n" +
                "            <marginType>SALES_MARGIN_FWD</marginType>\n" +
                "            <rate xsi:type=\"FixedRate_Type\">\n" +
                "                <fixedRate>\n" +
                "                    <value measure=\"Points\">0</value>\n" +
                "                </fixedRate>\n" +
                "                <priceSpecification xsi:type=\"DifferentialPrice_Type\">\n" +
                "                    <referencePrice xsi:type=\"PriceHandle_Type\" priceReference=\"TRADE_PRICE\"/>\n" +
                "                </priceSpecification>\n" +
                "            </rate>\n" +
                "        </margin>\n" +
                "        <margin>\n" +
                "            <marginType>SALES_MARGIN_TOTAL</marginType>\n" +
                "            <amount>\n" +
                "                <asset>\n" +
                "                    <identifier context=\"ISO4217\">USD</identifier>\n" +
                "                </asset>\n" +
                "                <quantity>0</quantity>\n" +
                "            </amount>\n" +
                "        </margin>\n" +
                "        <relatedComponent>\n" +
                "            <relationship>RATE_TO_BASE_BOUGHTCCY</relationship>\n" +
                "            <rate xsi:type=\"FixedRate_Type\">\n" +
                "                <fixedRate>\n" +
                "                    <value>1.1167065029</value>\n" +
                "                </fixedRate>\n" +
                "                <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">\n" +
                "                    <quoteStyle>DIRECT</quoteStyle>\n" +
                "                    <termsCurrency>\n" +
                "                        <identifier context=\"ISO4217\">USD</identifier>\n" +
                "                    </termsCurrency>\n" +
                "                    <unitCurrency>\n" +
                "                        <identifier context=\"ISO4217\">EUR</identifier>\n" +
                "                    </unitCurrency>\n" +
                "                </priceSpecification>\n" +
                "            </rate>\n" +
                "        </relatedComponent>\n" +
                "        <relatedComponent>\n" +
                "            <relationship>RATE_TO_BASE_SOLDCCY</relationship>\n" +
                "            <rate xsi:type=\"FixedRate_Type\">\n" +
                "                <fixedRate>\n" +
                "                    <value>7.5841772012</value>\n" +
                "                </fixedRate>\n" +
                "                <priceSpecification xsi:type=\"ExchangeRateSpecification_Type\">\n" +
                "                    <quoteStyle>INVERSE</quoteStyle>\n" +
                "                    <termsCurrency>\n" +
                "                        <identifier context=\"ISO4217\">USD</identifier>\n" +
                "                    </termsCurrency>\n" +
                "                    <unitCurrency>\n" +
                "                        <identifier context=\"ISO4217\">HKD</identifier>\n" +
                "                    </unitCurrency>\n" +
                "                </priceSpecification>\n" +
                "            </rate>\n" +
                "        </relatedComponent>\n" +
                "    </tradeDetail>\n" +
                "    <tradeInstructions>\n" +
                "        <Line></Line>\n" +
                "    </tradeInstructions>\n" +
                "</tradeMessage>";
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        StringReader reader = new StringReader(xml);
        TradeMessageWrapperType tradeMessage = (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal
                (reader));
        return tradeMessage;
    }

}
