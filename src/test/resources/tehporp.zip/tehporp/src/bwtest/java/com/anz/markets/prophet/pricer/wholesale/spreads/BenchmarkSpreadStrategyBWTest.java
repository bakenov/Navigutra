package com.anz.markets.prophet.pricer.wholesale.spreads;


import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.pricer.pfp.PliableBook;
import com.anz.markets.prophet.pricer.pfp.cache.ClientPriceDataRegisterDependencyManager;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.pricer.wholesale.BenchmarkSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.DriverInstrumentWholesaleBookManagerTest;
import com.anz.markets.prophet.pricer.wholesale.WholesaleBook;
import org.junit.Test;

import java.io.IOException;

public class BenchmarkSpreadStrategyBWTest {


    private final BenchmarkSpreadStrategy benchmarkSpreadStrategy = new BenchmarkSpreadStrategy();

    private static final int REPS = 400_000, THRESHOLD = 1000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private DataRegisters dataRegisters = new DataRegisters();
    private ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager = new ClientPriceDataRegisterDependencyManager(dataRegisters);
    private PliableBook pliableBook = new PliableBook(Market.WSP_A, Instrument.AUDUSD,clientPriceDataRegisterDependencyManager.getClientPriceRegisters(Market.WSP_A,Instrument.AUDUSD));
    private WholesaleBook wholesaleBook = new WholesaleBook(Market.WSP_A, pliableBook);

    public BenchmarkSpreadStrategyBWTest() throws IOException {
        benchmarkSpreadStrategy.applyConfiguration(new DriverInstrumentWholesaleBookManagerTest().indexedConfigurationData);
    }

    public void scenario_SpreadBasedBookFormation() {

        wholesaleBook.reset();
        wholesaleBook.initInstrument(Instrument.AUDUSD);
        WholesaleBookFactorsImpl wholesaleBookFactors = wholesaleBook.getWholesaleBookFactors();

        wholesaleBookFactors.setBaseSpread(0.1);
        wholesaleBookFactors.setModelSpread(1.1);
        wholesaleBookFactors.addConfigSpread(Level.QTY_1M, 0.4);
        wholesaleBookFactors.addConfigSpread(Level.QTY_2M, 0.5);
        wholesaleBookFactors.addConfigSpread(Level.QTY_4M, 0.6);
        wholesaleBookFactors.addConfigSpread(Level.QTY_10M, 0.7);
        wholesaleBookFactors.addConfigSpread(Level.QTY_15M, 0.8);
        wholesaleBookFactors.addConfigSpread(Level.QTY_30M, 0.9);

        wholesaleBookFactors.setModelSpread(0.4);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_1M).setModelSpread(0.4);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_2M).setModelSpread(0.5);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_4M).setModelSpread(0.6);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_10M).setModelSpread(0.7);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_15M).setModelSpread(0.8);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_30M).setModelSpread(0.9);

        benchmarkSpreadStrategy.execute(wholesaleBook);
    }

    @Test
    public void test_SpreadBasedBookFormation() {
        helper.testAllocationNotExceeded(
                this::scenario_SpreadBasedBookFormation,
                REPS, REPS,
                THRESHOLD
        );
    }

}
