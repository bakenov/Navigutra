package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class ChronicleFailoverPerfTest extends ChronicleFailoverTestBase {

    @Override
    protected void setupExtra() {
        id = 0;
    }

    @Test
    public void perfTest() {
        final TradeImpl tradeToWrite = createTrade();
        final Activate activate = createActivate();

        final int activateSize = 0;
        final int tradeSize = 0;
        checkTradesActivation(activateSize, tradeSize);
        // this is slower than it should be 'cos of the various pauses in this test.
        for (int i = 1; i < 100; i++) {
            sendActivate(activate, i % 2);
            sendTrades(tradeToWrite, 1);
            checkTradesActivation(activateSize + i, tradeSize + i);
        }
    }
}
