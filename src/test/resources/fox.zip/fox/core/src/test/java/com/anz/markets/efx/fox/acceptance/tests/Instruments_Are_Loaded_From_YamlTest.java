package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.codec.pojo.matcher.InstrumentConfigMatcher;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class Instruments_Are_Loaded_From_YamlTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(Instruments_Are_Loaded_From_YamlTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private InstrumentRepository instrumentRepository;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("instrument.config.class.path", "conf/instrument-config-test.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        instrumentRepository = application.getApplicationContext().getBean(InstrumentRepository.class,"instrumentRepository");
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_see_venue_created_commands_and_events_on_startup() throws Exception {

        final InstrumentConfigMatcher test1Matcher = InstrumentConfigMatcher.build()
                .body().matches(InstrumentConfigMatcher.instrumentId().eq(InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT, Tenor.SP)))
                .body().matches(InstrumentConfigMatcher.pipSizeDivisor().eq(10000))
                .body().matches(InstrumentConfigMatcher.enabled().eq(Boolean.TRUE));

        final InstrumentConfigMatcher test2Matcher = InstrumentConfigMatcher.build()
                .body().matches(InstrumentConfigMatcher.instrumentId().eq(InstrumentKey.instrumentId("EURUSD", SecurityType.FXSPOT, Tenor.SP)))
                .body().matches(InstrumentConfigMatcher.pipSizeDivisor().eq(10000))
                .body().matches(InstrumentConfigMatcher.enabled().eq(Boolean.TRUE));

        final InstrumentConfigMatcher test3Matcher = InstrumentConfigMatcher.build()
                .body().matches(InstrumentConfigMatcher.instrumentId().eq(InstrumentKey.instrumentId("EURUSD", SecurityType.FXSPOT, Tenor.SP)))
                .body().matches(InstrumentConfigMatcher.pipSizeDivisor().eq(100))
                .body().matches(InstrumentConfigMatcher.enabled().eq(Boolean.FALSE));

        final InstrumentConfigMatcher test4Matcher = InstrumentConfigMatcher.build()
                .body().matches(InstrumentConfigMatcher.instrumentId().eq(InstrumentKey.instrumentId("USDKRW", SecurityType.FXNDF, Tenor.W1)))
                .body().matches(InstrumentConfigMatcher.pipSizeDivisor().eq(1000))
                .body().matches(InstrumentConfigMatcher.enabled().eq(Boolean.FALSE));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(test1Matcher)
                .thenMatching(test2Matcher)
                .thenMatching(test3Matcher)
                .thenMatching(test4Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(test1Matcher)
                .thenMatching(test2Matcher)
                .thenMatching(test3Matcher)
                .thenMatching(test4Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT, Tenor.SP)).pipSizeDivisor()).isEqualTo(10000);
        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("EURUSD", SecurityType.FXSPOT, Tenor.SP)).pipSizeDivisor()).isEqualTo(100);
        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("EURUSD", SecurityType.FXSPOT, Tenor.SP)).enabled()).isFalse();
        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("AUDJPY", SecurityType.FXSPOT, Tenor.SP)).pipSizeDivisor()).isEqualTo(100);
        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("CADJPY", SecurityType.FXSPOT, Tenor.SP)).pipSizeDivisor()).isEqualTo(100);
        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("USDKRW", SecurityType.FXNDF, Tenor.W1)).enabled()).isFalse();
        assertThat(instrumentRepository.lookup(InstrumentKey.instrumentId("USDKRW", SecurityType.FXNDF, Tenor.M1)).enabled()).isFalse();
    }
}
