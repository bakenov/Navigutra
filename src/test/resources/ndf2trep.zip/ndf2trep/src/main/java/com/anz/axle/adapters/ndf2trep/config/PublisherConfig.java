package com.anz.axle.adapters.ndf2trep.config;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.adapters.ndf2trep.publisher.NdfTrepDataSource;
import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.axle.servicelifecycle.FailsafeServiceLifecycle;
import com.anz.axle.servicelifecycle.ServiceLifecycle;
import com.anz.axle.trep.publisher.TrepDataSource;
import com.anz.axle.trep.publisher.TrepLogonHandler;
import com.anz.axle.trep.publisher.TrepPublisher;
import com.anz.axle.trep.publisher.TrepStreamableQueue;
import com.anz.axle.trep.publisher.config.EnableTrepPublishing;
import com.anz.axle.trep.publisher.config.TrepPublisherConfig;
import com.anz.markets.adapters.trep.config.Connection;
import com.anz.markets.adapters.trep.config.NonInteractiveProviderConnection;

@Configuration
@EnableTrepPublishing
public class PublisherConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(PublisherConfig.class);

    private static final String NDF_PUBLISHER_SESSION = "MarketDataPublisherSession";
    private static final String NDF_PUBLISHER_CONNECTION = "MarketDataPublisherConnection";

    @Autowired
    private TrepStreamableQueue trepStreamableQueue;


    @Bean
    public ServiceLifecycle trepLogonServiceLifecycle() {
        return new FailsafeServiceLifecycle("Trep Logon", LOGGER);
    }

    @Bean
    public TrepLogonHandler trepLogonHandler(final ServiceLifecycle trepLogonServiceLifecycle) {
        return new TrepLogonHandler() {
            @Override
            public void onLogon() {
                LOGGER.info("Logged on to TREP");
                trepLogonServiceLifecycle.start();
            }

            @Override
            public void onLogonFailed(final String reason) {
                LOGGER.error("Failed to log on to TREP: " + reason);
            }

            @Override
            public void onLogoff() {
                LOGGER.info("Logged off TREP");
                trepLogonServiceLifecycle.stop();
            }
        };
    }

    @Bean
    public Connection ndfTrepPublisherConnection(@Value("${ndf.trep.publishing.host}") final String hostName,
                                                 @Value("${ndf.trep.publishing.port}") final int port,
                                                 @Value("${ndf.trep.publishing.ipcTrace:0x10}") final int ipcTraceFlags,
                                                 @Value("${ndf.trep.publishing.dacsCbeEnabled:false}") final boolean dacsCbeEnabled,
                                                 @Value("${ndf.trep.publishing.dacsGenerateLocks:false}") final boolean dacsGenerateLocks,
                                                 @Value("${ndf.trep.publishing.dacsSbePubEnabled:false}") final boolean dacsSbePubEnabled,
                                                 @Value("${ndf.trep.publishing.dacsSbeSubEnabled:false}") final boolean dacsSbeSubEnabled,
                                                 @Value("${ndf.trep.publishing.connectionTimeout:10000}") final int connectionTimeout,
                                                 @Value("${ndf.trep.publishing.connectRetryInterval:15000}") final int connectRetryInterval,
                                                 @Value("${ndf.trep.publishing.maxRetryConnection:-1}") final int maxRetryConnection,
                                                 @Value("${ndf.trep.publishing.logFile:ndf-trep-publisher.log}") final String logFile
    ) {
        final NonInteractiveProviderConnection connection = new NonInteractiveProviderConnection(NDF_PUBLISHER_CONNECTION);
        connection.setPortNumber(port);
        connection.setDacsCbeEnabled(dacsCbeEnabled);
        connection.setDacsGenerateLocks(dacsGenerateLocks);
        connection.setDacsSbePubEnabled(dacsSbePubEnabled);
        connection.setDacsSbeSubEnabled(dacsSbeSubEnabled);
        connection.setServerList(hostName);
        connection.setIpcTraceFlags(ipcTraceFlags);
        connection.setConnectionTimeout(connectionTimeout);
        connection.setConnectRetryInterval(connectRetryInterval);
        connection.setLogFileName(logFile);
        connection.setMountTrace(true);
        connection.setTraceMsgTypes("ALL");
        connection.setTraceMsgDomains("ALL");

        // unfortunately have to cast it this way...
        final Map<String, Object> configMap = (Map<String, Object>) connection.getConfigMap();
        configMap.put("maxRetryCount", maxRetryConnection);
        return connection;
    }

    @Bean
    public TrepDataSource ndfTrepPublisherDataSource(@Value("${ndf.trep.publish.destination.servicename}") final String serviceName,
                                                     final RicRepository ricRepository) {
        return new NdfTrepDataSource(trepStreamableQueue, ricRepository, serviceName);
    }

    @Bean
    public TrepPublisher ndfTrepPublisher(final TrepPublisherConfig.TrepPublisherBuilder trepPublisherBuilder,
                                          final TrepDataSource ndfTrepPublisherDataSource,
                                          final Connection ndfTrepPublisherConnection,
                                          @Value("${ndf.trep.publishing.user}") final String username) {
        return trepPublisherBuilder
                .withApplicationName("ndf2trep")
                .withConnection(ndfTrepPublisherConnection, ndfTrepPublisherDataSource, username)
                .withSessionName(NDF_PUBLISHER_SESSION)
                .build();
    }

    @Bean
    public RicRepository ricRepository(@Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<String>> symbolVenuesFXSPOT,
                                       @Value("#{${venue.symbol.tenors.FXNDF}}") final Map<String, Map<String, Set<String>>> venueSymbolTenorsFXNDF,
                                       @Value("#{${venue.subscription.sourceId}}") final Map<String, String> venueSubscriptionSourceId,
                                       @Value("#{${venue.publish.sourceId}}") final Map<String, String> venuePublishSourceId,
                                       @Value("#{${venue.publish.serviceName}}") final Map<String, String> venuePublishServiceName,
                                       @Value("${ndf.trep.publish.destination.servicename}") final String serviceName) {

        return new RicRepository(symbolVenuesFXSPOT, venueSymbolTenorsFXNDF, venueSubscriptionSourceId, venuePublishSourceId, venuePublishServiceName, serviceName);
    }
}
