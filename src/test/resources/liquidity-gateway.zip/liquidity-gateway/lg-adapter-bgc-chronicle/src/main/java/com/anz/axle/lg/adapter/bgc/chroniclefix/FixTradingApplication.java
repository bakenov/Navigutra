package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.generators.MessageGenerator;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelReject;
import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;

import java.util.Objects;

public class FixTradingApplication extends FixSessionApplication implements MessageNotifier {

    private final ChronicleMessageHandler<ExecutionReport> executionReportHandler;
    private final ChronicleMessageHandler<OrderCancelReject> orderCancelRejectHandler;

    public FixTradingApplication(final ChronicleMessageHandler<ExecutionReport> executionReportHandler,
                                 final ChronicleMessageHandler<OrderCancelReject> orderCancelRejectHandler,
                                 final ApplicationLogonHandler applicationLogonHandler) {
        super(applicationLogonHandler);
        this.executionReportHandler = Objects.requireNonNull(executionReportHandler);
        this.orderCancelRejectHandler = Objects.requireNonNull(orderCancelRejectHandler);
    }

    @Override
    public MessageGenerator onExecutionReport(final ExecutionReport executionReport) {
        executionReportHandler.accept(executionReport);
        return null;
    }

    @Override
    public MessageGenerator onOrderCancelReject(final OrderCancelReject orderCancelReject) {
        orderCancelRejectHandler.accept(orderCancelReject);
        return null;
    }
}