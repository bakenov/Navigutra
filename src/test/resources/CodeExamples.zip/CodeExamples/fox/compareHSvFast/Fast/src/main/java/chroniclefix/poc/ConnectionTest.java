package chroniclefix.poc;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.NetworkStatsListener;
import net.openhft.chronicle.network.connection.ClientConnectionMonitor;
import net.openhft.chronicle.network.connection.SocketAddressSupplier;

public class ConnectionTest {
    public static void main(String[] args) throws InterruptedException, IOException {
        String address = "10.54.180.239:16105";
        if (args.length > 0)
            address = args[0];
        final boolean ok = connect(address);
        if (ok)
            System.out.println("OK!!!!!!!!!");
        else
            System.err.println("FAILED");
        return;
    }

    private static boolean connect(final String address) throws InterruptedException, IOException {
        System.setProperty("client.timeout", "500");
        System.setProperty("tcp.client.buffer.size", "65536");
        System.setProperty("connectionStrategy.socketConnectionTimeoutMs", "10");
        AlwaysStartOnPrimaryConnectionStrategy connectionStrategy = new AlwaysStartOnPrimaryConnectionStrategy();

        final SocketAddressSupplier socketAddressSupplier = new SocketAddressSupplier(new String[]{address}, "MDANZUAT1:Fastmatch1");
        final NetworkStatsListener networkStatsListener = null;
        final boolean didLogin = false;
        ClientConnectionMonitor loggingClientConnectionMonitor = new ClientConnectionMonitor() {
            public void onConnected(String name, @NotNull SocketAddress socketAddress) {
                Jvm.warn().on(this.getClass(), "onConnected name=" + name + ",socketAddress=" + socketAddress);
            }
            public void onDisconnected(String name, @NotNull SocketAddress socketAddress) {
                Jvm.warn().on(this.getClass(), "onDisconnected name=" + name + ",socketAddress=" + socketAddress);
            }
        };
        final SocketChannel channel = connectionStrategy.connect("MDANZUAT1:Fastmatch1", socketAddressSupplier, didLogin, loggingClientConnectionMonitor);
        if (channel == null) {
            System.err.println("NULL");
            return false;
        }
        final boolean ok = channel.isConnected();
        channel.close();
        return ok;
    }
}
