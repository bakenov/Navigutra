package com.anz.markets.efx.ngaro.core;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Unit test for {@link ImmutableAsciiString}
 */
@RunWith(Spockito.class)
public class ImmutableAsciiStringTest {

    @Test
    public void isEmpty() {
        assertEquals("should not be empty", false, new ImmutableAsciiString("Bla").isEmpty());
        assertEquals("should be empty", true, new ImmutableAsciiString("").isEmpty());
    }

    @Test
    public void length() {
        assertEquals("length should be 3", 3, new ImmutableAsciiString("Bla").length());
        assertEquals("length should be 0", 0, new ImmutableAsciiString("").length());
        assertEquals("length should be 4", 4, new ImmutableAsciiString("ABCD\0\0\0\0").length());
        assertEquals("length should be 8", 8, new ImmutableAsciiString("ABCD\1\1\1\1").length());
    }

    @Test
    public void contains() {
        final ImmutableAsciiString bla = new ImmutableAsciiString("Bla");
        assertEquals("should contain itself", true, bla.contains(bla));
        assertEquals("should contain new equal instance", true, bla.contains(AsciiString.immutable("Bla")));
        assertEquals("should contain prefix", true, bla.contains(AsciiString.immutable("Bl")));
        assertEquals("should contain postfix", true, bla.contains(AsciiString.immutable("la")));
        assertEquals("should contain substring", true, bla.contains(AsciiString.immutable("l")));
        assertEquals("should contain empty string", true, bla.contains(AsciiString.immutable("")));
    }

    @Test
    public void indexOf() {
        //without from index
        final ImmutableAsciiString bla = new ImmutableAsciiString("Bla");
        assertEquals("indexOf(..) should return 0 for itself", 0, bla.indexOf(bla));
        assertEquals("indexOf(..) should return 0 for new equal instance", 0, bla.indexOf(AsciiString.immutable("Bla")));
        assertEquals("indexOf(..) should return 0 for prefix", 0, bla.indexOf(AsciiString.immutable("Bl")));
        assertEquals("indexOf(..) should return index for postfix", 1, bla.indexOf(AsciiString.immutable("la")));
        assertEquals("indexOf(..) should return index for postfix", 2, bla.indexOf(AsciiString.immutable("a")));
        assertEquals("indexOf(..) should return index for substring", 1, bla.indexOf(AsciiString.immutable("l")));
        assertEquals("indexOf(..) should return 0 for empty string", 0, bla.indexOf(AsciiString.immutable("")));
        //with from index
        final ImmutableAsciiString blaBla = new ImmutableAsciiString("BlaBla");
        assertEquals("indexOf(..) should return 0 for itself with fromIndex=0", 0, blaBla.indexOf(blaBla, 0));
        assertEquals("indexOf(..) should return 0 for itself with fromIndex<0", 0, blaBla.indexOf(blaBla, -1));
        assertEquals("indexOf(..) should return -1 for itself with fromIndex>0", -1, blaBla.indexOf(blaBla, 1));
        assertEquals("indexOf(..) should return 0 for first substring", 0, blaBla.indexOf(bla, 0));
        assertEquals("indexOf(..) should return index for second substring", 3, blaBla.indexOf(bla, 1));
        for (int i = -1; i < blaBla.length(); i++) {
            assertEquals("indexOf(EMPTY," + i + ") should return fromIndex for empty string", Math.max(0, i), blaBla.indexOf(AsciiString.EMPTY, i));
        }
        //with from index, with self-similar search string
        final ImmutableAsciiString needle = new ImmutableAsciiString("aabbaa");
        final ImmutableAsciiString hayStack = new ImmutableAsciiString("123aabbaabbaaabbaabba");
        assertEquals("hayStack.indexOf(needle, 0) should return index of 1st occurrence", 3, hayStack.indexOf(needle, 0));
        assertEquals("hayStack.indexOf(needle, 4) should return index of 2nd occurrence", 7, hayStack.indexOf(needle, 4));
        assertEquals("hayStack.indexOf(needle, 8) should return index of 3rd occurrence", 12, hayStack.indexOf(needle, 8));
        assertEquals("hayStack.indexOf(needle, 13) should return -1", -1, hayStack.indexOf(needle, 13));
    }

    @Test
    public void hash() {
        assertEquals("hash code should not be zero", true, 0 != new ImmutableAsciiString("Bla").hashCode());
        assertEquals("hash code should be 0", 0, new ImmutableAsciiString("").hashCode());
    }

    @Test
    public void equals() {
        final ImmutableAsciiString bla = new ImmutableAsciiString("Bla");
        assertEquals("should equal itself", true, bla.equals(bla));
        assertEquals("should not equal null", false, bla.equals(null));
        assertEquals("should not equal other non AsciiString value", false, bla.equals("Bla"));
        assertEquals("should not equal other non-equal AsciiString", false, bla.equals(AsciiString.immutable("BlaBla")));
        assertEquals("should equal other equal AsciiString", true, bla.equals(new ImmutableAsciiString("Bla")));
        assertEquals("should equal other equal MutableAsciiString", true, bla.equals(AsciiString.expandable().set("Bla")));
        assertEquals("should equal other overwritten equal MutableAsciiString", true, bla.equals(AsciiString.expandable().set("initial value").set("Bla")));
    }

    @Test
    public void compareTo() {
        final ImmutableAsciiString abc = new ImmutableAsciiString("abc");
        final ImmutableAsciiString aBC = new ImmutableAsciiString("aBC");
        final ImmutableAsciiString abcd = new ImmutableAsciiString("abcd");
        final ImmutableAsciiString ab = new ImmutableAsciiString("ab");
        final ImmutableAsciiString ab1 = new ImmutableAsciiString("ab1");
        assertTrue("compare result should be: abc = abc", abc.compareTo(abc) == 0);
        assertTrue("compare result should be: abc = abc (new AsciiString)", abc.compareTo(new ImmutableAsciiString("abc")) == 0);
        assertTrue("compare result should be: abc = abc (new MutableAsciiString)", abc.compareTo(AsciiString.expandable().set("abc")) == 0);
        assertTrue("compare result should be: abc > aBC", abc.compareTo(aBC) > 0);
        assertTrue("compare result should be: abc < abcd", abc.compareTo(abcd) < 0);
        assertTrue("compare result should be: abc > ab", abc.compareTo(ab) > 0);
        assertTrue("compare result should be: abc > ab1", abc.compareTo(ab1) > 0);
    }

    @Test
    @Spockito.Unroll({
            "| value1      | value2   | value3  |",
            "|=============|==========|=========|",
            "| Bla1\0c     | Bla2\0b  | Bla3\0a |",
            "| Bla1\0c     | Bla2\0b  | Bla3\0a |",
            "| Bl\0aac     | Bla\0ac  | Blaa\0c |",
            "| Blaac       | Blaac    | Blaac   |"
    })
    @Spockito.Name("[{row}]: {value1} < {value2} < {value3}")
    public void compareTo_inequalities(final String value1, final String value2, final String value3) {
        final ImmutableAsciiString bla1 = new ImmutableAsciiString(value1);
        final ImmutableAsciiString bla2 = new ImmutableAsciiString(value2);
        final ImmutableAsciiString bla3 = new ImmutableAsciiString(value3);

        assertTrue("should compare to itself", bla1.compareTo(bla1) == 0);
        assertTrue("should compare to itself", bla2.compareTo(bla2) == 0);
        assertTrue("should compare to itself", bla3.compareTo(bla3) == 0);

        assertTrue("bla1 should be less than bla2", Integer.signum(bla1.compareTo(bla2)) == -Integer.signum(bla2.compareTo(bla1)));
        assertTrue("bla2 should be less than bla3", Integer.signum(bla2.compareTo(bla3)) == -Integer.signum(bla3.compareTo(bla2)));
        assertTrue("bla1 should be less than bla3", Integer.signum(bla1.compareTo(bla3)) == -Integer.signum(bla3.compareTo(bla1)));
    }

    @Test
    @Spockito.Unroll({
            "| value1      | value2   | value3  |",
            "|=============|==========|=========|",
            "| Bla1\0c     | Bla1\0b  | Bla1\0a |",
            "| \0Blaac     | \0Blaac  | \0Blaac |"
    })
    @Spockito.Name("[{row}]: {value1} == {value2} == {value3}")
    public void compareTo_equalities(final String value1, final String value2, final String value3) {
        final ImmutableAsciiString bla1 = new ImmutableAsciiString(value1);
        final ImmutableAsciiString bla2 = new ImmutableAsciiString(value2);
        final ImmutableAsciiString bla3 = new ImmutableAsciiString(value3);

        assertTrue("should compare to itself", bla1.compareTo(bla1) == 0 && bla1.equals(bla1));
        assertTrue("should compare to itself", bla2.compareTo(bla2) == 0 && bla2.equals(bla2));
        assertTrue("should compare to itself", bla3.compareTo(bla3) == 0 && bla3.equals(bla3));

        assertTrue("bla1 should equal to bla2", bla1.compareTo(bla2) == bla2.compareTo(bla1) && bla1.equals(bla2) && bla2.equals(bla1));
        assertTrue("bla2 should equal to bla3", bla2.compareTo(bla3) == bla3.compareTo(bla2) && bla2.equals(bla3) && bla3.equals(bla2));
        assertTrue("bla1 should equal to bla3", bla1.compareTo(bla3) == bla3.compareTo(bla1) && bla1.equals(bla3) && bla3.equals(bla1));
    }


    @Test
    public void to_String() {
        assertEquals("should result in 'Bla' string", "Bla", new ImmutableAsciiString("Bla").toString());
        assertEquals("should result in empty string", "", new ImmutableAsciiString("").toString());
    }

    @Test
    public void toStringOrNull() {
        assertEquals("should result in 'Bla' string", "Bla", new ImmutableAsciiString("Bla").toStringOrNull());
        assertEquals("should result in null", null, new ImmutableAsciiString("").toStringOrNull());
    }

    @Test
    public void get_charAt() {
        final String abc = "abcdefg";
        final AsciiString ascii = AsciiString.immutable(abc);
        for (int i = 0; i < abc.length(); i++) {
            Assert.assertEquals("get(" + i + ") not as expected", (byte)abc.charAt(i), ascii.get(i));
            Assert.assertEquals("charAt(" + i + ") not as expected", abc.charAt(i), ascii.charAt(i));
        }
    }

    @Test
    public void get() {
        final String background = "0123456789";
        final String abc = "abcdefg";
        final AsciiString ascii = AsciiString.immutable(abc);
        final StringBuilder sb = new StringBuilder();
        for (int maxLength = 0; maxLength < 20; maxLength++) {
            for (int i = 0; i < abc.length(); i++) {
                //given
                sb.setLength(0);
                sb.append(background);
                final int expLength = Math.min(maxLength, abc.length());
                final String expVal = ""
                        + background.substring(0, i)
                        + abc.substring(0, expLength)
                        + background.substring(Math.min(i + expLength, background.length()), background.length());
                Assert.assertEquals("return value from get(target, ..., " + i + ", " + maxLength +") not as expected",
                        expLength, ascii.get(sb, ByteWriter.STRING_BUILDER, i, maxLength));
                Assert.assertEquals("string written to target via get(target, ..., " + i + ", " + maxLength + ") is not as expected",
                        expVal, sb.toString());
            }
        }
    }

    @Test
    public void testEmpty() {
        //isEmpty
        assertEquals("should be empty", true, AsciiString.EMPTY.isEmpty());
        assertEquals("length should be zero", 0, AsciiString.EMPTY.length());
        //contains
        assertEquals("should not contain non-empty string", false, AsciiString.EMPTY.contains(AsciiString.immutable("Bla")));
        assertEquals("should contain empty string", true, AsciiString.EMPTY.contains(AsciiString.immutable("")));
        //indexOf
        assertEquals("indexOf(..) should return -1 for non-empty string", -1, AsciiString.EMPTY.indexOf(AsciiString.immutable("Bla")));
        assertEquals("indexOf(..) should return 0 for empty string", 0, AsciiString.EMPTY.indexOf(AsciiString.immutable("")));
        assertEquals("indexOf(..) should return 0 for empty string with fromIndex > 0", 0, AsciiString.EMPTY.indexOf(AsciiString.immutable(""), 7));
        assertEquals("indexOf(..) should return 0 for empty string with fromIndex < 0", 0, AsciiString.EMPTY.indexOf(AsciiString.immutable(""), -1));
        //hashCode
        assertEquals("hash code should be zero", 0, AsciiString.EMPTY.hashCode());
        //equals
        assertEquals("should equal itself", true, AsciiString.EMPTY.equals(AsciiString.EMPTY));
        assertEquals("should not equal null", false, AsciiString.EMPTY.equals(null));
        assertEquals("should not equal other non AsciiString value", false, AsciiString.EMPTY.equals("Bla"));
        assertEquals("should not equal other non-empty AsciiString", false, AsciiString.EMPTY.equals(AsciiString.immutable("Bla")));
        assertEquals("should equal other empty AsciiString", true, AsciiString.EMPTY.equals(new ImmutableAsciiString("")));
        assertEquals("should equal other empty MutableAsciiString", true, AsciiString.EMPTY.equals(AsciiString.expandable().set("")));
        //compareTo
        assertEquals("should compare equal to itself", 0, AsciiString.EMPTY.compareTo(AsciiString.EMPTY));
        assertEquals("should be smaller than any other non-empty string", -1, AsciiString.EMPTY.compareTo(AsciiString.immutable("A")));
        //toString
        assertEquals("should result in empty string", "", AsciiString.EMPTY.toString());
        //toStringOrNull
        assertEquals("should result in null", null, AsciiString.EMPTY.toStringOrNull());
        //get
        assertEquals("should copy zero bytes", 0, AsciiString.EMPTY.get(null, ByteWriter.NULL, 0, Integer.MAX_VALUE));
        try {
            AsciiString.EMPTY.get(0);
            fail("get should throw an exception");
        } catch (final IndexOutOfBoundsException e) {
            //as expected
        }
    }

}