package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.status.Context;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * return true to filter
 */
public interface HeaderPredicates {

    Context.HeaderPredicate FILTER_ALLOW_ALL = (header, index, messageType) -> false;

    class MessageTypeEventIdPredicate implements Context.HeaderPredicate {
        private final Map<MessageType, Long> messageTypeEventIdMap;
        private final EnumMap<MessageType, ChronicleObjectReader> messageTypesToAccept;

        public MessageTypeEventIdPredicate(final Map<MessageType, Long> messageTypeEventIdMap,
                                           final EnumMap<MessageType, ChronicleObjectReader> messageTypesToAccept) {
            this.messageTypeEventIdMap = messageTypeEventIdMap;
            this.messageTypesToAccept = messageTypesToAccept;
        }

        @Override
        public boolean apply(final Header header, final long index, final MessageType messageType) {
            if (!messageTypeEventIdMap.containsKey(messageType)) {
                return !messageTypesToAccept.containsKey(messageType); // return false if want to accept the message
            }
            return messageTypeEventIdMap.get(messageType) >= header.getEventId();
        }

        @Override
        public String toString() {
            return "MessageTypeEventIdPredicate{messageTypeEventIdMap=" + messageTypeEventIdMap + '}';
        }
    }

    class TimelyDataFilter implements Context.HeaderPredicate {
        private final long allowableStaleNS;

        public TimelyDataFilter(final long allowableLagFromRealTimeMS) {
            this.allowableStaleNS = TimeUnit.MILLISECONDS.toNanos(allowableLagFromRealTimeMS);
        }

        @Override
        public boolean apply(final Header header, final long index, final MessageType messageType) {
            final boolean filter = (Context.context().timeSource().nowNanosRealTime() - Context.context().timeSource().nowNanos()) > allowableStaleNS;
            return filter;
        }
    }
}
