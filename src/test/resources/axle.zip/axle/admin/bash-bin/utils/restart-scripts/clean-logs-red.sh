#!/bin/bash

#Correlator
ssh AxlSv@daxa035z "find ~/logs -type f -delete"
ssh AxlSv@daxa018z "find ~/logs -type f -delete"


#Proxy broker
ssh AxlSv@daxa018z "rm -rf ~/apache-tomcat/logs/*"
ssh AxlSv@daxa018z "rm -rf ~/apache-tomcat/bin/*.log"
ssh AxlSv@daxa018z "rm -rf ~/apache-tomcat/bin/*.dat"

ssh AxlSv@daxa035z "rm -rf ~/apache-tomcat/logs/*"
ssh AxlSv@daxa035z "rm -rf ~/apache-tomcat/bin/*.log"
ssh AxlSv@daxa035z "rm -rf ~/apache-tomcat/bin/*.dat"

