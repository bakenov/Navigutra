package com.anz.axle.lg.adapter.ebsu;

import com.anz.axle.microtime.PrecisionClock;
import software.chronicle.itch.staticcode.VoidItchSessionProbes;

import java.nio.ByteBuffer;

public class RecordArrivalProbes extends VoidItchSessionProbes {
    private final PrecisionClock precisionClock;
    private long packetReceivedNanos;

    public RecordArrivalProbes(final PrecisionClock precisionClock) {
        this.precisionClock = precisionClock;
    }

    @Override
    public void onReadTime(final long readTimeNS, final ByteBuffer inBB, final int position, final int limit) {
        this.packetReceivedNanos = precisionClock.nanos();
    }

    public long packetReceivedNanos() {
        return packetReceivedNanos;
    }
}
