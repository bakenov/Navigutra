package com.anz.axle.lg.adapter.fxall.acceptance;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceConfig;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.fxall.ServerConfig;

@Configuration
@Import({ServerConfig.class, SharedAcceptanceConfig.class})
public class AcceptanceConfig {
    @Bean
    public AcceptanceContext acceptanceContext(final SharedAcceptanceContext sharedAcceptanceContext,
                                               final FixMessageSender fixTradingMessageSender) {
        final class AcceptanceContextImpl extends SharedAcceptanceContext.Delegate implements AcceptanceContext {
            public AcceptanceContextImpl() {
                super(sharedAcceptanceContext);
            }
            @Override
            public FixMessageSender fixTradingMessageSender() {
                return fixTradingMessageSender;
            }
        }
        return new AcceptanceContextImpl();
    }
}
