package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.messaging.endpoint.intf.AbstractSink;
import anz.markets.messaging.types.PDMessage;
import com.anz.axle.wss.domain.WssDeal;
import org.apache.log4j.Logger;

/**
 * Created by talwarg on 15/06/2015.
 */
public class LoggingSink extends AbstractSink<WssDeal> {
    private static final Logger LOG = Logger.getLogger(LoggingSink.class);
    @Override
    public boolean onMessage(final PDMessage<WssDeal> message) {
        LOG.info(String.format("WssDeal message sinked [%s]", message.getContent().toString()));
        return true;
    }
}
