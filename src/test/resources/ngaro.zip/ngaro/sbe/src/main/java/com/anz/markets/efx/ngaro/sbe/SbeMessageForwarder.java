package com.anz.markets.efx.ngaro.sbe;

import java.util.Objects;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;

/**
 * This class is non-thread safe.
 */
public class SbeMessageForwarder implements MessageForwarder {
    private final MessageDecoder.ForwardingLookup<SbeMessage> forwarderLookup;
    private SbeMessage sbeMessage;

    public SbeMessageForwarder(final MessageDecoder.ForwardingLookup<SbeMessage> forwarderLookup) {
        this.forwarderLookup = Objects.requireNonNull(forwarderLookup);
    }

    /**
     * allows wrapping nulls
     * @param sbeMessage
     */
    public void wrap(final SbeMessage sbeMessage) {
        this.sbeMessage = sbeMessage;
    }

    @Override
    public boolean forward(final String destination) {
        Objects.requireNonNull(sbeMessage);
        return forwarderLookup.apply(destination).decode(sbeMessage);
    }
}
