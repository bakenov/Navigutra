package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoFirewallConfigHandler implements FirewallConfigHandler {

    private final Consumer<? super FirewallConfig> messageConsumer;

    private FirewallConfig message = SorMessage.firewallConfig();

    public FirewallConfig message() {
        return message;
    }

    public PojoFirewallConfigHandler() {
        this(msg -> {});
    }

    public PojoFirewallConfigHandler(final Consumer<? super FirewallConfig> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(int source, long sourceSeq) {
        message = SorMessage.firewallConfig();
        message.header.source = source;
        message.header.sourceSeq = sourceSeq;
    }

    @Override
    public void onBody(final Body body) {
        message.body.firewallName = body.firewallName().decodeStringOrNull();
        message.body.ruleId = body.ruleId();
        message.body.regionPattern = body.regionPattern().decodeStringOrNull();
        message.body.orderTypePattern = body.orderTypePattern().decodeStringOrNull();
        message.body.deskPattern = body.deskPattern().decodeStringOrNull();
        message.body.portfolioPattern = body.portfolioPattern().decodeStringOrNull();
        message.body.usernamePattern = body.usernamePattern().decodeStringOrNull();
        message.body.venuePattern = body.venuePattern().decodeStringOrNull();
        message.body.securityTypePattern = body.securityTypePattern().decodeStringOrNull();
        message.body.tenorPattern = body.tenorPattern().decodeStringOrNull();
        message.body.symbolPattern = body.symbolPattern().decodeStringOrNull();
        message.body.period = body.period();
        message.body.periodUnit = body.periodUnit().decodeStringOrNull();
        message.body.local = body.local();
        message.body.comment = body.comment().decodeStringOrNull();
        message.body.lastEditUsername = body.lastEditUsername().decodeStringOrNull();
        message.body.lastEditTime = body.lastEditTime();
        message.body.limitThreshold = body.limitThreshold();
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
