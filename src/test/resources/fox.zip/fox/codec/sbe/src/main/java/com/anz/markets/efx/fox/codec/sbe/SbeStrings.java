package com.anz.markets.efx.fox.codec.sbe;

/**
 * Constants for SBE strings.
 */
public final class SbeStrings {

    private SbeStrings() {
        throw new RuntimeException("No SbeStrings for you!");
    }
}
