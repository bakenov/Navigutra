package com.anz.axle.direct.performance.metrics;

public interface Named {
    String getName();
}
