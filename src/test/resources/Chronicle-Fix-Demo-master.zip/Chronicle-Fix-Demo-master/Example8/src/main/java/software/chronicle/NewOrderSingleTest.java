package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixInstance;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.NewOrderSingle;
import software.chronicle.generated.code.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.TimeUnit;

import static software.chronicle.fix.cfg.ConnectionType.initiator;

/**
 * @author Rob Austin.
 */
public class NewOrderSingleTest {

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(ClientMessageNotifier.class,
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    @NotNull
    private static NewOrderSingle newOrderSingle() {
        final NewOrderSingle serverExpects = new DefaultNewOrderSingle();
        serverExpects.ordType('2');
        // side is required
        //serverExpects.side('1');
        serverExpects.symbol(Bytes.from("LCOM1"));
        serverExpects.clOrdID(Bytes.allocateDirect("CL_ORD_ID".getBytes()));
        serverExpects.handlInst('3');
        serverExpects.transactTime(1451902315496L);
        serverExpects.orderQty(1);
        serverExpects.price(200.0);
        serverExpects.timeInForce('0');
        serverExpects.maturityMonthYear("201106");
        serverExpects.securityType("FUT");
        serverExpects.idSource("5");
        serverExpects.securityID(Bytes.from("LCOM1"));
        serverExpects.account(Bytes.from("ABCTEST1"));
        return serverExpects;
    }

    private void cleanup() {
        IOTools.deleteDirWithFiles("acceptor", 10);
        IOTools.deleteDirWithFiles("connector", 10);
        IOTools.deleteDirWithFiles("connector2", 10);
    }

    public static void main( String[] args ) throws Exception {

        if( args.length != 1 ) {
            System.err.println("Usage " + NewOrderSingleTest.class.getSimpleName() + " <test = testMissingRequiredTag>");
            return;

        }

        String test = args[0];
        if( test.equals("testMissingRequiredTag") )
            new NewOrderSingleTest().sendTestExecutionReportTest();
        else if( test.equals("testFailValidation") )
            new NewOrderSingleTest().testValidationBeforeSendOnPojo();
        else
            System.err.println( "Unknown test name " +  test + ". Expect either testMissingRequiredTag or testFailValidation" );
    }

    public void sendTestExecutionReportTest() throws Exception {

        cleanup();

        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");
        final FixSessionCfg initiatorFixConfig = fixEngineCfg.fixSessionCfgs().stream().filter(cfg -> cfg.connectionType() == initiator).findFirst().get();

        final ClientMessageNotifier messageNotifier = (ClientMessageNotifier) initiatorFixConfig.messageNotifier();

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");

        try (final Closeable ignored = FixInstance.fixEngineMain(1, fixEngineCfg)) {

            try (final Closeable ignored1 = FixInstance.fixEngineMain(2, fixEngineCfg)) {

                String executionReport = messageNotifier.queue().poll(15, TimeUnit.SECONDS);

                String expected = "!software.chronicle.generated.code.messages.datamodel.DefaultReject {\n" +
                        "  senderCompID: SERVER,\n" +
                        "  targetCompID: CLIENT,\n" +
                        "  msgSeqNum: 2,\n" +
                        "  sendingTime: 0,\n" +
                        "  refSeqNum: 2,\n" +
                        "  refTagID: 54,\n" +
                        "  refMsgType: D,\n" +
                        "  sessionRejectReason: 1,\n" +
                        "  text: \"Required tag missing: side\"\n" +
                        "}\n";

                assert expected.equals(executionReport);

                System.out.println( "Intentional message reject (test missing required tag)" );
                System.out.println( expected );
            }
        }
    }

    public void testValidationBeforeSendOnPojo() throws Exception {
        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config-validation.yaml");
        final FixSessionCfg initiatorFixConfig = fixEngineCfg.fixSessionCfgs().stream().filter(cfg -> cfg.connectionType() == initiator).findFirst().get();

        final ValidatingClientMessageNotifier messageNotifier = (ValidatingClientMessageNotifier) initiatorFixConfig.messageNotifier();

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");

        try (final Closeable ignored = FixInstance.fixEngineMain(1, fixEngineCfg)) {

            try (final ChronicleFixEngine client = FixInstance.fixEngineMain(3, fixEngineCfg)) {
                messageNotifier.latch().await(15, TimeUnit.SECONDS);
                // logged in
                FixSessionHandler session = client.sessions().stream().findFirst().get();
                try {
                    session.sendMessage(newOrderSingle());
                    assert false; // Send message will fail with exception indicating the message is not well-formed;
                } catch (Exception e) {
                    System.out.println( "Intentionally failed (test validation). Stacktrace follows:" );
                    e.printStackTrace();
                }
            }
        }
    }
}

