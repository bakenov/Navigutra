package com.anz.markets.prophet.atest.pricing._0b_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.LinkedList;

import static com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType.MARKET_INDICATIVE;
import static com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType.MARKET_SINGLE_SIDED;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * AXPROPHET-532 When constructing an aggregated book (to derive TOB BID/OFFER for WSP_U),
 * PROPHET should always discard any prices(as INDICATIVE) where qty is 0 (zero) or less (negative) on BOTH sides
 *
 * AXPROPHET-1215 Single-Sided filter.
 */

@RestartBeforeTest(reason = "clear prices")
public class IndicativeAndSingleSidedFiltersTest extends BaseAcceptanceSpecification {

    @Test
    public void ignoreSingleVenueIndicativePrices() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setFilterEnabledConfigs(union(
                            tdd.enableFilter(MARKET_INDICATIVE)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.70011, 1000000, 0.70017, 1000000));
            prophet.incrementTime(1);
            // BID with negative qty and OFFER with 0 qty. Since this will be filtered no WSP_U will be generated
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.70013, -1, 0.70016, 0));
        }
        then:
        // CNX mkt data update is marked as INDICATIVE
        {
            FilteredMarketDataSnapshot hspMktDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(hspMktDataSnapshot.getBidEventList().size(), CoreMatchers.is(0));
            assertThat(hspMktDataSnapshot.getOfferEventList().size(), CoreMatchers.is(0));
            assertThat(hspMktDataSnapshot.getFailedFiltersBits(), CoreMatchers.is(MARKET_INDICATIVE.getBitMask()));
        }
        and:
        {
            FilteredMarketDataSnapshot wspUMktDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) wspUMktDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) wspUMktDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(wspUMktDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.70011, 0.70017));

            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            assertThat(clientPrice.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.700125, 0.700155));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1);
            // BID and OFFER with +ve qty which will be TOB in aggbook
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.70012, 1, 0.70015, 1));
        }
        then:
        // since new TOB, expect WSP_U
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, 1, 0.70012, 0.70015));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));
        }
    }

    @Test
    public void ignoreMultiVenueIndicativePrices() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setFilterEnabledConfigs(union(
                            tdd.enableFilter(MARKET_INDICATIVE)
                    ))
            );
        }
        when:
        {
            // make sure we have another (wider) price so as to stop minimum market filter
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.70010, 1, 0.70018, 1));
            // Bid Qty is ZERO. Since Single sided no WSP_U generated
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.70012, 0, 0.70017, 1));
            prophet.incrementTime(100);
            // OFFER Qty is NEGATIVE. Since Single sided no WSP_U generated
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.70011, 1, 0.70015, -1));
        }
        then:
        {
            FilteredMarketDataSnapshot mktDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) mktDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.DEUT));
            assertThat(((MarketDataNewOrder) mktDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.DEUT));
            assertThat(mktDataSnapshot, isMarketPricePoint(0, 1, 0.70010, 0.70018));


            FilteredMarketDataSnapshot cnxMktDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.CNX)).getLast();
            assertThat(cnxMktDataSnapshot.getFailedFiltersBits(), CoreMatchers.is(MARKET_SINGLE_SIDED.getBitMask()));
            FilteredMarketDataSnapshot hspMktDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(hspMktDataSnapshot.getFailedFiltersBits(), CoreMatchers.is(MARKET_SINGLE_SIDED.getBitMask()));
        }
    }
}
