package com.anz.axle.adapters.ndf2trep.acceptance;

import com.anz.markets.adapters.trep.Item;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * TREP NDF Subscribing client. Will subscribe to all NDF pairs defined in the ndf2trep application.
 * Will print any received price to log.
 */
@ContextConfiguration(classes = {
        TestConfig.class,
        TrepNdfSubscribingTest.Config.class
})
@Ignore("please un-comment this line to run it manually")
public class TrepNdfSubscribingTest extends AbstractJUnit4SpringContextTests {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrepNdfSubscribingTest.class);

    @Configuration
    @ImportResource({"classpath:ndf2trep-applicationContext-subscriptions.xml"})
    public static class Config {
    }

    @Autowired
    protected TestMessageProcessor testRateProcessor;

    @Autowired
    @Qualifier("testTrepNdfSubscriber")
    protected TrepRateSubscriber testTrepNdfSubscriber;


    @Before
    public void beforeTest() throws Exception {
        testTrepNdfSubscriber.run();
    }

    @Test
    public void logTrepItems() throws Exception {
        while (true) {
            final Item latestUpdate = testRateProcessor.getLatestRateForRIC();
            if (latestUpdate != null) {
                LOGGER.info("TREP Item: {}", latestUpdate);
            }
        }
    }

}
