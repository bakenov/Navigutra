package com.anz.axle.lg.adapter.fast.chroniclefix;

import org.junit.Ignore;
import org.junit.Test;

import net.openhft.chronicle.core.time.SystemTimeProvider;
import software.chronicle.fix.yaml.YamlFixTester;

import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.parsers.MessageParser;

@Ignore("Ignore sample tests")
public final class ExampleYamlFixTest {

    @Test
    public void yamlFixTest1() throws Exception {
        new YamlFixTester("fix-config-example12.yaml",
                "yamlFixTester",
                MessageParser.class,
                MessageNotifier.class,
                SystemTimeProvider.INSTANCE
        ).
                inputFormat(YamlFixTester.Format.FIX).
                outputFormat(YamlFixTester.Format.FIX).
                run();
    }

    @Test
    public void yamlFixTest2() throws Exception {
        new YamlFixTester("fix-config-example12.yaml",
                "yamlFixTester2",
                MessageParser.class,
                MessageNotifier.class,
                SystemTimeProvider.INSTANCE
        ).
                run();
    }
}