package com.anz.axle.environment.dls;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import java.io.PrintWriter;

public class TimeZonePairs{

        String id;
        DateTimeZone fromTimezone;
        DateTimeZone toTimezone;

        public TimeZonePairs(String id, String from, String to){
            this.id = id;
            fromTimezone =   DateTimeZone.forID(from);
            toTimezone =   DateTimeZone.forID(to);

        }

    public void writeTo(LocalDate targetLocalDate, PrintWriter writer) {

        for (int hour = 0; hour < 24; hour++) {
            LocalTime fromLocalTime = new LocalTime(hour, 0, 0);
            DateTime fromDateTime = targetLocalDate.toDateTime(fromLocalTime, fromTimezone);
            DateTime toDateTime = fromDateTime.withZone(toTimezone);

            writer.println("tzc_"+hour+"_"+id+"="+toDateTime.getHourOfDay());

        }
        writer.println();
        writer.println();

    }
}