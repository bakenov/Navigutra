package com.anz.markets.efx.fox.codec.pojo;

import org.junit.Test;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.pojo.matcher.FirewallConfigMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.codec.Header;

import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class FirewallConfigMatcherTest {
    private Predicate<FirewallConfig> predicate = Matchers.isA(FirewallConfig.class);
    private FirewallConfigMatcher matcher = new FirewallConfigMatcher() {

        @Override
        public Matcher<FirewallConfigMatcher, Header> header() {
            return matcher -> andThen(translate(firewallConfig -> firewallConfig.header, matcher));
        }

        @Override
        public Matcher<FirewallConfigMatcher, FirewallConfig.Body> body() {
            return matcher -> andThen(translate(firewallConfig -> firewallConfig.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof FirewallConfig && predicate.test((FirewallConfig) o);
        }

        private FirewallConfigMatcher andThen(final Predicate<? super FirewallConfig> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final FirewallConfig firewallConfig = SorMessage.firewallConfig( new MessageHeader(123, 2345),
                new FirewallConfig.Body("firewallName",345, "regionPattern","orderTypePattern",
                        "deskPattern", "portfolioPattern", "usernamePattern", "venuePattern", "securityTypePattern", "tenorPattern", "symbolPattern", 60, "s",
                        true, "comment", "lastEditUsername", 123456, 50.234));
        assertTrue(matcher.test(firewallConfig));
        assertNotNull(matcher.body());
    }
}
