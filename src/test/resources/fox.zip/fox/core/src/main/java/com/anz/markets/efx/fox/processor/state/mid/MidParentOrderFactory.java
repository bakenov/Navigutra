package com.anz.markets.efx.fox.processor.state.mid;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.processor.state.ParentOrderFactory;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.ngaro.core.ObjectPool;

import java.util.Objects;

public class MidParentOrderFactory implements ParentOrderFactory.NamedFactory {
    private final String strategyName;
    private final ObjectPool<MidParentOrder> parentOrderPool;

    public MidParentOrderFactory(final String strategyName,
                                 final ParentOrderRepository.Mutable parentOrderRepository,
                                 final int initialPoolSize,
                                 final TimerScheduler timerScheduler,
                                 final InstrumentRepository instrumentRepository,
                                 final VenueTimeInForceLookup venueTimeInForceLookup) {
        this.strategyName = Objects.requireNonNull(strategyName);
        Objects.requireNonNull(instrumentRepository);
        Objects.requireNonNull(parentOrderRepository);
        Objects.requireNonNull(timerScheduler);
        Objects.requireNonNull(venueTimeInForceLookup);

        parentOrderPool = new ObjectPool<>(
                releaser -> new MidParentOrder(timerScheduler,
                        releaser.andThen(parentOrder -> {
                            parentOrderRepository.removeByOrderId(parentOrder.details().orderId());
                            parentOrderRepository.removeByClOrderId(parentOrder.details().senderCompId(), parentOrder.details().origClOrdId());
                        }), instrumentRepository, venueTimeInForceLookup),
                initialPoolSize);

    }

    @Override
    public ParentOrder get() {
        return parentOrderPool.borrowOrNew();
    }

    @Override
    public String name() {
        return strategyName;
    }
}
