package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;

import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.core.time.SystemTimeProvider;
import net.openhft.chronicle.core.time.TimeProvider;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.QueueMsgSequenceHandler;
import software.chronicle.fix.staticcode.msgseq.SessionMessageProvider;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import com.anz.axle.lg.adapter.SecurityTypeSymbolLookup;
import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.AsyncApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.CheckLatencyProbes;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.EncodingSubscriptionSender;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.FixEngine;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.PerformanceProbes;
import com.anz.axle.lg.adapter.chroniclefix.tools.FixLogConsumer;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    private final String compId;
    private final String senderCompId;
    private final Venue venue;

    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId,
                     @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public SessionID pricingSessionId(@Value("${dbs.fix.pricing.sendercompid}") final String pricingSenderCompId, @Value("${dbs.fix.pricing.targetcompid}") final String pricingTargetCompId) {
        return new SessionID(pricingSenderCompId, pricingTargetCompId);
    }

    @Bean
    public SessionID tradingSessionId(@Value("${dbs.fix.trading.sendercompid}") final String tradingSenderCompId, @Value("${dbs.fix.trading.targetcompid}") final String tradingTargetCompId) {
        return new SessionID(tradingSenderCompId, tradingTargetCompId);
    }

    @Bean
    public EncodingSubscriptionSender encodingSubscriptionSender(final FixMessageSender fixPricingMessageSender,
                                                                 @Value("#{${flextrade.tenors}}") final Map<Tenor, String> flextradeTenors) {
        return new EncodingSubscriptionSender(new DbsMarketDataRequestEncoder(flextradeTenors), fixPricingMessageSender);
    }

    @Bean
    public SessionState tradingSessionState() {
        return new SessionState("TradingSession");
    }

    @Bean
    public Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState tradingSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(tradingSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler(final SessionID pricingSessionId,
                                                           @Qualifier("marketDataSubscriber") final Supplier<LogonHandler> pricingSessionLogonHandlerSupplier,
                                                           final SessionID tradingSessionId,
                                                           @Qualifier("tradingSessionState") final Supplier<LogonHandler> tradingSessionLogonHandlerSupplier,
                                                           final Queue<Runnable> mainEventLoopQueue) {

        return new AsyncApplicationLogonHandler(mainEventLoopQueue, sessionID -> {
            if (sessionID.equals(pricingSessionId)) {
                return pricingSessionLogonHandlerSupplier.get();
            } else if (sessionID.equals(tradingSessionId)) {
                return tradingSessionLogonHandlerSupplier.get();
            } else {
                return LogonHandler.NO_OP;
            }
        });
    }

    @Bean
    public FixMessageSender fixPricingMessageSender(final SessionID pricingSessionId, @Lazy final FixEngine fixPricingEngine) {
        return new FixMessageSender(() ->
                fixPricingEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(pricingSessionId)).findFirst().get());
    }

    @Bean
    public FixMessageSender fixTradingMessageSender(final SessionID tradingSessionId, @Lazy final FixEngine fixTradingEngine) {
        return new FixMessageSender(() ->
                fixTradingEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(tradingSessionId)).findFirst().get());
    }

    @Bean
    public EventLoop chronicleEventLoop() {
        EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false);
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter fixPricingEventLoopStep(final EventLoop chronicleEventLoop) {
        return new EventLoopAdapter(chronicleEventLoop);
    }

    @Bean
    public EventLoopAdapter fixTradingEventLoopStep(final EventLoop chronicleEventLoop) {
        return new EventLoopAdapter(chronicleEventLoop);
    }

    @Bean
    public FixEngineCfg fixEngineCfg(final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/dbs-chroniclefix.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final FixEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

    @Bean
    public Consumer<FixLog> pricingFixLogConsumer(@Value("${dbs.fix.pricing.log_all}") final boolean enableLogging,
                                                  @Value("${dbs.fix.file.log.path}") final String logPath,
                                                  @Value("${dbs.fix.pricing.logging.base_path}") final String bashPath,
                                                  @Value("${dbs.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public Consumer<FixLog> tradingFixLogConsumer(@Value("${dbs.fix.trading.log_all}") final boolean enableLogging,
                                                  @Value("${dbs.fix.file.log.path}") final String logPath,
                                                  @Value("${dbs.fix.trading.logging.base_path}") final String bashPath,
                                                  @Value("${dbs.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public SessionMessageProvider pricingSessionMessageProvider() {
        return new DbsSessionMessageProvider("Pricing",  false, null);
    }

    @Bean
    public FixEngine fixPricingEngine(final FixEngineCfg fixEngineCfg,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      final SessionMessageProvider pricingSessionMessageProvider,
                                      final Consumer<FixLog> pricingFixLogConsumer,
                                      final VenueRequestKeyLookup requestKeyLookup,
                                      final PricingEncoderLookup pricingEncoderLookup,
                                      final PrecisionClock precisionClock,
                                      final SubscriptionManager subscriptionManager,
                                      final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy,
                                      final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshEncoderFlagsAppender,
                                      final EventLoopAdapter fixPricingEventLoopStep,
                                      final MetricRepository<Metric, Venue> metricRepository,
                                      @Value("${dbs.fix.pricing.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      final SourceSequencer sourceSequencer) throws Exception {

        final FixSessionCfg pricingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("pricing")).findFirst().get();
        pricingSession.sessionMessageProvider(pricingSessionMessageProvider);

        final DbsIncrementalRefreshHandler incrementalRefreshHandler = new DbsIncrementalRefreshHandler(
                requestKeyLookup, pricingEncoderLookup, precisionClock,
                subscriptionManager, senderCompId, compId, incrementalRefreshEncoderFlagsAppender, sourceSequencer);
        final DbsMarketDataRequestRejectHandler marketDataRequestRejectHandler = new DbsMarketDataRequestRejectHandler(subscriptionManager, subscriptionRequestRejectStrategy);

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value);
        FixSessionApplication fixPricingApplication = new FixPricingApplication(
                new MonitoredChronicleMessageHandler<>(incrementalRefreshHandler, metricRecorder),
                new MonitoredChronicleMessageHandler<>(marketDataRequestRejectHandler, metricRecorder),
                applicationLogonHandler);
        pricingSession.messageNotifier(fixPricingApplication);

        pricingSession.consumer(pricingFixLogConsumer);

        return FixEngine.create("DBS-MD-SUBSCRIBER", fixEngineCfg.createInstance(pricingSession.hostId(), fixPricingEventLoopStep), waitForLogoutTimeoutInSec);
    }

    @Bean
    public SessionMessageProvider tradingSessionMessageProvider(final FixEngineCfg fixEngineCfg,
                                                                @Value("${appOptions:}") final String appOptions) {
        final FixSessionCfg tradingSessionCfg = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
        return new DbsSessionMessageProvider("Trading", OptionMatcher.HAS_RESET.test(appOptions), tradingSessionCfg);
    }

    @Bean
    public TimeProvider timeProvider() {
        return SystemTimeProvider.INSTANCE;
    }

    @Bean
    public SecurityTypeSymbolLookup securityTypeSymbolLookup(@Value("#{${symbol.tenors.FXNDF.${venue}}}") final Map<String, Set<Tenor>> fxNdfSymbolTenors) {
        return new SecurityTypeSymbolLookup(fxNdfSymbolTenors.keySet());
    }

    @Bean
    public FixEngine fixTradingEngine(final FixEngineCfg fixEngineCfg,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      final SessionMessageProvider tradingSessionMessageProvider,
                                      final TimeProvider timeProvider,
                                      final Consumer<FixLog> tradingFixLogConsumer,
                                      final PrecisionClock precisionClock,
                                      final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                      final LongIdFactory tradingMessageIdGenerator,
                                      final EventLoopAdapter fixTradingEventLoopStep,
                                      final MetricRepository<Metric, Venue> metricRepository,
                                      @Value("${dbs.fix.trading.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      @Value("${dbs.fix.trading.allowedLatencyMs}") final int allowedLatencyMs,
                                      @Value("${dbs.fix.trading.session.enable}") final boolean enableTradingSession,
                                      @Value("${appOptions:}") final String appOptions,
                                      final SecurityTypeSymbolLookup securityTypeSymbolLookup,
                                      final SourceSequencer sourceSequencer) throws Exception {

        final FixSessionCfg tradingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
        tradingSession.sessionMessageProvider(tradingSessionMessageProvider);
//        tradingSession.timeProvider(timeProvider);

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);
        final ChronicleMessageHandler<ExecutionReport> executionReportHandler = new MonitoredChronicleMessageHandler<>(
                new DbsExecutionReportHandler(tradingResponseEncoderSupplier, precisionClock, senderCompId, compId, tradingMessageIdGenerator::get, securityTypeSymbolLookup, sourceSequencer),
                metricRecorder);
        final FixTradingApplication fixTradingApplication = new FixTradingApplication(executionReportHandler, applicationLogonHandler);
        tradingSession.messageNotifier(fixTradingApplication);
        tradingSession.probes(new CheckLatencyProbes(new PerformanceProbes(), allowedLatencyMs));
        tradingSession.consumer(tradingFixLogConsumer);

        final ChronicleFixEngine chronicleFixEngine = fixEngineCfg.createInstance(tradingSession.hostId(), fixTradingEventLoopStep);
        if (OptionMatcher.HAS_RESET_SEQ_NUM.test(appOptions)) {
            resetSequenceNumbers(tradingSession, appOptions);
        }

        return FixEngine.create("DBS-TR-SUBSCRIBER", chronicleFixEngine, waitForLogoutTimeoutInSec, enableTradingSession);
    }

    private void resetSequenceNumbers(final FixSessionCfg fixSessionCfg, final String appOptions) {
        final int readSeqNum = OptionMatcher.RESET_READ_SEQ_NUM.apply(appOptions);
        final int writeSeqNum = OptionMatcher.RESET_WRITE_SEQ_NUM.apply(appOptions);

        LOGGER.info("ResetSeqNum read={} write={}", readSeqNum, writeSeqNum);
        final QueueMsgSequenceHandler msgSequenceHandler = (QueueMsgSequenceHandler) fixSessionCfg.msgSequenceHandler();
        msgSequenceHandler.overrideCurrentSequenceNumberValues(readSeqNum, writeSeqNum);
        msgSequenceHandler.persistSequenceNumbers();
    }

    @Bean
    public BooleanSupplier readyToSendHeartbeat(final SessionState tradingSessionState, final MarketDataSubscriber marketDataSubscriber) {
        return () -> tradingSessionState.getAsBoolean() && marketDataSubscriber.loggedOn();
    }

}