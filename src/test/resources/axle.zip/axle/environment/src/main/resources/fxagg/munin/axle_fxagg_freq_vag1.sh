#!/bin/bash
# (c) 2016 ANZ

TITLE="Price Update Frequency (VAG1)"
VENUES="RFX"
COLORS="FF751A"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_freq.common