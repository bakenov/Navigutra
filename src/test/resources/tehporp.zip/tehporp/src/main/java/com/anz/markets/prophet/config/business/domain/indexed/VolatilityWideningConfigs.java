package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.impl.VolatilityWideningConfig;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.List;

public class VolatilityWideningConfigs {

    private final EnumObjTable<FactorWindow, Instrument, EnumDoubleMap<Market>> levelCounts = new EnumObjTable<>(FactorWindow.class, Instrument.class);
    private final EnumObjTable<FactorWindow, Instrument, EnumObjMap<Market, VolatilityWideningConfig[]>> table = new EnumObjTable<>(FactorWindow.class, Instrument.class);

    public VolatilityWideningConfigs(final List<VolatilityWideningConfig> volatilityWideningConfigs) {

        GcFriendlyAssert.isFalse(volatilityWideningConfigs.isEmpty(), "EMPTY volatilityWideningConfigs");

        // need a count of the number of levels per factorWindow / instrument / priceModel to create arrays.
        volatilityWideningConfigs.forEach(config -> {
            if (!levelCounts.containsKey(config.factorWindow, config.instrument)) {
                levelCounts.put(config.factorWindow, config.instrument, new EnumDoubleMap<>(Market.class));
            }
            if (!levelCounts.get(config.factorWindow, config.instrument).containsKey(config.model)) {
                levelCounts.get(config.factorWindow, config.instrument).put(config.model, 0);
            }
            levelCounts.get(config.factorWindow, config.instrument).put(config.model, levelCounts.get(config.factorWindow, config.instrument).get(config.model) + 1);
        });

        volatilityWideningConfigs.forEach(volatilityWideningConfig -> {
            final double levelCount = levelCounts.get(volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument).get(volatilityWideningConfig.model);
            GcFriendlyAssert.isFalse(Double.isNaN(levelCount), "Could not determine number of levels for %s %s $s", volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument, volatilityWideningConfig.model);

            if (!table.containsKey(volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument)) {
                table.put(volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument, new EnumObjMap<>(Market.class));
            }
            if (!table.get(volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument).containsKey(volatilityWideningConfig.model)) {
                table.get(volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument).put(volatilityWideningConfig.model, new VolatilityWideningConfig[(int)levelCount]);
            }
            final VolatilityWideningConfig[] configArray = table.get(volatilityWideningConfig.factorWindow, volatilityWideningConfig.instrument).get(volatilityWideningConfig.model);
            GcFriendlyAssert.isNull(configArray[volatilityWideningConfig.level], "trying to overwrite a level with %s", volatilityWideningConfig);
            configArray[volatilityWideningConfig.level] = volatilityWideningConfig;
        });

        //make sure at a minimum, that ANY model is represented for all specified factor / instrument
        table.forEach((factorWindow, instrument, modelConfigs) -> {
            if (instrument != Instrument.ANY) {
                GcFriendlyAssert.isTrue(modelConfigs.containsKey(Market.ANY), "ANY model not specified for: %s %s", instrument, factorWindow);
            }
        });

        //propagate Instrument.ANY/factorWindow settings to any other non-configured instrument/factorWindow.
        for (FactorWindow factorWindow : FactorWindow.VALUES) {
            for (Instrument instrument : Instrument.VALUES) {
                if (!table.containsKey(factorWindow, instrument) && table.containsKey(factorWindow, Instrument.ANY)) {
                    table.put(factorWindow, instrument, table.get(factorWindow, Instrument.ANY));
                }
            }
        }

        table.forEach((factorWindow, instrument, modelConfigs) -> {
            modelConfigs.forEach((model, array) -> {
                for (VolatilityWideningConfig item : array) {
                    GcFriendlyAssert.notNull(item);
                }
            });
        });
    }

    public double getSpreadForRealVol(final FactorWindow factorWindow, final Instrument instrument, final Market model,
                                      final TradingTimeZone timeZone, final double realVol) {
        if (Double.isNaN(realVol)) {
            return Double.NaN;
        }

        final VolatilityWideningConfig[] configArray = getVolatilityWideningConfigs(factorWindow, instrument, model);
        if (Double.isNaN(configArray[0].get(timeZone)) || realVol < configArray[0].get(timeZone)) {
            return Double.NaN;
        }
        int i = 1; // can start at index 1..  0 is taken care of above.
        for (; i < configArray.length; i++) {
            if (configArray[i].get(timeZone) > realVol) {
                break;
            }
        }
        return configArray[i - 1].wideningFactor;
    }

    public VolatilityWideningConfig[] getVolatilityWideningConfigs(final FactorWindow factorWindow, final Instrument instrument, final Market model) {

        GcFriendlyAssert.isTrue(hasConfig(factorWindow, instrument));
        final VolatilityWideningConfig[] configArray = table.get(factorWindow, instrument).containsKey(model) ?
                table.get(factorWindow, instrument).get(model) : table.get(factorWindow, instrument).get(Market.ANY);

        return configArray;
    }

    public boolean hasConfig(final FactorWindow factorWindow, final Instrument instrument) {
        return table.containsKey(factorWindow, instrument);
    }
}
