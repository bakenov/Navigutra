package com.anz.markets.prophet;

import com.anz.markets.efx.ngaro.collections.EnumSet;
import com.anz.markets.prophet.config.app.importable.ConsumerConfig;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingArbitrageFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.firewall.PricingArbitrageFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilterableMidRate;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.domain.time.MutableLocalDate;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.status.Context;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED;
import static com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED;
import static com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED;
import static com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ConsumerConfig.class, DefaultTestConfig.class})
public class CoreWiringPricingTest {
    protected static final Logger LOGGER = LoggerFactory.getLogger(CoreWiringPricingTest.class);
    private static final int COUNT = 2, COUNT_NO_BIDS_OR_ASKS = 0, FREQ_THROTTLER_NUMBER_PRICES = 100;
    private static final double MID = 0.74332, DEUT_MID = MID+0.00002, SPREAD = 0.4d / 10_000;
    private static final double EPSILON = 10e-6;
    private static final long INITIAL_TS_MS = 1000;
    private static TestTimeSource testTimeSource;

    @BeforeClass
    public static void setupClass() {
        testTimeSource = new TestTimeSource(INITIAL_TS_MS);
        Context.set(new Context(testTimeSource));
        Context.context().region(Region.GB);
        Context.context().tradingTimeZone(TradingTimeZone.LDN);
    }

    @Before
    public void setup() {
        testTimeSource.setMillis(INITIAL_TS_MS);
    }

    @Autowired
    DefaultTestConfig defaultTestConfig;

    @Test
    @DirtiesContext
    public void testMarketDataSnapshotToClientPrice() {
        checkPriceAllTheWayThrough();
    }

    private void setWideningConfig(IndexedConfigurationData indexedConfigurationData, boolean isEnabled) {
        final List<String> cgfList = Arrays.asList(
                VOLATILITY_PRICE_WIDENING_ENABLED.getKeyName(),
                RISK_PRICE_WIDENING_ENABLED.getKeyName(),
                ECONNEWS_PRICE_WIDENING_ENABLED.getKeyName(),
                MARKETGAP_PRICE_WIDENING_ENABLED.getKeyName());
        ConfigurationDataDefault cfg = (ConfigurationDataDefault) indexedConfigurationData.getConfigurationData();
        cfg.getKeyValueConfigs().removeIf(keyValueConfig -> cgfList.contains(keyValueConfig.getKeyName()));
        cgfList.forEach(keyValueConfigType -> {
            cfg.getKeyValueConfigs().add(new KeyValueConfigImpl(KeyValueConfigType.getByKeyName(keyValueConfigType), isEnabled));
        });
        defaultTestConfig.configurationDataConsumer.accept(cfg);
    }

    private ClientPrice checkPriceAllTheWayThrough() {
        final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getLastEvent();
        final int numberOfPriceModels = getPricingModelMarketCount(indexedConfigurationData);
        MarketDataSnapshotImpl marketDataSnapshot, marketDataSnapshot2;
        given:
        {
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.RFX), is(true));
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.EURUSD,Market.DEUT), is(true));
            // create 2 MDS so we can get through the minimumMarketsFilter
            marketDataSnapshot = MidRateTestHelper.createMarketData(Market.RFX, COUNT, MID, SPREAD);
            marketDataSnapshot.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS));
            marketDataSnapshot2 = MidRateTestHelper.createMarketData(Market.DEUT, COUNT, DEUT_MID, SPREAD);
            marketDataSnapshot2.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS + 200));
        }
        when:
        {
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot);
            // 1st set of prices is empty books when AggBookManager initialises all downstreams

            List<ClientPrice> driverClientPrices = defaultTestConfig.clientPriceSink().getEvents().stream().filter(p -> p.getInstrument() == Instrument.AUDUSD).collect(Collectors.toList());
            assertEquals(numberOfPriceModels, driverClientPrices.size());
            assertEquals(Market.WSP_A, driverClientPrices.get(0).getMarket());
            assertEquals(Market.WSP_B, driverClientPrices.get(1).getMarket());
            assertEquals(Market.WSP_C, driverClientPrices.get(2).getMarket());
            assertEquals(marketDataSnapshot.getInstrument(), driverClientPrices.get(driverClientPrices.size()-1).getInstrument());
            assertTrue(driverClientPrices.get(2).isBidAndOfferIndicative());  // MINIMUM_MARKET causes firewall flag to be set only
            assertTrue((driverClientPrices.get(2).getBidIndicativeBits() & PricingFirewallType.MINIMUM_MARKETS.getBitMask()) > 0);
            assertTrue((driverClientPrices.get(2).getOfferIndicativeBits() & PricingFirewallType.MINIMUM_MARKETS.getBitMask()) > 0);
            defaultTestConfig.clientPriceSink().clear();
            // no -minimum markets filtering - now on firewall
            assertEquals(3, defaultTestConfig.marketDataSink().getEvents().size());
            final FilterableMidRate wspR = (FilterableMidRate) defaultTestConfig.marketDataSink().getEvents().get(0);
            assertEquals(Market.WSP_R, wspR.getMarket());
            assertEquals(FilterDecision.PASS, wspR.getFilterOutcome(MarketDataFilterType.AGG_BOOK_MINIMUM_MARKET));
            final FilterableMidRate wspU = (FilterableMidRate) defaultTestConfig.marketDataSink().getEvents().get(1);
            assertEquals(Market.WSP_U, wspU.getMarket());
            assertEquals(FilterDecision.PASS, wspU.getFilterOutcome(MarketDataFilterType.AGG_BOOK_MINIMUM_MARKET));
            // RFX was filtered by MM
            final FilteredMarketDataSnapshot cnx = (FilteredMarketDataSnapshot) defaultTestConfig.marketDataSink().getEvents().get(2);
            assertEquals(Market.RFX, cnx.getMarket());
            // order book filter doesn't get written onto market snapshot, this is so that we can maintain multiple aggbook referencing same market snapshot.
            assertEquals(FilterDecision.PASS, cnx.getFilterOutcome(MarketDataFilterType.AGG_BOOK_MINIMUM_MARKET));
            defaultTestConfig.marketDataSink().clear();
        }
        and:
        {
            testTimeSource.setNanos(marketDataSnapshot2.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot2);
        }
        then:
        {
            // 2nd set of prices is the actual real price
            assertEquals(numberOfPriceModels, defaultTestConfig.clientPriceSink().getEvents().size());
            assertEquals(Market.WSP_A, defaultTestConfig.clientPriceSink().getEvents().get(0).getMarket());
            assertEquals(Market.WSP_B, defaultTestConfig.clientPriceSink().getEvents().get(1).getMarket());
            assertEquals(Market.WSP_C, defaultTestConfig.clientPriceSink().getEvents().get(2).getMarket());
            final ClientPrice lastEvent = defaultTestConfig.clientPriceSink().getLastEvent();
            assertEquals(marketDataSnapshot2.getInstrument(), lastEvent.getInstrument());
            assertEquals(marketDataSnapshot2.getMidRate(), lastEvent.getMidRate(), EPSILON);
            defaultTestConfig.clientPriceSink().clear();
            // check filtering
            assertEquals(3, defaultTestConfig.marketDataSink().getEvents().size());
            final FilterableMidRate wspR = (FilterableMidRate) defaultTestConfig.marketDataSink().getEvents().get(0);
            assertEquals(Market.WSP_R, wspR.getMarket());
            assertEquals(FilterDecision.PASS, wspR.getFilterOutcome());
            final FilterableMidRate wspU = (FilterableMidRate) defaultTestConfig.marketDataSink().getEvents().get(1);
            assertEquals(Market.WSP_U, wspU.getMarket());
            assertEquals(FilterDecision.PASS, wspU.getFilterOutcome());
            final FilteredMarketDataSnapshot gs = (FilteredMarketDataSnapshot) defaultTestConfig.marketDataSink().getEvents().get(2);
            assertEquals(Market.DEUT, gs.getMarket());
            assertEquals(FilterDecision.PASS, gs.getFilterOutcome());
            defaultTestConfig.marketDataSink().clear();
            return lastEvent;
        }
    }

    @Test
    @DirtiesContext
    public void testPullPrice() {
        final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
        final int numberOfPriceModels = getPricingModelMarketCount(indexedConfigurationData);
        MarketDataSnapshotImpl marketDataSnapshotNoPrice, marketDataSnapshotNoPrice2;
        given:
        {
            checkPriceAllTheWayThrough();
            marketDataSnapshotNoPrice = MidRateTestHelper.createMarketData(Market.RFX, COUNT_NO_BIDS_OR_ASKS, MID, SPREAD);
            marketDataSnapshotNoPrice2 = MidRateTestHelper.createMarketData(Market.DEUT, COUNT_NO_BIDS_OR_ASKS, MID, SPREAD);
            marketDataSnapshotNoPrice.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS) + TimeUnit.SECONDS.toNanos(1));
        }
        when:
        {
            testTimeSource.setNanos(marketDataSnapshotNoPrice.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshotNoPrice);
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshotNoPrice2);
        }
        then:
        {
            // see comment in checkPriceAllTheWayThrough
            assertEquals(numberOfPriceModels, defaultTestConfig.clientPriceSink().getEvents().size());
            assertTrue(defaultTestConfig.clientPriceSink().getLastEvent().isEmpty());
        }
    }

    @Test
    @DirtiesContext
    public void testMidThrottlerOutputsAtCorrectRate() {
        final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
        final ClientPriceThrottleConfig clientPriceThrottleConfig = getByMarketAndInstrument(indexedConfigurationData.getClientPriceThrottleConfigs(), Market.WSP_A, Instrument.AUDUSD);
        final long incrementTimeMS = clientPriceThrottleConfig.getTimePeriod();
        // make a much bigger increment as price formation can widen the spread
        final double incrementPrice = (SPREAD * clientPriceThrottleConfig.getMinimumPriceDeltaFractionOfSpread()) * 10;
        final double basePrice = 0.7000;

        // send in a couple of prices to ensure that all filters, books etc. are primed
        checkPriceAllTheWayThrough();

        final int numberOfPriceModels = getPricingModelMarketCount(indexedConfigurationData);

        for (int i = 1; i <= FREQ_THROTTLER_NUMBER_PRICES; i++) {
            final double newMidRate = basePrice + (i * incrementPrice);

            testTimeSource.incrementNanos(TimeUnit.MILLISECONDS.toNanos(incrementTimeMS) + 1);
            // alternate between markets otherwise OrderBookSlowestMarketFilter knocks out one of the markets
            // and then OrderBookMinimumMarketFilter kills the aggbook altogether
            final Market market = (i % 2 == 0) ? Market.DEUT : Market.RFX;
            final MarketDataSnapshotImpl marketDataSnapshot = MidRateTestHelper.createMarketData(Instrument.AUDUSD, market, COUNT, newMidRate, SPREAD, 15_000_000);  // Using 15M to ensure liquidity filter doesn't interfere.
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot);
            List<MidRate> mds = defaultTestConfig.marketDataSink().getEvents();
            mds.forEach(midRate -> {
                FilterableMidRate filterableMidRate = (FilterableMidRate) midRate;
                assertThat("should not fail filter for " + filterableMidRate, filterableMidRate.getFilterOutcome(), is(FilterDecision.PASS));
            });

            assertEquals((i * numberOfPriceModels), defaultTestConfig.clientPriceSink().getEvents().size());
        }
    }

    @Test
    @DirtiesContext
    public void testHeartBeatThrottlerKeepsSendingBooksWhenMinimumMarketsNotMet() {
        final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
        final ClientPriceThrottleConfig clientPriceThrottleConfig = getByMarketAndInstrument(indexedConfigurationData.getClientPriceThrottleConfigs(), Market.WSP_A, Instrument.AUDUSD);
        final long incrementTimeMS = clientPriceThrottleConfig.getNoActivityHeartbeatFrequencyMs();

        // send in a couple of prices to ensure that all filters, books etc. are primed
        checkPriceAllTheWayThrough();
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.DEUT, COUNT_NO_BIDS_OR_ASKS, MID, SPREAD, 15_000_000));  // Using 15M to avoid liquidity filter.
        defaultTestConfig.clientPriceSink().clear();

        final int numberOfPriceModels = getPricingModelMarketCount(indexedConfigurationData);

        for (int i = 1; i <= FREQ_THROTTLER_NUMBER_PRICES; i++) {
            testTimeSource.incrementNanos(TimeUnit.MILLISECONDS.toNanos(incrementTimeMS) + 1);
            for (int j = 0; j < TimeUnit.MILLISECONDS.toSeconds(incrementTimeMS); j++) {
                defaultTestConfig.oneSecondConsumer.accept(OneSecond.INSTANCE);
            }
            List<ClientPrice> driverClientPrices = defaultTestConfig.clientPriceSink().getEvents().stream().filter(p -> p.getInstrument() == Instrument.AUDUSD).collect(Collectors.toList());
            assertEquals((i * numberOfPriceModels), driverClientPrices.size());
            assertTrue(!driverClientPrices.get(driverClientPrices.size()-1).isEmpty());
        }
    }

    @Test
    @DirtiesContext
    public void testTriangulation() {

        final Random random = new SecureRandom();
        final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
        setWideningConfig(indexedConfigurationData, false);

        final ClientPriceThrottleConfig clientPriceThrottleConfig = getByMarketAndInstrument(indexedConfigurationData.getClientPriceThrottleConfigs(), Market.WSP_A, Instrument.AUDUSD);
        final long incrementTimeMS = clientPriceThrottleConfig.getTimePeriod();
        final double incrementPrice = (SPREAD * clientPriceThrottleConfig.getMinimumPriceDeltaFractionOfSpread()) + EPSILON;
        double lastMidRateAUDUSD = 0.75, lastMidRateUSDCAD = 1.30;

        // send in a couple of prices to ensure that all filters, books etc. are primed
        checkPriceAllTheWayThrough();
        final MarketDataSnapshotImpl marketDataSnapshotPrimeUSDCAD = MidRateTestHelper.createMarketData(Instrument.USDCAD, Market.DEUT, COUNT, lastMidRateUSDCAD, SPREAD);
        defaultTestConfig.marketDataConsumers.accept(marketDataSnapshotPrimeUSDCAD);

        final MutableLocalDate Tplus2 = (new MutableLocalDate()).set(LocalDate.now().plus(2, ChronoUnit.DAYS));
        defaultTestConfig.spotDateConsumer.accept(new SpotDateImpl(Instrument.USDCAD, Tplus2));
        defaultTestConfig.spotDateConsumer.accept(new SpotDateImpl(Instrument.AUDUSD, Tplus2));
        defaultTestConfig.spotDateConsumer.accept(new SpotDateImpl(Instrument.AUDCAD, Tplus2));

        int lastNumberAudCad = 0;

        // after 3 the slowest market filter kicks in
        for (int i = 1; i <= 3; i++) {
            int direction = oneOrMinusOne(random);

            testTimeSource.incrementNanos(TimeUnit.MILLISECONDS.toNanos(incrementTimeMS) + 1);
            final MarketDataSnapshotImpl marketDataSnapshot = MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.RFX, COUNT, lastMidRateAUDUSD + (direction * incrementPrice), SPREAD);
            lastMidRateAUDUSD = marketDataSnapshot.getMidRate();
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot);

            final MarketDataSnapshotImpl marketDataSnapshot2 = MidRateTestHelper.createMarketData(Instrument.USDCAD, Market.RFX, COUNT, lastMidRateUSDCAD, SPREAD);
            lastMidRateUSDCAD = marketDataSnapshot2.getMidRate();
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot2);

            final List<ClientPrice> audcad = defaultTestConfig.clientPriceSink().getEvents().stream().filter(clientPrice -> clientPrice.getInstrument() == Instrument.AUDCAD).collect(Collectors.toList());
            assertTrue(audcad.size() > lastNumberAudCad);
            lastNumberAudCad = audcad.size();
            assertEquals(1.0d, audcad.get(audcad.size() - 1).getMidRate(), 0.2d);
        }
    }

    @Test
    @DirtiesContext
    public void testSlowestMarketMinimumMarketFiltersIncomingEmptyBooks() {
        final MarketDataSnapshotImpl marketDataSnapshot3, marketDataSnapshot4;
        given:
        {
            // send in a couple of prices to ensure that all filters, books etc. are primed
            checkPriceAllTheWayThrough();
            // send in 2 more markets with same price so dispersal filter doesn't get invoked
            marketDataSnapshot3 = MidRateTestHelper.createMarketData(Market.DEUT, COUNT, DEUT_MID, SPREAD);
            marketDataSnapshot3.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS + 400));
            marketDataSnapshot4 = MidRateTestHelper.createMarketData(Market.RFX, COUNT, MID, SPREAD);
            marketDataSnapshot4.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS + 600));
        }
        when:
        {
            testTimeSource.setNanos(marketDataSnapshot3.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot3);
            testTimeSource.setNanos(marketDataSnapshot4.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot4);
        }

        then:
        {
            // price not changed so no prices emitted
            assertEquals(0, defaultTestConfig.clientPriceSink().getEvents().size());
        }

        and:
        {
            for (int i = 0; i < 100; i++) {
                // send in repeated empty CNX books
                final MarketDataSnapshotImpl marketDataSnapshotNoPrice = MidRateTestHelper.createMarketData(Market.CNX, COUNT_NO_BIDS_OR_ASKS, MID, SPREAD);
                marketDataSnapshotNoPrice.setExternalEventTimeNS(testTimeSource.nowNanos() + TimeUnit.SECONDS.toNanos(1));
                testTimeSource.setNanos(marketDataSnapshotNoPrice.getExternalEventTimeNS());
                defaultTestConfig.marketDataConsumers.accept(marketDataSnapshotNoPrice);
                // price not changed so no prices emitted. If all markets were getting removed we would receive an empty book
                assertEquals(0, defaultTestConfig.clientPriceSink().getEvents().size());
                // TODO: confirm that defaultTestConfig.marketDataSink().getEvents() contains what we expect
            }
        }
    }

    @Test
    @DirtiesContext
    public void checkFilterOutcomesInMarketBookEvents() {
        final MarketDataSnapshotImpl marketDataSnapshot3, marketDataSnapshot4;
        given:
        {
            // send in a couple of prices to ensure that all filters, books etc. are primed
            checkPriceAllTheWayThrough();
            // send in 1 more markets with same price so dispersal filter doesn't get invoked
            marketDataSnapshot3 = MidRateTestHelper.createMarketData(Market.FASTMATCH, COUNT, DEUT_MID, SPREAD);
            marketDataSnapshot3.setExternalEventTimeNS(testTimeSource.nowNanos() + TimeUnit.SECONDS.toNanos(1));
        }
        when:
        {
            testTimeSource.setNanos(marketDataSnapshot3.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot3);
        }

        then:
        {
            // price not changed so no prices emitted
            assertEquals(0, defaultTestConfig.clientPriceSink().getEvents().size());
            // check filtering, WSP_U is unchanged so won't be emitted.
            assertEquals(1, defaultTestConfig.marketDataSink().getEvents().size());
            final FilteredMarketDataSnapshot deut = (FilteredMarketDataSnapshot) defaultTestConfig.marketDataSink().getEvents().get(0);
            assertEquals(Market.FASTMATCH, deut.getMarket());
            assertEquals(FilterDecision.PASS, deut.getFilterOutcome());
        }
    }

    @Test
    @DirtiesContext
    public void checkRepublishOnTZChange() {
        ClientPrice firstClientPrice = null;
        given:
        {
            // send in a couple of prices to ensure that all filters, books etc. are primed
            firstClientPrice = checkPriceAllTheWayThrough();
            assertEquals(firstClientPrice.getMarket(), Market.WSP_Z);
            assertEquals(3e-5, firstClientPrice.getSpread(), EPSILON);
        }
        when:
        {
            TradingTimeZoneChime.INSTANCE.setTradingTimeZone(TradingTimeZone.ROLL);
            defaultTestConfig.tradingTimeZoneChimeConsumer.accept(TradingTimeZoneChime.INSTANCE);
        }

        then:
        {
            final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getLastEvent();
            final int numberOfPriceModels = getPricingModelMarketCount(indexedConfigurationData);

            // spreads have increased.
            {
                assertEquals(numberOfPriceModels, defaultTestConfig.clientPriceSink().getEvents().size());
                final ClientPrice clientPrice = defaultTestConfig.clientPriceSink().findLast(p -> p.getInstrument()==Instrument.AUDUSD && p.getMarket()==Market.WSP_Z);
                assertEquals(firstClientPrice.getMarket(), Market.WSP_Z);
                assertEquals("spread should be wider in ROLL TZ", 2e-4, clientPrice.getSpread(), EPSILON);
            }

            final ClientPriceThrottleConfig clientPriceThrottleConfig = getByMarketAndInstrument(indexedConfigurationData.getClientPriceThrottleConfigs(), Market.WSP_A, Instrument.AUDUSD);
            final long incrementTimeMS = clientPriceThrottleConfig.getNoActivityHeartbeatFrequencyMs();
            for (int j = 0; j < Math.ceil(incrementTimeMS/1000.0); j++) {
                assertEquals(numberOfPriceModels, defaultTestConfig.clientPriceSink().getEvents().size());
                testTimeSource.incrementNanos(TimeUnit.SECONDS.toNanos(1));
                defaultTestConfig.oneSecondConsumer.accept(OneSecond.INSTANCE);
            }

            // additional heartbeat events.
            {
                List<ClientPrice> driverClientPrices = defaultTestConfig.clientPriceSink().getEvents().stream().filter(p -> p.getInstrument() == Instrument.AUDUSD).collect(Collectors.toList());
                assertEquals(numberOfPriceModels * 2, driverClientPrices.size());
                final ClientPrice clientPrice = driverClientPrices.get(driverClientPrices.size()-1);
                assertEquals(firstClientPrice.getMarket(), Market.WSP_Z);
                assertEquals("spread should be wider in ROLL TZ", 2e-4, clientPrice.getSpread(), EPSILON);
            }
        }
    }

    @Ignore("unreliable - investigating")
    @Test
    @DirtiesContext
    public void checkStalePriceTurnsOffArbitrageFirewall() {
        final IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
        final int numberOfPriceModels = getPricingModelMarketCount(indexedConfigurationData);
        MarketDataSnapshotImpl marketDataSnapshot, marketDataSnapshot2, marketDataSnapshot3;
        given:
        {
            setMinimumMarkets(indexedConfigurationData, 1);
            setArbThreshold(indexedConfigurationData, Instrument.AUDUSD, 0.5);
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.FASTMATCH), is(true));
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_R, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.FASTMATCH), is(false));
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.BARX), is(false));
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_R, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.BARX), is(true));

            // BARX is not primary and is reference
            marketDataSnapshot = MidRateTestHelper.createMarketData(Market.BARX, COUNT, MID, 0);
            marketDataSnapshot.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS));
            // FASTMATCH is the opposite
            marketDataSnapshot2 = MidRateTestHelper.createMarketData(Market.FASTMATCH, COUNT, MID, 0);
            marketDataSnapshot2.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(INITIAL_TS_MS + TimeUnit.SECONDS.toMillis(599)));
        }
        when:
        {
            testTimeSource.setNanos(marketDataSnapshot.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot);
            testTimeSource.setNanos(marketDataSnapshot2.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot2);

            assertEquals(numberOfPriceModels, defaultTestConfig.clientPriceSink().getEvents().size());
            final ClientPrice clientPriceA = defaultTestConfig.clientPriceSink().getEvents().get(0);
            assertEquals(Market.WSP_A, clientPriceA.getMarket());
            assertTrue(PricingFirewallType.ARBITRAGE.isBitMaskSet(clientPriceA.getBidIndicativeBits()));
            defaultTestConfig.clientPriceSink().clear();
        }

        then:
        {
            // fire stale filter on reference price
            testTimeSource.incrementMillis(TimeUnit.SECONDS.toMillis(1));
            defaultTestConfig.oneSecondConsumer.accept(OneSecond.INSTANCE);

            marketDataSnapshot3 = MidRateTestHelper.createMarketData(Market.FASTMATCH, COUNT, MID + 0.00001, 0);
            marketDataSnapshot3.setExternalEventTimeNS(marketDataSnapshot2.getExternalEventTimeNS() + 1);
            testTimeSource.setNanos(marketDataSnapshot3.getExternalEventTimeNS());
            defaultTestConfig.marketDataConsumers.accept(marketDataSnapshot3);

            assertEquals(numberOfPriceModels, defaultTestConfig.clientPriceSink().getEvents().size());
            final ClientPrice clientPriceA = defaultTestConfig.clientPriceSink().getEvents().get(0);
            assertEquals(Market.WSP_A, clientPriceA.getMarket());
            assertFalse(PricingFirewallType.ARBITRAGE.isBitMaskSet(clientPriceA.getBidIndicativeBits()));
        }
    }

    private void setMinimumMarkets(IndexedConfigurationData indexedConfigurationData, int minimumMarkets) {
        final ConfigurationDataDefault cfg = (ConfigurationDataDefault) indexedConfigurationData.getConfigurationData();
        cfg.setMinimumMarketsFilterConfigs(Arrays.asList(new MinimumMarketFilterConfigImpl(Instrument.ANY, minimumMarkets)));
        defaultTestConfig.configurationDataConsumer.accept(cfg);
    }

    private void setArbThreshold(IndexedConfigurationData indexedConfigurationData, final Instrument instrument,
                                 double threshold) {
        final ConfigurationDataDefault cfg = (ConfigurationDataDefault) indexedConfigurationData.getConfigurationData();
        pricingArbitrageFirewallConfig(cfg.getPricingArbitrageFirewallConfigs(), instrument).setThresholdInPips(threshold);
        defaultTestConfig.configurationDataConsumer.accept(cfg);
    }

    private PricingArbitrageFirewallConfigImpl pricingArbitrageFirewallConfig(
            final List<PricingArbitrageFirewallConfig> list, final Instrument instrument) {
        return (PricingArbitrageFirewallConfigImpl) list.stream().filter(pafc -> pafc.getInstrument() == instrument).findFirst().get();
    }

    private int oneOrMinusOne(final Random random) {
        return (random.nextInt(2) == 0) ? 1 : -1;
    }

    private ClientPriceThrottleConfig getByMarketAndInstrument(final List<ClientPriceThrottleConfig> list,
                                                               final Market market,
                                                               final Instrument instrument) {
        return list.stream().
                filter(c -> c.getMarket().equals(market) && c.getInstrument().equals(instrument)).
                findFirst().get();
    }

    private int getPricingModelMarketCount(final IndexedConfigurationData indexConfig) {
        final EnumSet<Market> marketSet = new EnumSet<>(Market.class);
        indexConfig.getPricingModelConfigTable().forEachRowKeyWithColumnKey((market, priceModel) -> {
            marketSet.add(market);
        }, Instrument.ANY);

        return marketSet.size();
    }
}