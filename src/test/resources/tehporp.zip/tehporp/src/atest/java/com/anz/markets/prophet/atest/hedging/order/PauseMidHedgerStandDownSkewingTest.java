package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.*;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.hedging.volume.HedgePauseState;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.features.StanddownMidHedgersOnNoSkewFeatureSpecs;
import com.anz.markets.prophet.pricer.pfp.features.StanddownSkewPnLFeatureSpecs;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Market.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 ** AXPROPHET-1326 Stand down skewing strategy(AXPROPHET-1143) will now also send signal
 * to PAUSE Mid Hedger (working in conjuction with Deal Volume
 *
 **/
@Requirement(value = {Requirement.Ref.HEDGING_AXPROPHET_1326})
public class PauseMidHedgerStandDownSkewingTest extends BaseAcceptanceSpecification {

    private NewOrder newOrder;
    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair
    double lowWaterMark = 100_000;

    private ConfigurationDataDefault setUpConfiguration() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig2 = new ArrayList<>();
        StanddownSkewPnLFeatureSpecs specs = StanddownSkewPnLFeatureSpecs.INSTANCE;
        StanddownMidHedgersOnNoSkewFeatureSpecs specs2 = StanddownMidHedgersOnNoSkewFeatureSpecs.INSTANCE;

        // set up Stand Down Skewing(pnl) config
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, 100.0,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, -0.6,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, 0.5,
                specs.PARAM_MIN_UNREALISED_PNL_USD, -100000.0,
                specs.PARAM_MAX_UNREALISED_PNL_USD, 100000.9,
                specs.PARAM_MIN_POSITION_USD, 1_000_000.0)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_VOLATILITY_FACTOR_WINDOW, "CAT_A",
                specs.PARAM_MAX_VOLATILITY, Double.NaN,
                specs.PARAM_MIN_UNREALISED_PNL_PIPS, Double.NaN,
                specs.PARAM_MAX_UNREALISED_PNL_PIPS, Double.NaN,
                specs.PARAM_MIN_UNREALISED_PNL_USD, Double.NaN,
                specs.PARAM_MAX_UNREALISED_PNL_USD, Double.NaN,
                specs.PARAM_MIN_POSITION_USD, Double.NaN)
        );

        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs2.PARAM_TARGET_HEDGERS, "MID_BGC_EP|MID_BGC_VAR")
        );

        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs2.PARAM_TARGET_HEDGERS, "")
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0)
                ))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(com.google.common.collect.Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ))
                .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                        new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 200_000, 2000, 3000, "MID_BGC_EP", TradingTimeZone.GLOBAL)
                ))
                .setMidHedgerConfigs(Arrays.asList(
                        new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                .setRiskTriggerLowWaterMark(lowWaterMark)
                                .setRiskTriggerHighWaterMark(1_600_000.0)
                                .setOrderQuantity(100_000)
                                .setVarTriggerHighVar(999_999)  // set large to disable
                                .setTradingTimeZone(TradingTimeZone.LDN)
                ));

        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME,priceFormationPipelineConfig);
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs2.NAME,priceFormationPipelineConfig2);

        return configuration;
    }

    @Test
    @RestartBeforeTest(reason="reset vol")
    @RelatedTest(PauseMidHedgerDealVolumeTest.class)
    public void stand_down_skew_and_trade_volume() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);

            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(AXL, indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        when:
        // send client deal to generated optimal positions
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 500_000, 78.420));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, BGCMIDFX)).getLast();
            assertThat(newOrder.getQuantity(), is(100_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        // unrealised pnl = 0.75100 - 0.75105 = -0.5 pip is between min(-0.6) and max(0.5) => stand down
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(-3_755_250.0));
            assertThat(positionsUpdate.getPosition1().getAvgRate(), is(0.75100));
            assertThat(positionsUpdate.getPosition1().getMidRate(), is(0.75105));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75100));  // UNSKEWED
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
        }
        and:
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
        }
        when:
        // t+0.5sec order 500k filled. Does not breach trade volume window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75100);
        }
        then:
        // gradPosition is still higher than LowWaterMark.
        // However, STAND DOWN SKEW ACTIVE so do NOT hedge
        {
            prophet.notExpect(HedgePauseSignal.class, isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));

            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SLEEPING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // receive AUDUSD
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75107, 0.00003));
        }
        then:
        // unrealised pnl = 0.75100 - 0.75107 = -0.7 pip is not between min(-0.6) and max(0.5) => do NOT stand down skew
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.751082));  // UNSKEWED
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewPnLFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.DORMANT_WARM));
            assertThat(ftl.offerStatus, is(FeatureStatus.DORMANT_WARM));

            prophet.expect(HedgePauseSignal.class, isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
        }
        and:
        // STAND DOWN SKEW not active -> Hedger places order
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, BGCMIDFX)).getLast();
        }
        when:
        // t+1.5sec order 100k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75100);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, therefore do NOT place out any orders until t+4.5
            prophet.expect(HedgePauseSignal.class, isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SLEEPING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // Mid Hedger cannot place order until sleep period is over
        // t+4.0 STAND DOWN SKEW active
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
        }
        then:
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
        }
        when:
        // t+4.5 end of sleep period. But since STAND DOWN SKEW ACTIVE so do NOT hedge
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // Stand Down skew is inactive
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75107, 0.00003));
        }
        then:
        // hedger now allowed to hedge
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, Market.BGCMIDFX));
        }
    }
}