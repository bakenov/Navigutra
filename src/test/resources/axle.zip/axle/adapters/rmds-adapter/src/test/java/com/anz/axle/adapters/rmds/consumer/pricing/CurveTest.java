package com.anz.axle.adapters.rmds.consumer.pricing;

import com.anz.axle.adapters.rmds.consumer.pricing.Curve.MaturityDateComparator;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.ForwardPointsQuotePageBuilder;
import com.anz.axle.pricing.Quote;
import org.joda.time.LocalDate;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class CurveTest {

    @Test
    public void testMaturityDateComparator() {
        LocalDate date1 = new LocalDate(2013, 1, 1);
        LocalDate date2 = date1.plusDays(2);
        ForwardPointsQuotePage page1 = new ForwardPointsQuotePageBuilder().withTenorDate(date1).build();
        ForwardPointsQuotePage page2 = new ForwardPointsQuotePageBuilder().withTenorDate(date2).build();

        MaturityDateComparator comparator = new MaturityDateComparator();
        assertTrue(comparator.compare(page1, page2) < 0);
        assertTrue(comparator.compare(page2, page1) > 0);

        page2 = new ForwardPointsQuotePageBuilder().withTenorDate(date1).build();
        assertTrue(comparator.compare(page1, page2) == 0);

        page2 = new ForwardPointsQuotePageBuilder().withTenorDate(date1.minusDays(1)).build();
        assertTrue(comparator.compare(page1, page2) > 0);
    }

    @Test
    public void testBuildPreSpotTomNextOnly() {
        Curve curve = new Curve("AUD/USD");

        ForwardPointsQuotePage TN = new ForwardPointsQuotePageBuilder()
            .withSymbol("AUD/USD")
            .withQuote(1.4, 1.5)
            .withTenor(Tenor.TOM_NEXT)
            .withTenorDate(new LocalDate())
            .withReferenceSpotDate(new LocalDate().plusDays(2))
            .build();

        assertEquals(0, curve.getPoints().size());
        curve.addPoint(TN);
        assertEquals(1, curve.getPoints().size());
        assertEquals(TN, curve.findPointForTenor(Tenor.TOM_NEXT));

        List<ForwardPointsQuotePage> preSpot = curve.calculatePreSpotTenors();
        assertEquals(1, preSpot.size());    // only calculates TOM, not TODAY
        ForwardPointsQuotePage TOM = preSpot.get(0);
        assertEquals(Tenor.TOM, TOM.getTenor());
        assertEquals(TN.getTenorDate(), TOM.getTenorDate());
        assertEquals(TN.getReferenceSpotDate(), TOM.getReferenceSpotDate());
        assertNotNull(TOM.getQuotes().get(0));
        Quote quote = TOM.getQuotes().get(0);
        assertEquals(TN.getQuotes().get(0).getAskPrice().negate(), quote.getBidPrice());
        assertEquals(TN.getQuotes().get(0).getBidPrice().negate(), quote.getAskPrice());
        assertEquals(TN.getState(), quote.getState());
    }


    @Test
    public void testBuildTodayTenorForTPlus1Pair() {
        final String symbol = "USD/CAD";
        Curve curve = new Curve(symbol);
        curve.setOneDaySettlementPairs(new HashSet<String>(Arrays.asList(symbol)));

        ForwardPointsQuotePage ON = new ForwardPointsQuotePageBuilder()
        .withSymbol(symbol)
        .withQuote(1.8, 1.7)
        .withTenor(Tenor.OVERNIGHT)
        .withTenorDate(new LocalDate())
        .build();

        assertEquals(0, curve.getPoints().size());

        // Add ON
        curve.addPoint(ON);
        assertEquals(1, curve.getPoints().size());
        assertEquals(ON, curve.findPointForTenor(Tenor.OVERNIGHT));


        List<ForwardPointsQuotePage> preSpot = curve.calculatePreSpotTenors();
        assertEquals(1, preSpot.size());    // only calculates TOM, not TODAY
        ForwardPointsQuotePage TODAY = preSpot.get(0);
        assertEquals(Tenor.TODAY, TODAY.getTenor());

        // check precalculated prespot rates (TODAY)
        Decimal todayAskPoints = ON.getBid().negate();
        Decimal todayBidPoints = ON.getAsk().negate();
        assertEquals(TODAY.getAsk(), todayAskPoints);
        assertEquals(TODAY.getBid(), todayBidPoints);
    }


    @Test
    public void testBuildPreSpotTomNextAndOvernight() {
        Curve curve = new Curve("AUD/USD");

        ForwardPointsQuotePage ON = new ForwardPointsQuotePageBuilder()
        .withSymbol("AUD/USD")
        .withQuote(1.8, 1.7)
        .withTenor(Tenor.OVERNIGHT)
        .withTenorDate(new LocalDate())
        .build();

        ForwardPointsQuotePage TN = new ForwardPointsQuotePageBuilder()
            .withSymbol("AUD/USD")
            .withQuote(1.5, 1.4)
            .withTenor(Tenor.TOM_NEXT)
            .withTenorDate(new LocalDate().plusDays(1))
            .build();

        assertEquals(0, curve.getPoints().size());

        // Add ON
        curve.addPoint(ON);
        assertEquals(1, curve.getPoints().size());
        assertEquals(ON, curve.findPointForTenor(Tenor.OVERNIGHT));

        // Add TN
        curve.addPoint(TN);
        assertEquals(2, curve.getPoints().size());
        assertEquals(TN, curve.findPointForTenor(Tenor.TOM_NEXT));

        List<ForwardPointsQuotePage> preSpot = curve.calculatePreSpotTenors();
        assertEquals(2, preSpot.size());    // only calculates TOM, not TODAY
        ForwardPointsQuotePage TODAY = preSpot.get(0);
        assertEquals(Tenor.TODAY, TODAY.getTenor());

        // check precalculated prespot rates (TODAY)
        Decimal todayAskPoints = ON.getBid().negate().add(TN.getBid().negate());
        Decimal todayBidPoints = ON.getAsk().negate().add(TN.getAsk().negate());
        assertEquals(TODAY.getAsk(), todayAskPoints);
        assertEquals(TODAY.getBid(), todayBidPoints);

        ForwardPointsQuotePage TOMORROW = preSpot.get(1);
        assertEquals(Tenor.TOM, TOMORROW.getTenor());

        Decimal tomorrowAskPoints = TN.getBid().negate();
        Decimal tomorrowBidPoints = TN.getAsk().negate();
        assertEquals(TOMORROW.getAsk(), tomorrowAskPoints);
        assertEquals(TOMORROW.getBid(), tomorrowBidPoints);

    }


    @Test
    public void testBuildPreSpotOvernightOnly() {
        Curve curve = new Curve("AUD/USD");

        ForwardPointsQuotePage ON = new ForwardPointsQuotePageBuilder()
            .withSymbol("AUD/USD")
            .withQuote(1.4, 1.5)
            .withTenor(Tenor.OVERNIGHT)
            .withTenorDate(new LocalDate())
            .build();

        assertEquals(0, curve.getPoints().size());
        curve.addPoint(ON);
        assertEquals(1, curve.getPoints().size());
        assertEquals(ON, curve.findPointForTenor(Tenor.OVERNIGHT));

        List<ForwardPointsQuotePage> preSpot = curve.calculatePreSpotTenors();
        assertEquals(0, preSpot.size());    // cant calculate TODAY without T/N
    }

    @Test
    public void test_hasPoint_for_tenor() {
        Curve curve = new Curve("AUD/USD");
        assertFalse(curve.hasPointFor(Tenor.SPOT));

        final ForwardPointsQuotePage page = new ForwardPointsQuotePageBuilder()
                .withSymbol("AUD/USD")
                .withQuote(1.4, 1.5)
                .withTenor(Tenor.SPOT)
                .withTenorDate(new LocalDate())
                .build();
        curve.addPoint(page);
        assertTrue(curve.hasPointFor(Tenor.SPOT));
    }


}
