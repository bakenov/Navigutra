package com.anz.axle.lg.adapter.ebs;

import java.util.concurrent.atomic.AtomicInteger;

import software.chronicle.fix.staticcode.SessionID;

import com.anz.axle.lg.adapter.chroniclefix.UserRequestEncoder;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.CustUserData_UserDataGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.CstmApplVerID;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultUserRequest;
import com.anz.axle.lg.adapter.fix.UserRequestData;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserRequestType.CHANGE_PASSWORD_FOR_USER;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserRequestType.LOG_OFF_USER;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserRequestType.LOG_ON_USER;

public class EbsUserRequestEncoder implements UserRequestEncoder<UserRequest> {

    private final DefaultUserRequest userRequest = new DefaultUserRequest();
    private final AtomicInteger index = new AtomicInteger(-1);

    @Override
    public UserRequest encode(final SessionID sessionID, final String requestId, final UserRequestData userRequestData) {

        userRequest.reset();
        userRequest.senderCompID(sessionID.localCompID());
        userRequest.targetCompID(sessionID.remoteCompID());
        userRequest.userRequestID(requestId);
        final int userRequestType = userRequestType(userRequestData);
        userRequest.userRequestType(userRequestType);
        userRequest.username(userRequestData.userName());
        userRequest.password(userRequestData.password());

        switch (userRequestType) {
            case LOG_ON_USER:
                final String cstmApplVerID = userRequestData.customerTagValues().get(CstmApplVerID.FIELD);
                userRequest.cstmApplVerID(cstmApplVerID != null ? cstmApplVerID : null);

                userRequest.noUserData(userRequestData.userDataNameValues().size());
                index.set(-1);
                userRequestData.userDataNameValues().forEach((name, value) -> {
                    final CustUserData_UserDataGrp_1 userRequestGroup = userRequest.custUserData_UserDataGrp_1(index.incrementAndGet());
                    userRequestGroup.userDataName(name);
                    userRequestGroup.userDataValue(value);
                });
                break;
            case LOG_OFF_USER:
                //no extra fields required for logoff
                break;
            case CHANGE_PASSWORD_FOR_USER:
                userRequest.newPassword(userRequestData.newPassword());
                break;
        }
        return userRequest;
    }

    private int userRequestType(final UserRequestData userRequestData) {
        switch (userRequestData.userRequestType()) {
            case USER_REQUEST_TYPE_LOGONUSER: return LOG_ON_USER;
            case USER_REQUEST_TYPE_LOGOFFUSER: return LOG_OFF_USER;
            case USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER: return CHANGE_PASSWORD_FOR_USER;
            default: throw new IllegalArgumentException("Unsupported UserRequestType: " + userRequestData.userRequestType());
        }
    }
}
