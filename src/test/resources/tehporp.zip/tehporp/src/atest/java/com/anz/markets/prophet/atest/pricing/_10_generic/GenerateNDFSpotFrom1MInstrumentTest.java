package com.anz.markets.prophet.atest.pricing._10_generic;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.EmptyBookReason;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class GenerateNDFSpotFrom1MInstrumentTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault setUpConfiguration() {
        final long fwdPointsMaxAgeMs = 5_000;
        ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_POINTS_MAX_AGE_MS, fwdPointsMaxAgeMs))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_TAGGED_INDICATIVE_ENABLED, true));

        final List<ClientSpreadConfig> clientSpreadConfigs = new ArrayList<>(configurationDataDefault.getClientSpreadConfigs());
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 8.0));
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10.0));
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 12.0));
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDIN1_1M, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDIN1_1M, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
        clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDIN1_1M, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
        configurationDataDefault.setClientSpreadConfigs(clientSpreadConfigs);

        final List<MarketConfig> marketConfigs = new ArrayList<>(configurationDataDefault.getMarketConfigs());
        marketConfigs.add(new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDIN1_1M).setEnabled(true));
        configurationDataDefault.setMarketConfigs(marketConfigs);
        configurationDataDefault.addAggBook(Market.WSP_U, Instrument.USDIN1_1M, TradingTimeZone.GLOBAL, Region.GB, Market.EBS);

        final List<InstrumentConfig> instrumentConfigs = new ArrayList<>(configurationDataDefault.getInstrumentConfigs());
        instrumentConfigs.add(new InstrumentConfigImpl(Instrument.USDIN1).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(0).setPrecisionMultiplier(1).setSpreadMultiplier(0));
        configurationDataDefault.setInstrumentConfigs(instrumentConfigs);

        final List<ClientPriceThrottleConfig> throttleConfigs = new ArrayList<>(configurationDataDefault.getClientPriceThrottleConfigs());
        throttleConfigs.add(new ClientPriceThrottleConfigImpl(Market.ANY, Currency.USD, Currency.INR)
                .setNoActivityHeartbeatFrequencyMs(20000)
                .setStartStopTimePeriodMS(0)
                .setLimit(2)
                .setTimePeriod(2)
                .setMinimumPriceDeltaFractionOfSpread(0.01)
                .setMinimumPriceDeltaFractionOfPreviousSpread(0.01)
                .setOverrideLimit(2)
                .setOverrideTimePeriod(2)
                .setOverrideMinimumPriceDeltaFractionOfMid(0.000001)
                .setMinimumPriceDeltaFractionOfPreviousSpread(0.001));
        configurationDataDefault.setClientPriceThrottleConfigs(throttleConfigs);

        return configurationDataDefault;
    }

    @Test
    @RestartBeforeTest(reason="clear prices")
    // AXPROPHET-1200 back out forward points from the 1M allin to generate offshore spot price
    public void generate_ndf_spot_from_1M_instrument() throws Exception {
        given:
        {
            prophet.receive(new SpotDateImpl(Instrument.USDIN1_1M, LocalDate.now().plusDays(2)));
            prophet.startUmProbes(setUpConfiguration(), true);
            prophet.startUmOutSubscription(new Market[]{Market.WSP_U, Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z}, Instrument.USDIN1);
            prophet.startUmOutSubscription(new Market[]{Market.WSP_U, Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z}, Instrument.USDIN1_1M);
        }
        when:
        // receive USDIN1_1M INCREMENTAL market data from UM
        {
            prophet.clearOutputBuffers();
            prophet.receiveNDFFromUm(tdd.marketDataIncrementNew(Market.EBS, Instrument.USDIN1_1M, 63.920, 111L));
        }
        then:
        // expect USDIN1_1M messages on chronicle out
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.890, 63.950));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 63.875, 63.965));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 63.855, 63.985));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 63.850, 63.990));

            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_B));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_C));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_Z));
        }
        and:
        // expect USDIN1_1M messages on UM
        {
            ClientPrice clientPrice = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.890, 63.950));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 63.875, 63.965));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 63.855, 63.985));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 63.850, 63.990));

            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_B));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_C));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1_1M, Market.WSP_Z));
        }
        when:
        // USDIN1_1M positive forward points received triggers price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.forwardPoint(Instrument.USDIN1_1M, 19.1d, 23.1d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
        }
        then:
        // USDIN1 price is the USDIN1_1M price with forwards points backed out at all levels
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.699, 63.719));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 63.684, 63.734));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 63.664, 63.754));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 63.659, 63.759));

            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_B));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_C));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_Z));
        }
        and:
        // expect USDIN1 messages on UM
        {
            ClientPrice clientPrice = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.699, 63.719));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 63.684, 63.734));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 63.664, 63.754));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 63.659, 63.759));

            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_B));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_C));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_Z));
        }
        when:
        // wait till forward point expire(5seconds)
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.clearOutputBuffers(); // throttler pushes out another set of client prices after 1sec chime(not sure why)
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // expect empty USDIN1 book
        {
            ClientPrice cpWspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(cpWspA.getBids().size(), is(0));
            assertThat(cpWspA.getEmptyBookReason(), is(EmptyBookReason.NDF_EXPIRED_1M_FORWARD_POINTS));

            ClientPrice cpWspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_B)).getLast();
            assertThat(cpWspB.getBids().size(), is(0));
            assertThat(cpWspB.getEmptyBookReason(), is(EmptyBookReason.NDF_EXPIRED_1M_FORWARD_POINTS));

            ClientPrice cpWspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_C)).getLast();
            assertThat(cpWspC.getBids().size(), is(0));
            assertThat(cpWspC.getEmptyBookReason(), is(EmptyBookReason.NDF_EXPIRED_1M_FORWARD_POINTS));

            ClientPrice cpWspZ = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_Z)).getLast();
            assertThat(cpWspZ.getBids().size(), is(0));
            assertThat(cpWspZ.getEmptyBookReason(), is(EmptyBookReason.NDF_EXPIRED_1M_FORWARD_POINTS));
        }
        and:
        // expect empty USDIN1 messages on UM
        {
            ClientPrice cpWspA = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(cpWspA.getBids().size(), is(0));

            ClientPrice cpWspB = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_B)).getLast();
            assertThat(cpWspB.getBids().size(), is(0));

            ClientPrice cpWspC = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_C)).getLast();
            assertThat(cpWspC.getBids().size(), is(0));

            ClientPrice cpWspZ = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_Z)).getLast();
            assertThat(cpWspZ.getBids().size(), is(0));
        }
        when:
        // negative forward points received and marketdata for 1M triggers price
        {
            prophet.receive(tdd.marketDataSnapshot(Market.EBS, Instrument.USDIN1_1M, 63.921, 0.02));
            prophet.receive(tdd.forwardPoint(Instrument.USDIN1_1M, -19.1d, -23.1d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
            prophet.clearOutputBuffers();
            prophet.receive(tdd.marketDataSnapshot(Market.EBS, Instrument.USDIN1_1M, 63.920, 0.02));
        }
        then:
        // expect USDIN1 again on chronicle out
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 64.081, 64.181));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 64.066, 64.196));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 64.046, 64.216));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 64.041, 64.221));
        }
        and:
        // expect USDIN1 messages on UM again
        {
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A));
        }
        when:
        // positive forward points received resulting in USDIN1 WSP_A CHOICE tob
        // marketdata for 1M triggers price
        {
            prophet.receive(tdd.marketDataSnapshot(Market.EBS, Instrument.USDIN1_1M, 63.921, 0.02));
            prophet.receive(tdd.forwardPoint(Instrument.USDIN1_1M, 19.1d, 25.1d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.EBS, Instrument.USDIN1_1M, 63.920, 0.02));
        }
        then:
        // expect USDIN1 choice on chronicle out
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.699, 63.699));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 63.684, 63.714));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 63.664, 63.734));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 63.659, 63.739));
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // positive forward points received resulting in USDIN1 WSP_A CROSSED tob
        {
            prophet.clearOutputBuffers();
            prophet.receive(tdd.forwardPoint(Instrument.USDIN1_1M, 19.1d, 25.2d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.699, 63.698));
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPrice, PricingFirewallType.PRICE_CROSSED);
        }
        and:
        // expect indicative USDIN1 on UM
        {
            ClientPrice clientPrice = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getFirst();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
        when:
        // positive forward points received resulting in UN-CROSSED USDIN1 TOB
        {
            prophet.clearOutputBuffers();
            prophet.receive(tdd.forwardPoint(Instrument.USDIN1_1M, 19.1d, 25.1d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
        }
        then:
        // expect FIRM USDIN1 on chronicle out
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 63.699, 63.699));
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        and:
        // expect FIRM USDIN1 on UM
        {
            ClientPrice clientPrice = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDIN1, Market.WSP_A)).getFirst();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.FIRM));
        }
    }
}
