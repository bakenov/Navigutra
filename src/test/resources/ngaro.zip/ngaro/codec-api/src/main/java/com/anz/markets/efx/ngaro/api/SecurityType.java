package com.anz.markets.efx.ngaro.api;

import java.util.function.Consumer;

public enum SecurityType {
    FXSPOT,
    FXNDF,
    FXFWD,
    FXSWAP;

    private static final SecurityType[] VALUES = values();

    public static int length() {
        return VALUES.length;
    }

    public static SecurityType valueByOrdinal(final int ordinal) {
        return VALUES[ordinal];
    }

    public static void forEach(final Consumer<? super SecurityType> consumer) {
        for (final SecurityType value : VALUES) {
            consumer.accept(value);
        }
    }
}
