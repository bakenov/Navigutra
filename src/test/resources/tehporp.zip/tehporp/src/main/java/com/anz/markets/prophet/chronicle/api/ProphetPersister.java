package com.anz.markets.prophet.chronicle.api;

import com.anz.markets.prophet.chronicle.NotMarshallableException;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.RawBytes;
import com.anz.markets.prophet.domain.chronicle.SelfDescribingBytes;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBookImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.util.function.Consumer;

public interface ProphetPersister extends Closeable {
    Logger LOGGER = LoggerFactory.getLogger(ProphetPersister.class);

    void processActivationMessage(final Activate activate) throws Exception;

    void write(final MessageType messageType, final ProphetMarshallable entity);

    default Consumer<RawBytes> sinkRawBytes() {
        return rawBytes -> write(rawBytes.getMessageType(), rawBytes);
    }

    default Consumer<SelfDescribingBytes> sinkSelfDescribingBytes() {
        return selfDescribingBytes -> write(selfDescribingBytes.getMessageType(), selfDescribingBytes);
    }

    /**
     * One-to-one mapping of a message to a message type
     */
    default <PROPHET_MARSHALLABLE> Consumer<PROPHET_MARSHALLABLE> sink(final MessageType messageType) {
        // TODO: if (messageType == MessageType.ACTIVATE) here?
        return marshallable -> {
            if (marshallable instanceof ProphetMarshallable) {
                write(messageType, (ProphetMarshallable) marshallable);
            } else {
                throw new NotMarshallableException();
            }

            if (messageType == MessageType.ACTIVATE) {
                try {
                    processActivationMessage((Activate) marshallable);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

    long firstIndex();

    long getLastWrittenIndex();

    /**
     * Avoid below sinks -> legacy stuff.
     * <p>
     * See {@link com.anz.markets.prophet.chronicle.api.ProphetPersister#sink(MessageType)}
     */

    @Deprecated
    default Consumer<MarketData> sinkMarketData() {
        return marketData -> {
            if (marketData instanceof MarketDataIncrement) {
                write(MessageType.MARKET_DATA_INCREMENT, (ProphetMarshallable) marketData);
            } else if (marketData instanceof MarketDataSnapshot) {
                write(MessageType.MARKET_DATA_SNAPSHOT, (ProphetMarshallable) marketData);
            } else {
                LOGGER.error("Unprocessable MarketData Format {}", marketData);
            }
        };
    }

    @Deprecated
    default Consumer<MidRate> sinkMidRate() {
        return midRate -> {
            // write out the MarketDataSnapshot but TOB only
            if (midRate instanceof FilteredMarketDataSnapshotImpl) {
                FilteredMarketDataSnapshotImpl marketDataSnapshot = (FilteredMarketDataSnapshotImpl) midRate;
                write(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, marketDataSnapshot);
            } else if (midRate instanceof AggregatedBookImpl) {
                AggregatedBookImpl marketDataSnapshot = (AggregatedBookImpl) midRate;
                write(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, marketDataSnapshot.getChronicleMarshallableWriteOnlyTOB());
            } else {
                throw new RuntimeException("Error - should not be here: " + midRate);
            }
        };
    }

    @Deprecated
    default Consumer<Order> sinkOrder() {
        return order -> {
            if (order instanceof NewOrder) {
                sink(MessageType.ORDER_NEW).accept(order);
            } else {
                sink(MessageType.ORDER_CANCEL).accept(order);
            }
        };
    }
}