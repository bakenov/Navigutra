package com.anz.axle.lg.adapter.apama.config.core;


import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.anz.axle.applicationboot.EnvironmentResolver;
import com.anz.axle.spring.config.NestedPropertiesFactoryBean;

@Configuration
public class PropertiesConfig {

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer(@Qualifier("applicationProperties") final Properties properties) {
        final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        propertySourcesPlaceholderConfigurer.setProperties(properties);
        return propertySourcesPlaceholderConfigurer;
    }

    @Bean
    public NestedPropertiesFactoryBean applicationProperties(final String instanceName) throws IOException {
        final NestedPropertiesFactoryBean propertiesFactoryBean = new NestedPropertiesFactoryBean();
        propertiesFactoryBean.setIgnoreResourceNotFound(true);
        propertiesFactoryBean.setEnv(EnvironmentResolver.environment());
        propertiesFactoryBean.setLocations(new String[]{
                "classpath:conf/market-data-request.properties",
                "classpath:conf/messaging-default.properties",
                "classpath:conf/messaging-${env}.properties",
                "classpath:conf/apama-default.properties",
                "classpath:conf/apama-${env}.properties",
                "classpath:conf/apama-" + instanceName + "-default.properties",
                "classpath:conf/apama-" + instanceName + "-${env}.properties"
        });
        return propertiesFactoryBean;
    }
}
