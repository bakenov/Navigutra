package com.anz.markets.efx.fox.codec.pojo;

import java.util.EnumSet;
import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.pojo.matcher.VenueConfigMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.api.Venue;
import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class VenueConfigMatcherTest {
    private Predicate<VenueConfig> predicate = Matchers.isA(VenueConfig.class);
    private VenueConfigMatcher matcher = new VenueConfigMatcher() {
        @Override
        public Matcher<VenueConfigMatcher, VenueConfig.Body> body() {
            return matcher -> andThen(translate(venueConfig -> venueConfig.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof VenueConfig && predicate.test((VenueConfig) o);
        }

        private VenueConfigMatcher andThen(final Predicate<? super VenueConfig> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final VenueConfig venueConfig = SorMessage.venueConfig(
                new MessageHeader(),
                new VenueConfig.Body(Venue.RFX, "lg-rfx", EnumSet.of(VenueCategory.BANK, VenueCategory.INTERBANK), true));
        assertTrue(matcher.test(venueConfig));
        assertNotNull(matcher.body());
    }
}
