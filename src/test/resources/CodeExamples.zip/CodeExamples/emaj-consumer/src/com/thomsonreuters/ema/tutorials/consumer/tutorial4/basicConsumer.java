/*
	basicConsumer - tutorial4 - Requesting, parsing and decoding Level 2 data

	This tutorial is the 4th part in a series of tutorials with the goal of creating a basic consumer application.
	
	The goal of this tutorial is to demonstrates how to retrieve and decode level 2 (MBP-Market By Price, MBO-Market By Order)
	or SymbolList data received in response of a request sent to a Thomson Reuters Market Data System. Piggybacking off
	the level 1 decoding we used in the previous tutorial, we extend the functionality to allow the parsing of the level 2
	container.

	The series includes the following:

		o Tutorial 1 - Creating a barebones EMA consumer application
		o Tutorial 2 - Requesting and displaying MarketPrice data
		o Tutorial 3 - Parsing and Decoding MarketPrice data
		o Tutorial 4 - Requesting, parsing and decoding Level 2 data
		o Tutorial 5 - Dispatching messages within the user thread
 */

package com.thomsonreuters.ema.tutorials.consumer.tutorial4;

import com.thomsonreuters.ema.access.Msg;
import com.thomsonreuters.ema.access.AckMsg;
import com.thomsonreuters.ema.access.GenericMsg;
import com.thomsonreuters.ema.access.RefreshMsg;
import com.thomsonreuters.ema.access.ReqMsg;
import com.thomsonreuters.ema.access.StatusMsg;
import com.thomsonreuters.ema.access.UpdateMsg;
import com.thomsonreuters.ema.access.Payload;
import com.thomsonreuters.ema.access.Data;
import com.thomsonreuters.ema.access.DataType;
import com.thomsonreuters.ema.access.DataType.DataTypes;
import com.thomsonreuters.ema.access.EmaFactory;
import com.thomsonreuters.ema.access.FieldEntry;
import com.thomsonreuters.ema.access.FieldList;
import com.thomsonreuters.ema.access.Map;
import com.thomsonreuters.ema.access.MapEntry;
import com.thomsonreuters.ema.access.OmmConsumer;
import com.thomsonreuters.ema.access.OmmConsumerClient;
import com.thomsonreuters.ema.access.OmmConsumerConfig;
import com.thomsonreuters.ema.access.OmmConsumerEvent;
import com.thomsonreuters.ema.access.OmmException;

import com.thomsonreuters.ema.rdm.EmaRdm;

// basicConsumer
// The basicConsumer interface manages all control for the consumption of real-time data.  Implementing the
// EMA interface: OmmConsumerClient, we now have the opportunity to capture multiple, realtime events to 
// process the different types of messages we can receive once we subscribe to a market data item.  The
// interface below implements a number of required callbacks to achieve this goal.
//
public class basicConsumer implements OmmConsumerClient
{
	// Define our consumer communication channel to our Provider managing connection and item registration
	OmmConsumer consumer = null; 
	
	//*************************************************************************************************
	// Callback methods required by the OmmConsumerClient Interface.
	//
	// The following methods allow us to capture realtime events such as status and data events.
	//*************************************************************************************************
	
	// onRefreshMsg
	// Capture the initial image after subscribing (registering interest) in a market data item.  This 
	// callback parses and decodes the message and displays to the terminal.
	public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event)
	{
		System.out.println("RefreshMsg");
		
		// Display the Service Name and Item Name
		// These two fields are typically sent in a RefreshMsg from the Provider.  However, this information
		// is usually not sent for subsequent updates (UpdateMsg), unless explicitely requested during
		// registration.  As a result, we first check of their existence as a safeguard.
		
		// Service Name 
		String serviceName = "Not Available";
		if (refreshMsg.hasServiceName())
		{
			serviceName = refreshMsg.serviceName();
		}
		System.out.println("\tService Name: " + serviceName);

		// Item Name
		String itemName = "Not Available";
		if (refreshMsg.hasName())
		{
			itemName = refreshMsg.name();
		}
		System.out.println("\tItem: " + itemName);
	
		// Retrieve and display the state of the item. In this example we directly print the item state. 
		// However, finer grained information can be retrieved via the OmmState methods.  
		System.out.println("\tState: " + refreshMsg.state());
		
		// Decode the Payload
		// The data for a refresh message is conveyed by the payload. The payload will contain a complex 
		// data structure that must be decoded and parsed to retrieve the individual fields of interest.
		// The refreshMsg or initial image will contain the complete set of fields related to the data.
		decodePayload( refreshMsg.payload() );
		
		// When dealing with level 2 or SymbolList messages, they are commonly sent as multi-part messages
		// due to their size.  As a result, we may receive multiple refreshes before completion.
		System.out.println("Refresh complete: " + (refreshMsg.complete() ? "YES" : "NO"));
	}
	
	// onUpdateMsg
	// After receiving the initial image, we capture any updates to the item based on market events.
	// This callback parses and decodes the message and displays to the terminal.
	public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event)
	{
		System.out.println("UpdateMsg");
		
		// Decode the Payload
		// The data for an update message is conveyed by the payload. As with the refresh message, payload 
		// will contain a complex data structure that must be decoded and parsed to retrieve the individual 
		// fields of interest. However, the updatehMsg will contain only thoese fields that have changed 
		// based on the market conditions.
		decodePayload( updateMsg.payload() );
	}
	
	// onStatusMsg
	// General status messages related to your consumer item registration.  For example, you will receive a 
	// status message if you register interest in an invalid item.  This callback utlizes the convenient 
	// print method to display output.	
	public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event)
	{
		System.out.println(statusMsg);
	}

	// onAllMsg, onAckMsg, onGenericMsg
	// These callbacks are not necessary for our series of tutorials.  You can refer to the documentation
	// to better understand the purpose of these callbacks.
	public void onAllMsg(Msg msg, OmmConsumerEvent consumerEvent){}
	public void onAckMsg(AckMsg ackMsg, OmmConsumerEvent consumerEvent){}
	public void onGenericMsg(GenericMsg genericMsg, OmmConsumerEvent consumerEvent){}

	//*************************************************************************************************
	// Helpers and other private methods.
	//
	//*************************************************************************************************

	// decodePayload
	// Based on type of data we are interested in, i.e. level 1 or level 2 data, the Provider will send down
	// the corresponding payload.  The payload provides convenient getter methods for the different data types.  
	private void decodePayload(Payload payload)
	{
		// Decode the payload.
		// When decoding each message, we overload the method: decodeAndPrint based on the data type.
		switch ( payload.dataType() )
		{
			// A level 1 message (MARKET_PRICE)is packaged as a field list
			case DataType.DataTypes.FIELD_LIST:
				decodeAndPrint( payload.fieldList() );
				break;

			// A level 2 message (MBP, MBO) or SymbolList is packaged as a map
			case DataType.DataTypes.MAP:
				decodeAndPrint( payload.map() );
				break;
		}
				
		System.out.println();		
	}
	
	
	// ****************************************************************************************************************
	// decodeAndPrint
	// This series of overloaded methods decode and print the different types of OMM complex data types received
	// from Thomson Reuters Market Data Systems. The method(s) below are specialized in decoding and printing their
	// corresponding container types.
	// ****************************************************************************************************************
	
	// decodeAndPrint - FieldList
	// The FieldList is a list of entries commonly used in level 1 (MarketPrice) data responses.
	private void decodeAndPrint(FieldList fieldList)
	{
		// A FieldList is a collection of FieldEntries. Each of these entries conveys information about a specific field 
		// of the requested MarketPrice data item. Our loop walks through the collection, determines the data type and 
		// displays the appropriate output to the terminal.
		for (FieldEntry fieldEntry : fieldList)
		{
			// Display the general details related to a field.  A field will contain an ID (or FID - Field ID), 
			// corresponding name, type and value.
			System.out.print("    Name: " + fieldEntry.name() + " (Fid: " + fieldEntry.fieldId() + ") DataType: " + 
							 DataType.asString(fieldEntry.load().dataType()) + ", Value: ");

			// Display the value based on the type of data
			//
			// Note: It's possible that a field may exist but there is no data, i.e. BLANK.  This is commonly used 
			//		 within market data systems to differentiate fields that have explicit values of zero, 
			//		 empty strings, etc.
			if (Data.DataCode.BLANK == fieldEntry.code())
				System.out.println(" blank");
			else
				switch (fieldEntry.loadType())
				{
				case DataTypes.REAL :
					System.out.println(fieldEntry.real().asDouble());
					break;
				case DataTypes.DATE :
					System.out.println(String.format("%02d", fieldEntry.date().day()) + "/" + 
									   String.format("%02d", fieldEntry.date().month()) + "/" + 
									   fieldEntry.date().year());
					break;
				case DataTypes.TIME :
					System.out.println(String.format("%02d", fieldEntry.time().hour()) + ":" + 
									   String.format("%02d", fieldEntry.time().minute()) + ":" + 
									   String.format("%02d", fieldEntry.time().second()) + ":" + 
									   fieldEntry.time().millisecond());
					break;
				case DataTypes.INT :
					System.out.println(fieldEntry.intValue());
					break;
				case DataTypes.UINT :
					System.out.println(fieldEntry.uintValue());
					break;
				case DataTypes.ASCII :
					System.out.println(fieldEntry.ascii());
					break;
				case DataTypes.ENUM :
					System.out.println(fieldEntry.enumValue());
					break;
				case DataTypes.ERROR :
					System.out.println("(" + fieldEntry.error().errorCodeAsString() + ")");
					break;
				default :
					System.out.println();
					break;
				}
		}
	}
	
	// decodeAndPrint - Map
	// The Map is a complex collection commonly used in level 2 (MBP, MBO) or SymbolList data responses.  
	// Each map entry will include only container types, such as a FieldList which we utilize within our tutorials.
	private void decodeAndPrint(Map map)
	{
		// The Map that is used to package level 2 data typically contains a SUMMARY section which outlines 
		// general header information about the collection.  The SUMMARY uses the FieldList container.		
		if (DataTypes.FIELD_LIST == map.summaryData().dataType())
		{
			System.out.println("  Map Summary data:");
			
			// Simply use the existing FieldList decoding method
			decodeAndPrint(map.summaryData().fieldList());

			System.out.println();
		}

		// The main body of our collection is a map of nodes containing an action and the data.
		for (MapEntry mapEntry : map)
		{
			// The action associated with the code  (ADD, UPDATE, DELETE)
			System.out.println("  Action: " + mapEntry.mapActionAsString());

			// The data value of the node
			if (DataTypes.FIELD_LIST == mapEntry.loadType())
			{
				System.out.println("  Entry data:");
				
				// Simply use the existing FieldList decoding method
				decodeAndPrint(mapEntry.fieldList());
				
				System.out.println();
			}
		}
	}	

	// run
	// Connect to our provider, request for data and run the application for a short time to capture the realtime data.
	private void run()
	{
		try
		{
			// The consumer configuration class allows the customization of the consumer (OmmConsumer) interface, i.e.
			// name of the server or IP, port, connection type, login username, etc.
			OmmConsumerConfig config = EmaFactory.createOmmConsumerConfig();
			
			// Create an instance of our consumer in preparation for communication.
			// When instructing the consumer to communicate with a Provider, we provide the following 
			// connection details.  The connection details are set within our configuration (OmmConsumerConfig).
			//
			// Note: 	After creating our consumer, by default, EMA will launch a background thread to manage 
			//			communication and message dispatching.  Within EMA, this is controlled by the 
			//			OperationModel available within the OmmConsumerConfig interface.  Refer to the 
			//			documentation for more details.
			//
			//			For example, EMA sets the following model by default:
			//				config.operationModel(OmmConsumerConfig.OperationModel.API_DISPATCH);			
			consumer = EmaFactory.createOmmConsumer(
				config.host("elektron:14002")
					  .username("user")
			);
			
			// Define what data we want and register it with our consumer
			//  
			// When registering, we also need to specify where we want to capture all the events generated by 
			// this request.  
			OmmConsumerClient eventHandler = this;
			
			consumer.registerClient(
				  EmaFactory.createReqMsg()
								.domainType(EmaRdm.MMT_MARKET_BY_PRICE)
								.serviceName("ELEKTRON_AD")
								.name("BB.TO"), 
				  eventHandler
			);

			// Because we are using the default operation model: API_DISPATCH where EMA manages the dispatching of
			// events within a background thread, we must block and wait on our application thread for a short 
			// period to capture our market data events.
			Thread.sleep(30000);
		} 
		catch (InterruptedException | OmmException excp)
		{
			System.out.println("Exception thrown: " + excp.getMessage());
		}
		finally
		{
			// Cleanup resources before we return
			if (consumer != null) 
			{
				// Important we uninitialize our consumer to properly clean up, unregister, disconnect and stop 
				// the background thread managing event dispatching.				
				consumer.uninitialize();
				consumer = null;
			}
		}
	}

	//*************************************************************************************************
	// main
	// Application entry point to manage the life of the consumer.
	//
	//*************************************************************************************************
	public static void main(String[] args)
    {
		// Main interface to manage all consumer communication to our Provider
        basicConsumer basicConsumer = new basicConsumer();
		
		// Run the application for short time to manage communication to our Provider
		basicConsumer.run();
		
		// Done processing
		System.out.print("Processing complete");		
    }	
}
