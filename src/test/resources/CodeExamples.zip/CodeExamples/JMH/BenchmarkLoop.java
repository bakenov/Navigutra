package com.anz.axle.adapters.ndf2trep.enrichment.margin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.DoubleUnaryOperator;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.Warmup;
import org.openjdk.jmh.infra.Blackhole;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.axle.adapters.ndf2trep.utils.MathUtils;
import com.anz.markets.efx.ngaro.api.Venue;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Benchmark)
@Fork(value = 2, jvmArgs = {"-Xms2G", "-Xmx2G"})
@Warmup(iterations = 10)
@Measurement(iterations = 10)
public class BenchmarkLoop {

    public static class InputData {
        private final String instrument;
        private final Venue market;
        private final double bid;
        private final double ask;
        private final int decimalPlaces;

        InputData(String instrument, Venue market, double bid) {
            this.instrument = instrument;
            this.market = market;
            this.decimalPlaces = getDecimalPlaces(instrument);
            this.bid = 1. + roundBid(bid);
            int pips = PIP_TABLE.get(instrument);
            this.ask = this.bid + 1. / pips;
        }

        double roundBid(final double price) {
            return MathUtils.floorN(price, decimalPlaces);
        }

        public String toString() {
            return instrument + ":" + market + ":" + bid + ":" + ask;
        }
    }

    private static Random random = new Random();
    private static final List<String> INSTRUMENTS = new ArrayList<>();
    private static final List<Venue> VENUES = new ArrayList<>();
    private static final Map<String, Integer> PIP_TABLE = new HashMap<>();

    private static final String SERVICE_NAME = "AXLE_DEV";

    static {
        INSTRUMENTS.add("AUDCAD");
        INSTRUMENTS.add("AUDEUR");
        INSTRUMENTS.add("AUDGBP");
        INSTRUMENTS.add("AUDNZD");
        INSTRUMENTS.add("AUDIDR");
        INSTRUMENTS.add("AUDJPY");
        INSTRUMENTS.add("AUDUSD");

        VENUES.add(Venue.valueOf("WSP_A"));
        VENUES.add(Venue.valueOf("WSP_U"));
        VENUES.add(Venue.valueOf("WSP_Z"));

        PIP_TABLE.put("AUDCAD", 10000);
        PIP_TABLE.put("AUDEUR", 10000);
        PIP_TABLE.put("AUDGBP", 10000);
        PIP_TABLE.put("AUDNZD", 10000);
        PIP_TABLE.put("AUDIDR", 10);
        PIP_TABLE.put("AUDJPY", 100);
        PIP_TABLE.put("AUDNOK", 10000);
        PIP_TABLE.put("AUDUSD", 10000);
    }

    private static String getInstrument() {
        return INSTRUMENTS.get(random.nextInt(INSTRUMENTS.size()));
    }

    private static Venue getVenue() {
        return VENUES.get(random.nextInt(VENUES.size()));
    }

    private static int getDecimalPlaces(String instrument) {
        int decNumber = 0;
        int pips = PIP_TABLE.get(instrument);
        switch (pips) {
            case 10 :
                decNumber = 1;
                break;
            case 100 :
                decNumber = 2;
                break;
            case 1000 :
                decNumber = 3;
                break;
            case 10000 :
                decNumber = 4;
                break;
            default :
        }
        return decNumber;
    }

    private static String getMarginConfig(String instrument) {
        int decNumber = getDecimalPlaces(instrument);
        if (random.nextBoolean())
            return "PERC,BID,-,0.009,ASK,+,0.008," + decNumber;
        return "PIPS ,BID,-,1, ask ,+,1," + decNumber;
    }

    public static void main(String[] args) throws RunnerException {
        Options opt = new OptionsBuilder()
                .include(BenchmarkLoop.class.getSimpleName())
                .forks(1)
                .build();
        new Runner(opt).run();
    }

    private int N = 100000;
    private MarginServiceImpl marginService;
    private Map<String, Map<String, List<String>>> marginConfigMap;
    private List<InputData> inputs;

    @Setup
    public void setup() {
        inputs = buildInputData();

        final Map<String, Set<String>> symbolVenuesFXSPOT = new HashMap<>();
        INSTRUMENTS.forEach((s) -> VENUES.forEach((v) -> symbolVenuesFXSPOT.computeIfAbsent(s, (k) -> new HashSet<>()).add(v.name())));


        final Map<String, Map<String, Set<String>>> instrumentRics = new HashMap<>();
        instrumentRics.put("EBS", new HashMap<>());
        instrumentRics.get("EBS").put("USDCNS", new HashSet<>());

        final Map<String, String> publishSourceId = new HashMap<>();
        publishSourceId.put("EBS", "AXLE_DEV");
        publishSourceId.put("WSP_A", "SPDEE");
        publishSourceId.put("WSP_Z", "AXLE_DEV");

        final Map<String, Set<String>> venueServiceNamesMap = new HashMap<>();
        VENUES.forEach((v) -> venueServiceNamesMap.computeIfAbsent(v.name(), (k) -> new HashSet<>()).add(SERVICE_NAME));

        final Map<String, String> serviceNamePublishSourceId = new HashMap<>();
        serviceNamePublishSourceId.put(SERVICE_NAME, SERVICE_NAME);

        RicRepository ricRepository = new RicRepository(symbolVenuesFXSPOT,
                instrumentRics,
                new HashMap<>(),
                serviceNamePublishSourceId,
                venueServiceNamesMap,
                SERVICE_NAME);

        marginConfigMap = new HashMap<>();
        INSTRUMENTS.forEach((s) -> addData(s, SERVICE_NAME, getMarginConfig(s)));

        marginService = new MarginServiceImpl(marginConfigMap, PIP_TABLE, ricRepository);
    }

    private List<InputData> buildInputData() {
        List<InputData> inputs = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            inputs.add(new InputData(getInstrument(), getVenue(), random.nextDouble()));
        }
        return inputs;
    }

    private void addData(String instrument, String source, String params) {
        Map<String, List<String>> map = marginConfigMap.computeIfAbsent(instrument, (k) -> new HashMap<>());
        map.put(source, new ArrayList<>(Arrays.asList(params.split(","))));
    }

    @Benchmark
    public void addMargin(Blackhole bh) {
        for (InputData id : inputs) {
            DoubleUnaryOperator op = marginService.getBidMarginOperator(id.instrument, id.market);
            op.applyAsDouble(id.bid);
            op = marginService.getOfferMarginOperator(id.instrument, id.market);
            op.applyAsDouble(id.ask);
        }
        bh.consume(true);
    }
}
