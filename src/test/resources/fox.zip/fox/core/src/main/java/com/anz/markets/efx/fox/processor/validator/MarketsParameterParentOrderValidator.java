package com.anz.markets.efx.fox.processor.validator;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class MarketsParameterParentOrderValidator implements ParentOrderValidator {
    private final InstrumentRepository instrumentRepository;
    private final ErrorHandler errorHandler;
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> parameterCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> parameterValueCache = new ByteValueCache<>(AsciiString::toString);
    private final Map<String, List<Venue>> valueToVenueListCache = new HashMap<>();


    public MarketsParameterParentOrderValidator(final ErrorHandler handler, final InstrumentRepository instrumentRepository) {
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
        this.errorHandler = Objects.requireNonNull(handler);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {

        final long instrumentId = InstrumentKey.instrumentId(parentOrderDecoder.body().symbol().decodeAndCache(symbolCache),
                parentOrderDecoder.body().securityType(),
                parentOrderDecoder.body().settlType());
        final Instrument instrument = instrumentRepository.lookup(instrumentId);
        if (instrument == null) {
            errorHandler.onError(OrderTextMessage.UNKNOWN_INSTRUMENT.getText(), parentOrderDecoder, commandContext);
            return false;
        }

        for(NewOrderSingleDecoder.StrategyParameter strategyParameter : parentOrderDecoder.strategyParameters()) {
            final String name = strategyParameter.strategyParameterName().decodeAndCache(parameterCache);
            final String value = strategyParameter.strategyParameterValue().decodeAndCache(parameterValueCache);

            if ("Markets".equals(name)) {
                final List<Venue> markets = computeMarkets(value);
                for (int i = 0; i < markets.size(); i++) {
                    final Venue venueId = markets.get(i);
                    final VenueInstrument venueInstrument = instrument.venueInstrument(venueId);
                    if (venueInstrument != null &&
                            venueInstrument.enabled() &&
                            venueInstrument.venue().enabled() &&
                            venueInstrument.venue().online() &&
                            venueInstrument.instrument().enabled()) {
                        return true;
                    }
                }
                errorHandler.onError(OrderTextMessage.NO_ENABLED_VENUES.getText(), parentOrderDecoder, commandContext);
                return false;
            }
        }
        return true;
    }

    private List<Venue> computeMarkets(final String marketsString) {
        if (marketsString != null && !marketsString.isEmpty()) {
            return valueToVenueListCache.computeIfAbsent(marketsString, val -> Arrays.stream(val.split(".*,.*")).map(Venue::valueOf).collect(Collectors.toList()));
        }
        return Collections.EMPTY_LIST;
    }

}
