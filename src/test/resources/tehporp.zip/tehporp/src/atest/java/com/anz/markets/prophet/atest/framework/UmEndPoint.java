package com.anz.markets.prophet.atest.framework;

import java.io.Closeable;
import java.util.LinkedList;
import java.util.List;

import com.anz.markets.efx.ngaro.api.Tenor;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;

public abstract class UmEndPoint implements Closeable {
    public static int totalOpenPublications = 0;
    public static int totalOpenSubscriptions = 0;

    protected LinkedList<Output> umBuffer = new LinkedList<>();

    public void openSubscriptions(final Market market, final Instrument instrument) {
        throw new NotImplementedException("Cannot open subscriptions for an end point that is not a sink");
    }

    public abstract void consumeIndexConfigurationData(IndexedConfigurationData indexedConfigurationData);

    public <T> void pushToUm(final T object, final SecurityType securityType, final Tenor tenor) {
        throw new NotImplementedException("Cannot push to an end point that is not a source");
    }

    public List<Output> getMessageQueue() {
        return umBuffer;
    }

    protected class PreTopic {
        private final Market market;
        private final Instrument instrument;
        private final String publisherSuffix;
        private final SecurityType securityType;
        private final boolean isDeal;
        private Topic topic;

        private final MessageHandler messageHandler;

        public PreTopic(final SecurityType securityType, final Market market, final Instrument instrument, final String publisherSuffix) {
            this.securityType = securityType;
            this.market = market;
            this.instrument = instrument;
            this.publisherSuffix = publisherSuffix;
            this.messageHandler = null;
            this.isDeal = false;
        }

        public PreTopic(final SecurityType securityType, final Market market, final Instrument instrument, final String publisherSuffix,
                        final MessageHandler messageHandler) {
            this.securityType = securityType;
            this.market = market;
            this.instrument = instrument;
            this.publisherSuffix = publisherSuffix;
            this.messageHandler = messageHandler;
            this.isDeal = false;
        }

        public PreTopic(final String dealOrigin, final String publisherSuffix) {
            this.securityType = null;
            this.market = null;
            this.instrument = null;
            this.messageHandler = null;
            this.publisherSuffix = publisherSuffix;
            this.isDeal = true;
            this.topic = DefaultTopic.create(dealOrigin + "_" + publisherSuffix);
        }

        public boolean isDeal() {
            return isDeal;
        }

        public SecurityType getSecurityType() {
            return securityType;
        }

        public Market getMarket() {
            return market;
        }

        public Instrument getInstrument() {
            return instrument;
        }

        public MessageHandler getMessageHandler() {
            return messageHandler;
        }

        public Topic sinkTopicOf() {
            if (topic == null) {
                topic = DefaultTopic.create(securityType.name() + "_" + market.getExternalCode() + "_" + instrument.toSpot().name() + "_" + publisherSuffix);
            }
            return topic;
        }

        public Topic sourceTopicOf() {
            if (topic == null) {
                topic = DefaultTopic.create(securityType.name() + "_" + market.getExternalCode() + "_" + instrument.getExternalCode() + "_" + publisherSuffix);
            }
            return topic;
        }
    }

    protected static class UmEndPointStatusHandler implements EndPointStatusHandler {
        public static UmEndPointStatusHandler INSTANCE = new UmEndPointStatusHandler();
        private static final Logger LOGGER = LoggerFactory.getLogger(UmEndPointStatusHandler.class);
        @Override
        public void onStatus(final EndPointStatusHandler.Event event, final Topic topic, final Object status) {
            switch (event) {
                case INFO:
                    LOGGER.debug("Status: event=INFO, topic={}, status={}", topic, status);
                    break;
                case CLOSE:
                    LOGGER.info("Status: event=CLOSE, topic={}, status={}", topic, status);
                    break;
                case NOTIFICATION:
                    LOGGER.warn("Status: event=NOTIFICATION, topic={}, status={}", topic, status);
                    break;
                case EXCEPTION:
                    LOGGER.error("Status: event=EXCEPTION, topic={}, status={}", topic, status);
                    break;
                default:
                    LOGGER.error("Unknown Status: event={}, topic={}, status={}", event, topic, status);
                    break;
            }
        }
    }
}
