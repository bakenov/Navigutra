package com.anz.markets.efx.ngaro.codec;

import java.io.IOException;
import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.Bytes;
import com.anz.markets.efx.ngaro.core.LongCodec;

public final class SimpleStringDecoder implements StringDecoder {

    private final Supplier<? extends String> getter;

    public SimpleStringDecoder(final Supplier<? extends String> getter) {
        this.getter = Objects.requireNonNull(getter);
    }

    public static final SimpleStringDecoder forString(final String s) {
        return forSupplier(() -> s);
    }

    public static final SimpleStringDecoder forCharSequence(final CharSequence s) {
        return forString(s == null ? null : s.toString());
    }

    public static final SimpleStringDecoder forSupplier(final Supplier<? extends String> getter) {
        return new SimpleStringDecoder(getter);
    }

    @Override
    public String decodeStringOrNull() {
        final String s = getter.get();
        return s == null || s.isEmpty() ? null : s;
    }

    @Override
    public <T> T decodeAndCache(final ByteValueCache<T> cache) {
        final String s = getter.get();
        return s == null || s.isEmpty() ? null : cache.lookupOrCache(s, ByteReader.CHAR_SEQUENCE, s.length());
    }

    @Override
    public <A extends Appendable> A decodeTo(final A target, final int maxTargetLength) {
        final String s = getter.get();
        if (s != null) {
            try {
                target.append(s.length() <= maxTargetLength ? s : s.substring(0, maxTargetLength));
            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }
        return target;
    }

    @Override
    public <T> int decodeTo(final T target, final ByteWriter<? super T> writer, final int targetOffset, final int maxTargetLength) {
        final String s = getter.get();
        if (s != null) {
            final int copyLength = Math.min(s.length(), maxTargetLength);
            Bytes.copy(s, ByteReader.CHAR_SEQUENCE, 0, target, writer, targetOffset, copyLength);
            return copyLength;
        }
        return 0;
    }

    @Override
    public long decodeLong(final long defaultValue) {
        final String s = getter.get();
        if (s == null || s.isEmpty()) {
            return defaultValue;
        }
        return LongCodec.decodeSigned(s, ByteReader.CHAR_SEQUENCE, s.length(), 10);
    }
}
