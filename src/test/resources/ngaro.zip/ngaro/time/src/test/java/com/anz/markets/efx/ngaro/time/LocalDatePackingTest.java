package com.anz.markets.efx.ngaro.time;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class LocalDatePackingTest {

    private final LocalDatePacking packing;
    private final LocalDate localDate;
    private final int packed;

    public LocalDatePackingTest(final LocalDatePacking packing, final LocalDate localDate, final int packed) {
        this.packing = Objects.requireNonNull(packing);
        this.localDate = Objects.requireNonNull(localDate);
        this.packed = packed;
    }

    @Parameterized.Parameters(name = "{index}: packing={0} value={1}")
    public static List<Object[]> data() {
        final List<Object[]> cases = new ArrayList<>();
        cases.add(new Object[] {LocalDatePacking.DECIMAL, LocalDate.of(1970, 1, 1), 19700101});
        cases.add(new Object[] {LocalDatePacking.DECIMAL, LocalDate.of(1922, 1, 1), 19220101});
        cases.add(new Object[] {LocalDatePacking.DECIMAL, LocalDate.of(1922, 5, 6), 19220506});
        cases.add(new Object[] {LocalDatePacking.DECIMAL, LocalDate.of(2016, 1, 1), 20160101});
        cases.add(new Object[] {LocalDatePacking.DECIMAL, LocalDate.of(2016, 12, 31), 20161231});
        cases.add(new Object[] {LocalDatePacking.DECIMAL, LocalDate.of(2222, 12, 31), 22221231});

        cases.add(new Object[] {LocalDatePacking.BINARY, LocalDate.of(1970, 1, 1), (1970<<9)|(1<<5)|1});
        cases.add(new Object[] {LocalDatePacking.BINARY, LocalDate.of(1922, 1, 1), (1922<<9)|(1<<5)|1});
        cases.add(new Object[] {LocalDatePacking.BINARY, LocalDate.of(1922, 5, 6), (1922<<9)|(5<<5)|6});
        cases.add(new Object[] {LocalDatePacking.BINARY, LocalDate.of(2016, 1, 1), (2016<<9)|(1<<5)|1});
        cases.add(new Object[] {LocalDatePacking.BINARY, LocalDate.of(2016, 12, 31), (2016<<9)|(12<<5)|31});
        cases.add(new Object[] {LocalDatePacking.BINARY, LocalDate.of(2222, 12, 31), (2222<<9)|(12<<5)|31});
        return cases;
    }

    @Test
    public void pack() throws Exception {
        //when
        final int packed1 = packing.pack(localDate);
        final int packed2 = packing.pack(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());

        //then
        Assert.assertEquals("pack(LocalDate) not as expected", packed, packed1);
        Assert.assertEquals("pack(year, month, day) not as expected", packed, packed2);
    }

    @Test
    public void unpack() throws Exception {
        //when
        final LocalDate decoded = packing.unpack(packed);
        final int year = packing.unpackYear(packed);
        final int month = packing.unpackMonth(packed);
        final int day = packing.unpackDay(packed);

        //then
        Assert.assertEquals("local date not as expected", localDate, decoded);
        Assert.assertEquals("year not as expected", localDate.getYear(), year);
        Assert.assertEquals("month not as expected", localDate.getMonthValue(), month);
        Assert.assertEquals("day not as expected", localDate.getDayOfMonth(), day);
    }

    @Test
    public void repack() throws Exception {
        for (final LocalDatePacking sourcePacking : LocalDatePacking.values()) {
            //given
            final int packed = sourcePacking.pack(localDate);

            //when
            final int repacked = packing.repack(packed, sourcePacking);

            //then
            Assert.assertEquals("unpack(repack(packed)) not as expected", localDate, packing.unpack(repacked));
        }
    }

    @Test
    public void packAndUnpack() throws Exception {
        //when
        final LocalDate packThenUnpack = packing.unpack(packing.pack(localDate));
        final int unpackThenPack = packing.pack(packing.unpack(packed));

        //then
        Assert.assertEquals("EXPECTED: unpack(pack(val)) = val", localDate, packThenUnpack);
        Assert.assertEquals("EXPECTED: pack(unpack(val)) = val", packed, unpackThenPack);
    }
}