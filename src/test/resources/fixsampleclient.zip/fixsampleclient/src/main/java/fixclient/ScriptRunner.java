// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.thomsonreuters.trfx.referenceclients.fixclient.util.MessageHelper;
import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionNotFound;
import quickfix.field.ApplVerID;
import quickfix.field.MsgType;
import quickfix.field.SenderSubID;
import quickfix.field.TargetSubID;

/**
 * Performs the actual script execution. It iterates through the supplied FIX
 * Message list, building and sending the outgoing messages and validating the
 * responses.
 * 
 */
public class ScriptRunner
{
    private static final int[]           HEADER_TAGS = { SenderSubID.FIELD,
            TargetSubID.FIELD,
            ApplVerID.FIELD                         };

    private final List<FIXMessage>       scriptedMessages;
    private final BlockingQueue<Message> receivedMessageQueue;
    private final SessionID              sessionID;
    private final int                    fixTimeout;
    private final IMessageFlowListener   messageFlowListener;

    /**
     * @param sessionID
     * @param scriptedMessages
     * @param receivedMessageQueue
     * @param messageFlowListener
     * @throws IOException
     */
    public ScriptRunner(final SessionID sessionID,
                        final List<FIXMessage> scriptedMessages,
                        final BlockingQueue<Message> receivedMessageQueue,
                        final IMessageFlowListener messageFlowListener) throws IOException
    {
        this.sessionID = sessionID;
        this.scriptedMessages = scriptedMessages;
        this.receivedMessageQueue = receivedMessageQueue;

        this.fixTimeout = FIXConfig.getFIXTimeout();
        this.messageFlowListener = messageFlowListener;
    }

    /**
     * Execute the script
     * 
     * @throws Exception
     */
    public void exec() throws Exception
    {
        for (final FIXMessage scriptedMessage : this.scriptedMessages)
        {
            switch (scriptedMessage.getDirection())
            {
                case SEND:
                    handleSend(scriptedMessage);
                    break;

                case RECEIVE:
                    handleReceive(scriptedMessage);
                    break;
            }
        }
    }

    private void handleSend(final FIXMessage scriptedMessage) throws SessionNotFound
    {
        this.messageFlowListener.logStatusText("Sending message: "
                + scriptedMessage);
        final Message quickFixMessage = buildFixMessage(scriptedMessage);

        Session.sendToTarget(quickFixMessage, this.sessionID);

        final QuickFixSessionMessage sentMessage = new QuickFixSessionMessage(quickFixMessage,
                this.sessionID,
                scriptedMessage.getMessageType());

        this.messageFlowListener.messageSent(sentMessage);
    }

    private void handleReceive(final FIXMessage scriptedMessage) throws InterruptedException,
            FieldNotFound,
            TimeoutException,
            IllegalArgumentException
    {
        final String expectedMessageType = scriptedMessage.getMessageType();
        this.messageFlowListener.logStatusText("Waiting for response ("
                + expectedMessageType
                + "): "
                + scriptedMessage);

        final Message receivedMessage = getNextMessage(expectedMessageType,
                this.fixTimeout);

        final QuickFixSessionMessage sessionMessage = new QuickFixSessionMessage(receivedMessage,
                this.sessionID,
                getMsgType(receivedMessage));

        this.messageFlowListener.messageReceived(sessionMessage);

        validateFixMessage(receivedMessage, scriptedMessage);
        validateGroups(scriptedMessage, receivedMessage);

        this.messageFlowListener.logStatusText("Success: Received expected response & validated against expected");
    }

    private static String getMsgType(final Message message)
    {
        try
        {
            return message.getHeader().getString(MsgType.FIELD);
        }
        catch (final FieldNotFound fnf)
        {
            throw new IllegalArgumentException(fnf);
        }
    }

    private Message getNextMessage(final String expectedMessageType,
            final int timeoutMillis) throws TimeoutException,
            InterruptedException,
            FieldNotFound
    {
        if (expectedMessageType == null
                || expectedMessageType.trim().length() == 0)
        {
            throw new IllegalArgumentException("messageType cannot be null or empty");
        }

        if (timeoutMillis <= 0)
        {
            throw new IllegalArgumentException("timeoutMillis cannot be zero or negative");
        }

        final long startTime = System.currentTimeMillis();
        long elapsed = 0;
        while (true)
        {
            if (elapsed >= timeoutMillis)
            {
                throw new TimeoutException("Timed-out after "
                        + timeoutMillis
                        + " ms waiting for expected response message ("
                        + expectedMessageType
                        + ")");
            }

            final Message receivedMessage = this.receivedMessageQueue.poll(1000,
                    TimeUnit.MILLISECONDS);

            if (receivedMessage != null)
            {
                if (getMsgType(receivedMessage).equals(expectedMessageType))
                {
                    return receivedMessage;
                }

                this.messageFlowListener.logStatusText("Discarding unexpected message: "
                        + toString(receivedMessage));
            }

            elapsed = System.currentTimeMillis() - startTime;
        }
    }

    private String toString(final Message message) throws FieldNotFound
    {
        return MessageHelper.convertToString(message, this.sessionID);

    }

    /**
     * Constructs a QuickFIX FIX Message according to the specification defined
     * for a "send" message in the XML script.
     * 
     * @param fixMessage
     * @return the constructed QuickFIX message
     */
    private Message buildFixMessage(final FIXMessage fixMessage)
    {
        final Message sendMessage = new Message();
        sendMessage.getHeader().setString(MsgType.FIELD,
                fixMessage.getMessageType());

        // set all the fields as specified in the script
        for (final FIXField field : fixMessage.getFields())
        {
            final int fieldId = Integer.parseInt(field.getId());
            final String value = field.getValue();

            if (isHeaderTag(fieldId))
            {
                sendMessage.getHeader().setString(fieldId, value);
            }
            else
            {
                sendMessage.setString(fieldId, value);
            }
        }

        // Add any repeating groups
        if (fixMessage.getRepeatingGroups() != null)
        {
            for (final FIXRepeatingGroup fixRepeatingGroup : fixMessage.getRepeatingGroups())
            {
                // A QuickFIX "Group" more-or-less corresponds to our
                // "groupItem" (see below).
                // The group tag, delimiter tag and field order are the same for
                // each "Group" in the repeating set.

                final Group sendGroup = new Group(Integer.parseInt(fixRepeatingGroup.getGroupTag()
                        .getId()),
                        Integer.parseInt(fixRepeatingGroup.getDelimiterFieldId()),
                        buildFieldOrderArray(fixRepeatingGroup));

                // Now add the fields to each "Group".
                for (final ArrayList<FIXField> groupItem : fixRepeatingGroup.getGroupItems())
                {
                    for (final FIXField field : groupItem)
                    {
                        sendGroup.setString(Integer.parseInt(field.getId()),
                                field.getValue());
                    }

                    // The QuickFIX Group Java object is re-usable - each time
                    // you set the field values and call Message.addGroup() a
                    // new "group" is added to the message.

                    sendMessage.addGroup(sendGroup);
                }
            }
        }

        return sendMessage;
    }

    /**
     * Derive the field order by looking at the order of fields in the first
     * group item.
     */
    private int[] buildFieldOrderArray(final FIXRepeatingGroup fixGroup)
    {
        final ArrayList<FIXField> firstGroupItem = fixGroup.getGroupItems()
                .iterator()
                .next();
        final int[] fieldOrder = new int[firstGroupItem.size()];

        int i = 0;
        for (final FIXField field : firstGroupItem)
        {
            fieldOrder[i++] = Integer.parseInt(field.getId());
        }

        return fieldOrder;
    }

    private void validateMsgType(final Message receivedMessage,
            final FIXMessage scriptedMessage) throws IllegalArgumentException
    {
        final String msgType = getMsgType(receivedMessage);

        if (!msgType.equals(scriptedMessage.getMessageType()))
        {
            throw new IllegalArgumentException("Unexpected message type. Expected: "
                    + scriptedMessage.getMessageType()
                    + ", Received: "
                    + msgType);
        }
    }

    /**
     * Validate the received QuickFIX message against our own representation,
     * loaded from the script, to make sure all values are as expected.
     * 
     * @param receivedMessage
     * @param scriptedMessage
     */
    private void validateFixMessage(final Message receivedMessage,
            final FIXMessage scriptedMessage) throws IllegalArgumentException
    {
        try
        {
            // Check the message type
            validateMsgType(receivedMessage, scriptedMessage);

            // Check the specified fields
            for (final FIXField field : scriptedMessage.getFields())
            {
                final String fieldValue = receivedMessage.getString(Integer.parseInt(field.getId()));

                if (!field.getValue().equals(fieldValue))
                {
                    throw new IllegalArgumentException("Unexpected value for field "
                            + field.getId()
                            + ". Expected: "
                            + field.getValue()
                            + ", Received: "
                            + fieldValue);
                }
            }
        }
        catch (final FieldNotFound fnf)
        {
            throw new IllegalArgumentException("Unable to validate FIX message: ",
                    fnf);
        }
    }

    /**
     * Validate the repeating groups in the received QuickFIX message against
     * our own representation, loaded from the script, to make sure all values
     * are as expected.
     * 
     * @param scriptedMessage
     * @param receivedMessage
     */
    private void validateGroups(final FIXMessage scriptedMessage,
            final Message receivedMessage) throws IllegalArgumentException
    {
        final ArrayList<FIXRepeatingGroup> expectedGroups = scriptedMessage.getRepeatingGroups();

        // For each repeating group...
        for (final FIXRepeatingGroup expectedGroup : expectedGroups)
        {
            // A QuickFIX "Group" more-or-less corresponds to our "groupItem".
            // Get all the QuickFIX Groups in our "repeating group".

            final List<Group> receivedGroups = receivedMessage.getGroups(Integer.parseInt(expectedGroup.getGroupTag()
                    .getId()));

            if (receivedGroups.size() != expectedGroup.getGroupItems().size())
            {
                throw new IllegalArgumentException("Repeating group "
                        + expectedGroup.getGroupTag().getId()
                        + " does not have the number of expected items, it has "
                        + receivedGroups.size()
                        + " expected = "
                        + expectedGroup.getGroupItems().size());
            }

            // Our "repeating group" contains multiple lists of fields, where
            // each list corresponds
            // to a "group item" (which in turn corresponds to a QuickFIX
            // "Group"...)

            final ArrayList<ArrayList<FIXField>> expectedGroupItems = expectedGroup.getGroupItems();

            // Now check that each field is correct for each group item/QuickFIX
            // Group
            for (int i = 0; i < expectedGroupItems.size(); i++)
            {
                final ArrayList<FIXField> expectedGroupItem = expectedGroupItems.get(i);
                final Group receivedGroup = receivedGroups.get(i);

                for (final FIXField expectedField : expectedGroupItem)
                {
                    final int expectedFieldId = Integer.parseInt(expectedField.getId());
                    final String expectedValue = expectedField.getValue();

                    String receivedValue;
                    try
                    {
                        receivedValue = receivedGroup.getString(expectedFieldId);
                        if (!expectedValue.equals(receivedValue))
                        {
                            throw new IllegalArgumentException("Field value invalid for tag "
                                    + expectedFieldId
                                    + " expected "
                                    + expectedValue
                                    + " was "
                                    + receivedValue);
                        }
                    }
                    catch (final FieldNotFound fnf)
                    {
                        throw new IllegalArgumentException("expected tag missing from message : "
                                + expectedFieldId,
                                fnf);
                    }
                }
            }
        }

    }

    /**
     * Utility method for determining whether a supplied field tag is a Header
     * tag or not.
     * 
     * @param tag
     * @return true if the tag is a header tag, false otherwise.
     */
    private boolean isHeaderTag(final int tag)
    {
        for (int i = 0; i < HEADER_TAGS.length; i++)
        {
            if (HEADER_TAGS[i] == tag)
            {
                return true;
            }
        }

        return false;
    }
}
