package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueReaderMulti;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.ReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.MutableByteArrayCharSequence;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.threads.EventHandler;
import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ChronicleReaderMultiRBTest {
    private static final int TRADE_COUNT = 5;
    private String[] basePaths;
    private ChronicleReaderMultiTest.CopyConsumer<Trade> tradeConsumer = new ChronicleReaderMultiTest.CopyConsumer<>(TradeImpl::new);
    private ExecutorService executorService;
    private ApiVersion previousApiVersion;
    private boolean previousRBEnabled;

    @Before
    public void before() throws IOException {
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = ApiVersion.CHRONICLE_QUEUE;
        previousRBEnabled = SystemProperties.CQ_RING_BUFFER_ENABLED;
        SystemProperties.CQ_RING_BUFFER_ENABLED = true;

        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("chronicle-in-%d").build();
        executorService = Executors.newSingleThreadExecutor(threadFactory);

        basePaths = new String[] { tmpFile("chronicle.in.conflated"), tmpFile("chronicle.in") };
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
        SystemProperties.CQ_RING_BUFFER_ENABLED = previousRBEnabled;
        for (String f : basePaths) {
            // delete and rb
        }
    }

    @NotNull
    private String tmpFile(final String after) throws IOException {
        return FileUtil.tmpFile(this.getClass().getSimpleName(), after);
    }

    @After
    public void after() {
        executorService.shutdown();
    }

    @Test
    public void nothingInRB() throws IOException {
        final AtomicLong eventId = new AtomicLong(1);
        final Header header = Context.context().header();
        // don't write anything to chronicle.in.conflated
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePaths[1])) {
            writeTrades(basePaths[1], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
            // wait for drainer
            Jvm.pause(50);
        }

        // after close of persister (and its queue), everything should be drained

        openCloseClean();

        checkAllThere();
    }

    @Test
    public void everythingDrainedEverythingInRB() throws IOException {
        final AtomicLong eventId = new AtomicLong(1);
        final Header header = Context.context().header();
        // don't write anything to chronicle.in.conflated
        try (ProphetPersister persister = ChronicleQueueSeekRBTest.createPersister(basePaths[1])) {
            writeTrades(basePaths[1], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
            // wait for drainer
            Jvm.pause(50);
        }

        // after close of persister (and its queue), everything should be drained

        openCloseClean();

        checkAllThere();
    }

    @Test
    public void nothingDrainedEverythingInRB() throws IOException, InterruptedException {
        final AtomicLong eventId = new AtomicLong(1);
        final Header header = Context.context().header();
        // don't write anything to chronicle.in.conflated
        final EventLoop eventLoop = new DontRunDrainerEventGroup(true);
        try (ProphetPersister persister = ChronicleQueueSeekRBTest.createPersister(basePaths[1], eventLoop)) {
            writeTrades(basePaths[1], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
            Jvm.pause(100);

            openCloseClean();

            checkAllThere();
        }
    }

    private void checkAllThere() {
        // ignore empty basePaths[0] (chronicle.in.conflated)
        int counter = 0;
        for (int i = 0; i < TRADE_COUNT; i++) {
            final Trade trade = tradeConsumer.events.get(counter);
            assertEquals(basePaths[1], trade.getOrderId().toString());
            ++counter;
        }
        for (int i = 1; i < tradeConsumer.eventIds.size(); i++) {
            assertTrue(tradeConsumer.eventIds.get(i) == 1 + tradeConsumer.eventIds.get(i - 1));
        }
    }

    private void writeTrades(final String chroniclePath,
                             final ProphetPersister persister,
                             final Runnable runnable,
                             final int count) {
        for (int i = 0; i < count; i++) {
            final TradeImpl trade = MidRateTestHelper.createTrade(Instrument.ZARJPY, OrderSide.BID, i, i);
            ((MutableByteArrayCharSequence)trade.getOrderId()).setTruncateOnOverflow(true);
            trade.setOrderId(chroniclePath);
            trade.setInceptionTimeNanos(i + 1);
            runnable.run();
            persister.sink(MessageType.TRADE).accept(trade);
        }
    }

    private void openCloseClean() throws IOException {
        startMultiReader();
    }

    private void startMultiReader() throws IOException {
        try (ProphetReader chronicleReaderMulti = createChronicleReaderMulti(basePaths)) {
            ThreadUtils.sleep(SystemProperties.CQ_RING_BUFFER_STALL_WAIT_MILLIS + 200);
        }
    }

    private ProphetReader createChronicleReaderMulti(final String[] paths) {
        final TradeReader objectReader = new TradeReader(tradeConsumer);
        final ReaderConfig config = ReaderConfigBuilder.create().withRingBuffer(RingBuffer.RING).withPauser(Pauser.millis(10)).withChronicleObjectReader(objectReader).build();
        final ProphetReader rv = ChronicleQueueReaderMulti.create(paths, config);
        executorService.execute(rv);
        return rv;
    }

    private class DontRunDrainerEventGroup extends EventGroup {
        public DontRunDrainerEventGroup(final boolean daemon) {
            super(daemon);
        }

        @Override
        public void addHandler(@NotNull final EventHandler handler) {
            if (handler.getClass().getSimpleName().equals("RingToQueueEventHandler")) {
                return;
            }
            super.addHandler(handler);
        }
    }
}
