package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.collections.Predicates;
import net.openhft.chronicle.core.threads.EventLoop;

import java.util.function.Predicate;

public class PersisterConfigBuilder {
    private boolean active = true;
    private Predicate<MessageType> messageTypePredicate = Predicates.alwaysTrue();
    private Append append = Append.ALL;
    private ActivationAware activationAware = ActivationAware.NO;
    private ChronicleHook beforeWrite = ChronicleHook.DO_NOTHING;
    private ChronicleHook afterWrite = ChronicleHook.DO_NOTHING;
    private boolean multipleWriterThreads = false;
    private RingBuffer ringBuffer = RingBuffer.NO_RING;
    private EventLoop eventLoop = null;

    public static PersisterConfigBuilder create(final PersisterConfig config) {
        return new PersisterConfigBuilder()
                .withActiveFlag(config.active())
                .withMessageTypePredicate(config.messageTypePredicate())
                .withMessageTypePredicate(config.messageTypePredicate())
                .withAppend(config.append())
                .withActivationAware(config.activationAware())
                .withBeforeWrite(config.beforeWrite())
                .withAfterWrite(config.afterWrite())
                .withRingBuffer(config.ringBuffer())
                .withEventLoop(config.eventLoop())
                .withMultipleWriterThreads(config.multipleWriterThreads());
    }

    public static PersisterConfigBuilder create() {
        return new PersisterConfigBuilder();
    }

    public PersisterConfigBuilder withActiveFlag(final boolean active) {
        this.active = active;
        return this;
    }

    public PersisterConfigBuilder withMessageTypePredicate(final Predicate<MessageType> messageTypePredicate) {
        this.messageTypePredicate = messageTypePredicate;
        return this;
    }

    public PersisterConfigBuilder withAppend(final Append append) {
        this.append = append;
        return this;
    }

    public PersisterConfigBuilder withActivationAware(final ActivationAware activationAware) {
        this.activationAware = activationAware;
        return this;
    }

    public PersisterConfigBuilder withBeforeWrite(final ChronicleHook beforeWrite) {
        this.beforeWrite = beforeWrite;
        return this;
    }

    public PersisterConfigBuilder withAfterWrite(final ChronicleHook afterWrite) {
        this.afterWrite = afterWrite;
        return this;
    }

    public PersisterConfigBuilder withMultipleWriterThreads(final boolean multipleWriterThreads) {
        this.multipleWriterThreads = multipleWriterThreads;
        return this;
    }

    public PersisterConfigBuilder withRingBuffer(final RingBuffer ringBuffer) {
        this.ringBuffer = ringBuffer;
        return this;
    }

    public PersisterConfigBuilder withEventLoop(final EventLoop eventLoop) {
        this.eventLoop = eventLoop;
        return this;
    }

    public PersisterConfig build() {
        return new PersisterConfigImpl(active, messageTypePredicate, append, activationAware, beforeWrite, afterWrite, multipleWriterThreads, ringBuffer, eventLoop);
    }

    public static class PersisterConfigImpl implements PersisterConfig {

        private final boolean active;
        private final Predicate<MessageType> messageTypePredicate;
        private final Append append;
        private final ActivationAware activationAware;
        private final ChronicleHook beforeWrite;
        private final ChronicleHook afterWrite;
        private final boolean multipleWriterThreads;
        private final RingBuffer ringBuffer;
        private final EventLoop eventLoop;

        PersisterConfigImpl(final boolean active, final Predicate<MessageType> messageTypePredicate, final Append append,
                            final ActivationAware activationAware, final ChronicleHook beforeWrite,
                            final ChronicleHook afterWrite, final boolean multipleWriterThreads, final RingBuffer ringBuffer, final EventLoop eventLoop) {
            this.active = active;
            this.messageTypePredicate = messageTypePredicate;
            this.append = append;
            this.activationAware = activationAware;
            this.beforeWrite = beforeWrite;
            this.afterWrite = afterWrite;
            this.multipleWriterThreads = multipleWriterThreads;
            this.ringBuffer = ringBuffer;
            this.eventLoop = eventLoop;
        }

        @Override
        public Predicate<MessageType> messageTypePredicate() {
            return messageTypePredicate;
        }

        @Override
        public Append append() {
            return append;
        }

        @Override
        public ActivationAware activationAware() {
            return activationAware;
        }

        @Override
        public ChronicleHook beforeWrite() {
            return beforeWrite;
        }

        @Override
        public ChronicleHook afterWrite() {
            return afterWrite;
        }

        @Override
        public RingBuffer ringBuffer() {
            return ringBuffer;
        }

        @Override
        public EventLoop eventLoop() {
            return eventLoop;
        }

        @Override
        public boolean active() {
            return active;
        }

        @Override
        public boolean multipleWriterThreads() {
            return multipleWriterThreads;
        }

        @Override
        public String toString() {
            return "PersisterConfigImpl{" +
                    "active=" + active +
                    ", messageTypePredicate=" + messageTypePredicate +
                    ", append=" + append +
                    ", activationAware=" + activationAware +
                    ", beforeWrite=" + beforeWrite +
                    ", afterWrite=" + afterWrite +
                    ", multipleWriterThreads=" + multipleWriterThreads +
                    ", ringBuffer=" + ringBuffer +
                    '}';
        }
    }
}