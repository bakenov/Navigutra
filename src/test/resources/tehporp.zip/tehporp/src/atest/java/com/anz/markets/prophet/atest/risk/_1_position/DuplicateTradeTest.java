package com.anz.markets.prophet.atest.risk._1_position;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.positionrisk.Positions;
import org.junit.Test;

import org.apache.logging.log4j.Level;


public class DuplicateTradeTest extends BaseAcceptanceSpecification {

    private static final String DUPLICATE_TRADE_RECEIVED_REGEX = ".*Duplicate trade received.*";

    @Test
    @DisplayName("AXPROPHET-142 Reject trades with duplicate trade IDs")
    public void when_receive_duplicate_trade_id_should_reject() {

        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.65755, 0.0004));
        }
        when:
        {
            final Trade trade1 = tdd.client_trade_001(1_000_000, 0.6500);
            prophet.receive(trade1);
            prophet.clearOutputBuffer();
            prophet.receive(trade1);
        }
        then:
        {
            prophet.expect(Level.WARN, matches(DUPLICATE_TRADE_RECEIVED_REGEX));
        }
        and:
        {
            prophet.notExpect(Positions.class);
        }
    }

    @Test
    @DisplayName("AXPROPHET-572 receive client deals over UM")
    public void receive_duplicate_trade_via_um() throws Exception{
        precondition:
        {
            ConfigurationDataDefault config = tdd.configuration_pricing_base();
            prophet.startUmProbes(config, true);
            prophet.receive(config);

            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.65755, 0.0004));
        }
        when:
        {
            Trade trade = tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.6500);
            prophet.receiveFromUm(trade);
            prophet.clearOutputBuffer();
            prophet.receive(trade);
        }
        then:
        // Duplicate trade received: SPDEE:Order-0@1000000ms
        {
            prophet.expect(Level.WARN, matches(DUPLICATE_TRADE_RECEIVED_REGEX));
            prophet.notExpect(Positions.class);
        }
    }

    @Test
    @DisplayName("AXPROPHET-572 receive client deals over UM")
    public void receive_duplicate_trade_via_m3axle_and_um() throws Exception{
        precondition:
        {
            ConfigurationDataDefault config = tdd.configuration_pricing_base();
            prophet.startUmProbes(config, true);
            prophet.receive(config);

            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.65755, 0.0004));
        }
        when:
        {
            final Trade trade1 = tdd.client_trade_001(1_000_000, 0.6500);
            prophet.receive(trade1);
            prophet.clearOutputBuffer();
            prophet.receiveFromUm(tdd.client_trade_002(Instrument.AUDUSD, 1_000_000, 0.6500, trade1.getOrderId()));
        }
        then:
        // Duplicate trade received on fast path: SPDEE:Order-0@1000000ms
        {
            prophet.expect(Level.WARN, matches(DUPLICATE_TRADE_RECEIVED_REGEX));
            prophet.notExpect(Positions.class);
        }
    }
}