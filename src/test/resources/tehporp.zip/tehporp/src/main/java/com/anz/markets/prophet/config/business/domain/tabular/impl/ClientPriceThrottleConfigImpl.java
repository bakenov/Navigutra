package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.BaseTermsToInstrumentMarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
public class ClientPriceThrottleConfigImpl extends BaseTermsToInstrumentMarketConfigImpl implements ClientPriceThrottleConfig, ProphetMarshallable {

    private double minimumPriceDeltaFractionOfPreviousSpread;
    private double overrideMinimumPriceDeltaFractionOfMid;
    private double minimumPriceDeltaFractionOfSpread;

    private long noActivityHeartbeatFrequencyMs;
    private long limit;

    private long timePeriod; // milliseconds
    private long overrideLimit;
    private long overrideTimePeriod;
    private long startStopTimePeriodMS;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public ClientPriceThrottleConfigImpl() {
    }

    public ClientPriceThrottleConfigImpl(final Market market, final Currency baseCurrency, final Currency termsCurrency) {
        super(market, baseCurrency, termsCurrency);
    }

    @Override
    public double getMinimumPriceDeltaFractionOfPreviousSpread() {
        return minimumPriceDeltaFractionOfPreviousSpread;
    }

    @Override
    public double getOverrideMinimumPriceDeltaFractionOfMid() {
        return overrideMinimumPriceDeltaFractionOfMid;
    }

    @Override
    public double getMinimumPriceDeltaFractionOfSpread() {
        return minimumPriceDeltaFractionOfSpread;
    }

    @Override
    public long getNoActivityHeartbeatFrequencyMs() {
        return noActivityHeartbeatFrequencyMs;
    }

    @Override
    public long getLimit() {
        return limit;
    }

    @Override
    public long getTimePeriod() {
        return timePeriod;
    }

    @Override
    public long getOverrideLimit() {
        return overrideLimit;
    }

    @Override
    public long getOverrideTimePeriod() {
        return overrideTimePeriod;
    }

    @Override
    public long getStartStopTimePeriodMS() {
        return startStopTimePeriodMS;
    }

    public ClientPriceThrottleConfigImpl setTimePeriod(final long timePeriodMS) {
        this.timePeriod = timePeriodMS;
        return this;
    }

    public ClientPriceThrottleConfigImpl setLimit(final long limit) {
        this.limit = limit;
        return this;
    }

    public ClientPriceThrottleConfigImpl setNoActivityHeartbeatFrequencyMs(final long noActivityHeartbeatFrequencyMs) {
        this.noActivityHeartbeatFrequencyMs = noActivityHeartbeatFrequencyMs;
        return this;
    }

    public ClientPriceThrottleConfigImpl setOverrideLimit(final long overrideLimit) {
        this.overrideLimit = overrideLimit;
        return this;
    }

    public ClientPriceThrottleConfigImpl setOverrideTimePeriod(final long overrideTimePeriod) {
        this.overrideTimePeriod = overrideTimePeriod;
        return this;
    }

    public ClientPriceThrottleConfigImpl setStartStopTimePeriodMS(final long startStopTimePeriodMS) {
        this.startStopTimePeriodMS = startStopTimePeriodMS;
        return this;
    }

    public ClientPriceThrottleConfigImpl setMinimumPriceDeltaFractionOfPreviousSpread(
            final double minimumPriceDeltaFractionOfPreviousSpread) {
        this.minimumPriceDeltaFractionOfPreviousSpread = minimumPriceDeltaFractionOfPreviousSpread;
        return this;
    }

    public ClientPriceThrottleConfigImpl setOverrideMinimumPriceDeltaFractionOfMid(
            final double overrideMinimumPriceDeltaFractionOfMid) {
        this.overrideMinimumPriceDeltaFractionOfMid = overrideMinimumPriceDeltaFractionOfMid;
        return this;
    }

    public ClientPriceThrottleConfigImpl setMinimumPriceDeltaFractionOfSpread(
            final double minimumPriceDeltaFractionOfSpread) {
        this.minimumPriceDeltaFractionOfSpread = minimumPriceDeltaFractionOfSpread;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        Context.context().header().before(MessageVersion.VERSION_0_21, () -> FieldReflectionBytesMarshallable.INSTANCE.read(in, this));
        Context.context().header().since(MessageVersion.VERSION_0_21, () -> {
            setMarket(Market.valueOf(in.readByte()));
            Context.context().header().before(MessageVersion.VERSION_0_61, () -> {
                final Instrument instrument = Instrument.valueOf(in.readByte());
                setBaseCurrency(instrument.getDealt());
                setTermsCurrency(instrument.getTerms());
            });
            this.overrideMinimumPriceDeltaFractionOfMid = in.readDouble();
            this.minimumPriceDeltaFractionOfSpread = in.readDouble();
            this.noActivityHeartbeatFrequencyMs = in.readLong();
            this.limit = in.readLong();
            this.timePeriod = in.readLong();
            this.overrideLimit = in.readLong();
            this.overrideTimePeriod = in.readLong();
        });
        Context.context().header().since(MessageVersion.VERSION_0_22, () -> this.minimumPriceDeltaFractionOfPreviousSpread = in.readDouble());
        Context.context().header().since(MessageVersion.VERSION_0_61, () -> setBaseCurrency(Currency.valueOf(in.readByte())));
        Context.context().header().since(MessageVersion.VERSION_0_61, () -> setTermsCurrency(Currency.valueOf(in.readByte())));
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(getMarket().getValue());
        out.writeDouble(this.overrideMinimumPriceDeltaFractionOfMid);
        out.writeDouble(this.minimumPriceDeltaFractionOfSpread);
        out.writeLong(this.noActivityHeartbeatFrequencyMs);
        out.writeLong(this.limit);
        out.writeLong(this.timePeriod);
        out.writeLong(this.overrideLimit);
        out.writeLong(this.overrideTimePeriod);
        out.writeDouble(this.minimumPriceDeltaFractionOfPreviousSpread);
        out.writeByte(getBaseCurrency().getValue());
        out.writeByte(getTermsCurrency().getValue());
    }

    @Override
    public String toString() {
        return "ClientPriceThrottleConfigImpl{market=" + getMarket() +
                ", baseCurrency=" + getBaseCurrency() +
                ", termsCurrency=" + getTermsCurrency() +
                ", minimumPriceDeltaFractionOfPreviousSpread=" + minimumPriceDeltaFractionOfPreviousSpread +
                ", overrideMinimumPriceDeltaFractionOfMid=" + overrideMinimumPriceDeltaFractionOfMid +
                ", minimumPriceDeltaFractionOfSpread=" + minimumPriceDeltaFractionOfSpread +
                ", noActivityHeartbeatFrequencyMs=" + noActivityHeartbeatFrequencyMs +
                ", limit=" + limit +
                ", timePeriod=" + timePeriod +
                ", overrideLimit=" + overrideLimit +
                ", overrideTimePeriod=" + overrideTimePeriod +
                '}';
    }
}
