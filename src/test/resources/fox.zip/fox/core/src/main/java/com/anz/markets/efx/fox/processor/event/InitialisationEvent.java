package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.agrona.collections.MutableLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.sbe.InitialisationSbeDecoder;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.processor.state.health.Health;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class InitialisationEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(InitialisationEvent.class);

    private final InitialisationSbeDecoder initialisationDecoder = new InitialisationSbeDecoder();
    private final EventContext eventContext;
    private final MutableLong idGeneratorOffset;
    private final Health health;

    private final StringBuilder stringBuilder = new StringBuilder();

    public InitialisationEvent(final EventContext eventContext, final MutableLong idGeneratorOffset, final Health health) {
        this.eventContext = Objects.requireNonNull(eventContext);
        this.idGeneratorOffset = Objects.requireNonNull(idGeneratorOffset);
        this.health = Objects.requireNonNull(health);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!initialisationDecoder.wrap(message)) return false;
        logMessage();

        if(initialisationDecoder.body().initStage() == InitStage.BEGIN) {
            final long offset = eventContext.precisionClock().micros();
            idGeneratorOffset.set(offset);
            LOGGER.info("Initialised ID Generator Offset: {}", offset);
        }
        if(initialisationDecoder.body().initStage() == InitStage.END) {
            health.scheduleHeartbeat();
        }
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        initialisationDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying initialisation: {}", stringBuilder);
    }
}
