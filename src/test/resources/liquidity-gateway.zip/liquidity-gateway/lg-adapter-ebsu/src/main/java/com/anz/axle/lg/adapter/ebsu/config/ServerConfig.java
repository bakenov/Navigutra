package com.anz.axle.lg.adapter.ebsu.config;

import com.anz.axle.lg.adapter.chroniclefix.ProcessNextEventHandler;
import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.lg.adapter.ebsu.RecordArrivalProbes;
import com.anz.axle.lg.adapter.ebsu.increment.IncrementMessageNotifier;
import com.anz.axle.lg.adapter.ebsu.preview.PreviewMessageNotifier;
import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import net.openhft.chronicle.core.threads.EventHandler;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StringUtils;
import software.chronicle.ebs.adapter.Orchestrator;
import software.chronicle.ebs.cfg.EbsEngineCfg;
import software.chronicle.ebs.util.MarshallableUtil;
import software.chronicle.ebs.util.StreamType;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.concurrent.ScheduledExecutorService;

@Configuration
@Import({
        CommonConfig.class,
        PricingConfig.class,
        LastMarketTradeConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
})
public class ServerConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(ServerConfig.class);

    @Bean
    public EbsEngineCfg engineCfg(@Qualifier("applicationProperties") final Properties applicationProperties,
                                  final PrecisionClock precisionClock,
                                  final IncrementMessageNotifier incrementMessageNotifier,
                                  final PreviewMessageNotifier previewMessageNotifier,
                                  @Value("${ebsu.incr.probes:true}") final boolean probes,
                                  @Value("${ebsu.preview.log.path}") final String logPathPreview,
                                  @Value("${ebsu.incr.log.path}") final String logPathIncr,
                                  @Value("${log.queue.RollCycle}") final RollCycles rollCycle) throws Exception {

        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/ebsu-engine.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();

        MarshallableUtil.addAliases();
        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final EbsEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);

        if (! StringUtils.isEmpty(logPathPreview)) {
            engineCfg.preview().consumerItch(new BytesQueueConsumer2(logPathPreview, StreamType.PREVIEW, rollCycle));
        }
        if (! StringUtils.isEmpty(logPathIncr)) {
            engineCfg.increment().consumerItch(new BytesQueueConsumer2(logPathIncr, StreamType.INCRMNT, rollCycle));
        }

        if (probes) {
            engineCfg.increment().probesItch(new RecordArrivalProbes(precisionClock));
        }

        engineCfg.increment().messageNotifierItch(incrementMessageNotifier);
        engineCfg.preview().messageNotifierItch(previewMessageNotifier);

        return engineCfg;
    }

    @Bean
    public EventGroup eventLoopPreview(@Value("${pauser.busy:true}") final boolean busy,
                                       @Value("${pauser.binding:false}") final boolean binding,
                                       @Value("${pauser.bindcpu:-1}") final int bindCpu) {

        return new EventGroup(true, busy ? Pauser.busy() : Pauser.balanced(), binding, bindCpu, -1, "ebsu_prv_");
    }

    @Bean
    public EventGroup eventLoopIncrement(@Value("${pauser.busy:true}") final boolean busy,
                                         @Value("${pauser.binding:false}") final boolean binding,
                                         @Value("${pauser.bindcpu:-1}") final int bindCpu) {

        return new EventGroup(true, busy ? Pauser.busy() : Pauser.balanced(), binding, bindCpu, -1, "ebsu_inc_");
    }

    @Bean
    public EventHandler processNextEventHandler(final Connection connection, final EbsEngineCfg engineCfg) {
        return new ProcessNextEventHandler(connection, engineCfg.increment().handlerPriority());
    }

    @Bean
    public Orchestrator orchestrator(final EventGroup eventLoopPreview,
                                     final EventGroup eventLoopIncrement,
                                     final EbsEngineCfg ebsEngineCfg,
                                     final EventHandler processNextEventHandler,
                                     final ScheduledExecutorService scheduledExecutorService) throws IOException {
        final Orchestrator orchestrator = new Orchestrator(ebsEngineCfg, eventLoopPreview, eventLoopIncrement);
        eventLoopIncrement.addHandler(processNextEventHandler);
        eventLoopPreview.start();

        // this next call blocks so we push off to BG thread
        scheduledExecutorService.submit(orchestrator::start);

        return orchestrator;
    }

    @Bean
    public EndPointStatusHandler endPointStatusHandler() {
        return new LoggingStatusHandler(LOGGER);
    }
}
