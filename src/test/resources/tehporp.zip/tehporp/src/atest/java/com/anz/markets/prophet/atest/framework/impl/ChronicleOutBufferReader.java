package com.anz.markets.prophet.atest.framework.impl;

import com.anz.markets.prophet.atest.framework.Output;
import com.anz.markets.prophet.atest.framework.OutputSource;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.MessageTypeClassMap;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;

public class ChronicleOutBufferReader {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleOutBufferReader.class);
    private final List<Output> messageQueue = Collections.synchronizedList(Lists.newArrayList());
    private final ProphetMarshallableCopier copier = new ProphetMarshallableCopier();

    public ChronicleObjectReader readFrom(final OutputSource source) {
        return (bytes, messageType) -> processEntity(bytes, messageType, chronicleMarshallable -> new Output<>(copyHeader(), chronicleMarshallable, source));
    }

    protected synchronized void processEntity(final ProphetBytes prophetBytes,
                                              final MessageType messageType,
                                              final Function<ProphetMarshallable, Output<ProphetMarshallable>> outputFactory) {
        try {
            final ProphetMarshallable ProphetMarshallable = createsTemplateObject(messageType);
            if (ProphetMarshallable != null) {
                ProphetMarshallable.readMarshallable(prophetBytes);
                messageQueue.add(outputFactory.apply(ProphetMarshallable));
            } else {
                LOGGER.warn("Unmapped messagetype {}. This message will be ignored.", messageType);
            }
        } catch (Exception e) {
            LOGGER.error("Unable to read from byte streams.", e);
        }
    }

    private Header copyHeader() {
        final Header rv = new Header();
        copier.copy(Context.context().header(), rv);
        return rv;
    }

    private ProphetMarshallable createsTemplateObject(final MessageType messageType) {
        switch (messageType) {
            case ONE_SECOND:
                return OneSecond.INSTANCE;
            case HOUR_CHIME:
                return HourChime.INSTANCE;
            case END_OF_WEEK_CHIME:
                return EndOfWeekChime.INSTANCE;
            case TIMEZONE_CHIME:
                return TradingTimeZoneChime.INSTANCE;
            case MARKET_DATA_SNAPSHOT:
                return MarketDataSnapshotImpl.forAggBook();
            case FILTERED_MARKET_DATA_SNAPSHOT:
                return FilteredMarketDataSnapshotImpl.forAggBook();
            default:
                try {
                    return (ProphetMarshallable) MessageTypeClassMap.MAP.inverse().get(messageType).newInstance();
                } catch (InstantiationException | IllegalAccessException e) {
                    return null;
                }
        }
    }

    List<Output> getMessageQueue() {
        return messageQueue;
    }
}
