package com.anz.markets.efx.fox.firewall.metric;

import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class LiveOrdersMetric implements Metric {
    private int liveOrders;

    @Override
    public void accept(final ExecutionReportDecoder executionReport, final long currentTimeNanos) {
        final ExecutionReportDecoder.Body body = executionReport.body();
        if (body.execType() == ExecType.NEW) {
            liveOrders++;
        } else if (body.leavesQty() <= 0) {
            liveOrders--;
        }
    }

    @Override
    public void accept(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        //noop
    }

    @Override
    public double currentValue(final long timeNanos) {
        return liveOrders;
    }

    @Override
    public double nextValue(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        return liveOrders + 1;
    }
}
