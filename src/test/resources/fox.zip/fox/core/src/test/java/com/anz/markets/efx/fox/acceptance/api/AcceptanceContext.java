package com.anz.markets.efx.fox.acceptance.api;

import com.anz.axle.microtime.PrecisionClock;

public interface AcceptanceContext {
    PricingClientEndpoint pricingClientEndpoint();
    VenueEndpoint.Lookup venueEndpointLookup();
    SorEndpoint sorEndpoint();
    CommandExecutionEndpoint eventProcessingEndpoint();
    PrecisionClock precisionClock();
    void awaitInit(int timeoutSeconds, boolean cleanQueue);

    default void awaitInit() {
        awaitInit(10, true);
    }
}
