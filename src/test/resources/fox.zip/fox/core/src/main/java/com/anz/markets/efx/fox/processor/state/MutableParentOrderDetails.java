package com.anz.markets.efx.fox.processor.state;

import java.util.Map;

import org.agrona.collections.Object2ObjectHashMap;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.ParentOrderDetails;
import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public class MutableParentOrderDetails implements ParentOrderDetails {
    private long orderId;
    private long origClOrdId;
    private long clOrdId;
    private long clOrdLinkId;
    private String userName;
    private String portfolio;
    private Region sourceRegion;
    private Region targetRegion;
    private Instrument instrument;
    private Venue venue;
    private String strategyName;
    private TimeInForce timeInForce;
    private OrderType orderType;
    private OrderStatus orderStatus;
    private String cancelReason;
    private String currency;
    private String settlCurrency;
    private Side side;
    private double price;
    private double orderQty;
    private String senderCompId;
    private long tradeDateMillis;
    private long settleDateMillis;
    private long transactTimeNanos;

    private double atMarketQty;
    private double toExecuteQty;

    private double lastQty;
    private double lastUsdQty;
    private double lastPx;
    private double commissionAdjLastPx;
    private double midPx;
    private double lastSpotRate;
    private double lastForwardPoints;
    private double leavesQty;
    private double cumQty;
    private double avgPx;
    private double commissionAdjAvgPx;
    private double commission;

    private final Map<PartyRole, String> partyRoles = new Object2ObjectHashMap<>();

    @Override
    public long orderId() {
        return orderId;
    }

    @Override
    public long origClOrdId() {
        return origClOrdId;
    }

    @Override
    public long clOrdId() {
        return clOrdId;
    }

    @Override
    public long clOrdLinkId() {
        return clOrdLinkId;
    }

    @Override
    public String userName() {
        return userName;
    }

    @Override
    public String portfolio() {
        return portfolio;
    }

    @Override
    public Region sourceRegion() {
        return sourceRegion;
    }

    @Override
    public Region targetRegion() {
        return targetRegion;
    }

    @Override
    public Instrument instrument() {
        return instrument;
    }

    @Override
    public TimeInForce timeInForce() {
        return timeInForce;
    }

    @Override
    public OrderType orderType() {
        return orderType;
    }

    @Override
    public String currency() {
        return currency;
    }

    @Override
    public String settlCurrency() {
        return settlCurrency;
    }

    @Override
    public Side side() {
        return side;
    }

    @Override
    public double price() {
        return price;
    }

    @Override
    public double orderQty() {
        return orderQty;
    }

    @Override
    public String senderCompId() {
        return senderCompId;
    }

    @Override
    public long tradeDateMillis() {
        return tradeDateMillis;
    }

    @Override
    public long settleDateMillis() {
        return settleDateMillis;
    }

    @Override
    public long transactTimeNanos() {
        return transactTimeNanos;
    }

    @Override
    public Venue venue() {
        return venue;
    }

    @Override
    public String strategyName() {
        return strategyName;
    }

    @Override
    public OrderStatus orderStatus() {
        return orderStatus;
    }

    @Override
    public String cancelReason() {
        return cancelReason;
    }

    @Override
    public double atMarketQty() {
        return atMarketQty;
    }

    @Override
    public double toExecuteQty() {
        return toExecuteQty;
    }

    @Override
    public double lastQty() {
        return lastQty;
    }

    @Override
    public double lastUsdQty() {
        return lastUsdQty;
    }

    @Override
    public double lastPx() {
        return lastPx;
    }

    @Override
    public double commissionAdjLastPx() {
        return commissionAdjLastPx;
    }

    @Override
    public double midPx() {
        return midPx;
    }

    @Override
    public double lastSpotRate() {
        return lastSpotRate;
    }

    @Override
    public double lastForwardPoints() {
        return lastForwardPoints;
    }

    @Override
    public double leavesQty() {
        return leavesQty;
    }

    @Override
    public double cumQty() {
        return cumQty;
    }

    @Override
    public double avgPx() {
        return avgPx;
    }

    @Override
    public double commissionAdjAvgPx() {
        return commissionAdjAvgPx;
    }

    @Override
    public double commission() {
        return commission;
    }

    @Override
    public Map<PartyRole, String> partyRoles(){
        return partyRoles;
    }

    public MutableParentOrderDetails orderId(final long orderId) {
        this.orderId = orderId;
        return this;
    }

    public MutableParentOrderDetails origClOrdId(final long origClOrdId) {
        this.origClOrdId = origClOrdId;
        return this;
    }

    public MutableParentOrderDetails clOrdId(final long clOrdId) {
        this.clOrdId = clOrdId;
        return this;
    }

    public MutableParentOrderDetails clOrdLinkId(final long clOrdLinkId) {
        this.clOrdLinkId = clOrdLinkId;
        return this;
    }

    public MutableParentOrderDetails userName(final String userName) {
        this.userName = userName;
        return this;
    }

    public MutableParentOrderDetails portfolio(final String portfolio) {
        this.portfolio = portfolio;
        return this;
    }

    public MutableParentOrderDetails sourceRegion(final Region sourceRegion) {
        this.sourceRegion = sourceRegion;
        return this;
    }

    public MutableParentOrderDetails targetRegion(final Region targetRegion) {
        this.targetRegion = targetRegion;
        return this;
    }

    public MutableParentOrderDetails instrument(final Instrument instrument) {
        this.instrument = instrument;
        return this;
    }

    public MutableParentOrderDetails timeInForce(final TimeInForce timeInForce) {
        this.timeInForce = timeInForce;
        return this;
    }

    public MutableParentOrderDetails orderType(final OrderType orderType) {
        this.orderType = orderType;
        return this;
    }

    public MutableParentOrderDetails currency(final String currency) {
        this.currency = currency;
        return this;
    }

    public MutableParentOrderDetails settlCurrency(final String settlCurrency) {
        this.settlCurrency = settlCurrency;
        return this;
    }

    public MutableParentOrderDetails side(final Side side) {
        this.side = side;
        return this;
    }

    public MutableParentOrderDetails price(final double price) {
        this.price = price;
        return this;
    }

    public MutableParentOrderDetails orderQty(final double orderQty) {
        this.orderQty = orderQty;
        return this;
    }

    public MutableParentOrderDetails senderCompId(final String senderCompId) {
        this.senderCompId = senderCompId;
        return this;
    }

    public MutableParentOrderDetails tradeDateMillis(final long tradeDateMillis) {
        this.tradeDateMillis = tradeDateMillis;
        return this;
    }

    public MutableParentOrderDetails settleDateMillis(final long settleDateMillis) {
        this.settleDateMillis = settleDateMillis;
        return this;
    }

    public MutableParentOrderDetails transactTimeNanos(final long transactTimeNanos) {
        this.transactTimeNanos = transactTimeNanos;
        return this;
    }

    public MutableParentOrderDetails venue(final Venue venue) {
        this.venue = venue;
        return this;
    }

    public MutableParentOrderDetails strategyName(final String strategyName) {
        this.strategyName = strategyName;
        return this;
    }

    public MutableParentOrderDetails orderStatus(final OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
        return this;
    }

    public MutableParentOrderDetails cancelReason(final String text) {
        this.cancelReason = text;
        return this;
    }

    public MutableParentOrderDetails atMarketQty(final double atMarketQty) {
        this.atMarketQty = atMarketQty;
        return this;
    }

    public MutableParentOrderDetails toExecuteQty(final double toExecuteQty) {
        this.toExecuteQty = toExecuteQty;
        return this;
    }

    public MutableParentOrderDetails lastQty(final double lastQty) {
        this.lastQty = lastQty;
        return this;
    }

    public MutableParentOrderDetails lastUsdQty(final double lastUsdQty) {
        this.lastUsdQty = lastUsdQty;
        return this;
    }

    public MutableParentOrderDetails lastPx(final double lastPx) {
        this.lastPx = lastPx;
        return this;
    }

    public MutableParentOrderDetails commissionAdjLastPx(final double commissionAdjLastPx) {
        this.commissionAdjLastPx = commissionAdjLastPx;
        return this;
    }

    public MutableParentOrderDetails midPx(final double midPx) {
        this.midPx = midPx;
        return this;
    }

    public MutableParentOrderDetails lastSpotRate(final double lastSpotRate) {
        this.lastSpotRate = lastSpotRate;
        return this;
    }

    public MutableParentOrderDetails lastForwardPoints(final double lastForwardPoints) {
        this.lastForwardPoints = lastForwardPoints;
        return this;
    }

    public MutableParentOrderDetails leavesQty(final double leavesQty) {
        this.leavesQty = leavesQty;
        return this;
    }

    public MutableParentOrderDetails cumQty(final double cumQty) {
        this.cumQty = cumQty;
        return this;
    }

    public MutableParentOrderDetails avgPx(final double avgPx) {
        this.avgPx = avgPx;
        return this;
    }

    public MutableParentOrderDetails commissionAdjAvgPx(final double commissionAdjAvgPx) {
        this.commissionAdjAvgPx = commissionAdjAvgPx;
        return this;
    }

    public MutableParentOrderDetails commission(final double commission) {
        this.commission = commission;
        return this;
    }

    public MutableParentOrderDetails addPartyRole(PartyRole partyRole, String partyValue){
        partyRoles.put(partyRole, partyValue);
        return this;
    }

    public MutableParentOrderDetails reset() {
        partyRoles.clear();
        return orderId(0)
                .origClOrdId(0)
                .clOrdId(0)
                .clOrdLinkId(0)
                .userName(null)
                .portfolio(null)
                .sourceRegion(null)
                .targetRegion(null)
                .instrument(null)
                .timeInForce(null)
                .orderType(null)
                .currency(null)
                .settlCurrency(null)
                .side(null)
                .price(Double.NaN)
                .orderQty(Double.NaN)
                .senderCompId(null)
                .tradeDateMillis(0)
                .settleDateMillis(0)
                .transactTimeNanos(0)
                .venue(null)
                .strategyName(null)
                .orderStatus(null)
                .cancelReason(null)
                .atMarketQty(0)
                .toExecuteQty(0)
                .lastQty(0)
                .lastUsdQty(0)
                .lastPx(Double.NaN)
                .commissionAdjLastPx(0)
                .midPx(Double.NaN)
                .lastSpotRate(Double.NaN)
                .lastForwardPoints(Double.NaN)
                .leavesQty(0)
                .cumQty(0)
                .avgPx(Double.NaN)
                .commissionAdjAvgPx(0)
                .commission(0);
    }

    @Override
    public String toString() {
        return "MutableParentOrderDetails{" +
                "orderId=" + orderId +
                ", origClOrdId=" + origClOrdId +
                ", clOrdId=" + clOrdId +
                ", clOrdLinkId=" + clOrdLinkId +
                ", userName='" + userName + '\'' +
                ", portfolio='" + portfolio + '\'' +
                ", sourceRegion=" + sourceRegion +
                ", targetRegion=" + targetRegion +
                ", instrument=" + instrument.key() + '\'' +
                ", venue=" + venue +
                ", strategyName='" + strategyName + '\'' +
                ", timeInForce=" + timeInForce +
                ", orderType=" + orderType +
                ", orderStatus=" + orderStatus +
                ", currency='" + currency + '\'' +
                ", settlCurrency='" + settlCurrency + '\'' +
                ", side=" + side +
                ", price=" + price +
                ", orderQty=" + orderQty +
                ", senderCompId='" + senderCompId + '\'' +
                ", tradeDateMillis=" + tradeDateMillis +
                ", settleDateMillis=" + settleDateMillis +
                ", transactTimeNanos=" + transactTimeNanos +
                ", atMarketQty=" + atMarketQty +
                ", toExecuteQty=" + toExecuteQty +
                ", lastQty=" + lastQty +
                ", lastUsdQty=" + lastUsdQty +
                ", lastPx=" + lastPx +
                ", commissionAdjLastPx=" + commissionAdjLastPx +
                ", midPx=" + midPx +
                ", lastSpotRate=" + lastSpotRate +
                ", lastForwardPoints=" + lastForwardPoints +
                ", leavesQty=" + leavesQty +
                ", cumQty=" + cumQty +
                ", avgPx=" + avgPx +
                ", commissionAdjAvgPx=" + commissionAdjAvgPx +
                ", commission=" + commission +
                ", partyRoles=" + partyRoles +
                ", cancelReason=" + cancelReason +
                '}';
    }
}
