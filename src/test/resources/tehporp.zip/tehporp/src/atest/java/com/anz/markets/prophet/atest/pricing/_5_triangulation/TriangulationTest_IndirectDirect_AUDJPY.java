package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class TriangulationTest_IndirectDirect_AUDJPY extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_6)
    @DisplayName("Triangulation of cross pair from INDIRECT-DIRECT driver pairs")
    public void given_indirect_direct_driver_pairs_triangulate_cross_pair() throws Exception {

        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverPairB = Instrument.USDJPY;
        final Instrument crossPair = Instrument.AUDJPY;

        given:
        {
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_75M.getQty(), Region.GB).set(TradingTimeZone.LDN, 8.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_100M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_150M.getQty(), Region.GB).set(TradingTimeZone.LDN, 13.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_200M.getQty(), Region.GB).set(TradingTimeZone.LDN, 17.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_75M.getQty(), Region.GB).set(TradingTimeZone.LDN, 9.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_100M.getQty(), Region.GB).set(TradingTimeZone.LDN, 12.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_150M.getQty(), Region.GB).set(TradingTimeZone.LDN, 16.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_200M.getQty(), Region.GB).set(TradingTimeZone.LDN, 19.5)
                    ))
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m|25m|25m|50m|50m"),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(13));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7500350, 0.750065));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7500200, 0.750080));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7500125, 0.750088));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7500000, 0.750100));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7499200, 0.750180));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7498600, 0.750240));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7497700, 0.750330));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7497300, 0.750370));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7496000, 0.750500));
            assertThat(clientPrice, isClientPricePoint(9, Level.QTY_25M, 0.7493200, 0.7507800));
            assertThat(clientPrice, isClientPricePoint(10, Level.QTY_25M, 0.7492800, 0.7508200));
            assertThat(clientPrice, isClientPricePoint(11, Level.QTY_50M, 0.7491000, 0.7510000));
            assertThat(clientPrice, isClientPricePoint(12, Level.QTY_50M, 0.7486000, 0.7515000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 101.005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(13));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 101.003500, 101.006500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 101.002000, 101.008000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 101.001250, 101.008750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 101.000000, 101.010000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 100.993500, 101.016500));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 100.988500, 101.021500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 100.98550, 101.024500));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 100.97250, 101.037500));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 100.95000, 101.060000));
            assertThat(clientPrice, isClientPricePoint(9, Level.QTY_25M, 100.91250, 101.097500));
            assertThat(clientPrice, isClientPricePoint(10, Level.QTY_25M, 100.8975, 101.112500));
            assertThat(clientPrice, isClientPricePoint(11, Level.QTY_50M, 100.8900, 101.120000));
            assertThat(clientPrice, isClientPricePoint(12, Level.QTY_50M, 100.8550, 101.155000));
        }
        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPrice.getBids().size(), is(13));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 75.7561601225, 75.7614404225));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 75.7537075138, 75.76389318875));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 75.7524812375, 75.765119600));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 75.7503124750, 75.767288600));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 75.7402953900, 75.777309140));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 75.7309859100, 75.786621960));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 75.717399135, 75.800213985));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 75.711858915, 75.805767065));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 75.688993800, 75.828643750));
            assertThat(clientPrice, isClientPricePoint(9, Level.QTY_25M, 75.636778500, 75.881017050));
            assertThat(clientPrice, isClientPricePoint(10, Level.QTY_25M, 75.61171800, 75.906057950));
            assertThat(clientPrice, isClientPricePoint(11, Level.QTY_50M, 75.58046925, 75.937378250));
            assertThat(clientPrice, isClientPricePoint(12, Level.QTY_50M, 75.52625400, 75.991806000));
        }
    }
}
