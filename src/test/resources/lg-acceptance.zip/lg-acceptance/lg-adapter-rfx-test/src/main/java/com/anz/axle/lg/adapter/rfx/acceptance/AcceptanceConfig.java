package com.anz.axle.lg.adapter.rfx.acceptance;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceConfig;
import com.anz.axle.lg.adapter.rfx.config.ServerConfig;

@Configuration
@Import({ServerConfig.class, SharedAcceptanceConfig.class})
public class AcceptanceConfig {
}