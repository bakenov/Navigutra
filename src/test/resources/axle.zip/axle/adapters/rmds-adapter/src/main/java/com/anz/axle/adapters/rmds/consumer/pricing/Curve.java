package com.anz.axle.adapters.rmds.consumer.pricing;

import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.ForwardPointsQuotePageKey;
import com.anz.axle.pricing.Quote;
import com.anz.axle.pricing.QuotePageType;
import com.anz.axle.pricing.QuoteState;
import com.anz.axle.spdee.dealing.QuotePriceType;
import com.google.common.base.Function;
import org.apache.log4j.Logger;
import org.joda.time.LocalDate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 *
 * @author winstonr
 */
public final class Curve {
    public static final Function<String, Curve> NEW = new Function<String, Curve>() {
        @Override
        public Curve apply(final String symbol) {
            return new Curve(symbol);
        }
    };

    private static final Quote ZERO_QUOTE = new Quote(Decimal.ZERO, Decimal.ZERO, QuotePriceType.FORWARD_POINTS);
    private static final Logger logger = Logger.getLogger(Curve.class);
    private final String instrument;
    private final ConcurrentMap<Tenor, ForwardPointsQuotePage> points = new ConcurrentHashMap<Tenor, ForwardPointsQuotePage>();

    private static final String D3_SOURCE_NAME = "D3";

    private Set<String> oneDaySettlementPairs = new HashSet<String>(Arrays.asList("USD/CAD","USD/TRY","USD/RUB"));

    public Curve(final String instrument) {
        this.instrument = instrument;
    }

    public List<ForwardPointsQuotePage> calculatePreSpotTenors() {
        final List<ForwardPointsQuotePage> tenors = new ArrayList<ForwardPointsQuotePage>();

        final ForwardPointsQuotePage tomNextPage = findPointForTenor(Tenor.TOM_NEXT);
        if (isValidPage(tomNextPage)) {
            calculateTomorrowQuotesUsingTomNextQuotes(tenors, tomNextPage);
        }
        else {
            if (isOneDaySettlement(instrument)) {
                calculateTodayQuotesUsingOvernightAndTomNextQuotes(tenors, ZERO_QUOTE);
            }
        }

        // sort for convenience
        if (tenors.size() > 1) Collections.sort(tenors, new MaturityDateComparator());
        return tenors;
    }

    private void calculateTomorrowQuotesUsingTomNextQuotes(
            final List<ForwardPointsQuotePage> tenors,
            final ForwardPointsQuotePage tomNextPage) {
        logger.debug("Calculating TOM quotes using TN page: " + tomNextPage);
        final QuoteState state = tomNextPage.getState();
        final ForwardPointsQuotePage tomPointsQuotePage = createPageFor(getInstrument(), Tenor.TOM, tomNextPage.getTenorDate(), tomNextPage.getReferenceSpotDate());
        final Quote tomNextQuote = tomNextPage.getQuotes().get(0);
        tomPointsQuotePage.getQuotes().add(new Quote(
                state,
                Decimal.minus(tomNextQuote.getAskPrice()),       // assume spot points are zero
                Decimal.minus(tomNextQuote.getBidPrice()),
                QuotePriceType.FORWARD_POINTS
                ));
        tomPointsQuotePage.setState(state);

        if (logger.isDebugEnabled()) logger.debug("Calculated TOM quote:" + tomPointsQuotePage);
        tenors.add(tomPointsQuotePage);

        calculateTodayQuotesUsingOvernightAndTomNextQuotes(tenors, tomNextQuote);
    }

    private void calculateTodayQuotesUsingOvernightAndTomNextQuotes(final List<ForwardPointsQuotePage> tenors, final Quote tomNextQuote) {
        final ForwardPointsQuotePage overnightQuotePage = findPointForTenor(Tenor.OVERNIGHT);

        if (isValidPage(overnightQuotePage)) {
            logger.debug("Calculating TODAY quotes using ON page: " + overnightQuotePage);
            final ForwardPointsQuotePage todayPointsQuotePage = createPageFor(getInstrument(), Tenor.TODAY, overnightQuotePage.getTenorDate(), overnightQuotePage.getReferenceSpotDate());
            final Quote overnightQuote = overnightQuotePage.getQuotes().get(0);
            todayPointsQuotePage.getQuotes().add(new Quote(
                    overnightQuotePage.getState(),
                    Decimal.minus(overnightQuote.getAskPrice().add(tomNextQuote.getAskPrice())),
                    Decimal.minus(overnightQuote.getBidPrice().add(tomNextQuote.getBidPrice())),
                    QuotePriceType.FORWARD_POINTS
                    ));
            todayPointsQuotePage.setState(overnightQuotePage.getState());

            if (logger.isDebugEnabled()) logger.debug("Calculated TODAY quote:" + todayPointsQuotePage);
            tenors.add(todayPointsQuotePage);
        }
    }

    private ForwardPointsQuotePage createPageFor(final String instrument,
                                                 final Tenor tenor,
                                                 final LocalDate tenorDate,
                                                 final LocalDate referenceSpotDate) {
        final ForwardPointsQuotePage page = new ForwardPointsQuotePage();
        page.setKey(new ForwardPointsQuotePageKey(instrument, tenor.getKey()));
        page.setSource(D3_SOURCE_NAME);
        page.setConfigVersion(-1);
        page.setTenorDate(tenorDate);
        page.setReferenceSpotDate(referenceSpotDate);
        page.setQuotePageType(QuotePageType.BANDED);
        return page;
    }

    private boolean isValidPage(final ForwardPointsQuotePage page) {
        return page != null && page.getQuotes().size() > 0;
    }

    private boolean isOneDaySettlement(final String pair) {
        return oneDaySettlementPairs.contains(pair);
    }

    public ForwardPointsQuotePage findPointForTenor(final Tenor tenor) {
        return points.get(tenor);
    }

    /**
     * Comparator that sorts forward quotes by maturity date
     * @author winstonr
     *
     */
    static final class MaturityDateComparator implements Comparator<ForwardPointsQuotePage> {
        @Override
        public int compare(final ForwardPointsQuotePage page1, final ForwardPointsQuotePage page2) {
            return page1.getTenorDate().compareTo(page2.getTenorDate());
        }
    }

    public String getInstrument() {
        return instrument;
    }

    public Map<Tenor, ForwardPointsQuotePage> getPoints() {
        return points;
    }

    public void addPoint(final ForwardPointsQuotePage point) {
       points.put(point.getTenor(), point);
    }

    public void setOneDaySettlementPairs(final Set<String> oneDaySettlementPairs) {
        this.oneDaySettlementPairs = oneDaySettlementPairs;
    }

    public boolean hasPointFor(final Tenor tenor) {
        return points.containsKey(tenor);
    }
}
