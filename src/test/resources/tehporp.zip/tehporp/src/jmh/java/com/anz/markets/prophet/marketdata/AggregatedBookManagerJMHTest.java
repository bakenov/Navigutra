package com.anz.markets.prophet.marketdata;

import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.marketdata.aggbook.AggregatedBookManager;
import com.anz.markets.prophet.marketdata.filter.SnapshotGenerator;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

public class AggregatedBookManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private Consumer<FilteredMarketDataSnapshot> aggregatedBookMarketDataConsumer;
        private FilteredMarketDataSnapshotImpl marketDataSnapshot;

        private TestStubConsumer<MidRate> midRateTestStubConsumer = new TestStubConsumer();

        @Setup
        public void setup() throws IOException {
            final IndexedConfigurationData indexedConfigurationData = TestConfigurationDataFactory.configurationDataForAggBookFiltering();
            final AggregatedBookManager aggregatedBookManager = new AggregatedBookManager(midRateTestStubConsumer, Market.WSP_U);
            aggregatedBookManager.consumerOfIndexedConfigurationData().accept(indexedConfigurationData);

            aggregatedBookMarketDataConsumer = aggregatedBookManager.consumerOfMarketData();
            marketDataSnapshot = new SnapshotGenerator(Market.CNX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        }
    }

    @Benchmark
    public long acceptFilteredMarketDataSnapshot(@NotNull final Data data) throws Exception {
        data.aggregatedBookMarketDataConsumer.accept(data.marketDataSnapshot);
        return data.midRateTestStubConsumer.getEvents().size();
    }
}
