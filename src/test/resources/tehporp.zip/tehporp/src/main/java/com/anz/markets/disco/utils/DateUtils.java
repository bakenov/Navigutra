package com.anz.markets.disco.utils;

import java.util.concurrent.TimeUnit;

import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateUtils {

    public static final String DATE_TIME_FORMAT = "yyyy.MM.dd'D'HH:mm:ss.SSS";

    public static ThreadLocal<DateTimeFormatter> DATE_TIME_FORMATTER = ThreadLocal.withInitial(() -> DateTimeFormat.forPattern(DATE_TIME_FORMAT).withZone(DateTimeZone.UTC));

    public static String getDateStr(long nanos) {
        return DATE_TIME_FORMATTER.get().print(TimeUnit.NANOSECONDS.toMillis(nanos));
    }
}
