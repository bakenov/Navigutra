package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.jetbrains.annotations.NotNull;
import org.junit.Test;

import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURSEK;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_CONFIGURED;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_16})
public class RealisedPositionFirewallTest extends ForEachHedgePortfolioBaseAcceptanceSpecification {

    @NotNull
    protected HedgeFirewallType getPositionFirewallType() {
        return REALISED_POSITION_PER_30_SEC;
    }

    @Test
    public void shouldEmitNotConfiguredWhenReceiveTradeAndNoConfiguration() {
        when:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgeFirewallConfigs(asList())
            );
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.94332, 0.00004, now()));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9));
        }
        then:
        {
            final EnumSet<HedgeFirewallType> pnlFirewallTypes = EnumSet.of(
                    REALISED_POSITION_PER_30_SEC,
                    UNREALISED_POSITION_PER_30_SEC);

            for (final HedgeFirewallType hedgeFirewallType : pnlFirewallTypes) {
                final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(hedgeFirewallType, portfolio)).getFirst();
                assertThat(status.getStatus(), is(NOT_CONFIGURED));
                assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
            }
        }
    }

    @Test
    public void shouldReactToMidRateChanges() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_000_000, true)
            )), false);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.9500));
        }
        when:
        // t+0, first trade not breached.
        {
            // AUD: +1mio AUD     | +0.9500mio USD
            // USD: -1mio USD     | -1mio USD
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 1.0));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
        when:
        // t+10, first trade breached when rate change 10 sec later.
        {
            // AUD: +1mio AUD     | +1.0001mio USD  => breach
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 1.0001));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*AUD.*1000100.*breached 1000000.0 limit.*"));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
        when:
        // t+20, first trade un breached when rate change 10 sec later.
        {
            // AUD: +1mio AUD     | +1mio USD
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 1.00000));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), is(""));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
    }

    @Test
    public void firewallIgnoreUSDPosition() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_000_000, true)
            )), false);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95000));
        }
        when:
        // t+0, usd position greater than limit.
        {
            // AUD: -1mio AUD     | -0.95mio USD
            // USD: +1.00001 USD
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, -1_000_000, 1.00001));
        }
        then:
        // do NOT breach as USD position ignored
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), is(""));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
    }

    @Test
    public void shouldBreachUntilOffSetTradeArrives() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_000_000, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 1.0001));

            // AXPROPHET-927 Should have no impact on existing scenario
            prophet.receive(tdd.biasPosition(Currency.AUD, 1_000_000));
        }
        when:
        // t+0, first trade filled rate cause usd ccy breached.
        {
            // AUD: -1mio AUD     | -1.0001mio USD => breach
            // USD: +0.95mio USD
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, -1_000_000, 0.9500));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*AUD.*-1000100.*breached 1000000.0 limit.*"));
        }
        when:
        // t+20, another trade comes in to offset usd pos brings it to unbreach
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 100, 1.0));
            // AUD: -0.9999mio AUD     | (-0.99999999)mio USD
            // USD: +0.9501mio USD
        }
        then:
        // not breached status is sent. posi is 1mio right on the limit.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), is(""));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
    }

    @Test
    public void shouldSlidePositionOutWhenPastWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_000_000, true)
            )), false);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95));
        }
        when:
        // t+1, first trade.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9500));
            // AUD: +1mio AUD     | +0.95mio USD
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), is(""));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
        when:
        // t+15, second trade breaches
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(14));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 100000, 1.0000));
            // AUD: +1.1mio AUD     | +1.045mio USD
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*AUD.*1045000.*breached 1000000.0 limit.*"));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
        when:
        // t+30, first trade slide at the window boundary
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(15));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), portfolio));
        }
        when:
        // t+31, first trade just after the window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), matches(""));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
    }

    @Test
    public void crossPairViaEURBreached() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_111_000, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.1));
            prophet.receive(tdd.marketDataSnapshot(EURSEK, 9.5));
        }
        when:
        // t+0, first trade not breached.
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, 500_000, 9.6));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, portfolio));

        }
        when:
        // second trade breached.
        {
            // EUR: +1mio EUR       | +1.1mio USD
            // SEK: -9.6mio SEK     | -9.6 * (1.1/9.5) = -1.11158 mio  => BREACHED
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, 500_000, 9.6));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), portfolio)).getFirst();
            assertThat(status.getStatus(), is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*SEK.*-1111578.947.*breached 1111000.0 limit.*"));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() {
        crossPairViaEURBreached();
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, getPositionFirewallType()));
        }
        then:
        {
            HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));

            prophet.clearOutputBuffer();
        }
        crossPairViaEURBreached();
    }

    @Test
    public void shouldResetWhenHedgerTurnedOn() {
        crossPairViaEURBreached();
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        then:
        {
            HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));

            prophet.clearOutputBuffer();
        }
        crossPairViaEURBreached();
    }

    @Test
    public void multiccyBreachedThenRemainBreachedOffsetTrade() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_111_000, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.1112));
            prophet.receive(tdd.marketDataSnapshot(EURSEK, 9.5));
        }
        when:
        // t+0, first trade breaches on both EUR and SEK ccy
        {
            // EUR: +1mio EUR       | +1.1112mio USD => BREACHED
            // SEK: -9.6mio SEK     | -9.6 * (1.1/9.5) = -1.11158 mio  => BREACHED
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, 1_000_000, 9.6));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*EUR.*1111200.*breached 1111000.0 limit.*"));
        }
        when:
        // t+10: second trade reduces EUR position below limit. However SEK still breached
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(10));
            prophet.receive(tdd.hedge_trade_001(portfolio, EURUSD, -125_000, 1.1));
            // EUR: +0.875mio EUR       | +0.9723mio USD => NOT BREACHED
            // SEK: -9.6mio SEK     | -9.6 * (1.1/9.5) = -1.11158 mio  => STILL BREACHED
        }
        then:
        // firewall still breached(on SEK)
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), portfolio));
        }
    }

    @Test
    public void multiccyBreachedThenRemainBreachedWhenSlideOut() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, getPositionFirewallType(), 1_111_000, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.1112));
            prophet.receive(tdd.marketDataSnapshot(EURSEK, 9.5));
        }
        when:
        // t+1, first trade breaches on both EUR and SEK ccy
        {
            // EUR: +1mio EUR       | +1.1112mio USD => BREACHED
            // SEK: -9.6mio SEK     | -9.6 * (1.1/9.5) = -1.11158 mio  => BREACHED
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, 1_000_000, 9.6));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*EUR.*1111200.*breached 1111000.0 limit.*"));
        }
        when:
        // t+10: second trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(9));
            prophet.receive(tdd.hedge_trade_001(portfolio, EURUSD, 1_000_000, 1.1));
            // EUR: +2.0mio EUR     | +2.2224mio USD => BREACHED
            // SEK: -9.6mio SEK     | -9.6 * (1.1/9.5) = -1.11158 mio  => BREACHED
        }
        then:
        // firewall still breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), portfolio));
        }
        when:
        // t+31: first trade slide out
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(21));
            // EUR: +1mio EUR       | +1.1112mio USD => BREACHED
        }
        then:
        // firewall still breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), portfolio));
        }
    }
}
