/*
	basicConsumer - tutorial2 - Requesting and displaying MarketPrice data

	This tutorial is the 2nd part in a series of tutorials with the goal of creating a basic consumer application.
	
	The goal of this tutorial is to introduce the EMA Consumer interface allowing the ability to request MarketPrice 
	data.  In addition, demonstrate how we receive the realtime, asynchronous responses from the Provider by simply 
	printing the messages to the terminal window.

	The series includes the following:

		o Tutorial 1 - Creating a barebones EMA consumer application
		o Tutorial 2 - Requesting and displaying MarketPrice data
		o Tutorial 3 - Parsing and Decoding MarketPrice data
		o Tutorial 4 - Requesting, parsing and decoding Level 2 data
		o Tutorial 5 - Dispatching messages within the user thread
 */

package com.thomsonreuters.ema.tutorials.consumer.tutorial2;

import com.thomsonreuters.ema.access.Msg;
import com.thomsonreuters.ema.access.AckMsg;
import com.thomsonreuters.ema.access.GenericMsg;
import com.thomsonreuters.ema.access.RefreshMsg;
import com.thomsonreuters.ema.access.ReqMsg;
import com.thomsonreuters.ema.access.StatusMsg;
import com.thomsonreuters.ema.access.UpdateMsg;
import com.thomsonreuters.ema.access.EmaFactory;
import com.thomsonreuters.ema.access.OmmConsumer;
import com.thomsonreuters.ema.access.OmmConsumerClient;
import com.thomsonreuters.ema.access.OmmConsumerConfig;
import com.thomsonreuters.ema.access.OmmConsumerEvent;
import com.thomsonreuters.ema.access.OmmException;

// basicConsumer
// The basicConsumer interface manages all control for the consumption of real-time data.  Implementing the
// EMA interface: OmmConsumerClient, we now have the opportunity to capture multiple, realtime events to 
// process the different types of messages we can receive once we subscribe to a market data item.  The
// interface below implements a number of required callbacks to achieve this goal.
//
public class basicConsumer implements OmmConsumerClient
{
	// Define our consumer communication channel to our Provider managing connection and item registration
	OmmConsumer consumer = null; 
	
	//*************************************************************************************************
	// Callback methods required by the OmmConsumerClient Interface.
	//
	// The following methods allow us to capture realtime events such as status and data events.
	//*************************************************************************************************
	
	// onRefreshMsg
	// Capture the initial image after subscribing (registering interest) in a market data item.  This 
	// callback utlizes the convenient print method to display output.
	public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event)
	{
		System.out.println(refreshMsg);
	}
	
	// onUpdateMsg
	// After receiving the initial image, we capture any updates to the item based on market events.
	// This callback utlizes the convenient print method to display output.
	public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event)
	{
		System.out.println(updateMsg);
	}
	
	// onStatusMsg
	// General status messages related to your consumer item registration.  For example, you will receive a 
	// status message if you register interest in an invalid item.  This callback utlizes the convenient 
	// print method to display output.	
	public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event)
	{
		System.out.println(statusMsg);
	}

	// onAllMsg, onAckMsg, onGenericMsg
	// These callbacks are not necessary for our series of tutorials.  You can refer to the documentation
	// to better understand the purpose of these callbacks.
	public void onAllMsg(Msg msg, OmmConsumerEvent consumerEvent){}
	public void onAckMsg(AckMsg ackMsg, OmmConsumerEvent consumerEvent){}
	public void onGenericMsg(GenericMsg genericMsg, OmmConsumerEvent consumerEvent){}

	
	// run
	// Connect to our provider, request for data and run the application for a short time to capture the 
	// realtime data.
	private void run()
	{
		try
		{
			// The consumer configuration class allows the customization of the consumer (OmmConsumer) 
			// interface, i.e. name of the server or IP, port, connection type, login username, etc.
			OmmConsumerConfig config = EmaFactory.createOmmConsumerConfig();
			
			// Create an instance of our consumer in preparation for communication.
			// When instructing the consumer to communicate with a Provider, we provide the following 
			// connection details.  The connection details are set within our configuration (OmmConsumerConfig).
			//
			// Note: 	After creating our consumer, by default, EMA will launch a background thread to manage 
			//			communication and message dispatching.  Within EMA, this is controlled by the 
			//			OperationModel available within the OmmConsumerConfig interface.  Refer to the 
			//			documentation for more details.
			//
			//			For example, EMA sets the following model by default:
			//				config.operationModel(OmmConsumerConfig.OperationModel.API_DISPATCH);
			consumer = EmaFactory.createOmmConsumer(
				  config.host("elektron:14002")
					    .username("user")
			);
			
			// Define what data we want and register it with our consumer
			//  
			// When registering, we also need to specify where we want to capture all the events generated by 
			// this request.  
			OmmConsumerClient eventHandler = this;

			consumer.registerClient(
				  EmaFactory.createReqMsg()
								.serviceName("ELEKTRON_AD")
								.name("BB.TO"), 
				  eventHandler
			);

			// Because we are using the default operation model: API_DISPATCH where EMA manages the dispatching 
			// of events within a background thread, we must block and wait on our application thread for a short 
			// period to capture our market data events.
			Thread.sleep(30000);
		} 
		catch (InterruptedException | OmmException excp)
		{
			System.out.println("Exception thrown: " + excp.getMessage());
		}
		finally
		{
			// Cleanup resources before we return
			if (consumer != null) 
			{
				// Important we uninitialize our consumer to properly clean up, unregister, disconnect and stop 
				// the background thread managing event dispatching.
				consumer.uninitialize();
				consumer = null;
			}
		}
	}

	//*************************************************************************************************
	// main
	// Application entry point to manage the life of the consumer.
	//
	//*************************************************************************************************
	public static void main(String[] args)
    {
		// Main interface to manage all consumer communication to our Provider
        basicConsumer basicConsumer = new basicConsumer();
		
		// Run the application for short time to manage communication to our Provider
		basicConsumer.run();
		
		// Done processing
		System.out.print("Processing complete");		
    }	
}
