package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;

/**
 * Firewall configuration for hedger per [HedgePortfolio](#HedgePortfolio), [Region](#Region) and [HedgeFirewallType](#HedgeFirewallType).
 * <p>
 * All firewalls operate as threshold under a configurable sliding window period and operate across all instruments under the given #HedgeType.
 * <p>
 * Note that sliding window period tick is in seconds. That is, all data in the second outside the window period is discarded from threshold check.
 */
public interface HedgeFirewallConfig extends ProphetMarshallable {

    Portfolio getPortfolio();

    Region getRegion();

    HedgeFirewallType getHedgeFirewallType();

    double getLimit();

    boolean isEnabled();
}
