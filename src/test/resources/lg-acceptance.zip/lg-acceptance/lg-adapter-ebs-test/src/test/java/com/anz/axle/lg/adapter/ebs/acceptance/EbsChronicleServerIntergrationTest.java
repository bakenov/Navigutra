package com.anz.axle.lg.adapter.ebs.acceptance;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.TestUtils;
import com.anz.axle.lg.adapter.ebs.EbsBookRules;
import com.anz.axle.lg.adapter.ebs.EbsNewOrderSingleHandler;
import com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator;
import com.anz.axle.lg.adapter.ebs.SymbolPriceDecimalFormat;
import com.anz.axle.lg.adapter.ebs.UserResponseBuilder;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.CustUserData_UserDataGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.CFICode;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MarketSegmentID;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.SettlType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserStatus;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelReject;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradeCaptureReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultMarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultMarketDataSnapshotFullRefresh;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.LastMarketTradeMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.LastMarketTrade;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRejectMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.wire.Marshallable;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.FixVersion;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.tools.FixToDTO;
import software.chronicle.fix.yaml.TcpSession;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.getRandomFreeLocalPort;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.axle.lg.adapter.ebs.EbsUserResponseHandler.USER_STATUS_TEXT_PASSWORD_CHANGE_REQUIRED;
import static com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator.ebsExecutionReportNew;
import static com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator.ebsPartialFillSequence_2_executionReportNew;
import static com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator.ebsPartialFillSequence_3_tradeCaptureReportZ2M;
import static com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator.ebsPartialFillSequence_4_tradeCaptureReportZ3M;
import static com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator.ebsPartialFillSequence_8_tradeCaptureReportDone2M;
import static com.anz.axle.lg.adapter.ebs.FixToDTOTestDataGenerator.ebsPartialFillSequence_9_tradeCaptureReportDone3M;
import static com.anz.axle.lg.adapter.ebs.UserResponseBuilder.DEFAULT_USER_REQUEST_ID;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.CANCELED;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.FILL;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.NEW;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.PARTIAL_FILL;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.TRADE;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserRequestType.CHANGE_PASSWORD_FOR_USER;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserRequestType.LOG_OFF_USER;
import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.UserRequestType.LOG_ON_USER;
import static com.anz.axle.lg.util.SymbolNormaliser.toSymbol6;
import static com.anz.markets.efx.pricing.codec.api.EntryType.BID;
import static com.anz.markets.efx.pricing.codec.api.EntryType.OFFER;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class EbsChronicleServerIntergrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsChronicleServerIntergrationTest.class);

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private Venue marketId;

    // Server side
    private static final String HOST = "localhost";
    private static final String TARGET_COMP_ID = "SERVER";
    private static final String USERNAME = "STUB";
    private static final String PASSWORD = "PASSWORD";
    private static final String SYMBOL1 = "GBP/CHF";
    private static final String SYMBOL2 = "EUR/CHF";
    private FixSessionHandler serverSession;
    private Queue<StandardHeaderTrailer> serverReceiveQueue;
    private FixEngineCfg cfg;
    private ChronicleFixEngine engine;
    private TcpSession tcpSession;

    private String appName;
    private String senderCompId;
    private int port;
    private String fixFilePath;
    private String fixStorePath;
    private String passwordFile;
    private String path;

    private final FixToDTO fixToDTO = new FixToDTO(new com.anz.axle.lg.adapter.ebs.chroniclefix.generated.parsers.MessageParser(), MessageNotifier.class);

    @Before
    public void setup() throws Exception {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        appName = "ebs";
        if (testName.getMethodName().startsWith("EBSHEDGE_")) {
            marketId = Venue.EBSHEDGE;
            senderCompId = "_EBSH_";
            System.setProperty("ebs.fix.user.request.AllowFixingInfo", "N");
        } else {
            marketId = Venue.EBS;
            senderCompId = "_EBS__";
            System.setProperty("ebs.fix.user.request.AllowFixingInfo", "Y");
        }
        setPersistStorePath(appName, testName.getMethodName());
        port = getRandomFreeLocalPort();
        path = "target/" + appName + "/" + System.currentTimeMillis();

        fixFilePath = path + "/log/";
        fixStorePath = path + "/store/";
        passwordFile = path + "/" + marketId.name() + "-passwords.properties";
        System.out.println("PASSWORD_FILE=" + new File(passwordFile).getAbsolutePath());
        System.setProperty("ebs.fix.user.password.file", new File(passwordFile).getAbsolutePath());

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + appName +
                                ",venue:" + marketId.name() +
                                ",appOptions:--reset" +
                                "," + appName + ".fix.socket.use.ssl:N" +
                                "," + appName + ".fix.log.destination:STDOUT" +
                                "," + appName + ".fix.file.log.path:" + fixFilePath +
                                "," + appName + ".fix.file.store.path:" + fixStorePath +
                                "," + appName + ".fix.log_all:true" +
                                "," + appName + ".fix.reconnectInterval:1" +
                                "," + appName + ".fix.sendercompid:" + senderCompId +
                                "," + appName + ".fix.targetcompid:" + TARGET_COMP_ID +
                                "," + appName + ".fix.user.request.username:" + USERNAME +
                                "," + appName + ".fix.user.request.password:" + PASSWORD +
                                "," + appName + ".fix.host:" + HOST +
                                "," + appName + ".fix.port:" + port
                ));

        startServerSide();

        application = new Application("lg-ebs-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);

        assertTrue(TestUtils.waitFor(serverSession::isConnected, 10_000));
        LOGGER.info("Server connected.");
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        IOTools.deleteDirWithFiles(path);
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @BeforeClass
    public static void beforeClass() {
        deleteAll();
    }
    @AfterClass
    public static void afterClass() {
        deleteAll();
    }

    private static void deleteAll() {
        IOTools.deleteDirWithFiles("target/ebs/");
    }

    @Test
    public void logon_to_logout() {
        waitForLogon();

        waitForUserRequestLogonUser();
        LOGGER.info("Sending logon UserResponse...");
        serverSession.sendMessage(FixToDTOTestDataGenerator.userResponse_logon(false));

        final MarketDataRequest marketDataRequest1 = waitForMarketDataRequest(SYMBOL1, CFICode.SPOT, SettlType.SPOT);
        final MarketDataRequest marketDataRequest2 = waitForMarketDataRequest(SYMBOL2, CFICode.SPOT, SettlType.SPOT);
        serverReceiveQueue.clear();

        assertHeartbeat();

        sendMarketDataSnapshotFullRefreshFor(marketDataRequest2);
        final SnapshotFullRefresh snapshotFullRefreshFromUM = waitForSnapshotFullRefreshFromUM(InstrumentKey.of(toSymbol6(SYMBOL2), SecurityType.FXSPOT, Tenor.SP));

        // test ExecutionReport Fill merged with TradeCaptureReport Done result in ER with parties from TCR
        sendExecutionReportFillAndTradeCaptureReportDoneReceiveERwithParties(snapshotFullRefreshFromUM);

        // test Cancel request being Rejected
        sendOrderThenCancelWithCancelReject(snapshotFullRefreshFromUM);

        // test TradingSessionList, TradingSessionStatus, FixingOrder and Cancels
        tradingSessionAndFixingOrdersWithCancelsAndRejects(snapshotFullRefreshFromUM);

        // test UM snapshot after MarketDataSnapshotFullRefresh + MarketDataIncrementalRefresh
        umSnapshotAfterMarketDataSnapshotFullRefreshAndMarketDataIncrementalRefresh(marketDataRequest1);

        // test tick from IncrementalRefresh
        tickerFromMarketDataIncrementalRefresh(marketDataRequest1);

        // test lg-ebs send UserRequest logoff on disconnect
        stoppingAndSendSessionLogoffOnDisconnect();
    }

    private void stoppingAndSendSessionLogoffOnDisconnect() {

        // trigger logoff
        application.stop();

        // receive UserRequest logoff from lg-ebs disconnect/logoff
        LOGGER.info("Waiting for UserRequest...LOG_OFF_USER");
        final UserRequest userRequest = waitForUserRequest(LOG_OFF_USER);
        System.out.println("Received UserRequest...LOG_OFF_USER: " + userRequest);
    }

    private void sendExecutionReportFillAndTradeCaptureReportDoneReceiveERwithParties(final SnapshotFullRefresh snapshotFullRefreshFromUM) {
        // send NewOrderSingle
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(clOrdId, snapshotFullRefreshFromUM);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);

        final com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle newOrderSingle =
                waitForNewOrderSingle(newOrderSingleUM);
        serverReceiveQueue.clear();

        // receive ER New
        final ExecutionReport executionReportNew = sendExecutionReport(newOrderSingle.clOrdID(), ebsPartialFillSequence_2_executionReportNew());
        waitForExecutionReportNewOrFillFromUM(executionReportNew);

        // send pending/Done TCRs
        sendTradeCaptureReport(newOrderSingle.clOrdID(), ebsPartialFillSequence_3_tradeCaptureReportZ2M());
        sendTradeCaptureReport(newOrderSingle.clOrdID(), ebsPartialFillSequence_4_tradeCaptureReportZ3M());
        final TradeCaptureReport tradeCaptureReportDone2M = sendTradeCaptureReport(newOrderSingle.clOrdID(), ebsPartialFillSequence_8_tradeCaptureReportDone2M());
        final TradeCaptureReport tradeCaptureReportDone3M = sendTradeCaptureReport(newOrderSingle.clOrdID(), ebsPartialFillSequence_9_tradeCaptureReportDone3M());

        // receive first partial Fill for 2M
        executionReportNew.execType(TRADE);
        executionReportNew.ordStatus(OrdStatus.PARTIALLY_FILLED);
        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport umExecutionReportPartialFill = waitForExecutionReportNewOrFillFromUM(executionReportNew, 3_000_000.0);
        assertThat(umExecutionReportPartialFill.body.execId, is(tradeCaptureReportDone2M.execID()));
        assertThat(umExecutionReportPartialFill.parties.size(), is(1));
        assertThat(umExecutionReportPartialFill.parties.get(0).partyRole, is(PartyRole.CONTRA_FIRM));
        assertThat(umExecutionReportPartialFill.parties.get(0).partyId, is(
                tradeCaptureReportDone2M.tradeCaptureReport_SidesGrp_1(0)
                        .tradeCaptureReport_SidesGrp_PartyIDsGrp_1(0).partyID()));

        // receive second/last Fill for 3M
        executionReportNew.ordStatus(OrdStatus.FILLED);
        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport umExecutionReportFill = waitForExecutionReportNewOrFillFromUM(executionReportNew, 0.0);
        assertThat(umExecutionReportFill.body.execId, is(tradeCaptureReportDone3M.execID()));
        assertThat(umExecutionReportFill.parties.size(), is(1));
        assertThat(umExecutionReportFill.parties.get(0).partyRole, is(PartyRole.CONTRA_FIRM));
        assertThat(umExecutionReportFill.parties.get(0).partyId, is(
                tradeCaptureReportDone3M.tradeCaptureReport_SidesGrp_1(0)
                        .tradeCaptureReport_SidesGrp_PartyIDsGrp_1(0).partyID()));
    }

    private void assertHeartbeat() {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(HeartbeatMatcher.build()
                        .header().matches(HeartbeatMatcher.source().gt(0))
                        .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                        .body().matches(HeartbeatMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(HeartbeatMatcher.messageId().gt(0L)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

    @Test
    public void send_EBSHEDGE_orderWith5DecimalPlacePrice() {
        waitForLogon();

        waitForUserRequestLogonUser();
        LOGGER.info("Sending logon UserResponse...");
        serverSession.sendMessage(FixToDTOTestDataGenerator.userResponse_logon(false));

        final MarketDataRequest marketDataRequest1 = waitForMarketDataRequest(SYMBOL2, CFICode.SPOT, SettlType.SPOT);
        serverReceiveQueue.clear();

        sendMarketDataSnapshotFullRefreshFor(marketDataRequest1);
        final SnapshotFullRefresh snapshotFullRefreshFromUM = waitForSnapshotFullRefreshFromUM(InstrumentKey.of(toSymbol6(SYMBOL2), SecurityType.FXSPOT, Tenor.SP));
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();

        // send NewOrderSingle
        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(clOrdId, snapshotFullRefreshFromUM);
        newOrderSingleUM.body.marketId = Venue.EBSHEDGE.name();
        newOrderSingleUM.body.price = 1.1d;
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);

        final com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle newOrderSingle =
                waitForNewOrderSingle(newOrderSingleUM);

        final SymbolPriceDecimalFormat symbolPriceDecimalFormat = application.getApplicationContext().getBean("symbolPriceDecimalFormat", SymbolPriceDecimalFormat.class);
        final CharSequence expectedPrice = symbolPriceDecimalFormat.formatPrice(toSymbol6(SYMBOL2), newOrderSingleUM.body.price);

        assertThat(SYMBOL2 + " should be configured as 5 decimal place in ebs.fix.symbol.price.decimal.places",
                newOrderSingle.price().toString(), is(expectedPrice.toString()));
    }

    @Test
    public void receive_UserResponseLogoff_changePasswordRequest_update() throws Exception {
        waitForLogon();
        waitForUserRequestLogonUser();

        // change old password
        sendUserResponseNotLoggedInPasswordChangeOldPasswordChangeRequired();
        waitForUserRequestPasswordChange();
        serverReceiveQueue.clear();

        // change expired password
        sendUserResponse(UserStatus.PASSWORD_EXPIRED);
        final String newPasswordForExpiredPassword = waitForUserRequestPasswordChange();
        sendUserResponse(UserStatus.PASSWORD_CHANGED);

        final String passwordOnFile = assertNewPasswordSavedToFile(newPasswordForExpiredPassword);

        // change password failed
        sendUserResponse(UserStatus.PASSWORD_EXPIRED);
        waitForUserRequestPasswordChange();
        sendUserResponse(UserStatus.PASSWORD_CHANGE_FAILED);
        // assert password not changed
        assertNewPasswordSavedToFile(passwordOnFile);
    }

    private void umSnapshotAfterMarketDataSnapshotFullRefreshAndMarketDataIncrementalRefresh(final MarketDataRequest marketDataRequest1) {
        final String symbol1 = marketDataRequest1.marketDataRequest_RelatedSymGrp_1(0).symbol();
        final InstrumentKey instrumentKey = InstrumentKey.of(toSymbol6(symbol1), SecurityType.FXSPOT, Tenor.SP);

        assertThat(instrumentKey.symbol(), is(toSymbol6(symbol1)));

        final EbsBookRules ebsBookRules = application.getApplicationContext().getBean("ebsBookRules", EbsBookRules.class);
        final EbsBookRules.Config config = ebsBookRules.configFor(instrumentKey.instrumentId());
        assertThat(symbol1 + " priceDepth", config.depth(), is(5));

        final MarketDataSnapshotFullRefresh snapshotFullRefresh = marketDataSnapshotFullRefresh_1(instrumentKey);
        snapshotFullRefresh.mDReqID(Bytes.from(marketDataRequest1.mDReqID()));

        serverSession.sendMessage(snapshotFullRefresh);
        SnapshotFullRefresh fullRefresh = waitForSnapshotFullRefreshFromUMWithKey(instrumentKey);
        LOGGER.info("Received MarketDataSnapshotFullRefresh..." + fullRefresh);

        MarketDataIncrementalRefresh marketDataIncrementalRefresh = marketDataIncrementalRefresh_2(instrumentKey);
        serverSession.sendMessage(marketDataIncrementalRefresh);
        IncrementalRefresh incrementalRefresh = waitForIncrementalRefreshFromUMWithKey(instrumentKey);
        LOGGER.info("Received MarketDataIncrementalRefresh.2.." + incrementalRefresh);

        marketDataIncrementalRefresh = marketDataIncrementalRefresh_3(instrumentKey);
        serverSession.sendMessage(marketDataIncrementalRefresh);
        incrementalRefresh = waitForIncrementalRefreshFromUMWithKey(instrumentKey);
        LOGGER.info("Received MarketDataIncrementalRefresh.3.." + incrementalRefresh);

        // expect combine of above snapshot+incremental
        final SnapshotFullRefreshMatcher fullRefreshMatcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lg-ebs"))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                .entries().countEquals(6)
                .entries().oneMatches(e -> e.mdEntryPx == 1.3057);

        LOGGER.info("Waiting for Combine MarketDataSnapshotFullRefresh..." + instrumentKey);
        fullRefresh = (SnapshotFullRefresh)Asserter.of(acceptanceContext.pricingMessageQueue()).matching(fullRefreshMatcher).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        LOGGER.info("Received Combine MarketDataSnapshotFullRefresh..." + fullRefresh);
        assertThat(fullRefresh.entries.size(), is(6));

        assertSnapshotFullRefreshEntry(fullRefresh,0, BID, 1.3, 6000000.0);
        assertSnapshotFullRefreshEntry(fullRefresh,1, BID, 1.2999, 7000000.0);
        assertSnapshotFullRefreshEntry(fullRefresh,2, BID, 1.2998, 3000000.0);
        assertSnapshotFullRefreshEntry(fullRefresh,3, OFFER, 1.3055, 6000000.0);
        assertSnapshotFullRefreshEntry(fullRefresh,4, OFFER, 1.3056, 7000000.0);
        assertSnapshotFullRefreshEntry(fullRefresh,5, OFFER, 1.3057, 3000000.0);
    }

    private void tickerFromMarketDataIncrementalRefresh(final MarketDataRequest marketDataRequest1) {
        final String symbol1 = marketDataRequest1.marketDataRequest_RelatedSymGrp_1(0).symbol();
        final InstrumentKey instrumentKey = InstrumentKey.of(toSymbol6(symbol1), SecurityType.FXSPOT, Tenor.SP);

        assertThat(instrumentKey.symbol(), is(toSymbol6(symbol1)));
        MarketDataIncrementalRefresh marketDataIncrementalRefresh = FixToDTOTestDataGenerator.ebsMarketDataIncrementalRefreshFor_1_Trade_entry();
        marketDataIncrementalRefresh.marketDataIncrementalRefresh_MDEntriesGrp_1(0).symbol(symbol1);

        serverSession.sendMessage(marketDataIncrementalRefresh);

        LOGGER.info("Waiting for LastMarketTrade..." + instrumentKey);
        LOGGER.info("Peak at queue: "+acceptanceContext.tradingResponseMessageQueue());
        final LastMarketTrade lastMarketTrade = (LastMarketTrade)Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(LastMarketTradeMatcher.build()
                        .body().matches(LastMarketTradeMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(LastMarketTradeMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                        .body().matches(LastMarketTradeMatcher.mdEntryPx().eq(marketDataIncrementalRefresh.marketDataIncrementalRefresh_MDEntriesGrp_1(0).mDEntryPx()))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        LOGGER.info("Received LastMarketTrade." + lastMarketTrade);
    }

    private void assertSnapshotFullRefreshEntry(final SnapshotFullRefresh snapshot, final int entryIdx, final EntryType entryType, final double price, final double qty) {
        assertThat(snapshot.entries.get(entryIdx).mdEntryType, is(entryType));
        assertThat(snapshot.entries.get(entryIdx).mdEntryPx, is(price));
        assertThat(snapshot.entries.get(entryIdx).mdEntrySize, is(qty));
    }

    private MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh_1(final InstrumentKey instrumentKey) {
        final String snapshotFix = "8=FIX.4.4|9=335|35=W|49=ICAP_Ai_Server|56=ANZ_PINK_GB_EBS|34=11|52=20190515-08:50:18.820|262=780180482|1021=2|55=GBP/CHF|461=RCSXXX|63=0|268=8|269=0|270=1.3000|271=6000000|269=0|270=1.2999|271=7000000|269=0|270=1.2998|271=3000000|269=1|270=1.3055|271=6000000|269=1|270=1.3056|271=7000000|269=1|270=1.3057|271=3000000|269=x|270=1.3002|269=w|270=1.3055|10=088|";
        final DefaultMarketDataSnapshotFullRefresh fullRefresh = new DefaultMarketDataSnapshotFullRefresh();
        FixToDTOTestDataGenerator.parse(snapshotFix.replace('|', (char) 0x01), fullRefresh);
        assertThat(instrumentKey.symbol(), is(toSymbol6(fullRefresh.symbol())));
        return fullRefresh;
    }

    private MarketDataIncrementalRefresh marketDataIncrementalRefresh_2(final InstrumentKey instrumentKey) {
        final String fixMessage = "8=FIX.4.4|9=208|35=X|49=ICAP_Ai_Server|56=ANZ_PINK_GB_EBS|34=126|52=20190515-08:50:43.680|1021=2|20203=1|268=2|279=0|269=1|55=GBP/CHF|461=RCSXXX|63=0|270=1.3050|271=16000000|279=0|269=w|55=GBP/CHF|461=RCSXXX|63=0|270=1.3050|10=003|";
        final DefaultMarketDataIncrementalRefresh incrementalRefresh = new DefaultMarketDataIncrementalRefresh();
        FixToDTOTestDataGenerator.parse(fixMessage.replace('|', (char) 0x01), incrementalRefresh);
        assertThat(instrumentKey.symbol(), is(toSymbol6(incrementalRefresh.marketDataIncrementalRefresh_MDEntriesGrp_1(0).symbol())));
        return incrementalRefresh;
    }

    private MarketDataIncrementalRefresh marketDataIncrementalRefresh_3(final InstrumentKey instrumentKey) {
        final String fixMessage = "8=FIX.4.4|9=394|35=X|49=ICAP_Ai_Server|56=ANZ_PINK_GB_EBS|34=133|52=20190515-08:50:46.979|1021=2|20203=1|268=5|279=2|269=1|55=GBP/CHF|461=RCSXXX|63=0|270=1.3050|271=16000000|279=0|269=1|55=GBP/CHF|461=RCSXXX|63=0|270=1.3055|271=6000000|279=0|269=1|55=GBP/CHF|461=RCSXXX|63=0|270=1.3056|271=7000000|279=0|269=1|55=GBP/CHF|461=RCSXXX|63=0|270=1.3057|271=3000000|279=0|269=w|55=GBP/CHF|461=RCSXXX|63=0|270=1.3054|10=117|";
        final DefaultMarketDataIncrementalRefresh incrementalRefresh = new DefaultMarketDataIncrementalRefresh();
        FixToDTOTestDataGenerator.parse(fixMessage.replace('|', (char) 0x01), incrementalRefresh);
        assertThat(instrumentKey.symbol(), is(toSymbol6(incrementalRefresh.marketDataIncrementalRefresh_MDEntriesGrp_1(0).symbol())));
        return incrementalRefresh;
    }

    private void tradingSessionAndFixingOrdersWithCancelsAndRejects(final SnapshotFullRefresh snapshotFullRefreshFromUM) {

        LOGGER.info("Sending TradingSessionList...");
        serverSession.sendMessage(FixToDTOTestDataGenerator.tradingSessionList());

        // send NewOrderSingle FixingOrder, receive ER new then send OrderCancelRequest to cancel.
        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(newClOrdId(), snapshotFullRefreshFromUM);
        newOrderSingleUM.body.ordType = OrderType.FIXING_ORDER;
        newOrderSingleUM.strategyParameters.add(new StrategyParameter(EbsNewOrderSingleHandler.BENCHMARK_FIX_STRATEGY_NAME, "WMR_LONDON_0700"));
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);

        LOGGER.info("Waiting for FIXING_ORDER NewOrderSingle ...");
        final com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle newOrderSingle =
                waitForNewOrderSingle(newOrderSingleUM);

        assertThat(newOrderSingle.ordType(), is(OrdType.FIXING_ORDER));
        assertThat(newOrderSingle.tradingSessionID(), is("212"));
        assertThat(newOrderSingle.marketSegmentID(), is(MarketSegmentID.FIXING));
        assertTrue("no price for fixing order", newOrderSingle.price() == null);

        serverReceiveQueue.clear();

        LOGGER.info("Sending EBS ExecutionReport for FIXING_ORDER.." + newOrderSingle.clOrdID().toString());
        final ExecutionReport executionReportNew = sendExecutionReport(newOrderSingle.clOrdID(), ebsExecutionReportNew());
        LOGGER.info("Waiting for ExecutionReport for FIXING_ORDER.." + newOrderSingle.clOrdID().toString());
        waitForExecutionReportNewOrFillFromUM(executionReportNew);

        // send OrderCancelRequest and Cancel
        final OrderCancelRequest orderCancelRequestUM = orderCancelRequestUMMessage(newOrderSingleUM, newClOrdId());
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequestUM);

        waitForOrderCancelRequest(orderCancelRequestUM);

        // send OrderCancelRequest and receive OrderCancelReject
        final OrderCancelRequest orderCancelRequestWithoutOrdTypeUM = orderCancelRequestUMMessage(newOrderSingleUM, newClOrdId());
        orderCancelRequestWithoutOrdTypeUM.body.ordType = OrderType.FIXING_ORDER;
        orderCancelRequestWithoutOrdTypeUM.body.timeInForce = TimeInForce.IOC; // this will be rejected as it will result in a EBS Protocol Violation
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequestWithoutOrdTypeUM);

        final com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject reject = waitForOrderCancelRejectFromUM(orderCancelRequestWithoutOrdTypeUM);
        assertThat(reject.body.text, is("OrdType.FIXING_ORDER must have TimeInForce.GTC."));

        // send NewOrderSingle FixingOrder for a closed session. Order Rejected
        final NewOrderSingle newOrderSingle2UM = newOrderSingleUMMessage(newClOrdId(), snapshotFullRefreshFromUM);
        newOrderSingle2UM.body.ordType = OrderType.FIXING_ORDER;
        // 'WMR_LONDON_0300 is closed. should reject
        newOrderSingle2UM.strategyParameters.add(new StrategyParameter(EbsNewOrderSingleHandler.BENCHMARK_FIX_STRATEGY_NAME, "WMR_LONDON_0300"));
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle2UM);

        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport executionReportReject = waitForExecutionReportRejectOfNewOrderSingle(newOrderSingle2UM);
        assertTrue(executionReportReject.body.rejectText, executionReportReject.body.rejectText.startsWith("Session closed"));
    }

    private com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject waitForOrderCancelRejectFromUM(final OrderCancelRequest orderCancelRequestUM) {

        LOGGER.info("Waiting for OrderCancelReject from UM for Order..." + orderCancelRequestUM);
        System.out.println("Peak at queue: "+acceptanceContext.tradingResponseMessageQueue());
        return (com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject) Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(OrderCancelRejectMatcher.build()
                        .body().matches(OrderCancelRejectMatcher.clOrdId().eq(orderCancelRequestUM.body.clOrdId))
                        .body().matches(OrderCancelRejectMatcher.origClOrdId().eq(orderCancelRequestUM.body.origClOrdId))
                        .body().matches(OrderCancelRejectMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(OrderCancelRejectMatcher.orderId().eq(orderCancelRequestUM.body.orderId))
                        .body().matches(OrderCancelRejectMatcher.ordStatus().eq(OrderStatus.REJECTED))
                        .body().matches(OrderCancelRejectMatcher.cxlRejResponseTo().eq(OrderCancelRequestType.ORDER_CANCEL_REQUEST))
                        .body().matches(OrderCancelRejectMatcher.cxlRejReason().eq(OrderCancelRejectReason.OTHER))
                ).awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

    private com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport waitForExecutionReportRejectOfNewOrderSingle(final NewOrderSingle newOrderSingleUM) {
        LOGGER.info("Waiting for ExecutionReport Reject from UM..." + newOrderSingleUM);
        LOGGER.info("Peak at queue: "+acceptanceContext.tradingResponseMessageQueue());
        return (com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport) Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.marketId().eq(marketId.name()))
                        .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(ExecutionReportMatcher.symbol().eq(newOrderSingleUM.body.symbol))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.REJECTED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.REJECTED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(newOrderSingleUM.body.ordType))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0.0))
                        .body().matches(ExecutionReportMatcher.securityType().eq(newOrderSingleUM.body.securityType))
                        .body().matches(ExecutionReportMatcher.settlType().eq(newOrderSingleUM.body.settlType))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(newOrderSingleUM.body.timeInForce))
                ).awaitMatchAndGetLast(20, TimeUnit.SECONDS);

    }

    private void sendOrderThenCancelWithCancelReject(final SnapshotFullRefresh snapshotFullRefreshFromUM) {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();

        // send NewOrderSingle
        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(clOrdId, snapshotFullRefreshFromUM);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);

        waitForNewOrderSingle(newOrderSingleUM);
        serverReceiveQueue.clear();

        // send OrderCancelRequest
        final OrderCancelRequest orderCancelRequestUM = orderCancelRequestUMMessage(newOrderSingleUM, clOrdId);
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequestUM);

        // send back OrderCancelReject
        final OrderCancelReject orderCancelReject = FixToDTOTestDataGenerator.orderCancelReject();
        orderCancelReject.clOrdID(orderCancelReject.clOrdID_buffer());
        orderCancelReject.clOrdID().append(orderCancelRequestUM.body.clOrdId);
        orderCancelReject.origClOrdID(orderCancelReject.origClOrdID_buffer());
        orderCancelReject.origClOrdID().append(orderCancelRequestUM.body.origClOrdId);
        serverSession.sendMessage(orderCancelReject);

        waitForOrderCancelRejectFromUM(orderCancelReject);
    }

    private com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject waitForOrderCancelRejectFromUM(final OrderCancelReject orderCancelReject) {
        LOGGER.info("Waiting for OrderCancelReject from UM..." + orderCancelReject);
        System.out.println("Peak at queue: "+acceptanceContext.tradingResponseMessageQueue());
        return (com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject) Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(OrderCancelRejectMatcher.build()
                        .body().matches(OrderCancelRejectMatcher.clOrdId().eq(orderCancelReject.clOrdID().toString()))
                        .body().matches(OrderCancelRejectMatcher.origClOrdId().eq(orderCancelReject.origClOrdID().toString()))
                        .body().matches(OrderCancelRejectMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(OrderCancelRejectMatcher.orderId().eq(orderCancelReject.orderID().toString()))
                        .body().matches(OrderCancelRejectMatcher.ordStatus().eq(OrderStatus.REJECTED))
                        .body().matches(OrderCancelRejectMatcher.cxlRejResponseTo().eq(OrderCancelRequestType.ORDER_CANCEL_REQUEST))
                        .body().matches(OrderCancelRejectMatcher.cxlRejReason().eq(OrderCancelRejectReason.OTHER))
                        .body().matches(OrderCancelRejectMatcher.text().eq(orderCancelReject.text()))
                ).awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

    private com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest waitForOrderCancelRequest(final OrderCancelRequest orderCancelRequestUM) {
        LOGGER.info("Waiting for OrderCancelRequest..." + orderCancelRequestUM.body.symbol);
        final com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest cancelRequest = (com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest)waitFor(com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelRequest.class);
        LOGGER.info("Received: " + cancelRequest);

        assertThat(cancelRequest.symbol(), is(SymbolNormaliser.toSymbol7(orderCancelRequestUM.body.symbol)));
        assertThat(cancelRequest.cFICode(), is(CFICode.SPOT));
        assertThat(cancelRequest.settlType(), is(SettlType.SPOT));
        assertThat(cancelRequest.side(), is(orderCancelRequestUM.body.side == Side.SELL ? com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.SELL : com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.BUY));
        assertThat(cancelRequest.orderQty(), is(orderCancelRequestUM.body.orderQty));
        assertThat(OrdType.asString(cancelRequest.ordType()), is(String.valueOf(orderCancelRequestUM.body.ordType)));
        assertThat(cancelRequest.timeInForce(), is(com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_CANCEL));
        return cancelRequest;
    }

    private com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle waitForNewOrderSingle(final NewOrderSingle newOrderSingleUM) {
        LOGGER.info("Waiting for NewOrderSingle..." + newOrderSingleUM.body.symbol + " clOrdId=" + newOrderSingleUM.body.clOrdId);
        final com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle newOrderSingle = (com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle)waitFor(com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.NewOrderSingle.class);
        LOGGER.info("waitForNewOrderSingle Received: " + newOrderSingle);

        assertThat(newOrderSingle.clOrdID().toString(), is(newOrderSingleUM.body.clOrdId));
        assertThat(newOrderSingle.symbol(), is(SymbolNormaliser.toSymbol7(newOrderSingleUM.body.symbol)));
        assertThat(newOrderSingle.cFICode(), is(CFICode.SPOT));
        assertThat(newOrderSingle.settlType(), is(SettlType.SPOT));
        assertThat(newOrderSingle.side(), is(newOrderSingleUM.body.side == Side.SELL ? com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.SELL : com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.BUY));
        assertThat(newOrderSingle.orderQty(), is(newOrderSingleUM.body.orderQty));
        if (newOrderSingleUM.body.ordType != OrderType.FIXING_ORDER && Venue.EBS.name().equals(newOrderSingleUM.body.marketId)) {
            assertThat("price in 5 decimal places", newOrderSingle.price().toString(), is(newOrderSingleUM.body.price + "0"));
        }
        assertThat(newOrderSingle.timeInForce(), is(com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_CANCEL));
        return newOrderSingle;
    }

    private com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport waitForExecutionReportNewOrFillFromUM(final ExecutionReport executionReport) {
        return waitForExecutionReportNewOrFillFromUM(executionReport, Double.NaN);
    }

    private com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport waitForExecutionReportNewOrFillFromUM(final ExecutionReport executionReport, final Double leaveQty) {
        LOGGER.info("Waiting for ExecutionReport from UM..." + executionReport);
        System.out.println("Peak at queue: "+acceptanceContext.tradingResponseMessageQueue());
        final ExecType execType = execType(executionReport.execType());
        final OrderStatus orderStatus = orderStatus(executionReport.ordStatus());
        final double expectedLeaveQty = leaveQty.isNaN() ? (executionReport.ordStatus() == OrdStatus.NEW ? executionReport.leavesQty() : 0.0) : leaveQty;
        return (com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport) Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(executionReport.clOrdID().toString()))
                        .body().matches(ExecutionReportMatcher.orderId().eq(executionReport.orderID().toString()))
                        .body().matches(ExecutionReportMatcher.marketId().eq(marketId.name()))
                        .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(ExecutionReportMatcher.symbol().eq(toSymbol6(executionReport.symbol())))
                        .body().matches(ExecutionReportMatcher.execType().eq(execType))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(orderStatus))
                        .body().matches(ExecutionReportMatcher.ordType().eq(OrderType.LIMIT))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(expectedLeaveQty))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.settlType().eq(Tenor.SP))
                ).awaitMatchAndGetLast(20, TimeUnit.SECONDS);
    }

    private OrderStatus orderStatus(final char ordStatus) {
        switch (ordStatus) {
            case NEW: return OrderStatus.NEW;
            case PARTIAL_FILL: return OrderStatus.PARTIALLY_FILLED;
            case FILL: return OrderStatus.FILLED;
            case CANCELED: return OrderStatus.CANCELED;
        }
        return null;
    }

    private ExecType execType(final char execType) {
        switch (execType) {
            case NEW: return ExecType.NEW;
            case TRADE: return ExecType.TRADE;
            case CANCELED: return ExecType.CANCELED;
        }
        return null;
    }

    private ExecutionReport sendExecutionReport(final Bytes clOrdID, final ExecutionReport executionReport) {
        executionReport.clOrdID(executionReport.clOrdID_buffer());
        executionReport.clOrdID().append(clOrdID);
        LOGGER.info("Sending EBS ExecutionReport.." + executionReport);
        serverSession.sendMessage(executionReport);
        return executionReport;
    }

    private TradeCaptureReport sendTradeCaptureReport(final Bytes clOrdID, final TradeCaptureReport tcrMatched) {
        tcrMatched.tradeCaptureReport_SidesGrp_1(0).clOrdID(tcrMatched.tradeCaptureReport_SidesGrp_1(0).clOrdID_buffer());
        tcrMatched.tradeCaptureReport_SidesGrp_1(0).clOrdID().append(clOrdID);
        LOGGER.info("Sending EBS TradeCaptureReport.." + tcrMatched);
        serverSession.sendMessage(tcrMatched);
        return tcrMatched;
    }

    private MarketDataSnapshotFullRefresh sendMarketDataSnapshotFullRefreshFor(final MarketDataRequest marketDataRequest) {
        final MarketDataSnapshotFullRefresh fullRefresh = FixToDTOTestDataGenerator.ebsMarketDataSnapshotFullRefresh();
        fullRefresh.mDReqID(Bytes.from(marketDataRequest.mDReqID()));
        fullRefresh.symbol(marketDataRequest.marketDataRequest_RelatedSymGrp_1(0).symbol());

        LOGGER.info("Sending MarketDataSnapshotFullRefresh..." + fullRefresh);
        serverSession.sendMessage(fullRefresh);
        return fullRefresh;
    }

    private void waitForLogon() {
        // wait for login request and reply with accept
        waitFor(Logon.class);
    }

    private void sendUserResponseLoggedInWithSymbols(final String... symbols) {
        LOGGER.info("Sending logon UserResponse..." + symbols);
        final UserResponseBuilder builder = new UserResponseBuilder().userStatus(UserStatus.LOGGED_IN);
        for (final String symbol : symbols) {
            builder.addRelatedSym(symbol, SecurityType.FXSPOT);
        }
        serverSession.sendMessage(builder.build());
    }

    private void sendUserResponseNotLoggedInPasswordChangeOldPasswordChangeRequired() {
        LOGGER.info("Sending UserResponse logged off with " + USER_STATUS_TEXT_PASSWORD_CHANGE_REQUIRED);
        final UserResponse userResponseLoggedOff = new UserResponseBuilder()
                .userStatus(UserStatus.NOT_LOGGED_IN)
                .userStatusText(USER_STATUS_TEXT_PASSWORD_CHANGE_REQUIRED)
                .build();
        serverSession.sendMessage(userResponseLoggedOff);
    }

    private void sendUserResponse(final int userStatus) {
        LOGGER.info("Sending UserResponse with UserStatus: "+ UserStatus.asString(userStatus));
        serverSession.sendMessage(new UserResponseBuilder().userStatus(userStatus).build());
    }

    private OrderCancelRequest orderCancelRequestUMMessage(final NewOrderSingle newOrderSingleUM, final String clOrdId) {
        final OrderCancelRequest orderCancelRequest = new OrderCancelRequest();

        orderCancelRequest.body.senderCompId = "GB:lg-acc";
        orderCancelRequest.body.clOrdId = clOrdId;
        orderCancelRequest.body.origClOrdId = newOrderSingleUM.body.clOrdId;
        orderCancelRequest.body.messageId = 1;
        orderCancelRequest.body.marketId = Venue.EBS.name();
        orderCancelRequest.body.ordType = newOrderSingleUM.body.ordType;
        orderCancelRequest.body.timeInForce = newOrderSingleUM.body.timeInForce;
        orderCancelRequest.body.side = newOrderSingleUM.body.side;
        orderCancelRequest.body.symbol = newOrderSingleUM.body.symbol;
        orderCancelRequest.body.securityType = newOrderSingleUM.body.securityType;
        orderCancelRequest.body.settlType = newOrderSingleUM.body.settlType;
        orderCancelRequest.body.orderQty = newOrderSingleUM.body.orderQty;
        orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
        return orderCancelRequest;
    }

    private NewOrderSingle newOrderSingleUMMessage(final String clOrdId, final SnapshotFullRefresh snapshotFullRefresh) {
        final InstrumentKey instrumentKey = InstrumentKey.of(snapshotFullRefresh.body.instrumentId);

        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = "GB:lg-acc";
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.marketId = Venue.EBS.name();
        newOrderSingle.body.ordType = OrderType.LIMIT;
        newOrderSingle.body.side = snapshotFullRefresh.entries.get(0).mdEntryType == BID ? Side.SELL : Side.BUY;
        newOrderSingle.body.symbol = instrumentKey.symbol();
        newOrderSingle.body.securityType = instrumentKey.securityType();
        newOrderSingle.body.settlType = instrumentKey.tenor();
        newOrderSingle.body.price = snapshotFullRefresh.entries.get(0).mdEntryPx;
        newOrderSingle.body.orderQty = snapshotFullRefresh.entries.get(0).mdEntrySize;
        newOrderSingle.body.timeInForce = TimeInForce.GTC;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private String newClOrdId() {
        return "" + acceptanceContext.tradingMessageIdGenerator().get();
    }

    private void waitForUserRequestLogonUser() {
        LOGGER.info("Waiting for UserRequest...");
        final UserRequest userRequest = waitForUserRequest(LOG_ON_USER);
        System.out.println(userRequest);
        assertThat(userRequest.noUserData(), is(7L));
        boolean foundAllowFixingInfo = false;
        for (int i = 0; i < userRequest.noUserData(); i++) {
            final CustUserData_UserDataGrp_1 grp = userRequest.custUserData_UserDataGrp_1(i);
            foundAllowFixingInfo = grp.userDataName().equals("AllowFixingInfo") && grp.userDataValue().equals("Y");
            if (foundAllowFixingInfo) break;
        }
        assertTrue(foundAllowFixingInfo);
        serverReceiveQueue.clear();
    }

    private String waitForUserRequestPasswordChange() {
        LOGGER.info("Waiting for UserRequest password change request...");
        final UserRequest passwordChangeUserRequest = waitForUserRequest(CHANGE_PASSWORD_FOR_USER);
        LOGGER.info("Received: " + passwordChangeUserRequest);

        assertThat(passwordChangeUserRequest.userRequestID(), is(DEFAULT_USER_REQUEST_ID));
        assertThat(passwordChangeUserRequest.username(), is(USERNAME));
        assertThat(passwordChangeUserRequest.password(), is(PASSWORD));
        assertTrue(passwordChangeUserRequest.newPassword() + " password should be Username follow digits",
                Pattern.matches(USERNAME +"[0-9]{10,}", passwordChangeUserRequest.newPassword()));
        return passwordChangeUserRequest.newPassword();
    }

    private UserRequest waitForUserRequest(final int userRequestType) {
        return (UserRequest) waitFor(m -> m instanceof UserRequest && ((UserRequest)m).userRequestType() == (long)userRequestType);
    }

    private SnapshotFullRefresh waitForSnapshotFullRefreshFromUMWithKey(final InstrumentKey instrumentKey) {
        LOGGER.info("Waiting for MarketDataSnapshotFullRefresh..." + instrumentKey);
        return (SnapshotFullRefresh)Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private SnapshotFullRefresh waitForSnapshotFullRefreshFromUM(final InstrumentKey instrumentKey) {
        LOGGER.info("Waiting for MarketDataSnapshotFullRefresh..." + instrumentKey);
        return (SnapshotFullRefresh)Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                        .entries().countEquals(12)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.3333))
                        .entries().atIndex(7).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(7).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.33355))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private IncrementalRefresh waitForIncrementalRefreshFromUMWithKey(final InstrumentKey instrumentKey) {
        LOGGER.info("Waiting for MarketDataIncrementalRefresh..." + instrumentKey);
        LOGGER.info("Peak at queue: {} {}", acceptanceContext.pricingMessageQueue().size(), acceptanceContext.pricingMessageQueue());
        return (IncrementalRefresh)Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.marketId().eq(marketId))
                        .body().matches(IncrementalRefreshMatcher.senderCompId().eq("GB:lg-ebs"))
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private MarketDataRequest waitForMarketDataRequest(final String symbol, final String cFICode, final String settlType) {
        LOGGER.info("Waiting for MarketDataRequest..." + symbol);
        final MarketDataRequest marketDataRequest = (MarketDataRequest) TestUtils.waitFor(serverReceiveQueue, (m) -> m instanceof MarketDataRequest && ((MarketDataRequest)m).marketDataRequest_RelatedSymGrp_1(0).symbol().equals(symbol), 2, "Waiting for MarketDataRequest "+symbol);
        LOGGER.info("Received: " + marketDataRequest);

        assertThat(marketDataRequest.noRelatedSym(), is(1L));
        assertThat(marketDataRequest.marketDataRequest_RelatedSymGrp_1(0).symbol(), is(symbol));
        assertThat(marketDataRequest.marketDataRequest_RelatedSymGrp_1(0).cFICode(), is(cFICode));
        assertThat(marketDataRequest.marketDataRequest_RelatedSymGrp_1(0).settlType(), is(settlType));
        return marketDataRequest;
    }

    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass, final int timeout, final String text) {
        return waitFor(m -> messageClass.isInstance(m), timeout, text);
    }

    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass, final String text) {
        return waitFor(messageClass, 60, text);
    }

    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass) {
        return waitFor(messageClass, "Waiting for "+messageClass.getSimpleName()+"...");
    }

    private StandardHeaderTrailer waitFor(final Predicate<? super Object> predicate) {
        return waitFor(predicate, 5, "Waiting for..."+predicate);
    }

    private StandardHeaderTrailer waitFor(final Predicate<? super Object> predicate, final int timeout, final String text) {
        return TestUtils.waitFor(serverReceiveQueue, predicate, timeout, text);
    }

    private StandardHeaderTrailer parse(final String fromFixMessage, final StandardHeaderTrailer toDTOMessage) {
        fixToDTO.parse(Bytes.from(fromFixMessage), sht -> sht.copyTo(toDTOMessage));
        return toDTOMessage;
    }

    private String assertNewPasswordSavedToFile(final String newPassword) throws IOException {
        final Properties passwordPropertiesFile = loadPasswordProperties();
        System.out.println("assertNewPasswordSavedToFile newPassword="+ newPassword + ",passwordPropertiesFile="+ passwordPropertiesFile);
        final String passwordOnFile = passwordPropertiesFile.getProperty(appName+".fix.user.request.password");
        assertThat(newPassword, is(passwordOnFile));
        return passwordOnFile;
    }

    private Properties loadPasswordProperties() throws IOException {
        final String passwordPropertiesFileName = System.getProperty("ebs.fix.user.password.file", null);
        assertNotNull("Can't find passwordPropertiesFileName from sysProp ebs.fix.user.password.file", passwordPropertiesFileName);

        final File passwordPropertiesFile = new File(passwordPropertiesFileName);

        LOGGER.info("Waiting for password file to be saved...:" + passwordPropertiesFile);
        if (!passwordPropertiesFile.exists()) {
            Jvm.pause(10);
            assertTrue(TestUtils.waitFor(passwordPropertiesFile::exists, 5_000));
        }

        final Properties properties = new Properties();
        if (passwordPropertiesFile.exists()) {
            try (final FileInputStream inputStream = new FileInputStream(passwordPropertiesFile)) {
                properties.load(inputStream);
            }
        }
        return properties;
    }

    private void startServerSide() throws Exception {
        cfg = Marshallable.fromFile("fix-ebs-acceptor.yaml");

        final FixSessionCfg sessionCfg = cfg.fixSessionCfgs().iterator().next();
        assertEquals(sessionCfg.name(), "SERVER");
        sessionCfg.fixVersion(FixVersion.V4_4);
        sessionCfg.fileStorePath(fixStorePath);
        sessionCfg.socketAcceptorHostPort(HOST + ":" + port);
        sessionCfg.targetCompID(TARGET_COMP_ID);
        sessionCfg.senderCompID(senderCompId);
        sessionCfg.messageNotifier(new TestMessageNotifier());

        engine = new ChronicleFixEngine(sessionCfg);
        serverSession = engine.getHandler(SessionID.create(sessionCfg));
        tcpSession = new TcpSession(sessionCfg);

        serverReceiveQueue = ((TestMessageNotifier) serverSession.messageNotifier()).queue();
    }
}
