package com.anz.axle.direct.performance;

import com.anz.axle.direct.performance.metrics.BasicStats;
import com.anz.axle.direct.performance.metrics.Count;
import com.anz.axle.direct.performance.metrics.Named;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.axle.direct.performance.metrics.Rates;
import com.google.common.collect.Iterables;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.NumberFormat;
import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class LoggingMetricReporter implements MetricReporter {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingMetricReporter.class);
    private final NumberFormat numberFormat;
    private final StringBuilder metricsReport = new StringBuilder();

    public LoggingMetricReporter() {
        numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setGroupingUsed(true);
        numberFormat.setMaximumFractionDigits(0);
        numberFormat.setMinimumFractionDigits(0);
    }

    public static final class Max<T extends Comparable<T>> {
        private T max;

        private Max(final T initialValue) {
            this.max = initialValue;
        }

        public static <T extends Comparable<T>> Max<T> startWith(final T initialValue) {
            return new Max<>(initialValue);
        }

        public void include(final T newValue) {
            if (newValue.compareTo(max) > 0) {
                max = newValue;
            }
        }

        public T get() {
            return max;
        }
    }

    public Integer getLargestField(Iterable<String>... fieldNames) {
        final Max<Integer> largestField = Max.startWith(1);
        for (final String s : Iterables.concat(fieldNames)) {
            largestField.include(s.length());
        }
        return largestField.get();
    }

    @Override
    public void appendCounts(final Collection<Count> counters) {
        metricsReport.append("\nCounts\n");
        final Integer largestFieldSize = Math.max(1, getLargestField(counters));
        for (final Count count : counters) {
            metricsReport.append(String.format("%-" + largestFieldSize + "s\t%8d\n", count.getName(), count.getCount()));
        }
    }

    private int getLargestField(final Iterable<? extends Named> namedMetrics) {
        return getLargestField(StreamSupport.stream(namedMetrics.spliterator(), false).map(counter -> counter.getName()).collect(Collectors.toList()));
    }

    @Override
    public void appendBasicStats(final Collection<BasicStats> basicStatsList) {
        final Integer largestFieldSize = getLargestField(basicStatsList);
        metricsReport.append(String.format("\n%-" + largestFieldSize + "s\tMean\n", "BasicStats"));
        for (final BasicStats basicStats : basicStatsList) {
            metricsReport.append(String.format("%-" + largestFieldSize + "s\t%.2f\n", basicStats.getName(), basicStats.getMean()));
        }
    }

    public StringBuilder format(final Integer largestFieldSize,
                                final String name,
                                final Object p00,
                                final Object p25,
                                final String p50,
                                final String p75,
                                final String p95,
                                final String p98,
                                final String p99,
                                final String p999,
                                final String p100,
                                final String count) {
        return metricsReport.append(String.format("%-" + largestFieldSize + "s %13s | %13s | %13s | %13s | %13s | %13s | %13s | %13s | %13s | %13s\n",
                name,
                p00,
                p25,
                p50,
                p75,
                p95,
                p98,
                p99,
                p999,
                p100,
                count));
    }

    @Override
    public void appendHistograms(final Collection<Percentiles> percentilesList) {
        metricsReport.append("\n");
        final Integer largestFieldSize = getLargestField(percentilesList);
        format(largestFieldSize, "Histograms", "0%", "25%", "50%", "75%", "95%", "98%", "99%", "99.9%", "100%", "samples");

        for (final Percentiles percentiles : percentilesList) {
            if (percentiles.getCount() == 0) {
                continue;
            }
            final String name = percentiles.getName();
            format(largestFieldSize, name,
                    numberFormat.format(percentiles.getPercentile(0.0)),
                    numberFormat.format(percentiles.getPercentile(25.0)),
                    numberFormat.format(percentiles.getPercentile(50.0)),
                    numberFormat.format(percentiles.getPercentile(75.0)),
                    numberFormat.format(percentiles.getPercentile(95.0)),
                    numberFormat.format(percentiles.getPercentile(98.0)),
                    numberFormat.format(percentiles.getPercentile(99.0)),
                    numberFormat.format(percentiles.getPercentile(99.9)),
                    numberFormat.format(percentiles.getPercentile(100.0)),
                    numberFormat.format(percentiles.getCount()));
        }
    }

    @Override
    public void appendRates(final Collection<Rates> ratesList) {
        metricsReport.append("\n");
        final Integer largestFieldSize = getLargestField(ratesList);
        metricsReport.append(String.format("%-" + largestFieldSize + "s\t%8s\t%8s\t%8s\t%8s\t%8s\n", "Rates", "10 sec", "1 min", "5 min", "15 min", "samples"));
        for (final Rates rates : ratesList) {
            metricsReport.append(String.format("%-" + largestFieldSize + "s\t%8.2f/s\t%8.2f/s\t%8.2f/s\t%8.2f/s\t%8d\n", rates.getName(), rates.getTenSecondRate(), rates.getOneMinuteRate(), rates.getFiveMinuteRate(), rates.getFifteenMinuteRate(), rates.getCount()));
        }
    }

    @Override
    public void beginReports() {
        metricsReport.setLength(0);
    }

    @Override
    public void endReports() {
        LOGGER.info("Test run metrics:\n{}\n", metricsReport);
    }

}
