package software.chronicle.fix;

import net.openhft.chronicle.core.Mocker;
import net.openhft.chronicle.core.time.SystemTimeProvider;
import software.chronicle.fix.cfg.ConnectionType;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.FixSessionProbes;
import software.chronicle.fix.staticcode.FixVersion;
import software.chronicle.fix.staticcode.context.DynamicTimestampResolutionFixSessionContext;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.parsers.MessageParserBase;
import software.chronicle.fix.tools.ReadStatCollectingProbes;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.TimeUnit;

public class Endpoint {
    public static void main(String[] args) throws Exception {
        String hostPort = args[0];
        ConnectionType connectionType = ConnectionType.valueOf(args[1]);
        String senderCompID = args[2];
        String targetCompID = args[3];
        FixVersion fixVersion = (args.length > 4) ? FixVersion.valueOf(args[4]) : FixVersion.V4_2;
        String senderSubId = (args.length > 5) ? args[5] : null;

        MessageParserBase messageParser = new MessageParser();
        TimeUnit internalTimeUnit = messageParser.coreFieldParser().internalTimeUnit();
        FixSessionContext sessionContext = new DynamicTimestampResolutionFixSessionContext(SystemTimeProvider.INSTANCE, internalTimeUnit, internalTimeUnit);

        MessageNotifier messageNotifier = Mocker.ignored(MessageNotifier.class);
        MessageGenerator messageGenerator = new MessageGenerator((char) 0, sessionContext);
        FixSessionProbes probes = null;//xxxnew ReadStatCollectingProbes(messageGenerator.internalTimeUnit(), 1000);
        FixSessionCfg sessionCfg = software.chronicle.fix.tools.Endpoint.createSessionCfg(hostPort,
                senderCompID, senderSubId, targetCompID, connectionType,
                messageParser, messageNotifier, messageGenerator, probes);
        sessionCfg.fixVersion(fixVersion);

        //resetOnLogon???

        new software.chronicle.fix.tools.Endpoint(sessionCfg).start();
    }
}
