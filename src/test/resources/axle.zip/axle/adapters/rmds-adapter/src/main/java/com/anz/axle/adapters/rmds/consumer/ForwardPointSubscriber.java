package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.adapters.rmds.consumer.filtering.MaturityFilter;
import com.anz.axle.adapters.rmds.consumer.pricing.Curve;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.common.util.Decision;
import com.anz.axle.common.util.Maps;
import com.anz.axle.common.util.function.Consumer;
import com.anz.axle.datafabric.client.config.GeneralConfigDAO;
import com.anz.axle.datafabric.client.pricing.ForwardPointsQuotePageDAO;
import com.anz.axle.datafabric.common.EntityFactory;
import com.anz.axle.datafabric.domain.trading.EntitySequenceGenerator;
import com.anz.axle.datafabric.domain.trading.EntitySequenceType;
import com.anz.axle.perf.PerformanceService;
import com.anz.axle.perf.StopWatch;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.markets.adapters.trep.Item;
import com.anz.markets.adapters.trep.consumer.AbstractMarketDataSubscriber;
import com.google.common.base.Optional;
import com.reuters.rfa.common.Handle;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * @author winstonr
 */
public class ForwardPointSubscriber extends AbstractMarketDataSubscriber<Item> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ForwardPointSubscriber.class);

    private final ConcurrentMap<String, Curve> curves = new ConcurrentHashMap<String, Curve>();

    /** Calculate and publish TODAY/TOM tenors? */
    private boolean preSpotCalculationEnabled = true;

    @Autowired
    private PerformanceService performanceService;

    @Autowired
    private ForwardPointsQuotePageDAO forwardPointsQuotePageDAO;

    @Autowired
    private GeneralConfigDAO generalConfigDAO;

    @Autowired
    protected EntityFactory entityFactory;

    @Autowired
    private MaturityFilter maturityFilter;

    @Autowired
    private ForwardPointsQuotePageFactory forwardPointsQuotePageFactory;

    private boolean tenorDefaultToBroken;

    /**
     * The sequence generator used to set the forward points quote page versions.
     */
    protected EntitySequenceGenerator entitySequenceGenerator;

    @PostConstruct
    public void init() {
        super.init();
        this.entitySequenceGenerator = entityFactory.createEntitySequenceGenerator("rmds-adapter.forward-points-quote-page", EntitySequenceType.FORWARD_POINTS_QUOTE_PAGE);
    }

    public void onRefresh(final Item item) {
        LOGGER.info("Received snapshot for:" + item.getName());
        onUpdate(item);
    }

    public void onUpdate(final Item item) {
        LOGGER.info("Received update for: {}", item);
        final StopWatch stopWatch = performanceService.start();
        final D3ForwardQuote d3ForwardQuote = new D3ForwardQuote(item, tenorDefaultToBroken);
        try {
            maturityFilter.filter(d3ForwardQuote)
                    .and(processItem(d3ForwardQuote))
                    .onSuccess(new Consumer<Decision>() {
                        @Override
                        public void accept(final Decision decision) {
                            stopWatch.stop("rmds.update.success", d3ForwardQuote.trepName());
                        }
                    })
                    .onFailure(new Consumer<Decision>() {
                        @Override
                        public void accept(final Decision decision) {
                            stopWatch.stop(decision.reason(), d3ForwardQuote.trepName());
                        }
                    });
        } catch (final Exception t) {
            LOGGER.error("Caught exception processing item {}", d3ForwardQuote, t);
            stopWatch.stop("rmds.update.exception", d3ForwardQuote.trepName());
        }
    }

    private Decision processItem(final D3ForwardQuote d3ForwardQuote) {
        final Optional<ForwardPointsQuotePage> optionalForwardPointsQuotePage = forwardPointsQuotePageFactory.forwardPointsAndWholesaleSpotForwardPointQuotePageFrom(d3ForwardQuote);
        if (optionalForwardPointsQuotePage.isPresent()) {
            final ForwardPointsQuotePage forwardPointsQuotePage = optionalForwardPointsQuotePage.get();
            final boolean publishTrepSpotQuotes = shouldPublishTrepSpotQuotes();
            if (forwardPointsQuotePage.getTenor() == Tenor.SPOT) {
                handleSpotForwardPointsQuotePage(forwardPointsQuotePage, publishTrepSpotQuotes);
            } else {
                handleNonSpotForwardPointsQuotePage(d3ForwardQuote, forwardPointsQuotePage, publishTrepSpotQuotes);
            }
            return Decision.yes();
        } else {
            return Decision.no("rmds.update.fail");
        }
    }

    private void handleNonSpotForwardPointsQuotePage(final D3ForwardQuote d3ForwardQuote,
                                                     final ForwardPointsQuotePage forwardPointsQuotePage,
                                                     final boolean publishTrepSpotQuotes) {
        final String symbol = forwardPointsQuotePage.getSymbol();
        final LocalDate referenceSpotDate = forwardPointsQuotePage.getReferenceSpotDate();
        publishPage(forwardPointsQuotePage);
        addToCurveCache(forwardPointsQuotePage);

        if (createOwnSpotQuote(symbol, publishTrepSpotQuotes)) {
            publishPage(ForwardPointsQuotePageFactory.spotTenorForwardPointsQuotePageFrom(d3ForwardQuote, referenceSpotDate));
        }
    }

    private void handleSpotForwardPointsQuotePage(final ForwardPointsQuotePage forwardPointsQuotePage,
                                                  final boolean publishTrepSpotQuotes) {
        addToCurveCache(forwardPointsQuotePage);
        if (publishTrepSpotQuotes) {
            publishPage(forwardPointsQuotePage);
        }
    }

    private boolean createOwnSpotQuote(final String symbol,
                                       final boolean publishTrepSpotQuotes) {
        return !publishTrepSpotQuotes || !curveFor(symbol).hasPointFor(Tenor.SPOT);
    }

    private boolean shouldPublishTrepSpotQuotes() {
        return generalConfigDAO.shouldPublishTrepSpotForwardPoint();
    }

    private void publishPage(final ForwardPointsQuotePage forwardPointsQuotePage) {
        forwardPointsQuotePage.setVersion(EntitySequenceGenerator.next(entitySequenceGenerator));
        LOGGER.info("Saving forward point quote page to datafabric [{}]", forwardPointsQuotePage);
        forwardPointsQuotePageDAO.save(forwardPointsQuotePage);
    }

    private void addToCurveCache(final ForwardPointsQuotePage forwardPointsQuotePage) {
        final Curve curve = curveFor(forwardPointsQuotePage.getSymbol());

        LOGGER.debug("Adding forward point to cache: {}", forwardPointsQuotePage);
        curve.addPoint(forwardPointsQuotePage);

        if (forwardPointsQuotePage.getTenor().isPreSpot() && isPreSpotCalculationEnabled()) {
            LOGGER.debug("Tenor {} is pre-spot, recalculating pre-spot ladder", forwardPointsQuotePage.getTenor());
            publishPreSpotTenors(curve);
        }
    }

    private Curve curveFor(final String symbol) {
        return Maps.computeIfAbsent(curves, symbol, Curve.NEW);
    }

    /**
     * Checks that
     *
     * @param curve
     */
    private void publishPreSpotTenors(final Curve curve) {
        final List<ForwardPointsQuotePage> preSpots = curve.calculatePreSpotTenors();
        for (final ForwardPointsQuotePage page : preSpots) {
            publishPage(page);
        }
    }

    @Override
    public void onError(final String name) {
        LOGGER.error("Error in subscription for item: {}", name);
    }

    /**
     * Return the current cache of forward curves - for testing
     *
     * @return
     */
    ConcurrentMap<String, Curve> getCurves() {
        return curves;
    }

    void setForwardPointsQuotePageDAO(final ForwardPointsQuotePageDAO forwardPointsQuotePageDAO) {
        this.forwardPointsQuotePageDAO = forwardPointsQuotePageDAO;
    }

    public void setPreSpotCalculationEnabled(final boolean preSpotCalculationEnabled) {
        this.preSpotCalculationEnabled = preSpotCalculationEnabled;
    }

    public void setForwardPointsQuotePageFactory(final ForwardPointsQuotePageFactory forwardPointsQuotePageFactory) {
        this.forwardPointsQuotePageFactory = forwardPointsQuotePageFactory;
    }

    public void setPerformanceService(final PerformanceService performanceService) {
        this.performanceService = performanceService;
    }

    public void setMaturityFilter(final MaturityFilter maturityFilter) {
        this.maturityFilter = maturityFilter;
    }

    public void setGeneralConfigDAO(final GeneralConfigDAO generalConfigDAO) {
        this.generalConfigDAO = generalConfigDAO;
    }

    public boolean isPreSpotCalculationEnabled() {
        return preSpotCalculationEnabled;
    }

    public void setTenorDefaultToBroken(final boolean tenorDefaultToBroken) {
        this.tenorDefaultToBroken = tenorDefaultToBroken;
    }

    @Override
    public void onStreamClosed(final Handle handle) {
    }

    @Override
    public void onConnectionUp() {
    }

    @Override
    public void onConnectionDown() {
    }

    @Override
    public void onStreamClosed(final Object context, final Handle handle) {
    }
}
