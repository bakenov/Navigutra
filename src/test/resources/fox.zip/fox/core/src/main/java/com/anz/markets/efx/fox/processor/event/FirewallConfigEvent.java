package com.anz.markets.efx.fox.processor.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.sbe.FirewallConfigSbeDecoder;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class FirewallConfigEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(FirewallConfigEvent.class);

    private final EventContext eventContext;
    private Firewall inboundFirewalls;
    private final StringBuilder stringBuilder = new StringBuilder();

    private final FirewallConfigSbeDecoder firewallConfigDecoder = new FirewallConfigSbeDecoder();

    public FirewallConfigEvent(final EventContext eventContext,
                               final Firewall inboundFirewalls) {
        this.eventContext = Objects.requireNonNull(eventContext);
        this.inboundFirewalls = Objects.requireNonNull(inboundFirewalls);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!firewallConfigDecoder.wrap(message)) return false;
        inboundFirewalls.applyFirewallConfigRuleResponse(eventContext, firewallConfigDecoder);
        logMessage();
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        firewallConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying config FC: {}", stringBuilder);
    }
}
