package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.UserGroupsDecoder;
import com.anz.markets.efx.ngaro.codec.EnumSetDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;

public final class SbeUserGroupSetDecoder implements EnumerableSetDecoder<UserGroup> {

    private final EnumerableSetDecoder<UserGroup> delegate;

    public SbeUserGroupSetDecoder(final Supplier<UserGroupsDecoder> decoderSupplier) {
        Objects.requireNonNull(decoderSupplier);
        this.delegate = new EnumSetDecoder<>(UserGroup::length, UserGroup::valueByOrdinal, userGroup -> Enums.userGroup(userGroup, decoderSupplier.get()), () -> false);
    }

    @Override
    public boolean containsAny() {
        return delegate.containsAny();
    }

    @Override
    public boolean contains(final UserGroup userGroup) {
        return delegate.contains(userGroup);
    }

    @Override
    public void decodeTo(final Consumer<? super UserGroup> consumer) {
        delegate.decodeTo(consumer);
    }

    @Override
    public void decodeTo(final BiConsumer<? super UserGroup, ? super Boolean> consumer) {
        delegate.decodeTo(consumer);
    }

    @Override
    public <S extends Set<? super UserGroup>> S decodeTo(final S target) {
        return delegate.decodeTo(target);
    }
}
