package com.anz.axle.direct.performance;

import org.joda.time.Duration;

public interface ProgressReporter {
    void beginTest(String testName,
                   Duration expectedDuration);

    void progress(String testName,
                  int step,
                  int totalSteps);

    void completed(String testName);
}
