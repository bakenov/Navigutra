package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.RawBytes;
import com.anz.markets.prophet.status.Context;

import java.util.function.Consumer;

public class ChronicleByteReader implements ChronicleObjectReader {
    private final Consumer<RawBytes> consumer;
    private final RawBytes rawBytes = new RawBytes();

    public ChronicleByteReader(final Consumer<RawBytes> consumer) {
        this.consumer = consumer;
    }

    @Override
    public void processEntity(ProphetBytes bytes, MessageType messageType) {
        rawBytes.setMessageType(messageType).readMarshallable(bytes);
        Context.overrideStartTimeStamp();
        consumer.accept(rawBytes);
    }
}
