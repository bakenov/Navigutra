package com.anz.axle.acc.job;

import com.anz.axle.common.domain.CounterpartyCreditUtilisations;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public interface CurrentCounterpartyCreditUtilisationJobListener {
    void listen(CounterpartyCreditUtilisations utilisations);
}
