package com.anz.markets.prophet.atest.framework.config;

import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.prophet.atest.framework.impl.TestUmConnection;
import com.anz.markets.prophet.config.app.StarfishOutConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(StarfishOutConfig.class)
public class StarOutAtestConfig {
    @Bean(destroyMethod = "close")
    public Connection connection() {
        return new TestUmConnection();
    }
}