package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.impl.FilterEnabledConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.marketdata.MarketDataFilter;

import java.util.List;

public class FilterEnabledConfigs {
    private final EnumObjMap<MarketDataFilterType, EnumObjTable<Instrument, Market, FilterEnabledConfig>> filtersEnabled = new EnumObjMap<>(MarketDataFilterType.class);

    public FilterEnabledConfigs(final List<FilterEnabledConfig> filterEnabledConfigs) {
        filtersEnabled.clear();
        filterEnabledConfigs.forEach(fec -> {
            filtersEnabled.computeIfAbsent(fec.filtertype, s -> new EnumObjTable<>(Instrument.class, Market.class)).put(fec.instrument, fec.market, fec);
        });
    }

    public EnumObjTable<Instrument, Market, FilterEnabledConfig> filterEnabledConfigs(final MarketDataFilter<?> filter) {
        return filtersEnabled.computeIfAbsent(filter.getMarketDataFilterType(), s -> new EnumObjTable<>(Instrument.class, Market.class));
    }

    public static boolean enabled(final EnumObjTable<Instrument, Market, FilterEnabledConfig> filterEnabledConfigs,
                                  final Instrument instrument,
                                  final Market market) {
        final FilterEnabledConfig fec = filterEnabledConfigs.get(instrument, market);
        return fec == null || fec.enabled;
    }
}
