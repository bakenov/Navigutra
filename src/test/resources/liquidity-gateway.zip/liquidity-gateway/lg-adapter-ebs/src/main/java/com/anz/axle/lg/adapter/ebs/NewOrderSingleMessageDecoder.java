package com.anz.axle.lg.adapter.ebs;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.sbe.NewOrderSingleSbeDecoder;

import java.util.Objects;
import java.util.function.Consumer;

public class NewOrderSingleMessageDecoder implements MessageDecoder<SbeMessage> {
    private final NewOrderSingleSbeDecoder newOrderSingleSbeDecoder = new NewOrderSingleSbeDecoder();
    private final Consumer<NewOrderSingleDecoder> decoderConsumer;

    public NewOrderSingleMessageDecoder(final Consumer<NewOrderSingleDecoder> decoderConsumer) {
        this.decoderConsumer = Objects.requireNonNull(decoderConsumer);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!newOrderSingleSbeDecoder.wrap(message)) return false;
        decoderConsumer.accept(newOrderSingleSbeDecoder);
        return true;
    }
}
