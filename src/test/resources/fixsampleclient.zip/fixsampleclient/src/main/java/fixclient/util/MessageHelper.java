// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient.util;

import java.util.Iterator;

import com.thomsonreuters.trfx.referenceclients.fixclient.QuickFixConfig;
import quickfix.DataDictionary;
import quickfix.Field;
import quickfix.FieldMap;
import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.field.ApplVerID;

/**
 */
public class MessageHelper
{
    /**
     * @param message
     * @param sessionID
     * @return message
     * @throws FieldNotFound
     */
    public static String convertToString(final Message message,
            final SessionID sessionID) throws FieldNotFound
    {

        String appVerId = null;
        try
        {
            appVerId = message.getHeader().getString(ApplVerID.FIELD);
        }
        catch (final FieldNotFound e)
        {
            // ignore we take care of it below
        }

        if (appVerId == null || appVerId.trim().equals(""))
        {
            appVerId = QuickFixConfig.getDefaultApplVerID();
        }
        final DataDictionary dictionary = Session.lookupSession(sessionID)
                .getDataDictionaryProvider()
                .getApplicationDataDictionary(new ApplVerID(appVerId));

        final StringBuilder result = new StringBuilder(2048);

        appendFieldMap(result, message.getHeader(), dictionary);
        appendFieldMap(result, message, dictionary);
        appendFieldMap(result, message.getTrailer(), dictionary);

        // Trim trailing ", " and return
        return result.length() > 0
                ? result.substring(0, result.length() - 2)
                : "";
    }

    private static void appendFieldMap(final StringBuilder output,
            final FieldMap fieldMap,
            final DataDictionary dictionary) throws FieldNotFound
    {
        Iterator<?> iterator = fieldMap.iterator();
        while (iterator.hasNext())
        {
            final Field<?> field = (Field<?>) iterator.next();
            output.append(dictionary.getFieldName(field.getTag()))
                    .append("(")
                    .append(field.getTag())
                    .append(")=")
                    .append(fieldMap.getString(field.getTag()))
                    .append(", ");
        }

        iterator = fieldMap.groupKeyIterator();
        while (iterator.hasNext())
        {
            final int groupCountTag = ((Integer) iterator.next()).intValue();
            output.append(dictionary.getFieldName(groupCountTag))
                    .append("(")
                    .append(groupCountTag)
                    .append(")=")
                    .append(fieldMap.getInt(groupCountTag))
                    .append(", ");

            final Group group = new Group(groupCountTag, 0);
            for (int i = 1; fieldMap.hasGroup(i, groupCountTag); i++)
            {
                fieldMap.getGroup(i, group);
                appendFieldMap(output, group, dictionary);
            }
        }
    }
}
