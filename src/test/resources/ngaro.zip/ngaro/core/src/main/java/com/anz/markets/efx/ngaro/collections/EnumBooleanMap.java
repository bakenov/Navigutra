package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.Arrays;

/**
 * To preserve the semantics of a map, a byte is used as a holder of values
 * <p>
 * 0 - false
 * 1 - true
 * 2 - EMPTY_BYTE
 */
public class EnumBooleanMap<K extends Enum<K>> {
    private final static byte FALSE_BYTE = (byte) 0;
    private final static byte TRUE_BYTE = (byte) 1;
    private final static byte EMPTY_BYTE = (byte) 2;
    private final K[] keyUniverse;
    private final boolean defaultValue;
    private final byte[] values;
    private int size;
    private final int capacity;
    private Class<K> keyType;

    public EnumBooleanMap(final Class<K> keyType) {
        this(keyType, false);
    }

    public EnumBooleanMap(final Class<K> keyType, final boolean defaultValue) {
        this.keyType = keyType;
        this.keyUniverse = keyType.getEnumConstants();
        this.defaultValue = defaultValue;
        this.capacity = keyUniverse.length;
        this.values = new byte[capacity];
        for (int i = 0; i < capacity; i++) {
            this.values[i] = EMPTY_BYTE;
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

     public boolean containsKey(final K key) {
        return !isEmptyValue(values[key.ordinal()]);
    }

    public boolean get(final K key) {
        final byte entry = values[key.ordinal()];
        return byteToBoolean(entry);
    }

    @NotGcFriendly // Use set for GC friendly insertions to the map
    public Boolean put(final K key, final boolean value) {
        final byte entry = values[key.ordinal()];
        set(key, value);
        return entry == EMPTY_BYTE ? null : byteToBoolean(entry);
    }

    public void set(final K key, final boolean value) {
        final byte newValue = booleanToByte(value);
        if (!containsKey(key)) {
            size++;
        }
        values[key.ordinal()] = newValue;
    }

    public boolean remove(final K key) {
        if (containsKey(key)) {
            values[key.ordinal()] = EMPTY_BYTE;
            size--;
            return true;
        }
        return false;
    }

    public void clear() {
        for (int i = 0; i < capacity; i++) {
            values[i] = EMPTY_BYTE;
        }
        size = 0;
    }

    public void forEach(ObjBooleanConsumer<? super K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                final byte valueInByte = values[i];
                if (!isEmptyValue(valueInByte)) {
                    action.accept(this.keyUniverse[i], byteToBoolean(valueInByte));
                }
            }
        }
    }

    public Class<K> getKeyType() {
        return keyType;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        final EnumBooleanMap<?> that = (EnumBooleanMap<?>) o;
        return size == that.size && Arrays.equals(this.values, ((EnumBooleanMap<?>) o).values);
    }

    private byte booleanToByte(final boolean booleanValue) {
        return booleanValue ? TRUE_BYTE : FALSE_BYTE;
    }

    private boolean byteToBoolean(final byte booleanInByte) {
        return booleanInByte == EMPTY_BYTE ? defaultValue : booleanInByte == TRUE_BYTE;
    }

    private static boolean isEmptyValue(final byte value) {
        return value == EMPTY_BYTE;
    }

}
