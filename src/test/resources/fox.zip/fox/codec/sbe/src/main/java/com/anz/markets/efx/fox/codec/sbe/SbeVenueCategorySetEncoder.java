package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueCategoriesEncoder;
import com.anz.markets.efx.ngaro.codec.EnumSetEncoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;

public final class SbeVenueCategorySetEncoder<E> implements EnumerableSetEncoder<E, VenueCategory> {

    private final EnumerableSetEncoder<E, VenueCategory> delegate;

    public SbeVenueCategorySetEncoder(final E enclosingEncoder, final Supplier<VenueCategoriesEncoder> encoderSupplier) {
        Objects.requireNonNull(encoderSupplier);
        this.delegate = new EnumSetEncoder<>(enclosingEncoder, VenueCategory::length, VenueCategory::valueByOrdinal,
                venueCategory -> Enums.venueCategory(venueCategory, encoderSupplier.get(), true),
                () -> encoderSupplier.get().clear()
        );
    }

    @Override
    public E clear() {
        return delegate.clear();
    }

    @Override
    public E add(final VenueCategory value) {
        return delegate.add(value);
    }

    @Override
    public E addAll(final Set<? extends VenueCategory> values) {
        return delegate.addAll(values);
    }

    @Override
    public <S> E addAll(final S source, final BiPredicate<? super S, ? super VenueCategory> reader) {
        return delegate.addAll(source, reader);
    }
}
