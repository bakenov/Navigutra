package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

import java.util.Objects;


public class TimeInForceParentOrderValidator implements ParentOrderValidator {
    private final TimeInForce[] allowedTimeInForce;
    private final ErrorHandler errorHandler;

    public TimeInForceParentOrderValidator(final ErrorHandler handler,
                                           final TimeInForce... tif) {
        allowedTimeInForce = Objects.requireNonNull(tif);
        errorHandler = Objects.requireNonNull(handler);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
        final TimeInForce orderTif =  parentOrderDecoder.body().timeInForce();

        for(TimeInForce validTif : allowedTimeInForce) {
            if (orderTif.equals(validTif))
                return true;
        }

        errorHandler.onError(OrderTextMessage.INVALID_TIMEINFORCE.getText(), parentOrderDecoder, commandContext);
        return false;
    }

}
