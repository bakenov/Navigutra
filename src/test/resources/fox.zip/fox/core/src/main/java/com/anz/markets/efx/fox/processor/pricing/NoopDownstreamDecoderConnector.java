package com.anz.markets.efx.fox.processor.pricing;

import com.anz.markets.efx.pricing.codec.snapshot.change.BookChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.connect.DownstreamDecoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.connect.ForwardingMode;

public class NoopDownstreamDecoderConnector implements DownstreamDecoderConnector {
    private final BookChangedListener snapshotFullRefreshListener;
    private final BookChangedListener incrementalRefreshListener;

    public NoopDownstreamDecoderConnector() {
        snapshotFullRefreshListener = new NoopBookChangedListener();
        incrementalRefreshListener = new NoopBookChangedListener();
    }

    @Override
    public ForwardingMode forwardingMode() {
        return ForwardingMode.SNAPSHOT_ONLY;
    }

    @Override
    public BookChangedListener snapshotFullRefreshListener() {
        return snapshotFullRefreshListener;
    }

    @Override
    public BookChangedListener incrementalRefreshListener() {
        return incrementalRefreshListener;
    }
}
