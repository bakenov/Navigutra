package com.anz.markets.efx.ngaro.core;

import java.util.ArrayDeque;
import java.util.Objects;
import java.util.Queue;
import java.util.function.Consumer;
import java.util.function.Function;

public class ObjectPool<T> {
    private final Queue<T> pool = new ArrayDeque<>();
    private final Function<Consumer<T>, ? extends T> factory;
    private final Consumer<T> releaser;

    public ObjectPool(final Function<Consumer<T>, ? extends T> factory, final int initialPoolSize) {
        this.factory = Objects.requireNonNull(factory);
        releaser = this::release;
        for (int i = 0; i < initialPoolSize; i++) {
            pool.add(factory.apply(releaser));
        }
    }

    public T borrowOrNew() {
        final T allocatedEntry = pool.poll();
        if (allocatedEntry != null) {
            return allocatedEntry;
        } else {
            return factory.apply(releaser);
        }
    }

    public void release(final T value) {
        pool.offer(value);

    }
}