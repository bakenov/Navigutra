// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

/**
 * Exception raised by the FIX client application to indicate a FIX related
 * problem, such as login failure.
 */
public class FIXClientException extends Exception
{
    private static final long serialVersionUID = 136216094742410910L;

    /**
     * @param message
     */
    public FIXClientException(final String message)
    {
        super(message);
    }
}