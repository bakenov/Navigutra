package com.anz.markets.efx.fox.codec.sbe;

import java.util.EnumSet;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import java.util.concurrent.atomic.AtomicReference;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.pojo.FirewallConfigAsserter;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.pojo.InitialisationAsserter;
import com.anz.markets.efx.fox.codec.pojo.PricingRefreshCompleteAsserter;
import com.anz.markets.efx.fox.codec.pojo.TimerExpiryAsserter;
import com.anz.markets.efx.fox.codec.pojo.InstrumentConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.VenueInstrumentConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.UserConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.VenueConfigAsserter;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InitialisationDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(Spockito.class)
public class SbeEncoderDecoderTest {

    //NOTE: we want to reuse the following objects and share them for all tests cause that's what we do in PROD code
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final MutableSbeMessage message = new SbeMessageForWriting(2048);
    private final SorEncoders<SbeMessage> sorEncoders = new SbeSorEncoders(() -> spoilMessage(message));
    private final SorDecoders<SbeMessage> sorDecoders = new SbeSorDecoders();

    @Test
    @Spockito.Unroll({
            "| instrumentId  | forceSnapshot |",
            "|===============|===============|",
            "| 5             | false         |",
            "| 5             | true          |",
            "| 6             | false         |",
            "|---------------|---------------|"
    })
    @Spockito.Name("[{row}]: {instrumentKeys}")
    public void translatePricingRefreshComplete(final long instrumentId,
                                                final boolean forceSnapshot) {
        //given
        final PricingRefreshComplete pricingRefreshComplete = SorMessage.pricingRefreshComplete(
                new MessageHeader(10, 15),
                new PricingRefreshComplete.Body(instrumentId, forceSnapshot));

        final PricingRefreshCompleteAsserter asserter = PricingRefreshCompleteAsserter.expect(pricingRefreshComplete);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        pricingRefreshComplete.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", PricingRefreshCompleteDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.pricingRefreshComplete().create(asserter.assertingPricingRefreshCompleteHandler()).decode(messageForReading));
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | triggeredTime | orderId | timerId | timerGroup |",
            "|===========|===========|===============|=========|=========|============|",
            "| 4         | 34        | 4352345345    | 454     | 6546434 | PARENT_ORDER_RELEASE |",
            "| 4         | 56        | 23452345      | 756     | 7634563 | PARENT_ORDER_RELEASE |",
            "| 5         | 89        | 56653454      | 785     | 4567346 | PARENT_ORDER_RELEASE |",
            "|-----------|-----------|---------------|---------|---------|------------|"
    })
    @Spockito.Name("[{row}]: {instrumentKeys}")
    public void translateTimerExpiry(final int sourceId, final long sourceSeq, final long triggeredTime,
                                     final long orderId, final long timerId, final TimerGroup timerGroup) {
        //given
        final TimerExpiry timerExpiry = SorMessage.timerExpiry(
                new MessageHeader(sourceId, sourceSeq),
                new TimerExpiry.Body(triggeredTime, orderId, timerId, timerGroup));

        final TimerExpiryAsserter asserter = TimerExpiryAsserter.expect(timerExpiry);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        timerExpiry.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", TimerExpiryDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.timerExpiry().create(asserter.assertingTimerExpiryHandler()).decode(messageForReading));

    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | firewallName  | ruleId               | regionPattern | orderTypePattern | deskPattern | portfolioPattern | usernamePattern | venuePattern | securityTypePattern | tenorPattern | symbolPattern | period | periodUnit | local | comment                    | lastEditUsername | lastEditTime | limitThreshold |",
            "|===========|===========|===============|======================|===============|==================|=============|==================|=================|==============|=====================|==============|===============|========|============|=======|============================|==================|==============|================|",
            "| 4         | 34        | UserThroughput| 5645                 |  regionPat1   | orderTypePat1    |  deskPat1   |   portfolioPat1  |   usernamePat1  |  venuePat1   |  securityTypePat1   |   tenorPat1  |  symbolPat1   | 60     |     s      | false | deny all users             | sawenkoa         | 12345678     | 0              |",
            "| 4         | 56        | UserThroughput| 6564                 |  regionPat2   | orderTypePat2    |  deskPat2   |   portfolioPat2  |   usernamePat2  |  venuePat2   |  securityTypePat2   |   tenorPat2  |  symbolPat2   | 90     |     ms     | false | allow all EFX Traders      | marsdenj         | 23456678     | 100000000      |",
            "| 5         | 89        | UserThroughput| 6342                 |  regionPat3   | orderTypePat3    |  deskPat3   |   portfolioPat3  |   usernamePat3  |  venuePat3   |  securityTypePat3   |   tenorPat3  |  symbolPat3   | 120    |     m      | true | joel head of EFX gets more | marsdenj         | 23444344     | 500000000      |",
            "|-----------|-----------|---------------|----------------------|---------------|------------------|-------------|------------------|-----------------|--------------|---------------------|--------------|---------------|--------|------------|-------|----------------------------|------------------|--------------|----------------|"
    })

    @Spockito.Name("[{row}]: {ruleId}")
    public void translateFirewallConfig(final int sourceId, final long sourceSeq, final String firewallName,
                                        final long ruleId, final String regionPattern,
                                        final String orderTypePattern, final String deskPattern, final String portfolioPattern,
                                        final String userNamePattern, final String venuePattern, final String securityTypePattern,
                                        final String tenorPattern, final String symbolPattern,
                                        final long period, final String periodUnit, final boolean local, final String comment,
                                        final String lastEditUsername, final long lastEditTime, final double limitThreshold) {
        //given
        final FirewallConfig firewallConfig = SorMessage.firewallConfig(
                new MessageHeader(sourceId, sourceSeq),
                new FirewallConfig.Body(firewallName, ruleId, regionPattern, orderTypePattern, deskPattern,
                        portfolioPattern, userNamePattern, venuePattern, securityTypePattern, tenorPattern,
                        symbolPattern, period, periodUnit, local, comment, lastEditUsername, lastEditTime, limitThreshold));

        final FirewallConfigAsserter asserter = FirewallConfigAsserter.expect(firewallConfig);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(4096);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();

        firewallConfig.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", FirewallConfigDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.firewallConfig().create(asserter.assertingFirewallConfigHandler()).decode(messageForReading));
    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | venue         | compId        | venueCategories            | enabled |",
            "|===========|===========|===============|===============|============================|=========|",
            "| 4         | 34        | EBS           | lg-ebs        | [INTERBANK;MATCHING_AGENT] | true    |",
            "| 4         | 56        | RFX           | lg-rfx        | [INTERBANK;MATCHING_AGENT] | true    |",
            "| 5         | 89        | CITI          | lg-citi       | [BANK]                     | false   |",
            "|-----------|-----------|---------------|---------------|----------------------------|---------|"
    })
    @Spockito.Name("[{row}]: {venue}")
    public void translateVenueConfig(final int sourceId, final long sourceSeq, final Venue venue, final String compId, final EnumSet<VenueCategory> venueCategories, final boolean enabled) {
        //given
        final VenueConfig venueConfig = SorMessage.venueConfig(
                new MessageHeader(sourceId, sourceSeq),
                new VenueConfig.Body(venue, compId, venueCategories, enabled));

        final VenueConfigAsserter asserter = VenueConfigAsserter.expect(venueConfig);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        venueConfig.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", VenueConfigDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.venueConfig().create(asserter.assertingVenueConfigHandler()).decode(messageForReading));

    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | userName      | userGroups            | location  |",
            "|===========|===========|===============|=======================|===========|",
            "| 4         | 34        | user1         | [TRADER;ADMIN]        | Melbourne |",
            "| 4         | 56        | user2         | [TRADER;ADMIN]        | Tokyo     |",
            "| 5         | 89        | user3         | [TRADER]              | London    |",
            "|-----------|-----------|---------------|-----------------------|-----------|"
    })
    @Spockito.Name("[{row}]: {userName}")
    public void translateUserConfig(final int sourceId, final long sourceSeq, final String userName, final EnumSet<UserGroup> userGroups, final String location) {
        //given
        final UserConfig userConfig = SorMessage.userConfig(
                new MessageHeader(sourceId, sourceSeq),
                new UserConfig.Body(userName, userGroups, location));

        final UserConfigAsserter asserter = UserConfigAsserter.expect(userConfig);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        userConfig.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", UserConfigDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.userConfig().create(asserter.assertingUserConfigHandler()).decode(messageForReading));

    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | initStage     |",
            "|===========|===========|===============|",
            "| 4         | 34        | BEGIN         |",
            "| 4         | 56        | END           |",
            "|-----------|-----------|---------------|"
    })
    @Spockito.Name("[{row}]: {initStage}")
    public void translateInitialisation(final int sourceId, final long sourceSeq, final InitStage initStage) {
        //given
        final Initialisation initialisation = SorMessage.initialisation(
                new MessageHeader(sourceId, sourceSeq),
                new Initialisation.Body(initStage));

        final InitialisationAsserter asserter = InitialisationAsserter.expect(initialisation);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        initialisation.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", InitialisationDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.initialisation().create(asserter.assertingInitialisationHandler()).decode(messageForReading));

    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | instrumentId  | pipSizeDivisor | enabled      |",
            "|===========|===========|===============|================|===========|",
            "| 4         | 34        | 23423423      | 10000          | true      |",
            "| 4         | 56        | 23423424      | 1000           | false     |",
            "| 5         | 89        | 23423425      | 10000          | true      |",
            "|-----------|-----------|---------------|----------------|-----------|"
    })
    @Spockito.Name("[{row}]: {userName}")
    public void translateInstrumentConfig(final int sourceId, final long sourceSeq, final long instrumentId, final int pipSizeDivisor, final  boolean enabled) {
        //given
        final InstrumentConfig instrumentConfig = SorMessage.instrumentConfig(
                new MessageHeader(sourceId, sourceSeq),
                new InstrumentConfig.Body(instrumentId, pipSizeDivisor, enabled));

        final InstrumentConfigAsserter asserter = InstrumentConfigAsserter.expect(instrumentConfig);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        instrumentConfig.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", InstrumentConfigDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.instrumentConfig().create(asserter.assertingInstrumentConfigHandler()).decode(messageForReading));

    }

    @Test
    @Spockito.Unroll({
            "| sourceId  | sourceSeq | venue    | instrumentId  | priceIncrement | sizeIncrement  | clipSizeMultiple | maxAllowedParentOrderQty | minClipSize | maxClipSize | staleDataTimeout | priority | proportion | enabled   |",
            "|===========|===========|==========|===============|================|================|==================|==========================|=============|=============|==================|==========|============|===========|",
            "| 4         | 34        | EBS      | 23423523      | 0.0005         | 100000         | 100000           | 30000000                 | 100000      | 200000      | 30               | 10       | 50         | true      |",
            "| 4         | 56        | RFX      | 23423524      | 0.0006         | 200000         | 50000            | 20000000                 | 300000      | 400000      | 60               | 20       | 25         | false     |",
            "| 5         | 89        | CITI     | 23423525      | 0.0003         | 300000         | 60000            | 50000000                 | 1000000     | 1000000     | 3600             | 30       | 100        | true      |",
            "|-----------|-----------|----------|---------------|----------------|----------------|------------------|--------------------------|-------------|-------------|------------------|----------|------------|-----------|"
    })
    @Spockito.Name("[{row}]: {instrumentId}")
    public void translateVenueInstrumentConfig(final int sourceId, final long sourceSeq,
                                               final Venue venue, final long instrumentId,
                                               final double priceIncrement, final int sizeIncrement,
                                               final int clipSizeMultiple, final double maxAllowedParentOrderQty,
                                               final int minClipSize, final int maxClipSize, final int staleDataTimeout,
                                               final int priority, final int proportion, final  boolean enabled) {
        //given
        final VenueInstrumentConfig venueInstrumentConfig = SorMessage.venueInstrumentConfig(
                new MessageHeader(sourceId, sourceSeq),
                new VenueInstrumentConfig.Body(venue, instrumentId, priceIncrement,
                        sizeIncrement, clipSizeMultiple, maxAllowedParentOrderQty,
                        minClipSize, maxClipSize, staleDataTimeout, priority, proportion, enabled));

        final VenueInstrumentConfigAsserter asserter = VenueInstrumentConfigAsserter.expect(venueInstrumentConfig);
        final MutableDirectBuffer targetBuffer = new ExpandableArrayBuffer(512);
        final SbeMessageForReading messageForReading = new SbeMessageForReading();

        //when
        venueInstrumentConfig.encode(sorEncoders, m -> {
            targetBuffer.putBytes(0, m.buffer(), 0, m.messageLength());
            messageForReading.wrap(targetBuffer, 0, m.messageLength());
        });

        //then: decode & assert
        assertTrue("Unexpected message length", messageForReading.messageLength() > 0);
        assertEquals("Unexpected message type", VenueInstrumentConfigDecoder.TEMPLATE_ID, headerDecoder.wrap(messageForReading.buffer(), 0).templateId());
        assertTrue(sorDecoders.venueInstrumentConfig().create(asserter.assertingVenueInstrumentConfigHandler()).decode(messageForReading));
    }

    private static MutableSbeMessage spoilMessage(final MutableSbeMessage message) {
        final int len = message.buffer().capacity();
        for (int i = 0; i < len; i++) {
            message.buffer().putByte(i, (byte) 0xff);
        }
        return message;
    }
}
