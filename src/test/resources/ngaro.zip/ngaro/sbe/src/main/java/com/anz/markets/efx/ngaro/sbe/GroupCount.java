package com.anz.markets.efx.ngaro.sbe;

import java.util.Objects;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * Helper class for SBE groups that allows us to reduce the group count at the end of writing group entries. This is
 * sometimes useful e.g. when we drop some entries while encoding or when we don't know exactly in advance how many
 * entries there will be.
 */
public final class GroupCount {
    private final IntSupplier limitReader;
    private final IntConsumer limitWriter;
    private final IntConsumer countWriter;

    private int max;
    private int limit;
    private int current;

    public GroupCount(final IntSupplier limitReader,
                      final IntConsumer limitWriter,
                      final IntConsumer countWriter) {
        this.limitReader = Objects.requireNonNull(limitReader);
        this.limitWriter = Objects.requireNonNull(limitWriter);
        this.countWriter = Objects.requireNonNull(countWriter);
    }

    public int count() {
        return current;
    }

    public void init(final int max) {
        this.max = max;
        this.limit = limitReader.getAsInt();
        this.current = 0;
    }

    public void increment() {
        if (current < max) {
            current++;
        } else {
            throw new IllegalStateException("Adding another group entry would exceed max=" + max + " defined at group start");
        }
    }

    public void adjustAndReset() {
        if (current < max) {
            final int curLimit = limitReader.getAsInt();
            limitWriter.accept(limit);
            countWriter.accept(current);
            limitWriter.accept(curLimit);
        }
        reset();
    }

    private void reset() {
        max = 0;
        limit = 0;
        current = 0;
    }
}
