package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.adapters.ndf2trep.snapshot.SnapshotterDecoderLookup;
import com.anz.axle.adapters.ndf2trep.snapshot.SnapshotterDecoderSupplier;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;

public class SnapshotterHealthCheck implements Runnable {
    private static final Logger LOGGER = LoggerFactory.getLogger(SnapshotterHealthCheck.class);
    private static final Set<Flag> MISSED_HEARTBEAT = new HashSet<>(Arrays.asList(Flag.MISSED_HEARTBEAT));

    private final long missingHeartbeatIntervalNanos;
    private final SnapshotterDecoderLookup snapshotterDecoderLookup;
    private final PrecisionClock precisionClock;

    public SnapshotterHealthCheck(
            final long missingHeartbeatIntervalMilliseconds,
            final SnapshotterDecoderLookup snapshotterDecoderLookup,
            final PrecisionClock precisionClock) {
        this.missingHeartbeatIntervalNanos = TimeUnit.MILLISECONDS.toNanos(missingHeartbeatIntervalMilliseconds);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.snapshotterDecoderLookup = Objects.requireNonNull(snapshotterDecoderLookup);
    }

    @Override
    public void run() {
        final Collection<SnapshotterDecoderSupplier> suppliers = snapshotterDecoderLookup.snapshotterDecoderSuppliers();

        for (final SnapshotterDecoderSupplier supplier: suppliers) {
            final Snapshotter snapshotter = supplier.snapshotter();

            performHealthCheck(snapshotter);
        }
    }

    private void performHealthCheck(final Snapshotter snapshotter) {

        final long sendingTimeNanosOfCurrentSnapshot = snapshotter.sendingTimeNanosOfCurrentSnapshot();
        final long thresholdTimestamp = precisionClock.nanos() - missingHeartbeatIntervalNanos;
        final boolean isHeartbeatMissing = (sendingTimeNanosOfCurrentSnapshot > 0 && (thresholdTimestamp > sendingTimeNanosOfCurrentSnapshot));

        if (isHeartbeatMissing) {
            LOGGER.info("Stale Instrument {} clearing book and forward empty snapshot downstream.", snapshotter.requestKey());
            snapshotter.clearBookAndForwardEmptySnapshot(MISSED_HEARTBEAT);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("thresholdTimestamp = {}, lastTOBTriggerTimestamp = {}", thresholdTimestamp, sendingTimeNanosOfCurrentSnapshot);
            }
        }
    }
}
