package com.anz.markets.efx.ngaro.collections;

import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class EnumBooleanTableTest {

    @Test
    public void shouldInitiallyReturnIsSetToFalse() {
        EnumBooleanTable<AlphabetEnum, AnimalEnum> table = new EnumBooleanTable<>(AlphabetEnum.class, AnimalEnum.class);
        for (final AnimalEnum instrument : AnimalEnum.values()) {
            table.forEachRowKeyWithColumnKey(instrument, (market, value) -> {
                assertThat(value, is(false));
            });
        }
    }

    @Test
    public void shouldReturnIsSetToTrueWhenSet() {
        final EnumBooleanTable<AlphabetEnum, AnimalEnum> table = new EnumBooleanTable<>(AlphabetEnum.class, AnimalEnum.class);
        for (final AlphabetEnum colour : AlphabetEnum.values()) {
            for (final AnimalEnum instrument : AnimalEnum.values()) {
                table.put(colour, instrument, true);
            }
        }

        for (final AnimalEnum instrument : AnimalEnum.values()) {
            table.forEachRowKeyWithColumnKey(instrument, (market, value) -> {
                assertThat(value, is(true));
            });
        }
    }
}