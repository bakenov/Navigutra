package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.util.Objects;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.datamodel.AbstractDataModel;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSide;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.components.MarketDataIncrementalRefresh_MDEntriesGrp_1;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.MDUpdateAction;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;


public final class FastIncrementalRefreshHandler implements FixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(FastIncrementalRefreshHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;


    public FastIncrementalRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                         final PricingEncoderLookup pricingEncoderLookup,
                                         final PrecisionClock precisionClock,
                                         final SubscriptionManager subscriptionManager,
                                         final String senderCompId,
                                         final String compId,
                                         final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender,
                                         final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final AbstractDataModel message) throws IllegalArgumentException {
        accept(message, Long.MIN_VALUE);
    }

    @Override
    public void accept(final AbstractDataModel adm, long receivedByAdapterTimestampNanos) throws IllegalArgumentException {
        assert adm instanceof MarketDataIncrementalRefresh;
        final MarketDataIncrementalRefresh message = (MarketDataIncrementalRefresh) adm;

        final long receivingTimeNanos = receivedByAdapterTimestampNanos <= 0 ? precisionClock.nanos() : receivedByAdapterTimestampNanos;
        LOGGER.debug("MarketDataIncrementalRefresh received: {}", message);
        final Bytes mdReqID = message.mDReqID();
        final int mdRequestId = (int) mdReqID.parseLong();
        final long entriesCount = message.noMDEntries();

        if (entriesCount > 0) {
            final long sequenceNumber = message.msgSeqNum();
            final long messageId = sequenceNumber;
            final long sendingTimeNanos = message.sendingTime();

            final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);
            if (subscription == null) {
                LOGGER.warn("No subscription found for requestId: {}. Discard : {}", mdRequestId, message);
                return;
            }

            final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
            // one HashMap but object has a complex hashCode
            final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
            flagsAppender.accept(encoder.mdFlags());

            final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next = encoder
                .senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .sendingTime(sendingTimeNanos)
                .referenceSpotDate().encodeNull()
                .tradeDate().encodeNull()
                .settlDate().encodeNull()
                .entriesStart((int) entriesCount);

            final long groups = message.noMDEntries();
            for (int i = 0; i < groups; i++) {
                final MarketDataIncrementalRefresh_MDEntriesGrp_1 priceEntryGroup = message.marketDataIncrementalRefresh_MDEntriesGrp_1(i);

                final char mdUpdateAction = priceEntryGroup.mDUpdateAction();
                final char mdEntryType = priceEntryGroup.mDEntryType();

                final EntryType side = FixSide.from(mdEntryType);
                final String fixSymbol = priceEntryGroup.symbol();
                subscription.validateSymbol(fixSymbol);

                final Bytes mdEntryId = priceEntryGroup.mDEntryID();

                if (MDUpdateAction.NEW == mdUpdateAction) {

                    final double mdEntryPx = priceEntryGroup.mDEntryPx();
                    final double mdEntrySize = priceEntryGroup.mDEntrySize();
                    final double minQty = Double.isNaN(priceEntryGroup.minQty()) ? 0.0 : priceEntryGroup.minQty();
                    final int mdEntryIdInt = subscription.stringToIntCache().put(mdEntryId);

                    mdEntries_Next.next()
                        .mdUpdateAction(UpdateAction.NEW)
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(side)
                        .mdEntrySize(mdEntrySize)
                        .minQty(minQty)
                        .mdEntryPx(mdEntryPx)
                        .mdEntryId(mdEntryIdInt)
                        .mdEntryRefId(0)
                        .quoteEntryId(0);

                } else if (MDUpdateAction.DELETE == mdUpdateAction || MDUpdateAction.CHANGE == mdUpdateAction) {
                    //these are newly added fields
                    final double mdEntryPx = priceEntryGroup.mDEntryPx();
                    final double mdEntrySize = priceEntryGroup.mDEntrySize();
                    final int mdEntryIdInt = MDUpdateAction.DELETE == mdUpdateAction
                            ? subscription.stringToIntCache().remove(mdEntryId)
                            : subscription.stringToIntCache().put(mdEntryId);

                    mdEntries_Next.next()
                        .mdUpdateAction(MDUpdateAction.DELETE == mdUpdateAction ? UpdateAction.DELETE : UpdateAction.CHANGE)
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(side)
                        .mdEntrySize(mdEntrySize)
                        .mdEntryPx(mdEntryPx)
                        .mdEntryId(mdEntryIdInt)
                        .mdEntryRefId(0)
                        .quoteEntryId(0);
                }
            }

            mdEntries_Next.entriesComplete()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .messageComplete();
        }
    }
}
