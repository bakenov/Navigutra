package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.codec.sbe.VenueInstrumentConfigSbeDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class VenueInstrumentConfigEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueInstrumentConfigEvent.class);

    private final VenueInstrumentRepository venueInstrumentRepository;
    private final VenueInstrumentConfigSbeDecoder venueInstrumentConfigDecoder = new VenueInstrumentConfigSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public VenueInstrumentConfigEvent(final VenueInstrumentRepository venueInstrumentRepository) {
        this.venueInstrumentRepository = Objects.requireNonNull(venueInstrumentRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!venueInstrumentConfigDecoder.wrap(message)) return false;
        logMessage();

        venueInstrumentRepository.apply(venueInstrumentConfigDecoder);
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        venueInstrumentConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying venue instrument config: {}", stringBuilder);
    }
}
