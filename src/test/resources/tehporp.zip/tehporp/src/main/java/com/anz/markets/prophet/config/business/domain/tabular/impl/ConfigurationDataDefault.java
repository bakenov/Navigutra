package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.indexed.AggregatedBookConfig;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.general.KeyValueConfig;
import com.anz.markets.prophet.config.business.domain.tabular.general.OperatingHourConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveNewsHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByMonitorHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByPositionHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTakeProfitHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTwapHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgeFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgePortfolioConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.MidHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.PassiveHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.SlidingWindowDealVolumeConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.PricingModel;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.adjustment.AdjustAggregatedConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LatencyFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LiquidityFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.MinimumMarketFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.StaleFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.firewall.PricingArbitrageFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.DriverMarketChooserConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.StandardMarketSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.skew.NetOpenPositionSkewRatioConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.BenchmarkSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.DiscoTightenByConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsItemConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWideningConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.MarketGapFactorConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.MarketGapToWideningFactorConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.MarketWideningFactorToDecayPeriodConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.config.business.domain.tabular.risk.NetOpenPositionLimitConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ConfigurationDataDefault implements ConfigurationData, ProphetMarshallable {

    private List<KeyValueConfig> keyValueConfigs = new ArrayList<>();
    private List<PricingArbitrageFirewallConfig> pricingArbitrageFirewallConfigs = new ArrayList<>();
    private List<OptimalPositionConfig> optimalPositionConfigs = new ArrayList<>();
    private List<PricingModel> pricingModels = new ArrayList<>();
    private List<MarketConfig> marketConfigs = new ArrayList<>();
    private List<InstrumentConfig> instrumentConfigs = new ArrayList<>();
    private List<StandardMarketSpreadConfig> standardMarketSpreadConfigs = new ArrayList<>();

    private List<ClientSpreadConfig> clientSpreadConfigs = new ArrayList<>();
    private List<DiscoTightenByConfig> discoTightenByConfigs = new ArrayList<>();
    private List<RealisedVolatilityConfig> realisedVolatilityConfigs = new ArrayList<>();// for unmarshalling to work
    private List<ClientPriceThrottleConfig> clientPriceThrottleConfigs = new ArrayList<>();
    private List<BenchmarkSpreadConfig> benchmarkSpreadConfigs = new ArrayList<>();
    private List<HedgePortfolioConfig> hedgePortfolioConfigs = new ArrayList<>();
    private List<MidHedgerConfig> midHedgerConfigs = new ArrayList<>();
    private List<AggressiveNewsHedgerConfig> aggressiveNewsHedgerConfigs = new ArrayList<>();
    private List<AggressiveTwapHedgerConfig> aggressiveTwapHedgerConfigs = new ArrayList<>();
    private List<AggressiveTakeProfitHedgerConfig> aggressiveTakeProfitHedgerConfigs = new ArrayList<>();
    private List<AggressiveSpeedUpByMonitorHedgerConfig> aggressiveSpeedUpByMonitorHedgerConfigs = new ArrayList<>();
    private List<AggressiveSpeedUpByPositionHedgerConfig> aggressiveSpeedUpByPositionHedgerConfigs = new ArrayList<>();
    private List<PassiveHedgerConfig> passiveHedgerConfigs = new ArrayList<>();
    private List<NetOpenPositionLimitConfig> netOpenPositionLimitConfigs = new ArrayList<>();
    private List<NetOpenPositionSkewRatioConfig> netOpenPositionSkewRatioConfigs = new ArrayList<>();

    private List<MarketGapFactorConfig> marketGapFactorConfigs = new ArrayList<>();
    private List<MarketGapToWideningFactorConfig> marketGapToWideningFactorConfigs = new ArrayList<>();
    private List<MarketWideningFactorToDecayPeriodConfig> marketWideningFactorToDecayPeriodConfigs = new ArrayList<>();
    private List<EconNewsItemConfig> econNewsItemConfigs = new ArrayList<>();
    private List<EconNewsWideningConfig> econNewsWideningConfigs = new ArrayList<>();

    private List<VolatilityWideningConfig> volatilityWideningConfigs = new ArrayList<>();
    private List<VolatilityWideningPercentileConfig> volatilityWideningPercentileConfigs = new ArrayList<>();
    private List<RiskAdjustedFactor> riskAdjustedSpreadParams = new ArrayList<>();
    private List<MaxSkewQuantities> maxSkewQuantities = new ArrayList<>();
    private List<PriceSpikeFirewallConfig> priceSpikeFirewallConfigs = new ArrayList<>();
    private List<PriceBarrierFirewallConfig> priceBarrierFirewallConfigs = new ArrayList<>();
    private List<PriceBarrierClippingConfig> priceBarrierClippingConfigs = new ArrayList<>();
    private List<FilterEnabledConfig> filterEnabledConfigs = new ArrayList<>();
    private List<SyntheticWideningFactor> syntheticWideningFactors = new ArrayList<>();
    private List<LatencyFilterConfig> latencyFilterConfigs = new ArrayList<>();
    private List<StaleFilterConfig> staleFilterConfigs = new ArrayList<>();
    private List<LiquidityFilterConfig> liquidityFilterConfigs = new ArrayList<>();
    private List<HedgeFirewallConfig> hedgeFirewallConfigs = new ArrayList<>();
    private List<OperatingHourConfig> operatingHourConfigs = new ArrayList<>();

    private List<SlidingWindowDealVolumeConfig> slidingWindowDealVolumeConfigs = new ArrayList<>();
    private List<AdjustAggregatedConfig> adjustAggregatedConfigs = new ArrayList<>();
    private List<DriverMarketChooserConfig> driverMarketChooserConfigs = new ArrayList<>();
    private List<SyntheticInstrumentConfig> syntheticInstrumentConfigs = new ArrayList<>();
    private PriceFormationPipelineConfigList priceFormationPipelineConfigList = new PriceFormationPipelineConfigList();
    private List<VolumeSkewConfig> volumeSkewConfigs = new ArrayList<>();
    private List<PassthroughSpreadConfig> passthroughSpreadConfigs = new ArrayList<>();
    private List<MinimumMarketFilterConfig> minimumMarketsFilterConfigs = new ArrayList<>();

    @Override
    public List<KeyValueConfig> getKeyValueConfigs() {
        return keyValueConfigs;
    }

    public ConfigurationDataDefault setKeyValueConfigs(final List<KeyValueConfig> keyValueConfigs) {
        this.keyValueConfigs = keyValueConfigs;
        return this;
    }

    public ConfigurationDataDefault putKeyValueConfig(final KeyValueConfig keyValueConfig) {
        // make sure we don't have duplicates.
        for (int i = 0; i < this.keyValueConfigs.size(); i++) {
            if (this.keyValueConfigs.get(i).getKeyName().equals(keyValueConfig.getKeyName())) {
                this.keyValueConfigs.remove(i);
            }
        }
        this.keyValueConfigs.add(keyValueConfig);
        return this;
    }

    public List<MarketConfig> getMarketConfigs() {
        return marketConfigs;
    }

    @Override
    public List<LatencyFilterConfig> getLatencyFilterConfigs() {
        return latencyFilterConfigs;
    }

    @Override
    public List<StaleFilterConfig> getStaleFilterConfigs() {
        return staleFilterConfigs;
    }

    @Override
    public List<LiquidityFilterConfig> getLiquidityFilterConfigs() {
        if (liquidityFilterConfigs.isEmpty()) {
            liquidityFilterConfigs.add(LiquidityFilterConfig.DEFAULT);
        }
        return liquidityFilterConfigs;
    }

    @Override
    public List<StandardMarketSpreadConfig> getStandardMarketSpreadConfigs() {
        return standardMarketSpreadConfigs;
    }

    @Override
    public List<InstrumentConfig> getInstrumentConfigs() {
        return instrumentConfigs;
    }

    @Override
    public List<ClientSpreadConfig> getClientSpreadConfigs() {
        return clientSpreadConfigs;
    }

    @Override
    public List<DiscoTightenByConfig> getDiscoTightenByConfigs() {
        return discoTightenByConfigs;
    }

    @Override
    public List<ClientPriceThrottleConfig> getClientPriceThrottleConfigs() {
        return clientPriceThrottleConfigs;
    }

    @Override
    public List<BenchmarkSpreadConfig> getBenchmarkSpreadConfigs() {
        return benchmarkSpreadConfigs;
    }

    @Override
    public List<PricingModel> getPricingModels() {
        return pricingModels;
    }

    @Override
    public List<HedgePortfolioConfig> getHedgePortfolioConfigs() {
        return hedgePortfolioConfigs;
    }

    @Override
    public List<MidHedgerConfig> getMidHedgerConfigs() {
        return midHedgerConfigs;
    }

    @Override
    public List<AggressiveNewsHedgerConfig> getAggressiveNewsHedgerConfigs() {
        return aggressiveNewsHedgerConfigs;
    }

    @Override
    public List<AggressiveTwapHedgerConfig> getAggressiveTwapHedgerConfigs() {
        return aggressiveTwapHedgerConfigs;
    }

    @Override
    public List<AggressiveTakeProfitHedgerConfig> getAggressiveTakeProfitHedgerConfigs() {
        return aggressiveTakeProfitHedgerConfigs;
    }

    @Override
    public List<AggressiveSpeedUpByMonitorHedgerConfig> getAggressiveSpeedUpByMonitorHedgerConfigs() {
        return aggressiveSpeedUpByMonitorHedgerConfigs;
    }

    @Override
    public List<AggressiveSpeedUpByPositionHedgerConfig> getAggressiveSpeedUpByPositionHedgerConfigs() {
        return aggressiveSpeedUpByPositionHedgerConfigs;
    }

    @Override
    public List<PassiveHedgerConfig> getPassiveHedgerConfigs() {
        return passiveHedgerConfigs;
    }

    @Override
    public List<NetOpenPositionLimitConfig> getNetOpenPositionLimitConfigs() {
        return netOpenPositionLimitConfigs;
    }

    @Override
    public List<HedgeFirewallConfig> getHedgeFirewallConfigs() {
        return hedgeFirewallConfigs;
    }

    @Override
    public List<OptimalPositionConfig> getOptimalPositionConfigs() {
        return optimalPositionConfigs;
    }

    @Override
    public List<OperatingHourConfig> getOperatingHourConfigs() {
        return operatingHourConfigs;
    }

    @Override
    public List<SlidingWindowDealVolumeConfig> getSlidingWindowDealVolumeConfigs() {
        return slidingWindowDealVolumeConfigs;
    }

    @Override
    public List<AdjustAggregatedConfig> getAdjustAggregatedConfigs() {
        return this.adjustAggregatedConfigs;
    }

    @Override
    public List<DriverMarketChooserConfig> getDriverMarketChooserConfigs() {
        return this.driverMarketChooserConfigs;
    }

    @Override
    public List<SyntheticInstrumentConfig> getSyntheticInstrumentConfigs() {
        return this.syntheticInstrumentConfigs;
    }

    public ConfigurationDataDefault setDriverMarketChooserConfigs(final List<DriverMarketChooserConfig> driverMarketChooserConfigs) {
        this.driverMarketChooserConfigs = driverMarketChooserConfigs;
        return this;
    }

    public ConfigurationDataDefault setAdjustAggregatedConfigs(final List<AdjustAggregatedConfig> adjustAggregatedConfigs) {
        this.adjustAggregatedConfigs = adjustAggregatedConfigs;
        return this;
    }

    public ConfigurationDataDefault setSlidingWindowDealVolumeConfigs(final List<SlidingWindowDealVolumeConfig> slidingWindowDealVolumeConfigs) {
        this.slidingWindowDealVolumeConfigs = slidingWindowDealVolumeConfigs;
        return this;
    }

    public ConfigurationDataDefault setOperatingHourConfigs(final List<OperatingHourConfig> operatingHourConfigs) {
        this.operatingHourConfigs = operatingHourConfigs;
        return this;
    }

    public ConfigurationDataDefault setOptimalPositionConfigs(
            final List<OptimalPositionConfig> optimalPositionConfigs) {
        this.optimalPositionConfigs = optimalPositionConfigs;
        return this;
    }

    public ConfigurationDataDefault setClientSpreadConfigs(final List<ClientSpreadConfig> clientSpreadConfigs) {
        this.clientSpreadConfigs = clientSpreadConfigs;
        return this;
    }

    public ConfigurationDataDefault setDiscoTightenByConfigs(final List<DiscoTightenByConfig> discoTightenByConfigs) {
        this.discoTightenByConfigs = discoTightenByConfigs;
        return this;
    }

    public ConfigurationDataDefault setInstrumentConfigs(final List<InstrumentConfig> instrumentConfigs) {
        this.instrumentConfigs = instrumentConfigs;
        return this;
    }

    public ConfigurationDataDefault setMarketConfigs(final List<MarketConfig> marketConfigs) {
        this.marketConfigs = marketConfigs;
        return this;
    }

    public ConfigurationDataDefault setStandardMarketSpreadConfigs(
            final List<StandardMarketSpreadConfig> standardMarketSpreadConfigs) {
        this.standardMarketSpreadConfigs = standardMarketSpreadConfigs;
        return this;
    }

    public ConfigurationDataDefault setClientPriceThrottleConfigs(
            final List<ClientPriceThrottleConfig> clientPriceThrottleConfigs) {
        this.clientPriceThrottleConfigs = clientPriceThrottleConfigs;
        return this;
    }

    public ConfigurationDataDefault setBenchmarkSpreadConfigs(
            final List<BenchmarkSpreadConfig> benchmarkSpreadConfigs) {
        this.benchmarkSpreadConfigs = benchmarkSpreadConfigs;
        return this;
    }

    public ConfigurationDataDefault setHedgePortfolioConfigs(final List<HedgePortfolioConfig> hedgePortfolioConfigs) {
        this.hedgePortfolioConfigs = hedgePortfolioConfigs;
        return this;
    }

    public ConfigurationDataDefault setMidHedgerConfigs(final List<MidHedgerConfig> midHedgerConfigs) {
        this.midHedgerConfigs = midHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setAggressiveNewsHedgerConfigs(
            final List<AggressiveNewsHedgerConfig> aggressiveNewsHedgerConfigs) {
        this.aggressiveNewsHedgerConfigs = aggressiveNewsHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setAggressiveTwapHedgerConfigs(
            final List<AggressiveTwapHedgerConfig> aggressiveTwapHedgerConfigs) {
        this.aggressiveTwapHedgerConfigs = aggressiveTwapHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setAggressiveTakeProfitHedgerConfigs(
            final List<AggressiveTakeProfitHedgerConfig> aggressiveTakeProfitHedgerConfigs) {
        this.aggressiveTakeProfitHedgerConfigs = aggressiveTakeProfitHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setAggressiveSpeedUpByMonitorHedgerConfigs(
            final List<AggressiveSpeedUpByMonitorHedgerConfig> aggressiveSpeedUpByMonitorHedgerConfigs) {
        this.aggressiveSpeedUpByMonitorHedgerConfigs = aggressiveSpeedUpByMonitorHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setAggressiveSpeedUpByPositionHedgerConfigs(
            final List<AggressiveSpeedUpByPositionHedgerConfig> aggressiveSpeedUpByPositionHedgerConfigs) {
        this.aggressiveSpeedUpByPositionHedgerConfigs = aggressiveSpeedUpByPositionHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setPassiveHedgerConfigs(final List<PassiveHedgerConfig> passiveHedgerConfigs) {
        this.passiveHedgerConfigs = passiveHedgerConfigs;
        return this;
    }

    public ConfigurationDataDefault setPricingModels(final List<PricingModel> pricingModels) {
        this.pricingModels = pricingModels;
        return this;
    }

    public ConfigurationDataDefault setNetOpenPositionLimitConfigs(
            final List<NetOpenPositionLimitConfig> netOpenPositionLimitConfigs) {
        this.netOpenPositionLimitConfigs = netOpenPositionLimitConfigs;
        return this;
    }

    public List<NetOpenPositionSkewRatioConfig> getNetOpenPositionSkewRatioConfigs() {
        return netOpenPositionSkewRatioConfigs;
    }

    public ConfigurationDataDefault setNetOpenPositionSkewRatioConfigs(
            final List<NetOpenPositionSkewRatioConfig> netOpenPositionSkewRatioConfigs) {
        this.netOpenPositionSkewRatioConfigs = netOpenPositionSkewRatioConfigs;
        Collections.sort(this.netOpenPositionSkewRatioConfigs, NetOpenPositionSkewRatioConfigImpl.RATIO_COMPARATOR);
        return this;
    }

    public ConfigurationDataDefault setSyntheticInstrumentConfigs(final List<SyntheticInstrumentConfig> syntheticInstrumentConfigs) {
        this.syntheticInstrumentConfigs = syntheticInstrumentConfigs;
        return this;
    }

    @Override
    public List<RealisedVolatilityConfig> getRealisedVolatilityConfigs() {
        return realisedVolatilityConfigs;
    }

    public ConfigurationDataDefault setRealisedVolatilityConfigs(
            final List<RealisedVolatilityConfig> realisedVolatilityConfigs) {
        this.realisedVolatilityConfigs = realisedVolatilityConfigs;
        return this;
    }

    public List<MarketGapToWideningFactorConfig> getMarketGapToWideningFactorConfigs() {
        return marketGapToWideningFactorConfigs;
    }

    public ConfigurationDataDefault setMarketGapToWideningFactorConfigs(
            final List<MarketGapToWideningFactorConfig> marketGapToWideningFactorConfigs) {
        this.marketGapToWideningFactorConfigs = marketGapToWideningFactorConfigs;
        return this;
    }

    public List<MarketWideningFactorToDecayPeriodConfig> getMarketWideningFactorToDecayPeriodConfigs() {
        return marketWideningFactorToDecayPeriodConfigs;
    }

    public ConfigurationDataDefault setMarketWideningFactorToDecayPeriodConfigs(
            final List<MarketWideningFactorToDecayPeriodConfig> marketWideningFactorToDecayPeriodConfigs) {
        this.marketWideningFactorToDecayPeriodConfigs = marketWideningFactorToDecayPeriodConfigs;
        return this;
    }

    public List<MarketGapFactorConfig> getMarketGapFactorConfigs() {
        return marketGapFactorConfigs;
    }

    public ConfigurationDataDefault setMarketGapFactorConfigs(
            final List<MarketGapFactorConfig> marketGapFactorConfigs) {
        this.marketGapFactorConfigs = marketGapFactorConfigs;
        return this;
    }

    public List<EconNewsWideningConfig> getEconNewsWideningConfigs() {
        return econNewsWideningConfigs;
    }

    @Override
    public List<EconNewsItemConfig> getEconNewsItemConfigs() {
        return econNewsItemConfigs;
    }

    public ConfigurationDataDefault setEconNewsWideningConfigs(
            final EconNewsWideningConfig... econNewsWideningConfigs) {
        this.econNewsWideningConfigs.clear();
        Collections.addAll(this.econNewsWideningConfigs, econNewsWideningConfigs);
        return this;
    }

    public ConfigurationDataDefault setEconNewsItemConfigs(final EconNewsItemConfig... econNewsItemConfigs) {
        this.econNewsItemConfigs.clear();
        Collections.addAll(this.econNewsItemConfigs, econNewsItemConfigs);
        return this;
    }

    @Override
    public List<PricingArbitrageFirewallConfig> getPricingArbitrageFirewallConfigs() {
        return pricingArbitrageFirewallConfigs;
    }

    public ConfigurationDataDefault setPricingArbitrageFirewallConfigs(
            final List<PricingArbitrageFirewallConfig> pricingArbitrageFirewallConfigs) {
        this.pricingArbitrageFirewallConfigs = pricingArbitrageFirewallConfigs;
        return this;
    }

    @Override
    public List<VolatilityWideningConfig> getVolatilityWideningConfigs() {
        return volatilityWideningConfigs;
    }

    public ConfigurationDataDefault setVolatilityWideningConfigs(
            final List<VolatilityWideningConfig> volatilityWideningConfigs) {
        this.volatilityWideningConfigs = volatilityWideningConfigs;
        return this;
    }

    @Override
    public List<VolatilityWideningPercentileConfig> getVolatilityWideningPercentileConfigs() {
        return  volatilityWideningPercentileConfigs;
    }

    public ConfigurationDataDefault setVolatilityWideningPercentileConfigs(
            final List<VolatilityWideningPercentileConfig> volatilityWideningPercentileConfigs) {
        this.volatilityWideningPercentileConfigs = volatilityWideningPercentileConfigs;
        return this;
    }

    @Override
    public List<RiskAdjustedFactor> getRiskAdjustedSpreadParams() {
        return riskAdjustedSpreadParams;
    }

    public ConfigurationDataDefault setRiskAdjustedSpreadParams(
            final List<RiskAdjustedFactor> riskAdjustedSpreadParams) {
        this.riskAdjustedSpreadParams = riskAdjustedSpreadParams;
        return this;
    }

    @Override
    public List<MaxSkewQuantities> getMaxSkewQuantities() {
        return maxSkewQuantities;
    }

    public ConfigurationDataDefault setMaxSkewQuantities(final List<MaxSkewQuantities> maxSkewQuantities) {
        this.maxSkewQuantities = maxSkewQuantities;
        return this;
    }

    @Override
    public List<PriceSpikeFirewallConfig> getPriceSpikeFirewallConfigs() {
        return priceSpikeFirewallConfigs;
    }

    public ConfigurationDataDefault setPriceSpikeFirewallConfigs(
            final List<PriceSpikeFirewallConfig> priceSpikeFirewallConfigs) {
        this.priceSpikeFirewallConfigs = priceSpikeFirewallConfigs;
        return this;
    }

    @Override
    public List<PriceBarrierFirewallConfig> getPriceBarrierFirewallConfigs() {
        return priceBarrierFirewallConfigs;
    }

    @Override
    public List<PriceBarrierClippingConfig> getPriceBarrierClippingConfigs() {
        return priceBarrierClippingConfigs;
    }

    public ConfigurationDataDefault setPriceBarrierClippingConfigs(
            final List<PriceBarrierClippingConfig> priceBarrierClippingConfigs) {
        this.priceBarrierClippingConfigs = priceBarrierClippingConfigs;
        return this;
    }


    public ConfigurationDataDefault setPriceBarrierFirewallConfigs(
            final List<PriceBarrierFirewallConfig> priceBarrierFirewallConfigs) {
        this.priceBarrierFirewallConfigs = priceBarrierFirewallConfigs;
        return this;
    }

    @Override
    public List<FilterEnabledConfig> getFilterEnabledConfigs() {
        return filterEnabledConfigs;
    }

    public ConfigurationDataDefault setFilterEnabledConfigs(final List<FilterEnabledConfig> filterEnabledConfigs) {
        this.filterEnabledConfigs = filterEnabledConfigs;
        return this;
    }

    @Override
    public List<SyntheticWideningFactor> getSyntheticWideningFactors() {
        return syntheticWideningFactors;
    }

    public ConfigurationDataDefault setSyntheticWideningFactors(
            final List<SyntheticWideningFactor> syntheticWideningFactors) {
        this.syntheticWideningFactors = syntheticWideningFactors;
        return this;
    }

    public ConfigurationDataDefault setLatencyFilterConfigs(final List<LatencyFilterConfig> latencyFilterConfigs) {
        this.latencyFilterConfigs = latencyFilterConfigs;
        return this;
    }

    public ConfigurationDataDefault setStaleFilterConfigs(final List<StaleFilterConfig> staleFilterConfigs) {
        this.staleFilterConfigs = staleFilterConfigs;
        return this;
    }

    public ConfigurationDataDefault setLiquidityFilterConfigs(final List<LiquidityFilterConfig> liquidityFilterConfigs) {
        this.liquidityFilterConfigs = liquidityFilterConfigs;
        return this;
    }

    public ConfigurationDataDefault setHedgeFirewallConfigs(final List<HedgeFirewallConfig> hedgeFirewallConfigs) {
        this.hedgeFirewallConfigs = hedgeFirewallConfigs;
        return this;
    }

    @Override
    public PriceFormationPipelineConfigList getPriceFormationPipelineConfigs() {
        return this.priceFormationPipelineConfigList;
    }

    public ConfigurationDataDefault setVolumeSkewConfigs(final List<VolumeSkewConfig> volumeSkewConfigs) {
        this.volumeSkewConfigs = volumeSkewConfigs;
        return this;
    }

    @Override
    public List<VolumeSkewConfig> getVolumeSkewConfigs() {
        return volumeSkewConfigs;
    }

    @Override
    public List<PassthroughSpreadConfig> getPassthroughSpreadConfigs() {
        return passthroughSpreadConfigs;
    }

    public ConfigurationDataDefault setPassthroughSpreadConfigs(final List<PassthroughSpreadConfig> passthroughSpreadConfigs) {
        this.passthroughSpreadConfigs = passthroughSpreadConfigs;
        return this;
    }

    @Override
    public List<MinimumMarketFilterConfig> getMinimumMarketsFilterConfigs() {
        return minimumMarketsFilterConfigs;
    }

    public ConfigurationDataDefault setMinimumMarketsFilterConfigs(final List<MinimumMarketFilterConfig> minimumMarketsFilterConfigs) {
        this.minimumMarketsFilterConfigs = minimumMarketsFilterConfigs;
        return this;
    }

    public ConfigurationDataDefault setPriceFormationPipelineConfigs(final PriceFormationPipelineConfigList priceFormationPipelineConfigList) {
        this.priceFormationPipelineConfigList = priceFormationPipelineConfigList;
        return this;
    }

    public ConfigurationDataDefault clearAggBooks() {
        getPriceFormationPipelineConfigs().removeFeature(AggregatedBookConfig.FEATURE_NAME);
        addAggBook(Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY);
        return this;
    }

    public ConfigurationDataDefault addAggBook(Market aggBookMarket, Instrument instrument, TradingTimeZone ttz, Region region, Market... constituents) {
        getPriceFormationPipelineConfigs().add(PriceFormationPipelineConfig.create(AggregatedBookConfig.FEATURE_NAME, aggBookMarket, instrument, ttz, region, AggregatedBookConfig.PARAM_CONSTITUENTS,Markets.getMarkets(constituents)));
        return this;
    }

    @Override
    @NotGcFriendly("New item in the list is instantiated")
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        try {
            readList(in, marketConfigs, MarketConfigImpl.class);
            readList(in, keyValueConfigs, KeyValueConfigImpl.class);
            readList(in, standardMarketSpreadConfigs, StandardMarketSpreadConfigImpl.class);
            readList(in, instrumentConfigs, InstrumentConfigImpl.class);
            readList(in, clientSpreadConfigs, ClientSpreadConfigImpl.class);

            // remove after version 17 is released
            Context.context().header().before(MessageVersion.VERSION_0_17, () -> {
                final List<ClientPriceConfigImpl> clientPriceConfigs = new ArrayList<>();
                readList(in, clientPriceConfigs, ClientPriceConfigImpl.class);
            });

            Context.context().header().since(MessageVersion.VERSION_0_17, () -> {
                readList(in, clientPriceThrottleConfigs, ClientPriceThrottleConfigImpl.class);
                readList(in, benchmarkSpreadConfigs, BenchmarkSpreadConfigImpl.class);
            });

            Context.context().header().since(MessageVersion.VERSION_0_21, () -> {
                readList(in, optimalPositionConfigs, OptimalPositionConfig.class);
            });

            readList(in, pricingModels, PricingModelImpl.class);

            // remove after version 13 is released
            Context.context().header().before(MessageVersion.VERSION_0_12, () -> {
                final List<SkewConfigImpl> skewConfigs = new ArrayList<>();
                readList(in, skewConfigs, SkewConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_12, () -> {
                readList(in, netOpenPositionLimitConfigs, NetOpenPositionLimitConfigImpl.class);
            });

            readList(in, netOpenPositionSkewRatioConfigs, NetOpenPositionSkewRatioConfigImpl.class);
            Context.context().header().since(MessageVersion.VERSION_0_21, () -> {
                readList(in, hedgePortfolioConfigs, HedgePortfolioConfigImpl.class);
            });
            readList(in, midHedgerConfigs, MidHedgerConfigImpl.class);
            readList(in, aggressiveNewsHedgerConfigs, AggressiveNewsHedgerConfigImpl.class);
            readList(in, aggressiveTwapHedgerConfigs, AggressiveTwapHedgerConfigImpl.class);
            Context.context().header().since(MessageVersion.VERSION_0_21, () -> {
                readList(in, aggressiveTakeProfitHedgerConfigs, AggressiveTakeProfitHedgerConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_48, () -> {
                readList(in, aggressiveSpeedUpByMonitorHedgerConfigs, AggressiveSpeedUpByMonitorHedgerConfigImpl.class);
                readList(in, aggressiveSpeedUpByPositionHedgerConfigs, AggressiveSpeedUpByPositionHedgerConfigImpl.class);
            });
            readList(in, passiveHedgerConfigs, PassiveHedgerConfigImpl.class);
            readList(in, marketGapFactorConfigs, MarketGapFactorConfigImpl.class);
            readList(in, marketGapToWideningFactorConfigs, MarketGapToWideningFactorConfigImpl.class);
            readList(in, marketWideningFactorToDecayPeriodConfigs, MarketWideningFactorToDecayPeriodConfigImpl.class);
            Context.context().header().since(MessageVersion.VERSION_0_4, () -> {
                readList(in, econNewsItemConfigs, EconNewsItemConfigImpl.class);
                readList(in, econNewsWideningConfigs, EconNewsWideningConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_19, () -> {
                readList(in, realisedVolatilityConfigs, RealisedVolatilityConfig.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_6, () -> {
                readList(in, filterEnabledConfigs, FilterEnabledConfig.class);
                readList(in, syntheticWideningFactors, SyntheticWideningFactor.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_7, () -> {
                Context.context().header().before(MessageVersion.VERSION_0_30, () -> {
                    double threshold = in.readDouble();
                    pricingArbitrageFirewallConfigs.clear();
                    for (Instrument instrument : Instrument.VALUES) {
                        pricingArbitrageFirewallConfigs.add(new PricingArbitrageFirewallConfigImpl(Market.ANY, instrument, threshold, true, false));
                    }
                });
                Context.context().header().since(MessageVersion.VERSION_0_30, () -> {
                    readList(in, pricingArbitrageFirewallConfigs, PricingArbitrageFirewallConfig.class);
                });
                readList(in, volatilityWideningConfigs, VolatilityWideningConfig.class);
                readList(in, riskAdjustedSpreadParams, RiskAdjustedFactor.class);
                readList(in, maxSkewQuantities, MaxSkewQuantities.class);
                readList(in, priceSpikeFirewallConfigs, PriceSpikeFirewallConfig.class);
                readList(in, priceBarrierFirewallConfigs, PriceBarrierFirewallConfig.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_84, () -> readList(in, priceBarrierClippingConfigs, PriceBarrierClippingConfig.class));
            readList(in, staleFilterConfigs, StaleFilterConfigImpl.class);
            readList(in, latencyFilterConfigs, LatencyFilterConfig.class);
            readList(in, hedgeFirewallConfigs, HedgeFirewallConfig.class);
            Context.context().header().since(MessageVersion.VERSION_0_24, () -> {
                readList(in, operatingHourConfigs, OperatingHourConfig.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_42, () -> {
                readList(in, liquidityFilterConfigs, LiquidityFilterConfig.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_45, () -> {
                readList(in, slidingWindowDealVolumeConfigs, SlidingWindowDealVolumeConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_47, () -> {
                readList(in, adjustAggregatedConfigs, AdjustAggregatedConfigImpl.class);
                readList(in, driverMarketChooserConfigs, DriverMarketChooserConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_49, () -> {
                List<PriceFormationPipelineConfig> l = new ArrayList<>();
                readList(in, l, PriceFormationPipelineConfig.class);
                priceFormationPipelineConfigList.replaceAll(l);
            });
            Context.context().header().since(MessageVersion.VERSION_0_60, () -> {
                readList(in, volatilityWideningPercentileConfigs, VolatilityWideningPercentileConfig.class);
            });

            Context.context().header().since(MessageVersion.VERSION_0_61, () -> {
                readList(in, syntheticInstrumentConfigs, SyntheticInstrumentConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_63, () -> readList(in, volumeSkewConfigs, VolumeSkewConfig.class));
            Context.context().header().since(MessageVersion.VERSION_0_68, () -> {
                readList(in, passthroughSpreadConfigs, PassthroughSpreadConfig.class);
                readList(in, minimumMarketsFilterConfigs, MinimumMarketFilterConfigImpl.class);
            });
            Context.context().header().since(MessageVersion.VERSION_0_91, () -> {
                readList(in, discoTightenByConfigs, DiscoTightenByConfigImpl.class);
            });

        } catch (IllegalAccessException | InstantiationException e) {
            throw new IllegalStateException("Unable to read config", e);
        }
    }

    private <T extends ProphetMarshallable> void readList(final ProphetBytes in,
                                                          final List<T> list,
                                                          final Class<? extends T> clazz) throws IllegalAccessException, InstantiationException {
        int size = in.readInt();
        list.clear();
        for (int i = 0; i < size; i++) {
            T config = (T) newInstance(clazz, in);
            config.readMarshallable(in);
            list.add(config);
        }
    }


    private <T> ProphetMarshallable newInstance(final Class<? extends T> clazz,
                                                final ProphetBytes in) throws IllegalAccessException, InstantiationException {
        // TODO: do this with reflection like kdb deserialiser
        if (clazz == RiskAdjustedFactor.class) {
            return RiskAdjustedFactor.constructReadMarshallable(in);
        } else if (clazz == MaxSkewQuantities.class) {
            return MaxSkewQuantities.constructReadMarshallable(in);
        } else if (clazz == PriceSpikeFirewallConfig.class) {
            return PriceSpikeFirewallConfig.constructReadMarshallable(in);
        } else if (clazz == PriceBarrierFirewallConfig.class) {
            return PriceBarrierFirewallConfig.constructReadMarshallable(in);
        } else if (clazz == PriceBarrierClippingConfig.class) {
            return PriceBarrierClippingConfig.constructReadMarshallable(in);
        } else if (clazz == LatencyFilterConfig.class) {
            return LatencyFilterConfigImpl.constructReadMarshallable(in);
        } else if (clazz == LiquidityFilterConfig.class) {
            return LiquidityFilterConfigImpl.constructReadMarshallable(in);
        } else if (clazz == RealisedVolatilityConfig.class) {
            return RealisedVolatilityConfig.constructReadMarshallable(in);
        } else if (clazz == HedgeFirewallConfig.class) {
            return HedgeFirewallConfigImpl.constructReadMarshallable(in);
        } else if (clazz == OptimalPositionConfig.class) {
            return OptimalPositionConfig.constructReadMarshallable(in);
        } else if (clazz == OperatingHourConfig.class) {
            return OperatingHourConfigImpl.constructReadMarshallable(in);
        } else if (clazz == StandardMarketSpreadConfigImpl.class) {
            return StandardMarketSpreadConfigImpl.constructReadMarshallable(in);
        } else if (clazz == PricingArbitrageFirewallConfig.class) {
            return PricingArbitrageFirewallConfigImpl.constructReadMarshallable(in);
        } else if (clazz == SlidingWindowDealVolumeConfigImpl.class) {
            return SlidingWindowDealVolumeConfigImpl.constructReadMarshallable(in);
        } else if (clazz == AdjustAggregatedConfigImpl.class) {
            return AdjustAggregatedConfigImpl.constructReadMarshallable(in);
        } else if (clazz == DriverMarketChooserConfigImpl.class) {
            return DriverMarketChooserConfigImpl.constructReadMarshallable(in);
        } else if (clazz == PriceFormationPipelineConfig.class) {
            return new PriceFormationPipelineConfig();
        } else if (clazz == VolatilityWideningPercentileConfig.class) {
            return VolatilityWideningPercentileConfig.constructReadMarshallable(in);
        } else if (clazz == SyntheticInstrumentConfigImpl.class) {
            return SyntheticInstrumentConfigImpl.constructReadMarshallable(in);
        } else if (clazz == VolumeSkewConfig.class) {
            return VolumeSkewConfig.constructReadMarshallable(in);
        } else {
            return (ProphetMarshallable) clazz.newInstance();
        }
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {

        writeList(out, marketConfigs);
        writeList(out, keyValueConfigs);
        writeList(out, standardMarketSpreadConfigs);
        writeList(out, instrumentConfigs);
        writeList(out, clientSpreadConfigs);
        writeList(out, clientPriceThrottleConfigs);
        writeList(out, benchmarkSpreadConfigs);
        writeList(out, optimalPositionConfigs);
        writeList(out, pricingModels);
        writeList(out, netOpenPositionLimitConfigs);
        writeList(out, netOpenPositionSkewRatioConfigs);
        writeList(out, hedgePortfolioConfigs);
        writeList(out, midHedgerConfigs);
        writeList(out, aggressiveNewsHedgerConfigs);
        writeList(out, aggressiveTwapHedgerConfigs);
        writeList(out, aggressiveTakeProfitHedgerConfigs);
        writeList(out, aggressiveSpeedUpByMonitorHedgerConfigs);
        writeList(out, aggressiveSpeedUpByPositionHedgerConfigs);
        writeList(out, passiveHedgerConfigs);
        writeList(out, marketGapFactorConfigs);
        writeList(out, marketGapToWideningFactorConfigs);
        writeList(out, marketWideningFactorToDecayPeriodConfigs);
        writeList(out, econNewsItemConfigs);
        writeList(out, econNewsWideningConfigs);
        writeList(out, realisedVolatilityConfigs);
        writeList(out, filterEnabledConfigs);
        writeList(out, syntheticWideningFactors);
        writeList(out, pricingArbitrageFirewallConfigs);
        writeList(out, volatilityWideningConfigs);
        writeList(out, riskAdjustedSpreadParams);
        writeList(out, maxSkewQuantities);
        writeList(out, priceSpikeFirewallConfigs);
        writeList(out, priceBarrierFirewallConfigs);
        writeList(out, priceBarrierClippingConfigs);
        writeList(out, staleFilterConfigs);
        writeList(out, latencyFilterConfigs);
        writeList(out, hedgeFirewallConfigs);
        writeList(out, operatingHourConfigs);
        writeList(out, liquidityFilterConfigs);
        writeList(out, slidingWindowDealVolumeConfigs);
        writeList(out, adjustAggregatedConfigs);
        writeList(out, driverMarketChooserConfigs);
        writeList(out, priceFormationPipelineConfigList.getList());
        writeList(out, volatilityWideningPercentileConfigs);
        writeList(out, syntheticInstrumentConfigs);
        writeList(out, volumeSkewConfigs);
        writeList(out, passthroughSpreadConfigs);
        writeList(out, minimumMarketsFilterConfigs);
        writeList(out, discoTightenByConfigs);
    }

    private <T> void writeList(final ProphetBytes out,
                               final List<T> list) {
        out.writeInt(list.size());
        for (T config : list) {
            ((ProphetMarshallable) config).writeMarshallable(out);
        }
    }

    @SuppressWarnings("unchecked")
    public <T> void set(final List<T> config,
                        final Class<T> type, String configTableName) {
        if (type == MarketConfigImpl.class) {
            this.setMarketConfigs((List<MarketConfig>) config);
        } else if (type == KeyValueConfigImpl.class) {
            this.setKeyValueConfigs((List<KeyValueConfig>) config);
        } else if (type == StandardMarketSpreadConfigImpl.class) {
            this.setStandardMarketSpreadConfigs((List<StandardMarketSpreadConfig>) config);
        } else if (type == InstrumentConfigImpl.class) {
            this.setInstrumentConfigs((List<InstrumentConfig>) config);
        } else if (type == ClientSpreadConfigImpl.class) {
            this.setClientSpreadConfigs((List<ClientSpreadConfig>) config);
        } else if (type == ClientPriceThrottleConfigImpl.class) {
            this.setClientPriceThrottleConfigs((List<ClientPriceThrottleConfig>) config);
        } else if (type == BenchmarkSpreadConfigImpl.class) {
            this.setBenchmarkSpreadConfigs((List<BenchmarkSpreadConfig>) config);
        } else if (type == NetOpenPositionLimitConfigImpl.class) {
            this.setNetOpenPositionLimitConfigs((List<NetOpenPositionLimitConfig>) config);
        } else if (type == NetOpenPositionSkewRatioConfigImpl.class) {
            this.setNetOpenPositionSkewRatioConfigs((List<NetOpenPositionSkewRatioConfig>) config);
        } else if (type == HedgePortfolioConfigImpl.class) {
            this.setHedgePortfolioConfigs((List<HedgePortfolioConfig>) config);
        } else if (type == MidHedgerConfigImpl.class) {
            this.setMidHedgerConfigs((List<MidHedgerConfig>) config);
        } else if (type == AggressiveNewsHedgerConfigImpl.class) {
            this.setAggressiveNewsHedgerConfigs((List<AggressiveNewsHedgerConfig>) config);
        } else if (type == AggressiveTwapHedgerConfigImpl.class) {
            this.setAggressiveTwapHedgerConfigs((List<AggressiveTwapHedgerConfig>) config);
        } else if (type == AggressiveTakeProfitHedgerConfigImpl.class) {
            this.setAggressiveTakeProfitHedgerConfigs((List<AggressiveTakeProfitHedgerConfig>) config);
        } else if (type == AggressiveSpeedUpByMonitorHedgerConfigImpl.class) {
            this.setAggressiveSpeedUpByMonitorHedgerConfigs((List<AggressiveSpeedUpByMonitorHedgerConfig>) config);
        } else if (type == AggressiveSpeedUpByPositionHedgerConfigImpl.class) {
            this.setAggressiveSpeedUpByPositionHedgerConfigs((List<AggressiveSpeedUpByPositionHedgerConfig>) config);
        } else if (type == PassiveHedgerConfigImpl.class) {
            this.setPassiveHedgerConfigs((List<PassiveHedgerConfig>) config);
        } else if (type == MarketGapFactorConfigImpl.class) {
            this.setMarketGapFactorConfigs((List<MarketGapFactorConfig>) config);
        } else if (type == MarketGapToWideningFactorConfigImpl.class) {
            this.setMarketGapToWideningFactorConfigs((List<MarketGapToWideningFactorConfig>) config);
        } else if (type == MarketWideningFactorToDecayPeriodConfigImpl.class) {
            this.setMarketWideningFactorToDecayPeriodConfigs((List<MarketWideningFactorToDecayPeriodConfig>) config);
        } else if (type == RealisedVolatilityConfig.class) {
            this.setRealisedVolatilityConfigs(((List<RealisedVolatilityConfig>) config));
        } else if (type == PricingModelImpl.class) {
            this.setPricingModels((List<PricingModel>) config);
        } else if (type == EconNewsItemConfigImpl.class) {
            this.econNewsItemConfigs = (List<EconNewsItemConfig>) config;
        } else if (type == EconNewsWideningConfigImpl.class) {
            this.econNewsWideningConfigs = (List<EconNewsWideningConfig>) config;
        } else if (type == OptimalPositionConfig.class) {
            this.optimalPositionConfigs = (List<OptimalPositionConfig>) config;
        } else if (type == RiskAdjustedFactor.class) {
            this.riskAdjustedSpreadParams = (List<RiskAdjustedFactor>) config;
        } else if (type == MaxSkewQuantities.class) {
            this.maxSkewQuantities = (List<MaxSkewQuantities>) config;
        } else if (type == VolatilityWideningConfig.class) {
            this.volatilityWideningConfigs = (List<VolatilityWideningConfig>) config;
        } else if (type == PriceSpikeFirewallConfig.class) {
            this.priceSpikeFirewallConfigs = (List<PriceSpikeFirewallConfig>) config;
        } else if (type == PriceBarrierFirewallConfig.class) {
            this.priceBarrierFirewallConfigs = (List<PriceBarrierFirewallConfig>) config;
        } else if (type == PriceBarrierClippingConfig.class) {
            this.priceBarrierClippingConfigs = (List<PriceBarrierClippingConfig>) config;
        } else if (type == SyntheticWideningFactor.class) {
            this.syntheticWideningFactors = (List<SyntheticWideningFactor>) config;
        } else if (type == FilterEnabledConfig.class) {
            this.filterEnabledConfigs = (List<FilterEnabledConfig>) config;
        } else if (type == StaleFilterConfigImpl.class) {
            this.staleFilterConfigs = (List<StaleFilterConfig>) config;
        } else if (type == LatencyFilterConfigImpl.class) {
            this.latencyFilterConfigs = (List<LatencyFilterConfig>) config;
        } else if (type == LiquidityFilterConfigImpl.class) {
            this.liquidityFilterConfigs = (List<LiquidityFilterConfig>) config;
        } else if (type == HedgeFirewallConfigImpl.class) {
            this.hedgeFirewallConfigs = (List<HedgeFirewallConfig>) config;
        } else if (type == OperatingHourConfigImpl.class) {
            this.operatingHourConfigs = (List<OperatingHourConfig>) config;
        } else if (type == PricingArbitrageFirewallConfigImpl.class) {
            this.pricingArbitrageFirewallConfigs = (List<PricingArbitrageFirewallConfig>) config;
        } else if (type == SlidingWindowDealVolumeConfigImpl.class) {
            this.slidingWindowDealVolumeConfigs = (List<SlidingWindowDealVolumeConfig>) config;
        } else if (type == AdjustAggregatedConfigImpl.class) {
            this.adjustAggregatedConfigs = (List<AdjustAggregatedConfig>) config;
        } else if (type == DriverMarketChooserConfigImpl.class) {
            this.driverMarketChooserConfigs = (List<DriverMarketChooserConfig>) config;
        } else if (type == PriceFormationPipelineConfig.class) {
            this.priceFormationPipelineConfigList.replaceFeature(configTableName,(List<PriceFormationPipelineConfig>) config);
        } else if (type == VolatilityWideningPercentileConfig.class) {
            this.volatilityWideningPercentileConfigs = (List<VolatilityWideningPercentileConfig>) config;
        } else if (type == SyntheticInstrumentConfigImpl.class) {
            this.syntheticInstrumentConfigs = (List<SyntheticInstrumentConfig>) config;
        } else if (type == VolumeSkewConfig.class) {
            this.volumeSkewConfigs = (List<VolumeSkewConfig>) config;
        } else if (type == PassthroughSpreadConfig.class) {
            this.passthroughSpreadConfigs = (List<PassthroughSpreadConfig>) config;
        } else if (type == MinimumMarketFilterConfigImpl.class) {
            this.minimumMarketsFilterConfigs = (List<MinimumMarketFilterConfig>) config;
        } else if (type == DiscoTightenByConfigImpl.class) {
            this.setDiscoTightenByConfigs((List<DiscoTightenByConfig>) config);
        } else {
            throw new IllegalArgumentException("Unsupported config type when set: " + type);
        }
    }

    @Override
    public String toString() {
        String s = "ConfigurationDataDefault{" +
                "keyValueConfigs=" + keyValueConfigs +
                ", pricingArbitrageFirewallConfigs=" + pricingArbitrageFirewallConfigs +
                ", optimalPositionConfigs=" + optimalPositionConfigs +
                ", pricingModels=" + pricingModels +
                ", marketConfigs=" + marketConfigs +
                ", instrumentConfigs=" + instrumentConfigs +
                ", standardMarketSpreadConfigs=" + standardMarketSpreadConfigs +
                ", clientSpreadConfigs=" + clientSpreadConfigs +
                ", realisedVolatilityConfigs=" + realisedVolatilityConfigs +
                ", clientPriceThrottleConfigs=" + clientPriceThrottleConfigs +
                ", benchmarkSpreadConfigs=" + benchmarkSpreadConfigs +
                ", hedgePortfolioConfigs=" + hedgePortfolioConfigs +
                ", midHedgerConfigs=" + midHedgerConfigs +
                ", aggressiveHedgerConfigs=" + aggressiveNewsHedgerConfigs +
                ", aggressiveTwapHedgerConfigs=" + aggressiveTwapHedgerConfigs +
                ", aggressiveTakeProfitHedgerConfigs=" + aggressiveTakeProfitHedgerConfigs +
                ", aggressiveSpeedUpByMonitorHedgerConfigs=" + aggressiveSpeedUpByMonitorHedgerConfigs  +
                ", aggressiveSpeedUpByPositionHedgerConfigs=" + aggressiveSpeedUpByPositionHedgerConfigs +
                ", passiveHedgerConfigs=" + passiveHedgerConfigs +
                ", netOpenPositionLimitConfigs=" + netOpenPositionLimitConfigs +
                ", netOpenPositionSkewRatioConfigs=" + netOpenPositionSkewRatioConfigs +
                ", marketGapFactorConfigs=" + marketGapFactorConfigs +
                ", marketGapToWideningFactorConfigs=" + marketGapToWideningFactorConfigs +
                ", marketWideningFactorToDecayPeriodConfigs=" + marketWideningFactorToDecayPeriodConfigs +
                ", econNewsItemConfigs=" + econNewsItemConfigs +
                ", econNewsWideningConfigs=" + econNewsWideningConfigs +
                ", volatilityWideningConfigs=" + volatilityWideningConfigs +
                ", volatilityWideningPercentileConfigs=" + volatilityWideningPercentileConfigs +
                ", riskAdjustedSpreadParams=" + riskAdjustedSpreadParams +
                ", maxSkewQuantities=" + maxSkewQuantities +
                ", priceSpikeFirewallConfigs=" + priceSpikeFirewallConfigs +
                ", priceBarrierFirewallConfigs=" + priceBarrierFirewallConfigs +
                ", priceBarrierClippingConfigs=" + priceBarrierClippingConfigs +
                ", filterEnabledConfigs=" + filterEnabledConfigs +
                ", syntheticWideningFactors=" + syntheticWideningFactors +
                ", latencyFilterConfigs=" + latencyFilterConfigs +
                ", staleFilterConfigs=" + staleFilterConfigs +
                ", liquidityFilterConfigs=" + liquidityFilterConfigs +
                ", hedgeFirewallConfigs=" + hedgeFirewallConfigs +
                ", operatingHourConfigs=" + operatingHourConfigs +
                ", slidingWindowDealVolumeConfigs=" + slidingWindowDealVolumeConfigs +
                ", adjustAggregatedConfigs=" + adjustAggregatedConfigs +
                ", driverMarketChooserConfigs=" + driverMarketChooserConfigs +
                ", priceFormationPipelineConfigs=" + priceFormationPipelineConfigList +
                ", syntheticInstrumentConfigs=" + syntheticInstrumentConfigs +
                ", volumeSkewConfigs=" + volumeSkewConfigs +
                ", passthroughSpreadConfigs=" + passthroughSpreadConfigs +
                ", minimumMarketsFilterConfigs=" + minimumMarketsFilterConfigs +
                ", discoTightenByConfigs=" + discoTightenByConfigs;
        return s + '}';
    }
}