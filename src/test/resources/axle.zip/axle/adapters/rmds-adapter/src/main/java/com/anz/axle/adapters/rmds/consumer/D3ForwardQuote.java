package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.pricing.QuoteState;
import com.anz.markets.adapters.trep.Item;
import com.google.common.base.Optional;
import com.google.common.base.Strings;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.springframework.util.ObjectUtils.nullSafeEquals;

public final class D3ForwardQuote {
    private static final Logger LOGGER = LoggerFactory.getLogger(D3ForwardQuote.class);

    // Format for parsing dates
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormat.forPattern("dd MMM yyyy");

    public static final String INSTRUMENT = "GV1_TEXT";     // currency pair
    public static final String BID = "BID";                 // bid (may be null for one-sided updates)
    public static final String ASK = "ASK";                 // offer (may be null for one-sided updates)
    public static final String STATUS = "GEN_TEXT16";       // INDIC for indicative rates, LIVE for tradeable
    public static final String MATURITY = "MATUR_DATE";     // value date
    public static final String SPOT_DATE = "GV1_DATE";      // spot date

    // Trade status flags
    public static final String INDICATIVE = "INDIC";
    public static final String TRADEABLE = "LIVE";
    public static final String SUSPENDED = "STOP";

    public static final int MIN_KNOWN_TENOR_LENGTH = Tenor.SPOT_NEXT.getKey().length();
    public static final int MAX_KNOWN_TENOR_LENGTH = Tenor.BROKEN.getKey().length();

    private final Item item;

    private final boolean tenorDefaultToBroken;

    public D3ForwardQuote(final Item item,
                          final boolean tenorDefaultToBroken) {
        this.item = item;
        this.tenorDefaultToBroken = tenorDefaultToBroken;
    }

    public Tenor tenor() {
        return resolveTenor(item.getName());
    }

    private boolean isTenorDefaultToBroken() {
        return tenorDefaultToBroken;
    }

    public String symbol() {
        return CurrencyPair.toSymbol(item.getValue(INSTRUMENT));
    }

    public Decimal ask() {
        return new Decimal(item.getValue(ASK));
    }

    public Decimal bid() {
        return new Decimal(item.getValue(BID));
    }

    public QuoteState status() {
        return toStatus(item.getValue(STATUS));
    }

    public Optional<LocalDate> maturityDate() {
        return getDate(item, MATURITY);
    }

    public Optional<LocalDate> spotDate() {
        return getDate(item, SPOT_DATE);
    }

    public String trepName() {
        return item.getName();
    }

    private static Optional<LocalDate> getDate(final Item item,
                                               final String fieldName) {
        final String value = item.getValue(fieldName);
        if (Strings.isNullOrEmpty(value)) {
            return Optional.absent();
        }
        return Optional.of(DATE_FORMATTER.parseLocalDate(value));
    }

    /**
     * Extract a tenor key from an item code
     * <ol>
     *      <li><code>currency</code>=D3, will return SPOT for that currency against USD.</li>
     *      <li><code>currency pair</code>=D3, will return SPOT for that currency pair.</li>
     *      <li><code>currency</code><code>tenorName</code>, will return tenor for that currency against USD.</li>
     *      <li><code>currency pair</code><code>tenorName</code>=D3, will return tenor for that currency pair.</li>
     * </ol>
     *
     * Example:
     * <ol>
     *     <li>AUD=D3       AUD/USD for SPOT</li>
     *     <li>AUDEUR=D3    AUD/EUR for SPOT</li>
     *     <li>AUD1M=D3     AUD/USD for 1M</li>
     *     <li>AUDEUR1M=D3  AUD/EUR for 1M</li>
     * </ol>
     *
     * @param code TREP item code. See example above for possible values.
     * @return {@link Tenor} for the item code.
     */
    public static Tenor resolveTenor(final String code) {
        final int symbolLength = code.indexOf('=');
        final int maxTenorLength = Math.min(symbolLength - 3, MAX_KNOWN_TENOR_LENGTH);
        for (int tryLength = maxTenorLength; tryLength >= MIN_KNOWN_TENOR_LENGTH; tryLength--) {
            final String tenorKey = code.substring(symbolLength - tryLength, symbolLength);
            final Tenor tenor = Tenor.parseTenorFromKey(tenorKey);
            if (tenor != null) {
                return tenor;
            }
        }
        return Tenor.SPOT;
    }


    /**
     * @param status
     * @return
     */
    private static QuoteState toStatus(final String status) {
        if (nullSafeEquals(status, INDICATIVE)) {
            return QuoteState.INDICATIVE;
        } else if (nullSafeEquals(status, SUSPENDED)) {
            return QuoteState.ERROR;
        } else if (nullSafeEquals(status, TRADEABLE)) {
            return QuoteState.STREAMABLE;
        } else {
            LOGGER.warn("Unknown forward point status [{}] setting quote state to ERROR", status);
            return QuoteState.ERROR;
        }
    }

    /**
     * Returns a {@link Tenor} instance given a tenor key, otherwise null if
     * the key cannot be parsed
     *
     * @param key
     * @return
     */
    public Tenor toTenor(final String key) {
        if (key == null) { return null; }
        Tenor tenor = Tenor.parseTenorFromKey(key);
        if (tenor == null && isTenorDefaultToBroken()) {
            LOGGER.info("Aliasing unknown tenor to BROKEN for item: {}", key);
            tenor = Tenor.BROKEN;
        }
        return tenor;
    }

    @Override
    public String toString() {
        return "TrepConverter{" +
                "item=" + item +
                '}';
    }
}
