#!/bin/bash
# (c) 2016 ANZ

TITLE="Correlator Event Metrics (MAIN)"
CORNAMES="MAIN"
COLORS1="F15854"
COLORS2="B30000"
LOGDIRS="fxagg"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_evt.common
