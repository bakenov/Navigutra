package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.nio.ByteBuffer;
import java.util.Objects;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.itch.sessioncode.fields.MDUnsubcribe;
import software.chronicle.itch.sessioncode.fields.PriceModifySupport;
import software.chronicle.itch.sessioncode.fields.ProtocolMode;
import software.chronicle.itch.sessioncode.messages.client.LoginRequest;
import software.chronicle.itch.staticcode.Constants;
import software.chronicle.itch.staticcode.VanillaSessionMessageProvider;

public class HspSessionMessageProvider extends VanillaSessionMessageProvider {

    private final String username;
    private final String password;

    public HspSessionMessageProvider(final String username, final String password) {
        this.username = Objects.requireNonNull(username);
        this.password = Objects.requireNonNull(password);
    }

    @Override
    public LoginRequest getLoginRequest(final Bytes<ByteBuffer> bytes, final FixSessionContext context) {
        LoginRequest loginRequest = super.getLoginRequest(bytes, context);
        loginRequest.loginName(this.username);
        loginRequest.password(this.password);
        loginRequest.mDUnsubcribe(MDUnsubcribe.T);
        loginRequest.protocolMode(ProtocolMode.DEFAULT);
        loginRequest.reserved(" ");
        loginRequest.priceModifySupport(PriceModifySupport.CANCEL_NEW);
        loginRequest.tLF(Constants.TLF);
        return loginRequest;
    }
}
