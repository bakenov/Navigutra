package com.anz.markets.efx.ngaro.sbe;

import java.time.LocalDate;

import com.anz.markets.efx.ngaro.codec.DateEncoder;
import com.anz.markets.efx.ngaro.codec.FormattedDateEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

/**
 * Encoder for local date in a fixed length string.
 * <p/>
 * This class thread safe. NOTE however that the {@link FixedStringTarget} passed to the constructor may not be thread
 * safe and hence this encoder instance may also not be thread safe.
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 */
public final class SbeDateEncoder<E> implements DateEncoder<E> {

    private final FormattedDateEncoder<E, FixedStringTarget> delegate;

    public SbeDateEncoder(final E enclosingEncoder, final FixedStringTarget target, final LocalDateFormat localDateFormat) {
        this.delegate = FormattedDateEncoder.forTargetAndFormat(enclosingEncoder,
                target, FixedStringTarget.BYTE_WRITER, localDateFormat);
    }

    public SbeDateEncoder(final E enclosingEncoder, final FixedStringTarget target, final LocalDateEncoder localDateEncoder) {
        this.delegate = FormattedDateEncoder.forTargetAndEncoder(enclosingEncoder,
                target, FixedStringTarget.BYTE_WRITER, localDateEncoder);
    }

    @Override
    public E encodeNullable(final LocalDate localDate) {
        return delegate.encodeNullable(localDate);
    }

    @Override
    public E encode(final int year, final int month, final int day) {
        return delegate.encode(year, month, day);
    }

    @Override
    public E encodeEpochMillis(final long epochMillis) {
        return delegate.encodeEpochMillis(epochMillis);
    }

    @Override
    public E encodeEpochSeconds(final long epochSeconds) {
        return delegate.encodeEpochSeconds(epochSeconds);
    }

    @Override
    public E encodeEpochDays(final long epochDays) {
        return delegate.encodeEpochDays(epochDays);
    }

    @Override
    public E encodeNull() {
        return delegate.encodeNull();
    }

}