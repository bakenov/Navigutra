package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigDecoder;

public interface InstrumentRepository {
    Instrument lookup(long instrumentId);
    Instrument apply(InstrumentConfigDecoder instrumentConfigDecoder);
}