package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.time.LocalDate;
import java.util.function.Supplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoNewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.pojo.model.Hop;
import com.anz.markets.efx.trading.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.RegulatoryTradeId;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(Spockito.class)
public class HspNewOrderSingleHandlerTest {

    private HspNewOrderSingleHandler handler;
    private StandardHeaderTrailer newOrderFixMessage;
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    private Supplier<StringToIntCache> quteIdCacheSupplier = new StringToIntCacheFactory(100, 25, 100, 8, 1);
    private StringToIntCache quoteIdCache = quteIdCacheSupplier.get();

    @Before
    public void setUp(){
        final FixMessageSender fixMessageSender = new FixMessageSender(() -> null){
            @Override
            public void accept(final StandardHeaderTrailer message) {
                newOrderFixMessage = message;
            }
        };

        handler = new HspNewOrderSingleHandler(fixMessageSender,"ANZ", new DefaultNewOrderSingle());
    }

    @Test
    @Spockito.Unroll({
            "| senderCompId | teargetCompId | messageId | clOrdId    | clOrdLinkId    | symbol | marketId   | securityType | settlType | orderQty | displayQty | ordType     | targetStrategyName | price      | side       | currency | timeInForce | transactTime | settlDate  | settlCurrency | effectiveTime | expireTime  | quoteId|",
            "|==============|==============|===========|============|================|========|============|==============|===========|==========|============|=============|====================|============|============|==========|=============|==============|============|===============|===============|=============|========|",
            "| GB:Sender:01 | GB:Target:01 |    9876   | 1122334455 | 1234567890123  | USDTWD | HSP        |    FXSPOT    |    SP     | 1000000  | 1000000    | MARKET      | TWAP               | 0.5674     | BUY        | USD      | IOC         | 345425345    | 2018-01-16 | USD           | 56456435634   | 76456435634 | dfsa34 |",
            "|--------------|--------------|-----------|------------|----------------|--------|------------|--------------|-----------|----------|------------|-------------|--------------------|------------|------------|----------|-------------|--------------|------------|---------------|---------------|-------------|--------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void handleNewOrderSingle (
            final String senderCompId, final String targetCompId, final long messageId, final String clOrdId, final String clOrdLinkId,
            final String symbol, final String marketId, final SecurityType securityType, final Tenor settlType, final double orderQty, final double displayQty,
            final OrderType ordType, final String targetStrategyName, final double price, final Side side,
            final String currency, final TimeInForce timeInForce, final long transactTime, final LocalDate settlDate,
            final String settlCurrency, final long effectiveTime, final long expireTime, final String quoteId) throws Exception {
        //given
        final int quoteIdInt = quoteIdCache.put(quoteId);

        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, securityType, settlType);
        when(subscriptionManager.findById(instrumentKey.instrumentId())).thenReturn(marketDataSubscription);
        when(marketDataSubscription.symbol()).thenReturn(symbol);
        when(marketDataSubscription.stringToIntCache()).thenReturn(quoteIdCache);

        final NewOrderSingle newOrderSingle = TradingMessage.newOrderSingle(
                new MessageHeader(23, 50L),
                new NewOrderSingle.Body(senderCompId, targetCompId, messageId, clOrdId, clOrdLinkId, symbol, marketId, securityType, settlType, orderQty,
                        displayQty, ordType, targetStrategyName, price, side, currency, timeInForce, transactTime,
                        settlDate, settlCurrency, effectiveTime, expireTime, String.valueOf(quoteIdInt)),
                new Party[0], new StrategyParameter[0], new RegulatoryTradeId[0], new Hop[0]);

        final PojoNewOrderSingleDecoder newOrderSingleDecoder = new PojoNewOrderSingleDecoder(() -> handler);

        //when
        newOrderSingleDecoder.decode(newOrderSingle);

        //then
        final DefaultNewOrderSingle newOrder = (DefaultNewOrderSingle)newOrderFixMessage;
        assertThat(newOrder.securityType(), is(com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.SecurityType.FOREIGN_EXCHANGE_CONTRACT));
        assertThat(newOrder.account(), is("ANZ"));
        assertThat(newOrder.symbol(), is("USD/TWD"));
        assertThat(newOrder.side(), is(com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.Side.BUY));
        assertThat(newOrder.orderQty(), is(1000000.0));
        assertThat(newOrder.ordType(), is(OrdType.MARKET));
        assertThat(newOrder.timeInForce(), is(com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.TimeInForce.IMMEDIATE_OR_CANCEL));
    }
}