package com.anz.axle.lg.adapter.anz;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.fix.AsyncMarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.DefaultSubscriptionManager;
import com.anz.axle.lg.adapter.fix.EmptyBookSender;
import com.anz.axle.lg.adapter.fix.LoggedOffState;
import com.anz.axle.lg.adapter.fix.LoggedOnState;
import com.anz.axle.lg.adapter.fix.LoggingSubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.fix.LogonAwareMarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.MarketDataEncodingEmptyBookSender;
import com.anz.axle.lg.adapter.fix.MarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestSender;
import com.anz.axle.lg.config.DefaultPricingEncoderLookup;
import com.anz.axle.lg.config.DefaultTopicRegistry;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.config.SbeMessagePublisher;
import com.anz.axle.lg.config.SnapshotterAccessor;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.CurrentMillisIdFactory;
import com.anz.axle.lg.util.IdFactoryWithMaxRate;
import com.anz.axle.lg.util.IntIdFactory;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamEncoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.queue.Queue;


@Configuration
public class PricingConfig {

    private final String compId;

    public PricingConfig(@Value("${messaging.compId}") final String compId) {
        this.compId = Objects.requireNonNull(compId);
    }

    @Bean
    public IdFactoryWithMaxRate requestIdFactory() {
        return IdFactoryWithMaxRate.rate1024PerSecond();
    }

    @Bean
    public DefaultSubscriptionManager subscriptionManager(final IntIdFactory requestIdFactory) {
        return new DefaultSubscriptionManager(requestIdFactory);
    }

    @Bean
    public CurrentMillisIdFactory pricingMessageIdGenerator() {
        return new CurrentMillisIdFactory();
    }

    @Bean
    public TopicRegistry pricingTopicRegistry(@Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                              @Value("#{${symbol.venues.FXNDF}}") final Map<String, Set<Venue>> fxNdfSymbolVenues,
                                              @Value("#{${symbol.venues.FXFWD}}") final Map<String, Set<Venue>> fxFwdSymbolVenues) {
        return new DefaultTopicRegistry();
    }

    @Bean
    public PricingEncoders<SbeMessage> sbePricingEncoders(@Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbePricingEncoders(() -> sbeMessage);
    }

    @Bean
    protected VenueRequestKeyLookup requestKeyLookup() {
        return new DefaultVenueRequestKeyLookup(Venue.ANZD);
    }

    @Bean
    protected PricingEncoderLookup pricingEncoderLookup(final PricingEncoders<SbeMessage> sbePricingEncoders,
                                                        final PrecisionClock precisionClock,
                                                        final @Value("${market.data.book.initial.size:10}") int marketDataBookInitialSize,
                                                        final LongIdFactory pricingMessageIdGenerator,
                                                        final TopicRegistry pricingTopicRegistry,
                                                        final MessageHandler publisher) {
        return new DefaultPricingEncoderLookup(pricingTopicRegistry, requestKey -> {
            final SnapshotterBuilder builder = SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, marketDataBookInitialSize, DefaultMarketDataEntry::new, MarketDataEntries.Factory.ENTRY_ID_WITH_OPTIONAL_FIELDS_MERGER))
                    .withDownstreamEncoder()
                    .forwardSnapshotsAndIncrementsTo(
                            PricingEncoderSupplier.create(sbePricingEncoders, SbeMessagePublisher.create(requestKey, pricingTopicRegistry, publisher)));

            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock,  pricingMessageIdGenerator::get, compId, 0);
            final UpstreamEncoderConnector upstreamEncoderConnector = builder.buildUpstreamEncoderConnector(UpdateTypeMismatchHandler.IGNORE_REPLACE_ON_ADD_AND_NOOP_ON_REMOVE);
            return SnapshotterAccessor.create(snapshotter, upstreamEncoderConnector);
        });
    }


    @Bean
    public MarketDataEncodingEmptyBookSender emptyBookSender(final VenueRequestKeyLookup requestKeyLookup,
                                                             final PricingEncoderLookup pricingEncoderLookup,
                                                             final PrecisionClock precisionClock,
 final SourceSequencer sourceSequencer) {
        return new MarketDataEncodingEmptyBookSender(requestKeyLookup, pricingEncoderLookup, precisionClock, compId, sourceSequencer);
    }

    @Bean
    public LoggingSubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy() {
        return new LoggingSubscriptionRequestRejectStrategy();
    }

    @Bean
    public LogonAwareMarketDataSubscriber marketDataSubscriber(final SubscriptionManager subscriptionManager,
                                                               final SubscriptionRequestSender encodingSubscriptionSender,
                                                               final EmptyBookSender emptyBookSender,
                                                               final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy) {
        final LoggedOnState loggedOnState = new LoggedOnState(subscriptionManager, encodingSubscriptionSender, emptyBookSender, subscriptionRequestRejectStrategy);
        final LoggedOffState loggedOffState = new LoggedOffState(subscriptionManager, emptyBookSender);

        return new LogonAwareMarketDataSubscriber(loggedOnState, loggedOffState);
    }

    @Bean
    public AsyncMarketDataSubscriber asyncMarketDataSubscriber(@Qualifier("marketDataSubscriber") final MarketDataSubscriber marketDataSubscriber,
                                                               final Queue<Runnable> mainEventLoopQueue) {
        return new AsyncMarketDataSubscriber(mainEventLoopQueue, marketDataSubscriber);
    }

    @Bean
    public ScheduledFuture<?> snapshotForwarderJob(final PricingEncoderLookup pricingEncoderLookup,
                                                   final Queue<Runnable> mainEventLoopQueue,
                                                   final ScheduledExecutorService scheduledExecutorService,
                                                   @Value("${pricing.snapshot.forwarder.period.sec}") int periodSeconds) {
        final Runnable snapshotForwarder = pricingEncoderLookup::forwardCurrentSnapshots;
        return scheduledExecutorService.scheduleWithFixedDelay(() -> mainEventLoopQueue.appender().enqueue(snapshotForwarder), periodSeconds, periodSeconds, TimeUnit.SECONDS);
    }


}
