package com.anz.axle.lg.adapter.acceptance.utils;

import java.io.File;
import java.util.Objects;

import org.fix4j.test.integration.quickfix.QuickFixTestSession;
import org.fix4j.test.session.MatchingSession;
import org.fix4j.test.session.SessionContext;

import net.openhft.chronicle.core.OS;

public class CustomMatchingSession extends MatchingSession {
    final SessionContext sessionContext;
    final boolean forceShutdown;

    public CustomMatchingSession(final SessionContext sessionContext) {
        super(sessionContext);
        this.sessionContext = Objects.requireNonNull(sessionContext);
        this.forceShutdown = Boolean.valueOf(System.getProperty("forceShutdown", "true"));
        System.out.println("Using forceShutdown="+forceShutdown);
    }

    @Override
    public void shutdown() {
        new File(OS.TARGET+"/fix").deleteOnExit();
        final QuickFixTestSession fixTestSession = (QuickFixTestSession)sessionContext.fixEngineSession;
        fixTestSession.shutdown(false);
        if (forceShutdown) fixTestSession.shutdown(true);
    }
}
