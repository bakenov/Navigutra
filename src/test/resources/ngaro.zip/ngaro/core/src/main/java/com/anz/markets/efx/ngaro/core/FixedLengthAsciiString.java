package com.anz.markets.efx.ngaro.core;

import java.util.Arrays;

public final class FixedLengthAsciiString implements MutableAsciiString {

    private final byte[] value;

    public FixedLengthAsciiString(final int length) {
        this.value = new byte[length];
    }

    public int capacity() {
        return value.length;
    }

    @Override
    public int length() {
        return findNull(value);
    }

    @Override
    public byte get(final int index) {
        return value[index];
    }

    @Override
    public FixedLengthAsciiString set(final int index, final byte b) {
        value[index] = b;
        return this;
    }

    @Override
    public FixedLengthAsciiString append(final byte b) {
        value[length()] = b;
        return this;
    }

    @Override
    public <T> int get(final T target, final ByteWriter<? super T> writer, final int offset, final int maxLength) {
        final int copyLen = Math.min(length(), maxLength);
        Bytes.copy(value, ByteReader.BYTE_ARRAY, 0, target, writer, offset, copyLen);
        return copyLen;
    }

    @Override
    public <S> FixedLengthAsciiString set(final S source, final ByteReader<? super S> reader, final int offset, final int length) {
        final int copyLen = Math.min(value.length, length);
        Bytes.copy(source, reader, offset, value, ByteWriter.BYTE_ARRAY, 0, copyLen);
        for (int i = copyLen; i < value.length; i++) {
            value[i] = NULL;
        }
        return this;
    }

    @Override
    public <S> FixedLengthAsciiString append(final S source, final ByteReader<? super S> reader, final int offset, final int length) {
        final int curLen = length();
        final int copyLen = Math.min(value.length - curLen, length);
        Bytes.copy(source, reader, offset, value, ByteWriter.BYTE_ARRAY, curLen, copyLen);
        return this;
    }

    @Override
    public FixedLengthAsciiString clear() {
        Arrays.fill(value, NULL);
        return this;
    }

    @Override
    public int hashCode() {
        return AsciiString.hashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
        return ImmutableAsciiString.equals(this, obj);
    }

    @Override
    @Garbage(Garbage.Type.RESULT)
    public String toString() {
        return new String(value, 0, length());
    }

    //override to return subtype

    @Override
    public FixedLengthAsciiString set(final AsciiString value) {
        MutableAsciiString.super.set(value);
        return this;
    }

    @Override
    public FixedLengthAsciiString append(final AsciiString value) {
        MutableAsciiString.super.append(value);
        return this;
    }

    @Override
    public FixedLengthAsciiString set(final CharSequence value) {
        MutableAsciiString.super.set(value);
        return this;
    }

    @Override
    public FixedLengthAsciiString append(final CharSequence value) {
        MutableAsciiString.super.append(value);
        return this;
    }

    @Override
    public boolean isEmpty() {
        return this.value[0] == NULL;
    }

    @Override
    public int compareTo(final AsciiString o) {
        if (o instanceof FixedLengthAsciiString) {
            return compareTo((FixedLengthAsciiString) o);
        } else {
            return MutableAsciiString.super.compareTo(o);
        }
    }

    int compareTo(final FixedLengthAsciiString o) {
        final int len1 = this.value.length;
        final int len2 = o.value.length;
        final int minLen = Math.min(len1, len2);

        for (int i = 0; i < minLen; ++i) {
            if (get(i) == NULL && o.get(i) == NULL)
                return 0;
            else if (get(i) == NULL)
                return -1;
            else if (o.get(i) == NULL)
                return 1;
            final int cmp = Byte.compare(get(i), o.get(i));
            if (cmp != 0) {
                return cmp;
            }
        }
        return Integer.compare(len1, len2);
    }

    //static helper
    private static final int findNull(final byte[] value) {
        for (int i = 0; i < value.length; i++) {
            if (value[i] == NULL) {
                return i;
            }
        }
        return value.length;
    }
}
