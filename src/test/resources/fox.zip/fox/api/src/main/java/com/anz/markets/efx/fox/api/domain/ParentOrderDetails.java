package com.anz.markets.efx.fox.api.domain;

import java.util.Map;

import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public interface ParentOrderDetails {
    long orderId();

    long origClOrdId();

    long clOrdId();

    long clOrdLinkId();

    String userName();

    String portfolio();

    Region sourceRegion();

    Region targetRegion();

    Venue venue();

    String strategyName();

    Instrument instrument();

    TimeInForce timeInForce();

    OrderType orderType();

    String currency();

    String settlCurrency();

    Side side();

    double price();

    double orderQty();

    String senderCompId();

    long tradeDateMillis();

    long settleDateMillis();

    long transactTimeNanos();

    OrderStatus orderStatus();

    String cancelReason();

    double atMarketQty();

    double toExecuteQty();

    double lastQty();

    double lastUsdQty();

    double lastPx();

    double commissionAdjLastPx();

    double midPx();

    double lastSpotRate();

    double lastForwardPoints();

    double leavesQty();

    double cumQty();

    double avgPx();

    double commissionAdjAvgPx();

    double commission();

    Map<PartyRole, String> partyRoles();
}
