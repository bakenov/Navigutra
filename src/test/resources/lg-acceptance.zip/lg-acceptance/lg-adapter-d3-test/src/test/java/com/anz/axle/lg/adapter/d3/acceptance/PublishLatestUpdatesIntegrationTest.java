package com.anz.axle.lg.adapter.d3.acceptance;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.SubscriptionRequestType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.MarketDataRequest;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;

public class PublishLatestUpdatesIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(PublishLatestUpdatesIntegrationTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;

    final private String senderCompId = "GB:lg-d3";
    final private Venue marketId = Venue.D3;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());

        System.setProperty("retry.task.millis", "20000");
        System.setProperty("expire.task.millis", "20000");
        System.setProperty("publish.latest.updates.task.millis", "3000");
        System.setProperty("retry.subscription.seconds", "10000");
        System.setProperty("missed.update.seconds", "100000");
        System.setProperty("appName", "lg-d3");

        application = new Application("lg-d3", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.throwableQueue().clear();
        acceptanceContext.updateMessageQueue().clear();
        acceptanceContext.pricingRequestMessageQueue().clear();
        acceptanceContext.errorMessageQueue().clear();
        acceptanceContext.subscriptionRequestQueue().clear();
        acceptanceContext.pricingMessageQueue().clear();
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_subscribe_then_get_empty_snapshot_after_missed_update() throws Exception {

        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 1000000;


        final MarketDataRequest marketDataRequest = new MarketDataRequest();
        marketDataRequest.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest.body.mdReqId = 1;
        marketDataRequest.body.marketId = marketId;
        marketDataRequest.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest.body.expireTime = exprireTime;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest);

        final SubscriptionRequest subscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Initial")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        final UpdateMessage updateMessage = UpdateMessageBuilder.defaultMessage()
                .withSubscriptionId(subscribeRequest.subscriptionId())
                .withCurrencies(symbol.substring(0, 3), symbol.substring(3))
                .withTenor("")
                .withSettlementDate(settlmentDate)
                .build();

        acceptanceContext.updateMessageQueue().add(updateMessage);

        PricingMessage initialMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.possResend().eq(false))
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                        .entries().countAtLeast(1)
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        acceptanceContext.pricingMessageQueue().clear();

        PricingMessage resentUpdateMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.possResend().eq(true))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(marketDataRequest.body.instrumentId))
                        .entries().countAtLeast(1)
                        .hops().hasAny())
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }
}