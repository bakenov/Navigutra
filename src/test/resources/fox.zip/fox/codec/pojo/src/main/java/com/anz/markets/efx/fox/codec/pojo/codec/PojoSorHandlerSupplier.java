package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.api.SorHandlerSupplier;
import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoSorHandlerSupplier implements SorHandlerSupplier {

    private final PojoPricingRefreshCompleteHandler pricingRefreshCompleteHandler;
    private final PojoTimerExpiryHandler timerExpiryHandler;
    private final PojoFirewallConfigHandler firewallConfigHandler;
    private final PojoVenueConfigHandler venueConfigHandler;
    private final PojoUserConfigHandler userConfigHandler;
    private final PojoInitialisationHandler initialisationHandler;
    private final PojoInstrumentConfigHandler instrumentConfigHandler;
    private final PojoVenueInstrumentConfigHandler venueInstrumentConfigHandler;

    public PojoSorHandlerSupplier() {
        this(msg -> {});
    }

    public PojoSorHandlerSupplier(final Consumer<? super SorMessage> messageConsumer) {
        pricingRefreshCompleteHandler = new PojoPricingRefreshCompleteHandler(messageConsumer);
        timerExpiryHandler = new PojoTimerExpiryHandler(messageConsumer);
        firewallConfigHandler = new PojoFirewallConfigHandler(messageConsumer);
        venueConfigHandler = new PojoVenueConfigHandler(messageConsumer);
        userConfigHandler = new PojoUserConfigHandler(messageConsumer);
        initialisationHandler = new PojoInitialisationHandler(messageConsumer);
        instrumentConfigHandler = new PojoInstrumentConfigHandler(messageConsumer);
        venueInstrumentConfigHandler = new PojoVenueInstrumentConfigHandler(messageConsumer);
    }

    @Override
    public PojoPricingRefreshCompleteHandler pricingRefreshComplete() {
        return pricingRefreshCompleteHandler;
    }

    @Override
    public TimerExpiryHandler timerExpiryHandler() {
        return timerExpiryHandler;
    }

    @Override
    public FirewallConfigHandler firewallConfigHandler() {
        return firewallConfigHandler;
    }

    @Override
    public VenueConfigHandler venueConfigHandler() {
        return venueConfigHandler;
    }

    @Override
    public UserConfigHandler userConfigHandler() {
        return userConfigHandler;
    }

    @Override
    public InitialisationHandler initialisationHandler() {
        return initialisationHandler;
    }

    @Override
    public InstrumentConfigHandler instrumentConfigHandler() {
        return instrumentConfigHandler;
    }

    @Override
    public VenueInstrumentConfigHandler venueInstrumentConfigHandler() {
        return venueInstrumentConfigHandler;
    }
}
