package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.PricingFirewallType.OUTSIDE_OPERATING_HOUR;
import static com.anz.markets.prophet.domain.PricingFirewallType.PRICE_BARRIER;
import static com.anz.markets.prophet.domain.PricingFirewallType.isBitMaskSetExclusively;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class OutsideOperatingHourFirewallTest extends BaseAcceptanceSpecification {

    @Test
    @RestartBeforeTest(reason = "This firewall has price cache. Need to restart to ensure it runs reliably", initialOperatingHourChime = OperatingHourSpecification.State.UNDEFINED)
    public void whenEnabledOperatingHourIsUndefinedByDefaultAndPriceWillBeSetToIndicative() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            // enabled
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    ));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.10000, 0.00004));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD)).getFirst();
            assertThat(clientPrice.isBidAndOfferIndicative(), is(true));
            Assert.assertThat(isBitMaskSetExclusively(clientPrice.getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            Assert.assertThat(isBitMaskSetExclusively(clientPrice.getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
        }
    }

    @Test
    @RestartBeforeTest(reason = "This firewall has price cache. Need to restart to ensure it runs reliably")
    public void whenDisabledOperatingHourIsOpenByDefault() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            // disabled
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, false)
                    ));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.10000, 0.00004));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD)).getFirst();
            assertThat(clientPrice.isBidAndOfferIndicative(), is(false));
            Assert.assertThat(isBitMaskSetExclusively(clientPrice.getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(false));
            Assert.assertThat(isBitMaskSetExclusively(clientPrice.getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(false));
        }
    }

    @Test
    @RestartBeforeTest(reason = "This firewall has price cache. Need to restart to ensure it runs reliably")
    public void shouldSetIndicativeWhenOutsideOperatingHour() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            // enabled
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    )
            );
        }
        when:
        {
            // received closed
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "CLOSE Mon 01:00 GMT"));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_C, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00000, 0.00004));
        }
        then:
        // WSP_A client prices indicative
        {
            ClientPrice wspAClientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst();
            assertThat(wspAClientPrice.isBidAndOfferIndicative(), is(true));
            Assert.assertThat(isBitMaskSetExclusively(wspAClientPrice.getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            Assert.assertThat(isBitMaskSetExclusively(wspAClientPrice.getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
        }
        and:
        // WSP_B and WSP_C client prices firm
        {
            ClientPrice wspBClientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getFirst();
            assertThat(wspBClientPrice.isBidAndOfferIndicative(), is(false));

            ClientPrice wspCClientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_C)).getFirst();
            assertThat(wspCClientPrice.isBidAndOfferIndicative(), is(false));
        }
        when:
        {
            // received open
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "OPEN Mon 02:00 GMT"));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.20000, 0.00004));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD)).getFirst();
            assertThat(clientPrice.isBidAndOfferIndicative(), is(false));
            Assert.assertThat(isBitMaskSetExclusively(clientPrice.getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(false));
            Assert.assertThat(isBitMaskSetExclusively(clientPrice.getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(false));
        }
    }

    @Test
    @RestartBeforeTest(reason = "This firewall has price cache. Need to restart to ensure it runs reliably")
    public void pushIndicativePricesOnCloseEvent() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            // enabled
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    )
            );
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00000, 0.00004));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // received closed
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "CLOSE Mon 01:00 GMT"));
        }
        then:
        // WSP_B client prices indicative
        {
            ClientPrice wspBClientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getFirst();
            assertThat(wspBClientPrice.isBidAndOfferIndicative(), is(true));
            Assert.assertThat(isBitMaskSetExclusively(wspBClientPrice.getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            Assert.assertThat(isBitMaskSetExclusively(wspBClientPrice.getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
        }
        and:
        // Do not republish WSP_A and WSP_C firm client prices
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_C));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // received another closed
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "CLOSE Mon 01:00 GMT"));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
    }

    @Test
    @RestartBeforeTest(reason = "This firewall has price cache. Need to restart to ensure it runs reliably")
    public void onlyRepublishIndicativePricesForGivenModel() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            // enabled
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    )
            );
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_C, "OPEN Mon 01:00 GMT"));
        }
        when: /* Prime with prices in cache */
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCAD, 1.10000, 0.00004));
        }
        then:
        // All client prices are firm.
        {
            assertThat(prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A)).getFirst()
                    .isBidAndOfferIndicative(), is(false));
            assertThat(prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCAD, Market.WSP_A)).getFirst()
                    .isBidAndOfferIndicative(), is(false));
            assertThat(prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getFirst()
                    .isBidAndOfferIndicative(), is(false));
            assertThat(prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCAD, Market.WSP_B)).getFirst()
                    .isBidAndOfferIndicative(), is(false));
            assertThat(prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_C)).getFirst()
                    .isBidAndOfferIndicative(), is(false));
            assertThat(prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCAD, Market.WSP_C)).getFirst()
                    .isBidAndOfferIndicative(), is(false));
        }
        when: /* WSP_B become close */
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "CLOSE Mon 01:00 GMT"));
        }
        then: /* Republish only WSP_B */
        {
            final LinkedList<ClientPrice> wsp = prophet.expect(ClientPrice.class, exactly(2), isClientPriceMarket(Market.WSP_B));
            assertThat(wsp.get(0).isBidAndOfferIndicative(), is(true));
            assertThat(isBitMaskSetExclusively(wsp.get(0).getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            assertThat(isBitMaskSetExclusively(wsp.get(0).getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            assertThat(wsp.get(1).isBidAndOfferIndicative(), is(true));
            assertThat(isBitMaskSetExclusively(wsp.get(1).getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            assertThat(isBitMaskSetExclusively(wsp.get(1).getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
        }
        and: /* Don't republish WSP_A, WSP_C */
        {
            prophet.notExpect(ClientPrice.class, isClientPriceMarket(Market.WSP_A));
            prophet.notExpect(ClientPrice.class, isClientPriceMarket(Market.WSP_C));
        }
    }

    @Test
    @RestartBeforeTest(reason = "This firewall has price cache. Need to restart to ensure it runs reliably")
    // send in a price that is outside operating hours. Prime the price cache.
    // then send in second price that has breach price barrier
    public void dontPushIndicativePriceAgainWhenAnotherFirewallIsBreached() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(
                            // enabled
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, true))
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.USDCAD, "", 0.9000, 1.0000, Currency.USD)
                            )

                    ));
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.00000, 0.00004));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // received closed
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_B, "CLOSE Mon 01:00 GMT"));
        }
        then: /* WSP_B client prices indicative */
        {
            ClientPrice wspBClientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B)).getFirst();
            assertThat(wspBClientPrice.isBidAndOfferIndicative(), is(true));
            Assert.assertThat(isBitMaskSetExclusively(wspBClientPrice.getBidIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
            Assert.assertThat(isBitMaskSetExclusively(wspBClientPrice.getOfferIndicativeBits(), OUTSIDE_OPERATING_HOUR), is(true));
        }
        and: /* Do not republish WSP_A and WSP_C firm client prices */
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_C));
        }
        when: /* PriceBarrier firewall is triggered. All USD pairs marked indicative */
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCAD, 1.10000, 0.00004));
        }
        then: /* do not resend old WSP_B price that was marked as indicative because of operating hour. */
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_B));
            prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_C));
        }
        and: /* only send out new price */
        {
            final ClientPrice indicatePrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDCAD, Market.WSP_B)).getFirst();

            assertThat(indicatePrice.isBidAndOfferIndicative(), is(true));
            Assert.assertThat(isBitMaskSetExclusively(indicatePrice.getBidIndicativeBits(), PRICE_BARRIER), is(true));
            Assert.assertThat(isBitMaskSetExclusively(indicatePrice.getOfferIndicativeBits(), PRICE_BARRIER), is(true));
        }
    }
}
