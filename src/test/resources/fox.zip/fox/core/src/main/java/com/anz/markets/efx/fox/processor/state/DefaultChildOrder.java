package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.api.domain.ChildOrderDetails;
import com.anz.markets.efx.fox.api.domain.ChildOrderState;
import com.anz.markets.efx.fox.api.domain.ChildOrderVisitor;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;

public class DefaultChildOrder implements ChildOrder {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultChildOrder.class);
    public static final String FOX_COMP_ID = "GB:fox";

    private final Consumer<DefaultChildOrder> releaser;
    private final VenueInstrumentRepository venueInstrumentRepository;

    private final ChildOrder notInitialisedOrderState = new NotInitialisedOrderState();
    private final ChildOrder waitingOrderState = new WaitingOrderState();
    private final ChildOrder workingOrderState = new WorkingOrderState();
    private final ChildOrder pendingCancelOrderState = new PendingCancelOrderState();
    private final ChildOrder deadOrderState = new DeadOrderState();
    private final ChildOrder unknownOrderState = new UnknownOrderState();

    private final ByteValueCache<Venue> venueCache = new ByteValueCache<>(asciiString -> Venue.valueOf(asciiString.toString()));
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> senderCompIdCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> textCache = new ByteValueCache<>(AsciiString::toString);

    private ParentOrder parentOrder;
    private final MutableChildOrderDetails childOrderDetails = new MutableChildOrderDetails();

    private ChildOrder orderState;
    private TimeInForceTimer waitingToDeadTimer;
    private TimeInForceTimer waitingToWorkingTimer;
    private TimeInForceTimer pendingCancelToDeadTimer;

    public DefaultChildOrder(final Consumer<DefaultChildOrder> releaser,
                             final TimeInForceTimer.Factory timeInForceTimerFactory,
                             final VenueInstrumentRepository venueInstrumentRepository) {
        this.releaser = Objects.requireNonNull(releaser);
        this.venueInstrumentRepository = Objects.requireNonNull(venueInstrumentRepository);
        Objects.requireNonNull(timeInForceTimerFactory);

        this.waitingToDeadTimer = timeInForceTimerFactory.create(new WaitingToDeadTimerExpiryHandler(this));
        this.waitingToWorkingTimer = timeInForceTimerFactory.create(new WaitingToWorkingTimerExpiryHandler(this));
        this.pendingCancelToDeadTimer = timeInForceTimerFactory.create(new PendingCancelToDeadTimerExpiryHandler(this));

        transitionToState(notInitialisedOrderState);
    }


    private void resetAndRelease() {
        final long origClOrdId = details().origClOrdId();
        releaser.accept(this);
        transitionToState(notInitialisedOrderState);

        parentOrder = null;
        childOrderDetails.reset();
        LOGGER.info("Child order has been released {}", origClOrdId);
    }

    @Override
    public void onTransition() {
        //no op
    }

    @Override
    public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
        orderState.init(eventContext, newOrderSingleDecoder, parentOrder);
    }

    @Override
    public ParentOrder parentOrder() {
        return orderState.parentOrder();
    }

    @Override
    public ChildOrderDetails details() {
        return orderState.details();
    }

    @Override
    public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
        orderState.requestCancel(commandContext, parentOrderCancelRequestDecoder);
    }

    @Override
    public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
        orderState.applyCancelRequest(orderCancelRequestDecoder);
    }

    @Override
    public void release() {
        orderState.release();
    }

    @Override
    public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
        orderState.applyExecutionReport(executionReportDecoder);
    }

    @Override
    public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
        orderState.applyOrderCancelReject(orderCancelRejectDecoder);
    }

    @Override
    public void accept(final ChildOrderVisitor visitor) {
        this.orderState.accept(visitor);
    }

    private void updateChildOrder(final ExecutionReportDecoder executionReportDecoder) {
        final ExecutionReportDecoder.Body body = executionReportDecoder.body();
        childOrderDetails.orderStatus(body.ordStatus())
        .orderId(body.orderId())
        .clOrdId(body.clOrdId().decodeLongOrZero())
        .lastQty(body.lastQty())
        .lastUsdQty(body.lastUsdQty())
        .lastPx(body.lastPx())
        .commissionAdjLastPx(body.commissionAdjLastPx())
        .midPx(body.midPx())
        .lastSpotRate(body.lastSpotRate())
        .lastForwardPoints(body.lastForwardPoints())
        .leavesQty(body.leavesQty())
        .cumQty(body.cumQty())
        .avgPx(body.avgPx())
        .commissionAdjAvgPx(body.commissionAdjAvgPx())
        .commission(body.commission());
    }

    private void transitionToState(final ChildOrder newState) {
        orderState = newState;
        orderState.onTransition();
    }

    private void encodeCancelRequest(final CommandContext commandContext,
                                     final String textReason) {
        final long sourceSeq = commandContext.idGenerator().getAsLong();
        commandContext.tradingEncoderSupplier().orderCancelRequest().messageStart(commandContext.source(), sourceSeq)
                .marketId().encode(childOrderDetails.venueInstrument().venue().venueId().name())
                .clOrdId().encodeLong(commandContext.idGenerator().getAsLong())
                .origClOrdId().encodeLong(childOrderDetails.origClOrdId())
                .clOrdLinkId().encodeLong(childOrderDetails.clOrdLinkId())
                .messageId(sourceSeq)
                .orderId().encode(childOrderDetails.orderId())
                .orderQty(childOrderDetails.orderQty())
                .ordType(childOrderDetails.orderType())
                .timeInForce(childOrderDetails.timeInForce())
                .senderCompId().encode(commandContext.senderCompId())
                .securityType(childOrderDetails.venueInstrument().instrument().key().securityType())
                .settlType(childOrderDetails.venueInstrument().instrument().key().tenor())
                .symbol().encode(childOrderDetails.venueInstrument().instrument().key().symbol())
                .side(childOrderDetails.side())
                .transactTime(commandContext.precisionClock().nanos())
                .partiesEmpty()
                .hopsEmpty()
                .text().encode(textReason)
                .messageComplete();
    }

    private void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus) {
        final long sourceSeq = commandContext.idGenerator().getAsLong();
        commandContext.tradingEncoderSupplier().executionReport()
                .messageStart(commandContext.source(), sourceSeq)
                .senderCompId().encode(FOX_COMP_ID)
                .messageId(sourceSeq)
                .orderId().encode(childOrderDetails.orderId())
                .clOrdId().encodeLong(childOrderDetails.clOrdId())
                .origClOrdId().encodeLong(childOrderDetails.origClOrdId())
                .clOrdLinkId().encodeLong(childOrderDetails.clOrdLinkId())
                .marketId().encode(childOrderDetails.venueInstrument().venue().venueId().name())
                .execId().encodeLong(commandContext.idGenerator().getAsLong())
                .execType(execType)
                .ordStatus(orderStatus)
                .symbol().encode(childOrderDetails.venueInstrument().instrument().key().symbol())
                .securityType(childOrderDetails.venueInstrument().instrument().key().securityType())
                .settlType(childOrderDetails.venueInstrument().instrument().key().tenor())
                .orderQty(childOrderDetails.orderQty())
                .ordType(childOrderDetails.orderType())
                .targetStrategyName().encodeEmpty()
                .price(childOrderDetails.price())
                .side(childOrderDetails.side())
                .currency().encode(childOrderDetails.currency())
                .timeInForce(childOrderDetails.timeInForce())
                .transactTime(commandContext.precisionClock().nanos())
                .settlCurrency().encode(childOrderDetails.currency())
                .lastQty(childOrderDetails.cumQty())
                .lastPx(childOrderDetails.lastPx())
                .leavesQty(childOrderDetails.leavesQty())
                .lastSpotRate(childOrderDetails.lastSpotRate())
                .cumQty(childOrderDetails.cumQty())
                .avgPx(childOrderDetails.avgPx())
                .commission(childOrderDetails.commission())
                .partiesEmpty()
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsEmpty()
                .quoteId().encodeEmpty()
                .rejectText().encodeEmpty()
                .messageComplete();
    }

    private String getTextReason(final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
        if (parentOrderCancelRequestDecoder == null)
            return OrderTextMessage.EMPTY.getText();

        parentOrderCancelRequestDecoder.body();
        final String cancelReason = parentOrderCancelRequestDecoder.trailer().text().decodeAndCache(textCache);
        return (cancelReason == null || cancelReason.isEmpty()) ? OrderTextMessage.CANCEL_REQUESTED_BY_USER.getText() : cancelReason;
    }

    class NotInitialisedOrderState implements ChildOrder, ChildOrderState.NotInitialisedOrderState {
        @Override
        public void onTransition() {
            //no op
        }

        @Override
        public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
            final long clOrdId = newOrderSingleDecoder.body().clOrdId().decodeLongOrZero();
            final long instrumentId = InstrumentKey.instrumentId(newOrderSingleDecoder.body().symbol().decodeAndCache(symbolCache),
                    newOrderSingleDecoder.body().securityType(),
                    newOrderSingleDecoder.body().settlType());
            final Venue venueId = newOrderSingleDecoder.body().marketId().decodeAndCache(venueCache);

            final VenueInstrument venueInstrument = venueInstrumentRepository.lookup(venueId, instrumentId);

            childOrderDetails
                    .clOrdId(clOrdId)
                    .origClOrdId(clOrdId)
                    .clOrdLinkId(newOrderSingleDecoder.body().clOrdLinkId().decodeLongOrZero())
                    .venueInstrument(venueInstrument)
                    .timeInForce(newOrderSingleDecoder.body().timeInForce())
                    .orderType(newOrderSingleDecoder.body().ordType())
                    .currency(newOrderSingleDecoder.body().currency().decodeAndCache(currencyCache))
                    .settlCurrency(newOrderSingleDecoder.body().settlCurrency().decodeAndCache(currencyCache))
                    .side(newOrderSingleDecoder.body().side())
                    .price(newOrderSingleDecoder.body().price())
                    .orderQty(newOrderSingleDecoder.body().orderQty())
                    .senderCompId(newOrderSingleDecoder.body().senderCompId().decodeAndCache(senderCompIdCache))
                    .tradeDateMillis(eventContext.precisionClock().millis())
                    .settleDateMillis(newOrderSingleDecoder.body().settlDate().decodeEpochMillis())
                    .transactTime(newOrderSingleDecoder.body().transactTime())
                    .leavesQty(newOrderSingleDecoder.body().orderQty())
                    .orderStatus(OrderStatus.PENDING_NEW);

            parentOrder.applyNewChildOrder(DefaultChildOrder.this);
            DefaultChildOrder.this.parentOrder = parentOrder;

            waitingToDeadTimer.reset(childOrderDetails.timeInForce());
            waitingToWorkingTimer.reset(childOrderDetails.timeInForce());
            pendingCancelToDeadTimer.reset(childOrderDetails.timeInForce());

            transitionToState(waitingOrderState);
        }

        @Override
        public ChildOrderDetails details() {
            return childOrderDetails;
        }

        @Override
        public ParentOrder parentOrder() {
            return parentOrder;
        }

        @Override
        public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
            LOGGER.error("Cannot request cancel for not initialised order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot request cancel for not initialised order");
        }

        @Override
        public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            LOGGER.error("Cannot transition to pending cancel not initialised order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot transition to pending cancel not initialised order");
        }

        @Override
        public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.error("Cannot update not initialised order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot update not initialised order");
        }

        @Override
        public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.error("Cannot update not initialised order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot update not initialised order");
        }

        @Override
        public void release() {
            resetAndRelease();
        }

        @Override
        public void accept(final ChildOrderVisitor visitor) {
            visitor.visit(this);
        }
    }

    class WaitingOrderState implements ChildOrder, ChildOrderState.WaitingOrderState {
        @Override
        public void onTransition() {
            LOGGER.info("Switching to waiting order state. origClOrdId {}", childOrderDetails.origClOrdId());
            waitingToDeadTimer.schedule();
            waitingToWorkingTimer.schedule();
        }

        @Override
        public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
            LOGGER.warn("Cannot initialise a waiting order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot initialise a waiting order");
        }

        @Override
        public ChildOrderDetails details() {
            return childOrderDetails;
        }

        @Override
        public ParentOrder parentOrder() {
            return parentOrder;
        }

        @Override
        public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
            encodeCancelRequest(commandContext, getTextReason(parentOrderCancelRequestDecoder));
        }

        @Override
        public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            transitionToState(pendingCancelOrderState);
        }

        @Override
        public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            updateChildOrder(executionReportDecoder);
            if (childOrderDetails.leavesQty() <= 0) {
                transitionToState(deadOrderState);
            } else if (executionReportDecoder.body().ordStatus() == OrderStatus.UNKNOWN) {
                transitionToState(unknownOrderState);
            } else {
                transitionToState(workingOrderState);
            }
            parentOrder.applyChildExecutionReport(executionReportDecoder);
        }

        @Override
        public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.warn("Cannot apply order cancel reject on a waiting order. origClOrdId {}", childOrderDetails.origClOrdId());
        }

        @Override
        public void release() {
            LOGGER.error("Can't release waiting order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Can't release waiting order");
        }

        @Override
        public void accept(final ChildOrderVisitor visitor) {
            visitor.visit(this);
        }

        @Override
        public void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus) {
            DefaultChildOrder.this.sendExecutionReport(commandContext, execType, orderStatus);
        }
    }

    class WorkingOrderState implements ChildOrder, ChildOrderState.WorkingOrderState {
        @Override
        public void onTransition() {
            LOGGER.info("Switching to working order state. origClOrdId {}", childOrderDetails.origClOrdId());
            waitingToWorkingTimer.cancel();
        }

        @Override
        public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
            LOGGER.error("Cannot init a working order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot init a working order");
        }

        @Override
        public ChildOrderDetails details() {
            return childOrderDetails;
        }

        @Override
        public ParentOrder parentOrder() {
            return parentOrder;
        }

        @Override
        public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
            encodeCancelRequest(commandContext, getTextReason(parentOrderCancelRequestDecoder));
        }

        @Override
        public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            updateChildOrder(executionReportDecoder);
            if (childOrderDetails.leavesQty() <= 0) {
                transitionToState(deadOrderState);
            } else if(executionReportDecoder.body().ordStatus() == OrderStatus.UNKNOWN) {
                transitionToState(unknownOrderState);
            }
            parentOrder.applyChildExecutionReport(executionReportDecoder);
        }

        @Override
        public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.warn("Cannot apply order cancel reject on a waiting order. origClOrdId {}", childOrderDetails.origClOrdId());
        }

        @Override
        public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            transitionToState(pendingCancelOrderState);
        }

        @Override
        public void release() {
            LOGGER.error("Can't release working order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Can't release waiting order");
        }

        @Override
        public void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus) {
            DefaultChildOrder.this.sendExecutionReport(commandContext, execType, orderStatus);
        }

        @Override
        public void accept(final ChildOrderVisitor visitor) {
            visitor.visit(this);
        }
    }

    class PendingCancelOrderState implements ChildOrder, ChildOrderState.PendingCancelOrderState {
        @Override
        public void onTransition() {
            LOGGER.info("Switching to pending cancel order state. origClOrdId {}", childOrderDetails.origClOrdId());
            pendingCancelToDeadTimer.schedule();
        }

        @Override
        public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
            LOGGER.error("Cannot init a pending cancel order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot init a pending cancel order");
        }

        @Override
        public ChildOrderDetails details() {
            return childOrderDetails;
        }

        @Override
        public ParentOrder parentOrder() {
            return parentOrder;
        }

        @Override
        public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
            //no op
        }

        @Override
        public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            LOGGER.info("The order is already in pending cancel state. origClOrdId {}", childOrderDetails.origClOrdId());
        }

        @Override
        public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            updateChildOrder(executionReportDecoder);
            if (childOrderDetails.leavesQty() <= 0) {
                transitionToState(deadOrderState);
            } else if(executionReportDecoder.body().ordStatus() == OrderStatus.UNKNOWN) {
                transitionToState(unknownOrderState);
            }
            parentOrder.applyChildExecutionReport(executionReportDecoder);
        }

        @Override
        public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            if (orderCancelRejectDecoder.body().cxlRejReason() == OrderCancelRejectReason.UNKNOWN_ORDER &&
                orderCancelRejectDecoder.body().ordStatus() == OrderStatus.REJECTED) {
                childOrderDetails.orderStatus(orderCancelRejectDecoder.body().ordStatus())
                        .leavesQty(0);
                transitionToState(deadOrderState);
            }
            parentOrder.applyChildOrderCancelReject(orderCancelRejectDecoder);
        }

        @Override
        public void sendExecutionReport(final CommandContext commandContext, final ExecType execType, final OrderStatus orderStatus) {
            DefaultChildOrder.this.sendExecutionReport(commandContext, execType, orderStatus);
        }

        @Override
        public void release() {
            LOGGER.error("Can't release pending cancel order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Can't release pending cancel order");
        }

        @Override
        public void accept(final ChildOrderVisitor visitor) {
            visitor.visit(this);
        }
    }

    class DeadOrderState implements ChildOrder, ChildOrderState.DeadOrderState {
        @Override
        public void onTransition() {
            LOGGER.info("Switching to dead order state. origClOrdId {}", childOrderDetails.origClOrdId());
            waitingToDeadTimer.cancel();
            pendingCancelToDeadTimer.cancel();
        }

        @Override
        public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
            LOGGER.error("Cannot init a dead order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot init a dead order");
        }

        @Override
        public ChildOrderDetails details() {
            return childOrderDetails;
        }

        @Override
        public ParentOrder parentOrder() {
            return parentOrder;
        }

        @Override
        public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
            //no op
        }

        @Override
        public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            LOGGER.error("Can't transition to pending cancel on dead order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Can't transition to pending cancel on dead order");
        }

        @Override
        public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.error("Cannot update a dead order. origClOrdId {}", childOrderDetails.origClOrdId());
        }

        @Override
        public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.error("Cannot update a dead order. origClOrdId {}", childOrderDetails.origClOrdId());
        }

        @Override
        public void release() {
            resetAndRelease();
        }

        @Override
        public void accept(final ChildOrderVisitor visitor) {
            visitor.visit(this);
        }
    }

    class UnknownOrderState implements ChildOrder, ChildOrderState.DeadOrderState {
        @Override
        public void onTransition() {
            LOGGER.info("Switching to unknown order state. origClOrdId {}", childOrderDetails.origClOrdId());
        }

        @Override
        public void init(final EventContext eventContext, final NewOrderSingleDecoder newOrderSingleDecoder, final ParentOrder parentOrder) {
            LOGGER.error("Cannot init a unknown order. origClOrdId {}", childOrderDetails.origClOrdId());
            throw new IllegalStateException("Cannot init a unknown order");
        }

        @Override
        public ChildOrderDetails details() {
            return childOrderDetails;
        }

        @Override
        public ParentOrder parentOrder() {
            return parentOrder;
        }

        @Override
        public void requestCancel(final CommandContext commandContext, final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
            encodeCancelRequest(commandContext, getTextReason(parentOrderCancelRequestDecoder));
        }

        @Override
        public void applyCancelRequest(final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            //no op
        }

        @Override
        public void applyExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            updateChildOrder(executionReportDecoder);
            if (childOrderDetails.leavesQty() <= 0) {
                transitionToState(deadOrderState);
            }
            parentOrder.applyChildExecutionReport(executionReportDecoder);
        }

        @Override
        public void applyOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            if (orderCancelRejectDecoder.body().cxlRejReason() == OrderCancelRejectReason.UNKNOWN_ORDER &&
                orderCancelRejectDecoder.body().ordStatus() == OrderStatus.REJECTED) {
                childOrderDetails.orderStatus(orderCancelRejectDecoder.body().ordStatus())
                        .leavesQty(0);
                transitionToState(deadOrderState);
            }
            parentOrder.applyChildOrderCancelReject(orderCancelRejectDecoder);
        }

        @Override
        public void release() {
            resetAndRelease();
        }

        @Override
        public void accept(final ChildOrderVisitor visitor) {
            visitor.visit(this);
        }
    }
}
