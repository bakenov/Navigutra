package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.annotation.GcFriendly;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("CPD-START")
@Deprecated
// this is hard to predict the order and makes it difficult to change serialisation attributes in a compatible way.
public class FieldReflectionBytesMarshallable {
    private static final Logger LOGGER = LoggerFactory.getLogger(FieldReflectionBytesMarshallable.class);
    public static final FieldReflectionBytesMarshallable INSTANCE = new FieldReflectionBytesMarshallable();

    private final Map<String, Class> classNameToClassMap = new HashMap<>();

    private FieldReflectionBytesMarshallable() {
        classNameToClassMap.put(Currency.class.getName(), Currency.class);
    }

    @GcFriendly("Only generate about 1000 bytes overheads")
    public void write(final Object object,
                      final ProphetBytes out) {
        try {
            if (object.getClass().isEnum()) {
                out.writeEnum((Enum)object);
                return;
            }

            for (Field field : object.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                if (!Modifier.isStatic(field.getModifiers()) && !Modifier.isTransient(field.getModifiers())) {
                    try {
                        if (field.getType().isEnum()) {
                            final Object o = field.get(object);
                            GcFriendlyAssert.notNull(o, "Field value must not be null: %s", field);
                            out.writeEnum((Enum)o);
                        } else if (field.getType() == boolean.class) {
                            out.writeBoolean(field.getBoolean(object)); // explicitly called primitive method to avoid autoboxing
                        } else if (field.getType() == double.class) {
                            out.writeDouble(field.getDouble(object));
                        } else if (field.getType() == long.class) {
                            out.writeLong(field.getLong(object));
                        } else if (field.getType() == int.class) {
                            out.writeInt(field.getInt(object));
                        } else if (field.getType() == String.class) {
                            final Object o = field.get(object);
                            GcFriendlyAssert.notNull(o, "Field value must not be null: %s %s", field.getName(), field);
                            out.writeUTF8((String) o);
                        } else if (field.getType() == List.class) {
                            final List o = (List) field.get(object);
                            writeList(out, o);
                        } else if (ProphetMarshallable.class.isAssignableFrom(field.getType())) {
                            ((ProphetMarshallable) field.get(object)).writeMarshallable(out);
                        } else {
                            throw new IllegalArgumentException("Could not write to bytes. Unknown type: " + field + " - " + field.getName());
                        }
                    } catch (IllegalArgumentException iae) {
                        throw new IllegalArgumentException("Error in config " + field, iae);
                    }
                }
            }
        } catch (IllegalAccessException iae) {
            throw new RuntimeException("Unable to read from field.", iae);
        }
    }

    @GcFriendly("Only generate about 1000 bytes overheads")
    public void read(final ProphetBytes in,
                     final Object object) {
        try {
            object.getClass().getDeclaredFields();
            for (Field field : object.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                if (!Modifier.isStatic(field.getModifiers()) && !Modifier.isTransient(field.getModifiers())) {
                    if (field.getType().isEnum()) {
                        field.set(object, in.readEnum(field.getType()));
                    } else if (field.getType() == boolean.class) {
                        field.setBoolean(object, in.readBoolean());
                    } else if (field.getType() == double.class) {
                        field.set(object, in.readDouble());
                    } else if (field.getType() == long.class) {
                        field.set(object, in.readLong());
                    } else if (field.getType() == int.class) {
                        field.set(object, in.readInt());
                    } else if (field.getType() == String.class) {
                        field.set(object, in.readUTF8());
                    } else if (field.getType() == List.class) {
                        final List o = (List) field.get(object);
                        readList(in, ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0], o);
                    } else if (ProphetMarshallable.class.isAssignableFrom(field.getType())) {
                        ((ProphetMarshallable) field.get(object)).readMarshallable(in);
                    } else {
                        throw new IllegalArgumentException("Could not read from bytes. Unknown type: " + field);
                    }
                }
            }
        } catch (IllegalAccessException iae) {
            throw new RuntimeException("Unable to read from field.", iae);
        }
    }

    private void readList(final ProphetBytes in,
                          final Type type,
                          final List o) {
        o.clear();
        final int size = in.readInt();
        for (int i = 0; i < size; i++) {
            final Class aClass = classNameToClassMap.get(type.getTypeName());
            if (aClass == null) {
                throw new IllegalArgumentException("Unsupported list type. Add the type into " + this.getClass().getName() + " class to support unmarshall by reflection.");
            }
            // only currently supports list of enums, change it if you need.
            o.add(in.readEnum(aClass));
        }
    }

    private void writeList(final ProphetBytes out,
                           final List o) {
        out.writeInt(o.size());
        for (int i = 0; i < o.size(); i++) {
            write(o.get(i), out);
        }
    }
}
