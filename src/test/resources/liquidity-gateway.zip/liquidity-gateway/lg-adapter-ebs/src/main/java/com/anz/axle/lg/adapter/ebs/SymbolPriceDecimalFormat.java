package com.anz.axle.lg.adapter.ebs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class SymbolPriceDecimalFormat {
    private static final Logger LOGGER = LoggerFactory.getLogger(SymbolPriceDecimalFormat.class);
    private final Map<String, Integer> symbolDecimalPlaceMap = new HashMap<>();
    private final StringBuilder sb = new StringBuilder();

    public SymbolPriceDecimalFormat(final Map<Integer, Set<String>> decimalSymbols) {
        Objects.requireNonNull(decimalSymbols);
        decimalSymbols.forEach((decimalPlace, symbolSet) ->
            symbolSet.forEach(symbol -> symbolDecimalPlaceMap.put(symbol, decimalPlace))
        );
        LOGGER.info("symbol.price.decimal.places={}", symbolDecimalPlaceMap);
    }

    public CharSequence formatPrice(final CharSequence symbol, final double price) {
        if (symbol != null) {
            final Integer decimalPlace = symbolDecimalPlaceMap.get(symbol);
            if (decimalPlace != null) {
                return formatPrice(price, decimalPlace);
            }
        }
        sb.setLength(0);
        return sb.append(price);
    }

    private CharSequence formatPrice(final double price, final int decimalPlace) {
        sb.setLength(0);
        sb.append(price);

        final int idx = sb.indexOf(".");
        final int currentDecimalPlace = sb.length() - (idx+1);
        final int placesToAdd = currentDecimalPlace >= decimalPlace ? 0 : decimalPlace - currentDecimalPlace;

        for (int i = 0; i < placesToAdd; i++) {
            sb.append("0");
        }

        if (currentDecimalPlace > decimalPlace) {
            final int end = sb.length();
            sb.delete(idx+decimalPlace+1, end);
        }
        return sb;
    }
}
