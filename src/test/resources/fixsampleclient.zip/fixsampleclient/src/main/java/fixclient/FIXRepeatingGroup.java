// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.util.ArrayList;

/**
 * A wrapper for a FIX repeating group structure within a FIX message. This is
 * used as part of the result model from the XML parsing of scripts.
 */
public class FIXRepeatingGroup
{
    private final FIXField                       groupTag;
    private final ArrayList<ArrayList<FIXField>> groupItems;

    /**
     * main constructor
     * 
     * @param groupTag
     * @param groupTagValue
     * @throws IllegalStateException
     */
    public FIXRepeatingGroup(final String groupTag, final String groupTagValue) throws IllegalStateException
    {
        this.groupTag = new FIXField(groupTag, groupTagValue);
        this.groupItems = new ArrayList<ArrayList<FIXField>>();
    }

    /**
     * Gets the group tag from this group
     * 
     * @return the group tag
     */
    public FIXField getGroupTag()
    {
        return this.groupTag;
    }

    /**
     * Returns all group items
     * 
     * @return the group items
     */
    public ArrayList<ArrayList<FIXField>> getGroupItems()
    {
        return this.groupItems;
    }

    /**
     * Adds a group item, consisting of a collection of FIXFields, to a group
     * 
     * @param groupItem
     */
    public void addGroupItem(final ArrayList<FIXField> groupItem)
    {
        this.groupItems.add(groupItem);
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer(this.groupTag.getId()).append("=")
                .append(this.groupTag.getValue());

        for (final ArrayList<FIXField> groupItem : this.groupItems)
        {
            for (final FIXField field : groupItem)
            {
                buffer.append(" ")
                        .append(field.getId())
                        .append("=")
                        .append(field.getValue());
            }
        }

        return buffer.toString();
    }

    /**
     * Returns the delimiter field id for this grouping - i.e. the id of the
     * first field in the first (and every) group item.
     * 
     * @return the id of the delimiter tag
     */
    public String getDelimiterFieldId()
    {
        if (this.groupItems.size() > 0)
        {
            // Return the id of the first field in the first group item
            return this.groupItems.iterator().next().iterator().next().getId();
        }

        return null;
    }
}
