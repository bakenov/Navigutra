package com.anz.markets.efx.fox.common.pricing;

import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

public interface PricingFeed {
    interface Request {
        void submit(long instrumentId, boolean forceSnapshot);
    }

    interface OpenOrdersObserver {
        void applyExecutionReport(ExecutionReportDecoder executionReport);
        int count(long instrumentId);
        void clear();
    }
}
