package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.efx.ngaro.math.Epsilon;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HedgeFirewallPnlStatusMatcher extends BaseMatcher<HedgeFirewallStatus> {
    private final HedgeFirewallStatus expected;

    private final double expectedDisplacement;
    private final double expectedPnl;
    private final double expectedMin;
    private final double expectedMax;
    private final double expectedLimit;

    private double actualDisplacement;
    private double actualPnl;
    private double actualMin;
    private double actualMax;
    private double actualLimit;

    public HedgeFirewallPnlStatusMatcher(final HedgeFirewallStatus expected,
                                         final double expectedDisplacement,
                                         final double expectedPnl,
                                         final double expectedMin,
                                         final double expectedMax,
                                         final double expectedLimit) {
        this.expected = expected;
        this.expectedDisplacement = expectedDisplacement;
        this.expectedPnl = expectedPnl;
        this.expectedMin = expectedMin;
        this.expectedMax = expectedMax;
        this.expectedLimit = expectedLimit;
    }

    @Override
    public boolean matches(final Object o) {
        final HedgeFirewallStatus actual = (HedgeFirewallStatus) o;
        parseDescription(actual.getDescription());

        return actual.getPortfolio() == expected.getPortfolio() && actual.getHedgeFirewallType() == expected.getHedgeFirewallType()
                && actual.getStatus() == expected.getStatus()
                && Epsilon.EPS_0_0001.equalsEpsilon(expectedDisplacement,actualDisplacement)
                && new IsRoundedTo(expectedPnl).matches(actualPnl)
                && new IsRoundedTo(expectedMin).matches(actualMin)
                && new IsRoundedTo(expectedMax).matches(actualMax)
                && new IsRoundedTo(expectedLimit).matches(actualLimit);
    }

    public void parseDescription(final CharSequence description) {
        final Pattern p = Pattern.compile("(.*)/(.*)/(.*)/(.*)/(.*)");
        final Matcher m = p.matcher(description.toString());
        if (m.matches()) {
            actualDisplacement = parseNumber(m.group(1));
            actualPnl = parseNumber(m.group(2));
            actualMin = parseNumber(m.group(3));
            actualMax = parseNumber(m.group(4));
            actualLimit = parseNumber(m.group(5));
        }
    }

    private double parseNumber(final String desc) {
        try {
            if (desc.equals(String.valueOf(Double.NaN))) {
                return Double.NaN;
            }
            NumberFormat format = NumberFormat.getInstance(Locale.ENGLISH);
            Number number = format.parse(desc);
            return number.doubleValue();
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid number: " + desc);
        }
    }

    @Override
    public void describeTo(final Description description) {
        description.appendText("portfolio: ").appendValue(expected.getPortfolio())
                .appendText(", type: ").appendValue(expected.getHedgeFirewallType())
                .appendText(", status: ").appendValue(expected.getStatus())
                .appendText(", displacement: ").appendValue(expectedDisplacement)
                .appendText(", pnl: ").appendValue(expectedPnl)
                .appendText(", min: ").appendValue(expectedMin)
                .appendText(", max: ").appendValue(expectedMax)
                .appendText(", limit: ").appendValue(expectedLimit);
    }

    @Override
    public void describeMismatch(final Object item,
                                 final Description description) {
        final HedgeFirewallStatus actual = (HedgeFirewallStatus) item;

        description.appendText("portfolio: ").appendValue(actual.getPortfolio())
                .appendText(", type: ").appendValue(actual.getHedgeFirewallType())
                .appendText(", status: ").appendValue(actual.getStatus())
                .appendText(", displacement: ").appendValue(actualDisplacement)
                .appendText(", pnl: ").appendValue(actualPnl)
                .appendText(", min: ").appendValue(actualMin)
                .appendText(", max: ").appendValue(actualMax)
                .appendText(", limit: ").appendValue(actualLimit);

    }
}
