package com.anz.axle.lg.adapter.ebs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.DefaultPropertiesPersister;

import com.anz.markets.efx.ngaro.api.Venue;

public class PasswordManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(PasswordManager.class);
    private static final int PASSWORD_MAX_LEN = 16;
    private final String PASSWORD_PROP_NAME = "ebs.fix.user.request.password";
    private String password;
    private String newPassword;
    private final String userName;
    private final Venue venue;
    private final String passwordPropertiesFileName;

    public PasswordManager(final String userName,
                           final String password,
                           final Venue venue,
                           final String passwordPropertiesFileName) {
        this.userName = Objects.requireNonNull(userName);
        this.password = Objects.requireNonNull(password);
        this.venue = Objects.requireNonNull(venue);
        this.passwordPropertiesFileName = Objects.requireNonNull(passwordPropertiesFileName);
        LOGGER.info("Init with userName={}, password={}, passwordPropertiesFileName={}",userName,password,passwordPropertiesFileName);
    }

    public String userName() {
        return this.userName;
    }
    public String password() {
        return this.password;
    }
    public String newPassword() {
        return this.newPassword;
    }

    public void clearNewPassword() {
        this.newPassword = null;
    }

    public String generatePasswordAndSaveNewPassword() {
        // where D=day-of-year, A=milli-of-day
        final String generatedPassword = userName + LocalDateTime.now().format(DateTimeFormatter.ofPattern("DA"));
        newPassword = generatedPassword.length() > PASSWORD_MAX_LEN ? generatedPassword.substring(0, PASSWORD_MAX_LEN) : generatedPassword;
        LOGGER.info("New Venue={} password={} created for userName={}", venue, newPassword, userName);
        return newPassword;
    }

    public void update() {
        if (newPassword != null) {
            save(newPassword);
            password = newPassword;
            newPassword = null;
        } else {
            LOGGER.info("No new password to update");
        }
    }

    protected void save(final String newPassword) {
        try {
            final File passwordPropertiesFile = new File(passwordPropertiesFileName);
            final Properties properties = loadOrCreate(passwordPropertiesFile);
            properties.setProperty(PASSWORD_PROP_NAME, newPassword);

            LOGGER.info("Writing new password properties {}={} to {}", PASSWORD_PROP_NAME, newPassword, passwordPropertiesFile.getAbsolutePath());
            try (final FileOutputStream fos = new FileOutputStream(passwordPropertiesFile)) {
                new DefaultPropertiesPersister().store(properties, fos, "Update " + venue + " " + userName + " password from " + password );
            }
        } catch (Exception e) {
            LOGGER.warn("Unexpected exception updating PropertiesFile: {} ", passwordPropertiesFileName, e);
        }
    }

    public Properties loadOrCreate(final File passwordPropertiesFile) throws IOException {

        if (!passwordPropertiesFile.exists()) {
            if (!passwordPropertiesFile.getParentFile().exists()) {
                passwordPropertiesFile.getParentFile().mkdirs();
            }
            passwordPropertiesFile.createNewFile();
            passwordPropertiesFile.setReadable(true);
            passwordPropertiesFile.setWritable(true);
        }

        final Properties properties = new Properties();
        if (passwordPropertiesFile.exists()) {
            try (final FileInputStream inputStream = new FileInputStream(passwordPropertiesFile)) {
                properties.load(inputStream);
            }
        }
        return properties;
    }
}
