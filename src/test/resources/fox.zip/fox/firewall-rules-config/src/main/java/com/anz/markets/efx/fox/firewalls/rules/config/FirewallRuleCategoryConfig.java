package com.anz.markets.efx.fox.firewalls.rules.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class FirewallRuleCategoryConfig {

    private List<FirewallTypeConfig> firewallTypeConfigs = new ArrayList<>();

    public void setFirewallTypeConfigs(final List<FirewallTypeConfig> firewallTypeConfigs){
        this.firewallTypeConfigs = firewallTypeConfigs;
    }

    public List<FirewallTypeConfig> getFirewallTypeConfigs() {
        return firewallTypeConfigs;
    }
}
