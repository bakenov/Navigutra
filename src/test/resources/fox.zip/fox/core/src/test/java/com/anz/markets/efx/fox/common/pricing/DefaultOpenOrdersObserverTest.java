package com.anz.markets.efx.fox.common.pricing;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.tools4j.spockito.Table;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import static org.assertj.core.api.Assertions.assertThat;

class DefaultOpenOrdersObserverTest {
    private DefaultOpenOrdersObserver openOrdersObserver;
    private TestExecutionReportFactory testExecutionReportFactory = new TestExecutionReportFactory();

    @BeforeEach
    void setUp() {
        openOrdersObserver = new DefaultOpenOrdersObserver();
    }

    @Test
    void applyExecutionReports_and_assert_counts() {
        //given
        String[] appliedExecutionReports = new String[] {
                "| timeNanos   | region | targetStrategy | portfolio | username | securityType | tenor | symbol | orderQty | markets   | execType  | leavesQty  |",
                "|=============|========|================|===========|==========|==============|=======|========|==========|===========|===========|============|",
                "| 1000000     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | NEW       | 1000000    |",
                "| 1000001     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDCAD | 1000000  | FXALLMB   | NEW       | 1000000    |",
                "| 1000002     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | NEW       | 1000000    |",
                "| 1000003     | GB     | MID            | XEFX      | anufriea | FXSPOT       | SP    | AUDCAD | 1000000  | FXALLMB   | NEW       | 1000000    |",
                "| 1000004     | GB     | MID            | XEFX      | marsdenj | FXSPOT       | SP    | AUDUSD | 1000000  | FXALLMB   | TRADE     | 0          |",
                "|-------------|--------|----------------|-----------|----------|--------------|-------|--------|----------|-----------|-----------|------------|"
        };

        final TestExecutionReportFactory.ExecutionReportStub[] executionReportStubs = Table.parse(TestExecutionReportFactory.ExecutionReportStub.class, appliedExecutionReports);

        //when
        Arrays.stream(executionReportStubs).forEach(executionReportStub -> {
            final ExecutionReportDecoder executionReport = testExecutionReportFactory.createExecutionReport(executionReportStub);
            openOrdersObserver.applyExecutionReport(executionReport);
        });

        //then
        assertThat(openOrdersObserver.count(InstrumentKey.instrumentId("AUDUSD", SecurityType.FXSPOT, Tenor.SP))).isEqualTo(1);
        assertThat(openOrdersObserver.count(InstrumentKey.instrumentId("AUDCAD", SecurityType.FXSPOT, Tenor.SP))).isEqualTo(2);

        //when
        openOrdersObserver.clear();

        //then
        assertThat(openOrdersObserver.count(InstrumentKey.instrumentId("AUDCAD", SecurityType.FXSPOT, Tenor.SP))).isEqualTo(0);
    }
}