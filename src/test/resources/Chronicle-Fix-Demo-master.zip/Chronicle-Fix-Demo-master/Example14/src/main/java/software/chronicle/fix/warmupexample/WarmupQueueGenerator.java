/*
 * Copyright 2014-2018 Chronicle Software
 *
 * http://chronicle.software
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package software.chronicle.fix.warmupexample;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.bytes.BytesStore;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.queue.ExcerptAppender;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.DocumentContext;
import software.chronicle.fix.staticcode.FixVersion;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.generators.Publisher;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.fix.staticcode.msgseq.fixlog.VanillaFixLog;
import software.chronicle.generated.code.fields.ExecTransType;
import software.chronicle.generated.code.messages.ExecutionReport;

import java.nio.ByteBuffer;

public class WarmupQueueGenerator {
    private static final Bytes bytes = Bytes.allocateElasticDirect(1024);
    private static final Bytes<ByteBuffer> flbytes = Bytes.elasticByteBuffer(1024);

    // Run with ./warmupqueue argument to generate the queue referred to from the config
    public static void main(String[] args) {
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        if (args.length != 1) {
            throw new IllegalArgumentException("Expected 1 argument - path to the queue");
        }
        String path = args[0];
        SingleChronicleQueue fixQueue = SingleChronicleQueueBuilder.binary(path).build();
        ExcerptAppender appender = fixQueue.acquireAppender();

        FixLog fixLog = new VanillaFixLog(flbytes);
        ExecutionReport er = ExecutionReport.newExecutionReport(bytes);
        fixLog.msgType(er.msgType());
        fixLog.fixVersion(FixVersion.V4_2);
        BytesStore addressBytes = Publisher.addressBytesFor(new SessionID("ISLD", "TW"));

        // this is an example only. Realistically one needs about 10000 messages to properly warm up the parsers
        for (int i = 0; i < 100; i++) {
            er.reset();
            er.avgPx(12.0);
            er.clOrdID(Bytes.allocateDirect("CL_ORD_ID".getBytes()));
            er.side('1');
            er.execTransType(ExecTransType.NEW);
            Publisher.publishToBytes(bytes, fixLog.msgType(), i, addressBytes,
                    System.currentTimeMillis(), fixLog.fixVersion());

            try (DocumentContext dc = appender.writingDocument()) {
                fixLog.msg(bytes);
                fixLog.writeMarshallable(dc.wire().bytes());
            }
        }

    }
}
