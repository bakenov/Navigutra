package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoTimerExpiryHandler;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class TimerExpiry implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public TimerExpiry() {
        this(new MessageHeader(), new Body());
    }

    public TimerExpiry( final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
    }

    public static final class Body {
        public long triggeredTime;
        public long timerId;
        public TimerGroup timerGroup;

        public Body() {
            super();
        }

        public Body(final long triggeredTime,
                    final long orderId,
                    final long timerId,
                    final TimerGroup timerGroup) {
            this.triggeredTime = triggeredTime;
            this.timerId = timerId;
            this.timerGroup = timerGroup;
        }

        @Override
        public String toString() {
            return "Body{" +
                    ", triggeredTime=" + triggeredTime +
                    ", timerId=" + timerId +
                    ", timerGroup=" + timerGroup +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "TimerExpiry{" +
                "header=" + header +
                ", body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.timerExpiryEncoder());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.timerExpiry().create(messageConsumer));
    }

    public void encode(final TimerExpiryEncoder encoder) {
        encoder.messageStart(header.source, header.sourceSeq)
                .triggeredTime(body.triggeredTime)
                .timerId(body.timerId)
                .timerGroup(body.timerGroup)
                .messageComplete();
    }

    public static <M> TimerExpiry decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoTimerExpiryHandler handler = new PojoTimerExpiryHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.timerExpiry().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onTimerExpiry(this);
    }
}
