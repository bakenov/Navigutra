package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.metric.LiveOrdersMetric;
import com.anz.markets.efx.fox.firewall.metric.LocalOrSharedTimePeriodMetricKeyFactory;
import com.anz.markets.efx.fox.firewall.metric.MetricPeriod;
import com.anz.markets.efx.fox.firewall.metric.OrderMaxQuantityMetric;
import com.anz.markets.efx.fox.firewall.metric.OrderSubmitThroughputMetric;
import com.anz.markets.efx.fox.firewall.metric.OrderUsdQuantityThroughputMetric;
import com.anz.markets.efx.fox.firewall.metric.RuleIdMetricKeyFactory;
import com.anz.markets.efx.fox.firewall.rule.NonPeriodRuleConfigCommandHandler;
import com.anz.markets.efx.fox.firewall.rule.TimePeriodRuleConfigCommandHandler;
import com.anz.markets.efx.fox.firewall.state.CustomRuleFirewall;
import com.anz.markets.efx.fox.firewall.state.MetricBasedFirewall;
import com.anz.markets.efx.fox.firewall.state.ParentOrderExecutionReportFilter;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public interface Firewall {
    void onFirewallConfigRuleRequest(CommandContext commandContext, FirewallConfigDecoder firewallConfigDecoder);

    void applyFirewallConfigRuleResponse(EventContext eventContext, FirewallConfigDecoder firewallConfigDecoder);

    void applyExecutionReport(EventContext eventContext, ExecutionReportDecoder executionReportDecoder);

    String firewallName();

    boolean accept(NewOrderSingleDecoder newOrderSingle, CommandContext commandContext);

    static Firewall customRules(final String name,
                           final OrderConsumer.ErrorHandler errorHandler,
                           final Rule... rules) {
        return new CustomRuleFirewall(name, errorHandler, rules);
    }

    static Firewall orderSubmitThroughput(final String name,
                                          final UserRepository userRepository,
                                          final OrderConsumer.ErrorHandler errorHandler) {
        return new MetricBasedFirewall(name,
                ruleConfig -> new OrderSubmitThroughputMetric(MetricPeriod.toMillis(ruleConfig)),
                new LocalOrSharedTimePeriodMetricKeyFactory(),
                new TimePeriodRuleConfigCommandHandler(name),
                userRepository,
                errorHandler,
                new ParentOrderExecutionReportFilter());
    }

    static Firewall orderTotalUsdQuantityThroughput(final String name,
                                                    final UserRepository userRepository,
                                                    final InstrumentRepository instrumentRepository,
                                                    final OrderConsumer.ErrorHandler errorHandler) {
        return new MetricBasedFirewall(name,
                ruleConfig -> new OrderUsdQuantityThroughputMetric(instrumentRepository, MetricPeriod.toMillis(ruleConfig)),
                new LocalOrSharedTimePeriodMetricKeyFactory(),
                new TimePeriodRuleConfigCommandHandler(name),
                userRepository,
                errorHandler,
                new ParentOrderExecutionReportFilter());
    }

    static Firewall orderMaxQuantity(final String name,
                                     final UserRepository userRepository,
                                     final OrderConsumer.ErrorHandler errorHandler) {
        return new MetricBasedFirewall(name,
                ruleConfig -> new OrderMaxQuantityMetric(),
                new RuleIdMetricKeyFactory(),
                new NonPeriodRuleConfigCommandHandler(name),
                userRepository,
                errorHandler,
                new ParentOrderExecutionReportFilter());
    }

    static Firewall liveOrders(final String name,
                               final UserRepository userRepository,
                               final OrderConsumer.ErrorHandler errorHandler) {
        return new MetricBasedFirewall(name,
                ruleConfig -> new LiveOrdersMetric(),
                new RuleIdMetricKeyFactory(),
                new NonPeriodRuleConfigCommandHandler(name),
                userRepository,
                errorHandler,
                new ParentOrderExecutionReportFilter());
    }

}
