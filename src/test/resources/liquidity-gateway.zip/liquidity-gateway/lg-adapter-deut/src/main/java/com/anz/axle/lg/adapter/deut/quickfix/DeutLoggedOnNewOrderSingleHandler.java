package com.anz.axle.lg.adapter.deut.quickfix;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Message;
import quickfix.field.Account;
import quickfix.field.ClOrdID;
import quickfix.field.Currency;
import quickfix.field.HandlInst;
import quickfix.field.MsgType;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.Price;
import quickfix.field.QuoteID;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix44.NewOrderSingle;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public final class DeutLoggedOnNewOrderSingleHandler implements NewOrderSingleHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeutLoggedOnNewOrderSingleHandler.class);

    private static final boolean INCLUDE_MILLISECONDS = true;
    private final Consumer<Message> fixMessageSender;
    private final SubscriptionManager subscriptionManager;

    private final NewOrderSingle newOrderSingle = new NewOrderSingle();
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final Date transactTime = new Date();
    private final String account;

    private MarketDataSubscription marketDataSubscription;


    public DeutLoggedOnNewOrderSingleHandler(final Consumer<Message> fixMessageSender,
                                             final SubscriptionManager subscriptionManager,
                                             final String account) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.account = Objects.requireNonNull(account);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.clear();
        marketDataSubscription = null;
    }

    @Override
    public void onBody(final Body body) {
        final String symbol6 = symbol6(body);
        final long instrumentId = InstrumentKey.instrumentId(symbol6, body.securityType(), body.settlType());
        marketDataSubscription = subscriptionManager.findById(instrumentId);

        newOrderSingle.getHeader().setString(MsgType.FIELD, MsgType.ORDER_SINGLE);
        newOrderSingle.setString(ClOrdID.FIELD, body.clOrdId().decodeStringOrNull());
        newOrderSingle.setString(Account.FIELD, account);
        newOrderSingle.setString(Symbol.FIELD, marketDataSubscription != null ? marketDataSubscription.symbol() : SymbolNormaliser.toSymbol7(symbol6));
        newOrderSingle.setChar(HandlInst.FIELD, HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        newOrderSingle.setChar(quickfix.field.Side.FIELD, side(body.side()));
        newOrderSingle.setDouble(OrderQty.FIELD, body.orderQty());
        newOrderSingle.setString(Currency.FIELD, currency(body));
        newOrderSingle.setChar(OrdType.FIELD, orderType(body.ordType()));
        if (body.price() != 0.0 && body.price() != Double.NaN) {newOrderSingle.setDouble(Price.FIELD, body.price());}
        newOrderSingle.setChar(quickfix.field.TimeInForce.FIELD, timeInForce(body.timeInForce()));
        newOrderSingle.setUtcTimeStamp(TransactTime.FIELD, transactTime(body.transactTime()), INCLUDE_MILLISECONDS);
    }

    private String symbol6(final Body body) {
        return body.symbol().decodeAndCache(symbolCache);
    }

    /**
     * uses a reusable date object.
     * @param transactTimeNanos
     * @return
     */
    private Date transactTime(long transactTimeNanos) {
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(transactTimeNanos));
        return transactTime;
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case LIMIT: return OrdType.LIMIT;
            case PREVIOUSLY_QUOTED: return OrdType.PREVIOUSLY_QUOTED;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case IOC: return quickfix.field.TimeInForce.IMMEDIATE_OR_CANCEL;
            case FOK: return quickfix.field.TimeInForce.FILL_OR_KILL;
            default: throw new IllegalArgumentException("Unsupported timeInForce" + timeInForce);
        }
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return quickfix.field.Side.BUY;
            case SELL: return quickfix.field.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }

    @Override
    public void onBody_QuoteId(final StringDecoder quoteId) {
        final int quoteIdInt = (int) quoteId.decodeLongOrZero();
        if (quoteIdInt > 0) {
            if (marketDataSubscription != null) {
                final String quoteIdStr = marketDataSubscription.stringToIntCache().getStringOrNull(quoteIdInt);
                if (quoteIdStr != null) {
                    newOrderSingle.setString(QuoteID.FIELD, quoteIdStr);
                    LOGGER.info("Translated  quote id {} to string quoteId {}", quoteIdInt, quoteIdStr);
                } else {
                    LOGGER.info("Could not find quote id string for " + quoteIdInt);
                }
            } else {
                LOGGER.error("marketDataSubscription is null");
            }
        }
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
    }
}
