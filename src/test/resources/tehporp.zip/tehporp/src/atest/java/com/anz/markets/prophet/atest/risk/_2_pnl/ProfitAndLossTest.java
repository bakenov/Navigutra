package com.anz.markets.prophet.atest.risk._2_pnl;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.positionrisk.Positions;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.CLIENTS_NET;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class ProfitAndLossTest extends BaseAcceptanceSpecification {
    @Test
    @Requirement(value = Ref.PROFIT_AND_LOSS_4_2_1)
    @DisplayName("PnL relies on usd mid rate. This is a normal case of PnL accumulation.")
    public void WHEN_receive_indirect_trade_with_mid_rate_SHOULD_send_one_correct_pnl() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.94332, 0.00004, now()));
            // AXPROPHET-927 Should have no impact on existing scenario
            prophet.receive(tdd.biasPosition(Currency.AUD, 2_000_000));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
        }
        then:
        {
            double audPosInUSD = 1_000_000.0 * 0.94332;
            double usdPos = -1_000_000 * 0.9;

            // should only generate on position update. atLeast is required because of pos heartbeat.
            Positions positionsUpdate = prophet.expect(Positions.class, atLeast(1), isPortfolio(CLIENTS_NET)).getLast();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(audPosInUSD));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.USD));
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), is(usdPos));

            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(audPosInUSD + usdPos));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // second trade arrives
            prophet.receive(tdd.client_trade_001(1_000_000, 0.8));

        }
        then:
        {
            double audPosInUSD = 2_000_000.0 * 0.94332;
            double usdPos = (-1_000_000 * 0.9) + (-1_000_000 * 0.8);

            // should only generate on position update.
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(audPosInUSD));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.USD));
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), is(usdPos));

            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(audPosInUSD + usdPos));
        }
    }

    @Test
    @Requirement(value = Ref.PROFIT_AND_LOSS_4_2_1)
    @DisplayName("PnL relies on usd mid rate. This is a normal case of PnL accumulation.")
    public void WHEN_receive_direct_trade_with_mid_rate_SHOULD_send_one_correct_pnl() {
        double audPosInUSD;
        double cadPosInUSD;
        double usdPos;

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDCAD, 1.31000, 0.00004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.75000, 0.00004, now()));
            prophet.receive(tdd.client_trade_001(Instrument.USDCAD, 1_000_000, 1.3000));
        }
        then:
        {
            cadPosInUSD = -1_000_000.0 * 1.30000 / 1.31000;
            usdPos = 1_000_000;

            // should only generate on position update. atLeast is required because of pos heartbeat.
            Positions positionsUpdate = prophet.expect(Positions.class, atLeast(1)).getLast();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.USD));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(usdPos));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.CAD));
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), is(cadPosInUSD));

            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(cadPosInUSD + usdPos));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // second trade arrives
            prophet.receive(tdd.client_trade_001(-1_000_000, 0.8));

        }
        then:
        {
            audPosInUSD = -1_000_000.0 * 0.75;
            usdPos = 1_000_000 + (1_000_000 * 0.8);

            // should only generate on position update.
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(audPosInUSD));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.USD));
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), is(usdPos));

            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(audPosInUSD + cadPosInUSD + usdPos));
        }
    }

    @Test
    @Requirement(value = Ref.PROFIT_AND_LOSS_4_2_1)
    @DisplayName("PnL relies on usd mid rate. Position is only published if positionInSystemBase can be calculated. If there is no mid rate, PnL won't be updated.")
    @RestartBeforeTest(reason = "Pnl cannot be reset without restart")
    public void WHEN_receive_one_indirect_trade_without_mid_rate_SHOULD_reject_until_rate() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001().setMarketConfigs(Arrays.asList(
                    // define driver pairs for market
                    new MarketConfigImpl(CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setMinimumMarketsFilterConfigs(Arrays.asList(
                            new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                    ))
                    .setPassiveHedgerConfigs(Collections.emptyList())
            );
        }
        when:
        {
            // receive trades without mid rate - should be rejected
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
        }
        then:
        {
            // should not generate position update as not mid rate to work with
            prophet.expect(Positions.class, exactly(0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // midrate arrives
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.94332, 0.00004, now()));
            // new trade should be accepted
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
        }
        then:
        {
            double audPosInUSD = 1_000_000.0 * 0.94332;
            double usdPos = -1_000_000 * 0.9;

            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPositionInSystemBase(), is(audPosInUSD));

            assertThat(positionsUpdate.getPosition2().getCcy(), is(Currency.USD));
            assertThat(positionsUpdate.getPosition2().getPositionInSystemBase(), is(usdPos));

            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(audPosInUSD + usdPos));
        }
    }

    @Test
    @Requirement(value = Ref.PROFIT_AND_LOSS_4_2_2)
    public void hedgerRevalPnl() {
        setup:
        {
            prophet.resetAllPositions();
            prophet.receive(tdd.configuration_pricing_001());
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.75000, 0.00004, now()));
        }

        int counter = 1;
        for (final Portfolio portfolio : Portfolio.VALUES) {
            if (portfolio.isHedger()) {
                when:
                {
                    prophet.clearOutputBuffer();
                    prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 1_000_000, 0.75010));
                }
                then:
                {
                    double clientsNet = (1_000_000 * 0.7500) + (-1_000_000 * 0.75010);
                    ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
                    assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(clientsNet * counter));
                    counter++;
                }
            }
        }
        when:
        // t+30 reval occurs at the latest rate
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.75001, 0.00004, now()));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(30));

        }
        then:
        {
            for (final Portfolio portfolio : Portfolio.VALUES) {
                if (portfolio.isHedger()) {
                    ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(portfolio)).getLast();
                    assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(1_000_000 * (0.75001 - 0.75010)));
                }
            }
        }
    }

    @Test
    @RestartBeforeTest(reason="reset")
    public void hedgerRevalPnlEUR() {
        final Instrument baseToUsd = Instrument.EURUSD;
        final Instrument euroCross = Instrument.EURSEK;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.marketDataSnapshot(baseToUsd, 1.07185));
            prophet.receive(tdd.marketDataSnapshot(euroCross, 9.78367));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(HEDGER_AGGRESSIVE, euroCross, -1_000_000, 9.78300));
            // EUR: -1mio EUR       | -1.07185mio USD
            // SEK: +9.783mio SEK   | +9.783mio * (1.07185/9.78367) mio USD
            // PnL = -73.40185
        }
        then:
        {
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), isRoundedTo(-73.40));
        }
        when:
        //market rates updated, then reval @t+30
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(baseToUsd, 1.07200));
            prophet.receive(tdd.marketDataSnapshot(euroCross, 9.78327));
            // EUR: -1mio EUR       | -1.072mio USD
            // SEK: +9.783mio SEK   | +9.783mio * (1.072/9.78327) mio USD
            // PnL = -29.585200040477263736971380734662

            prophet.incrementTime(TimeUnit.SECONDS.toMillis(30));
        }
        then:
        {
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(HEDGER_AGGRESSIVE)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), isRoundedTo(43.82));
        }
    }

    @Test
    @RestartBeforeTest(reason="reset")
    @Requirement(value = Ref.PROFIT_AND_LOSS_4_2_2)
    public void hedgerRevalPnlTrackedGreaterThanOneDay() {
        double revalPnl;

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        // t+1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.75000, 0.00004, now()));
            prophet.receive(tdd.hedge_trade_001(HEDGER_AGGRESSIVE, Instrument.AUDUSD, 1_000_000, 0.75010));
        }
        then:
        {
            prophet.notExpect(ProfitAndLoss.class, isProfitAndLossPortfolio(HEDGER_AGGRESSIVE));
        }
        when:
        // t+31 reval occurs at the latest rate
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.75050, 0.00004, now()));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(30));
        }
        then:
        {
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(HEDGER_AGGRESSIVE)).getLast();
            revalPnl = 1_000_000 * (0.75050 - 0.75010);
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(revalPnl));
        }
        when:
        // after 24 hrs i.e next day, receive hedge trade
        {
            prophet.incrementTime(TimeUnit.HOURS.toMillis(12));
            prophet.incrementTime(TimeUnit.HOURS.toMillis(12));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MINUTES.toMillis(1));

            prophet.receive(tdd.hedge_trade_001(HEDGER_AGGRESSIVE, Instrument.AUDUSD, -1_000_000, 0.75050));
        }
        then:
        {
            prophet.notExpect(ProfitAndLoss.class, isProfitAndLossPortfolio(HEDGER_AGGRESSIVE));
        }
        when:
        // 30s later reval occurs at the latest rate
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.75070, 0.00004, now()));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(30));
        }
        then:
        {
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(HEDGER_AGGRESSIVE)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), is(revalPnl + (1_000_000 * (0.75050 - 0.75070))));
        }
    }

}