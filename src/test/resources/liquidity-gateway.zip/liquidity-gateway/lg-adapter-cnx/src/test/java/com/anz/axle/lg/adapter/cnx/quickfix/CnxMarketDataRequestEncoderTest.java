package com.anz.axle.lg.adapter.cnx.quickfix;

import org.junit.Test;

import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateType;
import quickfix.field.MarketDepth;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.fix42.MarketDataRequest;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CnxMarketDataRequestEncoderTest {

    @Test
    public void testMarketDataSubscription() throws Exception {
        final int marketDepthInt = 0;
        final boolean aggregateBook = true;
        final boolean fullRefresh = false;
        final String expectedSymbol = "AUD/USD";
        final String requestId = "34214521";

        final CnxMarketDataRequestEncoder encoder = new CnxMarketDataRequestEncoder();

        final MarketDataSubscription subscription = mock(MarketDataSubscription.class);
        when(subscription.aggregateBook()).thenReturn(aggregateBook);
        when(subscription.symbol()).thenReturn(expectedSymbol);
        when(subscription.marketDepth()).thenReturn(marketDepthInt);
        when(subscription.fullRefresh()).thenReturn(fullRefresh);

        final MarketDataRequest marketDataRequest = encoder.encodeSubscribe(Integer.parseInt(requestId), subscription);

        final MDReqID mdReqId = marketDataRequest.getMDReqID();
        final MarketDepth marketDepth = marketDataRequest.getMarketDepth();
        final SubscriptionRequestType subscriptionRequestType = marketDataRequest.getSubscriptionRequestType();
        final MDUpdateType mdUpdateType = marketDataRequest.getMDUpdateType();
        final MarketDataRequest.NoMDEntryTypes bidMdEntryTypesGroup = new MarketDataRequest.NoMDEntryTypes();
        marketDataRequest.getGroup(1, bidMdEntryTypesGroup);
        final MDEntryType bidBdEntryType = bidMdEntryTypesGroup.getMDEntryType();

        final MarketDataRequest.NoMDEntryTypes offerMdEntryTypesGroup = new MarketDataRequest.NoMDEntryTypes();
        marketDataRequest.getGroup(2, offerMdEntryTypesGroup);
        final MDEntryType offerBdEntryType = offerMdEntryTypesGroup.getMDEntryType();

        final MarketDataRequest.NoRelatedSym noRelatedSymGroup = new MarketDataRequest.NoRelatedSym();
        marketDataRequest.getGroup(1, noRelatedSymGroup);
        final Symbol symbol = noRelatedSymGroup.getSymbol();

        assertEquals(mdReqId.getValue(), requestId);
        assertEquals(marketDepth.getValue(), marketDepthInt);
        assertEquals(subscriptionRequestType.getValue(), CnxMarketDataRequestEncoder.SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE);
        assertEquals(mdUpdateType.getValue(), MDUpdateType.INCREMENTAL_REFRESH);

        assertEquals(bidBdEntryType.getValue(), MDEntryType.BID);
        assertEquals(offerBdEntryType.getValue(), MDEntryType.OFFER);

        assertEquals(symbol.getValue(), expectedSymbol);
    }
}