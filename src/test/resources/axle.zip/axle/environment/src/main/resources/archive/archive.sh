#!/bin/bash
source ~/axle/environment/shell/axle.rc
# We wish to keep going on failure.
set +e

DATE_NOW=`date +%Y%m%d_%H%M%S`

echo "*********************************************"
echo "ARCHIVING... $DATE_NOW"
echo "*********************************************"

run_archive() {
	for name
	do
		if [ -d $HOME/axle/$name ]
		then
			$HOME/axle/environment/$name/bin/archive.sh
			if [ -e $HOME/axle/environment/$name/bin/create_log_links.sh ]; then
			    $HOME/axle/environment/$name/bin/create_log_links.sh
			fi
		fi
	done
}

run_if_home_archive() {
	if [ -d $HOME/archive ]
	then
		"$@"
	fi
}

# If it's an STP server we don't want to run the prepare script.
run_if_home_archive $HOME/axle/environment/archive/prepare-for-archive.sh
# These are run manually because there is no way through "run_archive" to run an environment archive script (run_archive would call this exact script again...).
run_archive datafabric pricing-ccm spdee-dealing spdee-direct spdee-direct-acceptance-server irate marketdata-adapter fxtrader webreports stp acc-adapter iiq rmds-adapter datafabric-ancillary wrate spdee-direct-smoke-test quote-simulator
$HOME/axle/environment/common/bin/archive.sh
$HOME/axle/environment/common/bin/create_log_links.sh

# NOTE: hardcoded kdb name to stop this firing on all boxes
if [ -d /app/kdb/axle/environment/kdb ]
then
    $HOME/axle/environment/kdb/bin/archive.sh
    $HOME/axle/environment/kdb/bin/create_log_links.sh
fi

# This doesn't happen on STP servers.
run_if_home_archive $HOME/axle/environment/archive/post-archive-cleanup.sh
