package com.anz.markets.prophet.marketdata;


import com.anz.markets.prophet.marketdata.aggbook.AbstractTriangulatedMidRateManagerForBwJmhTest;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;

public class TriangulatedMidRateManagerJmhTest {

    @State(Scope.Benchmark)
    public static class Data extends AbstractTriangulatedMidRateManagerForBwJmhTest {

        @Setup
        public void setup() throws IOException {
            // no setup!
        }
    }

    @Benchmark
    public double testAcceptMidRate(@NotNull final Data data) throws Exception {
        return data.testAcceptMidRate(1);
    }
}
