package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.FatalError;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.StopException;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.monitor.Monitored;
import com.anz.markets.prophet.monitor.ThreadMonitor;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSource;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.ThreadUtils;
import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.Excerpt;
import net.openhft.chronicle.ExcerptTailer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.jetbrains.annotations.TestOnly;

import java.io.Closeable;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.concurrent.ExecutorService;

public class LegacyChronicleReader implements ProphetReader, Monitored {
    protected static final Logger LOGGER = LogManager.getLogger(LegacyChronicleReader.class);
    private LegacyChronicleReaderConfig config;
    private ExcerptTailer tailer;
    private volatile boolean stopping = false, finished = true;
    private final ChronicleObjectReader objectReader;
    private int ignoredCount = 0;
    private long lastChronicleIndex;

    private volatile long loopStartMS;
    private volatile Thread thread;
    private volatile Context context;

    public LegacyChronicleReader(final ChronicleObjectReader objectReader,
                                 final LegacyChronicleReaderConfig config) throws IOException {
        this(ThreadUtils.NoOpExecutor.INSTANCE, objectReader, config);
    }

    public LegacyChronicleReader(final ExecutorService executorService,
                                 final ChronicleObjectReader objectReader,
                                 final LegacyChronicleReaderConfig config) throws IOException {
        this.objectReader = objectReader;
        this.config = config;

        init();
        executorService.submit(this);
    }

    @Override
    public long loopStartMS() {
        return loopStartMS;
    }

    @Override
    public Thread thread() {
        return thread;
    }

    @Override
    public Context context() {
        return context;
    }

    private void init() throws IOException {
        final Chronicle chronicle = config.createChronicle();
        tailer = chronicle.createTailer();

        // this next bit is not pretty but we need to guard for the case that construction does not finish
        try {
            final Excerpt excerpt = chronicle.createExcerpt();
            config.startAt().moveToStartIndex(new LegacyChronicleStartAtSeeker(excerpt, config.startPosition()));
            if (excerpt.index() > 0) tailer.index(excerpt.index()-1);
            LOGGER.info("Created reader from {} index {} lastIndex {} size {} config {}", chronicle.name(), tailer.index(), chronicle.lastIndex(), chronicle.size(), config);
        } catch (SeekException se) {
            close();
            throw se;
        }
    }

    @Override
    public void run() {
        ThreadContext.put("CHRONICLE_READER_FILE", config.chroniclePath);

        this.thread = Thread.currentThread();
        ThreadMonitor.INSTANCE.addTask(this);

        LOGGER.info("Starting.");
        if (Context.context().header().getEventId() > 0) {
            // for when we create >1 LegacyChronicleReader
            LOGGER.info("NOT replacing context {}", Context.context());
        } else {
            Context.set(new Context(new TimeSourceChronicle()));
        }

        this.context = Context.context();
        final TimeSource timeSource = context.timeSource();
        final Header header = context.header();

        finished = false;
        outerLoop:
        // TODO: metrics sometimes doesn't stop when killed. Seems that this stopping variable is not being seen?
        while (!stopping) {
            try {
                // normally we would set loopStartMs when below loop has finished processing, but as we come straight back here, we can do it here
                loopStartMS = Long.MAX_VALUE;
                while (!tailer.nextIndex()) {
                    config.waitStrategy().onTailerStalled(config.pauser());
                    if (stopping) {
                        break outerLoop;
                    }
                }
                config.pauser().reset();
                if (tailer.wasPadding()) {
                    continue;
                }

                // use real time for this
                loopStartMS = System.currentTimeMillis();
                final MessageType messageType = ChronicleObjectReader.readHeader(tailer(), header);
                context.eventContext().saveCurrentEventTimeStamps(messageType, header);

                // do not process empty messages
                if (messageType == MessageType.UNKNOWN) {
                    config.unknownReadHook().onEvent(context, messageType);
                    continue;
                }
                // set time from chronicle. Have to do this here before any filters called
                if (timeSource instanceof TimeSourceChronicle) { //TODO: work out why in some scenarios this is not a TimeSourceChronicle
                    ((TimeSourceChronicle) timeSource).setFromHeader(header.getEventTimeStampNS());
                }
                // filter out if predicate true - we can use this to filter out messages we have already processed
                if (config.headerFilter().apply(header, tailer.index(), messageType)) {
                    if ((ignoredCount++ % ChronicleObjectReader.FILTERED_LOG_EVENT_INTERVAL) == 0) {
                        LOGGER.info("Filtered {}", ignoredCount);
                    }
                    continue;
                }

                config.startReadHook().onEvent(context, messageType);

                objectReader.processEntity(tailer(), messageType);
                tailer.finish();

                config.endReadHook().onEvent(context, messageType);
            } catch (FatalError t) {
                stopping = true;
                LOGGER.error("FatalError. Stop reading. Index=" + tailer.index(), t);
            } catch (StopException t) {
                stopping = true;
                // don't log exception stack trace
                LOGGER.warn("StopException received. Index={} message {}", tailer.index(), t.getMessage());
            } catch (Throwable t) {
                if (isFatal(t)) {
                    stopping = true;
                    LOGGER.error("Fatal throwable. Stop reading. Index={}", tailer.index(), t);
                } else {
                    LOGGER.error("Exception processing message. Index={}", tailer.index(), t);
                }
            }
        }

        LOGGER.info("Finishing tailer index {} ", tailer.index());
        finished = true;
        LOGGER.warn("Finished");
        if (Closeable.class.isInstance(objectReader)) {
            try {
                ((Closeable) objectReader).close();
            } catch (IOException e) {
                // do nothing - just trying our best
            }
        }
        ThreadMonitor.INSTANCE.removeTask(this);
        ThreadContext.remove("CHRONICLE_READER_FILE");
    }

    private ProphetBytes tailer() {
        return LegacyChronicleWrappers.wrap(tailer);
    }

    private boolean isFatal(final Throwable t) {
        // we currently are seeing StreamCorruptedException sometimes when reading  ConfigurationData
        // and this is a subclass of IOException but does not indicate a problem with the chronicle, just the message
        return (t instanceof IllegalStateException) && ((t.getCause() instanceof IOException) && !(t.getCause() instanceof StreamCorruptedException));
    }

    /**
     * Blocks until the reader stops
     *
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        LOGGER.info("Closing reader config {}", config);
        this.stopping = true;
        while (!finished) {
            ThreadUtils.sleep(500);
            LOGGER.info("Waiting to stop");
        }
        tailer.close();
        tailer.chronicle().close();
        LOGGER.info("Closed");
    }

    @TestOnly
    @Override
    public String toString() {
        return "LegacyChronicleReader{" +
                "config=" + config +
                ", ignoredCount=" + ignoredCount +
                ", lastChronicleIndex=" + lastChronicleIndex +
                '}';
    }

    @TestOnly
    public LegacyChronicleReaderConfig getConfig() {
        return config;
    }
}

