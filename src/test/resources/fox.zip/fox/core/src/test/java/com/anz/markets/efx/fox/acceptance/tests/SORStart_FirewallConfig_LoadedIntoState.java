package com.anz.markets.efx.fox.acceptance.tests;

import java.io.InputStream;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.codec.pojo.matcher.FirewallConfigMatcher;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallConfigInstance;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallRuleCategoryConfig;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallTypeConfig;
import com.anz.markets.efx.fox.firewalls.rules.config.FirewallsConfig;
import com.anz.markets.efx.matcher.Asserter;

@RunWith(Spockito.class)
public class SORStart_FirewallConfig_LoadedIntoState {
    private static final Logger LOGGER = LoggerFactory.getLogger(SORStart_FirewallConfig_LoadedIntoState.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);


    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void fox_should_load_firewall_config_from_file_into_firewall_config_repo() {

        final InputStream marketDataRequestStream = this.getClass().getClassLoader().getResourceAsStream("conf/firewall-rules.yaml");
        final FirewallsConfig firewallsConfig = FirewallsConfig.yaml().load(marketDataRequestStream);

        Iterator<FirewallRuleCategoryConfig> firewallsItr = firewallsConfig.getFirewalls().values().iterator();
        FirewallRuleCategoryConfig firewallCategory = firewallsItr.next();

        FirewallTypeConfig firstFirewallType = firewallCategory.getFirewallTypeConfigs().get(0);
        FirewallConfigInstance firstOfFirstRule = firstFirewallType.getConfiguredInstances().get(0);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(FirewallConfigMatcher.build()
                    .body().matches(FirewallConfigMatcher.firewallName().eq(firstFirewallType.getFirewallName()))
                    .body().matches(FirewallConfigMatcher.ruleId().eq(firstOfFirstRule.getRuleId()))
                    .body().matches(FirewallConfigMatcher.regionPattern().eq(firstOfFirstRule.getRegionPattern()))
                    .body().matches(FirewallConfigMatcher.orderTypePattern().eq(firstOfFirstRule.getOrderTypePattern()))
                    .body().matches(FirewallConfigMatcher.deskPattern().eq(firstOfFirstRule.getDeskPattern()))
                    .body().matches(FirewallConfigMatcher.portfolioPattern().eq(firstOfFirstRule.getPortfolioPattern()))
                    .body().matches(FirewallConfigMatcher.userNamePattern().eq(firstOfFirstRule.getUsernamePattern()))
                    .body().matches(FirewallConfigMatcher.venuePattern().eq(firstOfFirstRule.getVenuePattern()))
                    .body().matches(FirewallConfigMatcher.securityTypePattern().eq(firstOfFirstRule.getSecurityTypePattern()))
                    .body().matches(FirewallConfigMatcher.tenorPattern().eq(firstOfFirstRule.getTenorPattern()))
                    .body().matches(FirewallConfigMatcher.symbolPattern().eq(firstOfFirstRule.getSymbolPattern()))
                    .body().matches(FirewallConfigMatcher.limitThreshold().eq(firstOfFirstRule.getLimitThreshold()))
                    .body().matches(FirewallConfigMatcher.period().eq(firstOfFirstRule.getPeriod()))
                    .body().matches(FirewallConfigMatcher.periodUnit().eq(firstOfFirstRule.getPeriodUnit()))
                    .body().matches(FirewallConfigMatcher.comment().eq(firstOfFirstRule.getComment()))
                    .body().matches(FirewallConfigMatcher.lastEditUsername().eq(firstOfFirstRule.getLastEditUsername()))
                    .body().matches(FirewallConfigMatcher.lastEditTime().eq(firstOfFirstRule.getLastEditTime().getTime()))
                )
                .awaitMatchAndGetLast(17, TimeUnit.SECONDS);

        // This is awaiting the firewall to be implemented so it can be forwarded through to the event queue
//        FirewallTypeConfig lastFirewallType = firewallCategory.getFirewallTypeConfigs().get(firewallCategory.getFirewallTypeConfigs().size()-1);
//        FirewallConfigInstance lastFirewall = lastFirewallType.getConfiguredInstances().get(lastFirewallType.getConfiguredInstances().size()-1);
//
//        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
//                .matching(FirewallRuleMatcher.build()
//                        .body().matches(FirewallRuleMatcher.firewallName().eq(lastFirewallType.getFirewallName()))
//                        .body().matches(FirewallRuleMatcher.ruleId().eq(lastFirewall.getRuleId()))
//                        .body().matches(FirewallRuleMatcher.regionPattern().eq(lastFirewall.getRegionPattern()))
//                        .body().matches(FirewallRuleMatcher.orderTypePattern().eq(lastFirewall.getOrderTypePattern()))
//                        .body().matches(FirewallRuleMatcher.deskPattern().eq(lastFirewall.getDeskPattern()))
//                        .body().matches(FirewallRuleMatcher.portfolioPattern().eq(lastFirewall.getPortfolioPattern()))
//                        .body().matches(FirewallRuleMatcher.userNamePattern().eq(lastFirewall.getUsernamePattern()))
//                        .body().matches(FirewallRuleMatcher.venuePattern().eq(lastFirewall.getVenuePattern()))
//                        .body().matches(FirewallRuleMatcher.securityTypePattern().eq(lastFirewall.getSecurityTypePattern()))
//                        .body().matches(FirewallRuleMatcher.tenorPattern().eq(lastFirewall.getTenorPattern()))
//                        .body().matches(FirewallRuleMatcher.symbolPattern().eq(lastFirewall.getSymbolPattern()))
//                        .body().matches(FirewallRuleMatcher.limitThreshold().eq(lastFirewall.getLimitThreshold()))
//                        .body().matches(FirewallRuleMatcher.period().eq(lastFirewall.getPeriod()))
//                        .body().matches(FirewallRuleMatcher.periodUnit().eq(lastFirewall.getPeriodUnit()))
//                        .body().matches(FirewallRuleMatcher.comment().eq(lastFirewall.getComment()))
//                        .body().matches(FirewallRuleMatcher.lastEditUsername().eq(lastFirewall.getLastEditUsername()))
//                        .body().matches(FirewallRuleMatcher.lastEditTime().eq(lastFirewall.getLastEditTime().getTime()))
//                )
//                .awaitMatchAndGetLast(7, TimeUnit.SECONDS);

        FirewallConfigInstance lastofFirstRule = firstFirewallType.getConfiguredInstances().get(firstFirewallType.getConfiguredInstances().size()-1);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(FirewallConfigMatcher.build()
                        .body().matches(FirewallConfigMatcher.firewallName().eq(firstFirewallType.getFirewallName()))
                        .body().matches(FirewallConfigMatcher.ruleId().eq(lastofFirstRule.getRuleId()))
                        .body().matches(FirewallConfigMatcher.regionPattern().eq(lastofFirstRule.getRegionPattern()))
                        .body().matches(FirewallConfigMatcher.orderTypePattern().eq(lastofFirstRule.getOrderTypePattern()))
                        .body().matches(FirewallConfigMatcher.deskPattern().eq(lastofFirstRule.getDeskPattern()))
                        .body().matches(FirewallConfigMatcher.portfolioPattern().eq(lastofFirstRule.getPortfolioPattern()))
                        .body().matches(FirewallConfigMatcher.userNamePattern().eq(lastofFirstRule.getUsernamePattern()))
                        .body().matches(FirewallConfigMatcher.venuePattern().eq(lastofFirstRule.getVenuePattern()))
                        .body().matches(FirewallConfigMatcher.securityTypePattern().eq(lastofFirstRule.getSecurityTypePattern()))
                        .body().matches(FirewallConfigMatcher.tenorPattern().eq(lastofFirstRule.getTenorPattern()))
                        .body().matches(FirewallConfigMatcher.symbolPattern().eq(lastofFirstRule.getSymbolPattern()))
                        .body().matches(FirewallConfigMatcher.limitThreshold().eq(lastofFirstRule.getLimitThreshold()))
                        .body().matches(FirewallConfigMatcher.period().eq(lastofFirstRule.getPeriod()))
                        .body().matches(FirewallConfigMatcher.periodUnit().eq(lastofFirstRule.getPeriodUnit()))
                        .body().matches(FirewallConfigMatcher.comment().eq(lastofFirstRule.getComment()))
                        .body().matches(FirewallConfigMatcher.lastEditUsername().eq(lastofFirstRule.getLastEditUsername()))
                        .body().matches(FirewallConfigMatcher.lastEditTime().eq(lastofFirstRule.getLastEditTime().getTime()))
                )
                .awaitMatchAndGetLast(17, TimeUnit.SECONDS);

        //List<FirewallRule> firewallRules = FirewallConfigApplierTest.extractRulesFromFirewall(inboundBurstSubmitOrderThroughputFirewall);
        //Assertions.assertThat(firewallRules.size()).isEqualTo(3);
    }


}
