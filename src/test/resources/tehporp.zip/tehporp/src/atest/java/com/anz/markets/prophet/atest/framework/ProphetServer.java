package com.anz.markets.prophet.atest.framework;

import com.anz.markets.prophet.atest.framework.impl.MessageCountPredicate;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.CovCorrAvgs;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.PricingFirewallReset;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Adjustments;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.LogEvent;
import org.hamcrest.Matcher;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;

/**
 * An abstract concept of prophet server as a thing that test can interact with.
 * <p>
 * Provides core interaction - send/receive events.
 * Provides controls of server - setting up transient state of the system (such as enable/disable) permanent controls are
 * done in configuration (via injecting command into the server).
 * <p>
 * Some definition of terminology.
 * Command is a datatype that instruct server to do something.
 * Event is a datatype that indicate what happen to the system.
 * <p>
 * <pre>
 * command --> | Prophet | --> output
 *                  |
 *                  v
 *               (event)
 * </pre>
 */
public interface ProphetServer {
    // Core interactions

    void start();

    void stop();

    void receive(ForwardPoint forwardPoint);

    void receive(VolatilityControl volatilityControl);

    void receive(BiasPositionControl biasPositionControl);

    void receive(ManualSkewControl manualSkewControl);

    void receive(MarketDataSnapshot marketDataSnapshot);

    void receive(MarketDataIncrement marketDataIncrement);

    void receive(ConfigurationData command);

    void receive(ConfigurationData command, final boolean clearOutputBuffer);

    void receive(ConfigurationData command, boolean clearOutputBuffer, boolean applicableToUm);

    void receive(EconNews command);

    void receive(Adjustment command);

    void receive(Adjustments adjustments);

    void receive(Trade trade);

    void receive(TradingTimeZone tradingTimeZone);

    void receive(SpotDate spotDate);

    @Deprecated
        // instead should call com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification.incrementTime(1000)
    void receive(OneSecond oneSecond);

    void receive(HourChime hourChime);

    void receive(PricingFirewallReset pricingFirewallReset);

    void receive(HedgerFirewallReset hedgerFirewallReset);

    void receive(OrderEvent orderEvent);

    void receive(OperatingHourChime operatingHourChime);

    void receive(HedgeCurrencyControl hedgeCurrencyControl);

    void receive(SkewCurrencyControl skewCurrencyControl);

    void receive(CovCorrAvgs covCorrAvgs);

    void receive(EndOfWeekChime endOfWeekChime);

    void receive(PricePauseControl pricePauseControl);

    void receiveHedgeOrderFullFill(final NewOrder newOrder);

    void receiveHedgeOrderFullFill(final NewOrder newOrder, double fillPrice);

    void receiveHedgeOrderFullFillOrderEvent(NewOrder newOrder, double fillPrice);

    void receiveHedgeOrderFullFillTrade(NewOrder newOrder, double fillPrice);

    void receiveHedgeOrderPartialFill(final NewOrder newOrder, double totalFilledQuantity, double avgFilledPrice);

    void receiveHedgeOrderPartialFillFullFill(final NewOrder newOrder, double filledQuantity, double avgFilledPrice);

    void receiveHedgeOrderPartialFillOverFill(final NewOrder newOrder, double filledQuantity, double totalFilledQuantity, double avgFilledPrice);

    void receiveHedgeOrderPartialFillTrade(final NewOrder newOrder, double filledQuantity, double fillPrice);

    void receiveHedgeOrderCompletedWithPartialFill(final NewOrder newOrder, double totalFilledQuantity,
                                                   double avgFilledPrice);

    void receive(HedgeControl hedgeControl);

    void receiveFWDFromUM(final ForwardPoint forwardPoint);

    void receiveNDFFromUM(final ForwardPoint forwardPoint);

    void receiveNDFFromUm(final MarketDataSnapshot marketDataSnapshot);

    void receiveNDFFromUm(final MarketDataIncrement marketDataIncrement);

    void receiveSpotSnapshotFromUm(final MarketDataSnapshot marketDataSnapshot);

    void receiveSpotIncrementalFromUm(final MarketDataIncrement marketDataIncrement);

    void receiveFromUm(Trade trade);

    <T> LinkedList<T> expect(Class<T> outputType) throws IllegalStateException;

    <T> LinkedList<T> expect(Class<T> outputType,
                             Predicate<Output<T>> predicate) throws IllegalStateException;

    /**
     * Expects an output from server. This call will wait for the given output with default time out.
     *
     * @param <T>
     * @param outputType
     * @param count
     * @return One or more output of the given type
     * @throws IllegalStateException when given output type does not occurs.
     */
    <T> LinkedList<T> expect(final Class<T> outputType,
                             final MessageCountPredicate count) throws IllegalStateException;

    <T> LinkedList<T> expect(final Class<T> outputType,
                             final MessageCountPredicate count,
                             final Predicate<Output<T>> predicate) throws IllegalStateException;

    /**
     * Synchronously wait till all prior events are processed and clear output buffer.
     */
    void clearOutputBuffer();

    void clearOutputBuffers();

    void clearUmOutputBuffer();

    void clearInputCommands();

    void clearLogCapture();

    void resetAllPositions();

    void resetManualSkews();

    void disableAllMarketDataFilter();

    void disableAllSkewing();

    void enablePricingFilter(String filter);

    void setTradingTimeZone(TradingTimeZone zone);

    @SuppressWarnings("unchecked")
    List<LogEvent> expect(Level level,
                          Matcher<String> messageMatcher) throws IllegalStateException;

    @SuppressWarnings("unchecked")
    LinkedList<LogEvent> expect(Class<? extends Throwable> throwable,
                                Matcher<String> messageMatcher) throws IllegalStateException;

    void notExpect(Level level,
                   Matcher<String> messageMatcher);

    void notExpect(final Class<? extends Throwable> throwable,
                          final Matcher<String> messageMatcher) throws IllegalStateException;

        List<Output> getBufferedOutput();

    void setUpDefaultSpotDates();

    void resetAllPricingState();

    <T> LinkedList<T> getCommand(Class<T> clazz);

    void waitTillAllEventsAreProcessed(final String reason);

    <T> LinkedList<T> expectFromUm(Class<T> outputType,
                                   MessageCountPredicate countPredicate,
                                   Predicate<Output<T>> messagePredicate) throws IllegalStateException;

    <T> void notExpect(Class<T> outputType,
                       Predicate<Output<T>> messagePredicate) throws IllegalStateException;

    <T> void notExpect(Class<T> outoutType);

    /**
     * Current time in ms from acceptance test timeSource. This timeSource is maintained by
     * ProphetServerEmbeddedImpl and is recreated when the prophet server is restarted
     */
    long now();

    /**
     * Increment time in acceptance test timeSource
     *
     * @param incrementMS
     */
    long incrementTime(long incrementMS);

    /**
     * Increment time and call the runnable just before (1ms) time has reached.
     * This intends to be used as an api for assertion if something has or has not happened before
     * the given time elapsed.
     * <p>
     * e.g., ensuring message as not arrived before time elapsed so as to ensure the boundary condition setup in the test.
     */
    void incrementTime(Runnable beforeTimeHasReached, long incrementMS);

    void receiveOperatingHourStateForAllEntities(final OperatingHourSpecification.State operatingHourState);

    void setRegion(Region region);

    void startUmProbes(ConfigurationData configurationData, boolean restart) throws Exception;

    void startUmOutSubscription(Market market, Instrument instrument);

    void startUmOutSubscription(Market[] markets, Instrument instrument);

    void stopUmProbes() throws Exception;
}