package com.anz.markets.efx.ngaro.core;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.IncludeCategories;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Unit test for {@link ExpandableAsciiString}
 */
@RunWith(Spockito.class)
public class ExpandableAsciiStringTest {
    @Test
    public void set() {
        assertEquals("should set byte", "abc", new ExpandableAsciiString(10).set(0, (byte)'a').set(2, (byte)'c').set(1, (byte)'b').toString());
        assertEquals("should set byte", "abc", new ExpandableAsciiString(10).set("abc").set(4, AsciiString.NULL).toString());
        assertEquals("should set byte", "abc", new ExpandableAsciiString(10).set("abc").set(3, AsciiString.NULL).toString());
        assertEquals("should set byte", "ab", new ExpandableAsciiString(10).set("abc").set(2, AsciiString.NULL).toString());
        assertEquals("should set byte", "a", new ExpandableAsciiString(10).set("abc").set(1, AsciiString.NULL).toString());
        assertEquals("should set byte", "", new ExpandableAsciiString(10).set("abc").set(0, AsciiString.NULL).toString());
        for(final String s : new String[] {"", "Hello", "Bla", "Blahblahbl"}) {
            assertEquals("should set string", s, new ExpandableAsciiString(10).set(s).toString());
            assertEquals("should set char sequence", s, new ExpandableAsciiString(10).set(new StringBuffer(s)).toString());
            assertEquals("should set ascii string", s, new ExpandableAsciiString(10).set(AsciiString.immutable(s)).toString());
            assertEquals("should set source", s, new ExpandableAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 0, s.length()).toString());
            assertEquals("should set nothing", "", new ExpandableAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 0, 0).toString());
            if (!s.isEmpty()) {
                assertEquals("should set source[0]", s.substring(0, 1), new ExpandableAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 0, 1).toString());
                assertEquals("should set source[1]", s.substring(1, 2), new ExpandableAsciiString(10).set(s, ByteReader.CHAR_SEQUENCE, 1, 1).toString());
            }
        }
        try {
            new ExpandableAsciiString(10).set("abc").set(-1, AsciiString.NULL);
            fail("Negative index should cause exception");
        } catch (final IndexOutOfBoundsException e) {
            //as expected
        }
    }

    @Test
    public void append() {
        final String prefix = "xyz";
        assertEquals("should set byte", prefix + "abc", new ExpandableAsciiString(10).set(prefix).append((byte)'a').append((byte)'b').append((byte)'c').toString());
        for(final String s : new String[] {"", "Hello", "Bla123567987766767"}) {
            assertEquals("should append string", prefix + s, new ExpandableAsciiString(10).set(prefix).append(s).toString());
            assertEquals("should append char sequence", prefix + s, new ExpandableAsciiString(10).set(prefix).append(new StringBuffer(s)).toString());
            assertEquals("should append ascii string", prefix + s, new ExpandableAsciiString(10).set(prefix).append(AsciiString.immutable(s)).toString());
            assertEquals("should append source", prefix + s, new ExpandableAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 0, s.length()).toString());
            assertEquals("should append nothing", prefix, new ExpandableAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 0, 0).toString());
            if (!s.isEmpty()) {
                assertEquals("should append source[0]", prefix + s.substring(0, 1), new ExpandableAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 0, 1).toString());
                assertEquals("should append source[1]", prefix + s.substring(1, 2), new ExpandableAsciiString(10).set(prefix).append(s, ByteReader.CHAR_SEQUENCE, 1, 1).toString());
            }
        }
    }

    @Test
    public void clear() {
        assertEquals("should be empty after clear", true, new ExpandableAsciiString(3).set("ABC").clear().isEmpty());
    }

    @Test
    public void ensureCapacity() {
        final ExpandableAsciiString s = AsciiString.expandable(1);
        for (int i = 0; i < 10; i++) {
            s.append((byte)('A' + i));
        }
        assertEquals("Should have extended capacity to a power of 2", 16, s.capacity());
        assertEquals("String not as expected", "ABCDEFGHIJ", s.toString());
        assertEquals("Should have doubled capacity", 20, AsciiString.expandable(10).ensureCapacity(11).capacity());
        assertEquals("Should have extended capacity", 100, AsciiString.expandable(10).ensureCapacity(100).capacity());
    }

    @Test
    public void isEmpty() {
        assertEquals("should not be empty", false, new ExpandableAsciiString(3).set("Bla").isEmpty());
        assertEquals("should be empty", true, new ExpandableAsciiString(3).isEmpty());
    }

    @Test
    public void length() {
        assertEquals("length should be 3", 3, new ExpandableAsciiString(10).set("Bla").length());
        assertEquals("length should be 0", 0, new ExpandableAsciiString(10).set("").length());
        assertEquals("length should be 4", 4, new ExpandableAsciiString(10).set("ABCD\0\0\0\0").length());
        assertEquals("length should be 8", 8, new ExpandableAsciiString(10).set("ABCD\1\1\1\1").length());
        assertEquals("length should be 4", 4, new ExpandableAsciiString(10).append("ABCD\0\0\0\0").length());
        assertEquals("length should be 8", 8, new ExpandableAsciiString(10).append("ABCD\1\1\1\1").length());
        assertEquals("length should be 0", 0, new ExpandableAsciiString(10).set(0, AsciiString.NULL).length());
        assertEquals("length should be 0", 1, new ExpandableAsciiString(10).set(0, (byte)1).length());
        assertEquals("length should be 0", 0, new ExpandableAsciiString(10).append(AsciiString.NULL).length());
        assertEquals("length should be 0", 1, new ExpandableAsciiString(10).append((byte)1).length());
    }

    @Test
    public void hash() {
        assertEquals("hash code should not be zero", true, 0 != new ExpandableAsciiString(3).set("Bla").hashCode());
        assertEquals("hash code should be 0", 0, new ExpandableAsciiString(3).hashCode());
    }

    @Test
    public void equals() {
        final ExpandableAsciiString bla = new ExpandableAsciiString(3).set("Bla");
        assertEquals("should equal itself", true, bla.equals(bla));
        assertEquals("should not equal null", false, bla.equals(null));
        assertEquals("should not equal other non AsciiString value", false, bla.equals("Bla"));
        assertEquals("should not equal other non-equal AsciiString", false, bla.equals(AsciiString.immutable("BlaBla")));
        assertEquals("should equal other equal AsciiString", true, bla.equals(AsciiString.immutable("Bla")));
        assertEquals("should equal other equal MutableAsciiString", true, bla.equals(AsciiString.expandable().set("Bla")));
    }

    @Test
    @Spockito.Unroll({
            "| value1      | value2   | value3  |",
            "|=============|==========|=========|",
            "| Bla1\0c     | Bla2\0b  | Bla3\0a |",
            "| Bla1\0c     | Bla2\0b  | Bla3\0a |",
            "| Bl\0aac     | Bla\0ac  | Blaa\0c |",
            "| Blaac       | Blaac    | Blaac   |"
    })
    @Spockito.Name("[{row}]: {value1} < {value2} < {value3}")
    public void compareTo_inequalities(final String value1, final String value2, final String value3) {
        final ExpandableAsciiString bla1 = new ExpandableAsciiString(5).set(value1);
        final ExpandableAsciiString bla2 = new ExpandableAsciiString(5).set(value2);
        final ExpandableAsciiString bla3 = new ExpandableAsciiString(5).set(value3);

        assertTrue("should compare to itself", bla1.compareTo(bla1) == 0);
        assertTrue("should compare to itself", bla2.compareTo(bla2) == 0);
        assertTrue("should compare to itself", bla3.compareTo(bla3) == 0);

        assertTrue("bla1 should be less than bla2", Integer.signum(bla1.compareTo(bla2)) == -Integer.signum(bla2.compareTo(bla1)));
        assertTrue("bla2 should be less than bla3", Integer.signum(bla2.compareTo(bla3)) == -Integer.signum(bla3.compareTo(bla2)));
        assertTrue("bla1 should be less than bla3", Integer.signum(bla1.compareTo(bla3)) == -Integer.signum(bla3.compareTo(bla1)));
    }

    @Test
    @Spockito.Unroll({
            "| value1      | value2   | value3  |",
            "|=============|==========|=========|",
            "| Bla1\0c     | Bla1\0b  | Bla1\0a |",
            "| \0Blaac     | \0Blaac  | \0Blaac |"
    })
    @Spockito.Name("[{row}]: {value1} == {value2} == {value3}")
    public void compareTo_equalities(final String value1, final String value2, final String value3) {
        final ExpandableAsciiString bla1 = new ExpandableAsciiString(5).set(value1);
        final ExpandableAsciiString bla2 = new ExpandableAsciiString(5).set(value2);
        final ExpandableAsciiString bla3 = new ExpandableAsciiString(5).set(value3);

        assertTrue("should compare to itself", bla1.compareTo(bla1) == 0 && bla1.equals(bla1));
        assertTrue("should compare to itself", bla2.compareTo(bla2) == 0 && bla2.equals(bla2));
        assertTrue("should compare to itself", bla3.compareTo(bla3) == 0 && bla3.equals(bla3));

        assertTrue("bla1 should equal to bla2", bla1.compareTo(bla2) == bla2.compareTo(bla1) && bla1.equals(bla2) && bla2.equals(bla1));
        assertTrue("bla2 should equal to bla3", bla2.compareTo(bla3) == bla3.compareTo(bla2) && bla2.equals(bla3) && bla3.equals(bla2));
        assertTrue("bla1 should equal to bla3", bla1.compareTo(bla3) == bla3.compareTo(bla1) && bla1.equals(bla3) && bla3.equals(bla1));
    }


    @Test
    public void to_String() {
        assertEquals("should result in 'Bla' string", "Bla", new ExpandableAsciiString(3).set("Bla").toString());
        assertEquals("should result in empty string", "", new ExpandableAsciiString(3).set("").toString());
    }

    @Test
    public void get_charAt() {
        final String abc = "abcdefg";
        final AsciiString ascii = new ExpandableAsciiString(10).set(abc);
        for (int i = 0; i < abc.length(); i++) {
            Assert.assertEquals("get(" + i + ") not as expected", (byte)abc.charAt(i), ascii.get(i));
            Assert.assertEquals("charAt(" + i + ") not as expected", abc.charAt(i), ascii.charAt(i));
        }
    }

    @Test
    public void get() {
        final String background = "0123456789";
        final String abc = "abcdefg";
        final AsciiString ascii = new ExpandableAsciiString(10).set(abc);
        final StringBuilder sb = new StringBuilder();
        for (int maxLength = 0; maxLength < 20; maxLength++) {
            for (int i = 0; i < abc.length(); i++) {
                //given
                sb.setLength(0);
                sb.append(background);
                final int expLength = Math.min(maxLength, abc.length());
                final String expVal = ""
                        + background.substring(0, i)
                        + abc.substring(0, expLength)
                        + background.substring(Math.min(i + expLength, background.length()), background.length());
                Assert.assertEquals("return value from get(target, ..., " + i + ", " + maxLength +") not as expected",
                        expLength, ascii.get(sb, ByteWriter.STRING_BUILDER, i, maxLength));
                Assert.assertEquals("string written to target via get(target, ..., " + i + ", " + maxLength + ") is not as expected",
                        expVal, sb.toString());
            }
        }
    }

    @Test
    public void testEmpty() {
        //isEmpty
        assertEquals("should be empty", true, new ExpandableAsciiString(3).isEmpty());
        assertEquals("length should be zero", 0, new ExpandableAsciiString(3).length());
        //contains
        assertEquals("should not contain non-empty string", false, new ExpandableAsciiString(3).contains(AsciiString.immutable("Bla")));
        assertEquals("should contain empty string", true, new ExpandableAsciiString(3).contains(AsciiString.immutable("")));
        //indexOf
        assertEquals("indexOf(..) should return -1 for non-empty string", -1, new ExpandableAsciiString(3).indexOf(AsciiString.immutable("Bla")));
        assertEquals("indexOf(..) should return 0 for empty string", 0, new ExpandableAsciiString(3).indexOf(AsciiString.immutable("")));
        assertEquals("indexOf(..) should return 0 for empty string with fromIndex > 0", 0, new ExpandableAsciiString(3).indexOf(AsciiString.immutable(""), 7));
        assertEquals("indexOf(..) should return 0 for empty string with fromIndex < 0", 0, new ExpandableAsciiString(3).indexOf(AsciiString.immutable(""), -1));
        //hashCode
        assertEquals("hash code should be zero", 0, new ExpandableAsciiString(3).hashCode());
        //equals
        assertEquals("should equal itself", true, new ExpandableAsciiString(3).equals(new ExpandableAsciiString(3)));
        assertEquals("should not equal null", false, new ExpandableAsciiString(3).equals(null));
        assertEquals("should not equal other non AsciiString value", false, new ExpandableAsciiString(3).equals("Bla"));
        assertEquals("should not equal other non-empty AsciiString", false, new ExpandableAsciiString(3).equals(AsciiString.immutable("Bla")));
        assertEquals("should equal other empty AsciiString", true, new ExpandableAsciiString(3).equals(AsciiString.EMPTY));
        assertEquals("should equal other empty MutableAsciiString", true, new ExpandableAsciiString(3).equals(AsciiString.expandable().set("")));
        //compareTo
        assertEquals("should compare equal to itself", 0, new ExpandableAsciiString(3).compareTo(new ExpandableAsciiString(3)));
        assertEquals("should be smaller than any other non-empty string", -1, new ExpandableAsciiString(3).compareTo(AsciiString.immutable("A")));
        //toString
        assertEquals("should result in empty string", "", new ExpandableAsciiString(3).toString());
        //toStringOrNull
        assertEquals("should result in null", null, new ExpandableAsciiString(3).toStringOrNull());
        //get
        assertEquals("should copy zero bytes", 0, new ExpandableAsciiString(3).get(null, ByteWriter.NULL, 0, Integer.MAX_VALUE));
        Assert.assertEquals("Must be NULL character if read after length but before capacity end",
                AsciiString.NULL, new ExpandableAsciiString(3).get(0));
        try {
            new ExpandableAsciiString(3).get(3);
        } catch (final IndexOutOfBoundsException e) {
            //expected, but not necessarily thrown
        }
    }

}