#!/bin/bash

mvn exec:java -Dexec.mainClass="software.chronicle.fix.warmupexample.WarmupQueueGenerator" -Dexec.args="warmupqueue"
mvn exec:java -Dexec.mainClass="software.chronicle.fix.warmupexample.WarmedUpSessionTest"

