package com.anz.axle.lg.adapter.acceptance.utils;

import java.util.Objects;
import java.util.function.Function;

import org.fix4j.spec.fix50sp2.FixSpec;
import org.fix4j.test.fixspec.FixSpecification;
import org.fix4j.test.integration.FixEngineSessionFactory;
import org.fix4j.test.session.AbstractContextFactory;

public class FixAssertContextFactory extends AbstractContextFactory {
    final private Function<FixSpecification, FixEngineSessionFactory> fixSpecTofixEngineSessionFactory;

    public FixAssertContextFactory(final Function<FixSpecification, FixEngineSessionFactory> fixSpecTofixEngineSessionFactory) {
        super(FixSpec.INSTANCE);
        this.fixSpecTofixEngineSessionFactory = Objects.requireNonNull(fixSpecTofixEngineSessionFactory);
    }

    @Override
    protected FixEngineSessionFactory createFixEngineSessionFactory(final FixSpecification fixSpecification) {
        return fixSpecTofixEngineSessionFactory.apply(fixSpecification);
    }
}
