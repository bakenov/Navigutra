package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class HspItchMarketDataSubscription implements MarketDataSubscription {

    private static final int DEFAULT_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK = true;
    private static final boolean FULL_REFRESH = true;

    private final Venue venue;
    private final String symbol;
    private final StringToIntCache stringToIntCache;
    private final InstrumentKey instrumentKey;

    public HspItchMarketDataSubscription(final Venue venue, final String symbol, final StringToIntCache stringToIntCache) {
        this.venue = Objects.requireNonNull(venue);
        this.symbol = Objects.requireNonNull(symbol);
        this.stringToIntCache = Objects.requireNonNull(stringToIntCache);
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), SecurityType.FXSPOT, Tenor.SP);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return venue;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return stringToIntCache;
    }

    @Override
    public boolean fullRefresh() {
        return FULL_REFRESH;
    }

    @Override
    public boolean aggregateBook() {
        return DEFAULT_AGGREGATE_BOOK;
    }

    @Override
    public int marketDepth() {
        return DEFAULT_MARKET_DEPTH;
    }

    @Override
    public String toString() {
        return "HspItchMarketDataSubscription{" +
                "instrumentKey=" + instrumentKey +
                ", venue=" + venue +
                ", symbol='" + symbol + '\'' +
                '}';
    }
}
