package com.anz.axle.lg.adapter.acceptance.utils;

public interface UatTest {/* category maker*/}
