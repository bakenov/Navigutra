package com.anz.markets.prophet.tools;

import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig;
import com.anz.markets.prophet.positionrisk.ChronicleGate;
import com.anz.markets.prophet.tools.tcp.Sink;
import com.anz.markets.prophet.tools.tcp.Source;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.util.ThreadUtils;
import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.ExcerptAppender;
import net.openhft.chronicle.ExcerptTailer;
import net.openhft.chronicle.IndexedChronicle;
import net.openhft.chronicle.core.io.Closeable;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister.EXCERPT_CAPACITY;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SourceSink {
    private static final LegacyChronicleConfig.ChronicleType TYPE = LegacyChronicleConfig.ChronicleType.INDEXED;
    private static final String HOST = "localhost";
    private static final String chronicle1BasePath = "c1", chronicle2BasePath = "c2";
    private static final long PAUSE_MS = 1000;
    private final String PORT = Integer.toString(1_000 + new Random().nextInt(9_000));
    private Chronicle chronicle1, chronicle2;
    private ExecutorService executorService = Executors.newFixedThreadPool(2);
    private Source source;
    private Sink sink;

    @BeforeClass
    @AfterClass
    public static void cleanFiles() {
        ChronicleGate.deleteNow(chronicle1BasePath);
        ChronicleGate.deleteNow(chronicle2BasePath);
    }

    @Before
    public void before() throws IOException {
        chronicle1 = LegacyChronicleConfig.createChronicle(chronicle1BasePath, TYPE, LegacyChronicleConfig.ReadWrite.READ_WRITE);
        chronicle2 = LegacyChronicleConfig.createChronicle(chronicle2BasePath, TYPE, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    @After
    public void after() throws InterruptedException {
        Closeable.closeQuietly(chronicle1, chronicle2, sink, source);

        executorService.shutdown();
        executorService.awaitTermination(PAUSE_MS, TimeUnit.MILLISECONDS);

        cleanFiles();
    }

    @Test
    public void a_testBothEmpty() throws Exception {
        run();
        check(0);
        // you will see exceptions on shutdown as Sink is stuck in tailer.nextIndex method
    }

    @Test
    public void b_testEmptySinkRunFirst() throws Exception {
        final int count = 10;
        run();
        writeTo(chronicle1, count);
        check(count);
    }

    @Test
    public void c_testEmptySinkRunLast() throws Exception {
        final int count = 8;
        writeTo(chronicle1, count);
        run();
        check(count);
    }

    @Test
    @Ignore("flaky on TC")
    public void d_testSinkAheadThenSourceCatchesUp() throws Exception {
        // in this case the sink starts ahead of the source...
        final int count = 50;
        run();
        writeTo(chronicle2, count);
        // ... nothing has been sent anywhere
        assertEquals(0, size(chronicle1));
        assertEquals(count, size(chronicle2));
        // ... write to source so now they should be the same
        writeTo(chronicle1, count);
        check(count);
        // ... write another n to source and ensure both the same
        writeTo(chronicle1, count, count);
        check(count * 2);
    }

    @Test
    @Ignore("long running")
    public void e_testPerformance() throws Exception {
        final int count = 1_000_000;
        writeTo(chronicle2, count);
        run();
    }

    private void run() throws IOException {
        source = new Source(chronicle1BasePath, PORT);
        sink = new Sink(HOST, PORT, chronicle2BasePath);
        executorService.submit(source);
        executorService.submit(sink);
        ThreadUtils.sleep(PAUSE_MS);
    }

    private void check(final int count) throws IOException {
        ThreadUtils.sleep(PAUSE_MS);
        assertEquals(count, size(chronicle1));
        assertEquals(count, size(chronicle2));
        try (final ExcerptTailer chronicle1Tailer = chronicle1.createTailer();
             final ExcerptTailer chronicle2Tailer = chronicle2.createTailer()) {
            final byte[] buffer1 = new byte[EXCERPT_CAPACITY];
            final byte[] buffer2 = new byte[EXCERPT_CAPACITY];
            for (int i = 0; i < count; i++) {
                GcFriendlyAssert.isTrue(chronicle1Tailer.nextIndex());
                GcFriendlyAssert.isTrue(chronicle2Tailer.nextIndex());
                int counter1 = chronicle1Tailer.readInt();
                int counter2 = chronicle2Tailer.readInt();
                assertEquals(i, counter1);
                assertEquals(i, counter2);
                chronicle1Tailer.index(chronicle1Tailer.index());
                chronicle2Tailer.index(chronicle2Tailer.index());
                int length1 = chronicle1Tailer.read(buffer1);
                int length2 = chronicle2Tailer.read(buffer2);
                assertEquals(length1, length2);
                assertArrayEquals(buffer1, buffer2);
            }
        }
    }

    private void writeTo(final Chronicle chronicle, final int count) throws IOException {
        writeTo(chronicle, 0, count);
    }

    private void writeTo(final Chronicle chronicle, final int start, final int count) throws IOException {
        try (final ExcerptAppender appender = chronicle.createAppender()) {
            for (int i = 0; i < count; i++) {
                appender.startExcerpt(EXCERPT_CAPACITY);
                appender.writeInt(i + start);
                appender.writeUTF("item " + i + start);
                appender.finish();
            }
        }
    }

    private static long size(final Chronicle chronicle) {
        ((IndexedChronicle) chronicle).findTheLastIndex();
        return chronicle.size();
    }
}
