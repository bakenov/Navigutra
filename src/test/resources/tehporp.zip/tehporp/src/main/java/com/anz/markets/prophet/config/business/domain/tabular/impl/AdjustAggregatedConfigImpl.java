package com.anz.markets.prophet.config.business.domain.tabular.impl;


import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.adjustment.AdjustAggregatedConfig;
import com.anz.markets.prophet.domain.Instrument;

@Deprecated
public class AdjustAggregatedConfigImpl implements AdjustAggregatedConfig, ProphetMarshallable {

    private Instrument instrument;
    private double maxVWAPQty;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    public AdjustAggregatedConfigImpl() {
    }

    public AdjustAggregatedConfigImpl(final Instrument instrument, final double maxVWAPQty) {
        this.instrument = instrument;
        this.maxVWAPQty = maxVWAPQty;
    }

    @Override
    public Instrument getInstrument() {
        return this.instrument;
    }

    @Override
    public double getMaxVWAPQty() {
        return this.maxVWAPQty;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        //Should not get here.
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeShort(this.instrument.getValue());
        out.writeDouble(this.maxVWAPQty);
    }

    public static ProphetMarshallable constructReadMarshallable(final ProphetBytes in) {
        return new AdjustAggregatedConfigImpl(
                Instrument.readMarshallableValueOf(in),
                in.readDouble()
        );
    }

    @Override
    public String toString() {
        return "AdjustAggregatedConfigImpl{" +
                "instrument=" + instrument +
                ", maxVWAPQty=" + maxVWAPQty +
                '}';
    }
}
