package com.anz.axle.lg.adapter.apama.config.core;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.MessagingConfig;

/**
 * Register all the core beans required for publishing to messaging transport
 * see {@link PropertiesConfig}, {@link MessagingConfig} and {@link PublishingConfig}
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
@Import({PropertiesConfig.class, MessagingConfig.class, PublishingConfig.class})
public @interface EnablePublishing {
}
