#!/bin/bash

echo "Killing everything on correlator boxes"
ssh daxa010z "ps -ef | grep 'corr' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh daxa010z "ps -ef | grep 'iaf' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh daxa010z "ps -ef | grep 'java' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh daxa010z "rm -rf ~/axle/datafabric/logs/*.pid"

echo "Killing everything on proxy boxes"
ssh daxa010z "ps -ef | grep 'java' | grep -v 'grep' | grep -v 'delta' | awk '{ print \$2 }' | xargs -l kill -9; rm -f ~/apache-tomcat/conf/pid"
