package com.anz.markets.prophet.pricer.wholesale;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.function.Consumer;

import static com.anz.markets.prophet.marketdata.TestConfigurationDataFactory.withDefaults;

public class NDFClientPriceManagerBWTest {

    private static final int REPS = 1_000_000;
    private static final long THRESHOLD = 100L;

    private static final ClientPriceImpl clientPrice = new ClientPriceImpl();
    private static final ForwardPointImpl forwardPoint = new ForwardPointImpl();
    private static IndexedConfigurationData indexedConfigurationData;

    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private final Consumer<IndexedConfigurationData> indexedConfigurationDataConsumer;
    private final Consumer<ClientPrice> clientPriceConsumer;
    private final Consumer<ForwardPoint> forwardPointConsumer;
    private final Consumer<OneSecond> oneSecondConsumer;

    public NDFClientPriceManagerBWTest() {
        final NDFClientPriceManager ndfClientPriceManager = new NDFClientPriceManager(new NotifierDefault<>());
        indexedConfigurationDataConsumer = ndfClientPriceManager.consumerIndexConfigurationData();
        clientPriceConsumer = ndfClientPriceManager.consumerClientPrice();
        forwardPointConsumer = ndfClientPriceManager.consumerForwardPoint();
        oneSecondConsumer = ndfClientPriceManager.consumerOneSecond();
        indexedConfigurationDataConsumer.accept(indexedConfigurationData);
    }

    @BeforeClass
    public static void setup() {
        Context.region(Region.GB);

        // Config
        indexedConfigurationData = new IndexedConfigurationData(withDefaults(new ConfigurationDataDefault()));

        // Price
        final PriceAndQtyImpl bidPricePoint = (PriceAndQtyImpl) clientPrice.getBids().addFromSupplier();
        bidPricePoint.setPrice(1d);
        bidPricePoint.setQty(1_000_000d);

        final PriceAndQtyImpl offerPricePoint = (PriceAndQtyImpl) clientPrice.getOffers().addFromSupplier();
        offerPricePoint.setPrice(2d);
        offerPricePoint.setQty(1_000_000d);

        clientPrice.setInstrument(Instrument.USDIN1_1M);
        clientPrice.setMarket(Market.WSP_A);

        // Forward Point
        forwardPoint.setInstrument(Instrument.USDIN1_1M);
        forwardPoint.setBidPoints(-1.1d);
        forwardPoint.setOfferPoints(1.2d);
        forwardPoint.setUpdatedTimeStampNS(System.nanoTime());
    }

    private void scenario_simulateEvents() {
        clientPriceConsumer.accept(clientPrice);
        forwardPointConsumer.accept(forwardPoint);
        oneSecondConsumer.accept(OneSecond.INSTANCE);
    }

    @Test
    public void allocation_not_exceeded() {
        helper.testAllocationNotExceeded(
                this::scenario_simulateEvents,
                REPS, REPS,
                THRESHOLD // no allocation!
        );
    }
}