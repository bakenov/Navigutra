package com.anz.markets.prophet.collections;

import com.anz.markets.prophet.domain.collections.ListWithSupplier;
import com.anz.markets.prophet.domain.collections.ObjectPoolArrays;
import com.anz.markets.prophet.domain.collections.PoolingArrayList;
import com.anz.markets.prophet.domain.collections.PoolingArrayListTest;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.util.function.Supplier;

public class ObjectPoolsJMHTest {
    private static final int MAX_NEW_ORDERS = 100;

    @State(Scope.Benchmark)
    public static class Data {
        private ListWithSupplier<MarketDataNewOrder> listArray;
        private double lastQuantity = 0;

        @Setup
        public void setup() {
            final Supplier<MarketDataNewOrder> newOrder = () -> {
                final MarketDataNewOrderImpl order = new MarketDataNewOrderImpl();
                order.setQuantity(lastQuantity++);
                return order;
            };
            listArray = new PoolingArrayList<>(MAX_NEW_ORDERS, ObjectPoolArrays.factory(newOrder));
        }
    }

    @Benchmark
    public double addAllRemoveAllFromStartArray(Data data) {
        PoolingArrayListTest.fill(data.listArray, MAX_NEW_ORDERS);
        return PoolingArrayListTest.removeAllFromStart(data.listArray, MAX_NEW_ORDERS);
    }

    @Benchmark
    public double addAllRemoveAllFromMiddleArray(Data data) {
        PoolingArrayListTest.fill(data.listArray, MAX_NEW_ORDERS);
        return PoolingArrayListTest.removeAllFromEnd(data.listArray, MAX_NEW_ORDERS);
    }

    @Benchmark
    public double addAllRemoveAllFromEndArray(Data data) {
        PoolingArrayListTest.fill(data.listArray, MAX_NEW_ORDERS);
        return PoolingArrayListTest.removeAllFromEnd(data.listArray, MAX_NEW_ORDERS);
    }

    @Benchmark
    public double removeIfEvenArray(Data data) {
        PoolingArrayListTest.fill(data.listArray, MAX_NEW_ORDERS);
        data.listArray.removeIf(element -> element.getQuantity() % 2 == 0);
        return data.listArray.get(0).getQuantity();
    }

    // these tests exercise the MarketDataSnapshot marshalling use case
    @Benchmark
    public double startFullResizeThreeQuartersArray(Data data) {
        return PoolingArrayListTest.resize(data.listArray, MAX_NEW_ORDERS, (MAX_NEW_ORDERS / 4) * 3);
    }

    @Benchmark
    public double startHalfResizeOneQuartersArray(Data data) {
        return PoolingArrayListTest.resize(data.listArray, MAX_NEW_ORDERS / 2, MAX_NEW_ORDERS / 4);
    }

    @Benchmark
    public double startHalfResizeThreeQuartersArray(Data data) {
        return PoolingArrayListTest.resize(data.listArray, MAX_NEW_ORDERS / 2, (MAX_NEW_ORDERS * 3) / 4);
    }

    @Benchmark
    public double startEmptyResizeOneQuartersArray(Data data) {
        return PoolingArrayListTest.resize(data.listArray, 0, MAX_NEW_ORDERS / 4);
    }

/*
20/6/16 JS disabled all *Set* tests as they are considerably slower than array tests and cause JMH build runtime to bloat out
Benchmark                                                                                             Mode      Cnt      Score      Error   Units
c.a.m.p.collections.ObjectPoolsJMHTest.addAllRemoveAllFromEndArray                                  sample  2759484      4.556 �    0.005   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.addAllRemoveAllFromMiddleArray                               sample  2748842      4.572 �    0.005   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.addAllRemoveAllFromStartArray                                sample  2084375      6.029 �    0.007   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startEmptyResizeOneQuartersArray                             sample  3560913      0.475 �    0.001   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startFullResizeThreeQuartersArray                            sample  2616992      4.809 �    0.005   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startHalfResizeOneQuartersArray                              sample  2335401      1.379 �    0.003   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startHalfResizeThreeQuartersArray                            sample  2423309      2.609 �    0.004   us/op
# see below *all* Set tests are slower. Need to look into more deeply
c.a.m.p.collections.ObjectPoolsJMHTest.addAllRemoveAllFromEndSet                                    sample  3420558     14.625 �    0.008   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.addAllRemoveAllFromMiddleSet                                 sample  3155412     15.855 �    0.009   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.addAllRemoveAllFromStartSet                                  sample  3269543     15.303 �    0.008   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.removeIfEvenSet                                              sample  3124417     16.013 �    0.009   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startEmptyResizeOneQuartersSet                               sample  3603552      0.906 �    0.002   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startFullResizeThreeQuartersSet                              sample  3345688     14.207 �    0.008   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startHalfResizeOneQuartersSet                                sample  2990825      4.211 �    0.004   us/op
c.a.m.p.collections.ObjectPoolsJMHTest.startHalfResizeThreeQuartersSet                              sample  2886507      8.681 �    0.007   us/op
 */
}
