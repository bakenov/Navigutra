package com.anz.markets.efx.fox.firewall.rule;

import java.util.Objects;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class MetricBasedRule implements Rule, Comparable<MetricBasedRule> {
    private final long id;
    private final Metric metric;
    private final double limit;
    private final RuleMatcher ruleMatcher;
    private final Predicate<NewOrderSingleDecoder> orderMatcher;
    private final String description;

    public MetricBasedRule(final String firewallName,
                           final long id,
                           final String comment,
                           final double limit,
                           final Metric metric,
                           final RuleMatcher ruleMatcher,
                           final Predicate<NewOrderSingleDecoder> orderMatcher) {
        this.id = id;
        this.metric = Objects.requireNonNull(metric);
        this.ruleMatcher = Objects.requireNonNull(ruleMatcher);
        this.orderMatcher = Objects.requireNonNull(orderMatcher);
        this.limit = limit;

        this.description = "firewallName=" + Objects.requireNonNull(firewallName) + ", ruleId=" + id + "(" + comment+ "), limit=" + limit;
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        final double nextValue = metric.nextValue(newOrderSingle, currentTimeNanos);
        return !Double.isNaN(nextValue) && metric.nextValue(newOrderSingle, currentTimeNanos) <= limit;
    }

    @Override
    public int compareTo(final MetricBasedRule o) {
        return ruleMatcher.compareTo(o.ruleMatcher);
    }

    public boolean match(final NewOrderSingleDecoder newOrderSingle) {
        return orderMatcher.test(newOrderSingle);
    }

    public long id() {
        return id;
    }

    public Metric metric() {
        return metric;
    }

    public String description() {
        return description;
    }
}
