package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.time.Epoch;

@Garbage(Garbage.Type.ANY)
public final class SimpleDateDecoder implements DateDecoder {

    private final Supplier<? extends LocalDate> getter;

    public SimpleDateDecoder(final Supplier<? extends LocalDate> getter) {
        this.getter = Objects.requireNonNull(getter);
    }

    public static SimpleDateDecoder forSupplier(final Supplier<? extends LocalDate> getter) {
        return new SimpleDateDecoder(getter);
    }

    public static SimpleDateDecoder forLocalDate(final LocalDate localDate) {
        return forSupplier(() -> localDate);
    }

    @Override
    public long decodeEpochDays() {
        final LocalDate localDate = decodeLocalDateOrNull();
        return localDate == null ? 0 : Epoch.toEpochDays(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
    }

    @Override
    public int decodeYear() {
        final LocalDate localDate = decodeLocalDateOrNull();
        return localDate == null ? 0 : localDate.getYear();
    }

    @Override
    public int decodeMonth() {
        final LocalDate localDate = decodeLocalDateOrNull();
        return localDate == null ? 0 : localDate.getMonthValue();
    }

    @Override
    public int decodeDay() {
        final LocalDate localDate = decodeLocalDateOrNull();
        return localDate == null ? 0 : localDate.getDayOfMonth();
    }

    @Override
    public LocalDate decodeLocalDateOrNull() {
        return getter.get();
    }
}
