package com.anz.markets.prophet.atest.pricing._9_forward_points;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import org.junit.Test;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class ForwardPoints_Stale_Test extends BaseAcceptanceSpecification {

    @Test
    @DisplayName("When forward point is stale, mark points as NaN")
    public void forwardPointStaleUnableToInterpolate() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.USDCAD;
        final Instrument crossPair = Instrument.EURCAD;
        final long fwdPointsMaxAgeSec = 30;

        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(5)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(1)));

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(5)));

            // receive/send fwd points for driverPairB
            prophet.receive(tdd.forwardPoint(driverPairB, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(driverPairB, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));

            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_POINTS_MAX_AGE_MS, TimeUnit.SECONDS.toMillis(fwdPointsMaxAgeSec)))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.11455, 0.00001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.30525, 0.00001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairB, Market.WSP_A));
        }
        and:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A));
        }
        when:
        // no update for SPOT_NEXT tenor. Set to NaN. Since this is required for interpolation we are unable to interpolate for cross pair.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(fwdPointsMaxAgeSec));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.forwardPoint(driverPairB, -0.61d, -0.21d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.11450, 0.00001));
        }
        then:
        // clear previous cross pair client price
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getLast();
            assertThat(clientPrice.getBids().size(), is(0));
            assertThat(clientPrice.getOffers().size(), is(0));
        }
    }
}
