package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceSpikeFirewallConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.control.PricingFirewallResetImpl;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "Firewall keeps state.")
public class PriceSpikeFirewallTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Firewall triggered when ratio of price difference from low breaches instrument threshold")
    public void shouldTriggerInstrumentWhenLowBreached() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 4, 1000, 0.001, 0.0214, 10000),
                            new PriceSpikeFirewallConfig(Instrument.EURDKK, 4, 1000, 0.1, 0.2, 10))
                    ));

        }
        when:
        {   // set up another driver pair
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURDKK, 7.50050, 0.00004));

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75200, 0.00040)); // price NOT included in sample

            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {   // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.001]  => firewall not triggered
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice prices = prophet.expect(ClientPrice.class).getLast();
            checkFirewallTriggered(prices);

            prophet.clearOutputBuffer();
        }

        when:
        {   // range from latest 0.75075 to lowest is larger than latest to highest
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > threshold ratio[0.001]  => firewall triggered
            prophet.incrementTime((long) 1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            // Verify AUD/USD client prices for ALL models are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 1 instrument AUDUSD
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 1, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp, PricingFirewallType.PRICE_SPIKE);
            });
            prophet.clearOutputBuffer();
        }

        and:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK));
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURDKK, 7.5007, 0.00004));
        }

        then:
        {
            LinkedList<ClientPrice> clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK));
            for (int i = 0; i < clientPriceEURDKK.size(); i++) {
                assertThat(clientPriceEURDKK.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPriceEURDKK.get(i));
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Firewall triggered when ratio of price difference from high breaches instrument threshold")
    public void shouldTriggerInstrumentWhenHighBreached() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 4, 1000, 0.001, 0.0214, 10))
                    ));

        }
        when:
        {   // range from latest 0.75075 to highest is larger than latest to lowest
            // Ratio (0.75150 - 0.75075) / 0.75150 = 0.000998 < threshold ratio[0.001]  => firewall not triggered
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75150, 0.00040)); // highest

            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.74900, 0.00040)); // price NOT included in sample

            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        {
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);

            prophet.clearOutputBuffer();
        }

        when:
        {   // range from latest 0.75076 to highest is larger than latest to lowest
            // Ratio (0.75150 - 0.75074) / 0.75150 = 0.00101 > threshold ratio[0.001]  => firewall triggered
            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            // Verify client prices for ALL models and ALL pairs are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 1 instruments AUDUSD
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 1, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp, PricingFirewallType.PRICE_SPIKE);
            });
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Two Firewalls running simultaneously")
    public void twoFirewallsRunningSimultaneously() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 2, 1000, 0.0005, 0.0214, 10000),    // 1 second sampling
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 2, 5000, 0.0010, 0.0214, 10000))    // 5 second sampling
                    ));
        }
        when:
        {   // t0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75010, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75020, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75030, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75037, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040));
        }

        then:
        {   // 1 second sampling contains [0.75037, 0.75074]
            // 5 second sampling contains [0.75000, 0.75074]
            // Ratio (0.75074 - 0.75037) / 0.75037 = 0.000493 < threshold ratio[0.0005]  => firewall not triggered
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.0010]  => firewall not triggered
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice prices = prophet.expect(ClientPrice.class).getLast();
            checkFirewallTriggered(prices);

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75040, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75038, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75037, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75035, 0.00040));
        }

        then:
        {
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.74998, 0.00040));
        }

        then:
        {   // 1 second sampling contains [0.74998, 0.75035]
            // 5 second sampling contains [0.74998, 0.75074]
            // Ratio (0.75035 - 0.74998) / 0.75035 = 0.000493 < threshold ratio[0.0005]  => firewall not triggered
            // Ratio (0.75074 - 0.74998) / 0.75074 = 0.001012 > threshold ratio[0.0010]  => firewall TRIGGERED
            ClientPrice clientPriceAUDUSD = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrument(Instrument.AUDUSD)).getFirst();

            assertThat(clientPriceAUDUSD, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPriceAUDUSD, PricingFirewallType.PRICE_SPIKE);
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Firewall triggered when ratio of price difference from low breaches global threshold")
    public void shouldTriggerAllWhenGlobalLowBreached() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 4, 1000, 0.0011, 0.001, 10),
                            new PriceSpikeFirewallConfig(Instrument.EURDKK, 4, 1000, 0.1, 0.2, 10))
                    ));

        }
        when:
        {   // set up another ccy pair
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURDKK, 7.5005, 0.00004));

            // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < global threshold ratio[0.001]  => firewall not triggered
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75147, 0.00040)); // price NOT included in sample

            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);

            prophet.clearOutputBuffer();
        }

        when:
        {   // range from latest 0.75075 to lowest is larger than latest to highest
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > global threshold ratio[0.001]  => firewall triggered
            prophet.incrementTime((long) 1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            LinkedList<ClientPrice> clientPriceAUDUSD = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < clientPriceAUDUSD.size(); i++) {
                assertThat(clientPriceAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceAUDUSD.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }

        and:
        // expect EURDKK to be indicative
        {
            LinkedList<ClientPrice> clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK));
            for (int i = 0; i < clientPriceEURDKK.size(); i++) {
                assertThat(clientPriceEURDKK.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceEURDKK.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Firewall triggered when ratio of price difference from high breaches global threshold")
    public void shouldTriggerAllWhenGlobalHighBreached() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 4, 30, 0.0011, 0.001, 10),
                            new PriceSpikeFirewallConfig(Instrument.EURDKK, 4, 30, 0.1, 0.2, 10))
                    ));

        }
        when:
        {   // set up another ccy pair
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURDKK, 7.5005, 0.00004));

            // range from latest 0.75076 to highest is larger than latest to lowest
            // Ratio (0.75150 - 0.75076) / 0.75150 = 0.000984 < threshold ratio  => firewall not triggered
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75150, 0.00040)); // highest

            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75076, 0.00040)); // latest
        }

        then:
        {
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice prices = prophet.expect(ClientPrice.class).getLast();
            checkFirewallTriggered(prices);

            prophet.clearOutputBuffer();
        }

        when:
        {   // range from latest 0.75076 to highest is larger than latest to lowest
            // Ratio (0.75150 - 0.75074) / 0.75150 = 0.00101 > threshold ratio  => firewall triggered
            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            LinkedList<ClientPrice> clientPriceAUDUSD = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < clientPriceAUDUSD.size(); i++) {
                assertThat(clientPriceAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceAUDUSD.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }

        and:
        // expect EURDKK to be indicative
        {
            LinkedList<ClientPrice> clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK));
            for (int i = 0; i < clientPriceEURDKK.size(); i++) {
                assertThat(clientPriceEURDKK.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceEURDKK.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("When driver pair firewall triggered synthetic pairs immediately set to indicative")
    public void setSyntheticPairsIndicativeWhenFirewallTriggered() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 4, 1000, 0.001, 0.0214, 10000),
                            new PriceSpikeFirewallConfig(Instrument.USDJPY, 4, 1000, 0.1, 0.2, 10))
                    ));

        }
        when:
        {   // set up another driver pair
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.004));

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {   // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.001]  => firewall not triggered
            LinkedList<ClientPrice> clientPriceAUDUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < clientPriceAUDUSD.size(); i++) {
                assertThat(clientPriceAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPriceAUDUSD.get(i));
            }

            LinkedList<ClientPrice> clientPriceAUDJPY = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDJPY));
            for (int i = 0; i < clientPriceAUDJPY.size(); i++) {
                assertThat(clientPriceAUDJPY.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPriceAUDJPY.get(i));
            }

            prophet.clearOutputBuffer();
        }

        when:
        {   // range from latest 0.75075 to lowest is larger than latest to highest
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > threshold ratio[0.001]  => firewall triggered
            prophet.incrementTime((long) 1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD AND synthetic pair AUDJPY to be indicative
        {
            LinkedList<ClientPrice> clientPriceAUDUSD = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < clientPriceAUDUSD.size(); i++) {
                assertThat(clientPriceAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceAUDUSD.get(i), PricingFirewallType.PRICE_SPIKE);
            }

            LinkedList<ClientPrice> clientPriceAUDJPY = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDJPY));
            for (int i = 0; i < clientPriceAUDJPY.size(); i++) {
                assertThat(clientPriceAUDJPY.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceAUDJPY.get(i), PricingFirewallType.PRICE_SPIKE);
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Testing sample size limit")
    public void sampleSizeLimitedToConfig() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 2, 1000, 0.001, 0.0214, 10000))
                    ));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {   // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.001]  => firewall not triggered
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);

            prophet.clearOutputBuffer();
        }

        when:
        {   // First price 0.75 is NOT included in sample bucket so firewall not triggered.
            // If it were to be included firewall would be triggered
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > threshold ratio[0.001]  => firewall triggered
            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be FIRM
        {
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Prices indicative for latching period when firewall triggered")
    public void pricesIndicativeForLatchingPeriod() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_AUTO_RESET, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 3, 1000, 0.001, 0.0214, 4000))
                    ));
        }
        when:
        // t+0ms
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {   // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.001]  => firewall not triggered
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);

            prophet.clearOutputBuffer();
        }

        when:
        // t+2000ms
        {   // range from latest 0.75075 to lowest is larger than latest to highest
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > threshold ratio[0.001] => firewall triggered for 4 SECONDS
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            // Verify AUD/USD client prices for ALL models are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 1 instrument AUDUSD
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 1, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp, PricingFirewallType.PRICE_SPIKE);
            });
            prophet.clearOutputBuffer();
        }

        when:
        // Firewall ON/Triggered. Send in rubbish prices to ensure Firewall does not breach again and reset latching period
        {
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75200, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75076, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));

            prophet.clearOutputBuffer();
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD)).getLast();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(clientPrice);
        }
    }

    @Test
    @Requirement(Ref.PRICING__4_7_7)
    @DisplayName("Firewall still breached after latching period")
    public void firewallStillBreachedAfterLatchingPeriod() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_AUTO_RESET, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 3, 1000, 0.001, 0.0214, 4000))
                    ));
        }
        when:
        // t+0ms
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {   // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.001]  => firewall not triggered
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice prices = prophet.expect(ClientPrice.class).getLast();
            checkFirewallTriggered(prices);

            prophet.clearOutputBuffer();
        }

        when:
        // t+2000ms
        {   // range from latest 0.75075 to lowest is larger than latest to highest
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > threshold ratio[0.001] => firewall triggered for 4 SECONDS
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            // Verify AUD/USD client prices for ALL models are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 1 instrument AUDUSD
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 1, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp, PricingFirewallType.PRICE_SPIKE);
            });
            prophet.clearOutputBuffer();
        }

        when:
        // Firewall ON/Triggered. Send in rubbish prices to ensure Firewall does not breach again and reset latching period
        {
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75200, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75076, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75076, 0.00040));
        }

        then:
        {   // Ratio (0.75076 - 0.75000) / 0.75000 = 0.0010133333 > threshold ratio[0.001] => firewall triggered for 4 SECONDS
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD)).getLast();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPrice, PricingFirewallType.PRICE_SPIKE);
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING__4_7_7, Ref.PRICING_4_7_11})
    @DisplayName("Do not reset firewall if autoReset is false until manual reset")
    public void doNotResetFirewallWhenAutoResetIsFalseUntilManualReset() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_AUTO_RESET, false))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.AUDUSD, 3, 1000, 0.001, 0.0214, 2000))
                    ));
        }
        when:
        // t+0ms
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040)); // lowest

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040)); // latest
        }

        then:
        {   // range from latest 0.75074 to lowest is larger than latest to highest
            // Ratio (0.75074 - 0.75000) / 0.75000 = 0.000986 < threshold ratio[0.001]  => firewall not triggered
            ClientPrice price = prophet.expect(ClientPrice.class).getLast();
            assertThat(price, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(price);

            prophet.clearOutputBuffer();
        }

        when:
        // t+2000ms
        {   // range from latest 0.75075 to lowest is larger than latest to highest
            // Ratio (0.75075 - 0.75000) / 0.75000 = 0.001000003 > threshold ratio[0.001] => firewall triggered for 2 SECONDS
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040)); // latest
        }

        then:
        // expect AUDUSD to be indicative
        {
            // Verify AUD/USD client prices for ALL models are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 1 instrument AUDUSD
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 1, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp, PricingFirewallType.PRICE_SPIKE);
            });
            prophet.clearOutputBuffer();
        }

        when:
        // Firewall ON/Triggered for 2 seconds
        {
            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75074, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75075, 0.00040));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75073, 0.00040));
        }

        then:
        // last client price(after latching period) is STILL INDICATIVE
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.AUDUSD)).getLast();

            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPrice, PricingFirewallType.PRICE_SPIKE);
            prophet.clearOutputBuffer();
        }

        when:
        {   // Price Spike Firewall manually reset by user
            prophet.receive(PricingFirewallResetImpl.of(PricingFirewallType.PRICE_SPIKE));

            prophet.incrementTime(SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75072, 0.00040));
        }

        then:
        // Client Prices now FIRM
        {
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 4 markets (WSP_A/B/C/Z) and 1 instrument AUDUSD
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 1, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(cp);
            });
        }
    }

    private List<ClientPrice> lastClientPrices(final List<ClientPrice> clientPrices, final int expectedInstruments,
                                               final int expectedMarkets) {
        final Set<Instrument> instruments = clientPrices.stream().map(ClientPrice::getInstrument).collect(Collectors.toSet());
        assertThat(instruments.size(), is(expectedInstruments));
        final Set<Market> markets = clientPrices.stream().map(ClientPrice::getMarket).collect(Collectors.toSet());
        assertThat(markets.size(), is(expectedMarkets));
        ArrayList<ClientPrice> result = new ArrayList<>();
        instruments.forEach(instrument ->
                markets.forEach(market -> {
                    Optional<ClientPrice> clientPrice = clientPrices.stream().filter(cp -> (cp.getMarket() == market && cp.getInstrument() == instrument)).reduce((a, b) -> b);
                    if (clientPrice.isPresent()) {
                        result.add(clientPrice.get());
                    }
                })
        );
        return result;
    }
}
