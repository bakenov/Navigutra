// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import javax.swing.JTable;
import javax.swing.JTextArea;

/**
 * A MessageFlowListener that stores FIX messages in tables, and logged messages
 * in a JTextArea. It is used as a relay for the various outputs of the FIX
 * script execution system to update the UI.
 * <p>
 * It is implemented as a set of queues (which record the various messages) and
 * a set of threaded tasks which relay those queued messages to the respective
 * areas of the UI.
 * 
 */
public class GUIMessageFlowListener implements IMessageFlowListener
{
    private final BlockingQueue<QuickFixSessionMessage> incomingDataQueue;
    private final BlockingQueue<QuickFixSessionMessage> outgoingDataQueue;
    private final TableUpdater                          incomingTableUpdater;
    private final TableUpdater                          outgoingTableUpdater;
    private final StatusUpdater                         statusUpdater;
    private final ExecutorService                       executorService;
    private final BlockingQueue<String>                 statusDataQueue;

    private static final DateFormat                     logDateFormat = createDateFormat();

    private static final DateFormat createDateFormat()
    {
        final SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss.SSS");
        format.setTimeZone(TimeZone.getTimeZone("GMT"));
        return format;
    }

    /**
     * @param incomingTable
     *            the table to display incoming messages
     * @param outgoingTable
     *            the table to display outgoing messages
     * @param statusTextArea
     *            the display area for status messages, exceptions etc.
     */
    public GUIMessageFlowListener(final JTable incomingTable,
                                  final JTable outgoingTable,
                                  final JTextArea statusTextArea)
    {
        this.incomingDataQueue = new LinkedBlockingQueue<QuickFixSessionMessage>();
        this.outgoingDataQueue = new LinkedBlockingQueue<QuickFixSessionMessage>();
        this.statusDataQueue = new LinkedBlockingQueue<String>();
        this.incomingTableUpdater = new TableUpdater("Incoming Table",
                incomingTable,
                this.incomingDataQueue,
                this);
        this.outgoingTableUpdater = new TableUpdater("Outgoing Table",
                outgoingTable,
                this.outgoingDataQueue,
                this);
        this.statusUpdater = new StatusUpdater(statusTextArea,
                this.statusDataQueue);

        this.executorService = Executors.newFixedThreadPool(3);
        this.executorService.execute(this.outgoingTableUpdater);
        this.executorService.execute(this.incomingTableUpdater);
        this.executorService.execute(this.statusUpdater);
    }

    /**
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#messageReceived(com.thomsonreuters.trfx.referenceclients.fixclient.QuickFixSessionMessage)
     */
    public void messageReceived(final QuickFixSessionMessage message)
    {
        this.incomingDataQueue.add(message);
    }

    /**
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#messageSent(com.thomsonreuters.trfx.referenceclients.fixclient.QuickFixSessionMessage)
     */
    public void messageSent(final QuickFixSessionMessage message)
    {
        this.outgoingDataQueue.add(message);
    }

    /**
     * 
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#logStatusText(java.lang.String)
     */
    public synchronized void logStatusText(final String statusText)
    {
        final String timestampedStatusText = applyTimeStamp(statusText);
        System.out.println(timestampedStatusText);
        this.statusDataQueue.add(timestampedStatusText);
    }

    /**
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#logError(java.lang.String,
     *      java.lang.Exception)
     */
    public synchronized void logError(final String errorText,
            final Exception exception)
    {
        final String timestampedErrorText = applyTimeStamp(errorText);

        final StringWriter errorWriter = new StringWriter();
        errorWriter.append(timestampedErrorText);
        if (exception != null)
        {
            errorWriter.append('\n');
            errorWriter.append(exception.getMessage());
        }
        final String msg = errorWriter.toString();
        this.statusDataQueue.add(msg);
        System.err.println(msg);
    }

    private static synchronized String applyTimeStamp(final String text)
    {
        return logDateFormat.format(new Date()) + ": " + text;
    }

    /**
     * Closes down the various background UI updaters.
     * 
     * @see com.thomsonreuters.trfx.referenceclients.fixclient.IMessageFlowListener#stop()
     */
    public void stop()
    {
        this.incomingTableUpdater.stop();
        this.outgoingTableUpdater.stop();
        this.statusUpdater.stop();

        // orderly shutdown of threads via interrupt
        this.executorService.shutdownNow();
    }

}
