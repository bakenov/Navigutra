package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoInitialisationEncoder implements InitialisationEncoder, InitialisationEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;
    private Initialisation message = SorMessage.initialisation();

    public PojoInitialisationEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
    }

    public Initialisation message() {
        return message;
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        message = SorMessage.initialisation();
        return this;
    }


    @Override
    public Trailer initStage(final InitStage initStage) {
        message.body.initStage = initStage;
        return this;
    }

    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
