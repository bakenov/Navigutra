package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.fox.processor.state.ParentExecutionReportPublisher;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.fox.processor.state.usersession.UserSessionKeyFactory;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidatorRepository;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class AcceptedParentOrderConsumer implements OrderConsumer {

    private final ParentOrderValidatorRepository validatorRepository;
    private final ParentOrderRepository.WithInit parentOrderRepository;
    private final UserRepository userRepository;

    private final ByteValueCache<UserSessionKey> userSessionKeyCache = new ByteValueCache<>(new UserSessionKeyFactory());
    private final ByteValueCache<String> targetStrategyNameCache = new ByteValueCache<>(AsciiString::toString);

    public AcceptedParentOrderConsumer(final ParentOrderRepository.WithInit parentOrderRepository,
                                       final UserRepository userRepository,
                                       final ParentOrderValidatorRepository validatorRepository) {
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
        this.userRepository = Objects.requireNonNull(userRepository);
        this.validatorRepository = Objects.requireNonNull(validatorRepository);
    }

    @Override
    public boolean accept(final NewOrderSingleDecoder newOrderSingle, final CommandContext commandContext) {
        final ParentOrderValidator validator = validatorRepository.lookupByStrategyName(newOrderSingle.body().targetStrategyName().decodeAndCache(targetStrategyNameCache));

        if (validator.validate(newOrderSingle, commandContext)) {
            final UserSessionKey userSessionKey = newOrderSingle.body().senderCompId().decodeAndCache(userSessionKeyCache);
            if (userSessionKey != UserSessionKey.UNKNOWN) {
                if (userRepository.lookup(userSessionKey.userName()) != null) {
                    updateUserSession(userSessionKey, commandContext);

                    final long orderId = ParentExecutionReportPublisher.newExecReportAndGetOrderId(commandContext, newOrderSingle);

                    final ParentOrder parentOrder = parentOrderRepository.lookupByOrderId(orderId);
                    parentOrder.onStart(commandContext);
                } else {
                    ParentExecutionReportPublisher.rejectedExecReport(commandContext, newOrderSingle, OrderTextMessage.UNKNOWN_USER_IN_SENDERCOMPID.getText());
                }
            } else {
                ParentExecutionReportPublisher.rejectedExecReport(commandContext, newOrderSingle, OrderTextMessage.INVALID_SENDERCOMPID.getText());
            }
        }

        return true;
    }

    private void updateUserSession(final UserSessionKey userSessionKey, final CommandContext commandContext) {
        final int source = commandContext.source();
        final long sourceSeq = commandContext.idGenerator().getAsLong();

        commandContext.tradingEncoderSupplier().heartbeat()
                .messageStart(source, sourceSeq)
                .messageId(sourceSeq)
                .senderCompId().encode(userSessionKey.sessionId())
                .hopsEmpty()
                .messageComplete();
    }
}
