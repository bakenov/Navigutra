package com.anz.markets.efx.fox.firewall.state;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToLongFunction;

import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.fox.firewall.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.fox.firewall.matcher.OrderMatcher;
import com.anz.markets.efx.fox.firewall.matcher.RegexpRuleMatcher;
import com.anz.markets.efx.fox.firewall.rule.MetricBasedRule;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class MetricBasedRuleMatcher implements Rule.Matcher {
    private final List<MetricBasedRule> rules = new ArrayList<>();
    private final Long2ObjectHashMap<Metric> metricsMap = new Long2ObjectHashMap<>();

    private final String firewallName;
    private final Function<FirewallConfigDecoder, Metric> metricFactory;
    private final ToLongFunction<FirewallConfigDecoder> metricKeyFunction;
    private final Function<String, String> deskByUsername;
    private final ByteValueCache<String> stringsCache = new ByteValueCache<>(AsciiString::toString, 256, 10000);

    public MetricBasedRuleMatcher(final String firewallName,
                                  final Function<FirewallConfigDecoder, Metric> metricFactory,
                                  final ToLongFunction<FirewallConfigDecoder> metricKeyFunction,
                                  final Function<String, String> deskByUsername) {
        this.firewallName = Objects.requireNonNull(firewallName);
        this.metricFactory = Objects.requireNonNull(metricFactory);
        this.metricKeyFunction = Objects.requireNonNull(metricKeyFunction);
        this.deskByUsername = Objects.requireNonNull(deskByUsername);
    }

    @Override
    public Rule match(final NewOrderSingleDecoder newOrderSingle) {
        for (int i = 0; i < rules.size(); i++) {
            final MetricBasedRule rule = rules.get(i);
            if(rule.match(newOrderSingle)) return rule;
        }
        return Rule.NOT_FOUND;
    }

    @Garbage(Garbage.Type.RARE)
    public void apply(final FirewallConfigDecoder ruleConfig, final EventContext eventContext) {
        final FirewallConfigDecoder.Body body = ruleConfig.body();
        final String ruleFirewallName = body.firewallName().decodeAndCache(stringsCache);
        if (firewallName.equals(ruleFirewallName)) {
            final long ruleId = body.ruleId();
            final String regionPattern = body.regionPattern().decodeAndCache(stringsCache);
            final String deskPattern = body.deskPattern().decodeAndCache(stringsCache);
            final String orderTypePattern = body.orderTypePattern().decodeAndCache(stringsCache);
            final String portfolioPattern = body.portfolioPattern().decodeAndCache(stringsCache);
            final String usernamePattern = body.usernamePattern().decodeAndCache(stringsCache);
            final String venuePattern = body.venuePattern().decodeAndCache(stringsCache);
            final String securityTypePattern = body.securityTypePattern().decodeAndCache(stringsCache);
            final String tenorPattern = body.tenorPattern().decodeAndCache(stringsCache);
            final String symbolPattern = body.symbolPattern().decodeAndCache(stringsCache);
            final String comment = body.comment().decodeAndCache(stringsCache);
            final boolean local = body.local();
            final double ruleLimit = body.limitThreshold();

            final MetricBasedRule foundRule = findById(ruleId);

            final long metricKey = metricKeyFunction.applyAsLong(ruleConfig);
            final Metric foundSharableMetric = metricsMap.get(metricKey);

            if (foundRule != null) {
                rules.remove(foundRule);
                if (local) {
                    metricsMap.values().remove(foundRule.metric());
                } else {
                    if (foundRule.metric() != foundSharableMetric && !metricUsed(foundRule.metric())) {
                        metricsMap.values().remove(foundRule.metric());
                    }
                }
            }

            final RuleMatcher ruleMatcher = new RegexpRuleMatcher(regionPattern, deskPattern,
                    orderTypePattern, portfolioPattern, usernamePattern,
                    venuePattern, securityTypePattern, tenorPattern, symbolPattern);

            final Metric newMetric;
            if (local) {
                newMetric =
                        Metric.withMatcher(
                            metricFactory.apply(ruleConfig),
                            new ExecutionReportMatcher(stringsCache, deskByUsername, ruleMatcher));
            } else {
                newMetric = foundSharableMetric == null ? metricFactory.apply(ruleConfig) : foundSharableMetric;
            }
            metricsMap.put(metricKey, newMetric);

            final Predicate<NewOrderSingleDecoder> orderMatcher = new OrderMatcher(stringsCache, deskByUsername, ruleMatcher);

            final MetricBasedRule rule = new MetricBasedRule(firewallName, ruleId, comment, ruleLimit, newMetric, ruleMatcher, orderMatcher);
            rules.add(rule);
            Collections.sort(rules);
        }
    }

    private MetricBasedRule findById(final long ruleId) {
        for (int i = 0; i < rules.size(); i++) {
            final MetricBasedRule rule = rules.get(i);
            if (ruleId == rule.id()) return rule;
        }
        return null;
    }

    private boolean metricUsed(final Metric metric) {
        for (int i = 0; i < rules.size(); i++) {
            final MetricBasedRule rule = rules.get(i);
            if (metric.equals(rule.metric())) return true;
        }
        return false;
    }

    public void apply(final ExecutionReportDecoder executionReport, final EventContext eventContext) {
        metricsMap.values().forEach(metric -> metric.accept(executionReport, eventContext.precisionClock().nanos()));
    }
}
