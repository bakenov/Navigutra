package com.anz.markets.efx.fox.receiver;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class TopicSubscriberTest {
    @Mock
    private Connection connection;
    @Mock
    private EndPointStatusHandler endPointStatusHandler;
    @Mock
    private MessageHandler messageHandler;
    private String topicName = "someTopic";

    private TopicSubscriber topicSubscriber;

    @BeforeEach
    void setUp() {
        topicSubscriber = new TopicSubscriber(connection, endPointStatusHandler, messageHandler, topicName);
    }

    @Test
    void subscribe_should_open_subscription() {
        topicSubscriber.subscribe();
        verify(connection).openSubscription(DefaultTopic.create(topicName), endPointStatusHandler, messageHandler);
    }
}