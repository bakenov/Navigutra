#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-spdee-deal-stp-latency - Plugin to monitor the SPDEE Deal STP Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title SPDEE Deal STP Latency'
    echo 'graph_category spdee'
    echo 'graph_scale no'

    echo 'latencyPendingConfirmed.label Position Pending to Confirmed (Ready for STP to CTA)'
    echo 'latencyPendingConfirmed.draw LINE2'

    echo 'latencyCommencedConfirmed.label Position Commenced to Confirmed (Start STP to CTA)'
    echo 'latencyCommencedConfirmed.draw LINE2'

    echo 'latencyCompletedConfirmed.label Position Completed to Confirmed (Finished STP to CTA)'
    echo 'latencyCompletedConfirmed.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "latencyPendingConfirmed.value U"
        echo "latencyCommencedConfirmed.value U"
        echo "latencyCompletedConfirmed.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "latencyPendingConfirmed.value U"
        echo "latencyCommencedConfirmed.value U"
        echo "latencyCompletedConfirmed.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
egrep 'dealing.position-.*-to-confirmed,,' $LOGFILE | tail -100 | awk -F, '
BEGIN {
        latencyPendingConfirmed_value=0;
        latencyCommencedConfirmed_value=0;
        latencyCompletedConfirmed_value=0;
}

/dealing.position-pending-to-confirmed/ {latencyPendingConfirmed_value=$15}
/dealing.position-commenced-to-confirmed/ {latencyCommencedConfirmed_value=$15}
/dealing.position-completed-to-confirmed/ {latencyCompletedConfirmed_value=$15}

END {
        print "latencyPendingConfirmed.value " latencyPendingConfirmed_value;
        print "latencyCommencedConfirmed.value " latencyCommencedConfirmed_value;
        print "latencyCompletedConfirmed.value " latencyCompletedConfirmed_value;
}
'
fi
