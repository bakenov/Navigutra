package com.anz.markets.efx.ngaro.collections;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class EnumSetImplTest {

    @Test
    public void testToString() {
        EnumSet<AnimalEnum> set = new EnumSet<>(AnimalEnum.class);
        assertThat(set.add(AnimalEnum.CAT), is(true));
        assertThat(set.add(AnimalEnum.DOG), is(true));
        assertThat(set.add(AnimalEnum.DOG), is(false));
        assertThat(set.toString(), is("CAT,DOG"));
    }
}