package com.anz.markets.efx.fox.codec.pojo;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class InstrumentConfigAsserter {
    private final InstrumentConfig message;

    public InstrumentConfigAsserter(final InstrumentConfig message) {
        this.message = Objects.requireNonNull(message);
    }

    public static InstrumentConfigAsserter expect(final InstrumentConfig message) {
        return new InstrumentConfigAsserter(message);
    }

    public static InstrumentConfigAsserter expect(final MessageHeader header, final InstrumentConfig.Body body) {
        return new InstrumentConfigAsserter(SorMessage.instrumentConfig(header, body));
    }

    public InstrumentConfig message() {
        return message;
    }

    public InstrumentConfig.Body body() {
        return message.body;
    }

    public InstrumentConfigHandler assertingInstrumentConfigHandler() {
        return body -> {
            assertEquals("instrumentId not as expected", body().instrumentId, body.instrumentId());
            assertEquals("pipSizeDivisor not as expected", body().pipSizeDivisor, body.pipSizeDivisor());
            assertEquals("enabled not as expected", body().enabled, body.enabled());
        };
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a InstrumentConfig", sorMessage instanceof InstrumentConfig);
        assertInstrumentConfig((InstrumentConfig) sorMessage);
    }

    public void assertInstrumentConfig(final InstrumentConfig instrumentConfig) {
        assertBody(instrumentConfig.body);
    }

    public void assertBody(final InstrumentConfig.Body body) {
        assertEquals("instrumentId not as expected", body().instrumentId, body.instrumentId);
        assertEquals("pipSizeDivisor not as expected", body().pipSizeDivisor, body.pipSizeDivisor);
        assertEquals("enabled not as expected", body().enabled, body.enabled);
    }
}
