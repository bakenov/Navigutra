package com.anz.axle.lg.adapter.bgc;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.annotation.PostConstruct;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingHandlerSupplier;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;

@Configuration
public class PricingSubscriptionConfig {

    private final EndPointStatusHandler END_POINT_STATUS_HANDLER = new LoggingStatusHandler(LoggerFactory.getLogger(PricingSubscriptionConfig.class));
    private final Connection connection;
    private final PricingHandlerSupplier pricingHandlerSupplier;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final Venue venue;
    private final String subscriptionMarket;
    private final String subscriptionHost;

    public PricingSubscriptionConfig(final Connection connection,
                                     final PricingHandlerSupplier pricingHandlerSupplier,
                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                     @Value("${bgc.subscription.market}") final String subscriptionMarket,
                                     @Value("${bgc.subscription.host}") final String subscriptionHost) {
        this.connection = Objects.requireNonNull(connection);
        this.pricingHandlerSupplier = Objects.requireNonNull(pricingHandlerSupplier);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.subscriptionMarket = Objects.requireNonNull(subscriptionMarket);
        this.subscriptionHost = Objects.requireNonNull(subscriptionHost);
        this.venue = Venue.BGCMIDFX;
    }

    @PostConstruct
    void init() {

        final SbePricingDecoders sbePricingDecoders = new SbePricingDecoders();
        final MessageDecoder<SbeMessage> messageDecoder = sbePricingDecoders.snapshotFullRefresh().create(pricingHandlerSupplier, MessageDecoder.ForwardingLookup.noop());
        final DecodingMessageHandler decodingMessageHandler = new DecodingMessageHandler(messageDecoder);

        fxSpotVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
            // sample topic FXSPOT_WSP_API_6_CADSGD_daxa015z
            final Topic topic = DefaultTopic.create(SecurityType.FXSPOT + "_" + subscriptionMarket + "_" + symbol + "_" + subscriptionHost);
            connection.openSubscription(topic, END_POINT_STATUS_HANDLER, decodingMessageHandler);
        });
    }
}
