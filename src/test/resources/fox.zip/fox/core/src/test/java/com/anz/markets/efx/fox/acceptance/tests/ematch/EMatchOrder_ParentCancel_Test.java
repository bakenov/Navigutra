package com.anz.markets.efx.fox.acceptance.tests.ematch;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.NewOrderSingleMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRequestMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RunWith(Spockito.class)
public class EMatchOrder_ParentCancel_Test {
    private static final Logger LOGGER = LoggerFactory.getLogger(EMatchOrder_ParentCancel_Test.class);
    private static final String SYMBOL = "AUDUSD";
    private static final String EMATCH_STRATEGY_NAME = "EMATCH";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private MarketDataFactory marketDataFactory = new MarketDataFactory();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_cancel_child_and_then_cancel_parent() throws Exception {
        final InstrumentKey instrumentKey = InstrumentKey.of(SYMBOL, SecurityType.FXSPOT, Tenor.SP);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "GB:lg-ebsc";
        sorEndpoint.tradingRequest().add(heartbeat);

        final Venue market = Venue.EBS;
        final String nosClOrdId = "3452435";
        final String ocrClOrdId = "3452436";
        final OrderType orderType = OrderType.FIXING_ORDER;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 0;
        final double quantity = 1000000;
        final TimeInForce timeInForce = TimeInForce.GTC;    // EMatch only supports GTC.
        final String senderCompId = "FXTrader.GB.litvinc.XEFX";
        final String targetCompId = "GB:fox";

        // New EMATCH order request
        final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
        order.body.senderCompId = senderCompId;
        order.body.targetCompId = targetCompId;
        order.body.transactTime = acceptanceContext.precisionClock().nanos();
        order.body.timeInForce = timeInForce;
        order.body.orderQty = quantity;
        order.body.clOrdId = nosClOrdId;
        order.body.currency = currency;
        order.body.ordType = orderType;
        order.body.price = price;
        order.body.targetStrategyName = EMATCH_STRATEGY_NAME;
        order.body.securityType = instrumentKey.securityType();
        order.body.settlCurrency = currency;
        order.body.side = side;
        order.body.symbol = instrumentKey.symbol();
        order.body.settlType = instrumentKey.tenor();
        order.parties.add(new Party(PartyRole.USER_NAME, "autotrader-MidHedger"));
        order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
        order.strategyParameters.add(new StrategyParameter("Markets", market.name()));
        order.strategyParameters.add(new StrategyParameter("BenchmarkFix", "BFIX_LONDON_1600"));

        sorEndpoint.tradingRequest().add(order);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(order.body.senderCompId))
                        .body().matches(NewOrderSingleMatcher.targetCompId().eq(order.body.targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.quoteId().eq(order.body.quoteId))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.targetStrategyName().eq(order.body.targetStrategyName))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterName().eq("Markets"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterValue().eq("EBS"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterName().eq("BenchmarkFix"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterValue().eq("BFIX_LONDON_1600"))
                )
                .awaitMatchAndGetLast(1000, TimeUnit.SECONDS);

        // Ack NOS EMATCH
        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:fox"))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(nosClOrdId))
                .body().matches(ExecutionReportMatcher.origClOrdId().eq(nosClOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                .regulatoryTradeIds().countEquals(0);


        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // Create venue NOS (EBS) and ack it
        final VenueEndpoint ebsVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.EBS);
        //Expect NewOrderSingle on EBS venue
        final TradingMessage venueNos = Asserter.of(ebsVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);


        final TradingMessage sorNewER = Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.targetCompId().eq(senderCompId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.price().eq(order.body.price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(ExecutionReportMatcher.currency().eq(order.body.currency))
                        .body().matches(ExecutionReportMatcher.side().eq(order.body.side))
                        .body().matches(ExecutionReportMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        // Once child order is acked -> cancel parent.
        sorNewER.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onExecutionReport(final ExecutionReport parentER) {
                //send an order cancel request
                final OrderCancelRequest orderCancelRequest = sorEndpoint.createOrderCancelRequest();
                orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
                orderCancelRequest.body.orderQty = quantity;
                orderCancelRequest.body.clOrdId = ocrClOrdId;
                orderCancelRequest.body.orderId = parentER.body.orderId;
                orderCancelRequest.body.origClOrdId = parentER.body.clOrdId;
                orderCancelRequest.body.clOrdLinkId = parentER.body.clOrdId;
                orderCancelRequest.body.securityType = instrumentKey.securityType();
                orderCancelRequest.body.senderCompId = senderCompId;
                orderCancelRequest.body.targetCompId = targetCompId;
                orderCancelRequest.body.side = side;
                orderCancelRequest.body.symbol = parentER.body.symbol;
                orderCancelRequest.body.text = "client requested";

                LOGGER.info(orderCancelRequest.toString());
                LOGGER.info("==============================================================");
                sorEndpoint.tradingRequest().add(orderCancelRequest);

            }
        });


        //Expect orderCancelRequest on EBS venue
        final TradingMessage venueOcr = Asserter.of(ebsVenue.tradingRequest())
                .matching(OrderCancelRequestMatcher.build()
                        .body().matches(OrderCancelRequestMatcher.senderCompId().eq("GB:fox"))
                        .body().matches(OrderCancelRequestMatcher.marketId().eq(market.name()))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueOcr.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onOrderCancelRequest(final OrderCancelRequest ocr) {
                final ExecutionReport executionReport1 = ebsVenue.createExecutionReport();
                executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport1.body.marketId = ocr.body.marketId;
                executionReport1.body.orderQty = ocr.body.orderQty;
                executionReport1.body.orderId = ocr.body.orderId;
                executionReport1.body.clOrdId = ocr.body.clOrdId;
                executionReport1.body.origClOrdId = ocr.body.origClOrdId;
                executionReport1.body.clOrdLinkId = ocr.body.clOrdLinkId;
                executionReport1.body.execId = "4568";
                executionReport1.body.securityType = ocr.body.securityType;
                executionReport1.body.senderCompId = "GB:lg-ebsc";
                executionReport1.body.side = ocr.body.side;
                executionReport1.body.symbol = ocr.body.symbol;
                executionReport1.body.execType = ExecType.CANCELED;
                executionReport1.body.ordStatus = OrderStatus.CANCELED;
                executionReport1.body.leavesQty = 0;
                executionReport1.body.cumQty = 0;
                executionReport1.body.lastQty = 0;
                executionReport1.body.lastPx = 0;

                ebsVenue.tradingResponse().add(executionReport1);
            }
        });


        final TradingMessage parentPendingCancel = Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.marketId().eq("FOX"))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.PENDING_CANCEL))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PENDING_CANCEL)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(ocrClOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(nosClOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    // Testing B.1.b scenario for order state transition (see FIX spec)
    @Test
    public void should_propagate_fill_when_child_partfilled_before_cancel_then_cancel() throws Exception {
        final InstrumentKey instrumentKey = InstrumentKey.of(SYMBOL, SecurityType.FXSPOT, Tenor.SP);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "GB:lg-ebsc";
        sorEndpoint.tradingRequest().add(heartbeat);

        final Venue market = Venue.EBS;
        final String nosClOrdId = "3452435";
        final String ocrClOrdId = "3452436";
        final String orderId = "2345";
        final OrderType orderType = OrderType.FIXING_ORDER;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 0;
        final double quantity = 1000000;
        final TimeInForce timeInForce = TimeInForce.GTC;    // EMatch only supports GTC.
        final String senderCompId = "FXTrader.GB.litvinc.XEFX";
        final String targetCompId = "GB:fox";


        // New EMATCH order request
        final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
        order.body.senderCompId = senderCompId;
        order.body.targetCompId = targetCompId;
        order.body.transactTime = acceptanceContext.precisionClock().nanos();
        order.body.timeInForce = timeInForce;
        order.body.orderQty = quantity;
        order.body.clOrdId = nosClOrdId;
        order.body.currency = currency;
        order.body.ordType = orderType;
        order.body.price = price;
        order.body.targetStrategyName = EMATCH_STRATEGY_NAME;
        order.body.securityType = instrumentKey.securityType();
        order.body.settlCurrency = currency;
        order.body.side = side;
        order.body.symbol = instrumentKey.symbol();
        order.body.settlType = instrumentKey.tenor();
        order.parties.add(new Party(PartyRole.USER_NAME, "autotrader-MidHedger"));
        order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
        order.strategyParameters.add(new StrategyParameter("Markets", market.name()));
        order.strategyParameters.add(new StrategyParameter("BenchmarkFix", "BFIX_LONDON_1600"));

        sorEndpoint.tradingRequest().add(order);

        snapshots.forEach((venue, snapshotFullRefresh) -> {
            Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                    .matching(SnapshotFullRefreshMatcher.build()
                            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(snapshotFullRefresh.body.senderCompId))
                            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(venue))
                            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId())))
                    .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
        });

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(order.body.senderCompId))
                        .body().matches(NewOrderSingleMatcher.targetCompId().eq(order.body.targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.quoteId().eq(order.body.quoteId))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.targetStrategyName().eq(order.body.targetStrategyName))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterName().eq("Markets"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterValue().eq("EBS"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterName().eq("BenchmarkFix"))
                        .strategyParameters().anyMatches(NewOrderSingleMatcher.strategyParameterValue().eq("BFIX_LONDON_1600"))
                )
                .awaitMatchAndGetLast(1000, TimeUnit.SECONDS);

        // Ack NOS EMATCH
        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(nosClOrdId))
                .body().matches(ExecutionReportMatcher.origClOrdId().eq(nosClOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                .regulatoryTradeIds().countEquals(0);


        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // Create venue NOS (EBS) and ack it
        final VenueEndpoint ebsVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.EBS);
        //Expect NewOrderSingle on EBS venue
        final TradingMessage venueNos = Asserter.of(ebsVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);


        final TradingMessage sorNewER = Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.targetCompId().eq(senderCompId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.price().eq(order.body.price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(ExecutionReportMatcher.currency().eq(order.body.currency))
                        .body().matches(ExecutionReportMatcher.side().eq(order.body.side))
                        .body().matches(ExecutionReportMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        // Once child order is acked -> cancel parent.
        sorNewER.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onExecutionReport(final ExecutionReport parentER) {
                //send an order cancel request
                final OrderCancelRequest orderCancelRequest = sorEndpoint.createOrderCancelRequest();
                orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
                orderCancelRequest.body.orderQty = quantity;
                orderCancelRequest.body.clOrdId = ocrClOrdId;
                orderCancelRequest.body.orderId = parentER.body.orderId;
                orderCancelRequest.body.origClOrdId = parentER.body.origClOrdId;
                orderCancelRequest.body.clOrdLinkId = parentER.body.clOrdLinkId;
                orderCancelRequest.body.securityType = instrumentKey.securityType();
                orderCancelRequest.body.senderCompId = senderCompId;
                orderCancelRequest.body.targetCompId = targetCompId;
                orderCancelRequest.body.side = side;
                orderCancelRequest.body.symbol = parentER.body.symbol;
                orderCancelRequest.body.text = "client requested";

                LOGGER.info(orderCancelRequest.toString());
                LOGGER.info("==============================================================");
                sorEndpoint.tradingRequest().add(orderCancelRequest);

            }
        });

        final TradingMessage parentPendingCancel = Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.marketId().eq("FOX"))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.PENDING_CANCEL))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PENDING_CANCEL)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);


        //Expect orderCancelRequest on EBS venue
        final TradingMessage venueOcr = Asserter.of(ebsVenue.tradingRequest())
                .matching(OrderCancelRequestMatcher.build()
                        .body().matches(OrderCancelRequestMatcher.senderCompId().eq("GB:fox"))
                        .body().matches(OrderCancelRequestMatcher.marketId().eq(market.name()))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueOcr.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onOrderCancelRequest(final OrderCancelRequest ocr) {

                final ExecutionReport executionReportFill = ebsVenue.createExecutionReport();
                executionReportFill.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReportFill.body.timeInForce = order.body.timeInForce;
                executionReportFill.body.marketId = market.name();
                executionReportFill.body.orderQty = order.body.orderQty;
                executionReportFill.body.orderId = orderId;
                executionReportFill.body.clOrdId = ocr.body.origClOrdId;
                executionReportFill.body.origClOrdId = ocr.body.origClOrdId;
                executionReportFill.body.clOrdLinkId = ocr.body.clOrdLinkId;
                executionReportFill.body.execId = "4568";
                executionReportFill.body.quoteId = order.body.quoteId;
                executionReportFill.body.currency = order.body.currency;
                executionReportFill.body.ordType = order.body.ordType;
                executionReportFill.body.price = 0.0;
                executionReportFill.body.securityType = order.body.securityType;
                executionReportFill.body.senderCompId = "GB:lg-ebsc";
                executionReportFill.body.targetCompId = targetCompId;
                executionReportFill.body.settlCurrency = order.body.currency;
                executionReportFill.body.settlType = order.body.settlType;
                executionReportFill.body.side = order.body.side;
                executionReportFill.body.symbol = order.body.symbol;
                executionReportFill.body.execType = ExecType.TRADE;
                executionReportFill.body.ordStatus = OrderStatus.PARTIALLY_FILLED;
                executionReportFill.body.leavesQty = 500000;
                executionReportFill.body.cumQty = order.body.orderQty - 500000;
                executionReportFill.body.lastQty = order.body.orderQty - 500000;
                executionReportFill.body.lastPx = 0.0;

                ebsVenue.tradingResponse().add(executionReportFill);

                LOGGER.info(executionReportFill.toString());
                LOGGER.info("============================================================");

                // .. then reject cancel request
                final ExecutionReport executionReportCanceled = ebsVenue.createExecutionReport();
                executionReportCanceled.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReportCanceled.body.timeInForce = ocr.body.timeInForce;
                executionReportCanceled.body.marketId = market.name();
                executionReportCanceled.body.orderQty = ocr.body.orderQty;
                executionReportCanceled.body.orderId = orderId;
                executionReportCanceled.body.clOrdId = ocr.body.clOrdId;
                executionReportCanceled.body.origClOrdId = ocr.body.origClOrdId;
                executionReportCanceled.body.clOrdLinkId = ocr.body.clOrdLinkId;
                executionReportCanceled.body.execId = "4569";
                executionReportCanceled.body.ordType = ocr.body.ordType;
                executionReportCanceled.body.price = 0.0;
                executionReportCanceled.body.securityType = ocr.body.securityType;
                executionReportCanceled.body.currency = order.body.currency;
                executionReportCanceled.body.senderCompId = "GB:lg-ebsc";
                executionReportCanceled.body.targetCompId = targetCompId;
                executionReportCanceled.body.settlCurrency = order.body.currency;
                executionReportCanceled.body.settlType = order.body.settlType;
                executionReportCanceled.body.side = ocr.body.side;
                executionReportCanceled.body.symbol = ocr.body.symbol;
                executionReportCanceled.body.execType = ExecType.CANCELED;
                executionReportCanceled.body.ordStatus = OrderStatus.CANCELED;
                executionReportCanceled.body.leavesQty = 0;
                executionReportCanceled.body.cumQty = order.body.orderQty - 500000;
                executionReportCanceled.body.lastQty = 0;
                executionReportCanceled.body.lastPx = 0;

                ebsVenue.tradingResponse().add(executionReportCanceled);
                LOGGER.info(executionReportCanceled.toString());
                LOGGER.info("============================================================");
            }
        });



        // Should have Partial Fill and then Cancel
        Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                                .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                                .body().matches(ExecutionReportMatcher.clOrdId().eq(nosClOrdId))
                                .body().matches(ExecutionReportMatcher.origClOrdId().eq(nosClOrdId))
                                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PENDING_CANCEL))
                                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                                .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                                .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                                .body().matches(ExecutionReportMatcher.side().eq(side))
                                .body().matches(ExecutionReportMatcher.price().eq(0.0))
                                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                                .body().matches(ExecutionReportMatcher.cumQty().eq(quantity - 500_000))
                                .body().matches(ExecutionReportMatcher.leavesQty().eq(500_000d))
                )
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(ocrClOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(nosClOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(instrumentKey.symbol()))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

    }

}
