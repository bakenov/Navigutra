package com.anz.axle.lg.adapter.apama.config.core;

import java.nio.ByteBuffer;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;

import org.agrona.concurrent.UnsafeBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.apama.engine.beans.EngineClientBean;
import com.apama.services.event.EventServiceFactory;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

import com.anz.axle.lg.adapter.apama.transport.ApamaTransport;
import com.anz.axle.lg.adapter.apama.transport.Transport;
import com.anz.axle.lg.config.DefaultTopicRegistry;
import com.anz.axle.lg.config.DuplicateSuppressingStatusHandler;
import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.axle.lg.config.MarketDataRequestConfig;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.BackPressureStrategy;
import com.anz.axle.lg.publisher.DefaultPublicationRegistry;
import com.anz.axle.lg.publisher.PublicationLookup;
import com.anz.axle.lg.publisher.Publisher;
import com.anz.axle.lg.util.CurrentMillisIdFactory;
import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;

@Configuration
public class PublishingConfig {
    @Bean
    public PrecisionClock precisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("async-%d").build());
    }

    @Bean
    public Transport apamaTransport() {
        return new ApamaTransport(EngineClientBean::new, EventServiceFactory::createEventService);
    }

    @Bean
    public CurrentMillisIdFactory messageIdFactory() {
        return new CurrentMillisIdFactory();
    }

    @Bean
    public TopicRegistry pricingTopicRegistry() {
        return new DefaultTopicRegistry();
    }

    @Bean
    public BackPressureStrategy backPressureStrategy() {
        return BackPressureStrategy.NOOP;
    }

    @Bean
    public DefaultPublicationRegistry publicationRegistry(final ScheduledExecutorService scheduledExecutorService,
                                                          final Connection connection,
                                                          final BackPressureStrategy backPressureStrategy) {
        final Logger logger = LoggerFactory.getLogger(DefaultPublicationRegistry.class);
        final DuplicateSuppressingStatusHandler duplicateSuppressingStatusHandler = new DuplicateSuppressingStatusHandler(new LoggingStatusHandler(logger));
        scheduledExecutorService.schedule(() -> duplicateSuppressingStatusHandler.flushSuppressedRepetitions(false), 10, TimeUnit.SECONDS);
        return new DefaultPublicationRegistry(connection, duplicateSuppressingStatusHandler, backPressureStrategy);
    }

    @Bean
    public Publisher publisher(final PublicationLookup publicationLookup) {
        return new Publisher(publicationLookup);
    }

    @Bean
    public Function<Consumer<SbeMessage>, PricingEncoderSupplier> pricingEncoderSupplierFactory(
            @Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity) {
        return compassMessageConsumer -> PricingEncoderSupplier.threadLocal(() -> {
            final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
            final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
            final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
            final PricingEncoders<SbeMessage> pricingEncoders = new SbePricingEncoders(() -> sbeMessage);
            return PricingEncoderSupplier.create(pricingEncoders, compassMessageConsumer);
        });
    }

    //FIXME add FXFWD ones merged/rebased and replace all usages of the raw maps with this bean
    @Bean
    public MarketDataRequestConfig marketDataRequestConfig(@Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                                           @Value("#{${symbol.venues.FXNDF}}") final Map<String, Set<Venue>> fxNdfSymbolVenues) {
        final Map<SecurityType, VenueSymbolMatrix> venueSymbolMatrices = new EnumMap<>(SecurityType.class);
        venueSymbolMatrices.put(SecurityType.FXSPOT, VenueSymbolMatrix.of(fxSpotSymbolVenues));
        venueSymbolMatrices.put(SecurityType.FXNDF, VenueSymbolMatrix.of(fxNdfSymbolVenues));

        return MarketDataRequestConfig.of(venueSymbolMatrices);
    }
}
