package com.anz.markets.disco;

import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.util.logging.LogThrottled;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * The message bus upon which all computation is triggered.
 * This should be the only class with synchronization in DISCO.
 */
public class MessageBus {

    private final LogThrottled logThrottled = new LogThrottled(MessageBus.class, LogThrottled.LogThrottleType.EVERY_SECOND);

    private static final int MAX_DEPTH = 10;

    private static final Map<Class,String> simpleNames = Collections.synchronizedMap(new HashMap<>());

    private final HashMap<Symbol, List<Consumer>> listeners = new HashMap<>();
    private final List<MessageBusConsumer> allConsumersStart = new ArrayList<>();
    private final List<MessageBusConsumer> allConsumersEnd = new ArrayList<>();

    private int depth;
    private long driverEventSystemTimeNanos;

    public interface MessageBusConsumer<T> extends BiConsumer<Symbol, T> {
        ;
    }

    public synchronized void pub(Class messageType, Object message) {
        pub(getMessageType(messageType), message);
    }

    public static Symbol getMessageType(Class messageType) {
        return Symbol.get(simpleNames.computeIfAbsent(messageType,m -> m.getSimpleName()));
    }

    public int getDepth() {
        return depth;
    }

    public boolean isInputEvent() {
        return depth == 1;
    }

    public MessageSource getMessageSource() {
        return isInputEvent() ? MessageSource.EXOGENOUS : MessageSource.ENDOGENOUS;
    }

    public long getDriverEventSystemTimeNanos() {
        return driverEventSystemTimeNanos;
    }

    public synchronized void pub(Symbol messageType, Object message) {

        try {
            if (depth == 0) {
                driverEventSystemTimeNanos = System.nanoTime();
            }

            depth++;
            if (depth > MAX_DEPTH) {
                throw new RuntimeException("Logic error, maximum depth exceeded: " + MAX_DEPTH);
            }

            for (int i = 0; i < allConsumersStart.size(); i++) {
                try {
                    allConsumersStart.get(i).accept(messageType, message);
                } catch (Exception e) {
                    logThrottled.error("Error notifying consumer.  Message={}.", message, e);
                }
            }

            final List<Consumer> consumers = listeners.get(messageType);
            if (consumers != null) {
                for (int i = 0; i < consumers.size(); i++) {
                    try {
                        consumers.get(i).accept(message);
                    } catch (Exception e) {
                        logThrottled.error("Error notifying consumer.  Message={}.", message, e);
                    }
                }
            }

            for (int i = 0; i < allConsumersEnd.size(); i++) {
                try {
                    allConsumersEnd.get(i).accept(messageType, message);
                } catch (Exception e) {
                    logThrottled.error("Error notifying consumer.  Message={}.", message, e);
                }
            }

        } finally {
            depth--;
        }
    }

    private void sub(Consumer consumer, Symbol messageType) {
        listeners.computeIfAbsent(messageType, s -> new ArrayList<>()).add(consumer);
    }

    public synchronized <T> void sub(Consumer<T> consumer, Class<T> messageType) {
        sub(consumer, getMessageType(messageType));
    }

    public synchronized <T> void subAnyPrior(MessageBusConsumer<T> consumer) {
        allConsumersStart.add(consumer);
    }

    public synchronized <T> void subAny(MessageBusConsumer<T> consumer) {
        allConsumersEnd.add(consumer);
    }

    public synchronized <T> void subAny(Consumer<T> consumer) {
        allConsumersEnd.add((s,v) -> consumer.accept((T) v));
    }

}
