package com.anz.markets.efx.ngaro.sbe;

import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.ByteWriter;

/**
 * Provides indexed write access to string bytes. Such methods are for instance found on SBE encoders for fixed length
 * strings.
 */
@FunctionalInterface
public interface FixedStringTarget {
    void putByte(int index, byte value);

    static FixedStringTarget lazy(final Supplier<FixedStringTarget> supplier) {
        return Lazy.fixedStringTarget(supplier);
    }

    ByteWriter<FixedStringTarget> BYTE_WRITER = (tgt, idx, val) -> tgt.putByte(idx, val);
}
