package com.anz.markets.prophet.pricer.truethrottle;

import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

@Ignore("failing in TC")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TrueThrottlerManagerBWTest {

    private static final int REPS = 100_000;
    public static final int THRESHOLD = 1256;

    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private TrueThrottleManagerTest trueThrottleManagerTest;

    @BeforeClass
    public static void warmup() throws IOException {
        TrueThrottleManagerTest.setupClass();
        TrueThrottlerManagerBWTest warmit = new TrueThrottlerManagerBWTest();
        warmit.setup();
        warmit.checkHeartbeat();
        warmit.checkSendChangingPrice();
    }

    @Before
    public void setup() throws IOException {
        trueThrottleManagerTest = new TrueThrottleManagerTest();
        trueThrottleManagerTest.setup();
        trueThrottleManagerTest.clientPriceConsumer.accept(trueThrottleManagerTest.price1);
        assertEquals(1, trueThrottleManagerTest.accumulator.size());
    }

    @Test
    public void testCheckHeartbeat() throws IOException {
        setup();
        helper.testAllocationNotExceeded(
                this::checkHeartbeat,
                THRESHOLD
        );
    }

    @Test
    public void testCheckSendChangingPrice() throws IOException {
        trueThrottleManagerTest.setup();
        helper.testAllocationNotExceeded(
                this::checkSendChangingPrice,
                THRESHOLD
        );
    }

    private void checkHeartbeat() {
        for (int i = 1; i < REPS; i++) {
            TrueThrottleManagerTest.timeSource.incrementNanos(TimeUnit.SECONDS.toNanos(1));
            trueThrottleManagerTest.oneSecondConsumer.accept(OneSecond.INSTANCE);
            GcFriendlyAssert.isTrue(trueThrottleManagerTest.accumulator.size() >= (i / 5));
        }
    }

    private void checkSendChangingPrice() {
        for (int i = 1; i < REPS; i++) {
            TrueThrottleManagerTest.timeSource.incrementNanos(TimeUnit.MILLISECONDS.toNanos(10));
            mutate((PriceAndQtyImpl) trueThrottleManagerTest.price1.getBids().get(0));
            ((PriceAndQtyImpl) trueThrottleManagerTest.price1.getOffers().get(0)).setPrice(trueThrottleManagerTest.price1.getTopOfBookBid().getPrice() + 1);
            mutate((PriceAndQtyImpl) trueThrottleManagerTest.price1.getOffers().get(0));
            trueThrottleManagerTest.clientPriceConsumer.accept(trueThrottleManagerTest.price1);
            GcFriendlyAssert.isTrue(trueThrottleManagerTest.accumulator.size() >= (i / 100));
        }
    }

    private void mutate(final PriceAndQtyImpl clientPricePoint) {
        clientPricePoint.setPrice(Math.max(100, clientPricePoint.getPrice() + (Math.random() - 0.5d)));
    }
}