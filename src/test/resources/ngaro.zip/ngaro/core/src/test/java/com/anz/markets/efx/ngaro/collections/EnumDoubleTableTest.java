package com.anz.markets.efx.ngaro.collections;

import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;


public class EnumDoubleTableTest {

    private EnumDoubleTable<AnimalEnum, AlphabetEnum> getInstrumentCurrencyTable() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = new EnumDoubleTable<>(AnimalEnum.class, AlphabetEnum.class);
        assertThat(table.size(), is(0));
        assertThat(table.isEmpty(), is(true));
        return table;
    }


    @Test
    public void testTable() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        assertThat(table.size(), is(1));
        assertThat(table.isEmpty(), is(false));
        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.A), is(1d));
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 2d);
        assertThat(table.size(), is(1));
        assertThat(table.isEmpty(), is(false));
        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.A), is(2d));
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 1.1);
        assertThat(table.size(), is(2));
        assertThat(table.isEmpty(), is(false));
        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.A), is(2d));
        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.B), is(1.1));
        table.clear();
        assertThat(table.size(), is(0));
        assertThat(table.isEmpty(), is(true));
    }

    @Test
    public void testRemoveIf() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        table.put(AnimalEnum.CAT, AlphabetEnum.C, 3d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.B, 5d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.C, 6d);

        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.A), is(1d));
        assertThat(table.size(), is(6));

        table.removeIf((rowKey, columnKey, value) -> {
            return value == 1d;
        });

        assertThat(Double.isNaN(table.get(AnimalEnum.CAT, AlphabetEnum.A)), is(true));
        assertThat(table.size(), is(5));

        table.removeIf((rowKey, columnKey, value) -> {
            return value == 1000d;
        });

        assertThat(table.size(), is(5));
    }

    @Test
    public void testForEach() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        table.put(AnimalEnum.CAT, AlphabetEnum.C, 3d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.B, 5d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.C, 6d);

        final AtomicInteger i = new AtomicInteger();
        table.forEach((rowKey, columnKey, v) -> {
            assertThat(table.get(rowKey, columnKey), is(v));
            i.incrementAndGet();
        });
        assertThat(i.get(), is(6));
    }

    @Test
    public void forEachColumnKey() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.DOG, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.MOUSE, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.C, 6d);


        final List<AlphabetEnum> list = Arrays.asList(AlphabetEnum.A, AlphabetEnum.B, AlphabetEnum.A, AlphabetEnum.C);
        final AtomicInteger i = new AtomicInteger(0);
        table.forEachColumnKey(k -> {
            if (i.get() == 0) {
                assertThat(k, is(AlphabetEnum.A));
            }
            if (i.get() == 1) {
                assertThat(k, is(AlphabetEnum.B));
            }
            if (i.get() == 2) {
                assertThat(k, is(AlphabetEnum.C));
            }
            i.incrementAndGet();
        });
        assertThat(i.get(), is(3));
    }

    @Test
    public void forEachRowKey() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.DOG, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.MOUSE, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.MOUSE, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 4d);

        final AtomicInteger i = new AtomicInteger(0);
        table.forEachRowKey(k -> {
            if (i.get() == 0) {
                assertThat(k, is(AnimalEnum.CAT));
            }
            if (i.get() == 1) {
                assertThat(k, is(AnimalEnum.DOG));
            }
            if (i.get() == 2) {
                assertThat(k, is(AnimalEnum.HIPPO));
            }
            if (i.get() == 3) {
                assertThat(k, is(AnimalEnum.MOUSE));
            }
            i.incrementAndGet();
        });
        assertThat(i.get(), is(4));
    }

    @Test
    public void testForEachValue() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        table.put(AnimalEnum.CAT, AlphabetEnum.C, 3d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.B, 5d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.C, 6d);

        Map<Double, Boolean> values = new HashMap<>();
        values.put(1d, false);
        values.put(2d, false);
        values.put(3d, false);
        values.put(4d, false);
        values.put(5d, false);
        values.put(6d, false);

        table.forEach((rowKey, columnKey, v) -> {
            assertThat(values.containsKey(v), is(true));
            values.put(v, true);
        });
        assertThat(values.values().contains(false), is(false));
    }

    @Test
    public void testContains() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        table.put(AnimalEnum.CAT, AlphabetEnum.C, 3d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.A, 4d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.B, 5d);
        table.put(AnimalEnum.HIPPO, AlphabetEnum.C, 6d);

        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.A), is(1d));
        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.B), is(2d));
        assertThat(table.get(AnimalEnum.CAT, AlphabetEnum.C), is(3d));
        assertThat(table.containsValue(1d), is(true));
        assertThat(table.containsValue(2d), is(true));
        assertThat(table.containsValue(3d), is(true));
        assertThat(table.containsValue(4d), is(true));
        assertThat(table.containsValue(5d), is(true));
        assertThat(table.containsValue(6d), is(true));
        assertThat(table.size(), is(6));

        assertThat(table.containsColumnKey(AnimalEnum.CAT), is(true));
        assertThat(table.containsColumnKey(AnimalEnum.HIPPO), is(true));

        assertThat(table.containsRowKey(AlphabetEnum.A), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.B), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.C), is(true));

        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.A), is(true));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.C), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.A), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.C), is(true));

        // remove 1
        table.remove(AnimalEnum.CAT, AlphabetEnum.A);
        assertThat(table.containsColumnKey(AnimalEnum.CAT), is(true));
        assertThat(table.containsColumnKey(AnimalEnum.HIPPO), is(true));

        assertThat(table.containsRowKey(AlphabetEnum.A), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.B), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.C), is(true));

        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.A), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.C), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.A), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.C), is(true));
        assertThat(table.containsValue(1d), is(false));
        assertThat(table.containsValue(2d), is(true));
        assertThat(table.containsValue(3d), is(true));
        assertThat(table.containsValue(4d), is(true));
        assertThat(table.containsValue(5d), is(true));
        assertThat(table.containsValue(6d), is(true));
        assertThat(table.size(), is(5));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.C), is(true));

        // remove 2
        table.remove(AnimalEnum.CAT, AlphabetEnum.B);
        assertThat(table.containsColumnKey(AnimalEnum.CAT), is(true));
        assertThat(table.containsColumnKey(AnimalEnum.HIPPO), is(true));

        assertThat(table.containsRowKey(AlphabetEnum.A), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.B), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.C), is(true));

        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.A), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.B), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.C), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.A), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.C), is(true));
        assertThat(table.containsValue(1d), is(false));
        assertThat(table.containsValue(2d), is(false));
        assertThat(table.containsValue(3d), is(true));
        assertThat(table.containsValue(4d), is(true));
        assertThat(table.containsValue(5d), is(true));
        assertThat(table.containsValue(6d), is(true));
        assertThat(table.size(), is(4));


        // remove 3
        table.remove(AnimalEnum.CAT, AlphabetEnum.C);
        assertThat(table.containsColumnKey(AnimalEnum.CAT), is(false));
        assertThat(table.containsColumnKey(AnimalEnum.HIPPO), is(true));

        assertThat(table.containsRowKey(AlphabetEnum.A), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.B), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.C), is(true));

        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.A), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.B), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.C), is(false));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.A), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.C), is(true));
        assertThat(table.containsValue(1d), is(false));
        assertThat(table.containsValue(2d), is(false));
        assertThat(table.containsValue(3d), is(false));
        assertThat(table.containsValue(4d), is(true));
        assertThat(table.containsValue(5d), is(true));
        assertThat(table.containsValue(6d), is(true));
        assertThat(table.size(), is(3));

        // remove 4
        table.remove(AnimalEnum.HIPPO, AlphabetEnum.C);
        assertThat(table.containsColumnKey(AnimalEnum.CAT), is(false));
        assertThat(table.containsColumnKey(AnimalEnum.HIPPO), is(true));

        assertThat(table.containsRowKey(AlphabetEnum.A), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.B), is(true));
        assertThat(table.containsRowKey(AlphabetEnum.C), is(false));

        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.A), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.B), is(false));
        assertThat(table.containsKey(AnimalEnum.CAT, AlphabetEnum.C), is(false));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.A), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.B), is(true));
        assertThat(table.containsKey(AnimalEnum.HIPPO, AlphabetEnum.C), is(false));
        assertThat(table.containsValue(1d), is(false));
        assertThat(table.containsValue(2d), is(false));
        assertThat(table.containsValue(3d), is(false));
        assertThat(table.containsValue(4d), is(true));
        assertThat(table.containsValue(5d), is(true));
        assertThat(table.containsValue(6d), is(false));
        assertThat(table.size(), is(2));
    }

    @Test
    public void testToString() {
        EnumDoubleTable<AnimalEnum, AlphabetEnum> table = getInstrumentCurrencyTable();
        table.put(AnimalEnum.CAT, AlphabetEnum.A, 1d);
        table.put(AnimalEnum.CAT, AlphabetEnum.B, 2d);
        assertThat(table.toString(), is("CAT/A=1.0,CAT/B=2.0"));
    }
}