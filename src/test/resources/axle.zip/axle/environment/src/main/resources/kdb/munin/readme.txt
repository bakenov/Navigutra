# Attention Unix Admin
# --------------------
# 1. please recreate the munin symlinks by running the following script as root:

create_munin_kdb_links.sh
