#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa019z "rm -rf ~/axle/datafabric/workspace/*"
ssh AxlSv@daxa003z "rm -rf ~/axle/datafabric/workspace/*"
ssh AxlSv@daxa036z "rm -rf ~/axle/datafabric/workspace/*"
