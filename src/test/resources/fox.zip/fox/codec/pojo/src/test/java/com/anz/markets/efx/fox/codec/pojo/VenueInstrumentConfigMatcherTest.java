package com.anz.markets.efx.fox.codec.pojo;

import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.pojo.matcher.VenueInstrumentConfigMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.api.Venue;
import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class VenueInstrumentConfigMatcherTest {
    private Predicate<VenueInstrumentConfig> predicate = Matchers.isA(VenueInstrumentConfig.class);
    private VenueInstrumentConfigMatcher matcher = new VenueInstrumentConfigMatcher() {
        @Override
        public Matcher<VenueInstrumentConfigMatcher, VenueInstrumentConfig.Body> body() {
            return matcher -> andThen(translate(venueInstrumentConfig -> venueInstrumentConfig.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof VenueInstrumentConfig && predicate.test((VenueInstrumentConfig) o);
        }

        private VenueInstrumentConfigMatcher andThen(final Predicate<? super VenueInstrumentConfig> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final VenueInstrumentConfig venueInstrumentConfig = SorMessage.venueInstrumentConfig(
                new MessageHeader(),
                new VenueInstrumentConfig.Body(Venue.FAST, 3456, 0.0005,
                        100000, 1000000, 5000000,
                        1000000, 1000000, 60,
                        10, 20, true));
        assertTrue(matcher.test(venueInstrumentConfig));
        assertNotNull(matcher.body());
    }
}
