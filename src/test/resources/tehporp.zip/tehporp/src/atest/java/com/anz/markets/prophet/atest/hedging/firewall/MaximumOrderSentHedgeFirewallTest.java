package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.SUSPICIOUS_DISCREPANCY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeTriggerType.AGR_AXL_TWAP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_ARBITRAGE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_RFX;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;

@RestartBeforeTest(reason = "Firewall keeps states and there is no normal operational mechanism to clear it. Therefore it needs to be restarted.")
@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_5})
public class MaximumOrderSentHedgeFirewallTest extends BaseAcceptanceSpecification {

    @Test
    public void shouldThrowExceptionWhenLimitIsNegative() {
        setup:
        {
            // prime system with valid config.
            prophet.receive(tdd.configuration_hedging_001());
        }
        when:
        // receives invalid config
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, -1, true)
            )));
        }
        then:
        {
            prophet.expect(IllegalArgumentException.class, matches(".*Maximum order sent must be more than zero.*"));
        }
    }

    @Test
    public void shouldTriggerWhenOverOrderLimit() {
        final NewOrder hedgingOrder1;
        final NewOrder hedgingOrder2;
        final NewOrder hedgingOrder3;

        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.95090, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95090));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));

            // trigger order sent
            prophet.receive(tdd.client_trade_001(AUDUSD, 10_000_000, 0.9510));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        // t1 hedger places order.
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // no change to firewall status
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // t1:30 fill order 1 and t31 hedger places order 2
        {
            prophet.incrementTime(29 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);

            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // firewall not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // t1:59 fill order 2 and t2:60 hedger places order 3
        {
            prophet.incrementTime(28 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2);
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // breached
        {
            HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
        }
        and:
        // hedger disabled
        {
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsPendingDisable(HEDGER_AGGRESSIVE, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldResetWhenHedgerTurnedOn() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setCancelUnknownTimeoutMS(10_000).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0).setOrderCompleteTimeoutMS(1_000),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.95090, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95090));
            prophet.receive(tdd.client_trade_001(AUDUSD, 20_000_000, 0.9510));
        }

        triggerFirewall();

        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1000);  // allow hedger to time time out due to order timeout
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.incrementTime(1_000); // increment time to cause a decision to be scheduled
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(MAXIMUM_ORDER_SENT_PER_MIN, NOT_BREACHED, HEDGER_AGGRESSIVE)).getLast();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
            prophet.notExpect(NewOrder.class);
        }

        triggerFirewall();
    }

    public void triggerFirewall() {
        final NewOrder hedgingOrder1;
        final NewOrder hedgingOrder2;
        final NewOrder hedgingOrder3;

        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        // t1 hedger places order.
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        when:
        // fill order 1 and hedger places order 2
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);

            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // firewall not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // fill order 2 hedger places order 3
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2);
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // breached
        {
            HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
        }
        and:
        // hedger disabled
        {
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsPendingDisable(HEDGER_AGGRESSIVE, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldMonitor1MinSlidingWindow() {
        final NewOrder hedgingOrder1;
        final NewOrder hedgingOrder2;

        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.95090, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95090));
        }
        when:
        // t1 hedger places order.
        {
            prophet.incrementTime(1 * 1_000);
            prophet.clearOutputBuffer();
            // trigger order sent
            prophet.receive(tdd.client_trade_001(AUDUSD, 10_000_000, 0.9510));
        }
        and:
        // t+2 after orderRateTimePeriod order placed
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // firewall not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // t2:30 fill order 1 and t2:31 hedger places order 2
        {
            prophet.incrementTime(28 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // firewall not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // t+61 fill order 2
        {
            prophet.incrementTime(30 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2);

        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t62 place order 3
        {
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            prophet.expect(NewOrder.class, exactly(1));
        }
        and:
        // NOT breached as first order send at t2 slides out
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
    }

    @Test
    public void shouldUnbreachWithSlidingWindow() {
        final NewOrder hedgingOrder1;
        final NewOrder hedgingOrder2;
        final NewOrder hedgingOrder3;


        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.95090, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95090));
        }
        when:
        // t+1 client trade received
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1_000);

            // trigger order sent
            prophet.receive(tdd.client_trade_001(AUDUSD, 10_000_000, 0.9510));
        }
        and:
        // t+2 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        // t+2 hedger places order.
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // firewall not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // t2:31 fill order 1 and t32 hedger places order 2
        {
            prophet.incrementTime(29 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // firewall not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE));
        }
        when:
        // t2:60 fill order 2 and t61 hedger places order 3
        {
            prophet.incrementTime(28 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2);
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.SELLING));

            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
        }
        and:
        // breached
        {
            HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
        }
        when:
        // t62 first sent order slides out of window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1_000);
        }
        then:
        {
            HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(MAXIMUM_ORDER_SENT_PER_MIN, HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
        }
    }

    private ConfigurationDataDefault setUpConfiguration() {

        double maxOrderSentPerMin = 2;

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setHedgeFirewallConfigs(asList(
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, maxOrderSentPerMin, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, SUSPICIOUS_DISCREPANCY, NaN, true)
                ))

                .setAggressiveTwapHedgerConfigs(Lists.newArrayList(
                        new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000)
                ));

        return configuration;
    }
}
