package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.OrderCancelRejectSbeDecoder;

public class ParentOrderCancelRejectEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParentOrderCancelRejectEvent.class);

    private final PrecisionClock precisionClock;
    private final ParentOrderRepository.WithInit parentOrderRepository;

    private final OrderCancelRejectSbeDecoder orderCancelRejectDecoder = new OrderCancelRejectSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    public ParentOrderCancelRejectEvent(final PrecisionClock precisionClock,
                                        final ParentOrderRepository.WithInit parentOrderRepository) {
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!orderCancelRejectDecoder.wrap(message)) return false;

        final String marketId = orderCancelRejectDecoder.body().marketId().decodeAndCache(marketIdCache);

        if (Venue.FOX.name().equals(marketId)) {
            logMessage();
            //do nothing yet
            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        orderCancelRejectDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying parent OCRJ: {}", stringBuilder);
    }
}
