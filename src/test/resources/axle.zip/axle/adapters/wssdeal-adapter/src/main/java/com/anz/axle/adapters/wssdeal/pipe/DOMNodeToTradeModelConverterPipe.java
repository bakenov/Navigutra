package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import anz.markets.messaging.pipes.intf.AbstractPipe;
import anz.markets.messaging.types.PDMessage;
import org.w3c.dom.Node;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.dom.DOMSource;

/**
 * Created by talwarg on 17/02/2015.
 */
public class DOMNodeToTradeModelConverterPipe extends AbstractPipe<Node,TradeMessageWrapperType> {

    private ThreadLocal<JAXBContext> jc = new ThreadLocal<JAXBContext>() {
        protected JAXBContext initialValue() {
            JAXBContext context;
            try {
                context = JAXBContext.newInstance(TradeMessageWrapperType.class);
            } catch (JAXBException e) {
                throw new RuntimeException(e);
            }
            return context;
        }
    };

    @Override
    public boolean onMessage(PDMessage<Node> domPDMessage) {
        try {
            final Unmarshaller unmarshaller = jc.get().createUnmarshaller();
            return getSink().onMessage(new PDMessage<TradeMessageWrapperType>(domPDMessage.getId(),
                    (TradeMessageWrapperType) JAXBIntrospector.getValue(unmarshaller.unmarshal(new DOMSource
                            (domPDMessage.getContent())))));
        } catch (JAXBException e) {
            throw new RuntimeException(e);
        }
    }
}
