package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.broker.domain.DomainEnums;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.datafabric.client.config.CurrencyPairService;
import com.anz.markets.adapters.trep.consumer.ItemNameProvider;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AllConfiguredPairsAndTenorsItemNameProvider implements ItemNameProvider {
    private static final Collection<Tenor> TENORS_FOR_NON_NDF_REQUESTS = EnumSet.complementOf(EnumSet.of(
            // Pointless
            Tenor.BROKEN,
            // Not used, and we dont want to publish it as WHOLESALE_SPOT
            Tenor.SPOT,
            // Calculated from OVERNIGHT
            Tenor.TODAY,
            // Calculated from TOM_NEXT
            Tenor.TOM
    ));

    private static final Collection<Tenor> TENORS_FOR_NDF_REQUESTS = EnumSet.complementOf(EnumSet.of(
            // Pointless
            Tenor.BROKEN,
            // Calculated from OVERNIGHT
            Tenor.TODAY,
            // Calculated from TOM_NEXT
            Tenor.TOM
    ));

    private final List<CurrencyPair> allAutoPricedSymbols;

    public AllConfiguredPairsAndTenorsItemNameProvider(final CurrencyPairService currencyPairService) {
        this.allAutoPricedSymbols = currencyPairService.findAllAutoPriced();
    }

    @Override
    public List<String> getItems() {
        final List<String> trepFwdRics = new ArrayList<String>();
        for (final CurrencyPair currencyPair : allAutoPricedSymbols) {
            final Set<String> trepSymbols = trepSymbolsFor(currencyPair.getSymbol());
            final Collection<Tenor> tenorsForSymbol = currencyPair.involves(DomainEnums.CurrencyType.N) ? TENORS_FOR_NDF_REQUESTS : TENORS_FOR_NON_NDF_REQUESTS;
            for (final String trepSymbol : trepSymbols) {
                for (final Tenor tenor : tenorsForSymbol) {
                    trepFwdRics.add(String.format("%s%s=D3", trepSymbol, trepTenorKey(tenor)));
                }
            }
        }
        Collections.sort(trepFwdRics);
        return trepFwdRics;
    }

    private String trepTenorKey(final Tenor tenor) {
        return tenor == Tenor.SPOT ? "" : tenor.getKey();
    }

    private Set<String> trepSymbolsFor(final String symbol) {
        final Set<String> symbols = new HashSet<String>(2);
        final String trepSymbol = symbol.replace("USD", "").replace("/", "");
        symbols.add(trepSymbol);
        symbols.add(trepSymbol.replace("SGD", "SG2"));
        return symbols;
    }
}
