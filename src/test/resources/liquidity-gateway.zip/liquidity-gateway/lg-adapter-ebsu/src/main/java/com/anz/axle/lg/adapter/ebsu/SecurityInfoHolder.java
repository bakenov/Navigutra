package com.anz.axle.lg.adapter.ebsu;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import org.jetbrains.annotations.NotNull;
import software.chronicle.ebs.instrument.VanillaInstrumentDictionary;
import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;

import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

public class SecurityInfoHolder {
    private final Function<RequestKey, PricingEncoderSupplier> pricingEncoderSupplierSupplier;
    private final SymbolConverter symbolConverter;
    private final SecurityInfo[] securityInfos;
    private final SecurityType securityType;
    private final Tenor tenor;
    private final Venue venue;

    public SecurityInfoHolder(@NotNull final Function<RequestKey, PricingEncoderSupplier> encoderSupplier,
                              @NotNull final Venue venue,
                              @NotNull final SecurityType securityType,
                              @NotNull final Map<String, String> ebsuSymbolLookup) {
        this.pricingEncoderSupplierSupplier = Objects.requireNonNull(encoderSupplier);
        this.securityInfos = new SecurityInfo[VanillaInstrumentDictionary.INSTRUMENTS];
        this.venue = Objects.requireNonNull(venue);
        this.securityType = Objects.requireNonNull(securityType);
        this.tenor = securityType == SecurityType.FXNDF ? Tenor.M1 : Tenor.SP;
        this.symbolConverter = new SymbolConverter(securityType, ebsuSymbolLookup);
    }

    public SecurityInfo get(final int locateCode, @NotNull final InstrumentDirectory securityDefinition) {
        final SecurityInfo securityInfo = securityInfos[locateCode];
        if (securityInfo != null) {
            return securityInfo;
        }
        return securityInfos[locateCode] = new SecurityInfo(securityDefinition);
    }

    public void forEachSecurity(@NotNull final Consumer<SecurityInfo> sender) {
        for (SecurityInfo securityInfo : securityInfos) {
            if (securityInfo != null) {
                sender.accept(securityInfo);
            }
        }
    }

    public class SecurityInfo {
        public final InstrumentKey instrumentKey;
        public final PricingEncoderSupplier pricingEncoderSupplier;

        SecurityInfo(@NotNull final InstrumentKey instrumentKey) {
            this.instrumentKey = instrumentKey;
            this.pricingEncoderSupplier = pricingEncoderSupplierSupplier.apply(RequestKey.of(venue, instrumentKey));
        }

        SecurityInfo(@NotNull final InstrumentDirectory securityDefinition) {
            this(InstrumentKey.of(symbolConverter.toSymbol6(securityDefinition), securityType, tenor));
        }
    }
}
