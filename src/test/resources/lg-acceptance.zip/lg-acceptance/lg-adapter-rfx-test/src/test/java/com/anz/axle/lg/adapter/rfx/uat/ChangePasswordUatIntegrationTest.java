package com.anz.axle.lg.adapter.rfx.uat;

import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.rfx.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.rfx.session.LogonManager;
import com.anz.markets.efx.ngaro.api.Venue;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;

public class ChangePasswordUatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChangePasswordUatIntegrationTest.class);

    @Rule
    public final TestName testName = new TestName();
    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private LogonManager logonManager;
    private UatConfiguration configuration;

    private Venue venue;
    private int maxNumberLogonAttempts = 1;
    private int timeInSecsBetweenLogonAttempts = 10;

    private CountDownLatch orderLatch;
    private CountDownLatch logoutLatch;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        venue = Venue.RFX;
        configuration = UatConfiguration.BURGUNDY_CHANGE_PASSWORD;

        final String path = "target/rfx";
        final String fixFilePath = path + "/log/";
        final String fixStorePath = path + "/store/";
        final String passwordFile = path + "/" + venue.name() + "-passwords.properties";
        System.out.println("PASSWORD_FILE=" + new File(passwordFile).getAbsolutePath());
        System.setProperty("rfx.fix.user.password.file", new File(passwordFile).getAbsolutePath());

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + venue.name().toLowerCase() +
                                ",venue:" + venue.name() +
                                ",appOptions:--reset" +
                                ",ConnectionType:initiator" +
                                "," + "rfx.fix.socket.use.ssl:N" +
                                "," + "rfx.fix.log.destination:STDOUT" +
                                "," + "rfx.fix.file.log.path:" + fixFilePath +
                                "," + "default.log.level:DEBUG" +
                                "," + "LOG_LEVEL:DEBUG" +
                                "," + "rfx.fix.file.store.path:" + fixStorePath +
                                "," + "rfx.fix.log_all:true" +
                                "," + "chronicle.fix.logging:true" +
                                "," + "rfx.fix.reconnectInterval:1" +
                                "," + "rfx.fix.maxNumLogonAttempts:" + maxNumberLogonAttempts +
                                "," + "rfx.fix.timeBetweenLogonAttemptsInSec:" + timeInSecsBetweenLogonAttempts +
                                "," + "rfx.fix.logon.appl.extid:" + 100 +
                                "," + "rfx.fix.logon.default.appl.extid:" + 100 +
                                "," + "rfx.fix.logon.default.appl.verid:9" +
                                "," + "messaging.source.id:" + 310
                ));

        configuration.updateSystemProperties();

        application = new Application("lg-rfx-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        logonManager = application.getApplicationContext().getBean("logonManager", LogonManager.class);
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void change_password() throws Exception {
        LOGGER.info("\\---------------- START {}", testName.getMethodName());
        orderLatch = new CountDownLatch(1);
//        logonManager.setTradingSessionStateConsumer(state -> {
//            LOGGER.info("login_send_cross_spread_order()     state={}", state);
//        });

        orderLatch.await(10, TimeUnit.SECONDS);
        LOGGER.info("closing Fix Session ...");
        logoutLatch = new CountDownLatch(1);
        logonManager.closeFixSession();
        logoutLatch.await(5, TimeUnit.SECONDS);

    }

}