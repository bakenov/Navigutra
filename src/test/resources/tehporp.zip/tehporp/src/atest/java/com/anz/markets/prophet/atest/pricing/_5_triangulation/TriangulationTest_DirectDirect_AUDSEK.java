package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Collections;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class TriangulationTest_DirectDirect_AUDSEK extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = {Ref.PRICING_4_6, Ref.PRICING_4_6_3})
    @DisplayName("Triangulation of cross pair from DIRECT-DIRECT driver pairs: AUDSEK via EUR")
    public void given_EURAUD_EURSEK_driver_pairs_triangulate_cross_pair() throws Exception {

        final Instrument driverPairA = Instrument.EURAUD;
        final Instrument driverPairB = Instrument.EURSEK;
        final Instrument crossPair = Instrument.AUDSEK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            // EUR/AUD is configured as a CROSS PAIR in tdd.configuration_pricing_base().
            // For this test we need to configure EUR/AUD as a DRIVER PAIR
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100)
                    ))
                    .setMarketConfigs(Lists.newArrayList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURAUD),
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURSEK)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.EURAUD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURSEK, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setStandardMarketSpreadConfigs(Lists.newArrayList(
                            // Driver Pairs
                            new StandardMarketSpreadConfigImpl(Instrument.EURAUD, 1.04E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                            new StandardMarketSpreadConfigImpl(Instrument.EURSEK, 0.00244, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.48146, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.481445, 1.481475));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.481430, 1.481490));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.481423, 1.481498));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.481410, 1.481510));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.481330, 1.481590));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.481270, 1.481650));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.481180, 1.481740));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.481140, 1.481780));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 1.481010, 1.481910));


        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 9.483, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(5));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 9.481000, 9.485000));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 9.480250, 9.485750));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 9.479250, 9.486750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 9.478000, 9.488000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 9.476000, 9.490000));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPrice.getBids().size(), is(6));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 6.39970299870, 6.4025326624));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 6.39926942663, 6.4029662823));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 6.39893546207, 6.4033003194));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 6.39795909053, 6.4042767871));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 6.39746411994, 6.4047720516));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 6.39583150534, 6.4064050549));

            assertThat(clientPrice.getUnskewedMid(), isRoundedTo((9.4830000/1.4814600)));
        }
    }

}
