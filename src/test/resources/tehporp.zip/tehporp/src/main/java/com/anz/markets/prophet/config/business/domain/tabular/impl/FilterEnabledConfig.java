package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.HasChanged;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

public class FilterEnabledConfig implements HasChanged<FilterEnabledConfig>, ProphetMarshallable {
    public MarketDataFilterType filtertype;
    public Instrument instrument;
    public Market market;
    public boolean enabled;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public FilterEnabledConfig() {
    }

    public FilterEnabledConfig(final String filtertype,
                               final Instrument instrument,
                               final Market market,
                               final boolean enabled) {
        this.filtertype = MarketDataFilterType.valueOf(filtertype);
        this.instrument = instrument;
        this.market = market;
        this.enabled = enabled;
    }

    @Override
    public boolean differs(final FilterEnabledConfig other) {
        GcFriendlyAssert.isTrue(this.filtertype.equals(other.filtertype) && this.instrument == other.instrument && this.market == other.market);
        return this.enabled != other.enabled;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        Context.context().header().before(MessageVersion.VERSION_0_65, () -> {
            filtertype = in.readEnum(MarketDataFilterType.class);
            instrument = in.readEnum(Instrument.class);
            market = in.readEnum(Market.class);
        });
        Context.context().header().since(MessageVersion.VERSION_0_65, () -> {
            filtertype = MarketDataFilterType.valueOf(in.readByte());
            instrument = Instrument.readMarshallableValueOf(in);
            market = Market.valueOf(in.readByte());
        });
        enabled = in.readBoolean();
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeByte(filtertype.getValue());
        out.writeShort(instrument.getValue());
        out.writeByte(market.getValue());
        out.writeBoolean(enabled);
    }

    @Override
    public String toString() {
        return "FilterEnabledConfig{" +
                "filtertype='" + filtertype + '\'' +
                ", instrument=" + instrument +
                ", market=" + market +
                ", enabled=" + enabled +
                '}';
    }
}
