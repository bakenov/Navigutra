package com.anz.markets.efx.fox.firewall.rule.customer;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.LongSupplier;

import com.anz.markets.efx.fox.firewall.api.CustomerRuleFactory;
import com.anz.markets.efx.fox.firewall.api.Rule;

public class CustomerRuleFactoryImpl implements CustomerRuleFactory {

    private final Map<CharSequence, Class<? extends Rule>> classByName;
    private final LongSupplier timeSupplier;

    public CustomerRuleFactoryImpl(LongSupplier timeSupplier) {
        this.timeSupplier = timeSupplier;
        classByName = new LinkedHashMap<>();
        for (CustomerRuleType type : CustomerRuleType.values()) {
            register(type);
        }
    }

    public boolean register(CustomerRuleType type) {
        return register(type.name(), type.getRuleClass());
    }

    public boolean register(CharSequence name, Class<? extends Rule> klass) {
        return classByName.putIfAbsent(name, klass) == klass;
    }

    @Override
    public Rule buildRule(CharSequence ruleClassName) {
        Class<? extends Rule> klass = classByName.get(ruleClassName);
        if (klass != null) {

        }
        return null;
    }

    @Override
    public Rule buildRule(CustomerRuleType type) {

        return null;
    }
}
