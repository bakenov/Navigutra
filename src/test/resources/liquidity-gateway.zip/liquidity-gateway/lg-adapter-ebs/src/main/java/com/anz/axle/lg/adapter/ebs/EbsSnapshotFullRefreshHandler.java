package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSide;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.MarketDataSnapshotFullRefresh_MDEntriesGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDEntryType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.QuoteCondition;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import net.openhft.chronicle.bytes.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import static com.anz.axle.lg.adapter.fix.Converter.nanToZero;

public class EbsSnapshotFullRefreshHandler implements ChronicleMessageHandler<MarketDataSnapshotFullRefresh> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsSnapshotFullRefreshHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final SourceSequencer sourceSequencer;

    public EbsSnapshotFullRefreshHandler(final VenueRequestKeyLookup requestKeyLookup,
                                         final PricingEncoderLookup pricingEncoderLookup,
                                         final PrecisionClock precisionClock,
                                         final SubscriptionManager subscriptionManager,
                                         final String senderCompId,
                                         final String compId,
                                         final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final MarketDataSnapshotFullRefresh message) throws IllegalArgumentException {
        accept(message, Long.MIN_VALUE);
    }

    @Override
    public void accept(final MarketDataSnapshotFullRefresh message, final long receivedByAdapterTimestampNanos) throws IllegalArgumentException {

        LOGGER.debug("MarketDataSnapshotFullRefresh received: {}", message);
        final long receivingTimeNanos = receivedByAdapterTimestampNanos <= 0 ? precisionClock.nanos() : receivedByAdapterTimestampNanos;

        final Bytes mdReqID = message.mDReqID();
        final int mdRequestId = (int) mdReqID.parseLong();
        final long entriesCount = message.noMDEntries();

        if (entriesCount > 0) {
            final long sequenceNumber = message.msgSeqNum();
            final long messageId = sequenceNumber;
            final long sendingTimeNanos = message.sendingTime();

            final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);
            if (subscription == null) {
                LOGGER.warn("No subscription found for requestId: {}. Discard : {}", mdRequestId, message);
                return;
            }

            final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());

            final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_Next = pricingEncoderLookup.lookup(requestKey).snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                    .possResend(false)
                    .marketId(requestKey.market())
                    .instrumentId(requestKey.instrumentKey().instrumentId())
                    .senderCompId().encode(compId)
                    .messageId(messageId)
                    .sendingTime(sendingTimeNanos)
                    .referenceSpotDate().encodeNull()
                    .tradeDate().encodeNull()
                    .settlDate().encodeFormatted(message.settlDate(), DATE_DECODER)
                    .entriesStart((int) entriesCount);

            final long groups = message.noMDEntries();
            for (int i = 0; i < groups; i++) {
                final MarketDataSnapshotFullRefresh_MDEntriesGrp_1 priceEntryGroup = message.marketDataSnapshotFullRefresh_MDEntriesGrp_1(i);

                final char mdEntryType = priceEntryGroup.mDEntryType();
                if (MDEntryType.BID != mdEntryType && mdEntryType != MDEntryType.OFFER) {
                    continue;
                }
                if (QuoteCondition.NO_DATA_AVAILABLE.equals(priceEntryGroup.quoteCondition())) {
                    continue;
                }
                if (QuoteCondition.NO_MARKET_ACTIVITY.equals(priceEntryGroup.quoteCondition())) {
                    continue;
                }
                final EntryType side = FixSide.from(mdEntryType);

                final double mdEntryPx = nanToZero(priceEntryGroup.mDEntryPx());
                final double mdEntrySize = nanToZero(priceEntryGroup.mDEntrySize());
                final double minQty = nanToZero(priceEntryGroup.minQty());

                final SnapshotFullRefreshEncoder.MdEntries.Body entryBody = mdEntries_Next.next();
                entryBody
                        .transactTime(sendingTimeNanos)
                        .mdMkt(requestKey.market())
                        .mdEntryType(side)
                        .mdEntrySize(mdEntrySize)
                        .minQty(minQty)
                        .mdEntryPx(mdEntryPx)
                        .mdEntryId(0)
                        .quoteEntryId(0);

            }

            mdEntries_Next.entriesComplete()
                    .hopsStart(2)
                    .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(sequenceNumber)
                    .hopSendingTime(sendingTimeNanos)
                    .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                    .messageComplete();
        }
    }
}
