package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.datamodel.DynamicFields;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixInstance;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.NewOrderSingle;
import software.chronicle.generated.code.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.TimeUnit;

import static software.chronicle.fix.cfg.ConnectionType.initiator;

/**
 * @author Rob Austin.
 */
public class PassthroughTest {

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(ClientMessageNotifier.class,
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    private void cleanup() {
        IOTools.deleteDirWithFiles("acceptor", 10);
        IOTools.deleteDirWithFiles("connector", 10);
    }

    public static void main( String[] args ) throws Exception {
        new PassthroughTest().sendTestExecutionReportTest();
    }

    public void sendTestExecutionReportTest() throws Exception {

        cleanup();

        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");
        final FixSessionCfg initiatorFixConfig = fixEngineCfg.fixSessionCfgs().stream().filter(cfg -> cfg.connectionType() == initiator).findFirst().get();

        final ClientMessageNotifier messageNotifier = (ClientMessageNotifier) initiatorFixConfig.messageNotifier();

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");

        try (final Closeable ignored = FixInstance.fixEngineMain(1, fixEngineCfg)) {

            try (final Closeable ignored1 = FixInstance.fixEngineMain(2, fixEngineCfg)) {

                String executionReport = messageNotifier.queue().poll(15, TimeUnit.SECONDS);

                String expected = "!software.chronicle.generated.code.messages.datamodel.DefaultExecutionReport {\n" +
                        "  senderCompID: SERVER,\n" +
                        "  targetCompID: CLIENT,\n" +
                        "  msgSeqNum: 2,\n" +
                        "  sendingTime: 0,\n" +
                        "  dynamicFields: !software.chronicle.fix.datamodel.BufferBackedDynamicFieldSupport {\n" +
                        "    c: !!binary ATEyMzQ9SGVsbG8BMTIzNT1Xb3JsZA==,\n" +
                        "    d: [ 1234, 1235, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ],\n" +
                        "    e: [ 11, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ],\n" +
                        "    f: 2\n" +
                        "  },\n" +
                        "  clOrdID: CL_ORD_ID,\n" +
                        "  side: \"1\",\n" +
                        "  avgPx: 12.0\n" +
                        "}\n";

                assert expected.equals(executionReport);

                System.out.println( executionReport );
            }
        }
    }
}

