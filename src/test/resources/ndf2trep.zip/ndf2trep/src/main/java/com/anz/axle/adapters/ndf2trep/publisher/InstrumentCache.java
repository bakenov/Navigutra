package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.EnumMap;
import java.util.Map;

import com.google.common.collect.Maps;

import com.anz.markets.efx.ngaro.api.SecurityType;

public class InstrumentCache {
    private final Map<SecurityType, Map<String, Map<String, String>>> keyCache = new EnumMap<>(SecurityType.class);

    public String lookup(final SecurityType securityType, final String market, final String symbol) {
        if (securityType == null || market == null || symbol == null) {
            return null;
        }

        Map<String, Map<String, String>> market2Symbol = keyCache.get(securityType);

        if (market2Symbol == null) {
            market2Symbol = Maps.newHashMap();
            keyCache.put(securityType, market2Symbol);
        }

        Map<String, String> symbol2Instrument = market2Symbol.get(market);
        if (symbol2Instrument == null) {
            symbol2Instrument = Maps.newHashMap();
            market2Symbol.put(market, symbol2Instrument);
        }

        String instrument = symbol2Instrument.get(symbol);
        if (instrument == null) {
            instrument = securityType.name() + "_" + market + "_" + symbol;
            symbol2Instrument.put(symbol, instrument);
        }
        return instrument;
    }
}