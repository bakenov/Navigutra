package com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceConfig;
import com.anz.axle.lg.adapter.bgc.chroniclefix.ServerConfig;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.stub.Source;
import com.anz.markets.efx.messaging.transport.stub.StubbedTransport;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingDecoders;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.base.PricingTranslator;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingDecoders;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

@Configuration
@Import({ServerConfig.class
})
public class PricingAcceptanceConfig extends SharedAcceptanceConfig {

    @Bean
    public LongIdFactory tradingMessageIdGenerator() {
        return () -> System.currentTimeMillis();
    }

    @Bean
    public Transport transport(final Queue<PricingMessage> pricingMessageQueue,
                               final Queue<TradingMessage> tradingResponseMessageQueue,
                               final Queue<TradingMessage> tradingRequestMessageQueue) {
        //Topic source stubs
        final Source pricingSource = pricingSource(pricingMessageQueue);

        return StubbedTransport.builder()
                .sinks(topic -> null)
                .sources(topic -> {
                    if (topic.name().startsWith("FX")) {
                        return pricingSource;
                    } else {
                        return null;
                    }
                }).build();
    }

    protected Source pricingSource(final Queue<PricingMessage> pricingMessageQueue) {
        final LongSupplier nanoTimeSource = () -> 0L;
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final PricingTranslator<PricingMessage> pojo2SbeTranslator = pricingPojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), nanoTimeSource.getAsLong())
        );
        return (topic, messageHandler) -> {
            final PricingMessage pojoPricingMessage = pricingMessageQueue.poll();
            if (pojoPricingMessage != null) {
                System.out.println("RECEIVED from: " + topic + " " + pojoPricingMessage);
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoPricingMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };
    }

    private PricingTranslator<PricingMessage> pricingPojo2SbeTranslator(final Consumer<? super SbeMessage> sbeMessageConsumer) {

        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);

        final PricingDecoders<PricingMessage> pojoPricingDecoders = new PojoPricingDecoders();

        final PricingEncoderSupplier sbeEncoderSupplier = new SbePricingEncoders(() -> sbeMessage).toPricingEncoderSupplier(sbeMessageConsumer);
        return PricingTranslator.create(pojoPricingDecoders.snapshotFullRefresh(), sbeEncoderSupplier);
    }
}