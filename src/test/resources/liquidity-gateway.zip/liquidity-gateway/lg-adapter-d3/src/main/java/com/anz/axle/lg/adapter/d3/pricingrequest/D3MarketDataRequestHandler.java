package com.anz.axle.lg.adapter.d3.pricingrequest;

import java.util.Objects;

import com.anz.axle.lg.adapter.d3.newsubscription.SubscriptionRegistry;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.pricing.codec.api.MarketDataRequestHandler;
import com.anz.markets.efx.pricing.codec.api.SubscriptionRequestType;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKeyLookup;

public final class D3MarketDataRequestHandler implements MarketDataRequestHandler {
    private final Venue venue;
    private final SecurityType securityType;
    private final SubscriptionRegistry subscriptionRegistry;
    private final RequestKeyLookup requestKeyLookup;

    public D3MarketDataRequestHandler(final Venue venue, final SubscriptionRegistry subscriptionRegistry, final SecurityType securityType, final RequestKeyLookup requestKeyLookup) {
        this.venue = Objects.requireNonNull(venue);
        this.subscriptionRegistry = Objects.requireNonNull(subscriptionRegistry);
        this.securityType = Objects.requireNonNull(securityType);
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        //no op
    }

    @Override
    public void onBody(final Body body) {
        if (body.subscriptionRequestType() != SubscriptionRequestType.SUBSCRIBE) {
            throw new UnsupportedOperationException("Unsupported subscriptionRequestType " + body.subscriptionRequestType());
        }
        final Venue market = body.marketId();
        if (venue != market) {
            throw new IllegalArgumentException("Market " + market + " is unsupported");
        }

        final RequestKey requestKey  = requestKeyLookup.lookup(venue, body.instrumentId());
        if (this.securityType != requestKey.instrumentKey().securityType()) {
            throw new IllegalArgumentException("SecurityType " + securityType + " is unsupported");
        }

        final long expireTime = body.expireTime();
        subscriptionRegistry.byVenueRequestKeyLookup().lookupOrCreate(requestKey).subscribe(expireTime <= 0 ? Long.MAX_VALUE : expireTime);
    }

    @Override
    public void onHopsStart(final int hopsCount) {
        //no op
    }

    @Override
    public void onHops_Body(final Hops.Handler.Body hop, final int hopsIndex, final int hopsCount) {
        //no op
    }

    @Override
    public void onMessageComplete() {
        //no op
    }
}
