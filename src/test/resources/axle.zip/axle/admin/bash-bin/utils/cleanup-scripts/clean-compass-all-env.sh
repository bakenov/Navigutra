#!/bin/bash
source ~/bin/shell-env/daxa009s/.functions

hostsOrange="daxa004z daxa029z"
hostsPink="daxa003z daxa015z daxa014z"
hostsYellow="aud4508s"
hostsBurgundy="daxa020z daxa002z"
hostsRed="daxa035z"

hosts="$hostsOrange $hostsPink $hostsYellow $hostsBurgundy $hostsRed"

echo "Cleaning Compass logs at `date`"

SCRIPTFILE=clean-compass-onebox.sh

for host in $hosts; do
  echo "> cleaning $host"
  scp $SCRIPTFILE AxlSv@$host:/tmp/$SCRIPTFILE
  ssh AxlSv@$host "sh /tmp/$SCRIPTFILE"
done
