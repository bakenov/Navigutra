package com.anz.markets.prophet.config.app;


import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.app.importable.SchedulingConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.positionrisk.PositionAdjustmentProducer;
import com.anz.markets.prophet.simulator.ClientTradeSimulatorImpl;
import com.anz.markets.prophet.simulator.MarketDataService;
import com.anz.markets.prophet.simulator.MarketDataSimulatorImpl;
import com.anz.markets.prophet.simulator.Simulator;
import com.anz.markets.prophet.simulator.TestMessageSimulatorImpl;
import com.anz.markets.prophet.simulator.regulator.FrequencyRegulator;
import com.anz.markets.prophet.simulator.regulator.FrequencyRegulatorFactory;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.ActivationAdjustmentProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.io.IOException;

@Configuration
@Import({BusinessConfig.class, SchedulingConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/simulator.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class SimulatorConfig extends JmxConfig {

    protected static final Logger LOGGER = LoggerFactory.getLogger(SimulatorConfig.class);

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.sim:-8}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    @Bean
    public ProphetPersister inboundChroniclePersister(
            @Value("${chronicle.in.path:./chronicle.in}") final String inChroniclePath) throws IOException {

        Context.instance((byte) 0);
        Context.stage(Stage.SIMULATED);

        return ChroniclePersisterFactory.createStarInPersister(inChroniclePath, LegacyChroniclePersister.OpenMode.APPEND);
    }

    @Bean
    public MarketDataService createMarketDataSimulator(
            @Value("${simulator.marketdata.isEnabled:false}") final boolean simulatorEnabledFlag,
            @Value("${simulator.marketdata.strategy:RANDOMWALK}") final String strategy,
            @Value("${simulator.marketdata.logProgress:true}") final boolean logProgress,
            @Value("${simulator.marketdata.messagesPerSecond:50}") final double messagesPerSecond,
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister,
            final ConfigurationDataDefault configurationDataDefault) throws InterruptedException {
        LOGGER.info("simulator.marketdata.isEnabled={} strategy={}", simulatorEnabledFlag, strategy);
        MarketDataSimulatorImpl.SimulationStrategy simulationStrategy = MarketDataSimulatorImpl.SimulationStrategy.valueOf(strategy);
        final FrequencyRegulator frequencyRegulator = FrequencyRegulatorFactory.createRegulatorSustained(messagesPerSecond);
        final MarketDataService marketDataService = new MarketDataSimulatorImpl(
                simulatorEnabledFlag, simulationStrategy, logProgress, frequencyRegulator,
                prophetPersister.sinkMarketData(), prophetPersister.sink(MessageType.TIMEZONE_CHIME),
                prophetPersister.sink(MessageType.SPOT_DATE), configurationDataDefault);
        if (simulatorEnabledFlag) {
            marketDataService.start();
        }
        return marketDataService;
    }

    @Bean
    public Simulator createTradeSimulator(
            @Value("${simulator.trade.isEnabled:false}") final boolean simulatorEnabledFlag,
            @Value("${simulator.trade.logProgress:true}") final boolean logProgress,
            @Value("${simulator.trade.messagesPerSecond:0.5}") final double messagesPerSecond,
            MarketDataService marketDataService,
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister) throws InterruptedException {
        // TODO: Configurable choice of regulator
        LOGGER.info("simulator.trade.isEnabled={}", simulatorEnabledFlag);
        final FrequencyRegulator frequencyRegulator = FrequencyRegulatorFactory.createRegulatorModulating(messagesPerSecond);
        final Simulator simulator = new ClientTradeSimulatorImpl(marketDataService, simulatorEnabledFlag, logProgress, frequencyRegulator, prophetPersister.sink(MessageType.TRADE));
        if (simulatorEnabledFlag) {
            simulator.start();
        }
        return simulator;
    }

    @Bean
    public Simulator createTestMessageSimulator(
            @Value("${simulator.testmessage.isEnabled:false}") final boolean enabled,
            @Value("${simulator.testmessage.payloadSizeBytes:128}") final int payloadSize,
            @Value("${simulator.testmessage.messagesPerSecond:1000}") final double messagesPerSecond,
            @Value("${simulator.testmessage.logEvery:10000}") final int logEvery,
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister) throws InterruptedException {
        LOGGER.info("simulator.testmessage.isEnabled={}", enabled);
        if (enabled) {
            LOGGER.info("simulator.testmessage.payloadSizeBytes={}", payloadSize);
            LOGGER.info("simulator.testmessage.messagesPerSecond={}", messagesPerSecond);
            LOGGER.info("simulator.testmessage.logEvery={}", logEvery);
        }
        final FrequencyRegulator frequencyRegulator = FrequencyRegulatorFactory.createRegulatorSustained(messagesPerSecond);
        final Simulator simulator = new TestMessageSimulatorImpl(enabled, frequencyRegulator, prophetPersister, payloadSize, (int) messagesPerSecond, logEvery);
        if (enabled) {
            simulator.start();
        }
        return simulator;
    }

    @Bean
    public PositionAdjustmentProducer createPositionAdjustmentProducer(
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister) {
        return new PositionAdjustmentProducer(prophetPersister.sink(MessageType.ADJUSTMENT), prophetPersister.sink(MessageType.TRADE));
    }

    @Bean
    public ActivationAdjustmentProducer createActivationAdjustmentProducer(
            @Qualifier("inboundChroniclePersister") final ProphetPersister prophetPersister) {
        return new ActivationAdjustmentProducer(prophetPersister.sink(MessageType.ACTIVATE));
    }
}
