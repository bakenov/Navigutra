package com.anz.axle.lg.adapter.hsp.chronicle;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.agrona.concurrent.IdleStrategy;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import software.chronicle.fix.staticcode.SessionID;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.AsyncApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.config.CommonConfig;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.hsp.chroniclefix.FixConfig;
import com.anz.axle.lg.adapter.hsp.chronicleitch.ItchConfig;
import com.anz.axle.servicelifecycle.Service;
import com.anz.lg.messaging.event.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.queue.Queue;


@Configuration
@Import({
        FixConfig.class,
        ItchConfig.class
})
public class HspConfig {

    @Bean
    public EventLoop chronicleEventLoop() {
        EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false);
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter itchPricingEventLoopStep(final EventLoop chronicleEventLoop) {
        return new EventLoopAdapter(chronicleEventLoop);
    }

    @Bean
    public EventLoopAdapter fixTradingEventLoopStep(final EventLoop chronicleEventLoop) {
        return new EventLoopAdapter(chronicleEventLoop);
    }


    @Bean
    public ApplicationLogonHandler applicationLogonHandler(final @Qualifier("marketDataSubscriber") Supplier<LogonHandler> pricingSessionLogonHandlerSupplier,
                                                           final SessionID tradingSessionId,
                                                           final @Qualifier("tradingSessionState") Supplier<LogonHandler> tradingSessionLogonHandlerSupplier,
                                                           final Queue<Runnable> mainEventLoopQueue) {

        return new AsyncApplicationLogonHandler(mainEventLoopQueue, sessionID -> {
            if (sessionID.localCompID().equals(tradingSessionId.localCompID()) && sessionID.remoteCompID().equals(tradingSessionId.remoteCompID())) {
                return tradingSessionLogonHandlerSupplier.get();
            } else {
                return pricingSessionLogonHandlerSupplier.get();
            }
        });
    }

    @Bean
    public Service mainEventLoop(final EventLoopStep itchPricingEventLoopStep,
                                 final EventLoopStep fixTradingEventLoopStep,
                                 final @Qualifier("backPressureStrategyEventLoopStep") EventLoopStep backPressureStrategyEventLoopStep,
                                 final EventLoopStep mainLoopMonitoringStep,
                                 final Queue<Runnable> mainEventLoopQueue,
                                 final Connection connection,
                                 final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor,
                                 final IdleStrategy idleStrategy) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return new EventLoopService(
                CommonConfig.MAIN_EVENT_LOOP_NAME,
                10, TimeUnit.SECONDS, idleStrategy,
                itchPricingEventLoopStep,
                fixTradingEventLoopStep,
                backPressureStrategyEventLoopStep,
                EventLoopStep.whenFinalisationRequired(() -> mainEventLoopQueue.poller().processNext(runnableProcessor)),
                EventLoopStep.whenFinalisationNotRequired(() -> connection.pollingStrategy().processNext()),
                mainLoopMonitoringStep);
    }
}
