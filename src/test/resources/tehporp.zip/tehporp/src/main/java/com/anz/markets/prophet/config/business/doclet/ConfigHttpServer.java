package com.anz.markets.prophet.config.business.doclet;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URL;

/**
 * Basic http server to serve up config htmls.
 */
public class ConfigHttpServer implements HttpHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigHttpServer.class);
    private static final String DOC_ROOT = "/configdoclet", OTHER_HTML_ROOT = "/otherhtml";
    private static final String DEFAULT_FILE = "/index.html";
    private final int port;


    public ConfigHttpServer(final int port) {
        this.port = port;
    }

    public void start() throws IOException {
        final HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", this);
        server.start();
        LOGGER.info("Started http config doc server at http://localhost:{}", server.getAddress().getPort());
    }

    public void handle(final HttpExchange t) throws IOException {
        final URI uri = t.getRequestURI();
        String path;
        if (uri.getPath().equals("/")) {
            path = DOC_ROOT + DEFAULT_FILE;
        } else if (uri.getPath().startsWith(OTHER_HTML_ROOT)) {
            path = uri.getPath();
        } else {
            path = DOC_ROOT + uri;
        }
        final URL url = this.getClass().getResource(path);
        if (uri.getPath().contains("../")) {
            LOGGER.warn("Suspected path traversal attack, reject with 403 error. Requested uri: ", uri);
            final String response = "403 (Forbidden)\n";
            t.sendResponseHeaders(403, response.length());
            final OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        } else if (url == null) {
            LOGGER.warn("Resource does not exists, reject with 404 error. Requested uri: ", uri);
            final String response = "404 (Not Found)\n";
            t.sendResponseHeaders(404, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        } else {
            // Object exists and is a file: accept with response code 200.
            t.sendResponseHeaders(200, 0);
            final OutputStream os = t.getResponseBody();
            final InputStream is = url.openStream();
            final byte[] buffer = new byte[0x10000];
            int count;
            while ((count = is.read(buffer)) >= 0) {
                os.write(buffer, 0, count);
            }
            is.close();
            os.close();
        }
    }

}
