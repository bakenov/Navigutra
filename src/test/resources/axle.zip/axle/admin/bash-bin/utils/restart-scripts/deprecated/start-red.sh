#!/bin/bash

ssh axle@daxa003z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'
ssh AxlSv@daxa020z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'

ssh axle@daxa007z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'
ssh AxlSv@daxa017z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'

