package com.anz.axle.lg.adapter.d3;

import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.StreamingService;

/**
 * Ensure that the provided {@link #streamingService} is running.
 */
public final class StreamingServiceHealthChecker {
    private static final Logger LOGGER = LoggerFactory.getLogger(StreamingServiceHealthChecker.class);

    private final ScheduledExecutorService healthCheckExecutorService;
    private final ExecutorService streamingExecutorService;
    private final StreamingService streamingService;
    private final long initialDelay;
    private final long healthCheckInterval;
    private final TimeUnit schedulerTimeUnit;
    private Future streamingServiceFuture;

    private volatile boolean isRunning;

    /**
     * @param healthCheckExecutorService scheduled executor used for scheduling heart beat check
     * @param streamingExecutorService   executor used for running the {@link #streamingService}
     * @param streamingService           actual streaming service
     * @param initialDelay               initial delay for the heart beat check
     * @param healthCheckInterval        interval for running the heart beat check
     * @param schedulerTimeUnit          time unit for both {@link #initialDelay} and {@link #healthCheckInterval}
     */
    public StreamingServiceHealthChecker(final ScheduledExecutorService healthCheckExecutorService,
                                         final ExecutorService streamingExecutorService,
                                         final StreamingService streamingService,
                                         final long initialDelay,
                                         final long healthCheckInterval,
                                         final TimeUnit schedulerTimeUnit) {
        this.healthCheckExecutorService = Objects.requireNonNull(healthCheckExecutorService);
        this.streamingExecutorService = Objects.requireNonNull(streamingExecutorService);
        this.streamingService = Objects.requireNonNull(streamingService);
        this.initialDelay = initialDelay;
        this.healthCheckInterval = healthCheckInterval;
        this.schedulerTimeUnit = Objects.requireNonNull(schedulerTimeUnit);
    }

    public void start() {
        // Do initial 'kick off' of the StreamingService
        LOGGER.info("Starting StreamingService");
        restartStreamingService();

        // Regularly check if the StreamingService has stopped. If so, start it again.
        LOGGER.info("Starting {}", getClass().getName());
        healthCheckExecutorService.scheduleAtFixedRate(this::checkHealth, initialDelay, healthCheckInterval, schedulerTimeUnit);

        isRunning = true;
    }

    private void checkHealth() {
        LOGGER.debug("Checking StreamingService health.");
        if (streamingServiceFuture.isDone() || streamingServiceFuture.isCancelled()) {
            LOGGER.info("Restarting StreamingService");
            restartStreamingService();
        }
    }

    public void stop() {
        LOGGER.info("Stopping {}", getClass().getName());
        LOGGER.info("Stopping StreamingService");
        streamingExecutorService.shutdown();
        streamingService.stop();

        isRunning = false;
    }

    private void restartStreamingService() {
        streamingServiceFuture = streamingExecutorService.submit(streamingService);
    }

    public boolean isRunning() {
        return isRunning;
    }
}
