package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import com.anz.markets.efx.ngaro.time.LocalDateEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

/**
 * Encoder for date only without time encoded into a fixed length string formatted for instance as YYYYMMDD.
 * <p/>
 * This class thread safe. NOTE however that the {@code target} and {@link ByteWriter} passed to the constructor may not
 * be thread safe and hence the resulting encoder instance may also not be thread safe.
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 * @param <T> the target type
 */
public final class FormattedDateEncoder<E,T> implements DateEncoder<E> {

    private final E enclosingEncoder;
    private final T target;
    private final ByteWriter<? super T> writer;
    private final LocalDateEncoder localDateEncoder;

    public FormattedDateEncoder(final E enclosingEncoder, final T target, final ByteWriter<? super T> writer, final LocalDateFormat localDateFormat) {
        this(enclosingEncoder, target, writer, localDateFormat.getDefaultEncoder());
    }
    public FormattedDateEncoder(final E enclosingEncoder, final T target, final ByteWriter<? super T> writer, final LocalDateEncoder localDateEncoder) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.target = Objects.requireNonNull(target);
        this.writer = Objects.requireNonNull(writer);
        this.localDateEncoder = Objects.requireNonNull(localDateEncoder);
    }

    public static <E> FormattedDateEncoder<E, MutableAsciiString> forAsciiString(final E enclosingEncoder,
                                                                                 final LocalDateFormat localDateFormat) {
        return forAsciiString(enclosingEncoder, new FixedLengthAsciiString(localDateFormat.getLength()), localDateFormat);
    }

    public static <E> FormattedDateEncoder<E, MutableAsciiString> forAsciiString(final E enclosingEncoder,
                                                                                 final MutableAsciiString asciiString,
                                                                                 final LocalDateFormat localDateFormat) {
        return forTargetAndFormat(enclosingEncoder, asciiString, ByteWriter.MUTABLE_ASCII_STRING, localDateFormat);
    }

    public static <E, T> FormattedDateEncoder<E, T> forTargetAndFormat(final E enclosingEncoder,
                                                                       final T target,
                                                                       final ByteWriter<? super T> writer,
                                                                       final LocalDateFormat localDateFormat) {
        return new FormattedDateEncoder<>(enclosingEncoder, target, writer, localDateFormat);
    }

    public static <E, T> FormattedDateEncoder<E, T> forTargetAndEncoder(final E enclosingEncoder,
                                                                        final T target,
                                                                        final ByteWriter<? super T> writer,
                                                                        final LocalDateEncoder localDateEncoder) {
        return new FormattedDateEncoder<>(enclosingEncoder, target, writer, localDateEncoder);
    }

    public T target() {
        return target;
    }

    @Override
    public E encodeNullable(final LocalDate localDate) {
        localDateEncoder.encodeNullable(target, writer, localDate);
        return enclosingEncoder;
    }

    @Override
    public E encode(final int year, final int month, final int day) {
        localDateEncoder.encode(target, writer, year, month, day);
        return enclosingEncoder;
    }

    @Override
    public E encodeEpochMillis(final long epochMillis) {
        localDateEncoder.encodeEpochMillis(target, writer, epochMillis);
        return enclosingEncoder;
    }

    @Override
    public E encodeEpochSeconds(final long epochSeconds) {
        localDateEncoder.encodeEpochSeconds(target, writer, epochSeconds);
        return enclosingEncoder;
    }

    @Override
    public E encodeEpochDays(final long epochDays) {
        localDateEncoder.encodeEpochDays(target, writer, epochDays);
        return enclosingEncoder;
    }

    @Override
    public E encodeNull() {
        localDateEncoder.encodeNull(target, writer);
        return enclosingEncoder;
    }

}