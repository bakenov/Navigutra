package com.anz.markets.prophet.pricer.inverse;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InverseRateManagerBWTest extends AbstractInverseRateManagerForBwJmhTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(InverseRateManagerBWTest.class);

    private static final int REPS = 100_000;
    private static final int THRESHOLD = 200;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    @Test
    public void processClientPrice() {
        helper.testAllocationNotExceeded(
                this::calculateForInversePairs,
                REPS, REPS,
                THRESHOLD
        );
    }
}
