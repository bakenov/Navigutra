package com.anz.axle.lg.adapter.d3.pricingrequest;

import java.util.Objects;
import java.util.function.LongConsumer;

import org.agrona.DirectBuffer;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;

public final class PricingRequestMessageHandler implements MessageHandler {

    private final MessageDecoder<SbeMessage> messageDecoder;
    private final LongConsumer receivedTimeNanosConsumer;
    private final SbeMessageForReading sbeMessage;

    public PricingRequestMessageHandler(
            final LongConsumer receivedTimeNanosConsumer,
            final MessageDecoder<SbeMessage> messageDecoder) {

        this.receivedTimeNanosConsumer = Objects.requireNonNull(receivedTimeNanosConsumer);
        this.messageDecoder = Objects.requireNonNull(messageDecoder);
        this.sbeMessage = new SbeMessageForReading();
    }

    @Override
    public void onMessage(final Topic topic, final DirectBuffer buffer, final int offset, final int length, final long receiveTimeNanosSinceEpoch) {
        receivedTimeNanosConsumer.accept(receiveTimeNanosSinceEpoch);
        try {
            messageDecoder.decode(sbeMessage.wrap(buffer, offset, length));
        } finally {
            sbeMessage.unwrap();
            resetReceiveTime();
        }
    }

    private void resetReceiveTime() {
        receivedTimeNanosConsumer.accept(0);
    }
}
