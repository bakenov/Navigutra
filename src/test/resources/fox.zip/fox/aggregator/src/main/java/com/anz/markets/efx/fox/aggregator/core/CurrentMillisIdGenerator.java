package com.anz.markets.efx.fox.aggregator.core;

import java.util.function.LongSupplier;

public class CurrentMillisIdGenerator implements LongSupplier {
    private long seed = System.currentTimeMillis() * 100;

    @Override
    public long getAsLong() {
        return ++seed;
    }
}
