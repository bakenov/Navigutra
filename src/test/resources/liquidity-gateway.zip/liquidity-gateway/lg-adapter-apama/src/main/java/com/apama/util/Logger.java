package com.apama.util;


import org.slf4j.LoggerFactory;

/**
 * This class adapts apama logger to slf4j logger. It is supposed to take precedence at class loading and
 * replace original apama {@link com.apama.util.Logger} class.
 */
public enum Logger {
    INSTANCE;

    private static final org.slf4j.Logger DELEGATE = LoggerFactory.getLogger(Logger.class);

    static {
        DELEGATE.info("USING CUSTOM APAMA LOGGER");
    }

    public static Logger getLogger() {
        return INSTANCE;
    }

    public static Logger getLogger(final String name) {
        return INSTANCE;
    }

    public static Logger getLogger(final Class clazz) {
        return getLogger(clazz.getName());
    }

    public static void shutdown() {
        return;
    }

    public void setThreshold(final String levelStr) {
        return;
    }

    public boolean debugEnabled() {
        return DELEGATE.isDebugEnabled();
    }

    public boolean infoEnabled() {
        return DELEGATE.isInfoEnabled();
    }

    public boolean warnEnabled() {
        return DELEGATE.isWarnEnabled();
    }

    public boolean errorEnabled() {
        return DELEGATE.isErrorEnabled();
    }

    public boolean fatalEnabled() {
        return DELEGATE.isErrorEnabled();
    }

    public boolean critEnabled() {
        return DELEGATE.isErrorEnabled();
    }

    public boolean forceEnabled() {
        return true;
    }

    public void debug(final String msg) {
        DELEGATE.debug(msg);
    }

    public void debug(final String msg, final Throwable ex) {
        DELEGATE.debug(msg, ex);
    }

    public void info(final String msg) {
        DELEGATE.info(msg);
    }

    public void info(final String msg, final Throwable ex) {
        DELEGATE.info(msg, ex);
    }

    public void warn(final String msg) {
        DELEGATE.warn(msg);
    }

    public synchronized void warn(final String msg, final Throwable ex) {
        DELEGATE.warn(msg, ex);
    }

    public void warnWithDebugStackTrace(final String msg, final Throwable ex) {
        if (DELEGATE.isWarnEnabled()) {
            DELEGATE.warn(msg.concat(ExceptionUtil.getMessageFromException(ex)));
            DELEGATE.debug(msg, ex);
        }
    }

    public synchronized void error(final String msg) {
        DELEGATE.error(msg);
    }

    public synchronized void error(final String msg, final Throwable ex) {
        DELEGATE.error(msg, ex);
    }

    public synchronized void errorWithDebugStackTrace(final String msg, final Throwable ex) {
        if (DELEGATE.isErrorEnabled()) {
            DELEGATE.error(msg.concat(ExceptionUtil.getMessageFromException(ex)));
            DELEGATE.debug(msg, ex);
        }
    }

    public synchronized void fatal(final String msg) {
        DELEGATE.error(msg);
    }

    public synchronized void fatal(final String msg, final Throwable ex) {
        DELEGATE.error(msg, ex);
    }

    public synchronized void crit(final String msg) {
        DELEGATE.error(msg);
    }

    public synchronized void crit(final String msg, final Throwable ex) {
        DELEGATE.error(msg, ex);
    }

    public synchronized void force(final String msg) {
        DELEGATE.error(msg);
    }

    public synchronized void force(final String msg, final Throwable ex) {
        DELEGATE.error(msg, ex);
    }

    public static final String VERSION_COMMENT = "Apama Platform Version: releases/5.2.0.x@234269";
    public static final String LOG_IMPL_PROPERTY_NAME = "APAMA_LOG_IMPL";
    public static final String LOG_LEVEL_PROPERTY_NAME = "APAMA_LOG_LEVEL";
    public static final String LOG_FILENAME_PROPERTY_NAME = "APAMA_LOG_FILE";
    public static final String LOG_STACK_TRACE_INTERVAL_PROPERTY_NAME = "APAMA_LOG_STACK_TRACE_INTERVAL";
    public static final String LOG_STACK_TRACE_FILENAME_PROPERTY_NAME = "APAMA_LOG_STACK_TRACE_FILENAME";
    public static final String ALL_STR = "ALL";
    public static final String CRIT_STR = "CRIT";
    public static final String DEBUG_STR = "DEBUG";
    public static final String INFO_STR = "INFO";
    public static final String WARN_STR = "WARN";
    public static final String ERROR_STR = "ERROR";
    public static final String FATAL_STR = "FATAL";
    public static final String FORCE_STR = "#####";
    public static final String OFF_STR = "OFF";
    public static final String DEFAULT_LOG_LEVEL = "WARN";
    public static final String LOG_IMPL_LOG4J = "log4j";
    public static final String LOG_IMPL_SIMPLE = "simple";
    public static final String DEFAULT_LOG_IMPL = "log4j";
    public static final String DEFAULT_LOG_FILENAME = null;
    public static final String LOG_THREADNAME_PROPERTY_NAME = "APAMA_LOG_THREAD";
    public static final String LOG_TIME_PROPERTY_NAME = "APAMA_LOG_TIME";
    public static final String LOG_RELATIVE_TIME_PROPERTY_NAME = "APAMA_LOG_RELATIVE_TIME";
    public static final String LOG_INCREMENTAL_TIME_PROPERTY_NAME = "APAMA_LOG_INCREMENTAL_TIME";
    public static final String DEFAULT_LOG_THREADNAME = "false";
    public static final String DEFAULT_LOG_TIME = "false";
    public static final String DEFAULT_LOG_RELATIVE_TIME = "false";
    public static final String DEFAULT_LOG_INCREMENTAL_TIME = "false";
}