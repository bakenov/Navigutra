#!/bin/bash

title="Available tests"
prompt="Select test:"
options=("fixFormat" "yamlFormat" "external")

PS3=$'\n'"$prompt "
COLUMNS=24

while true; do
    printf "\n$title\n"
    select opt in "${options[@]}" "Quit"; do

        case "$REPLY" in

        1 ) mvn exec:java -Dtest=$opt; break;;
        2 ) mvn exec:java -Dtest=$opt; break;;
        3 ) mvn exec:java -Dtest=$opt; break;;

        $(( ${#options[@]}+1 )) ) echo "Quit"; exit;;
        *) echo "Invalid option";continue;;

        esac

    done
done

