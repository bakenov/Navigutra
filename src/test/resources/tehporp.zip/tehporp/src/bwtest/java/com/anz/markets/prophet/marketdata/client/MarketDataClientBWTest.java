package com.anz.markets.prophet.marketdata.client;

import org.junit.Ignore;
import org.junit.Test;


public class MarketDataClientBWTest {


    @Ignore
    @Test
    public void isConnected() throws Exception {

    }
}