package com.anz.axle.lg.adapter.bgc;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamDecoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface SnapshotterDecoderSupplier {
    UpstreamDecoderConnector upstreamDecoderConnector();

    static Function<RequestKey, SnapshotterDecoderSupplier> create(final Function<RequestKey, SnapshotterBuilder> snapshotterBuilderFactory,
                                                                   final UpdateTypeMismatchHandler updateTypeMismatchHandler) {
        return (RequestKey requestKey) -> {
            final SnapshotterBuilder builder = snapshotterBuilderFactory.apply(requestKey);
            final UpstreamDecoderConnector upstreamDecoderConnector = builder.buildUpstreamDecoderConnector(updateTypeMismatchHandler);
            return (SnapshotterDecoderSupplier) () -> upstreamDecoderConnector;
        };
    }

    static Function<RequestKey, SnapshotterBuilder> createBuilder(final int initialBookEntries,
                                                                  final SnapshotFullRefreshHandler forwardTopOfBookSnapshotFullRefreshHandler,
                                                                  final PrecisionClock precisionClock,
                                                                  final long stalePriceTimestampOffsetMilliseconds) {
        Objects.requireNonNull(forwardTopOfBookSnapshotFullRefreshHandler);
        Objects.requireNonNull(precisionClock);

        return requestKey ->
             SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, initialBookEntries, DefaultMarketDataEntry::new, MarketDataEntries.Factory.SIDE_PRICE))
                    .withDownstreamDecoder()
                    .forwardTopOfBookToDecoder(forwardTopOfBookSnapshotFullRefreshHandler)
                    .withTopOfBookFilter(marketDataEntry -> {
                        final long stalePriceThresholdTimeTimeNanos = precisionClock.nanos() - TimeUnit.MILLISECONDS.toNanos(stalePriceTimestampOffsetMilliseconds);
                        return marketDataEntry.transactTimeNanos() >= stalePriceThresholdTimeTimeNanos;
                    });
    }
}
