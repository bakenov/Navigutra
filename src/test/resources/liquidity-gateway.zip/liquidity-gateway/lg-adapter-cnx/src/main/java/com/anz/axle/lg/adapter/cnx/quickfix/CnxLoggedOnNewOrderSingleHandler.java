package com.anz.axle.lg.adapter.cnx.quickfix;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import quickfix.Message;
import quickfix.field.ClOrdID;
import quickfix.field.ClientID;
import quickfix.field.Currency;
import quickfix.field.HandlInst;
import quickfix.field.MsgType;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.Price;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix44.NewOrderSingle;

import com.anz.axle.lg.adapter.cnx.HealthCheckFailActionState;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public final class CnxLoggedOnNewOrderSingleHandler implements NewOrderSingleHandler {
    private static final boolean INCLUDE_MILLISECONDS = false;
    private final Consumer<Message> fixMessageSender;
    private final HealthCheckFailActionState healthCheckFailActionState;
    private final NewOrderSingle newOrderSingle = new NewOrderSingle();
    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final Date transactTime = new Date();

    public CnxLoggedOnNewOrderSingleHandler(final Consumer<Message> fixMessageSender, final HealthCheckFailActionState healthCheckFailActionState) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.healthCheckFailActionState = Objects.requireNonNull(healthCheckFailActionState);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.clear();
    }

    @Override
    public void onBody(final Body body) {
        newOrderSingle.getHeader().setString(MsgType.FIELD, MsgType.ORDER_SINGLE);
        newOrderSingle.setString(ClOrdID.FIELD, body.clOrdId().decodeStringOrNull());
        newOrderSingle.setString(Symbol.FIELD, body.symbol().decodeAndCache(symbol7Cache));
        newOrderSingle.setChar(HandlInst.FIELD, HandlInst.AUTOMATED_EXECUTION_ORDER_PRIVATE);
        newOrderSingle.setChar(quickfix.field.Side.FIELD, side(body.side()));
        newOrderSingle.setDouble(OrderQty.FIELD, body.orderQty());
        newOrderSingle.setString(Currency.FIELD, currency(body));
        newOrderSingle.setChar(OrdType.FIELD, orderType(body.ordType()));
        if (body.price() != 0.0 && body.price() != Double.NaN) {
            newOrderSingle.setDouble(Price.FIELD, body.price());
        }
        if (body.timeInForce() != null) {
            newOrderSingle.setChar(quickfix.field.TimeInForce.FIELD, timeInForce(body.timeInForce()));
        }
        newOrderSingle.setUtcTimeStamp(TransactTime.FIELD, transactTime(body.transactTime()), INCLUDE_MILLISECONDS);
    }

    @Override
    public void onParties_Entry(final PartyRole partyRole, final StringDecoder partyId, final int partiesIndex, final int maxPartiesCount) {
        if (partyRole == PartyRole.CLIENT_ID) {
            final String clientId = partyId.decodeStringOrEmpty();
            newOrderSingle.setString(ClientID.FIELD, clientId);
            healthCheckFailActionState.cacheClientId(clientId);
        }
    }

    private Date transactTime(final long transactTimeNanos) {
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(transactTimeNanos));
        return transactTime;
    }

    private String currency(final Body body) {
        return body.currency().decodeAndCache(currencyCache);
    }

    private char orderType(final OrderType orderType) {
        Objects.requireNonNull(orderType, "orderType is required");
        switch (orderType) {
            case MARKET: return OrdType.FOREX_MARKET;
            case LIMIT: return OrdType.FOREX_LIMIT;
            case STOP_LOSS: return OrdType.STOP;
            case STOP_LIMIT: return OrdType.STOP_LIMIT;
            default: throw new IllegalArgumentException("Unsupported orderType" + orderType);
        }
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case DAY: return quickfix.field.TimeInForce.DAY;
            case GTC: return quickfix.field.TimeInForce.GOOD_TILL_CANCEL;
            case IOC: return quickfix.field.TimeInForce.IMMEDIATE_OR_CANCEL;
            case FOK: return quickfix.field.TimeInForce.FILL_OR_KILL;
            case GTD: return quickfix.field.TimeInForce.GOOD_TILL_DATE;
            default: throw new IllegalArgumentException("Unsupported timeInForce" + timeInForce);
        }
    }

    private char side(final Side side) {
        Objects.requireNonNull(side, "side is required");
        switch (side) {
            case BUY: return quickfix.field.Side.BUY;
            case SELL: return quickfix.field.Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side" + side);
        }
    }


    @Override
    public void onStrategyParameters_Value(final StringDecoder strategyParameterValue, final int strategyParametersIndex, final int strategyParametersCount) {

    }

    @Override
    public void onRegulatoryTradeIds_Id(final StringDecoder id, final int regulatoryTradeIdsIndex, final int regulatoryTradeIdsCount) {

    }

    @Override
    public void onRegulatoryTradeIds_IdSource(final StringDecoder idSource, final int regulatoryTradeIdsIndex, final int regulatoryTradeIdsCount) {

    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
        healthCheckFailActionState.executeAction(true);
    }
}
