#!/bin/bash
# (c) 2016 ANZ

TITLE="Aggregated Price Latency (Overall)"
GREPSTR="LatencyAggOverall"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_lat.common