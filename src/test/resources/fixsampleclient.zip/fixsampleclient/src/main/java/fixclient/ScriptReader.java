// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Parses the Script files. Uses an internal SAX parser to generate a List of
 * {@link FIXMessage}.
 */
public class ScriptReader
{
    private ArrayList<FIXMessage> scriptedMessages;
    private ArrayList<String>     parseErrors;

    private static final String   ROOT_ELEMENT       = "FIXScript";
    private static final String   SEND_ELEMENT       = "send";
    private static final String   RECEIVE_ELEMENT    = "receive";
    private static final String   GROUP_ELEMENT      = "group";
    private static final String   GROUP_ITEM_ELEMENT = "groupitem";
    private static final String   MSG_TYPE_TAG       = "msgtype";
    private static final String   TAG_PREFIX         = "tag";
    private static final String   PAUSE_ELEMENT      = "pausemillisecs";

    /**
     * Default constructor
     */
    public ScriptReader()
    {
        // no action required
    }

    /**
     * Parses the script
     * 
     * @param scriptLocation
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws IOException
     */
    public void parseScript(final String scriptLocation) throws ParserConfigurationException,
            SAXException,
            IOException
    {
        // read and parse the script
        final SAXParserFactory spf = SAXParserFactory.newInstance();

        // get a new instance of parser
        final SAXParser sp = spf.newSAXParser();

        // parse the file and also register this class for call backs
        sp.parse(new File(scriptLocation), new ScriptParserHandler());
    }

    private void parsingComplete(final ArrayList<FIXMessage> messages,
            final ArrayList<String> errors)
    {
        this.scriptedMessages = messages;
        this.parseErrors = errors;
    }

    /**
     * @return the messages from the most recent successful parse.
     * @throws IllegalStateException
     *             if no parse has been run, or there were errors in the most
     *             recent run.
     */
    public ArrayList<FIXMessage> getFIXMessages() throws IllegalStateException
    {
        if (this.parseErrors == null)
        {
            throw new IllegalStateException("No script parsed yet");
        }
        else if (this.parseErrors.size() > 0)
        {
            throw new IllegalStateException("Script contained errors");
        }
        else
        {
            return this.scriptedMessages;
        }
    }

    /**
     * @return true if the most recently parsed script has errors, false
     *         otherwise.
     * @throws IllegalStateException
     *             if no parse has been run.
     */
    public boolean hasErrors() throws IllegalStateException
    {
        if (this.parseErrors == null)
        {
            throw new IllegalStateException("No script parsed yet");
        }
        return this.parseErrors.size() > 0;
    }

    /**
     * @return the list of errors from the most recent parse. List is empty if
     *         there were no errors.
     * @throws IllegalStateException
     *             if no parse has been run.
     */
    public List<String> getErrors() throws IllegalStateException
    {
        if (this.parseErrors == null)
        {
            throw new IllegalStateException("No script parsed yet");
        }
        return Collections.unmodifiableList(this.parseErrors);
    }

    class ScriptParserHandler extends DefaultHandler
    {
        private final ArrayList<FIXMessage> messages         = new ArrayList<FIXMessage>();
        private final ArrayList<String>     errors           = new ArrayList<String>();
        private boolean                     parsedRoot       = false;
        private FIXMessage                  currentMessage   = null;
        private FIXRepeatingGroup           currentGroup     = null;
        private boolean                     parsingGroupItem = false;

        @Override
        public void startElement(final String uri,
                final String localName,
                final String qName,
                final Attributes attributes)
        {
            if (!validateQName(qName))
            {
                return;
            }

            if (qName.equals(ROOT_ELEMENT))
            {
                this.parsedRoot = true;
            }
            else if (qName.equals(SEND_ELEMENT)
                    || qName.equals(RECEIVE_ELEMENT))
            {
                if (attributes.getIndex(MSG_TYPE_TAG) == -1)
                {
                    this.errors.add("A "
                            + qName
                            + " element is missing the "
                            + MSG_TYPE_TAG);
                }
                else
                {
                    this.currentMessage = new FIXMessage(attributes.getValue(MSG_TYPE_TAG),
                            qName.equals(SEND_ELEMENT)
                                    ? FIXMessage.FIXMessageDirection.SEND
                                    : FIXMessage.FIXMessageDirection.RECEIVE);

                    // Add the attributes to our FIXMessage
                    for (int i = 0; i < attributes.getLength(); i++)
                    {
                        final String fieldId = getFieldId(attributes, i);
                        if (fieldId != null)
                        {
                            try
                            {
                                this.currentMessage.addField(fieldId,
                                        attributes.getValue(i));
                            }
                            catch (final IllegalStateException e)
                            {
                                this.errors.add(e.getMessage());
                            }
                        }
                    }
                }
            }
            else if (qName.equals(GROUP_ELEMENT))
            {
                if (attributes.getLength() == 0)
                {
                    this.errors.add("A "
                            + GROUP_ELEMENT
                            + " element must contain one tag");
                }
                else
                {
                    // A group element should only have one attribute
                    final String fieldId = getFieldId(attributes, 0);
                    if (fieldId != null)
                    {
                        try
                        {
                            this.currentGroup = new FIXRepeatingGroup(fieldId,
                                    attributes.getValue(0));
                        }
                        catch (final IllegalStateException e)
                        {
                            this.errors.add(e.getMessage());
                        }
                    }
                }
            }
            else if (qName.equals(GROUP_ITEM_ELEMENT))
            {
                if (attributes.getLength() == 0)
                {
                    this.errors.add("A "
                            + GROUP_ITEM_ELEMENT
                            + " element must contain at least one tag");
                }
                else
                {
                    final ArrayList<FIXField> groupItem = new ArrayList<FIXField>();
                    for (int i = 0; i < attributes.getLength(); i++)
                    {
                        final String fieldId = getFieldId(attributes, i);
                        if (fieldId != null)
                        {
                            try
                            {
                                groupItem.add(new FIXField(fieldId,
                                        attributes.getValue(i)));
                            }
                            catch (final IllegalStateException e)
                            {
                                this.errors.add(e.getMessage());
                            }
                        }
                    }

                    this.currentGroup.addGroupItem(groupItem);
                }

                // This is for validation - just in case we find anything we
                // don't expect inside the group item
                this.parsingGroupItem = true;
            }
        }

        private boolean validateQName(final String qName)
        {
            boolean isValid = true;

            // If we haven't started parsing the root element yet...
            if (!this.parsedRoot)
            {
                // ...then this must be the root element, otherwise there's a
                // problem
                isValid = qName.equals(ROOT_ELEMENT);
            }
            // else if we haven't started parsing a message yet...
            else if (this.currentMessage == null)
            {
                // ...then this must be a send or receive element, otherwise
                // there's a problem
                isValid = qName.equals(SEND_ELEMENT)
                        || qName.equals(RECEIVE_ELEMENT);
            }
            // else if we have started parsing a message, but haven't started a
            // repeating group...
            else if (this.currentGroup == null)
            {
                // ...then this has to be a repeating group as it's the only
                // element that can appear
                // directly inside a message
                isValid = qName.equals(GROUP_ELEMENT);
            }
            // else if we are parsing a group, but haven't started a group
            // item...
            else if (!this.parsingGroupItem)
            {
                // ...then this has to be a group item as it's the only element
                // that can appear directly inside a group
                isValid = qName.equals(GROUP_ITEM_ELEMENT);
            }
            // else we are current parsing a group item and should not encounter
            // any more elements.
            else
            {
                isValid = false;
            }

            if (!isValid)
            {
                this.errors.add("Unexpected element: " + qName);
            }

            return isValid;
        }

        private String getFieldId(final Attributes attributes, final int index)
        {
            String fieldId;
            final String qName = attributes.getQName(index);

            if (qName.equals(MSG_TYPE_TAG))
            {
                // "msgtype" is a special case - this is extracted separately so
                // can be ignored here
                fieldId = null;
            }
            else if (qName.startsWith(TAG_PREFIX))
            {
                // Remove the "tag" prefix to get the field id
                fieldId = attributes.getQName(index).replace(TAG_PREFIX, "");
            }
            else if (qName.startsWith(PAUSE_ELEMENT))
            {
                fieldId = null;
            }
            else
            {
                this.errors.add("Unexpected attribute: " + qName);
                fieldId = null;
            }

            return fieldId;
        }

        @Override
        public void endElement(final String uri,
                final String localName,
                final String qName)
        {
            if (this.messages != null
                    && qName.equals(SEND_ELEMENT)
                    || qName.equals(RECEIVE_ELEMENT))
            {
                this.messages.add(this.currentMessage);
                this.currentMessage = null;
            }
            else if (this.currentGroup != null && qName.equals(GROUP_ELEMENT))
            {
                if (this.currentGroup.getGroupItems().size() == 0)
                {
                    this.errors.add("A group element must contain at least one groupitem");
                }
                else if (this.currentMessage != null)
                {
                    this.currentMessage.addGroup(this.currentGroup);
                    this.currentGroup = null;
                }
            }
            else if (this.parsingGroupItem && qName.equals(GROUP_ITEM_ELEMENT))
            {
                this.parsingGroupItem = false;
            }
        }

        @Override
        public void endDocument()
        {
            // passes the completed parse results back to the outer class.
            parsingComplete(this.messages, this.errors);
        }
    }
}
