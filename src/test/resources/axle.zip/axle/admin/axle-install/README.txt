## The intention for this directory is to somewhat automate the installation of the Axle environment on a completely new box.

Steps would include the following:
0) Check out Axle installer bootstrap
     svn co https://subversion.apps.anz/svn/markets-fx/axle/tooling/axleinstallerbootstrap/bin/installer.sh
1) pack up contents of this directory
2) transfer the archive to the destination box
3) as axle user, unpack contents under /app/axle/installers
4) fill up the designated sub-directory with artifacts from ram for apama installer
5) fill up the designated sub-directory with artifacts from ram for axle environment installer
6) install axle environment
7) install axle components

## Directory structure:
* apama_install  - contains script to install apama + adapters
    |
    -- dist      - step4: download ram artifacts here
* axle           - contains bash profile and utilities - contents of this drectory are copied under /app/axle
* tools_install  - step5: download ram artifacts here
* install        - step6: axle environment installer
* installer.sh   - step7: axle components installer


## The following commands are noted for convenience, later on people may find the versions are out of date.

### Step4: ram artifacts for apama installation

RAM_USER="auaxlesvnsvc"
RAM_PASSWORD="Fr6T\!Q8b"
cd installers/apama_install/dist
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/17B55A2D-A4BE-7A1E-9254-3A3E151812E3/5.2.0.0/artifactContents/apama52installer.tar
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/17B55A2D-A4BE-7A1E-9254-3A3E151812E3/5.2.0.0/artifactContents/apama_5.2.0.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/17B55A2D-A4BE-7A1E-9254-3A3E151812E3/5.2.0.0/artifactContents/PAM_5.2.0_Fix4_ALL-LINUX-X86-64.tgz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/17B55A2D-A4BE-7A1E-9254-3A3E151812E3/5.2.0.0/artifactContents/capital_markets_foundation_5.2.0.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/5AEC2A71-2297-A15F-E396-CC8470A05F7A/5.2.1/artifactContents/fix_adapter_5.2.1_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/35D1B203-A8DD-2F21-B14A-08D08525E9A9/5.2.0/artifactContents/autobahn_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/35D1B203-A8DD-2F21-B14A-08D08525E9A9/5.2.0/artifactContents/AutobahnAPI_14-2-8-6.zip
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/35D1B203-A8DD-2F21-B14A-08D08525E9A9/5.2.0/artifactContents/autobahn_fix_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/61F09DA7-3857-5E28-3842-48B7D355D6AE/5.2.0/artifactContents/barx_fx_fix_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/C0FD109A-B0E9-85D6-2AC5-4F0E5B68EAC7/5.2.0/artifactContents/citigroup_spot_esp_fix_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/19F29967-A7D4-654F-2FAD-C7053CF2AFF2/5.2.0/artifactContents/currenex_fix_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/55CADD85-4FEB-4599-B0E8-0748FB7F2536/5.2.1/artifactContents/ebs_ai_fix_adapter_5.2.1_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/F7A971BA-6318-5815-3166-74442E5EA2E3/5.2.0/artifactContents/goldman_sachs_fx_fix_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/4CE85593-86E4-912D-4725-2A249440D701/5.2.0/artifactContents/hotspot_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/F8AC421A-ACBE-56B9-596B-CF25A3C52590/5.2.0/artifactContents/kdbplus_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/332C5F9A-C759-D2CF-0367-08C44C5BAB6D/5.2.0/artifactContents/morgan_stanley_fx_fix_adapter_5.2.0_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/614C640B-4D28-8781-E593-7329D4DD977C/5.2.2/artifactContents/reuters_rfa_adapter_5.2.2_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/83C08105-2187-E0A1-6BBC-1FFE95CCA77D/5.2.2/artifactContents/reuters_mapi_adapter_5.2.2_lnx_64_x86.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/D0B8B255-6AED-0DE3-DE54-0AA2BCC098E7/5.2.0/artifactContents/ubs_fx2b_fix_adapter_5.2.0_lnx_64_x86.tar.gz


### Step5: ram artifacts for axle environment installation

RAM_USER="auaxlesvnsvc"
RAM_PASSWORD="Fr6T\!Q8b"
cd installers/tools_install/
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/C4F627DA-C67D-8A5C-EEE4-F896AF53FDFD/1.6.0_31/artifactContents/jdk-6u31-linux-x64.bin 
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/C4F627DA-C67D-8A5C-EEE4-F896AF53FDFD/1.7.0_67/artifactContents/jdk-7u67-linux-x64.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/C4F627DA-C67D-8A5C-EEE4-F896AF53FDFD/1.8.0_73/artifactContents/jdk-8u73-linux-x64.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/264D2E64-7219-7FF2-CDBE-8563F9BBB941/1.8.2/artifactContents/apache-ant-1.8.2-bin.tar.bz2
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/3BCC9041-C701-9000-54CA-3C942D9B575E/7.0.30.1/artifactContents/apache-tomcat-7.0.30-install.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/6F364E85-4526-ADDE-8214-C7E6A5660DF5/2.0.25/artifactContents/munin-2.0.25-AxlSv-linux-x64.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/6F364E85-4526-ADDE-8214-C7E6A5660DF5/2.0.25/artifactContents/munin-2.0.25-kdb-linux-x64.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/2B107790-5F15-4E91-2BA3-46828B18B0B9/4.2x/artifactContents/stunnel-Linux_x86_64.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/2B107790-5F15-4E91-2BA3-46828B18B0B9/4.2x/artifactContents/stunnel-certs.tar.gz
wget --no-check-certificate --user=$RAM_USER --password=$RAM_PASSWORD https://assetmgr.apps.anz/ram.ws/oslc/assets/2B107790-5F15-4E91-2BA3-46828B18B0B9/4.2x/artifactContents/stunnel-certs-prod.tar.gz


### Step6: axle environment installation
cd installers
./install


### Step7: axle components installation

AXLE_VERSION="trunk.2016.04.16.r44004.b6570"
cd axle
./installer.sh distributeManifest "$AXLE_VERSION" <fxagg|broker|spdee|stp|webreport|maxle>
./installer.sh install -c -n -v "$AXLE_VERSION" all
