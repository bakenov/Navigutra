package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.TrimKeyable;
import com.anz.markets.prophet.domain.ConfigKey;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.anz.markets.prophet.config.business.domain.indexed.TrimKeyableConfigs.Key.INSTRUMENT;
import static com.anz.markets.prophet.config.business.domain.indexed.TrimKeyableConfigs.Key.MARKET;
import static com.anz.markets.prophet.config.business.domain.indexed.TrimKeyableConfigs.Key.REGION;
import static com.anz.markets.prophet.config.business.domain.indexed.TrimKeyableConfigs.Key.TIMEZONE;

public class TrimKeyableConfigs<T extends TrimKeyable> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrimKeyableConfigs.class);

    private final EnumObjMap<TradingTimeZone, EnumObjMap<Region, EnumObjTable<Market, Instrument, T>>> configsRaw = new EnumObjMap<>(TradingTimeZone.class);
    private final EnumObjMap<TradingTimeZone, EnumObjTable<Market, Instrument, T>> configsExploded = new EnumObjMap<>(TradingTimeZone.class);

    enum Key {
        REGION,
        TIMEZONE,
        MARKET,
        INSTRUMENT
    }

    private static final int KEY_COUNT = Key.values().length;
    private static final List<Key> DEFAULT_KEY_PRECEDENCE_LOW_TO_HIGH = Arrays.asList(REGION, TIMEZONE, MARKET, INSTRUMENT);
    private final List<Key> keyPrecedenceLowToHigh;

    private final List<ConfigKeyHolder> precedenceConfigKeys = new ArrayList<>();
    private final List<Integer> precedenceConfigKeyIndicies = new ArrayList<>();

    public TrimKeyableConfigs() {
        this(DEFAULT_KEY_PRECEDENCE_LOW_TO_HIGH);
    }

    TrimKeyableConfigs(final List<Key> keyPrecedenceLowToHigh) {
        GcFriendlyAssert.isTrue(keyPrecedenceLowToHigh.size() == KEY_COUNT, "keyPrecedence must be specify all keys");
        this.keyPrecedenceLowToHigh = keyPrecedenceLowToHigh;
        initialiseConfigKeys();

        for (TradingTimeZone tz : TradingTimeZone.VALUES) {
            EnumObjMap<Region, EnumObjTable<Market, Instrument, T>> configByRegion = new EnumObjMap<>(Region.class);
            configsRaw.put(tz, configByRegion);
            for (Region region : Region.VALUES) {
                final EnumObjTable<Market, Instrument, T> mktInstTable = new EnumObjTable<>(Market.class, Instrument.class);
                configByRegion.put(region, mktInstTable);
            }
            configsExploded.put(tz, new EnumObjTable<>(Market.class, Instrument.class));
        }
    }

    public T get(final Market market, final Instrument instrument) {
        GcFriendlyAssert.isFalse(market.isWildcard());
        GcFriendlyAssert.isFalse(instrument.isWildcard());
        return configsExploded.get(Context.context().tradingTimeZone()).get(market, instrument);
    }

    public T get(final Market market, final Instrument instrument, final TradingTimeZone ttz) {
        GcFriendlyAssert.isFalse(market.isWildcard());
        GcFriendlyAssert.isFalse(instrument.isWildcard());
        GcFriendlyAssert.isFalse(ttz.isWildcard());
        return configsExploded.get(ttz).get(market, instrument);
    }

    public void populate(final List<T> cs) {
        configsRaw.forEach((tz, map) -> map.forEach((r, table) -> table.clear()));
        for (T c : cs) {
            final EnumObjTable<Market, Instrument, T> marketInstrumentTable = configsRaw.get(c.getTradingTimeZone()).get(c.getRegion());
            if (marketInstrumentTable.containsKey(c.getMarket(), c.getInstrument())) {
                LOGGER.error("Config with duplicate keys: {} vs {} - Using first", c, marketInstrumentTable.get(c.getMarket(), c.getInstrument()));
            } else {
                marketInstrumentTable.put(c.getMarket(), c.getInstrument(), c);
            }
        }

        final Region region = Context.context().region();
        final Set<T> unusedConfigs = new HashSet();
        cs.forEach(t -> {
            if (t.getRegion() == region || t.getRegion().isWildcard()) {
                unusedConfigs.add(t);
            }
        });

        configsExploded.forEach((tz, table) -> {
            if (!tz.isWildcard()) {
                for (final Market market : Market.VALUES) {
                    if (!market.isWildcard()) {
                        for (final Instrument instrument : Instrument.VALUES) {
                            final T configFound = getWithPrecedence(tz, region, market, instrument);
                            table.put(market, instrument, configFound);
                            unusedConfigs.remove(configFound);
                        }
                    }
                }
            }
        });

        // check whether any config is unused
        for (final T config : unusedConfigs) {
            LOGGER.error("Config item unused: {}", config);
        }
    }

    /**
     * getWithPrecedence
     * Interprets the specified configs according to the rules of precedence, which are:
     * 1. A higher degree of specification ranks first (i.e. less wildcards supersedes more wildcards)
     * 2. At the same degree of specification, the highest ranked key specified supersedes the other
     */
    private T getWithPrecedence(final TradingTimeZone tradingTimeZone, final Region region, final Market market,
                               final Instrument instrument) {
        updateConfigKeys(tradingTimeZone, region, market, instrument);

        // try no wildcard
        T config = getForConfigKeys();
        if (config != null) {
            return config;
        }

        // try with wildcard
        config = getWithIncreasingWildcards();
        if (config != null) {
            return config;
        }
        throw new RuntimeException("No valid configuration");
    }

    private T getWithIncreasingWildcards() {
        // wildcardCount == 1
        for (int i = 0; i < KEY_COUNT; i++) {
            precedenceConfigKeys.get(i).setUseWildcard(true);
            T config = getForConfigKeys();
            precedenceConfigKeys.get(i).setUseWildcard(false);
            if (config != null) {
                return config;
            }
        }

        // wildcardCount == 2
        for (int i = 0; i < KEY_COUNT-1; i++) {
            precedenceConfigKeys.get(i).setUseWildcard(true);
            for (int j = i+1; j < KEY_COUNT; j++) {
                precedenceConfigKeys.get(j).setUseWildcard(true);
                T config = getForConfigKeys();
                precedenceConfigKeys.get(j).setUseWildcard(false);
                if (config != null) {
                    return config;
                }
            }
            precedenceConfigKeys.get(i).setUseWildcard(false);
        }

        // wildcardCount == 3
        precedenceConfigKeys.forEach(key -> key.setUseWildcard(true));
        for (int i = KEY_COUNT-1; i >= 0 ; i--) {
            precedenceConfigKeys.get(i).setUseWildcard(false);
            T config = getForConfigKeys();
            precedenceConfigKeys.get(i).setUseWildcard(true);
            if (config != null) {
                return config;
            }
        }

        // wildcardCount == 4 (ie. all)
        return getForConfigKeys();
    }

    private T getForConfigKeys() {
        final EnumObjTable<Market, Instrument, T> marketInstrumentTable = configsRaw.get(precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(TIMEZONE.ordinal())).getKey())
                .get(precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(REGION.ordinal())).getKey());
        final Market market = (Market) precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(MARKET.ordinal())).getKey();
        final Instrument instrument = (Instrument) precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(INSTRUMENT.ordinal())).getKey();
        return marketInstrumentTable.containsKey(market, instrument) ? marketInstrumentTable.get(market, instrument) : null;
    }

    private void updateConfigKeys(final TradingTimeZone tradingTimeZone, final Region region, final Market market,
                                  final Instrument instrument) {
        precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(TIMEZONE.ordinal())).setKey(tradingTimeZone).setUseWildcard(false);
        precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(REGION.ordinal())).setKey(region).setUseWildcard(false);
        precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(MARKET.ordinal())).setKey(market).setUseWildcard(false);
        precedenceConfigKeys.get(precedenceConfigKeyIndicies.get(INSTRUMENT.ordinal())).setKey(instrument).setUseWildcard(false);
    }

    private void initialiseConfigKeys() {

        for (int i = 0; i < KEY_COUNT; i++) {
            final Key key = keyPrecedenceLowToHigh.get(i);
            if (key == TIMEZONE) {
                precedenceConfigKeys.add(new ConfigKeyHolder(TradingTimeZone.GLOBAL));
                precedenceConfigKeyIndicies.add(TIMEZONE.ordinal());
            } else if (key == REGION) {
                precedenceConfigKeys.add(new ConfigKeyHolder(Region.ANY));
                precedenceConfigKeyIndicies.add(REGION.ordinal());
            } else if (key == MARKET) {
                precedenceConfigKeys.add(new ConfigKeyHolder(Market.ANY));
                precedenceConfigKeyIndicies.add(MARKET.ordinal());
            } else if (key == INSTRUMENT) {
                precedenceConfigKeys.add(new ConfigKeyHolder(Instrument.ANY));
                precedenceConfigKeyIndicies.add(INSTRUMENT.ordinal());
            }
        }
    }


    private static class ConfigKeyHolder {
        final ConfigKey wildcard;
        ConfigKey key;
        boolean useWildcard = false;

        ConfigKeyHolder(ConfigKey wildcard) {
            this.key = wildcard;
            this.wildcard = wildcard;
        }

        ConfigKey getKey() {
            return useWildcard ? wildcard : key;
        }

        ConfigKeyHolder setKey(final ConfigKey key) {
            this.key = key;
            return this;
        }

        ConfigKeyHolder setUseWildcard(final boolean useWildcard) {
            this.useWildcard = useWildcard;
            return this;
        }
    }

}
