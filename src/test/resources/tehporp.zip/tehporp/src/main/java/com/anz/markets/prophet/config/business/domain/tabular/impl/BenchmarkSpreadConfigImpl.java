package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.BenchmarkSpreadConfig;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

public class BenchmarkSpreadConfigImpl implements BenchmarkSpreadConfig, ProphetMarshallable {

    private Region region;
    private Market market;
    private Instrument instrument;
    private BenchmarkCalculationType benchmarkCalculationType;
    private double tooTightThresholdAsProportionOfBaseSpread;
    private double widenedSpreadAsProportionOfBenchmarkSpread;
    private String benchmarkSpreadMarkets;
    private FactorWindow category;
    private transient List<Market> benchmarkSpreadMarketAsEnumList;

    @Deprecated
    public BenchmarkSpreadConfigImpl() {
    }

    public BenchmarkSpreadConfigImpl(final Market market,
                                     final Region region,
                                     final Instrument instrument,
                                     final FactorWindow category) {
        this.market = market;
        this.region = region;
        this.instrument = instrument;
        this.category = category;
    }

    @Override
    public BenchmarkCalculationType getBenchmarkCalculationType() {
        return benchmarkCalculationType;
    }

    public BenchmarkSpreadConfigImpl setBenchmarkCalculationType(
            final BenchmarkCalculationType benchmarkCalculationType) {
        this.benchmarkCalculationType = benchmarkCalculationType;
        return this;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Region getRegion() {
        return region;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public FactorWindow getCategory() {
        return category;
    }

    @Override
    public double getTooTightThresholdAsProportionOfBaseSpread() {
        return tooTightThresholdAsProportionOfBaseSpread;
    }

    public BenchmarkSpreadConfigImpl setTooTightThresholdAsProportionOfBaseSpread(
            final double tooTightThresholdAsProportionOfBaseSpread) {
        this.tooTightThresholdAsProportionOfBaseSpread = tooTightThresholdAsProportionOfBaseSpread;
        return this;
    }

    @Override
    public double getWidenedSpreadAsProportionOfBenchmarkSpread() {
        return widenedSpreadAsProportionOfBenchmarkSpread;
    }

    public BenchmarkSpreadConfigImpl setWidenedSpreadAsProportionOfBenchmarkSpread(
            final double widenedSpreadAsProportionOfBenchmarkSpread) {
        this.widenedSpreadAsProportionOfBenchmarkSpread = widenedSpreadAsProportionOfBenchmarkSpread;
        return this;
    }

    @Override
    public String getBenchmarkSpreadMarkets() {
        return benchmarkSpreadMarkets;
    }

    @JsonIgnore
    @Override
    public List<Market> getBenchmarkSpreadMarketAsEnumList() {
        if (benchmarkSpreadMarketAsEnumList == null) {
            if (benchmarkSpreadMarkets != null) {
                this.benchmarkSpreadMarketAsEnumList = Market.valueOf(benchmarkSpreadMarkets.split("\\s*\\|\\s*"));
            }
        }
        return benchmarkSpreadMarketAsEnumList;
    }

    public BenchmarkSpreadConfigImpl setBenchmarkSpreadMarkets(final List<Market> benchmarkSpreadMarkets) {
        this.setBenchmarkSpreadMarkets(benchmarkSpreadMarkets.stream().map(e -> e.name()).collect(Collectors.joining("|")));
        return this;
    }

    public BenchmarkSpreadConfigImpl setBenchmarkSpreadMarkets(final String benchmarkSpreadMarkets) {
        this.benchmarkSpreadMarkets = benchmarkSpreadMarkets;
        return this;
    }

    public BenchmarkSpreadConfigImpl setCategory(final FactorWindow category) {
        this.category = category;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        Context.context().header().before(MessageVersion.VERSION_0_32, () -> {
            region = in.readEnum(Region.class);
            market = in.readEnum(Market.class);
            instrument = in.readEnum(Instrument.class);
            benchmarkCalculationType = in.readEnum(BenchmarkCalculationType.class);
        });
        Context.context().header().since(MessageVersion.VERSION_0_32, () -> {
            region = Region.valueOf(in.readByte());
            market = Market.valueOf(in.readByte());
            instrument = Instrument.readMarshallableValueOf(in);
            benchmarkCalculationType = BenchmarkCalculationType.valueOf(in.readByte());
        });
        tooTightThresholdAsProportionOfBaseSpread = in.readDouble();
        widenedSpreadAsProportionOfBenchmarkSpread = in.readDouble();
        benchmarkSpreadMarkets = in.readUTF8();
        Context.context().header().before(MessageVersion.VERSION_0_32, () -> {
            category = FactorWindow.CAT_A;
        });
        Context.context().header().since(MessageVersion.VERSION_0_32, () -> {
            category = FactorWindow.valueOf(in.readByte());
        });
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(region.getValue());
        out.writeByte(market.getValue());
        out.writeShort(instrument.getValue());
        out.writeByte(benchmarkCalculationType.getValue());
        out.writeDouble(tooTightThresholdAsProportionOfBaseSpread);
        out.writeDouble(widenedSpreadAsProportionOfBenchmarkSpread);
        out.writeUTF8(benchmarkSpreadMarkets);
        out.writeByte(category.getValue());
    }

    @Override
    public String toString() {
        return "BenchmarkSpreadConfigImpl{" +
                "market=" + market +
                ", region=" + region +
                ", instrument=" + instrument +
                ", category=" + category +
                ", benchmarkCalculationType=" + benchmarkCalculationType +
                ", tooTightThresholdAsProportionOfBaseSpread=" + tooTightThresholdAsProportionOfBaseSpread +
                ", widenedSpreadAsProportionOfBenchmarkSpread=" + widenedSpreadAsProportionOfBenchmarkSpread +
                ", benchmarkSpreadMarkets='" + benchmarkSpreadMarkets + '\'' +
                '}';
    }

}
