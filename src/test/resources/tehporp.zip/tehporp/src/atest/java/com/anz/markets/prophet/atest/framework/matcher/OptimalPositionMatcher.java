package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.efx.ngaro.math.DoubleTools;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import java.util.Optional;

import static com.anz.markets.prophet.util.DoubleUtil.toNonNaN;
import static com.anz.markets.prophet.util.DoubleUtil.toNonNegativeZero;

public class OptimalPositionMatcher extends BaseMatcher<OptimalPositions> {
    protected final OptimalPosition expected;
    private final boolean verifyRate;

    public OptimalPositionMatcher(OptimalPosition expected, final boolean verifyRate) {
        this.expected = expected;
        this.verifyRate = verifyRate;
    }

    @Override
    public boolean matches(Object o) {

        final OptimalPositions actuals = (OptimalPositions) o;
        final Optional<OptimalPosition> actual = getByInstrument(actuals);


        if (actual.isPresent()) {
            // for the purpose of test, NaN and zero are the same and system in test can yield different result depending on
            // if it was freshly started or previously has position and had been reset to zero.
            EqualsBuilder builder = new EqualsBuilder()
                    .append(expected.getInstrument(), actual.get().getInstrument())
                    .append(DoubleTools.round(toNonNegativeZero(toNonNaN(expected.getInstrumentPositionInNotional())), 2), DoubleTools.round(toNonNegativeZero(toNonNaN(actual.get().getInstrumentPositionInNotional())), 2))
                    .append(DoubleTools.round(toNonNegativeZero(toNonNaN(expected.getPositionInNotional())), 2), DoubleTools.round(toNonNegativeZero(toNonNaN(actual.get().getPositionInNotional())), 2))
                    .append(DoubleTools.round(toNonNegativeZero(toNonNaN(expected.getPositionInSystemBase())), 2), DoubleTools.round(toNonNegativeZero(toNonNaN(actual.get().getPositionInSystemBase())), 2))
                    .append(DoubleTools.round(toNonNegativeZero(toNonNaN(expected.getGradientPositionInNotional())), 2), DoubleTools.round(toNonNegativeZero(toNonNaN(actual.get().getGradientPositionInNotional())), 2))
                    .append(DoubleTools.round(toNonNegativeZero(toNonNaN(expected.getGradientPositionInSystemBase())), 2), DoubleTools.round(toNonNegativeZero(toNonNaN(actual.get().getGradientPositionInSystemBase())), 2))
                    .append(DoubleTools.round(toNonNegativeZero(toNonNaN(expected.getGradient())), 5), DoubleTools.round(toNonNegativeZero(toNonNaN(actual.get().getGradient())), 5))
                    .append(expected.isCorrelatedPosition(), actual.get().isCorrelatedPosition())
                    .append(toNonNegativeZero(toNonNaN(expected.getRate())), toNonNegativeZero(toNonNaN(actual.get().getRate())));

            if (verifyRate) {
                builder = builder.append(toNonNegativeZero(toNonNaN(expected.getRate())), toNonNegativeZero(toNonNaN(actual.get().getRate())));
            }
            return builder.isEquals();
        }
        throw new IllegalArgumentException("Actual optimal positions does not contain expected entry for " + expected.getInstrument());
    }

    private Optional<OptimalPosition> getByInstrument(final OptimalPositions actuals) {
        return actuals.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == expected.getInstrument()).findFirst();
    }

    @Override
    public void describeTo(Description description) {
        description.appendValue(expected);
    }

    @Override
    public void describeMismatch(final Object item,
                                 final Description description) {
        final OptimalPositions actuals = (OptimalPositions) item;
        final Optional<OptimalPosition> actual = getByInstrument(actuals);

        description.appendValue(actual.get());
    }

}
