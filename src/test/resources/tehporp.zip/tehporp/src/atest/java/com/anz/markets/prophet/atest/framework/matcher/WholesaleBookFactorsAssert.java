package com.anz.markets.prophet.atest.framework.matcher;


import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.clientprice.impl.SpreadFactorsModel;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;

import static com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification.isNear;
import static org.hamcrest.MatcherAssert.assertThat;

public class WholesaleBookFactorsAssert {

    public static void assertValueAtLevel(final EnumDoubleMap<Level> map, final Level level,
                                          final double expected) {
        assertThat(map.get(level), isNear(expected));
    }

    public static void assertModelSpreadAtLevel(final SpreadFactorsModel spreadFactorsModel, final Level level, final double expected) {
        assertThat(spreadFactorsModel.get(level).getModelSpread(), isNear(expected));
    }

    public static void assertSkewedModelSpreadAtLevel(final SpreadFactorsModel spreadFactorsModel, final Level level, final double bid, final double offer) {
        assertThat(spreadFactorsModel.get(level).getSkewedModelBidSpread(), isNear(bid));
        assertThat(spreadFactorsModel.get(level).getSkewedModelOfferSpread(), isNear(offer));
    }
}
