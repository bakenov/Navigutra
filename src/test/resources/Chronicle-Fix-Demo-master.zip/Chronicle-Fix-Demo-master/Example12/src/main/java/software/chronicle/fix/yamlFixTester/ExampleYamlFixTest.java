package software.chronicle.fix.yamlFixTester;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.OS;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.time.SystemTimeProvider;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.yaml.YamlFixTester;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.parsers.MessageParser;

import static org.junit.Assume.assumeFalse;

public final class ExampleYamlFixTest {


    static {
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main( String[] args ) throws Exception
    {
        if( args.length != 1 ) {
            System.err.println("Usage " + ExampleYamlFixTest.class.getSimpleName() + " <test = testMissingRequiredTag>");
            return;

        }

        String test = args[0];

        if( test.equals("fixFormat") )
            new ExampleYamlFixTest().fixFormat();
        else if( test.equals("yamlFormat") )
            new ExampleYamlFixTest().yamlFormat();
        else if( test.equals("external") )
            new ExampleYamlFixTest().externallyCreatedEngine();
        else
            System.err.println( "Unknown test name " +  test + ". Expect either fixFormat, yamlFormat or external" );
    }

    public void fixFormat() throws Exception {
        new YamlFixTester("fix-config-example12.yaml",
                "yamlFixTester",
                MessageParser.class,
                MessageNotifier.class,
                SystemTimeProvider.INSTANCE
        ).
                inputFormat(YamlFixTester.Format.FIX).
                outputFormat(YamlFixTester.Format.FIX).
                run();
    }

    public void yamlFormat() throws Exception {
        assumeFalse(OS.isWindows());
        new YamlFixTester("fix-config-example12.yaml",
                "yamlFixTester2",
                MessageParser.class,
                MessageNotifier.class,
                SystemTimeProvider.INSTANCE
        ).
                run();
    }

    public void externallyCreatedEngine() throws Exception {
        assumeFalse(OS.isWindows());

        YamlFixTester yamlFixTester = new YamlFixTester("fix-config-example12-initiator.yaml",
                "yamlFixTester2",
                MessageParser.class,
                MessageNotifier.class,
                SystemTimeProvider.INSTANCE
        );

        try (ChronicleFixEngine engine = ChronicleFixEngine.createFixEngineFromFile("fix-config-example12-acceptor.yaml")) {
            yamlFixTester.run();
        }
    }
}