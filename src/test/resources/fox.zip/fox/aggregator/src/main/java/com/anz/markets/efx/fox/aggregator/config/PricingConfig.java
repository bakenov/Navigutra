package com.anz.markets.efx.fox.aggregator.config;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.function.IntFunction;
import java.util.function.LongFunction;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.agrona.concurrent.OneToOneConcurrentArrayQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.tools4j.nobark.queue.EvictConflationQueue;
import org.tools4j.nobark.queue.ExchangeConflationQueue;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.IdleStrategyId;
import com.anz.markets.efx.fox.metric.Metric;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import com.anz.markets.efx.pricing.client.api.ConflatingPartition;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.client.api.SnapshotterDecoderLookup;
import com.anz.markets.efx.pricing.client.api.metric.QueueAppenderMetricHandler;
import com.anz.markets.efx.pricing.client.api.metric.QueuePollerMetricHandler;
import com.anz.markets.efx.pricing.client.conflator.ConflatingPricingClient;
import com.anz.markets.efx.pricing.client.conflator.DefaultConflatingPartitionFactory;
import com.anz.markets.efx.pricing.client.conflator.MarketDataBookSnapshotterDecoderLookupFactory;
import com.anz.markets.efx.pricing.client.conflator.PooledPoller;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import static com.anz.markets.efx.fox.aggregator.config.CommonConfig.idleStrategyFactory;

public class PricingConfig {

    @Bean
    public QueueAppenderMetricHandler queueAppenderMetricHandler() {
        return (key, conflation) -> {
        }; // todo
    }

    @Bean
    public QueuePollerMetricHandler queuePollerMetricHandler() {
        return (key, polled) -> {
        }; // todo
    }

    @Bean
    public ObjectPool<MarketDataBook> marketDataBookPool(final @Value("${initial.book.entries}") int initialBookEntries,
                                                         final @Value("${initial.book.pool.size}") int poolSize) {
        final RequestKey tempRequestKey = RequestKey.of(Venue.FOX, InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP));

        return new ObjectPool<>(consumer -> new DefaultMarketDataBook(tempRequestKey, initialBookEntries), poolSize);
    }

    @Bean
    public PricingClient<MarketDataBook> pricingClient(
                                       final @Value("${messaging.compId}") String compId,
                                       final @Value("${initial.book.entries}") int initialBookEntries,
                                       final @Value("${runnable.queue.capacity}") int runnableQueueCapacity,
                                       final @Value("#{${price.conflator.partition.idle.strategies}}") List<IdleStrategyId> idleStrategyIds,
                                       final @Value("${idle.strategy.backoff.maxSpins}") long backOffMaxSpins,
                                       final @Value("${idle.strategy.backoff.maxYields}") long backOffMaxYields,
                                       final @Value("${idle.strategy.backoff.maxParkPeriodUs}") long backOffMaxParkPeriodUs,
                                       final @Value("${conflation.queue.capacity}") int conflatingQueueCapacity,
                                       final @Value("#{${price.conflator.partitions}}") List<? extends List<String>> partitions,
                                       final PrecisionClock precisionClock,
                                       final Transport transport,
                                       final EndPointStatusHandler transportEndPointStatusHandler,
                                       final QueueAppenderMetricHandler queueAppenderMetricHandler,
                                       final QueuePollerMetricHandler queuePollerMetricHandler,
                                       final MetricRepository<Metric, Venue> metricRepository,
                                       final ScheduledExecutorService scheduledExecutorService,
                                       final @Value("${metrics.reporting.period.sec}") int metricReportingDelaySeconds,
                                       final ObjectPool<MarketDataBook> marketDataBookPool,
                                       final @Value("${fox.aggregator.source.id}") int foxAggregatorSourceId) {

        final LongFunction<ExchangeConflationQueue<RequestKey, MarketDataBook>> instrumentKeyConflationQueueFactory = instrumentConflationQueueFactory(conflatingQueueCapacity,
                queueAppenderMetricHandler,
                queuePollerMetricHandler);

        final SnapshotterDecoderLookup.Factory<MarketDataBook> snapshotterDecoderLookupFactory =
                new MarketDataBookSnapshotterDecoderLookupFactory(
                        compId,
                        requestKey -> new DefaultMarketDataBook(requestKey, initialBookEntries),
                        precisionClock,
                        MetricsConfig.latencyMetricRecorderLookup(metricRepository),
                        foxAggregatorSourceId);

        final IntFunction<? extends Queue<Runnable>> runnableQueueFactory = runnableQueueFactory(runnableQueueCapacity, metricRepository, scheduledExecutorService, metricReportingDelaySeconds);

        final ConflatingPartition.Factory<MarketDataBook> pricePartitionConflatorFactory =
                new DefaultConflatingPartitionFactory<>(
                        snapshotterDecoderLookupFactory,
                        runnableQueueFactory,
                        () -> transport.openConnection(() -> {}),
                        transportEndPointStatusHandler,
                        idleStratedyLookup(idleStrategyIds, backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs),
                        instrumentKeyConflationQueueFactory,
                        longFunction -> new PooledPoller<>(longFunction, marketDataBookPool));

        return new ConflatingPricingClient<>(partitions, pricePartitionConflatorFactory,
                "PriceConflator", "ConflatingPartition");
    }

    static LongFunction<ExchangeConflationQueue<RequestKey, MarketDataBook>> instrumentConflationQueueFactory(final int conflatingQueueCapacity,
                                                                                                              final QueueAppenderMetricHandler queueAppenderMetricHandler,
                                                                                                              final QueuePollerMetricHandler queuePollerMetricHandler) {
        return instrumentId -> new EvictConflationQueue<>(
                () -> new OneToOneConcurrentArrayQueue<>(conflatingQueueCapacity),
                HashMap::new,
                () -> (queue, key, newValue, oldValue, conflation) -> {
                    switch (conflation) {
                        case UNCONFLATED:
                            queueAppenderMetricHandler.record(key, QueueAppenderMetricHandler.Conflation.UNCONFLATED);
                            break;
                        case EVICTED:
                            queueAppenderMetricHandler.record(key, QueueAppenderMetricHandler.Conflation.EVICTED);
                            break;
                        case MERGED:
                            queueAppenderMetricHandler.record(key, QueueAppenderMetricHandler.Conflation.MERGED);
                            break;
                        default:
                            throw new IllegalArgumentException("Unsupported conflation type: " + conflation);
                    }
                },
                () -> (queue, key, value) -> queuePollerMetricHandler.record(key));
    }

    static IntFunction<? extends Queue<Runnable>> runnableQueueFactory(final int runnableQueueCapacity,
                                                                       final MetricRepository<Metric, Venue> metricRepository,
                                                                       final ScheduledExecutorService scheduledExecutorService,
                                                                       final int metricReportingDelaySeconds) {
        return partitionIndex -> {
            final Queue<Runnable> runnableQueue = new MonitoredQueue<>(
                    new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(runnableQueueCapacity)),
                    (metric, value, element) -> {
                    });// todo: runnable queue metrics
            MetricsConfig.createMetricReporterJob(
                    MetricsConfig.metricDomain(partitionIndex),
                    metricRepository,
                    runnableQueue,
                    scheduledExecutorService,
                    metricReportingDelaySeconds);
            return runnableQueue;
        };
    }

    static IntFunction<com.anz.markets.efx.eventloop.IdleStrategy> idleStratedyLookup(final List<IdleStrategyId> idleStrategyIds,
                                                                                      final long backOffMaxSpins,
                                                                                      final long backOffMaxYields,
                                                                                      final long backOffMaxParkPeriodUs) {
        final IntFunction<IdleStrategyId> idleStrategyIdFactory = index -> {
            if (index >= idleStrategyIds.size())
                throw new IllegalArgumentException("No idleStrategyId for index " + index);
            return idleStrategyIds.get(index);
        };

        return partitionIndex -> idleStrategyFactory(idleStrategyIdFactory.apply(partitionIndex), backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs).get();
    }
}
