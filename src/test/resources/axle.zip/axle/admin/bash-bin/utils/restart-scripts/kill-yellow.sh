#!/bin/bash
source ~/bin/shell-env/daxa009s/.functions

echo "Killing Yellow Axle"
hosts=""
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "ps -ef | egrep '(java|iaf|munin-node|corr|stunnel|mstats)' | egrep -v '(grep|delta|pdc|mahi/apps|prophet)' | awk '{ print \$2 }' | xargs -I {} kill -9 {}; echo 'Killed (java|iaf|munin-node|corr|stunnel|mstats)'") ::: $hosts
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "find ~/logs -type f -name '*pid*' -exec rm -rf {} \;; rm -f ~/apache-tomcat*/conf/pid;  echo Removed PID files") ::: $hosts

# No Passwordless access to STP Box
#echo "Killing Yellow STP"
#ssh axle@dfxa002z "ps -ef | grep 'java' | grep 'axle' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
