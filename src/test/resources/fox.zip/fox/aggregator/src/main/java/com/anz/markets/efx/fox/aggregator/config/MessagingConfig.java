package com.anz.markets.efx.fox.aggregator.config;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.ConversionService;
import org.springframework.format.support.DefaultFormattingConversionService;

import io.aeron.driver.ThreadingMode;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.aeron.AeronConfig;
import com.anz.markets.efx.messaging.transport.aeron.AeronConnection;
import com.anz.markets.efx.messaging.transport.aeron.AeronEndPointConfig;
import com.anz.markets.efx.messaging.transport.aeron.AeronPollingStrategyFactory;
import com.anz.markets.efx.messaging.transport.aeron.AeronTransport;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.base.ApplicationPollingStrategy;
import com.anz.markets.efx.messaging.transport.resilience.ResilientTransport;
import com.anz.markets.efx.messaging.transport.um.OperationalModeValue;
import com.anz.markets.efx.messaging.transport.um.TransportValue;
import com.anz.markets.efx.messaging.transport.um.UmConfig;
import com.anz.markets.efx.messaging.transport.um.UmConnection;
import com.anz.markets.efx.messaging.transport.um.UmEndPointConfig;
import com.anz.markets.efx.messaging.transport.um.UmPollingStrategyFactory;
import com.anz.markets.efx.messaging.transport.um.UmTransport;

@Configuration
public class MessagingConfig {
    private final static Logger UM_CONFIG_LOGGER = LoggerFactory.getLogger(UmConfig.class);

    private final PollingStrategy.Conductor conductor;

    public MessagingConfig(final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor) {
        this.conductor = conductor;
    }

    @Bean
    public static ConversionService conversionService() {
        return new DefaultFormattingConversionService();
    }

    @Bean
    public UmConfig umConfig(final @Value("${messaging.um.transport}") TransportValue transport,
                             final @Value("${messaging.um.operational_mode}") OperationalModeValue operationalMode,
                             final @Value("#{${messaging.um.default.context.attribute:T(java.util.Collections).emptyMap()}}") Map<String, Object> defaultContextAttributes,
                             final @Value("#{${messaging.um.default.source.attribute:T(java.util.Collections).emptyMap()}}") Map<String, Object> defaultSourceAttributes,
                             final @Value("#{${messaging.um.default.receiver.attribute:T(java.util.Collections).emptyMap()}}") Map<String, Object> defaultReceiverAttributes,
                             final @Value("#{${messaging.um.topic.source.attribute:T(java.util.Collections).emptyMap()}}") Map<String, Map<String, Object>> topicsSourceAttributes,
                             final @Value("#{${messaging.um.topic.receiver.attribute:T(java.util.Collections).emptyMap()}}") Map<String, Map<String, Object>> topicsReceiverAttributes,
                             final @Value("${messaging.um.resolver_unicast_daemons:}#{T(java.util.Collections).emptySet()}") Set<String> resolverUnicastDaemons) {
        return new UmConfig() {
            @Override
            public UmEndPointConfig getEndPointConfig() {
                return UmEndPointConfig.forSingleTransport(transport);
            }

            @Override
            public OperationalModeValue getOperationalMode() {
                return operationalMode;
            }

            @Override
            public long getProcessEventsMillis() {
                return 0;
            }

            @Override
            public String toString() {
                return toString(new StringBuilder()).toString();
            }

            @Override
            public Map<String, ?> getDefaultContextAttributes() {
                return defaultContextAttributes;
            }

            @Override
            public Map<String, ?> getDefaultSourceAttributes() {
                return defaultSourceAttributes;
            }

            @Override
            public Map<String, ?> getDefaultReceiverAttributes() {
                return defaultReceiverAttributes;
            }

            @Override
            public Set<String> getResolverUnicastDaemons() {
                return resolverUnicastDaemons;
            }

            @Override
            public Map<String, ?> getSourceAttributes(final Topic topic) {
                final Map<String, ?> topicSourceAttributes = getTopicAttributes(topic, topicsSourceAttributes);
                UM_CONFIG_LOGGER.info("Topic {} source config: {}", topic.name(), topicSourceAttributes);
                return topicSourceAttributes;
            }

            @Override
            public Map<String, ?> getReceiverAttributes(final Topic topic) {
                final Map<String, ?> topicReceiverAttributes = getTopicAttributes(topic, topicsReceiverAttributes);
                UM_CONFIG_LOGGER.info("Topic {} receiver config: {}", topic.name(), topicReceiverAttributes);
                return topicReceiverAttributes;
            }

            private Map<String, ?> getTopicAttributes(final Topic topic, final Map<String, Map<String, Object>> topicsAttributes) {
                return topicsAttributes.entrySet().stream()
                        .filter(entry -> topic.name().matches(entry.getKey()))
                        .flatMap(entry -> entry.getValue().entrySet().stream())
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (o, o2) -> o2));
            }

            @Override
            public PollingStrategy.Factory<UmConnection> getPollerFactory() {
                final UmPollingStrategyFactory transportPollingStrategyFactory = UmPollingStrategyFactory.valueOf(this.getOperationalMode());
                if (conductor == PollingStrategy.Conductor.APPLICATION) {
                    return ApplicationPollingStrategy.factory(transportPollingStrategyFactory);
                } else {
                    return transportPollingStrategyFactory;
                }
            }
        };
    }

    @Bean
    public AeronConfig aeronConfig(final @Value("${messaging.aeron.directory}") String aeronDirectory,
                                   final @Value("${messaging.aeron.publication.channel}") String aeronPublicationChannel,
                                   final @Value("${messaging.aeron.subscription.channel}") String aeronSubscriptionChannel,
                                   final @Value("${messaging.aeron.mediadriver.embedded}") boolean embeddedMediaDriver,
                                   final @Value("${messaging.aeron.mediadriver.dirsDeleteOnStart}") boolean mediaDriverDirsDeleteOnStart,
                                   final @Value("${messaging.aeron.mediadriver.threadingMode}") ThreadingMode threadingMode) {
        return new AeronConfig() {
            @Override
            public boolean getMediaDriverEmbedded() {
                return embeddedMediaDriver;
            }

            @Override
            public boolean getMediaDriverDirsDeleteOnStart() {
                return mediaDriverDirsDeleteOnStart;
            }

            @Override
            public ThreadingMode getThreadingMode() {
                return threadingMode;
            }

            @Override
            public boolean getAllowSubscriptions() {
                return true;
            }

            @Override
            public AeronEndPointConfig getEndPointConfig() {
                return AeronEndPointConfig.forSubscriptionAndPublicationChannel(aeronSubscriptionChannel, aeronPublicationChannel);
            }

            @Override
            public String getAeronDirectory() {
                return aeronDirectory;
            }

            @Override
            public String toString() {
                return toString(new StringBuilder()).toString();
            }

            @Override
            public PollingStrategy.Factory<AeronConnection> getPollerFactory() {
                final AeronPollingStrategyFactory transportPollingStrategyFactory = getAllowSubscriptions()? AeronPollingStrategyFactory.POLLER:AeronPollingStrategyFactory.NO_POLLER;
                if (conductor == PollingStrategy.Conductor.APPLICATION) {
                    return ApplicationPollingStrategy.factory(transportPollingStrategyFactory);
                } else {
                    return transportPollingStrategyFactory;
                }
            }
        };
    }

    @Bean
    public Transport transport(final PrecisionClock precisionClock,
                               final UmConfig umConfig,
                               final AeronConfig aeronConfig,
                               final @Value("${messaging.provider}") MessagingProvider messagingProvider,
                               final ScheduledExecutorService executorService,
                               final @Value("${messaging.seconds_to_retry_endpoint}")  long secondsToRetryEndpoint) {
        final Transport transport;
        switch (messagingProvider) {
            case UM:
                transport = new UmTransport(precisionClock, umConfig);
                break;
            case AERON:
                transport = new AeronTransport(precisionClock, aeronConfig, executorService);
                break;
             default:
                throw new IllegalArgumentException("Messaging provider not supported: " + messagingProvider);
        }
        return new ResilientTransport(transport, executorService, secondsToRetryEndpoint);
    }

    @Bean(destroyMethod = "close")
    public Connection connection1(final Transport transport) {
        return transport.openConnection(() -> {});
    }
}
