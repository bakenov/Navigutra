package com.anz.markets.efx.fox.aggregator.config;

public enum MessagingProvider {
    UM, AERON
}
