#!/bin/bash

echo "Killing everything on correlator boxes"
ssh axle@daxa011z "ps -ef | grep 'corr' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh axle@daxa011z "ps -ef | grep 'iaf' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh axle@daxa011z "ps -ef | grep 'java' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"

ssh AxlSv@daxa004z "ps -ef | grep 'corr' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh AxlSv@daxa004z "ps -ef | grep 'iaf' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh AxlSv@daxa004z "ps -ef | grep 'java' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"

echo "Killing everything on proxy boxes"
ssh axle@daxa015z "ps -ef | grep 'java' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9; rm -rf /app/apama/apache-tomcat/conf/pid"
ssh AxlSv@daxa004z "ps -ef | grep 'java' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9; rm -rf /app/apama/apache-tomcat/conf/pid"

