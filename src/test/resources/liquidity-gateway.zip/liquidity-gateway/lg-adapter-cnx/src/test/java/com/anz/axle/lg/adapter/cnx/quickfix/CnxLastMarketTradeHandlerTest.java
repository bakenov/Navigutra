package com.anz.axle.lg.adapter.cnx.quickfix;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import quickfix.Message;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.FormattedTimeParser;
import com.anz.axle.lg.util.test.FixMessageFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoLastMarketTradeEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.LastMarketTrade;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CnxLastMarketTradeHandlerTest {
    private static final String SENDER_COMP_ID = "GB:CNX";
    private static final String COMP_ID = "GB:lg-cnx";
    private static final long CURRENT_TIME = 34523453;
    private static final long MSG_SEQ_NUM = 4317;
    private static final String MSG_SEQ_NUM_STRING = "4317";
    private static final String SENDING_TIME_STRING = "20161129-06:23:35.982";
    private static final FormattedTimeParser FORMATTED_TIME_PARSER = new FormattedTimeParser();
    private static final long SENDING_TIME_NANOS = FORMATTED_TIME_PARSER.parseNanos(SENDING_TIME_STRING);
    private static final String CURRENCY = "EUR";
    private static final String SYMBOL = "EUR/CAD";
    private static final String NORMALISED_SYMBOL = "EURCAD";
    private static final SecurityType SECURITY_TYPE = SecurityType.FXSPOT;
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(NORMALISED_SYMBOL, SECURITY_TYPE, Tenor.SP);
    private static final String MDR_ID = "1234567";
    private static final int MDR_ID_INT = Integer.parseInt(MDR_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(MDR_ID);
    private static final double TOLERANCE = 1e-6;

    private FixMessageFactory messageFactory;
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription lastMarketTradeSubscription = mock(MarketDataSubscription.class);
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    @Before
    public void setUp() throws Exception {
        messageFactory = new FixMessageFactory("/conf/FIX42-cnx.xml");
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(MDR_ID_INT)).thenReturn(lastMarketTradeSubscription);
        when(lastMarketTradeSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        when(lastMarketTradeSubscription.market()).thenReturn(Venue.CNX);
        when(lastMarketTradeSubscription.symbol()).thenReturn(SYMBOL);
        when(lastMarketTradeSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
    }

    @Test
    public void shouldProcessLastMarketTrade() throws Exception {
        final PricingEncoderSupplier encoderSupplier = new PojoPricingEncoderSupplier(m -> {});
        final CnxLastMarketTradeHandler cnxLastMarketTradeHandler = new CnxLastMarketTradeHandler(encoderSupplier, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, sourceSequencer);
        final Message lastMarketTradeMessage = messageFactory.msg(
                "8=", "FIX.4.2",
                "9=", "156",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CNX_TICKS_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CNX_TICKS_S",
                "60=", "20180308-10:21:24.486",
                "262=", MDR_ID,
                "7562=", "P",
                "268=", "1",
                "279=", "0",
                "269=", "2",
                "55=", SYMBOL,
                "270=", "1.56039",
                "15=", CURRENCY,
                "10=", "156");
        assertNull(lastMarketTradeMessage.getException());

        //when
        cnxLastMarketTradeHandler.accept(lastMarketTradeMessage);

        //then
        PojoLastMarketTradeEncoder pojoEncoder = (PojoLastMarketTradeEncoder)encoderSupplier.lastMarketTrade();
        verifyLastMarketTrade(pojoEncoder.message(), 1.56039, 0.0);

    }

    private void verifyLastMarketTrade(final LastMarketTrade lastMarketTrade,
                                       final double price,
                                       final double size) {
        assertEquals(COMP_ID, lastMarketTrade.body.senderCompId);
        assertEquals(MSG_SEQ_NUM, lastMarketTrade.body.messageId);
        assertEquals(Venue.CNX, lastMarketTrade.body.marketId);
        assertEquals(INSTRUMENT_KEY.instrumentId(), lastMarketTrade.body.instrumentId);
        assertEquals(SENDING_TIME_NANOS, lastMarketTrade.body.sendingTime);
        assertEquals(price, lastMarketTrade.body.mdEntryPx, TOLERANCE);
        assertEquals(size, lastMarketTrade.body.mdEntrySize,TOLERANCE);

        assertEquals(2, lastMarketTrade.hops.size());

        assertEquals(SENDER_COMP_ID, lastMarketTrade.hops.get(0).hopCompId);
        assertEquals(MSG_SEQ_NUM, lastMarketTrade.hops.get(0).hopMessageId);
        assertEquals(0, lastMarketTrade.hops.get(0).hopReceivingTime);
        assertEquals(SENDING_TIME_NANOS, lastMarketTrade.hops.get(0).hopSendingTime);

        assertEquals(COMP_ID, lastMarketTrade.hops.get(1).hopCompId);
        assertEquals(MSG_SEQ_NUM, lastMarketTrade.hops.get(1).hopMessageId);
        assertEquals(CURRENT_TIME, lastMarketTrade.hops.get(1).hopReceivingTime);
        assertEquals(CURRENT_TIME, lastMarketTrade.hops.get(1).hopSendingTime);
    }
}