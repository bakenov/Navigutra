package com.anz.axle.lg.adapter.ebsu.increment;

import com.anz.axle.lg.adapter.ebsu.RecordArrivalProbes;
import com.anz.axle.lg.adapter.ebsu.trade.TradeMessageHandler;
import com.anz.axle.microtime.PrecisionClock;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.ebs.adapter.moldudp64.ConnectionStatus;
import software.chronicle.ebs.itch.generated.incremental.messages.MessageNotifier;
import software.chronicle.ebs.itch.generated.incremental.messages.server.Heartbeat;
import software.chronicle.ebs.itch.generated.incremental.messages.server.PriceLevelUpdate;
import software.chronicle.ebs.itch.generated.incremental.messages.server.SystemEvent;
import software.chronicle.ebs.itch.generated.incremental.messages.server.TradePrice;
import software.chronicle.itch.staticcode.IncrementalServerSessionHandler;

import java.io.Closeable;
import java.io.IOException;
import java.util.Objects;

public class IncrementMessageNotifier implements MessageNotifier, Closeable {
    private static final Logger LOGGER = LoggerFactory.getLogger(IncrementMessageNotifier.class);
    private final IncrementalMessageHandler incrementalMessageHandler;
    private final TradeMessageHandler tradeMessageHandler;
    private final PrecisionClock precisionClock;

    public IncrementMessageNotifier(@NotNull final IncrementalMessageHandler incrementalMessageHandler,
                                    @NotNull final TradeMessageHandler tradeMessageHandler,
                                    @NotNull final PrecisionClock precisionClock) {
        this.incrementalMessageHandler = Objects.requireNonNull(incrementalMessageHandler);
        this.tradeMessageHandler = Objects.requireNonNull(tradeMessageHandler);
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    @Override
    public void onConnectionStatusChange(final ConnectionStatus connectionStatus) {
        LOGGER.info("onConnectionStatusChange {}", connectionStatus);
        if (connectionStatus.isInterrupted()) {
            incrementalMessageHandler.connectionInterrupted();
        }
    }

    @Override
    public void onPriceLevelUpdate(final IncrementalServerSessionHandler session, final PriceLevelUpdate priceLevelUpdate) {
        this.incrementalMessageHandler.accept(session.instrumentDictionary());
        final long receivingTimeNanos;
        if (session.probes() instanceof RecordArrivalProbes) {
            receivingTimeNanos = ((RecordArrivalProbes) session.probes()).packetReceivedNanos();
        } else {
            receivingTimeNanos = precisionClock.nanos();
        }
        this.incrementalMessageHandler.accept(priceLevelUpdate, receivingTimeNanos);
    }

    @Override
    public void onTradePrice(final IncrementalServerSessionHandler session, final TradePrice tradePrice) {
        LOGGER.debug("onTradePrice {}", tradePrice);
        this.tradeMessageHandler.accept(session.instrumentDictionary());
        final long receivingTimeNanos;
        if (session.probes() instanceof RecordArrivalProbes) {
            receivingTimeNanos = ((RecordArrivalProbes) session.probes()).packetReceivedNanos();
        } else {
            receivingTimeNanos = precisionClock.nanos();
        }
        this.tradeMessageHandler.accept(tradePrice, receivingTimeNanos);
    }

    @Override
    public void onHeartbeat(final IncrementalServerSessionHandler session, final Heartbeat heartbeat) {
        LOGGER.debug("onHeartbeat {}", heartbeat);
    }

    @Override
    public void onSystemEvent(final IncrementalServerSessionHandler session, final SystemEvent systemEvent) {
        LOGGER.warn("onSystemEvent {}", systemEvent);
    }

    @Override
    public void close() throws IOException {
        onConnectionStatusChange(ConnectionStatus.CLOSED);
    }
}
