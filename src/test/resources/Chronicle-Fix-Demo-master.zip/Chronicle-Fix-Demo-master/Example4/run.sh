#!/bin/bash

mvn exec:java -Dexec.mainClass="software.chronicle.fix.cfg.QuickFIXUtils" -Dexec.args="target/classes/example_quickfix.ini output.cfg"
MAVEN_OPTS=-ea mvn exec:java -Dexec.mainClass="software.chronicle.fix.cfg.QuickFIXUtilsTest"

#mvn exec:java -Dinifile=target/classes/example_quickfix.ini -Doutfile=output.cfg
