package com.anz.markets.prophet.config.business;

import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.function.Consumer;

public class ConfigReader implements ChronicleObjectReader {
    private static final Logger LOGGER = LogManager.getLogger(ConfigReader.class);

    private final Consumer<ConfigurationData> consumer;

    public ConfigReader(final Consumer<ConfigurationData> consumer) {
        GcFriendlyAssert.notNull(consumer, "Empty consumer");
        this.consumer = consumer;
    }

    @NotGcFriendly("see comment inline")
    @Override
    public void processEntity(final ProphetBytes bytes,
                              final MessageType messageType) {
        // We need to make a new object here as config is different. As we have already sent down the last config object to
        // its consumers, deserialising into it here will change the config objects that the various consumers are
        // referring to directly, whereas we want to give them the ability to rebuild their config in an orderly
        // manner.
        // See also ConfigProcessor
        // Creating a bit of garbage on a rare event such as this is OK
        try {
            final ConfigurationData configurationData = new ConfigurationDataDefault();
            ((ProphetMarshallable) configurationData).readMarshallable(bytes);
            Context.overrideStartTimeStamp();
            consumer.accept(configurationData);
        } catch (Exception e) {
            LOGGER.error("Failed to process ConfigurationData", e);
        }

    }
}
