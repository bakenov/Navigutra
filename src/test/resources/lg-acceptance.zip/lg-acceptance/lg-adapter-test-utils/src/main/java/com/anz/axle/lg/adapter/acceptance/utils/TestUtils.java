package com.anz.axle.lg.adapter.acceptance.utils;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;

import net.openhft.chronicle.core.Jvm;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.matcher.TimeoutException;

public class TestUtils {

    private TestUtils() {
        throw new UnsupportedOperationException("No TestUtils for you");
    }

    public static void setupTestSystemProperties(final String appName, final String methodName) {
        final Properties sysProp = System.getProperties();
        sysProp.put(appName + ".fix.trading.host", "localhost");
        sysProp.put(appName + ".fix.pricing.host", "localhost");

        setPersistStorePath(appName, methodName);
    }

    public static void setPersistStorePath(final String appName, final String methodName) {
        final String persistMessages = appName + ".fix.persistMessages";
        System.getProperties().put(persistMessages, "N");

        final String storePath = appName + ".fix.file.store.path";
        System.getProperties().put(storePath, "target/logs/fixstore/" + methodName + "_" + System.currentTimeMillis());
        System.out.println("storePath=" + System.getProperties().getProperty(storePath));
    }

    public static int getRandomFreeLocalPort() {
        int port = random();
        for (int i = 0; i < 5; i++) {
            if (isLocalPortInUse(port)) {
                port = random();
            } else {
                return port;
            }
        }
        return port;
    }

    public static int random() {
        return (10_000) + (int) (Math.random() * 5000);
    }

    public static boolean isLocalPortInUse(final int port) {
        try {
            // ServerSocket try to open a LOCAL port
            new ServerSocket(port).close();
            // local port can be opened, it's available
            return false;
        } catch(IOException e) {
            // local port cannot be opened, it's in use
            return true;
        }
    }

    public static boolean waitFor(final BooleanSupplier test, final int timeoutMs) {
        final long endMs = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < endMs) {
            if (test.getAsBoolean()) {
                return true;
            }
            Jvm.pause(50);
        }
        return false;
    }

    public static StandardHeaderTrailer waitFor(final Queue<StandardHeaderTrailer> serverReceiveQueue,  final Predicate<? super Object> predicate, final int timeout) {
        return waitFor(serverReceiveQueue, predicate, timeout, "Waiting for...");
    }

    public static StandardHeaderTrailer waitFor(final Queue<StandardHeaderTrailer> serverReceiveQueue,  final Predicate<? super Object> predicate, final int timeout, final String text) {
        try {
            return Asserter.of(serverReceiveQueue)
                    .matching(predicate)
                    .awaitMatchAndGetLast(timeout, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            throw new RuntimeException(text, e);
        }
    }

    public static Queue<StandardHeaderTrailer> waitForAll(final Queue<StandardHeaderTrailer> serverReceiveQueue, final Predicate<? super Object> predicate, final int timeout, final String text) {
        try {
            final List<StandardHeaderTrailer> list = Asserter.of(serverReceiveQueue)
                    .matching(predicate)
                    .awaitMatchAndGetAll(timeout, TimeUnit.SECONDS);
            final Queue<StandardHeaderTrailer> queue = new LinkedList<>();
            queue.addAll(list);
            return queue;
        } catch (TimeoutException e) {
            throw new RuntimeException(text, e);
        }
    }

    public static void waitForStop(final Application application, final int retries, final int delayInMillis, final String testMethodName) {
        System.out.println("\\---------------- stopping "+ testMethodName + "...");
        application.stop();
        for (int i = 0; i < retries; i++) {
            if (application.isRunning()) {
                System.out.println("\\---------------- waitForStop waiting for "+ testMethodName + " to stop");
                Jvm.pause(delayInMillis);
                if (application.isRunning()) application.stop();
            } else {
                System.out.println("\\---------------- stopped "+ testMethodName + ".");
                return;
            }
        }
    }
}