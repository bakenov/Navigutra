package com.anz.markets.efx.fox.api.domain;

public interface UserSessionRepository {
    int onlinePortfolioSessions(String portfolio);
    UserSession userSession(UserSessionKey userSessionKey);
}
