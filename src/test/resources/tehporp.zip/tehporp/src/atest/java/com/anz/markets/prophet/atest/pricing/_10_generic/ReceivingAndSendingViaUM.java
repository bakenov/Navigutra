package com.anz.markets.prophet.atest.pricing._10_generic;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.pricing._5_triangulation.TriangulationTest_SpotOffSet_CADJPY;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.positionrisk.Positions;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class ReceivingAndSendingViaUM extends BaseAcceptanceSpecification {
    final Instrument driverPairA = Instrument.USDCAD;
    final Instrument driverPairB = Instrument.USDJPY;
    final Instrument crossPair = Instrument.CADJPY;

    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault config = tdd.configuration_pricing_base();

        final List<SyntheticInstrumentConfig> instrumentConfigs = new ArrayList<>(config.getSyntheticInstrumentConfigs());
        instrumentConfigs.add(new SyntheticInstrumentConfigImpl().setInstrument(crossPair).setMarkets("WSP_A|WSP_B|WSP_C|WSP_Z"));
        config.setSyntheticInstrumentConfigs(instrumentConfigs);

        final List<SyntheticWideningFactor> synWideningConfigs = new ArrayList<>(config.getSyntheticWideningFactors());
        synWideningConfigs.add(SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.CAD, Currency.JPY, Market.WSP_A, 1.0));
        synWideningConfigs.add(SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.CAD, Currency.JPY, Market.WSP_B, 1.0));
        synWideningConfigs.add(SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.CAD, Currency.JPY, Market.WSP_C, 1.0));
        synWideningConfigs.add(SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.CAD, Currency.JPY, Market.WSP_Z, 1.0));
        config.setSyntheticWideningFactors(synWideningConfigs);

        return config;
    }

    @RestartBeforeTest(reason = "clean start")
    @Test
    // AXPROPHET-1245
    @RelatedTest(TriangulationTest_SpotOffSet_CADJPY.class)
    public void receivingAndSendingViaUM() throws Exception {
        precondition:
        {
            ConfigurationDataDefault config = setUpConfiguration();

            prophet.startUmProbes(config, true);
            prophet.startUmOutSubscription(new Market[]{Market.WSP_U, Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z}, driverPairA);
            prophet.startUmOutSubscription(new Market[]{Market.WSP_U, Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z}, crossPair);
            prophet.receive(config);
        }
        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(1)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(2)));

            // receive fwd points vi UM for driverPairA
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, -0.44d, -0.06d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
        }
        when:
        // receive driverPairA marketData via UM
        {
            prophet.clearOutputBuffers();
            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshot(driverPairA, 1.30525, 0.0002));
        }
        then:
        // expect driverPairA chronicle out messages
        {
            FilteredMarketDataSnapshot wspU =  prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getFirst();
            assertThat(wspU.getMidRate(), isRoundedTo(1.30525));
            ClientPrice clientPriceA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getFirst();
            assertThat(clientPriceA, isClientPricePoint(0, Level.QTY_1M, 1.30522, 1.30528));
            ClientPrice clientPriceB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_B)).getFirst();
            assertThat(clientPriceB, isClientPricePoint(0, Level.QTY_1M, 1.30513, 1.30537));
            ClientPrice clientPriceC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_C)).getFirst();
            assertThat(clientPriceC, isClientPricePoint(0, Level.QTY_1M, 1.30519, 1.30531));
            ClientPrice clientPriceZ = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_Z)).getFirst();
            assertThat(clientPriceZ, isClientPricePoint(0, Level.QTY_1M, 1.30521, 1.30529));

        }
        and:
        // expect driverPairA messages on UM
        {
            FilteredMarketDataSnapshot wspU =  prophet.expectFromUm(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getFirst();
            assertThat(wspU.getMidRate(), isRoundedTo(1.30525));
            ClientPrice clientPriceA = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getFirst();
            assertThat(clientPriceA, isClientPricePoint(0, Level.QTY_1M, 1.30522, 1.30528));
            ClientPrice clientPriceB = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_B)).getFirst();
            assertThat(clientPriceB, isClientPricePoint(0, Level.QTY_1M, 1.30513, 1.30537));
            ClientPrice clientPriceC = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_C)).getFirst();
            assertThat(clientPriceC, isClientPricePoint(0, Level.QTY_1M, 1.30519, 1.30531));
            ClientPrice clientPriceZ = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_Z)).getFirst();
            assertThat(clientPriceZ, isClientPricePoint(0, Level.QTY_1M, 1.30521, 1.30529));
        }
        when:
        // receive driverPairB marketData via UM
        {
            prophet.clearOutputBuffers();
            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshot(driverPairB, 101.005, 0.006));
        }
        then:
        // expect crossPair chronicle out messages
        {
            ClientPrice clientPriceA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            assertThat(clientPriceA, isClientPricePoint(0, Level.QTY_1M, 77.38089, 77.38710));
            ClientPrice clientPriceB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_B)).getFirst();
            assertThat(clientPriceB, isClientPricePoint(0, Level.QTY_1M, 77.37556, 77.39244));
            ClientPrice clientPriceC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_C)).getFirst();
            assertThat(clientPriceC, isClientPricePoint(0, Level.QTY_1M, 77.37797, 77.39003));
            ClientPrice clientPriceZ = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_Z)).getFirst();
            assertThat(clientPriceZ, isClientPricePoint(0, Level.QTY_1M, 77.38030, 77.3877));
        }
        and:
        // expect crossPair messages on UM
        {
            ClientPrice clientPriceA = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            assertThat(clientPriceA, isClientPricePoint(0, Level.QTY_1M, 77.38089, 77.38710));
            ClientPrice clientPriceB = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_B)).getFirst();
            assertThat(clientPriceB, isClientPricePoint(0, Level.QTY_1M, 77.37556, 77.39244));
            ClientPrice clientPriceC = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_C)).getFirst();
            assertThat(clientPriceC, isClientPricePoint(0, Level.QTY_1M, 77.37797, 77.39003));
            ClientPrice clientPriceZ = prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossPair, Market.WSP_Z)).getFirst();
            assertThat(clientPriceZ, isClientPricePoint(0, Level.QTY_1M, 77.38030, 77.3877));
        }
        and:
        {
            prophet.receive(tdd.emptyMarketDataSnapshot(driverPairB));
        }
        when:
        // receive Client Deals via UM
        {
            prophet.clearOutputBuffer();
            prophet.receiveFromUm(tdd.client_trade_001(Instrument.USDCAD, 1_000_000, 0.9));
            prophet.receiveFromUm(tdd.client_trade_001(Instrument.USDCAD, -500_000, 0.9));
        }
        then:
        {
            List<Positions> positionsUpdate = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.CLIENTS_NET));
            assertThat(positionsUpdate.get(0).getPosition1().getCcy(), Matchers.is(Currency.USD));
            assertThat(positionsUpdate.get(0).getPosition1().getPositionInNotional(), Matchers.is(1_000_000.0));
            assertThat(positionsUpdate.get(0).getPosition2().getCcy(), Matchers.is(Currency.CAD));
            assertThat(positionsUpdate.get(0).getPosition2().getPositionInNotional(), Matchers.is(-900_000.0));
            assertThat(positionsUpdate.get(1).getPosition1().getCcy(), Matchers.is(Currency.USD));
            assertThat(positionsUpdate.get(1).getPosition1().getPositionInNotional(), Matchers.is(500_000.0));
            assertThat(positionsUpdate.get(1).getPosition2().getCcy(), Matchers.is(Currency.CAD));
            assertThat(positionsUpdate.get(1).getPosition2().getPositionInNotional(), Matchers.is(-450_000.0));
        }
    }

    @RestartBeforeTest(reason = "clean start")
    @Test
    // AXPROPHET-2448 consume sourceSeq coming from LG and puts it as externalSourceId in prophet client price messages
    public void sendingSnapshotWithExternalSourceIdViaUM() throws Exception{
        precondition:
        {
            ConfigurationDataDefault config = setUpConfiguration();

            prophet.startUmProbes(config, true);
            prophet.startUmOutSubscription(new Market[]{Market.WSP_U, Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z}, driverPairA);
            prophet.startUmOutSubscription(new Market[]{Market.WSP_U, Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z}, crossPair);
            prophet.receive(config);
        }
        given:
        {
            // set spot date driverPair A
            prophet.receive(new SpotDateImpl(driverPairA, LocalDate.now().plusDays(1)));

            // set spot date driverPair B
            prophet.receive(new SpotDateImpl(driverPairB, LocalDate.now().plusDays(2)));

            // receive fwd points vi UM for driverPairA
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, -0.44d, -0.06d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
        }
        when:
        // receive driverPairA marketData via UM
        {
            prophet.clearOutputBuffers();
            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshotWithExternalSourceId(driverPairA, 1.30525, 0.0002, 777L));
        }
        then:
        // expect driverPairA chronicle out messages
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_A, 777L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_B, 777L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_C, 777L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_Z, 777L));
        }
        and:
        // expect driverPairA messages on UM
        {
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_A, 777L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_B, 777L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_C, 777L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_Z, 777L));
        }
        when:
        // receive driverPairB marketData via UM
        {
            prophet.clearOutputBuffers();
            prophet.receiveSpotSnapshotFromUm(tdd.marketDataSnapshotWithExternalSourceId(driverPairB, 101.005, 0.006, 888L));
        }
        then:
        // expect driverPairB chronicle out messages
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairB, Market.WSP_A, 888L));
        }
        and:
        // expect crossPair chronicle out messages with 0 externalSourceId
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_A, 0L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_B, 0L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_C, 0L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_Z, 0L));
        }
        and:
        // expect crossPair messages on UM with 0 externalSourceId
        {
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_A, 0L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_B, 0L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_C, 0L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(crossPair, Market.WSP_Z, 0L));
        }
        when:
        // receive driverPairA marketDataINCREMENT via UM
        {
            prophet.clearOutputBuffers();
            prophet.receiveSpotIncrementalFromUm(tdd.marketDataIncrementNew(Market.CNX, driverPairA, 1.30524, 888L));
        }
        then:
        // expect driverPairA chronicle out messages
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_A, 888L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_B, 888L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_C, 888L));
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_Z, 888L));
        }
        and:
        // expect driverPairA messages on UM
        {
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_A, 888L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_B, 888L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_C, 888L));
            prophet.expectFromUm(ClientPrice.class, exactly(1), isClientPriceSourceId(driverPairA, Market.WSP_Z, 888L));
        }
    }
}
