#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axle_pub_corr_info - Plugin to monitor the axle publishing correlator info

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Daniel Hermans (daniel.hermans@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=axle
 #%# capabilities=autoconf

=cut

. $MUNIN_LIBDIR/plugins/plugin.sh

if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Axle Publishing Correlator Info'
    echo 'graph_args -l 0'
    echo 'graph_category axle'
    echo 'graph_scale no'
    echo 'size.label size mb'
    echo 'size.info Total Memory Usage'
    echo 'size.draw LINE2'
    echo 'rss.label rss mb'
    echo 'rss.draw LINE2'
    echo 'threads.label threads'
    echo 'threads.draw LINE2'
    #echo 'numfiles.label open files'
    #echo 'numfiles.draw LINE2'
    exit 0
fi

CORRELATOR_PIDFILE=~/axle/fxagg-publisher/fxagg-core/logs/Correlator-FxAgg.pid

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ ! -f ${CORRELATOR_PIDFILE} ] ; then
        echo "size.value U"
        echo "rss.value U"
        echo "threads.value U"
        exit 0
fi

CORRELATOR_PID=$(cat ${CORRELATOR_PIDFILE})
if [ ! -d /proc/${CORRELATOR_PID} ] ; then
        echo "size.value U"
        echo "rss.value U"
        echo "threads.value U"
        exit 0
fi

prstat -p ${CORRELATOR_PID} 1 1 | grep correlator | while read pid user size rss state pri nice time cpu name
do
        echo "size.value $(echo $size | sed 's/M//' | sed 's/G/*1024/' | bc)"
        echo "rss.value $(echo $rss | sed 's/M//' |  sed 's/G/*1024/' | bc)"
        echo "threads.value $(echo "$name" | cut -d/ -f2)"
done

