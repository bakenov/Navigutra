package com.anz.markets.efx.ngaro.sbe;

import org.junit.Test;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.ByteReader;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link FixedStringEncoder}
 */
public class FixedStringEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test(expected = NullPointerException.class)
    public void noNullSource() {
        StringEncoders.forFixedLength(ENCLOSING_ENCODER, null, 7);
    }

    @Test(expected = IllegalArgumentException.class)
    public void noNegativeLength() {
        StringEncoders.forFixedLength(ENCLOSING_ENCODER, (i,b) -> {}, -1);
    }

    @Test
    public void encodeEmpty() throws Exception {
        //given
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int len = 3;
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final StringEncoder<?> enc = StringEncoders.forFixedLength(ENCLOSING_ENCODER, target, len);

        //when
        enc.encodeEmpty();

        //then
        assertEquals("result should contain empty value at " + offset, "abc\0\0\0ghijklmno", result.toString());
    }

    @Test
    public void encodeFromCharSequence() throws Exception {
        //given
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int len = 6;
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final StringEncoder<?> enc = StringEncoders.forFixedLength(ENCLOSING_ENCODER, target, len);

        //when
        enc.encode("1234567");

        //then
        assertEquals("result should contain 123456 at " + offset, "abc123456jklmno", result.toString());

        //when
        enc.encode("UVWXYZ", 3, 3);

        //then
        assertEquals("result should contain XYZ at " + offset, "abcXYZ\0\0\0jklmno", result.toString());
    }

    @Test
    public void encodeFromByteReader() throws Exception {
        //given
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int len = 6;
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final StringEncoder<?> enc = StringEncoders.forFixedLength(ENCLOSING_ENCODER, target, len);

        //when
        enc.encode("1234567", ByteReader.CHAR_SEQUENCE, len);

        //then
        assertEquals("result should contain 123456 at " + offset, "abc123456jklmno", result.toString());

        //when
        enc.encode("UVWXYZ", ByteReader.CHAR_SEQUENCE, 3, 3);

        //then
        assertEquals("result should contain XYZ at " + offset, "abcXYZ\0\0\0jklmno", result.toString());
    }

    @Test
    public void encodeFromStringDecoder() throws Exception {
        //given
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int len = 6;
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final StringEncoder<?> enc = StringEncoders.forFixedLength(ENCLOSING_ENCODER, target, len);
        final String input = "123456";
        final StringDecoder dec = StringDecoders.forFixedLength(i -> (byte)input.charAt(i), input.length());

        //when
        enc.encodeFrom(dec);

        //then
        assertEquals("result should contain 123456 at " + offset, "abc123456jklmno", result.toString());
    }

}