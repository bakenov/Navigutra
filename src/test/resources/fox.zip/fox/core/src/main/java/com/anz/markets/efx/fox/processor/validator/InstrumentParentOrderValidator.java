package com.anz.markets.efx.fox.processor.validator;

import java.util.Objects;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class InstrumentParentOrderValidator implements ParentOrderValidator {
    private final InstrumentRepository instrumentRepository;
    private final ErrorHandler errorHandler;
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);


    public InstrumentParentOrderValidator(final ErrorHandler handler, final InstrumentRepository instrumentRepository) {
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
        this.errorHandler = Objects.requireNonNull(handler);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {

        final long instrumentId = InstrumentKey.instrumentId(parentOrderDecoder.body().symbol().decodeAndCache(symbolCache),
                parentOrderDecoder.body().securityType(),
                parentOrderDecoder.body().settlType());
        final Instrument instrument = instrumentRepository.lookup(instrumentId);
        if (instrument != null) {
            if (instrument.enabled()) {
                return true;
            } else {
                errorHandler.onError(OrderTextMessage.DISABLED_INSTRUMENT.getText(), parentOrderDecoder, commandContext);
                return false;
            }
        }

        errorHandler.onError(OrderTextMessage.UNKNOWN_INSTRUMENT.getText(), parentOrderDecoder, commandContext);
        return false;
    }
}
