package com.anz.markets.disco.modules;

import com.anz.markets.disco.InputModule;
import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.ArrayList;
import java.util.function.BiFunction;

/**
 * A list of cloned messages - useful for testing.
 */
public class EventCollectorModule extends AbstractModule {

    private final ArrayList<Data> data = new ArrayList<>();

    private BiFunction<Symbol, Object, Object> copier;

    public EventCollectorModule(final BiFunction<Symbol, Object, Object> copier) {
        this.copier = copier;
    }

    private class Data {
        final Symbol messageType;
        final Object message;

        public Data(final Symbol messageType, final Object message) {
            this.message = message;
            this.messageType = messageType;
        }

        public Object getMessage() {
            return message;
        }

        public Symbol getMessageType() {
            return messageType;
        }
    }

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.subAnyPrior(this::collectData);
    }

    private void collectData(Symbol messageType, Object message) {
        final Object copy = copier.apply(messageType, message);
        GcFriendlyAssert.notNull(copy, "Copier failed for %s.", messageType);
        data.add(new Data(messageType, copy));
    }

    public void clear() {
        data.clear();
    }

    public ArrayList<Data> getData() {
        return data;
    }

    public InputModule createInputModule() {
        return new AbstractInputModule("Event Collector Input (N=" + data.size() + ")") {
            @Override
            public Runnable createInputRunnable() {
                return () -> {
                    for (int i = 0; i < data.size(); i++) {
                        final Data d = data.get(i);
                        getStage().getMessageBus().pub(d.messageType, d.message);
                    }
                };
            }
        };
    }

}
