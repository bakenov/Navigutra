package com.anz.markets.efx.fox.aggregator.config;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.BusySpinIdleStrategy;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.eventloop.IdleStrategyId;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Transport;

@Configuration
public class CommonConfig {
    @Bean
    public PrecisionClock precisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("async-%d").build());
    }

    @Bean
    public EndPointStatusHandler transportEndPointStatusHandler() {
        return new LoggingEndPointStatusHandler(LoggerFactory.getLogger(Transport.class));
    }

    @Bean
    public Supplier<IdleStrategy> idleStrategySupplier(final @Value("${idle.strategy}") IdleStrategyId idleStrategyId,
                                                       final @Value("${idle.strategy.backoff.maxSpins}") long backOffMaxSpins,
                                                       final @Value("${idle.strategy.backoff.maxYields}") long backOffMaxYields,
                                                       final @Value("${idle.strategy.backoff.maxParkPeriodUs}") long backOffMaxParkPeriodUs) {
        return idleStrategyFactory(idleStrategyId, backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs);
    }

    public static Supplier<IdleStrategy> idleStrategyFactory(final IdleStrategyId idleStrategyId,
                                                             final long backOffMaxSpins,
                                                             final long backOffMaxYields,
                                                             final long backOffMaxParkPeriodUs) {
        return () -> {
            switch (idleStrategyId) {
                case BUSY_SPIN:
                    return adaptIdleStrategy(new BusySpinIdleStrategy());
                case BACK_OFF:
                    return adaptIdleStrategy(new BackoffIdleStrategy(backOffMaxSpins, backOffMaxYields, 1, TimeUnit.MICROSECONDS.toNanos(backOffMaxParkPeriodUs)));
                default:
                    throw new IllegalArgumentException("Unsupported idle strategy " + idleStrategyId);
            }
        };
    }

    static IdleStrategy adaptIdleStrategy(final org.agrona.concurrent.IdleStrategy strategy) {
        return IdleStrategy.create(strategy::idle, strategy::reset);
    }
}
