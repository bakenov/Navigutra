#!/bin/bash

echo "" | mailx -r "build.box@anz.com" -s "PINK ENV - starting restart" "axletest@anz.com"

ssh AxlSv@daxa005z 'rm -rf ~axle/axle/datafabric/workspace/*'

ssh AxlSv@daxa005z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh && sleep 5 && ./stop-datafabric.sh && sleep 5 && ./start-datafabric.sh'

ssh axle@daxa008z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'
ssh AxlSv@daxa002z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'

echo "" | mailx -r "build.box@anz.com" -s "PINK ENV - FINISHED restart" "axletest@anz.com"
