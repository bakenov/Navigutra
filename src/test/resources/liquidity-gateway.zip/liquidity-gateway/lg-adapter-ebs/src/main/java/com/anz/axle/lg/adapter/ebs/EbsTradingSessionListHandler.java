package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.TradingSessionList_TradingSessionsGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradingSessionList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public class EbsTradingSessionListHandler implements ChronicleMessageHandler<TradingSessionList> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsTradingSessionListHandler.class);

    private final TradingSessionRepository tradingSessionRepository;
    private final TradingSessionParser tradingSessionParser;

    public EbsTradingSessionListHandler(final TradingSessionRepository tradingSessionRepository,
                                        final TradingSessionParser tradingSessionParser) {
        this.tradingSessionRepository = Objects.requireNonNull(tradingSessionRepository);
        this.tradingSessionParser = Objects.requireNonNull(tradingSessionParser);
    }

    @Override
    public void accept(final TradingSessionList message) throws IllegalArgumentException {
        LOGGER.info("Received: {}", message);
        tradingSessionRepository.reset();

        for (int i = 0; i < message.noTradingSessions(); i++) {
            final TradingSessionList_TradingSessionsGrp_1 sessionsGrp = message.tradingSessionList_TradingSessionsGrp_1(i);
            tradingSessionRepository.addOrUpdate(tradingSessionParser.parse(sessionsGrp));
        }
    }
}
