package com.anz.axle.lg.adapter.apama.event;

import com.apama.event.Event;
import com.apama.event.parser.Field;
import com.apama.event.parser.StringFieldType;

import com.anz.markets.efx.pricing.codec.api.EntryType;


public class MdEntryTypeField extends Field<String> {

    public MdEntryTypeField() {
        super("MDEntryType", StringFieldType.TYPE);
    }

    public EntryType getSide(final Event mdEntry) {
        final String mdEntryType = mdEntry.getField(this);

        if (mdEntryType == null || mdEntryType.length() != 1) {
            return null;
        }
        switch (mdEntryType.charAt(0)) {
            case '0':
                return EntryType.BID;
            case '1':
                return EntryType.OFFER;
            default:
                return null;
        }
    }
}
