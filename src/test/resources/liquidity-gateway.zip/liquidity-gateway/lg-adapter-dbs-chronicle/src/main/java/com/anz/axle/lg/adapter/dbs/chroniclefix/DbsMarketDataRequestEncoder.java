package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import com.anz.axle.lg.adapter.chroniclefix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.components.MarketDataRequest_RelatedSymGrp_1;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.MDEntryType;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.MDUpdateType;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.SecurityType;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.SubscriptionRequestType;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MarketDataRequest;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.datamodel.DefaultMarketDataRequest;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.markets.efx.ngaro.api.Tenor;

public class DbsMarketDataRequestEncoder implements MarketDataRequestEncoder<MarketDataRequest> {

    private final DefaultMarketDataRequest marketDataRequest = new DefaultMarketDataRequest();
    private static final Optional<Tenor> SPOT = Optional.of(Tenor.SP);
    private final Map<Tenor, String> tenors;

    public DbsMarketDataRequestEncoder(final Map<Tenor, String> tenors) {
        this.tenors = Objects.requireNonNull(tenors);
        marketDataRequest.noMDEntryTypes(2);
        marketDataRequest.marketDataRequest_MDEntryTypesGrp_1(0).mDEntryType(MDEntryType.BID);
        marketDataRequest.marketDataRequest_MDEntryTypesGrp_1(1).mDEntryType(MDEntryType.OFFER);
    }

    @Override
    public MarketDataRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(marketDataRequest, requestId, subscription, SubscriptionRequestType.SUBSCRIBE);
    }

    @Override
    public MarketDataRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(marketDataRequest, requestId, subscription, SubscriptionRequestType.UNSUBSCRIBE);
    }

    private MarketDataRequest encode(final MarketDataRequest marketDataRequest, final long requestId, final MarketDataSubscription subscription, final char subscriptionRequestType) {

        marketDataRequest.mDReqID(marketDataRequest.mDReqID_buffer());
        marketDataRequest.mDReqID().append(requestId);
        marketDataRequest.subscriptionRequestType(subscriptionRequestType);
        marketDataRequest.marketDepth(subscription.marketDepth());
        marketDataRequest.mDUpdateType(MDUpdateType.INCREMENTAL_REFRESH);

        marketDataRequest.noRelatedSym(1);
        final MarketDataRequest_RelatedSymGrp_1 marketDataRequest_relatedSymGrp_1 = marketDataRequest.marketDataRequest_RelatedSymGrp_1(0);
        marketDataRequest_relatedSymGrp_1.symbol(subscription.symbol());
        marketDataRequest_relatedSymGrp_1.securityType(securityType(subscription.instrumentKey().securityType()));
        if (subscription.instrumentKey().tenor() != Tenor.SP) {
            marketDataRequest_relatedSymGrp_1.tenor(tenor(subscription.instrumentKey().tenor()));
        } else {
            marketDataRequest_relatedSymGrp_1.tenor(null);
        }
        return marketDataRequest;
    }

    private String securityType(final com.anz.markets.efx.ngaro.api.SecurityType type) {
        switch (type) {
            case FXSPOT: return SecurityType.SPOT;
            case FXNDF: return SecurityType.NDF;
            case FXFWD: return SecurityType.FORWARD;
            default: return "";
        }
    }

    private String tenor(final Tenor tenor) {
        final String ftTenor = tenors.get(tenor);
        if (ftTenor == null) {
            throw new IllegalArgumentException("No DBS tenor known for: " + ftTenor);
        }
        return ftTenor;
    }

}
