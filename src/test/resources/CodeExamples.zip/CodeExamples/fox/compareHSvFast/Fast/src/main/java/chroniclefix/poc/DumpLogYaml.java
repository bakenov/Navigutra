package chroniclefix.poc;

import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.parsers.MessageParser;

public class DumpLogYaml {
    public static void main(String[] args) {
        new software.chronicle.fix.tools.DumpLogYaml(new MessageParser(), MessageNotifier.class).dump(args[0]);
    }
}
