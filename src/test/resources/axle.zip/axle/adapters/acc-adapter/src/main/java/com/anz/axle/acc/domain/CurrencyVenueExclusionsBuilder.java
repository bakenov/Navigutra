package com.anz.axle.acc.domain;

import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditState;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("currencyVenueExclusionsBuilder")
public class CurrencyVenueExclusionsBuilder implements Builder<Collection<CurrencyVenueExclusion>, CurrentVenueCurrencyCreditStates> {

    @Autowired
    @Qualifier("currencyVenueExclusionBuilder")
    private Builder<CurrencyVenueExclusion, CurrentVenueCurrencyCreditState> builder;

    @Override
    public Collection<CurrencyVenueExclusion> build(CurrentVenueCurrencyCreditStates input) throws BuilderException {
        Collection<CurrencyVenueExclusion> exclusions = new ArrayList<CurrencyVenueExclusion>();
        for(CurrentVenueCurrencyCreditState thisState : input.findAll()) {
            exclusions.add(builder.build(thisState));
        }
        return exclusions;
    }

    /**
     * testing purposes only.
     * @param builder
     */
    public void setBuilder(Builder<CurrencyVenueExclusion, CurrentVenueCurrencyCreditState> builder) {
        this.builder = builder;
    }
}
