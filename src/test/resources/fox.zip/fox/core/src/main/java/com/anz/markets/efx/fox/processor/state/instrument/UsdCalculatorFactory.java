package com.anz.markets.efx.fox.processor.state.instrument;

import java.util.Objects;
import java.util.function.DoubleUnaryOperator;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.api.domain.Instrument;

public class UsdCalculatorFactory implements Supplier<DoubleUnaryOperator> {
    private final static String USD = "USD";
    private final static DoubleUnaryOperator IDENTITY = nominalAmount -> nominalAmount;

    private final Instrument instrument;
    private final String base;
    private final String baseUsd;
    private final String usdBase;

    public UsdCalculatorFactory(final Instrument instrument) {
        this.instrument = Objects.requireNonNull(instrument);
        this.base = instrument.key().symbol().substring(0, 3);
        this.baseUsd = base + USD;
        this.usdBase = USD + base;
    }

    @Override
    public DoubleUnaryOperator get() {
        if (base.equals(USD)) {
            return IDENTITY;
        }
        if (instrument.key().symbol().equals(baseUsd)) {
            return baseUsdCalculator(instrument);
        }
        final Instrument baseUsdInstrument = instrument.drivingInstrument(baseUsd);
        if (baseUsdInstrument != null) {
            return baseUsdCalculator(baseUsdInstrument);
        } else {
            final Instrument usdBaseInstrument = instrument.drivingInstrument(usdBase);
            if (usdBaseInstrument != null) {
                return nominalAmount -> {
                    final double midPrice = baseUsdInstrument.consensusMidPrice();
                    if (Double.isNaN(midPrice)) return Double.NaN;
                    return nominalAmount / midPrice;
                };
            }
        }
        return null;
    }

    private DoubleUnaryOperator baseUsdCalculator(final Instrument instrument) {
        return nominalAmount -> {
            final double midPrice = instrument.consensusMidPrice();
            if (Double.isNaN(midPrice)) return Double.NaN;
            return nominalAmount * midPrice;
        };
    }
}
