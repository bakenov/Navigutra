package com.anz.markets.prophet.pricer.wholesale.spreads;

import com.anz.markets.prophet.pricer.wholesale.AbstractEconomicsNewsSpreadStrategyForBwJmhTest;
import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

public class EconomicsNewsSpreadStrategyBWTest extends AbstractEconomicsNewsSpreadStrategyForBwJmhTest {

    private static final int REPS = 100_000;
    private static final int THRESHOLD = 0;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();

    public EconomicsNewsSpreadStrategyBWTest() {
        super();
        warmUp();
    }

    private void warmUp() {
        testAcceptWholesaleBookRepeatedly();
    }

    private void testAcceptWholesaleBookRepeatedly() {
        for (int i = 0; i < REPS; i++) {
            testAcceptWholesaleBook();
        }
    }

    @Test
    public void test_AllocationNotExceededForWholesaleBook() {
        helper.testAllocationNotExceeded(
                this::testAcceptWholesaleBookRepeatedly,
                THRESHOLD // no allocation!
        );
    }
}
