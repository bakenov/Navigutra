package com.anz.markets.prophet.atest.risk._3_optimalposition;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.domain.CovarianceCategory;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.efx.ngaro.collections.EnumDoubleTable;
import com.anz.markets.efx.ngaro.collections.EnumSet;
import com.anz.markets.prophet.domain.impl.CovCorrAvgsImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.google.common.collect.Lists;
import org.joda.time.DateTimeConstants;
import org.junit.Test;

import java.util.List;
import java.util.Random;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

public class OptimalPositionTest extends BaseAcceptanceSpecification {

    private static final java.util.EnumSet OPTIMAL_POSITION_INSTRUMENTS = java.util.EnumSet.of(
            Instrument.AUDJPY,
            Instrument.AUDNZD,
            Instrument.AUDUSD,
            Instrument.EURAUD,
            Instrument.EURCHF,
            Instrument.EURCZK,
            Instrument.EURDKK,
            Instrument.EURGBP,
            Instrument.EURHUF,
            Instrument.EURJPY,
            Instrument.EURNOK,
            Instrument.EURPLN,
            Instrument.EURSEK,
            Instrument.EURUSD,
            Instrument.GBPJPY,
            Instrument.GBPUSD,
            Instrument.NZDUSD,
            Instrument.USDCAD,
            Instrument.USDCHF,
            Instrument.USDCNH,
            Instrument.USDHKD,
            Instrument.USDILS,
            Instrument.USDJPY,
            Instrument.USDMXN,
            Instrument.USDSGD,
            Instrument.USDTHB,
            Instrument.USDTRY,
            Instrument.USDZAR
    );

    private static final Currency[] TEST_CURRENCIES = new Currency[] {Currency.AUD, Currency.CAD, Currency.CHF, Currency.CNH, Currency.CZK
            , Currency.DKK, Currency.EUR, Currency.GBP, Currency.HKD, Currency.HUF, Currency.ILS, Currency.JPY
            , Currency.MXN, Currency.NOK, Currency.NZD, Currency.PLN, Currency.SEK, Currency.SGD, Currency.THB
            , Currency.TRY, Currency.XAG, Currency.XAU, Currency.XPD, Currency.XPT, Currency.ZAR};

    private static final CovarianceCategory[] TEST_CATEGORIES = new CovarianceCategory[] {CovarianceCategory.COV_A, CovarianceCategory.COV_M};

    @Test
    @DisplayName("Make sure that OP changes on Position change.")
    @RestartBeforeTest(reason = "OP remember positions.")
    public void S0_WHEN_trade_received_calculate_optimal_positions() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75)); // Trigger : position created
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(2), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(2));
            final List<OptimalPositions> biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(2), isOptimalPositionType(OptimalPositionType.PRICING_BIAS));
            assertThat(biasOptimalPositionsUpdates.size(), is(2));

            and:
            // op from hour chime - should have no ops
            {
                final OptimalPositions actualOptimalPositionsFromPriceChange0 = optimalPositionsUpdates.get(0);
                assertThat(actualOptimalPositionsFromPriceChange0, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.AUDUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURJPY));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.NZDUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.USDJPY));

                final OptimalPositions actualBiasedOptimalPositionsFromPriceChange0 = biasOptimalPositionsUpdates.get(0);
                assertThat(actualBiasedOptimalPositionsFromPriceChange0, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

                assertThat(actualBiasedOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.AUDUSD));
                assertThat(actualBiasedOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURUSD));
                assertThat(actualBiasedOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURJPY));
                assertThat(actualBiasedOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.NZDUSD));
                assertThat(actualBiasedOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.USDJPY));
            }
            and:
            {
                final OptimalPositions actualOptimalPositionsFromPositionChange4 = optimalPositionsUpdates.get(1);
                assertThat(actualOptimalPositionsFromPositionChange4, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

                assertThat(actualOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
                assertThat(actualOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
                assertThat(actualOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(actualOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
                assertThat(actualOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94063.46248900656, -94063.46248900656, 0.0, 0.0, -0.005282478906068361, Double.NaN)));

                final OptimalPositions actualBiasedOptimalPositionsFromPositionChange4 = biasOptimalPositionsUpdates.get(1);
                assertThat(actualBiasedOptimalPositionsFromPositionChange4, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

                assertThat(actualBiasedOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
                assertThat(actualBiasedOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
                assertThat(actualBiasedOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(actualBiasedOptimalPositionsFromPositionChange4, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
            }
        }
    }

    @Test
    @RestartBeforeTest(reason = "OP remember positions.")
    // AXPROPHET-892 co var matrix can be updated via kdb
    // same setup as S0_WHEN_trade_received_calculate_optimal_positions but with different CoVar matrix
    public void loadNewCoVarFromKdb() {
        final Random r = new Random();
        final List<CovCorrAvgsImpl> inputData = Lists.newArrayList();

        final EnumDoubleTable<Currency, Currency> covarianceTable = new EnumDoubleTable<>(Currency.class, Currency.class);
        final EnumSet<Currency> currencies = new EnumSet<>(Currency.class);
        for (Currency c : TEST_CURRENCIES) {
            currencies.add(c);
        }

        for (int hourOfDay = 0; hourOfDay< DateTimeConstants.HOURS_PER_DAY; hourOfDay++) {
            for (CovarianceCategory category : TEST_CATEGORIES) {
                for (Currency iCurrency : TEST_CURRENCIES) {
                    for (Currency jCurrency : TEST_CURRENCIES) {
                        covarianceTable.put(iCurrency, jCurrency, r.nextDouble());
                    }
                }
                inputData.add(new CovCorrAvgsImpl(category, hourOfDay, currencies, covarianceTable));
            }
        }

        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
        }
        when:
        // receive new co var matrix i.e config updated from kdb
        {

            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));  // no OP change as position=0
            prophet.clearOutputBuffer();
            inputData.forEach(cc -> prophet.receive(cc));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75)); // Trigger : position created
        }
        then:
        // different gradient position compared to atest S0_WHEN_trade_received_calculate_optimal_positions due to different co var matrix()
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
        }
    }

    @Test
    @DisplayName("Make sure that OP does not change on EMPTY BOOK.")
    @RestartBeforeTest(reason = "caches op")
    public void S1_WHEN_empty_books_sent_ep_unchanged() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));  // no OP change as position=0
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75)); // Trigger : position created
        }
        when:
        {
            // this is a good test and Position changes in USD, but not in Notional so the USD position change does not impact OP calculation
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.AUDUSD)); // No Trigger : position rate withdrawn so no Notional for AUD
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(2), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(2));

            final List<OptimalPositions> biasedOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(2), isOptimalPositionType(OptimalPositionType.PRICING_BIAS));
            assertThat(biasedOptimalPositionsUpdates.size(), is(2));


            // op from hour chime - should have no ops
            final OptimalPositions actualOptimalPositionsFromPriceChange0 = optimalPositionsUpdates.get(0);
            assertThat(actualOptimalPositionsFromPriceChange0, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

            assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.AUDUSD));
            assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURUSD));
            assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURJPY));
            assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.NZDUSD));
            assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.USDJPY));

            final OptimalPositions optimalPositionsFromPriceChange = optimalPositionsUpdates.get(1);
            assertThat(optimalPositionsFromPriceChange, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));
            //@TODO review since rate is pulled maybe EP should be pulled?
            assertThat(optimalPositionsFromPriceChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1000000.0, 750000.0, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
            assertThat(optimalPositionsFromPriceChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
            assertThat(optimalPositionsFromPriceChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
            assertThat(optimalPositionsFromPriceChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
            assertThat(optimalPositionsFromPriceChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94063.46248900656, -94063.46248900656, 0.0, 0.0, -0.005282478906068361, Double.NaN)));
        }
    }

    @Test
    @DisplayName("Make sure that OP changes on price change.")
    @RestartBeforeTest(reason = "caches op")
    public void S2_WHEN_rate_changed_received_calculate_optimal_positions() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
            prophet.receive(tdd.hourChime(13)); // TRIGGER : OP change new covar #1
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001)); // no OP change : as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));  // no OP change : as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));  // no OP change : as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));  // no OP change : as position=0
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75)); // TRIGGER : position created #2
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.7507, 0.001)); // no OP change: less than 1k value change change
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.7515, 0.001)); // TRIGGER : greater than 1k value change #3
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(4), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(4));

            final List<OptimalPositions> biasOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(4), isOptimalPositionType(OptimalPositionType.PRICING_BIAS));
            assertThat(biasOptimalPositionsUpdates.size(), is(4));

            and:
            // op from hour chime - should have no ops
            {
                final OptimalPositions actualOptimalPositionsFromPriceChange0 = optimalPositionsUpdates.get(0);
                assertThat(actualOptimalPositionsFromPriceChange0, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.AUDUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURJPY));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.NZDUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.USDJPY));
            }
            and:
            {
                OptimalPositions opChange = optimalPositionsUpdates.get(1);
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94063.46248900656, -94063.46248900656, 0.0, 0.0, -0.005282478906068361, Double.NaN)));

                OptimalPositions biasOpChange = optimalPositionsUpdates.get(1);
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.1492038166887317, 0.75)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54231.4103881931, 54231.4103881931, 0.0, 0.0, 0.022622843272959443, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41575.34729192583, 41575.34729192583, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 309811.0824176717, 309811.0824176717, 0.0, 0.0, 0.07034788870688735, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94063.46248900656, -94063.46248900656, 0.0, 0.0, -0.005282478906068361, Double.NaN)));

            }
            and:
            {
                OptimalPositions opChange = optimalPositionsUpdates.get(2);
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 750700.0, 1500000.0, 1126050.0, 0.1492038166887317, 0.7507)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54282.026, 54282.026, 0.0, 0.0, 0.022622843272959443, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41614.1509, 41614.1509, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 310100.2394, 310100.2394, 0.0, 0.0, 0.07034788870688737, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94151.255, -94151.255, 0.0, 0.0, -0.005282478906068361, Double.NaN)));

                OptimalPositions biasOpChange = optimalPositionsUpdates.get(2);
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 750700.0, 1500000.0, 1126050.0, 0.1492038166887317, 0.7507)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54282.026, 54282.026, 0.0, 0.0, 0.022622843272959443, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41614.1509, 41614.1509, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 310100.2394, 310100.2394, 0.0, 0.0, 0.07034788870688737, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94151.255, -94151.255, 0.0, 0.0, -0.005282478906068361, Double.NaN)));
            }
            and:
            {
                OptimalPositions opChange = optimalPositionsUpdates.get(3);
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 751_500, 1500000.0, 1127250.0, 0.1492038166887317, 0.7515)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54339.87320896949, 54339.87320896949, 0.0, 0.0, 0.022622843272959447, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41658.497986509676, 41658.497986509676, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 310430.704582507, 310430.704582507, 0.0, 0.0, 0.07034788870688737, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94251.58941398458, -94251.58941398458, 0.0, 0.0, -0.005282478906068362, Double.NaN)));

                OptimalPositions biasOpChange = optimalPositionsUpdates.get(3);
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1000000.0, 1_000_000, 751_500, 1500000.0, 1127250.0, 0.1492038166887317, 0.7515)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, Double.NaN, 54339.87320896949, 54339.87320896949, 0.0, 0.0, 0.022622843272959447, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, Double.NaN, 41658.497986509676, 41658.497986509676, 0.0, 0.0, 0.017340364366891084, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, Double.NaN, 310430.704582507, 310430.704582507, 0.0, 0.0, 0.07034788870688737, 1.0)));
                assertThat(biasOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, Double.NaN, -94251.58941398458, -94251.58941398458, 0.0, 0.0, -0.005282478906068362, Double.NaN)));
            }
        }
    }

    @Test
    @DisplayName("Make sure that OP changes on hour change.")
    @RestartBeforeTest(reason = "caches op")
    public void S3_WHEN_covar_changes_on_hour_calculate_optimal_positions() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base(), false);
            prophet.receive(tdd.hourChime(13)); // TRIGGER : OP change new covar #1
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.001)); // no OP change : as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.0, 0.001));  // no OP change : as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURJPY, 1.0, 0.001));  // no OP change : as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.NZDUSD, 1.0, 0.001));  // no OP change : as position=0
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75)); // TRIGGER : position created #2
        }
        when:
        {
            prophet.receive(tdd.hourChime(21)); // #TRIGGER : covariance changed
        }
        then:
        {
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(3), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(3));

            final List<OptimalPositions> biasedOptimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(3), isOptimalPositionType(OptimalPositionType.PRICING_BIAS));
            assertThat(biasedOptimalPositionsUpdates.size(), is(3));

            and:
            // op from hour chime - should have no ops
            {
                final OptimalPositions actualOptimalPositionsFromPriceChange0 = optimalPositionsUpdates.get(0);
                assertThat(actualOptimalPositionsFromPriceChange0, hasInstruments(OPTIMAL_POSITION_INSTRUMENTS));

                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.AUDUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.EURJPY));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.NZDUSD));
                assertThat(actualOptimalPositionsFromPriceChange0, hasNoOptimalPositionFor(Instrument.USDJPY));
            }
            and:
            {
                OptimalPositions opChange = optimalPositionsUpdates.get(2);
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1_000_000, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.07830374401231993, 0.75)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 20734.30967935893, 20734.30967935893, 0.0, 0.0, 0.0013779566826832125, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 10931.917362932638, 10931.917362932638, 0.0, 0.0, 0.0010435026579732102, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 70997.5432826259, 70997.5432826259, 0.0, 0.0, 0.021296349211542207, 1.0)));
                assertThat(opChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 0.0, -9692.008859353595, -9692.008859353595, 0.0, 0.0, -0.0003344540247100023, Double.NaN)));

                OptimalPositions biasedOpChange = biasedOptimalPositionsUpdates.get(2);
                assertThat(biasedOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.AUDUSD, 1_000_000, 1_000_000, 750_000, 1500000.0, 1125000.0, 0.07830374401231993, 0.75)));
                assertThat(biasedOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURUSD, 0.0, 20734.30967935893, 20734.30967935893, 0.0, 0.0, 0.0013779566826832125, 1.0)));
                assertThat(biasedOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.EURJPY, 0.0, 10931.917362932638, 10931.917362932638, 0.0, 0.0, 0.0010435026579732102, 1.0)));
                assertThat(biasedOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.NZDUSD, 0.0, 70997.5432826259, 70997.5432826259, 0.0, 0.0, 0.021296349211542207, 1.0)));
                assertThat(biasedOpChange, isOptimalPosition(tdd.optimalPosition(Instrument.USDJPY, 0.0, -9692.008859353595, -9692.008859353595, 0.0, 0.0, -0.0003344540247100023, Double.NaN)));
            }
        }
    }
}
