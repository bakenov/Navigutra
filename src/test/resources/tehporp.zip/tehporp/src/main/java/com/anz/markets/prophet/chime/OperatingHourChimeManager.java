package com.anz.markets.prophet.chime;

import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedOperatingHourConfig;
import com.anz.markets.prophet.domain.IntHolder;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

/**
 * Chime for all entity at the start and when receives new config and then only chime for changes.
 */
public class OperatingHourChimeManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(OperatingHourChimeManager.class);
    private static final int THIRTY_SECONDS = 30;

    private final IntHolder holder = new IntHolder();
    private final Consumer<OperatingHourChime> operatingHourChimeConsumer;
    private final EnumObjMap<OperatingHourEntity, OperatingHourChime> entityState = new EnumObjMap<>(OperatingHourEntity.class);
    private IndexedOperatingHourConfig indexedOperatingHourConfig;
    private boolean hasPublishedAtLeastOnce = false;

    public OperatingHourChimeManager(final Consumer<OperatingHourChime> operatingHourChimeConsumer) {
        this.operatingHourChimeConsumer = operatingHourChimeConsumer;

        for (final OperatingHourEntity entity : OperatingHourEntity.values()) {
            final OperatingHourChime operatingHourChime = new OperatingHourChime();
            operatingHourChime.setEntity(entity);
            entityState.put(entity, operatingHourChime);
        }
    }

    public Consumer<IndexedConfigurationData> consumerOfIndexedConfigurationData() {
        return indexedConfigurationData -> {
            this.indexedOperatingHourConfig = indexedConfigurationData.getIndexedOperatingHourConfig();
            entityState.forEach((operatingHourEntity, previousSpecification) -> {
                if (!indexedOperatingHourConfig.hasConfig(operatingHourEntity)) {
                    LOGGER.warn("operatingHourConfig is not defined for {}. Please configure this or remove it from enum.", operatingHourEntity);
                }
            });
        };
    }

    /**
     * Send chime if new specification becomes effective.
     */
    public Consumer<OneSecond> consumerOfOneSecond() {
        return oneSecond -> {
            holder.increment();
            // only perform the operating hour check every minute
            if (isConfigured() && holder.value >= THIRTY_SECONDS) {
                    holder.reset();
                    entityState.forEach((operatingHourEntity, previousSpecification) -> {
                    OperatingHourSpecification effectiveSpecificationForNow;
                    if (indexedOperatingHourConfig.hasConfig(operatingHourEntity)) {
                        effectiveSpecificationForNow = indexedOperatingHourConfig.getEffectiveSpecificationForNow(operatingHourEntity);
                    } else {
                        // default anything that is not configured to undefined.
                        effectiveSpecificationForNow = OperatingHourSpecification.UNDEFINED;
                    }
                    // ensure that chime is sent for all entity at least once.
                    if (!hasPublishedAtLeastOnce || !effectiveSpecificationForNow.equals(previousSpecification.getSpecification())) {
                        LOGGER.info("Changed from {} to {}", previousSpecification.getSpecification(), effectiveSpecificationForNow);
                        previousSpecification.getSpecification().set(effectiveSpecificationForNow);
                        operatingHourChimeConsumer.accept(previousSpecification);
                    }
                });
                hasPublishedAtLeastOnce = true;
            }
        };
    }

    private boolean isConfigured() {
        return indexedOperatingHourConfig != null;
    }
}
