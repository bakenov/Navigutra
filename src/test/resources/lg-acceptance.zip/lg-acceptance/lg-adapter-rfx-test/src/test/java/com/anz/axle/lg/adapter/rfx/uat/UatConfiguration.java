package com.anz.axle.lg.adapter.rfx.uat;

import org.fix4j.test.util.StringUtils;

/**
 *  Holds connection configuration data for RFX adapter for different environments
 */
public enum UatConfiguration {

    BURGUNDY("10.54.180.209", "60237", "NNKM021939", "AXLEGB", "TRFXMAS00089_RED",
            "TR MATCHING", "FXM", "USRC", "USRE", "password1", null),
    BURGUNDY_CHANGE_PASSWORD("10.54.180.209", "60237", "NNKM021939", "AXLEGB", "TRFXMAS00089_RED",
            "TR MATCHING", "FXM", "USRC", "USRE", "password1", "password1"),
    BURGUNDY_FIRST_LOGON("10.54.180.209", "60237", "NNKM021939", "AXLEGB", "TRFXMAS00089_RED",
            "TR MATCHING", "FXM", "USRC", "USRE", "D2START", "password1"),
    PINK("10.54.180.209", "60237", "NNHC031851", "AXLEJP", "TRFXMAS00089_PINKGB",
            "TR MATCHING", "FXM", "USRD", "USRE", "password1", null),
    HOSTTOGO("159.220.63.14", "60237", "NNHC021851", "Anvar Bakenov", "TRFXMAS00089ANZ",
            "TR MATCHING", "FXM", "USRC", "USRE", "D2START", "password1");

    UatConfiguration(String host, String port, String senderCompId, String senderSubId, String senderLocationId,
                     String targetCompId, String targetSubId, String fixUserName, String tradingUserName,
                     String password, String newPassword) {
        this.host = host;
        this.port = port;
        this.senderCompId = senderCompId;
        this.senderSubId = senderSubId;
        this.senderLocationId = senderLocationId;
        this.targetSubId = targetSubId;
        this.targetCompId = targetCompId;
        this.fixUserName = fixUserName;
        this.tradingUserName = tradingUserName;
        this.password = password;
        this.newPassword = newPassword;
    }

    public String getSenderCompId() {
        return senderCompId;
    }

    public String getTargetCompId() {
        return targetCompId;
    }

    private final String senderCompId;
    private final String targetCompId;
    private final String targetSubId;
    private final String senderLocationId;
    private final String senderSubId;
    private final String fixUserName;
    private final String tradingUserName;
    private final String password;
    private final String newPassword;
    private final String host;
    private final String port;

    public void updateSystemProperties() {
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "rfx.fix.sendercompid:" + senderCompId +
                                "," + "rfx.fix.targetcompid:" + targetCompId +
                                "," + "rfx.fix.targetsubid:" + targetSubId +
                                "," + "rfx.fix.senderlocationid:" + senderLocationId +
                                "," + "rfx.fix.sendersubid:" + senderSubId +
                                "," + "rfx.fix.username:" + fixUserName +
                                "," + "rfx.fix.user.request.username:" + tradingUserName +
                                "," + "rfx.fix.user.request.password:" + password +
                                (newPassword == null ? "" : "," + "rfx.fix.user.request.newPassword:" + newPassword) +
                                "," + "rfx.fix.host:" + host +
                                "," + "rfx.fix.port:" + port
                )
        );

    }

}
