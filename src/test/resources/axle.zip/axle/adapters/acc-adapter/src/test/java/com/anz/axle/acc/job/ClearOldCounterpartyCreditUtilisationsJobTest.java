package com.anz.axle.acc.job;

import com.anz.axle.acc.AbstractUnitTest;
import com.anz.axle.common.domain.CounterpartyCreditPool;
import com.anz.axle.common.domain.Venue;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValueDAO;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationKey;
import org.jmock.Expectations;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class ClearOldCounterpartyCreditUtilisationsJobTest extends AbstractUnitTest {
    private ClearOldCounterpartyCreditUtilisationsJob job;
    private CounterpartyCreditUtilisationValueDAO dao;

    @Before
    public void before() {
        dao = mock(CounterpartyCreditUtilisationValueDAO.class);
        job = new ClearOldCounterpartyCreditUtilisationsJob();
        job.setCounterpartyCreditUtilisationDAO(dao);

    }

    @Test
    public void test_that_job_can_handle_not_found_removals() {
        LocalDate oldUtilisationDate = new LocalDate(2010, 11, 18);
        LocalDate now = new LocalDate(2010, 11, 28);
        job.setMaxAgeInDays(6);
        job.setNow(now);

        CounterpartyCreditPool creditPool = new CounterpartyCreditPool();
        creditPool.setId(1l);
        final CounterpartyCreditUtilisationKey oldUtilisationKey = new CounterpartyCreditUtilisationKey(creditPool, oldUtilisationDate, "CREDIT_CHECK");
        final CounterpartyCreditUtilisationValue oldUtilisation = new CounterpartyCreditUtilisationValue(oldUtilisationKey, 100d, new ArrayList<Venue>(), 0l);

        checking(new Expectations() {
            {
                oneOf(dao).findAll();
                will(returnValue(Arrays.asList(oldUtilisation)));
                oneOf(dao).remove(oldUtilisationKey);
                oneOf(dao).has(oldUtilisationKey);
                will(returnValue(true));
            }
        });
        //run the test
        job.run();
        assertThat(mockLogAppender.contains(""), is(true));
    }

    @Test
    public void test_that_job_removes_items_over_a_certain_age_in_business_days() {
        LocalDate newUtilisationDate = new LocalDate(2010, 11, 19);
        LocalDate oldUtilisationDate = new LocalDate(2010, 11, 18);
        LocalDate now = new LocalDate(2010, 11, 28);
        job.setMaxAgeInDays(6);
        job.setNow(now);

        CounterpartyCreditPool creditPoolOne = new CounterpartyCreditPool();
        creditPoolOne.setId(1l);

        CounterpartyCreditPool creditPoolTwo = new CounterpartyCreditPool();
        creditPoolTwo.setId(2l);

        final CounterpartyCreditUtilisationKey newUtilisationKey = new CounterpartyCreditUtilisationKey(creditPoolOne, newUtilisationDate, "CREDIT_CHECK");
        final CounterpartyCreditUtilisationValue newUtilisation = new CounterpartyCreditUtilisationValue(newUtilisationKey, 100d, new ArrayList<Venue>(), 0l);

        newUtilisation.setKey(newUtilisationKey);
        final CounterpartyCreditUtilisationKey oldUtilisationKey = new CounterpartyCreditUtilisationKey(creditPoolTwo, oldUtilisationDate, "CREDIT_CHECK");
        final CounterpartyCreditUtilisationValue oldUtilisation = new CounterpartyCreditUtilisationValue(oldUtilisationKey, 100d, new ArrayList<Venue>(), 0l);

        oldUtilisation.setKey(oldUtilisationKey);

        checking(new Expectations() {
            {
                oneOf(dao).findAll();
                will(returnValue(Arrays.asList(newUtilisation, oldUtilisation)));
                oneOf(dao).remove(oldUtilisationKey);
                oneOf(dao).has(oldUtilisationKey);
                will(returnValue(false));
            }
        });
        //run the test
        job.run();
        assertThat(mockLogAppender.contains(""), is(true));
    }
}
