package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.sbe.ExecutionReportSbeDecoder;

public class ParentExecutionReportEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParentExecutionReportEvent.class);

    private final EventContext eventContext;
    private final ParentOrderRepository.WithInit parentOrderRepository;
    private final Firewall inboundParentFirewalls;
    private final Consumer<ExecutionReportDecoder> onUpdateHandler;

    private final ExecutionReportSbeDecoder executionReportDecoder = new ExecutionReportSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    public ParentExecutionReportEvent(final EventContext eventContext,
                                      final ParentOrderRepository.WithInit parentOrderRepository,
                                      final Firewall inboundParentFirewalls,
                                      final Consumer<ExecutionReportDecoder> onUpdateHandler) {
        this.eventContext = Objects.requireNonNull(eventContext);
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
        this.inboundParentFirewalls = Objects.requireNonNull(inboundParentFirewalls);
        this.onUpdateHandler = Objects.requireNonNull(onUpdateHandler);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!executionReportDecoder.wrap(message)) return false;

        final String marketId = executionReportDecoder.body().marketId().decodeAndCache(marketIdCache);

        if (Venue.FOX.name().equals(marketId)) {
            logMessage();

            inboundParentFirewalls.applyExecutionReport(eventContext, executionReportDecoder);
            if (executionReportDecoder.body().execType() == ExecType.NEW) {
                parentOrderRepository.init(eventContext, executionReportDecoder);
                onUpdateHandler.accept(executionReportDecoder);
            } else if(executionReportDecoder.body().execType() != ExecType.REJECTED) {
                final long orderId = executionReportDecoder.body().orderId().decodeLongOrZero();
                final ParentOrder parentOrder = parentOrderRepository.lookupByOrderId(orderId);
                parentOrder.applyParentExecutionReport(eventContext, executionReportDecoder);
                onUpdateHandler.accept(executionReportDecoder);
            }

            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        executionReportDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying parent ER: {}", stringBuilder);
    }
}
