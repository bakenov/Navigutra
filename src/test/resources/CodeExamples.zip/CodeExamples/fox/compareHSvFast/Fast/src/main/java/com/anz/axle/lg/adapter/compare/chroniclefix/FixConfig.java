package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Properties;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;

import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.AsyncApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.CheckLatencyProbes;
import com.anz.axle.lg.adapter.chroniclefix.EncodingSubscriptionSender;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.FixEngine;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredFixMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.PerformanceProbes;
import com.anz.axle.lg.adapter.chroniclefix.tools.FixLogConsumer;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    private final String compId;
    private final String senderCompId;
    private final Venue venue;

    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId,
                     @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public SessionID pricingSessionId(@Value("${fast.fix.pricing.sendercompid}") final String pricingsendercompid, @Value("${fast.fix.pricing.targetcompid}") final String pricingtargetcompid) {
        return new SessionID(pricingsendercompid, pricingtargetcompid);
    }

    @Bean
    public SessionID tradingSessionId(@Value("${fast.fix.trading.sendercompid}") final String tradingsendercompid, @Value("${fast.fix.trading.targetcompid}") final String tradingtargetcompid) {
        return new SessionID(tradingsendercompid, tradingtargetcompid);
    }

    @Bean
    public EncodingSubscriptionSender encodingSubscriptionSender(final FixMessageSender fixPricingMessageSender) {
        return new EncodingSubscriptionSender(new FastMarketDataRequestEncoder(), fixPricingMessageSender);
    }

    @Bean
    public SessionState tradingSessionState() {
        return new SessionState("TradingSession");
    }

    @Bean
    public Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState tradingSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(tradingSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler(final SessionID pricingSessionId,
                                                           @Qualifier("marketDataSubscriber") final Supplier<LogonHandler> pricingSessionLogonHandlerSupplier,
                                                           final SessionID tradingSessionId,
                                                           @Qualifier("tradingSessionState") final Supplier<LogonHandler> tradingSessionLogonHandlerSupplier,
                                                           final Queue<Runnable> mainEventLoopQueue) {

        return new AsyncApplicationLogonHandler(mainEventLoopQueue, sessionID -> {
            if (sessionID.equals(pricingSessionId)) {
                return pricingSessionLogonHandlerSupplier.get();
            } else if (sessionID.equals(tradingSessionId)) {
                return tradingSessionLogonHandlerSupplier.get();
            } else {
                return LogonHandler.NO_OP;
            }
        });
    }

    @Bean
    public FixMessageSender fixPricingMessageSender(final SessionID pricingSessionId, @Lazy final FixEngine fixPricingEngine) {
        return new FixMessageSender(() ->
                fixPricingEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(pricingSessionId)).findFirst().get());
    }

    @Bean
    public FixMessageSender fixTradingMessageSender(final SessionID tradingSessionId, @Lazy final FixEngine fixTradingEngine) {
        return new FixMessageSender(() ->
                fixTradingEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(tradingSessionId)).findFirst().get());
    }

    @Bean
    public EventLoop chronicleEventLoop() {
        EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false);
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter fixPricingEventLoopStep(final EventLoop chronicleEventLoop) {
        return new EventLoopAdapter(chronicleEventLoop);
    }

    @Bean
    public EventLoopAdapter fixTradingEventLoopStep(final EventLoop chronicleEventLoop) {
        return new EventLoopAdapter(chronicleEventLoop);
    }

    @Bean
    public FixEngineCfg fixEngineCfg(final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/fast-chroniclefix.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final FixEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

   @Bean
    public Consumer<FixLog> pricingFixLogConsumer(@Value("${fast.fix.pricing.log_all}") final boolean enableLogging,
                                                  @Value("${fast.fix.file.log.path}") final String logPath,
                                                  @Value("${fast.fix.pricing.logging.base_path}") final String bashPath,
                                                  @Value("${fast.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public Consumer<FixLog> tradingFixLogConsumer(@Value("${fast.fix.trading.log_all}") final boolean enableLogging,
                                                  @Value("${fast.fix.file.log.path}") final String logPath,
                                                  @Value("${fast.fix.trading.logging.base_path}") final String bashPath,
                                                  @Value("${fast.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public FixEngine fixPricingEngine(final FixEngineCfg fixEngineCfg,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      final Consumer<FixLog> pricingFixLogConsumer,
                                      final VenueRequestKeyLookup requestKeyLookup,
                                      final PricingEncoderLookup pricingEncoderLookup,
                                      final PrecisionClock precisionClock,
                                      final SubscriptionManager subscriptionManager,
                                      final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy,
                                      final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> incrementalRefreshEncoderFlagsAppender,
                                      final EventLoopAdapter fixPricingEventLoopStep,
                                      final MetricRepository<Metric, Venue> metricRepository,
                                      @Value("${fast.fix.pricing.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      final SourceSequencer sourceSequencer) throws Exception {

        final FixSessionCfg pricingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("pricing")).findFirst().get();
        final FastIncrementalRefreshHandler incrementalRefreshHandler = new FastIncrementalRefreshHandler(requestKeyLookup,
                pricingEncoderLookup, precisionClock,
                subscriptionManager, senderCompId, compId, incrementalRefreshEncoderFlagsAppender, sourceSequencer);
        final FastSnapshotFullRefreshHandler snapshotFullRefreshHandler = new FastSnapshotFullRefreshHandler(requestKeyLookup,
                pricingEncoderLookup, precisionClock, subscriptionManager, senderCompId, compId, sourceSequencer);
        final FastMarketDataRequestRejectHandler marketDataRequestRejectHandler = new FastMarketDataRequestRejectHandler(subscriptionManager, subscriptionRequestRejectStrategy);

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value);
        FixSessionApplication fixPricingApplication = new FixPricingApplication(
                new MonitoredFixMessageHandler<>(incrementalRefreshHandler, metricRecorder),
                new MonitoredFixMessageHandler<>(snapshotFullRefreshHandler, metricRecorder),
                new MonitoredFixMessageHandler<>(marketDataRequestRejectHandler, metricRecorder),
                applicationLogonHandler);
        pricingSession.messageNotifier(fixPricingApplication);

        pricingSession.consumer(pricingFixLogConsumer);

        return FixEngine.create(venue.name() + "-MD-SUBSCRIBER", fixEngineCfg.createInstance(pricingSession.hostId(), fixPricingEventLoopStep), waitForLogoutTimeoutInSec);
    }

    @Bean
    public FixSessionCfg tradingSessionCfg(final FixEngineCfg fixEngineCfg) {
        return fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
    }

    @Bean
    public FixEngine fixTradingEngine(final FixEngineCfg fixEngineCfg,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      @Value("${appOptions:}") final String appOptions,
                                      final Consumer<FixLog> tradingFixLogConsumer,
                                      final PrecisionClock precisionClock,
                                      final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                      final LongIdFactory tradingMessageIdGenerator,
                                      final EventLoopAdapter fixTradingEventLoopStep,
                                      final MetricRepository<Metric, Venue> metricRepository,
                                      @Value("${fast.fix.trading.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      final SourceSequencer sourceSequencer) throws Exception {

        final FixSessionCfg tradingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();

        if (OptionMatcher.HAS_RESET.test(appOptions)) {
            LOGGER.info("Once-off sequence reset is enabled");
            final OnceOffResetMessageProvider onceOffResetMessageProvider = new OnceOffResetMessageProvider(tradingSession);
            tradingSession.sessionMessageProvider(onceOffResetMessageProvider);
        } else {
            LOGGER.info("Once-off sequence reset is disabled");
        }

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);
        final FixMessageHandler fastExecutionReportHandler = new MonitoredFixMessageHandler<>(
                new FastExecutionReportHandler(tradingResponseEncoderSupplier, precisionClock, senderCompId, compId, tradingMessageIdGenerator::get, sourceSequencer),
                metricRecorder);
        final FixTradingApplication fixTradingApplication = new FixTradingApplication(fastExecutionReportHandler, applicationLogonHandler);
        tradingSession.messageNotifier(fixTradingApplication);
        tradingSession.probes(new CheckLatencyProbes(new PerformanceProbes()));
        // TODO: need to set session.timeProvider with a wrapper around LG precision clock
        tradingSession.consumer(tradingFixLogConsumer);
        return FixEngine.create(venue.name() + "-TR-SUBSCRIBER", fixEngineCfg.createInstance(tradingSession.hostId(), fixTradingEventLoopStep), waitForLogoutTimeoutInSec);
    }
}

