package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueInstrumentConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoVenueInstrumentConfigEncoder implements VenueInstrumentConfigEncoder, VenueInstrumentConfigEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;

    private VenueInstrumentConfig message = SorMessage.venueInstrumentConfig();

    public PojoVenueInstrumentConfigEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
    }

    public VenueInstrumentConfig message() {
        return message;
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        message = SorMessage.venueInstrumentConfig();
        return this;
    }

    @Override
    public Body venue(final Venue venue) {
        message.body.venue = venue;
        return this;
    }

    @Override
    public Body instrumentId(final long instrumentId) {
        message.body.instrumentId = instrumentId;
        return this;
    }

    @Override
    public Body priceIncrement(final double priceIncrement) {
        message.body.priceIncrement = priceIncrement;
        return this;
    }

    @Override
    public Body sizeIncrement(final int sizeIncrement) {
        message.body.sizeIncrement = sizeIncrement;
        return this;
    }

    @Override
    public Body clipSizeMultiple(final int clipSizeMultiple) {
        message.body.clipSizeMultiple = clipSizeMultiple;
        return this;
    }

    @Override
    public Body maxAllowedParentOrderQty(final double maxAllowedParentOrderQty) {
        message.body.maxAllowedParentOrderQty = maxAllowedParentOrderQty;
        return this;
    }

    @Override
    public Body minClipSize(final int minClipSize) {
        message.body.minClipSize = minClipSize;
        return this;
    }

    @Override
    public Body maxClipSize(final int maxClipSize) {
        message.body.maxClipSize = maxClipSize;
        return this;
    }

    @Override
    public Body staleDataTimeout(final int staleDataTimeout) {
        message.body.staleDataTimeout = staleDataTimeout;
        return this;
    }

    @Override
    public Body priority(final int priority) {
        message.body.priority = priority;
        return this;
    }

    @Override
    public Body proportion(final int proportion) {
        message.body.proportion = proportion;
        return this;
    }

    @Override
    public Trailer enabled(final boolean enabled) {
        message.body.enabled = enabled;
        return this;
    }

    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
