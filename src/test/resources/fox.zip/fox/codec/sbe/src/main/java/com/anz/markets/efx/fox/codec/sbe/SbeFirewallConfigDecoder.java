package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.sbe.Lazy;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringDecoders;

final class SbeFirewallConfigDecoder {
    private final FirewallConfigDecoder firewallConfigDecoder = new FirewallConfigDecoder();
    private final Consumer<StringBuilder> messageLogger = firewallConfigDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.FirewallConfig encodingOrder = EncodingOrder.FirewallConfig.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final FirewallConfigHandler firewallConfigHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.FirewallConfig.INITIAL;
        firewallConfigDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            firewallConfigHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            firewallConfigHandler.messageForwarder(messageForwarder);
            firewallConfigHandler.messageLogger(messageLogger);
            body.decode(firewallConfigHandler);
            firewallConfigHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.FirewallConfig.INITIAL;
            firewallConfigDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements FirewallConfigHandler.Body {
        private final StringDecoder firewallName = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::firewallName), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.firewallNameLength());
        private final StringDecoder regionPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::regionPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.regionPatternLength());
        private final StringDecoder orderTypePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::orderTypePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.orderTypePatternLength());
        private final StringDecoder deskPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::deskPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.deskPatternLength());
        private final StringDecoder portfolioPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::portfolioPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.portfolioPatternLength());
        private final StringDecoder usernamePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::usernamePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.usernamePatternLength());
        private final StringDecoder venuePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::venuePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.venuePatternLength());
        private final StringDecoder securityTypePattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::securityTypePattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.securityTypePatternLength());
        private final StringDecoder tenorPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::tenorPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.tenorPatternLength());
        private final StringDecoder symbolPattern = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::symbolPattern), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.symbolPatternLength());
        private final StringDecoder periodUnit = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::periodUnit), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.periodUnitLength());
        private final StringDecoder comment = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::comment), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.commentLength());
        private final StringDecoder lastEditUsername = StringDecoders.forFixedLength(Lazy.fixedStringSource(() -> firewallConfigDecoder::lastEditUsername), com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.lastEditUsernameLength());

        void decode(final FirewallConfigHandler firewallConfigHandler) {
            encodingOrder = EncodingOrder.FirewallConfig.BODY;
            firewallConfigHandler.onBody(this);
        }

        @Override
        public StringDecoder firewallName() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallName;
        }

        @Override
        public long ruleId() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.ruleId();
        }

        @Override
        public StringDecoder regionPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return regionPattern;
        }

        @Override
        public StringDecoder orderTypePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return orderTypePattern;
        }

        @Override
        public StringDecoder deskPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return deskPattern;
        }

        @Override
        public StringDecoder portfolioPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return portfolioPattern;
        }

        @Override
        public StringDecoder usernamePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return usernamePattern;
        }

        @Override
        public StringDecoder venuePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return venuePattern;
        }

        @Override
        public StringDecoder securityTypePattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return securityTypePattern;
        }

        @Override
        public StringDecoder tenorPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return tenorPattern;
        }

        @Override
        public StringDecoder symbolPattern() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return symbolPattern;
        }

        @Override
        public long period() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.period();
        }

        @Override
        public StringDecoder periodUnit() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return periodUnit;
        }

        @Override
        public boolean local() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.local() == YesNo.YES;
        }

        @Override
        public StringDecoder comment() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return comment;
        }

        @Override
        public StringDecoder lastEditUsername() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return lastEditUsername;
        }

        @Override
        public long lastEditTime() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.lastEditTime();
        }

        @Override
        public double limitThreshold() {
            encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
            return firewallConfigDecoder.limitThreshold();
        }
    }
}
