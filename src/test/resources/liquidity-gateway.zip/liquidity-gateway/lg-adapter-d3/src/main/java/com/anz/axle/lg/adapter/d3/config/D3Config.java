package com.anz.axle.lg.adapter.d3.config;

import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.agrona.concurrent.IdleStrategy;
import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;

import de.digitec.d3.pricing.streaming.StreamingService;
import de.digitec.d3.pricing.streaming.StreamingServiceFactory;
import de.digitec.d3.pricing.streaming.StreamingServiceListener;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.lg.adapter.d3.DefaultStreamingServiceListener;
import com.anz.axle.lg.adapter.d3.StreamingServiceHealthChecker;
import com.anz.axle.lg.adapter.d3.newsubscription.D3TenorLookup;
import com.anz.axle.lg.adapter.d3.newsubscription.DefaultSubscriptionRegistry;
import com.anz.axle.lg.adapter.d3.newsubscription.RequestKeyD3Symbol;
import com.anz.axle.lg.adapter.d3.newsubscription.Subscription;
import com.anz.axle.lg.adapter.d3.newsubscription.SubscriptionRegistry;
import com.anz.axle.lg.config.IdleStrategyFactory;
import com.anz.axle.lg.config.IdleStrategyId;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.CurrentMillisIdFactory;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.servicelifecycle.Service;
import com.anz.lg.messaging.event.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;

@Configuration
class D3Config {
    public static final String MAIN_EVENT_LOOP_NAME = "MainEventLoop";
    public static final String SERVICE_REQUEST_LOOP_NAME = "ServiceRequestEventLoop";

    @Bean
    CurrentMillisIdFactory idGenerator() {
        return new CurrentMillisIdFactory();
    }

    @Bean
    StreamingService streamingService(@Value("${d3.server.host}") final String hostname,
                                      @Value("${d3.server.port}") final int port) {
        return new StreamingServiceFactory().createStreamingService(hostname, port);
    }

    @Bean
    Supplier<IdleStrategy> idleStrategyFactory(final @Value("${event.loop.idle.strategy}") IdleStrategyId idleStrategyId,
                                               final @Value("${event.loop.idle.strategy.backoff.maxSpins}") long backOffMaxSpins,
                                               final @Value("${event.loop.idle.strategy.backoff.maxYields}") long backOffMaxYields,
                                               final @Value("${event.loop.idle.strategy.backoff.maxParkPeriodUs}") long backOffMaxParkPeriodUs) {
        return () -> IdleStrategyFactory.create(idleStrategyId, backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs);
    }

    @Bean
    EventLoopStep connectionPollingStep(final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor,
                                        final Connection connection) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        return EventLoopStep.whenFinalisationNotRequired(() -> connection.pollingStrategy().processNext());
    }

    @Bean
    Queue<Runnable> mainEventLoopRunnableQueue(@Value("${main.event.loop.runnable.queue.capacity}") final int queueCapacity, final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(queueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(MonitoredQueueMetric.MAIN_LOOP_RUNNABLE.apply(metric), null).record(value));
    }

    @Bean
    Queue<UpdateMessage> mainEventLoopMessageQueue(@Value("${main.event.loop.message.queue.capacity}") final int queueCapacity, final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(queueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value));
    }

    @Bean
    EventLoopStep mainEventLoopRunnableProcessingStep(final Queue<Runnable> mainEventLoopRunnableQueue) {
        Objects.requireNonNull(mainEventLoopRunnableQueue);

        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return EventLoopStep.whenFinalisationRequired(() -> mainEventLoopRunnableQueue.poller().processNext(runnableProcessor));
    }


    @Bean
    EventLoopStep mainEventLoopMessageProcessingStep(final Queue<UpdateMessage> mainEventLoopMessageQueue,
                                                     final SubscriptionRegistry subscriptionRegistry) {
        Objects.requireNonNull(subscriptionRegistry);

        final Consumer<UpdateMessage> updateMessageProcessor = message -> {
            final long subscriptionId = Long.valueOf(message.getSubscriptionId()); //FIXME: parse with garbage free parser.
            subscriptionRegistry.byIdLookup().lookup(subscriptionId).processUpdate(message);
        };
        return EventLoopStep.whenFinalisationRequired(() -> mainEventLoopMessageQueue.poller().processNext(updateMessageProcessor));
    }

    @Bean
    EventLoopStep mainLoopMonitoringStep(final MetricRepository<Metric, Venue> metricRepository) {
        return EventLoopStep.whenFinalisationRequired(() -> {
            metricRepository.getOrCreate(Metric.MAIN_LOOP_ITERATION_CNT, null).record(1);
            return false;
        });
    }

    @Bean
    Service mainEventLoop(final Supplier<IdleStrategy> idleStrategyFactory,
                          final EventLoopStep mainEventLoopRunnableProcessingStep,
                          final EventLoopStep mainEventLoopMessageProcessingStep,
                          final EventLoopStep connectionPollingStep,
                          final EventLoopStep mainLoopMonitoringStep) {
        return new EventLoopService(MAIN_EVENT_LOOP_NAME,
                10, TimeUnit.SECONDS, idleStrategyFactory.get(),
                mainEventLoopRunnableProcessingStep,
                mainEventLoopMessageProcessingStep,
                connectionPollingStep,
                mainLoopMonitoringStep);
    }

    @Bean
    Queue<Runnable> serviceRequestEventLoopRunnableQueue(@Value("${service.request.event.loop.runnable.queue.capacity}") final int queueCapacity,
                                                         final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(queueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(MonitoredQueueMetric.SERVICE_LOOP_RUNNABLE.apply(metric), null).record(value));
    }

    @Bean
    EventLoopStep serviceRequestEventLoopProcessingStep(final Queue<Runnable> serviceRequestEventLoopRunnableQueue) {
        Objects.requireNonNull(serviceRequestEventLoopRunnableQueue);

        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return EventLoopStep.whenFinalisationNotRequired(() -> serviceRequestEventLoopRunnableQueue.poller().processNext(runnableProcessor));
    }

    @Bean
    EventLoopStep serviceRequestEventLoopMonitoringStep(final MetricRepository<Metric, Venue> metricRepository) {
        return EventLoopStep.whenFinalisationRequired(() -> {
            metricRepository.getOrCreate(Metric.SERVICE_LOOP_ITERATION_CNT, null).record(1);
            return false;
        });
    }

    @Bean
    Service serviceRequestEventLoop(final EventLoopStep serviceRequestEventLoopProcessingStep,
                                    final EventLoopStep serviceRequestEventLoopMonitoringStep,
                                    final Supplier<IdleStrategy> idleStrategyFactory) {

        return new EventLoopService(
                SERVICE_REQUEST_LOOP_NAME,
                10, TimeUnit.SECONDS, idleStrategyFactory.get(),
                serviceRequestEventLoopProcessingStep,
                serviceRequestEventLoopMonitoringStep);
    }

    @Bean
    PricingEncoders<SbeMessage> pricingEncoders(@Value("${messaging.sbe.buffer.capacity}") final int sbeMessageBufferCapacity) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbePricingEncoders(() -> sbeMessage);
    }

    @Bean
    SubscriptionRegistry subscriptionRegistry(final @Value("${venue}") Venue venue,
                                              final @Value("${securitytype}") SecurityType securityType,
                                              final LongIdFactory idGenerator,
                                              final PricingEncoders<SbeMessage> pricingEncoders,
                                              final PrecisionClock precisionClock,
                                              final PublicationRegistry publicationRegistry,
                                              final MessageHandler publisher,
                                              final Queue<Runnable> serviceRequestEventLoopRunnableQueue,
                                              final Queue<Runnable> mainEventLoopRunnableQueue,
                                              final StreamingService streamingService,
                                              final @Value("${retry.subscription.seconds}") long retrySubscriptionSeconds,
                                              final @Value("${spot.date.roll.subscribe.delay.seconds}") long sportDateRollSubscribeDelaySeconds,
                                              final @Value("${missed.update.seconds}") long missedUpdateSeconds,
                                              final @Value("${messaging.compId}") String compId,
                                              final @Value("${messaging.D3.compId}") String senderCompId,
                                              final @Value("${market.data.book.initial.size}") int marketDataBookInitialSize,
                                              final @Value("#{${tenor.to.d3.tenor.name}}") Map<Tenor, String> tenorToD3TenorName,
                                              final @Value("#{${venue.to.d3.classification}}") Map<Venue, String> d3SubscriptionClassifications,
                                              final SourceSequencer sourceSequencer) {
        final String classification = d3SubscriptionClassifications.get(venue);
        return new DefaultSubscriptionRegistry(securityType, idGenerator::get,
                pricingEncoders, precisionClock, publicationRegistry, publisher,
                serviceRequestEventLoopRunnableQueue.appender(), mainEventLoopRunnableQueue.appender(),
                streamingService, retrySubscriptionSeconds, missedUpdateSeconds, compId, senderCompId,
                new RequestKeyD3Symbol(D3TenorLookup.fromMap(tenorToD3TenorName), classification), marketDataBookInitialSize,
                sourceSequencer, sportDateRollSubscribeDelaySeconds);
    }

    @Bean
    StreamingServiceListener streamingServiceListener(final Queue<Runnable> mainEventLoopRunnableQueue,
                                                      final Queue<UpdateMessage> mainEventLoopMessageQueue,
                                                      final StreamingService streamingService,
                                                      final SubscriptionRegistry subscriptionRegistry) {
        final StreamingServiceListener streamingServiceListener = new DefaultStreamingServiceListener(
                mainEventLoopRunnableQueue.appender(),
                mainEventLoopMessageQueue.appender(),
                subscriptionRegistry);
        streamingService.addServiceListener(streamingServiceListener);
        return streamingServiceListener;
    }

    @Bean
    StreamingServiceHealthChecker streamingServiceHealthChecker(final ScheduledExecutorService scheduledExecutorService,
                                                                final StreamingService streamingService,
                                                                @Value("${streamingServiceHealthChecker.initialDelay.seconds}") final int initialDelaySeconds, @Value("${streamingServiceHealthChecker.interval.seconds}") final int healthCheckIntervalSeconds) {
        // Regularly checks if there is an active StreamingService.
        return new StreamingServiceHealthChecker(
                scheduledExecutorService,
                Executors.newSingleThreadExecutor(new CustomizableThreadFactory("D3StreamingService-DispatchThread-")),
                streamingService,
                initialDelaySeconds,
                healthCheckIntervalSeconds,
                TimeUnit.SECONDS);
    }

    @Bean
    Runnable subscriptionLoader(final @Value("${venue}") Venue venue,
                                final @Value("${securitytype}") SecurityType securityType,
                                final Queue<Runnable> mainEventLoopRunnableQueue,
                                final SubscriptionRegistry subscriptionRegistry,
                                @Value("#{${symbol.venues.${securitytype}}}") final Map<String, Set<Venue>> symbolVenues,
                                @Value("#{${symbol.tenors.${securitytype}.${venue}}}") final Map<String, Set<Tenor>> symbolTenors) {
        final VenueSymbolMatrix fxFwdVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(symbolVenues));

        return () -> {
            final Queue.Appender<Runnable> mainEventLoopRunnableQueueAppender = mainEventLoopRunnableQueue.appender();

            fxFwdVenueSymbolMatrix.forEachSymbolOfVenue(venue, symbol -> {
                final Set<Tenor> tenors = symbolTenors.getOrDefault(symbol, Collections.emptySet());
                tenors.forEach(tenor -> {
                    final RequestKey requestKey = RequestKey.of(venue, InstrumentKey.of(symbol, securityType, tenor));
                    mainEventLoopRunnableQueueAppender.enqueue(() -> {
                        final Subscription subscription = subscriptionRegistry.byVenueRequestKeyLookup().lookupOrCreate(requestKey);
                        subscription.subscribe(Long.MAX_VALUE);
                    });
                });
            });
        };
    }
}
