package com.anz.markets.efx.fox.acceptance.config;

import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;

import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelReject;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

public class DefaultVenueEndpoint implements VenueEndpoint {
    private final Venue venue;
    private final Function<String, Queue<PricingMessage>> pricingQueueLookup;
    private final Function<String, Queue<TradingMessage>> tradingQueueLookup;
    private final String tradingRequestTopicName;
    private final String tradingResponseTopicName;
    private final String lastMarketTradeTopicName;
    private final int source;
    private final AtomicLong sequencer;

    public DefaultVenueEndpoint(final Venue venue,
                                final Function<String, Queue<PricingMessage>> pricingQueueLookup,
                                final Function<String, Queue<TradingMessage>> tradingQueueLookup,
                                final long sequencerSeed) {
        this.venue = Objects.requireNonNull(venue);
        this.pricingQueueLookup = Objects.requireNonNull(pricingQueueLookup);
        this.tradingQueueLookup = Objects.requireNonNull(tradingQueueLookup);
        this.tradingRequestTopicName = venue.name() + "_TRADING_REQUEST";
        this.tradingResponseTopicName = venue.name() + "_TRADING_RESPONSE";
        this.lastMarketTradeTopicName = venue.name() + "_LAST_MARKET_TRADE";
        this.source = (venue.ordinal() + 1) * 1000;
        this.sequencer = new AtomicLong(sequencerSeed);
    }

    @Override
    public Venue venue() {
        return venue;
    }

    @Override
    public Queue<PricingMessage> pricingQueue(final String symbol, final SecurityType securityType) {
        final String topicName = securityType + "_" + venue.name() + "_" + symbol;
        return pricingQueueLookup.apply(topicName);
    }

    @Override
    public Queue<PricingMessage> lastMarketTrade() {
        return pricingQueueLookup.apply(lastMarketTradeTopicName);
    }

    @Override
    public Queue<TradingMessage> tradingRequest() {
        return tradingQueueLookup.apply(tradingRequestTopicName);
    }

    @Override
    public Queue<TradingMessage> tradingResponse() {
        return tradingQueueLookup.apply(tradingResponseTopicName);
    }

    @Override
    public ExecutionReport createExecutionReport() {
        final ExecutionReport executionReport = new ExecutionReport(new MessageHeader(source, sequencer.incrementAndGet()), new ExecutionReport.Body());
        executionReport.body.messageId = sequencer.get();
        executionReport.body.marketId = venue.name();
        return executionReport;
    }

    @Override
    public OrderCancelReject createOrderCancelReject() {
        final OrderCancelReject orderCancelReject = new OrderCancelReject(new MessageHeader(source, sequencer.incrementAndGet()), new OrderCancelReject.Body());
        orderCancelReject.body.messageId = sequencer.get();
        orderCancelReject.body.marketId = venue.name();
        return orderCancelReject;
    }

}
