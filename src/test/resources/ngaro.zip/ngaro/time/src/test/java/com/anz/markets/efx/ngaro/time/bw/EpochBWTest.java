package com.anz.markets.efx.ngaro.time.bw;

import java.time.LocalDate;
import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;
import org.octtech.bw.ByteWatcherSingleThread;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertTrue;

/**
 * ByteWatcher test for {@link Epoch}
 */
public class EpochBWTest {

    private static final int WARMUP_RUNS = 100_000;
    private static final int MEASURE_RUNS = 100_000;
    private static final int BYTE_LIMIT = 0;
    private static final LocalDate[] LOCAL_DATES = {
            LocalDate.of(1970, 1, 1),
            LocalDate.of(1922, 1, 1),
            LocalDate.of(1922, 5, 6),
            LocalDate.of(2016, 1, 1),
            LocalDate.of(2016, 12, 31),
            LocalDate.of(2222, 12, 31)
    };
    private static final long[] EPOCH_DAYS = {
            LOCAL_DATES[0].toEpochDay(),
            LOCAL_DATES[1].toEpochDay(),
            LOCAL_DATES[2].toEpochDay(),
            LOCAL_DATES[3].toEpochDay(),
            LOCAL_DATES[4].toEpochDay(),
            LOCAL_DATES[5].toEpochDay()
    };

    @Test
    public void toEpochMillis() throws Exception {
        final boolean[] allPassed = trueArray(LOCAL_DATES.length);
        final Runnable test = () -> {
            for (int i = 0; i < LOCAL_DATES.length; i++) {
                final LocalDate localDate = LOCAL_DATES[i];
                final long expected = EPOCH_DAYS[i] * 24L * 60L * 60L * 1000L;
                allPassed[i] &= expected == Epoch.toEpochMillis(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
            }
        };
        run(test, BYTE_LIMIT);
        assertAllPassed("toEpochMillis", allPassed);
    }

    @Test
    public void toEpochSeconds() throws Exception {
        final boolean[] allPassed = trueArray(LOCAL_DATES.length);
        final Runnable test = () -> {
            for (int i = 0; i < LOCAL_DATES.length; i++) {
                final LocalDate localDate = LOCAL_DATES[i];
                final long expected = EPOCH_DAYS[i] * 24L * 60L * 60L;
                allPassed[i] &= expected == Epoch.toEpochSeconds(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
            }
        };
        run(test, BYTE_LIMIT);
        assertAllPassed("toEpochSeconds", allPassed);
    }

    @Test
    public void toEpochDays() throws Exception {
        final boolean[] allPassed = trueArray(LOCAL_DATES.length);
        final Runnable test = () -> {
            for (int i = 0; i < LOCAL_DATES.length; i++) {
                final LocalDate localDate = LOCAL_DATES[i];
                allPassed[i] &= EPOCH_DAYS[i] == Epoch.toEpochDays(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
            }
        };
        run(test, BYTE_LIMIT);
        assertAllPassed("toEpochDays", allPassed);
    }

    @Test
    public void fromEpochMillis() throws Exception {
        final boolean[] allPassed = trueArray(LOCAL_DATES.length);
        final Runnable test = () -> {
            for (int i = 0; i < LOCAL_DATES.length; i++) {
                final LocalDate localDate = LOCAL_DATES[i];
                final long epochMillis = EPOCH_DAYS[i] * 24L * 60L * 60L * 1000L;
                final int packed = Epoch.fromEpochMillis(LocalDatePacking.BINARY, epochMillis);
                allPassed[i] &= localDate.getYear() == LocalDatePacking.BINARY.unpackYear(packed)
                        && localDate.getMonthValue() == LocalDatePacking.BINARY.unpackMonth(packed)
                        && localDate.getDayOfMonth() == LocalDatePacking.BINARY.unpackDay(packed);
            }
        };
        run(test, BYTE_LIMIT);
        assertAllPassed("fromEpochMillis", allPassed);
    }

    @Test
    public void fromEpochSeconds() throws Exception {
        final boolean[] allPassed = trueArray(LOCAL_DATES.length);
        final Runnable test = () -> {
            for (int i = 0; i < LOCAL_DATES.length; i++) {
                final LocalDate localDate = LOCAL_DATES[i];
                final long epochSeconds = EPOCH_DAYS[i] * 24L * 60L * 60L;
                final int packed = Epoch.fromEpochSeconds(LocalDatePacking.BINARY, epochSeconds);
                allPassed[i] &= localDate.getYear() == LocalDatePacking.BINARY.unpackYear(packed)
                        && localDate.getMonthValue() == LocalDatePacking.BINARY.unpackMonth(packed)
                        && localDate.getDayOfMonth() == LocalDatePacking.BINARY.unpackDay(packed);
            }
        };
        run(test, BYTE_LIMIT);
        assertAllPassed("fromEpochSeconds", allPassed);
    }

    @Test
    public void fromEpochDays() throws Exception {
        final boolean[] allPassed = trueArray(LOCAL_DATES.length);
        final Runnable test = () -> {
            for (int i = 0; i < LOCAL_DATES.length; i++) {
                final LocalDate localDate = LOCAL_DATES[i];
                final int packed = Epoch.fromEpochDays(LocalDatePacking.BINARY, EPOCH_DAYS[i]);
                allPassed[i] &= localDate.getYear() == LocalDatePacking.BINARY.unpackYear(packed)
                        && localDate.getMonthValue() == LocalDatePacking.BINARY.unpackMonth(packed)
                        && localDate.getDayOfMonth() == LocalDatePacking.BINARY.unpackDay(packed);
            }
        };
        run(test, BYTE_LIMIT);
        assertAllPassed("fromEpochDays", allPassed);
    }

    private static void run(final Runnable test, final long byteLimit) {
        final ByteWatcherSingleThread bw = new ByteWatcherSingleThread(Thread.currentThread());
        for (int i = 0; i < WARMUP_RUNS; i++) {
            test.run();
        }
        bw.reset();
        for (int i = 0; i < MEASURE_RUNS; i++) {
            test.run();
        }
        final long bytes = bw.calculateAllocations();
        Assert.assertTrue("Allocated bytes " + bytes + " exceeds limit " + byteLimit, bytes <= byteLimit);
    }

    private static void assertAllPassed(final String testName, final boolean[] allPassed) {
        for (int i = 0; i < allPassed.length; i++) {
            assertTrue(testName + "[" + i + "] with " + LOCAL_DATES[i] + " has failures", allPassed[i]);
        }
    }

    private static boolean[] trueArray(final int length) {
        final boolean[] allPassed = new boolean[length];
        Arrays.fill(allPassed, true);
        return allPassed;
    }

}