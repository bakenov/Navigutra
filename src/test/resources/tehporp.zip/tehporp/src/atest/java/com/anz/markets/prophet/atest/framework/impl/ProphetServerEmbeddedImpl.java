package com.anz.markets.prophet.atest.framework.impl;

import com.anz.axle.falcon.MillenniumFalcon;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.atest.framework.Output;
import com.anz.markets.prophet.atest.framework.OutputSource;
import com.anz.markets.prophet.atest.framework.ProphetServer;
import com.anz.markets.prophet.atest.framework.UmEndPoint;
import com.anz.markets.prophet.atest.framework.config.StarInAtestConfig;
import com.anz.markets.prophet.atest.framework.config.StarOutAtestConfig;
import com.anz.markets.prophet.chime.ChimeManager;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.config.app.CoreConfig;
import com.anz.markets.prophet.config.app.CoreCrossConfig;
import com.anz.markets.prophet.config.app.CoreDriverPricingConfig;
import com.anz.markets.prophet.config.app.CoreHedgingConfig;
import com.anz.markets.prophet.config.app.CorePricingConfig;
import com.anz.markets.prophet.config.app.StarfishInConfig;
import com.anz.markets.prophet.config.app.StarfishOutConfig;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.CovCorrAvgs;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.TradeType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.PricingFirewallReset;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.order.OrderEventType;
import com.anz.markets.prophet.domain.order.impl.OrderEventImpl;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.messaging.LiquidityGatewayClient;
import com.anz.markets.prophet.messaging.TradeUmClient;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.PositionAdjustmentProducer;
import com.anz.markets.prophet.pricer.ManualSkewControlProducer;
import com.anz.markets.prophet.pricer.SkewCurrencyControlProducer;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.LogCaptureAppender;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import com.espertech.esper.util.FileUtil;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.anz.markets.prophet.Main.RUNNER_BEAN;
import static com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification.prophet;
import static java.lang.String.format;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

public class ProphetServerEmbeddedImpl implements ProphetServer {
    public static final int START_TIME_MS = 1_000_000;

    private static final String PROPERTY_CORE_MODE = "prophet.core.mode";
    private static final String PROPERTY_CHRONICLE_CORE_IN_PATH = "chronicle.core.in.path";
    private static final String PROPERTY_CHRONICLE_IN_PATH = "chronicle.in.path";
    private static final String PROPERTY_CHRONICLE_DF_PATH = "chronicle.df.path";
    private static final String PROPERTY_CLIENT_PRICING_IN_PATH = "chronicle.core.client.pricing.in.path";
    private static final String PROPERTY_CLIENT_PRICING_OUT_PATH = "chronicle.core.client.pricing.out.path";
    private static final String PROPERTY_HEDGER_IN_PATH = "chronicle.core.hedger.in.path";
    private static final String PROPERTY_HEDGER_OUT_PATH = "chronicle.hedger.out.path";
    private static final String PROPERTY_CHRONICLE_OUT_PATH = "chronicle.out.path";
    private static final String PROPERTY_CHRONICLE_IN_STAROUT_PATH = "chronicle.starout.in.path";
    private static final String PROPERTY_CROSS_IN_PATH = "chronicle.cross.in.path";
    private static final String PROPERTY_CROSS_OUT_PATH = "chronicle.cross.out.path";

    private static final String[] CHRONICLE_FILE_PROPERTY_NAMES = {
            PROPERTY_CHRONICLE_CORE_IN_PATH,
            PROPERTY_CHRONICLE_IN_PATH,
            PROPERTY_CHRONICLE_DF_PATH,
            PROPERTY_CLIENT_PRICING_IN_PATH,
            PROPERTY_CLIENT_PRICING_OUT_PATH,
            PROPERTY_HEDGER_IN_PATH,
            PROPERTY_HEDGER_OUT_PATH,
            PROPERTY_CROSS_IN_PATH,
            PROPERTY_CROSS_OUT_PATH,
            PROPERTY_CHRONICLE_OUT_PATH,
            PROPERTY_CHRONICLE_IN_STAROUT_PATH
    };

    private static final Logger LOGGER = LoggerFactory.getLogger(ProphetServerEmbeddedImpl.class);
    private static final long WAIT_TIME = 50L, WAIT_ITERATIONS = 400;
    private static final String UM_IN_SUFFIX_PLACEHOLDER = "StarInUMSource_";
    private static final int ALLOW_MORE_THAN_2_READERS = 4;
    private AnnotationConfigApplicationContext starInContext, starOutContext;
    private AnnotationConfigApplicationContext coreContext, clientPricingContext, coreHedgerContext, coreCrossContext;
    private UmEndPoint umSource, umSink;
    private AtomicBoolean isRunning = new AtomicBoolean(false);
    private ChronicleOutBufferReader bufferedOutput = new ChronicleOutBufferReader();
    private List inputCommandList = new ArrayList();
    private ProphetReader chOutReader, chHedgerOutReader, chCrossOutReader;
    private PublishingTestTimeSource timeSource;
    private LogCaptureAppender logCaptureAppender;
    private ProphetPersister dfPersister;
    private final Set<OutputSource> testOutputSources = new HashSet<>();
    private int uniqueTopicSuffixId;

    public ProphetServerEmbeddedImpl() {
        // passing in a system property to gradle is difficult!
        try {
            configureProphetBootstrap();
            deleteChronicleFiles();
            configureLog4j("/log4j2-stdout.xml");
        } catch (Exception e) {
            throw new RuntimeException("Could not create prophet server.", e);
        }
    }

    public void start() {
        try {
            if (isRunning.get()) {
                LOGGER.debug("Prophet is running");
                return;
            }
            LOGGER.debug("Prophet is starting");
            startThreads();
            isRunning.set(true);
            LOGGER.debug("Prophet is started");
        } catch (Exception e) {
            throw new RuntimeException("Could not start prophet application.", e);
        }
    }

    public void stop() {
        try {
            if (!isRunning.get()) {
                return;
            }
            clearInputCommands();
            if (starInContext != null) {
                starInContext.destroy();
                starInContext.close();
                starInContext = null;
            }
            if (starOutContext != null) {
                starOutContext.destroy();
                starOutContext.close();
                starOutContext = null;
            }
            if (coreContext != null) {
                coreContext.destroy();
                coreContext.close();
                coreContext = null;
            }
            if (clientPricingContext != null) {
                clientPricingContext.destroy();
                clientPricingContext.close();
                clientPricingContext = null;
            }
            if (coreHedgerContext != null) {
                coreHedgerContext.destroy();
                coreHedgerContext.close();
                coreHedgerContext = null;
            }
            if (coreCrossContext != null) {
                coreCrossContext.destroy();
                coreCrossContext.close();
                coreCrossContext = null;
            }
            if (chOutReader != null) {
                chOutReader.close();
                chOutReader = null;
            }
            if (chHedgerOutReader != null) {
                chHedgerOutReader.close();
                chHedgerOutReader = null;
            }
            if (chCrossOutReader != null) {
                chCrossOutReader.close();
                chCrossOutReader = null;
            }
            if (dfPersister != null) {
                dfPersister.close();
                dfPersister = null;
            }
            bufferedOutput.getMessageQueue().clear();
            isRunning.set(false);

            // Clean up
            deleteChronicleFiles();
        } catch (IOException e) {
            throw new RuntimeException("Could not stop prophet application.", e);
        }
    }

    @Override
    public void clearOutputBuffer() {
        waitTillAllEventsAreProcessed("Ensure that all prior events are processed so that we don't get ghost messages (e.g., messages that should have been cleared but still appears because processing occurs on different thread than the test runner thread.).");
        bufferedOutput.getMessageQueue().clear();
    }

    @Override
    public void clearOutputBuffers() {
        clearOutputBuffer();
        clearUmOutputBuffer();
    }

    @Override
    public void clearUmOutputBuffer() {
        umSink.getMessageQueue().clear();
    }

    @Override
    public void clearInputCommands() {
        inputCommandList.clear();
    }

    @Override
    public void clearLogCapture() {
        logCaptureAppender.clearLogs();
    }

    @Override
    public void resetAllPositions() {
        starInContext.getBean(PositionAdjustmentProducer.class).resetAllPositions();
    }

    @Override
    public void resetManualSkews() {
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.ANY);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.AUD);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.CAD);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.EUR);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.GBP);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.JPY);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.NOK);
        starInContext.getBean(SkewCurrencyControlProducer.class).resumeSkew(Currency.NZD);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.AUD, 0.0);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.CAD, 0.0);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.EUR, 0.0);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.GBP, 0.0);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.JPY, 0.0);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.NOK, 0.0);
        starInContext.getBean(ManualSkewControlProducer.class).manualSkew(Currency.NZD, 0.0);
    }

    @Override
    public void resetAllPricingState() {
        pullAllPrices();
    }

    @Override
    public <T> LinkedList<T> getCommand(Class<T> clazz) {
        return (LinkedList<T>) inputCommandList.stream().filter(o -> clazz.isAssignableFrom(o.getClass())).collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    public void waitTillAllEventsAreProcessed(final String reason) {
        // using activate message as a proxy.
        final Activate activate = new Activate();
        activate.setInstanceToActivate(0);
        getChronicleInPersister().sink(MessageType.ACTIVATE).accept(activate);
        final long eventId = Context.context().header().getEventId();
        LOGGER.info("Waiting for Activation with eventId: {}", eventId);
        // we wait for 1 min, because event must definitely arrive but it may take long time if we are fast forwarding
        // further into the future - e.g., 1 day
        try {
            expectEndEvent(MessageType.ACTIVATE, new ExactMessageCountPredicate(testOutputSources.size()), output -> output.header.getEventId() >= eventId, WAIT_ITERATIONS);
        } catch (IllegalArgumentException iae) {
            LOGGER.error("Have already waited for {} seconds for events to flush. This indicates that processing takes longer than given time, you can increment time in smaller chunks to avoid this issue or reconsider your test case.",
                    MILLISECONDS.toSeconds(WAIT_TIME * WAIT_ITERATIONS));
            throw iae;
        }
    }

    @Override
    public void disableAllMarketDataFilter() {

    }

    @Override
    public void disableAllSkewing() {

    }

    @Override
    public void enablePricingFilter(final String filter) {

    }

    @Override
    public void setTradingTimeZone(final TradingTimeZone zone) {

    }

    @Override
    public void receive(final TradingTimeZone tradingTimeZone) {
        switch (tradingTimeZone) {
            case LDN:
                starInContext.getBean(ChimeManager.class).triggerTimeZoneLondon();
                break;
            case SNG:
                starInContext.getBean(ChimeManager.class).triggerTimeZoneSingapore();
                break;
            case WEEKEND:
                starInContext.getBean(ChimeManager.class).triggerEndOfWeekChime();
                break;
            default:
                throw new UnsupportedOperationException("Cannot handle timezone. " + tradingTimeZone + ". Please implement me!");
        }
    }

    @Override
    public void receive(final SpotDate spotDate) {
        getChronicleInPersister().sink(MessageType.SPOT_DATE).accept(spotDate);
    }

    @Override
    public void receive(final VolatilityControl volatilityControl) {
        getChronicleInPersister().sink(MessageType.VOLATILITY_CONTROL).accept(volatilityControl);
    }

    @Override
    public void receive(final BiasPositionControl biasPositionControl) {
        getChronicleInPersister().sink(MessageType.BIAS_OFFSET_CONTROL).accept(biasPositionControl);
    }

    @Override
    public void receive(final ManualSkewControl manualSkewControl) {
        getChronicleInPersister().sink(MessageType.MANUAL_SKEW_CONTROL).accept(manualSkewControl);
    }

    @Override
    public void receive(final ForwardPoint forwardPoint) {
        getChronicleInPersister().sink(MessageType.FORWARD_POINT).accept(forwardPoint);
    }

    @Override
    public void receiveFWDFromUM(final ForwardPoint forwardPoint) {
        receiveFromUm(forwardPoint, SecurityType.FXFWD);
    }

    @Override
    public void receiveNDFFromUM(final ForwardPoint forwardPoint) {
        receiveFromUm(forwardPoint, SecurityType.FXNDF);
    }

    @Override
    public void receiveNDFFromUm(final MarketDataSnapshot marketDataSnapshot) {
        umSource.pushToUm(marketDataSnapshot, SecurityType.FXNDF, Tenor.M1);
    }

    @Override
    public void receiveNDFFromUm(final MarketDataIncrement marketDataIncrement) {
        umSource.pushToUm(marketDataIncrement, SecurityType.FXNDF, Tenor.M1);
    }

    @Override
    public void receiveSpotSnapshotFromUm(final MarketDataSnapshot marketDataSnapshot) {
        umSource.pushToUm(marketDataSnapshot, SecurityType.FXSPOT, Tenor.SP);
    }

    @Override
    public void receiveSpotIncrementalFromUm(final MarketDataIncrement marketDataIncrement) {
        umSource.pushToUm(marketDataIncrement, SecurityType.FXSPOT, Tenor.SP);
    }


    private <T> void receiveFromUm(final T object, final SecurityType securityType) {
        umSource.pushToUm(object, securityType, Tenor.SP);
    }

    @Override
    public void receive(final MarketDataSnapshot marketDataSnapshot) {
        inputCommandList.add(marketDataSnapshot);
        getChronicleInPersister().sink(MessageType.MARKET_DATA_SNAPSHOT).accept(marketDataSnapshot);
    }

    @Override
    public void receiveFromUm(Trade trade) {
        umSource.pushToUm(trade, null, Tenor.SP);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void receive(final MarketDataIncrement marketDataIncrement) {
        inputCommandList.add(marketDataIncrement);
        getChronicleInPersister().sink(MessageType.MARKET_DATA_INCREMENT).accept(marketDataIncrement);
    }

    @Override
    public void receive(final ConfigurationData command) {
        receive(command, true, false);
    }

    @Override
    public void receive(final ConfigurationData command, final boolean clearOutputBuffer) {
        receive(command, clearOutputBuffer, false);
    }

    @Override
    public void receive(final ConfigurationData command, final boolean clearOutputBuffer, final boolean applicableToUm) {
        getChronicleInPersister().sink(MessageType.CONFIGURATION).accept(command);
        if (applicableToUm) {
            receiveConfigurationDataForUM(command);
        }
        if (clearOutputBuffer) {
            prophet.clearOutputBuffer();
        }
    }

    private void receiveConfigurationDataForUM(final ConfigurationData command) {
        final IndexedConfigurationData configurationData = new IndexedConfigurationData(command);

        umSource.consumeIndexConfigurationData(configurationData);

        // trigger star in to subscribe to um topics
        starInContext.getBean(LiquidityGatewayClient.class).consumerIndexedConfigurationData().accept(configurationData);
    }

    @Override
    public void receive(final EconNews command) {
        getChronicleInPersister().sink(MessageType.ECONNEWS).accept(command);
    }

    @Override
    public void receive(final Adjustment adjustment) {
        getChronicleInPersister().sink(MessageType.ADJUSTMENT).accept(adjustment);
    }

    @Override
    public void receive(final Adjustments adjustments) {
        getChronicleInPersister().sink(MessageType.ADJUSTMENTS).accept(adjustments);
    }

    @Override
    public void receive(Trade trade) {
        dfPersister.sink(MessageType.TRADE).accept(trade);
        // force this thread to wait for the trade to be received.
        expect(Level.INFO, Matchers.containsString("Received trade from DF"));
    }

    @Override
    public void receive(final OneSecond chime) {
        timeSource.incrementNanos(TimeUnit.SECONDS.toNanos(1));
    }

    @Override
    public void receive(final HourChime chime) {
        getChronicleInPersister().sink(MessageType.HOUR_CHIME).accept(chime);
    }

    @Override
    public void receive(final PricingFirewallReset pricingFirewallReset) {
        getChronicleInPersister().sink(MessageType.PRICING_FIREWALL_RESET).accept(pricingFirewallReset);
    }

    @Override
    public void receive(final HedgerFirewallReset hedgerFirewallReset) {
        getChronicleInPersister().sink(MessageType.HEDGER_FIREWALL_RESET).accept(hedgerFirewallReset);
    }

    @Override
    public void receive(OrderEvent orderEvent) {
        getChronicleInPersister().sink(MessageType.ORDER_EVENT).accept(orderEvent);
    }

    @Override
    public void receive(final OperatingHourChime operatingHourChime) {
        getChronicleInPersister().sink(MessageType.OPERATING_HOUR_CHIME).accept(operatingHourChime);
    }

    @Override
    public void receive(HedgeCurrencyControl hedgeCurrencyControl) {
        getChronicleInPersister().sink(MessageType.HEDGE_CURRENCY_CONTROL).accept(hedgeCurrencyControl);
    }

    @Override
    public void receive(SkewCurrencyControl skewCurrencyControl) {
        getChronicleInPersister().sink(MessageType.SKEW_CURRENCY_CONTROL).accept(skewCurrencyControl);
    }

    @Override
    public void receive(final CovCorrAvgs covCorrAvgs) {
        getChronicleInPersister().sink(MessageType.COV_CORR).accept(covCorrAvgs);
    }

    @Override
    public void receive(EndOfWeekChime endOfWeekChime) {
        getChronicleInPersister().sink(MessageType.END_OF_WEEK_CHIME).accept(endOfWeekChime);
    }

    @Override
    public void receive(PricePauseControl pricePauseControl) {
        getChronicleInPersister().sink(MessageType.PRICE_PAUSE_CONTROL).accept(pricePauseControl);
    }

    @Override
    public void receiveHedgeOrderFullFill(final NewOrder newOrder) {
        receiveHedgeOrderFullFill(newOrder, Double.NaN);
    }

    @Override
    public void receiveHedgeOrderFullFill(final NewOrder newOrder, final double fillPrice) {
        receiveHedgeOrderFullFillOrderEvent(newOrder, fillPrice);
        // simulate the deal event which FxAgg would normally provide
        receiveHedgeOrderFullFillTrade(newOrder, fillPrice);
    }

    @Override
    public void receiveHedgeOrderFullFillOrderEvent(final NewOrder newOrder, final double fillPrice) {
        final OrderEvent orderEvent = Double.isNaN(fillPrice) ? TestDataDictionaryImpl.hedgeOrderFullFill(newOrder) : TestDataDictionaryImpl.hedgeOrderFullFill(newOrder, fillPrice);
        GcFriendlyAssert.isTrue(orderEvent.getRemainingQuantity() == 0);
        receive(orderEvent);
    }

    @Override
    public void receiveHedgeOrderFullFillTrade(final NewOrder newOrder, final double fillPrice) {
        GcFriendlyAssert.isTrue(newOrder.getPortfolio().isHedger());
        // simulate an incoming Trade to cause position update
        final double qty = (newOrder.getSide() == HedgeOrderSide.BUY ? 1 : -1) * newOrder.getQuantity();
        final double price = Double.isNaN(fillPrice) ? newOrder.getPrice() : fillPrice;
        final Trade trade = TestDataDictionaryImpl.buildTrade(newOrder.getPortfolio(), newOrder.getInstrument(), qty, price, true, newOrder.getMarket(), newOrder.getId(), TradeType.HEDGING);
        receive(trade);
    }

    @Override
    public void receiveHedgeOrderPartialFill(final NewOrder newOrder, final double totalFilledQuantity,
                                             final double avgFilledPrice) {
        GcFriendlyAssert.isTrue(totalFilledQuantity < newOrder.getQuantity());
        receive(TestDataDictionaryImpl.hedgeOrderPartialFill(newOrder, totalFilledQuantity, avgFilledPrice));
    }

    @Override
    public void receiveHedgeOrderPartialFillTrade(final NewOrder newOrder, final double filledQuantity,
                                                  final double fillPrice) {
        // simulate an incoming Trade to cause position update
        final double qty = (newOrder.getSide() == HedgeOrderSide.BUY ? 1 : -1) * filledQuantity;
        final double price = Double.isNaN(fillPrice) ? newOrder.getPrice() : fillPrice;
        final Trade trade = TestDataDictionaryImpl.buildTrade(newOrder.getPortfolio(), newOrder.getInstrument(), qty, price, true, newOrder.getMarket(), newOrder.getId(), TradeType.HEDGING);
        receive(trade);
    }

    @Override
    public void receiveHedgeOrderPartialFillFullFill(final NewOrder newOrder, final double filledQuantity,
                                                     final double avgFilledPrice) {
        receive(TestDataDictionaryImpl.hedgeOrderPartialFillFullFill(newOrder, filledQuantity, avgFilledPrice));
    }

    @Override
    public void receiveHedgeOrderPartialFillOverFill(final NewOrder newOrder, final double filledQuantity,
                                                     final double totalFilledQuantity, final double avgFilledPrice) {
        receive(TestDataDictionaryImpl.hedgeOrderPartialFillOverFill(newOrder, filledQuantity, totalFilledQuantity, avgFilledPrice));
    }

    @Override
    public void receiveHedgeOrderCompletedWithPartialFill(final NewOrder newOrder, final double totalFilledQuantity,
                                                          final double avgFilledPrice) {
        GcFriendlyAssert.isTrue(totalFilledQuantity < newOrder.getQuantity());
        final OrderEventImpl orderEvent = TestDataDictionaryImpl.hedgeOrderPartialFill(newOrder, totalFilledQuantity, avgFilledPrice);
        orderEvent.setOrderEventType(OrderEventType.CANCELLED); // simulate cancelled part way through execution
        receive(orderEvent);

        // simulate the deal event which FxAgg would normally provide to cause position update
        GcFriendlyAssert.isTrue(orderEvent.getRemainingQuantity() != 0);
        final Portfolio portfolio = newOrder.getPortfolio();
        GcFriendlyAssert.isTrue(portfolio.isHedger());
        final double qty = (newOrder.getSide() == HedgeOrderSide.BUY ? 1 : -1) * orderEvent.getFilledQuantity();

        final Trade trade = TestDataDictionaryImpl.buildTrade(portfolio, orderEvent.getInstrument(), qty, orderEvent.getFilledPrice(), true, orderEvent.getMarket(), orderEvent.getOrderId(), TradeType.HEDGING);
        receive(trade);
    }

    @Override
    public void receive(final HedgeControl hedgeControl) {
        getChronicleInPersister().sink(MessageType.HEDGE_CONTROL).accept(hedgeControl);
    }

    @Override
    public <T> LinkedList<T> expect(final Class<T> outputType) throws IllegalStateException {
        //noinspection unchecked
        return expect(outputType, MessageCountPredicate.AT_LEAST_ONE, NoOpPredicate.NO_OP_PREDICATE);
    }

    @Override
    public <T> LinkedList<T> expect(final Class<T> outputType,
                                    final Predicate<Output<T>> messagePredicate) throws IllegalStateException {
        return expect(outputType, MessageCountPredicate.AT_LEAST_ONE, messagePredicate);
    }

    @Override
    public <T> LinkedList<T> expect(final Class<T> outputType,
                                    final MessageCountPredicate countPredicate) throws IllegalStateException {
        //noinspection unchecked
        return expect(outputType, countPredicate, NoOpPredicate.NO_OP_PREDICATE);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> LinkedList<T> expect(final Class<T> outputType,
                                    final MessageCountPredicate countPredicate,
                                    final Predicate<Output<T>> messagePredicate) throws IllegalStateException {
        return expectFromChronicle(outputType, countPredicate, messagePredicate, WAIT_ITERATIONS);
    }

    @Override
    public <T> LinkedList<T> expectFromUm(final Class<T> outputType,
                                          final MessageCountPredicate countPredicate,
                                          final Predicate<Output<T>> messagePredicate) throws IllegalStateException {
        return expectFromUm(outputType, countPredicate, messagePredicate, WAIT_ITERATIONS);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> void notExpect(final Class<T> outputType,
                              final Predicate<Output<T>> messagePredicate) throws IllegalStateException {
        waitTillAllEventsAreProcessed("Need to wait till all events are flushed through to avoid race condition.");
        final LinkedList<T> result = new LinkedList<>();
        final List<Output> messageQueue = bufferedOutput.getMessageQueue();
        filter(outputType, messagePredicate, result, messageQueue);

        if (result.size() > 0) {
            throw new IllegalStateException(format("Not expecting any %s but received %d message(s) as per below, \n %s", outputType.getSimpleName(), result.size(), result));
        }
    }

    @Override
    public <T> void notExpect(final Class<T> outputType) {
        notExpect(outputType, new NoOpPredicate<>());
    }

    @SuppressWarnings("unchecked")
    @Override
    public LinkedList<LogEvent> expect(final Level level,
                                       final Matcher<String> messageMatcher) throws IllegalStateException {
        waitTillAllEventsAreProcessed("To avoid race condition.");

        final LinkedList<LogEvent> results = logCaptureAppender.matches(level, messageMatcher);
        if (results.size() == 0) {
            throw new IllegalStateException(format("Expected log %s with %s.", level, messageMatcher));
        }
        return results;
    }

    @SuppressWarnings("unchecked")
    @Override
    public LinkedList<LogEvent> expect(final Class<? extends Throwable> throwable,
                                       final Matcher<String> messageMatcher) throws IllegalStateException {
        waitTillAllEventsAreProcessed("To avoid race condition.");
        final LinkedList<LogEvent> results = new LinkedList<>();
        for (int i = 0; i < logCaptureAppender.getLogEvents().size(); i++) {
            final LogEvent logEvent = logCaptureAppender.getLogEvents().get(i);
            if (logEvent.getThrown() != null &&
                    throwable.equals(logEvent.getThrown().getClass()) &&
                    messageMatcher.matches(logEvent.getThrown().getMessage())) {
                results.add(logEvent);
            }
        }
        if (results.size() == 0) {
            throw new IllegalStateException(format("Expected %s thrown with message %s.", throwable, messageMatcher));
        }
        return results;
    }

    @Override
    public void notExpect(final Level level,
                          final Matcher<String> messageMatcher) {
        waitTillAllEventsAreProcessed("To avoid race condition.");

        final LinkedList<LogEvent> results = logCaptureAppender.matches(level, messageMatcher);

        if (results.size() != 0) {
            throw new IllegalStateException(format("Not expected log %s with %s but found %s messages", level, messageMatcher, results.size()));
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void notExpect(final Class<? extends Throwable> throwable,
                          final Matcher<String> messageMatcher) throws IllegalStateException {
        waitTillAllEventsAreProcessed("To avoid race condition.");
        final LinkedList<LogEvent> results = new LinkedList<>();
        for (int i = 0; i < logCaptureAppender.getLogEvents().size(); i++) {
            final LogEvent logEvent = logCaptureAppender.getLogEvents().get(i);
            if (logEvent.getThrown() != null &&
                    throwable.equals(logEvent.getThrown().getClass()) &&
                    messageMatcher.matches(logEvent.getThrown().getMessage())) {
                results.add(logEvent);
            }
        }
        if (results.size() != 0) {
            throw new IllegalStateException(format("Not expected %s thrown with message %s.", throwable, messageMatcher));
        }
    }

    @Override
    public long now() {
        return Context.context().timeSource().nowMillis();
    }

    @Override
    public long incrementTime(final long incrementMS) {
        final TestTimeSource timeSource = (TestTimeSource) Context.context().timeSource();
        timeSource.incrementNanos(MILLISECONDS.toNanos(incrementMS));
        waitTillAllEventsAreProcessed("To avoid race condition because there can be lots of OneSecond events generated and it could take time to process.");
        return now();
    }

    @Override
    public void receiveOperatingHourStateForAllEntities(final OperatingHourSpecification.State operatingHourState) {
        for (final OperatingHourEntity entity : OperatingHourEntity.VALUES) {
            final OperatingHourChime chime = new OperatingHourChime();
            chime.setEntity(entity);
            chime.getSpecification().set(new OperatingHourSpecification(operatingHourState, DayOfWeek.MONDAY, LocalTime.now(), ZoneId.of("Australia/Sydney")));
            receive(chime);
        }
    }

    @Override
    public void setRegion(final Region region) {
        Context.region(region);
    }

    @Override
    public void incrementTime(final Runnable beforeTimeHasReached, final long incrementMS) {
        incrementTime(incrementMS - 1);
        beforeTimeHasReached.run();
        incrementTime(1);
    }


    @Override
    public List<Output> getBufferedOutput() {
        return bufferedOutput.getMessageQueue();
    }

    @Override
    public void setUpDefaultSpotDates() {
        this.receive(new SpotDateImpl(Instrument.AUDUSD, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.AUDJPY, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.CADJPY, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.CHFJPY, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.EURUSD, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.EURAUD, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.EURDKK, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.EURCAD, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.EURNOK, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.EURSEK, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.NOKSEK, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.USDCAD, LocalDate.now().plusDays(1)));
        this.receive(new SpotDateImpl(Instrument.USDCHF, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.USDJPY, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.USDHKD, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.USDSGD, LocalDate.now().plusDays(2)));
        this.receive(new SpotDateImpl(Instrument.SGDHKD, LocalDate.now().plusDays(2)));
    }

    private void configureProphetBootstrap() throws IOException {
        System.getProperties().load(new FileInputStream(FileUtil.findClasspathFile("common.properties")));

        final String propsFileName = String.format("%s.core.properties", System.getProperty(PROPERTY_CORE_MODE));
        final String coreProperties = resolveWithLegacyFlags(propsFileName);

        System.getProperties().load(new FileInputStream(FileUtil.findClasspathFile(coreProperties)));

        // TODO: Reload not necessary once TC builds have been updated to add the prophet.core.mode build parameters
        SystemProperties.reloadSystemProperties();

        LOGGER.info("Running in '{}' core mode", SystemProperties.CORE_MODE);
    }

    @Deprecated
    private String resolveWithLegacyFlags(final String coreProperties) {
        if (!coreProperties.startsWith("null")) {
            return coreProperties;
        }

        LOGGER.warn("Using legacy flags. Please add the necessary parameters to the TC build!");
        final boolean startHedgerCore = Boolean.getBoolean("prophet.acceptance.test.use_hedger_core");
        final boolean splitPricingCore = Boolean.getBoolean("prophet.acceptance.test.split_pricing_core");
        if (splitPricingCore) {
            return "triple.core.properties";
        } else if (startHedgerCore) {
            return "dual.core.properties";
        } else {
            return "single.core.properties";
        }
    }

    private void configureLog4j(final String log4jConfigPath) throws URISyntaxException {
        final LoggerContext context = (LoggerContext) LogManager.getContext(false);
        final URL resource = ProphetServerEmbeddedImpl.class.getResource(log4jConfigPath);
        context.setConfigLocation(resource.toURI());
        final Configuration config = context.getConfiguration();

        // attach to logger.
        logCaptureAppender = new LogCaptureAppender(Level.INFO);

        context.updateLoggers(config);
    }

    private void createTimeSource() {
        timeSource = new PublishingTestTimeSource(START_TIME_MS);
        LOGGER.info("Created new time source starting at {}ms", timeSource.nowMillis());
        Context.set(new Context(timeSource));
    }

    private void startThreads() throws Exception {
        configureProphetBootstrap();
        createTimeSource();
        createUniqueUmTopicSuffices();
        createDfPersister();
        starInContext = Main.createApplication(StarfishInConfig.class.getSimpleName(), StarInAtestConfig.class.getName());
        switch (SystemProperties.CORE_MODE) {
            case SINGLE:
                coreContext = Main.createApplication(CoreConfig.class.getSimpleName(), CoreConfig.class.getName());
                startRunnerBean(coreContext, "core-context");
                break;
            case DUAL:
                coreContext = Main.createApplication(CorePricingConfig.class.getSimpleName(), CorePricingConfig.class.getName());
                startRunnerBean(coreContext, "core-pricing-context");
                coreHedgerContext = Main.createApplication(CoreHedgingConfig.class.getSimpleName(), CoreHedgingConfig.class.getName());
                startRunnerBean(coreHedgerContext, "core-hedger-context");
                break;
            case TRIPLE:
                coreContext = Main.createApplication(CoreDriverPricingConfig.class.getSimpleName(), CoreDriverPricingConfig.class.getName());
                startRunnerBean(coreContext, "core-pricing-context");
                coreCrossContext = Main.createApplication(CoreCrossConfig.class.getSimpleName(), CoreCrossConfig.class.getName());
                startRunnerBean(coreCrossContext, "core-cross-context");
                coreHedgerContext = Main.createApplication(CoreHedgingConfig.class.getSimpleName(), CoreHedgingConfig.class.getName());
                startRunnerBean(coreHedgerContext, "core-hedger-context");
                break;
        }
        timeSource.setConsumerOneSecond(getChronicleInPersister().sink(MessageType.ONE_SECOND));
        timeSource.setConsumerHourChime(getChronicleInPersister().sink(MessageType.HOUR_CHIME));
        subscribeToChronicleOut();
        LOGGER.info("Application started.");
    }

    private void createDfPersister() throws IOException {
        dfPersister = ChroniclePersisterFactory.createToolsCommonPersister(System.getProperty("chronicle.df.path"));
    }

    private void createUniqueUmTopicSuffices() {
        final Random random = new Random();
        uniqueTopicSuffixId = random.nextInt(1024);
        System.setProperty("um.topicSuffix", UM_IN_SUFFIX_PLACEHOLDER + uniqueTopicSuffixId);
        System.setProperty("um.deal.origins", UM_IN_SUFFIX_PLACEHOLDER + uniqueTopicSuffixId);
        System.setProperty("clientpricepublisher.suffix", "cppUmSink" + uniqueTopicSuffixId);
        System.setProperty("unskewedpricepublisher.suffix", "uppUmSink" + uniqueTopicSuffixId);
    }

    @Override
    public void startUmProbes(final ConfigurationData configurationData, final boolean restart) throws Exception {
        startUmProbes(restart);
        receive(configurationData, false, true);
    }

    private void startUmProbes(final boolean restart) throws Exception {
        if (starOutContext == null) {
            // set the allowable lag time to be the maximum to ensure no message is filtered
            System.setProperty("allowable.lag.from.real.time.ms", String.valueOf(Long.MAX_VALUE));
            starOutContext = Main.createApplication(StarfishOutConfig.class.getSimpleName(), StarOutAtestConfig.class.getName());
        }

        if (starInContext == null) {
            starInContext = Main.createApplication(StarfishInConfig.class.getSimpleName(), StarInAtestConfig.class.getName());
        }

        if (umSource == null || restart) {
            // for source, use connection details from starIn
            final Connection umConnectionIn = starInContext.getBean("umConnection", Connection.class);
            final MillenniumFalcon falcon = starInContext.getBean(MillenniumFalcon.class);
            final String dealTopic = starInContext.getEnvironment().getProperty("um.deal.topic");

            umSource = new UmSource(umConnectionIn, falcon, UM_IN_SUFFIX_PLACEHOLDER + uniqueTopicSuffixId, dealTopic);
        }

        if (umSink == null || restart) {
            final Connection umConnectionOut = starOutContext.getBean(Connection.class);

            // for sink, use connection details from starOut
            umSink = new UmSink(umConnectionOut,
                    Arrays.asList(Market.WSP_A, Market.WSP_B, Market.WSP_C, Market.WSP_Z),
                    Collections.singletonList(Instrument.ANY),
                    "cppUmSink" + uniqueTopicSuffixId,
                    Arrays.asList(Market.WSP_U),
                    Collections.singletonList(Instrument.ANY),
                    "uppUmSink" + uniqueTopicSuffixId);
        }
    }

    @Override
    public void startUmOutSubscription(final Market market, final Instrument instrument) {
        umSink.openSubscriptions(market, instrument);
    }

    @Override
    public void startUmOutSubscription(final Market[] markets, final Instrument instrument) {
        for (Market m : markets) {
            umSink.openSubscriptions(m, instrument);
        }
    }

    @Override
    public void stopUmProbes() throws Exception {
        if (umSource != null) {
            umSource.close();
            starInContext.getBean(LiquidityGatewayClient.class).close();
            starInContext.getBean(TradeUmClient.class).close();
        }
        if (umSink != null) {
            umSink.close();
        }
    }

    private void deleteChronicleFiles() {
        for (String chroniclePropertyName : CHRONICLE_FILE_PROPERTY_NAMES) {
            deleteChronicleFileBySysProperty(chroniclePropertyName);
        }

        final String chronicleOutPath = System.getProperty(PROPERTY_CHRONICLE_OUT_PATH, "");
        final String chronicleClientPxOutPath = System.getProperty(PROPERTY_CLIENT_PRICING_OUT_PATH, "");
        for (int i = 0; i < 20; i++) {
            deleteChronicleFileByFileName(chronicleOutPath);
            deleteChronicleFileByFileName(chronicleClientPxOutPath);
        }
    }

    private void startRunnerBean(final AnnotationConfigApplicationContext context, final String name) {
        if (context.containsBean(RUNNER_BEAN)) {
            final Runnable runnable = context.getBean(RUNNER_BEAN, Runnable.class);
            final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat(name).build();
            final ExecutorService executorService = Executors.newSingleThreadExecutor(threadFactory);
            executorService.execute(runnable);
        }
    }

    private void deleteChronicleFileBySysProperty(final String chronicleInFileRef) {
        final String filename = System.getProperty(chronicleInFileRef);
        deleteChronicleFileByFileName(filename);
    }

    private void deleteChronicleFileByFileName(final String chronicleInFileRef) {
        final String filenameIndex = chronicleInFileRef + ".index";
        tryDeleteFile(filenameIndex);

        final String filenameData = chronicleInFileRef + ".data";
        tryDeleteFile(filenameData);

        if (chronicleInFileRef != null) {
            final File root = new File(chronicleInFileRef);
            if (root.exists()) {
                FileSystemUtils.deleteRecursively(root);
            }
        }
    }

    private void tryDeleteFile(final String filename) {
        GcFriendlyAssert.notNull(filename);
        File file = new File(filename);
        if (file.exists()) {
            if (file.delete()) {
                LOGGER.info("File '{}' deleted.", file.getAbsolutePath());
            } else {
                LOGGER.warn("File '{}' could not be deleted.", file.getAbsolutePath());
            }
        }
    }

    private void subscribeToChronicleOut() throws IOException {
        LOGGER.info("Subscribing to chronicle out in mode: '{}'", SystemProperties.CORE_MODE);
        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("chronicle-out-subscriber").build();

        // TODO: come back to enabling RB
        final RingBuffer ringBufferEnabled = RingBuffer.NO_RING;
        switch (SystemProperties.CORE_MODE) {
            case SINGLE:
                testOutputSources.add(OutputSource.CORE);
                chOutReader = ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory),
                        bufferedOutput.readFrom(OutputSource.CORE),
                        System.getProperty(PROPERTY_CHRONICLE_IN_STAROUT_PATH),
                        StartAt.END, ringBufferEnabled);
                break;
            case DUAL:
                // When running in 1-pricing-1-hedger-core mode, we get output from two chronicle queues
                testOutputSources.add(OutputSource.CORE_PRICER);
                chOutReader = ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory),
                        bufferedOutput.readFrom(OutputSource.CORE_PRICER),
                        System.getProperty(PROPERTY_CHRONICLE_IN_STAROUT_PATH),
                        StartAt.END, ringBufferEnabled);

                testOutputSources.add(OutputSource.CORE_HEDGER);
                chHedgerOutReader = ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory),
                        bufferedOutput.readFrom(OutputSource.CORE_HEDGER),
                        System.getProperty(PROPERTY_HEDGER_OUT_PATH),
                        StartAt.END, ringBufferEnabled);
                break;
            case TRIPLE:
                testOutputSources.add(OutputSource.CORE_PRICER);
                chOutReader = ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory),
                        bufferedOutput.readFrom(OutputSource.CORE_PRICER),
                        System.getProperty(PROPERTY_CHRONICLE_IN_STAROUT_PATH),
                        StartAt.END, ringBufferEnabled);

                testOutputSources.add(OutputSource.CORE_CROSS);
                chCrossOutReader = ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory),
                        bufferedOutput.readFrom(OutputSource.CORE_CROSS),
                        System.getProperty(PROPERTY_CROSS_OUT_PATH),
                        StartAt.END, ringBufferEnabled);

                testOutputSources.add(OutputSource.CORE_HEDGER);
                chHedgerOutReader = ChronicleReaderFactory.createSimpleReader(Executors.newSingleThreadExecutor(threadFactory),
                        bufferedOutput.readFrom(OutputSource.CORE_HEDGER),
                        System.getProperty(PROPERTY_HEDGER_OUT_PATH),
                        StartAt.END, ringBufferEnabled);
                break;
        }
    }

    private void pullAllPrices() {
        final LinkedList<MarketDataSnapshot> marketData = getCommand(MarketDataSnapshot.class);
        final TestDataDictionaryImpl tdd = new TestDataDictionaryImpl();
        for (final MarketDataSnapshot md : marketData) {
            this.receive(tdd.emptyMarketDataSnapshot(md.getMarket(), md.getInstrument()));
        }
    }

    private ProphetPersister getChronicleInPersister() {
        return starInContext.getBean(ProphetPersister.class);
    }

    private LinkedList<EndEvent> expectEndEvent(final MessageType messageType,
                                                final MessageCountPredicate countPredicate,
                                                final Predicate<Output<EndEvent>> messagePredicate,
                                                final long waitIteration) throws IllegalStateException {
        return expectFromChronicle(EndEvent.class, countPredicate, messagePredicate.and(o -> o.data.getMessageType() == messageType), waitIteration);
    }

    private <T> LinkedList<T> expectFromChronicle(final Class<T> outputType,
                                                  final MessageCountPredicate countPredicate,
                                                  final Predicate<Output<T>> messagePredicate,
                                                  final long waitIteration) throws IllegalStateException {
        return expect(outputType, countPredicate, messagePredicate, waitIteration, bufferedOutput::getMessageQueue);
    }

    private <T> LinkedList<T> expectFromUm(final Class<T> outputType,
                                           final MessageCountPredicate countPredicate,
                                           final Predicate<Output<T>> messagePredicate,
                                           final long waitIteration) {
        return expect(outputType, countPredicate, messagePredicate, waitIteration, umSink::getMessageQueue);
    }

    private <T> LinkedList<T> expect(final Class<T> outputType,
                                     final MessageCountPredicate countPredicate,
                                     final Predicate<Output<T>> messagePredicate,
                                     final long waitIteration,
                                     final Supplier<List<Output>> messageQueueSupplier) throws IllegalStateException {
        // we are no longer user real time, but still, as core is writing in a different thread, and
        // all components have some jitter, we loop round waiting for a short (by human standards period)
        final LinkedList<T> result = new LinkedList<>();

        int loops = 0;
        while (loops++ < waitIteration && !countPredicate.test(result)) {
            result.clear();
            filter(outputType, messagePredicate, result, messageQueueSupplier.get());
            ThreadUtils.sleep(WAIT_TIME);
        }
        if (!countPredicate.test(result)) {
            throw new IllegalStateException(format("%s of type %s but received %d message(s).", countPredicate.toString(), outputType.getName(), result.size()));
        }
        return result;
    }

    private <T> void filter(final Class<T> outputType,
                            final Predicate<Output<T>> messagePredicate,
                            final LinkedList<T> result,
                            final List<Output> messageQueue) {
        for (int i = 0; i < messageQueue.size(); i++) {
            final Output output = messageQueue.get(i);
            if (outputType.isAssignableFrom(output.data.getClass())) {
                if (messagePredicate.test(output)) {
                    result.add((T) output.data);
                }
            }
        }
    }

    private static class NoOpPredicate<T> implements Predicate<Output<T>> {
        static final NoOpPredicate NO_OP_PREDICATE = new NoOpPredicate();

        @Override
        public boolean test(final Output<T> t) {
            return true;
        }
    }
}
