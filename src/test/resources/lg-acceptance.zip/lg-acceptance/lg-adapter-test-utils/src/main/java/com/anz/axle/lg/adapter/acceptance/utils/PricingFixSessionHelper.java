package com.anz.axle.lg.adapter.acceptance.utils;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MDReqRejReason;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.integration.quickfix.QuickFixProperties;
import org.fix4j.test.session.ContextFactory;
import org.fix4j.test.session.FixConnectionMode;
import org.fix4j.test.session.FixSessionId;
import org.fix4j.test.session.MatchingSession;
import org.fix4j.test.session.SessionContext;
import org.fix4j.test.util.StringUtils;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.getRandomFreeLocalPort;

public class PricingFixSessionHelper {
    private static final int PRICING_FIX_PORT = 34012;
    private final String pricingSenderCompId;
    private final String pricingTargetCompId;
    private final String acceptorFixVersion;
    private final int port;

    public PricingFixSessionHelper(final String appName, final String pricingSenderCompId, final String pricingTargetCompId, final String acceptorFixVersion) {
        if (appName == null) throw new IllegalArgumentException("appName must not be null");

        this.pricingSenderCompId = pricingSenderCompId;
        this.pricingTargetCompId = pricingTargetCompId;
        this.acceptorFixVersion = acceptorFixVersion;

        final String useDefaultPort = System.getProperty("useDefaultPort");
        this.port = useDefaultPort == null ? getRandomFreeLocalPort() : PRICING_FIX_PORT;

        final String waitTimeout = System.getProperty("fix4j.default.fix.msg.wait.timeout.ms", "30000");

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + appName +
                                "," + appName + ".fix.socket.use.ssl:N" +
                                "," + appName + ".fix.log.destination:STDOUT" +
                                "," + appName + ".fix.reconnectInterval:1" +
                                "," + appName + ".fix.sendercompid:" + pricingSenderCompId +
                                "," + appName + ".fix.targetcompid:" + pricingTargetCompId +
                                "," + appName + ".fix.host:localhost" +
                                "," + appName + ".fix.port:" + port+

                                "," + appName + ".fix.pricing.sendercompid:" + pricingSenderCompId +
                                "," + appName + ".fix.pricing.targetcompid:" + pricingTargetCompId +
                                "," + appName + ".fix.pricing.host:localhost" +
                                "," + appName + ".fix.pricing.port:" + port +
                                "," + appName + ".fix.file.log.path:target/fix/log/" +
                                "," + appName + ".fix.file.store.path:target/fix/store/" +

                                ",fix4j.default.fix.msg.wait.timeout.ms:" + waitTimeout +
                                ",fix4j.quickfix.validate.unordered.group.fields:N" +
                                "," + QuickFixProperties.USE_DATA_DICTIONARY.getKey() + ":N"
                ));
    }

    public PricingFixSessionHelper(final String appName, final String pricingSenderCompId, final String pricingTargetCompId, final String acceptorFixVersion, final String dataDictionaryLocation) {
        this(appName,pricingSenderCompId, pricingTargetCompId, acceptorFixVersion);

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "fix4j.quickfix.data.dictionary:" + dataDictionaryLocation +
                        "," + QuickFixProperties.USE_DATA_DICTIONARY.getKey() + ":Y"
                ));
    }

    public MatchingSession createPricingSession() {
        final ContextFactory contextFactory = new FixAssertContextFactory(FixAssertQuickFixSessionFactory::new);

        final SessionContext sessionContext = contextFactory.createSessionContext(
                new FixSessionId(acceptorFixVersion, pricingTargetCompId, pricingSenderCompId),
                FixConnectionMode.ACCEPTOR,
                StringUtils.parseMap("fix4j.quickfix.socket.accept.port:" + port));

        sessionContext.fixEngineSession.startup();

        return new CustomMatchingSession(sessionContext);
    }

    public final FixMessage marketDataRequestRejectFixMessage(String marketDataRequestId) {
        return marketDataRequestRejectFixMessageBuilder(marketDataRequestId)
                .withField(FieldTypes.MDReqRejReason, MDReqRejReason.Values.INSUFFICIENT_BANDWIDTH)
                .withField(FieldTypes.Text, "reject reason")
                .build();
    }

    public final FixMessageBuilder marketDataRequestRejectFixMessageBuilder(String marketDataRequestId) {
        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATAREQUESTREJECT.getOrdinal())
                .withField(FieldTypes.MDReqID, marketDataRequestId);
    }
}
