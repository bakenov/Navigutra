package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.Objects;
import java.util.function.IntSupplier;
import java.util.function.ToIntFunction;

import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

public final class PackedDateDecoder implements DateDecoder {

    private final ToIntFunction<LocalDatePacking> packedDateSupplier;

    public PackedDateDecoder(final ToIntFunction<LocalDatePacking> packedDateSupplier) {
        this.packedDateSupplier = Objects.requireNonNull(packedDateSupplier);
    }

    public static PackedDateDecoder forPackedDateSupplier(final ToIntFunction<LocalDatePacking> packedDateSupplier) {
        return new PackedDateDecoder(packedDateSupplier);
    }

    public static PackedDateDecoder forBinaryPackedDateSupplier(final IntSupplier binaryPackedDateSupplier) {
        Objects.requireNonNull(binaryPackedDateSupplier);
        return forPackedDateSupplier(packing -> packing.repack(
                binaryPackedDateSupplier.getAsInt(), LocalDatePacking.BINARY)
        );
    }

    public static PackedDateDecoder forDecimalPackedDateSupplier(final IntSupplier decimalPackedDateSupplier) {
        Objects.requireNonNull(decimalPackedDateSupplier);
        return forPackedDateSupplier(packing -> packing.repack(
                decimalPackedDateSupplier.getAsInt(), LocalDatePacking.DECIMAL)
        );
    }

    private int binaryPackedDate() {
        return packedDateSupplier.applyAsInt(LocalDatePacking.BINARY);
    }

    @Override
    public long decodeEpochDays() {
        final int packed = binaryPackedDate();
        return packed == 0 ? 0 : Epoch.toEpochDays(
                LocalDatePacking.BINARY.unpackYear(packed),
                LocalDatePacking.BINARY.unpackMonth(packed),
                LocalDatePacking.BINARY.unpackDay(packed)
        );
    }

    @Override
    public int decodeYear() {
        final int packed = binaryPackedDate();
        return packed == 0 ? 0 : LocalDatePacking.BINARY.unpackYear(packed);
    }

    @Override
    public int decodeMonth() {
        final int packed = binaryPackedDate();
        return packed == 0 ? 0 : LocalDatePacking.BINARY.unpackMonth(packed);
    }

    @Override
    public int decodeDay() {
        final int packed = binaryPackedDate();
        return packed == 0 ? 0 : LocalDatePacking.BINARY.unpackDay(packed);
    }

    @Override
    public int decodePacked(final LocalDatePacking packing) {
        return packedDateSupplier.applyAsInt(packing);
    }

    @Garbage(Garbage.Type.RESULT)
    public LocalDate decodeLocalDateOrNull() {
        final int packed = binaryPackedDate();
        return (packed == 0) ? null : LocalDate.of(
                LocalDatePacking.BINARY.unpackYear(packed),
                LocalDatePacking.BINARY.unpackMonth(packed),
                LocalDatePacking.BINARY.unpackDay(packed)
        );
    }
}