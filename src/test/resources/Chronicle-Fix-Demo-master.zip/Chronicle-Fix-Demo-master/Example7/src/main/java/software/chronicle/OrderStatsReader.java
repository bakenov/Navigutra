package software.chronicle;

import software.chronicle.generated.code.MessageManifest;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.HeaderTrailer;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public class OrderStatsReader implements Consumer<HeaderTrailer> {

    private final Map<String, OrderInfo> stats;

    public OrderStatsReader() {
        stats = new LinkedHashMap<>();
    }

    @Override
    public void accept(HeaderTrailer message) {
        if (message.msgType() == MessageManifest.ExecutionReport) {
            ExecutionReport er = (ExecutionReport) message;
            OrderInfo orderInfo = stats.computeIfAbsent(er.clOrdID().toString(), OrderInfo::new);
            orderInfo.ers++;
            orderInfo.avgPx = er.avgPx();
        } else if (message.msgType() == MessageManifest.NewOrderSingle) {
            NewOrderSingle nos = (NewOrderSingle) message;
            OrderInfo orderInfo = stats.computeIfAbsent(nos.clOrdID().toString(), OrderInfo::new);
            orderInfo.sendingTime = nos.sendingTime();
        }
    }

    @Override
    public String toString() {
        return "OrderStatsReader{" +
                "stats=" + stats +
                '}';
    }

    private static class OrderInfo {
        final String clordid;
        int ers = 0;
        double avgPx;
        long sendingTime;

        OrderInfo(String clordid) {
            this.clordid = clordid;
        }

        @Override
        public String toString() {
            return "OrderInfo{" +
                    "clordid='" + clordid + '\'' +
                    ", ers=" + ers +
                    ", avgPx=" + avgPx +
                    ", sendingTime=" + sendingTime +
                    '}';
        }
    }
}