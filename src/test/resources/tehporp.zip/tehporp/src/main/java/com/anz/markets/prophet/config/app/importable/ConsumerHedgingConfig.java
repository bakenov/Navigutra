package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.backtest.BackTestManager;
import com.anz.markets.prophet.config.business.FailSafeConfigManager;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.domain.time.SpotDateRollChime;
import com.anz.markets.prophet.hedger.HedgeManager;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallManager;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.marketdata.aggbook.TriangulatedMidRateManager;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.hedging.pnl.HedgersRevalProfitAndLossManager;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.prophet.riskpath.RiskPathManager;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceRealTime;
import com.anz.markets.prophet.syscontrol.ActivationProcessor;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.syscontrol.NotifierChecked;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.function.Consumer;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;

@Configuration
@Import({BusinessConfig.class, BackTestConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class ConsumerHedgingConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ConsumerHedgingConfig.class);

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public Consumer<Activate> activateConsumers(final ActivationProcessor activationProcessor) {
        return activationProcessor;
    }

    @Bean
    public Consumer<ConfigurationData> configurationDataConsumer(final FailSafeConfigManager failSafeConfigManager) {
        return failSafeConfigManager.consumerConfigurationData();
    }

    @Bean
    public Consumer<Adjustment> adjustmentConsumers(final RiskPathManager riskPathManager) {
        return riskPathManager.consumerOfAdjustment();
    }

    @Bean
    public Consumer<Adjustments> adjustmentsConsumers(final RiskPathManager riskPathManager) {
        return riskPathManager.consumerOfAdjustments();
    }

    @Bean
    public Consumer<EconNews> econNewsConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfEconNews());
    }

    // Note that HedgeManager expects trade to be consumed prior to Positions (as it uses Positions update to trigger a collective decision)
    @Bean
    public Consumer<Trade> tradeConsumer(final HedgeManager hedgeManager,
                                         final HedgeFirewallManager hedgeFirewallManager,
                                         final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
                                         final RiskPathManager riskPathManager) {
        return new NotifierChecked(hedgeFirewallManager.consumerOfTrade(), hedgersRevalProfitAndLossManager.consumerOfTrade(), hedgeManager.consumerOfTrade(), riskPathManager.consumerOfTrade());
    }

    @Bean
    public Consumer<MarketDataSnapshot> marketDataConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfMarketData());
    }

    @Bean
    public Consumer<MarketDataSnapshot> unskewedMidRateConsumer(final TriangulatedMidRateManager triangulatedMidRateManager,
                                                                final HedgeFirewallManager hedgeFirewallManager,
                                                                final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
                                                                final RiskPathManager riskPathManager) {
        return new NotifierDefault(
                triangulatedMidRateManager.consumerOfDriverMidRate(),
                hedgeFirewallManager.consumerOfMidRate(),
                hedgersRevalProfitAndLossManager.consumerOfMidRate(),
                riskPathManager.consumerOfMidRate());
    }

    @Bean
    public Consumer<MarketDataSnapshot> allAggBookConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfAggregatedBookMidRate());
    }

    @Bean
    public Consumer<OptimalPositions> optimalPositionsConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfOptimalPositions());
    }

    @Bean
    public Consumer<Positions> positionsConsumer(final HedgeManager hedgeManager) {
        return positions -> {
            if (positions.getPortfolio() == Portfolio.CLIENTS_NET || positions.getPortfolio() == Portfolio.BIASED_CLIENTS_NET) {
                hedgeManager.consumerOfPositions().accept(positions);
            }
        };
    }

    @Bean
    public Consumer<ValueAtRisk> valueAtRiskConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfValueAtRisk());
    }

    @Bean
    public ActivationProcessor activationProcessor(@Value("${core.instance:0}") final int coreInstance,
                                                   @Qualifier("activateSink") final Consumer<Activate> activateSink,
                                                   final HedgeManager hedgeManager) {
        return new ActivationProcessor(new NotifierDefault<>(hedgeManager.consumerOfActivate(), activateSink), coreInstance);
    }

    @Bean
    public Consumer<OneSecond> oneSecondConsumer(final HedgeManager hedgeManager,
                                                 final HedgeFirewallManager hedgeFirewallManager,
                                                 final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager) {
        return new NotifierDefault(
                hedgeFirewallManager.consumerOfOneSecond(),
                hedgeManager.consumerOfOneSecond(),
                hedgersRevalProfitAndLossManager.consumerOfOneSecond()
        );
    }

    @Bean
    public Consumer<EndOfWeekChime> endOfWeekChimeConsumer(final RiskPathManager riskPathManager) {
        return new NotifierDefault<>(riskPathManager.consumerOfEndOfWeekChime());
    }

    @Bean
    public Consumer<OrderEvent> orderEventConsumer(final HedgeManager hedgeManager,
                                                   final HedgeFirewallManager hedgeFirewallManager) {
        return new NotifierDefault<>(hedgeManager.consumerOfOrderEvent(), hedgeFirewallManager.consumerOfOrderEvent());
    }

    @Bean
    public FailSafeConfigManager configProcessor(final ConfigurationData configurationDataDefault,
                                                 final HedgeManager hedgeManager,
                                                 final HedgeFirewallManager hedgeFirewallManager,
                                                 final TriangulatedMidRateManager triangulatedMidRateManager,
                                                 final RiskPathManager riskPathManager,
                                                 final BackTestManager backTestManager,
                                                 @Qualifier("configurationSink") final Consumer<IndexedConfigurationData> configurationSink,
                                                 @Value("${business.config.json.file:/business.config.json}") final String jsonFile,
                                                 @Value("${fail.safe.config.manager.should.initialise.with.cache:true}") final boolean shouldInitialiseWithCache,
                                                 @Value("${fail.safe.config.manager.should.write.to.disk:true}") final boolean writeToDisk,
                                                 @Value("${core.instance}") final byte coreInstance,
                                                 @Value("${default.active.core.instance}") final int defaultActiveCoreInstance) throws IOException {

        final Consumer<IndexedConfigurationData> consumers = new NotifierDefault<>(
                hedgeManager.consumerIndexedConfigurationData(),
                hedgeFirewallManager.consumerOfConfiguration(),
                triangulatedMidRateManager.consumerIndexedConfigurationData(),
                riskPathManager.consumerIndexedConfigurationData(),
                configurationSink);

        // make sure only one core writes config file. TODO: wire up FailSafeConfigManager to activate msg
        final boolean activeAndCanWrite = writeToDisk && (coreInstance == defaultActiveCoreInstance);
        return FailSafeConfigManager.createInstance(shouldInitialiseWithCache, activeAndCanWrite, backTestManager.isBackTestEnabled(),
                (ConfigurationDataDefault) configurationDataDefault, jsonFile, consumers);
    }

    @Bean
    public Consumer<HedgeControl> hedgeControlConsumer(final HedgeManager hedgeManager,
                                                       final HedgeFirewallManager hedgeFirewallManager) {
        return new NotifierDefault<>(hedgeFirewallManager.consumerOfHedgeControl(), hedgeManager.consumerOfHedgeControl());
    }

    @Bean
    public Consumer<HedgeCurrencyControl> hedgeCurrencyControlConsumer(final HedgeManager hedgeManager) {
        return hedgeManager.consumerOfHedgeCurrencyControl();
    }

    @Bean
    public Consumer<HedgeFirewallStatus> hedgeFirewallStatusConsumer(final HedgeManager hedgeManager) {
        return hedgeManager.consumerOfHedgeFirewallStatus();
    }

    @Bean
    public HedgeManager hedgeManager(@Value("${hedger.canSendOrders:false}") final boolean canSendOrders,
                                     @Value("${hedger.autoAcknowledgeOrders:false}") final boolean autoAcknowledge,
                                     final Consumer<Order> orderSink,
                                     final Consumer<HedgeStatus> hedgeStatusSink,
                                     final Consumer<HedgeDecision> hedgeDecisionSink,
                                     @Qualifier("hedgeCurrencyControlSink") final Consumer<HedgeCurrencyControl> hedgeCurrencyControlSink) {
        return new HedgeManager(canSendOrders, autoAcknowledge, orderSink, hedgeStatusSink, hedgeDecisionSink, hedgeCurrencyControlSink);
    }

    @Bean
    public Consumer<HourChime> hourChimeConsumer(final HedgeManager hedgeManager, final HedgeFirewallManager hedgeFirewallManager) {
        final Consumer<HourChime> recalibrateTimeSource = (Context.context().timeSource() instanceof TimeSourceRealTime) ?((TimeSourceRealTime) Context.context().timeSource()) : NoConsumer.instance();
        return new NotifierDefault<>(
                recalibrateTimeSource,
                hedgeManager.consumerOfHourChime(),
                hedgeFirewallManager.consumerOfHourChime());
    }

    @Bean
    public TriangulatedMidRateManager triangulatedMidRateManager(final HedgeFirewallManager hedgeFirewallManager,
                                                                 final HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager,
                                                                 final RiskPathManager riskPathManager) {
        return new TriangulatedMidRateManager(new NotifierDefault<>(
                hedgeFirewallManager.consumerOfMidRate(),
                hedgersRevalProfitAndLossManager.consumerOfMidRate(),
                riskPathManager.consumerOfMidRate()
                ));
    }

    // temporarily disable hedgefirewall - issues with nan rate firing 40k per sec in pink
    @Bean
    public HedgeFirewallManager hedgeFirewallManager(
            @Value("${hedger.firewall.maxTradeCountForRevalPnlLossPerMin:1000}") final int maxTradeCountForRevalPnlLossPerMin,
            @Value("${hedger.firewall.maxTradeCountForRevalPnlLossPerHour:5000}") final int maxTradeCountForRevalPnlLossPerHour,
            @Value("${hedger.firewall.maxTradeCountForRevalPnlLossPerDay:15000}") final int maxTradeCountForRevalPnlLossPerDay,
            @Value("${hedger.firewall.maxTradeCountForRevalPnlProfitPerDay:15000}") final int maxTradeCountForRevalPnlProfitPerDay,

            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlLossPerMin:1000}") final int maxTradeCountForAggregatedPnlLossPerMin,
            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlLossPerHour:5000}") final int maxTradeCountForAggregatedPnlLossPerHour,
            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlLossPerDay:15000}") final int maxTradeCountForAggregatedPnlLossPerDay,
            @Value("${hedger.firewall.maxTradeCountForAggregatedPnlProfitPerDay:15000}") final int maxTradeCountForAggregatedPnlProfitPerDay,

            @Value("${hedger.firewall.maxTradeCountForRealisedPositionPer30Sec:1000}") final int maxTradeCountForRealisedPositionPerMin,
            @Value("${hedger.firewall.maxTradeCountForUnrealisedPositionPer30Sec:1000}") final int maxTradeCountForUnrealisedPositionPerMin,
            @Value("${hedger.firewall.maxTradeCountBeforeRevalTime:400}") final int maxTradeCountBeforeRevalTime,
            @Value("${hedger.firewall.maxTradeCountForVolumeInOneHour:400}") final int maxTradeCountForVolumeInOneHour,
            final HedgeManager hedgeManager,
            final Consumer<HedgeFirewallStatus> hedgeFirewallStatusSink) {

        final EnumDoubleMap<HedgeFirewallType> maxTradeCountByType = new EnumDoubleMap<>(HedgeFirewallType.class);
        maxTradeCountByType.put(REVAL_PNL_LOSS_PER_MIN, maxTradeCountForRevalPnlLossPerMin);
        maxTradeCountByType.put(REVAL_PNL_LOSS_PER_HOUR, maxTradeCountForRevalPnlLossPerHour);
        maxTradeCountByType.put(REVAL_PNL_LOSS_PER_DAY, maxTradeCountForRevalPnlLossPerDay);
        maxTradeCountByType.put(REVAL_PNL_PROFIT_PER_DAY, maxTradeCountForRevalPnlProfitPerDay);

        maxTradeCountByType.put(AGGREGATED_PNL_LOSS_PER_MIN, maxTradeCountForAggregatedPnlLossPerMin);
        maxTradeCountByType.put(AGGREGATED_PNL_LOSS_PER_HOUR, maxTradeCountForAggregatedPnlLossPerHour);
        maxTradeCountByType.put(AGGREGATED_PNL_LOSS_PER_DAY, maxTradeCountForAggregatedPnlLossPerDay);
        maxTradeCountByType.put(AGGREGATED_PNL_PROFIT_PER_DAY, maxTradeCountForAggregatedPnlProfitPerDay);

        maxTradeCountByType.put(REALISED_POSITION_PER_30_SEC, maxTradeCountForRealisedPositionPerMin);
        maxTradeCountByType.put(UNREALISED_POSITION_PER_30_SEC, maxTradeCountForUnrealisedPositionPerMin);
        maxTradeCountByType.put(MAXIMUM_TRADE_VOLUME_PER_HOUR, maxTradeCountForVolumeInOneHour);

        final NotifierDefault<HedgeFirewallStatus> hedgeFirewallStatusConsumer = new NotifierDefault<>(hedgeManager.consumerOfHedgeFirewallStatus(), hedgeFirewallStatusSink);
        // hedge manager consume firewall status, firewall manager consume order so can't register both in each constructor
        final HedgeFirewallManager hedgeFirewallManager = new HedgeFirewallManager(hedgeFirewallStatusConsumer, maxTradeCountByType, maxTradeCountBeforeRevalTime);

        hedgeManager.registerOrderConsumer(hedgeFirewallManager.consumerOfOrder());
        return hedgeFirewallManager;
    }

    @Bean
    public Consumer<HedgerFirewallReset> hedgerFirewallResetConsumer(final HedgeFirewallManager hedgeFirewallManager) {
        return hedgeFirewallManager.consumerOfHedgerFirewallReset();
    }

    @Bean
    public HedgersRevalProfitAndLossManager hedgersRevalProfitAndLossManager(
            final Consumer<ProfitAndLoss> profitAndLossSink,
            @Value("${hedger.pnl.maxTradeCountBeforeRevalTime:400}") final int maxTradeCountBeforeRevalTime) {
        return new HedgersRevalProfitAndLossManager(profitAndLossSink, maxTradeCountBeforeRevalTime);
    }

    @Bean
    public RiskPathManager riskPathManager(final Consumer<RiskPath> riskPathSink) {
        return new RiskPathManager(riskPathSink);
    }

    @Bean
    public Consumer<OperatingHourChime> operatingHourChimeConsumer(final HedgeManager hedgeManager) {
        return hedgeManager.consumerOfOperatingHourChime();
    }

    @Bean
    public Consumer<SpotDateRollChime> spotDateRollChimeConsumer (final HedgeManager hedgeManager) {
        return new NotifierDefault<>(hedgeManager.consumerOfSpotDateRollChimeConsumer());
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManager(final HedgeManager hedgeManager) {
        return new TradingTimeZoneManager(new NotifierDefault<>(hedgeManager.consumerOfTradingTimeZoneChime()));
    }

    @Bean
    public Consumer<HedgePauseSignal> dealVolumeSignalConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfHedgePauseSignal());
    }

    @Bean
    public Consumer<ProfitAndLoss> profitAndLossConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfProfitAndLoss());
    }

    @Bean
    public Consumer<RealisedVolatility> realisedVolatilityConsumer(final HedgeManager hedgeManager) {
        return new NotifierDefault(hedgeManager.consumerOfRealisedVolatility());
    }
}
