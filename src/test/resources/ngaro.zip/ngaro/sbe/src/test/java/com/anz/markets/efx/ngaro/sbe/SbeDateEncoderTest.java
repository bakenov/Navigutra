package com.anz.markets.efx.ngaro.sbe;

import java.time.LocalDate;

import org.junit.Test;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link SbeDateEncoder}
 */
public class SbeDateEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test
    public void encode() throws Exception {
        //given
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final SbeDateEncoder<?> encoder = new SbeDateEncoder<>(ENCLOSING_ENCODER, target, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encode(2016, 02, 28);

        //then
        assertEquals("encoded string not as expected", "abc20160228lmno", result.toString());

        //when
        encoder.encodeNullable(LocalDate.of(2017, 03, 14));

        //then
        assertEquals("encoded string not as expected", "abc20170314lmno", result.toString());
    }

    @Test
    public void encodeEpochMillis() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final SbeDateEncoder<?> encoder = new SbeDateEncoder<>(ENCLOSING_ENCODER, target, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeEpochMillis(localDate.toEpochDay() * Epoch.MILLIS_PER_DAY);

        //then
        assertEquals("encoded string not as expected", "abc20170314lmno", result.toString());
    }

    @Test
    public void encodeEpochSeconds() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final SbeDateEncoder<?> encoder = new SbeDateEncoder<>(ENCLOSING_ENCODER, target, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeEpochSeconds(localDate.toEpochDay() * Epoch.SECONDS_PER_DAY);

        //then
        assertEquals("encoded string not as expected", "abc20170314lmno", result.toString());
    }

    @Test
    public void encodeEpochDays() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final SbeDateEncoder<?> encoder = new SbeDateEncoder<>(ENCLOSING_ENCODER, target, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeEpochDays(localDate.toEpochDay());

        //then
        assertEquals("encoded string not as expected", "abc20170314lmno", result.toString());
    }

    @Test
    public void encodeNull() throws Exception {
        //given
        final StringBuilder result = new StringBuilder("abcdefghijklmno");
        final int offset = 3;
        final FixedStringTarget target = (i,b) -> result.setCharAt(offset + i, (char)b);
        final SbeDateEncoder<?> encoder = new SbeDateEncoder<>(ENCLOSING_ENCODER, target, LocalDateFormat.YYYYMMDD);

        //when
        encoder.encodeNull();

        //then
        assertEquals("encoded string not as expected", "abc\0\0\0\0\0\0\0\0lmno", result.toString());
    }

}