package com.anz.axle.acc.job;

import org.apache.log4j.Logger;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.quartz.impl.triggers.AbstractTrigger;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 * @author jonesr18
 */
public abstract class AbstractRecoverableJob {

    private static final Logger LOG = Logger.getLogger(CurrentVenueCurrencyCreditCheckJob.class);
    
    public abstract String getTriggerName();
    public abstract Scheduler getScheduler();

    protected void awake() throws SchedulerException {
        Scheduler scheduler = getScheduler();
        AbstractTrigger trigger = (AbstractTrigger)scheduler.getTrigger(TriggerKey.triggerKey(getTriggerName(), Scheduler.DEFAULT_GROUP));
        if(!"ok".equals(trigger.getDescription())) {
            trigger.setDescription("ok");
            scheduler.rescheduleJob(trigger.getKey(), trigger);
        }
    }

    protected void sleep() throws SchedulerException {
        Scheduler scheduler = getScheduler();
        LOG.warn("Sleeping trigger " + getTriggerName() + " for recovery management.");
        AbstractTrigger trigger = (AbstractTrigger)scheduler.getTrigger(TriggerKey.triggerKey(getTriggerName(), Scheduler.DEFAULT_GROUP));
        trigger.setDescription("recovery");
        scheduler.rescheduleJob(trigger.getKey(), trigger);
        scheduler.pauseTrigger(trigger.getKey());
    }
}
