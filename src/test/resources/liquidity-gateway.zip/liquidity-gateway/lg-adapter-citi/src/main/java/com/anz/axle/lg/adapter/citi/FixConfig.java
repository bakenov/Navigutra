package com.anz.axle.lg.adapter.citi;

import java.util.Objects;
import java.util.Properties;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.agrona.Strings;
import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import quickfix.DefaultMessageFactory;
import quickfix.FieldNotFound;
import quickfix.FileStoreFactory;
import quickfix.LogFactory;
import quickfix.Message;
import quickfix.MessageFactory;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;

import com.anz.axle.lg.adapter.citi.quickfix.CitiExecutionReportHandler;
import com.anz.axle.lg.adapter.citi.quickfix.CitiMarketDataRequestEncoder;
import com.anz.axle.lg.adapter.citi.quickfix.CitiMarketDataRequestRejectHandler;
import com.anz.axle.lg.adapter.citi.quickfix.CitiMassQuoteHandler;
import com.anz.axle.lg.adapter.citi.quickfix.CitiQuoteCancelHandler;
import com.anz.axle.lg.adapter.citi.quickfix.LogonToAdminHandler;
import com.anz.axle.lg.adapter.fix.FixEngine;
import com.anz.axle.lg.adapter.fix.LogDestination;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.quickfix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.quickfix.AsyncApplicationLogonHandler;
import com.anz.axle.lg.adapter.quickfix.CreateSessionHandler;
import com.anz.axle.lg.adapter.quickfix.EncodingSubscriptionSender;
import com.anz.axle.lg.adapter.quickfix.FixApplication;
import com.anz.axle.lg.adapter.quickfix.FixMessageDispatcher;
import com.anz.axle.lg.adapter.quickfix.FixMessageSender;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.SequenceResetHandler;
import com.anz.axle.lg.adapter.quickfix.ToAdminHandler;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);
    private final String compId;
    private final String senderCompId;
    private final Venue venue;


    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId,
                     @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public SessionID pricingSessionId(@Value("${citi.fix.beginstring}:${citi.fix.pricing.sendercompid}->${citi.fix.pricing.targetcompid}") final String pricingSessionIdString) {
        return new SessionID(pricingSessionIdString);
    }

    @Bean
    public SessionID tradingSessionId(@Value("${citi.fix.beginstring}:${citi.fix.trading.sendercompid}->${citi.fix.trading.targetcompid}") final String tradingSessionIdString) {
        return new SessionID(tradingSessionIdString);
    }

    @Bean
    public EncodingSubscriptionSender encodingSubscriptionSender(
            final SessionID pricingSessionId,
            @Value("${citi.fix.targetsubid}") final String targetSubId,
            @Value("${citi.fix.xconnect.colo.specification.version}") final String xConnectSpecVersion) {
        return new EncodingSubscriptionSender(
                new CitiMarketDataRequestEncoder(targetSubId,
                        Strings.isEmpty(xConnectSpecVersion) || xConnectSpecVersion.trim().isEmpty()),
                pricingSessionId);
    }

    @Bean
    public FixMessageDispatcher fixPricingMessageDispatcher(final VenueRequestKeyLookup requestKeyLookup,
                                                            final PricingEncoderLookup pricingEncoderLookup,
                                                            final PrecisionClock precisionClock,
                                                            final SubscriptionManager subscriptionManager,
                                                            final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy,
                                                            final Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> snapshotFullRefreshEncoderFlagsAppender,
 final SourceSequencer sourceSequencer) {
        final CitiMassQuoteHandler massQuoteHandler = new CitiMassQuoteHandler(requestKeyLookup,
                pricingEncoderLookup, precisionClock, subscriptionManager, senderCompId, compId, snapshotFullRefreshEncoderFlagsAppender, sourceSequencer);
        final CitiQuoteCancelHandler quoteCancelHandler = new CitiQuoteCancelHandler(requestKeyLookup,
                pricingEncoderLookup, precisionClock, subscriptionManager, senderCompId, compId, snapshotFullRefreshEncoderFlagsAppender, sourceSequencer);
        final CitiMarketDataRequestRejectHandler marketDataRequestRejectHandler = new CitiMarketDataRequestRejectHandler(subscriptionManager, subscriptionRequestRejectStrategy);
        final TypedFixMessageHandler pricingLogonMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.LOGON);
        final TypedFixMessageHandler pricingLogoutMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.LOGOUT);
        final TypedFixMessageHandler pricingSequenceResetHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.SEQUENCE_RESET);
        final TypedFixMessageHandler pricingHeartbeatMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.HEARTBEAT);
        final TypedFixMessageHandler testRequestMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.TEST_REQUEST);
        return new FixMessageDispatcher(
                massQuoteHandler,
                quoteCancelHandler,
                marketDataRequestRejectHandler,
                pricingHeartbeatMessageHandler,
                pricingLogoutMessageHandler,
                pricingLogonMessageHandler,
                pricingSequenceResetHandler,
                testRequestMessageHandler);
    }

    @Bean
    public SessionState tradingSessionState() {
        return new SessionState("TradingSession");
    }

    @Bean
    public Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> snapshotFullRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState tradingSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(tradingSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public FixMessageDispatcher fixTradingMessageDispatcher(final PrecisionClock precisionClock,
                                                            final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                                            final LongIdFactory tradingMessageIdGenerator,
 final SourceSequencer sourceSequencer) {
        final TypedFixMessageHandler tradingLogonMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.LOGON);
        final TypedFixMessageHandler tradingLogoutMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.LOGOUT);
        final TypedFixMessageHandler tradingSequenceResetHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.SEQUENCE_RESET);
        final CitiExecutionReportHandler citiExecutionReportHandler = new CitiExecutionReportHandler(tradingResponseEncoderSupplier, precisionClock, senderCompId, compId, tradingMessageIdGenerator::get, sourceSequencer);
        final TypedFixMessageHandler tradingHeartbeatMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.HEARTBEAT);
        final TypedFixMessageHandler testRequestMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.TEST_REQUEST);
        return new FixMessageDispatcher(
                tradingLogonMessageHandler,
                tradingLogoutMessageHandler,
                tradingHeartbeatMessageHandler,
                citiExecutionReportHandler,
                tradingSequenceResetHandler,
                testRequestMessageHandler);
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler(final SessionID pricingSessionId,
                                                           @Qualifier("marketDataSubscriber") final Supplier<LogonHandler> pricingSessionLogonHandlerSupplier,
                                                           final SessionID tradingSessionId,
                                                           @Qualifier("tradingSessionState") final Supplier<LogonHandler> tradingSessionLogonHandlerSupplier,
                                                           final Queue<Runnable> mainEventLoopQueue) {
        return new AsyncApplicationLogonHandler(mainEventLoopQueue, sessionID -> {
            if (sessionID.equals(pricingSessionId)) {
                return pricingSessionLogonHandlerSupplier.get();
            } else if (sessionID.equals(tradingSessionId)) {
                return tradingSessionLogonHandlerSupplier.get();
            } else {
                return LogonHandler.NO_OP;
            }
        });
    }

    @Bean
    public FixMessageSender fixMessageSender(final SessionID tradingSessionId) {
        return new FixMessageSender(tradingSessionId);
    }

    @Bean
    public Queue<Message> fixPricingMessageQueue(@Value("${citi.fix.pricing.queue.capacity}") final int pricingQueueCapacity,
                                                 final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(pricingQueueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value));

    }

    @Bean
    public Queue<Message> fixTradingMessageQueue(@Value("${citi.fix.trading.queue.capacity}") final int tradingQueueCapacity,
                                                 final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(tradingQueueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value));
    }

    @Bean
    public EventLoopStep fixPricingEventLoopStep(final Queue<Message> fixPricingMessageQueue,
                                                 final FixMessageDispatcher fixPricingMessageDispatcher) {
        final Consumer<Message> messageProcessor = message -> {
            try {
                fixPricingMessageDispatcher.accept(message);
            } catch (final FieldNotFound fieldNotFound) {
                LOGGER.error("FixMessageDispatcher fieldNotFound exception", fieldNotFound);
            }
        };
        return EventLoopStep.whenFinalisationNotRequired(() -> fixPricingMessageQueue.poller().processNext(messageProcessor));
    }

    @Bean
    public EventLoopStep fixTradingEventLoopStep(final Queue<Message> fixTradingMessageQueue,
                                                 final FixMessageDispatcher fixTradingMessageDispatcher) {
        final Consumer<Message> messageProcessor = message -> {
            try {
                fixTradingMessageDispatcher.accept(message);
            } catch (final FieldNotFound fieldNotFound) {
                LOGGER.error("FixMessageDispatcher fieldNotFound exception", fieldNotFound);
            }
        };
        return EventLoopStep.whenFinalisationRequired(() -> fixTradingMessageQueue.poller().processNext(messageProcessor));
    }

    @Bean
    public FixEngine fixEngine(final Properties applicationProperties,
                               final SessionID pricingSessionId,
                               @Value("${citi.fix.pricing.password}") final String pricingPassword,
                               final SessionID tradingSessionId,
                               @Value("${citi.fix.trading.password}") final String tradingPassword,
                               final Queue<Message> fixPricingMessageQueue,
                               final Queue<Message> fixTradingMessageQueue,
                               final ApplicationLogonHandler applicationLogonHandler,
                               @Value("${appOptions:}") final String appOptions,
                               @Value("${citi.fix.log.destination}") final LogDestination logDestination,
                               @Value("${citi.fix.xconnect.colo.specification.version}") final String xConnectSpecVersion)
            throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/" + venue.name().toLowerCase() + "-quickfix.ini"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final SessionSettings sessionSettings = new SessionSettings(configuredRuntimeResource.getInputStream());
        final FileStoreFactory fileStoreFactory = new FileStoreFactory(sessionSettings);
        final LogFactory logFactory = logDestination.logFactory(sessionSettings);
        final MessageFactory messageFactory = new DefaultMessageFactory();

        final Function<SessionID, Queue<Message>> eventQueueLookup = sessionID -> {
            if (sessionID.equals(pricingSessionId)) {
                return fixPricingMessageQueue;
            } else if (sessionID.equals(tradingSessionId)) {
                return fixTradingMessageQueue;
            } else {
                throw new UnsupportedOperationException("Unknown sessionId " + sessionID);
            }
        };

        final ToAdminHandler toAdminHandler = new LogonToAdminHandler(venue, pricingSessionId, pricingPassword,
                tradingSessionId, tradingPassword, xConnectSpecVersion);
        final FixApplication fixPricingApplication;
        if (OptionMatcher.HAS_RESET.test(appOptions)) {
            LOGGER.info("Once-off sequence reset is enabled");
            final SequenceResetHandler sequenceResetHandler = SequenceResetHandler.onceOffForSessions(pricingSessionId, tradingSessionId, toAdminHandler);
            fixPricingApplication = new FixApplication(eventQueueLookup, sequenceResetHandler, applicationLogonHandler, sequenceResetHandler);
        } else {
            LOGGER.info("Once-off sequence reset is disabled");
            fixPricingApplication = new FixApplication(eventQueueLookup, toAdminHandler, applicationLogonHandler, CreateSessionHandler.NO_OP);
        }

        final SocketInitiator fixPricingInitiator = new SocketInitiator(fixPricingApplication, fileStoreFactory, sessionSettings, logFactory, messageFactory);

        return new FixEngine(venue.name() + "-MD-ORDER", fixPricingInitiator);
    }

    @Bean
    public BooleanSupplier readyToSendHeartbeat(final SessionState tradingSessionState, final MarketDataSubscriber marketDataSubscriber) {
        return () -> tradingSessionState.getAsBoolean() && marketDataSubscriber.loggedOn();
    }

}
