package com.anz.markets.prophet.atest.pricing._10_generic;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.OutputSource;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.framework.RunInCoreMode;
import com.anz.markets.prophet.atest.framework.impl.MessageCountPredicate;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.common.EventHop;
import com.anz.markets.prophet.syscontrol.CoreMode;
import org.junit.Test;

import java.util.LinkedList;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;

@RestartBeforeTest(reason = "clean start")
public class EndEventTest extends BaseAcceptanceSpecification {

    @Test
    @RunInCoreMode(coreMode = CoreMode.SINGLE)
    public void END_EVENT_creation_and_hop_addition_tests_SINGLE_CORE_MODE() {
        prophet.incrementTime(100L);
        final EndEvent core1EndEvent = prophet.expect(EndEvent.class, MessageCountPredicate.EXACTLY_ONE, o -> o.source == OutputSource.CORE).getLast();
        assertEndEventInfo(core1EndEvent, MessageType.ACTIVATE, Stage.STARFISHIN);
    }

    @Test
    @RunInCoreMode(coreMode = CoreMode.DUAL)
    public void END_EVENT_creation_and_hop_addition_tests_DUAL_CORE_MODE() {
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1000L);
        }
        then:
        {
            final LinkedList<EndEvent> core2PricerEndEvent = prophet.expect(EndEvent.class, MessageCountPredicate.EXACTLY_TWO, o -> o.source == OutputSource.CORE_PRICER);
            assertEndEventInfo(core2PricerEndEvent.getFirst(), MessageType.ONE_SECOND, Stage.STARFISHIN);
            assertEndEventInfo(core2PricerEndEvent.getLast(), MessageType.ACTIVATE, Stage.STARFISHIN);

            final LinkedList<EndEvent> core2HedgerEndEvent = prophet.expect(EndEvent.class, MessageCountPredicate.EXACTLY_TWO, o -> o.source == OutputSource.CORE_HEDGER);
            assertEndEventInfo(core2HedgerEndEvent.getFirst(), MessageType.ONE_SECOND, Stage.STARFISHIN, Stage.PRICE);
            assertEndEventInfo(core2HedgerEndEvent.getLast(), MessageType.ACTIVATE, Stage.STARFISHIN, Stage.PRICE);
        }
    }

    @Test
    @RunInCoreMode(coreMode = CoreMode.TRIPLE)
    public void END_EVENT_creation_and_hop_addition_tests_TRIPLE_CORE_MODE() {
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1000L);
        }
        then:
        {
            final LinkedList<EndEvent> core2PricerEndEvent = prophet.expect(EndEvent.class, MessageCountPredicate.EXACTLY_TWO, o -> o.source == OutputSource.CORE_PRICER);
            assertEndEventInfo(core2PricerEndEvent.getFirst(), MessageType.ONE_SECOND, Stage.STARFISHIN);
            assertEndEventInfo(core2PricerEndEvent.getLast(), MessageType.ACTIVATE, Stage.STARFISHIN);

            final LinkedList<EndEvent> core2HedgerEndEvent = prophet.expect(EndEvent.class, MessageCountPredicate.EXACTLY_TWO, o -> o.source == OutputSource.CORE_HEDGER);
            assertEndEventInfo(core2HedgerEndEvent.getFirst(), MessageType.ONE_SECOND, Stage.STARFISHIN, Stage.PRICE);
            assertEndEventInfo(core2HedgerEndEvent.getLast(), MessageType.ACTIVATE, Stage.STARFISHIN, Stage.PRICE);

            final LinkedList<EndEvent> core2CrossEndEvent = prophet.expect(EndEvent.class, MessageCountPredicate.EXACTLY_TWO, o -> o.source == OutputSource.CORE_CROSS);
            assertEndEventInfo(core2CrossEndEvent.getFirst(), MessageType.ONE_SECOND, Stage.STARFISHIN, Stage.PRICE);
            assertEndEventInfo(core2CrossEndEvent.getLast(), MessageType.ACTIVATE, Stage.STARFISHIN, Stage.PRICE);
        }
    }

    private void assertEndEventInfo(final EndEvent endEvent, final MessageType messageType, final Stage... hopStages) {
        assertThat(endEvent.getMessageType(), is(equalTo(messageType)));
        assertThat(endEvent.getEventHopList().size(), is(equalTo(hopStages.length)));

        EventHop previousHop = null;
        for (int i = 0; i < endEvent.getEventHopList().size(); i++) {
            final EventHop currentHop = endEvent.getEventHopList().get(i);
            // Context.stage is static so hopStage would be set to whatever ProcessConfig was last created
            // Need to handle this better in acceptance tests, probably easiest to launch separate JVMs for each process
            // to avoid stage collisions

            // For now should be ok to check that the time stamps are not moving backwards
            assertThat(currentHop.getFinishTimeStampNS(), is(greaterThanOrEqualTo(currentHop.getStartTimeStampNS())));
            if (previousHop != null) {
                assertThat(currentHop.getStartTimeStampNS(), is(greaterThanOrEqualTo(previousHop.getFinishTimeStampNS())));
            }

            previousHop = currentHop;
        }
    }
}
