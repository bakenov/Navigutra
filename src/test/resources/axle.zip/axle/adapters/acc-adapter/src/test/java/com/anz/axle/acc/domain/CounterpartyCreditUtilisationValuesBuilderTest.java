package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CounterpartyCreditPool;
import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.Venue;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import org.joda.time.LocalDate;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import static junit.framework.Assert.assertEquals;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public class CounterpartyCreditUtilisationValuesBuilderTest {
    @Test
    public void test_multiple_construction() throws BuilderException {
        CounterpartyCreditPool creditPoolOne = new CounterpartyCreditPool();
        creditPoolOne.setId(1l);
        CounterpartyCreditPool creditPoolTwo = new CounterpartyCreditPool();
        creditPoolTwo.setId(2l);
        LocalDate spotDateOne = new LocalDate(2010,11,3);
        LocalDate spotDateTwo = new LocalDate(2010,11,4);

        CounterpartyCreditUtilisation utilisationOne = new CounterpartyCreditUtilisation(creditPoolOne, spotDateOne, 0.8d, new ArrayList<Venue>(), 0l);
        Venue venue = new Venue();
        venue.setId(3L);
        Collection<Venue> venues = new ArrayList<Venue>();
        venues.add(venue);
        CounterpartyCreditUtilisation utilisationTwo = new CounterpartyCreditUtilisation(creditPoolTwo, spotDateTwo, 0.7d, venues, 0l);
        CounterpartyCreditUtilisations utilisations = new CounterpartyCreditUtilisations();
        utilisations.add(utilisationOne);
        utilisations.add(utilisationTwo);

        CounterpartyCreditUtilisationValuesBuilder builder = new CounterpartyCreditUtilisationValuesBuilder();
        CounterpartyCreditUtilisationValueBuilder valueBuilder = new CounterpartyCreditUtilisationValueBuilder();
        valueBuilder.setKeyBuilder(new CounterpartyCreditUtilisationKeyBuilder());
        builder.setValueBuilder(valueBuilder);

        Collection<CounterpartyCreditUtilisationValue> results = builder.build(utilisations);

        assertEquals(2, results.size());

        Iterator<CounterpartyCreditUtilisationValue> iterator = results.iterator();

        CounterpartyCreditUtilisationValue valueOne = iterator.next();
        assertEquals(new Long(1l), valueOne.getCreditPoolId());
        assertEquals(spotDateOne, valueOne.getSpotDate());
        assertEquals(0.8d, valueOne.getUtilisationValue());
        assertEquals("CREDIT_CHECK", valueOne.getSource());
        assertEquals(new Long(1l), valueOne.getKey().getCreditPoolId());
        assertEquals(spotDateOne, valueOne.getKey().getSpotDate());
        assertEquals("CREDIT_CHECK", valueOne.getKey().getSource());


        CounterpartyCreditUtilisationValue valueTwo = iterator.next();
        assertEquals(new Long(2l), valueTwo.getCreditPoolId());
        assertEquals(spotDateTwo, valueTwo.getSpotDate());
        assertEquals(0.7d, valueTwo.getUtilisationValue());
        assertEquals("CREDIT_CHECK", valueTwo.getSource());
        assertEquals(new Long(2l), valueTwo.getKey().getCreditPoolId());
        assertEquals(spotDateTwo, valueTwo.getKey().getSpotDate());
        assertEquals("CREDIT_CHECK", valueTwo.getKey().getSource());
    }
}
