package com.anz.axle.lg.adapter.apama.transport;

public interface ConnectionStatusHandler {
    void onConnect(Connection connection);
    void onDisconnect(Connection connection);
    void onNotification(Connection connection, String notification);
}
