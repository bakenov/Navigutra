package com.anz.axle.adapters.wssdeal.filter;

import anz.markets.canonical.model.v2.IdentifierType;
import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import anz.markets.canonical.model.v2.TradeMessageWrapperType.TradeParty;
import anz.markets.messaging.filters.impl.XPATHFilterCondition;
import com.anz.axle.common.filter.Filter;
import com.anz.axle.common.filter.FilterException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by talwarg on 8/04/2015.
 */
public class NonXEFXFilterTest {
    private Filter<TradeMessageWrapperType> tradeMessageFilter;

    private final ThreadLocal<DocumentBuilder> builder = new ThreadLocal<DocumentBuilder>() {
        @Override
        protected DocumentBuilder initialValue() {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            try {
                return dbf.newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                return null;
            }
        }
    };

    @Before
    public void setUp(){
        tradeMessageFilter = new NonXEFXFilter();
    }

    @Test
     public void testXEFXTrade() throws FilterException{

        TradeMessageWrapperType tradeMessage = new TradeMessageWrapperType();
        List<TradeParty> tradePartyList = tradeMessage.getTradeParty();

        TradeMessageWrapperType.TradeParty tradeParty1 = new TradeMessageWrapperType.TradeParty();
        tradeParty1.setID("PARTY1");
        List<IdentifierType> identifierList1 = new LinkedList<IdentifierType>();
        IdentifierType identifier1 = new IdentifierType();
        identifier1.setContext("WSS_PORTFOLIO");
        identifier1.setValue("XEFX");
        identifierList1.add(identifier1);
        //tradeParty1.setPartyReference(identifierList1);

        TradeMessageWrapperType.TradeParty tradeParty4 = new TradeMessageWrapperType.TradeParty();
        tradeParty4.setID("PARTY4");
        List<IdentifierType> identifierList = new LinkedList<IdentifierType>();
        IdentifierType identifier = new IdentifierType();
        identifier.setContext("WSS_TRADER");
        identifier.setValue("XEFX");
        identifierList.add(identifier);
        //tradeParty4.setPartyReference(identifierList);

        tradePartyList.add(tradeParty1);
        tradePartyList.add(tradeParty4);

        boolean filter = tradeMessageFilter.accept(tradeMessage);
        Assert.assertTrue(filter);
    }

    @Test
    public void testNonXEFXTrade() throws FilterException{

        TradeMessageWrapperType tradeMessage = new TradeMessageWrapperType();
        List<TradeParty> tradePartyList = new LinkedList<TradeParty>();

        TradeParty tradeParty1 = new TradeParty();
        tradeParty1.setID("PARTY1");
        List<IdentifierType> identifierList1 = new LinkedList<IdentifierType>();
        IdentifierType identifier1 = new IdentifierType();
        identifier1.setContext("WSS_PORTFOLIO");
        identifier1.setValue("FXC");
        identifierList1.add(identifier1);
        tradeParty1.setPartyReference(identifierList1);

        TradeParty tradeParty4 = new TradeParty();
        tradeParty4.setID("PARTY4");
        List<IdentifierType> identifierList = new LinkedList<IdentifierType>();
        IdentifierType identifier = new IdentifierType();
        identifier.setContext("WSS_TRADER");
        identifier.setValue("XAU");
        identifierList.add(identifier);
        //tradeParty4.setPartyIdentifierList(identifierList);

        tradePartyList.add(tradeParty1);
        tradePartyList.add(tradeParty4);

        //tradeMessage.setTradePartyList(tradePartyList);
        boolean filter = tradeMessageFilter.accept(tradeMessage);
        Assert.assertTrue(filter);
    }

    @Test
    public void testEvaluateBack2BackWSSCondition() throws Exception{
        String clientDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_NEWREFERENCECOPY'>RET-AD_14404629</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        XPATHFilterCondition fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/channelIdentifier/identifier[@context='WSS_NEWREFERENCECOPY']");
        fc.setMatch("_B[0-9]*$");

        DocumentBuilder dbuilder = builder.get();
        BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        Document d = dbuilder.parse(bis);
        assertFalse(fc.evaluate(d));

        String riskDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_NEWREFERENCECOPY'>RET-AD_14404629_R</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/channelIdentifier/identifier[@context='WSS_NEWREFERENCECOPY']");
        fc.setMatch("_B[0-9]*$");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(riskDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertFalse(fc.evaluate(d));

        String backToBackDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_NEWREFERENCECOPY'>RET-AD_14404629_B</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/channelIdentifier/identifier[@context='WSS_NEWREFERENCECOPY']");
        fc.setMatch("_B[0-9]*$");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(backToBackDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        String backToBackDealWithNumber = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_NEWREFERENCECOPY'>RET-AD_14404629_B2</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/channelIdentifier/identifier[@context='WSS_NEWREFERENCECOPY']");
        fc.setMatch("_B[0-9]*$");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(backToBackDealWithNumber.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));
    }


    @Test
    public void testEvaluateWSSSourceSystemCondition() throws Exception {
        String clientDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_SOURCESYSTEM'>AXLE</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        XPATHFilterCondition fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/channelIdentifier/identifier[@context='WSS_SOURCESYSTEM']");
        fc.setMatch("AXLE|SPDEE|RET-AD|^$");

        DocumentBuilder dbuilder = builder.get();
        BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        Document d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_SOURCESYSTEM'>SPDEE</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_SOURCESYSTEM'>FXALL</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertFalse(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_SOURCESYSTEM'>RET-AD2323232</identifier></channelIdentifier></tradeHeader></tradeMessage>";

        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <channelIdentifier><identifier context='WSS_SOURCESYSTEM'></identifier></channelIdentifier></tradeHeader></tradeMessage>";

        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));


    }

    @Test
    public void testEvaluateWSSOperationAllowedConditionCondition() throws Exception {
        String clientDeal = "<tradeMessage> <tradeHeader> <sourceSystemOperation>CREATE</sourceSystemOperation></tradeHeader></tradeMessage>";

        XPATHFilterCondition fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/sourceSystemOperation");
        fc.setMatch("(CREATE|MODIFY|CANCEL)");

        DocumentBuilder dbuilder = builder.get();
        BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        Document d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <sourceSystemOperation>MODIFY</sourceSystemOperation></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/sourceSystemOperation");
        fc.setMatch("(CREATE|MODIFY|CANCEL)");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <sourceSystemOperation>CANCEL</sourceSystemOperation></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/sourceSystemOperation");
        fc.setMatch("(CREATE|MODIFY|CANCEL)");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));


        clientDeal = "<tradeMessage> <tradeHeader> <tradeBusinessEvent> <eventIdentifier context='FX_TRADE_EVENT'>NEW</eventIdentifier></tradeBusinessEvent></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();
        fc.setField("xpath:/tradeMessage/tradeHeader/tradeBusinessEvent/eventIdentifier[@context='FX_TRADE_EVENT']");
        fc.setMatch("(NEW|CANCELLATION)");
        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <tradeBusinessEvent> <eventIdentifier context='FX_TRADE_EVENT'>AMENDMENT</eventIdentifier></tradeBusinessEvent></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();
        fc.setField("xpath:/tradeMessage/tradeHeader/tradeBusinessEvent/eventIdentifier[@context='FX_TRADE_EVENT']");
        fc.setMatch("(NEW|CANCELLATION)");
        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertFalse(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <tradeBusinessEvent> <eventIdentifier context='FX_TRADE_EVENT'>CANCELLATION</eventIdentifier></tradeBusinessEvent></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();
        fc.setField("xpath:/tradeMessage/tradeHeader/tradeBusinessEvent/eventIdentifier[@context='FX_TRADE_EVENT']");
        fc.setMatch("(NEW|CANCELLATION)");
        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

    }

    @Test
    public void testEvaluateWSSProductnAllowedConditionCondition() throws Exception {
        String clientDeal = "<tradeMessage> <tradeHeader> <productIdentifier><identifier context='FX_PRODUCT_CODE'>SPOT</identifier></productIdentifier></tradeHeader></tradeMessage>";

        XPATHFilterCondition fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/productIdentifier/identifier[@context='FX_PRODUCT_CODE']");
        fc.setMatch("(SPOT|FORWARD)");

        DocumentBuilder dbuilder = builder.get();
        BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        Document d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <productIdentifier><identifier context='FX_PRODUCT_CODE'>FORWARD</identifier></productIdentifier></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/productIdentifier/identifier[@context='FX_PRODUCT_CODE']");
        fc.setMatch("(SPOT|FORWARD)");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));

        clientDeal = "<tradeMessage> <tradeHeader> <productIdentifier><identifier context='FX_PRODUCT_CODE'>AUXILIARIES</identifier></productIdentifier></tradeHeader></tradeMessage>";

        fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeHeader/productIdentifier/identifier[@context='FX_PRODUCT_CODE']");
        fc.setMatch("(SPOT|FORWARD)");

        dbuilder = builder.get();
        bis = new BufferedInputStream(new ByteArrayInputStream(clientDeal.getBytes("UTF-8")));
        d = dbuilder.parse(bis);
        assertFalse(fc.evaluate(d));
    }

    @Test
    public void testEvaluateAggregatedXGLWSSCondition() throws Exception{
        String XGLDeal = "<tradeMessage><tradeParty ID=\"PARTY_1\">\n" +
                "    <partyIdentifier context=\"WSS_PORTFOLIO\">FWD</partyIdentifier>\n" +
                "    <partyIdentifier context=\"WSS_AREA\">WELFWD</partyIdentifier>\n" +
                "    <partyIdentifier context=\"WSS_CITY_CODE\">NZLOPS</partyIdentifier>\n" +
                "    <partyIdentifier context=\"MIDANZ_BOOK_CODE\">NZW</partyIdentifier>\n" +
                "    <partyIdentifier context=\"WSS_PORTFOLIO_TYPE\">OPTION</partyIdentifier>\n" +
                "</tradeParty><tradeParty ID=\"PARTY_2\">\n" +
                "<partyIdentifier context=\"WSS_CUSTOMER_NUMBER\">ANZBAU3M</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_CUSTOMER_SHORT_NAME\">ANZBAU3M</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_CUSTOMER_DISPLAY_ID\">ANZBAU3M</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_CUSTOMER_FULL_NAME\">ANZ G.H.Q</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_CUSTOMER_TYPE\">BANK</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_COUNTERPARTY_CODE\">ANZBAU</partyIdentifier>\n" +
                "<partyIdentifier context=\"MIDANZ_SHORT_NAME\">000018</partyIdentifier>\n" +
                "<partyIdentifier context=\"MIDANZ_CUSTOMER_NUMBER\">000018</partyIdentifier>\n" +
                "<partyIdentifier context=\"CUSTACCOUNTSTRING\"/>\n" +
                "</tradeParty><tradeParty ID=\"PARTY_3\">\n" +
                "<partyIdentifier context=\"WSS_BROKER_CODE\">PHO</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_BROKER_NAME\">PHONE</partyIdentifier>\n" +
                "<partyIdentifier context=\"MIDANZ_BROKER_CODE\">PHO</partyIdentifier>\n" +
                "</tradeParty><tradeParty ID=\"PARTY_4\">\n" +
                "<partyIdentifier context=\"WSS_TRADER\">WGB</partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_TRADER_NAME\">WALLSTREET GLOBAL BOOKING</partyIdentifier>\n" +
                "<partyIdentifier context=\"CAF_CODE\"/>\n" +
                "<partyLocation>\n" +
                "    <locationIdentifier context=\"WSS_TRADER_LOCATION\">AU</locationIdentifier>\n" +
                "</partyLocation>\n" +
                "</tradeParty><tradeParty ID=\"PARTY_5\">\n" +
                "<partyIdentifier context=\"WSS_MOD_TRADER\"></partyIdentifier>\n" +
                "<partyIdentifier context=\"WSS_MOD_TRADER_NAME\"></partyIdentifier>\n" +
                "<partyLocation>\n" +
                "    <locationIdentifier context=\"WSS_MOD_TRADER_LOCATION\"></locationIdentifier>\n" +
                "</partyLocation>\n" +
                "</tradeParty><tradeParty ID=\"PARTY_6\">\n" +
                "<partyIdentifier context=\"WSS_OTC_REPORTING_PARTY\"/>\n" +
                "<partyIdentifier context=\"WSS_OTC_PARTY_OVERRIDE\"/>\n" +
                "</tradeParty><tradeParty ID=\"PARTY_7\">\n" +
                "<partyIdentifier context=\"WSS_ORIGINAL_TRADER\"/>\n" +
                "</tradeParty></tradeMessage>";

        XPATHFilterCondition fc = new XPATHFilterCondition();

        fc.setField("xpath:/tradeMessage/tradeParty/partyIdentifier[@context='WSS_TRADER']");
        fc.setMatch("WGB");

        DocumentBuilder dbuilder = builder.get();
        BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(XGLDeal.getBytes("UTF-8")));
        Document d = dbuilder.parse(bis);
        assertTrue(fc.evaluate(d));
    }


}
