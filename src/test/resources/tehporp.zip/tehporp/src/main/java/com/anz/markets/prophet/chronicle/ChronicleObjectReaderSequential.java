package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.chronicle.MessageType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ChronicleObjectReaderSequential implements ChronicleObjectReader {
    private List<ChronicleObjectReader> readers = new ArrayList<>();

    public ChronicleObjectReaderSequential(ChronicleObjectReader... readers) {
        this.readers.addAll(Arrays.asList(readers));
    }

    @Override
    public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
        this.readers.forEach(reader -> reader.processEntity(bytes, messageType));
    }
}
