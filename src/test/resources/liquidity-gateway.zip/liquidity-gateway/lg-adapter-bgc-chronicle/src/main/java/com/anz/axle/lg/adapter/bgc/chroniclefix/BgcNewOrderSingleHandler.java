package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import net.openhft.chronicle.bytes.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import static com.anz.axle.lg.adapter.chroniclefix.FixSide.fixSide;

public class BgcNewOrderSingleHandler implements NewOrderSingleHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(BgcNewOrderSingleHandler.class);
    private final FixMessageSender fixMessageSender;
    private final NewOrderSingle newOrderSingle;
    private final double DEFAULT_PRICE = 1.0;
    private final ByteValueCache<String> symbol7Cache = new ByteValueCache<>(asciiString -> SymbolNormaliser.toSymbol7(asciiString.toString()));

    public BgcNewOrderSingleHandler(final FixMessageSender fixMessageSender) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.newOrderSingle = new DefaultNewOrderSingle();
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        newOrderSingle.reset();
    }

    @Override
    public void onBody(final NewOrderSingleHandler.Body body) {

        newOrderSingle.clOrdID(newOrderSingle.clOrdID_buffer());
        newOrderSingle.clOrdID().append(body.clOrdId().decodeLongOrZero());
        newOrderSingle.symbol(body.symbol().decodeAndCache(symbol7Cache));
        newOrderSingle.side(fixSide(body.side()));
        newOrderSingle.transactTime(body.transactTime());
        newOrderSingle.orderQty(body.orderQty());
        newOrderSingle.price(DEFAULT_PRICE);
        newOrderSingle.ordType(OrdType.LIMIT);
        newOrderSingle.timeInForce(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.DAY);
        newOrderSingle.securityType(body.securityType().name());
    }

    @Override
    public void onMessageComplete() {
        fixMessageSender.accept(newOrderSingle);
        LOGGER.info("Sending..{}", newOrderSingle);
    }
}
