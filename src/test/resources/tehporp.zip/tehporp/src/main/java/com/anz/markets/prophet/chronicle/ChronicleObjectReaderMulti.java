package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.EnumMap;

public class ChronicleObjectReaderMulti implements ChronicleObjectReader {
    private final EnumMap<MessageType, ChronicleObjectReader> readers;
    private final ChronicleObjectReader fallback;

    public ChronicleObjectReaderMulti(EnumMap<MessageType, ChronicleObjectReader> readers) {
        this(readers, false);
    }

    public ChronicleObjectReaderMulti(EnumMap<MessageType, ChronicleObjectReader> map, boolean ignoreUnMatched) {
        this(map, new ChronicleObjectReaderIgnoreUnmatched(ignoreUnMatched));
    }

    public ChronicleObjectReaderMulti(EnumMap<MessageType, ChronicleObjectReader> map, ChronicleObjectReader fallback) {
        this.readers = map;
        this.fallback = fallback;
    }

    @Override
    public void processEntity(ProphetBytes bytes, MessageType messageType) {
        final ChronicleObjectReader reader = this.readers.get(messageType);
        if (reader != null) {
            reader.processEntity(bytes, messageType);
        } else {
            fallback.processEntity(bytes, messageType);
        }
    }

    private static class ChronicleObjectReaderIgnoreUnmatched implements ChronicleObjectReader {
        private final boolean ignoreUnMatched;

        public ChronicleObjectReaderIgnoreUnmatched(final boolean ignoreUnMatched) {
            this.ignoreUnMatched = ignoreUnMatched;
        }

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            GcFriendlyAssert.isTrue(ignoreUnMatched, "Could not find a reader for message type %s", messageType);
        }
    }
}
