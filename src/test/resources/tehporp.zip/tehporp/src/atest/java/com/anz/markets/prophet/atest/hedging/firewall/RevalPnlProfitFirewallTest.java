package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Ref.HEDGING_FIREWALL_4_9_11, Ref.PROFIT_AND_LOSS_4_2_6, Ref.PROFIT_AND_LOSS_4_2_7})
public class RevalPnlProfitFirewallTest extends ForEachHedgePortfolioBaseAcceptanceSpecification {
    // todo:
    // NaN pnl should update hedge firewall status as breached.

    @Test
    public void shouldUnbreachWithSlidingWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_PROFIT_PER_DAY, 510.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9405));
        }
        when:
        {   // t+0 receive hedge trade 1
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9405));
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
        }
        when:
        // t+10, receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9500));
        }
        then:
        // not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
        }

        when:
        // t+30, reval Pnl for hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // mkt TOB equals fill rate. reval PnL is therefore 0 => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
        }

        when:
        // t+35, rate change but still not breached
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.95051));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }

        when:
        // t+40, reval Pnl for hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
        }
        then:
        // t+30 Reval P/L = 0 (LOWEST)
        // t+40 Reval P/L = (0.95051-0.95050) * 1mio = 510 (HIGH)
        // PROFIT = 510  => not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+1hr i.e next 1hr bucket, receive hedge trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.HOURS.toMillis(1) - TimeUnit.SECONDS.toMillis(40));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.95005));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, -1_000_000, 0.95000));
        }
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+1hr+30sec reval and receive another hedge trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(30));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, -1_000_000, 0.95011));
        }
        then:
        // Reval P/L = (0.95-0.95005) * 1mio = -50
        // PnL = +460 (BUCKET LOW)
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+1hr+1min reval
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(30));
        }
        then:
        // Reval P/L = (0.95011-0.95005) * 1mio = +60
        // PnL = +520  => (BUCKET HIGH)   => BREACHED
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_PROFIT_PER_DAY, portfolio, BREACHED, 520.0, 520., 0, 520.0, 510.00));
        }
        when:
        // t+2hr i.e next 1hr bucket, receive hedge trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.HOURS.toMillis(1) - TimeUnit.MINUTES.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.95010));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, -1_000_000, 0.95000));
        }
        then:
        // Reval P/L = (0.95000-0.95010) * 1mio = -100
        // PnL = +420  => (BUCKET LOW)
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+24hr, 1st hour bucket slide out
        {
            prophet.incrementTime(TimeUnit.HOURS.toMillis(11));
            prophet.incrementTime(TimeUnit.HOURS.toMillis(10));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.HOURS.toMillis(1));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_PROFIT_PER_DAY, portfolio, NOT_BREACHED, -100, 0.0, 420, 520.0, 510.00));
        }
    }

    @Test
    public void verifyRevalProfitCalcLossToProfit() {
        // lowest Reval P/L = loss
        // highest Reval P/K = profit
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_PROFIT_PER_DAY, 549.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9405));
        }
        firewallBreached();
    }

    // parameterised to allow test to be run twice with reset in between
    private void firewallBreached() {
        when:
        // receive hedge trade 1(ANZ BUY)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9405));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.95000));
        }
        then:
        // no reval => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+10, rate change
        {
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.94975));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+30, trigger reval of hedge trade 1
        {
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // t+30 Reval P/L = (0.94975-0.95) * 1mio = -250 (LOWEST)  => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }

        when:
        // t+35, market update
        {
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.95005));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+1hr, receive hedge trade 2 (ANZ BUY)
        {
            prophet.incrementTime(TimeUnit.HOURS.toMillis(1) - TimeUnit.SECONDS.toMillis(35));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.95005));

            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.94950));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+1hr+30sec, trigger reval of hedge trade 2
        {
            prophet.incrementTime(30 * 1_000);
        }
        then:
        // t+30 Reval P/L = -250 (LOWEST)
        // t+40 Reval P/L = (0.95005-0.94950) * 1mio = +550
        // Total PnL = +300 (HIGH)
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(REVAL_PNL_PROFIT_PER_DAY, portfolio, BREACHED, 550, 300, -250, 300, 549.00));
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() {
        // lowest Reval P/L = loss
        // highest Reval P/K = profit
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_PROFIT_PER_DAY, 549.00, true)
            )));
        }
        given:
        // first breached
        {
            firewallBreached();
        }
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, REVAL_PNL_PROFIT_PER_DAY));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
            prophet.clearOutputBuffer();
        }
        and:
        // repeat first breached pattern - e.g., reset works
        {
            firewallBreached();
        }
    }

    @Test
    public void shouldResetWhenHedgerTurnedOn() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_PROFIT_PER_DAY, 549.00, true),

                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                    new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false)
            )));
        }
        given:
        // first breached
        {
            firewallBreached();
        }
        when:
        // enable hedger which will reset firewall
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(portfolio));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
        }
        and:
        // repeat first breached pattern - e.g., reset works
        {
            firewallBreached();
        }
    }

    @Test
    public void firewallNotTriggeredWhenProfitToLoss() {
        // lowest Reval P/L = loss
        // highest Reval P/K = profit
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_PROFIT_PER_DAY, 549.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9405));
        }

        when:
        // receive hedge trade 1(ANZ BUY)
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.94950));
        }
        then:
        // no reval eyt
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+10, rate change
        // t+10, receive hedge trade 2 (ANZ BUY)
        {
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.94975));

            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.95005));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+30, trigger reval of hedge trade 1
        {
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // t+30 Reval P/L = (0.94975-0.94950) * 1mio = +250 (HIGHEST)  => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }

        when:
        // t+35, market update
        {
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.94950));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
            prophet.clearOutputBuffer();
        }

        when:
        // t+40, trigger reval of hedge trade 2
        {
            prophet.incrementTime(5 * 1_000);
        }
        then:
        // t+30 Reval P/L = +250 (HIGH)
        // t+40 Reval P/L = (0.94950-0.95005) * 1mio = -550
        // Total PnL = -300 (LOW)  => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
    }

    @Test
    public void notBreachedIfEqualLimit() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_PROFIT_PER_DAY, 510.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9405));
        }
        when:
        // receive hedge trade 1
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9405));
        }
        then:
        // no reval yet
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(REVAL_PNL_PROFIT_PER_DAY, BREACHED, portfolio));
        }
        when:
        // t+10, receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9500));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+30, reval Pnl for hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
        }
        then:
        // mkt TOB equals hedge trade 1's fill rate. PnL is 0
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+35, mkt TOB update
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.95051));
        }
        then:
        // no reval
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }

        when:
        // t+40, reval Pnl for hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
        }
        then:
        // t+30 Reval P/L = 0 (LOWEST)
        // t+40 Reval P/L = (0.95051-0.9500) * 1mio = 510 (HIGH)
        // PROFIT = 510  => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(REVAL_PNL_PROFIT_PER_DAY, portfolio));
        }
    }

    @Test
    public void shouldThrowExceptionWhenPnlProfitConfigurationIsLessThanZero() {
        setup:
        // prime the server first so that expects works.
        {
            prophet.receive(tdd.configuration_hedging_001());
        }
        when:
        // send in reval pnl loss config that is more than zero.
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_PROFIT_PER_DAY, -0.0001, true)
            )));
        }
        then:
        // exception should be thrown.
        {
            prophet.expect(IllegalArgumentException.class, matches(".*Profit pnl limit must be more than zero.*"));
        }
    }
}
