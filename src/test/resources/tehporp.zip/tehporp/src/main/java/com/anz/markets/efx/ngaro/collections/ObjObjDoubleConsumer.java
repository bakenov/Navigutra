package com.anz.markets.efx.ngaro.collections;

@FunctionalInterface
public interface ObjObjDoubleConsumer<T, U> {

    void accept(T t, U u, double v);
}
