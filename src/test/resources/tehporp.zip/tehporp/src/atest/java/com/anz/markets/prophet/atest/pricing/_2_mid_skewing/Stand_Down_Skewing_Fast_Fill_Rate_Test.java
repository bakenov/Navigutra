package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.hedging.volume.HedgePauseState;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.features.StanddownMidHedgersOnNoSkewFeatureSpecs;
import com.anz.markets.prophet.pricer.pfp.features.StanddownSkewFastFillRateFeatureSpecs;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.matcher.LamdaMatcher.f;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 ** AXPROPHET-1285 Stand down skewing strategy
 *  Stand down skewing(Fast Fill) when all conditions met:
 *  - Position(usd) above PARAM_MIN_POSITION_USD
 *  - total of risk reducing trade quantities(in USD using systemBaseMid) within sliding window above PARAM_RR_FILL_QUANTITY
 *  - ratio of risk reducing trades to biasedPositionInSystemBase above PARAM_RR_FILL_RATIO
 *
 * If stand down is triggered, no skew for a period window(even if rr trade totals/ratios fall below thresholds during this period)
 * However Stand Down CAN be cancelled immediately during this period ONLY if either occurs:
 *  - the Position(usd) falls below PARAM_MIN_POSITION_USD
 *  - the Position(usd) changes side/sign
 *
 *  Again, MANUAL Skew will override any active Stand Down skew
 *
 *  AXPROPHET-1326 Stand down skewing strategies will now also send signal
 *  to PAUSE Mid Hedger
 **/
@RelatedTest(Optimal_Position_Risk_Skew_and_NOP_Skew_Combined.class)
@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1285})
public class Stand_Down_Skewing_Fast_Fill_Rate_Test extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Instrument directPair = Instrument.USDJPY;
    private Instrument crossPair = Instrument.EURNOK;  // also a driver pair

    private ConfigurationDataDefault setUpConfiguration() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig2 = new ArrayList<>();
        StanddownSkewFastFillRateFeatureSpecs specs = StanddownSkewFastFillRateFeatureSpecs.INSTANCE;
        StanddownMidHedgersOnNoSkewFeatureSpecs specs2 = StanddownMidHedgersOnNoSkewFeatureSpecs.INSTANCE;

        // set up config for indirect pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.LDN,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, 1_126_000d,
                specs.PARAM_RR_FILL_RATIO, 0.24d,
                specs.PARAM_RR_FILL_INTERVAL_MS, 5_000L,
                specs.PARAM_STANDDOWN_PERIOD_MS, 500L, // under 1 second
                specs.PARAM_MIN_POSITION_USD, 1_500_000d)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_B,
                indirectPair,
                TradingTimeZone.SNG,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, 750_000d,
                specs.PARAM_RR_FILL_RATIO, 0.24d,
                specs.PARAM_RR_FILL_INTERVAL_MS, 5_000L,
                specs.PARAM_STANDDOWN_PERIOD_MS, 500L,
                specs.PARAM_MIN_POSITION_USD, 1_500_000d)
        );

        // set up config for direct pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                directPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, 500_000d,
                specs.PARAM_RR_FILL_RATIO, 0.1d,
                specs.PARAM_RR_FILL_INTERVAL_MS, 5_000L,
                specs.PARAM_STANDDOWN_PERIOD_MS, 2_000L,
                specs.PARAM_MIN_POSITION_USD, 2_775_000d)
        );

        // set up config for cross driver pair
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                crossPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, 1_000_000d,
                specs.PARAM_RR_FILL_RATIO, 0.67d,
                specs.PARAM_RR_FILL_INTERVAL_MS, 1_499L,
                specs.PARAM_STANDDOWN_PERIOD_MS, 1_500L, // over 1 second
                specs.PARAM_MIN_POSITION_USD, 1d)
        );

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_RR_FILL_QUANTITY, Double.NaN,
                specs.PARAM_RR_FILL_RATIO, Double.NaN,
                specs.PARAM_RR_FILL_INTERVAL_MS, 0,
                specs.PARAM_STANDDOWN_PERIOD_MS, 0,
                specs.PARAM_MIN_POSITION_USD, Double.NaN)
        );

        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                Market.WSP_A,
                indirectPair,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs2.PARAM_TARGET_HEDGERS, "MID_BGC_EP")
        );

        priceFormationPipelineConfig2.add(PriceFormationPipelineConfig.create(specs2.NAME,
                Market.ANY,
                Instrument.ANY,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs2.PARAM_TARGET_HEDGERS, "")
        );

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_RISK_REDUCING_FLOW_PORTFOLIOS, new Portfolio[]{Portfolio.CLIENTS, Portfolio.HEDGER_MID_BGC}))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_SKEWING_PERIOD_SEC, 4))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.AUD, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.EUR, 5_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.JPY, 1_000_000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.USD, 4_000_000.0)
                ))
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setNetOpenPositionLimitConfigs(com.google.common.collect.Lists.newArrayList(
                        new NetOpenPositionLimitConfigImpl(Currency.AUD).setLimit(22_806_762),
                        new NetOpenPositionLimitConfigImpl(Currency.EUR).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(20_000_000),
                        new NetOpenPositionLimitConfigImpl(Currency.JPY).setLimit(50_000_000)
                ));

        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME,priceFormationPipelineConfig);
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs2.NAME,priceFormationPipelineConfig2);

        return configuration;
    }

    @Test
    public void rr_window_interval() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));

            // t+1, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 500_000, 0.75100));

            // t+2, receive risk INCREASING trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -500_000, 0.75100));

            // t+3, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 500_000, 0.75100));

            // t+5, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 500_000, 0.75100));
        }
        then:
        // STAND DOWN SKEWING for 0.5sec (until t+5.5sec)
        {
            // Stand down skew is ACTIVE!! Mid is UNSKEWED
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105));  // UNSKEWED MID

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.operations[0].var, is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].oldVal, f(oldVal -> (oldVal > 0.0)));  // i.e skew existed
            assertThat(ftl.operations[0].newVal, is(0.0));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(1_126_575.0));

            // Client Price is unskewed
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(indirectPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getUnskewedMid(), isRoundedTo(0.75105));
            assertThat(clientPrice.getSkewedMid(), isRoundedTo(0.75105));
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.75105));
        }
        and:
        // send pause signal to hedger
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
        }
        when:
        // receive AUD manual skew - overrides stand down skew
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.manualSkew(Currency.AUD, 0.1));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75106)); // 0.75105 + 0.00001
        }
        when:
        // t+5.25 continue to standdown skewing
        {
            prophet.receive(tdd.manualSkew(Currency.AUD, 0.0));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.0004));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75100));  // UNSKEWED MID
        }
        when:
        // t+5.5 standdown skewing period concluded
        // However, in the past 5 second window total riskreducing amt still above threshold. (i.e no trades have slide out)
        // Continue to standdown skewing until t+6sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.0004));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105));  // UNSKEWED MID

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(1_126_575.0));
        }
        and:
        // do NOT send pause signal to hedger since state has not changed
        {
            prophet.notExpect(HedgePauseSignal.class);
        }
        when:
        // t+6 standdown skewing period concluded
        // Since sliding window of 5sec risk increasing trade @t+1 slides out and total riskreducing amt below threshold.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.0004));
        }
        then:
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbfA.getSkewedMidPrice(), new IsRoundedTo(0.7510086));  // OP SKEWED MID
        }
        and:
        // send not pause signal to hedger
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.SKEW_STANDDOWN, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
        }
        when:
        // verify correct config(PARAM_RR_FILL_QUANTITY) used for SNG tz
        {
            prophet.receive(TradingTimeZone.SNG);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.0004));
        }
        then:
        // riskreducing amt is above SNG WSP_B PARAM_RR_FILL_QUANTITY -> stand down skew
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_B)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105));  // no skew

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(751_050.0));
        }
    }

    @Test
    public void verifying_config_parameters() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3_755_000.0));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(3_774_729.2418772564));
        }
        when:
        // receive risk reducing USDJPY trade
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(directPair, 1_000_000, 103.875));
        }
        then:
        // PARAM_MIN_POSITION_USD: 2_775_000d NOT MET, do NOT standdown skew
        {
            Positions positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(positionsUpdates.getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.getPosition2().getPositionInSystemBase(), is(2_774_729.2418772564));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.875864));  // skewed
        }
        when:
        // receive risk increasing CROSS client deal to generate positions then risk reducing trade
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, -5_000_000, 9.100));
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 2_000_000, 9.100));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(5_500_000.0));
            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), isRoundedTo(3_300_000.0));
        }
        and:
        // risk reducing amout = 2.2mio, nok pos(usd)=3.3mio, ratio=0.667  => below threshold 0.67
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(2), isWholesaleBookFactors(crossPair, Market.WSP_A)).getLast();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(9.10132));  // skewed
        }
        when:
        // receive risk decreasing CROSS client deal
        {

            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.EURNOK, 10_000, 9.100));
        }
        then:
        // risk reducing amout = 2.2mio + 11000, nok pos(usd)=3_289_000 mio, ratio=0.672 => ABOVE PARAM_RR_FILL_RATIO(0.67d)
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.NOK));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), isRoundedTo(3_289_000.0));
        }
        and:
        // standdown skewing
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(crossPair, Market.WSP_A)).getLast();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(9.100));  // unskewed
        }
        when:
        // verify skewing standdown for 1.5 sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1_499));  // just before stand down period ends
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.105, 0.004));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1)); // stand down period ends
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.004));
        }
        then:
        {
            LinkedList<WholesaleBookFactors> wbf = prophet.expect(WholesaleBookFactors.class, atLeast(2), isWholesaleBookFactors(crossPair, Market.WSP_A));
            assertThat(wbf.get(0).getSkewedMidPrice(), new IsRoundedTo(9.105));  // unskewed
            assertThat(wbf.get(1).getSkewedMidPrice(), new IsRoundedTo(9.1013156));  // skewed
        }
    }

    @Test
    public void sign_of_position_changed() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));

            // t+1, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 500_000, 0.75100));

            // t+5, receive risk decreasing trade
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.75100));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-2_628_500.0));
        }
        and:
        // STAND DOWN SKEWING for 0.5sec (until t+5.5sec)
        {
            // Stand down skew is ACTIVE!! Mid is UNSKEWED
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75100));  // UNSKEWED MID
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.bidStatus, is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, is(FeatureStatus.ACTIVE_IMPACT));
        }
        when:
        // t+5.25 during standdown window, receive client trade such that AUD position is now LONG
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 5_500_100, 0.75105));
        }
        then:
        {
            Positions positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(positionsUpdates.getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.getPosition1().getPositionInSystemBase(), is(1_502_075.1));
        }
        and:
        // abort stand down skew immediately
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.7509951));  // OP SKEWED MID
        }
        when:
        // to prove we have reset risk reducing amt(even though we have not increased time for any risk reducing trades to slide out),
        // a risk reducing trade of 563_250 USD is not enough to trigger standdown(PARAM_RR_FILL_QUANTITY 1_126_000d)
        {
            // risk increasing
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
            // risk decreasing
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -750_000, 0.75100));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.7509859));  // SKEWED MID
        }
    }

    @Test
    public void position_falls_below_min() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);

            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));
        }
        when:
        // t+1 receive risk increasing trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -5_000_000, 78.420));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-3_755_000.0));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(3_774_729.2418772564));
        }
        when:
        // receive risk reducing USDJPY trade
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(directPair, 990_000, 103.875));
        }
        then:
        // PARAM_MIN_POSITION_USD: 2_775_000d MET, STANDDOWN skew for 2sec (until t+3)
        {
            Positions positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(positionsUpdates.getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.getPosition2().getPositionInSystemBase(), is(2_784_729.2418772564));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.875));  // UNSKEWED MID
        }
        when:
        // while stand down skew active, receive risk reducing trade such what position falls below min(2_775_000d)
        // resume skew immediately (and clear previous risk reducing trades in buffer)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(directPair, 50_000, 103.875));
        }
        then:
        {
            Positions positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET)).getFirst();
            assertThat(positionsUpdates.getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.getPosition2().getPositionInSystemBase(), isRoundedTo(2_734_729.2));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.875849));  // SKEWED MID (EP only)
        }
        when:
        // to prove we have reset risk reducing amt(even though we have not increased time for any risk reducing trades to slide out),
        // a risk reducing trade of 490_000 USD is not enough to trigger standdown(PARAM_RR_FILL_QUANTITY 500_000d)
        {
            // risk increasing
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
            // risk decreasing
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(directPair, 490_000, 103.875));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(103.874426));  // EP SKEWED MID
        }
    }

    @Test
    public void risk_reducing_cross_trades() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 6_000_000, 78.420));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(4_506_000.0));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(-4_529_675.090252708));
        }
        when:
        // receive risk reducing AUDJPY trade
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -1_500_000, 78.420));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(3_379_500.0));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.JPY));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), is(-3_397_256.317689531));
        }
        and:
        // AUD risk reducing amt = 1126500, ratio = 826100/3679900 = 0.33
        // JPY risk reducing amt = 1132418.77, ratio = 1132418.77/3_397_256.317689531 = 0.33
        {
            WholesaleBookFactors wbfIndirect = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbfIndirect.getSkewedMidPrice(), new IsRoundedTo(0.75100));  // UNSKEWED MID

            FeatureTraceLine ftl =  wbfIndirect.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(1_126_500.0));

            WholesaleBookFactors wbfDirect = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(directPair, Market.WSP_A)).getFirst();
            assertThat(wbfDirect.getSkewedMidPrice(), new IsRoundedTo(103.875));  // UNSKEWED MID

            FeatureTraceLine ftl2 =  wbfDirect.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl2.operations[0].operation, is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl2.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl2.data[0].fx, isRoundedTo(1_132_418.00));
        }
    }

    @Test
    // only include risk reducing trades from the configured portfolios: CLIENTS,HEDGER_MID_BGC
    public void exclude_trades_from_certain_portfolios() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(setUpConfiguration(), false);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75100, 0.00003));
            prophet.receive(tdd.marketDataSnapshot(directPair, 103.875, 0.003));
            prophet.receive(tdd.marketDataSnapshot(crossPair, 9.100, 0.003));
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.10000, 0.00003));

            // send client deal to generate positions
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -7_000_000, 78.420));

            // t+1, receive risk decreasing trade but from INELIGIBLE PORTFOLIO
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(Portfolio.HEDGER_AGGRESSIVE, Instrument.AUDUSD, 1_500_000, 0.75100));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, exactly(2), isPortfolio(Portfolio.BIASED_CLIENTS_NET));

            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), is(-5_257_000.0));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), is(-4_130_500.0));
        }
        when:
        // receive AUDUSD
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75105, 0.0004));
        }
        then:
        // MID IS STILL SKEWED
        {
            // Stand down skew is ACTIVE!! Mid is UNSKEWED
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.7510618));  // SKEWED MID
        }
        when:
        // receive risk reducing trade from ELIGIBLE portfolio(hedger).
        // (op/nop skew is updated triggers client price)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedge_trade_001(Portfolio.HEDGER_MID_BGC, Instrument.AUDUSD, 1_500_000, 0.75100));
        }
        then:
        // stand down skewing enabled
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(indirectPair, Market.WSP_A)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), new IsRoundedTo(0.75105));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(StanddownSkewFastFillRateFeatureSpecs.NAME);
            assertThat(ftl.data[0].var.toString(), is(StanddownSkewFastFillRateFeatureSpecs.DATA_RR_FLOW));
            assertThat(ftl.data[0].fx, isRoundedTo(1_500_000 * 0.75105));
        }
    }
}