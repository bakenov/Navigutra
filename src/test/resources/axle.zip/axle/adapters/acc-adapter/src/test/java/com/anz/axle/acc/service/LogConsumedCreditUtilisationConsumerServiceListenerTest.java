package com.anz.axle.acc.service;

import com.anz.axle.acc.AbstractUnitTest;
import com.anz.axle.acc.domain.CreditCheckLogEntryBuilder;
import com.anz.axle.common.dao.CreditCheckLogDAO;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CreditCheckLogEntry;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import org.jmock.Expectations;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertTrue;

public class LogConsumedCreditUtilisationConsumerServiceListenerTest extends AbstractUnitTest {

    private CreditCheckLogDAO creditCheckLogDao;

    private CreditCheckLogEntryBuilder builder;

    private LogConsumedCreditUtilisationConsumerServiceListener listener;

    @Before
    public void before() {
        creditCheckLogDao = mock(CreditCheckLogDAO.class);
        builder = mock(CreditCheckLogEntryBuilder.class);

        listener = new LogConsumedCreditUtilisationConsumerServiceListener();
        listener.setBuilder(builder);
        listener.setCreditCheckLogDao(creditCheckLogDao);
    }

    @Test
    public void test_listener_saves_log_entry() throws BuilderException {
        final CreditCheckLogEntry entry = new CreditCheckLogEntry();
        final CurrencyVenueExclusion exclusion = new CurrencyVenueExclusion();

        checking(new Expectations() {
            {
                oneOf(builder).build(exclusion);
                will(returnValue(entry));
                oneOf(creditCheckLogDao).save(entry);
                will(returnValue(null));
            }
        });
        listener.onConsume(exclusion);
        assertTrue(mockLogAppender.contains("[SAVED EXCLUSION]"));
    }

    @Test
    public void test_listener_log_entry_even_if_save_fails() throws BuilderException {
        final CreditCheckLogEntry entry = new CreditCheckLogEntry();
        final CurrencyVenueExclusion exclusion = new CurrencyVenueExclusion();

        checking(new Expectations() {
            {
                oneOf(builder).build(exclusion);
                will(returnValue(entry));
                oneOf(creditCheckLogDao).save(entry);
                throwException(new RuntimeException("foo"));
            }
        });
        listener.onConsume(exclusion);
        assertTrue(mockLogAppender.contains("[SAVED EXCLUSION]"));
    }

    @Test
    public void test_listener_log_entry_even_if_build_fails() throws BuilderException {
        final CreditCheckLogEntry entry = new CreditCheckLogEntry();
        final CurrencyVenueExclusion exclusion = new CurrencyVenueExclusion();

        checking(new Expectations() {
            {
                oneOf(builder).build(exclusion);
                throwException(new BuilderException("foo"));
                never(creditCheckLogDao).save(entry);
            }
        });
        listener.onConsume(exclusion);
        assertTrue(mockLogAppender.contains("[SAVED EXCLUSION]"));
    }
}
