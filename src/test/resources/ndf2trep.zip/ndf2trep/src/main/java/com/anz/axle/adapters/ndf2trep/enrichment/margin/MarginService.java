package com.anz.axle.adapters.ndf2trep.enrichment.margin;

import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class MarginService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MarginService.class);

    private final Map<String, MarginCalculator> spotMarginCalculatorByRicMap;
    private final Map<String, Long> symbolPipsMap;
    private final RicRepository ricRepository;

    public MarginService(final Map<String, Map<String, List<String>>> spotMarginConfigMap,
                         final Map<String, Long> symbolPipsMap,
                         final RicRepository ricRepository) {
        Objects.requireNonNull(spotMarginConfigMap, "NULL spotMarginConfigMap");
        Objects.requireNonNull(symbolPipsMap, "NULL symbolPipsMap");
        Objects.requireNonNull(ricRepository, "NULL ricRepository");

        this.ricRepository = ricRepository;
        this.symbolPipsMap = symbolPipsMap;
        this.spotMarginCalculatorByRicMap = new HashMap<>();
        LOGGER.debug("MarginService init: spotMarginConfigMap={}, symbolPipsMap={}, ricRepository={}",
                spotMarginConfigMap, symbolPipsMap, ricRepository);
        spotMarginConfigMap.forEach((i, map) -> map.forEach((service, config) -> {
            if (service.equals(ricRepository.getServiceName())) {
                processConfig(i, config);
            }
        }));
        LOGGER.debug("built : spotMarginCalculatorByRicMap={}", spotMarginCalculatorByRicMap);
    }

    public boolean isSpotMarginConfigured(final String ricName) {
        return spotMarginCalculatorByRicMap.containsKey(ricName);
    }

    private void processConfig(String symbol, List<String> params) {
        String ricName = getRicNameBySymbol(symbol);
        if (ricName != null) {
            spotMarginCalculatorByRicMap.put(ricName,
                    MarginCalculator.createFromMarginConfig(params, symbolPipsMap.getOrDefault(symbol, 0L)));
        } else {
            LOGGER.warn("Can't find RIC name for symbol {}", symbol);
        }
    }

    private String getRicNameBySymbol(String symbol) {
        final String instrument = ricRepository.getSpotConfiguredInstrument(symbol);
        return ricRepository.getRicName(instrument, Tenor.SP.name());
    }

    public double applyMargin(final String ricName, final EntryType side, final double price) {
        MarginCalculator calculator = spotMarginCalculatorByRicMap.get(ricName);
        if (calculator != null) {
            LOGGER.debug("Margin configuration for RIC {}: {}", ricName, calculator);
            return calculator.applyMargin(side, price);
        } else {
            LOGGER.debug("No margin configured for RIC {}", ricName);
            return price;
        }
    }
}
