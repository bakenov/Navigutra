package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.PauserFactory;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceRealTime;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class ChronicleTimelyFilterTest {
    private static final int MAX = 100;
    private final ExecutorService executor = Executors.newFixedThreadPool(1);
    private final TimeSourceRealTime realTimeSource = new TimeSourceRealTime();
    private final TestTimeSource testTimeSource = new TestTimeSource(0L);
    private final CountingCheckingReader objectReader = new CountingCheckingReader();
    private final long allowableLagFromRealTimeMS = 1_000;
    private ProphetPersister persister;
    private ProphetReader reader;
    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    @After
    public void close() throws IOException {
        persister.close();
        reader.close();
        executor.shutdown();
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    @Before
    public void setup() throws Exception {
        Context.set(new Context(testTimeSource));
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;
        final String basePath = FileUtil.tmpFile(this.getClass().getSimpleName());
        persister = ChroniclePersisterFactory.coreConflate(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, true);
        reader = this.createStarfishOutReader(basePath, executor, objectReader);
        System.out.println(persister + "\n" + reader);
    }

    @Test
    public void testAllowThroughUpToDateEvents() throws Exception {
        checkWriteRead(0, MAX, MAX);
    }

    @Test
    public void testFilterOutOldEvents() throws Exception {
        checkWriteRead((allowableLagFromRealTimeMS + 1), 0, 0);
    }

    private void checkWriteRead(final long offsetMS, final int count, final int countValid) {
        final AdjustmentImpl adjustment = new AdjustmentImpl();
        adjustment.setCcy(Currency.CAD);

        testTimeSource.setMillis(realTimeSource.nowMillis() - offsetMS);
        for (int i = 0; i < MAX; i++) {
            Context.context().header().setEventTimeStampNS(testTimeSource.nowNanos());
            persister.sink(MessageType.ADJUSTMENT).accept(adjustment);
        }
        ThreadUtils.sleep(10);
        assertEquals(count, this.objectReader.count);
        assertEquals(countValid, this.objectReader.countValid);
    }

    public ProphetReader createStarfishOutReader(final String basePath, final ExecutorService executor, final CountingCheckingReader objectReader) throws IOException {
        return ChronicleReaderFactory.createStarOutReader(executor, objectReader, basePath, allowableLagFromRealTimeMS, null, RingBuffer.NO_RING, PauserFactory.create());
    }

    private class CountingCheckingReader implements ChronicleObjectReader {
        int count = 0, countValid = 0;

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            ++count;
            if ((realTimeSource.nowNanos() - Context.context().timeSource().nowNanos()) < TimeUnit.MILLISECONDS.toNanos(allowableLagFromRealTimeMS)) {
                ++countValid;
            }
        }
    }
}
