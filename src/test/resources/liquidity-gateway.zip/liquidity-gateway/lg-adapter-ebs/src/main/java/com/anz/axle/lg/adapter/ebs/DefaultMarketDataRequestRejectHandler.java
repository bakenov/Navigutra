package com.anz.axle.lg.adapter.ebs;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataRequestReject;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;

public final class DefaultMarketDataRequestRejectHandler implements ChronicleMessageHandler<MarketDataRequestReject> {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultMarketDataRequestRejectHandler.class);

    private final SubscriptionManager subscriptionManager;
    private final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy;

    public DefaultMarketDataRequestRejectHandler(final SubscriptionManager subscriptionManager,
                                                 final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy) {
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.subscriptionRequestRejectStrategy = Objects.requireNonNull(subscriptionRequestRejectStrategy);
    }

    @Override
    public void accept(final MarketDataRequestReject message) throws IllegalArgumentException {

        final int mdRequestId = (int) message.mDReqID().parseLong();
        final char mdRequestRejectReason = message.mDReqRejReason();
        final String rejectMessage = message.text();

        LOGGER.error("MarketDataRequest has been rejected with message: {}, rejection reason code: {}", rejectMessage, mdRequestRejectReason);

        subscriptionManager.rejectRequest(mdRequestId, subscriptionRequestRejectStrategy);
    }
}
