package com.anz.axle.acc.dao;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.transaction.annotation.Transactional;

import com.anz.axle.common.dao.jdbc.AggregatorTradeDAO;
import com.anz.axle.common.dao.jdbc.AuthenticationSystemDAO;
import com.anz.axle.common.dao.jdbc.StpCounterpartyDAO;
import com.anz.axle.common.dao.jdbc.TradeDAO;

import com.anz.axle.acc.domain.CreditUtilisingTrade;
import com.anz.axle.broker.domain.DomainEnums;
import com.anz.axle.common.domain.AggregatorTrade;
import com.anz.axle.common.domain.Amount;
import com.anz.axle.common.domain.AuthenticationSystem;
import com.anz.axle.common.domain.AuthenticationSystemCode;
import com.anz.axle.common.domain.Counterparty;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.Operation;
import com.anz.axle.common.domain.Price;
import com.anz.axle.common.domain.PublishableTrade;
import com.anz.axle.common.domain.RateDirection;
import com.anz.axle.common.domain.Source;
import com.anz.axle.common.domain.SourceFeed;
import com.anz.axle.common.domain.SourceFeedCode;
import com.anz.axle.common.domain.Trade;
import com.anz.axle.common.domain.TradeRole;
import com.anz.axle.common.domain.TradeState;
import com.anz.axle.common.domain.TradeType;

@ContextConfiguration(locations = {"classpath:config-test.xml"})
@Transactional(transactionManager = "transactionManager")
@Rollback
public class CreditUtilisationDAOTest extends AbstractTransactionalJUnit4SpringContextTests {
    @Autowired
    private CreditUtilisationDAO creditUtilisationDAO;

    @Autowired
    private TradeDAO tradeDAO = null;

    @Autowired
    private AggregatorTradeDAO aggregatorTradeDAO = null;

    @Autowired
    protected AuthenticationSystemDAO authSystemDAO;

    @Autowired
    protected StpCounterpartyDAO jdbcCounterpartyDAO = null;

    @Autowired
    protected com.anz.axle.common.dao.CounterpartyDAO hibernateCounterpartyDao = null;

    /**
     * difficult to know much about the data here without
     * scaffolding.
     */
    @Test
    public void test_find_and_build_counterparty_credit_utilisations() {
        LocalDate start = new LocalDate(2011, 1, 1);
        List<Counterparty> counterparties = hibernateCounterpartyDao.findCreditLimitedCounterparties();
        CounterpartyCreditUtilisations results = creditUtilisationDAO.getCounterpartySpotDateCreditUtilisations(start, counterparties);
    }

    @Test
    public void test_find_all() throws Exception {
        Counterparty counterparty = jdbcCounterpartyDAO.findById(198l);
        AuthenticationSystem barclays = authSystemDAO.findByAuthenticationSystemCode(AuthenticationSystemCode.BARCLAYS);
        PublishableTrade trade = getTrade("AUD", new LocalDate().plusDays(2).toDateTimeAtStartOfDay().toDate(), "source_system_id", "jonesr18",
                      barclays, TradeState.COMPLETED, TradeType.INITIAL, "USD", new Date());
        trade.setLinkedCounterparty(counterparty);
        tradeDAO.save(trade);

        AggregatorTrade aggregatorTrade = getAggregatorTrade(Operation.FILL, 2, "source_system_id", new Amount(1000000d));
        aggregatorTradeDAO.save(aggregatorTrade);

        Collection<CreditUtilisingTrade> results = creditUtilisationDAO.findAll();
        assertFalse(results.isEmpty());
    }

    @Test
    public void test_find_by_id() throws Exception {
        Counterparty counterparty = jdbcCounterpartyDAO.findById(198l);
        AuthenticationSystem commerz = authSystemDAO.findByAuthenticationSystemCode(AuthenticationSystemCode.COMMERZ);
        PublishableTrade trade = getTrade("AUD", new LocalDate().plusDays(2).toDateTimeAtStartOfDay().toDate(), "source_system_id", "jonesr18",
                      commerz, TradeState.COMPLETED, TradeType.INITIAL, "USD", new DateTime().withZone(DateTimeZone.UTC).toDate());
        trade.setLinkedCounterparty(counterparty);
        tradeDAO.save(trade);

        AggregatorTrade aggregatorTrade = getAggregatorTrade(Operation.FILL, 10, "source_system_id", new Amount(1000000d));
        aggregatorTradeDAO.save(aggregatorTrade);

        CreditUtilisingTrade creditUtilisingTrade = creditUtilisationDAO.findById(new Long(trade.getId()));

        assertCreditUtilisatingTrade(aggregatorTrade, trade, creditUtilisingTrade);
    }

    @Test
    public void test_find_utilisations() {
        creditUtilisationDAO.getCounterpartySpotDateCreditUtilisations(new LocalDate(), hibernateCounterpartyDao.findCreditLimitedCounterparties());
    }

    private void assertCreditUtilisatingTrade(AggregatorTrade aggregatorTrade, Trade trade, CreditUtilisingTrade creditUtilisingTrade) {
        assertNotNull(aggregatorTrade);
        assertNotNull(trade);
        assertNotNull(creditUtilisingTrade);
        assertNotNull(creditUtilisingTrade.getCreditPool());
        assertEquals("Commerzbank", creditUtilisingTrade.getCreditPool().getName());
        assertEquals(new Long(trade.getId()), creditUtilisingTrade.getId());
        assertEquals(aggregatorTrade.getOperation(), creditUtilisingTrade.getOperation());
        assertEquals(trade.getTradeState(), creditUtilisingTrade.getTradeState());
        assertEquals(aggregatorTrade.getUsdLastDoneAmount().asPlainString(), creditUtilisingTrade.getUsdLastDoneAmount().asPlainString());
        assertEquals(trade.getSourceSystemTradeId(), creditUtilisingTrade.getSourceSystemTradeId());
        assertEquals(trade.getTradeSource().getCode().getCode(), creditUtilisingTrade.getVenue().getCode());
        assertEquals(new LocalDate(trade.getSettlementDate()), creditUtilisingTrade.getSpotDate());
    }

    public AggregatorTrade getAggregatorTrade(Operation operation, int sourceSystemId, String destExecutionId, Amount usdLastDoneAmount) throws Exception {
        AggregatorTrade trade = new AggregatorTrade();
		trade.setOperation(operation);
		trade.setAxleOrderId("axle-order-id");

		trade.setAxleTimeStamp(new LocalDate().toDateTimeAtStartOfDay(DateTimeZone.UTC).toDate());
		trade.setAxleDealerId("axle-dealer-id");
		trade.setSourceSystem(sourceSystemId);
		trade.setDestination("Reuters");
		trade.setDestOrderId("dest-order-id");
		trade.setDestTimeStamp(new LocalDate().toDateTimeAtStartOfDay(DateTimeZone.UTC).toDate());
		trade.setDestDealerId("dest-dealer-id");
		trade.setDestExecutionId(destExecutionId);
		trade.setOrderType("order-type");
		trade.setInstrument("instrument");
		trade.setSide(DomainEnums.Side.BUY);
		trade.setOrderRate(new Price(0.034d));
		trade.setOrderAmount(new Amount(100000d));
		trade.setLeftAmount(new Amount(123000000d));
		trade.setDoneAmount(new Amount(2000000d));
		trade.setAvgRate(new Price(0.012d));
		trade.setLastDoneAmount(new Amount(1200000d));
		trade.setLastDoneRate(new Price(0.98d));
		trade.setValueDate(new LocalDate().plusDays(2).toDateTimeAtStartOfDay(DateTimeZone.UTC).toDate());
		trade.setCounterParty("counterparty");
		trade.setOriginalMessage("original-message");
		trade.setTradeArrived(new LocalDate().toDateTimeAtStartOfDay(DateTimeZone.UTC).toDate());
		trade.setUsdLastDoneAmount(usdLastDoneAmount);
		trade.setUsdLastDoneRate(new Price(0.99d));
        return trade;
    }

    private PublishableTrade getTrade(String fixedCcy, Date settlementDate, String sourceSystemTradeId,
                           String sourceSystemTraderId, AuthenticationSystem authSystem,
                           TradeState tradeState, TradeType tradeType, String variableCurrency, Date tradeDate) {
        PublishableTrade trade = new PublishableTrade();
        trade.setAggregatorTradeId("aggregatorId");
        trade.setFixedAmount(new Amount(1000000d));
        trade.setFixedCurrency(fixedCcy);
        trade.setFormedByReportId("report-id");
        trade.setLastPrice(new Price(0.12345d));
        trade.setRateDirection(RateDirection.NORMAL);
        trade.setSettlementDate(settlementDate);
        trade.setFixingDate(settlementDate);
        trade.setSide(DomainEnums.Side.BUY);
        trade.setSource(Source.UNKNOWN);
        trade.setSourceFeed(new SourceFeed(1, SourceFeedCode.CMZ_FIX_STP, "", "FX"));
        trade.setSourceSystemTradeId(sourceSystemTradeId);
        trade.setSourceSystemTraderId(sourceSystemTraderId);
        trade.setSpotPrice(new Price(0.1234d));
        trade.setTradeArrived(tradeDate);
        trade.setTradeDateAndTime(tradeDate);
        trade.setTradeRole(TradeRole.INITIATOR);
        trade.setTradeSource(authSystem);
        trade.setTradeState(tradeState);
        trade.setTradeType(tradeType);
        trade.setVariableAmount(new Amount(1000000d));
        trade.setExecutionChannel(DomainEnums.ExecutionChannel.AXLE);
        trade.setVariableCurrency(variableCurrency);
        trade.setCounterPartyName("counterparty_name");
        trade.setOriginalReport("original_report");
        return trade;
    }
}