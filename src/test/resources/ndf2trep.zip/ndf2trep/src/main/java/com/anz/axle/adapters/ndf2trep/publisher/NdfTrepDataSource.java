package com.anz.axle.adapters.ndf2trep.publisher;

import com.anz.axle.trep.publisher.TrepDataSource;
import com.anz.axle.trep.publisher.TrepDestination;
import com.anz.axle.trep.publisher.TrepDirectory;
import com.anz.axle.trep.publisher.TrepStreamable;
import com.anz.axle.trep.publisher.TrepStreamableQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public final class NdfTrepDataSource implements TrepDataSource {
    private static final Logger LOGGER = LoggerFactory.getLogger(NdfTrepDataSource.class);
    private static final int PUBLISHER_THREAD_SLEEP_TIME_MILLIS = 100;
    private static final int THREAD_JOIN_WAIT_MILLIS = 2 * PUBLISHER_THREAD_SLEEP_TIME_MILLIS;
    private static final String AXLE_VENDOR = "AXLE";

    private final TrepStreamableQueue trepStreamableQueue;
    private final AtomicReference<TrepDestination> publisher = new AtomicReference<TrepDestination>();
    private final AtomicBoolean runPublishingThread = new AtomicBoolean(false);
    private final String serviceName;
    private final RicRepository ricRepository;
    private PublisherThread publisherThread;

    public NdfTrepDataSource(final TrepStreamableQueue trepStreamableQueue, final RicRepository ricRepository, final String serviceName) {
        this.trepStreamableQueue = Objects.requireNonNull(trepStreamableQueue);
        this.ricRepository = Objects.requireNonNull(ricRepository);
        this.serviceName = Objects.requireNonNull(serviceName);
    }

    @PostConstruct
    public void start() {
        runPublishingThread.set(true);
        publisherThread = new PublisherThread();
        publisherThread.start();
    }

    @PreDestroy
    public void stop() {
        LOGGER.info("Publishing empty quotes from RicRepository on shutdown.");
        for (final String ricName: ricRepository.getRicNames(serviceName)) {
            trepStreamableQueue.enqueueItem(TrepQuote.createEmptyUpdateQuote(serviceName, ricName));
        }

        try {
            Thread.sleep(PUBLISHER_THREAD_SLEEP_TIME_MILLIS);
        } catch (InterruptedException e) {
            LOGGER.warn("Failed to wait from shutdown empty quotes to enqueueItem within {}ms", PUBLISHER_THREAD_SLEEP_TIME_MILLIS, e);
        }

        runPublishingThread.set(false);
        try {
            if (publisherThread != null) {
                publisherThread.join(THREAD_JOIN_WAIT_MILLIS);
                publisherThread = null;
            }
        } catch (InterruptedException e) {
            LOGGER.warn("Failed to stop publishing thread within {}ms", THREAD_JOIN_WAIT_MILLIS, e);
        }
    }

    @Override
    public int publishDirectoryImage(final TrepDestination trepDestination) {
        final TrepDirectory trepDirectory = new TrepDirectory(AXLE_VENDOR, serviceName);
        return trepDestination.submitIfLoggedOn(trepDirectory);
    }

    @Override
    public void publishInitialFullRefresh(final TrepDestination trepDestination) {
        for (final String ricName : ricRepository.getRicNames(serviceName)) {
            final TrepStreamable trepQuote = TrepQuote.createIndicativeRefreshQuote(serviceName, ricName);
            final int nextResult = trepDestination.submitIfLoggedOn(trepQuote);
            if (nextResult < 0) {
                LOGGER.error("Error sending initial REFRESH for {}.  Clients will not see updates for this RIC.", ricName);
            }
        }
    }

    @Override
    public void startPublishingUpdates(final TrepDestination trepDestination) {
        if (!publisher.compareAndSet(null, trepDestination) && !publisher.compareAndSet(trepDestination, trepDestination)) {
            LOGGER.error("Publishing already started to {} when start was requested by {}", publisher.get(), trepDestination);
        }
    }

    @Override
    public void stopPublishingUpdates(final TrepDestination trepDestination) {
        if (!publisher.compareAndSet(trepDestination, null)) {
            LOGGER.error("Request to stop publishing to {} when start is running to {}", trepDestination, publisher.get());
        }
    }

    private static int count = 0;
    private class PublisherThread extends Thread {
        public PublisherThread() {
            super(String.format("%s-%d", PublisherThread.class.getName(), count++));
        }

        @Override
        public void run() {
            LOGGER.info("Starting to publish NDF prices for {}", serviceName);
            while (runPublishingThread.get()) {
                try {
                    final TrepDestination trepDestination = publisher.get();
                    if (trepDestination != null) {
                        final TrepStreamable trepStreamable = trepStreamableQueue.poll(PUBLISHER_THREAD_SLEEP_TIME_MILLIS, TimeUnit.MILLISECONDS);
                        if (trepStreamable != null) {
                            if (trepDestination.submitIfLoggedOn(trepStreamable) == 0) {
                                LOGGER.warn("Publish failed for {}", trepStreamable);
                            } else {
                                LOGGER.debug("Published {}", trepStreamable);
                            }
                        }
                    } else {
                        Thread.sleep(PUBLISHER_THREAD_SLEEP_TIME_MILLIS);
                    }
                } catch (InterruptedException e) {
                    LOGGER.warn("Publishing of NDF prices for {} interrupted", serviceName, e);
                    return;
                } catch (Throwable t) {
                    LOGGER.error("Unexpected error in publisher thread", t);
                }
            }
        }
    }
}
