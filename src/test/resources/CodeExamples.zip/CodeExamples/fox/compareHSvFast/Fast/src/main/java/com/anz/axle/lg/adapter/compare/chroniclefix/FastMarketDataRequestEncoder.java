package com.anz.axle.lg.adapter.fast.chroniclefix;


import software.chronicle.fix.datamodel.AbstractDataModel;

import com.anz.axle.lg.adapter.chroniclefix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.MDEntryType;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.NoMDEntryTypes;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.NoRelatedSym;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.Symbol;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.MarketDataRequest;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.messages.datamodel.DefaultMarketDataRequest;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

import static com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.AggregatedBook.MULTIPLE_ENTRIES_PER_SIDE_PER_PRICE_ALLOWED;
import static com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.AggregatedBook.ONE_BOOK_ENTRY_PER_SIDE_PER_PRICE;
import static com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.MDUpdateType.FULL_REFRESH;
import static com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.MDUpdateType.INCREMENTAL_REFRESH;

public final class FastMarketDataRequestEncoder implements MarketDataRequestEncoder<MarketDataRequest> {
    protected static final char SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE = '1';
    protected static final char SUBSCRIPTION_REQUEST_TYPE_UNSUBSCRIBE = '2';
    private final DefaultMarketDataRequest marketDataRequest = new DefaultMarketDataRequest();

    public FastMarketDataRequestEncoder() {
        marketDataRequest.noMDEntryTypes(2);
        // TODO: would be good to have an addGroup?
        final AbstractDataModel bidEntryType = marketDataRequest.getGroup(NoMDEntryTypes.FIELD, 0);
        bidEntryType.setChar(MDEntryType.FIELD, MDEntryType.BID);
        final AbstractDataModel offerEntryType = marketDataRequest.getGroup(NoMDEntryTypes.FIELD, 1);
        offerEntryType.setChar(MDEntryType.FIELD, MDEntryType.OFFER);
    }

    @Override
    public MarketDataRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(requestId, subscription, SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE);
    }

    @Override
    public MarketDataRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(requestId, subscription, SUBSCRIPTION_REQUEST_TYPE_UNSUBSCRIBE);
    }


    private MarketDataRequest encode(final long requestId, final MarketDataSubscription subscription, final char subscriptionRequestType) {

        final int mdUpdateType = subscription.fullRefresh() ? FULL_REFRESH : INCREMENTAL_REFRESH;

        // don't need to reset as we are always overwriting
        //marketDataRequest.reset();
        marketDataRequest.mDReqID(marketDataRequest.mDReqID_buffer());
        marketDataRequest.mDReqID().append(requestId);
        marketDataRequest.subscriptionRequestType(subscriptionRequestType);
        marketDataRequest.marketDepth(subscription.marketDepth());
        marketDataRequest.mDUpdateType(mdUpdateType);
        marketDataRequest.aggregatedBook(subscription.aggregateBook() ? ONE_BOOK_ENTRY_PER_SIDE_PER_PRICE : MULTIPLE_ENTRIES_PER_SIDE_PER_PRICE_ALLOWED);

        marketDataRequest.setLong(NoRelatedSym.FIELD, 1);
        final AbstractDataModel group = marketDataRequest.getGroup(NoRelatedSym.FIELD, 0);
        //group.reset();
        group.setString(Symbol.FIELD, subscription.symbol());

        return marketDataRequest;
    }
}
