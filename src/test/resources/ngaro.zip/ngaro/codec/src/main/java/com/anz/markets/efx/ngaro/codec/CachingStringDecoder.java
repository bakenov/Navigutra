package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.ExpandableAsciiString;

/**
 * A {@link StringDecoder} which caches strings.
 * <p>
 * This class is NOT thread safe!
 */
public final class CachingStringDecoder implements StringDecoder {

    private final StringDecoder decoder;
    private final ByteValueCache<String> cache;
    private final ExpandableAsciiString temp;

    public CachingStringDecoder(final StringDecoder decoder, final int initialStringBufferSize, final int cacheSize) {
        this(decoder, initialStringBufferSize, new ByteValueCache<>(AsciiString::toString, initialStringBufferSize, cacheSize));
    }

    public CachingStringDecoder(final StringDecoder decoder, final int initialStringBufferSize, final ByteValueCache<String> cache) {
        this.decoder = Objects.requireNonNull(decoder);
        this.cache = Objects.requireNonNull(cache);
        this.temp = new ExpandableAsciiString(initialStringBufferSize);
    }

    public ByteValueCache<String> getCache() {
        return cache;
    }

    /**
     * Adds the specified value to the cache.
     * @param value the value to be added to the cache.
     */
    public void cache(final CharSequence value) {
        cache.lookupOrCache(value, ByteReader.CHAR_SEQUENCE, value.length());
    }

    @Override
    public String decodeStringOrNull() {
        return decodeAndCache(this.cache);
    }

    @Override
    public <T> T decodeAndCache(final ByteValueCache<T> cache) {
        final int length = decodeTo(temp, Integer.MAX_VALUE);
        try {
            if (length > 0) {
                return cache.lookupOrCache(temp);
            } else {
                return null;
            }
        } finally {
            temp.clear();
        }
    }

    @Override
    public <A extends Appendable> A decodeTo(final A target, final int maxTargetLength) {
        return decoder.decodeTo(target, maxTargetLength);
    }

    @Override
    public <T> int decodeTo(final T target, final ByteWriter<? super T> writer, final int targetOffset, final int maxTargetLength) {
        return decoder.decodeTo(target, writer, targetOffset, maxTargetLength);
    }

    @Override
    public long decodeLong(final long defaultValue) {
        return decoder.decodeLong(defaultValue);
    }
}
