#!/bin/bash

echo "Cleaning data on red    correlator boxes"
./clean-olddata-onebox.sh AxlSv@daxa021z clean_olddata_correlator
./clean-olddata-onebox.sh daxa004z clean_olddata_correlator

echo "Cleaning data on red    proxy broker boxes"
./clean-olddata-onebox.sh AxlSv@daxa021z clean_olddata_proxybroker
./clean-olddata-onebox.sh daxa004z clean_olddata_proxybroker