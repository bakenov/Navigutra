package com.anz.markets.efx.ngaro.time;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 * Unit test for {@link Epoch}
 */
@RunWith(Parameterized.class)
public class EpochTest {

    private final LocalDate localDate;
    private final long epochSecond;

    public EpochTest(final LocalDate localDate) {
        this.localDate = Objects.requireNonNull(localDate);
        this.epochSecond = localDate.atStartOfDay().toEpochSecond(ZoneOffset.UTC);
    }

    @Parameterized.Parameters(name = "{index}: value={0}")
    public static List<Object[]> data() {
        final List<Object[]> cases = new ArrayList<>();
        cases.add(new Object[] {LocalDate.of(1970, 1, 1)});
        cases.add(new Object[] {LocalDate.of(1922, 1, 1)});
        cases.add(new Object[] {LocalDate.of(1922, 5, 6)});
        cases.add(new Object[] {LocalDate.of(2016, 1, 1)});
        cases.add(new Object[] {LocalDate.of(2016, 12, 31)});
        cases.add(new Object[] {LocalDate.of(2222, 12, 31)});
        return cases;
    }
    @Test
    public void toEpochMillis() throws Exception {
        Assert.assertEquals("epochMillis not as expected", epochSecond * 1000, Epoch.toEpochMillis(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth()));
    }

    @Test
    public void toEpochSeconds() throws Exception {
        Assert.assertEquals("epochSeconds not as expected", epochSecond, Epoch.toEpochSeconds(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth()));
    }

    @Test
    public void toEpochDays() throws Exception {
        Assert.assertEquals("epochDays not as expected", localDate.toEpochDay(), Epoch.toEpochDays(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth()));
    }

    @Test
    public void fromEpochMillis() throws Exception {
        Assert.assertEquals("date not as expected", localDate, LocalDatePacking.BINARY.unpack(Epoch.fromEpochMillis(LocalDatePacking.BINARY, epochSecond * 1000)));
    }

    @Test
    public void fromEpochSeconds() throws Exception {
        Assert.assertEquals("date not as expected", localDate, LocalDatePacking.BINARY.unpack(Epoch.fromEpochSeconds(LocalDatePacking.BINARY, epochSecond)));
    }

    @Test
    public void fromEpochDays() throws Exception {
        Assert.assertEquals("date not as expected", localDate, LocalDatePacking.BINARY.unpack(Epoch.fromEpochDays(LocalDatePacking.BINARY, localDate.toEpochDay())));
    }

}