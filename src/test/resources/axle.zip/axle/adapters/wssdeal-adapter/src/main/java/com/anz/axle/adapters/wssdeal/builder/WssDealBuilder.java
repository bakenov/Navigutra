package com.anz.axle.adapters.wssdeal.builder;

import anz.markets.canonical.model.v2.AdjustableDateType;
import anz.markets.canonical.model.v2.ArrangementHandleType;
import anz.markets.canonical.model.v2.BusinessEventType;
import anz.markets.canonical.model.v2.DeliverableCommitmentType;
import anz.markets.canonical.model.v2.ExchangeRateSpecificationType;
import anz.markets.canonical.model.v2.FixedRateType;
import anz.markets.canonical.model.v2.IdentifierType;
import anz.markets.canonical.model.v2.LocationType;
import anz.markets.canonical.model.v2.PartyArrangementAssociationType;
import anz.markets.canonical.model.v2.RelatedTradeIdentifierType;
import anz.markets.canonical.model.v2.SimpleArrangementType;
import anz.markets.canonical.model.v2.SimpleResourceParcelType;
import anz.markets.canonical.model.v2.TimeInstantType;
import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import anz.markets.canonical.model.v2.TradeRelationshipEnumType;
import com.anz.axle.broker.domain.DomainEnums;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.wss.domain.WssDeal;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Date;
import java.util.List;

public class WssDealBuilder implements Builder<WssDeal, TradeMessageWrapperType> {
    private static final Logger LOG = Logger.getLogger(WssDealBuilder.class);

    static final String WSS_TRANSACTION_ID = "WSS_TRANSACTION_ID";
    static final String FX_PRODUCT_CODE = "FX_PRODUCT_CODE";
    static final String WSS_CUSTOMER_TYPE = "WSS_CUSTOMER_TYPE";
    static final String WSS_DEAL_NUMBER = "WSS_DEAL_NUMBER";
    static final String WSS_TRADE_TYPE = "WSS_TRADE_TYPE";
    static final String WSS_NEWREFERENCECOPY = "WSS_NEWREFERENCECOPY";
    static final String WSS_SOURCESYSTEM = "WSS_SOURCESYSTEM";
    static final String WSS_SOURCEDEALID = "WSS_SOURCEDEALID";
    static final String WSS_CUSTOMER_NUMBER = "WSS_CUSTOMER_NUMBER";
    static final String WSS_CUSTOMER_SHORT_NAME = "WSS_CUSTOMER_SHORT_NAME";
    static final String WSS_TRADER = "WSS_TRADER";
    static final String WSS_PORTFOLIO = "WSS_PORTFOLIO";
    static final String WSS_AREA = "WSS_AREA";
    static final String WSS_BROKER_CODE = "WSS_BROKER_CODE";
    static final String PARTY_1 = "PARTY_1";
    static final String PARTY_2 = "PARTY_2";
    static final String PARTY_3 = "PARTY_3";
    static final String PARTY_4 = "PARTY_4";
    static final String INVERSE = "INVERSE";
    static final String TRADE_SIDE_BUY = "B";
    static final String DEFAULT = "";
    static final String TRADE_EVENT = "FX_TRADE_EVENT";
    static final String PREVIOUS_TRADE = "PREVIOUS_TRADE";
    static final String WSS_PREV_DEAL = "WSS_PREV_DEAL";
    static final String WSS_TRADER_LOCATION = "WSS_TRADER_LOCATION";
    static final String WSS_TAKER_MEMO = "WSS_TAKERMEMO";
    static final String SPDEE_PREFIX = "SPDEE";

    @Override
    public WssDeal build(TradeMessageWrapperType tradeMessage) throws BuilderException {
        WssDeal deal = new WssDeal();
        try {
            deal.setTradeDateTime(getTradeDateTime(tradeMessage));
            deal.setWssTransactionId(getWssTransactionId(tradeMessage));
            deal.setDealType(getPartyIdentifierValue(tradeMessage, PARTY_2, WSS_CUSTOMER_TYPE));
            deal.setDealId(getDealId(tradeMessage));
            deal.setSide(getTradeType(tradeMessage));
            setBaseAndTermsCurrencyAndQuantity(deal, tradeMessage);
            deal.setSymbol(getSymbol(deal, tradeMessage));
            deal.setOriginalSymbol(getOriginalSymbol(deal, tradeMessage));
            deal.setRealtedDealId(getNewReferenceCopyOrTakerMemo(tradeMessage));
            deal.setSourceSystem(getSourceSystem(tradeMessage));
            deal.setCounterDealId(getCounterDealId(tradeMessage));
            deal.setCounterDealType(getCounterDealType(tradeMessage));
            deal.setCounterparty(getCounterparty(tradeMessage));
            deal.setCounterpartyGroup(getCounterpartyGroup(tradeMessage));
            deal.setPositionParty(getPositionParty(tradeMessage));
            deal.setPositionAccount(getPositionAccount(tradeMessage));
            deal.setWssArea(getWssArea(tradeMessage));
            deal.setWssTraderLocation(getWssTraderLocation(tradeMessage));
            deal.setClientPrice(getClientPrice(tradeMessage));
            deal.setSpotDate(getSpotDate(tradeMessage));
            deal.setValueDate(getValueDate(tradeMessage));
            deal.setSettlementRegion(getSettlementRegion(tradeMessage));
            deal.setQuoteStyle(getQuoteStyle(tradeMessage));
            deal.setProxyId(getProxyId(tradeMessage));
            deal.setDealStatus(getDealStatus(tradeMessage));
            deal.setCancelReason(getCancelReason(tradeMessage));
            deal.setOrigDealId(getAmendedDealId(tradeMessage));

        } catch (Exception e) {
            LOG.error(String.format("Not able to build WssDeal Object from tradeMessage %s", tradeMessage.toString()), e);
            throw new BuilderException(e);
        }
        return deal;
    }

    private String getAmendedDealId(final TradeMessageWrapperType tradeMessage) {
        List<RelatedTradeIdentifierType> relatedTradeIdentifierList = tradeMessage.getTradeHeader().getRelatedTradeIdentifier();
        for (RelatedTradeIdentifierType relatedTradeIdentifier : relatedTradeIdentifierList) {
            TradeRelationshipEnumType tradeRelationshipEnumType = relatedTradeIdentifier.getTradeRelationship();
            if (tradeRelationshipEnumType != null) {
                if (PREVIOUS_TRADE.equalsIgnoreCase(tradeRelationshipEnumType.value())) {
                    List<IdentifierType> arrangementIdeList = relatedTradeIdentifier.getArrangementIdentifier();
                    for (IdentifierType arrangementIdentifier : arrangementIdeList) {
                        if (WSS_PREV_DEAL.equalsIgnoreCase(arrangementIdentifier.getContext())) {
                            return arrangementIdentifier.getValue();
                        }
                    }
                }
            }
        }
        return DEFAULT;
    }

    private String getCancelReason(final TradeMessageWrapperType tradeMessage) {
        List<BusinessEventType> tradeBusinessEventList = tradeMessage.getTradeHeader().getTradeBusinessEvent();
        for (BusinessEventType tradeBusinessEvent : tradeBusinessEventList) {
            BusinessEventType.Reason reason = tradeBusinessEvent.getReason();
            return reason.getValue();
        }
        return DEFAULT;
    }

    private String getDealStatus(final TradeMessageWrapperType tradeMessage) {
        List<BusinessEventType> tradeBusinessEventList = tradeMessage.getTradeHeader().getTradeBusinessEvent();
        for (BusinessEventType tradeBusinessEvent : tradeBusinessEventList) {
            List<IdentifierType> eventIdentifierList = tradeBusinessEvent.getEventIdentifier();
            for (IdentifierType identifier : eventIdentifierList) {
                if (TRADE_EVENT.equalsIgnoreCase(identifier.getContext())) {
                    return identifier.getValue();
                }
            }
        }
        return DEFAULT;
    }

    private String getProxyId(final TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, PARTY_3, WSS_BROKER_CODE);
    }

    protected String getSymbol(WssDeal deal,
                               TradeMessageWrapperType tradeMessage) {
        return deal.getBaseCurrency() + deal.getTermsCurrency();
    }

    protected String getOriginalSymbol(WssDeal deal,
                                       TradeMessageWrapperType tradeMessage) {
        if (INVERSE.equals(getQuoteStyle(tradeMessage))) {
            return deal.getTermsCurrency() + deal.getBaseCurrency();
        }
        return deal.getSymbol();
    }

    protected String getPartyIdentifierValue(TradeMessageWrapperType tradeMessage,
                                             String party,
                                             String context) {
        List<TradeMessageWrapperType.TradeParty> tradePartyList = tradeMessage.getTradeParty();
        for (TradeMessageWrapperType.TradeParty tradeParty : tradePartyList) {
            if (party.equals(tradeParty.getID())) {
                return getIdentifierValueFromList(tradeParty.getPartyIdentifier(), context);
            }
        }
        return DEFAULT;
    }


    protected String getIdentifierValueFromList(List<IdentifierType> identifierList,
                                                String context) {
        for (IdentifierType identifier : identifierList) {
            if (context.equals(identifier.getContext())) {
                return identifier.getValue();
            }
        }
        return DEFAULT;
    }

    protected String getIdentifierValueFromPartyArrangementAssociationType(List<PartyArrangementAssociationType>
                                                                                   partyArrangementAssociationTypes,
                                                                           String context) {
        for (PartyArrangementAssociationType partyArrangementAssociationType : partyArrangementAssociationTypes) {
            ArrangementHandleType arrangement = partyArrangementAssociationType.getArrangement();
            for (IdentifierType identifierType : arrangement.getArrangementIdentifier()) {
                if (context.equals(identifierType.getContext())) {
                    return identifierType.getValue();
                }
            }
        }
        return DEFAULT;
    }


    protected String getDealId(TradeMessageWrapperType tradeMessage) {
        return getIdentifierValueFromPartyArrangementAssociationType(tradeMessage.getTradeHeader().getTradeIdentifier(), WSS_DEAL_NUMBER);
    }

    protected DomainEnums.Side getTradeType(TradeMessageWrapperType tradeMessage) {
        String side = getIdentifierValueFromPartyArrangementAssociationType(tradeMessage.getTradeHeader().getTradeIdentifier(), WSS_TRADE_TYPE);
        if (TRADE_SIDE_BUY.equals(side)) {
            return DomainEnums.Side.BUY;
        }
        return DomainEnums.Side.SELL;
    }

    protected void setBaseAndTermsCurrencyAndQuantity(WssDeal deal,
                                                      TradeMessageWrapperType tradeMessage) {
        SimpleArrangementType tradeDetail = (SimpleArrangementType) tradeMessage.getTradeDetail();

        DeliverableCommitmentType deliverableCommitmentType1 = (DeliverableCommitmentType) tradeDetail.getCommitment().get(0);
        DeliverableCommitmentType deliverableCommitmentType2 = (DeliverableCommitmentType) tradeDetail.getCommitment().get(1);

        SimpleResourceParcelType simpleResourceParcelType1 = (SimpleResourceParcelType) deliverableCommitmentType1.getDeliverable();
        SimpleResourceParcelType simpleResourceParcelType2 = (SimpleResourceParcelType) deliverableCommitmentType2.getDeliverable();

        Decimal commitment1Quantity = new Decimal(simpleResourceParcelType1.getQuantity().getValue());
        Decimal commitment2Quantity = new Decimal(simpleResourceParcelType2.getQuantity().getValue());

        String commitment1Ccy = simpleResourceParcelType1.getAsset().getIdentifier().get(0).getValue();
        String commitment2Ccy = simpleResourceParcelType2.getAsset().getIdentifier().get(0).getValue();
        if (DomainEnums.Side.BUY.equals(deal.getSide())) {
            deal.setQuantity(commitment1Quantity);
            deal.setBaseCurrency(commitment1Ccy);
            deal.setTermsQuantity(commitment2Quantity);
            deal.setTermsCurrency(commitment2Ccy);
        } else {
            deal.setQuantity(commitment2Quantity);
            deal.setBaseCurrency(commitment2Ccy);
            deal.setTermsQuantity(commitment1Quantity);
            deal.setTermsCurrency(commitment1Ccy);
        }
    }

    protected String getNewReferenceCopyOrTakerMemo(TradeMessageWrapperType tradeMessage) {
        String wssTakerMemo = getIdentifierValueFromList(tradeMessage.getTradeHeader().getChannelIdentifier().getIdentifier(), WSS_TAKER_MEMO);
        if (StringUtils.isNotEmpty(wssTakerMemo) && (StringUtils.startsWithIgnoreCase(wssTakerMemo, SPDEE_PREFIX) || StringUtils.containsIgnoreCase(wssTakerMemo, SPDEE_PREFIX))) {
            return getIdentifierValueFromList(tradeMessage.getTradeHeader().getChannelIdentifier().getIdentifier(), WSS_TAKER_MEMO);
        }
        return getIdentifierValueFromList(tradeMessage.getTradeHeader().getChannelIdentifier().getIdentifier(), WSS_NEWREFERENCECOPY);
    }

    protected String getCounterDealId(TradeMessageWrapperType tradeMessage) {
        return getIdentifierValueFromList(tradeMessage.getTradeHeader().getChannelIdentifier().getIdentifier(), WSS_SOURCEDEALID);
    }

    protected String getCounterDealType(TradeMessageWrapperType tradeMessage) {
        return getIdentifierValueFromList(tradeMessage.getTradeHeader().getProductIdentifier().getIdentifier(), FX_PRODUCT_CODE);
    }

    protected String getCounterparty(TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, PARTY_2, WSS_CUSTOMER_NUMBER);
    }

    protected String getCounterpartyGroup(TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, PARTY_2, WSS_CUSTOMER_SHORT_NAME);
    }

    protected String getPositionParty(TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, PARTY_4, WSS_TRADER);
    }

    protected String getPositionAccount(TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, PARTY_1, WSS_PORTFOLIO);
    }

    protected String getWssArea(TradeMessageWrapperType tradeMessage) {
        return getPartyIdentifierValue(tradeMessage, PARTY_1, WSS_AREA);
    }

    protected String getWssTraderLocation(TradeMessageWrapperType tradeMessage) {
        List<TradeMessageWrapperType.TradeParty> tradePartyList = tradeMessage.getTradeParty();
        for (TradeMessageWrapperType.TradeParty tradeParty : tradePartyList) {
            if (PARTY_4.equals(tradeParty.getID())) {
                List<LocationType> locationTypes = tradeParty.getPartyLocation();
                for (LocationType locationType : locationTypes) {
                    if(locationType.getLocationIdentifier()!=null && WSS_TRADER_LOCATION.equals(locationType
                            .getLocationIdentifier().getContext())) {
                        return locationType.getLocationIdentifier().getValue();
                    }
                }
            }
        }
        return DEFAULT;
    }

    protected String getQuoteStyle(TradeMessageWrapperType tradeMessage) {
        SimpleArrangementType tradeDetail = (SimpleArrangementType) tradeMessage.getTradeDetail();
        FixedRateType tradePrice = (FixedRateType) tradeDetail.getTradePrice();
        ExchangeRateSpecificationType exchangeRateSpecificationType = (ExchangeRateSpecificationType) tradePrice.getPriceSpecification();
        return exchangeRateSpecificationType.getQuoteStyle();
    }

    protected Decimal getClientPrice(TradeMessageWrapperType tradeMessage) {
        Decimal clientPrice = new Decimal(0.0d);
        SimpleArrangementType tradeDetail = (SimpleArrangementType) tradeMessage.getTradeDetail();
        FixedRateType tradePrice = (FixedRateType) tradeDetail.getTradePrice();
        try {
            clientPrice = new Decimal(tradePrice.getFixedRate().getValue().getValue());
        } catch (Exception e) {
            LOG.info(String.format("Client Price format problem %s", tradePrice.getFixedRate().getValue().getValue()));
        }
        return clientPrice;

    }

    protected Date getSpotDate(TradeMessageWrapperType tradeMessage) {
        XMLGregorianCalendar xmlGregorianCalendar = tradeMessage.getTradeHeader().getTradeDateStamp().get(0).getValue();
        java.util.Date dt = xmlGregorianCalendar.toGregorianCalendar().getTime();
        DateTime spotDate = new DateTime(dt, DateTimeZone.UTC);
        return spotDate.toDate();
    }

    protected Date getValueDate(TradeMessageWrapperType tradeMessage) {
        SimpleArrangementType tradeDetail = (SimpleArrangementType) tradeMessage.getTradeDetail();
        DeliverableCommitmentType deliverableCommitmentType = (DeliverableCommitmentType) tradeDetail.getCommitment().get(0);
        TimeInstantType deliveryPeriod = (TimeInstantType) deliverableCommitmentType.getDeliveryPeriod();
        AdjustableDateType dateType = deliveryPeriod.getDateTime().get(0);
        XMLGregorianCalendar xmlGregorianCalendar = dateType.getValue();
        java.util.Date dt = xmlGregorianCalendar.toGregorianCalendar().getTime();
        DateTime valueDate = new DateTime(dt, DateTimeZone.UTC);
        return valueDate.toDate();
    }

    protected String getSettlementRegion(TradeMessageWrapperType tradeMessage) {
        // return getPartyIdentifierValue(tradeMessage, PARTY_3, WSS_BROKER_CODE);
        return tradeMessage.getMessageHeader().getEmittedBySourceSystemInstance().getCountryCode();
    }

    protected Date getTradeDateTime(TradeMessageWrapperType tradeMessage) {
        XMLGregorianCalendar xmlGregorianCalendar = tradeMessage.getMessageHeader().getSourceSystemCreationDateTime();
        java.util.Date dt = xmlGregorianCalendar.toGregorianCalendar().getTime();
        DateTime tradeDateTime = new DateTime(dt, DateTimeZone.UTC);
        return tradeDateTime.toDate();

 }

    protected String getWssTransactionId(TradeMessageWrapperType tradeMessage) throws BuilderException {
        for (PartyArrangementAssociationType partyArrangementAssociationType : tradeMessage.getTradeHeader().getTradeIdentifier()) {
            ArrangementHandleType arrangement = partyArrangementAssociationType.getArrangement();
            for (IdentifierType identifierType : arrangement.getArrangementIdentifier()) {
                if (identifierType.getContext().equals(WSS_TRANSACTION_ID)) {
                    return identifierType.getValue();
                }
            }
        }
        throw new BuilderException("Unique identifier - Wss Transaction id not found in message.");
    }

    protected String getSourceSystem(TradeMessageWrapperType tradeMessage) throws BuilderException {
        for (IdentifierType identifier : tradeMessage.getTradeHeader().getChannelIdentifier().getIdentifier()) {
            if (identifier.getContext().equals(WSS_SOURCESYSTEM)) {
                return identifier.getValue();
            }
        }
        throw new BuilderException("Trade Source system not found in message.");
    }
}
