package com.anz.markets.efx.fox.firewall.metric;

import java.util.Objects;

import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class MatchableMetric implements Metric {
    private final Metric delegateMetric;
    private final ExecutionReportMatcher matcher;

    public MatchableMetric(final Metric delegateMetric, final ExecutionReportMatcher matcher) {
        this.delegateMetric = Objects.requireNonNull(delegateMetric);
        this.matcher = Objects.requireNonNull(matcher);
    }

    @Override
    public void accept(final ExecutionReportDecoder executionReport, final long currentTimeNanos) {
        if (matcher.test(executionReport)) {
            delegateMetric.accept(executionReport, currentTimeNanos);
        }
    }

    @Override
    public void accept(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        delegateMetric.accept(newOrderSingle, currentTimeNanos);
    }

    @Override
    public double currentValue(final long currentTimeNanos) {
        return delegateMetric.currentValue(currentTimeNanos);
    }

    @Override
    public double nextValue(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        return delegateMetric.nextValue(newOrderSingle, currentTimeNanos);
    }
}
