package com.anz.axle.lg.adapter.apama.event;

import java.util.Map;

import com.apama.event.parser.BooleanFieldType;
import com.apama.event.parser.DictionaryFieldType;
import com.apama.event.parser.Field;
import com.apama.event.parser.FloatFieldType;
import com.apama.event.parser.IntegerFieldType;
import com.apama.event.parser.StringFieldType;

/**
 * Declares general fields, i.e. fields commonly occurring in all apama event types
 */
public class GeneralApamaEventFields {
    public static final Field<String> FIELD_TRANSPORT = new Field<String>("TRANSPORT", StringFieldType.TYPE);
    public static final Field<String> FIELD_SESSION = new Field<>("SESSION", StringFieldType.TYPE);
    public static final Field<String> FIELD_SYMBOL = new Field<>("Symbol", StringFieldType.TYPE);
    public static final Field<Long> FIELD_SEQUENCE_NUMBER = new Field<>("seqnum", IntegerFieldType.TYPE);
    public static final Field<Boolean> FIELD_CONNECTED = new Field<>("connected", BooleanFieldType.TYPE);
    public static final Field<Long> FIELD_ID = new Field<>("id", IntegerFieldType.TYPE);
    public static final Field<Map<Long, Double>> FIELD_TIMESTAMPS = new Field<>("__timestamps", new DictionaryFieldType<>(IntegerFieldType.TYPE, FloatFieldType.TYPE));
    public static final Field<Map<String, String>> FIELD_PAYLOAD = new Field<>("__payload", new DictionaryFieldType<>(StringFieldType.TYPE, StringFieldType.TYPE));
    public static final Field<Map<Long, String>> FIELD_EXTRA_PARAMS = new Field<>("_extraParams", new DictionaryFieldType<>(IntegerFieldType.TYPE, StringFieldType.TYPE));
}
