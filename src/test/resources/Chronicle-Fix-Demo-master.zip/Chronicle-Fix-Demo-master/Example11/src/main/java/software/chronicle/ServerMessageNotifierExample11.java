package software.chronicle;

import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.concurrent.CountDownLatch;

public class ServerMessageNotifierExample11 implements MessageNotifier, Marshallable {

    public CountDownLatch messageReceived = new CountDownLatch(1);

    @Override
    public void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        // do nothing as the message will be logged to the chronicle queue
        messageReceived.countDown();
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }
}
