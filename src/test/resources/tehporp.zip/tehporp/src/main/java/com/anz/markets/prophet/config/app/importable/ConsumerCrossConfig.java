package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.backtest.BackTestManager;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.config.business.FailSafeConfigManager;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.pricer.ClientPriceEnricher;
import com.anz.markets.prophet.pricer.cross.CrossRateCalculator;
import com.anz.markets.prophet.pricer.cross.CrossRateManager;
import com.anz.markets.prophet.pricer.cross.ForwardPointManager;
import com.anz.markets.prophet.pricer.cross.MidRateToBaseCache;
import com.anz.markets.prophet.pricer.cross.SeparatedCrossRateManager;
import com.anz.markets.prophet.pricer.inverse.InverseRateManager;
import com.anz.markets.prophet.pricer.inverse.SeparatedInverseRateManager;
import com.anz.markets.prophet.pricer.pfp.cache.ClientPriceDataRegisterDependencyManager;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.pricer.throttle.ClientPriceThrottleManager;
import com.anz.markets.prophet.pricer.truethrottle.TrueThrottleManager;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.ActivationProcessor;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.util.function.Consumer;

@Configuration
@Import({BusinessConfig.class, BackTestConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class ConsumerCrossConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ConsumerCrossConfig.class);

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public Consumer<Activate> activateConsumers(final ActivationProcessor activationProcessor) {
        return activationProcessor;
    }

    @Bean
    public ActivationProcessor activationProcessor(@Value("${core.instance:0}") final int coreInstance,
                                                   @Qualifier("activateSink") final Consumer<Activate> activateSink) {
        return new ActivationProcessor(new NotifierDefault<>(activateSink), coreInstance);
    }

    @Bean
    public Consumer<ConfigurationData> configurationDataConsumer(final FailSafeConfigManager failSafeConfigManager) {
        return failSafeConfigManager.consumerConfigurationData();
    }

    @Bean
    public Consumer<SpotDate> spotDateConsumer(final ForwardPointManager forwardPointManager,
                                               final CrossRateManager crossRateManager,
                                               final ClientPriceEnricher clientPriceEnricher) {
        return new NotifierDefault(forwardPointManager.consumerOfSpotDate(),
                crossRateManager.consumerSpotDate(),
                clientPriceEnricher.consumerSpotDate());
    }

    @Bean
    public Consumer<ForwardPoint> forwardPointConsumer(final ForwardPointManager forwardPointManager) {
        return new NotifierDefault<>(forwardPointManager.consumerOfForwardPoint());
    }

    // the business consumers themselves
    @Bean
    public FailSafeConfigManager configProcessor(final ConfigurationData configurationDataDefault,
                                                 final DataRegisters dataRegisters,
                                                 final ClientPriceThrottleManager clientPriceThrottleManager,
                                                 final TrueThrottleManager trueThrottleManager,
                                                 final CrossRateManager crossRateManager,
                                                 final ForwardPointManager forwardPointManager,
                                                 final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager,
                                                 final InverseRateManager inverseRateManager,
                                                 final BackTestManager backTestManager,
                                                 @Value("${business.config.json.file:/business.config.json}") final String jsonFile,
                                                 @Value("${fail.safe.config.manager.should.initialise.with.cache:true}") final boolean shouldInitialiseWithCache) {

        final Consumer<IndexedConfigurationData> consumers = new NotifierDefault<>(
                dataRegisters.consumerIndexedConfigurationData(),
                clientPriceDataRegisterDependencyManager.consumerIndexedConfigurationData(),
                crossRateManager.consumerIndexedConfigurationData(),
                forwardPointManager.consumerIndexedConfigurationData(),
                inverseRateManager.consumerIndexedConfigurationData(),
                clientPriceThrottleManager.consumerIndexedConfigurationData(),
                trueThrottleManager.consumerIndexedConfigurationData());

        // the separate cross processor will not write to config file.
        return FailSafeConfigManager.createInstance(shouldInitialiseWithCache, false, backTestManager.isBackTestEnabled(),
                (ConfigurationDataDefault) configurationDataDefault, jsonFile, consumers);
    }

    @Bean
    public ForwardPointManager forwardPointManager(final DataRegisters dataRegisters, final CrossRateManager crossRateManager) {
        return new ForwardPointManager(dataRegisters,crossRateManager.consumerForwardPointCurve());
    }

    @Bean
    public Consumer<MarketDataSnapshot> midRateConsumer(final DataRegisters dataRegisters) {
        return new NotifierDefault(dataRegisters.consumerOfMarketData());
    }

    @Bean
    public TradingTimeZoneManager tradingTimeZoneManager(final CrossRateManager crossRateManager) {
        return new TradingTimeZoneManager(new NotifierDefault<>(
                crossRateManager.consumerTradingTimeZoneChime()));
    }

    @Bean
    public DataRegisters dataRegisters() {
        return new DataRegisters();
    }

    @Bean
    public ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager(@NotNull final DataRegisters dataRegisters) {
        return new ClientPriceDataRegisterDependencyManager(dataRegisters);
    }

    @Bean
    public CrossRateManager crossRateManager(@NotNull final InverseRateManager inverseRateManager,
                                             @Value("${backtest.enabled:false}") final boolean backTestEnabled,
                                             @Value("${backtest.disable.crossrates:false}") final boolean disableCrossRateFormation) {
        final MidRateToBaseCache midRateToBaseProvider = new MidRateToBaseCache();
        final CrossRateCalculator calculator = new CrossRateCalculator(midRateToBaseProvider,backTestEnabled);
        SeparatedCrossRateManager crossRateManager = new SeparatedCrossRateManager(calculator,
                midRateToBaseProvider,
                inverseRateManager.consumerOfClientPrice());
        crossRateManager.setDisableCrossRateFormation(backTestEnabled && disableCrossRateFormation);
        return crossRateManager;
    }

    @Bean
    public InverseRateManager inverseRateManager(@NotNull final ClientPriceThrottleManager clientPriceThrottleManager,
                                                 final TrueThrottleManager trueThrottleManager) {

        return new SeparatedInverseRateManager(new NotifierDefault<>(
                clientPriceThrottleManager.consumerClientPrice(),
                trueThrottleManager.consumerClientPrice()));
    }

    @Bean
    public Consumer<OneSecond> oneSecondConsumer(final ForwardPointManager forwardPointManager,
                                                 final ClientPriceThrottleManager clientPriceThrottleManager,
                                                 final TrueThrottleManager trueThrottleManager) {
        return new NotifierDefault<>(
                clientPriceThrottleManager.consumerOneSecond(),
                trueThrottleManager.consumerOneSecond(),
                forwardPointManager.consumerOfOneSecond());
    }

    @Bean
    public Consumer<ClientPrice> clientPriceConsumer(final CrossRateManager crossRateManager) {
        return new NotifierDefault<>(crossRateManager.consumerClientPrice());
    }

    @Bean
    public ClientPriceThrottleManager clientPriceThrottleManager(@NotNull final ClientPriceEnricher clientPriceEnricher,
                                                                 @Value("${throttler.should.publish.all:true}") final boolean publishAll) {
        return new ClientPriceThrottleManager(clientPriceEnricher.consumerClientPrice(), publishAll);
    }

    @Bean
    public TrueThrottleManager trueThrottleManager(@NotNull final ClientPriceEnricher clientPriceEnricher,
                                                   @Value("${throttler.should.publish.all:true}") final boolean publishAll,
                                                   @Value("${backtest.enabled:false}") final boolean backTestEnabled) {
        return new TrueThrottleManager(clientPriceEnricher.consumerClientPrice(), publishAll, backTestEnabled);
    }

    @Bean
    public ClientPriceEnricher clientPriceEnricher(@NotNull final ProphetPersister prophetPersister) {
        return new ClientPriceEnricher(prophetPersister.sink(MessageType.CLIENT_PRICE));
    }
}
