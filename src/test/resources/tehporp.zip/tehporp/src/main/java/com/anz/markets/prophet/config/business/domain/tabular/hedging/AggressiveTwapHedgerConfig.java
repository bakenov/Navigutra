package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.TradingTimeZone;

public interface AggressiveTwapHedgerConfig extends HedgeInstrumentConfig {
    AggressiveTwapHedgerConfig EMPTY = new AggressiveTwapHedgerConfigImpl();

    double getMaximumSpread();

    long getMinimumQuantity();

    double getMinimumRisk();

    long getOrderRateLimit();

    long getOrderRateTimePeriodMS();

    TradingTimeZone getTradingTimeZone();

    FactorWindow getVolatilityFactorWindow();

    double getMinimumVolatility();

    int getVolatilityPeriodInMillis();
}