package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.general.KeyValueConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.stream.Collectors;

@SuppressWarnings("CPD-START")
public class KeyValueConfigImpl implements KeyValueConfig, ProphetMarshallable {

    private String keyName;
    private String valueName;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public KeyValueConfigImpl() {
    }

    public KeyValueConfigImpl(final String keyName,
                              final String valueName) {
        this.keyName = keyName;
        this.valueName = valueName;
    }

    // type safe method for construction via unit test.
    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final String valueName) {
        this(keyValueConfigType.getKeyName(), valueName);
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == String.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), String.class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final boolean valueName) {
        this(keyValueConfigType.getKeyName(), String.valueOf(valueName));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == boolean.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), boolean.class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final double valueName) {
        this(keyValueConfigType.getKeyName(), String.valueOf(valueName));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == double.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), double.class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final int valueName) {
        this(keyValueConfigType.getKeyName(), String.valueOf(valueName));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == int.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), int.class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final long valueName) {
        this(keyValueConfigType.getKeyName(), String.valueOf(valueName));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == long.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), long.class);
    }

    @SuppressWarnings("CPD-START")
    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final Currency[] valueName) {
        this(keyValueConfigType.getKeyName(), Arrays.asList(valueName).stream().map(e -> e.name()).collect(Collectors.joining(",")));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == Currency[].class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), Currency[].class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final Instrument[] valueName) {
        this(keyValueConfigType.getKeyName(), Arrays.asList(valueName).stream().map(e -> e.name()).collect(Collectors.joining(",")));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == Instrument[].class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), Instrument[].class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final Market[] valueName) {
        this(keyValueConfigType.getKeyName(), Arrays.asList(valueName).stream().map(e -> e.name()).collect(Collectors.joining(",")));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == Market[].class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), Market[].class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final Portfolio[] valueName) {
        this(keyValueConfigType.getKeyName(), Arrays.asList(valueName).stream().map(e -> e.name()).collect(Collectors.joining(",")));
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == Portfolio[].class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), Portfolio[].class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final Region valueName) {
        this(keyValueConfigType.getKeyName(), valueName.name());
        GcFriendlyAssert.notNull(valueName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == Region.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), long.class);
    }

    public KeyValueConfigImpl(final KeyValueConfigType keyValueConfigType,
                              final Market marketName) {
        this(keyValueConfigType.getKeyName(), marketName.name());
        GcFriendlyAssert.notNull(marketName);
        GcFriendlyAssert.isTrue(keyValueConfigType.getType() == Market.class, "Incorrect value type, %s is defined as %s but seeing %s.", keyValueConfigType.getKeyName(), keyValueConfigType.getType(), long.class);
    }

    @SuppressWarnings("CPD-END")

    @Override
    public String getKeyName() {
        return keyName;
    }

    @Override
    public String getValueName() {
        return valueName;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        FieldReflectionBytesMarshallable.INSTANCE.read(in, this);
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        FieldReflectionBytesMarshallable.INSTANCE.write(this, out);
    }

    @Override
    public String toString() {
        return "KeyValueConfigImpl{" +
                "keyName='" + keyName + '\'' +
                ", valueName='" + valueName + '\'' +
                '}';
    }
}
