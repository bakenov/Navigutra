package com.anz.axle.lg.adapter.d3.config;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;

import com.anz.axle.lg.config.DefaultTopicRegistry;
import com.anz.axle.lg.config.DuplicateSuppressingStatusHandler;
import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.publisher.BackPressureStrategy;
import com.anz.axle.lg.publisher.DefaultPublicationRegistry;
import com.anz.axle.lg.publisher.PublicationLookup;
import com.anz.axle.lg.publisher.Publisher;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
class PublisherConfig {

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new CustomizableThreadFactory("async-"));
    }

    @Bean
    public BackPressureStrategy backPressureStrategy() {
        return BackPressureStrategy.NOOP;
    }
    @Bean
    public TopicRegistry topicRegistry(@Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                       @Value("#{${symbol.venues.FXNDF}}") final Map<String, Set<Venue>> fxNdfSymbolVenues,
                                       @Value("#{${symbol.venues.FXFWD}}") final Map<String, Set<Venue>> fxFwdSymbolVenues) {
        return new DefaultTopicRegistry();
    }

    @Bean
    public DefaultPublicationRegistry publicationRegistry(final ScheduledExecutorService scheduledExecutorService,
                                                          final Connection connection,
                                                          final BackPressureStrategy backPressureStrategy) {
        final LoggingStatusHandler loggingStatusHandler = new LoggingStatusHandler(LoggerFactory.getLogger(DefaultPublicationRegistry.class));
        final DuplicateSuppressingStatusHandler duplicateSuppressingStatusHandler = new DuplicateSuppressingStatusHandler(loggingStatusHandler);
        scheduledExecutorService.schedule(() -> duplicateSuppressingStatusHandler.flushSuppressedRepetitions(false), 10, TimeUnit.SECONDS);
        return new DefaultPublicationRegistry(connection, duplicateSuppressingStatusHandler, backPressureStrategy);
    }

    @Bean
    Publisher publisher(final PublicationLookup publicationLookup) {
        return new Publisher(publicationLookup);
    }
}
