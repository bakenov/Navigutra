package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.config.StartAtSeeker;
import com.anz.markets.prophet.domain.chronicle.Header;
import net.openhft.chronicle.Excerpt;

import java.util.function.ToLongFunction;

public class LegacyChronicleStartAtSeeker implements StartAtSeeker {

    private final Excerpt excerpt;

    // NOTE: Depending on the StartAt type, the config start position could be a queue INDEX, or any attribute of Header
    private final long configStartPosition;

    LegacyChronicleStartAtSeeker(final Excerpt excerpt, final long startConfig) {
        this.excerpt = excerpt;
        this.configStartPosition = startConfig;
    }

    @Override
    public void firstIndex() {
        excerpt.toStart();
    }

    @Override
    public void lastIndex() {
        excerpt.toEnd();
    }

    @Override
    public void configIndex() {
        verifyIndex(configStartPosition);
    }

    @Override
    public void findIndex(final ToLongFunction<Header> headerToLongFunction, final boolean exactMatch) {
        if (configStartPosition <= 0) {
            verifyIndex(configStartPosition);
            return;
        }

        final Header header = new Header();
        long matchIndex = -1L;
        try {
            final ProphetBytes prophetBytes = LegacyChronicleWrappers.wrap(excerpt);
            matchIndex = excerpt.findMatch(e -> {
                ChronicleObjectReader.readHeader(prophetBytes, header);
                final long eventId = headerToLongFunction.applyAsLong(header);
                return Long.compare(eventId, configStartPosition);
            });
            if (matchIndex < 0L) {
                if (exactMatch) {
                    throw new SeekException("Could not seek to exact match", configStartPosition);
                } else {
                    // handle nearest match
                    matchIndex = -(matchIndex + 2L);
                }
            } else {
                if (headerToLongFunction.applyAsLong(header) != configStartPosition) {
                    throw new SeekException("Lying about exact match", configStartPosition);
                }
                // exact match. As there can be >1 rows with the same eventId, wind back to the first
                while (headerToLongFunction.applyAsLong(header) == configStartPosition && excerpt.index(--matchIndex)) {
                    ChronicleObjectReader.readHeader(prophetBytes, header);
                }
                ++matchIndex;
            }
            verifyIndex(matchIndex);
        } catch (ArrayIndexOutOfBoundsException a) {
            throw new SeekException(a.getMessage() + " for index " + matchIndex, configStartPosition);
        }
    }

    private void verifyIndex(final long index) {
        if (index <= 0) { // No need to verify
            return;
        }
        final boolean ok = excerpt.index(index);
        if (!ok) {
            throw new SeekException("Cannot seek by index", index);
        }
    }
}
