package com.anz.markets.prophet.atest.pricing._10_generic;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.BenchmarkSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.StandardMarketSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.BenchmarkSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class PreciousMetalsTest extends BaseAcceptanceSpecification {

    @Test
    // AXPROPHET-1089
    public void precious_metals_gold_client_price() throws Exception {

        final Instrument driverPairA = Instrument.XAUUSD;

        given:
        {
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 1.0))  // set high Overall-skew threshold
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setInstrument(Instrument.ANY),
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1k|2k|2k|5k|5k|5k|10k|10k|10k").setSkewed(true).setInstrument(driverPairA),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                            ));

            final List<ClientSpreadConfig> clientSpreadConfigs = new ArrayList<>(configurationDataDefault.getClientSpreadConfigs());
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15K.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20K.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30K.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40K.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50K.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_1K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_1K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_Z, driverPairA, Level.QTY_1K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3));
            configurationDataDefault.setClientSpreadConfigs(clientSpreadConfigs);

            final List<BenchmarkSpreadConfig> benchSpreadConfigs = new ArrayList<>(configurationDataDefault.getBenchmarkSpreadConfigs());
            benchSpreadConfigs.add(new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, driverPairA, FactorWindow.CAT_A)
                    .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                    .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)));
            configurationDataDefault.setBenchmarkSpreadConfigs(benchSpreadConfigs);

            final List<InstrumentConfig> instrumentConfigs = new ArrayList<>(configurationDataDefault.getInstrumentConfigs());
            instrumentConfigs.add(new InstrumentConfigImpl(driverPairA).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(0).setPrecisionMultiplier(1).setSpreadMultiplier(0));
            configurationDataDefault.setInstrumentConfigs(instrumentConfigs);

            final List<MarketConfig> marketConfigs = new ArrayList<>(configurationDataDefault.getMarketConfigs());
            marketConfigs.add(new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.XAUUSD).setEnabled(true));
            configurationDataDefault.setMarketConfigs(marketConfigs);
            configurationDataDefault.addAggBook(Market.WSP_U, Instrument.XAUUSD, TradingTimeZone.GLOBAL, Region.GB, Market.CNX);
            configurationDataDefault.addAggBook(Market.WSP_R, Instrument.XAUUSD, TradingTimeZone.GLOBAL, Region.GB, Market.CNX);

            final List<StandardMarketSpreadConfig> stdMarketSpreads = new ArrayList<>(configurationDataDefault.getStandardMarketSpreadConfigs());
            stdMarketSpreads.add(new StandardMarketSpreadConfigImpl(driverPairA, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0));
            configurationDataDefault.setStandardMarketSpreadConfigs(stdMarketSpreads);

            final List<ClientPriceThrottleConfig> throttleConfigs = new ArrayList<>(configurationDataDefault.getClientPriceThrottleConfigs());
            throttleConfigs.add(new ClientPriceThrottleConfigImpl(Market.ANY, Currency.XAU, Currency.USD).setNoActivityHeartbeatFrequencyMs(20000).
                    setStartStopTimePeriodMS(0).
                    setLimit(1).
                    setTimePeriod(1).
                    setMinimumPriceDeltaFractionOfSpread(0.01).
                    setOverrideLimit(1).
                    setOverrideTimePeriod(1).
                    setOverrideMinimumPriceDeltaFractionOfMid(0.000001).
                    setMinimumPriceDeltaFractionOfPreviousSpread(0.001));
            configurationDataDefault.setClientPriceThrottleConfigs(throttleConfigs);

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.0004));
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -5_000_000, 0.75101));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, driverPairA, 1316.65, 2_000, 1316.95, 2_000));
        }
        then:
        // no XAU MaxSkewQuantities config and no XAUUSD OptimalPositionConfigs -> NO mid skewing
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1K, 1316.79850, 1316.80150));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2K, 1316.79700, 1316.80300));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2K, 1316.79625, 1316.80375));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5K, 1316.79500, 1316.80500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5K, 1316.78700, 1316.81300));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5K, 1316.78100, 1316.81900));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10K, 1316.77200, 1316.82800));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10K, 1316.76800, 1316.83200));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10K, 1316.75500, 1316.84500));
        }
    }
}
