package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import anz.markets.messaging.endpoint.intf.DataSink;
import anz.markets.messaging.endpoint.intf.DataSource;
import anz.markets.messaging.types.PDMessage;

import com.anz.axle.common.AbstractUnitTest;
import org.jmock.Expectations;
import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

/**
 * Created by talwarg on 18/02/2015.
 */
public class DOMNodeToTradeModelCoverterPipeTest extends AbstractUnitTest {

    private DOMNodeToTradeModelConverterPipe domNodeToTradeModelConverterPipe;

    private final ThreadLocal<DocumentBuilder> builder = new ThreadLocal<DocumentBuilder>() {
        @Override
        protected DocumentBuilder initialValue() {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            try {
                return dbf.newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                return null;
            }
        }
    };

    @Before
    public void setUp(){
        domNodeToTradeModelConverterPipe = new DOMNodeToTradeModelConverterPipe();
    }

    @Test
    public void testOnMessage() throws IOException, SAXException {
        final DataSink<TradeMessageWrapperType> dataSink = mock(DataSink.class);
        String xml = "<tradeMessage> </tradeMessage>";
        checking(new Expectations() {
        {
            try {
                oneOf(dataSink).setSource(with(any(DataSource.class)));

                oneOf(dataSink).onMessage(with(any(PDMessage.class)));
                will(returnValue(true));
            } catch (Exception e) {

            }
        }
        });
        domNodeToTradeModelConverterPipe.setSink(dataSink);
        domNodeToTradeModelConverterPipe.onMessage(new PDMessage<Node>("1", getDocument(xml)));
    }

    @Test (expected = SAXParseException.class)
    public void testOnMessageWithException() throws IOException, SAXException {
        final DataSink<TradeMessageWrapperType> dataSink = mock(DataSink.class);
        String xml = "<tradeMessage>";
        checking(new Expectations() {
            {
                try {
                    oneOf(dataSink).setSource(with(any(DataSource.class)));
                } catch (Exception e) {

                }
            }
        });
        domNodeToTradeModelConverterPipe.setSink(dataSink);
        domNodeToTradeModelConverterPipe.onMessage(new PDMessage<Node>("1", getDocument(xml)));
    }

    private Document getDocument(String xml) throws IOException, SAXException {
        BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(xml.getBytes("UTF-8")));
        DocumentBuilder dbuilder = builder.get();
        if (dbuilder != null) {

            return dbuilder.parse(bis);
        }
        return null;
    }
}
