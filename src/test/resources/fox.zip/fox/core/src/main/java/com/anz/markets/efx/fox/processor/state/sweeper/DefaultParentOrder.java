package com.anz.markets.efx.fox.processor.state.sweeper;

import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderDetails;
import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.processor.state.ChildExecutionReportLinkedToParentOrderPublisher;
import com.anz.markets.efx.fox.processor.state.ChildOrderCancelRejectLinkedToParentOrderPublisher;
import com.anz.markets.efx.fox.processor.state.MutableParentOrderDetails;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public class DefaultParentOrder implements ParentOrder {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultParentOrder.class);

    public static final String STRATEGY_NAME = "Sweeper";

    private final ParentOrder notInitialisedParentOrderState = new NotInitialisedParentOrderState();
    private final ParentOrder workingParentOrderState = new WorkingParentOrderState();
    private final ParentOrder pendingCancelParentOrderState = new PendingCancelParentOrderState();
    private final ParentOrder deadParentOrderState = new DeadParentOrderState();
    private final MutableParentOrderDetails parentOrderDetails = new MutableParentOrderDetails();

    private final ByteValueCache<Venue> venueCache = new ByteValueCache<>(asciiString -> Venue.valueOf(asciiString.toString()));
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> currencyCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> compIdCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> stringsCache = new ByteValueCache<>(AsciiString::toString);

    private final Consumer<DefaultParentOrder> releaser;
    private final InstrumentRepository instrumentRepository;
    private final List<ChildOrder> childOrders = new ArrayList<>(100);

    private final DefaultStrategyParameters parameters = new DefaultStrategyParameters();

    public DefaultParentOrder(final Consumer<DefaultParentOrder> releaser,
                              final InstrumentRepository instrumentRepository) {
        this.releaser = Objects.requireNonNull(releaser);
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
    }

    private ParentOrder orderState = notInitialisedParentOrderState;
    
    private void resetAndRelease() {
        releaser.accept(this);
        this.orderState = notInitialisedParentOrderState;
        this.parentOrderDetails.reset();
        releaseChildOrders();
    }

    private void releaseChildOrders() {
        for (int i = 0; i < childOrders.size(); i++) {
            final ChildOrder childOrder = childOrders.get(i);
            childOrders.remove(childOrder);
            childOrder.release();
        }
    }

    @Override
    public ParentOrderDetails details() {
        return parentOrderDetails;
    }

    @Override
    public void onStart(final CommandContext commandContext) {
        orderState.onStart(commandContext);
    }

    @Override
    public void applyNewChildOrder(final ChildOrder childOrder) {
        orderState.applyNewChildOrder(childOrder);
    }

    @Override
    public void onChildExecutionReport(final CommandContext commandContext, final ExecutionReportDecoder executionReportDecoder) {
        orderState.onChildExecutionReport(commandContext, executionReportDecoder);
    }

    @Override
    public void onChildOrderCancelReject(final CommandContext commandContext, final OrderCancelRejectDecoder orderCancelRejectDecoder) {
        orderState.onChildOrderCancelReject(commandContext, orderCancelRejectDecoder);
    }

    @Override
    public void applyChildExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
        orderState.applyChildExecutionReport(executionReportDecoder);
    }

    @Override
    public void applyChildOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
        orderState.applyChildOrderCancelReject(orderCancelRejectDecoder);
    }

    @Override
    public void applyParentExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
        orderState.applyParentExecutionReport(eventContext, executionReportDecoder);
    }

    @Override
    public void onPriceUpdate(final CommandContext commandContext) {
        orderState.onPriceUpdate(commandContext);
    }

    @Override
    public void onParentOrderCancelRequest(final CommandContext commandContext, final OrderCancelRequestDecoder orderCancelRequestDecoder) {
        orderState.onParentOrderCancelRequest(commandContext, orderCancelRequestDecoder);
    }

    @Override
    public void release() {
        orderState.release();
    }

    private void addChildOrderAndUpdateWorkingQty(final ChildOrder childOrder) {
        childOrders.add(childOrder);
        parentOrderDetails
                .atMarketQty(parentOrderDetails.atMarketQty() + childOrder.details().orderQty())
                .toExecuteQty(parentOrderDetails.orderQty() - parentOrderDetails.atMarketQty());
    }

    private void updateBalanceFromChildExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
        final ExecutionReportDecoder.Body body = executionReportDecoder.body();
        parentOrderDetails
                .atMarketQty(parentOrderDetails.atMarketQty() -
                    (body.orderQty() - body.cumQty() + body.lastQty()) +
                    body.leavesQty())
        .cumQty(parentOrderDetails.cumQty() + body.lastQty())
        .leavesQty(parentOrderDetails.orderQty() - parentOrderDetails.cumQty())
        .lastQty(body.lastQty())
        .lastUsdQty(body.lastUsdQty())
        .lastPx(body.lastPx())
        .commissionAdjLastPx(body.commissionAdjLastPx())
        .midPx(body.midPx())
        .lastSpotRate(body.lastSpotRate())
        .lastForwardPoints(body.lastForwardPoints())
        .avgPx((parentOrderDetails.avgPx() + body.lastPx())/2)
        .commissionAdjAvgPx((parentOrderDetails.commissionAdjAvgPx() + body.commissionAdjLastPx())/2)
        .commission(parentOrderDetails.commission() + body.commissionAdjLastPx())
        .toExecuteQty(parentOrderDetails.orderQty() - parentOrderDetails.atMarketQty() - parentOrderDetails.cumQty());
    }

    private void sendOrderCancelReject(final CommandContext commandContext,
                                       final OrderCancelRejectReason rejectReason,
                                       final OrderCancelRequestDecoder orderCancelRequestDecoder) {
        final long sourceSeq = commandContext.idGenerator().getAsLong();
        commandContext.tradingEncoderSupplier().orderCancelReject().messageStart(commandContext.source(), sourceSeq)
                .senderCompId().encode(commandContext.senderCompId())
                .targetCompId().encode(parentOrderDetails.senderCompId())
                .messageId(sourceSeq)
                .marketId().encode(parentOrderDetails.venue().name())
                .clOrdId().encodeFrom(orderCancelRequestDecoder.body().clOrdId())
                .origClOrdId().encodeLong(parentOrderDetails.origClOrdId())
                .clOrdLinkId().encodeLong(parentOrderDetails.clOrdLinkId())
                .orderId().encodeLong(parentOrderDetails.orderId())
                .transactTime(commandContext.precisionClock().nanos())
                .cxlRejResponseTo(OrderCancelRequestType.ORDER_CANCEL_REQUEST)
                .cxlRejReason(rejectReason)
                .partiesEmpty()
                .hopsEmpty()
                .text().encodeEmpty()
                .messageComplete();
    }

    private void sendExecutionReport(final CommandContext commandContext,
                                     final ExecType execType,
                                     final OrderStatus orderStatus,
                                     final long clOrdId,
                                     final String text) {
        final long sourceSeq = commandContext.idGenerator().getAsLong();
        commandContext.tradingEncoderSupplier().executionReport()
                .messageStart(commandContext.source(), sourceSeq)
                .senderCompId().encode(commandContext.senderCompId())
                .targetCompId().encode(parentOrderDetails.senderCompId())
                .messageId(sourceSeq)
                .orderId().encodeLong(parentOrderDetails.orderId())
                .clOrdId().encodeLong(clOrdId)
                .origClOrdId().encodeLong(parentOrderDetails.origClOrdId())
                .clOrdLinkId().encodeLong(parentOrderDetails.clOrdLinkId())
                .marketId().encode(parentOrderDetails.venue().name())
                .execId().encodeLong(commandContext.idGenerator().getAsLong())
                .execType(execType)
                .ordStatus(orderStatus)
                .symbol().encode(parentOrderDetails.instrument().key().symbol())
                .securityType(parentOrderDetails.instrument().key().securityType())
                .settlType(parentOrderDetails.instrument().key().tenor())
                .orderQty(parentOrderDetails.orderQty())
                .ordType(parentOrderDetails.orderType())
                .targetStrategyName().encode(parentOrderDetails.strategyName())
                .price(parentOrderDetails.price())
                .side(parentOrderDetails.side())
                .currency().encode(parentOrderDetails.currency())
                .timeInForce(parentOrderDetails.timeInForce())
                .transactTime(commandContext.precisionClock().nanos())
                .tradeDate().encodeEpochMillis(parentOrderDetails.tradeDateMillis())
                .settlDate().encodeEpochMillis(parentOrderDetails.settleDateMillis())
                .settlCurrency().encode(parentOrderDetails.currency())
                .lastQty(parentOrderDetails.lastQty())
                .lastUsdQty(parentOrderDetails.lastUsdQty())
                .lastPx(parentOrderDetails.lastPx())
                .leavesQty(parentOrderDetails.leavesQty())
                .lastSpotRate(parentOrderDetails.lastSpotRate())
                .cumQty(parentOrderDetails.cumQty())
                .avgPx(parentOrderDetails.avgPx())
                .commission(parentOrderDetails.commission())
                .partiesEmpty()
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsEmpty()
                .quoteId().encodeEmpty()
                .rejectText().encodeNullable(text)
                .messageComplete();
    }

    private String getCancelReason(final OrderCancelRequestDecoder parentOrderCancelRequestDecoder) {
        parentOrderCancelRequestDecoder.body();
        final String cancelReason = parentOrderCancelRequestDecoder.trailer().text().decodeAndCache(stringsCache);
        return (cancelReason == null || cancelReason.isEmpty()) ? OrderTextMessage.CANCEL_REQUESTED_BY_USER.getText() : cancelReason;
    }

    private String getCancelReason(final ExecutionReportDecoder executionReportDecoder) {
        executionReportDecoder.body();
        final String cancelReason = executionReportDecoder.trailer().rejectText().decodeAndCache(stringsCache);
        return (cancelReason == null || cancelReason.isEmpty()) ? OrderTextMessage.CANCEL_REQUESTED_BY_USER.getText() : cancelReason;
    }

    private void publishChildExecutionReportLinkedToParentOrder(final TradingEncoderSupplier encoderSupplier, final ExecutionReportDecoder executionReportDecoder) {
        ChildExecutionReportLinkedToParentOrderPublisher.publish(encoderSupplier, executionReportDecoder, details());
    }

    private void publishChildOrderCancelRejectLinkedToParentOrder(final TradingEncoderSupplier encoderSupplier, final OrderCancelRejectDecoder orderCancelRejectDecoder) {
        ChildOrderCancelRejectLinkedToParentOrderPublisher.publish(encoderSupplier, orderCancelRejectDecoder, details());
    }

    class NotInitialisedParentOrderState implements ParentOrder {
        @Override
        public void applyParentExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
            final long orderId = executionReportDecoder.body().orderId().decodeLongOrZero();
            final long clOrdId = executionReportDecoder.body().clOrdId().decodeLongOrZero();
            final long instrumentId = InstrumentKey.instrumentId(executionReportDecoder.body().symbol().decodeAndCache(symbolCache),
                    executionReportDecoder.body().securityType(),
                    executionReportDecoder.body().settlType());
            final Instrument instrument = instrumentRepository.lookup(instrumentId);

            parentOrderDetails.orderId(orderId)
            .origClOrdId(clOrdId)
            .clOrdId(clOrdId)
            .clOrdLinkId(executionReportDecoder.body().clOrdLinkId().decodeLongOrZero())
            .venue(executionReportDecoder.body().marketId().decodeAndCache(venueCache))
            .orderStatus(OrderStatus.NEW)
            .strategyName(STRATEGY_NAME)
            .instrument(instrument)
            .timeInForce(executionReportDecoder.body().timeInForce())
            .orderType(executionReportDecoder.body().ordType())
            .currency(executionReportDecoder.body().currency().decodeAndCache(currencyCache))
            .settlCurrency(executionReportDecoder.body().settlCurrency().decodeAndCache(currencyCache))
            .side(executionReportDecoder.body().side())
            .price(executionReportDecoder.body().price())
            .orderQty(executionReportDecoder.body().orderQty())
            .senderCompId(executionReportDecoder.body().targetCompId().decodeAndCache(compIdCache))
            .tradeDateMillis(eventContext.precisionClock().millis())
            .settleDateMillis(executionReportDecoder.body().settlDate().decodeEpochMillis())
            .transactTimeNanos(executionReportDecoder.body().transactTime())
            .leavesQty(executionReportDecoder.body().orderQty())
            .toExecuteQty(executionReportDecoder.body().orderQty());

            ExecutionReportDecoder.Party parties = executionReportDecoder.parties();
            for (ExecutionReportDecoder.Party party : parties) {
                final PartyRole partyRole = party.partyRole();
                final String partyId = party.partyId().decodeAndCache(stringsCache);
                switch (partyRole) {
                    case USER_NAME: parentOrderDetails.userName(partyId); break;
                    case PORTFOLIO: parentOrderDetails.portfolio(partyId); break;
                    case SOURCE_REGION: parentOrderDetails.sourceRegion(Region.valueOf(partyId)); break;
                    case TARGET_REGION: parentOrderDetails.targetRegion(Region.valueOf(partyId)); break;
                }
                parentOrderDetails.addPartyRole(partyRole, partyId);
            }

            parameters.init(executionReportDecoder);

            orderState = workingParentOrderState;
        }

        @Override
        public ParentOrderDetails details() {
            return parentOrderDetails;
        }

        @Override
        public void onStart(final CommandContext commandContext) {
            LOGGER.error("Can't execute not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't execute not initialised order");
        }

        @Override
        public void applyNewChildOrder(final ChildOrder childOrder) {
            LOGGER.error("Can't add child order to not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't add child order to not initialised order");
        }

        @Override
        public void onChildExecutionReport(final CommandContext commandContext, final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.error("Can't handle child execution report in not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't update not initialised order");
        }

        @Override
        public void onChildOrderCancelReject(final CommandContext commandContext, final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.error("Can't handle child order cancel reject in not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't update not initialised order");
        }

        @Override
        public void applyChildExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.error("Can't update not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't update not initialised order");
        }

        @Override
        public void applyChildOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.error("Can't update not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't update not initialised order");
        }

        @Override
        public void onPriceUpdate(final CommandContext commandContext) {
            LOGGER.error("Can't execute not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't execute not initialised order");
        }

        @Override
        public void onParentOrderCancelRequest(final CommandContext commandContext, final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            LOGGER.error("Can't request cancel not initialised order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't request cancel not initialised order");
        }

        @Override
        public void release() {
            resetAndRelease();
        }
    }

    class WorkingParentOrderState implements ParentOrder {
        @Override
        public ParentOrderDetails details() {
            return parentOrderDetails;
        }

        @Override
        public void onStart(final CommandContext commandContext) {
            onPriceUpdate(commandContext);
        }

        @Override
        public void applyNewChildOrder(final ChildOrder childOrder) {
            addChildOrderAndUpdateWorkingQty(childOrder);
        }

        @Override
        public void onChildExecutionReport(final CommandContext commandContext, final ExecutionReportDecoder executionReportDecoder) {
            publishChildExecutionReportLinkedToParentOrder(commandContext.tradingEncoderSupplier(), executionReportDecoder);

            if (executionReportDecoder.body().lastQty() > 0) {
                sendExecutionReport(commandContext, ExecType.TRADE, parentOrderDetails.leavesQty() <= 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED, parentOrderDetails.clOrdId(), OrderTextMessage.EMPTY.getText());
            }
            onPriceUpdate(commandContext);
        }

        @Override
        public void onChildOrderCancelReject(final CommandContext commandContext, final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            publishChildOrderCancelRejectLinkedToParentOrder(commandContext.tradingEncoderSupplier(), orderCancelRejectDecoder);

            onPriceUpdate(commandContext);
        }

        @Override
        public void applyChildExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            updateBalanceFromChildExecutionReport(executionReportDecoder);
        }

        @Override
        public void applyChildOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            if(orderCancelRejectDecoder.body().ordStatus() == OrderStatus.REJECTED &&
               orderCancelRejectDecoder.body().cxlRejReason() == OrderCancelRejectReason.UNKNOWN_ORDER) {
                final double childOrderQty = 0; //FIXME get childOrderQty from child order by orderCancelRejectDecoder.body().clOrdId();

                parentOrderDetails
                        .atMarketQty(parentOrderDetails.atMarketQty() - childOrderQty)
                        .leavesQty(parentOrderDetails.orderQty() - parentOrderDetails.cumQty())
                        .toExecuteQty(parentOrderDetails.orderQty() - parentOrderDetails.atMarketQty() - parentOrderDetails.cumQty());
            }
        }

        @Override
        public void applyParentExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
            final OrderStatus orderStatus = executionReportDecoder.body().ordStatus();
            parentOrderDetails.clOrdId(executionReportDecoder.body().clOrdId().decodeLongOrZero());

            switch (orderStatus) {
                case PENDING_CANCEL:
                    parentOrderDetails.cancelReason(getCancelReason(executionReportDecoder));
                    orderState = pendingCancelParentOrderState;
                    break;
                case CANCELED:
                case FILLED:
                    orderState = deadParentOrderState;
                    break;
            }
        }

        @Override
        public void onPriceUpdate(final CommandContext commandContext) {
            if (parentOrderDetails.toExecuteQty() > 0 && !parameters.markets().isEmpty()) {
                final long sourceSeq = commandContext.idGenerator().getAsLong();
                commandContext.tradingEncoderSupplier().newOrderSingle()
                        .messageStart(commandContext.source(), sourceSeq)
                        .senderCompId().encode(commandContext.senderCompId())
                        .messageId(sourceSeq)
                        .marketId().encode(parameters.markets().get(0).name())
                        .clOrdId().encodeLong(commandContext.idGenerator().getAsLong())
                        .clOrdLinkId().encodeLong(parentOrderDetails.orderId())
                        .symbol().encode(parentOrderDetails.instrument().key().symbol())
                        .securityType(parentOrderDetails.instrument().key().securityType())
                        .settlType(parentOrderDetails.instrument().key().tenor())
                        .orderQty(parentOrderDetails.toExecuteQty())
                        .ordType(parentOrderDetails.orderType())
                        .targetStrategyName().encode("VENUE")
                        .price(parentOrderDetails.price())
                        .side(parentOrderDetails.side())
                        .currency().encode(parentOrderDetails.currency())
                        .timeInForce(parentOrderDetails.timeInForce())
                        .transactTime(commandContext.precisionClock().nanos())
                        .settlDate().encodeEpochMillis(parentOrderDetails.settleDateMillis())
                        .settlCurrency().encode(parentOrderDetails.settlCurrency())
                        .partiesEmpty()
                        .strategyParametersEmpty()
                        .regulatoryTradeIdsEmpty()
                        .hopsEmpty()
                        .quoteId().encodeEmpty()
                        .messageComplete();
            }
        }

        @Override
        public void onParentOrderCancelRequest(final CommandContext commandContext, final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            for (int idx = 0; idx < childOrders.size(); idx++) {
                final ChildOrder childOrder = childOrders.get(idx);
                childOrder.requestCancel(commandContext, orderCancelRequestDecoder);
            }

            sendExecutionReport(commandContext, ExecType.PENDING_CANCEL, OrderStatus.PENDING_CANCEL,
                    orderCancelRequestDecoder.body().clOrdId().decodeLongOrZero(), getCancelReason(orderCancelRequestDecoder));
        }

        @Override
        public void release() {
            LOGGER.error("Can't release working order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't release working order");
        }
    }

    class PendingCancelParentOrderState implements ParentOrder {
        @Override
        public ParentOrderDetails details() {
            return parentOrderDetails;
        }

        @Override
        public void onStart(final CommandContext commandContext) {
            LOGGER.error("Can't start order in pending cancel state. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't start order in pending cancel state");
        }

        @Override
        public void applyNewChildOrder(final ChildOrder childOrder) {
            LOGGER.error("Can't add child order to pending cancel order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't add child order to pending cancel order");
        }

        @Override
        public void onChildExecutionReport(final CommandContext commandContext, final ExecutionReportDecoder executionReportDecoder) {
            publishChildExecutionReportLinkedToParentOrder(commandContext.tradingEncoderSupplier(), executionReportDecoder);

            if (parentOrderDetails.atMarketQty() == 0) {
                if (parentOrderDetails.cumQty() >= parentOrderDetails.orderQty()) {
                    sendExecutionReport(commandContext, ExecType.TRADE, OrderStatus.FILLED, parentOrderDetails.origClOrdId(), OrderTextMessage.FILLED_WHILE_BEING_CANCELED.getText());
                } else {
                    sendExecutionReport(commandContext, ExecType.CANCELED, OrderStatus.CANCELED, parentOrderDetails.clOrdId(), parentOrderDetails.cancelReason());
                }
            } else {
                if (executionReportDecoder.body().execType() == ExecType.TRADE && executionReportDecoder.body().lastQty() > 0) {
                    sendExecutionReport(commandContext, ExecType.TRADE, OrderStatus.PENDING_CANCEL, parentOrderDetails.origClOrdId(), OrderTextMessage.FILLED_WHILE_BEING_CANCELED.getText());
                }
            }
        }

        @Override
        public void onChildOrderCancelReject(final CommandContext commandContext, final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            publishChildOrderCancelRejectLinkedToParentOrder(commandContext.tradingEncoderSupplier(), orderCancelRejectDecoder);
            parentOrderDetails.cancelReason(OrderTextMessage.EMPTY.getText());
        }

        @Override
        public void applyChildExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            updateBalanceFromChildExecutionReport(executionReportDecoder);
            if (parentOrderDetails.atMarketQty() == 0) {//all child orders are dead
                parentOrderDetails
                        .leavesQty(0)
                        .toExecuteQty(0);
            }
        }

        @Override
        public void applyChildOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            if(orderCancelRejectDecoder.body().ordStatus() == OrderStatus.REJECTED &&
               orderCancelRejectDecoder.body().cxlRejReason() == OrderCancelRejectReason.UNKNOWN_ORDER) {
                final double childOrderQty = 0; //FIXME get childOrderQty from child order by orderCancelRejectDecoder.body().clOrdId();

                parentOrderDetails
                        .atMarketQty(parentOrderDetails.atMarketQty() - childOrderQty)
                        .leavesQty(parentOrderDetails.orderQty() - parentOrderDetails.cumQty())
                        .toExecuteQty(parentOrderDetails.orderQty() - parentOrderDetails.atMarketQty() - parentOrderDetails.cumQty());
            }
        }

        @Override
        public void applyParentExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
            final OrderStatus orderStatus = executionReportDecoder.body().ordStatus();

            switch (orderStatus) {
                case CANCELED:
                case FILLED:
                    parentOrderDetails
                            .orderStatus(orderStatus)
                            .clOrdId(executionReportDecoder.body().clOrdId().decodeLongOrZero());

                    orderState = deadParentOrderState;
                    break;
            }
        }

        @Override
        public void onPriceUpdate(final CommandContext commandContext) {
            //no op
        }

        @Override
        public void onParentOrderCancelRequest(final CommandContext commandContext, final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            sendOrderCancelReject(commandContext, OrderCancelRejectReason.ORDER_ALREADY_IN_PENDING_STATUS, orderCancelRequestDecoder);
        }

        @Override
        public void release() {
            LOGGER.error("Can't release pending cancel order. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't release pending cancel order");
        }
    }

    class DeadParentOrderState implements ParentOrder {
        @Override
        public ParentOrderDetails details() {
            return parentOrderDetails;
        }

        @Override
        public void onStart(final CommandContext commandContext) {
            LOGGER.error("Can't start order in dead state. orderId {}", parentOrderDetails.orderId());
            throw new IllegalStateException("Can't start order in dead state");
        }

        @Override
        public void applyNewChildOrder(final ChildOrder childOrder) {
            LOGGER.warn("Can't add child order to dead order. orderId {}, {}", parentOrderDetails.orderId(), childOrder);
        }

        @Override
        public void onChildExecutionReport(final CommandContext commandContext, final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.error("Can't update dead order. orderId {}", parentOrderDetails.orderId());
        }

        @Override
        public void onChildOrderCancelReject(final CommandContext commandContext, final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.error("Can't update dead order. orderId {}", parentOrderDetails.orderId());
        }

        @Override
        public void applyChildExecutionReport(final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.error("Can't update dead order. orderId {}", parentOrderDetails.orderId());
        }

        @Override
        public void applyChildOrderCancelReject(final OrderCancelRejectDecoder orderCancelRejectDecoder) {
            LOGGER.error("Can't update dead order. orderId {}", parentOrderDetails.orderId());

        }

        @Override
        public void applyParentExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
            LOGGER.warn("The order is already dead. orderId {}", parentOrderDetails.orderId());
        }

        @Override
        public void onPriceUpdate(final CommandContext commandContext) {
            //no op
        }

        @Override
        public void onParentOrderCancelRequest(final CommandContext commandContext, final OrderCancelRequestDecoder orderCancelRequestDecoder) {
            sendOrderCancelReject(commandContext, OrderCancelRejectReason.TOO_LATE_TO_CANCEL, orderCancelRequestDecoder);
        }

        @Override
        public void release() {
            resetAndRelease();
        }
    }
}
