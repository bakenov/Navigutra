package com.anz.markets.prophet.config.business.domain.tabular;


import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.general.KeyValueConfig;
import com.anz.markets.prophet.config.business.domain.tabular.general.OperatingHourConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveNewsHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByMonitorHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByPositionHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTakeProfitHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTwapHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgeFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgePortfolioConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.MidHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.PassiveHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.SlidingWindowDealVolumeConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.FilterEnabledConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MITRConfigList;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.OptimalPositionConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PassthroughSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierClippingConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceSpikeFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.RiskAdjustedFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolatilityWideningConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolatilityWideningPercentileConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolumeSkewConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.PricingModel;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.adjustment.AdjustAggregatedConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LatencyFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LiquidityFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.MinimumMarketFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.StaleFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.firewall.PricingArbitrageFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.DriverMarketChooserConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.StandardMarketSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.skew.NetOpenPositionSkewRatioConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.BenchmarkSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.DiscoTightenByConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsItemConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWideningConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.MarketGapFactorConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.MarketGapToWideningFactorConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.MarketWideningFactorToDecayPeriodConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.config.business.domain.tabular.risk.NetOpenPositionLimitConfig;

import java.util.List;

/**
 * Config data is designed to be mappable to basic tabular/tuple structure.
 * Most config items should be a list/tuple of config data type. The config data type (e.g., MarketConfig) should be
 * simple flat structure - e.g., a pojo of primitives and Enums so that they can be mapped to csv/kdb table.
 */
public interface ConfigurationData {

    List<KeyValueConfig> getKeyValueConfigs();

    List<MarketConfig> getMarketConfigs();

    List<LatencyFilterConfig> getLatencyFilterConfigs();

    List<StaleFilterConfig> getStaleFilterConfigs();

    List<LiquidityFilterConfig> getLiquidityFilterConfigs();

    List<StandardMarketSpreadConfig> getStandardMarketSpreadConfigs();

    List<InstrumentConfig> getInstrumentConfigs();

    List<ClientSpreadConfig> getClientSpreadConfigs();

    List<DiscoTightenByConfig> getDiscoTightenByConfigs();

    List<ClientPriceThrottleConfig> getClientPriceThrottleConfigs();

    List<BenchmarkSpreadConfig> getBenchmarkSpreadConfigs();

    List<PricingModel> getPricingModels();

    List<HedgePortfolioConfig> getHedgePortfolioConfigs();

    List<MidHedgerConfig> getMidHedgerConfigs();

    List<AggressiveNewsHedgerConfig> getAggressiveNewsHedgerConfigs();

    List<AggressiveTwapHedgerConfig> getAggressiveTwapHedgerConfigs();

    List<AggressiveTakeProfitHedgerConfig> getAggressiveTakeProfitHedgerConfigs();

    List<AggressiveSpeedUpByMonitorHedgerConfig> getAggressiveSpeedUpByMonitorHedgerConfigs();

    List<AggressiveSpeedUpByPositionHedgerConfig> getAggressiveSpeedUpByPositionHedgerConfigs();

    List<PassiveHedgerConfig> getPassiveHedgerConfigs();

    List<NetOpenPositionLimitConfig> getNetOpenPositionLimitConfigs();

    List<NetOpenPositionSkewRatioConfig> getNetOpenPositionSkewRatioConfigs();

    List<RealisedVolatilityConfig> getRealisedVolatilityConfigs();

    List<MarketGapToWideningFactorConfig> getMarketGapToWideningFactorConfigs();

    List<MarketWideningFactorToDecayPeriodConfig> getMarketWideningFactorToDecayPeriodConfigs();

    List<MarketGapFactorConfig> getMarketGapFactorConfigs();

    List<EconNewsItemConfig> getEconNewsItemConfigs();

    List<EconNewsWideningConfig> getEconNewsWideningConfigs();

    List<VolatilityWideningConfig> getVolatilityWideningConfigs();

    List<VolatilityWideningPercentileConfig> getVolatilityWideningPercentileConfigs();

    List<RiskAdjustedFactor> getRiskAdjustedSpreadParams();

    List<MaxSkewQuantities> getMaxSkewQuantities();

    List<PricingArbitrageFirewallConfig> getPricingArbitrageFirewallConfigs();

    List<PriceSpikeFirewallConfig> getPriceSpikeFirewallConfigs();

    List<PriceBarrierFirewallConfig> getPriceBarrierFirewallConfigs();

    List<PriceBarrierClippingConfig> getPriceBarrierClippingConfigs();

    List<FilterEnabledConfig> getFilterEnabledConfigs();

    List<SyntheticWideningFactor> getSyntheticWideningFactors();

    List<HedgeFirewallConfig> getHedgeFirewallConfigs();

    List<OptimalPositionConfig> getOptimalPositionConfigs();

    List<OperatingHourConfig> getOperatingHourConfigs();

    List<SlidingWindowDealVolumeConfig> getSlidingWindowDealVolumeConfigs();  // TODO: Not supported in prophet_json_config_loader.q

    List<AdjustAggregatedConfig> getAdjustAggregatedConfigs();  // TODO: Not supported in prophet_json_config_loader.q

    List<DriverMarketChooserConfig> getDriverMarketChooserConfigs();   // TODO: Not supported in prophet_json_config_loader.q

    List<SyntheticInstrumentConfig> getSyntheticInstrumentConfigs();

    MITRConfigList getPriceFormationPipelineConfigs();   // TODO: Not supported in prophet_json_config_loader.q

    List<VolumeSkewConfig> getVolumeSkewConfigs();

    List<PassthroughSpreadConfig> getPassthroughSpreadConfigs();

    List<MinimumMarketFilterConfig> getMinimumMarketsFilterConfigs();

    /**
     * Used to determine if a material change has occurred to a piece of child config
     */
    static boolean hasChanged(Object before,
                              Object after) {
        if (before == null && after != null) {
            return true;
        }
        if (before instanceof HasChanged) {
            return ((HasChanged<Object>) before).differs(after);
        }
        if (before instanceof List<?>) {
            List<HasChanged<Object>> beforeList = (List<HasChanged<Object>>) before,
                    afterList = (List<HasChanged<Object>>) after;
            if (beforeList.size() != afterList.size()) {
                return true;
            }
            for (int i = 0; i < beforeList.size(); i++) {
                if (beforeList.get(i).differs(afterList.get(i))) {
                    return true;
                }
            }
            return false;
        }
        throw new RuntimeException("Can't tell if this config has changed");
    }
}
