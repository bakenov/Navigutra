package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByMonitorHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpHedgerConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

public abstract class AggressiveSpeedUpHedgerConfigImpl implements AggressiveSpeedUpHedgerConfig, ProphetMarshallable {

    private Market market;
    private Instrument instrument;

    private double pnLThreshold = Double.NaN;
    private TradingTimeZone tradingTimeZone;
    private double maximumSpread;
    private double minimumOrderQuantity;
    private double minimumRisk;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public AggressiveSpeedUpHedgerConfigImpl() {
    }

    public AggressiveSpeedUpHedgerConfigImpl(final Market market, final Instrument instrument) {
        this.market = market;
        this.instrument = instrument;
    }

    @Override
    public Market getMarket() {
        return this.market;
    }

    @Override
    public Instrument getInstrument() {
        return this.instrument;
    }

    @Override
    public double getPnLThreshold() {
        return this.pnLThreshold;
    }

    @Override
    public TradingTimeZone getTradingTimeZone() {
        return this.tradingTimeZone;
    }

    @Override
    public double getMaximumSpread() {
        return this.maximumSpread;
    }

    @Override
    public double getMinimumOrderQuantity() {
        return this.minimumOrderQuantity;
    }

    @Override
    public double getMinimumRisk() {
        return this.minimumRisk;
    }

    public AggressiveSpeedUpHedgerConfigImpl setPnLThreshold(final double pnLThreshold) {
        this.pnLThreshold = pnLThreshold;
        return this;
    }

    public AggressiveSpeedUpHedgerConfigImpl setTradingTimeZone(final TradingTimeZone tradingTimeZone) {
        this.tradingTimeZone = tradingTimeZone;
        return this;
    }

    public AggressiveSpeedUpHedgerConfigImpl setMaximumSpread(final double maximumSpread) {
        this.maximumSpread = maximumSpread;
        return this;
    }

    public AggressiveSpeedUpHedgerConfigImpl setMinimumOrderQuantity(final double minimumOrderQuantity) {
        this.minimumOrderQuantity = minimumOrderQuantity;
        return this;
    }

    public AggressiveSpeedUpHedgerConfigImpl setMinimumRisk(final double minimumRisk) {
        this.minimumRisk = minimumRisk;
        return this;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        this.market = Market.valueOf(in.readByte());
        this.instrument = Instrument.readMarshallableValueOf(in);

        this.pnLThreshold = in.readDouble();
        this.tradingTimeZone = TradingTimeZone.valueOf(in.readByte());
        this.maximumSpread = in.readDouble();
        this.minimumOrderQuantity = in.readDouble();
        if (this instanceof AggressiveSpeedUpByMonitorHedgerConfig) {
            Context.context().header().since(MessageVersion.VERSION_0_53, () -> this.minimumRisk = in.readDouble());
        }
        else {
            this.minimumRisk = in.readDouble();
        }
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeByte(this.market.getValue());
        out.writeShort(this.instrument.getValue());

        out.writeDouble(this.pnLThreshold);
        out.writeByte(this.tradingTimeZone.getValue());
        out.writeDouble(this.maximumSpread);
        out.writeDouble(this.minimumOrderQuantity);
        out.writeDouble(this.minimumRisk);
    }
}
