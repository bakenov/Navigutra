package com.anz.markets.efx.ngaro.api;

import java.util.function.Consumer;
import java.util.stream.Stream;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TenorTest {
    @Test
    public void valueByOrdinal() {
        Stream.of(Tenor.values())
                .forEach(tenor ->
                        assertThat(Tenor.valueByOrdinal(tenor.ordinal())).isEqualTo(tenor)
                );
    }

    @Test
    public void forEach() {
        @SuppressWarnings({"unchecked", "rawType"})
        final Consumer<Tenor> consumer = mock(Consumer.class);
        Tenor.forEach(consumer);
        Stream.of(Tenor.values()).forEach(tenor -> verify(consumer).accept(tenor));
    }
}