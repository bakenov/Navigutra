package com.anz.markets.efx.fox.common.pricing;

import java.util.ArrayDeque;
import java.util.Objects;
import java.util.Queue;

import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.ngaro.api.InstrumentKey;

public class ScheduledPriceRefreshExecutionStep implements EventLoopStep {
    private static final boolean NO_FORCE_SNAPSHOT = false;

    private final Queue<InstrumentKey> requestQueue;
    private final Queue<RefreshHandler> scheduleQueue;
    private final Long2ObjectHashMap<RefreshHandler> instrumentRefreshHandlerMap = new Long2ObjectHashMap<>();

    private final PricingRefresher pricingRefresher;

    public ScheduledPriceRefreshExecutionStep(final Queue<InstrumentKey> requestQueue,
                                              final Queue<RefreshHandler> scheduleQueue,
                                              final PricingRefresher pricingRefresher) {
        this.requestQueue = Objects.requireNonNull(requestQueue);
        this.scheduleQueue = Objects.requireNonNull(scheduleQueue);
        this.pricingRefresher = Objects.requireNonNull(pricingRefresher);
    }

    public ScheduledPriceRefreshExecutionStep(final Queue<InstrumentKey> requestQueue,
                                              final int scheduleQueueSize,
                                              final PricingRefresher pricingRefresher) {
        this(requestQueue, new ArrayDeque<>(scheduleQueueSize), pricingRefresher);
    }

    @Override
    public boolean process() {
        return  pollScheduleQueue() | pollQueue();
    }

    private boolean pollQueue() {
        final InstrumentKey instrumentKey = requestQueue.poll();
        if (instrumentKey != null) {
            getOrCreate(instrumentKey).onRequest();
            return true;
        }
        return false;
    }

    private RefreshHandler getOrCreate(final InstrumentKey instrumentKey) {
        final long instrumentId = instrumentKey.instrumentId();
        RefreshHandler refreshHandler = instrumentRefreshHandlerMap.get(instrumentId);
        if (refreshHandler == null) {
            refreshHandler = new InstrumentRefreshHandler(instrumentKey);
            instrumentRefreshHandlerMap.put(instrumentId, refreshHandler);
        }
        return refreshHandler;
    }

    private boolean pollScheduleQueue() {
        final RefreshHandler refreshHandler = scheduleQueue.poll();
        if (refreshHandler != null) {
            refreshHandler.onSchedule();
            return true;
        }
        return false;
    }

    public interface RefreshHandler {
        void onRequest();
        void onSchedule();
    }

    private class InstrumentRefreshHandler implements RefreshHandler {
        private final InstrumentKey key;
        private final RefreshHandler unscheduled = new Unscheduled();
        private final RefreshHandler incompleteScheduled = new IncompleteScheduled();
        private final RefreshHandler completeScheduled = new CompleteScheduled();

        private RefreshHandler currentState;

        private InstrumentRefreshHandler(final InstrumentKey key) {
            this.key = Objects.requireNonNull(key);
            this.currentState = unscheduled;
        }

        @Override
        public void onRequest() {
            currentState.onRequest();
        }

        @Override
        public void onSchedule() {
            currentState.onSchedule();
        }

        private class Unscheduled implements RefreshHandler {
            @Override
            public void onRequest() {
                if (!pricingRefresher.refresh(key.instrumentId(), NO_FORCE_SNAPSHOT)) {
                    currentState = incompleteScheduled;
                    scheduleQueue.offer(InstrumentRefreshHandler.this);
                }
            }

            @Override
            public void onSchedule() {
                //LOGGER.warn();
                onRequest();
            }
        }

        private class IncompleteScheduled implements RefreshHandler {
            @Override
            public void onRequest() {
                if (pricingRefresher.refresh(key.instrumentId(), NO_FORCE_SNAPSHOT)) {
                    currentState = completeScheduled;
                }
            }

            @Override
            public void onSchedule() {
                if (pricingRefresher.refresh(key.instrumentId(), NO_FORCE_SNAPSHOT)) {
                    currentState = unscheduled;
                } else {
                    scheduleQueue.offer(InstrumentRefreshHandler.this);
                }
            }
        }

        private class CompleteScheduled implements RefreshHandler {
            @Override
            public void onRequest() {
                if (!pricingRefresher.refresh(key.instrumentId(), NO_FORCE_SNAPSHOT)) {
                    currentState = incompleteScheduled;
                }
            }

            @Override
            public void onSchedule() {
                currentState = unscheduled;
            }
        }
    }
}
