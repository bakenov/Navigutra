package com.anz.markets.efx.ngaro.time;

import java.util.function.Consumer;

/**
 * Very simplistic date formats with 4 digit year, 2 digit month and 2 digit day.
 */
public enum LocalDateFormat {
    /** Date format reading like 20170223 */
    YYYYMMDD(0, 4, 6, -1, -1),
    /** Date format reading like 2017-02-23 or with any other delimiter char */
    YYYY_MM_DD(0, 5, 8, 4, 7),
    /** Date format reading like 23022017 */
    MMDDYYYY(4, 0, 2, -1, -1),
    /** Date format reading like 23-02-2017 or with any other delimiter char */
    MM_DD_YYYY(6, 0, 3, 2, 5),
    /** Date format reading like 02232017 */
    DDMMYYYY(4, 2, 0, -1, -1),
    /** Date format reading like 02-23-2017 or with any other delimiter char */
    DD_MM_YYYY(6, 3, 0, 2, 5);

    private static LocalDateFormat[] VALUES = values();

    private final int offsetYear;
    private final int offsetMonth;
    private final int offsetDay;
    private final int positionDelimiter1;
    private final int positionDelimiter2;
    private final LocalDateEncoder defaultEncoder;
    private final LocalDateDecoder defaultDecoder;

    LocalDateFormat(final int offsetYear, final int offsetMonth, final int offsetDay,
                    final int positionDelimiter1, final int positionDelimiter2) {
        this.offsetYear = offsetYear;
        this.offsetMonth = offsetMonth;
        this.offsetDay = offsetDay;
        this.positionDelimiter1 = positionDelimiter1;
        this.positionDelimiter2 = positionDelimiter2;
        this.defaultEncoder = new LocalDateEncoder(this);
        this.defaultDecoder = new LocalDateDecoder(this);
    }

    public final int getOffsetYear() {
        return offsetYear;
    }

    public final int getOffsetMonth() {
        return offsetMonth;
    }

    public final int getOffsetDay() {
        return offsetDay;
    }

    public final int getPositionDelimiter1() {
        return positionDelimiter1;
    }

    public final int getPositionDelimiter2() {
        return positionDelimiter2;
    }

    /**
     * Returns the total length of a string which represents a date in this format.
     * @return the formatted string length, usually 8 or 10 for formats without and with delimiters, respectively
     */
    public final int getLength() {
        return 4 + 2 + 2 + (getPositionDelimiter1() >= 0 ? 1 : 0) + (getPositionDelimiter2() >= 0 ? 1 : 0);
    }

    /**
     * @return the default encoder using '-' for formats with a delimiter
     */
    public final LocalDateEncoder getDefaultEncoder() {
        return defaultEncoder;
    }

    /**
     * @return the default decoder for this format
     */
    public final LocalDateDecoder getDefaultDecoder() {
        return defaultDecoder;
    }

    public static void forEach(final Consumer<? super LocalDateFormat> consumer) {
        for (final LocalDateFormat value : VALUES) {
            consumer.accept(value);
        }
    }
}
