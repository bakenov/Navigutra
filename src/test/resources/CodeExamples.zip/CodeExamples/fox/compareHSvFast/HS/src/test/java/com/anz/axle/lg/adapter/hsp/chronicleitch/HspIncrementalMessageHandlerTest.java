package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.itchcboe.messages.CancelOrder;
import software.chronicle.itchcboe.messages.ModifyOrder;
import software.chronicle.itchcboe.messages.NewOrder;
import software.chronicle.itchcboe.messages.datamodel.DefaultModifyOrder;

import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoIncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class HspIncrementalMessageHandlerTest {

    private static final String SENDER_COMP_ID = "GB:GS";
    private static final String COMP_ID = "GB:lg-gs";
    private static final String SYMBOL_7 = "AUD/NZD";
    private static final String SYMBOL_6 = "AUDNZD";
    private static final Bytes ORDER_ID = Bytes.from("291579");
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(SYMBOL_6);

    private static final Optional<Tenor> SPOT = Optional.of(Tenor.SP);
    private static final long CURRENT_TIME = 34523453;

    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderSupplier encoderSupplier;
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    private StringToIntCache stringToIntCache;
    private SymbolOrderIdSideLookUp lookUp;

    private HspIncrementalMessageHandler handler;
    private int entryId_for_ORDER_ID;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    @Before
    public void setUp() throws Exception {
        final StringToIntCacheFactory stringToIntCacheFactory = new StringToIntCacheFactory(1000, 25, 1000, 8, 1);
        stringToIntCache = stringToIntCacheFactory.get();
        entryId_for_ORDER_ID = stringToIntCache.put(ORDER_ID);

        lookUp = new SymbolOrderIdSideLookUp();
        encoderSupplier = new PojoPricingEncoderSupplier(m -> {});

        handler = new HspIncrementalMessageHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, () -> System.currentTimeMillis(), SENDER_COMP_ID, COMP_ID, lookUp, PricingFlagsAppender.noOp(), sourceSequencer);
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY)).thenReturn(RequestKey.of(Venue.HSPMD, INSTRUMENT_KEY));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);

        when(subscriptionManager.lookupBySymbol(SYMBOL_7)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.stringToIntCache()).thenReturn(stringToIntCache);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
    }

    @Test
    public void handleNewOrder() throws Exception {
        //given
        final NewOrder newOrder = newOrder("B", "1.08108","1E6");

        //when
        handler.newOrderHandler().accept(newOrder);

        //then
        assertThat("cached new BID orderId", lookUp.lookUpSide(INSTRUMENT_KEY.instrumentId(), entryId_for_ORDER_ID), is(EntryType.BID));

        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(INSTRUMENT_KEY.instrumentId()));
        assertThat(body.marketId, is(Venue.HSPMD));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.NEW));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(entryId_for_ORDER_ID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryPx, is(1.08108));
        assertThat(pojoEncoder.message().entries.get(0).mdEntrySize, is(1000000.0));
    }

    @Test
    public void handleModifyOrder() throws Exception {
        //given
        lookUp.cache(INSTRUMENT_KEY.instrumentId(), entryId_for_ORDER_ID, EntryType.BID);
        final ModifyOrder modifyOrder = modifyOrder(1.0,1000000.0);

        //when
        handler.modifyOrderHandler().accept(modifyOrder);

        //then
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(INSTRUMENT_KEY.instrumentId()));
        assertThat(body.marketId, is(Venue.HSPMD));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.CHANGE));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(entryId_for_ORDER_ID));
        //assertThat(pojoEncoder.message().entries.get(0).mdEntryPx, is(1.0));
        assertThat(pojoEncoder.message().entries.get(0).mdEntrySize, is(1000000.0));
    }

    @Test
    public void handleCancelOrder() throws Exception {
        //given
        lookUp.cache(INSTRUMENT_KEY.instrumentId(), entryId_for_ORDER_ID, EntryType.BID);
        final CancelOrder cancelOrder = Marshallable.fromString(
                "!software.chronicle.itchcboe.messages.datamodel.DefaultCancelOrder {ccyPair: "+SYMBOL_7+", orderId: " +ORDER_ID+ " }");
        //when
        handler.cancelOrderHandler().accept(cancelOrder);

        //then
        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder) encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(INSTRUMENT_KEY.instrumentId()));
        assertThat(body.marketId, is(Venue.HSPMD));

        assertThat(pojoEncoder.message().entries.size(), is(1));
        assertThat(pojoEncoder.message().entries.get(0).mdUpdateAction, is(UpdateAction.DELETE));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(entryId_for_ORDER_ID));

        assertThat("removed orderId from cache", lookUp.lookUpSide(INSTRUMENT_KEY.instrumentId(), entryId_for_ORDER_ID), nullValue());
    }

    private NewOrder newOrder(final String buySell, final String price, final String amount) {
        return Marshallable.fromString(
                "!software.chronicle.itchcboe.messages.datamodel.DefaultNewOrder {" +
                        "buySell: "+buySell+", ccyPair: "+SYMBOL_7+", orderId: "+ORDER_ID+", price: "+price+", amount: "+amount+"}");
    }

    private ModifyOrder modifyOrder(final double price, final double amount) {
        final ModifyOrder modifyOrder = new DefaultModifyOrder();
        modifyOrder.ccyPair(SYMBOL_7);
        modifyOrder.orderId(ORDER_ID);
        modifyOrder.amount(amount);
        //TODO: modifyOrder.price(price);
        return modifyOrder;
    }
}