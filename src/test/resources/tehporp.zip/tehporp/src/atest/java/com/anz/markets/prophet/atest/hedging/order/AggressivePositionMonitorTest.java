package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.*;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.positionrisk.Positions;
import org.apache.logging.log4j.Level;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerState.BUYING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.IDLE;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELLING;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCAD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * AXPROPHET-896 New Aggressive Hedger strategy that triggers during periods of not receiving trades AND if specified
 * pnl(loss or profit) is met during that period
 *
 * AXPROPHET-937 Pnl is scaled to /1mio USD. (only when the currency positionInSystemBase is above 1mio USD)
 *
 * AXPROPHET-1137 can now specify pnl loss AND profit
 */

@Requirement(value = {Requirement.Ref.HEDGING_AXPROPHET_896, Requirement.Ref.HEDGING_AXPROPHET_937})
@RestartBeforeTest(reason = "As hedger states are left hanging")
public class AggressivePositionMonitorTest extends BaseAcceptanceSpecification {
    NewOrder newOrder;
    NewOrder newOrder2;
    private double instrumentPos;

    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                        new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setMinimumRisk(999_999);
                                setPositionMonitorWindowSeconds(5);
                                setPnLThreshold(-199.0);}}
                ));
                return configuration;
    }

    @Test
    public void noTradesAndPnlLossSignificant_Sell() {
        double maxSpreadBps = 0.0002;
        double tobBid = 0.74998;
        double tobOffer = 0.75002;

        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, tobBid, tobOffer, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => equal to/greater than PnL threshold -200.0
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder.getSide(),is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(),is(instrumentPos));
            assertThat(newOrder.getPrice(),is(tobOffer - maxSpreadBps));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=100;windowEndPnl=-100"));
        }
    }

    @Test
    public void noTradesAndPnlProfitSignificant_Buy() {
        double maxSpreadBps = 0.0002;
        double tobBid = 0.74998;
        double tobOffer = 0.75002;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(999_999);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(199.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, tobBid, tobOffer, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s initial position created
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74990));
        }
        and:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            instrumentPos = Math.abs(gradientPos.getInstrumentPositionInNotional());
        }
        then:
        // initial position creates pnl -100
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
        }
        when:
        // t+1.5s market data update causing new pnl -50
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74995));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+2.5s market data update causing new pnl +150
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74975));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 150.0));
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = 150.  Start PnL = -50.  Total change = +200 => equal to/greater than PnL threshold
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, BUYING));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder2.getSide(),is(HedgeOrderSide.BUY));
            assertThat(newOrder2.getQuantity(),is(instrumentPos));
            assertThat(newOrder2.getPrice(),is(tobBid + maxSpreadBps));
        }
    }

    @Test
    public void noTradesAndPnlLossNotSignificant() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(999_999);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-201.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5 -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => NOT equal/greater than PnLThreshold(-201.0)
        // Do NOT trigger Aggressive Hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLP));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void noTradesAndMinRiskNotMet_ManualAdjustment() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(1_000_100);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-66.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5 -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 =>  equal/greater than PnLThreshold(-75.0)
        // However current instrumentPosition 1mio is below MinRisk(1_000_100) => do NOT trigger aggressive order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLP));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+7.5 manual adjustment
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1500));
            prophet.receive(tdd.adjustments(tdd.adjustment(Currency.USD, -375_010), tdd.adjustment(Currency.AUD, 500_000, 0.75000)));
        }
        then:
        // InstrumentPositionNotional is now 1.5mio.  |PositionInSystemBase| = 1.5 * 0.75 = 1.125mio
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(gradientPos.getInstrumentPositionInNotional(), isRoundedTo(1_500_000.0));
        }
        and:
        // manual adjustment causes pnl point of -200
        // |PositionInSystemBase| of 1.125mio is > 1mio therefore pnl is scaled
        // -200 /1.125mioUSD = -177.78/mio
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -200.0));
        }
        when:
        // t+8.5s market data update causing new pnl -275
        // |PositionInSystemBase| of 1.5 * 0.74975 = 1.24625mio is > 1mio therefore pnl is scaled
        // -275 / 1.24625mioUSD = -244.53/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74975));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -275.0));
        }
        when:
        // @t+13.0s still no position change.
        // Current/latest Pnl = -244.53  Start PnL=-177.78.  Total change = -66.748 => equal/greater than PnLThreshold(-66.0)
        // trigger Aggressive Hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 4_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=-178;windowEndPnl=-245"));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    @DisplayName("Verify biased notional position used for Min Risk and Order Amount. " +
            "Ensure correct config tier based on min risk is used")
    public void strategyToUseBiasedPositions() {
        double biasedMinRisk = 1_000_100;
        double tobOffer = 0.75002;
        double maxSpreadBps = 0.0002;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0003);
                                setMinimumRisk(10_000);
                                setPositionMonitorWindowSeconds(5);
                                setPnLThreshold(-66.0);}},
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(maxSpreadBps);
                                setMinimumRisk(biasedMinRisk);
                                setPositionMonitorWindowSeconds(5);
                                setPnLThreshold(-66.0);}},
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0004);
                                setMinimumRisk(5_000_000);
                                setPositionMonitorWindowSeconds(5);
                                setPnLThreshold(-66.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, tobOffer, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, tobOffer, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));

            // set up biased position
            prophet.receive(tdd.biasPosition(Currency.AUD, -101.0));
        }
        given:
        // t+0.5 -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        then:
        {
            // unbiased op pos does NOT meet min risk
            OptimalPositions pos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(opPos.getInstrumentPositionInNotional(), isRoundedTo(1_000_000.0));

            // biased op pos DOES meet min risk
            OptimalPositions biasedPos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition biasedOpPos = biasedPos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(biasedOpPos.getInstrumentPositionInNotional(), isRoundedTo(1_000_101.0));
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 =>  equal/greater than PnLThreshold(-75.0)
        // Biased instrumentPosition above MinRisk => trigger aggressive order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder.getSide(),is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(),is(1_000_101.0)); // biased notional position
            assertThat(newOrder.getPrice(),is(tobOffer - maxSpreadBps));
        }
    }

    @Test
    public void noTradesAndPnlLossSignificant_RollingWindow() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(999_999);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-299.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s initial position created
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        // initial position creates pnl +100
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 100.0));
        }
        when:
        // t+1.5s market data update causing new pnl +200
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75010));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 200.0));
        }
        when:
        // t+2.5s market data update causing new pnl -100
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74980));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => NOT equal/greater than PnLThreshold(-300.0)
        // Do NOT trigger Aggressive Hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLP));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // @t+7.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=200.  Total change = -300 => equal/greater than PnLThreshold(-300.0)
        // trigger Aggressive Hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=200;windowEndPnl=-100"));
        }
    }

    @Test
    public void multipleMonitorsTwoInstruments() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumRisk(500_000);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-100.0);}},
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.USDCAD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumRisk(500_000);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(4);
                                    setPnLThreshold(39.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        when:
        // t+0.5s initial position created. End of Position monitor will be @t+6 (i.nearest sec)
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // initial position creates pnl -50
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+1.5s AUDUSD market data update causing new pnl -350
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74970));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -350.0));
        }
        when:
        // t+2.5s USDCAD client deal received resulting in pnl +80
        // End of Position monitor will be @t+7 (i.e nearest sec)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 80.0));
        }
        when:
        // t+3.5s USDCAD market data update causing new pnl +120 (actually 119.995, hence PnLThreshold set to 39)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, USDCAD, 1.25005));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 120.0));
        }
        when:
        // t+4.5s AUDUSD market data update causing new pnl -250
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74980));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -250.0));

            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            instrumentPos = Math.round(gradientPos.getInstrumentPositionInNotional());
        }
        when:
        // @t+6.0s End of AUDUSD position window. Still no position change
        // Current/latest Pnl = -250.  Start PnL@t+1 = -50.  Total change = -200 => equal/greater than PnLTracker(-100)
        // Aggressive Hedge AUD/USD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=-50;windowEndPnl=-250"));
        }
        when:
        // @t+7.0s end of USDCAD position window. Still no position change
        // Current/latest Pnl = +120.  Start PnL@t+3 = +80.  Total change = +40 => equal/greater than PnLTracker(+40.0)
        // Aggressive Hedge USDCAD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=80;windowEndPnl=120"));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD)).getFirst();
            assertThat(newOrder.getSide(),is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(),is(instrumentPos));
        }
    }

    @Test
    // AXPROPHET-1137
    public void multipleMonitorsPositiveNegativePnl() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(500_000);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setPositionMonitorWindowSeconds(5);
                                setPnLThreshold(-201.0);}},
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(500_000);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setPositionMonitorWindowSeconds(4);
                                setPnLThreshold(101.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        when:
        // t+0.5s initial position created. End of Position monitor will be @t+6 (i.nearest sec)
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // initial position creates pnl -50
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+1.5s AUDUSD market data update causing new pnl -350
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74970));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -350.0));
        }
        when:
        // t+2.5s AUDUSD market data update causing new pnl -450
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74960));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -450.0));
        }
        when:
        // t+4.5s AUDUSD market data update causing new pnl -250
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74980));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -250.0));

            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            instrumentPos = Math.round(gradientPos.getInstrumentPositionInNotional());
        }
        when:
        // @t+6.0s Still no position change
        // 5sec window: Current Pnl = -250.  Start PnL@t+1 = -50.  Total change = -200 => less than PnLTracker(-201)
        // 4sec window: Current Pnl = -250.  Start PnL@t+2 = -350.  Total change = +100 => less than PnLTracker(+101)
        // Aggressive Hedge AUD/USD order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_500);
        }
        then:
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // @t+7.0s Still no position change
        // 5sec window: Current Pnl = -250.  Start PnL@t+2 = -350.  Total change = +100 => loss less than PnLTracker(-201)
        // 4sec window: Current Pnl = -250.  Start PnL@t+3 = -450.  Total change = +200 => exceeds PnLTracker(+101)
        // Aggressive Hedge AUD/USD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            prophet.expect(Level.INFO, newOrderComment("windowSec=4;windowStartPnl=-450;windowEndPnl=-250"));
        }
    }

    @Test
    public void unableToPlaceAggressiveOrder_Retry() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumRisk(1000);
                                    setMinimumOrderQuantity(1_000_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}}
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_BENCH,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.DEUT,Market.FASTMATCH)
            );

            //            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
            //                    Arrays.asList(new PriceAndQtyImpl(0.74998, 500_000),
            //                            new PriceAndQtyImpl(0.74980, 100_000)),
            //                    Arrays.asList(new PriceAndQtyImpl(0.75002, 1_000_000)),
            //                    tdd.now()));

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.FASTMATCH, AUDUSD, 0.74980, 100_000, 0.75002, 500_000, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, AUDUSD, 0.74998, 500_000, 0.75002, 500_000, now()));


            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => equal to/greater than PnL threshold -200.0
        // Aggressive Hedge order triggered
        // However Aggressive hedger unable to place order since insufficient liquidity(MinimumOrderQuantity) in WSP_BENCH book
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLP));
        }
        when:
        // @t+6.5s AXL market data update(now with sufficient liquidity)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, AUDUSD, 0.74998, 0.75001, now()));
        }
        and:
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 500);
        }
        then:
        // @t+7.0 on the one sec chime re-evaluate and place out aggressive hedge order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void positionChange_NoAggressiveOrder() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(999_999);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-133.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // t+3.5 receive client deal i.e change in position(2mio). Therefore end of position window now t+9
        // results in pnl -150
        // |PositionInSystemBase| of 2.0 * 0.75 = 1.5mio is > 1mio therefore pnl is scaled
        // -150 / 1.5mioUSD = -100/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -150.0));
        }
        when:
        // t+4.5s market data update causing new pnl -350
        // -350 / 1.5mioUSD = -233.33/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74970));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -350.0));
        }
        when:
        // @t+9.0s still no position change.
        // Current/latest Pnl = -233.33.  Start PnL = -100.  Total change = -133.33 => equal to/greater than PnL threshold -133.0
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 4_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=-100;windowEndPnl=-233"));
        }
    }

    @Test
    public void differentTimeZone_NoAggressiveOrder() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.SNG);
                                    setMinimumRisk(1000);
                                    setMinimumOrderQuantity(1_000_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => equal to/greater than PnL threshold -200.0
        // However current TZ is LDN. NO Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void higherPriorityThanTwapWhenOrderAmountEqual() {
        /**
         * If TWAP and Position monitor both want to place order then which ever has highest order amount wins
         * If order amounts equal then Position Monitor strategy wins

         * Removing AggressivePositionMonitorHedge config shows TWAP order placed @t+6
         * With both strategies active, AggressivePositionMonitor hedger places order @t+6
         */
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(5_000)
                    ))
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumRisk(100_000);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(10.0);}}
                    ))
                    .setOptimalPositionConfigs(
                            Arrays.asList(
                                    new OptimalPositionConfig(Instrument.AUDJPY, Instrument.AUDJPY, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.AUDNZD, Instrument.AUDNZD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.AUDUSD, Instrument.AUDUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.EURAUD, Instrument.EURAUD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.EURCHF, Instrument.EURCHF, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURCZK, Instrument.USDCZK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURDKK, Instrument.USDDKK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURGBP, Instrument.EURGBP, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURHUF, Instrument.USDHUF, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURJPY, Instrument.EURJPY, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.EURNOK, Instrument.USDNOK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURPLN, Instrument.USDPLN, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURSEK, Instrument.USDSEK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURUSD, Instrument.EURUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.GBPJPY, Instrument.GBPJPY, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.GBPUSD, Instrument.GBPUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.NZDUSD, Instrument.NZDUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.USDCAD, Instrument.USDCAD, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDCHF, Instrument.USDCHF, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDCNH, Instrument.USDCNH, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDILS, Instrument.USDILS, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDJPY, Instrument.USDJPY, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.USDMXN, Instrument.USDMXN, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDSGD, Instrument.USDSGD, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDTHB, Instrument.USDTHB, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDTRY, Instrument.USDTRY, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDHKD, Instrument.USDHKD, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDZAR, Instrument.USDZAR, 0.6, 1.0, false)
                            ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));

            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        when:
        // t+0.5 receive AUDUSD Client Deal generating PnL 100
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 100.0));

            // gradient position(which TWAP strategy uses) is EQUAL TO instrumentPositionNotional(which PositionMonitor strategy uses)
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            assertThat(gradientPos.getGradientPositionInNotional() == gradientPos.getInstrumentPositionInNotional(), is(true));
        }
        when:
        // t+2.5s AUDUSD market data update resulting in pnl 150
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75005));

        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 150.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+6.0s End of PositionMonitor window. No position change. Also end of TWAP Order Rate window
        // Current/latest Pnl = 150.  Start PnL = 100.  Total change = +100 => equal/greater than PnLTracker(10)
        // Since PositionMonitor strategy order amount == TWAP strategy order amount, PositionMonitor has HIGHER PRIORITY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, SELLING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void twapAmtGreaterThanPositionMonitorAmt() {
        /**
         * If TWAP and Position monitor both want to place order then which ever has highest order amount wins
         * If order amounts equal then Position Monitor strategy wins
         */
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(5_000)
                    ))
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumRisk(100_000);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(10.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        when:
        // t+0.5 receive AUDUSD Client Deal generating PnL 50
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74995));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 50.0));

            // gradient position(which TWAP strategy uses) is GREATER THAN instrumentPositionNotional(which PositionMonitor strategy uses)
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(gradientPos.getGradientPositionInNotional() > gradientPos.getInstrumentPositionInNotional(), is(true));
        }
        when:
        // t+2.5s AUDUSD market data update resulting in pnl 150
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75010));

        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 150.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+6.0s End of PositionMonitor window. No position change. Also end of TWAP Order Rate window
        // Current/latest Pnl = 150.  Start PnL = 50.  Total change = +100 => equal/greater than PnLTracker(10)
        // TWAP strategy order amount > PositionMonitor strategy order amount, PositionMonitor has HIGHER PRIORITY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void changeInOptimalPositionDueToMarketDataUpdates() {
        /**
         * MarketData updates cause slight changes to instrument position.
         * Therefore we will now monitor changes in Currency Position instead which will not be impacted
         */
        double initialInstrumentPosition;
        double initialCcyPosition;
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.USDCAD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumRisk(100_000);
                                    setMinimumOrderQuantity(1_000_000);
                                    setMaximumSpread(0.0002);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(79.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        when:
        // t+0.5 receive Client Deal generating PnL 120
        // |PositionInSystemBase| of 1.5 * 1.2499 / 1.25 = 1.49988 mio is > 1mio therefore pnl is scaled
        // 120 / 1.49988mioUSD = 80.0064/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_500_000, 1.24990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 120.0));
            initialCcyPosition = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst().getPosition2().getPositionInNotional();

            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            initialInstrumentPosition = gradientPos.getInstrumentPositionInNotional();
        }
        when:
        // t+2.5s USDCAD market data received resulting in pnl 240
        // |PositionInSystemBase| of 1.5 * 1.2499 / 1.2501 = 1.49976mio
        // 240 / 1.49976mio = 160.026
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(2));
            prophet.receive(tdd.marketDataSnapshot(CNX, USDCAD, 1.25010));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 240.0));

            // USDCAD instrument position CHANGED
            // CAD Position UNCHANGED  => this is what we monitor
            // Therefore do NOT reset window
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            assertThat(gradientPos.getInstrumentPositionInNotional() != initialInstrumentPosition, is(true));
            assertThat(initialCcyPosition == prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst().getPosition1().getPositionInNotional(), is(true));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+6.0s End of SLMonitor order window. No position change. Also end of TWAP Order Rate window
        // Current/latest Pnl = 160.026 Start PnL = 80.06.  Total change = +79.97 => equal/greater than PnLTracker(79)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=80;windowEndPnl=160"));
        }
    }

    @Test
    public void disabledViaNanPnl() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(999_999);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(Double.NaN);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => however PnLThreshold = NaN
        // NO Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLP));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void resetWhenHedgerTurnedOn() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setMinimumRisk(999_999);
                                    setPositionMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+2.5s aggressive hedger turned on i.e RESET STATES
        {
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+6.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200
        // However, monitor reset to IDLE when aggressive hedger turned on. Therefore Aggressive hedger not triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLP));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+8.0s
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_000);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeSpeedUpSignal() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setMinimumRisk(999_999);
                                setPositionMonitorWindowSeconds(3);
                                setPnLThreshold(-99.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            // Pause enabled(period set to 5 sec)
            prophet.receive(tdd.setHedgingPause(Currency.AUD, true));
        }
        given:
        // t+0.5s -> t+2.5s
        // create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
        {
            createPnlLossPoints();
        }
        when:
        // @t+4.0s still no position change.
        // Current/latest Pnl = -100.  Start PnL=100.  Total change = -200 => equal to/greater than PnL threshold -200.0
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_500);
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // PAUSE is manually disabled(HedgeCurrencyControl does not trigger order)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setHedgingPause(Currency.AUD, false));
        }
        then:
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        and:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.expect(NewOrder.class);
        }
    }

    public void createPnlLossPoints() {
        /**
         * create pnl points @t+0.5: +100, @t+1.5: 0, @t+2.5: -100
         */
        given:
        // t+0.5s initial position created
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        // initial position creates pnl +100
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 100.0));
        }
        and:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            instrumentPos = gradientPos.getInstrumentPositionInNotional();
        }
        when:
        // t+1.5s market data update causing new pnl 0.0
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 0.0));
        }
        when:
        // t+2.5s market data update causing new pnl -100
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74980));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
        }
    }
}