package com.anz.axle.lg.adapter.apama.decoder;

public final class FixStringConstants {
    public static final String SENDING_TIME = "52";
    public static final String SYMBOL = "55";
    public static final String QUOTE_REQ_ID = "131";
    public static final String BID_PX = "132";
    public static final String OFFER_PX = "133";
    public static final String BID_SIZE = "134";
    public static final String OFFER_SIZE = "135";
    public static final String QUOTE_TYPE = "537";
    public static final String BID_MIN_SIZE = "647";
    public static final String OFFER_MIN_SIZE = "648";
    public static final String QUOTE_TYPE_INDICATIVE = "0";
    public static final String QUOTE_CONDITION_INDICATIVE = "I";
    public static final String CONDITION_NO_MARKET_ACTIVITY = "1000";
    public static final String CONDITION_NO_DATA_AVAILABLE = "1001";
    public static final String TAG_CFI_CODE = String.valueOf(FixNumericConstants.TAG_CFI_CODE);
    public static final String TAG_SETTL_TYPE = String.valueOf(FixNumericConstants.TAG_SETTL_TYPE);
    public static final String TAG_SETTL_DATE = String.valueOf(FixNumericConstants.TAG_SETTL_DATE);

}
