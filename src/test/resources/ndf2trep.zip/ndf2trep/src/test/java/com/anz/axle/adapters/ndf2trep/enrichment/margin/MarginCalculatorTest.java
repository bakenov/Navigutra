package com.anz.axle.adapters.ndf2trep.enrichment.margin;

import com.anz.markets.efx.ngaro.maths.Epsilon;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class MarginCalculatorTest {

    @Test
    public void testConfig_side() {
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.9","ASK","+","0","4"), 10);

        assertExceptionOnParseConfig(Arrays.asList("PERC","BIDD","-","0.9","ASK","+","0","4"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.9","DDD","+","0","4"), 10);
    }

    @Test
    public void testConfig_marginValue() {
        MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS","BID","-","0.009975","ASK","+","0","4"), 10);

        assertExceptionOnParseConfig(Arrays.asList("PIPS","BID","-","NaN","ASK","+","0","4"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PIPS","BID","-","0","ASK","+","NaN","4"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PIPS","BID","-","0.1","ASK","+","sss","4"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PIPS","BID","-","aaa","ASK","+","1","4"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PIPS","BID","-","-1","ASK","+","0","4"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PIPS","BID","-","0.1","ASK","+","-2","4"), 10);
    }

    @Test
    public void testConfig_paramSize() {
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 10);

        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4", "dummy"), 10);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0"), 10);
    }

    @Test
    public void testConfig_pips() {
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 0);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), -1);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 9);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 11);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 102);

        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 10);
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 100);
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 1000);
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 10000);
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 100000);
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 1000000);
    }

    @Test
    public void testConfig_operator() {
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","4"), 100);

        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","*","0.009975","ASK","+","0","4"), 100);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","+","0.009975","ASK","/","0","4"), 100);
    }

    @Test
    public void testConfig_rounding() {
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","3"), 100);

        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","0.5"), 100);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","0"), 100);
        assertExceptionOnParseConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","-1"), 100);
    }

    @Test
    public void testConfig_marginType() {
        MarginCalculator.createFromMarginConfig(Arrays.asList("PERC","BID","-","0.009975","ASK","+","0","3"), 100);
        MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS","BID","-","1","ASK","+","0","3"), 100);

        assertExceptionOnParseConfig(Arrays.asList("SSS","BID","-","0.009975","ASK","+","0","3"), 100);
    }

    private void assertExceptionOnParseConfig(final List<String> params, final long pips) {
        try {
            MarginCalculator.createFromMarginConfig(params, pips);
            fail("Exception expected on parsing margin config");
        } catch (Exception e) {
            // expected
            e.printStackTrace(System.out);
        }
    }


    private void testMarginForSymbol(MarginCalculator calculator, EntryType side, double input, double expected) {
        double test = calculator.applyMargin(side, input);
        assertEquals(expected, test, Epsilon.EPS_1eNegative10.getValue());
    }

    @Test
    public void testApplyMargin_percMarginType() {
        MarginCalculator calculator1 = MarginCalculator.createFromMarginConfig(Arrays.asList("PERC", "BID", "-", "0.009", "ASK", "+", "0.008", "4"), 1000L);
        testMarginForSymbol(calculator1, EntryType.BID, 1.2345, 1.2233);
        testMarginForSymbol(calculator1, EntryType.OFFER, 1.2347, 1.2446);

        MarginCalculator calculator2 = MarginCalculator.createFromMarginConfig(Arrays.asList("PERC", "BID", "-", "0.009", "ASK", "+", "0.008", "3"), 1000L);
        testMarginForSymbol(calculator2, EntryType.BID, 1.2345, 1.223);
        testMarginForSymbol(calculator2, EntryType.OFFER, 1.2347, 1.245);
    }

    @Test
    public void testApplyMargin_percMarginType_ZeroMargin() {
        MarginCalculator calculator1 = MarginCalculator.createFromMarginConfig(Arrays.asList("PERC", "BID", "-", "0", "ASK", "+", "0.001", "4"), 1000L);
        testMarginForSymbol(calculator1, EntryType.BID, 1.2345, 1.2345);
        testMarginForSymbol(calculator1, EntryType.OFFER, 1.2347, 1.2360);

        MarginCalculator calculator2 = MarginCalculator.createFromMarginConfig(Arrays.asList("PERC", "BID", "-", "0.009", "ASK", "+", "0", "4"), 1000L);
        testMarginForSymbol(calculator2, EntryType.BID, 1.2345, 1.2233);
        testMarginForSymbol(calculator2, EntryType.OFFER, 1.2347, 1.2347);
    }

    @Test
    public void testApplyMargin_pipsMarginType() {
        MarginCalculator calculator1 = MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS", "BID", "-", "1", "ASK", "+", "2", "4"), 100L);
        testMarginForSymbol(calculator1, EntryType.BID, 1.2345, 1.2245);
        testMarginForSymbol(calculator1, EntryType.OFFER, 1.2347, 1.2547);

        MarginCalculator calculator2 = MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS", "BID", "-", "1", "ASK", "+", "2", "4"), 1000L);
        testMarginForSymbol(calculator2, EntryType.BID, 1.2345, 1.2335);
        testMarginForSymbol(calculator2, EntryType.OFFER, 1.2347, 1.2367);

        MarginCalculator calculator3 = MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS", "BID", "-", "1", "ASK", "+", "2", "4"), 10000L);
        testMarginForSymbol(calculator3, EntryType.BID, 1.2345, 1.2344);
        testMarginForSymbol(calculator3, EntryType.OFFER, 1.2347, 1.2349);

        MarginCalculator calculator4 = MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS", "BID", "-", "1", "ASK", "+", "2", "4"), 100000L);
        testMarginForSymbol(calculator4, EntryType.BID, 1.2345, 1.2344);
        testMarginForSymbol(calculator4, EntryType.OFFER, 1.2347, 1.2348);
    }

    @Test
    public void testApplyMargin_pipsMarginType_trailingZero() {
        MarginCalculator calculator = MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS", "BID", "-", "5", "ASK", "+", "3", "4"), 10000L);
        testMarginForSymbol(calculator, EntryType.BID, 1.2345, 1.2340);
        testMarginForSymbol(calculator, EntryType.BID, 1.2345, 1.234);
        testMarginForSymbol(calculator, EntryType.OFFER, 1.2347, 1.2350);
        testMarginForSymbol(calculator, EntryType.OFFER, 1.2347, 1.235);
    }

    @Test
    public void testApplyMargin_pipsMarginType_zeroMargin() {
        MarginCalculator calculator = MarginCalculator.createFromMarginConfig(Arrays.asList("PIPS", "BID", "-", "0", "ASK", "+", "0", "4"), 10000L);
        testMarginForSymbol(calculator, EntryType.BID, 1.2345, 1.2345);
        testMarginForSymbol(calculator, EntryType.OFFER, 1.2347, 1.2347);
    }
}
