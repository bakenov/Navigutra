package com.anz.markets.efx.fox.aggregator.config;

import javax.annotation.PostConstruct;
import java.io.InputStream;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.anz.markets.efx.fox.pricing.subscription.config.VenueInstrumentConfig;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

@Configuration
public class PricingSubscriptionConfig {
    private final static Logger LOGGER = LoggerFactory.getLogger(PricingSubscriptionConfig.class);

    private final PricingClient<MarketDataBook> pricingClient;
    private final String venueInstrumentConfigClassPath;

    public PricingSubscriptionConfig(final PricingClient<MarketDataBook> pricingClient,
                                     final @Value("${venue.instrument.config.class.path}") String venueInstrumentConfigClassPath) {
        this.pricingClient = Objects.requireNonNull(pricingClient);
        this.venueInstrumentConfigClassPath = Objects.requireNonNull(venueInstrumentConfigClassPath);
    }

    @PostConstruct
    public void start() {
        final InputStream venueInstrumentConfigStream = this.getClass().getClassLoader().getResourceAsStream(venueInstrumentConfigClassPath);
        final VenueInstrumentConfig venueInstrumentConfig = VenueInstrumentConfig.yaml().load(venueInstrumentConfigStream);

        venueInstrumentConfig.getVenues().forEach((venue, securityTypeInstrumentGroups) -> {
            securityTypeInstrumentGroups.getSecurityTypes().forEach((securityType, instrumentGroups) -> {
                instrumentGroups.getInstrumentGroups().forEach(instrumentGroup -> {
                    instrumentGroup.getSymbols().forEach(symbol -> {
                        instrumentGroup.getTenors().forEach(tenor -> {
                            final RequestKey requestKey = RequestKey.of(venue, InstrumentKey.of(symbol, securityType, tenor));
                            LOGGER.info("Subscribing for {}", requestKey);
                            pricingClient.pricingSubscriber().subscribe(requestKey);
                        });
                    });
                });
            });
        });
    }
}
