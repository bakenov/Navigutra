package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReader;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderConfigBuilder;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.marketdata.MarketDataReader;
import com.google.common.collect.Maps;

import java.io.IOException;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.function.Consumer;

public class ProphetChronicleReaderModule extends AbstractInputModule {

    private final Symbol MARKET_DATA_SNAPSHOT_MESSAGE = MessageBus.getMessageType(MarketDataSnapshot.class);
    private final Symbol MARKET_DATA_INCREMENT_MESSAGE = MessageBus.getMessageType(MarketDataIncrement.class);

    private final String inPath;
    private final boolean pauser;
    private final boolean replay;
    private final boolean end;

    public ProphetChronicleReaderModule(String inPath, boolean pauser, boolean replay, boolean end) throws IOException {
        super("Prophet Chronicle Reader: " + inPath);
        this.inPath = inPath;
        this.pauser = pauser;
        this.replay = replay;
        this.end = end;
    }

    @Override
    public Runnable createInputRunnable() {
        try {
            final MarketDataReader reader = new MarketDataReader(Arrays.asList(marketData ->
                    getStage().getMessageBus().pub(marketData instanceof MarketDataIncrement ? MARKET_DATA_INCREMENT_MESSAGE : MARKET_DATA_SNAPSHOT_MESSAGE, marketData)
            ));
            final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
            for (MessageType messageType : MessageType.values()) {
                map.put(messageType, (bytes, mt) -> {
                });
            }
            map.put(MessageType.MARKET_DATA_SNAPSHOT, reader::processEntity);
            map.put(MessageType.MARKET_DATA_INCREMENT, reader::processEntity);
            map.put(MessageType.ONE_SECOND, new ChronicleReaderGeneric<>(OneSecond.INSTANCE, m -> { getStage().getMessageBus().pub(OneSecond.class,m); }));

            final Consumer<EndEvent> endEventSink = endEvent -> {
            };
            final LegacyChronicleReaderConfig baseConfig = LegacyChronicleReaderConfig.core(inPath, pauser, replay, end, endEventSink);
            final ChronicleObjectReaderMulti objectReader = new ChronicleObjectReaderMulti(map);
            final LegacyChronicleReaderConfigBuilder configReaderBuilder = new LegacyChronicleReaderConfigBuilder(baseConfig);
            return new LegacyChronicleReader(objectReader, configReaderBuilder.createChronicleConfigReader());
        } catch (Exception e) {
            throw new RuntimeException("Unable to create Prophet Chronicle reader.", e);
        }
    }
}
