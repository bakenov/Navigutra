package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Encoder of a message using the <i>stepped encoding</i> approach.
 * <p>
 * <b>Stepped encoding</b>
 * <br>
 * Encoder implementations will define steps each providing methods to encode certain message elements.  Encoding starts
 * with the invocation of {@link #messageStart} which returns an encoder for the first message elements.  Other
 * elements can be encoded in a next step and so on until encoding is completed via the final step by invoking
 * {@link MessageEncoder.Trailer#messageComplete() messageComplete()}.  A stepped encoding approach is necessary
 * if the wire format constrains a certain encoding order.  Application code shall therefore not hold on to step
 * encoders and invoke encoders out of sequence as this would violate the encoding order and lead to exceptions.
 *
 * @param <T> the type of the first encoder step
 */
public interface MessageEncoder<T> {

    /**
     * Starts encoding of a new message and returns the encoder to do so.
     * @param source - source to encode into header
     * @param sourceSeq - source sequence to encode into header
     * @return the first step of the stepped encoder
     */
    T messageStart(int source, long sourceSeq);

    /**
     * Element returned by last step of implementing encoder.  If the encoder is single-step then the first step
     * {@code <E>} returned by {@link #messageStart} also implements Trailer.
     */
    interface Trailer {
        /**
         * Completes the message encoding.  The encoded message is process by the consumer passed to
         * {@link Factory#create(Consumer)}.
         */
        void messageComplete();
    }

    /**
     * Message encoder factory.
     *
     * @param <M> the message type, or a buffer/medium containing messages
     * @param <E> the encoder type
     */
    @FunctionalInterface
    interface Factory<M, E extends MessageEncoder<?>> {
        /**
         * Returns an encoder that invokes the specified {@code messageConsumer} when message encoding is
         * {@link Trailer#messageComplete() completed}.
         *
         * @param messageConsumerSupplier supplier for consumer called with every message when encoding completes
         * @return an encoder invoking the specified consumer with the encoded message
         * @throws NullPointerException if the message consumer is null
         */
        E create(Supplier<? extends Consumer<? super M>> messageConsumerSupplier);

        /**
         * Returns an encoder that invokes the specified {@code messageConsumer} when message encoding is
         * {@link Trailer#messageComplete() completed}.
         *
         * @param messageConsumer the consumer called with every message when encoding completes
         * @return an encoder invoking the specified consumer with the encoded message
         * @throws NullPointerException if the message consumer is null
         */
        default E create(final Consumer<? super M> messageConsumer) {
            Objects.requireNonNull(messageConsumer);
            return create(() -> messageConsumer);
        }
    }
}
