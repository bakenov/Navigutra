package com.anz.markets.efx.ngaro.collections;

import java.util.function.BiConsumer;
import java.util.function.ObjDoubleConsumer;

public class ToStringHelpers {

    public static class CollectKeys<K, X> implements BiConsumer<K, X>, ObjDoubleConsumer<K>, ObjBooleanConsumer<K> {
        private final StringBuilder builder = new StringBuilder();

        public void start() {
            builder.setLength(0);
        }

        @Override
        public void accept(final K key, final boolean value) {
            appendKey(key);
        }

        @Override
        public void accept(final K key, final X value) {
            appendKey(key);
        }

        public void accept(final K key, final double value) {
            appendKey(key);
        }

        private void appendKey(final K key) {
            if (builder.length() > 0) {
                builder.append(',');
            }
            builder.append(key);
        }

        @Override
        public String toString() {
            return builder.toString();
        }
    }

    public static class CollectMapValues<A, X> implements BiConsumer<A, X>, ObjDoubleConsumer<A> {
        private final StringBuilder builder = new StringBuilder();

        public void accept(final A a, final X value) {
            appendKey(a);
            builder.append(value);
        }

        @Override
        public void accept(final A a, final double value) {
            appendKey(a);
            builder.append(value);
        }

        private void appendKey(final A a) {
            if (builder.length() > 0) {
                builder.append(',');
            }
            builder.append(a);
            builder.append("=");
        }

        @Override
        public String toString() {
            return builder.toString();
        }
    }

    public static class CollectTableValues<U, V, X> implements TriConsumer<U, V, X>, ObjObjDoubleConsumer<U, V> {
        private final StringBuilder builder = new StringBuilder();

        public void accept(final U u, final V v, final X value) {
            appendKey(u, v);
            builder.append(value);
        }

        @Override
        public void accept(final U u, final V v, final double value) {
            appendKey(u, v);
            builder.append(value);
        }

        private void appendKey(final U u, final V v) {
            if (builder.length() > 0) {
                builder.append(',');
            }
            builder.append(u);
            builder.append("/");
            builder.append(v);
            builder.append("=");
        }

        @Override
        public String toString() {
            return builder.toString();
        }
    }
}
