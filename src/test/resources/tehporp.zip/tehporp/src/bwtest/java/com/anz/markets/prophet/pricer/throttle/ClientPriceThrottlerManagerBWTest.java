package com.anz.markets.prophet.pricer.throttle;

import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

@Ignore("failing in TC")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ClientPriceThrottlerManagerBWTest {
    private static final int REPS = 100_000;
    // a higher threshold than I'd like but I'm satisfied that when running this in JMC no garbage shows up
    public static final int THRESHOLD = 1256; // this value is stable over increasing reps - up to 10m
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private ClientPriceThrottleManagerTest clientPriceThrottleManagerTest;

    @BeforeClass
    public static void warmup() throws IOException {
        ClientPriceThrottleManagerTest.setupClass();
        ClientPriceThrottlerManagerBWTest warmit = new ClientPriceThrottlerManagerBWTest();
        warmit.setup();
        warmit.checkHeartbeat();
        warmit.checkSendChangingPrice();
    }

    @Before
    public void setup() throws IOException {
        clientPriceThrottleManagerTest = new ClientPriceThrottleManagerTest();
        clientPriceThrottleManagerTest.setup();
        clientPriceThrottleManagerTest.clientPriceConsumer.accept(clientPriceThrottleManagerTest.price1);
        assertEquals(1, clientPriceThrottleManagerTest.accumulator.size());
    }

    @Test
    public void testCheckHeartbeat() throws IOException {
        setup();
        helper.testAllocationNotExceeded(
                this::checkHeartbeat,
                THRESHOLD
        );
    }

    @Test
    public void testCheckSendChangingPrice() throws IOException {
        clientPriceThrottleManagerTest.setup();
        helper.testAllocationNotExceeded(
                this::checkSendChangingPrice,
                THRESHOLD
        );
    }

    private void checkHeartbeat() {
        for (int i = 1; i < REPS; i++) {
            ClientPriceThrottleManagerTest.timeSource.incrementNanos(TimeUnit.SECONDS.toNanos(1));
            clientPriceThrottleManagerTest.oneSecondConsumer.accept(OneSecond.INSTANCE);
            GcFriendlyAssert.isTrue(clientPriceThrottleManagerTest.accumulator.size() >= (i / 5));
        }
    }

    private void checkSendChangingPrice() {
        for (int i = 1; i < REPS; i++) {
            ClientPriceThrottleManagerTest.timeSource.incrementNanos(TimeUnit.MILLISECONDS.toNanos(10));
            mutate((PriceAndQtyImpl) clientPriceThrottleManagerTest.price1.getBids().get(0));
            mutate((PriceAndQtyImpl) clientPriceThrottleManagerTest.price1.getOffers().get(0));
            clientPriceThrottleManagerTest.clientPriceConsumer.accept(clientPriceThrottleManagerTest.price1);
            GcFriendlyAssert.isTrue(clientPriceThrottleManagerTest.accumulator.size() >= (i / 100));
        }
    }

    private void mutate(final PriceAndQtyImpl clientPricePoint) {
        clientPricePoint.setPrice(clientPricePoint.getPrice() + (Math.random() - 0.5d));
    }
}