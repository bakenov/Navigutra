package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.TestRequest;

@RunWith(Spockito.class)
public class StartHeartbeating_When_TestRequestReceivedTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StartHeartbeating_When_TestRequestReceivedTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_start_heartbeating_when_test_request_is_received() throws Exception {
        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        final HeartbeatMatcher heartbeatMatcher = HeartbeatMatcher.build()
                .header().matches(HeartbeatMatcher.source().gt(0))
                .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                .body().matches(HeartbeatMatcher.senderCompId().eq("GB:fox"))
                .body().matches(HeartbeatMatcher.messageId().gt(0L));

        //assert first heartbeat
        Asserter.of(sorEndpoint.tradingResponse())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        //assert second heartbeat
        sorEndpoint.tradingResponse().clear();
        Asserter.of(sorEndpoint.tradingResponse())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

    }
}
