package com.anz.markets.prophet.atest.disco;

import com.anz.markets.disco.config.DiscoPFPConfig;
import com.anz.markets.disco.config.DiscoVolatilityPFPConfig;
import com.anz.markets.disco.data.Signal;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.modules.DiscoveryModule;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;


public class DiscoVolatilityTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault configuration1() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base();

        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.ANY,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.GBPUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoPFPConfig.FEATURE_NAME, Market.WSP_MU, Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoPFPConfig.PARAM_CONSTITUENTS, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX),
                DiscoPFPConfig.PARAM_PROTECTION, Markets.markets2DFlat(Market.HSP, Market.LMAXP, Market.EBS, Market.OCX, Market.CMEJMP, Market.RFX, Market.UBS),
                DiscoPFPConfig.PARAM_TWO_PRICE_MODE, DiscoveryModule.TwoPriceMode.BEST.name()));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoPFPConfig.FEATURE_NAME, priceFormationPipelineConfig);

        priceFormationPipelineConfig.clear();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, ""));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.WSP_MU, Instrument.ANY, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, "2|5|10|20|40"));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.WSP_MU, Instrument.AUDUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, "2"));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.WSP_MU, Instrument.GBPUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, ""));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, Market.WSP_MU, Instrument.USDCAD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, "2",
                DiscoVolatilityPFPConfig.PARAM_INC_SPREAD,3.0,
                DiscoVolatilityPFPConfig.PARAM_VOL_STEP,0.1,
                DiscoVolatilityPFPConfig.PARAM_VOL_START,0.0,
                DiscoVolatilityPFPConfig.PARAM_VOL_POWER,2.0));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoVolatilityPFPConfig.FEATURE_NAME_TV1, priceFormationPipelineConfig);

        priceFormationPipelineConfig.clear();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV2, Market.ANY, Instrument.ANY, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, ""));
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(DiscoVolatilityPFPConfig.FEATURE_NAME_TV2, Market.WSP_MU, Instrument.GBPUSD, TradingTimeZone.GLOBAL, Region.GB,
                DiscoVolatilityPFPConfig.PARAM_TIME_PERIOD_SECONDS, "2|5|10"));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(DiscoVolatilityPFPConfig.FEATURE_NAME_TV2, priceFormationPipelineConfig);

        return configuration;
    }

    @Test
    @RestartBeforeTest(reason = "Timing issue")
    public void basico_1tau_volatility() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(4));

            final Signal signal2 = signals.getSignal(2);
            assertThat(signal2.getSignalType(), is(SignalType.TV1));
            assertThat(signal2.getValue(), is(Double.NaN));
            assertThat(signal2.getConditionCode(), is(Symbol.get("X")));

            final Signal signal3 = signals.getSignal(3);
            assertThat(signal3.getSignalType(), is(SignalType.TVS));
            assertThat(signal3.getValue(), is(Double.NaN));
            assertThat(signal3.getConditionCode(), is(Symbol.get("X")));

        }

        // No change, no output.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
        }

        // Signal is at 0.7504, small bid change - first non-NaN delta signal so vol generated.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));

            final Signal signal = signals.getSignal(1);
            assertThat(signal.getSignalType(), is(SignalType.TV1));
            assertThat(signal.getValue(), is(0.0));
            assertThat(signal.getConditionCode(), is(Symbol.get("L")));
        }

        // Signal is at 0.7504, bid change outside spread, new signal = 0.75045, sigdelta=0.00005 term2=0,
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75045, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        double vol = 0.00005;
        double volAnnualised = annualise(vol, 2, 0.75045);
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV1), is(true));
            assertThat(signals.getSignal(SignalType.TV1).getValue(), closeTo(volAnnualised, 1E-7));
        }

        // Signal is at 0.7505, bid change outside spread, new signal = 0.7505, sigdelta=0.00005 term2=vol,
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75055, 1_000_000)),
                    tdd.now()));
        }
        vol = 0.00005 + 0.00005 * weight(0, 2);
        volAnnualised = annualise(vol, 2, 0.75050);
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV1), is(true));
            assertThat(signals.getSignal(SignalType.TV1).getValue(), closeTo(volAnnualised, 1E-7));
        }


        // Curr signal is 0.7505, vol is 0.  New signal will be 0.7504 creating a 0.0001 delta.
        // Testing time increment less than tau (fractional).
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(500);
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    tdd.now()));
        }
        vol = 0.0001 + vol * weight(TimeUnit.MILLISECONDS.toNanos(500), 2);
        volAnnualised = annualise(vol, 2, 0.7504);
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV1), is(true));
            assertThat(signals.getSignal(SignalType.TV1).getValue(), closeTo(volAnnualised, 1E-7));
        }

        // Test NaN prices don't reset vol.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(Double.NaN, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(Double.NaN, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV1), is(false));
        }

        // Test no change after NaN input prices.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV1), is(false));
            // no change in bid/offer and no time decay so no signal
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74050, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.74060, 1_000_000)),
                    tdd.now()));
        }
        vol = 0.75040 - 0.74060 + vol * weight(TimeUnit.MILLISECONDS.toNanos(0), 2);
        volAnnualised = annualise(vol, 2, 0.74060);
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV1), is(true));
            assertThat(signals.getSignal(SignalType.TV1).getValue(), closeTo(volAnnualised, 1E-7));
        }

        // Test that removing config stops disco output.
        given:
        {
            final ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
            prophet.receive(configuration, false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.74050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
            prophet.expect(FilteredMarketDataSnapshot.class, exactly(0), isMarket(Market.WSP_MU));
            prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP));
        }

    }


    /**
     * Tests 3 tau volatility on TV2 enum.
     */
    @Test
    @RestartBeforeTest(reason = "Timing issue")
    public void basico_3tau_volatility() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.GBPUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(3));

            final Signal signal2 = signals.getSignal(2);
            assertThat(signal2.getSignalType(), is(SignalType.TV2));
            assertThat(signal2.getValue(), is(Double.NaN));
            assertThat(signal2.getConditionCode(), is(Symbol.get("X")));
        }

        // Signal is at 0.7504, small bid change - first non-NaN delta signal so vol generated.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.GBPUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(2));

            final Signal signal = signals.getSignal(1);
            assertThat(signal.getSignalType(), is(SignalType.TV2));
            assertThat(signal.getValue(), is(0.0));
            assertThat(signal.getConditionCode(), is(Symbol.get("L")));
        }

        // Signal is at 0.7504, bid change outside spread, new signal = 0.75045, sigdelta=0.00005 term2=0,
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.GBPUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75045, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        double vol = 0.00005;
        double volAnnualised2 = annualise(vol, 2, 0.75045);
        double volAnnualised5 = annualise(vol, 5, 0.75045);
        double volAnnualised10 = annualise(vol, 10, 0.75045);
        double volAnnualised = Math.max(volAnnualised2, Math.max(volAnnualised5, volAnnualised10));

        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.containsSignal(SignalType.TV2), is(true));
            assertThat(signals.getSignal(SignalType.TV2).getValue(), closeTo(volAnnualised, 1E-7));
        }

    }

    @Test
    @RestartBeforeTest(reason = "Timing issue")
    public void basico_1tau_volSpread() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration1(), false);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.USDCAD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(4));

            final Signal signal2 = signals.getSignal(2);
            assertThat(signal2.getSignalType(), is(SignalType.TV1));
            assertThat(signal2.getValue(), is(Double.NaN));
            assertThat(signal2.getConditionCode(), is(Symbol.get("X")));

            final Signal signal3 = signals.getSignal(3);
            assertThat(signal3.getSignalType(), is(SignalType.TVS));
            assertThat(signal3.getValue(), is(Double.NaN));
            assertThat(signal3.getConditionCode(), is(Symbol.get("X")));

        }

        // No change, no output.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.USDCAD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            prophet.notExpect(Signals.class);
        }

        // Signal is at 0.7504, small bid change - first non-NaN delta signal so vol generated.
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.USDCAD,
                    Arrays.asList(new PriceAndQtyImpl(0.75020, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);
            assertThat(signals.getSize(), is(3));

            final Signal signal2 = signals.getSignal(1);
            assertThat(signal2.getSignalType(), is(SignalType.TV1));
            assertThat(signal2.getValue(), is(0.0));
            assertThat(signal2.getConditionCode(), is(Symbol.get("L")));

            final Signal signal3 = signals.getSignal(2);
            assertThat(signal3.getSignalType(), is(SignalType.TVS));
            assertThat(signal3.getValue(), is(0.0));
            assertThat(signal3.getConditionCode(), is(Symbol.get("L")));

        }

        // Signal is at 0.7504, bid change outside spread, new signal = 0.75045, sigdelta=0.00005 term2=0,
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.HSP, Instrument.USDCAD,
                    Arrays.asList(new PriceAndQtyImpl(0.75045, 1_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        double vol = 0.00005;
        double volAnnualised = annualise(vol, 2, 0.75045);
        then:
        {
            final List<Signals> signalsList = prophet.expect(Signals.class);
            assertThat(signalsList.size(), is(1));
            final Signals signals = signalsList.get(0);

            assertThat(signals.containsSignal(SignalType.TV1), is(true));
            assertThat(signals.getSignal(SignalType.TV1).getValue(), closeTo(volAnnualised, 1E-7));

            assertThat(signals.containsSignal(SignalType.TVS), is(true));
            assertThat(signals.getSignal(SignalType.TVS).getValue(), closeTo(3*Math.sqrt(Math.max(0,volAnnualised/0.1)), 1E-7));
        }

    }

    final long ONE_YEAR_NANOS = TimeUnit.SECONDS.toNanos(250 * 24 * 60 * 60);

    private double annualise(double x, int tauSeconds, double rate) {
        return (x / rate) * Math.sqrt(ONE_YEAR_NANOS / TimeUnit.SECONDS.toNanos(tauSeconds));
    }

    private double weight(long dtNanos, int tauSeconds) {
        return Math.exp(-1 * dtNanos / (double) TimeUnit.SECONDS.toNanos(tauSeconds));
    }
}
