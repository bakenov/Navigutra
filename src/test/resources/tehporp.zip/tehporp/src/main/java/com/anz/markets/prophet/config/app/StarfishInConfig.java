package com.anz.markets.prophet.config.app;

import com.anz.axle.falcon.MillenniumFalcon;
import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.um.OperationalModeValue;
import com.anz.markets.efx.messaging.transport.um.TransportValue;
import com.anz.markets.efx.messaging.transport.um.UmConfig;
import com.anz.markets.efx.messaging.transport.um.UmEndPointConfig;
import com.anz.markets.efx.messaging.transport.um.UmTransport;
import com.anz.markets.prophet.chime.OperatingHourChimeManager;
import com.anz.markets.prophet.chronicle.ChronicleByteReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.cache.CachingThrottlingConsumerFactory;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.app.importable.SchedulingConfig;
import com.anz.markets.prophet.config.business.FailSafeConfigManager;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.persistence.kdb.KdbConfigSubscriber;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.hedger.HedgerStatusManager;
import com.anz.markets.prophet.kdb.KdbCovCorrSubscriber;
import com.anz.markets.prophet.kdb.KdbEconNewsSubscriber;
import com.anz.markets.prophet.marketdata.ForwardPointOriginChooser;
import com.anz.markets.prophet.marketdata.ForwardPointOriginChooser.ForwardPointSource;
import com.anz.markets.prophet.marketdata.MarketDataProducer;
import com.anz.markets.prophet.messaging.TradeUmClient;
import com.anz.markets.prophet.messaging.LiquidityGatewayClient;
import com.anz.markets.prophet.positionrisk.BiasPositionControlProducer;
import com.anz.markets.prophet.positionrisk.HedgeCurrencyControlProducer;
import com.anz.markets.prophet.positionrisk.PositionAdjustmentProducer;
import com.anz.markets.prophet.positionrisk.PriceProducer;
import com.anz.markets.prophet.pricer.ManualSkewControlProducer;
import com.anz.markets.prophet.pricer.SkewCurrencyControlProducer;
import com.anz.markets.prophet.pricer.VolatilityControlProducer;
import com.anz.markets.prophet.pricer.wholesale.spreads.CovarianceFileReloadControlProducer;
import com.anz.markets.prophet.starfish.StartTimeStamper;
import com.anz.markets.prophet.starfish.TradeDuplicateChecker;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.ActivationAdjustmentProducer;
import com.anz.markets.prophet.syscontrol.HedgerFirewallResetProducer;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import com.anz.markets.prophet.syscontrol.PricingFirewallResetProducer;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.function.Consumer;

/**
 * All messages entering the prophet realm must have the eventTimeStampNS set!
 */
@EnableScheduling
@Configuration
@Import({BusinessConfig.class, SchedulingConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/starfish.in.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class StarfishInConfig extends JmxConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(StarfishInConfig.class);
    public static final int CHRONICLE_DF_TAILER_ID = 99;

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        Context.establishProperties(env);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.starin:8}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    @Bean
    public TradeDuplicateChecker tradeDuplicateChecker(final ProphetPersister prophetPersister) {
        return new TradeDuplicateChecker(prophetPersister.sink(MessageType.TRADE));
    }

    @Bean
    public LiquidityGatewayClient liquidityGatewayClientUM(final Connection umConnection,
                                                           final ConfigurationData configurationDataDefault,
                                                           final ProphetPersister prophetPersister,
                                                           final ForwardPointOriginChooser forwardPointOriginChooser,
                                                           @Value("${um.dontWaitForSnapshots:false}") final boolean dontWaitForSnapshots,
                                                           @Value("${um.ndfForwardHeartbeats:true}") final boolean ndfForwardHeartbeats,
                                                           @Value("${um.topicSuffix:}") String topicSuffix,
                                                           @Value("${um.subscribeAtStartup:true}") final boolean subscribeAtStartup) {

        final LiquidityGatewayClient liquidityGateway = new LiquidityGatewayClient(new IndexedConfigurationData(configurationDataDefault), dontWaitForSnapshots, ndfForwardHeartbeats,
                umConnection, topicSuffix, prophetPersister.sinkMarketData(), forwardPointOriginChooser.consumerOfForwardPointUM(), prophetPersister.sinkSelfDescribingBytes());

        if (subscribeAtStartup) {
            liquidityGateway.subscribeToVenueSpot();
            liquidityGateway.subscribeToD3ForwardPoints();
            liquidityGateway.subscribeToD3Spot();
            liquidityGateway.subscribeToVenueNDF1M();
        }
        return liquidityGateway;
    }

    @Bean
    public TradeUmClient umTradeClient(final MillenniumFalcon millenniumFalcon,
                                       final Consumer<Trade> tradeDuplicateChecker,
                                       @Value("${deal.topic}_") final String dealTopic,
                                       @Value("#{'${deal.origins}'.split(',')}") final List<String> dealOrigins,
                                       @Value("${deal.subscribeAtStartup:true}") final boolean subscribeAtStartup) {
        dealOrigins.replaceAll(dealTopic::concat);
        return new TradeUmClient(
                millenniumFalcon,
                tradeDuplicateChecker,
                dealOrigins,
                subscribeAtStartup
        );
    }

    @Bean //(destroyMethod = "shutdown")
    public MillenniumFalcon millenniumFalcon(@Value("#{'${um.unicast_resolvers}'.split(',')}") final List<String> unicastResolvers,
                                             @Value("#{${falcon.overrideProperties:T(java.util.Collections).emptyMap()}}") final Map<String, Map<String, String>> overrides) throws Exception {
        return MillenniumFalcon.start(unicastResolvers, overrides);
    }

    @Bean(destroyMethod = "close")
    public Connection umConnection(final UmConfig umConfig,
                                   @Value("${um.secondsToRetryEndpoint:10}") final long secondsToRetryEndpoint) {
        final PrecisionClock precisionClock = NanoClock.nanoClockUTC();
        final Transport transport = new UmTransport(precisionClock, umConfig);
        // creates poller thread
        return transport.openConnection(() -> { /**/ });
    }

    @Bean
    public UmConfig umConfig(@Value("${um.transport}") final TransportValue transport,
                             @Value("${um.operational_mode}") final OperationalModeValue operationalMode,
                             @Value("#{${um.default.context.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultContextAttributes,
                             @Value("#{${um.default.source.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultSourceAttributes,
                             @Value("#{${um.default.receiver.attribute:T(java.util.Collections).emptyMap()}}") final Map<String, Object> defaultReceiverAttributes,
                             @Value("#{'${um.unicast_resolvers}'.split(',')}") final Set<String> unicastResolvers) {
        final UmConfig config = new UmConfig() {
            private Set<String> translated = null;

            @Override
            public UmEndPointConfig getEndPointConfig() {
                return UmEndPointConfig.forSingleTransport(transport);
            }

            @Override
            public OperationalModeValue getOperationalMode() {
                return operationalMode;
            }

            @Override
            public long getProcessEventsMillis() {
                return 0; // TODO: work out what this is for
            }

            @Override
            public Map<String, ?> getDefaultContextAttributes() {
                return defaultContextAttributes;
            }

            @Override
            public Map<String, ?> getDefaultSourceAttributes() {
                return defaultSourceAttributes;
            }

            @Override
            public Map<String, ?> getDefaultReceiverAttributes() {
                return defaultReceiverAttributes;
            }

            @Override
            public Set<String> getResolverUnicastDaemons() {
                if (translated == null) {
                    translated = new LinkedHashSet<>();
                    for (String address : unicastResolvers) {
                        translated.add(hostAndPortToIpPort(address));
                    }
                }

                return translated;
            }
        };
        config.logInfo(LOGGER);
        return config;
    }

    public static String hostAndPortToIpPort(String hostAndPort) throws IllegalArgumentException {
        try {
            // using URI to parse the address precisely (will parse IPv4, IPv6, host:port, and more)
            URI uri = new URI("http://" + hostAndPort);

            String host = "";
            if (uri.getHost() == null) {
                throw new IllegalArgumentException("Unicast resolver address missing host = " + hostAndPort);
            } else {
                InetAddress inetAddress = InetAddress.getByName(uri.getHost());
                host = inetAddress.getHostAddress();
            }

            if (uri.getPort() == -1) {
                throw new IllegalArgumentException("Unicast resolver address missing port = " + hostAndPort);
            }

            return host + ":" + uri.getPort();
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Format error in unicast resolver address " + hostAndPort);
        } catch (UnknownHostException e) {
            throw new IllegalArgumentException("Unicast resolver host name not resolved: " + hostAndPort);
        }
    }

    // JMX
    @Bean
    public PositionAdjustmentProducer createPositionAdjustmentProducer(
            final ProphetPersister prophetPersister) {
        return new PositionAdjustmentProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.ADJUSTMENT)), StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.TRADE)));
    }

    @Bean
    public BiasPositionControlProducer createBiasPositionControlProducer(
            final ProphetPersister prophetPersister) {
        return new BiasPositionControlProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.BIAS_OFFSET_CONTROL)));
    }

    @Bean
    public HedgeCurrencyControlProducer createHedgeCurrencyControlProducer(
            final ProphetPersister prophetPersister) {
        return new HedgeCurrencyControlProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.HEDGE_CURRENCY_CONTROL)));
    }

    @Bean
    public CovarianceFileReloadControlProducer createCovarianceFileReloadControl(final KdbCovCorrSubscriber kdbCovarianceCorrelationSubscriber,
                                                                                 final ProphetPersister prophetPersister,
                                                                                 @Value("${file.analytic.loadCovarOnStartup.enabled:false}") final boolean reloadFileCovarOnStartup) {
        return new CovarianceFileReloadControlProducer(kdbCovarianceCorrelationSubscriber, StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.COV_CORR)), reloadFileCovarOnStartup);
    }

    @Bean
    public VolatilityControlProducer createVolatilityControlProducer(
            final ProphetPersister prophetPersister) {
        return new VolatilityControlProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.VOLATILITY_CONTROL)));
    }

    @Bean
    public SkewCurrencyControlProducer createSkewCurrencyControlProducer(
            final ProphetPersister prophetPersister) {
        return new SkewCurrencyControlProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.SKEW_CURRENCY_CONTROL)));
    }

    @Bean
    public ManualSkewControlProducer createManualSkewControlProducer(
            final ProphetPersister prophetPersister) {
        return new ManualSkewControlProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.MANUAL_SKEW_CONTROL)));
    }

    @Bean
    public ActivationAdjustmentProducer createActivationAdjustmentProducer(
            final ProphetPersister prophetPersister) {
        return new ActivationAdjustmentProducer(prophetPersister.sink(MessageType.ACTIVATE));
    }

    @Bean
    public PricingFirewallResetProducer createPricingFirewallResetProducer(
            final ProphetPersister prophetPersister) {
        return new PricingFirewallResetProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.PRICING_FIREWALL_RESET)));
    }

    @Bean
    public HedgerFirewallResetProducer createHedgerFirewallResetProducer(
            final ProphetPersister prophetPersister) {
        return new HedgerFirewallResetProducer(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.HEDGER_FIREWALL_RESET)));
    }

    @Bean
    public MarketDataProducer createMarketDataProducer(
            final ProphetPersister prophetPersister) {
        return new MarketDataProducer(StartTimeStamper.consumeBefore(prophetPersister.sinkMarketData()));
    }

    @Bean
    public PriceProducer createPriceProducer(
            final ProphetPersister prophetPersister) {
        return new PriceProducer(StartTimeStamper.consumeBefore(prophetPersister.sinkMarketData()));
    }

    @Bean
    public ForwardPointOriginChooser forwardPointOriginChooser(
            final ProphetPersister prophetPersister,
            final @Value("${forwardPoint.subscriptionMode:UM}") ForwardPointSource subscribeVia) {
        return new ForwardPointOriginChooser(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.FORWARD_POINT)), subscribeVia);
    }

    // KDB
    @Bean
    public KdbConfigSubscriber kdbConfigSubscriber(final ConfigurationData configurationData,
                                                   final FailSafeConfigManager failSafeConfigManager,
                                                   @Value("${kdb.host}") final String kdbConfigHost,
                                                   @Value("${kdb.config.port}") final int kdbConfigPort,
                                                   @Value("${kdb.credential}") final String kdbConfigCredential,
                                                   @Value("${kdb.config.enabled:true}") final boolean kdbConfigEnabled) throws Exception {
        // delegate to fail safe config manager.
        final KdbConfigSubscriber kdbConfigSubscriber = new KdbConfigSubscriber(
                kdbConfigHost, kdbConfigPort, kdbConfigCredential,
                (ConfigurationDataDefault) configurationData,
                failSafeConfigManager.consumerConfigurationData());

        if (kdbConfigEnabled) {
            kdbConfigSubscriber.start();
        } else {
            LOGGER.warn("KDB Config is not enabled. Will not receive snapshot or updates from kdb config. You can enable this by setting kdb.config.enabled property.");
        }
        return kdbConfigSubscriber;
    }

    @Bean
    // config distribution point in memory managers and then into chronicle persister
    public FailSafeConfigManager failSafeConfigManager(final ConfigurationDataDefault configurationDataDefault,
                                                       final OperatingHourChimeManager operatingHourChimeManager,
                                                       final LiquidityGatewayClient liquidityGatewayClientUM,
                                                       final ProphetPersister prophetPersister,
                                                       @Value("${fail.safe.config.manager.should.initialise.with.cache:true}") final boolean shouldInitialiseWithCache) {
        // persist last - only persist if all consumer process ok.
        final Consumer<IndexedConfigurationData> consumers = new NotifierDefault<>(
                operatingHourChimeManager.consumerOfIndexedConfigurationData(),
                liquidityGatewayClientUM.consumerIndexedConfigurationData(),
                indexedConfigurationData -> prophetPersister.sink(MessageType.CONFIGURATION).accept(indexedConfigurationData.getConfigurationData())
        );

        return FailSafeConfigManager.createInstance(shouldInitialiseWithCache, false, false, configurationDataDefault, null, consumers);
    }

    @Bean
    public KdbEconNewsSubscriber kdbEconNewsSubscriber(
            final ProphetPersister prophetPersister,
            @Value("${kdb.host}") final String kdbConfigHost,
            @Value("${kdb.tp.sub.port}") final int kdbConfigPort,
            @Value("${kdb.credential}") final String kdbConfigCredential,
            @Value("${kdb.news.subscriber.enabled:true}") final boolean kdbSubscriberEnabled) throws Exception {
        // need to ensure header is populated
        final KdbEconNewsSubscriber kdbEconNewsSubscriber = new KdbEconNewsSubscriber(kdbConfigHost, kdbConfigPort, kdbConfigCredential, prophetPersister.sink(MessageType.ECONNEWS));
        if (kdbSubscriberEnabled) {
            kdbEconNewsSubscriber.start();
        }
        return kdbEconNewsSubscriber;
    }

    @Bean
    public KdbCovCorrSubscriber kdbCovarianceCorrelationSubscriber(
            final ProphetPersister prophetPersister,
            @Value("${kdb.host:}") final String kdbConfigHost,
            @Value("${kdb.analytic.port:}") final int kdbConfigPort,
            @Value("${kdb.credential}") final String kdbConfigCredential,
            @Value("${kdb.analytic.covar.subscriber.enabled:false}") final boolean kdbCovarSubscriberEnabled,
            @Value("${kdb.analytic.saveCovarFile.name:./conf/covar.%s.properties}") final String saveCovarFilename,
            @Value("${kdb.analytic.saveCovarFile.enabled:true}") final boolean enableSaveCovarFile) throws Exception {

        final KdbCovCorrSubscriber kdbCovCorrSubscriber = new KdbCovCorrSubscriber(kdbConfigHost, kdbConfigPort, kdbConfigCredential, prophetPersister.sink(MessageType.COV_CORR),
                saveCovarFilename, enableSaveCovarFile);
        if (kdbCovarSubscriberEnabled) {
            kdbCovCorrSubscriber.start();
        }
        return kdbCovCorrSubscriber;
    }

    // chronicle.in
    @Bean
    public ProphetPersister inboundChroniclePersister(
            @Value("${chronicle.in.path:./chronicle.in}") final String inChroniclePath,
            @Value("${chronicle.ringBufferEnabled.starin2core:NO_RING}") final RingBuffer ringBuffer,
            @Value("${chronicle.open.mode:APPEND}") final LegacyChroniclePersister.OpenMode openMode) throws IOException {
        // append everything to the chronicle as currently we don't have any incoming eventId or
        // sequence number to use to determine where we are in vs out

        Context.instance((byte) 0);
        Context.stage(Stage.STARFISHIN);

        return ChroniclePersisterFactory.createStarInPersister(inChroniclePath, openMode, ringBuffer);
    }

    // chronicle.df read and passthrough to chronicle.in
    @Bean
    public ProphetReader fromDatafabricChronicleReader(
            @Value("${chronicle.df.path:./chronicle.df}") final String chronicleFromDatafabricPath,
            final ProphetPersister prophetPersister,
            final ForwardPointOriginChooser forwardPointOriginChooser,
            final TradeDuplicateChecker tradeChecker,
            @Value("${cache.spots:false}") final boolean cacheSpotDates,
            @Value("${cache.forwards:false}") final boolean cacheForwardPoints) throws IOException {

        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.SPOT_DATE, new ChronicleReaderGeneric<>(new SpotDateImpl(), prophetPersister.sink(MessageType.SPOT_DATE)));
        map.put(MessageType.FORWARD_POINT, new ChronicleReaderGeneric<>(new ForwardPointImpl(), forwardPointOriginChooser.consumerOfForwardPoint()));
        map.put(MessageType.TRADE, new ChronicleReaderGeneric<>(new TradeImpl(), t -> {
                LOGGER.info("Received trade from DF: {}", t.getOrderId());
                tradeChecker.accept(t);
        }));

        if (cacheSpotDates) { //override with equality check throttler.
            map.put(MessageType.SPOT_DATE,
                    new ChronicleReaderGeneric<>(new SpotDateImpl(),
                            CachingThrottlingConsumerFactory.forSpotDate(prophetPersister.sink(MessageType.SPOT_DATE))));
        }
        if (cacheForwardPoints) { //override with equality check throttler.
            map.put(MessageType.FORWARD_POINT,
                    new ChronicleReaderGeneric<>(new ForwardPointImpl(),
                            CachingThrottlingConsumerFactory.forForwardPoint(forwardPointOriginChooser.consumerOfForwardPoint())));
        }
        final ChronicleByteReader passThrough = new ChronicleByteReader(prophetPersister.sinkRawBytes());
        final ChronicleObjectReaderMulti objectReaderMulti = new ChronicleObjectReaderMulti(map, passThrough);

        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("chronicle-read-df").build();
        final ExecutorService executorService = Executors.newFixedThreadPool(1, threadFactory);
        return ChronicleReaderFactory.createStarInReader(executorService, objectReaderMulti, chronicleFromDatafabricPath, CHRONICLE_DF_TAILER_ID);
    }

    // JMX hedger status manager
    @Bean
    public HedgerStatusManager createHedgeStatusManager(
            final ProphetPersister prophetPersister) {
        return new HedgerStatusManager(StartTimeStamper.consumeBefore(prophetPersister.sink(MessageType.HEDGE_CONTROL)));
    }
}
