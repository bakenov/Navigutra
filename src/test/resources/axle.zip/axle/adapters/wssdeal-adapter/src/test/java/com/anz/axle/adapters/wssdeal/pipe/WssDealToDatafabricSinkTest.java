package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.messaging.types.PDMessage;
import com.anz.axle.common.AbstractUnitTest;
import com.anz.axle.datafabric.client.wss.WssDealService;
import com.anz.axle.wss.domain.WssDeal;
import org.jmock.Expectations;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by talwarg on 18/02/2015.
 */
public class WssDealToDatafabricSinkTest  extends AbstractUnitTest {

    private WssDealToDatafabricSink wssDealToDatafabricSink;

    @Before
    public void SetUp(){
        wssDealToDatafabricSink = new WssDealToDatafabricSink();
    }

    @Test
    public void testOnMessage(){
        final WssDealService wssDealService = mock(WssDealService.class);
        final WssDeal wssDeal = new WssDeal();
        final PDMessage<WssDeal> wssDealPDMessage = new PDMessage<WssDeal>("1",wssDeal);

        checking(new Expectations() {
            {
                oneOf(wssDealService).validateAndSave(wssDeal);
            }});
        wssDealToDatafabricSink.setWssDealService(wssDealService);
        wssDealToDatafabricSink.onMessage(wssDealPDMessage);

    }

}
