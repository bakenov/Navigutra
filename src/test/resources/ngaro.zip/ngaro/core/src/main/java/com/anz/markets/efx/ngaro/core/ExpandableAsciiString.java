package com.anz.markets.efx.ngaro.core;

import java.util.Arrays;

public final class ExpandableAsciiString implements MutableAsciiString {

    public static final int DEFAULT_INITIAL_CAPACITY = 16;

    private byte[] value;
    private int length;

    public ExpandableAsciiString() {
        this(DEFAULT_INITIAL_CAPACITY);
    }
    public ExpandableAsciiString(final int initialCapacity) {
        this.value = new byte[initialCapacity];
        this.length = 0;
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only if byte array capacity needs to be increased (usually doubled)")
    public ExpandableAsciiString ensureCapacity(final int capacity) {
        if (capacity > value.length) {
            final int newCapacity = Math.max(capacity, 2 * value.length);
            value = Arrays.copyOf(value, newCapacity);
        }
        return this;
    }

    public int capacity() {
        return value.length;
    }

    @Override
    public int length() {
        return length;
    }

    @Override
    public byte get(final int index) {
        if (index > length) {
            throw new IndexOutOfBoundsException("Index greater than length: " + index + " > " + length);
        }
        return value[index];
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only if byte array capacity needs to be increased (usually doubled)")
    @Override
    public ExpandableAsciiString set(final int index, final byte b) {
        if (b != NULL) {
            ensureCapacity(index + 1);
            value[index] = b;
            length = Math.max(length, index + 1);
        } else {
            if (index < 0) {
                throw new IndexOutOfBoundsException("Negative index: " + index);
            }
            if (index < length) {
                //setting NULL actually shortens the string
                Arrays.fill(value, index, length, NULL);
                this.length = index;
            }//else: NULL is ignored
        }
        return this;
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only if byte array capacity needs to be increased (usually doubled)")
    @Override
    public ExpandableAsciiString append(final byte b) {
        if (b != NULL) {
            ensureCapacity(length + 1);
            value[length] = b;
            length++;
        }
        return this;
    }

    @Override
    public <T> int get(final T target, final ByteWriter<? super T> writer, final int offset, final int maxLength) {
        final int copyLen = Math.min(length, maxLength);
        Bytes.copy(value, ByteReader.BYTE_ARRAY, 0, target, writer, offset, copyLen);
        return copyLen;
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only if byte array capacity needs to be increased (usually doubled)")
    @Override
    public <S> ExpandableAsciiString set(final S source, final ByteReader<? super S> reader, final int offset, final int length) {
        ensureCapacity(length);
        int index;
        for (index = 0; index < length; index++) {
            final byte b = reader.readByte(source, offset + index);
            if (b != NULL) {
                value[index] = b;
            } else {
                break;
            }
        }
        if (index < this.length) {
            Arrays.fill(value, index, value.length, NULL);
        }
        this.length = index;
        return this;
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only if byte array capacity needs to be increased (usually doubled)")
    @Override
    public <S> ExpandableAsciiString append(final S source, final ByteReader<? super S> reader, final int offset, final int length) {
        ensureCapacity(this.length + length);
        final int targetOffset = this.length;
        int index;
        for (index = 0; index < length; index++) {
            final byte b = reader.readByte(source, offset + index);
            if (b != NULL) {
                value[targetOffset + index] = b;
            } else {
                break;
            }
        }
        this.length += index;
        return this;
    }

    @Override
    public ExpandableAsciiString clear() {
        Arrays.fill(value, 0, length, NULL);
        length = 0;
        return this;
    }

    @Override
    public int hashCode() {
        return AsciiString.hashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
        return ImmutableAsciiString.equals(this, obj);
    }

    @Override
    @Garbage(Garbage.Type.RESULT)
    public String toString() {
        return new String(value, 0, length);
    }

    //override to return subtype

    @Override
    public ExpandableAsciiString set(final AsciiString value) {
        MutableAsciiString.super.set(value);
        return this;
    }
    @Override
    public ExpandableAsciiString append(final AsciiString value) {
        MutableAsciiString.super.append(value);
        return this;
    }
    @Override
    public ExpandableAsciiString set(final CharSequence value) {
        MutableAsciiString.super.set(value);
        return this;
    }
    @Override
    public ExpandableAsciiString append(final CharSequence value) {
        MutableAsciiString.super.append(value);
        return this;
    }
}
