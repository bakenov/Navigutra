package com.anz.markets.efx.fox.processor.state.sweeper;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.validator.InstrumentParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.MarketsParameterParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.OrderQuantityParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.OrderTypeParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.TimeInForceParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.UserSessionParentOrderValidator;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

import java.util.Objects;

public class DefaultParentOrderValidator implements ParentOrderValidator.NamedValidator {
    private final ParentOrderValidator[] validators;

    public DefaultParentOrderValidator(final ErrorHandler errorHandler, final InstrumentRepository instrumentRepository) {
        Objects.requireNonNull(errorHandler);

        validators = new ParentOrderValidator[]{
                new InstrumentParentOrderValidator(errorHandler, instrumentRepository),
                new MarketsParameterParentOrderValidator(errorHandler, instrumentRepository),
                new TimeInForceParentOrderValidator(errorHandler, TimeInForce.GTC, TimeInForce.DAY, TimeInForce.IOC, TimeInForce.FOK, TimeInForce.GTD),
                new OrderTypeParentOrderValidator(errorHandler, OrderType.LIMIT, OrderType.MARKET),
                new OrderQuantityParentOrderValidator(errorHandler),
                new UserSessionParentOrderValidator(errorHandler)
        };
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
        for(int idx=0; idx<validators.length; idx++) {
            if (!validators[idx].validate(parentOrderDecoder, commandContext))
                return false;
        }

        return true;

    }

    @Override
    public String name() {
        return DefaultParentOrder.STRATEGY_NAME;
    }
}
