package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PassthroughSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.StandardMarketSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class ModelSpread_NDF_Passthrough_Test extends BaseAcceptanceSpecification {
    private double d3Spread;
    private Instrument driverPairA;

    @RestartBeforeTest(reason="reset config")
    @Test
    public void generate_client_price_ndf_onshore() throws Exception {

        driverPairA = Instrument.USDINR;
        d3Spread = 0.0015;

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setMinimumMarketsFilterConfigs(Arrays.asList(
                        new MinimumMarketFilterConfigImpl(Instrument.ANY, 2),
                        new MinimumMarketFilterConfigImpl(Instrument.USDINR, 1),
                        new MinimumMarketFilterConfigImpl(Instrument.AUDUSD, 1)
                ))
                .setPassthroughSpreadConfigs(Arrays.asList(
                        new PassthroughSpreadConfig(Market.WSP_A, Instrument.USDINR)
                ))
                .setClientSpreadConfigs(Arrays.asList(
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDINR, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDINR, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDINR, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDINR, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDINR, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDINR, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDINR, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDINR, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6)
                ));

        final List<InstrumentConfig> instrumentConfigs = new ArrayList<>((configuration.getInstrumentConfigs()));
        instrumentConfigs.add(new InstrumentConfigImpl(Instrument.AUDINR).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1));
        configuration.setInstrumentConfigs(instrumentConfigs);

        final List<SyntheticWideningFactor> syntheticConfigs = new ArrayList<>(configuration.getSyntheticWideningFactors());
        syntheticConfigs.add(SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.INR, Market.WSP_A, 1.0));
        configuration.setSyntheticWideningFactors(syntheticConfigs);

        final List<SyntheticInstrumentConfig> syntheticInstrumentConfigs = new ArrayList<>(configuration.getSyntheticInstrumentConfigs());
        syntheticInstrumentConfigs.add(new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDINR).setMarkets(Market.WSP_A.name()));
        configuration.setSyntheticInstrumentConfigs(syntheticInstrumentConfigs);

        given:
        {
            prophet.receive(configuration);
            prophet.receive(new SpotDateImpl(Instrument.AUDUSD, LocalDate.now().plusDays(2)));
            prophet.receive(new SpotDateImpl(Instrument.USDINR, LocalDate.now().plusDays(2)));
            prophet.receive(new SpotDateImpl(Instrument.AUDINR, LocalDate.now().plusDays(2)));
            prophet.receive(tdd.marketDataSnapshot(Market.D3, driverPairA, 65.132, 0.004));
        }
        when:
        // marketDataSnapshot generated with spread less than 1mio client spread config
        {
            prophet.clearOutputBuffer();
            // marketDataSnapshot is generated onto starin when receiving d3 "fwd point"
            prophet.receive(tdd.marketDataSnapshot(Market.D3, driverPairA, 65.130, d3Spread));
        }
        then:
        {
            // D3 spread of 0.15
            // Overall Widening Factor = 0.15/config base spread(0.4) = 0.375
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbf.getOverallWideningFactor(), isRoundedTo(0.375));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice.getSpread(), isRoundedTo(d3Spread));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 65.1292500, 65.1307500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 65.1286875, 65.1313125));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 65.1279375, 65.1320625));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 65.1277500, 65.1322500));
        }
        when:
        // verify passthrough driver can be used to generate cross pairs
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.6500, 0.0004));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDINR, Market.WSP_A));
        }
        when:
        // throttle heartbeat set to 20sec in TestDataDictionaryImpl
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20000);
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A));
        }
        when:
        // AXPROPHET-1252 Manual global/market volatility to exclude passthrough instruments
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, 4d));
            prophet.receive(tdd.setManualGlobalVol(3d));
            prophet.receive(tdd.setManualCcyVol(Currency.INR, 2d));
        }
        then:
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA, Market.WSP_A)).getLast();
            assertThat(wbfA.getVolatilityWideningFactorManual(), isNear(2.0));
            assertThat(wbfA.getOverallWideningFactor(), isRoundedTo(0.375 * 2.0));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getLast();
            assertThat(clientPrice.getSpread(), isRoundedTo(d3Spread * 2.0));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 65.12850, 65.131500));
        }
        and:
        // reset manual volatility
        {
            prophet.receive(tdd.setManualGlobalVol(Double.NaN));
            prophet.receive(tdd.setManualCcyVol(Currency.INR, Double.NaN));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, Double.NaN));
        }
    }

    @Test
    // AXPROPHET-1189 config to allow local market instruments to use pass through strategy for specified markets
    public void use_pass_through_strategy_for_local_market_ccy() throws Exception {

        driverPairA = Instrument.USDHRK;
        d3Spread = 0.0015;

        given:
        {
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Arrays.asList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_Z, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.LOCAL_MARKET_PASSTHROUGH_MODELS, new Market[]{Market.WSP_A, Market.WSP_C})
                    );

            final List<MarketConfig> marketConfigs = new ArrayList<>(configurationDataDefault.getMarketConfigs());
            marketConfigs.add(new MarketConfigImpl(Market.D3).setRegion(GB).setInstrument(driverPairA).setEnabled(true));
            configurationDataDefault.setMarketConfigs(marketConfigs);
            configurationDataDefault.addAggBook(Market.WSP_U,driverPairA, TradingTimeZone.GLOBAL, Region.GB,Market.D3);

            final List<StandardMarketSpreadConfig> stdMktSpreads = new ArrayList<>(configurationDataDefault.getStandardMarketSpreadConfigs());
            stdMktSpreads.add(new StandardMarketSpreadConfigImpl(driverPairA, 0.0025, 0.0, 0.0, 0.0, 0.0, 0.0025, 0.0, 0.0, 0.0));
            configurationDataDefault.setStandardMarketSpreadConfigs(stdMktSpreads);

            final List<InstrumentConfig> instrumentConfigs = new ArrayList<>(configurationDataDefault.getInstrumentConfigs());
            instrumentConfigs.add(new InstrumentConfigImpl(driverPairA).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(0).setPrecisionMultiplier(1).setSpreadMultiplier(0));
            configurationDataDefault.setInstrumentConfigs(instrumentConfigs);

            final List<ClientPriceThrottleConfig> throttleConfigs = new ArrayList<>(configurationDataDefault.getClientPriceThrottleConfigs());
            throttleConfigs.add(new ClientPriceThrottleConfigImpl(Market.ANY, Currency.USD, Currency.HRK)
                    .setNoActivityHeartbeatFrequencyMs(20000)
                    .setStartStopTimePeriodMS(0)
                    .setLimit(2)
                    .setTimePeriod(2)
                    .setMinimumPriceDeltaFractionOfSpread(0.01)
                    .setMinimumPriceDeltaFractionOfPreviousSpread(0.01)
                    .setOverrideLimit(2)
                    .setOverrideTimePeriod(2)
                    .setOverrideMinimumPriceDeltaFractionOfMid(0.000001)
                    .setMinimumPriceDeltaFractionOfPreviousSpread(0.001));
            configurationDataDefault.setClientPriceThrottleConfigs(throttleConfigs);


            prophet.receive(configurationDataDefault);

            prophet.receive(tdd.marketDataSnapshot(Market.D3, driverPairA, 65.132, 0.004));
        }
        when:
        // marketDataSnapshot generated with spread less than 1mio client spread config
        {
            prophet.incrementTime(1000); // to get around the throttler
            prophet.clearOutputBuffer();

            // marketDataSnapshot is generated onto starin when receiving d3 "fwd point"
            prophet.receive(tdd.marketDataSnapshot(Market.D3, driverPairA, 65.130, d3Spread));
        }
        then:
        // Only Markets WSP_A and WSP_C enabled for "local market passthrough" strategy
        {
            // Passthrough calculations:
            // D3 spread of 0.15
            // Overall Widening Factor = 0.15/config base spread(0.4) = 0.375
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbfA.getOverallWideningFactor(), isRoundedTo(0.375));

            WholesaleBookFactors wbfB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getLast();
            assertThat(wbfB.getOverallWideningFactor(), isRoundedTo(1.0));

            WholesaleBookFactors wbfC = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_C)).getLast();
            assertThat(wbfC.getOverallWideningFactor(), isRoundedTo(0.375));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getLast();
            assertThat(clientPrice.getBids().size(), is(4));
            assertThat(clientPrice.getSpread(), isRoundedTo(d3Spread));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 65.1292500, 65.1307500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_3M, 65.1286875, 65.1313125));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_5M, 65.1279375, 65.1320625));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_10M, 65.1277500, 65.1322500));
        }
        when:
        // AXPROPHET-1252 Manual global/market volatility to exclude passthrough instruments
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, 4d));
            prophet.receive(tdd.setManualGlobalVol(3d));
            prophet.receive(tdd.setManualCcyVol(Currency.HRK, 2d));
        }
        then:
        {
            WholesaleBookFactors wbfA = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getLast();
            assertThat(wbfA.getVolatilityWideningFactorManual(), isNear(2.0));
            assertThat(wbfA.getOverallWideningFactor(), isRoundedTo(0.375 * 2.0));

            WholesaleBookFactors wbfB = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_B)).getLast();
            assertThat(wbfB.getVolatilityWideningFactorManual(), isNear(3.0));
            assertThat(wbfB.getOverallWideningFactor(), isRoundedTo(3.0));

            ClientPrice clientPriceA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getLast();
            assertThat(clientPriceA.getSpread(), isRoundedTo(d3Spread * 2.0));
            assertThat(clientPriceA, isClientPricePoint(0, Level.QTY_1M, 65.12850, 65.131500));

            ClientPrice clientPriceB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_B)).getLast();
            assertThat(clientPriceB.getSpread(), isRoundedTo(0.004 * 3.0));
        }
        and:
        // reset manual volatility
        {
            prophet.receive(tdd.setManualGlobalVol(Double.NaN));
            prophet.receive(tdd.setManualCcyVol(Currency.HRK, Double.NaN));
            prophet.receive(tdd.setManualMarketVol(Market.WSP_A, Double.NaN));
        }
    }
}
