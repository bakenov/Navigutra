package com.anz.axle.lg.adapter.rfx.uat;

import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.rfx.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.rfx.session.LogonManager;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.axle.lg.adapter.rfx.session.fsm.fix.FixStateMachine.SessionType;
import static com.anz.axle.lg.adapter.rfx.session.fsm.fix.FixStateMachine.State.FINAL_LOGOUT;
import static com.anz.axle.lg.adapter.rfx.session.fsm.fix.FixStateMachine.State.LOGON;
import static com.anz.axle.lg.adapter.rfx.session.fsm.fix.FixStateMachine.State.LOGOUT;
import static com.anz.markets.efx.trading.codec.api.ExecType.CANCELED;
import static com.anz.markets.efx.trading.codec.api.ExecType.NEW;
import static com.anz.markets.efx.trading.codec.api.ExecType.PENDING_CANCEL;
import static com.anz.markets.efx.trading.codec.api.ExecType.TRADE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RfxUatIntegrationTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(RfxUatIntegrationTest.class);
    private static final char BUY = com.anz.axle.lg.adapter.rfx.chroniclefix.generated.fields.Side.BUY;
    private static final char SELL = com.anz.axle.lg.adapter.rfx.chroniclefix.generated.fields.Side.SELL;

    private static final double PASSIVE_BID = 1.0;
    private static final double CROSSING_BID = 1.3;

    @Rule
    public final TestName testName = new TestName();
    private Application application;
    private SharedAcceptanceContext acceptanceContext;
    private LogonManager logonManager;
    private UatConfiguration configuration;

    private Venue venue;
    private String clOrdId;
    private String origClOrdId;
    private Side side;
    private OrderType orderType;
    private double orderQty = 3300000;
    private boolean orderSent;
    private char autoLogon = 'N';
    private int maxNumberLogonAttempts = 3;
    private int timeInSecsBetweenLogonAttempts = 10;
    private int numberLogonEvents;
    private boolean rfaLogon;

    private CountDownLatch orderLatch;
    private CountDownLatch logoutLatch;
    private CountDownLatch rfaLatch;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        venue = Venue.RFX;
        configuration = UatConfiguration.BURGUNDY;
        orderSent = false;

        final String path = "target/rfx";
        final String fixFilePath = path + "/log/";
        final String fixStorePath = path + "/store/";
        final String passwordFile = path + "/" + venue.name() + "-passwords.properties";
        System.out.println("PASSWORD_FILE=" + new File(passwordFile).getAbsolutePath());
        System.setProperty("rfx.fix.user.password.file", new File(passwordFile).getAbsolutePath());

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + venue.name().toLowerCase() +
                                ",venue:" + venue.name() +
                                ",appOptions:--reset" +
                                ",ConnectionType:initiator" +
                                "," + "rfx.fix.socket.use.ssl:N" +
                                "," + "rfx.fix.log.destination:STDOUT" +
                                "," + "rfx.fix.file.log.path:" + fixFilePath +
                                "," + "default.log.level:DEBUG" +
                                "," + "LOG_LEVEL:DEBUG" +
                                "," + "rfx.fix.file.store.path:" + fixStorePath +
                                "," + "rfx.fix.log_all:true" +
                                "," + "chronicle.fix.logging:true" +
                                "," + "rfx.fix.reconnectInterval:1" +
                                "," + "rfx.fix.maxNumLogonAttempts:" + maxNumberLogonAttempts +
                                "," + "rfx.fix.timeBetweenLogonAttemptsInSec:" + timeInSecsBetweenLogonAttempts +
                                "," + "rfx.fix.chronicle.autologon:" + autoLogon +
                                "," + "rfx.fix.logon.appl.extid:" + 100 +
                                "," + "rfx.fix.logon.default.appl.extid:" + 100 +
                                "," + "rfx.fix.logon.default.appl.verid:9" +
                                "," + "messaging.source.id:" + 310
                ));

        configuration.updateSystemProperties();

        application = new Application("lg-rfx-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
        logonManager = application.getApplicationContext().getBean("logonManager", LogonManager.class);
        orderLatch = new CountDownLatch(1);
        rfaLatch = new CountDownLatch(1);
    }

    @After
    public void afterEach() {
        waitForStop(application, 5, 500, testName.getMethodName());
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private void closeSession() throws Exception {
        LOGGER.info("closing Fix Session ...");
        logoutLatch = new CountDownLatch(1);
        logonManager.closeFixSession();
        logoutLatch.await(5, TimeUnit.SECONDS);
    }

    @Test
    public void rfa_login_and_exit() throws Exception {
        LOGGER.info("\\---------------- START TEST: {}", testName.getMethodName());
        logonManager.setSessionStateConsumer((session, state) -> {
            System.out.println("TEST    ******************************************   session=" + session + "    " + state);
            if (session == SessionType.RFA && state == LOGOUT) {
                if (state == LOGON)
                    rfaLogon = true;
                else
                    rfaLogon = false;
                rfaLatch.countDown();
            }
        });
        rfaLatch.await(60, TimeUnit.SECONDS);
        if (rfaLogon) {
            System.out.println("WAITING    ******************************************   pricing processing");
            rfaLatch = new CountDownLatch(1);
            rfaLatch.await(180, TimeUnit.SECONDS);
        }
        System.out.println("TEST    ******************************************   closing sessions");
        closeSession();
    }


//    @Test
    public void trading_login_and_exit() throws Exception {
        LOGGER.info("\\---------------- START TEST: {}", testName.getMethodName());
        logonManager.setSessionStateConsumer((session, state) -> {
            System.out.println("TEST    ******************************************   session=" + session + "    " + state);
            if (session == SessionType.FIX && state == FINAL_LOGOUT) {
                if (logoutLatch != null)
                    logoutLatch.countDown();
            } else if (session == SessionType.TRADING && state == LOGON) {
                orderLatch.countDown();
            } else if (session == SessionType.RFA && state == LOGOUT) {
                if (state == LOGON)
                    rfaLogon = true;
                else
                    rfaLogon = false;
                rfaLatch.countDown();
            }

            if (state == LOGON) {
                numberLogonEvents++;
            }
        });
        rfaLatch.await(60, TimeUnit.SECONDS);

        orderLatch.await(60, TimeUnit.SECONDS);
        assertEquals("numberLogonEvents", 2, numberLogonEvents);
        System.out.println("WAITING    ******************************************   pricing processing");
        orderLatch = new CountDownLatch(1);
        orderLatch.await(180, TimeUnit.SECONDS);
        System.out.println("TEST    ******************************************   closing sessions");
        closeSession();
    }

//    @Test
    public void login_send_cross_spread_order() throws Exception {
        LOGGER.info("\\---------------- START TEST: {}", testName.getMethodName());
        logonManager.setTradingMonitorListener((b) -> {
            System.out.println("login_send_cross_spread_order()    trading monitor state: " + b);
            if (b) {
                origClOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
                side = Side.BUY;
                orderType = OrderType.LIMIT;
                NewOrderSingle newOrderSingle = newOrderSingle(origClOrdId, orderType, side, CROSSING_BID, orderQty);
                acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
                orderSent = true;
                orderLatch.countDown();
            }
        });

        orderLatch.await(20, TimeUnit.SECONDS);
        assertTrue(orderSent);
        assertExecutionReport(side, origClOrdId, null, NEW);
        assertExecutionReport(side, origClOrdId, null, TRADE, 5);
        System.out.println("TEST    ******************************************   closing sessions");
        closeSession();
    }

//    @Test
    public void login_send_passive_order_and_cancel() throws Exception {
        LOGGER.info("\\---------------- START TEST: {}", testName.getMethodName());
        logonManager.setTradingMonitorListener((b) -> {
            System.out.println("login_send_passive_order_and_cancel()    trading monitor state: " + b);
            if (b) {
                origClOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
                side = Side.BUY;
                orderType = OrderType.LIMIT;
                NewOrderSingle newOrderSingle = newOrderSingle(origClOrdId, orderType, side, PASSIVE_BID, orderQty);
                acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
                orderSent = true;
                orderLatch.countDown();
            }
        });

        orderLatch.await(20, TimeUnit.SECONDS);
        assertTrue(orderSent);
        assertExecutionReport(side, origClOrdId, null, NEW);
        clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        OrderCancelRequest cancelRequest = cancelOrderRequest(clOrdId, origClOrdId, orderType, side, PASSIVE_BID, orderQty);
        acceptanceContext.tradingRequestMessageQueue().add(cancelRequest);
        assertExecutionReport(side, origClOrdId, null, PENDING_CANCEL, 1);
        assertExecutionReport(side, origClOrdId, null, CANCELED, 1);
        System.out.println("TEST    ******************************************   closing sessions");
        closeSession();
    }

    private NewOrderSingle newOrderSingle(final String clOrdId, final OrderType orderType, Side side, double price, double qty) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.senderCompId = configuration.getSenderCompId();
        newOrderSingle.body.targetCompId = configuration.getTargetCompId();
        newOrderSingle.body.messageId = System.currentTimeMillis();
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.symbol = "eurusd";
        newOrderSingle.body.currency = "eur";
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.settlType = Tenor.SP;
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = qty;
        newOrderSingle.body.side = side;
        newOrderSingle.body.timeInForce = TimeInForce.DAY;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private OrderCancelRequest cancelOrderRequest(final String clOrdId, final String origClOrdId, final OrderType orderType, Side side, double price, double qty) {
        final OrderCancelRequest cancelRequest = new OrderCancelRequest();
        cancelRequest.body.clOrdId = clOrdId;
        cancelRequest.body.origClOrdId = origClOrdId;
        cancelRequest.body.senderCompId = configuration.getSenderCompId();
        cancelRequest.body.targetCompId = configuration.getTargetCompId();
        cancelRequest.body.messageId = System.currentTimeMillis();
        cancelRequest.body.ordType = orderType;
        cancelRequest.body.symbol = "eurusd";
        cancelRequest.body.securityType = SecurityType.FXSPOT;
        cancelRequest.body.settlType = Tenor.SP;
        cancelRequest.body.orderQty = qty;
        cancelRequest.body.side = side;
        cancelRequest.body.timeInForce = TimeInForce.DAY;
        cancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
        return cancelRequest;
    }


    private void assertExecutionReport(final Side side, final String clOrdId, final OrderType orderType, final ExecType execType) throws Exception {
        assertExecutionReport(side, clOrdId, orderType, execType, 0L);
    }

    private void assertExecutionReport(final Side side, final String clOrdId, final OrderType orderType, final ExecType execType, final long sleepBefore) throws Exception {
        TimeUnit.SECONDS.sleep(sleepBefore);

        final ExecutionReportMatcher matcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.marketId().eq(venue.name()))
                .body().matches(ExecutionReportMatcher.side().eq(side));
        if (orderType != null)
            matcher.body().matches(ExecutionReportMatcher.ordType().eq(orderType));
        switch (execType) {
            case NEW:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW));
                break;
            case TRADE:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED));
                break;
            case CANCELED:
                matcher
                        .body().matches(ExecutionReportMatcher.execType().eq(CANCELED))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.CANCELED));
                break;
        }

        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(matcher)
                .awaitMatchAndGetLast(30, TimeUnit.SECONDS);
    }

}