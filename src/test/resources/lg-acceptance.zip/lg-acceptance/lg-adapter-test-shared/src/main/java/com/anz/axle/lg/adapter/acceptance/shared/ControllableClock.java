package com.anz.axle.lg.adapter.acceptance.shared;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import com.anz.axle.microtime.PrecisionClock;

/**
 * Precision clock that can be controlled from a test if desired.  Default returns a constant time.
 */
public class ControllableClock extends Clock implements PrecisionClock {

    public static final long DEFAULT_CONSTANT_TIME_NANOS = 1500000000000000000L;

    private final ZoneId zoneId;
    private final LongSupplier nanoSource;

    public ControllableClock() {
        this(DEFAULT_CONSTANT_TIME_NANOS);
    }

    public ControllableClock(final long constantTimeNanos) {
        this(ZoneId.systemDefault(), constantTimeNanos);
    }

    public ControllableClock(final LongSupplier nanoSource) {
        this(ZoneId.systemDefault(), nanoSource);
    }

    public ControllableClock(final ZoneId zoneId, final long constantTimeNanos) {
        this(zoneId, () -> constantTimeNanos);
    }

    public ControllableClock(final ZoneId zoneId, final LongSupplier nanoSource) {
        this.zoneId = Objects.requireNonNull(zoneId);
        this.nanoSource = Objects.requireNonNull(nanoSource);
    }

    @Override
    public ZoneId getZone() {
        return zoneId;
    }

    @Override
    public Clock withZone(final ZoneId zoneId) {
        if (zoneId.equals(this.zoneId)) {
            return this;
        }
        return new ControllableClock(zoneId, nanoSource);
    }

    @Override
    public long millis() {
        return TimeUnit.NANOSECONDS.toMillis(nanos());
    }

    @Override
    public long micros() {
        return TimeUnit.NANOSECONDS.toMicros(nanos());
    }

    @Override
    public long nanos() {
        return nanoSource.getAsLong();
    }

    @Override
    public Instant instant() {
        return Instant.ofEpochSecond(0L, nanos());
    }

}
