package com.anz.markets.prophet.atest.framework;

import com.anz.markets.prophet.domain.chronicle.Header;

public class Output<T> {
    public final OutputSource source;
    public final Header header;
    public final T data;

    public Output(final Header header,
                  final T data,
                  final OutputSource source) {
        this.header = header;
        this.data = data;
        this.source = source;
    }

    @Override
    public String toString() {
        return "Output{" +
                "source=" + source +
                ", header=" + header +
                ", data=" + data +
                '}';
    }
}
