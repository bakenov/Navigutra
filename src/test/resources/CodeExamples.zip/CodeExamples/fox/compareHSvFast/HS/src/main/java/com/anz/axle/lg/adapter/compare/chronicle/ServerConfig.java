package com.anz.axle.lg.adapter.hsp.chronicle;

import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.CommonConfig;
import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.lg.adapter.hsp.chroniclefix.TradingConfig;
import com.anz.axle.lg.adapter.hsp.chronicleitch.PricingConfig;
import com.anz.axle.lg.adapter.hsp.chronicleitch.PricingSubscriptionConfig;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
@Import({
        CommonConfig.class,
        HspConfig.class,
        PricingConfig.class,
        TradingConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PricingSubscriptionConfig.class
})
public class ServerConfig {

    private final Service itchEngine;
    private final Service fixEngine;
    private final Connection connection;
    private final Service mainEventLoop;

    public ServerConfig(final Service itchEngine,
                        final Service fixTradingEngine,
                        final Connection connection,
                        final Service mainEventLoop) {
        this.itchEngine = Objects.requireNonNull(itchEngine);
        this.fixEngine = Objects.requireNonNull(fixTradingEngine);
        this.connection = Objects.requireNonNull(connection);
        this.mainEventLoop = Objects.requireNonNull(mainEventLoop);
    }

    @PostConstruct
    public void init() {
        mainEventLoop.start();
        itchEngine.start();
        fixEngine.start();
    }

    @PreDestroy
    public void destroy() {
        fixEngine.stop();
        itchEngine.stop();
        mainEventLoop.stop();
        connection.close();
    }
}
