package com.anz.markets.prophet.atest.risk._4_riskpath;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Direction;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.TradeType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.prophet.riskpath.RiskPathStatus;
import com.anz.markets.efx.ngaro.math.Epsilon;
import org.junit.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.number.IsCloseTo.closeTo;

@RestartBeforeTest(reason = "clear positions and mkt rates")
@Requirement(Requirement.Ref.POSITION_4_3)
public class RiskPathTest extends BaseAcceptanceSpecification {

    @Test
    @DisplayName("Base case risk path test")
    public void simple_risk_path() throws Exception{
        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
            ConfigurationDataDefault config = tdd.configuration_pricing_base();
            prophet.startUmProbes(config, true);
            prophet.receive(config);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.751, 0.001)); // no OP change as position=0
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, 1_000_000, 0.75, "RiskPath-0")); // Risk Increase

            prophet.incrementTime(1000L);
            Trade trade2 = tdd.client_trade_002(Instrument.AUDUSD, -500_000, 0.750, "RiskPath-1"); // Risk decrease
            prophet.receiveFromUm(trade2);

            prophet.incrementTime(1000L);
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, -400_000, 0.75, "RiskPath-2")); // Risk decrease

            prophet.incrementTime(1000L);
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, -200_000, 0.7501, "RiskPath-3")); // Risk decreased -> closed -> risk increased
        }
        then:
        {
            final List<RiskPath> riskPathUpdates = prophet.expect(RiskPath.class, atLeast(5));
            assertThat(riskPathUpdates.size(), is(5));

            final RiskPath riskPath1 = new RiskPath();
            riskPath1.setTradeId("RiskPath-0");
            riskPath1.setLastOffsetTradeId("RiskPath-0");
            riskPath1.setOrderId("RiskPath-0");
            riskPath1.setCounterparty("CLIENT-COUNTERPARTY");
            riskPath1.setInstrument("AUDUSD");
            riskPath1.setTradingTimeZone(TradingTimeZone.LDN);
            riskPath1.setCurrency(Currency.AUD);
            riskPath1.setTradeType(TradeType.CLIENT);
            riskPath1.setSide(OrderSide.BID);
            riskPath1.setPrice(0.75);
            riskPath1.setQty(1_000_000.0);
            riskPath1.setBaseQty(1_000_000.0);
            riskPath1.setCounterQty(-750_000.0);
            riskPath1.setMarket(Market.WSP_A);
            riskPath1.setParty(Portfolio.CLIENTS);
            riskPath1.setOpenTimeInNanos(1000000000000L);
            riskPath1.setCloseTimeInNanos(1000000000000L);
            riskPath1.setFullLifeInMillis(0L);
            riskPath1.setStartPositionInNotional(1_000_000.0);
            riskPath1.setStartPositionInSystemBase(750_000.0);
            riskPath1.setPositionInNotional(1_000_000.0);
            riskPath1.setPositionInSystemBase(750_000.0);
            riskPath1.setProfitAndLoss(0.0);
            riskPath1.setTradeProfitAndLoss(0.0);
            riskPath1.setRiskIncreasing(true);
            riskPath1.setRiskIncreasingRatio(1.0);
            riskPath1.setBaseRate(0.75);
            riskPath1.setMtmRate(0.751);
            riskPath1.setStatus(RiskPathStatus.OPEN);
            riskPath1.setDirection(Direction.LONG);
            riskPath1.setSystemBaseTerms(true);
            riskPath1.setRiskAdjustment(0.0);
            riskPath1.setMtmRateAtInception(0.751);
            riskPath1.setInceptionPnl(1000.0);
            riskPath1.setHoldingPnl(0.0);
            riskPath1.setMtmPnl(1000.0);
            assertThat(riskPathUpdates.get(0), isRiskPath(riskPath1));

            final RiskPath riskPath2 = new RiskPath();
            riskPath2.setTradeId("RiskPath-0");
            riskPath2.setLastOffsetTradeId("RiskPath-1");
            riskPath2.setOrderId("RiskPath-1");
            riskPath2.setCounterparty("CLIENT-COUNTERPARTY");
            riskPath2.setInstrument("AUDUSD");
            riskPath2.setTradingTimeZone(TradingTimeZone.LDN);
            riskPath2.setCurrency(Currency.AUD);
            riskPath2.setTradeType(TradeType.CLIENT);
            riskPath2.setSide(OrderSide.OFFER);
            riskPath2.setPrice(0.75);
            riskPath2.setQty(500_000.0);
            riskPath2.setBaseQty(-500_000.0);
            riskPath2.setCounterQty(375_000.0);
            riskPath2.setMarket(Market.WSP_A);
            riskPath2.setParty(Portfolio.CLIENTS);
            riskPath2.setOpenTimeInNanos(1000000000000L);
            riskPath2.setCloseTimeInNanos(1001000000000L);
            riskPath2.setFullLifeInMillis(1000L);
            riskPath2.setStartPositionInNotional(1_000_000.0);
            riskPath2.setStartPositionInSystemBase(750_000.0);
            riskPath2.setPositionInNotional(500_000.0);
            riskPath2.setPositionInSystemBase(375_000.0);
            riskPath2.setProfitAndLoss(0.0);
            riskPath2.setTradeProfitAndLoss(0.0);
            riskPath2.setRiskIncreasing(true);
            riskPath2.setRiskIncreasingRatio(-0.5);
            riskPath2.setBaseRate(0.75);
            riskPath2.setMtmRate(0.751);
            riskPath2.setStatus(RiskPathStatus.WORKING);
            riskPath2.setDirection(Direction.LONG);
            riskPath2.setSystemBaseTerms(true);
            riskPath2.setRiskAdjustment(-500000.0);
            riskPath2.setMtmRateAtInception(0.751);
            riskPath2.setInceptionPnl(-500.0);
            riskPath2.setHoldingPnl(0.0);
            riskPath2.setMtmPnl(1000.0);
            assertThat(riskPathUpdates.get(1), isRiskPath(riskPath2));

            final RiskPath riskPath3 = new RiskPath();
            riskPath3.setTradeId("RiskPath-0");
            riskPath3.setLastOffsetTradeId("RiskPath-2");
            riskPath3.setOrderId("RiskPath-2");
            riskPath3.setCounterparty("CLIENT-COUNTERPARTY");
            riskPath3.setInstrument("AUDUSD");
            riskPath3.setTradingTimeZone(TradingTimeZone.LDN);
            riskPath3.setCurrency(Currency.AUD);
            riskPath3.setTradeType(TradeType.CLIENT);
            riskPath3.setSide(OrderSide.OFFER);
            riskPath3.setPrice(0.75);
            riskPath3.setQty(400_000.0);
            riskPath3.setBaseQty(-400_000.0);
            riskPath3.setCounterQty(300_000.0);
            riskPath3.setMarket(Market.WSP_A);
            riskPath3.setParty(Portfolio.CLIENTS);
            riskPath3.setOpenTimeInNanos(1000000000000L);
            riskPath3.setCloseTimeInNanos(1002000000000L);
            riskPath3.setFullLifeInMillis(2000L);
            riskPath3.setStartPositionInNotional(1_000_000.0);
            riskPath3.setStartPositionInSystemBase(750_000.0);
            riskPath3.setPositionInNotional(100_000.0);
            riskPath3.setPositionInSystemBase(75_000.0);
            riskPath3.setProfitAndLoss(0.0);
            riskPath3.setTradeProfitAndLoss(0.0);
            riskPath3.setRiskIncreasing(true);
            riskPath3.setRiskIncreasingRatio(-0.4);
            riskPath3.setBaseRate(0.75);
            riskPath3.setMtmRate(0.751);
            riskPath3.setStatus(RiskPathStatus.WORKING);
            riskPath3.setDirection(Direction.LONG);
            riskPath3.setSystemBaseTerms(true);
            riskPath3.setRiskAdjustment(-400000.0);
            riskPath3.setMtmRateAtInception(0.751);
            riskPath3.setInceptionPnl(-400.0);
            riskPath3.setHoldingPnl(0.0);
            riskPath3.setMtmPnl(1000.0);
            assertThat(riskPathUpdates.get(2), isRiskPath(riskPath3));

            final RiskPath riskPath4 = new RiskPath();
            riskPath4.setTradeId("RiskPath-0");
            riskPath4.setLastOffsetTradeId("RiskPath-3");
            riskPath4.setOrderId("RiskPath-3");
            riskPath4.setCounterparty("CLIENT-COUNTERPARTY");
            riskPath4.setInstrument("AUDUSD");
            riskPath4.setTradingTimeZone(TradingTimeZone.LDN);
            riskPath4.setCurrency(Currency.AUD);
            riskPath4.setTradeType(TradeType.CLIENT);
            riskPath4.setSide(OrderSide.OFFER);
            riskPath4.setPrice(0.7501);
            riskPath4.setQty(200_000.0);
            riskPath4.setBaseQty(-200_000.0);
            riskPath4.setCounterQty(150_020.0);
            riskPath4.setMarket(Market.WSP_A);
            riskPath4.setParty(Portfolio.CLIENTS);
            riskPath4.setOpenTimeInNanos(1000000000000L);
            riskPath4.setCloseTimeInNanos(1003000000000L);
            riskPath4.setFullLifeInMillis(3000L);
            riskPath4.setStartPositionInNotional(1_000_000.0);
            riskPath4.setStartPositionInSystemBase(750_000.0);
            riskPath4.setPositionInNotional(0.0);
            riskPath4.setPositionInSystemBase(-10.0);
            riskPath4.setProfitAndLoss(10.0);
            riskPath4.setTradeProfitAndLoss(10.0);
            riskPath4.setRiskIncreasing(true);
            riskPath4.setRiskIncreasingRatio(-0.1);
            riskPath4.setBaseRate(0.7501);
            riskPath4.setMtmRate(0.751);
            riskPath4.setStatus(RiskPathStatus.CLOSED);
            riskPath4.setDirection(Direction.LONG);
            riskPath4.setSystemBaseTerms(true);
            riskPath4.setRiskTradeBaseRate(0.75);
            riskPath4.setRiskAdjustment(-100000.0);
            riskPath4.setMtmRateAtInception(0.751);
            riskPath4.setInceptionPnl(-180.0);
            riskPath4.setHoldingPnl(0.0);
            riskPath4.setMtmPnl(1000.0);
            assertThat(riskPathUpdates.get(3), isRiskPath(riskPath4));

            final RiskPath riskPath5 = new RiskPath();
            riskPath5.setTradeId("RiskPath-3");
            riskPath5.setLastOffsetTradeId("RiskPath-3");
            riskPath5.setOrderId("RiskPath-3");
            riskPath5.setCounterparty("CLIENT-COUNTERPARTY");
            riskPath5.setInstrument("AUDUSD");
            riskPath5.setTradingTimeZone(TradingTimeZone.LDN);
            riskPath5.setCurrency(Currency.AUD);
            riskPath5.setTradeType(TradeType.CLIENT);
            riskPath5.setSide(OrderSide.OFFER);
            riskPath5.setPrice(0.75);
            riskPath5.setQty(200_000.0);
            riskPath5.setBaseQty(-200_000.0);
            riskPath5.setCounterQty(150_020.0);
            riskPath5.setMarket(Market.WSP_A);
            riskPath5.setParty(Portfolio.CLIENTS);
            riskPath5.setOpenTimeInNanos(1003000000000L);
            riskPath5.setCloseTimeInNanos(1003000000000L);
            riskPath5.setFullLifeInMillis(0L);
            riskPath5.setStartPositionInNotional(-100_000.0);
            riskPath5.setStartPositionInSystemBase(-75_010.0);
            riskPath5.setPositionInNotional(-100_000.0);
            riskPath5.setPositionInSystemBase(-75010.0);
            riskPath5.setTradeProfitAndLoss(0.0);
            riskPath5.setProfitAndLoss(0.0);
            riskPath5.setRiskIncreasing(true);
            riskPath5.setRiskIncreasingRatio(0.5);
            riskPath5.setBaseRate(0.75);
            riskPath5.setMtmRate(0.751);
            riskPath5.setStatus(RiskPathStatus.OPEN);
            riskPath5.setDirection(Direction.SHORT);
            riskPath5.setSystemBaseTerms(true);
            riskPath5.setRiskAdjustment(-100000.0);
            riskPath5.setMtmRateAtInception(0.751);
            riskPath5.setInceptionPnl(-180.0);
            riskPath5.setHoldingPnl(0.0);
            riskPath5.setMtmPnl(-180.0);
            assertThat(riskPathUpdates.get(4), isRiskPath(riskPath5));
        }
        when:
        // use Weekend trading tz to trigger endOfWeek chime -> open risk path is closed off
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.WEEKEND);
        }
        then:
        {
            RiskPath riskpath = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.AUD)).getLast();
            assertThat(riskpath.getCounterparty().toString(), is("ADJUSTMENT"));
            assertThat(riskpath.getQty(), is(100_000.0));
            assertThat(riskpath.getBaseRate(), is(0.751));
            assertThat(riskpath.getStatus(), is(RiskPathStatus.CLOSED));
        }
    }

    @Test
    @DisplayName("Complex risk path test with multiple cross pairs")
    public void complexRiskPath() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75170, 0.75180));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.06850, 1.06950));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
        }
        when:
        // receive trade 0: Risk increase on AUD.
        {
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, -5_000_000, 0.75175, "RiskPath-0"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75175)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 1:
        // Risk decrease on RiskPath-0 AUD.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75169, 0.75179));
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, 1_000_000, 0.75170, "RiskPath-1"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75170)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

        }
        when:
        // receive trade 2:
        // Risk decrease on RiskPath-0 AUD.
        // Risk increase on RiskPath-2 JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDJPY, 109.451, 109.454)); // does not impact Risk Path pnls

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.AUDJPY, 1_000_000, 82.286, "RiskPath-2"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-36.8));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(13.2013));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // baseToUsd rate using coefficient
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY tradeRate / AUDUSD base rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(-82_286_000.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 3:
        // Risk decrease on RiskPath-0 AUD.
        // Risk increase on RiskPath-3 EUR
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.0685, 1.0695));

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.EURAUD, -1_000_000, 1.42186, "RiskPath-3"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-2.0863));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(11.115));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517515)); // EURUSD base rate / EURUSDTradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(riskPath0AUD.getCounterQty() / riskPath0AUD.getStartPositionInNotional()));
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(-1_578_140));

            RiskPath riskPath3EUR = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3EUR.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getBaseRate(), isRoundedTo(1.068885)); // EURUSD base rate
            assertThat(riskPath3EUR.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 4:
        // Risk decrease on RiskPath-0 AUD. Squared
        // New Risk increase on AUD. Risk increase on JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.AUDJPY, 2_000_000, 82.286, "RiskPath-4"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-58.07));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(-46.9585));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // AUDUSD Base rate
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), is(closeTo(1_578_140 / riskPath0AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.7517868)); // AUDUSD Base rate
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(421_860.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(closeTo(riskPath4AUD.getPositionInNotional() / riskPath4AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY trade rate / USDJPY base rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-164_572_000.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(1.0));
        }
        when:
        // receive trade 5:
        // Risk decrease on JPY RiskPath-2. Squared
        // Risk decrease on JPY RiskPath-4
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDJPY, -1_000_000, 109.455, "RiskPath-5"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(-1.0));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(2.49));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(2.49));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-137_403_000));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(27_169_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 6:
        // Risk decrease on JPY RiskPath-4. Squared
        // Risk increase on JPY RiskPath-6
        // Risk increase on CAD RiskPath-6
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDCAD, 1.34050, 1.34080));
            prophet.receive(tdd.client_trade_002(Instrument.CADJPY, -2_000_000, 81.651, "RiskPath-6"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.04));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(2.5301));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4539077)); // USDJPY trade rate * USDCAD base rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(137_403_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath6JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.JPY)).getLast();
            assertThat(riskPath6JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6JPY.getBaseRate(), isRoundedTo(109.4539077)); // USDJPY trade rate * USDCAD base rate
            assertThat(riskPath6JPY.getPositionInNotional(), isRoundedTo(25_899_000.0));
            assertThat(riskPath6JPY.getRiskIncreasingRatio(), is(closeTo(riskPath6JPY.getPositionInNotional() / riskPath4JPY.getCounterQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.340509)); // USDCAD base rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(-2_000_000.0));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 7:
        // Risk decrease on CAD RiskPath-6
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDCAD, -500_000, 1.3410, "RiskPath-7"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(183.11));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(183.1057));
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.3410)); // USDCAD trade rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(-1_329_500d));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), is(closeTo(riskPath6CAD.getCounterQty() / riskPath6CAD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 8:
        // Risk decrease on CAD RiskPath-6 squared
        // Risk increase on CAD RiskPath-8
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDCAD, -1_500_000d, 1.3409, "RiskPath-8"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(289.1336));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(472.2393));
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.3409)); // USDCAD trade rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), is(closeTo(1_329_500 / riskPath6CAD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath8CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-8", Currency.CAD)).getLast();
            assertThat(riskPath8CAD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath8CAD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath8CAD.getBaseRate(), isRoundedTo(1.3409)); // USDCAD trade rate
            assertThat(riskPath8CAD.getPositionInNotional(), isRoundedTo(681850.0));
            assertThat(riskPath8CAD.getRiskIncreasingRatio(), is(closeTo(riskPath8CAD.getPositionInNotional() / riskPath8CAD.getCounterQty(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 9:
        // Risk decrease on AUD RiskPath-4 squared
        // Risk decrease on EUR RiskPath-3
        // Risk increase on AUD RiskPath-9
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.AUDEUR, -500_000d, 0.70355, "RiskPath-9"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(-1.1));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(-1.1));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.7517842)); // AUDUSD base rate
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(-1.0));

            RiskPath riskPath9AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-9", Currency.AUD)).getLast();
            assertThat(riskPath9AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getBaseRate(), isRoundedTo(0.7517842)); // AUDUSD base rate
            assertThat(riskPath9AUD.getPositionInNotional(), isRoundedTo(-78_140));
            assertThat(riskPath9AUD.getRiskIncreasingRatio(), is(closeTo(riskPath9AUD.getPositionInNotional() / riskPath9AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath3AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3AUD.getTradeProfitAndLoss(), isRoundedTo(115.05));
            assertThat(riskPath3AUD.getProfitAndLoss(), isRoundedTo(115.05));
            assertThat(riskPath3AUD.getBaseRate(), isRoundedTo(1.068558)); // AUDUSD base rate / AUDEUR Trade rate
            assertThat(riskPath3AUD.getRiskIncreasingRatio(), is(closeTo(riskPath3AUD.getCounterQty() / riskPath3AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 10(requires triangulation via EUR):
        // Risk decrease on AUD RiskPath-9 squared
        // Risk increase on AUD RiskPath-10
        // Risk increase on DKK RiskPath-10
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURDKK, 6.87490, 6.87510));
            prophet.receive(tdd.client_trade_002(Instrument.AUDDKK, 1_000_000d, 4.83500, "RiskPath-10"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath9AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-9", Currency.AUD)).getLast();
            assertThat(riskPath9AUD.getTradeProfitAndLoss(), isRoundedTo(2.8986));
            assertThat(riskPath9AUD.getProfitAndLoss(), isRoundedTo(2.8986));
            assertThat(riskPath9AUD.getBaseRate(), isRoundedTo(0.7517471)); // AUDUSD base rate
            assertThat(riskPath9AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getRiskIncreasingRatio(), is(-1.0));

            RiskPath riskPath10AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-10", Currency.AUD)).getLast();
            assertThat(riskPath10AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath10AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath10AUD.getBaseRate(), isRoundedTo(0.7517471)); // AUDUSD base rate
            assertThat(riskPath10AUD.getPositionInNotional(), isRoundedTo(921_860.0));
            assertThat(riskPath10AUD.getRiskIncreasingRatio(), is(closeTo(riskPath10AUD.getPositionInNotional() / riskPath10AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath10DKK = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-10", Currency.DKK)).getLast();
            assertThat(riskPath10DKK.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath10DKK.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath10DKK.getBaseRate(), isRoundedTo(6.43168)); // AUDDKK Trade rate / AUDUSD base rate
            assertThat(riskPath10DKK.getRiskIncreasingRatio(), is(closeTo(riskPath10DKK.getCounterQty() / riskPath10DKK.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // at endOfWeek chime, open risk paths are closed off
        {
            prophet.clearOutputBuffer();
            prophet.receive(TradingTimeZone.WEEKEND);
        }
        then:
        {
            RiskPath riskPath3EUR = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3EUR.getStatus(), is(RiskPathStatus.CLOSED));

            RiskPath riskPath6JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.JPY)).getLast();
            assertThat(riskPath6JPY.getStatus(), is(RiskPathStatus.CLOSED));

            RiskPath riskPath8CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-8", Currency.CAD)).getLast();
            assertThat(riskPath8CAD.getStatus(), is(RiskPathStatus.CLOSED));

            RiskPath riskPath10AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-10", Currency.AUD)).getLast();
            assertThat(riskPath10AUD.getStatus(), is(RiskPathStatus.CLOSED));

            RiskPath riskPath10DKK = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-10", Currency.DKK)).getLast();
            assertThat(riskPath10DKK.getStatus(), is(RiskPathStatus.CLOSED));
        }    }

    @Test
    @DisplayName("Verify Risk paths created and closed via Adjustments")
    public void complexRiskPathWithAdjustments() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75170, 0.75180));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.06850, 1.06950));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
        }
        when:
        // Initial adjustment: Risk increase on AUD.
        {
            //            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, -5_000_000, 0.75175, "RiskPath-0"));
            prophet.receive(tdd.adjustments(tdd.adjustment(Currency.AUD,-5_000_000), tdd.adjustment(Currency.USD, 3_758_750)));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75175)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 1:
        // Risk decrease on ADJUSTMENT AUD.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75169, 0.75179));
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, 1_000_000, 0.75170, "RiskPath-1"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75170)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

        }
        when:
        // receive trade 2:
        // Risk decrease on ADJUSTMENT AUD.
        // Risk increase on RiskPath-2 JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDJPY, 109.451, 109.454)); // does not impact Risk Path pnls

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.AUDJPY, 1_000_000, 82.286, "RiskPath-2"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-36.8));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(13.2013));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // baseToUsd rate using coefficient
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY tradeRate / AUDUSD base rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(-82_286_000.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 3:
        // Risk decrease on ADJUSTMENT AUD.
        // Risk increase on RiskPath-3 EUR
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.0685, 1.0695));

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.EURAUD, -1_000_000, 1.42186, "RiskPath-3"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-2.0863));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(11.115));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517515)); // EURUSD base rate / EURUSDTradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(riskPath0AUD.getCounterQty() / riskPath0AUD.getStartPositionInNotional()));
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(-1_578_140));

            RiskPath riskPath3EUR = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3EUR.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getBaseRate(), isRoundedTo(1.068885)); // EURUSD base rate
            assertThat(riskPath3EUR.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 4:
        // Risk decrease on ADJUSTMENT AUD. Squared
        // New Risk increase on RiskPath-4 AUD. Risk increase on RiskPath-4 JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.AUDJPY, 2_000_000, 82.286, "RiskPath-4"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-58.07));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(-46.9585));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // AUDUSD Base rate
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), is(closeTo(1_578_140 / riskPath0AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.7517868)); // AUDUSD Base rate
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(421_860.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(closeTo(riskPath4AUD.getPositionInNotional() / riskPath4AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY trade rate / USDJPY base rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-164_572_000.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(1.0));
        }
        when:
        // receive trade 5:
        // Risk decrease on JPY RiskPath-2. Squared
        // Risk decrease on JPY RiskPath-4
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDJPY, -1_000_000, 109.455, "RiskPath-5"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(-1.0));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(2.49));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(2.49));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-137_403_000));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(27_169_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 6:
        // Risk decrease on JPY RiskPath-4. Squared
        // Risk increase on JPY RiskPath-6
        // Risk increase on CAD RiskPath-6
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDCAD, 1.34050, 1.34080));
            prophet.receive(tdd.client_trade_002(Instrument.CADJPY, -2_000_000, 81.651, "RiskPath-6"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.04));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(2.5301));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4539077)); // USDJPY trade rate * USDCAD base rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(137_403_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath6JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.JPY)).getLast();
            assertThat(riskPath6JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6JPY.getBaseRate(), isRoundedTo(109.4539077)); // USDJPY trade rate * USDCAD base rate
            assertThat(riskPath6JPY.getPositionInNotional(), isRoundedTo(25_899_000.0));
            assertThat(riskPath6JPY.getRiskIncreasingRatio(), is(closeTo(riskPath6JPY.getPositionInNotional() / riskPath4JPY.getCounterQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.340509)); // USDCAD base rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(-2_000_000.0));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 7:
        // Risk decrease on CAD RiskPath-6
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDCAD, -500_000, 1.3410, "RiskPath-7"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(183.11));;
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(183.1057));;
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.3410)); // USDCAD trade rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(-1_329_500d));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), is(closeTo(riskPath6CAD.getCounterQty() / riskPath6CAD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive USDCAD ADJUSTMENT:
        // Risk decrease on CAD RiskPath-6 squared
        // Risk increase on CAD ADJUSTMENT(RiskPath-8)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDCAD, 1.3409));
//            prophet.receive(tdd.client_trade_002(Instrument.USDCAD, -1_500_000d, 1.3409, "RiskPath-8"));
            prophet.receive(tdd.adjustments(tdd.adjustment(Currency.USD,-1_500_000), tdd.adjustment(Currency.CAD, 2_011_350)));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.3409)); // USDCAD MID RATE
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(289.1336));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(472.2393));
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), is(closeTo(1_329_500 / riskPath6CAD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath8CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.CAD)).getLast();
            assertThat(riskPath8CAD.getBaseRate(), isRoundedTo(1.3409)); // USDCAD MID RATE
            assertThat(riskPath8CAD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath8CAD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath8CAD.getPositionInNotional(), isRoundedTo(681850.0));
            assertThat(riskPath8CAD.getRiskIncreasingRatio(), is(closeTo(riskPath8CAD.getPositionInNotional() / riskPath8CAD.getQty(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 9:
        // Risk decrease on AUD RiskPath-4 squared
        // Risk decrease on EUR RiskPath-3
        // Risk increase on AUD RiskPath-9
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.AUDEUR, -500_000d, 0.70355, "RiskPath-9"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(-1.1));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(-1.1));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.7517842)); // AUDUSD base rate
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(-1.0));

            RiskPath riskPath9AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-9", Currency.AUD)).getLast();
            assertThat(riskPath9AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getBaseRate(), isRoundedTo(0.7517842)); // AUDUSD base rate
            assertThat(riskPath9AUD.getPositionInNotional(), isRoundedTo(-78_140));
            assertThat(riskPath9AUD.getRiskIncreasingRatio(), is(closeTo(riskPath9AUD.getPositionInNotional() / riskPath9AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath3AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3AUD.getTradeProfitAndLoss(), isRoundedTo(115.05));
            assertThat(riskPath3AUD.getProfitAndLoss(), isRoundedTo(115.05));
            assertThat(riskPath3AUD.getBaseRate(), isRoundedTo(1.068558)); // AUDUSD base rate / AUDEUR Trade rate
            assertThat(riskPath3AUD.getRiskIncreasingRatio(), is(closeTo(riskPath3AUD.getCounterQty() / riskPath3AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
    }

    @Test
    @DisplayName("Verify Risk paths from Adjustments containing rate")
    public void complexRiskPathWithAdjustmentsAndRate() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75170, 0.75180));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.06850, 1.06950));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
        }
        when:
        // receive trade 0: Risk increase on AUD.
        {
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, -5_000_000, 0.75175, "RiskPath-0"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75175)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 1:
        // Risk decrease on RiskPath-0 AUD.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75169, 0.75179));
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, 1_000_000, 0.75170, "RiskPath-1"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75170)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

        }
        when:
        // receive trade 2:
        // Risk decrease on RiskPath-0 AUD.
        // Risk increase on RiskPath-2 JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDJPY, 109.451, 109.454)); // does not impact Risk Path pnls

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.AUDJPY, 1_000_000, 82.286, "RiskPath-2"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-36.8));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(13.2013));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // baseToUsd rate using coefficient
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY tradeRate / AUDUSD base rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(-82_286_000.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 3:
        // Risk decrease on ADJUSTMENT AUD.
        // Risk increase on RiskPath-3 EUR
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.0685, 1.0695));

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.EURAUD, -1_000_000, 1.42186, "RiskPath-3"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-2.0863));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(11.115));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517515)); // EURUSD base rate / EURUSDTradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(riskPath0AUD.getCounterQty() / riskPath0AUD.getStartPositionInNotional()));
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(-1_578_140));

            RiskPath riskPath3EUR = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3EUR.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getBaseRate(), isRoundedTo(1.068885)); // EURUSD base rate
            assertThat(riskPath3EUR.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 4:
        // Risk decrease on ADJUSTMENT AUD. Squared
        // New Risk increase on RiskPath-4 AUD. Risk increase on RiskPath-4 JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.AUDJPY, 2_000_000, 82.286, "RiskPath-4"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-0", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-58.07));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(-46.9585));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // AUDUSD Base rate
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), is(closeTo(1_578_140 / riskPath0AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.7517868)); // AUDUSD Base rate
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(421_860.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(closeTo(riskPath4AUD.getPositionInNotional() / riskPath4AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY trade rate / USDJPY base rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-164_572_000.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(1.0));
        }
        when:
        // receive trade 5:
        // Risk decrease on JPY RiskPath-2. Squared
        // Risk decrease on JPY RiskPath-4
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDJPY, -1_000_000, 109.455, "RiskPath-5"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(-1.0));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(2.49));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(2.49));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-137_403_000));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(27_169_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 6:
        // Risk decrease on JPY RiskPath-4. Squared
        // Risk increase on JPY RiskPath-6
        // Risk increase on CAD RiskPath-6
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDCAD, 1.34050, 1.34080));
            prophet.receive(tdd.client_trade_002(Instrument.CADJPY, -2_000_000, 81.651, "RiskPath-6"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.04));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(2.5301));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4539077)); // USDJPY trade rate * USDCAD base rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(137_403_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath6JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.JPY)).getLast();
            assertThat(riskPath6JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6JPY.getBaseRate(), isRoundedTo(109.4539077)); // USDJPY trade rate * USDCAD base rate
            assertThat(riskPath6JPY.getPositionInNotional(), isRoundedTo(25_899_000.0));
            assertThat(riskPath6JPY.getRiskIncreasingRatio(), is(closeTo(riskPath6JPY.getPositionInNotional() / riskPath4JPY.getCounterQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.340509)); // USDCAD base rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(-2_000_000.0));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 7:
        // Risk decrease on CAD RiskPath-6
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDCAD, -500_000, 1.3410, "RiskPath-7"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(183.11));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(183.1057));
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.3410)); // USDCAD trade rate
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(-1_329_500d));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), is(closeTo(riskPath6CAD.getCounterQty() / riskPath6CAD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive USDCAD ADJUSTMENT:
        // Risk decrease on CAD RiskPath-6 squared
        // Risk increase on CAD ADJUSTMENT(RiskPath-8)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));

            // Adjustment representing trade of ANZ SELL USDCAD -1.5mio @ 1.3409
            prophet.receive(tdd.adjustment(Currency.USD, -1_500_000));
            prophet.receive(tdd.adjustment(Currency.CAD, 2_011_350, 1.3409));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath6CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-6", Currency.CAD)).getLast();
            assertThat(riskPath6CAD.getBaseRate(), isRoundedTo(1.3409)); // USDCAD MID RATE
            assertThat(riskPath6CAD.getTradeProfitAndLoss(), isRoundedTo(289.1336));
            assertThat(riskPath6CAD.getProfitAndLoss(), isRoundedTo(472.2393));
            assertThat(riskPath6CAD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath6CAD.getRiskIncreasingRatio(), is(closeTo(1_329_500 / riskPath6CAD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath8CAD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("ADJ", Currency.CAD)).getLast();
            assertThat(riskPath8CAD.getBaseRate(), isRoundedTo(1.3409)); // USDCAD MID RATE
            assertThat(riskPath8CAD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath8CAD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath8CAD.getPositionInNotional(), isRoundedTo(681850.0));
            assertThat(riskPath8CAD.getRiskIncreasingRatio(), is(closeTo(riskPath8CAD.getPositionInNotional() / riskPath8CAD.getQty(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive trade 9:
        // Risk decrease on AUD RiskPath-4 squared
        // Risk decrease on EUR RiskPath-3
        // Risk increase on AUD RiskPath-9
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.AUDEUR, -500_000d, 0.70355, "RiskPath-9"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(3));
            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-4", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(-1.1));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(-1.1));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.7517842)); // AUDUSD base rate
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(-1.0));

            RiskPath riskPath9AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-9", Currency.AUD)).getLast();
            assertThat(riskPath9AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath9AUD.getBaseRate(), isRoundedTo(0.7517842)); // AUDUSD base rate
            assertThat(riskPath9AUD.getPositionInNotional(), isRoundedTo(-78_140));
            assertThat(riskPath9AUD.getRiskIncreasingRatio(), is(closeTo(riskPath9AUD.getPositionInNotional() / riskPath9AUD.getBaseQty(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath3AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3AUD.getTradeProfitAndLoss(), isRoundedTo(115.05));
            assertThat(riskPath3AUD.getProfitAndLoss(), isRoundedTo(115.05));
            assertThat(riskPath3AUD.getBaseRate(), isRoundedTo(1.068558)); // AUDUSD base rate / AUDEUR Trade rate
            assertThat(riskPath3AUD.getRiskIncreasingRatio(), is(closeTo(riskPath3AUD.getCounterQty() / riskPath3AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
    }

    @Test
    public void complexRiskPathWithPositionBias() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75170, 0.75180));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.06850, 1.06950));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.62d, -0.22d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(8), Tenor.ONE_WEEK));
        }
        when:
        // receive Position Bias adjustment 0: Risk increase on AUD. (OPENING RISK PATH)
        {
//            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, -5_000_000, 0.75175, "RiskPath-0"));
            prophet.receive(tdd.biasPosition(Currency.AUD, 5_000_000.0));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("BIAS", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75175)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 1:
        // Risk decrease on RiskPath-0 AUD.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.AUDUSD, 0.75169, 0.75179));
            prophet.receive(tdd.client_trade_002(Instrument.AUDUSD, 1_000_000, 0.75170, "RiskPath-1"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(1));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("BIAS", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(50.0));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75170)); // AUDUSD tradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

        }
        when:
        // receive trade 2:
        // Risk decrease on RiskPath-0 AUD.
        // Risk increase on RiskPath-2 JPY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.USDJPY, 109.451, 109.454)); // does not impact Risk Path pnls

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.AUDJPY, 1_000_000, 82.286, "RiskPath-2"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("BIAS", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-36.8));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(13.2013));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517868)); // baseToUsd rate using coefficient
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(-0.2));

            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getProfitAndLoss(), is(0.0));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.4539039)); // AUDJPY tradeRate / AUDUSD base rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(-82_286_000.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 3:
        // Risk decrease on RiskPath-0 AUD.
        // Risk increase on RiskPath-3 EUR
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Instrument.EURUSD, 1.0685, 1.0695));

            // hedge trade vs client trade does NOT impact Risk Path calcs
            prophet.receive(tdd.hedge_trade_002(Portfolio.HEDGER_AGGRESSIVE, Instrument.EURAUD, -1_000_000, 1.42186, "RiskPath-3"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(1), isRiskPath("BIAS", Currency.AUD)).getLast();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(-2.0863));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(11.115));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.7517515)); // EURUSD base rate / EURUSDTradeRate
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), isRoundedTo(riskPath0AUD.getCounterQty() / riskPath0AUD.getStartPositionInNotional()));
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(-1_578_140));

            RiskPath riskPath3EUR = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-3", Currency.EUR)).getLast();
            assertThat(riskPath3EUR.getTradeProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getProfitAndLoss(), is(0.0));
            assertThat(riskPath3EUR.getBaseRate(), isRoundedTo(1.068885)); // EURUSD base rate
            assertThat(riskPath3EUR.getRiskIncreasingRatio(), isRoundedTo(1.0));
        }
        when:
        // receive trade 4 as a POSITION BIAS OFFSET ADJUSTMENT:
        // Risk decrease on RiskPath-0 AUD. Squared
        // New Risk increase on AUD.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
//            prophet.receive(tdd.client_trade_002(Instrument.AUDJPY, 2_000_000, 82.286, "RiskPath-4"));
            prophet.receive(tdd.biasPosition(Currency.AUD, 3_000_000.0));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath0AUD = prophet.expect(RiskPath.class, exactly(2), isRiskPath("BIAS", Currency.AUD)).getFirst();
            assertThat(riskPath0AUD.getTradeProfitAndLoss(), isRoundedTo(15.78));
            assertThat(riskPath0AUD.getProfitAndLoss(), isRoundedTo(26.8964));
            assertThat(riskPath0AUD.getBaseRate(), isRoundedTo(0.75174)); // AUDUSD Mid
            assertThat(riskPath0AUD.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath0AUD.getRiskIncreasingRatio(), is(closeTo(1_578_140 / riskPath0AUD.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));

            RiskPath riskPath4AUD = prophet.expect(RiskPath.class, exactly(2), isRiskPath("BIAS", Currency.AUD)).getLast();
            assertThat(riskPath4AUD.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4AUD.getBaseRate(), isRoundedTo(0.75174)); // AUDUSD Mid
            assertThat(riskPath4AUD.getPositionInNotional(), isRoundedTo(421_860.0));
            assertThat(riskPath4AUD.getRiskIncreasingRatio(), is(closeTo(riskPath4AUD.getPositionInNotional() / riskPath4AUD.getQty(), Epsilon.EPS_0_001.getValue())));
        }
        when:
        // receive POSITION BIAS OFFSET ADJUSTMENT:
        // New Risk increase on JPY.
        {
            prophet.receive(tdd.biasPosition(Currency.JPY, 164_572_000));
        }
        then:
        {
            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("BIAS", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(0.0));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.4525)); // USD/JPY mid
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-164_572_000.0));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(1.0));
        }
        when:
        // receive trade 5:
        // Risk decrease on JPY RiskPath-2. Squared
        // Risk decrease on JPY ADJUSTMENT
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_002(Instrument.USDJPY, -1_000_000, 109.455, "RiskPath-5"));
        }
        then:
        {
            prophet.expect(RiskPath.class, exactly(2));
            RiskPath riskPath2JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("RiskPath-2", Currency.JPY)).getLast();
            assertThat(riskPath2JPY.getTradeProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getProfitAndLoss(), isRoundedTo(7.53));
            assertThat(riskPath2JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath2JPY.getPositionInNotional(), isRoundedTo(0.0));
            assertThat(riskPath2JPY.getRiskIncreasingRatio(), isRoundedTo(-1.0));

            RiskPath riskPath4JPY = prophet.expect(RiskPath.class, exactly(1), isRiskPath("BIAS", Currency.JPY)).getLast();
            assertThat(riskPath4JPY.getTradeProfitAndLoss(), isRoundedTo(5.67));
            assertThat(riskPath4JPY.getProfitAndLoss(), isRoundedTo(5.67));
            assertThat(riskPath4JPY.getBaseRate(), isRoundedTo(109.455)); // USDJPY trade rate
            assertThat(riskPath4JPY.getPositionInNotional(), isRoundedTo(-137_403_000));
            assertThat(riskPath4JPY.getRiskIncreasingRatio(), is(closeTo(27_169_000 / riskPath4JPY.getStartPositionInNotional(), Epsilon.EPS_0_001.getValue())));
        }
    }
}
