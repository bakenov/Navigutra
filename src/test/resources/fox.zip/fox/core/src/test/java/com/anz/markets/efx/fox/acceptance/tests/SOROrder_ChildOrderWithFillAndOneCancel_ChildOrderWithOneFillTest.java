package com.anz.markets.efx.fox.acceptance.tests;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.codec.pojo.matcher.PricingRefreshCompleteMatcher;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.NewOrderSingleMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.StrategyParameter;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

@RunWith(Spockito.class)
public class SOROrder_ChildOrderWithFillAndOneCancel_ChildOrderWithOneFillTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SOROrder_ChildOrderWithFillAndOneCancel_ChildOrderWithOneFillTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private MarketDataFactory marketDataFactory = new MarketDataFactory();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_1 = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|0             |   BARX         |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   []         |     1     |     1        | 0                 |",
            "|0             |   CNX          |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 |   []         |     2     |     2        | 0                 |",
            "|0             |   EBS          |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   [LATENT]   |     1     |     1        | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_2 = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|0             |   BARX         |      BID    |   1.3345  |        0.0           |     1e6     |  500000 |   []         |      1    |       1      | 0                 |",
            "|0             |   CNX          |     OFFER   |   1.3320  |        0.0001        |     2e6     |  800000 |   []         |      2    |       2      | 0                 |",
    });

    private static final List<SnapshotFullRefresh.Entry[]> snapshotEntries() {
        return Arrays.asList(SNAP_ENTRIES_1, SNAP_ENTRIES_2);
    }

    private static final Hop[] HOPS = Table.parse(Hop.class, new String[] {
            "|   hopCompId  | hopMessageId | hopReceivingTime | hopSendingTime |",
            "|==============|==============|==================|================|",
            "| GB:HopName:1 |   123456789  |    66655556666   |  66655557777   |",
            "| AU:HopName:2 |   123123123  |    66556655666   |  66556655777   |",
    });

    @Test
    @Spockito.Unroll({
            "| source | sourceSeq |idx | senderCompId | messageId | possResend | origSendingTime | symbol |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|========|===========|====|==============|===========|============|=================|========|===============|==========|============|===========|============|===================|===================|",
            "| 1      | 12345     | 0  | GB:Sender:01 |    9876   |    false   |    1122334000   | AUDUSD |   FXSPOT      | FAST     | 2016-01-14 |    SP     | 2016-01-16 |     2016-01-06    | []                |",
            "|--------|-----------|----|--------------|-----------|------------|-----------------|--------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void receiver_should_forward_price_snapshots_and_itself_to_command_queue(
            final int source, final long sourceSeq, final int idx, final String senderCompId, final long messageId,
            final boolean possResend, final long origSendingTime,
            final String symbol, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags
    ) throws Exception {
        final SnapshotFullRefresh.Entry[] snapShotEntry = snapshotEntries().get(idx);
        final long currentTimeNanos = acceptanceContext.precisionClock().nanos();
        Arrays.stream(snapShotEntry).forEach(e -> e.transactTime = currentTimeNanos);

        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, securityType, settlType);

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(source, sourceSeq),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, currentTimeNanos, origSendingTime, instrumentKey.instrumentId(), marketId,
                        tradeDate, settlDate, referenceSpotDate, mdFlags),
                snapShotEntry, HOPS);

        final VenueEndpoint venueEndpoint = acceptanceContext.venueEndpointLookup()
                .lookup(marketId);

        venueEndpoint.pricingQueue(symbol, securityType)
                 .add(snapshot);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| GS       |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| BARX     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        //FIXME: need to reliably check
        Thread.sleep(2000);

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "GB:lg-fastc";
        sorEndpoint.tradingRequest().add(heartbeat);

        final String clOrdId = "3456";
        final OrderType orderType = OrderType.LIMIT;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 1.2320;
        final double quantity = 1000000;
        final TimeInForce timeInForce = TimeInForce.IOC;
        final String sndrCompId = "FXTrader.GB.anufriea.XEFX";
        final String targetCompId = "GB:fox";

        final NewOrderSingle order = sorEndpoint.createNewOrderSingle();
        order.body.senderCompId = sndrCompId;
        order.body.targetCompId = targetCompId;
        order.body.transactTime = acceptanceContext.precisionClock().nanos();
        order.body.timeInForce = timeInForce;
        order.body.orderQty = quantity;
        order.body.clOrdId = clOrdId;
        order.body.currency = currency;
        order.body.ordType = orderType;
        order.body.price = price;
        order.body.targetStrategyName = "Sweeper";
        order.body.securityType = instrumentKey.securityType();
        order.body.settlCurrency = currency;
        order.body.side = side;
        order.body.symbol = instrumentKey.symbol();
        order.body.settlType = instrumentKey.tenor();
        order.parties.add(new Party(PartyRole.USER_NAME, "autotrader-MidHedger"));
        order.parties.add(new Party(PartyRole.PORTFOLIO, "XEFX"));
        order.strategyParameters.add(new StrategyParameter("Markets", "FAST"));

        sorEndpoint.tradingRequest().add(order);

        snapshots.forEach((venue, snapshotFullRefresh) -> {
            Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                    .matching(SnapshotFullRefreshMatcher.build()
                            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(snapshotFullRefresh.body.senderCompId))
                            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(venue))
                            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId())))
                    .awaitMatchAndGetLast(15, TimeUnit.SECONDS);
        });

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(PricingRefreshCompleteMatcher.build()
                        .body().matches(PricingRefreshCompleteMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);


        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(order.body.senderCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.quoteId().eq(order.body.quoteId))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce));


        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        final VenueEndpoint fastVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.FAST);
        //Expect NewOrderSingle on FAST venue
        final TradingMessage venueNos1 = Asserter.of(fastVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(OrderType.LIMIT))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueNos1.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onNewOrderSingle(final NewOrderSingle nos) {


                final ExecutionReport executionReport1 = fastVenue.createExecutionReport();
                executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport1.body.timeInForce = nos.body.timeInForce;
                executionReport1.body.marketId = nos.body.marketId;
                executionReport1.body.orderQty = nos.body.orderQty;
                executionReport1.body.orderId = "2345";
                executionReport1.body.clOrdId = nos.body.clOrdId;
                executionReport1.body.origClOrdId = nos.body.clOrdId;
                executionReport1.body.clOrdLinkId = nos.body.clOrdLinkId;
                executionReport1.body.execId = "4567";
                executionReport1.body.quoteId = nos.body.quoteId;
                executionReport1.body.currency = nos.body.currency;
                executionReport1.body.ordType = nos.body.ordType;
                executionReport1.body.price = nos.body.price;
                executionReport1.body.securityType = nos.body.securityType;
                executionReport1.body.senderCompId = "GB:lg-fast";
                executionReport1.body.settlCurrency = nos.body.currency;
                executionReport1.body.side = nos.body.side;
                executionReport1.body.symbol = nos.body.symbol;
                executionReport1.body.execType = ExecType.TRADE;
                executionReport1.body.ordStatus = OrderStatus.PARTIALLY_FILLED;
                executionReport1.body.leavesQty = nos.body.orderQty / 2;
                executionReport1.body.cumQty = nos.body.orderQty / 2;
                executionReport1.body.lastQty = nos.body.orderQty / 2;
                executionReport1.body.lastPx = 0.3453;

                final ExecutionReport executionReport2 = fastVenue.createExecutionReport();
                executionReport2.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport2.body.timeInForce = nos.body.timeInForce;
                executionReport2.body.marketId = nos.body.marketId;
                executionReport2.body.orderQty = nos.body.orderQty;
                executionReport2.body.orderId = "2345";
                executionReport2.body.clOrdId = nos.body.clOrdId;
                executionReport2.body.origClOrdId = nos.body.clOrdId;
                executionReport2.body.clOrdLinkId = nos.body.clOrdLinkId;
                executionReport2.body.execId = "4568";
                executionReport2.body.quoteId = nos.body.quoteId;
                executionReport2.body.currency = nos.body.currency;
                executionReport2.body.ordType = nos.body.ordType;
                executionReport2.body.price = nos.body.price;
                executionReport2.body.securityType = nos.body.securityType;
                executionReport2.body.senderCompId = "GB:lg-fast";
                executionReport2.body.settlCurrency = nos.body.currency;
                executionReport2.body.side = nos.body.side;
                executionReport2.body.symbol = nos.body.symbol;
                executionReport2.body.execType = ExecType.CANCELED;
                executionReport2.body.ordStatus = OrderStatus.PARTIALLY_FILLED;
                executionReport2.body.leavesQty = 0;
                executionReport2.body.cumQty = nos.body.orderQty / 2;
                executionReport2.body.lastQty = 0;
                executionReport2.body.lastPx = 0;

                fastVenue.tradingResponse().add(executionReport1);
                fastVenue.tradingResponse().add(executionReport2);
            }
        });


        final TradingMessage venueNos2 = Asserter.of(fastVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(targetCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(OrderType.LIMIT))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty / 2))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueNos2.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onNewOrderSingle(final NewOrderSingle nos) {


                final ExecutionReport executionReport3 = fastVenue.createExecutionReport();
                executionReport3.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport3.body.timeInForce = nos.body.timeInForce;
                executionReport3.body.marketId = nos.body.marketId;
                executionReport3.body.orderQty = nos.body.orderQty;
                executionReport3.body.orderId = "2346";
                executionReport3.body.clOrdId = nos.body.clOrdId;
                executionReport3.body.origClOrdId = nos.body.clOrdId;
                executionReport3.body.clOrdLinkId = nos.body.clOrdLinkId;
                executionReport3.body.execId = "4568";
                executionReport3.body.quoteId = nos.body.quoteId;
                executionReport3.body.currency = nos.body.currency;
                executionReport3.body.ordType = nos.body.ordType;
                executionReport3.body.price = nos.body.price;
                executionReport3.body.securityType = nos.body.securityType;
                executionReport3.body.senderCompId = "GB:lg-fast";
                executionReport3.body.settlCurrency = nos.body.currency;
                executionReport3.body.side = nos.body.side;
                executionReport3.body.symbol = nos.body.symbol;
                executionReport3.body.execType = ExecType.TRADE;
                executionReport3.body.ordStatus = OrderStatus.FILLED;
                executionReport3.body.leavesQty = 0;
                executionReport3.body.cumQty = nos.body.orderQty;
                executionReport3.body.lastQty = nos.body.orderQty;
                executionReport3.body.lastPx = 0.3453;

                fastVenue.tradingResponse().add(executionReport3);
            }
        });

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(targetCompId))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(instrumentKey.securityType()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }
}
