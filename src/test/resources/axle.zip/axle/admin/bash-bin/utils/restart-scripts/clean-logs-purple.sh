#!/bin/bash

#Correlator
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "find ~/logs -type f -delete") ::: auq4000s auq4014s auq4015s auq4013s auq4009s auq4016s auq4054s auq4011s
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "rm -rf ~/apache-tomcat/logs/*; rm -rf ~/apache-tomcat/bin/*.log; rm -rf ~/apache-tomcat/bin/*.dat") ::: auq4016s auq4011s


#ssh auq4014s "find ~/logs -type f -delete"
#ssh auq4015s "find ~/logs -type f -delete"

#ssh auq4016s "find ~/logs -type f -delete"
#ssh auq4054s "find ~/logs -type f -delete"

#ssh auq4009s "find ~/logs -type f -delete"
#ssh auq4000s "find ~/logs -type f -delete"
#ssh auq4011s "find ~/logs -type f -delete"
#ssh auq4013s "find ~/logs -type f -delete"

#Proxy broker
#ssh auq4016s "rm -rf ~/apache-tomcat/logs/*"
#ssh auq4016s "rm -rf ~/apache-tomcat/bin/*.log"
#ssh auq4016s "rm -rf ~/apache-tomcat/bin/*.dat"
#
#ssh auq4011s "rm -rf ~/apache-tomcat/logs/*"
#ssh auq4011s "rm -rf ~/apache-tomcat/bin/*.log"
#ssh auq4011s "rm -rf ~/apache-tomcat/bin/*.dat"

