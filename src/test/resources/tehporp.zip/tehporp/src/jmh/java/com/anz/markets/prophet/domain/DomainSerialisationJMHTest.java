package com.anz.markets.prophet.domain;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueWrappers;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataIncrementImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.util.concurrent.TimeUnit;

public class DomainSerialisationJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private MarketDataSnapshotImpl marketDataSnapshotLP;
        private MarketDataSnapshotImpl marketDataSnapshotAggBook;
        private MarketDataIncrementImpl marketDataIncrement;
        private TradeImpl trade;
        private ProphetBytes bytes;

        @Setup
        public void setup() {
            bytes = ChronicleQueueWrappers.wrapFixedSize();
            marketDataIncrement = MidRateTestHelper.createMarketDataIncrement();
            marketDataSnapshotLP = MidRateTestHelper.createMarketData(marketDataIncrement.getEventsList().size() / 2);
            marketDataSnapshotAggBook = MidRateTestHelper.createMarketData(100);
            trade = (TradeImpl) MidRateTestHelper.createTrade(Instrument.AUDUSD, OrderSide.OFFER, 1_000_000, 0.7666, TradeType.CLIENT);
        }
    }

    @Benchmark
    public double serialiseDeserialiseMarketDataSnapshotImpl(Data data) {
        data.marketDataSnapshotLP.setExternalEventTimeNS(System.currentTimeMillis());
        data.bytes.position(0);
        data.marketDataSnapshotLP.writeMarshallable(data.bytes);
        data.bytes.position(0);
        data.marketDataSnapshotLP.readMarshallable(data.bytes);
        return data.marketDataSnapshotLP.getExternalEventTimeNS();
    }

    @Benchmark
    public double serialiseDeserialiseMarketDataSnapshotImplAggBook(Data data) {
        data.marketDataSnapshotAggBook.setExternalEventTimeNS(System.currentTimeMillis());
        data.bytes.position(0);
        data.marketDataSnapshotAggBook.writeMarshallable(data.bytes);
        data.bytes.position(0);
        data.marketDataSnapshotAggBook.readMarshallable(data.bytes);
        return data.marketDataSnapshotAggBook.getExternalEventTimeNS();
    }

    @Benchmark
    public double serialiseDeserialiseMarketDataIncrementImpl(Data data) {
        final long startTime = System.currentTimeMillis();
        data.bytes.position(0);
        data.marketDataIncrement.writeMarshallable(data.bytes);
        data.bytes.position(0);
        data.marketDataIncrement.readMarshallable(data.bytes);
        return startTime;
    }

    @Benchmark
    public long serialiseTradeImpl(Data data) {
        data.trade.setInceptionTimeNanos(TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis()));
        data.bytes.position(0);
        data.trade.writeMarshallable(data.bytes);
        data.bytes.position(0);
        data.trade.readMarshallable(data.bytes);
        return TimeUnit.NANOSECONDS.toMillis(data.trade.getInceptionTimeNanos());
    }
}
