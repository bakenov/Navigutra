package com.anz.markets.efx.fox.api.domain;

public interface ChildOrderVisitor {
    default void visit(ChildOrderState.NotInitialisedOrderState order) {}
    default void visit(ChildOrderState.WaitingOrderState order) {}
    default void visit(ChildOrderState.WorkingOrderState order) {}
    default void visit(ChildOrderState.DeadOrderState order) {}
    default void visit(ChildOrderState.PendingCancelOrderState order) {}
    default void visit(ChildOrderState.UnknownOrderState order) {}
}

