package com.anz.axle.lg.adapter.deut.quickfix;

import java.util.function.Consumer;
import java.util.function.Supplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import quickfix.Message;

import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.FixSide;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.FormattedTimeParser;
import com.anz.axle.lg.util.test.FixMessageFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.inOrder;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DeutIncrementalRefreshHandlerTest {
    private static final String SENDER_COMP_ID = "GB:DEUT";
    private static final String COMP_ID = "GB:lg-deut";
    private static final long CURRENT_TIME = 34523453;
    private static final long MSG_SEQ_NUM = 4317;
    private static final String MSG_SEQ_NUM_STRING = "4317";
    private static final String SENDING_TIME_STRING = "20161129-06:23:35.982";
    private static final FormattedTimeParser FORMATTED_TIME_PARSER = new FormattedTimeParser();
    private static final long SENDING_TIME_NANOS = FORMATTED_TIME_PARSER.parseNanos(SENDING_TIME_STRING);
    private static final String SYMBOL = "EUR/CAD";
    private static final String NORMALISED_SYMBOL = "EURCAD";
    private static final SecurityType SECURITY_TYPE = SecurityType.FXSPOT;
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(NORMALISED_SYMBOL, SECURITY_TYPE, Tenor.SP);
    private static final String MDR_ID = "1234567";
    private static final int MDR_ID_INT = Integer.parseInt(MDR_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(MDR_ID);
    private static final EntryType SIDE1 = EntryType.BID;
    private static final String ENTRY_ID1 = "3075290317";
    private static final String QUOTE_ENTRY_ID1 = "1234567890";
    private static final String QUANTITY_STRING1 = "500000.00";
    private static final String PRICE_STRING1 = "1.56039";
    private static final EntryType SIDE2 = EntryType.OFFER;
    private static final String ENTRY_ID2 = "3075290318";
    private static final String QUANTITY_STRING2 = "1000000.00";
    private static final String PRICE_STRING2 = "1.56041";

    private MockitoPricingEncoder encoders = new MockitoPricingEncoder();
    private FixMessageFactory messageFactory;
    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderSupplier encoderSupplier = mock(PricingEncoderSupplier.class);
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    @Mock
    private Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private DeutIncrementalRefreshHandler deutIncrementalRefreshHandler;
    private InOrder inOrder;

    private Supplier<StringToIntCache> quteIdCacheSupplier = new StringToIntCacheFactory(100, 25, 100, 8, 1);
    private StringToIntCache quoteIdCache = quteIdCacheSupplier.get();
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);


    @Before
    public void setUp() throws Exception {
        deutIncrementalRefreshHandler = new DeutIncrementalRefreshHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, flagsAppender, sourceSequencer);
        messageFactory = new FixMessageFactory("/conf/FIX44-deut.xml");
        when(encoderSupplier.incrementalRefresh()).thenReturn(encoders.incrementalEncoder);
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);
        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.incrementalEncoder,
                encoders.incrementalEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.incrementalBody.senderCompId(),
                encoders.incrementalBody.tradeDate(),
                encoders.incrementalBody.settlDate(),
                encoders.incrementalBody.referenceSpotDate(),
                encoders.incrementalBody.mdFlags(),
                encoders.incrementalEntries_next,
                encoders.incrementalEntries_body,
                encoders.incrementalEntries_body.mdEntryFlags(),

                encoders.incrementalHops,
                encoders.incrementalHops_next,
                encoders.incrementalHops_body,
                encoders.incrementalHops_body.hopCompId(),
                encoders.messageEncoder);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY)).thenReturn(RequestKey.of(Venue.DEUT, INSTRUMENT_KEY));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(MDR_ID_INT)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        when(marketDataSubscription.symbol()).thenReturn(SYMBOL);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
        when(marketDataSubscription.stringToIntCache()).thenReturn(quoteIdCache);

    }

    @Test
    public void shouldProcessNewEntry() throws Exception {
        final int entryId = quoteIdCache.put(ENTRY_ID1);
        final int quoteEntryId = quoteIdCache.put(QUOTE_ENTRY_ID1);

        final Message incrementalMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "262=", MDR_ID,
                "268=", "1",
                "279=", "0", // NEW
                "269=", FixSide.to(SIDE1),
                "278=", ENTRY_ID1,
                "55=", SYMBOL,
                "270=", PRICE_STRING1,
                "271=", QUANTITY_STRING1,
                "299=", QUOTE_ENTRY_ID1,
                "5020=", "20171122",
                "10=", "133");
        assertNull(incrementalMessage.getException());

        //when
        deutIncrementalRefreshHandler.accept(incrementalMessage);

        //then
        verifyIncrement( 1, entryId, quoteEntryId, SIDE1, QUANTITY_STRING1, PRICE_STRING1, UpdateAction.NEW);
    }

    @Test
    public void shouldProcessChangeEntry() throws Exception {
        final int entryId = quoteIdCache.put(ENTRY_ID1);
        final int quoteEntryId = quoteIdCache.put(QUOTE_ENTRY_ID1);

        final Message incrementalMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "262=", MDR_ID,
                "268=", "1",
                "279=", "1", // CHANGE
                "269=", FixSide.to(SIDE1),
                "278=", ENTRY_ID1,
                "55=", SYMBOL,
                "270=", PRICE_STRING1,
                "271=", QUANTITY_STRING1,
                "299=", QUOTE_ENTRY_ID1,
                "5020=", "20171122",
                "10=", "134");
        assertNull(incrementalMessage.getException());

        //when
        deutIncrementalRefreshHandler.accept(incrementalMessage);

        //then
        verifyIncrement( 1, entryId, quoteEntryId, SIDE1, QUANTITY_STRING1, PRICE_STRING1, UpdateAction.CHANGE);
    }


    @Test
    public void shouldProcessDeleteEntry() throws Exception {

        final int entryId = quoteIdCache.put(ENTRY_ID1);
        final int quoteEntryId = quoteIdCache.put(QUOTE_ENTRY_ID1);

        final Message incrementalMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "262=", MDR_ID,
                "268=", "1",
                "279=", "2", // DELETE
                "269=", FixSide.to(SIDE1),
                "278=", ENTRY_ID1,
                "55=", SYMBOL,
                "299=", QUOTE_ENTRY_ID1,
                "10=", "42");
        assertNull(incrementalMessage.getException());

        //when
        deutIncrementalRefreshHandler.accept(incrementalMessage);

        //then
        verifyIncrement( 1, entryId, quoteEntryId, SIDE1, null, null, UpdateAction.DELETE);
    }

    @Test
    public void shouldProcessEmptyBook() throws Exception {
        final Message incrementalMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_DEUT_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_DEUT_MD_S",
                "262=", MDR_ID,
                "268=", "0",
                "10=", "170");
        assertNull(incrementalMessage.getException());

        //when
        deutIncrementalRefreshHandler.accept(incrementalMessage);

        //then
        verifyIncrement( 0, 0, 0, null, null, null, null);
    }

    private void verifyIncrement(final int entriesCount,
                                 final int entryId,
                                 final int quoteEntryId,
                                 final EntryType side1,
                                 final String quantityString1,
                                 final String priceString1,
                                 final UpdateAction updateAction) {
        inOrder.verify(encoders.incrementalBody.senderCompId()).encode(COMP_ID);
        inOrder.verify(encoders.incrementalBody).messageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.incrementalBody).marketId(Venue.DEUT);
        inOrder.verify(encoders.incrementalBody).instrumentId(INSTRUMENT_KEY.instrumentId());
        inOrder.verify(encoders.incrementalBody).sendingTime(SENDING_TIME_NANOS);

        if (entriesCount == 0) {
            inOrder.verify(encoders.incrementalBody).entriesEmpty();
        } else {
            inOrder.verify(encoders.incrementalBody).entriesStart(entriesCount);
            inOrder.verify(encoders.incrementalEntries_next).next();
            inOrder.verify(encoders.incrementalEntries_body).mdUpdateAction(updateAction);
            inOrder.verify(encoders.incrementalEntries_body).transactTime(SENDING_TIME_NANOS);
            inOrder.verify(encoders.incrementalEntries_body).mdMkt(Venue.DEUT);
            inOrder.verify(encoders.incrementalEntries_body).mdEntryType(side1);
            if (updateAction == UpdateAction.NEW || updateAction == UpdateAction.CHANGE) {
                inOrder.verify(encoders.incrementalEntries_body).mdEntrySize(Double.valueOf(quantityString1));
                inOrder.verify(encoders.incrementalEntries_body).mdEntryPx(Double.valueOf(priceString1));
            }
            inOrder.verify(encoders.incrementalEntries_body).mdEntryId(entryId);
            inOrder.verify(encoders.incrementalEntries_body).mdEntryRefId(0);
            inOrder.verify(encoders.incrementalEntries_body).quoteEntryId(quoteEntryId);
            inOrder.verify(encoders.incrementalEntries_next).entriesComplete();
        }
        inOrder.verify(encoders.incrementalHops).hopsStart(2);
        inOrder.verify(encoders.incrementalHops_next).next();
        inOrder.verify(encoders.incrementalHops_body.hopCompId()).encode(SENDER_COMP_ID);
        inOrder.verify(encoders.incrementalHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.incrementalHops_body).hopReceivingTime(0);
        inOrder.verify(encoders.incrementalHops_body).hopSendingTime(SENDING_TIME_NANOS);
        inOrder.verify(encoders.incrementalHops_body).next();
        inOrder.verify(encoders.incrementalHops_body.hopCompId()).encode(COMP_ID);
        inOrder.verify(encoders.incrementalHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.incrementalHops_body).hopReceivingTime(CURRENT_TIME);
        inOrder.verify(encoders.incrementalHops_body).hopSendingTime(CURRENT_TIME);
        inOrder.verify(encoders.incrementalHops_body).hopsComplete();
        inOrder.verify(encoders.messageEncoder).messageComplete();
    }

}