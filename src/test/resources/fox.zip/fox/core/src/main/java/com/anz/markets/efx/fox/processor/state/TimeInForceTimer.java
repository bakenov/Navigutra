package com.anz.markets.efx.fox.processor.state;

import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public interface TimeInForceTimer {
    void schedule();
    void cancel();
    void reset(TimeInForce timeInForce);

    interface Factory {
        TimeInForceTimer create(TimerScheduler.ExpiryHandler expiryHandler);
    }
}
