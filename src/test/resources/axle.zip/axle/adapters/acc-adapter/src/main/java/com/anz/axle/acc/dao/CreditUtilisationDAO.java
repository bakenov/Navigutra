package com.anz.axle.acc.dao;

import static org.springframework.util.ObjectUtils.nullSafeEquals;

import java.io.Serializable;
import java.util.*;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.joda.time.LocalDate;
import org.springframework.stereotype.Repository;

import com.anz.axle.acc.domain.CreditUtilisingTrade;
import com.anz.axle.common.dao.AbstractHibernateDAO;
import com.anz.axle.common.domain.Counterparty;
import com.anz.axle.common.domain.CounterpartyCreditPool;
import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.Operation;
import com.anz.axle.common.domain.TradeState;
import com.anz.axle.common.domain.Venue;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Repository
public class CreditUtilisationDAO extends AbstractHibernateDAO<CreditUtilisingTrade> {
    public CreditUtilisationDAO() {
        super(CreditUtilisingTrade.class);
    }

    public CounterpartyCreditUtilisations getCounterpartySpotDateCreditUtilisations(LocalDate start, List<Counterparty> counterparties) {
        final List<String> acceptableOperations = Arrays.asList(Operation.FILL.getCode(), Operation.PARTIAL_FILL.getCode(), Operation.TRADE.getCode(), Operation.CANCELLED_WITH_FILL.getCode());
        final CriteriaBuilder builder = getCriteriaBuilder();
        final CriteriaQuery<CreditUtilisingTrade> criteriaQuery = getCriteriaQuery();
        criteriaQuery.multiselect(
            builder.sum(attribute("rawUsdLastDoneAmount")),
                attribute("rawSpotDate"),
                attribute("creditPool")
        );
        criteriaQuery.groupBy(
                attribute("rawSpotDate"),
                attribute("creditPool")
        );
        criteriaQuery.where(
                builder.equal(attribute("rawTradeState"), TradeState.COMPLETED.getCode()),
                builder.isTrue(attribute("rawOperation").in(acceptableOperations)),
                builder.greaterThanOrEqualTo(attribute("rawSpotDate"), start.toDateTimeAtStartOfDay().toDate())
        );

        List<CreditUtilisingTrade> rows = findByCriteria(criteriaQuery);
        Collection<CounterpartyCreditUtilisation> utilisations = new ArrayList<>();
        for(CreditUtilisingTrade row : rows) {
            final CounterpartyCreditPool creditPool = row.getCreditPool();
            final LocalDate spotDate = new LocalDate(row.getRawSpotDate());
            final double sum = row.getRawUsdLastDoneAmount();
            utilisations.add(new CounterpartyCreditUtilisation(creditPool, spotDate, sum, getAffectedVenues(counterparties, creditPool), System.currentTimeMillis()));
        }
        return new CounterpartyCreditUtilisations(utilisations);
    }

    private Collection<Venue> getAffectedVenues(List<Counterparty> counterparties, CounterpartyCreditPool creditPool) {
        Collection<Venue> venues = new ArrayList<Venue>();
        for(Counterparty counterparty : counterparties) {
            CounterpartyCreditPool thisCreditPool = counterparty.getCreditPool();
            if(nullSafeEquals(thisCreditPool.getId(), creditPool.getId()) && !venues.contains(counterparty.getVenue())) {
                venues.add(counterparty.getVenue());
            }
        }
        return venues;
    }

    @Override
    public CreditUtilisingTrade findByKey(Serializable key) {
        throw new UnsupportedOperationException();
    }
}
