#!/bin/bash
# (c) 2016 ANZ

TITLE="Price Update Frequency (VAG2)"
VENUES="EBS"
COLORS="264D00"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_freq.common