package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.OrderCancelRejectSbeDecoder;

public class ChildOrderCancelRejectEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChildOrderCancelRejectEvent.class);

    private final ChildOrderRepository childOrderRepository;
    private final OrderCancelRejectSbeDecoder orderCancelRejectDecoder = new OrderCancelRejectSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    public ChildOrderCancelRejectEvent(final ChildOrderRepository childOrderRepository) {
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if(!orderCancelRejectDecoder.wrap(message)) return false;

        final String marketId = orderCancelRejectDecoder.body().marketId().decodeAndCache(marketIdCache);

        if (!Venue.FOX.name().equals(marketId)) {
            logMessage();

            final long childOrigClOrdId = orderCancelRejectDecoder.body().origClOrdId().decodeLongOrZero();

            final ChildOrder childOrder;
            if (childOrigClOrdId > 0) {
                childOrder = childOrderRepository.lookupByClOrdId(childOrigClOrdId);
            } else {
                throw new IllegalStateException("OrderCancelReject must provide clOrdId");
            }

            childOrder.applyOrderCancelReject(orderCancelRejectDecoder);
            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        orderCancelRejectDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying child OCRJ: {}", stringBuilder);
    }
}
