package com.anz.markets.efx.fox.firewall.metric;

import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;

public class MetricPeriod {
    private static ByteValueCache<String> PERIOD_UNIT_CACHE = new ByteValueCache<>(AsciiString::toString);

    public static long toMillis(final FirewallConfigDecoder ruleConfig) {
        final FirewallConfigDecoder.Body body = ruleConfig.body();
        final String periodUnit = body.periodUnit().decodeAndCache(PERIOD_UNIT_CACHE);
        final TimeUnit timeUnit = getPeriodUnitAsTimeUnit(periodUnit);
        return timeUnit.toMillis(body.period());
    }

    private static TimeUnit getPeriodUnitAsTimeUnit(String periodUnit){
        switch (periodUnit){
            case "s" :
                return TimeUnit.SECONDS;
            case "m" :
                return TimeUnit.MINUTES;
            case "hr" :
                return TimeUnit.HOURS;
            case "d" :
                return TimeUnit.DAYS;
            case "ms" :
            default :
                return TimeUnit.MILLISECONDS;
        }
    }
}
