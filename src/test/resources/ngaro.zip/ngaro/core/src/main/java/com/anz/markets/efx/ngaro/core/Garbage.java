package com.anz.markets.efx.ngaro.core;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation added to types or methods which are not garbage free.
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface Garbage {
    enum Type {
        /**
         * The result is (at least sometimes) allocated, but the method does not produce any intermediary garbage other
         * than the result.
         */
        RESULT,
        /**
         * The method or class does not normally produce garbage but it may do so in rare events for instance when
         * doubling the array backing a list when the array capacity needs to be enlarged.
         */
        RARE,
        /**
         * The implementation uses thread locals which for temporary objects which could become garbage once the threads
         * become garbage.
         */
        THREAD_LOCALS,
        /**
         * The method produces intermediary objects or calles other methods which potentially create garbage.
         */
        ANY
    }
    Type[] value();

    /**
     * Optional description value with detailed information about when and how garbage might occur.
     */
    String description() default "";
}
