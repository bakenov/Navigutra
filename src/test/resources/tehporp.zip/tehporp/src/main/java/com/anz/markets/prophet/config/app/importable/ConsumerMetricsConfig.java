package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.disco.data.SignalRegisters;
import com.anz.markets.prophet.backtest.BackTestManager;
import com.anz.markets.prophet.config.business.FailSafeConfigManager;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.marketdata.FilteredMarketDataSnapshotManager;
import com.anz.markets.prophet.marketdata.aggbook.AggregatedBookManager;
import com.anz.markets.prophet.syscontrol.NoConsumer;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

import java.io.IOException;
import java.util.function.Consumer;

@Configuration
@Import({BusinessConfig.class, BackTestConfig.class})
@PropertySources({
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class ConsumerMetricsConfig {

    @Bean
    public FailSafeConfigManager failSafeConfigManager(final ConfigurationData configurationDataDefault,
                                                 final AggregatedBookManager primaryAggregatedBookManager,
                                                 final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager,
                                                 final BackTestManager backTestManager,
                                                 @Value("${business.config.json.file:/business.config.json}") final String jsonFile,
                                                 @Value("${fail.safe.config.manager.should.initialise.with.cache:true}") final boolean shouldInitialiseWithCache) throws IOException {

        final Consumer<IndexedConfigurationData> consumers = new NotifierDefault<>(
                primaryAggregatedBookManager.consumerOfIndexedConfigurationData(),
                filteredMarketDataSnapshotManager.consumerIndexedConfigurationData());

        final boolean writeToDisk = false;
        return FailSafeConfigManager.createInstance(shouldInitialiseWithCache, writeToDisk, backTestManager.isBackTestEnabled(),
                (ConfigurationDataDefault) configurationDataDefault, jsonFile, consumers);
    }

    @Bean
    public FailSafeConfigManager failSafeConfigManager2(final ConfigurationData configurationDataDefault,
                                                   final AggregatedBookManager primaryAggregatedBookManager2,
                                                   final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager2,
                                                   final BackTestManager backTestManager,
                                                   @Value("${business.config.json.file:/business.config.json}") final String jsonFile,
                                                   @Value("${fail.safe.config.manager.should.initialise.with.cache:true}") final boolean shouldInitialiseWithCache) throws IOException {

        final Consumer<IndexedConfigurationData> consumers = new NotifierDefault<>(
                primaryAggregatedBookManager2.consumerOfIndexedConfigurationData(),
                filteredMarketDataSnapshotManager2.consumerIndexedConfigurationData());

        final boolean writeToDisk = false;
        return FailSafeConfigManager.createInstance(shouldInitialiseWithCache, writeToDisk, backTestManager.isBackTestEnabled(),
                (ConfigurationDataDefault) configurationDataDefault, jsonFile, consumers);
    }

    @Bean
    public Consumer<ConfigurationData> inConfigurationDataConsumer(final FailSafeConfigManager failSafeConfigManager) {
        return failSafeConfigManager.consumerConfigurationData();
    }

    @Bean
    public Consumer<ConfigurationData> inConfigurationDataConsumer2(final FailSafeConfigManager failSafeConfigManager2) {
        return failSafeConfigManager2.consumerConfigurationData();
    }

    @Bean
    public Consumer<MarketData> inMarketDataConsumers(final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager) {
        return filteredMarketDataSnapshotManager.consumerOfMarketData();
    }

    @Bean
    public Consumer<MarketData> inMarketDataConsumers2(final FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager2) {
        return filteredMarketDataSnapshotManager2.consumerOfMarketData();
    }

    @Bean
    public FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager(final AggregatedBookManager primaryAggregatedBookManager,
                                                                                    final Consumer<FilteredMarketDataSnapshot> marketDepthSink) {
        return new FilteredMarketDataSnapshotManager(new NotifierDefault<>(primaryAggregatedBookManager.consumerOfMarketData()),new NotifierDefault<>(marketDepthSink),new SignalRegisters(), signals -> {});
    }

    @Bean
    public FilteredMarketDataSnapshotManager filteredMarketDataSnapshotManager2(final AggregatedBookManager primaryAggregatedBookManager2,
                                                                               final Consumer<FilteredMarketDataSnapshot> marketDepthSink2) {
        return new FilteredMarketDataSnapshotManager(new NotifierDefault<>(primaryAggregatedBookManager2.consumerOfMarketData()),new NotifierDefault<>(marketDepthSink2),new SignalRegisters(),signals -> {});
    }

    @Bean
    public AggregatedBookManager primaryAggregatedBookManager(
            final Consumer<FilteredMarketDataSnapshot> marketDepthSink) {
        final Consumer<MidRate> changedMidRateConsumers = new NotifierDefault(marketDepthSink);
        return new AggregatedBookManager(Market.WSP_U, changedMidRateConsumers, NoConsumer.instance());
    }

    @Bean
    public AggregatedBookManager primaryAggregatedBookManager2(
            final Consumer<FilteredMarketDataSnapshot> marketDepthSink2) {
        final Consumer<MidRate> changedMidRateConsumers = new NotifierDefault(marketDepthSink2);
        return new AggregatedBookManager(Market.WSP_U, changedMidRateConsumers, NoConsumer.instance());
    }

}
