// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import quickfix.Message;
import quickfix.SessionID;

/**
 * Simple wrapper for a QuickFIX message.
 */
public class QuickFixSessionMessage
{
    private final Message   message;
    private final SessionID sessionID;
    private final String    msgType;

    /**
     * @param message
     * @param sessionID
     * @param msgType
     */
    public QuickFixSessionMessage(final Message message,
                                  final SessionID sessionID,
                                  final String msgType)
    {
        this.message = message;
        this.sessionID = sessionID;
        this.msgType = msgType;
    }

    /**
     * @return the message
     */
    public Message getMessage()
    {
        return this.message;
    }

    /**
     * @return the sessionID
     */
    public SessionID getSessionID()
    {
        return this.sessionID;
    }

    /**
     * @return the msgType
     */
    public String getMsgType()
    {
        return this.msgType;
    }
}
