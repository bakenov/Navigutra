package com.anz.markets.efx.fox.processor.timer;

public interface Timer {
    void schedule(long timeoutMillis);
    void cancel();

    interface Factory {
        Timer create(TimerScheduler.ExpiryHandler expiryHandler);
    }
}
