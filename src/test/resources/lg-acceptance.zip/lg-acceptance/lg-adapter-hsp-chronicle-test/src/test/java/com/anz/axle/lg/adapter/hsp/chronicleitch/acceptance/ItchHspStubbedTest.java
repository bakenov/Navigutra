package com.anz.axle.lg.adapter.hsp.chronicleitch.acceptance;

import java.io.File;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.anz.markets.efx.ngaro.api.Venue;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.OS;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.itch.cfg.ItchEngineCfg;
import software.chronicle.itch.cfg.ItchSessionCfg;
import software.chronicle.itch.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.itch.sessioncode.messages.client.LoginRequest;
import software.chronicle.itch.sessioncode.messages.client.LogoutRequest;
import software.chronicle.itch.staticcode.ChronicleItchEngine;
import software.chronicle.itch.staticcode.ItchClientSessionHandler;
import software.chronicle.itch.tools.ItchToDTO;
import software.chronicle.itchcboe.messages.CancelOrder;
import software.chronicle.itchcboe.messages.MarketSnapshot;
import software.chronicle.itchcboe.messages.ModifyOrder;
import software.chronicle.itchcboe.messages.NewOrder;
import software.chronicle.itchcboe.messages.client.MarketDataSubscribeRequest;
import software.chronicle.itchcboe.messages.datamodel.DefaultCancelOrder;
import software.chronicle.itchcboe.messages.datamodel.DefaultMarketSnapshot;
import software.chronicle.itchcboe.messages.datamodel.DefaultModifyOrder;
import software.chronicle.itchcboe.messages.datamodel.DefaultNewOrder;
import software.chronicle.itchcboe.messages.datamodel.server.DefaultLoginAccepted;
import software.chronicle.itchcboe.messages.datamodel.server.DefaultSequenced;
import software.chronicle.itchcboe.messages.server.LoginAccepted;
import software.chronicle.itchcboe.messages.server.Sequenced;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.TestUtils;
import com.anz.axle.lg.adapter.hsp.acceptance.AcceptanceConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.getRandomFreeLocalPort;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ItchHspStubbedTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItchHspStubbedTest.class);
    private static final String HOST = "localhost";
    private static final String PORT = String.valueOf(getRandomFreeLocalPort());
    private static final String CCY_PAIR = "GBP/JPY";
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("GBPJPY", SecurityType.FXSPOT, Tenor.SP);

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(
                ItchEngineCfg.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                LoggingMode.class);
    }

    @Rule
    public final TestName testName = new TestName();
    // client side
    private Application application;

    private SharedAcceptanceContext acceptanceContext;
    // Server side
    private ItchEngineCfg cfg;
    private ChronicleItchEngine engine;

    private ItchClientSessionHandler serverSession;
    private ItchToDTO itchToDTO;
    private BlockingQueue<Marshallable> serverReceiveQueue;

    @Before
    public void setUp() throws Exception {

        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        final String venue = testName.getMethodName().contains(Venue.CMEJMP.name()) ? Venue.CMEJMP.name() : Venue.HSP.name();
        System.getProperties().putAll(StringUtils.parseMap(
    "appName:lg-hsp" +
                ",default.log.appender:Console" +
                ",default.log.level:DEBUG" +
                ",hsp.itch.pricing.log_all:false" +
                ",hsp.itch.pricing.host:"+ HOST +
                ",hsp.itch.pricing.port:"+ PORT +
                ",hsp.itch.pricing.username:test_username" +
                ",hsp.itch.pricing.password:test_password" +
                ",hsp.itch.pricing.session.enable:true" +
                ",hsp.fix.trading.session.enable:false" +
                ",hsp.fix.trading.log_all:false" +
                ",chronicle.fix.logging:false" +
                ",venue:" + venue
        ));
        startServerSide();

        application = new Application("lg-hsp-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);

        assertTrue(TestUtils.waitFor(() -> serverSession.isConnected(), 30_000));
        LOGGER.info("Server connected.");
    }

    @After
    public void tearDown() throws Exception {
        waitForStop(application, 3, 500, testName.getMethodName());
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private void startServerSide() throws Exception {

        cfg = Marshallable.fromFile("itch-cboe-cfg.yaml");
        final ItchSessionCfg sessionCfg = (ItchSessionCfg) cfg.fixSessionCfgs().iterator().next();
        String fileStorePath = sessionCfg.fileStorePath();
        fileStorePath = OS.TARGET + "/" + System.currentTimeMillis() + "/" + fileStorePath;
        new File(fileStorePath).deleteOnExit();
        assertEquals(sessionCfg.name(), "SERVER");
        sessionCfg.socketAcceptorHostPort(HOST +":"+ PORT);

        sessionCfg.fileStorePath(OS.TARGET + "/" + System.currentTimeMillis() + "/" + sessionCfg.fileStorePath());
        new File(sessionCfg.fileStorePath()).deleteOnExit();

        engine = new ChronicleItchEngine(cfg.fixSessionCfgs());
        serverSession = (ItchClientSessionHandler) engine.getHandler("SERVER");

        itchToDTO = new ItchToDTO(new software.chronicle.itchcboe.parsers.server.MessageParser(), software.chronicle.itchcboe.messages.MessageNotifier.class);
        serverReceiveQueue = ((TestMessageNotifier) serverSession.messageNotifier()).queue();
    }

    @Test
    public void logonSubscribeReceivePricesLogoff() throws Exception {
        System.out.println("GBP/JPY instrumentId="+INSTRUMENT_KEY.instrumentId());

        // wait for login request and reply with accept
        waitFor(LoginRequest.class);
        serverSession.sendMessage((LoginAccepted)parse("A         1|", new DefaultLoginAccepted()));

        // wait for subscribe and reply prices
        waitFor((m) -> m instanceof MarketDataSubscribeRequest && ((MarketDataSubscribeRequest)m).ccyPair().equals(CCY_PAIR));

        // reply prices
        serverSession.sendMessage(marketSnapshot("S230607899S   109   1GBP/JPY   1142.640      11000000         122354            1144.000      11000000         122355         |"));
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryId().eq(1))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryId().eq(2))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        serverSession.sendMessage(newOrder("S230613039NBGBP/JPY122356         143.039   1000000         |"));
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryId().eq(3))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // new orderid 122357 with amount of 1000000
        serverSession.sendMessage(newOrder("S230613039NSGBP/JPY122357         143.537   1000000         |"));
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryId().eq(4))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntrySize().eq(1000000d))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // modify orderid 122357 with to amount of 5000000
        serverSession.sendMessage(modifyOrder("S230613039MGBP/JPY122357         5000000         |"));
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.CHANGE))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryId().eq(4))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntrySize().eq(5000000d))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // new order 122358 for cancel
        serverSession.sendMessage(newOrder("S230613039NBGBP/JPY122358         143.038   1000000         |"));
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.NEW))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryId().eq(5))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // cancel orderId 122358
        serverSession.sendMessage(cancelOrder("S230613039XGBP/JPY122358         |"));
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().countEquals(1)
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdUpdateAction().eq(UpdateAction.DELETE))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(IncrementalRefreshMatcher.mdEntryId().eq(5))
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        // send logoff, trigger logoff in lg-adapter
        serverSession.sendMessage((Sequenced)parse("S|", new DefaultSequenced()));

        // empty snapshot
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(InstrumentKey.instrumentId("GBPJPY")))
                        .entries().countEquals(0)
                ).awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        waitFor(LogoutRequest.class);
    }

    @Test
    public void testVenueCMPJMPlogon() throws Exception {
        waitFor(LoginRequest.class);
    }

    private Marshallable waitFor(final Class<? extends StandardHeaderTrailer> itchMessageClass, final int timeout) throws InterruptedException {
        return waitFor((m) -> itchMessageClass.isInstance(m), timeout);
    }

    private Marshallable waitFor(final Class<? extends StandardHeaderTrailer> itchMessageClass) throws InterruptedException {
        return waitFor(itchMessageClass, 5);
    }

    private Marshallable waitFor(final Predicate<Object> predicate) throws InterruptedException {
        return waitFor(predicate, 5);
    }

    private Marshallable waitFor(final Predicate<Object> predicate, final int timeout) throws InterruptedException {
        return Asserter.of(serverReceiveQueue)
                .matching(predicate)
                .awaitMatchAndGetLast(timeout, TimeUnit.SECONDS);
    }

    private MarketSnapshot marketSnapshot(final String itchMsg) {
        return (MarketSnapshot) parse(itchMsg, new DefaultMarketSnapshot());
    }

    private NewOrder newOrder(final String itchMsg) {
        return (NewOrder) parse(itchMsg, new DefaultNewOrder());
    }

    private CancelOrder cancelOrder(final String itchMsg) {
        return (CancelOrder) parse(itchMsg, new DefaultCancelOrder());
    }

    private ModifyOrder modifyOrder(final String itchMsg) {
        return (ModifyOrder) parse(itchMsg, new DefaultModifyOrder());
    }

    private StandardHeaderTrailer parse(final String itchMsg, final StandardHeaderTrailer o) {
        final AtomicBoolean first = new AtomicBoolean(true);
        final Consumer<StandardHeaderTrailer> receiver = (m) -> {
            if (first.get()) {
                m.copyTo(o);
                first.set(false);
            }
        };

        itchToDTO.parse(Bytes.from(itchMsg.replace('|', '\n')), receiver);
        return o;
    }
}
