package com.anz.markets.efx.fox.firewall.rule.customer;

import java.util.Objects;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

/**
 * Executes customer rule
 *
 */
public class CustomerRule implements Rule, Comparable<CustomerRule> {
    private final long id;
    private final RuleMatcher ruleMatcher;
    private final Predicate<NewOrderSingleDecoder> orderMatcher;
    private final String description;

    private final Predicate<NewOrderSingleDecoder> customerRuleProcessor;

    public CustomerRule(final String firewallName,
                        final long id,
                        final String comment,
                        final RuleMatcher ruleMatcher,
                        final Predicate<NewOrderSingleDecoder> orderMatcher,
                        final Predicate<NewOrderSingleDecoder> customerRuleProcessor) {
        this.id = id;
        this.ruleMatcher = Objects.requireNonNull(ruleMatcher);
        this.orderMatcher = Objects.requireNonNull(orderMatcher);
        this.customerRuleProcessor = Objects.requireNonNull(customerRuleProcessor);
        this.description = "firewallName=" + Objects.requireNonNull(firewallName) + ", ruleId=" + id + "(" + comment+ ")";
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        return customerRuleProcessor.test(newOrderSingle);
    }

    @Override
    public int compareTo(final CustomerRule o) {
        return ruleMatcher.compareTo(o.ruleMatcher);
    }

    public boolean match(final NewOrderSingleDecoder newOrderSingle) {
        return orderMatcher.test(newOrderSingle);
    }

    public long id() {
        return id;
    }

    public String description() {
        return description;
    }

    @Override
    public int priority() {
        return 0;
    }

}
