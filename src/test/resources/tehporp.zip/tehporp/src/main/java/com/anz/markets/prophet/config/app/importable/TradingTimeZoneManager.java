package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.status.Context;

import java.util.function.Consumer;

public class TradingTimeZoneManager implements Consumer<TradingTimeZoneChime> {
    private final Consumer<TradingTimeZoneChime> nfy;

    public TradingTimeZoneManager(final Consumer<TradingTimeZoneChime> nfy) {
        this.nfy = nfy;
    }

    @Override
    public void accept(final TradingTimeZoneChime tradingTimeZoneChime) {
        Context.context().tradingTimeZone(tradingTimeZoneChime.getTradingTimeZone());
        nfy.accept(tradingTimeZoneChime);
    }
}
