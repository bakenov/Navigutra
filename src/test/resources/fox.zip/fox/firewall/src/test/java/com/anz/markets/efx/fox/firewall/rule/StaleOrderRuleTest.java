package com.anz.markets.efx.fox.firewall.rule;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Tests for class StaleOrderRule
 */
@ExtendWith(MockitoExtension.class)
class StaleOrderRuleTest {

    private static final long TIMEOUT = 1000;

    @Mock
    private NewOrderSingleDecoder newOrderSingle;
    @Mock
    private NewOrderSingleDecoder.Body body;

    private StaleOrderRule rule;
    private long currentTime;
    private long transactionTime;

    @BeforeEach
    void setUp() {
        transactionTime = System.nanoTime();
        rule = new StaleOrderRule(TIMEOUT);
        newOrderSingle = mock(NewOrderSingleDecoder.class);
        body = mock(NewOrderSingleDecoder.Body.class);
        when(newOrderSingle.body()).thenReturn(body);
        when(body.transactTime()).thenReturn(transactionTime);
    }

    @Test
    void validate_should_succeed() {
        currentTime = transactionTime + 100;
        assertThat(rule.validate(newOrderSingle, currentTime)).isTrue();
    }

    @Test
    void validate_just_miss_should_not_succeed() {
        currentTime = transactionTime + TimeUnit.NANOSECONDS.convert(TIMEOUT, TimeUnit.MILLISECONDS) + 1;
        assertThat(rule.validate(newOrderSingle, currentTime)).isFalse();
    }

    @Test
    void validate_should_not_succeed() {
        currentTime = transactionTime + TimeUnit.NANOSECONDS.convert(TIMEOUT, TimeUnit.MILLISECONDS) + 100;
        assertThat(rule.validate(newOrderSingle, currentTime)).isFalse();
    }

    @Test
    void validate_exact_threshold_boundary() {
        currentTime = transactionTime + TimeUnit.NANOSECONDS.convert(TIMEOUT, TimeUnit.MILLISECONDS);
        assertThat(rule.validate(newOrderSingle, currentTime)).isTrue();
    }

    @Test
    void validate_no_delay() {
        currentTime = transactionTime;
        assertThat(rule.validate(newOrderSingle, currentTime)).isTrue();
    }

}