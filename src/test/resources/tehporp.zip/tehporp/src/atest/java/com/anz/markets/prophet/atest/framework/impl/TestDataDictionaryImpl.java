package com.anz.markets.prophet.atest.framework.impl;

import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumSet;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.atest.framework.TestDataDictionary;
import com.anz.markets.prophet.config.business.RealisedVolatilityConfig;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveNewsHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTakeProfitHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTwapHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgeFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgePortfolioConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.MidHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.PassiveHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AdjustAggregatedConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveNewsHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTakeProfitHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.BenchmarkSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.DriverMarketChooserConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsItemConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsWideningConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.FilterEnabledConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.LatencyFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.LiquidityFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketGapFactorConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketGapToWideningFactorConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketWideningFactorToDecayPeriodConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MinimumMarketFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionSkewRatioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.OptimalPositionConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PassiveHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingArbitrageFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.RiskAdjustedFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StaleFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolatilityWideningConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolumeSkewConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LiquidityFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.StaleFilterConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.Country;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.CurrencyGroup;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.PriceAndQty;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.TradeType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.VolatilityType;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.BiasPositionControlImpl;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeControlImpl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControlImpl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.HedgerFirewallResetImpl;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.ManualSkewControlImpl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.PricePauseControlImpl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControlImpl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.control.VolatilityControlImpl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.forward.ForwardPointSource;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataDeleteOrderImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataIncrementImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.order.OrderEventType;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.order.impl.OrderEventImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.AdjustmentImpl;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.AdjustmentsImpl;
import com.anz.markets.prophet.risk.GradientOptimalPosition;
import com.anz.markets.prophet.status.Context;
import com.google.common.collect.Lists;
import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.anz.markets.prophet.domain.Instrument.ANY;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_ARBITRAGE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_RFX;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.domain.Region.JP;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;


/**
 * Encapsulate all test data and its complex creation pattern.
 */
public class TestDataDictionaryImpl implements TestDataDictionary {

    public static final double MD_SPREAD = 0.1;  // TODO:: should be 0.0001 PLEASE INVESTIGATE
    public static final Currency[] COVARIANCE_MATRIX_MANAGED_ASSETS = new Currency[]{Currency.AUD, Currency.EUR, Currency.JPY, Currency.NZD, Currency.USD};
    public static final Instrument[] EQUILVALENT_POSITION_MINIMAL_INSTRUMENTS = new Instrument[]{Instrument.AUDJPY, Instrument.AUDNZD, Instrument.EURAUD};
    public final static EnumObjMap<Instrument, OptimalPositionConfig> OPTIMAL_POSITION_CONFIG_MAP = new EnumObjMap<>(Instrument.class);
    protected static final HourChime HOUR_CHIME = HourChime.INSTANCE;
    private static final double MD_MID = 0.9499;
    private static int tradeId = 0;
    private long emptyEventId = now();

    static {
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.AUDJPY, new OptimalPositionConfig(Instrument.AUDJPY, Instrument.AUDJPY, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.AUDNZD, new OptimalPositionConfig(Instrument.AUDNZD, Instrument.AUDNZD, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.AUDUSD, new OptimalPositionConfig(Instrument.AUDUSD, Instrument.AUDUSD, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURAUD, new OptimalPositionConfig(Instrument.EURAUD, Instrument.EURAUD, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURCHF, new OptimalPositionConfig(Instrument.EURCHF, Instrument.EURCHF, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURCZK, new OptimalPositionConfig(Instrument.EURCZK, Instrument.USDCZK, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURDKK, new OptimalPositionConfig(Instrument.EURDKK, Instrument.USDDKK, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURGBP, new OptimalPositionConfig(Instrument.EURGBP, Instrument.EURGBP, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURHUF, new OptimalPositionConfig(Instrument.EURHUF, Instrument.USDHUF, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURJPY, new OptimalPositionConfig(Instrument.EURJPY, Instrument.EURJPY, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURNOK, new OptimalPositionConfig(Instrument.EURNOK, Instrument.USDNOK, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURPLN, new OptimalPositionConfig(Instrument.EURPLN, Instrument.USDPLN, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURSEK, new OptimalPositionConfig(Instrument.EURSEK, Instrument.USDSEK, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.EURUSD, new OptimalPositionConfig(Instrument.EURUSD, Instrument.EURUSD, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.GBPJPY, new OptimalPositionConfig(Instrument.GBPJPY, Instrument.GBPJPY, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.GBPUSD, new OptimalPositionConfig(Instrument.GBPUSD, Instrument.GBPUSD, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.NZDUSD, new OptimalPositionConfig(Instrument.NZDUSD, Instrument.NZDUSD, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDCAD, new OptimalPositionConfig(Instrument.USDCAD, Instrument.USDCAD, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDCHF, new OptimalPositionConfig(Instrument.USDCHF, Instrument.USDCHF, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDCNH, new OptimalPositionConfig(Instrument.USDCNH, Instrument.USDCNH, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDILS, new OptimalPositionConfig(Instrument.USDILS, Instrument.USDILS, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDJPY, new OptimalPositionConfig(Instrument.USDJPY, Instrument.USDJPY, 0.6, 1.5, true));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDMXN, new OptimalPositionConfig(Instrument.USDMXN, Instrument.USDMXN, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDSGD, new OptimalPositionConfig(Instrument.USDSGD, Instrument.USDSGD, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDTHB, new OptimalPositionConfig(Instrument.USDTHB, Instrument.USDTHB, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDTRY, new OptimalPositionConfig(Instrument.USDTRY, Instrument.USDTRY, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDHKD, new OptimalPositionConfig(Instrument.USDHKD, Instrument.USDHKD, 0.6, 1.5, false));
        OPTIMAL_POSITION_CONFIG_MAP.put(Instrument.USDZAR, new OptimalPositionConfig(Instrument.USDZAR, Instrument.USDZAR, 0.6, 1.5, false));
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot_pullPrice(final Market market,
                                                           final Instrument instrument) {
        return emptyMarketDataSnapshot(market, instrument);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot_001() {
        return marketDataSnapshot(Instrument.AUDUSD, MD_MID, MD_SPREAD);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot(final Instrument instrument,
                                                 final double mid,
                                                 final double spread) {
        return marketDataSnapshot(Market.CNX, instrument, mid, spread, now());
    }

    @Override
    public MarketDataIncrement marketDataIncrementNew(final Market market, final Instrument instrument,
                                                      final double price, final long externalSourceId) {
        final long triggerTimeMs = now();
        final double qty = 1_000_000d;
        final MarketDataIncrementImpl marketDataIncrement = new MarketDataIncrementImpl();
        marketDataIncrement.setMarket(market);
        marketDataIncrement.setInstrument(instrument);
        marketDataIncrement.setExternalSourceId(externalSourceId);

        addMarketDataIncrementNewOrder(
                String.valueOf(triggerTimeMs),
                market,
                instrument,
                OrderSide.BID,
                price,
                qty,
                triggerTimeMs, externalSourceId,
                marketDataIncrement.getEventsList()::addFromSupplier);

        addMarketDataIncrementNewOrder(
                String.valueOf(triggerTimeMs << 1),
                market,
                instrument,
                OrderSide.OFFER,
                price,
                qty,
                triggerTimeMs,externalSourceId ,
                marketDataIncrement.getEventsList()::addFromSupplier);
        return marketDataIncrement;
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot(final Instrument instrument,
                                                 final double mid) {
        return marketDataSnapshot(Market.CNX, instrument, mid, MD_SPREAD, now());
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithExternalSourceId(final Instrument instrument,
                                                                     final double mid,
                                                                     final double spread,
                                                                     final long externalSourceId) {
        double bid = mid - spread / 2;
        double offer = mid + spread / 2;
        final List<PriceAndQty> bids = Arrays.asList(new PriceAndQtyImpl(bid, Level.QTY_1M.getQty()));
        final List<PriceAndQty> offers = Arrays.asList(new PriceAndQtyImpl(offer, Level.QTY_1M.getQty()));
        final Market market = Market.CNX;
        final long triggerTimeMs = now();


        final List<String> bidOrderIds = new ArrayList<>(bids.size());
        final List<String> offerOrderIds = new ArrayList<>(offers.size());
        final List<QuoteType> bidQuoteTypes = new ArrayList<>(bids.size());
        final List<QuoteType> offerQuoteTypes = new ArrayList<>(offers.size());
        int i;
        for (i = 0; i < bids.size(); i++) {
            bidQuoteTypes.add(QuoteType.FIRM);
            bidOrderIds.add(String.valueOf(i));
        }
        for (i = 0; i < offers.size(); i++) {
            offerQuoteTypes.add(QuoteType.FIRM);
            offerOrderIds.add(String.valueOf(i));
        }

        MarketDataSnapshotImpl marketDataSnapshot = MarketDataSnapshotImpl.forMarket();
        marketDataSnapshot.setMarket(market);
        marketDataSnapshot.setInstrument(instrument);
        marketDataSnapshot.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(triggerTimeMs));
        marketDataSnapshot.setExternalSourceId(externalSourceId);

        addNewMarketDataOrder(marketDataSnapshot, bids, bidOrderIds, bidQuoteTypes, OrderSide.BID, triggerTimeMs,
                () -> (MarketDataNewOrderImpl) marketDataSnapshot.getBidEventList().addFromSupplier());
        addNewMarketDataOrder(marketDataSnapshot, offers, offerOrderIds, offerQuoteTypes, OrderSide.OFFER, triggerTimeMs,
                () -> (MarketDataNewOrderImpl) marketDataSnapshot.getOfferEventList().addFromSupplier());

        return marketDataSnapshot;
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot(final Market market,
                                                 final Instrument instrument,
                                                 final double mid,
                                                 final double spread) {
        return marketDataSnapshot(market, instrument, mid, spread, now());
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot(final Market market,
                                                 final Instrument instrument,
                                                 final double mid) {
        final double dontCare = 0.0004;
        return marketDataSnapshot(market, instrument, mid, dontCare);
    }

    @Override
    public MarketDataSnapshot emptyMarketDataSnapshot(final Market market,
                                                      final Instrument instrument) {
        MarketDataSnapshotImpl md = MarketDataSnapshotImpl.forMarket();
        md.setEventId(String.valueOf(emptyEventId++));
        md.setMarket(market);
        md.setInstrument(instrument);
        md.setExternalEventTimeNS(Context.context().timeSource().nowNanos());
        return md;
    }

    @Override
    public MarketDataSnapshot emptyMarketDataSnapshot(final Instrument instrument) {
        return emptyMarketDataSnapshot(Market.CNX, instrument);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshot(final Market market,
                                                 final Instrument instrument,
                                                 final double mid,
                                                 final double spread,
                                                 long triggerTimeMs) {
        double bid = mid - spread / 2;
        double offers = mid + spread / 2;
        return marketDataSnapshotWithBidOffer(market, instrument, bid, offers, triggerTimeMs);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffer(final Instrument instrument,
                                                             final double bid,
                                                             final double offer) {
        return marketDataSnapshotWithBidOffer(Market.CNX, instrument, bid, offer);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                             final Instrument instrument,
                                                             final double bid,
                                                             final double offer) {
        return marketDataSnapshotWithBidOffer(market, instrument, bid, Level.QTY_1M.getQty(), offer, Level.QTY_1M.getQty(), now());
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                             final Instrument instrument,
                                                             final double bid,
                                                             final double bidQty,
                                                             final double offer,
                                                             final double offerQty) {
        return marketDataSnapshotWithBidOffer(market, instrument, bid, bidQty, offer, offerQty, now());
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                             final Instrument instrument,
                                                             final double bid,
                                                             final double offer,
                                                             final long triggerTimeMs) {
        return marketDataSnapshotWithBidOffer(market, instrument, bid, Level.QTY_1M.getQty(), offer, Level.QTY_1M.getQty(), triggerTimeMs);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                             final Instrument instrument,
                                                             final double bid,
                                                             final double bidQty,
                                                             final double offer,
                                                             final double offerQty,
                                                             final long triggerTimeMs) {
        return marketDataSnapshotWithBidOffers(market, instrument, Arrays.asList(new PriceAndQtyImpl(bid, bidQty)), Arrays.asList(new PriceAndQtyImpl(offer, offerQty)), triggerTimeMs);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffers(final Market market,
                                                              final Instrument instrument,
                                                              final List<PriceAndQty> bids,
                                                              final List<QuoteType> bidQuoteTypes,
                                                              final List<PriceAndQty> offers,
                                                              final List<QuoteType> offerQuoteTypes,
                                                              final long triggerTimeMs) {
        return marketDataSnapshotWithBidOfferOrderIds(market,
                instrument,
                bids,
                IntStream.range(0, bids.size()).boxed().map(String::valueOf).collect(Collectors.toList()),
                bidQuoteTypes,
                offers,
                IntStream.range(0, offers.size()).boxed().map(String::valueOf).collect(Collectors.toList()),
                offerQuoteTypes,
                triggerTimeMs);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOffers(final Market market,
                                                              final Instrument instrument,
                                                              final List<PriceAndQty> bids,
                                                              final List<PriceAndQty> offers,
                                                              final long triggerTimeMs) {
        final List<String> bidOrderIds = new ArrayList<>(bids.size());
        final List<String> offerOrderIds = new ArrayList<>(offers.size());
        final List<QuoteType> bidQuoteTypes = new ArrayList<>(bids.size());
        final List<QuoteType> offerQuoteTypes = new ArrayList<>(offers.size());
        int i;
        for (i = 0; i < bids.size(); i++) {
            bidQuoteTypes.add(QuoteType.FIRM);
            bidOrderIds.add(String.valueOf(i));
        }
        for (i = 0; i < offers.size(); i++) {
            offerQuoteTypes.add(QuoteType.FIRM);
            offerOrderIds.add(String.valueOf(i));
        }
        return marketDataSnapshotWithBidOfferOrderIds(market, instrument, bids, bidOrderIds, bidQuoteTypes, offers, offerOrderIds, offerQuoteTypes, triggerTimeMs);
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOfferOrderIds(final Market market,
                                                                     final Instrument instrument,
                                                                     final List<PriceAndQty> bids,
                                                                     final List<String> bidOrderIds,
                                                                     final List<PriceAndQty> offers,
                                                                     final List<String> offerOrderIds,
                                                                     final long triggerTimeMs) {

        return marketDataSnapshotWithBidOfferOrderIds(market,
                instrument,
                bids,
                bidOrderIds,
                bids.stream().map(b -> QuoteType.FIRM).collect(Collectors.toList()),
                offers,
                offerOrderIds,
                offers.stream().map(o -> QuoteType.FIRM).collect(Collectors.toList()),
                triggerTimeMs);
    }

    private void addNewMarketDataOrder(final MarketDataSnapshotImpl snapshot,
                                       final List<PriceAndQty> entries,
                                       final List<String> ids,
                                       final List<QuoteType> quoteTypes,
                                       final OrderSide side,
                                       final long triggerTimeMs, final Supplier<MarketDataNewOrderImpl> addFromSupplier) {
        MarketDataNewOrderImpl entry;
        for (int i = 0; i < entries.size(); i++) {
            entry = addFromSupplier.get();
            entry.setPrice(entries.get(i).getPrice());
            entry.setQuantity(entries.get(i).getQuantity());
            entry.setSide(side);
            entry.setOrderId(ids.get(i));
            entry.setQuoteType(quoteTypes.get(i));
            entry.setMarket(snapshot.getMarket());
            entry.setInstrument(snapshot.getInstrument());
            entry.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(triggerTimeMs));
            entry.setExternalSourceId(snapshot.getExternalSourceId());
        }
    }

    @Override
    public MarketDataSnapshot marketDataSnapshotWithBidOfferOrderIds(final Market market,
                                                                     final Instrument instrument,
                                                                     final List<PriceAndQty> bids,
                                                                     final List<String> bidOrderIds,
                                                                     final List<QuoteType> bidQuoteTypes,
                                                                     final List<PriceAndQty> offers,
                                                                     final List<String> offerOrderIds,
                                                                     final List<QuoteType> offerQuoteTypes,
                                                                     final long triggerTimeMs) {
        MarketDataSnapshotImpl marketDataSnapshot = MarketDataSnapshotImpl.forMarket();
        marketDataSnapshot.setMarket(market);
        marketDataSnapshot.setInstrument(instrument);
        marketDataSnapshot.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(triggerTimeMs));

        addNewMarketDataOrder(marketDataSnapshot, bids, bidOrderIds, bidQuoteTypes, OrderSide.BID, triggerTimeMs,
                () -> (MarketDataNewOrderImpl) marketDataSnapshot.getBidEventList().addFromSupplier());
        addNewMarketDataOrder(marketDataSnapshot, offers, offerOrderIds, offerQuoteTypes, OrderSide.OFFER, triggerTimeMs,
                () -> (MarketDataNewOrderImpl) marketDataSnapshot.getOfferEventList().addFromSupplier());

        return marketDataSnapshot;
    }

    @Override
    public MarketDataIncrement marketDataIncrementDelete(Market market,
                                                         Instrument instrument,
                                                         String orderId,
                                                         OrderSide orderSide,
                                                         long triggerTimeMs) {
        MarketDataIncrementImpl increment = new MarketDataIncrementImpl();
        increment.setMarket(market);
        increment.setInstrument(instrument);

        MarketDataDeleteOrderImpl deleteOrder = (MarketDataDeleteOrderImpl) increment.getEventsList().addFromSupplier(MarketDataDeleteOrderImpl.class);
        deleteOrder.setOrderId(orderId);
        deleteOrder.setMarket(market);
        deleteOrder.setInstrument(instrument);
        deleteOrder.setSide(orderSide);
        deleteOrder.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(triggerTimeMs));

        return increment;
    }

    private void addMarketDataIncrementNewOrder(final String orderId,
                                                final Market market,
                                                final Instrument instrument,
                                                final OrderSide side,
                                                final double price,
                                                final double qty,
                                                final long triggerTimeMs,
                                                final long externalSourceId,
                                                final Function<Class<?>, MarketDataOrder> orderSupplier){

        MarketDataNewOrderImpl order = (MarketDataNewOrderImpl) orderSupplier.apply(MarketDataNewOrderImpl.class);
        order.setOrderId(orderId);
        order.setMarket(market);
        order.setInstrument(instrument);
        order.setSide(side);
        order.setPrice(price);
        order.setQuantity(qty);
        order.setExternalSourceId(externalSourceId);
        order.setExternalEventTimeNS(TimeUnit.MILLISECONDS.toNanos(triggerTimeMs));
    }

    @Override
    public MarketDataSnapshot skew(final double points,
                                   final MarketDataSnapshot marketDataMessage) {

        MarketDataSnapshotImpl marketDataSnapshot = MarketDataSnapshotImpl.forMarket();
        marketDataSnapshot.copy((MarketDataSnapshotImpl) marketDataMessage);

        marketDataSnapshot.getBidEventList().forEach(o -> ((MarketDataNewOrderImpl)o).setPrice(o.getPrice() + points));
        marketDataSnapshot.getOfferEventList().forEach(o -> ((MarketDataNewOrderImpl)o).setPrice(o.getPrice() + points));

        return marketDataSnapshot;
    }

    @Override
    public HourChime hourChime(int hourOfDayInUtc) {
        HOUR_CHIME.setHourOfDayUTC(hourOfDayInUtc);
        return HOUR_CHIME;
    }

    @Override
    public ConfigurationDataDefault configuration_pricing_base() {
        EconNews econNews = econNews(now());

        final ConfigurationDataDefault configurationData = new ConfigurationDataDefault()
                .setEconNewsItemConfigs(new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_5, Currency.AUD))
                .setEconNewsWideningConfigs(new EconNewsWideningConfigImpl(EconNewsWeight.W_5, 5.0, 500, 500, false, Market.ANY))

                .setClientSpreadConfigs(Arrays.asList(
                        // spread config for driver pairs
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 9.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 20),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 25),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDTHB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDTHB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDTHB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDTHB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.7),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.SNG, 2.7),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.3),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 9.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.1),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 20),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 25),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 9.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 20),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 25),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 7.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURDKK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 9.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURGBP, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.GBPUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCAD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 10),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 20),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 25),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 7.0),
                        //
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 7.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURDKK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 9.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURGBP, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.EURUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.GBPUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCAD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 10),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 20),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 25),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 7.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURDKK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 9.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURGBP, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 50),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 60),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 80),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 100),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.EURUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.GBPUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCAD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 6.0),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 10),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 20),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDCHF, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 25),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDJPY, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURDKK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURGBP, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 40),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.GBPUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDCAD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDCHF, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.3)
                ))
                .setSyntheticInstrumentConfigs(Arrays.asList(
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDDKK).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDJPY).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDSEK).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.CADJPY).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.CHFJPY).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.DKKHKD).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.EURCAD).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.HKDDKK).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.NOKSEK).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.USDDKK).setMarkets("WSP_A"),

                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDEUR).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDGBP).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.NZDAUD).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.NZDEUR).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.NZDGBP).setMarkets("WSP_A"),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.GBPEUR).setMarkets("WSP_A")
                ))
                .setSyntheticWideningFactors(Arrays.asList(
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.JPY, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.DKK, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.SEK, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.CAD, Currency.JPY, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.CHF, Currency.JPY, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.EUR, Currency.CAD, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.HKD, Currency.DKK, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.NOK, Currency.SEK, Market.WSP_A, 1.0),
                        SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.USD, Currency.DKK, Market.WSP_A, 1.0)
                ))
                .setKeyValueConfigs(Lists.newArrayList(
                        new KeyValueConfigImpl(KeyValueConfigType.PAUSE_HEDGING_PERIOD_SEC, 5),
                        new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_MIDRATE_MARKET, Market.WSP_U),
                        new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET, new Instrument[] { Instrument.ANY }),
                        new KeyValueConfigImpl(KeyValueConfigType.HEDGING_TRADEABLE_HEDGING_INSTRUMENTS, new Instrument[]{Instrument.AUDUSD}),
                        new KeyValueConfigImpl(KeyValueConfigType.RISK_COVARIANCE_MATRIX_MANAGED_ASSETS, COVARIANCE_MATRIX_MANAGED_ASSETS),
                        new KeyValueConfigImpl(KeyValueConfigType.EQUILVALENT_POSITION_MINIMAL_INSTRUMENT_SET, EQUILVALENT_POSITION_MINIMAL_INSTRUMENTS),
                        new KeyValueConfigImpl(KeyValueConfigType.MARKET_ORDER_BOOK_SLOWEST_MARKET_TOLERANCE_MS, Long.MAX_VALUE),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_PREDICTOR_SKEW_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.4),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 100000.0),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 1000),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 100000.0),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 1000),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 1000),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_INPUT_LATENCY_BARRIER_MS, 0L),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_INPUT_LATENCY_RESUME_MS, 0L),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_TAGGED_INDICATIVE_ENABLED, true),
                        new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_ENABLED, true),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, false),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_POINTS_MAX_AGE_MS, 1800000L),
                        new KeyValueConfigImpl(KeyValueConfigType.RISK_PATH_PUBLISHING_REGION, Region.GB),
                        new KeyValueConfigImpl(KeyValueConfigType.RISK_PATH_PUBLISHING_ENABLED, true),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_DIVERGENCE_ALLOWANCE, 100.0),
                        new KeyValueConfigImpl(KeyValueConfigType.POSITION_BIAS_OFFSET_CURRENCY_LIMIT_USD, 15_000_000.0),
                        new KeyValueConfigImpl(KeyValueConfigType.POSITION_BIAS_OFFSET_TOTAL_LIMIT_USD, 20_000_000.0),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_SHORTCIRCUIT_AGGRESSIVE_LATENCY_THRESHOLD_NS, 0L),
                        new KeyValueConfigImpl(KeyValueConfigType.HEDGING_LIQUIDITY_CHECK_MARKET, Market.WSP_BENCH),
                        new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SIMULTANEOUS_SKEW_EXPERIMENTS, 1),
                        new KeyValueConfigImpl(KeyValueConfigType.POSITION_IN_SYSTEM_BASE_USE_MIDRATE_ENABLED, false)
                ))
                .setMinimumMarketsFilterConfigs(Arrays.asList(
                        new MinimumMarketFilterConfigImpl(Instrument.ANY, 1)
                ))
                .setPricingModels(
                        Arrays.asList(
                                new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(true).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                        ))
                .setMarketGapFactorConfigs(Arrays.asList(new MarketGapFactorConfigImpl(FactorWindow.CAT_A, 300L, 1L, 0.75, 0.25, 0.25, 0.75)))
                .setMarketGapToWideningFactorConfigs(Arrays.asList(
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 64.0, 80.0),

                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 64.0, 80.0),

                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 64.0, 80.0),

                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 2.0, 2.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 4.0, 3.5),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 6.0, 10.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 32.0, 40.0),
                        new MarketGapToWideningFactorConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 64.0, 80.0)
                ))
                .setMarketWideningFactorToDecayPeriodConfigs(Arrays.asList(
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 2.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 3.5, 8000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_A, GB, 80.0, 45000),

                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 2.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 3.5, 8000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_B, GB, 80.0, 45000),

                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 2.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 3.5, 8000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_C, GB, 80.0, 45000),

                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 1.0, 0),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 2.0, 1500),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 2.5, 3000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 3.5, 8000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 40.0, 15000),
                        new MarketWideningFactorToDecayPeriodConfigImpl(FactorWindow.CAT_A, Market.WSP_Z, GB, 80.0, 45000)
                ))
                .setInstrumentConfigs(Arrays.asList(
                        new InstrumentConfigImpl(Instrument.AUDEUR).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.AUDDKK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.AUDUSD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.AUDSEK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(3).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(7).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.AUDJPY).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.CADJPY).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.CHFJPY).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.DKKHKD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURAUD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURCAD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURCHF).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURDKK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURGBP).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURJPY).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURNOK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURSEK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.EURUSD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.GBPEUR).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.GBPUSD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.HKDDKK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.NZDUSD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.NOKSEK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDCAD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDCHF).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDHKD).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDNOK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDJPY).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDINR).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDIN1_1M).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDTHB).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(1).setPrecisionMultiplier(2).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDDKK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(1),
                        new InstrumentConfigImpl(Instrument.USDSEK).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4).setSpreadMultiplier(0)
                ))
                .setMarketConfigs(Arrays.asList(
                        // Driver Pairs
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.DEUT).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.FASTMATCH).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.GS).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.RFX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.EURDKK).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.EURGBP).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.EURJPY).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.EURNOK).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.EURSEK).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.EURUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.GBPUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.NZDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.USDCAD).setEnabled(true),
                        new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.USDCAD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.USDCHF).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.USDHKD).setEnabled(true),
                        new MarketConfigImpl(Market.D3).setRegion(GB).setInstrument(Instrument.USDINR).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.USDJPY).setEnabled(true),
                        new MarketConfigImpl(Market.RFX).setRegion(GB).setInstrument(Instrument.USDJPY).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.USDTHB).setEnabled(true),

                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.DEUT).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.FASTMATCH).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.GS).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.HSP).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.RFX).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.EURDKK).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.EURGBP).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.EURJPY).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.EURNOK).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.EURSEK).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.EURUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.GBPUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.NZDUSD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.USDCAD).setEnabled(true),
                        new MarketConfigImpl(Market.HSP).setRegion(JP).setInstrument(Instrument.USDCAD).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.USDCHF).setEnabled(true),
                        new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.USDJPY).setEnabled(true),

                        // (Passive) hedger markets
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.EURCHF).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.EURJPY).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.EURUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.GBPJPY).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.NZDUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDCAD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDCHF).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDCNH).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDJPY).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.RFX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5),

                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.EURCHF).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.EURJPY).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.EURUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.GBPJPY).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.NZDUSD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDCAD).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDCHF).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDCNH).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDJPY).setEnabled(true).setStepSizePips(0.5),
                        new MarketConfigImpl(Market.RFX).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5)
                ))
                .clearAggBooks()
                .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.DEUT,Market.FASTMATCH,Market.GS,Market.HSP,Market.RFX,Market.EBS)
                .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP,Market.RFX)
                .addAggBook(Market.WSP_U,Instrument.EURDKK,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURGBP,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURJPY,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURNOK,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURSEK,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.GBPUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.NZDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.USDCAD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX, Market.HSP)
                .addAggBook(Market.WSP_U,Instrument.USDCHF,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.USDHKD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.USDINR,TradingTimeZone.GLOBAL,Region.GB,Market.D3)
                .addAggBook(Market.WSP_U,Instrument.USDJPY,TradingTimeZone.GLOBAL,Region.GB,Market.CNX, Market.RFX)
                .addAggBook(Market.WSP_U,Instrument.USDTHB,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)

                .addAggBook(Market.WSP_BENCH,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURCHF,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURDKK,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURGBP,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURJPY,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURNOK,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURSEK,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.EURUSD,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.GBPUSD,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.NZDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.USDCAD,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.USDCHF,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.USDHKD,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.USDINR,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.USDJPY,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)
                .addAggBook(Market.WSP_BENCH,Instrument.USDTHB,TradingTimeZone.GLOBAL,Region.GB,Market.AXL)

                .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX,Market.DEUT,Market.FASTMATCH,Market.GS,Market.HSP,Market.RFX)
                .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX,Market.HSP,Market.RFX)
                .addAggBook(Market.WSP_U,Instrument.EURDKK,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURGBP,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURJPY,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURNOK,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURSEK,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.EURUSD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.GBPUSD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.NZDUSD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.USDCAD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX, Market.HSP)
                .addAggBook(Market.WSP_U,Instrument.USDCHF,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.USDHKD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)
                .addAggBook(Market.WSP_U,Instrument.USDINR,TradingTimeZone.GLOBAL,Region.JP,Market.D3)
                .addAggBook(Market.WSP_U,Instrument.USDJPY,TradingTimeZone.GLOBAL,Region.JP,Market.CNX, Market.RFX)
                .addAggBook(Market.WSP_U,Instrument.USDTHB,TradingTimeZone.GLOBAL,Region.JP,Market.CNX)

                // Driver Pairs
                .setStandardMarketSpreadConfigs(Arrays.asList(
                        new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 1.39E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.EURDKK, 2.56E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.EURGBP, 1.39E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.EURNOK, 0.00251, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.EURJPY, 0.00244, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.EURSEK, 0.00244, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.EURUSD, 1.04E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.GBPUSD, 1.39E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.NZDUSD, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDCAD, 1.39E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDHKD, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDCHF, 2.58E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDJPY, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDTHB, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDINR, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                        new StandardMarketSpreadConfigImpl(Instrument.USDIN1_1M, 1.25E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                ))
                .setClientPriceThrottleConfigs(Arrays.asList(
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.INR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.AUD, Currency.GBP),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.CAD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.CHF, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.DKK, Currency.HKD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.GBP),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.NOK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.EUR, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.GBP, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.GBP, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.HKD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.NOK, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.NZD, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.NZD, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.NZD, Currency.GBP),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.CHF),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.HKD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.THB),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.INR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.IN1),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.USD, Currency.SGD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.SGD, Currency.HKD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_A, Currency.HKD, Currency.SGD),

                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.AUD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.AUD, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.AUD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.AUD, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.CAD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.CHF, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.GBP),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.NOK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.EUR, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.GBP, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.GBP, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.NOK, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.NZD, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.USD, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.USD, Currency.CHF),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.USD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.USD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.USD, Currency.INR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_B, Currency.USD, Currency.IN1),

                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.AUD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.AUD, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.AUD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.AUD, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.CAD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.CHF, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.GBP),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.NOK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.EUR, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.GBP, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.GBP, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.NOK, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.NZD, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.USD, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.USD, Currency.CHF),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.USD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.USD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.USD, Currency.INR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_C, Currency.USD, Currency.IN1),

                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.AUD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.AUD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.AUD, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.CAD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.CHF, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.GBP),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.NOK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.EUR, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.GBP, Currency.EUR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.GBP, Currency.USD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.NOK, Currency.SEK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.NZD, Currency.AUD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.USD, Currency.CAD),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.USD, Currency.CHF),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.USD, Currency.JPY),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.USD, Currency.DKK),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.USD, Currency.INR),
                        new ClientPriceThrottleConfigImpl(Market.WSP_Z, Currency.USD, Currency.IN1),

                        new ClientPriceThrottleConfigImpl(Market.WSP_API_6, Currency.AUD, Currency.USD)

                ))
                .setBenchmarkSpreadConfigs(Arrays.asList(
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.AUDEUR, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.AUDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.AUDSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.CADJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        //Not sure why these are required for cross pairs???
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.CHFJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                //                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                //                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURAUD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURGBP, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURNOK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.EURUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.GBPUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.NOKSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.USDCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.USDCHF, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.USDHKD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.USDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.USDDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, GB, Instrument.USDTHB, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),

                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.AUDEUR, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.AUDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        //Not sure why these are required for cross pairs???
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.CHFJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                //                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                //                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURAUD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURGBP, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURNOK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.EURUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.GBPUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.NOKSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.USDCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.USDCHF, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.USDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_B, GB, Instrument.USDDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),

                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.AUDEUR, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.AUDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        //Not sure why these are required for cross pairs???
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.CHFJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                //                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                //                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURAUD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURGBP, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURNOK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.EURUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.GBPUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.NOKSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.USDCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.USDCHF, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.USDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_C, GB, Instrument.USDDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),

                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.AUDEUR, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.AUDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURAUD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURGBP, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURNOK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.EURUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.GBPUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.NOKSEK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.USDCAD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.USDCHF, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.USDJPY, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_Z, GB, Instrument.USDDKK, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL, Market.CNX))
                ))
                .setStaleFilterConfigs(getStaleFilterConfigs(Integer.MAX_VALUE))
                .setLatencyFilterConfigs(Arrays.asList(
                        new LatencyFilterConfigImpl(Market.AXL, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.BARX, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.CNX, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.CITI, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.CMZ, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.CNX, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.DEUT, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.D3, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.EBS, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.GS, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.HSP, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.MSI, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.RFX, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.UBS, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.FASTMATCH, Integer.MAX_VALUE)
                ))
                .setAdjustAggregatedConfigs((Lists.newArrayList(
                        new AdjustAggregatedConfigImpl(ANY, 0))
                ))
                .setDriverMarketChooserConfigs((Lists.newArrayList(
                        new DriverMarketChooserConfigImpl(ANY, Market.WSP_MU))
                ))
                .setLiquidityFilterConfigs(getLiquidityFilterConfigs(0, 0))
                .setHedgeFirewallConfigs(getHedgeFirewallConfigs())
                .setHedgePortfolioConfigs(getHedgePortfolioConfigs())
                .setAggressiveNewsHedgerConfigs(getAggressiveNewsHedgerConfigs())
                .setAggressiveTwapHedgerConfigs(getAggressiveTwapHedgerConfigs())
                .setAggressiveTakeProfitHedgerConfigs(getAggressiveTakeProfitHedgerConfigs())
                .setPassiveHedgerConfigs(getPassiveHedgerConfigs())
                .setMidHedgerConfigs(getMidHedgerConfigs())
                .setRealisedVolatilityConfigs(Arrays.asList(
                        new RealisedVolatilityConfig(FactorWindow.CAT_A, 300, 5000, 5000, 1d, 1d, VolatilityType.SHORT_OPEN_CLOSE, true, true),
                        new RealisedVolatilityConfig(FactorWindow.CAT_B, 300, 300000, 3600000, 1d, 1d, VolatilityType.LONG_OPEN_CLOSE, false, false))
                )
                .setVolatilityWideningConfigs(getVolatilityWideningConfigs())
                .setRiskAdjustedSpreadParams(Arrays.asList(
                        new RiskAdjustedFactor(0.0, 0.0),
                        new RiskAdjustedFactor(0.5, 1.25),
                        new RiskAdjustedFactor(1.0, 1.5),
                        new RiskAdjustedFactor(1.4, 2.0),
                        new RiskAdjustedFactor(2.0, 3.0),
                        new RiskAdjustedFactor(4.0, 5.0),
                        new RiskAdjustedFactor(10.0, 10.0)
                ))
                .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.EUR, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.NOK, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.AUD, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_B, Currency.USD, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_C, Currency.AUD, 7000000.0),
                        new MaxSkewQuantities(Market.WSP_C, Currency.USD, 7000000.0)
                ))
                .setNetOpenPositionLimitConfigs(
                        Arrays.asList(
                                new NetOpenPositionLimitConfigImpl(Currency.AUD, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.CAD, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.CHF, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.CNH, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.CZK, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.DKK, 2e7),
                                new NetOpenPositionLimitConfigImpl(Currency.EUR, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.GBP, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.HKD, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.HUF, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.ILS, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.JPY, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.MXN, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.NOK, 2e7),
                                new NetOpenPositionLimitConfigImpl(Currency.NZD, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.PLN, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.PLN, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.RON, 5000000.0),
                                new NetOpenPositionLimitConfigImpl(Currency.RUB, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.SEK, 2e7),
                                new NetOpenPositionLimitConfigImpl(Currency.SGD, 7e7),
                                new NetOpenPositionLimitConfigImpl(Currency.THB, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.TRY, 1e7),
                                new NetOpenPositionLimitConfigImpl(Currency.USD, 2e7),
                                new NetOpenPositionLimitConfigImpl(Currency.ZAR, 1e7)
                        )
                )
                .setNetOpenPositionSkewRatioConfigs(Arrays.asList(
                        new NetOpenPositionSkewRatioConfigImpl(0.0, 0.0),
                        new NetOpenPositionSkewRatioConfigImpl(0.375, 0.1),
                        new NetOpenPositionSkewRatioConfigImpl(0.75, 0.2),
                        new NetOpenPositionSkewRatioConfigImpl(1.0, 0.3)
                ))
                .setOptimalPositionConfigs(
                        Arrays.asList(
                                new OptimalPositionConfig(Instrument.AUDJPY, Instrument.AUDJPY, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.AUDNZD, Instrument.AUDNZD, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.AUDUSD, Instrument.AUDUSD, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.EURAUD, Instrument.EURAUD, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.EURCHF, Instrument.EURCHF, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURCZK, Instrument.USDCZK, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURDKK, Instrument.USDDKK, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURGBP, Instrument.EURGBP, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURHUF, Instrument.USDHUF, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURJPY, Instrument.EURJPY, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.EURNOK, Instrument.USDNOK, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURPLN, Instrument.USDPLN, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURSEK, Instrument.USDSEK, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.EURUSD, Instrument.EURUSD, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.GBPJPY, Instrument.GBPJPY, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.GBPUSD, Instrument.GBPUSD, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.NZDUSD, Instrument.NZDUSD, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.USDCAD, Instrument.USDCAD, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDCHF, Instrument.USDCHF, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDCNH, Instrument.USDCNH, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDILS, Instrument.USDILS, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDJPY, Instrument.USDJPY, 0.6, 1.5, true),
                                new OptimalPositionConfig(Instrument.USDMXN, Instrument.USDMXN, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDSGD, Instrument.USDSGD, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDTHB, Instrument.USDTHB, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDTRY, Instrument.USDTRY, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDHKD, Instrument.USDHKD, 0.6, 1.5, false),
                                new OptimalPositionConfig(Instrument.USDZAR, Instrument.USDZAR, 0.6, 1.5, false)
                        )
                )
                .setPricingArbitrageFirewallConfigs(Arrays.asList(
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.AUDJPY, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.AUDNZD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.AUDUSD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURAUD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURCHF, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURCZK, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURDKK, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURGBP, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURHUF, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURJPY, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURNOK, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURPLN, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURSEK, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.EURUSD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.GBPJPY, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.GBPUSD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.NZDUSD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDCAD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDCHF, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDCNH, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDILS, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDJPY, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDMXN, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDSGD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDTHB, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDTRY, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDHKD, 0.1, true, false),
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.USDZAR, 0.1, true, false)
                        )
                )
                .setVolumeSkewConfigs(
                        Arrays.asList(
                                new VolumeSkewConfig(Market.ANY, Instrument.ANY, 5_000_000d, 5_000_000d, 0.2, 0.5, false)
                        )
                );

        //                .setPricingArbitrageFirewallConfig(new PricingArbitrageFirewallConfigImpl().setThresholdInPips(0.01));

        // set up throttle config
        final IndexedConfigurationData indexedConfigurationData = new IndexedConfigurationData(configurationData);
        for (ClientPriceThrottleConfig cpc : indexedConfigurationData.getClientPriceThrottleConfigs()) {
            ClientPriceThrottleConfigImpl clientPriceConfig = (ClientPriceThrottleConfigImpl) cpc;
            clientPriceConfig.setNoActivityHeartbeatFrequencyMs(20000).
                    setStartStopTimePeriodMS(0).
                    setLimit(1).
                    setTimePeriod(1).
                    setMinimumPriceDeltaFractionOfSpread(0.01).
                    setOverrideLimit(1).
                    setOverrideTimePeriod(1).
                    setOverrideMinimumPriceDeltaFractionOfMid(0.000001).
                    setMinimumPriceDeltaFractionOfPreviousSpread(0.001);
        }
        return configurationData;
    }

    @Override
    public ConfigurationDataDefault configuration_pricing_001() {
        EconNews econNews = econNews(0);
        return this.configuration_pricing_base()
                .setInstrumentConfigs(Arrays.asList(
                        // todo: why override this?
                        new InstrumentConfigImpl(Instrument.AUDUSD).setSpotDecimalPlaces(4.0).setSpotFractionalPip(1.0).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0.0).setAllInDecimalPlaces(5.0)
                ))
                .setClientSpreadConfigs(Lists.newArrayList(
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.1),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_2M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.11),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.12),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.13),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.14),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.15),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.16),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.11),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.12),

                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.1),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_2M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.11),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.12),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.13),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.14),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.15),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.16),

                        new ClientSpreadConfigImpl(Market.WSP_B, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.11),

                        new ClientSpreadConfigImpl(Market.WSP_C, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.12)
                ))
                .setEconNewsItemConfigs(new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_5, Currency.AUD))
                .setPricingArbitrageFirewallConfigs(Arrays.asList(
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.AUDUSD, 0.1, true, false)
                ))
                .setVolatilityWideningConfigs(getVolatilityWideningConfigs());
    }

    @Override
    public ConfigurationDataDefault configuration_hedging_001() {
        return configuration_pricing_base();
    }

    @Override
    public EconNews econNews(long eventTimeStamp) {
        return new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(eventTimeStamp);
    }

    @Override
    public Trade client_trade_001(final double qty,
                                  double price) {
        return client_trade_001(Instrument.AUDUSD, qty, price);
    }

    @Override
    public Trade client_trade_001(final Instrument instrument,
                                  final double qty,
                                  double price) {
        return buildTrade(Portfolio.CLIENTS, instrument, qty, price, false, Market.WSP_A, TradeType.CLIENT);
    }

    @Override
    public Trade client_trade_002(final Instrument instrument,
                                  final double qty,
                                  final double price,
                                  final CharSequence orderId) {
        return buildTrade(Portfolio.CLIENTS, instrument, qty, price, false, Market.WSP_A, orderId.toString(), TradeType.CLIENT);
    }

    @Override
    public Trade client_trade_001(final Instrument instrument,
                                  final double qty,
                                  double price,
                                  final String counterparty) {
        return buildTrade(Portfolio.CLIENTS, instrument, qty, price, counterparty, false, Market.WSP_A, getNextOrderId(), TradeType.CLIENT);
    }

    @Override
    public Trade hedge_trade_001(final Portfolio portfolio,
                                 final Instrument instrument,
                                 final double qty,
                                 final double price) {
        return buildTrade(portfolio, instrument, qty, price, true, Market.CNX, TradeType.HEDGING);
    }

    @Override
    public Trade hedge_trade_002(final Portfolio portfolio,
                                 final Instrument instrument,
                                 final double qty,
                                 final double price,
                                 final CharSequence orderId) {
        return buildTrade(portfolio, instrument, qty, price, true, Market.CNX, orderId, TradeType.HEDGING);
    }

    @Override
    public ForwardPoint forwardPoint(final Instrument instrument,
                                     final double bidPoints,
                                     final double offerPoints,
                                     final LocalDate referenceSpotDate,
                                     final LocalDate tenorDate, final Tenor tenor) {
        final ForwardPointImpl fp = new ForwardPointImpl();
        fp.setSource(ForwardPointSource.D3);
        fp.setInstrument(instrument);
        fp.setBidPoints(bidPoints);
        fp.setOfferPoints(offerPoints);
        fp.setReferenceSpotDate(referenceSpotDate);
        fp.setTenorDate(tenorDate);
        fp.setTenor(tenor);
        fp.setUpdatedTimeStampNS(Context.context().timeSource().nowNanos());
        return fp;
    }

    @Override
    public Adjustment adjustment(final Currency currency,
                                 final double amount) {
        final AdjustmentImpl adjustment = new AdjustmentImpl();
        adjustment.setAmount(amount);
        adjustment.setCcy(currency);
        return adjustment;
    }

    @Override
    public Adjustment adjustment(final Currency currency,
                                 final double amount,
                                 final double fillRate) {
        final AdjustmentImpl adjustment = new AdjustmentImpl();
        adjustment.setAmount(amount);
        adjustment.setFillRate(fillRate);
        adjustment.setCcy(currency);
        return adjustment;
    }

    public Adjustments adjustments(final Adjustment... adjustmentList) {
        final AdjustmentsImpl adjustments = new AdjustmentsImpl();
        adjustments.getAll().addAll(Arrays.asList(adjustmentList));
        return adjustments;
    }

    @Override
    public OptimalPosition optimalPosition(final Instrument instrument,
                                           final double instrumentPositionNotional,
                                           final double notionalAmount,
                                           final double systemBaseAmount,
                                           final double gradientNotionalAmount,
                                           final double gradientSystemBaseAmount,
                                           final double gradient,
                                           final double rate) {
        GradientOptimalPosition optimalPosition = new GradientOptimalPosition(OPTIMAL_POSITION_CONFIG_MAP.get(instrument));

        optimalPosition.setInstrumentPositionInNotional(instrumentPositionNotional);
        optimalPosition.setEquivalentPositionInNotional(notionalAmount);
        optimalPosition.setEquivalentPositionInSystemBase(systemBaseAmount);
        optimalPosition.setGradientPositionInNotional(gradientNotionalAmount);
        optimalPosition.setGradientPositionInSystemBase(gradientSystemBaseAmount);
        optimalPosition.setGradient(gradient);
        optimalPosition.setRate(rate);

        return optimalPosition;
    }

    @Override
    public BiasPositionControl biasPosition(final Currency ccy, final double bias) {
        final BiasPositionControlImpl biasPosition = new BiasPositionControlImpl();
        biasPosition.setCurrency(ccy);
        biasPosition.setBiasPosition(bias);
        return biasPosition;
    }

    @Override
    public ManualSkewControl manualSkew(final Currency ccy, final double skewInPips) {
        final ManualSkewControlImpl manualSkew = new ManualSkewControlImpl();
        manualSkew.currency(ccy);
        manualSkew.manualSkewInPips(skewInPips);
        return manualSkew;
    }

    @Override
    public long now() {
        return Context.context().timeSource().nowMillis();
    }

    @Override
    public List<FilterEnabledConfig> disableFilter(MarketDataFilterType filterType) {
        final List list = new ArrayList();
        for (Market market : Market.values()) {
            for (Instrument instrument : Instrument.values()) {
                list.add(new FilterEnabledConfig(filterType.name(), instrument, market, false));
            }
        }
        return list;
    }

    @Override
    public List<FilterEnabledConfig> enableFilter(MarketDataFilterType filterType) {
        final List list = new ArrayList();
        for (Market market : Market.values()) {
            for (Instrument instrument : Instrument.values()) {
                list.add(new FilterEnabledConfig(filterType.name(), instrument, market, true));
            }
        }
        return list;
    }

    @Override
    public HedgeControl enableHedger(final Portfolio portfolio) {
        final HedgeControlImpl hedgeControl = new HedgeControlImpl();
        hedgeControl.setPortfolio(portfolio);
        hedgeControl.setEnabled(true);
        return hedgeControl;
    }

    @Override
    public HedgeControl disableHedger(final Portfolio portfolio) {
        final HedgeControlImpl hedgeControl = new HedgeControlImpl();
        hedgeControl.setPortfolio(portfolio);
        hedgeControl.setEnabled(false);
        return hedgeControl;
    }


    @Override
    public OrderEvent hedgeOrderConfirmed(final NewOrder newOrder) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.CONFIRMED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledQuantity(0).setRemainingQuantity(newOrder.getQuantity()).setPortfolio(newOrder.getPortfolio());
    }

    @Override
    public OrderEvent hedgeOrderConfirmed(final NewOrder newOrder, final double remainingAmount) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.CONFIRMED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledQuantity(0).setRemainingQuantity(remainingAmount).setPortfolio(newOrder.getPortfolio());
    }

    @Override
    public OrderEvent hedgeOrderReject(final NewOrder newOrder) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.REJECTED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledQuantity(0).setRemainingQuantity(newOrder.getQuantity()).setPortfolio(newOrder.getPortfolio());
    }


    @Override
    public OrderEvent hedgeOrderAcknowledgeCancel(final NewOrder newOrder, final CancelOrder cancelOrder,
                                                  final double filledQuantity, final double filledPrice) {
        GcFriendlyAssert.isTrue(cancelOrder.getOrderId().equals(newOrder.getId()));
        return new OrderEventImpl().setCancelRequestId(cancelOrder.getId()).setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.CANCELLED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(filledPrice).setFilledQuantity(filledQuantity).setRemainingQuantity(newOrder.getQuantity() - filledQuantity).setPortfolio(newOrder.getPortfolio());
    }

    @Override
    public OrderEvent hedgeUnsolicitedOrderReject(final NewOrder newOrder, final double filledQuantity,
                                                  final double filledPrice) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.CANCELLED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(filledPrice).setFilledQuantity(filledQuantity).setRemainingQuantity(newOrder.getQuantity() - filledQuantity).setPortfolio(newOrder.getPortfolio());
    }


    @Override
    public OrderEvent hedgeOrderRejectCancel(final NewOrder newOrder, final CancelOrder cancelOrder) {
        GcFriendlyAssert.isTrue(cancelOrder.getOrderId().equals(newOrder.getId()));
        return new OrderEventImpl().setCancelRequestId(cancelOrder.getId()).setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.CANCEL_REJECT).setPortfolio(newOrder.getPortfolio()).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument());
    }

    @Override
    public OperatingHourChime createOperatingHourChime(final OperatingHourEntity entity, final String specs) {
        final OperatingHourChime chime = new OperatingHourChime();
        chime.setEntity(entity);
        chime.getSpecification().parse(specs);
        return chime;
    }

    @Override
    public HedgerFirewallReset createHedgerFirewallReset(final Portfolio portfolio,
                                                         final HedgeFirewallType hedgeFirewallType) {
        final HedgerFirewallResetImpl hedgerFirewallReset = new HedgerFirewallResetImpl();
        hedgerFirewallReset.setHedgeFirewallType(hedgeFirewallType);
        hedgerFirewallReset.setPortfolio(portfolio);
        return hedgerFirewallReset;
    }

    @Override
    public VolatilityControl setManualGlobalVol(final double vol) {
        final VolatilityControlImpl volatilityControl = new VolatilityControlImpl();
        volatilityControl.setInstrument(Instrument.ANY);
        volatilityControl.setCurrency(Currency.ANY);
        volatilityControl.setVolatilityFactor(vol);

        return volatilityControl;
    }

    @Override
    public VolatilityControl setManualCcyVol(final Currency currency, final double vol) {
        final VolatilityControlImpl volatilityControl = new VolatilityControlImpl();
        volatilityControl.setInstrument(Instrument.ANY);
        volatilityControl.setCurrency(currency);
        volatilityControl.setVolatilityFactor(vol);

        return volatilityControl;
    }

    @Override
    public VolatilityControl setManualMarketVol(final Market market, final double vol) {
        final VolatilityControlImpl volatilityControl = new VolatilityControlImpl();
        volatilityControl.setInstrument(Instrument.ANY);
        volatilityControl.setMarket(market);
        volatilityControl.setVolatilityFactor(vol);

        return volatilityControl;
    }

    @Override
    public HedgeCurrencyControl setHedgingPause(final Currency ccy, final boolean flag) {
        final HedgeCurrencyControlImpl hedgeCurrencyControl = new HedgeCurrencyControlImpl();
        hedgeCurrencyControl.setCurrency(ccy);
        hedgeCurrencyControl.setPauseHedging(flag);
        return hedgeCurrencyControl;
    }

    @Override
    public SkewCurrencyControl setSkewingPause(final Currency ccy, final boolean flag) {
        final SkewCurrencyControlImpl skewCurrencyControl = new SkewCurrencyControlImpl();
        skewCurrencyControl.currency(ccy);
        skewCurrencyControl.pauseSkewing(flag);
        return skewCurrencyControl;
    }

    @Override
    public PricePauseControl setPricePauseControl(final boolean pricingEnabled, final Currency ccy, final Market... markets) {
        final PricePauseControlImpl indicativeControl = new PricePauseControlImpl();
        final EnumSet marketsSet = new EnumSet<>(Market.class);
        for (Market market : markets) {
            marketsSet.add(market);
        }
        indicativeControl.setMarkets(marketsSet);
        indicativeControl.setCurrency(ccy);
        indicativeControl.setPricingEnabled(pricingEnabled);
        return indicativeControl;
    }

    private List<VolatilityWideningConfig> getVolatilityWideningConfigs() {
        return Arrays.asList(
                new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY,0, 0.0001),
                new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY,1, 0.0001),
                new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY,2, 0.0001),
                new VolatilityWideningConfig(Instrument.AUDUSD, FactorWindow.CAT_A, Market.ANY,3, 0.0001)
        );
    }

    public static List<HedgeFirewallConfig> getHedgeFirewallConfigs() {
        return Arrays.asList(
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),

                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, HedgeFirewallType.REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),

                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, HedgeFirewallType.REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),

                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_EBS, GB, HedgeFirewallType.REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),

                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                new HedgeFirewallConfigImpl(HEDGER_PASSIVE_RFX, GB, HedgeFirewallType.REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true)
        );
    }

    public static List<HedgePortfolioConfig> getHedgePortfolioConfigs() {
        return Arrays.asList(
                new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setCancelUnknownTimeoutMS(10_000).setOrderQuantityPrecision(0),
                new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
        );
    }

    public static List<AggressiveNewsHedgerConfig> getAggressiveNewsHedgerConfigs() {
        return Arrays.asList(
                new AggressiveNewsHedgerConfigImpl(Instrument.AUDUSD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURCHF, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURGBP, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURUSD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.GBPUSD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.NZDUSD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDCAD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDCHF, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDJPY, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDCNH, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDSGD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURDKK, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURNOK, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURSEK, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURCZK, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURHUF, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.EURPLN, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDILS, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDHKD, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDMXN, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDTRY, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000),
                new AggressiveNewsHedgerConfigImpl(Instrument.USDZAR, Market.AXL).setMaximumSpread(0.0001).setMinimumOrderQuantity(1000000)
        );
    }

    public static List<AggressiveTwapHedgerConfig> getAggressiveTwapHedgerConfigs() {
        return Arrays.asList(
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDSGD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDHKD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURDKK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURNOK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURSEK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURCZK).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURHUF).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURPLN).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDILS).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDMXN).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDTRY).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDZAR).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDCHF).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDCAD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.GBPUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.NZDUSD).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDJPY).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000),
                new AggressiveTwapHedgerConfigImpl(Market.AXL, Instrument.USDCNH).setTradingTimeZone(TradingTimeZone.LDN).setMaximumSpread(0.0002).setMinimumQuantity(1_000_000).setMinimumRisk(6_000_000).setOrderRateLimit(1_000_000).setOrderRateTimePeriodMS(1_000)
        );
    }

    public static List<AggressiveTakeProfitHedgerConfig> getAggressiveTakeProfitHedgerConfigs() {
        return Arrays.asList(
                new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD).setMaximumRiskIncrease(1000000).setTriggeringTradeMultiplier(2.5).setMinimumTriggerQuantity(1000000).setMinimumPriceImprovementPips(0.001).setActivePeriodMS(1000).setCounterparty("TestPartyA")
        );
    }

    public static List<PassiveHedgerConfig> getPassiveHedgerConfigs() {
        return Arrays.asList(
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.EURCHF).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.EURJPY).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.EURUSD).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.USDCHF).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.USDJPY).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.USDCNH).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.GBPJPY).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.GBPUSD).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.NZDUSD).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d),
                new PassiveHedgerConfigImpl(Market.EBS, Instrument.USDCAD).setReferenceMarket(Market.AXL).setMaximumTargetMarketPriceImprovementPips(-0.5).setArbitrageProtectionDistancePips(0.1).setAdditionalSpreadPips(-0.1).setPriceSamples(30).setPriceSampleInterval(1000).setMinimumRisk(1_500_000d).setOrderQuantity(1_000_000d)
        );
    }

    public static List<MidHedgerConfig> getMidHedgerConfigs() {
        return Arrays.asList(
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURCHF).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURJPY).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.NZDUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDCAD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDCHF).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDJPY).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDCNH).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURDKK).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURNOK).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURSEK).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURCZK).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURHUF).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURPLN).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDHKD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDMXN).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDSGD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDTRY).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDZAR).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.AUDUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.EURCHF).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.GBPUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.NZDUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.USDCAD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.USDCHF).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.USDJPY).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                new MidHedgerConfigImpl(Market.FXALLMB, Instrument.USDCNH).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0)
        );
    }

    public static SyntheticWideningFactor getDefaultWideningFactorOverride(final Currency baseCurrency, Currency termsCurrency,
                                                                           final Market market,
                                                                           final double factor,
                                                                           final TradingTimeZone timeZone) {
        final SyntheticWideningFactor rv = new SyntheticWideningFactor(baseCurrency, termsCurrency, market);
        for (TradingTimeZone tz : TradingTimeZone.VALUES) {
            if(tz.name() == timeZone.name()) {
                rv.set(tz, factor);
            }
            else {
                rv.set(tz, 0.5);
            }
        }
        return rv;
    }

    public static List<StaleFilterConfig> getStaleFilterConfigsWithTimezoneOverride(CurrencyGroup currencyGroup,
                                                                                    TradingTimeZone tradingTimeZone,
                                                                                    double stalenessMin,
                                                                                    double defaultStalenesMin) {
        final List<StaleFilterConfig> staleFilterConfigs = new ArrayList<>();
        for (Currency currency : Currency.values()) {
            if (currency.getCurrencyGroup() == currencyGroup) {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(defaultStalenesMin).set(tradingTimeZone, stalenessMin));
            } else {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(defaultStalenesMin));
            }
        }
        return staleFilterConfigs;
    }

    public static List<StaleFilterConfig> getStaleFilterConfigs(double stalenessMin) {
        final List<StaleFilterConfig> staleFilterConfigs = new ArrayList<>();
        for (Currency currency : Currency.values()) {
            staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(stalenessMin));
        }
        return staleFilterConfigs;
    }

    public static List<StaleFilterConfig> getStaleFilterConfigs(Map<CurrencyGroup, Long> stalenessMinMap) {
        final List<StaleFilterConfig> staleFilterConfigs = new ArrayList<>();
        for (Currency currency : Currency.values()) {
            if (currency.getCurrencyGroup() == CurrencyGroup.MAJOR) {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(stalenessMinMap.get(CurrencyGroup.MAJOR)));
            } else if (currency.getCurrencyGroup() == CurrencyGroup.PRECIOUS_METAL) {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(stalenessMinMap.get(CurrencyGroup.PRECIOUS_METAL)));
            } else if (currency.getCurrencyGroup() == CurrencyGroup.NON_DELIVERABLE_FORWARD) {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(stalenessMinMap.get(CurrencyGroup.NON_DELIVERABLE_FORWARD)));
            } else if (currency.getCurrencyGroup() == CurrencyGroup.EMERGING_MARKET) {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(stalenessMinMap.get(CurrencyGroup.EMERGING_MARKET)));
            } else if (currency.getCurrencyGroup() == CurrencyGroup.LOCAL_MARKET) {
                staleFilterConfigs.add(new StaleFilterConfigImpl((currency)).setAll(stalenessMinMap.get(CurrencyGroup.LOCAL_MARKET)));
            }
        }
        return staleFilterConfigs;
    }

    public static List<LiquidityFilterConfig> getLiquidityFilterConfigs(final double minimumLiquidity,
                                                                        final double maximumDistance) {
        final List<LiquidityFilterConfig> liquidityFilterConfigs = new ArrayList<>();
        for (Market market : Market.VALUES) {
            if (!market.isWildcard()) {
                for (Instrument instrument : Instrument.VALUES) {
                    liquidityFilterConfigs.add(new LiquidityFilterConfigImpl(TradingTimeZone.GLOBAL, Region.ANY, market, instrument, minimumLiquidity, maximumDistance));
                }
            }
        }
        return liquidityFilterConfigs;
    }

    @NotNull
    public static Trade buildTrade(final Portfolio portfolio,
                                   final Instrument instrument,
                                   final double qty, final double price,
                                   final boolean taker,
                                   final Market market,
                                   final CharSequence orderId,
                                   final TradeType tradeType) {
        final String counterparty = taker ? "HEDGE-COUNTERPARTY" : "CLIENT-COUNTERPARTY";
        return buildTrade(portfolio, instrument, qty, price, counterparty, taker, market, orderId.toString(), tradeType);
    }

    @NotNull
    public static Trade buildTrade(final Portfolio portfolio,
                                   final Instrument instrument,
                                   final double qty,
                                   final double price,
                                   final boolean taker,
                                   final Market market,
                                   final TradeType tradeType) {
        final String counterparty = taker ? "HEDGE-COUNTERPARTY" : "CLIENT-COUNTERPARTY";
        return buildTrade(portfolio, instrument, qty, price, counterparty, taker, market, getNextOrderId(), tradeType);
    }

   static OrderEventImpl hedgeOrderPartialFill(final NewOrder newOrder, final double filledQuantity,
                                                final double filledPrice) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.PARTIAL_FILL).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(filledPrice).setFilledQuantity(filledQuantity).setRemainingQuantity(newOrder.getQuantity() - filledQuantity).setPortfolio(newOrder.getPortfolio());
    }

    static OrderEvent hedgeOrderPartialFillFullFill(final NewOrder newOrder, final double filledQuantity,
                                                    final double filledPrice) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.COMPLETED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(filledPrice).setFilledQuantity(newOrder.getQuantity()).setRemainingQuantity(0).setLastPrice(filledPrice).setLastQuantity(filledQuantity).setPortfolio(newOrder.getPortfolio());
    }

    static OrderEvent hedgeOrderPartialFillOverFill(final NewOrder newOrder, final double filledQuantity,
                                                    final double totalFilledQuantity, final double filledPrice) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.COMPLETED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(filledPrice).setFilledQuantity(totalFilledQuantity).setRemainingQuantity(0).setLastPrice(filledPrice).setLastQuantity(filledQuantity).setPortfolio(newOrder.getPortfolio());
    }

    static OrderEvent hedgeOrderFullFill(final NewOrder newOrder, final double filledPrice) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.COMPLETED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(filledPrice).setFilledQuantity(newOrder.getQuantity()).setRemainingQuantity(0).setLastPrice(filledPrice).setLastQuantity(newOrder.getQuantity()).setPortfolio(newOrder.getPortfolio());
    }

    static OrderEvent hedgeOrderFullFill(final NewOrder newOrder) {
        return new OrderEventImpl().setOrderId(newOrder.getId()).setOrderEventType(OrderEventType.COMPLETED).setMarket(newOrder.getMarket()).setInstrument(newOrder.getInstrument()).setFilledPrice(newOrder.getPrice()).setFilledQuantity(newOrder.getQuantity()).setRemainingQuantity(0.0).setPortfolio(newOrder.getPortfolio());
    }

    private static String getNextOrderId() {
        return String.format("Order-%s@%sms", tradeId, Context.context().timeSource().nowMillis());
    }

    @NotNull
    private static Trade buildTrade(final Portfolio portfolio,
                                    final Instrument instrument,
                                    final double qty,
                                    final double price,
                                    final String counterparty,
                                    final boolean taker,
                                    final Market market,
                                    final String orderId,
                                    final TradeType tradeType) {
        final TradeImpl t = new TradeImpl();
        t.setPortfolio(portfolio);
        t.setCounterparty(counterparty);
        t.setOrderId(orderId);
        t.setClientOrderId(orderId);
        t.setCounterDealId((taker ? "C" : "H") + "-TEST-TRADEID-" + (tradeId++));
        t.setMarket(market);
        t.setTradeType(tradeType);
        t.setDealtCurrency(instrument.getDealt());
        t.setTermsCurrency(instrument.getTerms());
        t.setFilledQuantity(Math.abs(qty));
        t.setFilledPrice(price);
        t.setSide(qty < 0 ? OrderSide.OFFER : OrderSide.BID);
        t.setInceptionTimeNanos(Context.context().timeSource().nowNanos());
        return t;
    }

}
