package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringDecoders;

final class SbeVenueConfigDecoder {
    private final VenueConfigDecoder venueConfigDecoder = new VenueConfigDecoder();
    private final Consumer<StringBuilder> messageLogger = venueConfigDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.VenueConfig encodingOrder = EncodingOrder.VenueConfig.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final VenueConfigHandler venueConfigHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.VenueConfig.INITIAL;
        venueConfigDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            venueConfigHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            venueConfigHandler.messageForwarder(messageForwarder);
            venueConfigHandler.messageLogger(messageLogger);
            body.decode(venueConfigHandler);
            venueConfigHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.VenueConfig.INITIAL;
            venueConfigDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements VenueConfigHandler.Body {
        private final EnumerableSetDecoder<VenueCategory> venueCategories = new SbeVenueCategorySetDecoder(venueConfigDecoder::venueCategories);
        private final StringDecoder compId = StringDecoders.forFixedLength(
                venueConfigDecoder::compId, VenueConfigDecoder.compIdLength());

        void decode(final VenueConfigHandler venueConfigHandler) {
            encodingOrder = EncodingOrder.VenueConfig.BODY;
            venueConfigHandler.onBody(this);
        }

        @Override
        public Venue venue() {
            encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
            return Enums.venue(venueConfigDecoder.venue());
        }

        @Override
        public StringDecoder compId() {
            encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
            return compId;
        }

        @Override
        public EnumerableSetDecoder<VenueCategory> venueCategories() {
            encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
            return venueCategories;
        }

        @Override
        public boolean enabled() {
            encodingOrder.checkStrict(EncodingOrder.VenueConfig.BODY);
            return venueConfigDecoder.enabled() == YesNo.YES;
        }
    }
}
