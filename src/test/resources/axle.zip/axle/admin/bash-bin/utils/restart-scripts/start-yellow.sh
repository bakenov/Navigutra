#!/bin/bash

source ~/bin/shell-env/daxa009z/.functions

hosts=""
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "cd axle/environment/bin; ./start.sh") ::: $hosts
