package com.anz.axle.lg.adapter.d3.acceptance;

import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.agrona.concurrent.UnsafeBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.StreamingService;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.lg.adapter.d3.config.ServerConfig;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.stub.Sink;
import com.anz.markets.efx.messaging.transport.stub.Source;
import com.anz.markets.efx.messaging.transport.stub.StubbedTransport;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingDecoders;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.base.PricingTranslator;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingDecoders;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;

@Configuration
@Import({ServerConfig.class})
public class AcceptanceConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(AcceptanceConfig.class);

    @Bean
    Runnable subscriptionLoader() {
        return () -> LOGGER.info("Standard subscriptions loading is skipped for acceptance testing purposes");
    }

    @Bean
    public Queue<PricingMessage> pricingMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<PricingMessage> pricingRequestMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<SubscriptionRequest> subscriptionRequestQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<UpdateMessage> updateMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<ErrorMessage> errorMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<Throwable> throwableQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public AcceptanceContext acceptanceContext(final Queue<PricingMessage> pricingMessageQueue,
                                               final Queue<PricingMessage> pricingRequestMessageQueue,
                                               final PrecisionClock precisionClock,
                                               final LongIdFactory pricingMessageIdGenerator,
                                               final Queue<SubscriptionRequest> subscriptionRequestQueue,
                                               final Queue<UpdateMessage> updateMessageQueue,
                                               final Queue<ErrorMessage> errorMessageQueue,
                                               final Queue<Throwable> throwableQueue,
                                               final com.anz.markets.efx.queue.Queue<Runnable> mainEventLoopRunnableQueue,
                                               final HandlerRegistry onStreamingServiceSubscribeHandlerRegistry) {
        return new AcceptanceContext() {
            @Override
            public Queue<PricingMessage> pricingMessageQueue() {
                return pricingMessageQueue;
            }

            @Override
            public Queue<PricingMessage> pricingRequestMessageQueue() {
                return pricingRequestMessageQueue;
            }

            @Override
            public PrecisionClock precisionClock() {
                return precisionClock;
            }

            @Override
            public LongIdFactory pricingMessageIdGenerator() {
                return pricingMessageIdGenerator;
            }

            @Override
            public Queue<SubscriptionRequest> subscriptionRequestQueue() {
                return subscriptionRequestQueue;
            }

            @Override
            public Queue<UpdateMessage> updateMessageQueue() {
                return updateMessageQueue;
            }

            @Override
            public Queue<ErrorMessage> errorMessageQueue() {
                return errorMessageQueue;
            }

            @Override
            public Queue<Throwable> throwableQueue() {
                return throwableQueue;
            }

            @Override
            public void awaitMainEventLoopRunnableQueueIsProcessed(final long time, final TimeUnit timeUnit) throws InterruptedException {
                final CountDownLatch processed = new CountDownLatch(1);
                mainEventLoopRunnableQueue.appender().enqueue(processed::countDown);
                processed.await(time, timeUnit);
            }

            @Override
            public HandlerRegistry onStreamingServiceSubscribeHandlerRegistry() {
                return onStreamingServiceSubscribeHandlerRegistry;
            }
        };
    }

    @Bean
    public HandlerRegistry onStreamingServiceSubscribeHandlerRegistry() {
        return new HandlerRegistry();
    }

    @Bean
    public StreamingService streamingService(final Queue<SubscriptionRequest> subscriptionRequestQueue,
                                             final Queue<UpdateMessage> updateMessageQueue,
                                             final Queue<ErrorMessage> errorMessageQueue,
                                             final Queue<Throwable> throwableQueue,
                                             final HandlerRegistry onStreamingServiceSubscribeHandlerRegistry) {
        return new StubbedStreamingService(
                subscriptionRequestQueue,
                updateMessageQueue, errorMessageQueue, throwableQueue, onStreamingServiceSubscribeHandlerRegistry);
    }

    @Bean
    public Transport transport(final Queue<PricingMessage> pricingMessageQueue,
                               final Queue<PricingMessage> pricingRequestMessageQueue) {

        //Topic sinks
        final Sink pricingMessageSink = pricingMessageSink(pricingMessageQueue);

        //Topic source stubs
        final Source pricingRequestSource = pricingRequestSource(pricingRequestMessageQueue);


        return StubbedTransport.builder().
                sinks(publicationTopic -> {
                    return pricingMessageSink;
                }).sources(subscriptionTopic -> {
            if (subscriptionTopic.name().matches(".*PRICING_REQUEST")) {
                return pricingRequestSource;
            } else {
                return (messageHandler, topic1) -> false;
            }
        }).build();
    }

    /**
     * PojoPricingMessages are sourced from the pricingRequestMessageQueue, translated to SBE message and pushed to
     * the subscription message handler.
     *
     * @param pricingRequestMessageQueue       - source of PojoPricingRequestMessages
     * @return PricingRequest source
     */
    private Source pricingRequestSource(final Queue<PricingMessage> pricingRequestMessageQueue) {
        final LongSupplier nanoTimeSource = () -> 0L;
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final PricingTranslator<PricingMessage> pojo2SbeTranslator = pricingRequestPojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), nanoTimeSource.getAsLong())
        );
        return (topic, messageHandler) -> {
            final PricingMessage pojoPricingMessage = pricingRequestMessageQueue.poll();
            if (pojoPricingMessage != null) {
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoPricingMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };
    }

    /**
     * DirectBuffer content is translated to PricingMessage and placed to the pricingMessageQueue.
     *
     * @param pricingMessageQueue       - destination of PojoPricingMessages
     * @return PricingMessage sink
     */
    private Sink pricingMessageSink(final Queue<PricingMessage> pricingMessageQueue) {
        final AtomicReference<PricingMessage> messageHolder = new AtomicReference<>();
        final PricingTranslator<SbeMessage> pricingSbe2PojoTranslator = pricingSbe2PojoTranslator(messageHolder::set);
        return Sink.create((buf, off, len) -> {
            pricingSbe2PojoTranslator.decode(new SbeMessageForReading().wrap(buf, off, len));
            return messageHolder.get();
        }, pricingMessageQueue::offer);
    }

    private PricingTranslator<PricingMessage> pricingRequestPojo2SbeTranslator(final Consumer<? super SbeMessage> sbeMessageConsumer) {
        final PricingDecoders<PricingMessage> pojoPricingDecoders = new PojoPricingDecoders();

        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final PricingEncoders<SbeMessage> sbePricingRequestEncoder = new SbePricingEncoders(() -> sbeMessage);

        return PricingTranslator.create(pojoPricingDecoders.marketDataRequest(), sbePricingRequestEncoder.toPricingEncoderSupplier(sbeMessageConsumer));
    }

    private PricingTranslator<SbeMessage> pricingSbe2PojoTranslator(final Consumer<? super PricingMessage> pojoMessageConsumer) {
        final PricingDecoders<SbeMessage> sbePricingDecoders = new SbePricingDecoders();
        final PricingEncoderSupplier pojoEncoderSupplier = new PojoPricingEncoderSupplier(pojoMessageConsumer);
        return PricingTranslator.create(sbePricingDecoders.snapshotFullAndIncrementalRefresh(), pojoEncoderSupplier);
    }
}
