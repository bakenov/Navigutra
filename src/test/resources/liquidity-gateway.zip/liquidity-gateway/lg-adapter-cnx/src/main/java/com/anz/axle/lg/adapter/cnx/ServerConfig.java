package com.anz.axle.lg.adapter.cnx;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import java.util.Objects;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.HealthConfig;
import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.lg.adapter.health.HeartbeatMonitor;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
@Import({
        OverrideConfig.class,
        FixConfig.class,
        PricingConfig.class,
        TradingConfig.class,
        LastMarketTradeConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PricingSubscriptionConfig.class,
        LastMarketTradeSubscriptionConfig.class,
        HealthConfig.class
})
public class ServerConfig {

    private final Service fixEngine;
    private final Connection connection;
    private final Service mainEventLoop;
    private HeartbeatMonitor heartbeatMonitor;

    public ServerConfig(final Service fixEngine,
                        final Connection connection,
                        final Service mainEventLoop,
                        final HeartbeatMonitor heartbeatMonitor) {
        this.fixEngine = Objects.requireNonNull(fixEngine);
        this.connection = Objects.requireNonNull(connection);
        this.mainEventLoop = Objects.requireNonNull(mainEventLoop);
        this.heartbeatMonitor = Objects.requireNonNull(heartbeatMonitor);
    }

    @PostConstruct
    public void init() {
        mainEventLoop.start();
        fixEngine.start();
        heartbeatMonitor.start();
    }

    @PreDestroy
    public void destroy() {
        fixEngine.stop();
        mainEventLoop.stop();
        connection.close();
    }
}
