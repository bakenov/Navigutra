package com.anz.axle.lg.adapter.barx.quickfix;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Message;
import quickfix.field.BidPx;
import quickfix.field.BidSize;
import quickfix.field.MinBidSize;
import quickfix.field.MinOfferSize;
import quickfix.field.MsgSeqNum;
import quickfix.field.OfferPx;
import quickfix.field.OfferSize;
import quickfix.field.QuoteID;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteType;
import quickfix.field.SendingTime;

import com.anz.axle.lg.adapter.barx.EntryIdPacking;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public final class BarxQuoteHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BarxQuoteHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public BarxQuoteHandler(final VenueRequestKeyLookup requestKeyLookup,
                            final PricingEncoderLookup pricingEncoderLookup,
                            final PrecisionClock precisionClock,
                            final SubscriptionManager subscriptionManager,
                            final String senderCompId,
                            final String compId,
                            final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_QUOTE;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("Quote received: {}", message);
        final int quoteRequestId = message.getInt(QuoteReqID.FIELD);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = sequenceNumber;
        final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
        final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());
        final boolean isIndicativeQuote = isIndicativeQuote(message);
        final String settlDate = settlDateOrNull(message);

        final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(quoteRequestId);
        final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());

        final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        flagsAppender.accept(encoder.mdFlags());
        if (isIndicativeQuote) {
            encoder.mdFlags().add(Flag.INDICATIVE);
        }

        final int quoteId = quoteId(subscription.stringToIntCache(), message);

        final IncrementalRefreshEncoder.Body mdEntries = encoder
            .marketId(requestKey.market())
            .instrumentId(requestKey.instrumentKey().instrumentId())
            .senderCompId().encode(compId)
            .messageId(messageId)
            .sendingTime(sendingTimeNanos)
            .referenceSpotDate().encodeNull()
            .tradeDate().encodeNull()
            .settlDate().encodeFormatted(settlDate, DATE_DECODER);

        final int bidQuote = haveQuote(message, BidPx.FIELD, BidSize.FIELD);
        final int offerQuote = haveQuote(message, OfferPx.FIELD, OfferSize.FIELD);
        final IncrementalRefreshEncoder.MdEntries.Next mdEntriesNext = mdEntries.entriesStart(bidQuote + offerQuote);

        if (bidQuote > 0) {
            addEntry(message, mdEntriesNext, quoteId, sendingTimeNanos, requestKey.market(), EntryType.BID, BidPx.FIELD, BidSize.FIELD, MinBidSize.FIELD);
        }

        if (offerQuote > 0) {
            addEntry(message, mdEntriesNext, quoteId, sendingTimeNanos, requestKey.market(), EntryType.OFFER, OfferPx.FIELD, OfferSize.FIELD, MinOfferSize.FIELD);
        }

        mdEntriesNext.entriesComplete()
            .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(sequenceNumber)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
            .messageComplete();
    }

    private int quoteId(StringToIntCache stringToIntCache, final Message message) throws FieldNotFound {
        final String quoteIdStr  = message.getString(QuoteID.FIELD);
        if (quoteIdStr != null && !quoteIdStr.isEmpty()) {
            return stringToIntCache.put(quoteIdStr);
        }
        return 0;
    }
    private void addEntry(final Message message,
                          final IncrementalRefreshEncoder.MdEntries.Next mdEntriesNext,
                          final int quoteId,
                          final long sendingTimeNanos,
                          final Venue market,
                          final EntryType entryType,
                          final int priceField,
                          final int sizeField,
                          final int minSizeField) throws FieldNotFound {

        final double price = getDoubleOrZero(message, priceField);
        final double size = getDoubleOrZero(message, sizeField);
        final double minSize = getDoubleOrZero(message, minSizeField);
        final int entryId = EntryIdPacking.toId(entryType, (int)size);

        mdEntriesNext.next()
            .mdUpdateAction(UpdateAction.CHANGE)
            .transactTime(sendingTimeNanos)
            .mdMkt(market)
            .mdEntryType(entryType)
            .mdEntryPx(price)
            .mdEntrySize(size)
            .minQty(minSize)
            .mdEntryId(entryId)
            .mdEntryRefId(0)
            .quoteEntryId(quoteId);
    }

    private int haveQuote(final Message message, final int priceField, final int sizeField) {
        return message.isSetField(priceField) && message.isSetField(sizeField) ? 1 : 0;
    }

    private boolean isIndicativeQuote(final Message message) throws FieldNotFound {
        return message.isSetField(QuoteType.FIELD) && message.getInt(QuoteType.FIELD) == QuoteType.INDICATIVE;
    }

    private String settlDateOrNull(final Message message) throws FieldNotFound {
        if (message.isSetField(quickfix.field.SettlDate.FIELD)) {
            final String settlDate = message.getString(quickfix.field.SettlDate.FIELD);
            return (settlDate.length() == 8) ? settlDate : null;
        } else {
            return null;
        }
    }

    private double getDoubleOrZero(final Message message, final int field) throws FieldNotFound {
        return message.isSetField(field) ? message.getDouble(field) : 0.0f;
    }
}
