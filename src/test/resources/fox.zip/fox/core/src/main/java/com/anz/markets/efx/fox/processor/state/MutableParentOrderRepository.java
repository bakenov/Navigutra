package com.anz.markets.efx.fox.processor.state;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;

public class MutableParentOrderRepository implements ParentOrderRepository.Mutable {
    private final Long2ObjectHashMap<ParentOrder> activeParentOrdersByOrderId;
    private final Map<String, Long2ObjectHashMap<ParentOrder>> activeParentOrdersBySenderCompId;

    public MutableParentOrderRepository(final Long2ObjectHashMap<ParentOrder> activeParentOrdersByOrderId,
                                        final Map<String, Long2ObjectHashMap<ParentOrder>> activeParentOrdersBySenderCompId) {
        this.activeParentOrdersByOrderId = Objects.requireNonNull(activeParentOrdersByOrderId);
        this.activeParentOrdersBySenderCompId = Objects.requireNonNull(activeParentOrdersBySenderCompId);
    }

    public MutableParentOrderRepository() {
        this(new Long2ObjectHashMap<>(), new HashMap<>());
    }

    @Override
    public ParentOrder lookupByOrderId(final long orderId) {
        return activeParentOrdersByOrderId.get(orderId);
    }

    @Override
    public ParentOrder lookupByClOrderId(final String compId, final long clOrdId) {
        final  Long2ObjectHashMap<ParentOrder> activeStrategiesByClOrderId = activeParentOrdersBySenderCompId.get(compId);
        if (activeStrategiesByClOrderId == null) {
            return null;
        }
        return activeStrategiesByClOrderId.get(clOrdId);
    }

    @Override
    public void removeByOrderId(final long orderId) {
        activeParentOrdersByOrderId.remove(orderId);
    }

    @Override
    public void removeByClOrderId(final String compId, final long clOrdId) {
        final Long2ObjectHashMap<ParentOrder> activeStrategiesByClOrderId = activeParentOrdersBySenderCompId.get(compId);
        if (activeStrategiesByClOrderId != null) {
            activeStrategiesByClOrderId.remove(clOrdId);
        }
    }

    @Override
    public void add(final long orderId, final ParentOrder parentOrder) {
        activeParentOrdersByOrderId.put(orderId, parentOrder);
    }

    @Override
    public void add(final String compId, final long clOrdId, final ParentOrder parentOrder) {
        final Long2ObjectHashMap<ParentOrder> activeStrategiesByClOrderId = activeParentOrdersBySenderCompId.computeIfAbsent(compId, sCompId -> new Long2ObjectHashMap<>());
        activeStrategiesByClOrderId.put(clOrdId, parentOrder);
    }

    @Override
    public void forEach(final Consumer<? super ParentOrder> consumer) {
        activeParentOrdersByOrderId.values().forEach(consumer);
    }
}
