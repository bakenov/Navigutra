package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelReject;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectEncoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.function.LongSupplier;

import static com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.CxlRejReason.BROKER_EXCHANGE_OPTION;
import static com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.CxlRejReason.ORDER_ALREADY_IN_PENDING_CANCEL_OR_PENDING_REPLACE_STATUS;
import static com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.CxlRejReason.TOO_LATE_TO_CANCEL;
import static com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.CxlRejReason.UNKNOWN_ORDER;
import static com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.CxlRejResponseTo.ORDER_CANCEL_REPLACE_REQUEST;
import static com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.CxlRejResponseTo.ORDER_CANCEL_REQUEST;

public class BgcOrderCancelRejectHandler implements ChronicleMessageHandler<OrderCancelReject> {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcOrderCancelRejectHandler.class);

    private final TradingEncoderSupplier tradingEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;
    private final SourceSequencer sourceSequencer;

    public BgcOrderCancelRejectHandler(final TradingEncoderSupplier tradingEncoderSupplier,
                                       final PrecisionClock precisionClock,
                                       final String senderCompId,
                                       final String compId,
                                       final LongSupplier messageIdGenerator,
                                       final SourceSequencer sourceSequencer) {
        this.tradingEncoderSupplier = Objects.requireNonNull(tradingEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final OrderCancelReject message) throws IllegalArgumentException {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("OrderCancelReject received: {}", message);

        final long sequenceNumber = message.msgSeqNum();
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = message.sendingTime();
        final OrderStatus orderStatus = orderStatus(message.ordStatus());

        final OrderCancelRejectEncoder.Body bodyEncoder = tradingEncoderSupplier.orderCancelReject().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .orderId().encode(message.orderID())
                .clOrdId().encode(message.clOrdID())
                .origClOrdId().encode(message.origClOrdID())
                .clOrdLinkId().encodeEmpty()
                .ordStatus(orderStatus)
                .transactTime(message.transactTime())
                .cxlRejResponseTo(cxlRejResponseTo(message.cxlRejResponseTo()))
                .cxlRejReason(cxlRejReasonOrOther((int)message.cxlRejReason()));

        bodyEncoder
                .partiesEmpty().hopsStart(2)
                .next()
                .hopCompId().encode(senderCompId)
                .hopMessageId(sequenceNumber)
                .hopReceivingTime(0)
                .hopSendingTime(sendingTimeNanos)
                .next()
                .hopCompId().encode(compId)
                .hopMessageId(messageId)
                .hopReceivingTime(receivingTimeNanos)
                .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
                .text().encode(message.text())
                .messageComplete();
    }

    private OrderStatus orderStatus(final char ordStatus) {
        switch (ordStatus) {
            case OrdStatus.REJECTED : return OrderStatus.REJECTED;
            // what about U = Undefined?
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private OrderCancelRequestType cxlRejResponseTo(final char cxlRejResponseTo) {
        switch (cxlRejResponseTo) {
            case ORDER_CANCEL_REPLACE_REQUEST :  return OrderCancelRequestType.ORDER_CANCEL_REPLACE_REQUEST;
            case ORDER_CANCEL_REQUEST : return OrderCancelRequestType.ORDER_CANCEL_REQUEST;
            default: throw new IllegalArgumentException("Unsupported cxlRejResponseTo " + cxlRejResponseTo);
        }
    }

    private OrderCancelRejectReason cxlRejReasonOrOther(final int cxlRejReason) {
        switch (cxlRejReason) {
            case TOO_LATE_TO_CANCEL :  return OrderCancelRejectReason.TOO_LATE_TO_CANCEL;
            case UNKNOWN_ORDER :  return OrderCancelRejectReason.UNKNOWN_ORDER;
            case BROKER_EXCHANGE_OPTION :  return OrderCancelRejectReason.OTHER;
            case ORDER_ALREADY_IN_PENDING_CANCEL_OR_PENDING_REPLACE_STATUS :  return OrderCancelRejectReason.ORDER_ALREADY_IN_PENDING_STATUS;
            default: return OrderCancelRejectReason.OTHER;
        }
    }
}