package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringEncoders;

public final class SbeFirewallConfigEncoder implements FirewallConfigEncoder, FirewallConfigEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigEncoder firewallConfigEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();


    private final StringEncoder<Body> firewallName = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::firewallName, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.firewallNameLength());
    private final StringEncoder<Body> regionPattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::regionPattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.regionPatternLength());
    private final StringEncoder<Body> orderTypePattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::orderTypePattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.orderTypePatternLength());
    private final StringEncoder<Body> deskPattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::deskPattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.deskPatternLength());
    private final StringEncoder<Body> portfolioPattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::portfolioPattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.portfolioPatternLength());
    private final StringEncoder<Body> usernamePattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::usernamePattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.usernamePatternLength());
    private final StringEncoder<Body> venuePattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::venuePattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.venuePatternLength());
    private final StringEncoder<Body> securityTypePattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::securityTypePattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.securityTypePatternLength());
    private final StringEncoder<Body> tenorPattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::tenorPattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.tenorPatternLength());
    private final StringEncoder<Body> symbolPattern = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::symbolPattern, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.symbolPatternLength());
    private final StringEncoder<Body> periodUnit = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::periodUnit, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.periodUnitLength());
    private final StringEncoder<Body> comment = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::comment, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.commentLength());
    private final StringEncoder<Body> lastEditUsername = StringEncoders.forFixedLength(this,
            firewallConfigEncoder::lastEditUsername, com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder.lastEditUsernameLength());
    private EncodingOrder.FirewallConfig encodingOrder = EncodingOrder.FirewallConfig.INITIAL;

    SbeFirewallConfigEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                             final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(int source, long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        firewallConfigEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.FirewallConfig.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        firewallConfigEncoder.buffer().setMemory(offset, firewallConfigEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public StringEncoder<Body> firewallName() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return firewallName;
    }

    @Override
    public Body ruleId(final long ruleId) {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        firewallConfigEncoder.ruleId(ruleId);
        return this;
    }

    @Override
    public StringEncoder<Body> regionPattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return regionPattern;
    }

    @Override
    public StringEncoder<Body> orderTypePattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return orderTypePattern;
    }

    @Override
    public StringEncoder<Body> deskPattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return deskPattern;
    }

    @Override
    public StringEncoder<Body> portfolioPattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return portfolioPattern;
    }

    @Override
    public StringEncoder<Body> usernamePattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return usernamePattern;
    }

    @Override
    public StringEncoder<Body> venuePattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return venuePattern;
    }

    @Override
    public StringEncoder<Body> securityTypePattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return securityTypePattern;
    }

    @Override
    public StringEncoder<Body> tenorPattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return tenorPattern;
    }

    @Override
    public StringEncoder<Body> symbolPattern() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return symbolPattern;
    }

    @Override
    public Body period(final long period) {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        firewallConfigEncoder.period(period);
        return this;
    }

    @Override
    public StringEncoder<Body> periodUnit() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return periodUnit;
    }

    @Override
    public Body local(final boolean local) {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        firewallConfigEncoder.local(local ? YesNo.YES : YesNo.NO);
        return this;
    }

    @Override
    public StringEncoder<Body> comment() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return comment;
    }

    @Override
    public StringEncoder<Body> lastEditUsername() {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        return lastEditUsername;
    }

    @Override
    public Body lastEditTime(final long lastEditTime) {
        encodingOrder.checkStrict(EncodingOrder.FirewallConfig.BODY);
        firewallConfigEncoder.lastEditTime(lastEditTime);
        return this;
    }

    @Override
    public Trailer limitThreshold(final double limitThreshold) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.FirewallConfig.TRAILER);
        firewallConfigEncoder.limitThreshold(limitThreshold);
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.FirewallConfig.TRAILER);
                message.messageLength(headerLength + firewallConfigEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.FirewallConfig.INITIAL;
                headerEncoder.wrap(null, 0);
                firewallConfigEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
