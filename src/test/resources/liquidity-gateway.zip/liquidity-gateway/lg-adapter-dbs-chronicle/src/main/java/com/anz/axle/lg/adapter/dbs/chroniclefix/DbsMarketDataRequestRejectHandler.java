package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.MDReqRejReason;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MarketDataRequestReject;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;

public final class DbsMarketDataRequestRejectHandler implements ChronicleMessageHandler<MarketDataRequestReject> {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbsMarketDataRequestRejectHandler.class);

    private final SubscriptionManager subscriptionManager;
    private final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy;

    public DbsMarketDataRequestRejectHandler(final SubscriptionManager subscriptionManager,
                                             final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy) {
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.subscriptionRequestRejectStrategy = Objects.requireNonNull(subscriptionRequestRejectStrategy);
    }

    @Override
    public void accept(final MarketDataRequestReject message) throws IllegalArgumentException {

        final Bytes mdReqID = message.mDReqID();
        final int mdRequestId = (int) mdReqID.parseLong();

        final char mdRequestRejectReason = message.mDReqRejReason();
        final String rejectMessage = message.text();

        LOGGER.error("MarketDataRequest has been rejected with message: {}, rejection reason code: {}", rejectMessage, MDReqRejReason.asString(mdRequestRejectReason));

        subscriptionManager.rejectRequest(mdRequestId, subscriptionRequestRejectStrategy);
    }
}
