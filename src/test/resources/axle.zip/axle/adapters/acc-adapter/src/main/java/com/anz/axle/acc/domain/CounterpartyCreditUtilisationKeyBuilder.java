package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationKey;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("counterpartyCreditUtilisationKeyBuilder")
public class CounterpartyCreditUtilisationKeyBuilder implements Builder<CounterpartyCreditUtilisationKey, CounterpartyCreditUtilisation> {

    @Override
    public CounterpartyCreditUtilisationKey build(CounterpartyCreditUtilisation utilisation) throws BuilderException {
        return new CounterpartyCreditUtilisationKey(utilisation.getCreditPool(), utilisation.getSpotDate(), "CREDIT_CHECK");
    }
}
