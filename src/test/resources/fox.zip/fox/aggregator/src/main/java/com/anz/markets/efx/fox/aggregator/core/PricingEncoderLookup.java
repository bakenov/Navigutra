package com.anz.markets.efx.fox.aggregator.core;

import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface PricingEncoderLookup {

    @FunctionalInterface
    interface SnapshotterFactory {
        SnapshotterAccessor create(RequestKey requestKey);
    }

    PricingEncoderSupplier lookup(RequestKey requestKey);

}
