package com.anz.markets.efx.fox.api.domain;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public interface ChildOrderDetails {
    AsciiString orderId();

    long origClOrdId();

    long clOrdId();

    long clOrdLinkId();

    VenueInstrument venueInstrument();

    String strategyName();

    TimeInForce timeInForce();

    OrderType orderType();

    String currency();

    String settlCurrency();

    Side side();

    double price();

    double orderQty();

    String senderCompId();

    long tradeDateMillis();

    long settleDateMillis();

    long transactTimeNanos();

    OrderStatus orderStatus();

    double lastQty();

    double lastUsdQty();

    double lastPx();

    double commissionAdjLastPx();

    double midPx();

    double lastSpotRate();

    double lastForwardPoints();

    double leavesQty();

    double cumQty();

    double avgPx();

    double commissionAdjAvgPx();

    double commission();
}
