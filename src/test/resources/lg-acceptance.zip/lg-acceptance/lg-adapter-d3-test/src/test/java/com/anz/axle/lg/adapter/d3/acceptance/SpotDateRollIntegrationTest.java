package com.anz.axle.lg.adapter.d3.acceptance;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.SubscriptionRequestType;
import com.anz.markets.efx.pricing.codec.pojo.model.MarketDataRequest;

public class SpotDateRollIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SpotDateRollIntegrationTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;

    final private String senderCompId = "GB:lg-d3";
    final private Venue marketId = Venue.D3;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());

        final ZonedDateTime expectedSpotDateRollTime = ZonedDateTime.now().plus(10, ChronoUnit.SECONDS);

        System.setProperty("retry.task.millis", "200");
        System.setProperty("expire.task.millis", "20000");
        System.setProperty("retry.subscription.seconds", "100");
        System.setProperty("missed.update.task.millis", "5000000");
        System.setProperty("missed.update.seconds", "5000");
        System.setProperty("spot.date.roll.cron.expression", String.format("%s %s %s * * *", expectedSpotDateRollTime.getSecond(), expectedSpotDateRollTime.getMinute(), expectedSpotDateRollTime.getHour()));
        System.setProperty("spot.date.roll.cron.time.zone", expectedSpotDateRollTime.getZone().getId());
        System.setProperty("spot.date.roll.subscribe.delay.seconds", "5");

        System.setProperty("appName", "lg-d3");

        application = new Application("lg-d3", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.throwableQueue().clear();
        acceptanceContext.updateMessageQueue().clear();
        acceptanceContext.pricingRequestMessageQueue().clear();
        acceptanceContext.errorMessageQueue().clear();
        acceptanceContext.subscriptionRequestQueue().clear();
        acceptanceContext.pricingMessageQueue().clear();
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_subscribe_then_get_resubscribed_on_spot_date_roll() throws Exception {

        final String symbol = "AUDUSD";
        final LocalDate settlmentDate = LocalDate.of(2018, 1, 20);
        final SecurityType securityType = SecurityType.FXFWD;
        final long exprireTime = System.currentTimeMillis() + 20000000;


        final MarketDataRequest marketDataRequest = new MarketDataRequest();
        marketDataRequest.body.subscriptionRequestType = SubscriptionRequestType.SUBSCRIBE;
        marketDataRequest.body.mdReqId = 1;
        marketDataRequest.body.marketId = marketId;
        marketDataRequest.body.instrumentId = InstrumentKey.instrumentId(symbol, securityType, Tenor.BROKEN, settlmentDate);
        marketDataRequest.body.expireTime = exprireTime;

        acceptanceContext.pricingRequestMessageQueue().add(marketDataRequest);

        final SubscriptionRequest subscribeRequest = Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Initial")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        acceptanceContext.awaitMainEventLoopRunnableQueueIsProcessed(5, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.subscriptionRequestQueue())
                .matching(SubscriptionRequestMatcher.build("Unsubscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.UNSUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.subscriptionId().eq(subscribeRequest.subscriptionId())))
                .thenMatching(SubscriptionRequestMatcher.build("Re-subscribe")
                        .body().matches(SubscriptionRequestMatcher.type().eq(SubscriptionRequest.Type.SUBSCRIBE))
                        .body().matches(SubscriptionRequestMatcher.subscriptionId().neq(subscribeRequest.subscriptionId()))
                        .body().matches(SubscriptionRequestMatcher.symbol().eq(symbol + "20180120=API")))
                .awaitMatchAndGetLast(30, TimeUnit.SECONDS);
    }
}