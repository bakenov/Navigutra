package com.anz.markets.efx.ngaro.core;

import java.util.function.Consumer;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ObjectPoolTest {
    private static class SomeReusable {
        Consumer<SomeReusable> releaser;
        boolean released = false;

        public SomeReusable(final Consumer<SomeReusable> releaser) {
            this.releaser = releaser;
        }

        public void release() {
            released = true;
            releaser.accept(this);
        }

        public boolean released() {
            return released;
        }
    }

    @Test
    public void borrowAndRelease() {
        final ObjectPool<SomeReusable> objectPool = new ObjectPool<>(SomeReusable::new, 1);
        final SomeReusable value1 =  objectPool.borrowOrNew();
        final SomeReusable value2 =  objectPool.borrowOrNew();
        assertFalse(value1.released());

        value1.release();
        assertTrue(value1.released());

        final SomeReusable value3 =  objectPool.borrowOrNew();

        assertEquals(value3, value1);
    }
}