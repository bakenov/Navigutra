#!/bin/bash

source ~/bin/shell-env/daxa009z/.functions

hosts="daxa035z daxa018z"
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "cd axle/environment/bin; ./start.sh") ::: $hosts

