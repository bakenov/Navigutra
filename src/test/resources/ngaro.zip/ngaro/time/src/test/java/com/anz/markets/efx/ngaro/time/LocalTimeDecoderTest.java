package com.anz.markets.efx.ngaro.time;

import java.nio.ByteBuffer;
import java.time.LocalTime;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteReader;

public class LocalTimeDecoderTest {

    private final LocalTimeDecoder localTimeDecoder = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();

    @Test
    public void decodeEpochSeconds() {
        //given
        final int hh = 17;
        final int mm = 15;
        final int ss = 31;
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final long epochSeconds1 = localTimeDecoder.decodeEpochSeconds(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochSeconds2 = localTimeDecoder.decodeEpochSeconds(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final long exp = ((hh * 60) + mm) * 60 + ss;
        Assert.assertEquals("epochSeconds1 not as expected", exp, epochSeconds1);
        Assert.assertEquals("epochSeconds2 not as expected", exp, epochSeconds2);
    }

    @Test
    public void decodeEpochMillis() {
        //given
        final int hh = 17;
        final int mm = 15;
        final int ss = 31;
        final int milli = 123;
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final long epochMillis1 = localTimeDecoder.decodeEpochMillis(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochMillis2 = localTimeDecoder.decodeEpochMillis(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final long exp = (((hh * 60) + mm) * 60 + ss) * 1000 + milli;
        Assert.assertEquals("epochMillis1 not as expected", exp, epochMillis1);
        Assert.assertEquals("epochMillis2 not as expected", exp, epochMillis2);
    }


    @Test
    public void decodeEpochNanos() {
        //given
        final int hh = 17;
        final int mm = 15;
        final int ss = 31;
        final int nano = 123000000;
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final long epochNanos1 = localTimeDecoder.decodeEpochNanos(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochNanos2 = localTimeDecoder.decodeEpochNanos(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final long exp = (((hh * 60) + mm) * 60 + ss) * 1000000000L + nano;
        Assert.assertEquals("epochNanos1 not as expected", exp, epochNanos1);
        Assert.assertEquals("epochNanos2 not as expected", exp, epochNanos2);
    }

    @Test
    public void decodeLocalTime() {
        //given
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final LocalTime localTime1 = localTimeDecoder.decodeLocalTime(sb, ByteReader.CHAR_SEQUENCE, offset);
        final LocalTime localTime2 = localTimeDecoder.decodeLocalTime(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final LocalTime expected = LocalTime.of(17, 15, 31, 123000000);
        Assert.assertEquals("localTime1 not as expected", expected, localTime1);
        Assert.assertEquals("localTime2 not as expected", expected, localTime2);
    }

    @Test
    public void decodeLocalTimeNull() {
        //given
        final StringBuilder sb = new StringBuilder("xxx\0\0:\0\0:\0\0.\0\0\0xxx");
        final int offset = 3;

        //when
        final LocalTime localTime1 = localTimeDecoder.decodeLocalTime(sb, ByteReader.CHAR_SEQUENCE, offset);
        final LocalTime localTime2 = localTimeDecoder.decodeLocalTime(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertNull("localTime1 should be null", localTime1);
        Assert.assertNull("localTime2 should be null", localTime2);
    }

    @Test
    public void decodeHour() {
        //given
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final int hour1 = localTimeDecoder.decodeHour(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int hour2 = localTimeDecoder.decodeHour(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("hour1 not as expected", 17, hour1);
        Assert.assertEquals("hour2 not as expected", 17, hour2);
    }

    @Test
    public void decodeMinute() {
        //given
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final int minute1 = localTimeDecoder.decodeMinute(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int minute2 = localTimeDecoder.decodeMinute(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("minute1 not as expected", 15, minute1);
        Assert.assertEquals("minute2 not as expected", 15, minute2);
    }

    @Test
    public void decodeSecond() {
        //given
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123xxx");
        final int offset = 3;

        //when
        final int second1 = localTimeDecoder.decodeSecond(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int second2 = localTimeDecoder.decodeSecond(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("second1 not as expected", 31, second1);
        Assert.assertEquals("second2 not as expected", 31, second2);
    }

    @Test
    public void decodeMilli() {
        //given
        final LocalTimeDecoder dec1 = LocalTimeFormat.HH_MM_SS.getDefaultDecoder();
        final LocalTimeDecoder dec2 = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();
        final LocalTimeDecoder dec3 = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultDecoder();
        final LocalTimeDecoder dec4 = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final int milli1 = dec1.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli2 = dec2.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli3 = dec3.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli4a = dec4.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli4b = dec4.decodeMilli(sb.substring(3), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("milli1 not as expected", 0, milli1);
        Assert.assertEquals("milli2 not as expected", 123, milli2);
        Assert.assertEquals("milli3 not as expected", 123, milli3);
        Assert.assertEquals("milli4a not as expected", 123, milli4a);
        Assert.assertEquals("milli4b not as expected", 123, milli4b);
    }

    @Test
    public void decodeMicro() {
        //given
        final LocalTimeDecoder dec1 = LocalTimeFormat.HH_MM_SS.getDefaultDecoder();
        final LocalTimeDecoder dec2 = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();
        final LocalTimeDecoder dec3 = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultDecoder();
        final LocalTimeDecoder dec4 = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final int micro1 = dec1.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro2 = dec2.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro3 = dec3.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro4a = dec4.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro4b = dec4.decodeMicro(sb.substring(3), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("micro1 not as expected", 0, micro1);
        Assert.assertEquals("micro2 not as expected", 123000, micro2);
        Assert.assertEquals("micro3 not as expected", 123456, micro3);
        Assert.assertEquals("micro4a not as expected", 123456, micro4a);
        Assert.assertEquals("micro4b not as expected", 123456, micro4b);
    }

    @Test
    public void decodeNano() {
        //given
        final LocalTimeDecoder dec1 = LocalTimeFormat.HH_MM_SS.getDefaultDecoder();
        final LocalTimeDecoder dec2 = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();
        final LocalTimeDecoder dec3 = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultDecoder();
        final LocalTimeDecoder dec4 = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final int nano1 = dec1.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano2 = dec2.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano3 = dec3.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano4a = dec4.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano4b = dec4.decodeNano(sb.substring(3), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("nano1 not as expected", 0, nano1);
        Assert.assertEquals("nano2 not as expected", 123000000, nano2);
        Assert.assertEquals("nano3 not as expected", 123456000, nano3);
        Assert.assertEquals("nano4a not as expected", 123456789, nano4a);
        Assert.assertEquals("nano4b not as expected", 123456789, nano4b);
    }

    @Test
    public void decodeMilliNull() {
        //given
        final LocalTimeDecoder dec1 = LocalTimeFormat.HH_MM_SS.getDefaultDecoder();
        final LocalTimeDecoder dec2 = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();
        final LocalTimeDecoder dec3 = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultDecoder();
        final LocalTimeDecoder dec4 = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx17:15:31.\0\0\0\0\0\0\0\0\0xxx");
        final int offset = 3;

        //when
        final int milli1 = dec1.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli2 = dec2.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli3 = dec3.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int milli4 = dec4.decodeMilli(sb, ByteReader.CHAR_SEQUENCE, offset);

        //then
        Assert.assertEquals("milli1 not as expected", 0, milli1);
        Assert.assertEquals("milli2 not as expected", 0, milli2);
        Assert.assertEquals("milli3 not as expected", 0, milli3);
        Assert.assertEquals("milli4 not as expected", 0, milli4);
    }

    @Test
    public void decodeMicroNull() {
        //given
        final LocalTimeDecoder dec1 = LocalTimeFormat.HH_MM_SS.getDefaultDecoder();
        final LocalTimeDecoder dec2 = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();
        final LocalTimeDecoder dec3 = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultDecoder();
        final LocalTimeDecoder dec4 = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx17:15:31.\0\0\0\0\0\0\0\0\0xxx");
        final int offset = 3;

        //when
        final int micro1 = dec1.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro2 = dec2.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro3 = dec3.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int micro4 = dec4.decodeMicro(sb, ByteReader.CHAR_SEQUENCE, offset);

        //then
        Assert.assertEquals("micro1 not as expected", 0, micro1);
        Assert.assertEquals("micro2 not as expected", 0, micro2);
        Assert.assertEquals("micro3 not as expected", 0, micro3);
        Assert.assertEquals("micro4 not as expected", 0, micro4);
    }

    @Test
    public void decodeNanoNull() {
        //given
        final LocalTimeDecoder dec1 = LocalTimeFormat.HH_MM_SS.getDefaultDecoder();
        final LocalTimeDecoder dec2 = LocalTimeFormat.HH_MM_SS_MMM.getDefaultDecoder();
        final LocalTimeDecoder dec3 = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultDecoder();
        final LocalTimeDecoder dec4 = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx17:15:31.\0\0\0\0\0\0\0\0\0xxx");
        final int offset = 3;

        //when
        final int nano1 = dec1.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano2 = dec2.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano3 = dec3.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano4 = dec4.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);

        //then
        Assert.assertEquals("nano1 not as expected", 0, nano1);
        Assert.assertEquals("nano2 not as expected", 0, nano2);
        Assert.assertEquals("nano3 not as expected", 0, nano3);
        Assert.assertEquals("nano4 not as expected", 0, nano4);
    }

    @Test
    public void decodeDelim() {
        //given
        final StringBuilder sb = new StringBuilder("xxx17:15/31.123xxx");
        final int offset = 3;

        //when
        final char delim1a = localTimeDecoder.decodeDelimiter1(sb, ByteReader.CHAR_SEQUENCE, offset);
        final char delim1b = localTimeDecoder.decodeDelimiter1(sb.substring(offset), ByteReader.CHAR_SEQUENCE);
        final char delim2a = localTimeDecoder.decodeDelimiter2(sb, ByteReader.CHAR_SEQUENCE, offset);
        final char delim2b = localTimeDecoder.decodeDelimiter2(sb.substring(offset), ByteReader.CHAR_SEQUENCE);
        final char symbolA = localTimeDecoder.decodeFractionSymbol(sb, ByteReader.CHAR_SEQUENCE, offset);
        final char symbolB = localTimeDecoder.decodeFractionSymbol(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("delim1a not as expected", ':', delim1a);
        Assert.assertEquals("delim1b not as expected", ':', delim1b);
        Assert.assertEquals("delim2a not as expected", '/', delim2a);
        Assert.assertEquals("delim2b not as expected", '/', delim2b);
        Assert.assertEquals("symbolA not as expected", '.', symbolA);
        Assert.assertEquals("symbolB not as expected", '.', symbolB);
    }

    @Test
    public void decodeAllFormats() {
        final LocalTime expMM_SS_NNNNNNNNN = LocalTime.of(17, 15, 31, 123456789);
        final LocalTime expMM_SS_UUUUUU = LocalTime.of(17, 15, 31, 123456000);
        final LocalTime expMM_SS_MMM = LocalTime.of(17, 15, 31, 123000000);
        final LocalTime expMM_SS = LocalTime.of(17, 15, 31);
        final LocalTime expMM = LocalTime.of(17, 15, 00);
        final LocalTimeFormat[] formats = {
                LocalTimeFormat.HHMM, LocalTimeFormat.HHMMSS, LocalTimeFormat.HHMMSSMMM, LocalTimeFormat.HHMMSSUUUUUU, LocalTimeFormat.HHMMSSNNNNNNNNN,
                LocalTimeFormat.HH_MM, LocalTimeFormat.HH_MM_SS, LocalTimeFormat.HH_MM_SS_MMM, LocalTimeFormat.HH_MM_SS_UUUUUU, LocalTimeFormat.HH_MM_SS_NNNNNNNNN};
        final String[] dateStrings = {
                "1715", "171531", "171531123", "171531123456", "171531123456789",
                "17:15", "17:15:31", "17:15:31.123", "17:15:31.123456", "17:15:31.123456789"};
        final LocalTime[] expectedValues = {
                expMM, expMM_SS, expMM_SS_MMM, expMM_SS_UUUUUU, expMM_SS_NNNNNNNNN,
                expMM, expMM_SS, expMM_SS_MMM, expMM_SS_UUUUUU, expMM_SS_NNNNNNNNN
        };
        final char[] delims = {':', '/', '.'};
        final char[] symbols = {'.', '_'};

        for (int f = 0; f < formats.length; f++) {
            final LocalTimeDecoder decoder = LocalTimeDecoder.valueOf(formats[f]);
            final LocalTime expected = expectedValues[f];
            final int offset = 3;
            final String input = dateStrings[f];
            final String inputString = "abc" + input + "defghklmnopkrstuvwxyz".substring(input.length());
            final byte[] inputArray = input.getBytes();
            final ByteBuffer inputBuffer = ByteBuffer.wrap(inputArray);

            //when
            final LocalTime actual1 = decoder.decodeLocalTime(inputString, ByteReader.CHAR_SEQUENCE, offset);
            final LocalTime actual2 = decoder.decodeLocalTime(inputArray, ByteReader.BYTE_ARRAY);
            final LocalTime actual3 = decoder.decodeLocalTime(inputBuffer, ByteReader.BYTE_BUFFER);

            //then
            Assert.assertEquals("decoded actual1 not as expected for format " + formats[f], expected, actual1);
            Assert.assertEquals("decoded actual2 not as expected for format " + formats[f], expected, actual2);
            Assert.assertEquals("decoded actual3 not as expected for format " + formats[f], expected, actual3);
        }
    }
}