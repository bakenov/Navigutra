package com.anz.markets.prophet;

import org.junit.Assert;
import org.octtech.bw.ByteWatcherSingleThread;

/**
 * Based on org.octtech.bw.ByteWatcherRegressionTestHelper
 * This class will run the method under test for $warmupReps then start the GC counter and run again for $measureReps
 */
public class WarmingByteWatcherRegressionTestHelper {
    private final ByteWatcherSingleThread bw;

    public WarmingByteWatcherRegressionTestHelper(Thread thread) {
        this.bw = new ByteWatcherSingleThread(thread);
    }

    public WarmingByteWatcherRegressionTestHelper() {
        this(Thread.currentThread());
    }

    public void testAllocationNotExceeded(Runnable job, int warmupReps, int measureReps, long limit) {
        for (int i = 0; i < warmupReps; i++) {
            job.run();
        }
        this.bw.reset();
        for (int i = 0; i < measureReps; i++) {
            job.run();
        }
        long size = this.bw.calculateAllocations();
        Assert.assertTrue(String.format("exceeded limit: %d using: %d%n", Long.valueOf(limit), Long.valueOf(size)), size <= limit);
    }
}
