package com.anz.axle.adapters.ndf2trep.snapshot;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class DefaultSnapshotterDecoderLookup implements SnapshotterDecoderLookup {

    private final Map<RequestKey, SnapshotterDecoderSupplier> cache = new HashMap<>();
    private final Function<RequestKey, SnapshotterDecoderSupplier> snapshotterDecoderSupplierFactory;

    public DefaultSnapshotterDecoderLookup(final Function<RequestKey, SnapshotterDecoderSupplier> snapshotterDecoderSupplierFactory) {
        this.snapshotterDecoderSupplierFactory = Objects.requireNonNull(snapshotterDecoderSupplierFactory);
    }

    @Override
    public Collection<SnapshotterDecoderSupplier> snapshotterDecoderSuppliers() {
        return cache.values();
    }

    @Override
    public SnapshotterDecoderSupplier lookup(final RequestKey requestKey) {
        return cache.computeIfAbsent(requestKey, snapshotterDecoderSupplierFactory);
    }
}