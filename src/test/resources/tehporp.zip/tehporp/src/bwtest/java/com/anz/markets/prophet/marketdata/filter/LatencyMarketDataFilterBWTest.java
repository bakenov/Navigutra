package com.anz.markets.prophet.marketdata.filter;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;

public class LatencyMarketDataFilterBWTest extends AbstractLatencyMarketDataFilterForBwJmhTest {

    private static final int REPS = 100_000;
    private static final int THRESHOLD = 500;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    @Test
    public void test_AllocationNotExceeded_Test() {
        helper.testAllocationNotExceeded(
                this::testPerformFilter,
                REPS, REPS,
                THRESHOLD
        );
    }
}