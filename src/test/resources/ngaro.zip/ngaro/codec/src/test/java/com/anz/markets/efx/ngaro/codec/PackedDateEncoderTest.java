package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

import org.junit.Test;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link PackedDateEncoder}
 */
public class PackedDateEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test(expected = NullPointerException.class)
    public void noNullEnclosingEncoder() {
        PackedDateEncoder.forPackedDateConsumer(null, (packing, value) -> {});
    }

    @Test(expected = NullPointerException.class)
    public void noNullPackedDateConsumer() {
        PackedDateEncoder.forPackedDateConsumer(ENCLOSING_ENCODER, null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullBinaryPackedConsumer() {
        PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullDecimalPackedDateConsumer() {
        PackedDateEncoder.forDecimalPackedDateConsumer(ENCLOSING_ENCODER, null);
    }

    @Test
    public void encode() throws Exception {
        //given
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> encoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);

        //when
        encoder.encode(2016, 02, 28);

        //then
        assertEquals(LocalDate.of(2016, 02, 28), binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        encoder.encodeNullable(LocalDate.of(2017, 03, 14));

        //then
        assertEquals(LocalDate.of(2017, 03, 14), binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        encoder.encodeNullable(null);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));
    }

    @Test
    public void encodeEpochMillis() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> encoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);

        //when
        encoder.encodeEpochMillis(localDate.toEpochDay() * Epoch.MILLIS_PER_DAY);

        //then
        assertEquals(localDate, binaryPackedToLocalDate(binaryPackedDateHolder::get));
    }

    @Test
    public void encodeEpochSeconds() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> encoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);

        //when
        encoder.encodeEpochSeconds(localDate.toEpochDay() * Epoch.SECONDS_PER_DAY);

        //then
        assertEquals(localDate, binaryPackedToLocalDate(binaryPackedDateHolder::get));
    }

    @Test
    public void encodePackedDecimal() throws Exception {
        //given
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final AtomicInteger decimalPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> binaryEncoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);
        final PackedDateEncoder<?> decimalEncoder = PackedDateEncoder.forDecimalPackedDateConsumer(ENCLOSING_ENCODER, decimalPackedDateHolder::set);

        //when
        binaryEncoder.encode(LocalDatePacking.DECIMAL, 20170314);
        decimalEncoder.encode(LocalDatePacking.DECIMAL, 20170314);

        //then
        assertEquals(LocalDate.of(2017, 03, 14), binaryPackedToLocalDate(binaryPackedDateHolder::get));
        assertEquals(LocalDate.of(2017, 03, 14), decimalPackedToLocalDate(decimalPackedDateHolder::get));
    }

    @Test
    public void encodePackedBinary() throws Exception {
        //given
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final AtomicInteger decimalPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> binaryEncoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);
        final PackedDateEncoder<?> decimalEncoder = PackedDateEncoder.forDecimalPackedDateConsumer(ENCLOSING_ENCODER, decimalPackedDateHolder::set);

        //when
        binaryEncoder.encode(LocalDatePacking.BINARY, LocalDatePacking.BINARY.pack(2017, 03, 14));
        decimalEncoder.encode(LocalDatePacking.BINARY, LocalDatePacking.BINARY.pack(2017, 03, 14));

        //then
        assertEquals(LocalDate.of(2017, 03, 14), binaryPackedToLocalDate(binaryPackedDateHolder::get));
        assertEquals(LocalDate.of(2017, 03, 14), decimalPackedToLocalDate(decimalPackedDateHolder::get));
    }

    @Test
    public void encodeEpochDays() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> encoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);

        //when
        encoder.encodeEpochDays(localDate.toEpochDay());

        //then
        assertEquals(localDate, binaryPackedToLocalDate(binaryPackedDateHolder::get));
    }

    @Test
    public void encodeNull() throws Exception {
        //given
        final AtomicInteger binaryPackedDateHolder = new AtomicInteger();
        final PackedDateEncoder<?> encoder = PackedDateEncoder.forBinaryPackedConsumer(ENCLOSING_ENCODER, binaryPackedDateHolder::set);

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encodeNull();

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encodeNullable(null);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encode(0, 0, 0);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encodeEpochDays(0);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encodeEpochSeconds(0);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encodeEpochMillis(0);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encode(LocalDatePacking.BINARY, 0);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));

        //when
        fromLocalDate(LocalDate.now(), binaryPackedDateHolder::set);
        encoder.encode(LocalDatePacking.DECIMAL, 0);

        //then
        assertEquals(null, binaryPackedToLocalDate(binaryPackedDateHolder::get));
    }

    private static LocalDate binaryPackedToLocalDate(final IntSupplier binaryPackedDateSupplier) {
        final int binaryPackedDate = binaryPackedDateSupplier.getAsInt();
        return binaryPackedDate == 0 ? null : LocalDate.of(
                LocalDatePacking.BINARY.unpackYear(binaryPackedDate),
                LocalDatePacking.BINARY.unpackMonth(binaryPackedDate),
                LocalDatePacking.BINARY.unpackDay(binaryPackedDate)
        );
    }

    private static LocalDate decimalPackedToLocalDate(final IntSupplier decimalPackedDateSupplier) {
        final int binaryPackedDate = decimalPackedDateSupplier.getAsInt();
        return binaryPackedDate == 0 ? null : LocalDate.of(
                LocalDatePacking.DECIMAL.unpackYear(binaryPackedDate),
                LocalDatePacking.DECIMAL.unpackMonth(binaryPackedDate),
                LocalDatePacking.DECIMAL.unpackDay(binaryPackedDate)
        );
    }

    private static void fromLocalDate(final LocalDate localDate, final IntConsumer binaryPackedDateConsumer) {
        binaryPackedDateConsumer.accept(localDate == null ? 0 : LocalDatePacking.BINARY.pack(
                localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth()
        ));
    }

}