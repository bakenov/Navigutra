package com.anz.axle.lg.adapter.d3.newsubscription;

import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface SubscriptionRegistry {
    @FunctionalInterface
    interface Registerer {
        void register(long subscriptionId, Subscription subscription);
    }

    @FunctionalInterface
    interface Unregisterer {
        void unregister(long subscriptionId);
    }

    @FunctionalInterface
    interface ByIdLookup {
        Subscription lookup(long subscriptionId);
    }

    @FunctionalInterface
    interface ByVenueRequestKeyLookup {
        Subscription lookupOrCreate(RequestKey requestKey);
    }

    ByIdLookup byIdLookup();
    ByVenueRequestKeyLookup byVenueRequestKeyLookup();
    void checkAndRetryAllFailed();
    void checkAndHandleAllExpired();
    void errorAll(String errorMessage);
    void checkAndHandleMissedUpdate();
    void publishLatestUpdates();
    void spotDateRollResubscribe();
    void submitStop();
}
