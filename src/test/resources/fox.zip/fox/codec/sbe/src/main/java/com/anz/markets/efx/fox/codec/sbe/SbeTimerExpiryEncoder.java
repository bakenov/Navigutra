package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public final class SbeTimerExpiryEncoder implements TimerExpiryEncoder, TimerExpiryEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryEncoder timerExpiryEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();

    private EncodingOrder.TimerExpiry encodingOrder = EncodingOrder.TimerExpiry.INITIAL;

    SbeTimerExpiryEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                          final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        timerExpiryEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.TimerExpiry.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        timerExpiryEncoder.buffer().setMemory(offset, timerExpiryEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public Body triggeredTime(final long triggeredTime) {
        encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
        timerExpiryEncoder.triggeredTime(triggeredTime);
        return this;
    }

    @Override
    public Body timerId(final long timerId) {
        encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
        timerExpiryEncoder.timerId(timerId);
        return this;
    }

    @Override
    public Trailer timerGroup(final TimerGroup timerGroup) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.TimerExpiry.TRAILER);
        timerExpiryEncoder.timerGroup(Enums.timerGroup(timerGroup));
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.TimerExpiry.TRAILER);
                message.messageLength(headerLength + timerExpiryEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.TimerExpiry.INITIAL;
                headerEncoder.wrap(null, 0);
                timerExpiryEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
