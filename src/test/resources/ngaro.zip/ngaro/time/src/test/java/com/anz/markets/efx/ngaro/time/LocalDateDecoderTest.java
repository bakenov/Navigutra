package com.anz.markets.efx.ngaro.time;

import java.nio.ByteBuffer;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteWriter;

public class LocalDateDecoderTest {

    private final LocalDateDecoder localDateDecoder = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    @Test
    public void decodeEpochMillis() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final long epochMillis1 = localDateDecoder.decodeEpochMillis(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochMillis2 = localDateDecoder.decodeEpochMillis(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final LocalDate expected = LocalDate.of(2016, 12, 15);
        Assert.assertEquals("epochMillis1 not as expected", expected.toEpochDay() * 24 * 3600 * 1000, epochMillis1);
        Assert.assertEquals("epochMillis2 not as expected", expected.toEpochDay() * 24 * 3600 * 1000, epochMillis2);
    }

    @Test
    public void decodeEpochSeconds() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final long epochSeconds1 = localDateDecoder.decodeEpochSeconds(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochSeconds2 = localDateDecoder.decodeEpochSeconds(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final LocalDate expected = LocalDate.of(2016, 12, 15);
        Assert.assertEquals("epochSeconds1 not as expected", expected.toEpochDay() * 24 * 3600, epochSeconds1);
        Assert.assertEquals("epochSeconds2 not as expected", expected.toEpochDay() * 24 * 3600, epochSeconds2);
    }

    @Test
    public void decodeEpochDays() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final long epochDays1 = localDateDecoder.decodeEpochDays(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochDays2 = localDateDecoder.decodeEpochDays(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final LocalDate expected = LocalDate.of(2016, 12, 15);
        Assert.assertEquals("epochDays1 not as expected", expected.toEpochDay(), epochDays1);
        Assert.assertEquals("epochDays2 not as expected", expected.toEpochDay(), epochDays2);
    }

    @Test
    public void decodeLocalDate() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final LocalDate localDate1 = localDateDecoder.decodeLocalDateOrNull(sb, ByteReader.CHAR_SEQUENCE, offset);
        final LocalDate localDate2 = localDateDecoder.decodeLocalDateOrNull(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final LocalDate expected = LocalDate.of(2016, 12, 15);
        Assert.assertEquals("localDate1 not as expected", expected, localDate1);
        Assert.assertEquals("localDate2 not as expected", expected, localDate2);
    }

    @Test
    public void decodeLocalDateNull() {
        //given
        final StringBuilder sb = new StringBuilder("xxx\0\0\0\0\0\0\0\0xxx");
        final int offset = 3;

        //when
        final LocalDate localDate1 = localDateDecoder.decodeLocalDateOrNull(sb, ByteReader.CHAR_SEQUENCE, offset);
        final LocalDate localDate2 = localDateDecoder.decodeLocalDateOrNull(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertNull("localDate1 should be null", localDate1);
        Assert.assertNull("localDate2 should be null", localDate2);
    }

    @Test
    public void decodeYear() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final int year1 = localDateDecoder.decodeYear(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int year2 = localDateDecoder.decodeYear(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("year1 not as expected", 2016, year1);
        Assert.assertEquals("year2 not as expected", 2016, year2);
    }

    @Test
    public void decodeMonth() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final int month1 = localDateDecoder.decodeMonth(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int month2 = localDateDecoder.decodeMonth(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("month1 not as expected", 12, month1);
        Assert.assertEquals("month2 not as expected", 12, month2);
    }

    @Test
    public void decodeDay() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int offset = 3;

        //when
        final int day1 = localDateDecoder.decodeDay(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int day2 = localDateDecoder.decodeDay(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("day1 not as expected", 15, day1);
        Assert.assertEquals("day2 not as expected", 15, day2);
    }

    @Test
    public void decodePacked() {
        //given
        final StringBuilder sb = new StringBuilder("xxx20161215xxx");
        final int binPacked = LocalDatePacking.BINARY.pack(2016, 12, 15);
        final int offset = 3;

        //when
        final int packed1 = localDateDecoder.decodePacked(LocalDatePacking.DECIMAL, sb, ByteReader.CHAR_SEQUENCE, offset);
        final int packed2 = localDateDecoder.decodePacked(LocalDatePacking.BINARY, sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("packed1 not as expected", 20161215, packed1);
        Assert.assertEquals("packed2 not as expected", binPacked, packed2);
    }

    @Test
    public void decodeDelim() {
        //given
        final LocalDateDecoder decoder = LocalDateFormat.YYYY_MM_DD.getDefaultDecoder();
        final StringBuilder sb = new StringBuilder("xxx2016/12.15xxx");
        final int offset = 3;

        //when
        final char delim1a = decoder.decodeDelimiter1(sb, ByteReader.CHAR_SEQUENCE, offset);
        final char delim1b = decoder.decodeDelimiter1(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);
        final char delim2a = decoder.decodeDelimiter2(sb, ByteReader.CHAR_SEQUENCE, offset);
        final char delim2b = decoder.decodeDelimiter2(sb.toString().substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("delim1a not as expected", '/', delim1a);
        Assert.assertEquals("delim1b not as expected", '/', delim1b);
        Assert.assertEquals("delim2a not as expected", '.', delim2a);
        Assert.assertEquals("delim2b not as expected", '.', delim2b);
    }

    @Test
    public void decodeAllFormats() {
        final LocalDate input = LocalDate.of(2017, 02, 24);
        final LocalDateFormat[] formats = {LocalDateFormat.YYYYMMDD, LocalDateFormat.MMDDYYYY, LocalDateFormat.DDMMYYYY,
                LocalDateFormat.YYYY_MM_DD, LocalDateFormat.MM_DD_YYYY, LocalDateFormat.DD_MM_YYYY};
        final String[] dateStrings = {"20170224", "02242017", "24022017",
                "2017-02-24", "02-24-2017", "24-02-2017"};
        final char[] delims = {'-', '/', '.'};

        for (int f = 0; f < formats.length; f++) {
            for (final char delim : delims) {
                final LocalDateEncoder encoder = LocalDateEncoder.valueOf(formats[f], delim);
                final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
                final int offset = 3;
                final byte[] bytes1 = new byte[10];
                final ByteBuffer buffer = ByteBuffer.allocate(10);

                //when
                encoder.encodeNullable(string, ByteWriter.STRING_BUILDER, offset, input);
                encoder.encodeNullable(bytes1, ByteWriter.BYTE_ARRAY, input);
                encoder.encodeNullable(buffer, ByteWriter.BYTE_BUFFER, input);

                //then
                final String expected = dateStrings[f].replace('-', delim);
                final String expectedString = "abc" + expected +"defghklmnopkrstuvwxyz".substring(expected.length());
                final String expectedBytes = expected + "\0\0\0\0\0\0\0\0\0\0".substring(expected.length());
                Assert.assertEquals("encoded string not as expected", expectedString, string.toString());
                Assert.assertEquals("encoded bytes1 not as expected", expectedBytes, new String(bytes1));
                Assert.assertEquals("encoded buffer not as expected", expectedBytes, new String(buffer.array()));
            }
        }
    }
}