#!/bin/bash
# (c) 2016 ANZ

TITLE="Depth Latency (Overall)"
GREPSTR="LatencyDepthOverall"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_lat.common