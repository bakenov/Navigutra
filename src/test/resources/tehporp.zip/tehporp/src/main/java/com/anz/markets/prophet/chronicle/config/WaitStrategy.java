package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.chronicle.StopException;
import net.openhft.chronicle.threads.Pauser;
import org.slf4j.LoggerFactory;

public interface WaitStrategy {
    WaitStrategy PAUSE = new WaitStrategy() {
        @Override
        public void onTailerStalled(final Pauser pauser) {
            pauser.pause();
        }
    };
    WaitStrategy STOP_ON_STALL = new WaitStrategy() {
        @Override
        public void onTailerStalled(final Pauser pauser) {
            throw new StopException("Reached end of chronicle");
        }
    };
    WaitStrategy LOG_START_MESSAGE = new WaitStrategy() {
        private boolean started = false;

        @Override
        public void onTailerStalled(final Pauser pauser) {
            if (started) {
                PAUSE.onTailerStalled(pauser);
            } else {
                LOGGER.info(STARTED_MESSAGE);
                started = true;
            }
        }
    };

    void onTailerStalled(final Pauser pauser);

    String STARTED_MESSAGE = "ALL STARTED AND CAUGHT UP";
    org.slf4j.Logger LOGGER = LoggerFactory.getLogger(WaitStrategy.class);
}
