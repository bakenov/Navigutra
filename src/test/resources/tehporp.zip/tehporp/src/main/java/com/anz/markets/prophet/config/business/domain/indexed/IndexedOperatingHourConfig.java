package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.general.OperatingHourConfig;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Operating hours is a list of open and closed time (OperatingHourSpecification). This class
 * wraps around that list of specification and provide a method to evaluate the effective specification for now.
 * <p>
 * The effective specification is the specification that is the most recent. e.g., if the specification is  Monday 9am OPEN,
 * Monday 5pm CLOSE and now is 10 am, the effective specification for now is MONDAY 9am OPEN.
 * <p>
 * For each entity there must be at least one specifications and that no specification has the same time as another specification.
 */
public class IndexedOperatingHourConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(IndexedOperatingHourConfig.class);

    private final EnumObjMap<OperatingHourEntity, List<OperatingHourSpecification>> operatingHoursByEntity = new EnumObjMap<>(OperatingHourEntity.class);


    public IndexedOperatingHourConfig(final List<OperatingHourConfig> operatingHourConfigs) {
        for (int i = 0; i < operatingHourConfigs.size(); i++) {
            final OperatingHourConfig operatingHourConfig = operatingHourConfigs.get(i);
            assertThatConfigIsValid(operatingHourConfig);
            GcFriendlyAssert.isNull(operatingHoursByEntity.get(operatingHourConfig.getEntity()), "OperatingEntity must only be defined once: %s", operatingHourConfig.getEntity());
            operatingHoursByEntity.put(operatingHourConfig.getEntity(), operatingHourConfig.getHoursAsList());
        }
    }

    private void assertThatConfigIsValid(final OperatingHourConfig operatingHourConfig) {
        final List<OperatingHourSpecification> specs = operatingHourConfig.getHoursAsList();
        GcFriendlyAssert.isTrue(specs.size() > 0, "At least one specification must be defined. %s", operatingHourConfig);

        for (int i = 0; i < specs.size(); i++) {
            GcFriendlyAssert.isTrue(specs.get(i).state != OperatingHourSpecification.State.UNDEFINED, "State must not be UNDEFINED");
            for (int j = i + 1; j < specs.size(); j++) {
                GcFriendlyAssert.isTrue(!specs.get(i).hasSameTime(specs.get(j)), "Operating hours must not be repeated. %s", operatingHourConfig);
            }
        }
    }

    public boolean hasConfig(final OperatingHourEntity entity) {
        return operatingHoursByEntity.get(entity) != null;
    }

    /**
     * Returns the effective specification (open or close) for this instance in time.
     */
    public OperatingHourSpecification getEffectiveSpecificationForNow(final OperatingHourEntity entity) {
        final long nowInSeconds = nowInSeconds();

        final List<OperatingHourSpecification> operatingHourSpecifications = operatingHoursByEntity.get(entity);
        // Do not move this Jerry, sort is a function of clock time
        Collections.sort(operatingHourSpecifications);

        OperatingHourSpecification effectiveSpec = null;

        // Specifications are sorted in chronological order with all specifications converted into real instances in time.
        // in present or future date relative to now.
        //
        //   today                                 tomorrow
        //     |--------------[------------]----------|--------[------------]---------------|
        //                open(s1)     close(s2)          open(s3)     close(s4)
        //                         ^
        //                         |- scenario a: now with effective spec as s1
        //                                        ^
        //                                        |- scenario b: now with effective spec as s2
        //             ^
        //             |- scenario c: now with effective spec as s4
        //
        // Most of the spec will be in the future (e.g., if it is not for today) - except for ones that are defined on the
        // same day(but earlier time) as now.
        //
        // The algorithm is to scan through and find the last spec that is just before now (scenario a & b).
        // If no spec exists that is earlier from now then the effective spec must be the last one in the list (scenario 4).
        //
        // There must be at least one item in specification and to avoid ambiguity, open and close spec must not be the same time.
        //
        int i = 0;
        while (i < operatingHourSpecifications.size() && operatingHourSpecifications.get(i).toInstanceEpochSecond() <= nowInSeconds) {
            effectiveSpec = operatingHourSpecifications.get(i++);
        }

        // we've exhausted the search for today, the operating hour must be the last in the list (scenario c).
        if (effectiveSpec == null) {
            effectiveSpec = operatingHourSpecifications.get(operatingHourSpecifications.size() - 1);
        }
        return effectiveSpec;
    }

    private static long nowInSeconds() {
        return TimeUnit.NANOSECONDS.toSeconds(Context.context().getInternalTimeStampNS());
    }

}
