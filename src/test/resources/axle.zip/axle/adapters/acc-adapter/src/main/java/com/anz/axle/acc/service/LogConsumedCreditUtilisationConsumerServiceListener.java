package com.anz.axle.acc.service;

import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import com.anz.axle.common.dao.CreditCheckLogDAO;
import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.CreditCheckLogEntry;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("logConsumedCreditUtilisationConsumerServiceListener")
public class LogConsumedCreditUtilisationConsumerServiceListener implements CreditUtilisationConsumerServiceListener {
    private final static Logger LOG = Logger.getLogger(CreditUtilisationConsumerService.class);

    @Autowired
    private CreditCheckLogDAO creditCheckLogDao;

    @Autowired
    @Qualifier("creditCheckLogEntryBuilder")
    private Builder<CreditCheckLogEntry, CurrencyVenueExclusion> builder = null;

    @Override
    public void onConsume(CurrencyVenueExclusion exclusion) {
        try {
            CreditCheckLogEntry entry = builder.build(exclusion);
            creditCheckLogDao.save(entry);
        } catch (Throwable e) {
            LOG.error("Could not log consumed exclusion", e);
        } finally {
            LOG.info("[SAVED EXCLUSION] : " + exclusion.toString());
        }
    }

    @Override
    public void onConsume(CounterpartyCreditUtilisationValue utilisation) {
        LOG.info("[SAVED UTILISATION] : " + utilisation.toString());
    }

    /**
     * Test purposes only.
     * @param dao
     */
    protected void setCreditCheckLogDao(CreditCheckLogDAO dao) {
        this.creditCheckLogDao = dao;
    }

    /**
     * Testing purposes only.
     * @param builder
     */
    protected void setBuilder(Builder<CreditCheckLogEntry, CurrencyVenueExclusion> builder) {
        this.builder = builder;
    }
}
