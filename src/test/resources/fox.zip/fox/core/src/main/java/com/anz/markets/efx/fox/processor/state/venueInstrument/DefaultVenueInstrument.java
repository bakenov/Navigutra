package com.anz.markets.efx.fox.processor.state.venueInstrument;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.Venue;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class DefaultVenueInstrument implements VenueInstrument {
    private final Instrument instrument;
    private final Venue venue;
    private final RequestKey requestKey;
    private final DefaultMarketDataBook marketDataBook;
    private final Consumer<VenueInstrument> onEnabledConsumer;
    private final Consumer<VenueInstrument> onDisabledConsumer;

    private double priceIncrement;
    private int sizeIncrement;
    private int clipSizeMultiple;
    private double maxAllowedParentOrderQty;
    private int minClipSize;
    private int maxClipSize;
    private int staleDataTimeout;
    private int priority;
    private int proportion;
    private boolean enabled;

    private int topBidIndex;
    private int topAskIndex;

    public DefaultVenueInstrument(final Instrument instrument,
                                  final Venue venue,
                                  final int initialBookSize,
                                  final Consumer<VenueInstrument> onEnabledConsumer,
                                  final Consumer<VenueInstrument> onDisabledConsumer) {
        this.instrument = Objects.requireNonNull(instrument);
        this.venue = Objects.requireNonNull(venue);
        this.onEnabledConsumer = Objects.requireNonNull(onEnabledConsumer);
        this.onDisabledConsumer = Objects.requireNonNull(onDisabledConsumer);
        this.requestKey = RequestKey.of(venue.venueId(), instrument.key());
        this.marketDataBook = new DefaultMarketDataBook(requestKey, initialBookSize);
    }

    @Override
    public Instrument instrument() {
        return instrument;
    }

    @Override
    public Venue venue() {
        return venue;
    }

    @Override
    public RequestKey requestKey() {
        return requestKey;
    }

    @Override
    public MarketDataBook marketDataBook() {
        return marketDataBook;
    }

    @Override
    public double priceIncrement() {
        return priceIncrement;
    }

    @Override
    public int sizeIncrement() {
        return sizeIncrement;
    }

    @Override
    public int clipSizeMultiple() {
        return clipSizeMultiple;
    }

    @Override
    public double maxAllowedParentOrderQty() {
        return maxAllowedParentOrderQty;
    }

    @Override
    public int minClipSize() {
        return minClipSize;
    }

    @Override
    public int maxClipSize() {
        return maxClipSize;
    }

    @Override
    public int staleDataTimeout() {
        return staleDataTimeout;
    }

    @Override
    public int priority() {
        return priority;
    }

    @Override
    public int proportion() {
        return proportion;
    }

    @Override
    public boolean enabled() {
        return enabled;
    }

    @Override
    public int topBidIndex() {
        return topBidIndex;
    }

    @Override
    public int topAskIndex() {
        return topAskIndex;
    }

    @Override
    public void topBidIndex(final int index) {
        topBidIndex = index;
    }

    @Override
    public void topAskIndex(final int index) {
        topAskIndex = index;
    }

    @Override
    public MarketDataEntry topBid() {
        return topBidIndex != NULL_MD_ENTRY_INDEX && topBidIndex < marketDataBook.bids().size() ? marketDataBook.bids().get(topBidIndex) : null;
    }

    @Override
    public MarketDataEntry topAsk() {
        return topAskIndex != NULL_MD_ENTRY_INDEX && topAskIndex < marketDataBook.asks().size() ? marketDataBook.asks().get(topAskIndex) : null;
    }

    public DefaultVenueInstrument priceIncrement(final double priceIncrement) {
        this.priceIncrement = priceIncrement;
        return this;
    }

    public DefaultVenueInstrument sizeIncrement(final int sizeIncrement) {
        this.sizeIncrement = sizeIncrement;
        return this;
    }

    public DefaultVenueInstrument clipSizeMultiple(final int clipSizeMultiple) {
        this.clipSizeMultiple = clipSizeMultiple;
        return this;
    }

    public DefaultVenueInstrument maxAllowedParentOrderQty(final double maxAllowedParentOrderQty) {
        this.maxAllowedParentOrderQty = maxAllowedParentOrderQty;
        return this;
    }

    public DefaultVenueInstrument minClipSize(final int minClipSize) {
        this.minClipSize = minClipSize;
        return this;
    }

    public DefaultVenueInstrument maxClipSize(final int maxClipSize) {
        this.maxClipSize = maxClipSize;
        return this;
    }

    public DefaultVenueInstrument staleDataTimeout(final int staleDataTimeout) {
        this.staleDataTimeout = staleDataTimeout;
        return this;
    }

    public DefaultVenueInstrument priority(final int priority) {
        this.priority = priority;
        return this;
    }

    public DefaultVenueInstrument proportion(final int proportion) {
        this.proportion = proportion;
        return this;
    }

    public DefaultVenueInstrument enabled(final boolean enabled) {
        final boolean origEnabled = this.enabled;
        this.enabled = enabled;
        if (origEnabled && !enabled) {
            onDisabledConsumer.accept(this);
        } else if(!origEnabled && enabled) {
            onEnabledConsumer.accept(this);
        }
        return this;
    }

    @Override
    public String toString() {
        return "DefaultVenueInstrument{" +
                "instrument=" + instrument.key() +
                ", venue=" + venue.venueId() +
                ", priceIncrement=" + priceIncrement +
                ", sizeIncrement=" + sizeIncrement +
                ", clipSizeMultiple=" + clipSizeMultiple +
                ", maxAllowedParentOrderQty=" + maxAllowedParentOrderQty +
                ", minClipSize=" + minClipSize +
                ", maxClipSize=" + maxClipSize +
                ", staleDataTimeout=" + staleDataTimeout +
                ", priority=" + priority +
                ", proportion=" + proportion +
                ", enabled=" + enabled +
                '}';
    }
}
