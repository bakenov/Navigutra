package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.HeaderDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;

public interface UserConfigDecoder extends HeaderDecoder {
    Body body();
    void appendTo(StringBuilder stringBuilder);

    interface Body {
        StringDecoder userName();
        EnumerableSetDecoder<UserGroup> userGroups();
        StringDecoder location();
    }
}