package com.anz.markets.prophet.positionrisk;

import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.ChronicleQueueBuilder;
import net.openhft.chronicle.ExcerptAppender;
import net.openhft.chronicle.ExcerptTailer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.LockSupport;

import static org.junit.Assert.fail;

/*
Performance on JS laptop
---------------------------------
reps 10,000,000 delayNS 1
Latencies NS min: 0 mode 0 90th 1000 99th 1000 max 1366000

reps 10,000,000 delayNS 1
Latencies NS min: 113 mode 316 90th 7094353 99th 19721337 max 146867699

reps 1,000,000 delayNS 10
Latencies NS min: 0 mode 0 90th 1000 99th 1000 max 2336000

reps 1,000,000 delayNS 1000
Latencies NS min: 0 mode 0 90th 1000 99th 1000 max 2256000

reps 100,000,000 delayNS 0
finished write -- with no delay, writing faster than reading!!!
Latencies NS min: 0 mode 309767000 90th 1107744000 99th 1282187000 max 1295974000

Performance on build box Run #1
---------------------------------
reps 10,000,000 delayNS 1
Latencies NS min: 113 mode 316 90th 7094353 99th 19721337 max 146867699

[18:21:34] :				 [test2] [Test Output]
reps 100,000 delayNS 10
Latencies NS min: 126 mode 318 90th 9371902 99th 17880522 max 42785341

[18:21:40] :				 [test3] [Test Output]
reps 1000 delayNS 1000
Latencies NS min: 133 mode 186 90th 4121644 99th 6329005 max 6621581

[18:21:40] :				 [test4] [Test Output]
reps 100,000,000 delayNS 0
Latencies NS min: 151 mode 62871528 90th 447165366 99th 922225628 max 991499673

Performance on build box Run #2
---------------------------------
reps 10000000 delayNS 1
Latencies NS min: 99 mode 242 90th 380 99th 812 max 1138968

[12:29:28]test2 (5s)
reps 100000 delayNS 10
Latencies NS min: 183 mode 304 90th 414 99th 811 max 150881

[12:29:33]test3
reps 1000 delayNS 1000
Latencies NS min: 184 mode 293 90th 377 99th 571 max 126285

[12:29:34]test4 (46s)
reps 100000000 delayNS 0
Latencies NS min: 129 mode 427 90th 1181039 99th 2271100 max 2623519

 */
public class ChronicleLatencyTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleLatencyTest.class);
    private static String basePath = "./chron_lat";
    private static final String[] STRINGS;

    static {
        STRINGS = new String[1 + ('Z' - 'A')];
        for (char c = 'A'; c <= 'Z'; c++) {
            STRINGS[c - 'A'] = Character.toString(c);
        }
    }

    @AfterClass
    @BeforeClass
    public static void clean() {
        LOGGER.warn("Cleanup Chronicle {}", basePath);
        ChronicleGate.deleteNow(basePath);
    }

    @Before
    @After
    public void beforeAfter() {
        ChronicleLatencyTest.clean();
    }

    @Test
    public void test1() throws IOException, InterruptedException {
        doit(1_000_000, 1);
    }

    @Test
    public void test2() throws IOException, InterruptedException {
        doit(100_000, 10);
    }

    @Test
    public void test3() throws IOException, InterruptedException {
        doit(100_000, 1000);
    }

    @Test
    public void test4() throws IOException, InterruptedException {
        doit(1_000_100, 0);
    }

    @Test
    public void test4threaded() throws IOException, InterruptedException {
        doit(1_000_100, 0, 4);
    }

    private void doit(final int reps, final int delayNS) throws IOException, InterruptedException {
        doit(reps, delayNS, 1);
    }

    private void doit(final int reps, final int delayNS, final int threads) throws IOException, InterruptedException {
        LOGGER.warn("reps " + reps + " delayNS " + delayNS);
        final Chronicle chronicle = ChronicleQueueBuilder.indexed(basePath).build();
        final long[] delays = new long[reps];
        final CountDownLatch done = new CountDownLatch(threads + 1);

        for (int threadCount = 0; threadCount < threads; threadCount++) {
            final int tc = threadCount;
            final Thread t = new Thread(() -> {
                try {
                    boolean errors = false;
                    int c = 0;
                    final ExcerptTailer reader = chronicle.createTailer();
                    while (true) {
                        while (!reader.nextIndex()) {
                            ; // while until there is a new Excerpt to read
                        }
                        final byte index = reader.readByte();
                        final byte cByte = (byte) c;
                        if (cByte != index) {
                            System.err.println("failed for byte " + c + " b=" + index + " should be " + cByte);
                            errors = true;
                        }
                        final int index2 = reader.readInt();
                        if (c != index2) {
                            System.err.println("failed for int  " + c + " b=" + index2 + " should be " + c);
                            errors = true;
                        }
                        final long index3 = reader.readLong();
                        if (c != index3) {
                            System.err.println("failed for long " + c + " b=" + index3 + " should be " + c);
                            errors = true;
                        }
                        final String str = reader.readUTF();
                        if (!STRINGS[c % STRINGS.length].equals(str)) {
                            System.err.println("failed for long " + c + " b=" + index3 + " should be " + c);
                            errors = true;
                        }
                        long sent = reader.readLong();
                        if (tc == 0) {
                            long delay = System.nanoTime() - sent;
                            delays[c] = delay;
                        }
                        reader.finish();
                        if (++c == reps) {
                            break;
                        }
                    }
                    LOGGER.warn("finished read");
                    reader.close();
                    done.countDown();
                    if (errors) {
                        fail("errors - check stderr for details");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            t.start();
        }

        ExcerptAppender appender = chronicle.createAppender();
        int i = 0;
        for (; i < reps; i++) {
            appender.startExcerpt(75);
            appender.writeByte(i);
            appender.writeInt(i);
            appender.writeLong(i);
            appender.writeUTF(STRINGS[i % STRINGS.length]); // +i
            appender.writeLong(System.nanoTime());
            appender.finish();
            LockSupport.parkNanos(delayNS);
        }
        appender.close();
        LOGGER.warn("finished write");
        done.countDown();

        done.await();
        Arrays.sort(delays);
        LOGGER.warn(String.format("Latencies NS min: %d mode %d 90th %d 99th %d max %d",
                delays[0], delays[reps / 2], delays[(int) (reps * 0.9)], delays[(int) (reps * 0.99)], delays[reps - 1]));
        chronicle.close();
    }

}
