package com.anz.markets.efx.fox.codec.sbe;

import java.lang.reflect.Method;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueCategoriesDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueCategoriesEncoder;
import static org.junit.Assert.assertEquals;

/**
 * Test consistency between {@link VenueCategory} and VenueCategories choice generated from SBE file.
 */
public class EnumsVenueCategoryTest {

    @Test
    public void venueCategoryCountMatches() {
        int count = 0;
        for (final Method method : VenueCategoriesEncoder.class.getMethods()) {
            if (method.getReturnType() == VenueCategoriesEncoder.class && method.getParameterCount() == 1 && method.getParameterTypes()[0] == boolean.class) {
                count++;
            }
        }
        assertEquals("venueCategory count should be same", VenueCategory.length(), count);
    }

    @Test
    public void venueCategoryEncodeDifferentValues() {
        //given
        final MutableDirectBuffer buf = new ExpandableArrayBuffer(8);
        final VenueCategoriesEncoder enc = new VenueCategoriesEncoder();
        enc.wrap(buf, 0);

        //when
        for (int i = 0; i < VenueCategory.length(); i++) {
            Enums.venueCategory(VenueCategory.valueByOrdinal(i), enc, true);
        }

        //then
        assertEquals("each venueCategory should set one bit", VenueCategory.length(), bitCount(buf.byteArray()));

        //when
        for (int i = 0; i < VenueCategory.length(); i++) {
            Enums.venueCategory(VenueCategory.valueByOrdinal(i), enc, false);
        }

        //then
        assertEquals("all bits should have been cleared", 0, bitCount(buf.byteArray()));
    }

    @Test
    public void encodeAndDecode() {
        //given
        final MutableDirectBuffer buf = new ExpandableArrayBuffer(8);
        final VenueCategoriesEncoder enc = new VenueCategoriesEncoder();
        final VenueCategoriesDecoder dec = new VenueCategoriesDecoder();
        enc.wrap(buf, 0);
        dec.wrap(buf, 0);

        for (int i = 0; i < VenueCategory.length(); i++) {
            //when
            Enums.venueCategory(VenueCategory.valueByOrdinal(i), enc, true);

            //then
            assertEquals("1 bit should be set", 1, bitCount(buf.byteArray()));

            for (int j = 0; j < VenueCategory.length(); j++) {
                //when
                final boolean set = Enums.venueCategory(VenueCategory.valueByOrdinal(j), dec);
                //then
                assertEquals("flag value not as expected", i==j, set);
            }

            //when
            Enums.venueCategory(VenueCategory.valueByOrdinal(i), enc, false);

            //then
            assertEquals("no bits should be set", 0, bitCount(buf.byteArray()));
        }
    }

    private static int bitCount(final byte[] bytes) {
        int count = 0;
        for (final byte b : bytes) {
            count += Integer.bitCount(b & 0xff);
        }
        return count;
    }
}
