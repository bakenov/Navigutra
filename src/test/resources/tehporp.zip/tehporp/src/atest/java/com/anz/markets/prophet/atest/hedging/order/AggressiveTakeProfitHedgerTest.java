package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTakeProfitHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.efx.ngaro.math.Epsilon;
import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerType.*;
import static com.anz.markets.prophet.domain.HedgeTriggerType.AGR_AXL_TWAP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURSEK;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.USDJPY;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_ARBITRAGE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_RFX;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.number.IsCloseTo.closeTo;

@Requirement(Requirement.Ref.HEDGING_4_3)
@RestartBeforeTest(reason = "As hedger states are left hanging")
public class AggressiveTakeProfitHedgerTest extends BaseAcceptanceSpecification {
    private NewOrder newOrder;

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setAggressiveTwapHedgerConfigs(Arrays.asList(
                        new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                .setMaximumSpread(0.0002)
                                .setMinimumQuantity(1_000_000)
                                .setMinimumRisk(30_000_000)
                                .setOrderRateLimit(1_000_000)
                                .setOrderRateTimePeriodMS(1_000)
                                .setTradingTimeZone(TradingTimeZone.LDN)
                ));

        return configuration;
    }

    @Test
    // AXPROPHET-953
    public void disableAXLMktLiquidityCheck() {
        setup:
        // start with AXL liquidity check enabled
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(3_000_000.)
                                    .setLiquidityCheckEnabled(true)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        // since no AXL book, do not hedge
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // update config to turn off AXL liquidity check
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(3_000_000.)
                                    .setLiquidityCheckEnabled(false)
                    ))
            );
        }
        and:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void unmatchedCounterPartyNoHedge() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(1)
                                    .setActivePeriodMS(1_000)
                    ))

            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75, "AnotherCounterParty"));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TP));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void hedgeSellOrderCorrectPriceNonJPY() {
        double triggeringTradePrice = 9.70001;
        double priceImprovementPips = 0.6;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, EURSEK)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(priceImprovementPips)
                                    .setActivePeriodMS(1_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, EURSEK, 9.74998, 9.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, EURSEK, 9.74996, 9.75004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURSEK, 3_000_000, triggeringTradePrice, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(EURSEK, AGR_AXL_TP));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            assertThat(newOrder.getPrice(), is(triggeringTradePrice + (priceImprovementPips / 10000)));
        }
    }

    @Test
    public void hedgeBuyOrderCorrectPriceJPY() {
        double triggeringTradePrice = 88.701;
        double priceImprovementPips = 1;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, USDJPY)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(priceImprovementPips)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDJPY, 88.701, 88.705, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDJPY, 88.701, 88.705, now()));
            prophet.receive(tdd.client_trade_001(USDJPY, -1_000_000, 88.703));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDJPY, -3_000_000, triggeringTradePrice, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(USDJPY, AGR_AXL_TP));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getPrice(), is(closeTo(triggeringTradePrice - (priceImprovementPips / 100), Epsilon.EPS_0_001.getValue())));
        }
    }

    @Test
    public void minTriggerQtyNotMet() {
        double minTriggerQty = 1_000_001;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, USDJPY)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(minTriggerQty)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(1)
                                    .setActivePeriodMS(1_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDJPY, 88.701, 88.705, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDJPY, 88.701, 88.705, now()));
            prophet.receive(tdd.client_trade_001(USDJPY, -1_000_000, 88.703));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDJPY, -1_000_000, 88.703, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(USDJPY, AGR_AXL_TP));
            prophet.notExpect(NewOrder.class);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDJPY, -1_000_001, 88.703, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-645
    public void buyMinOrderQtyNotMet() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(3_000_001.)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        // given counterparty trade, hedger would hedge 3mio. But this is less than minOrderQty so do not hedge
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_001, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-645
    public void buyHedgeOrderRounded() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.0)
                                    .setMaximumRiskIncrease(1_000_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(1_000_000.)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setCancelUnknownTimeoutMS(10_000).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(10000),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_515_000.5, 0.75000));
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_514_000.5, .75000, "TriggerClientCounterparty"));
        }
        then:
        // OrderQuantityPrecision set to 10k.  Order qty rounded down to nearest 10k
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_510_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    public void clientBuy_ShortToZeroAfterHedging_FullAmt() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(3_000_000.)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.7500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-645
    public void sellMinOrderQtyNotMet() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(3_000_001.)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // given counterparty trade, hedger would hedge 3mio. But this is less than minOrderQty so do not hedge
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_001, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }

    @Test
    // AXPROPHET-645
    public void sellHedgeOrderRounded() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.0)
                                    .setMaximumRiskIncrease(1_100_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(1_000_000.)
                    ))
                    .setHedgePortfolioConfigs(Arrays.asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setCancelUnknownTimeoutMS(10_000).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(10000),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderQuantityPrecision(0)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_519_000.99, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_519_000.99, .75000, "TriggerClientCounterparty"));
        }
        then:
        // OrderQuantityPrecision set to 10k.  Order qty rounded down to nearest 10k
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_510_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void clientSell_LongToZeroAfterHedging_FullAmt() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                                    .setMinimumOrderQuantity(3_000_000.)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void clientSell_LongToShortAfterHedging_FullAmt() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(6_000_000d));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void clientSell_LongToShortAfterHedging_AmtReduced() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(2_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(5_500_000.0)); // AXPROPHET-1012
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void clientSell_LongToLongAfterHedging_FullAmt() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 4_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(500);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderPartialFill(newOrder, 500_000, 0.75000);
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TP)), 2_000);
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void clientSell_strategyToUseBiasedPositionsForOrderAmt() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(2_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75000));
            // set up biased position -> bias pos is 2mio!
            prophet.receive(tdd.biasPosition(Currency.AUD, -1_000_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        // if using non-biased pos, hedge amt would have been capped at 5.5mio
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(6_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void clientBuy_LongUnchangedAfterHedging_AmtReduced() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_500_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    public void clientBuy_LongToLongAfterHedging_AmtReduced() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(2_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 4_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0)); // AXPROPHET-1012
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    // AXPROPHET-1012
    // maximumRiskIncrease is now the maximumPosition which can be aggress'd
    public void clientBuy_LongToLongAfterHedging_NoHedge() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(2_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 4_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    public void clientBuy_strategyToUseBiasedPositionsForOrderAmt() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(2_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 4_000_000, 0.75000));
            // set up biased position, biased pos is 2mio!
            prophet.receive(tdd.biasPosition(Currency.AUD, 2_000_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        // if using non-biased pos, hedge amt would have been 0.5mio
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(2_500_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    public void clientSell_ShortToShortAfterHedging_AmtReduced() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(2_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -2_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(2_500_000d));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
    }

    @Test
    public void clientSell_ShortToShortAfterHedging_NoHedge() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void monitorActivePeriodContinueToResend() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty(active period starts when received) deal which triggers hedge order
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        // @t+2.49 hedge trade is rejected. Hedger places out order again
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1) + TimeUnit.MILLISECONDS.toMillis(490));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        // @t+2.50 hedge trade is rejected. Hedger does NOT place order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(10));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void monitorRemainingQtyDuringActivityPeriodNotFilled() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty deal which triggers hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2 hedge order is partially filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_250_000, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2.4 hedge order is partially filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_000_000, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2.5 hedge trade is rejected. Hedger does NOT place order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void monitorRemainingQtyDuringActivityPeriodFullyFilled() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_400_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty deal which triggers hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2 hedge order is partially filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_250_000, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2.4 hedge order is partially filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void sanityTestDoNotHedgeWhileCurrentlyHedging() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 4_000_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(500);
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TP)), 2_000);
        }
        and:
        {
            prophet.notExpect(IllegalArgumentException.class, matches(".*IGNORED_INVALID_TRANSITION.*"));
        }
    }

    @Test
    public void queueSubsequentCounterpartyTradeFirstPartialFilled() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000d)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_400_000d)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500L)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty deal which triggers hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TP;posNotional=3000000;epNotional=4500000;cpty=TriggerClientCounterparty;tradeId=Order.*1001000ms;tradeQty=1500000;tradePrice=0.75;hedgeQty=-3000000.0;remainQty=-3000000.0;priceImprovement=3.0E-4"));
        }
        when:
        // @t+2 hedge order is partially filled. Also receive second counterparty trade.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_250_000d, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TP;posNotional=1500000;epNotional=2250000;cpty=TriggerClientCounterparty;tradeId=Order.*1001000ms;tradeQty=1500000;tradePrice=0.75;hedgeQty=-3000000.0;remainQty=-1750000.0;priceImprovement=3.0E-4"));
        }
        when:
        // @t+2.4 hedge order is partially filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400L));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_000_000d, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));

            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition instrumentPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(instrumentPos.getInstrumentPositionInNotional(), isRoundedTo(-750_000.0));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TP;posNotional=250000;epNotional=375000;cpty=TriggerClientCounterparty;tradeId=Order.*1001000ms;tradeQty=1500000;tradePrice=0.75;hedgeQty=-3000000.0;remainQty=-750000.0;priceImprovement=3.0E-4"));
        }
        when:
        // @t+2.5 post 1st order's active period, hedge trade is rejected. Hedger now allowed to hedge 2nd counterparty trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        // posNotional=-750000, therefore hedge amt is capped at 2_150_000.0
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(2_150_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            prophet.expect(org.apache.logging.log4j.Level.INFO, newOrderComment("AGR_AXL_TP;posNotional=-750000;epNotional=-1125000;cpty=TriggerClientCounterparty;tradeId=Order.*1002000ms;tradeQty=1500000;tradePrice=0.75;hedgeQty=2150000.0;remainQty=2150000.0;priceImprovement=3.0E-4"));
        }
    }

    @Test
    public void queueSubsequentCounterpartyTradeFirstFullyFilled() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000d)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_400_000d)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500L)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty deal which triggers hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2 hedge order is partially filled. Also receive second counterparty trade.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_250_000d, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2.4 hedge order is fully filled. Hedger now allowed to hedge 2nd counterparty trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(400L));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // hedger places out hedge order based on latest pos
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition instrumentPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(instrumentPos.getInstrumentPositionInNotional(), isRoundedTo(-1_500_000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(2_900_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
    }

    @Test
    public void activePeriodOfSubsequentCounterpartyTrade() {
        // active period begins upon counterparty trade arriving
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000d)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_400_000d)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500L)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty deal which triggers hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+1.1 hedge order is partially filled. Also receive second counterparty trade(Active Period begins)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(100));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 1_250_000d, 0.75000);
        }
        then:
        // hedger places out hedge order for remaining unfilled qty
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_750_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2.4 hedge order is fully filled. Hedger now allowed to hedge 2nd counterparty trade
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1L) + TimeUnit.MILLISECONDS.toMillis(300L));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // hedger places out hedge order based on latest pos
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition instrumentPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(instrumentPos.getInstrumentPositionInNotional(), isRoundedTo(-1_500_000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(2_900_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        // @t+2.6 Order rejected. Since active period is concluded hedger does not resend
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(200L));
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void activePeriodExpiresThenPlaceTwapHedgeOrder() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_000)

                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_000_000)
                                    .setOrderRateLimit(2_999_000)
                                    .setOrderRateTimePeriodMS(1_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 3000000, 0.75002, 3000000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 3000000, 0.75004, 3000000));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            // Take Profit BUYING_REQ and BUYING
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.BUYING));
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TP)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(3000000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        {
            // TWAP BUYING_REQ only
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUY_REQ));
            HedgeDecision twapHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(twapHedgeDecision.getQuantity(), is(2999000.0));
        }
        when:
        // TP hedge order rejected.
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        // since TP active period expires TP stands down. TWAP takes over and places order
        {
            // TP IDLE
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, AGR_AXL_TP));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));

            // TWAP BUYING
            HedgeDecision twapHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUYING)).getLast();
            assertThat(twapHedgeDecision.getQuantity(), is(2999000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(2999000.0));
        }
    }

    @Test
    @Requirement(Requirement.Ref.HEDGING_4_1_8)
    @DisplayName("If Take Profit Strategy and TWAP are triggered then strategy with GREATEST amt wins")
    public void takeProfitAmtGreaterThanTwap() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(2_000)

                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_000_000)
                                    .setOrderRateLimit(2_999_000)
                                    .setOrderRateTimePeriodMS(1_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 3000000, 0.75002, 3000000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 3000000, 0.75004, 3000000));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            // Take Profit BUYING_REQ and BUYING
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.BUYING));
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TP)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(3000000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        // TWAP wants to buy but TP already has order out
        {
            // TWAP BUYING_REQ only
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUY_REQ));
            HedgeDecision twapHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(twapHedgeDecision.getQuantity(), is(2999000.0));
        }
        when:
        // TP hedge order rejected.
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            // Take Profit IDLE, BUY_REQ, BUYING
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.BUYING)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(3000000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
        }
        when:
        // t+2 TP hedge order filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.IDLE));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.IDLE));
        }
    }

    @Test
    @Requirement(Requirement.Ref.HEDGING_4_1_8)
    @DisplayName("Take Profit Strategy take precedence over TWAP when hedging amts are equal")
    public void takeProfitAndTwapEqualHedgingAmts() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(2_000)

                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_000_000)
                                    .setOrderRateLimit(3_000_000)
                                    .setOrderRateTimePeriodMS(1_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 3000000, 0.75002, 3000000));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 3000000, 0.75004, 3000000));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            // Take Profit BUYING_REQ and BUYING
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.BUYING));
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, AGR_AXL_TP)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(3000000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)), 1_000);
        }
        then:
        // TWAP wants to buy but TP already has order out
        {
            // TWAP BUYING_REQ only
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, HedgeTriggerState.BUY_REQ));
            HedgeDecision twapHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeTriggerType(AUDUSD, AGR_AXL_TWAP)).getLast();
            assertThat(twapHedgeDecision.getQuantity(), is(3000000.0));
        }
        when:
        // TP hedge order rejected.
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(newOrder));
        }
        then:
        {
            // Take Profit IDLE, BUY_REQ, BUYING
            HedgeDecision tpHedgeDecision = prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TP, HedgeTriggerState.BUYING)).getLast();
            assertThat(tpHedgeDecision.getQuantity(), is(3000000.0));

            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
        }
    }

    @Test
    public void partialFillTradeReceivedBeforeOrderEvent() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, Instrument.AUDUSD)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000d)
                                    .setTriggeringTradeMultiplier(2.0)
                                    .setMaximumRiskIncrease(1_400_000d)
                                    .setMinimumPriceImprovementPips(3)
                                    .setActivePeriodMS(1_500L)

                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74996, 0.75004, now()));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.75000));
        }
        when:
        // @t+1 receive counterparty deal which triggers hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, .75000, "TriggerClientCounterparty"));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(3_000_000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // @t+2 hedge order is partially filled TRADE before order event
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));

            prophet.receiveHedgeOrderPartialFillTrade(newOrder, 1_000_000d, 0.75000);
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_TP));
        }
        when:
        // receive partial fill ORDER EVENT which is ignored
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderPartialFill(newOrder, 1_000_000d, 0.75000);
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_TP));
        }
    }

    @Test
    @Requirement({Requirement.Ref.HEDGING_AXPROPHET_943})
    public void hedgerPausedBeforeTriggeringDeal() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveTakeProfitHedgerConfigs(Arrays.asList(
                            new AggressiveTakeProfitHedgerConfigImpl(Market.AXL, EURSEK)
                                    .setCounterparty("TriggerClientCounterparty")
                                    .setMinimumTriggerQuantity(1_000_000.)
                                    .setTriggeringTradeMultiplier(1.5)
                                    .setMaximumRiskIncrease(1_500_000.)
                                    .setMinimumPriceImprovementPips(0.1)
                                    .setActivePeriodMS(1_000)
                    ))
                    // Pause period set to 5 seconds
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PAUSE_HEDGING_PERIOD_SEC, 5))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, EURSEK, 9.74998, 9.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, EURSEK, 9.74996, 9.75004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000, 0.00004));
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.75000));

            // Pause enabled
            prophet.receive(tdd.setHedgingPause(Currency.SEK, true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURSEK, 3_000_000, 9.70001, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.notExpect(IllegalArgumentException.class, matches(".*IGNORED_INVALID_TRANSITION.*"));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+5 PAUSE period inactive.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5_000);
        }
        then:
        {
            prophet.expect(HedgeCurrencyControl.class, isHedgingCcyUnpaused(Currency.SEK));
            prophet.notExpect(NewOrder.class);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURSEK, 1_000_000, 9.70001, "TriggerClientCounterparty"));
        }
        then:
        {
            prophet.expect(NewOrder.class);
        }
    }
}
