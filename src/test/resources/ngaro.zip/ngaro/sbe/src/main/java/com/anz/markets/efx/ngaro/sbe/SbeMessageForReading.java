package com.anz.markets.efx.ngaro.sbe;

import org.agrona.DirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;

public final class SbeMessageForReading implements SbeMessage {

    private final DirectBuffer buffer = new UnsafeBuffer(0, 0);
    private int length = -1;

    @Override
    public DirectBuffer buffer() {
        checkWrapped();
        return buffer;
    }

    @Override
    public int messageLength() {
        checkWrapped();
        return length;
    }

    public SbeMessageForReading wrap(final SbeMessage message) {
        return wrap(message.buffer(), 0, message.messageLength());
    }

    public SbeMessageForReading wrap(final DirectBuffer buffer, final int offset, final int length) {
        this.buffer.wrap(buffer, offset, length);
        this.length = length;
        return this;
    }

    public SbeMessageForReading unwrap() {
        buffer.wrap(0, 0);
        length = -1;
        return this;
    }

    private void checkWrapped() {
        if (length < 0) {
            throw new IllegalStateException("No current message. Hint: call wrap(..) before accessing message");
        }
    }
}
