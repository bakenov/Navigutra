package com.anz.markets.efx.fox.acceptance.api;

import java.util.Queue;

import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

public interface SorEndpoint {
    Queue<TradingMessage> tradingRequest();
    Queue<TradingMessage> tradingResponse();
    Queue<SorMessage> config();
    NewOrderSingle createNewOrderSingle();
    OrderCancelRequest createOrderCancelRequest();
    Heartbeat createHeartbeat();
}
