package com.anz.axle.direct.performance.metrics;

public interface Percentiles extends BasicStats {
    /**
     * Return the value at a given percentile
     *
     * @param percentile Value in [0..100]
     */
    double getPercentile(double percentile);
}
