package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.framework.matcher.WholesaleBookFactorsAssert;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.BenchmarkSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.pricer.wholesale.BenchmarkSpreadStrategy;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@RestartBeforeTest(reason = "Widening has state.")
public class BenchmarkModelSpread_Test extends BaseAcceptanceSpecification {

    private Instrument driverPairA = Instrument.AUDUSD;

    @Test
    @Requirement(Ref.PRICING_4_5_3)
    @DisplayName("Calculate widened Benchmark Model Spreads")
    public void calculate_benchmark_model_spreads() throws Exception {
        given:
        {
            ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_75M.getQty(), Region.GB).set(TradingTimeZone.LDN, 8.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_100M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_150M.getQty(), Region.GB).set(TradingTimeZone.LDN, 13.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_200M.getQty(), Region.GB).set(TradingTimeZone.LDN, 17.0)
                    ))
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m").setInstrument(Instrument.ANY),
                                    // AXPROPHET-1089 pricing model config to allow Instrument
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m|25m|25m|50m|50m").setInstrument(Instrument.AUDUSD),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m")
                            ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true));

            prophet.receive(configuration);

            // setup news event to generate MODEL SPREAD:
            // conNewsWeight.W_5 and tob base spread = 0.3pips
            // MODEL SPREAD = 5 * 0.3pips = 1.5pips
            prophet.receive(tdd.econNews(now()));
        }
        when:
        {
            // HSP Benchmark Spread = 2.5pip
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, driverPairA, 0.75080, 0.75105));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, driverPairA, 0.75095, 0.75105));
        }
        then:
        {
            /**
             * Benchmark Spread = 2.5pip
             * Model Spread = 1.5pip
             * Difference = 1.0pip

             * Base Spread = 0.3
             * TooTightThresholdAsProportionOfBaseSpread(3.0)
             * Allowable Threshold = 0.3 * 3 = 0.9pip

             * Difference > Allowable Threshold.  Therefore WIDEN MODEL SPREAD

             * WIDENED MODEL SPREAD =  BENCHMARK Spread (2.5pip) * WidenedSpreadAsProportionOfBenchmarkSpread(1.2) = 3 pip
             **/
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, exactly(2), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wholesaleBookFactors.getMarket(), is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.75100));
            assertThat(wholesaleBookFactors.getBaseSpread(), isNear(0.3));
            assertThat(wholesaleBookFactors.getModelSpread(), isNear(1.5));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), isNear(2.5));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), isNear(3.0));

            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_1M, 3.0);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_3M, 4.0);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_5M, 4.5);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_10M, 5.5);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_15M, 6.1);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_20M, 6.7);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_30M, 7.9);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_40M, 8.7);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_50M, 9.7);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_75M, 12.9);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_100M, 14.7);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_150M, 17.7);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_200M, 21.7);

            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(2), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_A)).getLast();
            assertThat(cp.getBids().size(), is(13));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // HSP Benchmark Spread = 2.2pip
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, driverPairA, 0.75097, 0.75119));
        }
        then:
        {
            /**
             * Benchmark Spread = 2.2pip
             * Model Spread = 1.5pip
             * Difference = 0.7pip

             * Base Spread = 0.3
             * TooTightThresholdAsProportionOfBaseSpread(3.0)
             * Allowable Threshold = 0.3 * 3 = 0.9pip

             * Difference < Allowable Threshold.  Therefore DO NOT WIDEN MODEL SPREAD
             */
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wholesaleBookFactors.getMarket(), is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.75101));
            assertThat(wholesaleBookFactors.getBaseSpread(), isNear(0.3));
            assertThat(wholesaleBookFactors.getModelSpread(), isNear(1.5));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), isNear(2.2));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), isNear(0.0));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_5_3)
    @DisplayName("Calculate widened Benchmark Model Spreads")
    public void calculate_not_widened_benchmark_model_spreads_based_on_region() throws Exception {
        given:
        {
            ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.JP).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.JP).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.JP).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.JP).set(TradingTimeZone.LDN, 5.0)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true));

            // set Region to JP
            prophet.setRegion(Region.JP);
            prophet.receive(configuration);

            // setup news event to generate MODEL SPREAD:
            // econNewsWeight.W_5 and JP tob base spread = 0.4pips
            // MODEL SPREAD = 5 * 0.4pips = 2.0pips
            prophet.receive(tdd.econNews(now()));
        }
        when:
        {
            // Benchmark Spread = 3.0pip
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, driverPairA, 0.75083, 0.75117));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, driverPairA, 0.75083, 0.75117));
        }
        then:
        {
            /**
             * Benchmark Spread = 3.0 pip
             * Model Spread = 2.0 pip
             * Difference = 1.0 pip

             * Base Spread = 0.4
             * TooTightThresholdAsProportionOfBaseSpread(3.0)
             * Allowable Threshold = 0.4 * 3 = 1.2pip

             * Difference < Allowable Threshold.  Therefore DO NOT WIDEN MODEL SPREAD

             * WIDENED MODEL SPREAD =  NA
             **/
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wholesaleBookFactors.getMarket(), is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.75100));
            assertThat(wholesaleBookFactors.getBaseSpread(), isNear(0.4));
            assertThat(wholesaleBookFactors.getModelSpread(), isNear(2.0));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), is(Double.NaN));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), is(Double.NaN));

            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_1M, 2.0);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_3M, 2.5);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_5M, 3.0);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_10M, 4.0);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_15M, 4.6);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_20M, 5.2);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_30M, 6.4);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_40M, 7.2);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_50M, 8.2);

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509000, 0.7511000));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7508625, 0.7511375));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7508125, 0.7511875));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7507500, 0.7512500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7507100, 0.7512900));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7506500, 0.7513500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7505600, 0.7514400));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7505200, 0.7514800));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7503900, 0.7516100));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_5_3)
    @DisplayName("Use the max of all category benchmarksModel spreads")
    public void multi_tier_benchmark_model_spreads_take_max() throws Exception {
        given:
        {
            ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0)
                    ))
                    .setBenchmarkSpreadConfigs(com.google.common.collect.Lists.newArrayList(
                            new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                    .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                    .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                    .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                    .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.CNX, Market.GS)),
                            new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_B)
                                    .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                    .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                    .setWidenedSpreadAsProportionOfBenchmarkSpread(1.3)
                                    .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.CNX, Market.GS))
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true));

            prophet.receive(configuration);

            // setup news event to generate MODEL SPREAD:
            // conNewsWeight.W_5 and tob base spread = 0.3pips
            // MODEL SPREAD = 5 * 0.3pips = 1.5pips
            prophet.receive(tdd.econNews(now()));
        }
        when:
        {
            // Benchmark Spread = 2.5pip
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00025));
        }

        then:
        {
            /**
             * Benchmark Spread = 2.5pip
             * Model Spread = 1.5pip
             * Difference = 1.0pip

             * Base Spread = 0.3
             * TooTightThresholdAsProportionOfBaseSpread(3.0)
             * Allowable Threshold = 0.3 * 3 = 0.9pip

             * Difference > Allowable Threshold.  Therefore WIDEN MODEL SPREAD

             * Benchmark Category B has the greater WidenedSpreadAsProportionOfBenchmarkSpread factor which will result
             * in the larger WIDENED MODEL SPREAD:
             * WIDENED MODEL SPREAD =  BENCHMARK Spread (2.5pip) * WidenedSpreadAsProportionOfBenchmarkSpread(1.3) = 3.25 pip
             **/
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wholesaleBookFactors.getMarket(), is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.75100));
            assertThat(wholesaleBookFactors.getBaseSpread(), isNear(0.3));
            assertThat(wholesaleBookFactors.getModelSpread(), isNear(1.5));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), isNear(2.5));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), isNear(3.25));
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), is(FactorWindow.CAT_B));

            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_1M, 3.25);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_3M, 4.25);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_5M, 4.75);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_10M, 5.75);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_15M, 6.35);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_20M, 6.95);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_30M, 8.15);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_40M, 8.95);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_50M, 9.95);

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7508375, 0.7511625));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7507625, 0.7512375));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7507250, 0.7512750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7506625, 0.7513375));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7506225, 0.7513775));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7505625, 0.7514375));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7504725, 0.7515275));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7504325, 0.7515675));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7503025, 0.7516975));
            assertThat(clientPrice.getDominantFeatureBid().toString(), is(BenchmarkSpreadStrategy.FEATURE_NAME));
            assertThat(clientPrice.getDominantFeatureOffer().toString(), is(BenchmarkSpreadStrategy.FEATURE_NAME));
        }
    }

    @Test
    @DisplayName("Use the max of all category benchmarksModel spreads")
    public void useMaxOfCategoryBenchmarkModelSpread() {
        /**
         *  Calc each category benchmark model spreads separately and then take the maximum
         **/
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = tdd.configuration_pricing_base();

            configuration.setBenchmarkSpreadConfigs(com.google.common.collect.Lists.newArrayList(
                    new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                            .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                            .setTooTightThresholdAsProportionOfBaseSpread(4.0) // Large -> will not have to widen benchmarkModelSpread
                            .setWidenedSpreadAsProportionOfBenchmarkSpread(1.3)
                            .setBenchmarkSpreadMarkets(Arrays.asList(Market.WSP_U)),
                    new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_B)
                            .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                            .setTooTightThresholdAsProportionOfBaseSpread(0.25) // Small -> will have to widen benchmarkModelSpread
                            .setWidenedSpreadAsProportionOfBenchmarkSpread(1.3)
                            .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL))
            ));

            prophet.receive(configuration);
        }
        when:
        // CAT A HSP BenchmarkSpread 0.5pip
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.76100, 0.76105));
        }
        then:
        {
            // WSP_A Benchmark spread is 0.5 pip
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.5));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), new IsRoundedTo(0.0)); // i.e BenchmarkSpread not widened
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), is(FactorWindow.CAT_A));
        }
        when:
        // (CAT A) HSP BenchmarkSpread 0.5pip -  No widening required
        // (CAT B) AXL BenchmarkSpread 0.4pip -> widened by 1.3 = 0.52 pip => CAT B wins
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.AXL, Instrument.AUDUSD, 0.76101, 0.76105));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.76102, 0.76107));
        }
        then:
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.4));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), new IsRoundedTo(0.52));
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), is(FactorWindow.CAT_B));
        }
    }

    @Ignore("floating point artifacts issue again.")
    @Test
    @Requirement(Ref.PRICING_4_5_3)
    @DisplayName("Do not widened benchmark spread when on the boundary of the threshold")
    public void do_not_widen_spread_when_on_boundary_of_threshold() throws Exception {
        given:
        {
            ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0)

                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true));

            prophet.receive(configuration);

            // setup news event to generate MODEL SPREAD:
            // conNewsWeight.W_5 and tob base spread = 0.3pips
            // MODEL SPREAD = 5 * 0.3pips = 1.5pips
            prophet.receive(tdd.econNews(now()));
        }
        when:
        {
            // Benchmark Spread = 2.4pip
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75100, 0.00024));
        }

        then:
        {
            /**
             * Benchmark Spread = 2.4pip ==> Note system calculates as 2.400000000001798
             * Model Spread = 1.5pip
             * Difference = 0.9 pip ==> Note system calculates 0.900000000001798

             * Base Spread = 0.3
             * TooTightThresholdAsProportionOfBaseSpread(3.0)
             * Allowable Threshold = 0.3 * 3 = 0.9pip

             * Difference == Allowable Threshold.  Therefore do NOT widen Model Spread

             **/
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, isWholesaleBookFactors(driverPairA)).getLast();

            assertThat(wholesaleBookFactors.getMarket(), is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.75100));
            assertThat(wholesaleBookFactors.getBaseSpread(), is(0.3));
            assertThat(wholesaleBookFactors.getModelSpread(), is(1.5));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(2.4));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), new IsRoundedTo(1.5));

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509250, 0.7510750));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7508500, 0.7511500));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7508125, 0.7511875));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7507500, 0.7512500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7507100, 0.7512900));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7506500, 0.7513500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7505600, 0.7514400));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7505200, 0.7514800));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7503900, 0.7516100));
        }
    }

    @Test
    // AXPROPHET-746, AXPROPHET-1089
    @DisplayName("WSP_C contains different band amounts e.g 0.5mio as first band")
    public void wspCModelWithDifferentBandAmounts() throws Exception {
        Instrument driverPairA = Instrument.USDJPY;

        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m"),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setInstrument(Instrument.USDJPY),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setInstrument(Instrument.ANY)
                            ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.ANY, Instrument.AUDUSD, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_500K.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.7),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_2M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.2),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.4),
                            new ClientSpreadConfigImpl(Market.WSP_C, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.0)
                    )));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 111.650, 0.004));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(driverPairA, Market.WSP_C)).getLast();
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_C)).getLast();

            assertThat(wholesaleBookFactors.getMarket(), is(Market.WSP_C));
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(111.650));
            assertThat(wholesaleBookFactors.getBaseSpread(), isNear(0.6));
            assertThat(wholesaleBookFactors.getModelSpread(), isNear(0.6));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), isNear(0.4));
            assertThat(wholesaleBookFactors.getBenchmarkModelSpread(), isNear(0.0));

            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_500K, 0.6);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_1M, 0.7);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_2M, 0.8);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_3M, 0.9);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_5M, 1.2);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_10M, 1.6);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_15M, 2.0);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_20M, 2.4);
            WholesaleBookFactorsAssert.assertModelSpreadAtLevel(wholesaleBookFactors.getSpreadFactorsModel(), Level.QTY_30M, 3.0);

            assertThat(clientPrice.getBids().size(), is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_500K, 111.6470, 111.653000));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_1M, 111.646000, 111.654000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 111.645500, 111.654500));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_3M, 111.644500, 111.655500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 111.641750, 111.658250));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_10M, 111.64000, 111.660000));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_15M, 111.63600, 111.664000));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_20M, 111.63200, 111.668000));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_30M, 111.62900, 111.671000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75, 0.0004));
        }
        then:
        // AUDUSD to use default(ANY) WSP_C pricing model stack i.e first stack is 1mio
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_C)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.74976, 0.75024));
        }
    }
}
