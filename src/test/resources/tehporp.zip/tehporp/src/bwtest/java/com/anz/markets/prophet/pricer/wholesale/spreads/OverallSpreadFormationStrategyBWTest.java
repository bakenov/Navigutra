package com.anz.markets.prophet.pricer.wholesale.spreads;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.pricer.pfp.PliableBook;
import com.anz.markets.prophet.pricer.pfp.cache.ClientPriceDataRegisterDependencyManager;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.pricer.wholesale.DriverInstrumentWholesaleBookManagerTest;
import com.anz.markets.prophet.pricer.wholesale.WholesaleBook;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.io.IOException;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OverallSpreadFormationStrategyBWTest {

    private final OverallSpreadFormationStrategy overallSpreadFormationStrategy = new OverallSpreadFormationStrategy();

    private static final int REPS = 200_000, THRESHOLD = 0;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    private WholesaleBook wholesaleBook;
    private final DataRegisters dataRegisters = new DataRegisters();
    private final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager = new ClientPriceDataRegisterDependencyManager(dataRegisters);

    public OverallSpreadFormationStrategyBWTest() throws IOException {
        final IndexedConfigurationData config = new DriverInstrumentWholesaleBookManagerTest().indexedConfigurationData;

        final PliableBook pliableBook = new PliableBook(Market.WSP_A, Instrument.AUDUSD,clientPriceDataRegisterDependencyManager.getClientPriceRegisters(Market.WSP_A,Instrument.AUDUSD));
        pliableBook.applyConfiguration(config);
        wholesaleBook = new WholesaleBook(Market.WSP_A, pliableBook);

        overallSpreadFormationStrategy.applyConfiguration(config);
    }

    public void scenario_SpreadBasedBookFormation() {

        wholesaleBook.reset();
        wholesaleBook.initInstrument(Instrument.AUDUSD);

        overallSpreadFormationStrategy.execute(wholesaleBook);
    }

    @Test
    public void test_SpreadBasedBookFormation() {
        helper.testAllocationNotExceeded(
                this::scenario_SpreadBasedBookFormation,
                REPS, REPS,
                THRESHOLD
        );
    }

}
