package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.NewOrderSingleSbeDecoder;

public class ChildNewOrderSingleEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChildNewOrderSingleEvent.class);

    private final EventContext eventContext;
    private final ChildOrderRepository childOrderRepository;
    private final ParentOrderRepository.WithInit parentOrderRepository;
    private final NewOrderSingleSbeDecoder newOrderSingleDecoder = new NewOrderSingleSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    public ChildNewOrderSingleEvent(final EventContext eventContext,
                                    final ChildOrderRepository childOrderRepository,
                                    final ParentOrderRepository.WithInit parentOrderRepository) {
        this.eventContext = Objects.requireNonNull(eventContext);
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        newOrderSingleDecoder.wrap(message);

        final String marketId = newOrderSingleDecoder.body().marketId().decodeAndCache(marketIdCache);
        if (!Venue.FOX.name().equals(marketId)) {
            logMessage();

            long parentOrderId = newOrderSingleDecoder.body().clOrdLinkId().decodeLongOrZero();

            final ParentOrder parentOrder = parentOrderRepository.lookupByOrderId(parentOrderId);
            childOrderRepository.init(eventContext, newOrderSingleDecoder, parentOrder);
            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        newOrderSingleDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying child NOS: {}", stringBuilder);
    }
}
