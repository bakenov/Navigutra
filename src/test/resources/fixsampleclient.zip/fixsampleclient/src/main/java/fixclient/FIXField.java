// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * An immutable class to hold individual FIX fields. It is used in the XML
 * parsing phase in order to represent the specified FIX fields to send or to
 * expect.
 */
public class FIXField
{
    private static final String           CURRENT_TIME_PLACEHOLDER = "@CURRENT_TIME@";
    private static final String           PROPERTY_DELIMITER       = "@";
    private static final SimpleDateFormat FIX_DATE_FORMAT          = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");

    private final String                  id;
    private String                        value;

    /**
     * @param id
     *            the field id
     * @param value
     *            the field value
     * @throws IllegalStateException
     */
    public FIXField(final String id, final String value) throws IllegalStateException
    {
        this.id = id;

        // If the value is a current time placeholder, replace this with the
        // current date/time.
        if (value.equals(CURRENT_TIME_PLACEHOLDER))
        {
            this.value = FIX_DATE_FORMAT.format(new Date());
        }
        // if the value is property replacement then fins the corresponding
        // value and use that
        else if (value.startsWith(PROPERTY_DELIMITER)
                && value.endsWith(PROPERTY_DELIMITER))
        {
            final String propertyName = value.replace(PROPERTY_DELIMITER, "");

            try
            {
                this.value = FIXConfig.getNamedProperty(propertyName);
            }
            catch (final IOException e)
            {
                throw new IllegalStateException("Attempt to use undefined property: "
                        + propertyName);
            }
        }
        // otherwise just use the value
        else
        {
            this.value = value;
        }
    }

    /**
     * @return the field id
     */
    public String getId()
    {
        return this.id;
    }

    /**
     * @return the field value
     */
    public String getValue()
    {
        return this.value;
    }
}
