package com.anz.axle.adapters.ndf2trep.config;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.anz.axle.adapters.ndf2trep.enrichment.margin.MarginService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;

@Configuration
@PropertySource("classpath:conf/ndf2trep-margin-test.properties")
public class MarginTestConfig {

    @Bean
    public RicRepository ricRepository(@Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<String>> symbolVenuesFXSPOT,
                                       @Value("#{${venue.symbol.tenors.FXNDF}}") final Map<String, Map<String, Set<String>>> venueSymbolTenorsFXNDF,
                                       @Value("#{${venue.subscription.sourceId}}") final Map<String, String> venueSubscriptionSourceId,
                                       @Value("#{${venue.publish.sourceId}}") final Map<String, String> venuePublishSourceId,
                                       @Value("#{${venue.publish.serviceName}}") final Map<String, String> venuePublishServiceNames,
                                       @Value("${ndf.trep.publish.destination.servicename}") final String serviceName) {
        return new RicRepository(symbolVenuesFXSPOT, venueSymbolTenorsFXNDF, venueSubscriptionSourceId, venuePublishSourceId, venuePublishServiceNames, serviceName);
    }

    @Bean
    public MarginService marginService(@Value("#{${symbol.serviceName.margins.FXSPOT}}") final Map<String, Map<String, List<String>>> marginMap,
                                       @Value("#{${symbol.pips}}") final Map<String, Long> symbolPipsMap,
                                       final RicRepository ricRepository) {
        return new MarginService(marginMap, symbolPipsMap, ricRepository);
    }

}
