package com.anz.axle.adapters.ndf2trep.publisher;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.anz.axle.adapters.ndf2trep.enrichment.margin.MarginService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.anz.axle.trep.publisher.TrepStreamableQueue;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import static com.anz.axle.adapters.ndf2trep.publisher.TrepAsserter.assertEqualTrepQuote;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class TrepTopOfBookSnapshotFullRefreshHandlerTest {

    private static final String SERVICE_NAME = "AXLE_DEV";
    private static final String SYMBOL = "USDCNY";
    private static final Venue MARKET = Venue.EBS;
    private static final boolean HAVE_FLAGS = true;
    private static final SecurityType SEC_TYPE = SecurityType.FXNDF;

    private RicRepository ricRepository;
    private MarginService marginService;
    private TrepTopOfBookSnapshotFullRefreshHandler handler;

    private TrepStreamableQueue mockTrepStreamableQueue;
    private SnapshotFullRefreshHandler.Body mockMessageHandlerBody;
    private StringDecoder mockStringDecoder, mockStringDecoder2;

    @Before
    public void beforeEach() {

        final Map<String, Map<String, Set<String>>> instrumentRics = new HashMap<>();
        instrumentRics.put("EBS", new HashMap<>());
        instrumentRics.get("EBS").put("USDCNS", new HashSet<>());
        instrumentRics.get("EBS").get("USDCNS").add("M1:CNS1M");
        instrumentRics.get("EBS").get("USDCNS").add("M3:CNS3M");
        instrumentRics.get("EBS").get("USDCNS").add("M6:CNS6M");
        instrumentRics.get("EBS").get("USDCNS").add("Y1:CNS12M");

        instrumentRics.get("EBS").put("USDCNY", new HashSet<>());
        instrumentRics.get("EBS").get("USDCNY").add("M1:CN11M");
        instrumentRics.get("EBS").get("USDCNY").add("M3:CN13M");
        instrumentRics.get("EBS").get("USDCNY").add("M6:CN16M");
        instrumentRics.get("EBS").get("USDCNY").add("Y1:CN112M");

        final Map<String, String> publishSourceId = new HashMap<>();
        publishSourceId.put("EBS", SERVICE_NAME);

        final Map<String, String> venueServiceNameMap = new HashMap<>();
        venueServiceNameMap.put("EBS", SERVICE_NAME);

        final Map<String, String> venuePublishSourceId = new HashMap<>();
        venuePublishSourceId.put("EBS", SERVICE_NAME);

        ricRepository = new RicRepository(new HashMap<>(),
                instrumentRics,
                new HashMap<>(),
                venuePublishSourceId,
                venueServiceNameMap,
                SERVICE_NAME);


        mockTrepStreamableQueue = mock(TrepStreamableQueue.class);
        mockMessageHandlerBody = mock(SnapshotFullRefreshHandler.Body.class);
        mockStringDecoder = mock(StringDecoder.class);

        marginService = new MarginService(new HashMap<>(), new HashMap<>(), ricRepository);

        handler = new TrepTopOfBookSnapshotFullRefreshHandler(mockTrepStreamableQueue, ricRepository, marginService);
    }

    @Test
    public void testBidQuotePushedOnTrepStreamableQueueOnMessageComplete() {

        assertTrepQuoteEnqueuedOnTrepStream(1, Tenor.M1,
                expectedTrepQuote(TrepQuote.QuoteType.EXECUTABLE,"CN11M=AXLE_DEV", 0.79, Double.NaN, 30L),
                createEntryBodyMock(EntryType.BID, 30L, 0.79));
    }

    @Test
    public void testBidAndOfferQuotePushedOnTrepStreamableQueueOnMessageComplete() {

        assertTrepQuoteEnqueuedOnTrepStream(1, Tenor.M3,
                expectedTrepQuote(TrepQuote.QuoteType.EXECUTABLE,"CN13M=AXLE_DEV",0.79, 0.78, 30L),
                createEntryBodyMock(EntryType.BID, 30L, 0.79),
                createEntryBodyMock(EntryType.OFFER, 30L, 0.78));
    }

    @Test
    public void testSendEmptyQuoteWhenHaveFlags() {
        assertTrepQuoteEnqueuedOnTrepStream(HAVE_FLAGS, 1, Tenor.Y1,
                expectedTrepQuote(TrepQuote.QuoteType.INDICATIVE,"CN112M=AXLE_DEV", 0.79, 0.75, 20L), // prices are now published,  but with the indicative set to true.
                createEntryBodyMock(EntryType.BID, 30L, 0.79),
                createEntryBodyMock(EntryType.OFFER, 30L, 0.75));
    }

    @Test
    public void testSkippingUnsubscribedTenors() throws Exception {

        final Tenor unSubscriptedTenor = Tenor.BOM2;

        createMessageHandlerBodyMock(unSubscriptedTenor, false);
        handler.onMessageStart(0, 0);
        handler.onBody(mockMessageHandlerBody);
        handler.onMdEntries_Body(createEntryBodyMock(EntryType.BID, 30L, 0.79),0,0);
        handler.onMessageComplete();

        ArgumentCaptor<TrepQuote> queueTrepQuote = ArgumentCaptor.forClass(TrepQuote.class);
        verify(mockTrepStreamableQueue, never()).enqueueItem(queueTrepQuote.capture());
    }


    private void assertTrepQuoteEnqueuedOnTrepStream(int quoteCount, Tenor tenor, TrepQuote expected, SnapshotFullRefreshHandler.MdEntries.Body... entries) {
        assertTrepQuoteEnqueuedOnTrepStream(!HAVE_FLAGS, quoteCount, tenor, expected, entries);
    }

    private void assertTrepQuoteEnqueuedOnTrepStream(boolean haveFlags, int quoteCount, Tenor tenor, TrepQuote expected, SnapshotFullRefreshHandler.MdEntries.Body... entries) {

        createMessageHandlerBodyMock(tenor, haveFlags);
        handler.onMessageStart(0, 0);
        handler.onBody(mockMessageHandlerBody);

        for (SnapshotFullRefreshHandler.MdEntries.Body entry: entries) {
            handler.onMdEntries_Body(entry, 0,0);
        }

        handler.onMessageComplete();

        ArgumentCaptor<TrepQuote> queueTrepQuote = ArgumentCaptor.forClass(TrepQuote.class);
        verify(mockTrepStreamableQueue, times(quoteCount)).enqueueItem(queueTrepQuote.capture());

        assertEqualTrepQuote(queueTrepQuote.getValue(), expected);
    }

    private TrepQuote expectedTrepQuote(final TrepQuote.QuoteType quoteType, final String ricName, final double bid, final double ask, final long tiggerTime) {
        return TrepQuote.createUpdateQuote(quoteType, SERVICE_NAME, ricName, bid, ask, tiggerTime);
    }

    private void createMessageHandlerBodyMock(final Tenor tenor, final boolean haveFlags) {
        mockMessageHandlerBody = mock(SnapshotFullRefreshHandler.Body.class);
        final long instrumentId = InstrumentKey.instrumentId(SYMBOL, SEC_TYPE, tenor);
        when(mockMessageHandlerBody.instrumentId()).thenReturn(instrumentId);
        when(mockMessageHandlerBody.marketId()).thenReturn(MARKET);

        EnumerableSetDecoder setDecoder = mock(EnumerableSetDecoder.class);
        when(setDecoder.containsAny()).thenReturn(haveFlags);
        when(mockMessageHandlerBody.mdFlags()).thenReturn(setDecoder);
    }

    private SnapshotFullRefreshHandler.MdEntries.Body createEntryBodyMock(final EntryType entryType, final long transactTime, final double price) {

        EnumerableSetDecoder setDecoder = mock(EnumerableSetDecoder.class);
        when(setDecoder.containsAny()).thenReturn(false);
        when(mockMessageHandlerBody.mdFlags()).thenReturn(setDecoder);

        final SnapshotFullRefreshHandler.MdEntries.Body mockBody = mock(SnapshotFullRefreshHandler.MdEntries.Body.class);
        when(mockBody.mdEntryType()).thenReturn(entryType);
        when(mockBody.transactTime()).thenReturn(transactTime);
        when(mockBody.mdEntryPx()).thenReturn(price);
        when(mockBody.mdEntryFlags()).thenReturn(setDecoder);

        return mockBody;
    }
}