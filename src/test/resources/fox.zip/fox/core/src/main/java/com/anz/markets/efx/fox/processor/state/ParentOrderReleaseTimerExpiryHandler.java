package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;

public class ParentOrderReleaseTimerExpiryHandler implements TimerScheduler.ExpiryHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParentOrderReleaseTimerExpiryHandler.class);

    private final ParentOrder order;

    public ParentOrderReleaseTimerExpiryHandler(final ParentOrder order) {
        this.order = Objects.requireNonNull(order);
    }

    @Override
    public TimerGroup timerGroup() {
        return TimerGroup.PARENT_ORDER_RELEASE;
    }

    @Override
    public boolean onExpiryEvent(final long timerId, final long triggeredTime) {
        LOGGER.info("Releasing order {}", order.details().orderId());
        order.release();
        return true;
    }
}
