package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumSetEncoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.SimpleStringEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoVenueConfigEncoder implements VenueConfigEncoder, VenueConfigEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;
    private final EnumerableSetEncoder<Body, VenueCategory> venueCategories;
    private final StringEncoder<Body> compId;


    private VenueConfig message = SorMessage.venueConfig();

    public PojoVenueConfigEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
        this.venueCategories = new EnumSetEncoder<>(this, VenueCategory::length, VenueCategory::valueByOrdinal, f -> message.body.venueCategories.add(f), () -> message.body.venueCategories.clear());
        this.compId = new SimpleStringEncoder<>(this, s -> message.body.compId = s);

    }

    public VenueConfig message() {
        return message;
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        message = SorMessage.venueConfig();
        return this;
    }


    @Override
    public Body venue(final Venue venue) {
        message.body.venue = venue;
        return this;
    }

    @Override
    public StringEncoder<Body> compId() {
        return compId;
    }

    @Override
    public EnumerableSetEncoder<VenueConfigEncoder.Body, VenueCategory> venueCategories() {
        return venueCategories;
    }

    @Override
    public Trailer enabled(final boolean enabled) {
        message.body.enabled = enabled;
        return this;
    }

    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
