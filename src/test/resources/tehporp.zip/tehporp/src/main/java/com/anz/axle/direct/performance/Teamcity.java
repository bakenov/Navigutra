package com.anz.axle.direct.performance;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.apache.commons.lang3.tuple.Pair;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class Teamcity {
    private static final DateTimeFormatter TEAMCITY_TIMESTAMP = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    public static final class MessageBuilder {
        private static final Pattern IDENTIFIER = Pattern.compile("[a-z][A-Za-z0-9_]*");
        private final String name;
        private final List<Pair<String, String>> properties = new ArrayList<>();
        private final Pattern SIMPLE_ESCAPES = Pattern.compile("('|\\||\\[|\\])");
        private String value;

        public MessageBuilder(final String name) {
            this.name = name;
        }

        public MessageBuilder prop(final String name,
                                   final String value) {
            GcFriendlyAssert.isTrue(IDENTIFIER.matcher(name).matches(), "Property name '" + name + "' should match '" + IDENTIFIER + "'");
            properties.add(Pair.of(name, escape(value)));
            return this;
        }

        public MessageBuilder value(final String value) {
            this.value = value;
            return this;
        }

        private String escape(final String value) {
            return SIMPLE_ESCAPES.matcher(value).replaceAll("|$1").replaceAll("\n", "|n").replaceAll("\r", "|r");
        }

        public String format() {
            final StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("##teamcity[").append(name);
            for (final Pair<String, String> prop : properties) {
                stringBuilder.append(String.format(" %s='%s'", prop.getLeft(), prop.getRight()));
            }
            if (value != null) {
                stringBuilder.append(" ").append('\'').append(value).append('\'');
            }
            stringBuilder.append("]");
            return stringBuilder.toString();
        }

        @Override
        public String toString() {
            return format();
        }
    }

    public static MessageBuilder message(final String name) {
        return new MessageBuilder(name).prop("timestamp", TEAMCITY_TIMESTAMP.print(System.currentTimeMillis()));
    }

    public static MessageBuilder progress(final String text) {
        return new MessageBuilder("progressMessage").value(text);
    }

    public static MessageBuilder logNormal(final String text) {
        return message("message").prop("text", text).prop("status", Status.NORMAL.name());
    }

    public static MessageBuilder logWarning(final String text) {
        return message("message").prop("text", text).prop("status", Status.WARNING.name());
    }

    public static MessageBuilder logFailure(final String text) {
        return message("message").prop("text", text).prop("status", Status.FAILURE.name());
    }

    public static MessageBuilder logError(final String text, final String errorDetails) {
        return message("message").prop("text", text).prop("status", Status.FAILURE.name()).prop("errorDetails", errorDetails);
    }

    public enum Status {
        NORMAL, WARNING, FAILURE, ERROR
    }
}
