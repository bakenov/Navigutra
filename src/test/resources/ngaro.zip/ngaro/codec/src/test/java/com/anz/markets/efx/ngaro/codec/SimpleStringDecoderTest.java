package com.anz.markets.efx.ngaro.codec;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Unit test for {@link SimpleStringDecoder}
 */
public class SimpleStringDecoderTest {

    @Test(expected = NullPointerException.class)
    public void noNullSupplier() {
        SimpleStringDecoder.forSupplier(null);
    }

    @Test
    public void decodeEmpty() throws Exception {
        final SimpleStringDecoder dec = SimpleStringDecoder.forString(null);

        //when
        final String output1 = dec.decodeStringOrNull();

        //then
        assertNull("output1 should be null", output1);

        //when
        final String output2 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output2 should be empty string", "", output2);
    }

    @Test
    public void decodeStringOrNull() throws Exception {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final String input3 = "";

        //when
        stringHolder.set(input1);
        final String output1 = dec.decodeStringOrNull();

        //then
        assertEquals("output1 should be 123456", "123456", output1);

        //when
        stringHolder.set(input2);
        final String output2 = dec.decodeStringOrNull();

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);

        //when
        stringHolder.set(input3);
        final String output3 = dec.decodeStringOrNull();

        //then
        assertEquals("output2 should be null", null, output3);
    }

    @Test
    public void decodeStringOrNullViaCache() throws Exception {
        //given
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);

        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final String input = "123456";

        //when
        stringHolder.set(input);
        final String output = dec.decodeAndCache(cache);

        //then
        assertEquals("output should be equal to input", input, output);
        assertNotSame("output should be same as reference to input", input, output);

        //when
        final String second = dec.decodeAndCache(cache);

        //then
        assertSame("second should be the same reference as output", output, second);
    }

    @Test
    public void decodeStringOrNullViaCache_whenEmpty() throws Exception {
        //given
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);

        final AtomicReference<String> stringHolder = new AtomicReference<>("");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);

        //when
        final String output = dec.decodeAndCache(cache);

        //then
        assertEquals("output should be null", null, output);
    }

    @Test
    public void decodeStringOrEmpty() throws Exception {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final String input3 = "";

        //when
        stringHolder.set(input1);
        final String output1 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output1 should be 123456", "123456", output1);

        //when
        stringHolder.set(input2);
        final String output2 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);

        //when
        stringHolder.set(input3);
        final String output3 = dec.decodeStringOrEmpty();

        //then
        assertEquals("output2 should be empty string", "", output3);
    }

    @Test
    public void decodeTransformed() throws Exception {
        //given
        final Function<StringDecoder, SimpleStringEncoderTest.Color> transformNullable = EnumTransforms.toEnumOrNull(SimpleStringEncoderTest.Color.class);
        final Function<StringDecoder, SimpleStringEncoderTest.Color> transformThrows = EnumTransforms.toEnumOrException(SimpleStringEncoderTest.Color.class);
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);

        for (final SimpleStringEncoderTest.Color color : SimpleStringEncoderTest.Color.values()) {
            //given
            stringHolder.set(color.name());

            //when
            final SimpleStringEncoderTest.Color outputA = dec.decodeAndTransform(transformNullable);

            //then
            assertEquals("outputA should be " + color, color, outputA);

            //when
            final SimpleStringEncoderTest.Color outputB = dec.decodeAndTransform(transformThrows);

            //then
            assertEquals("outputB should be " + color, color, outputB);
        }

        //SPECIAL: null values

        //given
        stringHolder.set(null);

        //when
        final SimpleStringEncoderTest.Color output1 = dec.decodeAndTransform(transformNullable);

        //then
        assertEquals("output1 should be " + null, null, output1);

        //when
        final SimpleStringEncoderTest.Color output2 = dec.decodeAndTransform(transformThrows);

        //then
        assertEquals("output2 should be " + null, null, output2);

        //SPECIAL: empty string values

        //given
        stringHolder.set("");

        //when
        final SimpleStringEncoderTest.Color output3 = dec.decodeAndTransform(transformNullable);

        //then
        assertEquals("output3 should be " + null, null, output3);

        //when
        final SimpleStringEncoderTest.Color output4 = dec.decodeAndTransform(transformThrows);

        //then
        assertEquals("output4 should be " + null, null, output4);

        //SPECIAL: invalid values

        //given
        //let's be mean --- this starts with a valid constant name!
        final String badValue = SimpleStringEncoderTest.Color.YELLOW + "blablablaGRRRRRR";
        stringHolder.set(badValue);

        //when
        final SimpleStringEncoderTest.Color output5 = dec.decodeAndTransform(transformNullable);

        //then
        assertEquals("output5 should be " + null, null, output5);

        try {
            //when
            final SimpleStringEncoderTest.Color output6 = dec.decodeAndTransform(transformThrows);

            //then: expecte exception
            fail("Expected an exception for invalid values but received: " + output6);
        } catch (final IllegalArgumentException e) {
            //then
            final String badValuePrefix = badValue.substring(0, SimpleStringEncoderTest.Color.YELLOW.name().length() + 1);
            assertTrue("exception message " + e.getMessage() + " should contain bad value prefix: " + badValue, e.getMessage().contains(badValuePrefix));
        }
    }

    @Test
    public void decodeToAppendable() throws Exception {
        //given
        final int len = 6;
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final StringBuilder output = new StringBuilder();

        //when
        stringHolder.set(input1);
        final Appendable a1 = dec.decodeTo(output, len);

        //then
        assertEquals("output should end with 123456", input1, output.toString());
        assertSame("returned appendable should be same as the target", output, a1);

        //when
        stringHolder.set(input2);
        final Appendable a2 = dec.decodeTo(output, len);

        //then
        assertEquals("output should end with XYZ", "123456XYZ", output.toString());
        assertSame("returned appendable should be same as the target", output, a2);

        //when
        stringHolder.set(input1);
        final Appendable a3 = dec.decodeTo(output, 3);

        //then
        assertEquals("output should end with 123", "123456XYZ123", output.toString());
        assertSame("returned appendable should be same as the target", output, a3);

        //when
        stringHolder.set(null);
        final Appendable a4 = dec.decodeTo(output, len);

        //then
        assertEquals("output should not have changed", "123456XYZ123", output.toString());
        assertSame("returned appendable should be same as the target", output, a4);
    }

    @Test(expected = RuntimeException.class)
    public void decodeToAppendable_throwsException() throws Exception {
        //given
        final int len = 6;
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final Appendable output = new Appendable() {
            @Override
            public Appendable append(final CharSequence csq) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final char c) throws IOException {
                throw new IOException("Test appendable exception");
            }
        };

        //when
        dec.decodeTo(output, len);

        //then: expect exception
    }

    @Test
    public void decodeToByteWriter() throws Exception {
        //given
        final int len = 6;
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final String input1 = "123456";
        final String input2 = "XYZ";
        final StringBuilder output = new StringBuilder("pqrstuvwxyz");
        int tgtOffset = 0;

        //when
        stringHolder.set(input1);
        final int len1 = dec.decodeTo(output, ByteWriter.STRING_BUILDER);

        //then
        assertEquals("output should contain 123456 at " + tgtOffset, "123456vwxyz", output.toString());
        assertEquals("len1 should be " + len, len, len1);

        //when
        tgtOffset = 0;
        stringHolder.set(input2);
        final int len2 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, len);

        //then
        assertEquals("output should contain XYZ at " + tgtOffset, "XYZ456vwxyz", output.toString());
        assertEquals("len2 should be 3", 3, len2);

        //when
        tgtOffset = 1;
        stringHolder.set(input1);
        final int len3 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, 3);

        //then
        assertEquals("output should contain 123 at " + tgtOffset, "X12356vwxyz", output.toString());
        assertEquals("len3 should be 3", 3, len3);

        //when
        tgtOffset = 0;
        stringHolder.set(null);
        final int len4 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, len);

        //then
        assertEquals("output should not have changed", "X12356vwxyz", output.toString());
        assertEquals("len4 should be 0", 0, len4);
    }
    @Test
    public void decodeToNull() throws Exception {
        //given
        final int len = 6;
        final AtomicReference<String> stringHolder = new AtomicReference<>("blablabla");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);
        final String input1 = "123456";
        final String input2 = "XYZ";

        //when
        stringHolder.set(input1);
        final int len1 = dec.decodeToNull();

        //then
        assertEquals("len1 not as expected", len, input1.length(), len1);

        //when
        stringHolder.set(input2);
        final int len2 = dec.decodeToNull();

        //then
        assertEquals("len2 not as expected", input2.length(), len2);

        //when
        stringHolder.set(null);
        final int len3 = dec.decodeToNull();

        //then
        assertEquals("len3 should be 0", 0, len3);
    }

    @Test
    public void decodeLong() {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>("4567467575645");
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);

        //when + then
        assertEquals(dec.decodeLongOrZero(), 4567467575645L);
    }

    @Test
    public void decodeLongFromNullString() {
        //given
        final AtomicReference<String> stringHolder = new AtomicReference<>(null);
        final SimpleStringDecoder dec = SimpleStringDecoder.forSupplier(stringHolder::get);

        //when + then
        assertEquals(dec.decodeLongOrZero(), 0);
    }

}