#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-spdee-order-reject-freq - Plugin to monitor the SPDEE Order Frequency (All)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title SPDEE Order Frequency'
    echo 'graph_category spdee'
    echo 'graph_scale no'

    echo 'freqReject360t.label Order Rejected Frequency (360T)'
    echo 'freqReject360t.draw STACK'
    echo 'freqReject360tRFS.label Order Rejected Frequency (360T_RFS)'
    echo 'freqReject360tRFS.draw STACK'
    echo 'freqRejectFxall.label Order Rejected Frequency (FXAll)'
    echo 'freqRejectFxall.draw STACK'
    echo 'freqRejectFxallRFS.label Order Rejected Frequency (FXAll_RFS)'
    echo 'freqRejectFxallRFS.draw STACK'
    echo 'freqRejectBloomberg.label Order Rejected Frequency (Bloomberg)'
    echo 'freqRejectBloomberg.draw STACK'
    echo 'freqRejectBloombergRFS.label Order Rejected Frequency (Bloomberg_RFS)'
    echo 'freqRejectBloombergRFS.draw STACK'

    echo 'freqFilled360t.label Order Filled Frequency (360T)'
    echo 'freqFilled360t.draw STACK'
    echo 'freqFilled360tRFS.label Order Filled Frequency (360T_RFS)'
    echo 'freqFilled360tRFS.draw STACK'
    echo 'freqFilledFxall.label Order Filled Frequency(FXAll)'
    echo 'freqFilledFxall.draw STACK'
    echo 'freqFilledFxallRFS.label Order Filled Frequency(FXAll_RFS)'
    echo 'freqFilledFxallRFS.draw STACK'
    echo 'freqFilledBloomberg.label Order Filled Frequency(Bloomberg)'
    echo 'freqFilledBloomberg.draw STACK'
    echo 'freqFilledBloombergRFS.label Order Filled Frequency(Bloomberg_RFS)'
    echo 'freqFilledBloombergRFS.draw STACK'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "freqReject360t.value U"
        echo "freqReject360tRFS.value U"
        echo "freqRejectFxall.value U"
        echo "freqRejectFxallRFS.value U"
        echo "freqRejectBloomberg.value U"
        echo "freqRejectBloombergRFS.value U"

        echo "freqFilled360t.value U"
        echo "freqFilled360tRFS.value U"
        echo "freqFilledFxall.value U"
        echo "freqFilledFxallRFS.value U"
        echo "freqFilledBloomberg.value U"
        echo "freqFilledBloombergRFS.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "freqReject360t.value U"
        echo "freqReject360tRFS.value U"
        echo "freqRejectFxall.value U"
        echo "freqRejectFxallRFS.value U"
        echo "freqRejectBloomberg.value U"
        echo "freqRejectBloombergRFS.value U"

        echo "freqFilled360t.value U"
        echo "freqFilled360tRFS.value U"
        echo "freqFilledFxall.value U"
        echo "freqFilledFxallRFS.value U"
        echo "freqFilledBloomberg.value U"
        echo "freqFilledBloombergRFS.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
egrep 'dealing.order.ccm-create-to-ccm-(rejected|filled)-ack-commence,,' $LOGFILE | tail -100 | awk -F, '
BEGIN {
        freqReject360t=0;
        freqReject360tRFS=0;
        freqRejectFxall=0;
        freqRejectFxallRFS=0;
        freqRejectBloomberg=0;
        freqRejectBloombergRFS=0;

        freqFilled360t=0;
        freqFilled360tRFS=0;
        freqFilledFxall=0;
        freqFilledFxallRFS=0;
        freqFilledBloomberg=0;
        freqFilledBloombergRFS=0;
}

/dealing.order.ccm-create-to-ccm-rejected-ack-commence,,fxall,/ {freqRejectFxall=$19}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,fxall,/ {freqFilledFxall=$19}

/dealing.order.ccm-create-to-ccm-rejected-ack-commence,,fxall_rfs,/ {freqRejectFxallRFS=$19}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,fxall_rfs,/ {freqFilledFxallRFS=$19}

/dealing.order.ccm-create-to-ccm-rejected-ack-commence,,360t,/ {freqReject360t=$19}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,360t,/ {freqFilled360t=$19}

/dealing.order.ccm-create-to-ccm-rejected-ack-commence,,360t_rfs,/ {freqReject360tRFS=$19}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,360t_rfs,/ {freqFilled360tRFS=$19}

/dealing.order.ccm-create-to-ccm-rejected-ack-commence,,bloomberg,/ {freqRejectBloomberg=$19}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,bloomberg,/ {freqFilledBloomberg=$19}

/dealing.order.ccm-create-to-ccm-rejected-ack-commence,,bloomberg_rfs,/ {freqRejectBloombergRFS=$19}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,bloomberg_rfs,/ {freqFilledBloombergRFS=$19}

END {
        print "freqRejectFxall.value " freqRejectFxall;
        print "freqRejectFxallRFS.value " freqRejectFxallRFS;
        print "freqReject360t.value " freqReject360t;
        print "freqReject360tRFS.value " freqReject360tRFS;
        print "freqRejectBloomberg.value " freqRejectBloomberg;
        print "freqRejectBloombergRFS.value " freqRejectBloombergRFS;

        print "freqFilledFxall.value " freqFilledFxall;
        print "freqFilledFxallRFS.value " freqFilledFxallRFS;
        print "freqFilled360t.value " freqFilled360t;
        print "freqFilled360tRFS.value " freqFilled360tRFS;
        print "freqFilledBloomberg.value " freqFilledBloomberg;
        print "freqFilledBloombergRFS.value " freqFilledBloombergRFS;
}
'
fi

