package com.anz.markets.efx.fox.api.domain;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.Region;

class DefaultUserSessionKey implements UserSessionKey {
    private final String sessionId;
    private final String userName;
    private final String portfolio;
    private final Region region;

    public DefaultUserSessionKey(final String sessionId, final String userName, final String portfolio, final Region region) {
        this.sessionId = Objects.requireNonNull(sessionId);
        this.userName = Objects.requireNonNull(userName);
        this.portfolio = Objects.requireNonNull(portfolio);
        this.region = Objects.requireNonNull(region);
    }

    @Override
    public String sessionId() {
        return sessionId;
    }

    @Override
    public String userName() {
        return userName;
    }

    @Override
    public String portfolio() {
        return portfolio;
    }

    @Override
    public Region region() {
        return region;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final DefaultUserSessionKey that = (DefaultUserSessionKey) o;

        if (!sessionId.equals(that.sessionId)) return false;
        if (!userName.equals(that.userName)) return false;
        if (!portfolio.equals(that.portfolio)) return false;
        return region == that.region;
    }

    @Override
    public int hashCode() {
        int result = sessionId.hashCode();
        result = 31 * result + userName.hashCode();
        result = 31 * result + portfolio.hashCode();
        result = 31 * result + region.hashCode();
        return result;
    }
}
