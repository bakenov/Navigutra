package com.anz.markets.efx.fox.firewall.metric;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.firewall.api.Metric;
import com.anz.markets.efx.fox.firewall.state.SlidingTimeWindowMeter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class OrderUsdQuantityThroughputMetric implements Metric {
    private final SlidingTimeWindowMeter slidingTimeWindowMeter;
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);
    private final InstrumentRepository instrumentRepository;


    public OrderUsdQuantityThroughputMetric(final InstrumentRepository instrumentRepository, final long periodMillis) {
        this.instrumentRepository = Objects.requireNonNull(instrumentRepository);
        slidingTimeWindowMeter = new SlidingTimeWindowMeter(periodMillis, TimeUnit.MILLISECONDS);
    }

    @Override
    public void accept(final ExecutionReportDecoder executionReport, final long currentTimeNanos) {
        final ExecutionReportDecoder.Body body = executionReport.body();
        if (body.lastUsdQty() > 0) {
            slidingTimeWindowMeter.add(currentTimeNanos, (long) body.lastUsdQty());
        }
    }

    @Override
    public void accept(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        //no op
    }

    @Override
    public double currentValue(final long timeNanos) {
        return slidingTimeWindowMeter.get(timeNanos);
    }

    @Override
    public double nextValue(final NewOrderSingleDecoder newOrderSingle, final long currentTimeNanos) {
        final NewOrderSingleDecoder.Body body = newOrderSingle.body();
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        final SecurityType securityType = body.securityType();
        final Tenor tenor = body.settlType();
        final long instrumentId = InstrumentKey.instrumentId(symbol, securityType, tenor);
        final Instrument instrument = instrumentRepository.lookup(instrumentId);
        if (instrument == null) {
            return Double.NaN;
        }
        final double usdValue = instrument.usdValue(body.orderQty());
        if (Double.isNaN(usdValue)) {
            return Double.NaN;
        }
        return slidingTimeWindowMeter.get(currentTimeNanos) + usdValue ;
    }
}
