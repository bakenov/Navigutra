package com.anz.markets.efx.ngaro.codec;

import java.io.IOException;
import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.core.ImmutableAsciiString;
import com.anz.markets.efx.ngaro.core.LongCodec;

/**
 * String decoder backed by a supplier of {@link AsciiString}.
 */
public final class AsciiStringDecoder implements StringDecoder {

    private final Supplier<? extends AsciiString> asciiStringSupplier;

    public AsciiStringDecoder(final Supplier<? extends AsciiString> asciiStringSupplier) {
        this.asciiStringSupplier = Objects.requireNonNull(asciiStringSupplier);
    }

    public static AsciiStringDecoder forSupplier(final Supplier<? extends AsciiString> asciiStringSupplier) {
        return new AsciiStringDecoder(asciiStringSupplier);
    }

    public static AsciiStringDecoder forAsciiString(final AsciiString asciiString) {
        Objects.requireNonNull(asciiString);
        return forSupplier(() -> asciiString);
    }

    public static AsciiStringDecoder forString(final String s) {
        return forCharSequence(s);
    }

    public static AsciiStringDecoder forCharSequence(final CharSequence s) {
        return forAsciiString(new ImmutableAsciiString(s));
    }

    public AsciiString asciiString() {
        return asciiStringSupplier.get();
    }

    @Override
    public int decodeToNull() {
        return asciiString().length();
    }

    @Garbage(Garbage.Type.RESULT)
    @Override
    public String decodeStringOrNull() {
        return asciiString().toStringOrNull();
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only possible if caching of a value causes eviction of another value due to a full cache")
    @Override
    public <T> T decodeAndCache(final ByteValueCache<T> cache) {
        final AsciiString asciiString = asciiString();
        return asciiString.isEmpty() ? null : cache.lookupOrCache(asciiString);
    }

    @Override
    public <A extends Appendable> A decodeTo(final A target, final int maxTargetLength) {
        final AsciiString asciiString = asciiString();
        final int minLen = Math.min(asciiString.length(), maxTargetLength);
        for (int i = 0; i < minLen; i++) {
            try {
                target.append(asciiString.charAt(i));
            } catch (final IOException e) {
                throw new RuntimeException("append failed, e=" + e, e);
            }
        }
        return target;
    }

    @Override
    public <T> int decodeTo(final T target, final ByteWriter<? super T> writer, final int targetOffset, final int maxTargetLength) {
        return asciiString().get(target, writer, targetOffset, maxTargetLength);
    }

    @Override
    public long decodeLong(final long defaultValue) {
        if (asciiString().isEmpty()) {
            return defaultValue;
        }
        return LongCodec.decodeSigned(asciiString());
    }
}
