#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa012z "rm -rf ~/axle/datafabric/workspace/*"
