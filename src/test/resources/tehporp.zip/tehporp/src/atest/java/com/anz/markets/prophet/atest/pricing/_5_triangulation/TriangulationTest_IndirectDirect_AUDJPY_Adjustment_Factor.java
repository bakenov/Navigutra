package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.impl.TestDataDictionaryImpl;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.efx.ngaro.math.Epsilon;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.core.Is.is;

@Requirement(value = {Ref.PRICING_4_6, Ref.PRICING_4_6_9})
public class TriangulationTest_IndirectDirect_AUDJPY_Adjustment_Factor extends BaseAcceptanceSpecification {

    final Instrument driverPairA = Instrument.AUDUSD;
    final Instrument driverPairB = Instrument.USDJPY;
    final Instrument crossPair = Instrument.AUDJPY;

    private ConfigurationDataDefault configWithSyntheticWideningFactor(double adjustmentFactor) {
        ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                .setClientSpreadConfigs(Lists.newArrayList(
                        // spread config for driver pairs
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_B, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.SNG, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.SNG, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.SNG, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.SNG, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.SNG, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.SNG, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.SNG, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.SNG, 7.0)
                ))
                .setSyntheticInstrumentConfigs(Arrays.asList(
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDJPY).setMarkets(Market.WSP_A.toString()),
                        new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDJPY).setMarkets(Market.WSP_B.toString())
                ))
                .setSyntheticWideningFactors(Arrays.asList(
                        TestDataDictionaryImpl.getDefaultWideningFactorOverride(Currency.AUD, Currency.JPY, Market.WSP_A, adjustmentFactor, TradingTimeZone.LDN)
                ))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

        return configurationDataDefault;
    }

    @Test
    @Requirement(value = {Ref.PRICING_AXPROPHET_1134})
    @DisplayName("Triangulation of cross pair with NARROWING from INDIRECT-DIRECT driver pairs")
    public void given_indirect_direct_driver_pairs_triangulate_cross_pair_narrowed() throws Exception {
        given:
        {
            prophet.receive(configWithSyntheticWideningFactor(0.5)
                    .setSyntheticInstrumentConfigs(Arrays.asList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDJPY).setMarkets(Market.ANY.toString())
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            TestDataDictionaryImpl.getDefaultWideningFactorOverride(Currency.AUD, Currency.JPY, Market.WSP_A, 0.5, TradingTimeZone.LDN),
                            TestDataDictionaryImpl.getDefaultWideningFactorOverride(Currency.AUD, Currency.JPY, Market.ANY, 1.5, TradingTimeZone.LDN)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice.getUnskewedMid(), isRoundedTo(0.75005));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7500350, 0.750065));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7500200, 0.750080));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7500125, 0.750088));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7500000, 0.750100));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7499200, 0.750180));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7498600, 0.750240));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7497700, 0.750330));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7497300, 0.750370));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7496000, 0.750500));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 101.005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice.getUnskewedMid(), isRoundedTo(101.005));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 101.003500, 101.006500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 101.002000, 101.008000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 101.001250, 101.008750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 101.000000, 101.010000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 100.993500, 101.016500));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 100.988500, 101.021500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 100.970500, 101.039500));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 100.957500, 101.052500));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 100.930000, 101.080000));
        }
        and:
        {
            ClientPrice clientPriceWspA = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            double wspATobSpread = clientPriceWspA.getTopOfBookOffer().getPrice() - clientPriceWspA.getTopOfBookBid().getPrice();
            assertThat(clientPriceWspA.getBids().size(), is(9));
            assertThat(clientPriceWspA, isClientPricePoint(0, Level.QTY_1M, 75.75748019, 75.7601203));
            assertThat(clientPriceWspA, isClientPricePoint(1, Level.QTY_2M, 75.75625388, 75.7613467));
            assertThat(clientPriceWspA, isClientPricePoint(2, Level.QTY_2M, 75.75564074, 75.7619599));
            assertThat(clientPriceWspA, isClientPricePoint(3, Level.QTY_5M, 75.75455636, 75.7630444));
            assertThat(clientPriceWspA, isClientPricePoint(4, Level.QTY_5M, 75.74954782, 75.7680547));
            assertThat(clientPriceWspA, isClientPricePoint(5, Level.QTY_5M, 75.74489308, 75.7727111));
            assertThat(clientPriceWspA, isClientPricePoint(6, Level.QTY_10M, 75.73622717, 75.7813868));
            assertThat(clientPriceWspA, isClientPricePoint(7, Level.QTY_10M, 75.72970661, 75.7879114));
            assertThat(clientPriceWspA, isClientPricePoint(8, Level.QTY_10M, 75.71827503, 75.7993508));

            // since no widening factor is configured for WSP_B, use WSP_ANY configured value(which is 3 * WSP_A's factor)
            ClientPrice clientPriceWspB = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, Market.WSP_B)).getFirst();
            assertThat(clientPriceWspB.getSpread(), is(closeTo(wspATobSpread * 3.0, Epsilon.EPS_1eNegative8.getValue())));
        }
    }

    @Test
    @DisplayName("Triangulation of cross pair with WIDENING from INDIRECT-DIRECT driver pairs")
    public void given_indirect_direct_driver_pairs_triangulate_cross_pair_widen() throws Exception {

        given:
        {
            prophet.receive(configWithSyntheticWideningFactor(1.5));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7500350, 0.750065));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.7500200, 0.750080));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.7500125, 0.750088));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.7500000, 0.750100));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7499200, 0.750180));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7498600, 0.750240));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7497700, 0.750330));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7497300, 0.750370));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7496000, 0.750500));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 101.005, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 101.003500, 101.006500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 101.002000, 101.008000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 101.001250, 101.008750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 101.000000, 101.010000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 100.993500, 101.016500));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 100.988500, 101.021500));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 100.970500, 101.039500));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 100.957500, 101.052500));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 100.930000, 101.080000));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 75.75484006, 75.7627605));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 75.75116115, 75.7664397));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 75.74932173, 75.7682793));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 75.74606859, 75.7715328));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 75.73104296, 75.7865636));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 75.71707874, 75.8005328));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 75.69108100, 75.8265600));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 75.67151932, 75.8461338));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 75.637224575, 75.88045175));
        }
    }

    @Test
    public void apply_correct_adjustment_factor_based_on_timezone() throws Exception {
        given:
        {
            // Set timezone as LDN
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configWithSyntheticWideningFactor(1.5));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00001));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 101.005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 75.75484006, 75.7627605));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 75.75116115, 75.7664397));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 75.74932173, 75.7682793));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 75.74606859, 75.7715328));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 75.73104296, 75.7865636));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 75.71707874, 75.8005328));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 75.69108100, 75.8265600));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 75.67151932, 75.8461338));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 75.637224575, 75.88045175));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75010, 0.00001));
            prophet.clearOutputBuffer();

            // Set timezone as SNG (default widening factor 0.5)
            prophet.receive(TradingTimeZone.SNG);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 75.75748019, 75.7601203));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 75.75625388, 75.7613467));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 75.75564074, 75.7619599));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 75.75455636, 75.7630444));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 75.74954782, 75.7680547));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 75.74489308, 75.7727111));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 75.73622717, 75.7813868));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 75.72970661, 75.7879114));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 75.71827503, 75.7993508));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75010, 0.00001));
            prophet.clearOutputBuffer();

            // Set timezone as LDN (widening factor 1.5)
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.75005, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(crossPair, Market.WSP_A)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 75.75484006, 75.7627605));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 75.75116115, 75.7664397));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 75.74932173, 75.7682793));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 75.74606859, 75.7715328));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 75.73104296, 75.7865636));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 75.71707874, 75.8005328));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 75.69108100, 75.8265600));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 75.67151932, 75.8461338));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 75.637224575, 75.88045175));
        }
    }
}
