package com.anz.axle.lg.adapter.ebsu;

import software.chronicle.ebs.itch.generated.preview.fields.SecurityType;
import software.chronicle.ebs.itch.generated.preview.fields.TenorType;
import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;

// filter out non-M1 tenor NDFs TODO: translate and publish
public class TenorFilter {
    public static boolean canPublish(final InstrumentDirectory securityDefinition) {
        return (securityDefinition.securityType() != SecurityType.FX_NDF) ||
               (securityDefinition.tenorType() == TenorType.MONTHS && securityDefinition.tenorValue() == 1);
    }
}
