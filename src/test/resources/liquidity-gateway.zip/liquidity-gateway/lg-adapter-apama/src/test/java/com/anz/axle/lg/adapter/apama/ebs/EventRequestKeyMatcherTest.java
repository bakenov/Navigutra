package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Optional;
import java.util.function.Function;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.event.Event;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EventRequestKeyMatcherTest {
    @Mock
    private Function<Event, Tenor> eventToTenor;
    @Mock
    private Function<Event, String> eventToSymbol;
    @Mock
    private Function<Event, SecurityType> eventToSecurityType;
    @Mock
    private Event event;

    //under test
    private EventRequestKeyMatcher eventRequestKeyMatcher;

    @Before
    public void setUp() throws Exception {
        eventRequestKeyMatcher = new EventRequestKeyMatcher(eventToSymbol, eventToSecurityType, eventToTenor);
    }

    @Test
    public void test_when_NDF() throws Exception {
        //given
        final String symbol = "USDTWS";
        final SecurityType securityType = SecurityType.FXNDF;
        final Tenor tenor = Tenor.EOM1;

        final RequestKey requestKey = RequestKey.of(Venue.EBS, InstrumentKey.of(symbol, securityType, tenor));

        when(eventToSymbol.apply(event)).thenReturn(symbol);
        when(eventToSecurityType.apply(event)).thenReturn(securityType);
        when(eventToTenor.apply(event)).thenReturn(tenor);

        //when + then
        assertThat(eventRequestKeyMatcher.test(requestKey, event)).isTrue();
    }

    @Test
    public void test_when_SPOT() throws Exception {
        //given
        final String symbol = "AUDUSD";
        final SecurityType securityType = SecurityType.FXSPOT;

        final RequestKey requestKey = RequestKey.of(Venue.EBS, InstrumentKey.of(symbol, securityType, Tenor.SP));

        when(eventToSymbol.apply(event)).thenReturn(symbol);
        when(eventToSecurityType.apply(event)).thenReturn(securityType);

        //when + then
        assertThat(eventRequestKeyMatcher.test(requestKey, event)).isTrue();
        verify(eventToTenor, times(0)).apply(event);
    }

}