package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(Parameterized.class)
public class ChronicleReaderMultiTest {
    private static final int TRADE_COUNT = 5;
    private String[] basePaths;
    private String[] basePaths2;
    private CopyConsumer<Trade> tradeConsumer = new CopyConsumer<>(TradeImpl::new);
    private ExecutorService executorService;
    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    @Before
    public void before() throws IOException {
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;

        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("chronicle-in-%d").build();
        executorService = Executors.newSingleThreadExecutor(threadFactory);

        basePaths = new String[] { tmpFile("c0"), tmpFile("c1") };
        basePaths2 = new String[] { tmpFile("d0"), tmpFile("d1") };
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    @NotNull
    private String tmpFile(final String after) throws IOException {
        return FileUtil.tmpFile(this.getClass().getSimpleName(), after);
    }

    @After
    public void after() {
        executorService.shutdown();
    }

    @Test
    public void confirmEverythingGetsClosedAndWeCanReopen() throws IOException {
        openCloseClean();
        openCloseClean();
    }

    @Test
    public void testReadInCorrectOrderFromAll() throws IOException, InterruptedException {
        final AtomicLong eventId = new AtomicLong(1);
        final Header header = Context.context().header();
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePaths[0])) {
            writeTrades(basePaths[0], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
        }
        eventId.decrementAndGet();
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePaths[1])) {
            // write a dummy trade at same eventId
            writeTrades(basePaths[1], persister, () -> header.setEventId(eventId.getAndIncrement()), 1);
            writeTrades(basePaths[1], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
        }

        openCloseClean();

        checkAllThere(basePaths);
    }

    @Test
    public void testReadInCorrectOrderFromAllSecondChronicleFull() throws IOException, InterruptedException {
        final AtomicLong eventId = new AtomicLong(1);
        final Header header = Context.context().header();
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePaths[0])) {
            writeTrades(basePaths[0], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
        }
        eventId.set(1);
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePaths[1])) {
            writeTrades(basePaths[1], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT * 2);
        }

        openCloseClean();

        checkAllThere(basePaths);
    }

    @Test
    public void testReadWithFirstChronicleLaterThanSecond() throws IOException {
        final AtomicLong eventId = new AtomicLong(1);
        final Header header = Context.context().header();
        try (ProphetPersister persister = ChroniclePersisterFactory.createToolsCommonPersister(basePaths2[0])) {
            writeTrades(basePaths2[0], persister, () -> header.setEventId(eventId.getAndIncrement()), TRADE_COUNT);
        }

        startMultiReader(basePaths2);
        ThreadUtils.sleep(100);

        assertEquals(TRADE_COUNT, tradeConsumer.events.size());

        // TODO: hook into thrown exception

        // following exception thrown to executor service
        //com.anz.markets.prophet.chronicle.SeekException: Cannot seek by eventid: 6
    }

    private void checkAllThere(final String[] paths) throws InterruptedException {
        assertEquals(basePaths.length * TRADE_COUNT, tradeConsumer.events.size());
        int counter = 0;
        for (String chroniclePath : paths) {
            for (int i = 0; i < TRADE_COUNT; i++) {
                final Trade trade = tradeConsumer.events.get(counter);
                assertEquals(chroniclePath, trade.getOrderId().toString());
                ++counter;
            }
        }
        for (int i = 1; i < tradeConsumer.eventIds.size(); i++) {
            assertTrue(tradeConsumer.eventIds.get(i) == 1 + tradeConsumer.eventIds.get(i - 1));
        }
        executorService.awaitTermination(1, TimeUnit.SECONDS);
    }

    private void writeTrades(final String chroniclePath,
                             final ProphetPersister persister,
                             final Runnable runnable,
                             final int count) {
        for (int i = 0; i < count; i++) {
            final TradeImpl trade = MidRateTestHelper.createTrade(Instrument.ZARJPY, OrderSide.BID, i, i);
            trade.setOrderId(chroniclePath);
            trade.setInceptionTimeNanos(i + 1);
            runnable.run();
            persister.sink(MessageType.TRADE).accept(trade);
        }
    }

    private void openCloseClean() throws IOException {
        startMultiReader(basePaths);
        // TODO: check for WaitStrategy.STARTED_MESSAGE
    }

    private void startMultiReader(final String[] paths) throws IOException {
        try (Closeable chronicleReaderMulti = createChronicleReaderMulti(paths)) {
            ThreadUtils.sleep(500);
        }
    }

    private Closeable createChronicleReaderMulti(final String[] paths) throws IOException {
        final TradeReader objectReader = new TradeReader(tradeConsumer);
        final Closeable rv = ChronicleReaderFactory.multiReader(paths, objectReader);
        executorService.execute((Runnable) rv);
        return rv;
    }

    static class CopyConsumer<T> implements Consumer<T> {
        private final ProphetMarshallableCopier prophetMarshallableCopier = new ProphetMarshallableCopier();
        private final Supplier<T> supplier;
        List<T> events;
        List<Long> eventIds;

        CopyConsumer(final Supplier<T> supplier) {
            this.supplier = supplier;
            this.events = new ArrayList<>();
            this.eventIds = new ArrayList<>();
        }

        @Override
        public void accept(final T t) {
            final T copy = supplier.get();
            prophetMarshallableCopier.copy((ProphetMarshallable) t, (ProphetMarshallable) copy);
            events.add(copy);
            eventIds.add(Context.context().header().getEventId());
        }
    }
}
