package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteEncoder;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoPricingRefreshCompleteHandler;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PricingRefreshComplete implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public PricingRefreshComplete() {
        this(new MessageHeader(), new Body());
    }

    public PricingRefreshComplete(final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
    }

    public static final class Body {
        public long instrumentId;
        public boolean forceSnapshot;

        public Body() {
            super();
        }

        public Body(final long instrumentId,
                    final boolean forceSnapshot) {
            this.instrumentId = instrumentId;
            this.forceSnapshot = forceSnapshot;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "instrumentId=" + instrumentId +
                    ", forceSnapshot=" + forceSnapshot +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "PricingRefreshComplete{" +
                "body=" + body +
                '}';
    }


    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.pricingRefreshCompleteEncoder());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.pricingRefreshComplete().create(messageConsumer));
    }

    public void encode(final PricingRefreshCompleteEncoder encoder) {
        encoder.messageStart(header.source, header.sourceSeq)
                .instrumentId(body.instrumentId)
                .forceSnapshot(body.forceSnapshot).messageComplete();
    }

    public static <M> PricingRefreshComplete decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoPricingRefreshCompleteHandler handler = new PojoPricingRefreshCompleteHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.pricingRefreshComplete().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onPricingRefreshComplete(this);
    }
}
