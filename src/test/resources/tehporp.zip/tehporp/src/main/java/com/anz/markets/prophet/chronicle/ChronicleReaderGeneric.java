package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.status.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class ChronicleReaderGeneric<T> implements ChronicleObjectReader {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ChronicleReaderGeneric.class);
    private final T entity;
    private final Predicate<T> predicate;
    private final List<Consumer<T>> consumers;
    private int counter = 0;

    public ChronicleReaderGeneric(final T entity, final Consumer<T>... consumers) {
        this(entity, Predicates.alwaysTrue(), consumers);
    }

    public ChronicleReaderGeneric(final T entity, final Predicate<T> predicate, final Consumer<T>... consumers) {
        this.entity = entity;
        this.predicate = predicate;
        this.consumers = Arrays.asList(consumers);
    }

    public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
        ((ProphetMarshallable) entity).readMarshallable(bytes);
        Context.overrideStartTimeStamp();

        if (!predicate.test(entity)) {
            return;
        }

        // the below must do its work in this thread or else make a defensive copy (or we adopt a different strategy)
        consumers.forEach(consumer -> consumer.accept(entity));
        if ((counter++ % INGESTED_LOG_EVENT_INTERVAL) == 0) {
            LOGGER.info("Ingested {} {}", counter, entity.getClass().getSimpleName());
        }
    }
}
