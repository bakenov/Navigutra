package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.Bytes;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class SimpleStringEncoder<E> implements StringEncoder<E> {

    private final E enclosingEncoder;
    private final Consumer<? super String> setter;

    public SimpleStringEncoder(final E enclosingEncoder, final Consumer<? super String> setter) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.setter = Objects.requireNonNull(setter);
    }

    @Override
    public E encodeEmpty() {
        setter.accept(null);
        return enclosingEncoder;
    }

    @Garbage(Garbage.Type.ANY)
    @Override
    public E encodeFrom(final StringDecoder stringDecoder) {
        setter.accept(stringDecoder.decodeStringOrNull());
        return enclosingEncoder;
    }

    @Garbage(Garbage.Type.ANY)
    @Override
    public <S> E encode(final S source, final ByteReader<? super S> reader, final int sourceOffset, final int length) {
        if (length > 0) {
            final StringBuilder sb = new StringBuilder(length);
            Bytes.copy(source, reader, sourceOffset, sb, ByteWriter.STRING_BUILDER, 0, length);
            setter.accept(sb.toString());
            return enclosingEncoder;
        }
        return encodeEmpty();
    }

    @Garbage(Garbage.Type.ANY)
    @Override
    public E encode(final AsciiString source) {
        setter.accept(source.toStringOrNull());
        return enclosingEncoder;
    }

    @Garbage(Garbage.Type.ANY)
    @Override
    public E encode(final CharSequence source, final int sourceOffset, final int length) {
        if (source != null && length > 0) {
            setter.accept(sourceOffset == 0 && length == source.length() ? source.toString() : source.subSequence(sourceOffset, sourceOffset + length).toString());
            return enclosingEncoder;
        }
        return encodeEmpty();
    }

    @Override
    public E encodeLong(final long value) {
        setter.accept(String.valueOf(value));
        return enclosingEncoder;
    }
}
