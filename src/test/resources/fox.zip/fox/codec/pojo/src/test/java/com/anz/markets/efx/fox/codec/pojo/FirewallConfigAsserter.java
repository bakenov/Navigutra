package com.anz.markets.efx.fox.codec.pojo;

import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class FirewallConfigAsserter {
    private final FirewallConfig message;

    public FirewallConfigAsserter(final FirewallConfig message) {
        this.message = Objects.requireNonNull(message);
    }

    public static FirewallConfigAsserter expect(final FirewallConfig message) {
        return new FirewallConfigAsserter(message);
    }

    public static FirewallConfigAsserter expect(final MessageHeader header, final FirewallConfig.Body body) {
        return new FirewallConfigAsserter(SorMessage.firewallConfig(header, body));
    }

    public FirewallConfig message() {
        return message;
    }

    public FirewallConfig.Body body() {
        return message.body;
    }

    public FirewallConfigHandler assertingFirewallConfigHandler() {
        return new FirewallConfigHandler() {

            @Override
            public void onMessageStart(final int source, final long sourceSeq) {
                HeaderAsserter.assertHeader(header(), source, sourceSeq);
            }

            @Override
            public void onBody(final Body body) {
                assertEquals("firewallName not as expected", FirewallConfigAsserter.this.body().firewallName, body.firewallName().decodeStringOrNull());
                assertEquals("ruleId not as expected", FirewallConfigAsserter.this.body().ruleId, body.ruleId());
                assertEquals("regionPattern not as expected", FirewallConfigAsserter.this.body().regionPattern, body.regionPattern().decodeStringOrNull());
                assertEquals("orderTypePattern not as expected", FirewallConfigAsserter.this.body().orderTypePattern, body.orderTypePattern().decodeStringOrNull());
                assertEquals("deskPattern not as expected", FirewallConfigAsserter.this.body().deskPattern, body.deskPattern().decodeStringOrNull());
                assertEquals("portfolioPattern not as expected", FirewallConfigAsserter.this.body().portfolioPattern, body.portfolioPattern().decodeStringOrNull());
                assertEquals("usernamePattern not as expected", FirewallConfigAsserter.this.body().usernamePattern, body.usernamePattern().decodeStringOrNull());
                assertEquals("venuePattern not as expected", FirewallConfigAsserter.this.body().venuePattern, body.venuePattern().decodeStringOrNull());
                assertEquals("tenorPattern not as expected", FirewallConfigAsserter.this.body().tenorPattern, body.tenorPattern().decodeStringOrNull());
                assertEquals("symbolPattern not as expected", FirewallConfigAsserter.this.body().symbolPattern, body.symbolPattern().decodeStringOrNull());
                assertEquals("period not as expected", FirewallConfigAsserter.this.body().period, body.period());
                assertEquals("periodUnit not as expected", FirewallConfigAsserter.this.body().periodUnit, body.periodUnit().decodeStringOrNull());
                assertEquals("local not as expected", FirewallConfigAsserter.this.body().local, body.local());
                assertEquals("comment not as expected", FirewallConfigAsserter.this.body().comment, body.comment().decodeStringOrNull());
                assertEquals("lastEditUsername not as expected", FirewallConfigAsserter.this.body().lastEditUsername, body.lastEditUsername().decodeStringOrNull());
                assertEquals("lastEditTime not as expected", FirewallConfigAsserter.this.body().lastEditTime, body.lastEditTime());
                assertEquals("limitThreshold not as expected", FirewallConfigAsserter.this.body().limitThreshold, body.limitThreshold(), 0.000001);
            }
        };
    }

    public MessageHeader header() {
        return message.header;
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a FirewallConfig", sorMessage instanceof FirewallConfig);
        assertFirewallConfig((FirewallConfig) sorMessage);
    }

    public void assertFirewallConfig(final FirewallConfig firewallConfig) {

        HeaderAsserter.assertHeader(header(), firewallConfig.header);
        assertBody(firewallConfig.body);
    }

    public void assertBody(final FirewallConfig.Body body) {
        assertEquals("firewallName not as expected", body().firewallName, body.firewallName);
        assertEquals("ruleId not as expected", body().ruleId, body.ruleId);
        assertEquals("regionPattern not as expected", body().regionPattern, body.regionPattern);
        assertEquals("orderTypePattern not as expected", body().orderTypePattern, body.orderTypePattern);
        assertEquals("deskPattern not as expected", body().deskPattern, body.deskPattern);
        assertEquals("portfolioPattern not as expected", body().portfolioPattern, body.portfolioPattern);
        assertEquals("usernamePattern not as expected", body().usernamePattern, body.usernamePattern);
        assertEquals("venuePattern not as expected", body().venuePattern, body.venuePattern);
        assertEquals("securityTypePattern not as expected", body().securityTypePattern, body.securityTypePattern);
        assertEquals("tenorPattern not as expected", body().tenorPattern, body.tenorPattern);
        assertEquals("symbolPattern not as expected", body().symbolPattern, body.symbolPattern);
        assertEquals("period not as expected", body().period, body.period);
        assertEquals("periodUnit not as expected", body().periodUnit, body.periodUnit);
        assertEquals("local not as expected", body().local, body.local);
        assertEquals("comment not as expected", body().comment, body.comment);
        assertEquals("lastEditUsername not as expected", body().lastEditUsername, body.lastEditUsername);
        assertEquals("lastEditTime not as expected", body().lastEditTime, body.lastEditTime);
        assertEquals("limitThreshold not as expected", body().limitThreshold, body.limitThreshold, 0.000001);
    }
}
