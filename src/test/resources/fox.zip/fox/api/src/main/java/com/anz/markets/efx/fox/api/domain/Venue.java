package com.anz.markets.efx.fox.api.domain;

import java.util.Set;

import com.anz.markets.efx.fox.codec.api.VenueCategory;

public interface Venue {
    com.anz.markets.efx.ngaro.api.Venue venueId();
    String compId();
    Set<VenueCategory> venueCategories();
    boolean enabled();
    void updateOnline();
    void updateOffline();
    boolean online();
}
