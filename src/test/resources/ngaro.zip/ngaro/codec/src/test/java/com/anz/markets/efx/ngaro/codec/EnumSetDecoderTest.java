package com.anz.markets.efx.ngaro.codec;

import java.util.EnumSet;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link EnumSetDecoder}
 */
public class EnumSetDecoderTest {

    private enum MyEnum {
        ZERO, ONE, TWO, THREE;
    }

    private EnumSet<MyEnum> backingSet;
    private EnumSetDecoder<MyEnum> decoder;

    @Before
    public void init() {
        final MyEnum[] values = MyEnum.values();
        backingSet = EnumSet.noneOf(MyEnum.class);
        decoder = new EnumSetDecoder<>(() -> values.length, i -> values[i], backingSet);
    }

    @Test
    public void containsAny() throws Exception {
        //when + then
        assertFalse("should be empty", decoder.containsAny());

        //when
        backingSet.add(MyEnum.TWO);

        //then
        assertTrue("should not be empty", decoder.containsAny());
    }

    @Test
    public void contains() throws Exception {
        for (final MyEnum v : MyEnum.values()) {
            assertFalse("should not contain " + v, decoder.contains(v));
        }
        for (final MyEnum v : MyEnum.values()) {
            backingSet.add(v);
            assertTrue("should contain " + v, decoder.contains(v));
        }
    }

    @Test
    public void decodeTo_Consumer() throws Exception {
        //given
        backingSet.add(MyEnum.TWO);
        backingSet.add(MyEnum.THREE);
        final EnumSet<MyEnum> copy = EnumSet.noneOf(MyEnum.class);

        //when
        decoder.decodeTo((Consumer<? super MyEnum>) e -> copy.add(e));

        //then
        assertEquals("copy should equal backing set", backingSet, copy);
    }

    @Test
    public void decodeTo_BiConsumer() throws Exception {
        //given
        backingSet.add(MyEnum.TWO);
        backingSet.add(MyEnum.THREE);
        final EnumSet<MyEnum> copy = EnumSet.noneOf(MyEnum.class);
        final EnumSet<MyEnum> complement = EnumSet.noneOf(MyEnum.class);

        //when
        decoder.decodeTo((BiConsumer<? super MyEnum, Boolean>)(e, set) -> (set ? copy : complement).add(e));

        //then
        assertEquals("copy should equal backing set", backingSet, copy);
        assertEquals("complement should equal complement of backing set", EnumSet.complementOf(backingSet), complement);
    }

    @Test
    public void decodeTo_Set() throws Exception {
        //given
        backingSet.add(MyEnum.TWO);
        backingSet.add(MyEnum.THREE);

        //when
        final EnumSet<MyEnum> copy = decoder.decodeTo(EnumSet.noneOf(MyEnum.class));

        //then
        assertEquals("copy should equal backing set", backingSet, copy);
    }

}