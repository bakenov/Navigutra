#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_gui_lat_au - Plugin to monitor the GUI Message Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=fxagg::gui
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title GUI Message Latency'
    echo 'graph_args --upper-limit 1000'
    echo 'graph_category fxagg::gui'
    echo 'graph_scale no'
    echo 'gui1.label New Order Request (Broker to Correlator)'
    echo 'gui1.draw LINE2'
    echo 'gui2.label Ping Request/Response (GUI to Broker)'
    echo 'gui2.draw LINE2'
    echo 'gui3.label New Order Request (GUI to Correlator)'
    echo 'gui3.draw LINE2'
    echo 'gui4.label Ping Request/Response (GUI to Correlator)'
    echo 'gui4.draw LINE2'
    exit 0
fi

CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logs/Correlator-FxAgg.pid

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ ! -f ${CORRELATOR_PIDFILE} ] ; then
        echo "gui1.value U"
        echo "gui2.value U"
        echo "gui3.value U"
        echo "gui4.value U"
        exit 0
fi

CORRELATOR_PID=$(cat ${CORRELATOR_PIDFILE})
if [ ! -d /proc/${CORRELATOR_PID} ] ; then
        echo "gui1.value U"
        echo "gui2.value U"
        echo "gui3.value U"
        echo "gui4.value U"
        exit 0
fi

LOGS=~/axle/fxagg/fxagg-core/logs
LOGFILE=`ls -altr $LOGS/AggregateTechPerformanceReports_[0-9]*.log | awk '{file=$9} END {print file}'`

if [ -f "$LOGFILE" ]; then
# Awk program for processing AggregateTechPerformanceReports.log
tail -3000 $LOGFILE | awk -F, '
BEGIN {
		if (gui4_perf > 1000 ) {gui4_perf = 1000};
        gui1_count=0; gui1_perf=0;
        gui2_count=0; gui2_perf=0;
        gui3_count=0; gui3_perf=0;
        gui4_count=0; gui4_perf=0;
}
/"Broker-Server:NewOrderRequest","","",""/ {gui1_count=$10; gui1_perf=$13}
/"Gui-Broker:Ping","","",""/ {gui2_count=$10; gui2_perf=$13}
/"Gui-Server:NewOrderRequest","","",""/ {gui3_count=$10; gui3_perf=$13}
/"Gui-Server:Ping","","",""/ {gui4_count=$10; gui4_perf=$13}
END {
        print "gui1.value " gui1_perf;
        print "gui2.value " gui2_perf;
        print "gui3.value " gui3_perf;
        print "gui4.value " gui4_perf;
}
'
fi

