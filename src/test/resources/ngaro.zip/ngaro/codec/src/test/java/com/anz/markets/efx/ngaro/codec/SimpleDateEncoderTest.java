package com.anz.markets.efx.ngaro.codec;

import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.Test;

import com.anz.markets.efx.ngaro.time.Epoch;
import com.anz.markets.efx.ngaro.time.LocalDatePacking;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link SimpleDateEncoder}
 */
public class SimpleDateEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test
    public void encode() throws Exception {
        //given
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        encoder.encode(2016, 02, 28);

        //then
        assertEquals("encoded string not as expected", LocalDate.of(2016, 02, 28), dateHolder.get());

        //when
        encoder.encodeNullable(LocalDate.of(2017, 03, 14));

        //then
        assertEquals("encoded string not as expected", LocalDate.of(2017, 03, 14), dateHolder.get());

        //when
        encoder.encodeNullable(null);

        //then
        assertEquals("encoded string should be null", null, dateHolder.get());
    }

    @Test
    public void encodeEpochMillis() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        encoder.encodeEpochMillis(localDate.toEpochDay() * Epoch.MILLIS_PER_DAY);

        //then
        assertEquals("encoded string not as expected", localDate, dateHolder.get());
    }

    @Test
    public void encodeEpochSeconds() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        encoder.encodeEpochSeconds(localDate.toEpochDay() * Epoch.SECONDS_PER_DAY);

        //then
        assertEquals("encoded string not as expected", localDate, dateHolder.get());
    }

    @Test
    public void encodePackedDecimal() throws Exception {
        //given
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        encoder.encode(LocalDatePacking.DECIMAL, 20170314);

        //then
        assertEquals("encoded string not as expected", LocalDate.of(2017, 03, 14), dateHolder.get());
    }

    @Test
    public void encodePackedBinary() throws Exception {
        //given
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        encoder.encode(LocalDatePacking.BINARY, LocalDatePacking.BINARY.pack(2017, 03, 14));

        //then
        assertEquals("encoded string not as expected", LocalDate.of(2017, 03, 14), dateHolder.get());
    }

    @Test
    public void encodeEpochDays() throws Exception {
        //given
        final LocalDate localDate = LocalDate.of(2017, 03, 14);
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        encoder.encodeEpochDays(localDate.toEpochDay());

        //then
        assertEquals("encoded string not as expected", localDate, dateHolder.get());
    }

    @Test
    public void encodeNull() throws Exception {
        //given
        final AtomicReference<LocalDate> dateHolder = new AtomicReference<>();
        final SimpleDateEncoder<?> encoder = new SimpleDateEncoder<>(ENCLOSING_ENCODER, dateHolder::set);

        //when
        dateHolder.set(LocalDate.now());
        encoder.encodeNull();

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encodeNullable(null);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encode(0, 0, 0);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encodeEpochDays(0);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encodeEpochSeconds(0);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encodeEpochMillis(0);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encode(LocalDatePacking.BINARY, 0);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());

        //when
        dateHolder.set(LocalDate.now());
        encoder.encode(LocalDatePacking.DECIMAL, 0);

        //then
        assertEquals("encoded string not as expected", null, dateHolder.get());
    }

}