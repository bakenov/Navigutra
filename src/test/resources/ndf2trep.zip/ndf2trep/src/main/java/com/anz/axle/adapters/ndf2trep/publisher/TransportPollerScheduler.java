package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.messaging.transport.api.Connection;

public class TransportPollerScheduler implements Scheduler {
    private static final Logger LOGGER = LoggerFactory.getLogger(TransportPollerScheduler.class);

    private final Connection connection;

    public TransportPollerScheduler(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    @Override
    public void submit(final Runnable runnable) {
        try {
            LOGGER.info("invokeInPollingThread {}", runnable);
            connection.pollingStrategy().invokeInPollingThread(runnable);

        } catch (final RuntimeException e) {
            LOGGER.warn("Can't submit Runnable to TransportPoller due connection not available. No action needed.", e);
        }
    }
}
