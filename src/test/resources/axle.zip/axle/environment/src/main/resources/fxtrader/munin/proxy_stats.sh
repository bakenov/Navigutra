#!/bin/bash
# -*- sh -*-

#=head1 NAME

#axle_proxy_- Plugin to monitor the number of accesses to Tomcat
#servers. Ported from Perl to Bash

#=head1 CONFIGURATION

#=head1 USAGE

#Requirements:

#=head1 AUTHOR

#Rory Winston <rory.winston@anz.com>

#=head1 LICENSE

#Unknown license

#=head1 MAGIC MARKERS

 #%# family=manual
 #%# capabilities=autoconf

#=cut

JAVA_HOME=~/jdk1.7/

filename=$(basename "$0")
function_name=${filename##axle_proxy_}

if [ "$1" = "config" ]; then
	if [ "$function_name" = "jvm" ]; then
		echo 'graph_title Tomcat JVM memory';
		echo 'graph_args -l 0';
		echo 'graph_scale no';
		echo 'graph_vlabel kbytes';
		echo 'graph_category axle';
		echo 'graph_order s0 s1 eden old perm';
		echo 's0.label survivor0';
		echo 's0.draw AREA';
		echo 's1.label survivor1';
		echo 's1.draw STACK';
		echo 'eden.label Eden';
		echo 'eden.draw STACK';
		echo 'old.label Old';
		echo 'old.draw STACK';
		echo 'perm.label Perm';
		echo 'perm.draw STACK';
		exit 0;
    fi
	if [ "$function_name" = "threads" ]; then
		echo 'graph_title Tomcat threads';
		echo 'graph_category axle';
		echo 'graph_args -l 0';
		echo 'graph_scale no';
		echo 'graph_vlabel threads';
		echo 'graph_order threads';
		echo 'threads.label Threads';
		echo 'threads.draw LINE2';
    fi
	exit 0;
fi

function do_notrunning {
	if [ "$function_name" = "jvm" ]; then 
		echo "s0.value U";
		echo "s1.value U";
		echo "eden.value U";
   		echo "old.value U";
		echo "perm.value U";
    fi
	if [ "$function_name" = "threads" ]; then
		echo "threads.value U";
    fi
	exit 0;
}

TOMCAT_PIDFILE=~/apache-tomcat/conf/pid
if [ ! -f ~/apache-tomcat/conf/pid ]; then 
	do_notrunning
    exit 0
fi

pid=$(cat $TOMCAT_PIDFILE)
if [ ! -e "/proc/${pid}" ]; then 
	do_notrunning
    exit 0
fi

if [ "$function_name" = "jvm" ]; then 
    STATS=$(${JAVA_HOME}/bin/jstat -gc $pid | tail -1)

    echo "s0.value $(echo $STATS | awk '{print $1}')"
    echo "s1.value $(echo $STATS | awk '{print $2}')"
    echo "eden.value $(echo $STATS | awk '{print $5}')"
    echo "old.value $(echo $STATS | awk '{print $7}')"
    echo "perm.value $(echo $STATS | awk '{print $9}')"
fi

if [ "$function_name" = "threads" ]; then
    THREADS=$(ps -o nlwp -p $pid | tail -1)
	echo "threads.value $THREADS"
fi



