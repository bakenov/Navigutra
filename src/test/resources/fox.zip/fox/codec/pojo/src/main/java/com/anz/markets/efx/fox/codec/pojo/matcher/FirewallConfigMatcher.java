package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.core.Garbage;

import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface FirewallConfigMatcher extends Predicate<Object> {

    Matcher<FirewallConfigMatcher, Header> header();
    Matcher<FirewallConfigMatcher, FirewallConfig.Body> body();

    static FirewallConfigMatcher build() {
        return new FirewallConfigMatcher() {
            private Predicate<FirewallConfig> predicate = Matchers.isA(FirewallConfig.class);

            @Override
            public Matcher<FirewallConfigMatcher, Header> header() {
                return matcher -> andThen(translate(firewallConfig -> firewallConfig.header, matcher));
            }

            @Override
            public Matcher<FirewallConfigMatcher, FirewallConfig.Body> body() {
                return matcher -> andThen(translate(firewallConfig -> firewallConfig.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof FirewallConfig && predicate.test((FirewallConfig) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private FirewallConfigMatcher matcher() {
                return this;
            }

            private FirewallConfigMatcher andThen(final Predicate<? super FirewallConfig> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<FirewallConfig.Body, String> firewallName() {
        return ComparisonMatcher.create("firewallName", b -> b.firewallName);
    }

    static ComparisonMatcher<FirewallConfig.Body, Long> ruleId() {
        return ComparisonMatcher.create("ruleId", b -> b.ruleId);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> regionPattern() {
        return ComparisonMatcher.create("regionPattern", b -> b.regionPattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> orderTypePattern() {
        return ComparisonMatcher.create("orderTypePattern", b -> b.orderTypePattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> deskPattern() {
        return ComparisonMatcher.create("deskPattern", b -> b.deskPattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> portfolioPattern() {
        return ComparisonMatcher.create("portfolioPattern", b -> b.portfolioPattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> userNamePattern() {
        return ComparisonMatcher.create("usernamePattern", b -> b.usernamePattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> venuePattern() {
        return ComparisonMatcher.create("venuePattern", b -> b.venuePattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> securityTypePattern() {
        return ComparisonMatcher.create("securityTypePattern", b -> b.securityTypePattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> tenorPattern() {
        return ComparisonMatcher.create("tenorPattern", b -> b.tenorPattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> symbolPattern() {
        return ComparisonMatcher.create("symbolPattern", b -> b.symbolPattern);
    }

    static ComparisonMatcher<FirewallConfig.Body, Long> period() {
        return ComparisonMatcher.create("period", b -> b.period);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> periodUnit() {
        return ComparisonMatcher.create("periodUnit", b -> b.periodUnit);
    }

    static ComparisonMatcher<FirewallConfig.Body, Boolean> local() {
        return ComparisonMatcher.create("local", b -> b.local);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> comment() {
        return ComparisonMatcher.create("comment", b -> b.comment);
    }

    static ComparisonMatcher<FirewallConfig.Body, String> lastEditUsername() {
        return ComparisonMatcher.create("lastEditUsername", b -> b.lastEditUsername);
    }

    static ComparisonMatcher<FirewallConfig.Body, Long> lastEditTime() {
        return ComparisonMatcher.create("lastEditTime", b -> b.lastEditTime);
    }

    static ComparisonMatcher<FirewallConfig.Body, Double> limitThreshold() {
        return ComparisonMatcher.create("limitThreshold", b -> b.limitThreshold);
    }
}
