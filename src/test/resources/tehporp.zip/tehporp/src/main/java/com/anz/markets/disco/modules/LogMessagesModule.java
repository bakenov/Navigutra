package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.utils.Symbol;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;

public class LogMessagesModule extends AbstractModule {

    private final Logger log = LoggerFactory.getLogger(LogMessagesModule.class);

    private final long LOG_EVERY_MILLIS = 100;

    private long nextLog;

    private final HashSet<Symbol> messageTypes;

    public LogMessagesModule(final Class... messageTypes) {
        this.messageTypes = messageTypes.length > 0 ? new HashSet() : null;
        for (Class messageType : messageTypes) {
            this.messageTypes.add(MessageBus.getMessageType(messageType));
        }
    }

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.subAnyPrior(this::consumeAnyMessage);
    }

    private void consumeAnyMessage(Symbol messageType, Object message) {
        if (messageTypes == null || messageTypes.contains(messageType)) {
            final long tMillis = System.currentTimeMillis();
            if (nextLog <= tMillis) {
                log.info(messageType + ": " + message);
                nextLog = tMillis + LOG_EVERY_MILLIS;
            }
        }
    }

}
