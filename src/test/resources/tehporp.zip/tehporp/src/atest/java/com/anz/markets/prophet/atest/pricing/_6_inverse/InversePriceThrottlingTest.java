package com.anz.markets.prophet.atest.pricing._6_inverse;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.pricing._7_throttle.PriceThrottlerLimitTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;

import static com.anz.markets.prophet.domain.Instrument.AUDEUR;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURAUD;
import static com.anz.markets.prophet.domain.Instrument.EURGBP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPEUR;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement(value = {Requirement.Ref.PRICING_4_9})
public class InversePriceThrottlingTest extends BaseAcceptanceSpecification {

    @Test
    public void throttleInverseSourcedFromTriangulatedPair() {
        final double minPriceDeltaFractionOfSpread = 0.16;
        final int normalFrequencyMS = 100;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(EURAUD, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_A, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_B, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_C, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_Z, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),

                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
                    .setSyntheticInstrumentConfigs(Arrays.asList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.EURAUD).setMarkets(Market.WSP_A.name()),
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDEUR).setMarkets(Market.WSP_A.name())
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.EUR, Currency.AUD, Market.WSP_A, 1.0),
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.EUR, Market.WSP_A, 1.0)
                    ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5)
                    ));
            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.12985, 0.00004));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.76105, 0.00004));
        }

        then:
        {
            ClientPrice inverseCp = prophet.expect(ClientPrice.class, atLeast(1), isPublishable(Market.WSP_A, AUDEUR)).getLast();
            assertThat(inverseCp.getMidRate(), isRoundedTo(0.673585));
            assertThat(inverseCp.getSpread(), is(6.52115320564084E-5));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.12984, 0.00004));
        }

        then:
        {   // triangulated pair publishable
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, EURAUD)).getFirst();

            // Driver pairs tightest spread = 0.00004
            // min movement required AUD/EUR = 0.16 * 0.00004 = 0.0000064
            // change in AUD/EUR mid = |0.673585 - 0.673591| = 0.000006 < 0.0000064  ==> NOT PUBLISHABLE
            // However spread has increased therefore PUBLISH  AXPROPHET-990
            ClientPrice inverseCp = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, AUDEUR)).getFirst();
            assertThat(inverseCp.getMidRate(), isRoundedTo(0.673591));
            assertThat(inverseCp.getSpread() > 6.521153E-5, is(true));
        }
    }

    @Test
    public void notThrottleInverseSourcedFromTriangulatedPair() {
        final double minPriceDeltaFractionOfSpread = 0.14;
        final int normalFrequencyMS = 100;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(EURAUD, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_A, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_B, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_C, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_Z, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_A, Currency.AUD, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_B, Currency.AUD, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_C, Currency.AUD, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
                    .setSyntheticInstrumentConfigs(Arrays.asList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.EURAUD).setMarkets(Market.WSP_A.name()),
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDEUR).setMarkets(Market.WSP_A.name())
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.EUR, Currency.AUD, Market.WSP_A, 1.0)
                    ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),

                            new ClientSpreadConfigImpl(Market.WSP_A, AUDUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, AUDUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURUSD, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURUSD, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5)
                    ));
            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.12985, 0.00004));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.76105, 0.00004));
        }

        then:
        {
            ClientPrice inverseCp = prophet.expect(ClientPrice.class, atLeast(1), isPublishable(Market.WSP_A, AUDEUR)).getLast();
            assertThat(inverseCp.getMidRate(), isRoundedTo(0.673585));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.12984, 0.00004));
        }

        then:
        {   // triangulated pair publishable
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, EURAUD)).getFirst();

            // Driver pairs tightest spread = 0.00004
            // min movement required AUD/EUR = 0.14 * 0.00004 = 0.0000056
            // change in AUD/EUR mid = |0.673585 - 0.673591| = 0.000006 > 0.0000056  ==> PUBLISHABLE
            ClientPrice inverseCp = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, AUDEUR)).getFirst();
            assertThat(inverseCp.getMidRate(), isRoundedTo(0.673591));
        }
    }

    @Test
    public void throttleInverseSourcedFromDriverPair() {
        final double minPriceDeltaFractionOfSpread = 0.36;
        inverseSourcedFromDriverPair(minPriceDeltaFractionOfSpread);
    }

    @Test
    public void notThrottleInverseSourcedFromDriverPair() {
        final double minPriceDeltaFractionOfSpread = 0.34;
        inverseSourcedFromDriverPair(minPriceDeltaFractionOfSpread);
    }

    private void inverseSourcedFromDriverPair(double minPriceDeltaFractionOfSpread) {
        final int normalFrequencyMS = 100;

        given:
        {
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_A, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_B, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_C, Currency.ANY, Currency.ANY, 0.1, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_A, Currency.GBP, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_B, Currency.GBP, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS),
                            PriceThrottlerLimitTest.clientPriceConfigNormalThrottle(Market.WSP_C, Currency.GBP, Currency.EUR, minPriceDeltaFractionOfSpread, normalFrequencyMS)
                    ))
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, EURGBP, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURGBP, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),

                            new ClientSpreadConfigImpl(Market.WSP_A, EURGBP, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, EURGBP, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.5)
                    ));
            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(EURGBP, 0.85000, 0.00001));
        }
        then:
        {
            ClientPrice inverseCp = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, GBPEUR)).getFirst();
            assertThat(inverseCp.getMidRate(), isRoundedTo(1.176471));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(EURGBP, 0.85001, 0.00004));
        }

        then:
        {   // driver pair publishable
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, EURGBP)).getFirst();

            if (minPriceDeltaFractionOfSpread < 0.36) {
                // Driver pairs tightest spread = 0.00004
                // min movement required GBPEUR = 0.35 * 0.00004 = 0.000014
                // change in GBPEUR mid = |1.176471 - 1.176457| = 0.000014 <= 0.000014  ==> PUBLISHABLE
                ClientPrice inverseCp = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, GBPEUR)).getFirst();
                assertThat(inverseCp.getMidRate(), isRoundedTo(1.176457));

            } else {
                // Driver pairs tightest spread = 0.00004
                // min movement required GBPEUR = 0.36 * 0.00004 = 0.0000144
                // change in GBPEUR mid = |1.176471 - 1.176457| = 0.000014 < 0.0000144  ==> NOT PUBLISHABLE
                ClientPrice inverseCp = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A, GBPEUR)).getFirst();
                assertThat(inverseCp.getMidRate(), isRoundedTo(1.176457));
            }
        }
    }


}
