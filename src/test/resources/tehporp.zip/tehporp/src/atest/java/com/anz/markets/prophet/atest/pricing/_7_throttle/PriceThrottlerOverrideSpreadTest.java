package com.anz.markets.prophet.atest.pricing._7_throttle;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsItemConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.EconNewsWideningConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.EconNewsWeight;
import com.anz.markets.prophet.domain.Country;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import com.google.common.collect.Lists;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Collections;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.number.IsCloseTo.closeTo;

@RestartBeforeTest(reason = "To avoid same econ overlapping with different tests.")
@Requirement({Ref.PRICING_4_8_2, Ref.PRICING_4_8_3})
public class PriceThrottlerOverrideSpreadTest extends BaseAcceptanceSpecification {

    private double EPSILON = 1e-6;

    @Ignore("Rounding issues again.  Difference is slightly less instead of equals")
    @Test
    @DisplayName("Client Spread positive change equals override min - price published")
    public void clientSpreadPositiveChangeEqualsMinPricePublished() {
        final double minPriceDeltaFractionOfMid = 0.000011;
        final double minPriceDeltaFractionOfSpread = 1.5;
        final int overrideFrequencyMS = 100;

        final EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now());

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS)
                    ))
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_2, Currency.USD)
                    )
                    .setEconNewsWideningConfigs(
                            new EconNewsWideningConfigImpl(EconNewsWeight.W_2, 2.5, 300, 300, false, Market.ANY)
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(econNews);  // base spread 0.8 pip * 2.5 factor = 2.0 pip spread
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00020));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 < min mid movement
            // minimumPriceDeltaFractionOfSpread = 1.5, last spread = 0.00008 => min movement = 0.00008 * 1.5 = 0.00012
            // Spread movement |0.00008-0.00020| = 0.00012  => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00001));
            assertThat(clientPrice.getSpread(), is(closeTo(0.0002, EPSILON)));
        }
    }

    @Ignore("Rounding issues again.  Difference is slightly less instead of equals")
    @Test
    @DisplayName("Client Spread negative change equals override min - price published")
    public void clientSpreadNegativeChangeEqualsMinPricePublished() {
        final double minPriceDeltaFractionOfMid = 0.000011;
        final double minPriceDeltaFractionOfSpread = 0.5;
        final int overrideFrequencyMS = 100;

        final EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now());

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS)
                    ))
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_2, Currency.USD)
                    )
                    .setEconNewsWideningConfigs(
                            new EconNewsWideningConfigImpl(EconNewsWeight.W_2, 0.5, 300, 300, false, Market.ANY)
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(econNews);  // base spread 0.8 pip * 0.5 factor = 0.4 pip spread
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00004));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 < min mid movement
            // minimumPriceDeltaFractionOfSpread = 0.5, last spread = 0.00008 => min movement = 0.00008 * 0.5 = 0.00004
            // Spread movement |0.00008-0.00004| = 0.00004  => price published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00001));
            assertThat(clientPrice.getSpread(), is(closeTo(0.00004, EPSILON)));
        }
    }

    @Test
    @DisplayName("Client Spread change less than min - price not queued")
    public void clientSpreadChangeLessThanMinNotQueued() {
        final double minPriceDeltaFractionOfMid = 0.000011;
        final double minPriceDeltaFractionOfSpread = 1.5;
        final int overrideFrequencyMS = 100;

        final EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now());

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS)
                    ))
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_2, Currency.USD)
                    )
                    .setEconNewsWideningConfigs(
                            new EconNewsWideningConfigImpl(EconNewsWeight.W_2, 2.4, 300, 300, false, Market.ANY)
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(econNews);  // base spread 0.8 pip * 2.4 factor = 1.92 pip spread
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00020));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 < min mid movement
            // minimumPriceDeltaFractionOfSpread = 1.5, last spread = 0.00008 => min movement = 0.00008 * 1.5 = 0.00012
            // Spread movement |0.00008-0.000192-| = 0.000112 < 0.00012  => price NOT queued
            // AXPROPHET-990 however since spread has increased => PUBLISH
            prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF));
        }
    }

    @Test
    @DisplayName("Price throttled and then pushed at start of new cycle")
    public void priceThrottledThenPushedAtStartNewPeriod() {
        final double minPriceDeltaFractionOfMid = 0.000011;
        final double minPriceDeltaFractionOfSpread = 1.4;
        final int overrideFrequencyMS = 100;

        final EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now());

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_2, Currency.USD)
                    )
                    .setEconNewsWideningConfigs(
                            new EconNewsWideningConfigImpl(EconNewsWeight.W_2, 2.5, 300, 300, false, Market.ANY)
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getSpread(), is(closeTo(0.00008, EPSILON)));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            prophet.receive(econNews);  // base spread 0.8 pip * 2.5 factor = 2 pip spread
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00020));
        }
        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 < min mid movement
            // minimumPriceDeltaFractionOfSpread = 1.4, last spread = 0.00008 => min movement = 0.00008 * 1.4 = 0.000112
            // Spread movement |0.00008-0.00020| = 0.00012 > 0.000112  => price queued
            // AXPROPHET-990 however since spread has increased => PUBLISH
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getSpread(), is(closeTo(0.0002, EPSILON)));
        }
    }

    @Test
    @DisplayName("Queued price replaced with significant spread movement price")
    public void queuedPriceReplacedWithSignificantSpreadPrice() {
        final double minPriceDeltaFractionOfMid = 0.000011;
        final double minPriceDeltaFractionOfSpread = 1.4;
        final int overrideFrequencyMS = 100;

        final EconNews econNews = new EconNewsImpl().setCode("NEWS_CODE#1").setCountry(Country.AU).setEventTimeStampMS(now());

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, minPriceDeltaFractionOfMid, minPriceDeltaFractionOfSpread, overrideFrequencyMS)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
                    .setEconNewsItemConfigs(
                            new EconNewsItemConfigImpl(econNews.getCode(), EconNewsWeight.W_2, Currency.USD)
                    )
                    .setEconNewsWideningConfigs(
                            new EconNewsWideningConfigImpl(EconNewsWeight.W_2, 2.5, 300, 300, false, Market.ANY)
                    )
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, true))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getSpread(), is(closeTo(0.00008, EPSILON)));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(50);
            // mid movement is > minPriceDeltaFractionOfMid.  Price throttled/queued
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00002, 0.00008));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00002));
        }

        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(25);
            prophet.receive(econNews);  // base spread 0.8 pip * 2.5 factor = 2 pip spread
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00020));
        }

        then:
        {   // minimumPriceDeltaFractionOfMid = 0.00001, last mid = 1.00000 => min movement = 0.00001 * 1.00000 = 0.00001
            // Mid movement of 0.00001 < min mid movement
            // minimumPriceDeltaFractionOfSpread = 1.4, last spread = 0.00008 => min movement = 0.00008 * 1.4 = 0.000112
            // Spread movement |0.00008-0.00020| = 0.00012 > 0.000112  => price queued
            // AXPROPHET-990 however since spread increased PUBLISH IMMEDIATELY
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getSpread(), is(closeTo(0.0002, EPSILON)));
        }
    }


    private ClientPriceThrottleConfigImpl clientPriceConfigOverrideThrottle(final Market market, Currency baseCurrency, Currency termsCurrency,
                                                                            double minimumPriceDeltaFractionOfMid,
                                                                            double minimumPriceDeltaFractionOfSpread,
                                                                            int midRateFrequencyMS) {
        return new ClientPriceThrottleConfigImpl(market, baseCurrency, termsCurrency)
                .setNoActivityHeartbeatFrequencyMs(DONT_CARE_LARGE_LONG)
                .setLimit(1)
                .setTimePeriod(DONT_CARE_LARGE_LONG)
                .setMinimumPriceDeltaFractionOfSpread(DONT_CARE_LARGE_DOUBLE)
                .setOverrideLimit(1)
                .setOverrideTimePeriod(midRateFrequencyMS)
                .setOverrideMinimumPriceDeltaFractionOfMid(minimumPriceDeltaFractionOfMid)
                .setMinimumPriceDeltaFractionOfPreviousSpread(minimumPriceDeltaFractionOfSpread);
    }
}
