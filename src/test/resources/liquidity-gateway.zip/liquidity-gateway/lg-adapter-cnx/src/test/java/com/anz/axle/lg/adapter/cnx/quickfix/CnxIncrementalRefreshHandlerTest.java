package com.anz.axle.lg.adapter.cnx.quickfix;

import java.util.List;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import quickfix.Message;

import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.FixSide;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.FormattedTimeParser;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.test.FixMessageFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoIncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CnxIncrementalRefreshHandlerTest {
    private static final String SENDER_COMP_ID = "GB:CNX";
    private static final String COMP_ID = "GB:lg-cnx";
    private static final long CURRENT_TIME = 34523453;
    private static final long MSG_SEQ_NUM = 4317;
    private static final String MSG_SEQ_NUM_STRING = "4317";
    private static final String SENDING_TIME_STRING = "20161129-06:23:35.982";
    private static final FormattedTimeParser FORMATTED_TIME_PARSER = new FormattedTimeParser();
    private static final long SENDING_TIME_NANOS = FORMATTED_TIME_PARSER.parseNanos(SENDING_TIME_STRING);
    private static final String CURRENCY = "EUR";
    private static final String SYMBOL = "EUR/CAD";
    private static final String NORMALISED_SYMBOL = "EURCAD";
    private static final SecurityType SECURITY_TYPE = SecurityType.FXSPOT;
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(NORMALISED_SYMBOL, SECURITY_TYPE, Tenor.SP);
    private static final String MDR_ID = "1234567";
    private static final int MDR_ID_INT = Integer.parseInt(MDR_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(MDR_ID);
    private static final EntryType SIDE1 = EntryType.BID;
    private static final String ENTRY_ID1 = "39504";
    private static final String QUANTITY_STRING1 = "500000.00";
    private static final String PRICE_STRING1 = "1.56039";

    private FixMessageFactory messageFactory;
    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    @Mock
    private Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private CnxIncrementalRefreshHandler cnxIncrementalRefreshHandler;
    private PricingEncoderSupplier encoderSupplier;
    private StringToIntCache entryIdCache;
    private int mdEntryIdInt;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    @Before
    public void setUp() throws Exception {
        entryIdCache = new StringToIntCacheFactory(1000, 30, 2, 2, 1).get();
        mdEntryIdInt = entryIdCache.put(ENTRY_ID1);
        encoderSupplier = new PojoPricingEncoderSupplier(m -> {});
        cnxIncrementalRefreshHandler = new CnxIncrementalRefreshHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, flagsAppender, sourceSequencer);
        messageFactory = new FixMessageFactory("/conf/FIX42-cnx.xml");
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY)).thenReturn(RequestKey.of(Venue.CNX, INSTRUMENT_KEY));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(MDR_ID_INT)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        when(marketDataSubscription.symbol()).thenReturn(SYMBOL);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
        when(marketDataSubscription.stringToIntCache()).thenReturn(entryIdCache);
    }

    @Test
    public void shouldProcessNewEntry() throws Exception {
        final Message incrementalMessage = messageFactory.msg(
                "8=", "FIX.4.2",
                "9=", "179",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CNX_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CNX_MD_S",
                "262=", MDR_ID,
                "268=", "1",
                "279=", "0", // NEW
                "269=", FixSide.to(SIDE1),
                "278=", ENTRY_ID1,
                "55=", SYMBOL,
                "270=", PRICE_STRING1,
                "15=", CURRENCY,
                "271=", QUANTITY_STRING1,
                "346=2",
                "10=", "10");
        assertNull(incrementalMessage.getException());

        //when
        cnxIncrementalRefreshHandler.accept(incrementalMessage);

        //then
        verifyIncrement( 1, ENTRY_ID1, SIDE1, QUANTITY_STRING1, PRICE_STRING1, UpdateAction.NEW);
    }

    @Test
    public void shouldProcessDeleteEntry() throws Exception {
        final Message incrementalMessage = messageFactory.msg(
                "8=", "FIX.4.2",
                "9=", "179",
                "35=", "X",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CNX_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CNX_MD_S",
                "262=", MDR_ID,
                "268=", "1",
                "279=", "2", // DELETE
                "269=", FixSide.to(SIDE1),
                "278=", ENTRY_ID1,
                "55=", SYMBOL,
                "15=", CURRENCY,
                "10=", "55");
        assertNull(incrementalMessage.getException());

        //when
        cnxIncrementalRefreshHandler.accept(incrementalMessage);

        //then
        verifyIncrement( 1, ENTRY_ID1, SIDE1,  null, null, UpdateAction.DELETE);
    }

    private void verifyIncrement(final int entriesCount,
                                 final String entryId1,
                                 final EntryType side1,
                                 final String quantityString1,
                                 final String priceString1,
                                 final UpdateAction updateAction) {

        final PojoIncrementalRefreshEncoder pojoEncoder = (PojoIncrementalRefreshEncoder)encoderSupplier.incrementalRefresh();
        final IncrementalRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.senderCompId, is(COMP_ID));
        assertThat(body.messageId, is(MSG_SEQ_NUM));
        assertThat(body.marketId, is(Venue.CNX));
        assertThat(body.instrumentId, is(INSTRUMENT_KEY.instrumentId()));
        assertThat(body.sendingTime, is(SENDING_TIME_NANOS));

        final List<IncrementalRefresh.Entry> entries = pojoEncoder.message().entries;
        assertThat(entries.size(), is(entriesCount));
        if (entriesCount == 1) {
            assertThat(entries.get(0).mdUpdateAction, is(updateAction));
            assertThat(entries.get(0).transactTime, is(SENDING_TIME_NANOS));
            assertThat(entries.get(0).mdEntryType, is(side1));
            if (updateAction == UpdateAction.NEW) {
                assertThat(entries.get(0).mdEntrySize, is(Double.valueOf(quantityString1)));
                assertThat(entries.get(0).mdEntryPx, is(Double.valueOf(priceString1)));
            }
            assertThat(entries.get(0).mdEntryId, is(mdEntryIdInt));
            assertThat(entries.get(0).mdEntryRefId, is(0));
            assertThat(entries.get(0).quoteEntryId, is(0));
        }

        final List<Hop> hops = pojoEncoder.message().hops;
        assertThat(hops.size(), is(2));
        assertThat(hops.get(0).hopCompId, is(SENDER_COMP_ID));
        assertThat(hops.get(0).hopMessageId, is(MSG_SEQ_NUM));
        assertThat(hops.get(0).hopReceivingTime, is(0L));
        assertThat(hops.get(0).hopSendingTime, is(SENDING_TIME_NANOS));

        assertThat(hops.get(1).hopCompId, is(COMP_ID));
        assertThat(hops.get(1).hopMessageId, is(MSG_SEQ_NUM));
        assertThat(hops.get(1).hopReceivingTime, is(CURRENT_TIME));
        assertThat(hops.get(1).hopSendingTime, is(CURRENT_TIME));
    }
}