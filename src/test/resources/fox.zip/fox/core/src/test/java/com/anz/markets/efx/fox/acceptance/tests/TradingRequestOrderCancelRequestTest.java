package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRejectMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRequestMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;

@RunWith(Spockito.class)
public class TradingRequestOrderCancelRequestTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(TradingRequestOrderCancelRequestTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }


    @Test
    @Spockito.Unroll({
            "| senderCompId | messageId | clOrdId | orderId | symbol |  side   |  securityType | marketId | orderQty  |",
            "|==============|===========|=========|=========|========|=========|===============|==========|===========|",
            "| GB:lg-fast   |    9876   | 3456    | 5678    | AUDUSD |  BUY    |   FXSPOT      | FOX      | 1e6       |",
            "|--------------|-----------|---------|---------|--------|---------|---------------|----------|-----------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void receiver_should_forward_execution_report_to_command_queue_and_then_to_event_queue(
            final String senderCompId, final long messageId, final String clOrdId, final String orderId,
            final String symbol, final Side side, final SecurityType securityType, final String marketId, final double orderQty
    ) {

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        final OrderCancelRequest orderCancelRequest = sorEndpoint.createOrderCancelRequest();
        orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
        orderCancelRequest.body.orderQty = orderQty;
        orderCancelRequest.body.clOrdId = clOrdId;
        orderCancelRequest.body.orderId = orderId;
        orderCancelRequest.body.origClOrdId = clOrdId;
        orderCancelRequest.body.clOrdLinkId = clOrdId;
        orderCancelRequest.body.securityType = securityType;
        orderCancelRequest.body.senderCompId = senderCompId;
        orderCancelRequest.body.targetCompId = "GB:fox";
        orderCancelRequest.body.side = side;
        orderCancelRequest.body.symbol = symbol;

        sorEndpoint.tradingRequest().add(orderCancelRequest);

        final OrderCancelRequestMatcher orderCancelRequestMatcher = OrderCancelRequestMatcher.build()
                .body().matches(OrderCancelRequestMatcher.senderCompId().eq(senderCompId))
                .body().matches(OrderCancelRequestMatcher.orderQty().eq(orderQty))
                .body().matches(OrderCancelRequestMatcher.orderId().eq(orderId))
                .body().matches(OrderCancelRequestMatcher.clOrdId().eq(clOrdId))
                .body().matches(OrderCancelRequestMatcher.origClOrdId().eq(clOrdId))
                .body().matches(OrderCancelRequestMatcher.clOrdLinkId().eq(clOrdId))
                .body().matches(OrderCancelRequestMatcher.securityType().eq(securityType))
                .body().matches(OrderCancelRequestMatcher.side().eq(side))
                .body().matches(OrderCancelRequestMatcher.marketId().eq(marketId))
                .body().matches(OrderCancelRequestMatcher.symbol().eq(symbol));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(orderCancelRequestMatcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        final OrderCancelRejectMatcher orderCancelRejectMatcher = OrderCancelRejectMatcher.build()
                .body().matches(OrderCancelRejectMatcher.senderCompId().eq("GB:fox"))
                .body().matches(OrderCancelRejectMatcher.marketId().eq(marketId))
                .body().matches(OrderCancelRejectMatcher.clOrdId().eq(clOrdId))
                .body().matches(OrderCancelRejectMatcher.origClOrdId().eq(clOrdId))
                .body().matches(OrderCancelRejectMatcher.clOrdLinkId().eq(clOrdId))
                .body().matches(OrderCancelRejectMatcher.orderId().eq(orderId))
                .body().matches(OrderCancelRejectMatcher.cxlRejResponseTo().eq(OrderCancelRequestType.ORDER_CANCEL_REQUEST))
                .body().matches(OrderCancelRejectMatcher.cxlRejReason().eq(OrderCancelRejectReason.UNKNOWN_ORDER));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(orderCancelRejectMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(orderCancelRejectMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }
}
