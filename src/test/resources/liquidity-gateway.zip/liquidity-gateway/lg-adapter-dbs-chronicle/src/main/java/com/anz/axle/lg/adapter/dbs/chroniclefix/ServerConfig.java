package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.CommonConfig;
import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
@Import({
        CommonConfig.class,
        FixConfig.class,
        PricingConfig.class,
        TradingConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PricingSubscriptionConfig.class
})
public class ServerConfig {

    private final Service fixPricingEngine;
    private final Service fixTradingEngine;
    private final Connection connection;
    private final Service mainEventLoop;

    public ServerConfig(@Qualifier("fixPricingEngine") final Service fixPricingEngine,
                        @Qualifier("fixTradingEngine") final Service fixTradingEngine,
                        final Connection connection,
                        final Service mainEventLoop) {
        this.fixPricingEngine = Objects.requireNonNull(fixPricingEngine);
        this.fixTradingEngine = Objects.requireNonNull(fixTradingEngine);
        this.connection = Objects.requireNonNull(connection);
        this.mainEventLoop = Objects.requireNonNull(mainEventLoop);
    }

    @PostConstruct
    public void init() {
        mainEventLoop.start();
        fixPricingEngine.start();
        fixTradingEngine.start();
    }

    @PreDestroy
    public void destroy() {
        fixPricingEngine.stop();
        fixTradingEngine.stop();
        mainEventLoop.stop();
        connection.close();
    }
}
