package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.UserGroupsEncoder;
import com.anz.markets.efx.ngaro.codec.EnumSetEncoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;

public final class SbeUserGroupSetEncoder<E> implements EnumerableSetEncoder<E, UserGroup> {

    private final EnumerableSetEncoder<E, UserGroup> delegate;

    public SbeUserGroupSetEncoder(final E enclosingEncoder, final Supplier<UserGroupsEncoder> encoderSupplier) {
        Objects.requireNonNull(encoderSupplier);
        this.delegate = new EnumSetEncoder<>(enclosingEncoder, UserGroup::length, UserGroup::valueByOrdinal,
                userGroup -> Enums.userGroup(userGroup, encoderSupplier.get(), true),
                () -> encoderSupplier.get().clear()
        );
    }

    @Override
    public E clear() {
        return delegate.clear();
    }

    @Override
    public E add(final UserGroup value) {
        return delegate.add(value);
    }

    @Override
    public E addAll(final Set<? extends UserGroup> values) {
        return delegate.addAll(values);
    }

    @Override
    public <S> E addAll(final S source, final BiPredicate<? super S, ? super UserGroup> reader) {
        return delegate.addAll(source, reader);
    }
}
