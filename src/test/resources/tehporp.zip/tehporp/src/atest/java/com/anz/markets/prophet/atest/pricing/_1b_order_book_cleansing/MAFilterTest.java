package com.anz.markets.prophet.atest.pricing._1b_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.status.Context;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * MA-Filter : Order book crossed filter (exclude oldest price in the crossed price point)
 */
public class MAFilterTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault enableMAFilter() {

        ConfigurationDataDefault config = tdd.configuration_pricing_base()
                .setFilterEnabledConfigs(union(
                        tdd.disableFilter(MarketDataFilterType.MARKET_BOOK_CROSSED),
                        tdd.disableFilter(MarketDataFilterType.AGG_BOOK_DISPERSION)
                ));

        return config;
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_10)
    @DisplayName("TOB inverted equal to threshold - no market filtered")
    public void do_not_remove_any_market_when_TOB_inverted_on_threshold() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = enableMAFilter();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1.5
             * threshold = 0.2 * 1.5 = 0.3 pips / 0.00003
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.5).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75011, 0.75012));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75012));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75015, 0.75016));
        }

        then:
        {
            // WSP_U TOB (0.75015, 0.75012) crossed by 0.3pip.  Threshold = 0.3. Therefore do NOT remove any market
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75015, 0.75012));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_10)
    @DisplayName("Remove multiple markets from OFFER side")
    public void TOB_inverted_beyond_threshold_THEN_remove_multiple_older_markets_OFFER_side() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = enableMAFilter();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1
             * threshold = 0.2 * 1 = 0.2 pips / 0.00002
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.0).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        final long timestampMS = Context.context().timeSource().nowMillis();

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75011, 0.75016, timestampMS + 1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75015, timestampMS + 2));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75010, 0.75014, timestampMS + 3));

        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.GS));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.DEUT));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75014));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75018, 0.75020, timestampMS + 4));
        }

        then:
        {
            // Remove oldest venues in crossed TOB price point until TOB is within threshold
            // i.e DEUT OFFER and HSP OFFER removed
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(marketDataSnapshot.getFilterOutcome(), is(FilterDecision.PASS));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.GS));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75018, 0.75016));
        }

    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_10)
    @DisplayName("Remove market from BID side to generate choice TOB")
    public void TOB_inverted_beyond_threshold_THEN_remove_oldest_market_BID_side() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = enableMAFilter();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 0
             * threshold = 0.2 * 0 = 0.0
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(0.0).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        final long timestampMS = Context.context().timeSource().nowMillis();

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75011, 0.75014, timestampMS + 1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75013, timestampMS + 2));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75009, 0.75012, timestampMS + 3));
        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.GS));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.DEUT));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75012));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update causing crossed TOB greater than threshold
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75008, 0.75009, timestampMS + 4));
        }

        then:
        {
            // Remove oldest venues in crossed TOB price point until TOB is within threshold
            // i.e GS BID and HSP BID removed
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.DEUT));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.CNX));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75009, 0.75009));
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_1_10)
    @DisplayName("Remove market from BID and OFFER side when equal age")
    public void remove_bid_offer_market_when_equal_age() {
        setup:
        {
            prophet.setTradingTimeZone(TradingTimeZone.LDN);

            ConfigurationDataDefault config = enableMAFilter();
            /**
             * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
             * set spread-multiplier config = 1
             * threshold = 0.2 * 1 = 0.2 pips / 0.00002
             */
            config.setStandardMarketSpreadConfigs(Lists.newArrayList(
                    new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.0).setSpotDecimalPlaces(4.0).setSpotDecimalPlaces(4).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ));

            prophet.receive(config);
        }

        final long timestampMS = Context.context().timeSource().nowMillis();

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, Instrument.AUDUSD, 0.75011, 0.75016, timestampMS + 1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.75010, 0.75015, timestampMS + 2));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.DEUT, Instrument.AUDUSD, 0.75010, 0.75014, timestampMS + 3));

        }

        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(3), isMarket(Market.WSP_U)).getLast();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.GS));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.DEUT));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75011, 0.75014));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // CNX MarketData Update is crossed and will be TOB
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.75016, 0.75013, timestampMS + 4));
        }

        then:
        {
            // Crossed TOB consists of CNX on bid and offer sides
            // Since CNX bid and offer are the same age, remove both
            // Since resultant TOB WSP_U unchanged, do NOT expect a WSP_U
            prophet.notExpect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U));
        }
    }
}
