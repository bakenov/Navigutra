package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.InstrumentConfig;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoInstrumentConfigDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends InstrumentConfigHandler> handlerSupplier;

    public PojoInstrumentConfigDecoder(final Supplier<? extends InstrumentConfigHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof InstrumentConfig) {
            return decode((InstrumentConfig) sorMessage);
        }
        return false;
    }

    public boolean decode(final InstrumentConfig message) {
        final InstrumentConfigHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source, message.header.sourceSeq);
        handler.onBody(new InstrumentConfigHandler.Body() {

            @Override
            public long instrumentId() {
                return message.body.instrumentId;
            }

            @Override
            public int pipSizeDivisor() {
                return message.body.pipSizeDivisor;
            }

            @Override
            public boolean enabled() {
                return  message.body.enabled;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoInstrumentConfigDecoder() {
        throw new RuntimeException("No PojoInstrumentConfigDecoder for you!");
    }
}
