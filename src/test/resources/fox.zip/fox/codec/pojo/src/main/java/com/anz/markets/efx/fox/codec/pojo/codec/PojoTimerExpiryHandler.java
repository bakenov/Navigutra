package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoTimerExpiryHandler implements TimerExpiryHandler {

    private final Consumer<? super TimerExpiry> messageConsumer;

    private TimerExpiry message = SorMessage.timerExpiry();

    public TimerExpiry message() {
        return message;
    }

    public PojoTimerExpiryHandler() {
        this(msg -> {});
    }

    public PojoTimerExpiryHandler(final Consumer<? super TimerExpiry> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.timerExpiry();
        message.header.source = source;
        message.header.sourceSeq = sourceSeq;
    }

    @Override
    public void onBody(final Body body) {
        message.body.triggeredTime = body.triggeredTime();
        message.body.timerId = body.timerId();
        message.body.timerGroup = body.timerGroup();
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
