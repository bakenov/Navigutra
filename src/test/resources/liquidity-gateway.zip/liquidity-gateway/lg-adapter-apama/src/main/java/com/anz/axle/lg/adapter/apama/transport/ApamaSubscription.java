package com.anz.axle.lg.adapter.apama.transport;

import java.util.Objects;

public class ApamaSubscription implements Subscription {
    private final Runnable subscriptionCloser;

    public ApamaSubscription(final Runnable subscriptionCloser) {
        this.subscriptionCloser = Objects.requireNonNull(subscriptionCloser);
    }

    @Override
    public void close() {
        subscriptionCloser.run();
    }
}
