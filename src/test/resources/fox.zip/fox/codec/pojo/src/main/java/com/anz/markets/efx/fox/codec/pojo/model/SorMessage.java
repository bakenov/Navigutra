package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoSorHandlerSupplier;
import com.anz.markets.efx.ngaro.codec.HeaderDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public interface SorMessage extends HeaderDecoder {

    void accept(MessageVisitor visitor);

    <M> void encode(SorEncoders<M> pricingEncoder, Consumer<? super M> messageConsumer);

    void encode(SorEncoderSupplier sorEncoderSupplier);

    static <M> SorMessage decode(final M message, final SorDecoders<M> sorDecoders) {
        final AtomicReference<SorMessage> result = new AtomicReference<>(null);
        final PojoSorHandlerSupplier handlerSupplier = new PojoSorHandlerSupplier(result::set);
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.all().create(handlerSupplier, forwardingLookup).decode(message);
        return result.get();
    }

    static PricingRefreshComplete pricingRefreshComplete() {
        return new PricingRefreshComplete();
    }

    static PricingRefreshComplete pricingRefreshComplete(final MessageHeader header, final PricingRefreshComplete.Body body) {
        final PricingRefreshComplete message = new PricingRefreshComplete(header, body);
        return message;
    }

    static TimerExpiry timerExpiry() {
        return new TimerExpiry();
    }

    static TimerExpiry timerExpiry(final MessageHeader header, final TimerExpiry.Body body) {
        return new TimerExpiry(header, body);
    }

    static FirewallConfig firewallConfig() {
        return new FirewallConfig();
    }

    static FirewallConfig firewallConfig(final MessageHeader header, final FirewallConfig.Body body) {
        return new FirewallConfig(header, body);
    }

    static VenueConfig venueConfig() {
        return new VenueConfig();
    }

    static VenueConfig venueConfig(final MessageHeader header, final VenueConfig.Body body) {
        return new VenueConfig(header, body);
    }

    static UserConfig userConfig() {
        return new UserConfig();
    }

    static UserConfig userConfig(final MessageHeader header, final UserConfig.Body body) {
        return new UserConfig(header, body);
    }

    static Initialisation initialisation() {
        return new Initialisation();
    }

    static Initialisation initialisation(final MessageHeader header, final Initialisation.Body body) {
        return new Initialisation(header, body);
    }

    static InstrumentConfig instrumentConfig() {
        return new InstrumentConfig();
    }

    static InstrumentConfig instrumentConfig(final MessageHeader header, final InstrumentConfig.Body body) {
        return new InstrumentConfig(header, body);
    }

    static VenueInstrumentConfig venueInstrumentConfig() {
        return new VenueInstrumentConfig();
    }

    static VenueInstrumentConfig venueInstrumentConfig(final MessageHeader header, final VenueInstrumentConfig.Body body) {
        return new VenueInstrumentConfig(header, body);
    }
}
