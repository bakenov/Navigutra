package com.anz.axle.lg.adapter.citi.quickfix;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Message;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteRequestRejectReason;

import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;

import static com.anz.axle.lg.adapter.quickfix.FixFields.textOrNull;

public class CitiMarketDataRequestRejectHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(CitiMarketDataRequestRejectHandler.class);

    private final SubscriptionManager subscriptionManager;
    private final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy;

    public CitiMarketDataRequestRejectHandler(final SubscriptionManager subscriptionManager,
                                              final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy) {
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.subscriptionRequestRejectStrategy = Objects.requireNonNull(subscriptionRequestRejectStrategy);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_QUOTE_REQUEST_REJECT;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final int quoteRequestId = message.getInt(QuoteReqID.FIELD);
        final int quoteRequestRejectReasonCode = message.getInt(QuoteRequestRejectReason.FIELD);
        final String rejectMessage = textOrNull(message);
        LOGGER.error("QuoteRequest has been rejected with message: {}, rejection reason code: {}", rejectMessage, quoteRequestRejectReasonCode);
        subscriptionManager.rejectRequest(quoteRequestId, subscriptionRequestRejectStrategy);
    }
}
