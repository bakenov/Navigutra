package com.anz.markets.efx.ngaro.codec;

import java.util.Set;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

/**
 * Encoder for an enumerable set of values. Note that the encoder implementation implicitly or explicitly defines the
 * value domain, that is, it defines all possible values {@code V}.
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 * @param <V> the type of enumerable set value
 */
public interface EnumerableSetEncoder<E, V> {
    E clear();

    E add(V value);

    <S> E addAll(S source, BiPredicate<? super S, ? super V> reader);

    @SuppressWarnings("unchecked")
    default E addAll(Set<? extends V> values) {
        return addAll(values, (BiPredicate<Set<? extends V>, V>)SET_READER);
    }

    @SuppressWarnings("unchecked")
    default E addAll(Predicate<? super V> values) {
        return addAll(values, (BiPredicate<Predicate<? super V>, V>)(BiPredicate<?,?>)PREDICATE_READER);
    }

    @SuppressWarnings("unchecked")
    default E addAllFrom(EnumerableSetDecoder<? extends V> values) {
        return addAll(values, (BiPredicate<EnumerableSetDecoder<? extends V>, V>)(BiPredicate<?,?>)DECODER_READER);
    }

    BiPredicate<? extends Set<?>, ?> SET_READER = (s, v) -> s.contains(v);
    BiPredicate<? extends Predicate<Object>, Object> PREDICATE_READER = (p, v) -> p.test(v);
    BiPredicate<? extends EnumerableSetDecoder<Object>, Object> DECODER_READER = (d, v) -> d.contains(v);
}
