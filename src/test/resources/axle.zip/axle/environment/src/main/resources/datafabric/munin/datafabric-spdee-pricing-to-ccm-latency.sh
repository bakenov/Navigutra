#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-spdee-pricing-to-ccm-latency - Plugin to monitor the SPDEE Pricing to CCM Latency (All)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title SPDEE Pricing Latency'
    echo 'graph_category spdee'
    echo 'graph_scale no'
    echo 'latencyQuoteBook.label QuoteBook to CCM'
    echo 'latencyQuoteBook.draw LINE2'
    echo 'latencyAggBook.label AggBook to CCM'
    echo 'latencyAggBook.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "latencyAggBook.value U"
        echo "latencyQuoteBook.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "latencyAggBook.value U"
        echo "latencyQuoteBook.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
egrep 'pricing.*-to-ccm,,' $LOGFILE | tail -1000 | awk -F, '
BEGIN {
        latencyAggBook=0;
        latencyQuoteBook=0;
}

/pricing.agg-book-to-ccm/ {latencyAggBook=$15}
/pricing.quote-book-to-ccm/ {latencyQuoteBook=$15}

END {
        print "latencyAggBook.value " latencyAggBook;
        print "latencyQuoteBook.value " latencyQuoteBook;
}
'
fi

