package com.anz.axle.lg.adapter.ebsu.increment;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.core.util.Histogram;
import software.chronicle.ebs.instrument.InstrumentDictionary;
import software.chronicle.ebs.itch.generated.incremental.messages.server.PriceLevelUpdate;
import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;
import software.chronicle.ebs.util.DecodeUtil;

import com.anz.axle.lg.adapter.EntryIdUtil;
import com.anz.axle.lg.adapter.ebsu.SecurityInfoHolder;
import com.anz.axle.lg.adapter.ebsu.SideConverter;
import com.anz.axle.lg.adapter.ebsu.TenorFilter;
import com.anz.axle.lg.adapter.ebsu.UpdateActionConverter;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;

public final class IncrementalMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(IncrementalMessageHandler.class);

    private final LongSupplier sequenceNumberSupplier;
    private final SecurityInfoHolder securityInfoHolder;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final Venue market;
    private final boolean encodeHops;
    private final long dumpHistosEveryNanos;
    private final Histogram sendToRcv;
    private final Histogram processed;
    private final Histogram completed;
    private final SourceSequencer sourceSequencer;
    private InstrumentDictionary securityDictionary;
    private long lastHistosDumpNanos = 0;

    public IncrementalMessageHandler(@NotNull final SecurityInfoHolder securityInfoHolder,
                                     @NotNull final LongSupplier sequenceNumberSupplier,
                                     @NotNull final PrecisionClock precisionClock,
                                     @NotNull final String senderCompId,
                                     @NotNull final String compId,
                                     @NotNull final Venue market,
                                     final boolean encodeHops,
                                     final int dumpHistosEveryMillis,
                                     @NotNull final SourceSequencer sourceSequencer) {
        this.securityInfoHolder = Objects.requireNonNull(securityInfoHolder);
        this.sequenceNumberSupplier = Objects.requireNonNull(sequenceNumberSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.market = Objects.requireNonNull(market);
        this.encodeHops = encodeHops;
        this.dumpHistosEveryNanos = TimeUnit.MILLISECONDS.toNanos(dumpHistosEveryMillis);
        this.sendToRcv = new Histogram();
        this.processed = new Histogram();
        this.completed = new Histogram();
    }

    public void accept(@NotNull final InstrumentDictionary securityDictionary) {
        this.securityDictionary = securityDictionary;
    }

    public void accept(@NotNull final PriceLevelUpdate message, final long receivingTimeNanos) {
        LOGGER.debug("MarketDataIncrementalRefresh received: {}", message);

//        if (message.marketRegion() != expectedRegion) {
//            throw new IllegalStateException();
//        }

        int locateCode = (int) message.locateCode();
        if (securityDictionary == null || (! securityDictionary.contains(locateCode))) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("No security definition for {}", locateCode);
            }
            return;
        }
        final InstrumentDirectory securityDefinition = securityDictionary.get(locateCode);
        if (! isPublishable(securityDefinition)) {
            return;
        }

        final long sequenceNumber = message.sequenceNumber();
        final long sendingTimeNanos = message.timestamp();
        final long messageId = sequenceNumberSupplier.getAsLong();

        final SecurityInfoHolder.SecurityInfo securityInfo = securityInfoHolder.get(locateCode, securityDefinition);
        final IncrementalRefreshEncoder.Body encoder = securityInfo.pricingEncoderSupplier.incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        final IncrementalRefreshEncoder.MdEntries.Next mdEntries_Next = encoder
                .senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(market)
                .instrumentId(securityInfo.instrumentKey.instrumentId())
                .sendingTime(sendingTimeNanos)
                .mdFlags().clear()
                .entriesStart(1);

        // we may (most likely will) publish a NEW as a CHANGE as we cannot tell
        // DELETE can be followed by DELETE if something existed before being removed
        final UpdateAction updateAction = UpdateActionConverter.from(message);
        final EntryType side = SideConverter.entryType(message.marketSide());
        final double mdEntryPx = DecodeUtil.price(message.priceLevel());
        if (Double.isNaN(mdEntryPx))
            throw new IllegalStateException("No price level");
        final double mdEntrySize = DecodeUtil.amount(message.levelAmount());
        // price level is how EBS identify entries so we make an int id from price level
        final int entryId = EntryIdUtil.entryIdFromPriceLevel(mdEntryPx, (int) securityDefinition.pricePrecision(), side.ordinal() + 1);

        mdEntries_Next.next()
                .mdUpdateAction(updateAction)
                .transactTime(sendingTimeNanos)
                .mdMkt(market)
                .mdEntryType(side)
                .mdEntryId(entryId)
                .mdEntryRefId(entryId)
                .mdEntrySize(mdEntrySize)
                .mdEntryPx(mdEntryPx);

        long beforeMessageCompleteNanos = precisionClock.nanos();

        if (encodeHops) {
            mdEntries_Next.entriesComplete()
                    .hopsStart(2)
                    .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                    .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                    .messageComplete();
        } else {
            mdEntries_Next.entriesComplete().hopsEmpty().messageComplete();
        }

        if (dumpHistosEveryNanos > 0) {
            sampleAndDumpHistos(receivingTimeNanos, sendingTimeNanos, beforeMessageCompleteNanos);
        }
    }

    private boolean isPublishable(final InstrumentDirectory securityDefinition) {
        return TenorFilter.canPublish(securityDefinition);
    }

    private void sampleAndDumpHistos(final long receivingTimeNanos, final long sendingTimeNanos, final long beforeMessageCompleteNanos) {
        sendToRcv.sampleNanos(receivingTimeNanos - sendingTimeNanos);
        processed.sampleNanos(beforeMessageCompleteNanos - receivingTimeNanos);
        completed.sampleNanos(precisionClock.nanos() - beforeMessageCompleteNanos);
        if ((receivingTimeNanos - lastHistosDumpNanos) > dumpHistosEveryNanos) {
            LOGGER.info("histos\nsendToRcv {}: {}\nprocessed {}: {}\ncompleted {}: {}",
                    sendToRcv.totalCount(), sendToRcv.toMicrosFormat(),
                    processed.totalCount(), processed.toMicrosFormat(),
                    completed.totalCount(), completed.toMicrosFormat());
            sendToRcv.reset();
            processed.reset();
            completed.reset();
            lastHistosDumpNanos = receivingTimeNanos;
        }
    }

    public void connectionInterrupted() {
        LOGGER.info("Clearing books");
        securityInfoHolder.forEachSecurity(this::emptySnapshot);
    }

    private void emptySnapshot(@NotNull final SecurityInfoHolder.SecurityInfo securityInfo) {
        final long messageId = sequenceNumberSupplier.getAsLong();

        final SnapshotFullRefreshEncoder.Body encoder = securityInfo.pricingEncoderSupplier.snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        encoder.messageId(messageId)
                .marketId(market)
                .instrumentId(securityInfo.instrumentKey.instrumentId())
                .mdFlags().addAll(PricingEncoderLookup.MD_FLAGS_DISCONNECTED)
                .entriesEmpty()
                .hopsEmpty()
                .messageComplete();
    }
}
