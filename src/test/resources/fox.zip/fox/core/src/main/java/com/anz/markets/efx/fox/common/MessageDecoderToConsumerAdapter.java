package com.anz.markets.efx.fox.common;

import java.util.Objects;

import org.tools4j.eventsourcing.api.MessageConsumer;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class MessageDecoderToConsumerAdapter implements MessageDecoder<SbeMessage> {
    private final MessageConsumer messageConsumer;

    public MessageDecoderToConsumerAdapter(final MessageConsumer messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        messageConsumer.accept(message.buffer(), 0, message.messageLength());
        return true;
    }
}
