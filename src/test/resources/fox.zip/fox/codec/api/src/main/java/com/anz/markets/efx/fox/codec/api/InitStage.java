package com.anz.markets.efx.fox.codec.api;

public enum InitStage {
    BEGIN,
    END;
}
