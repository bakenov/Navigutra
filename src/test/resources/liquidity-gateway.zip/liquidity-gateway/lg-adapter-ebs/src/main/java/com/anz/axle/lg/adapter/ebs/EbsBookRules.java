package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;

/**
 * EBS implicit book construction rules (with parameters as provided in 35=BF message):
 * <ul>
 *     <li>max number of levels (PriceDepth tag 20100)</li>
 *     <li>max price range (combo of PriceDepthRange tag 20105 and priceIncrement nested data tags 9001/9002)</li>
 * </ul>
 * Note that for this application, the parameters as provided at logon have been recorded in
 * {@literal apama-EBS-default.properties}
 */
public interface EbsBookRules {

    int INDEX_PRICE_DEPTH = 0;
    int INDEX_PRICE_RANGE_INCREMENT = 1;
    int INDEX_PRICE_RANGE_STEPS = 2;

    Config configFor(long instrumentId);
    void update(UserResponse userResponse);

    interface Config {
        int depth();

        double priceRangeIncrement();

        int priceRangeSteps();
    }
}
