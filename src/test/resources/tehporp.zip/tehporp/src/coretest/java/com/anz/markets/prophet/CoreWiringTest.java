package com.anz.markets.prophet;

import com.anz.markets.efx.ngaro.math.Epsilon;
import com.anz.markets.prophet.config.app.importable.ConsumerConfig;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.TradeType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.Filterable;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.positionrisk.AdjustmentImpl;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.AmountUnit;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ConsumerConfig.class, DefaultTestConfig.class})
public class CoreWiringTest {
    private static final double EPSILON = 1e-7;

    @BeforeClass
    public static void setupClass() {
        Context.set(new Context(new TestTimeSource(ZonedDateTime.parse("2017-01-20T05:00:00+00:00").toEpochSecond() * 1000)));
        Context.context().region(Region.GB);
        Context.context().tradingTimeZone(TradingTimeZone.LDN);
    }

    @Autowired
    DefaultTestConfig defaultTestConfig;

    List<String> hedgingInstrumentsCutdown = Arrays.asList("EURGBP", "AUDUSD");

    @Test
    @DirtiesContext
    public void testTradeToPositionEtc() {
        final Trade trade;
        given:
        {
            IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.RFX), is(true));
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.EURUSD,Market.DEUT), is(true));
            defaultTestConfig.optimalPositionsSink().clear();
            defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.RFX, 1, 0.7621, 0.0001));
            defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.DEUT, 1, 0.7721, 0.0001));
            trade = MidRateTestHelper.createTrade(Instrument.AUDUSD, OrderSide.BID, 1_000_000, 0.7621, TradeType.CLIENT);
        }
        when:
        {
            defaultTestConfig.tradeConsumer.accept(trade);
        }
        then:
        {
            assertEquals(0, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS).size());
            assertEquals(1, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS_NET).size());
            Positions positions = defaultTestConfig.positionsSink().getLastEvent(Portfolio.CLIENTS_NET);
            assertEquals(trade.getDealtCurrency(), positions.getPosition1().getCcy());
            assertEquals(trade.getFilledQuantity(), positions.getPosition1().getPositionInNotional(), EPSILON);

            // notional position change means updates of client price
            List<ClientPrice> driverClientPrices = defaultTestConfig.clientPriceSink().getEvents().stream().filter(p -> p.getInstrument() == Instrument.AUDUSD).collect(Collectors.toList());
            assertEquals(11, driverClientPrices.size());  // 11 here because last WSP_Z client price update is throttled.
            assertEquals(0, defaultTestConfig.orderSink().getEvents().size());
            assertEquals(6, defaultTestConfig.marketDataSink().getEvents().size());
            assertEquals(1, defaultTestConfig.varSink().getEvents().size());
            Map<OptimalPositionType, List<OptimalPositions>> resultOptimalPositions = extractOptimalPositionsByType(defaultTestConfig.optimalPositionsSink().getEvents(), 2); // added position_bias
            assertThat(resultOptimalPositions.get(OptimalPositionType.HEDGING).size(), is(0));
            assertThat(resultOptimalPositions.get(OptimalPositionType.HEDGING_BIAS).size(), is(0));
            assertThat(resultOptimalPositions.get(OptimalPositionType.PRICING).size(), is(1));
            assertThat(resultOptimalPositions.get(OptimalPositionType.PRICING_BIAS).size(), is(1));
            assertEquals(0, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS).size());
            assertEquals(1, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS_NET).size());
        }
    }

    @Test
    @DirtiesContext
    public void testAllDownstreamCalcsForAllHedgingInstruments() {
        checkAllDownstreamCalcsForAllHedgingInstruments();
    }

    @Test
    @DirtiesContext
    public void testPositionAdjustFlushFlushesAllDownstream() {
        given:
        {
            defaultTestConfig.optimalPositionsSink().clear();
            checkAllDownstreamCalcsForAllHedgingInstruments();

            defaultTestConfig.varSink().clear();
            defaultTestConfig.positionsSink().clear();
            defaultTestConfig.optimalPositionsSink().clear();
            defaultTestConfig.profitAndLossSink().clear();
            defaultTestConfig.varSink().getEvents().clear();
        }
        when:
        {
            AdjustmentImpl clearAll = new AdjustmentImpl();
            clearAll.setFlushAll();
            defaultTestConfig.adjustmentConsumers.accept(clearAll);
        }
        then:
        {
            Positions positions = defaultTestConfig.positionsSink().getLastEvent(Portfolio.CLIENTS_NET);
            positions.forEach(position -> assertEquals(0, positions.getPosition1().getPositionInNotional(), EPSILON));

            assertEquals(3, defaultTestConfig.varSink().getEvents().size());
            ValueAtRisk var = defaultTestConfig.varSink().getLastEvent();
            assertEquals(0d, var.getValue(), EPSILON);

            Map<OptimalPositionType, List<OptimalPositions>> resultOptimalPositions = extractOptimalPositionsByType(defaultTestConfig.optimalPositionsSink().getEvents(), 6); // added bias_position
            assertThat(resultOptimalPositions.get(OptimalPositionType.HEDGING).size(), is(0));
            assertThat(resultOptimalPositions.get(OptimalPositionType.HEDGING_BIAS).size(), is(0));
            assertThat(resultOptimalPositions.get(OptimalPositionType.PRICING).size(), is(3));
            assertThat(resultOptimalPositions.get(OptimalPositionType.PRICING_BIAS).size(), is(3));
            OptimalPositions ops = resultOptimalPositions.get(OptimalPositionType.PRICING).get(2);

            // some NaN some 0?
            ops.ops.forEach(op -> assertTrue(Double.isNaN(op.getPositionInNotional()) || Math.abs(op.getPositionInNotional()) < EPSILON));
            // >1 P&L is emitted as all positions are not zeroed atomically
            assertEquals(0, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS).size());
            assertEquals(4, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS_NET).size());
            ProfitAndLoss pAndL = defaultTestConfig.profitAndLossSink().getLastEvent(Portfolio.CLIENTS_NET);
            assertEquals(0d, pAndL.getValueSystemBaseCurrency(), EPSILON);

            ops = resultOptimalPositions.get(OptimalPositionType.PRICING).get(2);

            // some NaN some 0?
            ops.ops.forEach(op -> assertTrue(Double.isNaN(op.getPositionInNotional()) || Math.abs(op.getPositionInNotional()) < EPSILON));
            // >1 P&L is emitted as all positions are not zeroed atomically
            assertEquals(0, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS).size());
            assertEquals(4, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS_NET).size());
            pAndL = defaultTestConfig.profitAndLossSink().getLastEvent(Portfolio.CLIENTS_NET);
            assertEquals(0d, pAndL.getValueSystemBaseCurrency(), EPSILON);
        }
    }

    @Test
    @DirtiesContext
    public void testPositionReFlushedEveryMinute() {
        given:
        {
            checkAllDownstreamCalcsForAllHedgingInstruments();

            defaultTestConfig.varSink().clear();
            defaultTestConfig.positionsSink().clear();
            defaultTestConfig.optimalPositionsSink().clear();
            defaultTestConfig.profitAndLossSink().clear();
            defaultTestConfig.varSink().getEvents().clear();
        }
        when:
        {
            for (int i = 1; i < 60; i++) {
                defaultTestConfig.oneSecondConsumer.accept(OneSecond.INSTANCE);
                final List<Positions> positions = defaultTestConfig.positionsSink().getEvents(Portfolio.CLIENTS_NET);
                assertEquals(0, positions.size());
            }
            defaultTestConfig.oneSecondConsumer.accept(OneSecond.INSTANCE);
        }
        then:
        {
            final List<Positions> positions = defaultTestConfig.positionsSink().getEvents(Portfolio.CLIENTS_NET);
            assertEquals(hedgingInstrumentsCutdown.size() * 2, positions.size());
        }
    }

    private void checkAllDownstreamCalcsForAllHedgingInstruments() {
        IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();

        assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.GBPUSD,Market.RFX), is(true));
        assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.GBPUSD,Market.DEUT), is(true));
        assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.GBPUSD,Market.FASTMATCH), is(true));
        assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.RFX), is(true));
        assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.EURUSD,Market.DEUT), is(true));
        assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.EURUSD,Market.CITI), is(true));

        // pump in mid rates for all instruments
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.GBPUSD, Market.RFX, 1, 1.3, 0.0001));
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.GBPUSD, Market.DEUT, 1, 1.3, 0.0001));
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.GBPUSD, Market.FASTMATCH, 1, 1.3, 0.0001));
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.DEUT, 1, 0.7621, 0.0001));
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.RFX, 1, 0.7621, 0.0001));
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.EURUSD, Market.DEUT, 1, 1.12, 0.0001));
        defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.EURUSD, Market.CITI, 1, 1.12, 0.0001));
        List<MidRate> mds = defaultTestConfig.marketDataSink().getEvents();
        mds.forEach(midRate -> {
            Filterable filteredMarketDataSnapshot = (Filterable) midRate;
            assertThat("should not fail filter for " + filteredMarketDataSnapshot, filteredMarketDataSnapshot.getFilterOutcome(), is(FilterDecision.PASS));
        });

        defaultTestConfig.marketDataSink().getEvents().clear();
        defaultTestConfig.clientPriceSink().getEvents().clear();
        defaultTestConfig.optimalPositionsSink().getEvents().clear();
        defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS_NET).clear();

        // TODO: add other instrs back in
        final List<Instrument> instruments = Instrument.valueOf(hedgingInstrumentsCutdown);
        for (Instrument i : instruments) {
            // same x rate for all
            final Trade trade = MidRateTestHelper.createTrade(i, OrderSide.BID, AmountUnit.MILLIONS.toDollar(1), 0.762, TradeType.CLIENT);
            defaultTestConfig.tradeConsumer.accept(trade);
            Positions positions = defaultTestConfig.positionsSink().getLastEvent(Portfolio.CLIENTS_NET);
            assertEquals(trade.getDealtCurrency(), positions.getPosition1().getCcy());
            assertEquals(trade.getFilledQuantity(), positions.getPosition1().getPositionInNotional(), EPSILON);
        }

        // Notional Position change means updates
        assertEquals(13, defaultTestConfig.clientPriceSink().getEvents().size()); // no change in price that not impacted
        assertEquals(0, defaultTestConfig.orderSink().getEvents().size());
        assertEquals(0, defaultTestConfig.marketDataSink().getEvents().size());

        assertEquals(instruments.size(), defaultTestConfig.varSink().getEvents().size());
        ValueAtRisk var = defaultTestConfig.varSink().getLastEvent();
        assertNotEquals(0d, var.getValue(), EPSILON);

        Map<OptimalPositionType, List<OptimalPositions>> resultOptimalPositions = extractOptimalPositionsByType(defaultTestConfig.optimalPositionsSink().getEvents(), 4); // added position_bas
        assertThat(resultOptimalPositions.get(OptimalPositionType.HEDGING).size(), is(0));
        assertThat(resultOptimalPositions.get(OptimalPositionType.HEDGING_BIAS).size(), is(0));
        assertThat(resultOptimalPositions.get(OptimalPositionType.PRICING).size(), is(2));
        assertThat(resultOptimalPositions.get(OptimalPositionType.PRICING_BIAS).size(), is(2));

        OptimalPositions ops = defaultTestConfig.optimalPositionsSink().getLastEvent();
        ops.ops.forEach(op -> {
            assertNotEquals(Double.isNaN(op.getPositionInSystemBase()), true);
            if (!op.getInstrument().isDealtSystemBase() && !op.getInstrument().isCross()) {
                assertNotEquals(Double.isNaN(op.getPositionInSystemBase()), true);
            }
        });
        // One Client trade emits pnl on CLIENTS and CLIENTS_NET portfolios
        assertEquals(0, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS).size());
        assertEquals(2, defaultTestConfig.profitAndLossSink().getEvents(Portfolio.CLIENTS_NET).size());
        final ProfitAndLoss pAndL = defaultTestConfig.profitAndLossSink().getLastEvent(Portfolio.CLIENTS_NET);
        assertEquals(129500.0, pAndL.getValueSystemBaseCurrency(), EPSILON);
    }

    private Map<OptimalPositionType, List<OptimalPositions>> extractOptimalPositionsByType(
            List<OptimalPositions> events, int expectedOptimalPositions) {
        assertThat(events.size(), is(expectedOptimalPositions));
        List<OptimalPositions> pricingOP = new ArrayList<>();
        List<OptimalPositions> pricingOPB = new ArrayList<>();
        List<OptimalPositions> hedgingOP = new ArrayList<>();
        List<OptimalPositions> hedgingOPB = new ArrayList<>();
        defaultTestConfig.optimalPositionsSink().getEvents().forEach(optimalPositions -> {
            if (optimalPositions.getOptimalPositionType() == OptimalPositionType.PRICING) {
                pricingOP.add(optimalPositions);
            }
            else if (optimalPositions.getOptimalPositionType() == OptimalPositionType.PRICING_BIAS) {
                pricingOPB.add(optimalPositions);
            }
            else if (optimalPositions.getOptimalPositionType() == OptimalPositionType.HEDGING) {
                hedgingOP.add(optimalPositions);
            }
            else if (optimalPositions.getOptimalPositionType() == OptimalPositionType.HEDGING_BIAS) {
                hedgingOPB.add(optimalPositions);
            }
        });
        Map<OptimalPositionType, List<OptimalPositions>> map = new HashMap<>();
        map.put(OptimalPositionType.PRICING, pricingOP);
        map.put(OptimalPositionType.PRICING_BIAS, pricingOPB);
        map.put(OptimalPositionType.HEDGING, hedgingOP);
        map.put(OptimalPositionType.HEDGING_BIAS, hedgingOPB);
        return map;
    }


    @Test
    @DirtiesContext
    public void testZeroTrade() {
        final Trade trade;
        given:
        {
            IndexedConfigurationData indexedConfigurationData = defaultTestConfig.configurationSink().getEvent();
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.AUDUSD,Market.RFX), is(true));
            assertThat("primary market has change in business.configuration.data.json", indexedConfigurationData.getAggregatedBookConfig().getConstituentMatrix(Market.WSP_U, TradingTimeZone.SNG).get(Instrument.EURUSD,Market.DEUT), is(true));
            defaultTestConfig.optimalPositionsSink().clear();
            defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.DEUT, 1, 0.7621, 0.0001));
            defaultTestConfig.marketDataConsumers.accept(MidRateTestHelper.createMarketData(Instrument.AUDUSD, Market.RFX, 1, 0.7721, 0.0001));
            trade = MidRateTestHelper.createTrade(Instrument.AUDUSD, OrderSide.BID, 0, 0.7621, TradeType.CLIENT);
        }
        when:
        {
            defaultTestConfig.tradeConsumer.accept(trade);
        }
        then:
        {
            assertEquals(0, defaultTestConfig.positionsSink().getEvents(Portfolio.CLIENTS).size()); // this is disabled, so always 0
            final List<Positions> positions = defaultTestConfig.positionsSink().getEvents(Portfolio.CLIENTS_NET);
            assertEquals(1, positions.size());
            assertEquals(2, positions.get(0).countPositions());
            assertEquals(0, positions.get(0).getPosition1().getPositionInNotional(), Epsilon.EPS_1eNegative8.getValue());
            assertEquals(0, positions.get(0).getPosition2().getPositionInNotional(), Epsilon.EPS_1eNegative8.getValue());
        }
    }
}