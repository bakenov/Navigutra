package com.anz.axle.lg.adapter.apama.event;

import java.util.Map;

import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;

public class MarketDataIncrementalRefresh_MDEntry {
    public static final String EVENT_NAME = "com.apama.fix.MarketDataIncrementalRefresh_MDEntry";
    public static final Field<String> FIELD_MD_UPDATE_ACTION = MarketDataApamaEventFields.FIELD_MD_UPDATE_ACTION;
    public static final MdEntryTypeField FIELD_MD_ENTRY_TYPE = MarketDataApamaEventFields.FIELD_MD_ENTRY_TYPE;
    public static final Field<String> FIELD_MD_ENTRY_ID = MarketDataApamaEventFields.FIELD_MD_ENTRY_ID;
    public static final Field<String> FIELD_SYMBOL = GeneralApamaEventFields.FIELD_SYMBOL;
    public static final Field<Double> FIELD_MD_ENTRY_PX = MarketDataApamaEventFields.FIELD_MD_ENTRY_PX;
    public static final Field<Double> FIELD_MD_ENTRY_SIZE = MarketDataApamaEventFields.FIELD_MD_ENTRY_SIZE;
    public static final Field<String> FIELD_MD_ORDER_ID = MarketDataApamaEventFields.FIELD_MD_ORDER_ID;
    public static final Field<Map<Long, String>> FIELD_EXTRA_PARAMS = GeneralApamaEventFields.FIELD_EXTRA_PARAMS;

    public static final EventType EVENT_TYPE = initEventType();

    private static EventType initEventType() {
        return new EventType(EVENT_NAME,
                FIELD_MD_UPDATE_ACTION,
                FIELD_MD_ENTRY_TYPE,
                FIELD_MD_ENTRY_ID,
                FIELD_SYMBOL,
                FIELD_MD_ENTRY_PX,
                FIELD_MD_ENTRY_SIZE,
                FIELD_MD_ORDER_ID,
                FIELD_EXTRA_PARAMS);
    }

}
