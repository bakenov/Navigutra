package com.anz.axle.lg.adapter.barx;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class BarxMarketDataSubscription implements MarketDataSubscription {
    private static final int DEFAULT_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK = false;
    private static final boolean DEFAULT_FULL_REFRESH = true;
    private final long id;
    private final String symbol;
    private final int priceBand;
    private final InstrumentKey instrumentKey;
    private final StringToIntCache stringToIntCache;


    public BarxMarketDataSubscription(final long id, final String symbol, final int priceBand, final StringToIntCache stringToIntCache) {
        this.symbol = Objects.requireNonNull(symbol);
        this.priceBand = priceBand;
        this.id = id;
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), SecurityType.FXSPOT, Tenor.SP);
        this.stringToIntCache = Objects.requireNonNull(stringToIntCache);
    }

    public static BarxMarketDataSubscription idSymbolPriceBand(final long id, final String symbol, final int priceBand, final StringToIntCache stringToIntCache) {
        return new BarxMarketDataSubscription(id, symbol, priceBand, stringToIntCache);
    }

    @Override
    public long id() {
        return id;
    }

    @Override
    public Venue market() {
        return Venue.BARX;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public boolean fullRefresh() {
        return DEFAULT_FULL_REFRESH;
    }

    @Override
    public boolean aggregateBook() {
        return DEFAULT_AGGREGATE_BOOK;
    }

    @Override
    public int marketDepth() {
        return DEFAULT_MARKET_DEPTH;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return stringToIntCache;
    }

    @Override
    public long orderQty() {
        return priceBand;
    }

    @Override
    public String toString() {
        return "BarxMarketDataSubscription{" +
                "id=" + id +
                ", symbol='" + symbol + '\'' +
                ", instrumentKey=" + instrumentKey +
                ", orderQty='" + priceBand + '\'' +
                '}';
    }
}
