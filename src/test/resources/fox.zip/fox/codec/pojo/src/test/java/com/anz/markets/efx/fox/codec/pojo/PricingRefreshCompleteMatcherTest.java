package com.anz.markets.efx.fox.codec.pojo;

import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.pojo.matcher.PricingRefreshCompleteMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.codec.Header;

import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class PricingRefreshCompleteMatcherTest {
    private Predicate<PricingRefreshComplete> predicate = Matchers.isA(PricingRefreshComplete.class);
    private PricingRefreshCompleteMatcher matcher = new PricingRefreshCompleteMatcher() {

        @Override
        public Matcher<PricingRefreshCompleteMatcher, Header> header() {
            return matcher -> andThen(translate(pricingRefreshComplete -> pricingRefreshComplete.header, matcher));
        }

        @Override
        public Matcher<PricingRefreshCompleteMatcher, PricingRefreshComplete.Body> body() {
            return matcher -> andThen(translate(pricingRefreshComplete -> pricingRefreshComplete.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof PricingRefreshComplete && predicate.test((PricingRefreshComplete) o);
        }

        private PricingRefreshCompleteMatcher andThen(final Predicate<? super PricingRefreshComplete> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final PricingRefreshComplete pricingRefreshComplete = SorMessage.pricingRefreshComplete(
                new MessageHeader(2, 3),
                new PricingRefreshComplete.Body(5, true));
        assertTrue(matcher.test(pricingRefreshComplete));
        assertNotNull(matcher.body());
    }
}
