#!/bin/bash

set -e

function die {
    echo "$1\nUsage: ./create-release-branch.sh -u|--svnusername <svn_username> -p|--svnpassword <svn_password> [-n|--branchname <branch_name>] [-r|--svnrevision <svn_revision>] [-s|--startsnapshotbuild]"
    exit -1
}

echo "JAVA_HOME: $JAVA_HOME"
export M2_HOME=/app/axle/teamcity/tools/apache-maven-3.0.4
export PATH=$M2_HOME/bin:$PATH
FORCE=false

while [[ $# > 0 ]]
do
key="$1"
value="$2"
case $key in
    -u|--svnusername)
    SVN_USERNAME="$value"
    shift
    ;;
    -p|--svnpassword)
    SVN_PASSWORD="$value"
    shift
    ;;
    -r|--svnrevision)
    SVN_REVISION="$value"
    shift
    ;;
    -n|--branchname)
    BRANCH_NAME="$value"
    shift
    ;;
    -s|--startsnapshotbuild)
    START_SNAPSHOT_BUILD=true
    # No additional shift as this option requires no arguments
    ;;
    -f|--force)
    FORCE=true
    # No additional shift as this option requires no arguments
    ;;
    *)
      # unknown option
      die "Unknown option $key"
 esac
 shift
done


if [ -z "${SVN_USERNAME}" ] ; then
  die "svn username not provided"
fi
if [ -z "${SVN_PASSWORD}" ] ; then
  die "svn password not provided"
fi

SCRIPT_NAME=$0

echo Setting up SVN with username and password
svn="/app/axle/svn/bin/svn --no-auth-cache --username $SVN_USERNAME --password $SVN_PASSWORD"
SVN_ROOT_URL=https://subversion.apps.anz/svn/markets-fx/axle
SVN_TRUNK_URL=$SVN_ROOT_URL/axle/trunk

FROM_SVN_URL="${SVN_TRUNK_URL}"

REVISION_FLAG=''
[ -n "${SVN_REVISION}" ] && REVISION_FLAG="-r${SVN_REVISION}"


#############################################################################
## setup teamcity project to point to this release branch
curl="curl --basic --user restapi:password --request"
TC_REST_API=http://daxa009s.unix.anz:9191/teamcity/httpAuth/app/rest

##############################################################################
### work out the branch name
if [ -z $BRANCH_NAME ]; then
    echo "Getting the current name of the trunk project.  Must contain the word 'trunk'"
    RESPONSE=$($curl GET $TC_REST_API/projects/AXLE/name)
    [[ $RESPONSE =~ 'Error has occurred during request processing' ]] && echo "Error whilst attempting to get the name of the trunk project. Response: $RESPONSE" && exit -1
    TRUNK_TC_PROJECT_NAME=$RESPONSE
    [[ ! $TRUNK_TC_PROJECT_NAME =~ "trunk" ]] && echo "Trunk TeamCity project name must contain the word 'trunk' but was $TRUNK_TC_PROJECT_NAME" && exit -1
    BRANCH_NAME=$(echo "$TRUNK_TC_PROJECT_NAME" | sed 's/trunk/branch/')
fi
BRANCH_NAME_COMPACT=$(echo "$BRANCH_NAME" | sed 's/\.//g')

##############################################################################
## check to see whether the branch already exists
TO_BRANCH_URL=$SVN_ROOT_URL/axle/branches/$BRANCH_NAME
TO_BRANCH_WORKSPACE_URL=$TO_BRANCH_URL.workspace

echo Check that branch WORKSPACE doesn\'t already exist.
if [ `$svn info $TO_BRANCH_WORKSPACE_URL 2>&1 | grep 'Node Kind: directory' | wc -l` -eq 1 ] ; then
  if [ "$FORCE" = true ] ; then
    echo "Workspace branch already exists.  Because the force flag was declared, automatically deleting $TO_BRANCH_WORKSPACE_URL"
    $svn -m"$SCRIPT_NAME - Deleting branch $TO_BRANCH_WORKSPACE_URL as force flag was specified" rm $TO_BRANCH_WORKSPACE_URL 2>&1
  else
    echo "ERROR: Branch already exists. Please delete this branch manually if you wish to recreate - svn delete $TO_BRANCH_WORKSPACE_URL"
    exit -1
  fi
fi

echo Check that branch doesn\'t already exist.
if [ `$svn info $TO_BRANCH_URL 2>&1 | grep 'Node Kind: directory' | wc -l` -eq 1 ] ; then
  if [ "$FORCE" = true ] ; then
    echo "Branch already exists.  Because the force flag was declared, automatically deleting $TO_BRANCH_URL"
    $svn -m"$SCRIPT_NAME - Deleting branch $TO_BRANCH_URL as force flag was specified" rm $TO_BRANCH_URL 2>&1
  else
    echo "ERROR: Branch already exists. Please delete this branch manually if you wish to recreate - svn delete $TO_BRANCH_URL"
    exit -1
  fi
fi

#############################################################################
# svn create a 'workspace' branch from trunk
echo Creating branch. Performing svn copy from $FROM_SVN_URL ...to... $TO_BRANCH_WORKSPACE_URL
$svn copy -m"$SCRIPT_NAME - Creating branch for $RELEASE_VERSION" $REVISION_FLAG $FROM_SVN_URL $TO_BRANCH_WORKSPACE_URL || (echo "ERROR: Could not create branch" && exit -1)

#############################################################################
# check-out the branch so we can update the poms
echo Checking out branch so that we can set versions in the maven poms.
rm -rf workspace
$svn co -q $TO_BRANCH_WORKSPACE_URL workspace || (echo "ERROR: Could not checkout trunk - $TO_BRANCH_WORKSPACE_URL" && exit -1)
cd workspace
$svn info

#############################################################################
# Update maven version in the poms
POM_VERSION=$BRANCH_NAME-SNAPSHOT
echo Updating all poms version to $POM_VERSION
mvn versions:set -DgenerateBackupPoms=false -Dhttps.protocols=TLSv1 -Dmaven.wagon.http.ssl.insecure=true -Dmaven.wagon.http.ssl.allowall=true -DnewVersion=$POM_VERSION -q || (echo "ERROR: Could not update poms to Release Candidate version." && exit -1)

##############################################################################
## Commit back into repo
echo Committing pom changes
$svn commit -m"$SCRIPT_NAME - Updated pom version to $POM_VERSION" . || (echo "ERROR: Could not commit poms." && exit -1)

##############################################################################
## Move the workspace branch to the true branch name, this will effecively remove the workspace branch
echo Moving the workspace branch $TO_BRANCH_WORKSPACE_URL into the true branch $TO_BRANCH_URL
$svn -m"Moving the workspace branch $TO_BRANCH_WORKSPACE_URL into the true branch $TO_BRANCH_URL" mv $TO_BRANCH_WORKSPACE_URL $TO_BRANCH_URL

##############################################################################
### check to see if project exists with id=branchyyyymmdd
echo "Checking to see if TeamCity build with id $BRANCH_NAME_COMPACT already exists"
RESPONSE=$($curl GET $TC_REST_API/projects/${BRANCH_NAME_COMPACT})
if [[ ! $RESPONSE =~ "Error has occurred during request processing (Not Found)" ]]; then
  if [ "$FORCE" = true ] ; then
    echo "TeamCity project already exists: $BRANCH_NAME_COMPACT. Because the force flag was declared, attempting delete"
    RESPONSE=$($curl DELETE $TC_REST_API/projects/$BRANCH_NAME_COMPACT)
    echo "Checking whether there was an error during call to TeamCity."
    [[ $RESPONSE =~ "Error has occurred during request processing" ]] && echo "Error occurred whilst trying to delete existing TeamCity project $BRANCH_NAME_COMPACT" && echo $RESPONSE && exit -1
  else
    echo "ERROR: Project with id='$BRANCH_NAME_COMPACT' already exists, please manually delete this from TeamCity and try again"
    exit -1
  fi
fi


##############################################################################
### copy teamcity project with id AXLE (name=trunk.yyyy.mm.dd) to new teamcity project with id branchyyyymmdd (name=branch.yyyy.mm.dd)
RESPONSE=$($curl POST $TC_REST_API/projects --header "Content-Type: application/xml" --data-binary "<newProjectDescription name='$BRANCH_NAME' id='$BRANCH_NAME_COMPACT' copyAllAssociatedSettings='true'><parentProject locator='_Root'/><sourceProject locator='id:AXLE'/></newProjectDescription>")
[[ $RESPONSE =~ 'Error has occurred during request processing' ]] && echo "Error whilst attempting to create project with id='$BRANCH_NAME_COMPACT'.  Response: $RESPONSE" && exit -1
echo "TeamCity project $BRANCH_NAME successfully created"

#############################################################################
# Update teamcity branch svn
#
echo "Renaming ID of VCS root"
RESPONSE=$($curl PUT $TC_REST_API/vcs-roots/${BRANCH_NAME_COMPACT}_AxleTrunk/id --header "Content-Type: text/plain" --data "${BRANCH_NAME_COMPACT}_svn")
[[ $RESPONSE =~ 'Error has occurred during request processing' ]] && echo "Error whilst attempting to update SVN ID to $BRANCH_NAME_COMPACT.  Response: $RESPONSE" && exit -1

echo "Renaming NAME of VCS root"
RESPONSE=$($curl PUT $TC_REST_API/vcs-roots/${BRANCH_NAME_COMPACT}_SVN/name --header "Content-Type: text/plain" --data "${BRANCH_NAME_COMPACT}_svn")
[[ $RESPONSE =~ 'Error has occurred during request processing' ]] && echo "Error whilst attempting to update SVN name to $BRANCH_NAME_COMPACT.  Response: $RESPONSE" && exit -1

echo "Updating URL of VCS root"
RESPONSE=$($curl PUT $TC_REST_API/vcs-roots/${BRANCH_NAME_COMPACT}_SVN/properties/url --header "Content-Type: text/plain" --data "$TO_BRANCH_URL")
[[ $RESPONSE =~ 'Error has occurred during request processing' ]] && echo "Error whilst attempting to update SVN url to $TO_BRANCH_URL'.  Response: $RESPONSE" && exit -1

#############################################################################
# Kick off a teamCity SNAPSHOT build
#
if [ -n "$START_SNAPSHOT_BUILD" ]; then
    echo "Triggering snapshot build of new branch"
    RESPONSE=$($curl POST $TC_REST_API/buildQueue --header "Content-Type:application/xml" --data-binary "<build><buildType id=\"${BRANCH_NAME_COMPACT}_Snapshot\"/></build>")
    [[ $RESPONSE =~ 'Error has occurred during request processing' ]] && echo "Error whilst attempting trigger a build of $BRANCH_NAME_COMPACT'.  Response: $RESPONSE" && exit -1
fi

exit 0