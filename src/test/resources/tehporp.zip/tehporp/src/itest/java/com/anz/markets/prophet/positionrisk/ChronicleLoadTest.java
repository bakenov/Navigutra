package com.anz.markets.prophet.positionrisk;

import com.anz.axle.direct.performance.MetricReporter;
import com.anz.axle.direct.performance.TeamcityReporterFactory;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersisterConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReader;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.RawBytesMutable;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.marketdata.MarketDataReader;
import com.anz.markets.prophet.metrics.Metric;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Snapshot;
import com.google.common.collect.Maps;
import org.jetbrains.annotations.NotNull;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.LockSupport;
import java.util.function.Consumer;

public class ChronicleLoadTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleLoadTest.class);
    private static final int LOG_EVERY = 10_000, WARMUP = 10_000;
    private final MetricReporter metricReporter = new TeamcityReporterFactory().createMetricReporter();
    private final Metric metric = new Metric();
    private final int TRADE_LENGTH = 50, MD_LENGTH = 10_000;
    private static String basePath = "./chron_load";

    @AfterClass
    @BeforeClass
    public static void clean() {
        LOGGER.warn("Cleanup Chronicle {}", basePath);
        ChronicleGate.deleteNow(basePath);
    }

    @Rule
    public TestName testName = new TestName();

    @Test
    public void writeAndReadFullSpeed() throws IOException, InterruptedException {
        writeAndRead(900_000, 0, WriteBack.NO_WRITEBACK, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadFullSpeedWriteBack() throws IOException, InterruptedException {
        writeAndRead(900_000, 0, WriteBack.WRITEBACK_METRICS, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadSlowProducer() throws IOException, InterruptedException {
        writeAndRead(900_000, 1000, WriteBack.NO_WRITEBACK, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadSlowProducerLargerMD() throws IOException, InterruptedException {
        writeAndRead(900_000, 1000, WriteBack.NO_WRITEBACK, LegacyChronicleConfig.ChronicleType.INDEXED, 10);
    }

    @Test
    public void writeAndReadSlowProducerWriteBack() throws IOException, InterruptedException {
        writeAndRead(900_000, 1000, WriteBack.WRITEBACK_METRICS, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadSlowProducerWriteBack2Readers() throws IOException, InterruptedException {
        writeAndRead2Readers(900_000, 1000, false, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadSlowProducerWriteBack2ReadersMetricsWaitForStarfish() throws IOException, InterruptedException {
        writeAndRead2Readers(900_000, 1000, true, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadSlowerProducerWriteBack() throws IOException, InterruptedException {
        writeAndRead(900_000, 10_000, WriteBack.WRITEBACK_METRICS, LegacyChronicleConfig.ChronicleType.INDEXED);
    }

    @Test
    public void writeAndReadSlowProducerByteArray() throws IOException, InterruptedException {
        final LegacyChronicleConfig.ChronicleType chronicleType = LegacyChronicleConfig.ChronicleType.INDEXED;
        final int pauseWriterNS = 10_000;
        final int reps = 90_000;

        final Histogram sentToReceivedTrade = metric.getHistogram("sentToReceivedTrade");
        final Histogram sentToReceivedMD = metric.getHistogram("sentToReceivedMD");
        final CountDownLatch done = new CountDownLatch(1);

        LOGGER.warn("Output: {}", basePath);
        final LegacyChroniclePersister legacyChroniclePersister = new LegacyChroniclePersister(LegacyChroniclePersisterConfig.testIn(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, chronicleType), true);

        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        final ByteArrayReader tradeReader = new ByteArrayReader(sentToReceivedTrade);
        map.put(MessageType.TRADE, tradeReader);
        final ByteArrayReader mdReader = new ByteArrayReader(sentToReceivedMD);
        map.put(MessageType.MARKET_DATA_SNAPSHOT, mdReader);
        final LegacyChronicleReaderConfig readerConfig;
        readerConfig = LegacyChronicleReaderConfig.metrics(basePath, chronicleType);
        final LegacyChronicleReader LegacyChronicleReader = new LegacyChronicleReader(Executors.newSingleThreadExecutor(), new ChronicleObjectReaderMulti(map), readerConfig);
        LOGGER.warn("Start reading");

        final RawBytesMutable rawBytes = new RawBytesMutable();
        final ByteBuffer buffer = ByteBuffer.wrap(rawBytes.getByteArray());

        final Thread writer = new Thread() {
            @Override
            public void run() {
                LOGGER.warn("Start writing");
                long startTime = System.currentTimeMillis();
                for (int i = -WARMUP; i < reps; i++) {
                    final long nanoTime = System.nanoTime();
                    buffer.position(0);
                    buffer.putLong(nanoTime);
                    if (i % 10 == 0) {
                        rawBytes.setLength(TRADE_LENGTH);
                        rawBytes.setMessageType(MessageType.TRADE);
                        legacyChroniclePersister.consumeRawBytes().accept(rawBytes);
                    } else {
                        rawBytes.setLength(MD_LENGTH);
                        rawBytes.setMessageType(MessageType.MARKET_DATA_SNAPSHOT);
                        legacyChroniclePersister.consumeRawBytes().accept(rawBytes);
                    }
                    if (i > 0) {
                        // LockSupport.parkNanos waits for much too long on windows
                        // TODO: scheduleAtFixedRate or use Allan's amazing rate limiter?
                        LockSupport.parkNanos(pauseWriterNS);
                    }
                    if (i % LOG_EVERY == 0) {
                        LOGGER.info("Written {}", i);
                    }
                }
                long elapsed = System.currentTimeMillis() - startTime;
                LOGGER.warn("Wrote {} entities in {} secs at {}/sec", WARMUP + reps, elapsed / 1000, ((WARMUP + reps) * 1000) / elapsed);
                try {
                    legacyChroniclePersister.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                done.countDown();
            }
        };

        Thread.sleep(100);
        LOGGER.warn("Start writing");
        writer.start();
        Thread.sleep(500);

        long startTime = System.currentTimeMillis();
        while (true) {
            Thread.sleep(100);
            if (tradeReader.count + mdReader.count >= (WARMUP + reps)) {
                break;
            }
        }
        long elapsed = System.currentTimeMillis() - startTime;
        final int count = tradeReader.count + mdReader.count;
        if (0 == (elapsed / 1000)) {
            elapsed = 1000;
        }
        LOGGER.warn("Read  {} entities in {} secs at {}/sec", count, elapsed / 1000, count / (elapsed / 1000));
        LegacyChronicleReader.close();
        done.await();

        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedMD", sentToReceivedMD)));
        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedTrade", sentToReceivedTrade)));
        metric.getMetricRegistry().remove("sentToReceivedTrade");
        metric.getMetricRegistry().remove("sentToReceivedMD");
    }

    public void writeAndRead(final int reps,
                             final int pauseWriterNS,
                             WriteBack writeBackToInChronicle,
                             LegacyChronicleConfig.ChronicleType chronicleType) throws IOException, InterruptedException {
        writeAndRead(reps, pauseWriterNS, writeBackToInChronicle, chronicleType, 1);
    }

    public void writeAndRead(final int reps,
                             final int pauseWriterNS,
                             WriteBack writeBackToInChronicle,
                             LegacyChronicleConfig.ChronicleType chronicleType,
                             int marketDataDepth) throws IOException, InterruptedException {
        // TODO: is codahale performant enough for this test?
        final Histogram sentToReceivedTrade = metric.getHistogram("sentToReceivedTrade");
        final Histogram sentToReceivedMD = metric.getHistogram("sentToReceivedMD");
        final CountDownLatch done = new CountDownLatch(1);

        LOGGER.warn("Output: {}", basePath);
        final LegacyChroniclePersister legacyChroniclePersister = new LegacyChroniclePersister(LegacyChroniclePersisterConfig.testIn(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, chronicleType), true);

        final TradeConsumer tradeConsumer = new TradeConsumer(sentToReceivedTrade);
        final MarketDataConsumer marketDataConsumer = new MarketDataConsumer(sentToReceivedMD);
        final LegacyChronicleReader LegacyChronicleReader = createReader(writeBackToInChronicle, chronicleType, basePath, tradeConsumer, marketDataConsumer);
        LOGGER.warn("Start reading");

        Thread writer = createWritingThread(reps, pauseWriterNS, done, legacyChroniclePersister, marketDataDepth);
        Thread.sleep(100);
        LOGGER.warn("Start writing");
        writer.start();

        waitForReader(reps, tradeConsumer, marketDataConsumer);
        LegacyChronicleReader.close();
        done.await();

        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedMD", sentToReceivedMD)));
        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedTrade", sentToReceivedTrade)));

        metric.getMetricRegistry().remove("sentToReceivedTrade");
        metric.getMetricRegistry().remove("sentToReceivedMD");
    }

    private Percentiles percentiles(final String name, final Histogram hist) {
        return new HistogramToPercentilesAdapter(name, hist);
    }

    public void writeAndRead2Readers(final int reps,
                                     final int pauseWriterNS,
                                     final boolean delay2ndReader,
                                     LegacyChronicleConfig.ChronicleType chronicleType) throws IOException, InterruptedException {
        // TODO: is codahale performant enough for this test?
        final Histogram sentToReceivedTrade = metric.getHistogram("sentToReceivedTrade");
        final Histogram sentToReceivedMD = metric.getHistogram("sentToReceivedMD");
        final Histogram sentToReceivedTrade2 = metric.getHistogram("sentToReceivedTrade2");
        final Histogram sentToReceivedMD2 = metric.getHistogram("sentToReceivedMD2");
        final CountDownLatch done = new CountDownLatch(1);

        LOGGER.warn("Output: {}", basePath);
        final LegacyChroniclePersister legacyChroniclePersister = new LegacyChroniclePersister(LegacyChroniclePersisterConfig.testIn(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, chronicleType), true);

        final TradeConsumer tradeConsumer = new TradeConsumer(sentToReceivedTrade);
        final MarketDataConsumer marketDataConsumer = new MarketDataConsumer(sentToReceivedMD);
        final LegacyChronicleReader LegacyChronicleReader = createReader(WriteBack.WRITEBACK_STARFISH_OUT, chronicleType, basePath, tradeConsumer, marketDataConsumer);
        TradeConsumer tradeConsumer2 = new TradeConsumer(sentToReceivedTrade2);
        MarketDataConsumer marketDataConsumer2 = new MarketDataConsumer(sentToReceivedMD2);
        final WriteBack writeback2 = delay2ndReader ? WriteBack.WRITEBACK_METRICS_WAIT : WriteBack.WRITEBACK_METRICS;
        LegacyChronicleReader LegacyChronicleReader2 = createReader(writeback2, chronicleType, basePath, tradeConsumer2, marketDataConsumer2);
        LOGGER.warn("Start reading");

        Thread writer = createWritingThread(reps, pauseWriterNS, done, legacyChroniclePersister, 1);
        Thread.sleep(100);
        LOGGER.warn("Start writing");
        writer.start();
        Thread.sleep(500);

        waitForReader(reps, tradeConsumer, marketDataConsumer);
        waitForReader(reps, tradeConsumer2, marketDataConsumer2);
        LegacyChronicleReader.close();
        LegacyChronicleReader2.close();
        done.await();

        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedMD", sentToReceivedMD)));
        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedTrade", sentToReceivedTrade)));
        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedMD2", sentToReceivedMD2)));
        metricReporter.appendHistograms(Arrays.asList(percentiles(testName.getMethodName() + ".sentToReceivedTrade2", sentToReceivedTrade2)));
        metric.getMetricRegistry().remove("sentToReceivedTrade");
        metric.getMetricRegistry().remove("sentToReceivedMD");
        metric.getMetricRegistry().remove("sentToReceivedTrade2");
        metric.getMetricRegistry().remove("sentToReceivedMD2");
    }

    @NotNull
    private LegacyChronicleReader createReader(final WriteBack writeBackToInChronicle,
                                               final LegacyChronicleConfig.ChronicleType chronicleType,
                                               final String basePath,
                                               final TradeConsumer tradeConsumer,
                                               final MarketDataConsumer marketDataConsumer) throws IOException {
        final TradeReader tr = new TradeReader(tradeConsumer);
        final MarketDataReader mdr = new MarketDataReader(Collections.singletonList(marketDataConsumer));
        EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.TRADE, tr);
        map.put(MessageType.MARKET_DATA_SNAPSHOT, mdr);
        final LegacyChronicleReaderConfig readerConfig;
        if (writeBackToInChronicle == WriteBack.WRITEBACK_METRICS) {
            readerConfig = LegacyChronicleReaderConfig.metrics(basePath, chronicleType);
        } else if (writeBackToInChronicle == WriteBack.WRITEBACK_METRICS_WAIT) {
            readerConfig = LegacyChronicleReaderConfig.metrics(basePath, chronicleType);
        } else {
            readerConfig = LegacyChronicleReaderConfig.readOnly(basePath, chronicleType);
        }
        return new LegacyChronicleReader(Executors.newSingleThreadExecutor(), new ChronicleObjectReaderMulti(map), readerConfig);
    }

    private void waitForReader(final int reps,
                               final TradeConsumer tradeConsumer,
                               final MarketDataConsumer marketDataConsumer) throws InterruptedException {
        long startTime = System.currentTimeMillis();
        while (true) {
            Thread.sleep(100);
            if (tradeConsumer.count + marketDataConsumer.count >= (WARMUP + reps)) {
                break;
            }
        }
        long elapsed = System.currentTimeMillis() - startTime;
        final int count = tradeConsumer.count + marketDataConsumer.count;
        if (0 == (elapsed / 1000)) {
            elapsed = 1000;
        }
        LOGGER.warn("Read  {} entities in {} secs at {}/sec", count, elapsed / 1000, count / (elapsed / 1000));
    }

    @NotNull
    private Thread createWritingThread(final int reps,
                                       final int pauseWriterNS,
                                       final CountDownLatch done,
                                       final LegacyChroniclePersister LegacyChroniclePersister,
                                       final int marketDataDepth) {
        final String[] IDS = new String[WARMUP + reps];
        for (int i = 0; i < IDS.length; i++) {
            IDS[i] = Integer.toString(i);
        }
        final TradeImpl tradeToWrite = (TradeImpl) MidRateTestHelper.createTrade(Instrument.AUDUSD, OrderSide.BID, 1000, 1.345);
        final MarketData marketDataToWrite = MidRateTestHelper.createMarketData(marketDataDepth);
        return new Thread() {
            @Override
            public void run() {
                LOGGER.warn("Start writing");
                long startTime = System.currentTimeMillis();
                for (int i = -WARMUP; i < reps; i++) {
                    final long nanoTime = System.nanoTime();
                    if (i % 10 == 0) {
                        tradeToWrite.setOrderId(IDS[i + WARMUP]);
                        tradeToWrite.setInceptionTimeNanos(nanoTime);
                        tradeToWrite.setFilledQuantity(i);
                        LegacyChroniclePersister.consumerTrade().accept(tradeToWrite);
                    } else {
                        final MarketDataSnapshotImpl marketDataSnapshot = (MarketDataSnapshotImpl) marketDataToWrite;
                        marketDataSnapshot.setEventId(i < 0 ? "" : IDS[i + WARMUP]);
                        marketDataSnapshot.setExternalEventTimeNS(nanoTime);
                        LegacyChroniclePersister.consumerMarketDataMessage().accept(marketDataToWrite);
                    }
                    if (i > 0) {
                        // LockSupport.parkNanos waits for much too long on windows
                        // TODO: scheduleAtFixedRate or use Allan's amazing rate limiter?
                        LockSupport.parkNanos(pauseWriterNS);
                    }
                    if (i % LOG_EVERY == 0) {
                        LOGGER.info("Written {}", i);
                    }
                }
                long elapsed = System.currentTimeMillis() - startTime;
                LOGGER.warn("Wrote {} entities in {} secs at {}/sec", WARMUP + reps, elapsed / 1000, ((WARMUP + reps) * 1000) / elapsed);
                try {
                    LegacyChroniclePersister.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                done.countDown();
            }
        };
    }

    private class TradeConsumer implements Consumer<Trade> {
        private final Histogram sentToReceivedTrade;
        public volatile int count = 0;

        public TradeConsumer(Histogram sentToReceivedTrade) {
            this.sentToReceivedTrade = sentToReceivedTrade;
        }

        @Override
        public void accept(Trade it) {
            ++count;
            if (it.getFilledQuantity() > 0) {
                sentToReceivedTrade.update(System.nanoTime() - it.getInceptionTimeNanos());
            }
            if (count % LOG_EVERY == 0) {
                LOGGER.info("Read {} trades", count);
            }
        }
    }

    private class MarketDataConsumer implements Consumer<MarketData> {
        private final Histogram sentToReceivedMD;
        public volatile int count = 0;

        public MarketDataConsumer(Histogram sentToReceivedMD) {
            this.sentToReceivedMD = sentToReceivedMD;
        }

        @Override
        public void accept(final MarketData it) {
            ++count;
            MarketDataSnapshot snapshot = (MarketDataSnapshot) it;
            if (snapshot.getEventId().length() > 0) { // ie exclude warmup
                sentToReceivedMD.update(System.nanoTime() - snapshot.getExternalEventTimeNS());
            }
            if (count % LOG_EVERY == 0) {
                LOGGER.info("Read {} mds", count);
            }
        }
    }

    private class ByteArrayReader implements ChronicleObjectReader {
        private final ByteBuffer buffer = ByteBuffer.allocate(MD_LENGTH + 1);
        private final Histogram sentToReceived;
        public volatile int count = 0;

        private ByteArrayReader(final Histogram sentToReceived) {
            this.sentToReceived = sentToReceived;
        }

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            ++count;
            if (count > 0) { // ie exclude warmup
                bytes.read(buffer.array());
                buffer.position(0);
                final long sent = buffer.getLong();
                sentToReceived.update(System.nanoTime() - sent);
            }
            if (count % LOG_EVERY == 0) {
                LOGGER.info("Read {}", count);
            }
        }
    }

    private enum WriteBack {
        NO_WRITEBACK,
        WRITEBACK_METRICS,
        WRITEBACK_METRICS_WAIT,
        WRITEBACK_STARFISH_OUT
    }

    // TODO: move to metrics
    private class HistogramToPercentilesAdapter implements Percentiles {
        private final Histogram hist;
        private final Snapshot snapshot;
        private final String name;

        public HistogramToPercentilesAdapter(final String name, final Histogram hist) {
            this.name = name;
            this.hist = hist;
            this.snapshot = hist.getSnapshot();
        }

        @Override
        public double getPercentile(final double percentile) {
            return snapshot.getValue(percentile / 100.0);
        }

        @Override
        public double getMin() {
            return snapshot.getMin();
        }

        @Override
        public double getMean() {
            return snapshot.getMean();
        }

        @Override
        public double getMax() {
            return snapshot.getMax();
        }

        @Override
        public long getCount() {
            return hist.getCount();
        }

        @Override
        public String getName() {
            return name;
        }
    }

}
