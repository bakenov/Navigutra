package com.anz.axle.lg.adapter.d3.newsubscription;

import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import com.anz.markets.efx.ngaro.api.Tenor;

public interface D3TenorLookup extends Function<Tenor, String> {
    static D3TenorLookup fromMap(final Map<Tenor, String> tenorToD3TenorNameMap) {
        Objects.requireNonNull(tenorToD3TenorNameMap);
        return tenor -> {
            final String d3TenorName = tenorToD3TenorNameMap.get(tenor);
            if (d3TenorName == null) {
                throw new IllegalArgumentException("Cannot find D3TenorName for given tenor" + tenor + ". Please configure mapping for this tenor in d3-default.properties");
            }
            return d3TenorName;
        };
    }
}
