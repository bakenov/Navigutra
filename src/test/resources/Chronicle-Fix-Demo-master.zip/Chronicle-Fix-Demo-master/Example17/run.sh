#!/bin/bash

mvn exec:exec

