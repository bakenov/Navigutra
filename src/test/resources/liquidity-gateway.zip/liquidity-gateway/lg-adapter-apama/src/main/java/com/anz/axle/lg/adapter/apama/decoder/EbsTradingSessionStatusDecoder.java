package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.EbsTradingSessionStatus;
import com.anz.axle.lg.config.PricingEncoderLookup;

/**
 * Decodes Apama events as defined by {@link com.anz.axle.lg.adapter.apama.event.EbsTradingSessionStatus}
 */
public final class EbsTradingSessionStatusDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsTradingSessionStatusDecoder.class);

    static final long STATUS_OPEN = 2;
    static final long STATUS_CLOSED = 3;
    static final long STATUS_UP = 1003;
    static final long STATUS_DOWN = 1004;

    private final PricingEncoderLookup pricingEncoderLookup;
    private final String transport;

    public EbsTradingSessionStatusDecoder(final PricingEncoderLookup pricingEncoderLookup, final String transport) {
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.transport = Objects.requireNonNull(transport);
    }

    @Override
    public void decode(final Event event) {
        final String eventTransport = event.getField(EbsTradingSessionStatus.FIELD_TRANSPORT);
        if (transport.equals(eventTransport)) {
            final long status = event.getField(EbsTradingSessionStatus.FIELD_TRADING_SESSION_STATUS);
            if (status ==  STATUS_CLOSED | status == STATUS_DOWN) {
                LOGGER.info("Received closed/down trading session status for {}", eventTransport);
                pricingEncoderLookup.clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_DISCONNECTED);
            }
        }
    }
}
