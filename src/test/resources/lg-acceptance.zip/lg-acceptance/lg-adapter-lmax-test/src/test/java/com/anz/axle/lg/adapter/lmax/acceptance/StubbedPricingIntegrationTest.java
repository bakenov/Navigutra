package com.anz.axle.lg.adapter.lmax.acceptance;

import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MDEntryType;
import org.fix4j.spec.fix50sp2.fieldtype.MDUpdateAction;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.PricingFixSessionHelper;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;

public class StubbedPricingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StubbedPricingIntegrationTest.class);
    private static final String FIX_DATA_DICTIONARY_FILE = "conf/FIX42-lmax.xml";
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);


    final static String SYMBOL = "AUD/USD";
    final static double QTY = 16;
    final static double ORDER_QTY_CONTRACT_SIZE = 1;

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private MatchingSession pricingServer;
    private AcceptanceContext acceptanceContext;
    private PricingFixSessionHelper pricingFixSessionHelper;

    final private String senderCompId = "GB:lg-lmax";
    final private Venue marketId = Venue.LMAX;

    @Before
    public void setup(){
		LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        setPersistStorePath("lmax", testName.getMethodName());

        System.getProperties().putAll(
                StringUtils.parseMap("appName:lg-lmax" + ",lmax.fix.pricing.order.qty.contract.size:"+ORDER_QTY_CONTRACT_SIZE));

        pricingFixSessionHelper = new PricingFixSessionHelper("lmax", "GB_LMAX_MD_S", "GB_LMAX_MD_T", "FIX.4.2", FIX_DATA_DICTIONARY_FILE);

        application = new Application("lg-lmax-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        if (pricingServer != null) pricingServer.shutdown();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private Predicate<Object> defaultSnapshotRefreshMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
            .entries().countEquals(2)
            .hops().hasAny()
            .hops().countAtLeast(2);
    }

    private Predicate<Object> defaultIncrementalRefreshMessageMatcher() {
        return IncrementalRefreshMatcher.build()
            .body().matches(IncrementalRefreshMatcher.senderCompId().eq(senderCompId))
            .body().matches(IncrementalRefreshMatcher.marketId().eq(marketId))
            .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
//                .entries().countEquals(4)
            .hops().hasAny()
            .hops().countAtLeast(2);
    }

    private Predicate<Object> emptySnapshotMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
            .entries().hasNone();
    }

    private final FixMessage snapshotRefreshFixMessageForTicker(final String requestId) {
        //<20171018-05:00:21.505, FIX.4.2:DATA_FIX_NY5ANZ_FIX->HSFX-FIX-BRIDGE, incoming>
        // (8=FIX.4.2|9=153|35=W|34=68|49=HSFX-FIX-BRIDGE|52=20171018-05:00:21.369|56=DATA_FIX_NY5ANZ_FIX|55=USD/JPY|268=1|269=2|270=112.251|271=0.0|272=20171018|273=01:00:20|274=2|10=174|)
        final String newEntryQuantityString1 = "16863000000.00";
        final String newEntryPriceString1 = "1.33627";

        return new FixMessageBuilder()
            .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATASNAPSHOTFULLREFRESH.getOrdinal())
            .withField(FieldTypes.MDReqID, requestId)
            .withField(FieldTypes.Symbol, SYMBOL)
            .withField(FieldTypes.Currency, "AUD")
            .withField(FieldTypes.NoMDEntries, 1)
            .withField(FieldTypes.MDEntryType, MDEntryType.Values.TRADE.getOrdinal())
            .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
            .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
            .withField(FieldTypes.MDEntryDate, "20170912")
            .build();
    }


    private final FixMessage defaultSnapshotRefreshFixMessage(final String requestId) {
        final String newEntryQuantityString1 = String.valueOf(QTY);
        final String newBIDEntryPriceString1 = "1.33627";
        final String newOFFEREntryPriceString1 = "1.33626";
        //(8=FIX.4.2|9=175|35=W|49=LMAXIBB-MD|56=anzmd1|34=45|52=20171122-22:46:55.804|22=8|48=3003|55=EUR/GBP|207=LMAX|262=402220076|
        // 268=2|
        // 269=0|270=0.88709|271=50|290=1|
        // 269=1|270=0.88727|271=60|290=1|
        // 10=072|)
        return new FixMessageBuilder()
            .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATASNAPSHOTFULLREFRESH.getOrdinal())
            .withField(FieldTypes.MDReqID, requestId)
            .withField(FieldTypes.Symbol, SYMBOL)
            .withField(FieldTypes.NoMDEntries, 2)

            .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
            .withField(FieldTypes.MDEntryPx, newBIDEntryPriceString1)
            .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
            .withField(FieldTypes.MDEntryPositionNo, 1)

            .withField(FieldTypes.MDEntryType, MDEntryType.Values.OFFER.getOrdinal())
            .withField(FieldTypes.MDEntryPx, newOFFEREntryPriceString1)
            .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
            .withField(FieldTypes.MDEntryPositionNo, 1)
            .build();
    }

    private final FixMessage defaultIncrementalRefreshFixMessage(String requestId) {
        final String newEntryQuantityString1 = String.valueOf(QTY);
        final String newEntryPriceString1 = "0.79122";
        //(8=FIX.4.2|9=203|35=X|49=LMAXIBB-MD|56=anzmd1|34=6524|52=20171122-23:20:13.150|262=402220076|
        // 268=2|
        // 279=2|269=1|55=EUR/GBP|48=3003|22=8|207=LMAX|290=1|                      <-- delete pos 1
        // 279=0|269=1|55=EUR/GBP|48=3003|22=8|207=LMAX|270=0.88707|271=25|290=1|   <-- add pos 1
        // 10=037|)
        return new FixMessageBuilder()
            .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATAINCREMENTALREFRESH.getOrdinal())
            .withField(FieldTypes.MDReqID, requestId)

            .withField(FieldTypes.NoMDEntries, 4)

            .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.NEW.getOrdinal())
            .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
            .withField(FieldTypes.Symbol, SYMBOL)
            .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
            .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
            .withField(FieldTypes.MDEntryPositionNo, 1)

            .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.DELETE.getOrdinal())
            .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
            .withField(FieldTypes.Symbol, SYMBOL)
            .withField(FieldTypes.MDEntryPositionNo, 1)

            .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.NEW.getOrdinal())
            .withField(FieldTypes.MDEntryType, MDEntryType.Values.OFFER.getOrdinal())
            .withField(FieldTypes.Symbol, SYMBOL)
            .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
            .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
            .withField(FieldTypes.MDEntryPositionNo, 1)

            .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.NEW.getOrdinal())
            .withField(FieldTypes.MDEntryType, MDEntryType.Values.OFFER.getOrdinal())
            .withField(FieldTypes.Symbol, SYMBOL)
            .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
            .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
            .withField(FieldTypes.MDEntryPositionNo, 2)
            .build();
    }

    @Test
    public void should_receive_snapshot_pricing_information_for_the_registered_ccy_pair() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataSnapshotRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataSnapshotRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
            .matching(defaultSnapshotRefreshMessageMatcher())
            .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                    LOGGER.info("WWWW-" + snapshotFullRefresh.toString());
                    Assert.assertEquals(marketId, snapshotFullRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), snapshotFullRefresh.body.instrumentId);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.body.senderCompId);
                    Assert.assertNull(snapshotFullRefresh.body.tradeDate);
                    Assert.assertEquals(2, snapshotFullRefresh.entries.size());

                    Assert.assertEquals(EntryType.BID, snapshotFullRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.get(0).mdEntryPositionNo);
                    Assert.assertEquals(1.33627, snapshotFullRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, snapshotFullRefresh.entries.get(0).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(QTY * ORDER_QTY_CONTRACT_SIZE, snapshotFullRefresh.entries.get(0).mdEntrySize, 1e-6);

                    Assert.assertEquals(EntryType.OFFER, snapshotFullRefresh.entries.get(1).mdEntryType);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.get(1).mdEntryPositionNo);
                    Assert.assertEquals(1.33626, snapshotFullRefresh.entries.get(1).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, snapshotFullRefresh.entries.get(1).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(QTY * ORDER_QTY_CONTRACT_SIZE, snapshotFullRefresh.entries.get(1).mdEntrySize, 1e-6);

                    Assert.assertEquals(2, snapshotFullRefresh.hops.size());
                    Assert.assertEquals("GB:LMAX", snapshotFullRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, snapshotFullRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(snapshotFullRefresh.body.sendingTime, snapshotFullRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(1).hopMessageId);
                }
        });
    }

    @Test
    public void should_receive_incremental_pricing_information_for_the_registered_ccy_pair() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataIncrementalRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultIncrementalRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataIncrementalRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                    LOGGER.info("XXXXX-" + incrementalRefresh.toString());
                    Assert.assertEquals(marketId, incrementalRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), incrementalRefresh.body.instrumentId);
                    Assert.assertEquals(senderCompId, incrementalRefresh.body.senderCompId);
                    Assert.assertNull(incrementalRefresh.body.tradeDate);
                    Assert.assertEquals(4, incrementalRefresh.entries.size());

                    Assert.assertEquals(EntryType.BID, incrementalRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(UpdateAction.NEW, incrementalRefresh.entries.get(0).mdUpdateAction);
                    Assert.assertEquals(1, incrementalRefresh.entries.get(0).mdEntryPositionNo);
                    Assert.assertEquals(0.79122, incrementalRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, incrementalRefresh.entries.get(0).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(QTY * ORDER_QTY_CONTRACT_SIZE, incrementalRefresh.entries.get(0).mdEntrySize, 1e-6);

                    Assert.assertEquals(EntryType.BID, incrementalRefresh.entries.get(1).mdEntryType);
                    Assert.assertEquals(UpdateAction.DELETE, incrementalRefresh.entries.get(1).mdUpdateAction);
                    Assert.assertEquals(1, incrementalRefresh.entries.get(1).mdEntryPositionNo);

                    Assert.assertEquals(EntryType.OFFER, incrementalRefresh.entries.get(2).mdEntryType);
                    Assert.assertEquals(UpdateAction.NEW, incrementalRefresh.entries.get(2).mdUpdateAction);
                    Assert.assertEquals(1, incrementalRefresh.entries.get(2).mdEntryPositionNo);
                    Assert.assertEquals(0.79122, incrementalRefresh.entries.get(2).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, incrementalRefresh.entries.get(2).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(QTY * ORDER_QTY_CONTRACT_SIZE, incrementalRefresh.entries.get(2).mdEntrySize, 1e-6);

                    Assert.assertEquals(EntryType.OFFER, incrementalRefresh.entries.get(3).mdEntryType);
                    Assert.assertEquals(UpdateAction.NEW, incrementalRefresh.entries.get(3).mdUpdateAction);
                    Assert.assertEquals(2, incrementalRefresh.entries.get(3).mdEntryPositionNo);
                    Assert.assertEquals(0.79122, incrementalRefresh.entries.get(3).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, incrementalRefresh.entries.get(3).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(QTY * ORDER_QTY_CONTRACT_SIZE, incrementalRefresh.entries.get(3).mdEntrySize, 1e-6);

                    Assert.assertEquals(2, incrementalRefresh.hops.size());
                    Assert.assertEquals("GB:LMAX", incrementalRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, incrementalRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(incrementalRefresh.body.sendingTime, incrementalRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, incrementalRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(1).hopMessageId);
                }
        });
    }

    @Test
    public void market_data_request_rejected() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataRequestReject is sent to adapter.
        pricingServer.send(pricingFixSessionHelper.marketDataRequestRejectFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }

    @Test
    public void should_send_empty_snapshot_when_marketdata_fix_disconnects() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataSnapshotRefresh processed message is available in pricing queue.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultSnapshotRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println("==============================================================");

        //When pricingServer (venue simulator) is shutdown
        pricingServer.shutdown();

        //Then empty snapshot messages should be available in pricing queue
        final PricingMessage pricingSnapShotMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(emptySnapshotMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println(pricingSnapShotMessage.toString());

        //pricingSnapShotMessage.accept(snapshotFullRefresh -> assertEquals("GB:lg-fastma", snapshotFullRefresh.body.senderCompId), incrementalRefresh -> {});
        System.out.println("==============================================================");
    }

    @Test
    public void should_not_send_empty_snapshot_when_not_logged_on() throws Exception {

        //Given pricingServer (venue simulator) is down
        //When adapter is not connected
        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }
}
