package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableSet;
import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.tools.FixToDTO;

import com.anz.axle.lg.adapter.SecurityTypeSymbolLookup;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.datamodel.DefaultExecutionReport;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.parsers.MessageParser;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingEncoderSupplier;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DbsExecutionReportHandlerTest {

    private static final String SENDER_COMP_ID = "GB:DBS";
    private static final String COMP_ID = "GB:lg-dbs";
    private static final String SPOT_SYMBOL = "USD/SGD";
    private static final String NDF_SYMBOL = "USD/KRW";
    private static final String CURRENCY = "USD";
    private static final String SPOT_NORMALISED_SYMBOL = "USDSGD";
    private static final String NDF_NORMALISED_SYMBOL = "USDKRW";
    private static final String SETTL_DATE = "20181116";
    private static final String MATURITY_DATE = "20181213";
    private static final long CURRENT_TIME = 34523453;

    private DbsExecutionReportHandler dbsExecutionReportHandler;
    private TradingEncoderSupplier encoderSupplier;
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport executionReport;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    @Before
    public void setUp() throws Exception {
        encoderSupplier = new PojoTradingEncoderSupplier(m -> executionReport = (com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport)m);
        dbsExecutionReportHandler = new DbsExecutionReportHandler(
                encoderSupplier,
                precisionClock,
                SENDER_COMP_ID,
                COMP_ID,
                System::currentTimeMillis,
                new SecurityTypeSymbolLookup(ImmutableSet.of(NDF_NORMALISED_SYMBOL)), sourceSequencer);

        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
    }

    @Test
    public void acceptExecutionReportMessage_SPOT_FILL() throws Exception {
        //when
        dbsExecutionReportHandler.accept(executionReportMessageFromFix_SPOT_FILL());

        //then
        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport.Body body = executionReport.body;

        assertThat(body.senderCompId, is(COMP_ID));
        assertThat(body.marketId, is(Venue.DBS.name()));
        assertThat(body.symbol, is(SPOT_NORMALISED_SYMBOL));
        assertThat(body.securityType, is(SecurityType.FXSPOT));
        assertThat(body.ordStatus, is(OrderStatus.FILLED));
        assertThat(body.side, is(Side.SELL));
        assertThat(body.currency, is(CURRENCY));
        assertThat(body.settlDate.format(DateTimeFormatter.ofPattern("YYYYMMdd")), is(SETTL_DATE));
        assertThat(body.price, is(1.37994));
        assertThat(body.avgPx, is(1.5419));
        assertThat(body.lastPx, is(1.5419));
        assertThat(body.lastQty, is(100000.0));
        assertThat(body.cumQty, is(100000.0));
        assertThat(body.leavesQty, is(0.0));
    }

    @Test
    public void acceptExecutionReportMessage_NDF_FILL() throws Exception {
        //when
        dbsExecutionReportHandler.accept(executionReportMessageFromFix_NDF_FILL());

        //then
        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport.Body body = executionReport.body;
        assertThat(body.senderCompId, is(COMP_ID));
        assertThat(body.marketId, is(Venue.DBS.name()));
        assertThat(body.symbol, is(NDF_NORMALISED_SYMBOL));
        assertThat(body.securityType, is(SecurityType.FXNDF));
        assertThat(body.ordStatus, is(OrderStatus.FILLED));
        assertThat(body.side, is(Side.BUY));
        assertThat(body.currency, is(CURRENCY));
        assertThat(body.settlDate.format(DateTimeFormatter.ofPattern("YYYYMMdd")), is(SETTL_DATE));
        // TODO assertThat(body.maturityDate.format(DateTimeFormatter.ofPattern("YYYYMMdd")), is(MATURITY_DATE));
        assertThat(body.orderQty, is(10000000.0));
        assertThat(body.price, is(1135.57));
        assertThat(body.avgPx, is(1135.57));
        assertThat(body.lastPx, is(1135.57));
        assertThat(body.lastQty, is(1000000.0));
        assertThat(body.cumQty, is(10000000.0));
        assertThat(body.leavesQty, is(0.0));
    }

    private ExecutionReport executionReportMessageFromFix_SPOT_FILL() throws Exception {
        final String executionReportFixMessage = ("8=FIX.4.2|9=350|35=8|34=194|49=FLEXECN|56=ANZ_FLEX|57=ANZ_FLEX|52=20181114-20:53:19.668|38=100000.00|6=1.54190000|11=154222873044701|14=100000.00|15=USD|17=1811148000000102|20=0|29=1|31=1.54190000|32=100000.00|37=B154222873044701ANZ_FLEX|39=2|44=1.37994000|54=2|55=USD/SGD|60=20181114-20:53:19.665|63=0|" +
                "64=20181116|150=2|198=SOE:1542228799-54 FAKE|151=0.00|10993=51|10=030|")
                .replace("55=USD/SGD", "55="+SPOT_SYMBOL)
                .replace("64=20181116", "64="+SETTL_DATE)
                .replace('|', (char) 0x01);

        final ExecutionReport executionReport = new DefaultExecutionReport();
        final FixToDTO fixToDTO = new FixToDTO(new MessageParser(), MessageNotifier.class);
        fixToDTO.parse(Bytes.from(executionReportFixMessage), sht -> sht.copyTo(executionReport));
        return executionReport;
    }

    private ExecutionReport executionReportMessageFromFix_NDF_FILL() throws Exception {
        final String executionReportFixMessage = ("8=FIX.4.2|9=392|35=8|34=238|49=FLEXECN|56=ANZ_FLEX|57=ANZ_FLEX|52=20181114-21:40:08.225|38=10000000.00|" +
                "6=1135.57000000|11=154223160052001|14=10000000.00|15=USD|17=1811148000000123|20=0|29=1|" +
                "31=1135.57000000|32=1000000.00|37=B154223160052001ANZ_FLEX|39=2|" +
                "44=1135.57000000|54=1|55=USD/KRW|60=20181114-21:40:08.224|63=0|" +
                "64=20181217|150=2|198=SOE:1542231608-68 FAKE|" +
                "541=20181213|195=0.00000000|151=0.00|10993=51|10=173|")
                .replace("55=USD/KRW", "55="+NDF_SYMBOL)
                .replace("64=20181217", "64="+SETTL_DATE)
                .replace("541=20181213", "541="+MATURITY_DATE)
                .replace('|', (char) 0x01);

        final ExecutionReport executionReport = new DefaultExecutionReport();
        final FixToDTO fixToDTO = new FixToDTO(new MessageParser(), MessageNotifier.class);
        fixToDTO.parse(Bytes.from(executionReportFixMessage), sht -> sht.copyTo(executionReport));
        return executionReport;
    }
}