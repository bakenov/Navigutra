package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

public class OptimalPositionsInstrumentMatcher extends BaseMatcher<OptimalPositions> {
    private static final Logger LOGGER = LoggerFactory.getLogger(OptimalPositionsInstrumentMatcher.class);
    private final EnumSet<Instrument> expected;

    public OptimalPositionsInstrumentMatcher(final EnumSet<Instrument> expected) {
        this.expected = expected;
    }


    @Override
    public boolean matches(Object o) {

        final OptimalPositions actuals = (OptimalPositions) o;

        for (OptimalPosition op : actuals.ops) {
            if (!expected.contains(op.getInstrument())) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void describeTo(Description description) {
        description.appendValue(expected);
    }

    @Override
    public void describeMismatch(final Object item,
                                 final Description description) {
        final OptimalPositions actuals = (OptimalPositions) item;

        List<Instrument> instruments = new ArrayList<>();
        actuals.ops.forEach(optimalPosition -> instruments.add(optimalPosition.getInstrument()));

        description.appendValue(EnumSet.copyOf(instruments));
    }

}
