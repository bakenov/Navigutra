package com.anz.axle.adapters.ndf2trep.publisher;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class RicRepositoryTest {
    private Map<String, Set<String>> symbolVenuesFXSPOT;
    private Map<String, Map<String, Set<String>>> instrumentRics;
    private Map<String, String> venueServiceNameMap;
    private Map<String, String> venuePublishSourceId;

    @Before
    public void beforeEach() {

        symbolVenuesFXSPOT = new HashMap<>();
        symbolVenuesFXSPOT.put("AUDCAD", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDCAD").add("WSP_A");
        symbolVenuesFXSPOT.get("AUDCAD").add("WSP_Z");
        symbolVenuesFXSPOT.put("AUDJPY", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDJPY").add("WSP_Z");
        symbolVenuesFXSPOT.put("AUDNOK", new HashSet<>());
        symbolVenuesFXSPOT.get("AUDNOK").add("WSP_A");

        instrumentRics = new HashMap<>();
        instrumentRics.put("EBS", new HashMap<>());
        instrumentRics.get("EBS").put("USDCNS", new HashSet<>());
        instrumentRics.get("EBS").get("USDCNS").add("M1:CNS1M");
        instrumentRics.get("EBS").get("USDCNS").add("M3:CNS3M");
        instrumentRics.get("EBS").get("USDCNS").add("M6:CNS6M");
        instrumentRics.get("EBS").get("USDCNS").add("Y1:CNS12M");

        instrumentRics.get("EBS").put("USDCN1", new HashSet<>());
        instrumentRics.get("EBS").get("USDCN1").add("M1:CN11M");
        instrumentRics.get("EBS").get("USDCN1").add("M3:CN13M");
        instrumentRics.get("EBS").get("USDCN1").add("M6:CN16M");
        instrumentRics.get("EBS").get("USDCN1").add("Y1:CN112M");

        venuePublishSourceId = new HashMap<>();
        venuePublishSourceId.put("EBS", "AXLE_DEV");
        venuePublishSourceId.put("WSP_A", "WHOLESALE");
        venuePublishSourceId.put("WSP_Z", "SPDEE_DEV");

        venueServiceNameMap = new HashMap<>();
        venueServiceNameMap.put("EBS", "AXLE_DEV");
        venueServiceNameMap.put("WSP_A", "WHOLESALE");
        venueServiceNameMap.put("WSP_Z", "SPDEE_DEV");
    }

    private RicRepository buildRicRepository(String serviceName) {
        return new RicRepository(symbolVenuesFXSPOT,        // symbol.venues.FXSPOT
                instrumentRics,                             // venue.symbol.tenors.FXNDF
                new HashMap<>(),                            // venue.subscription.sourceId
                venuePublishSourceId,                       // venue.publish.sourceId
                venueServiceNameMap,                        // venue.publish.serviceName
                serviceName);                               // ndf.trep.publish.destination.servicename
    }

    @Test
    public void testInstruments() {
        RicRepository ricRepository = buildRicRepository("AXLE_DEV");
        assertThat("2 Instruments to subscribe", ricRepository.getInstruments().size(), is(2));
        assertThat("2 Instruments to subscribe", ricRepository.getInstruments(),
                containsInAnyOrder("FXNDF_EBS_USDCNS", "FXNDF_EBS_USDCN1"));

        ricRepository = buildRicRepository("SPDEE_DEV");
        assertThat("2 Instruments to subscribe", ricRepository.getInstruments().size(), is(2));
        assertThat("2 Instruments to subscribe", ricRepository.getInstruments(),
                containsInAnyOrder("FXSPOT_WSP_Z_AUDCAD", "FXSPOT_WSP_Z_AUDJPY"));

        ricRepository = buildRicRepository("WHOLESALE");
        assertThat("2 Instruments to subscribe", ricRepository.getInstruments().size(), is(2));
        assertThat("2 Instruments to subscribe", ricRepository.getInstruments(),
                containsInAnyOrder("FXSPOT_WSP_A_AUDCAD", "FXSPOT_WSP_A_AUDNOK"));

        ricRepository = buildRicRepository("UNKNOWN");
        assertThat("No Instruments to subscribe", ricRepository.getInstruments().size(), is(0));
    }

    @Test
    public void testGetRicName() {
        RicRepository ricRepository = buildRicRepository("AXLE_DEV");
        assertThat("ricName to publish", ricRepository.getRicName("FXNDF_EBS_USDCNS", "M1"), is("CNS1M=AXLE_DEV"));
        assertThat("null when null instrument", ricRepository.getRicName(null, "M1"), nullValue());
        assertThat("null when null tenor", ricRepository.getRicName("FXNDF_EBS_USDCNS", null), nullValue());
        assertThat("null when all null", ricRepository.getRicName(null, null), nullValue());

        ricRepository = buildRicRepository("SPDEE_DEV");
        assertThat("ricName to publish", ricRepository.getRicName("FXSPOT_WSP_Z_AUDCAD", "SP"), is("AUDCAD=SPDEE_DEV"));
        assertThat("ricName to publish", ricRepository.getRicName("FXSPOT_WSP_Z_AUDJPY", "SP"), is("AUDJPY=SPDEE_DEV"));

        assertThat("instrument by symbol", ricRepository.getSpotConfiguredInstrument("AUDCAD"), is("FXSPOT_WSP_Z_AUDCAD"));
        assertThat("instrument by symbol", ricRepository.getSpotConfiguredInstrument("AUDJPY"), is("FXSPOT_WSP_Z_AUDJPY"));
        assertThat("instrument by symbol", ricRepository.getSpotConfiguredInstrument("AUDNOK"), is("FXSPOT_WSP_Z_AUDNOK"));
    }

    @Test
    public void testGetRicNames() {
        RicRepository ricRepository = buildRicRepository("AXLE_DEV");
        assertThat("12 publish ricNames", ricRepository.getRicNames("AXLE_DEV"),
                containsInAnyOrder("CNS1M=AXLE_DEV", "CNS3M=AXLE_DEV", "CNS6M=AXLE_DEV", "CNS12M=AXLE_DEV", "CN11M=AXLE_DEV", "CN13M=AXLE_DEV", "CN16M=AXLE_DEV", "CN112M=AXLE_DEV"));
        assertThat("No Rics for different service name", ricRepository.getRicNames("SPDEE_DEV").size(), is(0));
        assertThat("No Rics for different service name", ricRepository.getRicNames("FXEAZYAU").size(), is(0));
        ricRepository = buildRicRepository("SPDEE_DEV");
        assertThat("No Rics for service name", ricRepository.getRicNames("SPDEE_DEV").size(), is(2));
        assertThat("2 publish ricNames", ricRepository.getRicNames("SPDEE_DEV"),
                containsInAnyOrder("AUDJPY=SPDEE_DEV", "AUDCAD=SPDEE_DEV"));
        ricRepository = buildRicRepository("FXEAZYAU");
        assertThat("No Rics for service name", ricRepository.getRicNames("FXEAZYAU").size(), is(0));
        ricRepository = buildRicRepository("WHOLESALE");
        assertThat("No Rics for service name", ricRepository.getRicNames("WHOLESALE").size(), is(2));
        assertThat("2 publish ricNames", ricRepository.getRicNames("WHOLESALE"),
                containsInAnyOrder("AUDNOK=WHOLESALE", "AUDCAD=WHOLESALE"));
    }
}