package com.anz.markets.efx.fox.codec.api;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.ngaro.core.Garbage;

public interface SorEncoderSupplier {

    PricingRefreshCompleteEncoder pricingRefreshCompleteEncoder();
    TimerExpiryEncoder timerExpiryEncoder();
    FirewallConfigEncoder firewallConfigEncoder();
    VenueConfigEncoder venueConfig();
    UserConfigEncoder userConfig();
    InitialisationEncoder initialisation();
    InstrumentConfigEncoder instrumentConfig();
    VenueInstrumentConfigEncoder venueInstrumentConfig();

    @Garbage(Garbage.Type.RESULT)
    static <M> SorEncoderSupplier create(final SorEncoders<M> sorEncoders,
                                         final Consumer<? super M> messageConsumer) {
        return create(sorEncoders.pricingRefreshComplete().create(messageConsumer),
                      sorEncoders.timerExpiry().create(messageConsumer),
                      sorEncoders.firewallConfig().create(messageConsumer),
                      sorEncoders.venueConfig().create(messageConsumer),
                      sorEncoders.userConfig().create(messageConsumer),
                      sorEncoders.initialisation().create(messageConsumer),
                      sorEncoders.instrumentConfig().create(messageConsumer),
                      sorEncoders.venueInstrumentConfig().create(messageConsumer)
                );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorEncoderSupplier create(final PricingRefreshCompleteEncoder pricingRefreshCompleteEncoder,
                                     final TimerExpiryEncoder timerExpiryEncoder,
                                     final FirewallConfigEncoder firewallConfigEncoder,
                                     final VenueConfigEncoder venueConfigEncoder,
                                     final UserConfigEncoder userConfigEncoder,
                                     final InitialisationEncoder initialisationEncoder,
                                     final InstrumentConfigEncoder instrumentConfigEncoder,
                                     final VenueInstrumentConfigEncoder venueInstrumentConfigEncoder
    ) {
        return create(() -> pricingRefreshCompleteEncoder,
                      () -> timerExpiryEncoder,
                      () -> firewallConfigEncoder,
                      () -> venueConfigEncoder,
                      () -> userConfigEncoder,
                      () -> initialisationEncoder,
                      () -> instrumentConfigEncoder,
                      () -> venueInstrumentConfigEncoder
                );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorEncoderSupplier create(final Supplier<? extends PricingRefreshCompleteEncoder> pricingRefreshCompleteEncoderSupplier,
                                     final Supplier<? extends TimerExpiryEncoder> timerExpiryEncoder,
                                     final Supplier<? extends FirewallConfigEncoder> firewallConfigEncoder,
                                     final Supplier<? extends VenueConfigEncoder> venueConfigEncoder,
                                     final Supplier<? extends UserConfigEncoder> userConfigEncoder,
                                     final Supplier<? extends InitialisationEncoder> initialisationEncoder,
                                     final Supplier<? extends InstrumentConfigEncoder> instrumentConfigEncoder,
                                     final Supplier<? extends VenueInstrumentConfigEncoder> venueInstrumentConfigEncoder
    ) {
        Objects.requireNonNull(pricingRefreshCompleteEncoderSupplier);
        Objects.requireNonNull(timerExpiryEncoder);
        Objects.requireNonNull(firewallConfigEncoder);
        Objects.requireNonNull(venueConfigEncoder);
        Objects.requireNonNull(userConfigEncoder);
        Objects.requireNonNull(initialisationEncoder);
        Objects.requireNonNull(instrumentConfigEncoder);
        Objects.requireNonNull(venueInstrumentConfigEncoder);

        return new SorEncoderSupplier() {
            @Override
            public PricingRefreshCompleteEncoder pricingRefreshCompleteEncoder() {
                return pricingRefreshCompleteEncoderSupplier.get();
            }

            @Override
            public TimerExpiryEncoder timerExpiryEncoder() {
                return timerExpiryEncoder.get();
            }

            @Override
            public FirewallConfigEncoder firewallConfigEncoder() {
                return firewallConfigEncoder.get();
            }

            @Override
            public VenueConfigEncoder venueConfig() {
                return venueConfigEncoder.get();
            }

            @Override
            public UserConfigEncoder userConfig() {
                return userConfigEncoder.get();
            }

            @Override
            public InitialisationEncoder initialisation() {
                return initialisationEncoder.get();
            }

            @Override
            public InstrumentConfigEncoder instrumentConfig() {
                return instrumentConfigEncoder.get();
            }

            @Override
            public VenueInstrumentConfigEncoder venueInstrumentConfig() {
                return venueInstrumentConfigEncoder.get();
            }
        };
    }

    @Garbage(Garbage.Type.RESULT)
    static SorEncoderSupplier threadLocal(final Supplier<? extends PricingRefreshCompleteEncoder> pricingRefreshCompleteEncoderSupplier,
                                          final Supplier<? extends TimerExpiryEncoder> timerExpiryEncoderSupplier,
                                          final Supplier<? extends FirewallConfigEncoder> firewallConfigEncoderSupplier,
                                          final Supplier<? extends VenueConfigEncoder> venueConfigEncoderSupplier,
                                          final Supplier<? extends UserConfigEncoder> userConfigEncoderSupplier,
                                          final Supplier<? extends InitialisationEncoder> initialisationEncoderSupplier,
                                          final Supplier<? extends InstrumentConfigEncoder> instrumentConfigEncoderSupplier,
                                          final Supplier<? extends VenueInstrumentConfigEncoder> venueInstrumentConfigEncoderSupplier
    ) {
        final ThreadLocal<PricingRefreshCompleteEncoder> pricingRefreshCompleteEncoder = ThreadLocal.withInitial(pricingRefreshCompleteEncoderSupplier);
        final ThreadLocal<TimerExpiryEncoder> timerExpiryEncoder = ThreadLocal.withInitial(timerExpiryEncoderSupplier);
        final ThreadLocal<FirewallConfigEncoder> firewallConfigEncoder = ThreadLocal.withInitial(firewallConfigEncoderSupplier);
        final ThreadLocal<VenueConfigEncoder> venueConfigEncoder = ThreadLocal.withInitial(venueConfigEncoderSupplier);
        final ThreadLocal<UserConfigEncoder> userConfigEncoder = ThreadLocal.withInitial(userConfigEncoderSupplier);
        final ThreadLocal<InitialisationEncoder> initialisationEncoder = ThreadLocal.withInitial(initialisationEncoderSupplier);
        final ThreadLocal<InstrumentConfigEncoder> instrumentConfigEncoder = ThreadLocal.withInitial(instrumentConfigEncoderSupplier);
        final ThreadLocal<VenueInstrumentConfigEncoder> venueInstrumentConfigEncoder = ThreadLocal.withInitial(venueInstrumentConfigEncoderSupplier);
        return create(pricingRefreshCompleteEncoder::get,
                timerExpiryEncoder::get,
                firewallConfigEncoder::get,
                venueConfigEncoder::get,
                userConfigEncoder::get,
                initialisationEncoder::get,
                instrumentConfigEncoder::get,
                venueInstrumentConfigEncoder::get
        );
    }

    @Garbage(Garbage.Type.RESULT)
    static SorEncoderSupplier threadLocal(final Supplier<? extends SorEncoderSupplier> encoderSupplierSupplier) {
        final ThreadLocal<SorEncoderSupplier> encoderSupplier = ThreadLocal.withInitial(encoderSupplierSupplier);
        return new SorEncoderSupplier() {
            @Override
            public PricingRefreshCompleteEncoder pricingRefreshCompleteEncoder() {
                return encoderSupplier.get().pricingRefreshCompleteEncoder();
            }

            @Override
            public TimerExpiryEncoder timerExpiryEncoder() {
                return encoderSupplier.get().timerExpiryEncoder();
            }

            @Override
            public FirewallConfigEncoder firewallConfigEncoder() {
                return encoderSupplier.get().firewallConfigEncoder();
            }

            @Override
            public VenueConfigEncoder venueConfig() {
                return encoderSupplier.get().venueConfig();
            }

            @Override
            public UserConfigEncoder userConfig() {
                return encoderSupplier.get().userConfig();
            }

            @Override
            public InitialisationEncoder initialisation() {
                return encoderSupplier.get().initialisation();
            }

            @Override
            public InstrumentConfigEncoder instrumentConfig() {
                return encoderSupplier.get().instrumentConfig();
            }

            @Override
            public VenueInstrumentConfigEncoder venueInstrumentConfig() {
                return encoderSupplier.get().venueInstrumentConfig();
            }
        };
    }
}