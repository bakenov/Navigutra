// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * This class acts as a static interface to the FIXConfig.properties file, with
 * convenience methods for accessing the defined fields.
 * 
 */
public class FIXConfig
{
    private static final Properties properties = new Properties();
    private static boolean          isLoaded   = false;

    protected static Properties getProperties() throws IOException
    {
        synchronized (properties)
        {
            if (!isLoaded)
            {
                final InputStream is = ClassLoader.getSystemResourceAsStream("config/FIXConfig.properties");
                if (is == null)
                {
                    throw new FileNotFoundException("config/FIXConfig.properties not found on classpath");
                }
                properties.load(is);
                is.close();

                isLoaded = true;
            }

            return properties;
        }
    }

    /**
     * Accesses the fix_timeout property, which indicates how long we will wait
     * for an expected message to arrive.
     * 
     * @return the fix_timeout
     * @throws IOException
     */
    public static int getFIXTimeout() throws IOException
    {
        return Integer.parseInt(getProperties().getProperty("fix.timeout"));
    }

    /**
     * @return authenticated_fix_session_user_name
     * @throws IOException
     */
    public static String getAuthenticatedFixSessionUserName() throws IOException
    {
        return getProperties().getProperty("fix.session.username");
    }

    /**
     * @return authenticated_fix_session_password
     * @throws IOException
     */
    public static String getAuthenticatedFixSessionPassword() throws IOException
    {
        return getProperties().getProperty("fix.session.password");
    }

    /**
     * @return authenticated_fix_session_new_password
     * @throws IOException
     */
    public static String getAuthenticatedFixSessionNewPassword() throws IOException
    {
        return getProperties().getProperty("fix.session.newpassword");
    }

    /**
     * @param key
     *            the name of the property to be returned
     * @return the property value corresponding the the provided key
     * @throws IOException
     */
    public static String getNamedProperty(final String key) throws IOException
    {
        return getProperties().getProperty(key);
    }
}
