package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;

public interface UserConfigEncoder extends MessageEncoder<UserConfigEncoder.Body> {
    @Override
    Body messageStart(final int source, final long sourceSeq);

    interface Body {
        StringEncoder<Body> userName();
        EnumerableSetEncoder<Body, UserGroup> userGroups();
        StringEncoder<Trailer> location();
    }
}
