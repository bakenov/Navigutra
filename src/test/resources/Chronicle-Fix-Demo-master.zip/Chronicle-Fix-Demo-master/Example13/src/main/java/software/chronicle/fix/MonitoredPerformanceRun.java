package software.chronicle.fix;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.jlbh.JLBH;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.cfg.Monitor;
import software.chronicle.generated.code.messages.MessageNotifier;

import java.io.IOException;

public class MonitoredPerformanceRun extends PerformanceRun {
    final Monitor acceptorMonitor = Monitor.valueOf(System.getProperty("monitor.acceptor", "LATENCY"));
    final Monitor initiatorMonitor = Monitor.valueOf(System.getProperty("monitor.initiator", "NONE"));

    public static void main(String[] args) throws IOException {
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        PerformanceRun.runWith(new MonitoredPerformanceRun());
    }

    @Override
    protected @NotNull FixSessionCfg acceptorConfig(JLBH lth) {
        FixSessionCfg config = super.acceptorConfig(lth);
        config.monitor(acceptorMonitor);
        return config;
    }

    @Override
    protected @NotNull FixSessionCfg initiatorConfig(JLBH lth, MessageNotifier messageNotifier) {
        FixSessionCfg config = super.initiatorConfig(lth, messageNotifier);
        config.monitor(initiatorMonitor);
        return config;
    }
}