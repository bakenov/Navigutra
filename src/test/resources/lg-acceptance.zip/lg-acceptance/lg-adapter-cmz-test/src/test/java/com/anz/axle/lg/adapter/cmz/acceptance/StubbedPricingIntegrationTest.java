package com.anz.axle.lg.adapter.cmz.acceptance;

import java.util.EnumSet;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MDEntryType;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.PricingFixSessionHelper;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;

public class StubbedPricingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StubbedPricingIntegrationTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);


    final static String SYMBOL = "AUD/USD";
    final static String QUOTE_CONDITION_OPEN = "A";
    final static String QUOTE_CONDITION_CLOSED = "B";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private MatchingSession pricingServer;
    private SharedAcceptanceContext acceptanceContext;
    private PricingFixSessionHelper pricingFixSessionHelper;

    final private String senderCompId = "GB:lg-cmz";
    final private Venue marketId = Venue.CMZ;

    @Before
    public void setup(){
		LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        setPersistStorePath("cmz", testName.getMethodName());

        pricingFixSessionHelper = new PricingFixSessionHelper("cmz", "GB_CMZ_MD_S", "GB_CMZ_MD_T", "FIX.4.4");

        application = new Application("lg-cmz-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        if (pricingServer != null) pricingServer.shutdown();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private Predicate<Object> defaultSnapshotRefreshMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().countEquals(1)
                .hops().hasAny()
                .hops().countAtLeast(2);
    }

    private Predicate<Object> emptySnapshotMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().hasNone();
    }

    private final FixMessage defaultSnapshotRefreshFixMessage(final String requestId) {
        return defaultSnapshotRefreshFixMessage(requestId, QUOTE_CONDITION_OPEN);
    }

    private final FixMessage defaultSnapshotRefreshFixMessage(final String requestId, final String quoteCondition) {
        final String newEntryId1 = "B#-1388272055";
        final String newEntryQuantityString1 = "16863000000.00";
        final String newEntryPriceString1 = "1.33627";

        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATASNAPSHOTFULLREFRESH.getOrdinal())
                .withField(FieldTypes.MDReqID, requestId)
                .withField(FieldTypes.Symbol, SYMBOL)
                .withField(FieldTypes.SettlDate, "SP")
                .withField(FieldTypes.NoMDEntries, 1)
                .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
                .withField(FieldTypes.MDEntryPx, newEntryPriceString1)
                .withField(FieldTypes.Currency, "AUD")
                .withField(FieldTypes.MDEntrySize, newEntryQuantityString1)
                .withField(FieldTypes.MDEntryDate, "20170912")
                .withField(FieldTypes.QuoteCondition, quoteCondition)
                .withField(FieldTypes.QuoteEntryID, newEntryId1)
                .build();
    }

    @Test
    public void should_receive_pricing_information_for_the_registered_ccy_pair() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataSnapshotRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataSnapshotRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultSnapshotRefreshMessageMatcher())
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                    LOGGER.info(snapshotFullRefresh.toString());
                    Assert.assertEquals(marketId, snapshotFullRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), snapshotFullRefresh.body.instrumentId);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.body.senderCompId);
                    Assert.assertNull(snapshotFullRefresh.body.tradeDate);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.size());
                    Assert.assertEquals(0, snapshotFullRefresh.entries.get(0).mdEntryId);
                    Assert.assertEquals(EntryType.BID, snapshotFullRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(1.33627, snapshotFullRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, snapshotFullRefresh.entries.get(0).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(16863000000.00, snapshotFullRefresh.entries.get(0).mdEntrySize, 1e-6);
                    Assert.assertEquals(0.0, snapshotFullRefresh.entries.get(0).minQty, 1e-6);
                    Assert.assertEquals(2, snapshotFullRefresh.hops.size());
                    Assert.assertEquals("GB:CMZ", snapshotFullRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, snapshotFullRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(snapshotFullRefresh.body.sendingTime, snapshotFullRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(1).hopMessageId);
                }
        });
    }

    @Test
    public void market_data_request_rejected() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataRequestReject is sent to adapter.
        pricingServer.send(pricingFixSessionHelper
                .marketDataRequestRejectFixMessageBuilder(marketDataRequest.getField(FieldTypes.MDReqID).getValue())
                .withField(FieldTypes.Text, "reject reason")
                .build()
        );

        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }

    @Test
    public void should_send_empty_snapshot_when_marketdata_fix_disconnects() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataSnapshotRefresh processed message is available in pricing queue.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultSnapshotRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println("==============================================================");

        //When pricingServer (venue simulator) is shutdown
        pricingServer.shutdown();

        //Then empty snapshot messages should be available in pricing queue
        final PricingMessage pricingSnapShotMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(emptySnapshotMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println(pricingSnapShotMessage.toString());

        //pricingSnapShotMessage.accept(snapshotFullRefresh -> assertEquals("GB:lg-fastma", snapshotFullRefresh.body.senderCompId), incrementalRefresh -> {});
        System.out.println("==============================================================");
    }

    @Test
    public void should_not_send_empty_snapshot_when_not_logged_on() throws Exception {

        //Given pricingServer (venue simulator) is down
        //When adapter is not connected
        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }

    @Test
    public void should_receive_indicative_when_quote_condition_is_closed() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55="+SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataSnapshotRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue(), QUOTE_CONDITION_CLOSED));

        //Then the  MarketDataSnapshotRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultSnapshotRefreshMessageMatcher())
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                    LOGGER.info(snapshotFullRefresh.toString());
                    Assert.assertEquals(marketId, snapshotFullRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), snapshotFullRefresh.body.instrumentId);

                    Assert.assertEquals(senderCompId, snapshotFullRefresh.body.senderCompId);

                    Assert.assertNull(snapshotFullRefresh.body.tradeDate);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.size());
                    Assert.assertEquals(EnumSet.of(Flag.INDICATIVE), snapshotFullRefresh.entries.get(0).mdEntryFlags);
                    Assert.assertEquals(0, snapshotFullRefresh.entries.get(0).mdEntryId);
                    Assert.assertEquals(EntryType.BID, snapshotFullRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(1.33627, snapshotFullRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(0.0, snapshotFullRefresh.entries.get(0).mdEntryForwardPoints, 1e-6);
                    Assert.assertEquals(16863000000.00, snapshotFullRefresh.entries.get(0).mdEntrySize, 1e-6);
                    Assert.assertEquals(0.0, snapshotFullRefresh.entries.get(0).minQty, 1e-6);
                    Assert.assertEquals(2, snapshotFullRefresh.hops.size());
                    Assert.assertEquals("GB:CMZ", snapshotFullRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, snapshotFullRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(snapshotFullRefresh.body.sendingTime, snapshotFullRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(1).hopMessageId);
                }
        });
    }
}
