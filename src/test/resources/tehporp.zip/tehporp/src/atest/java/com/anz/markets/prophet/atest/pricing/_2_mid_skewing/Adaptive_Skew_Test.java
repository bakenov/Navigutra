package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceFormationPipelineConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.pfp.features.AdaptiveSkewFeature;
import com.anz.markets.prophet.pricer.pfp.features.AdaptiveSkewFeatureSpecs;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1357})
public class Adaptive_Skew_Test extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;
    private Double activeUSD = 1_200_000d;
    private AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;
    private PriceFormationPipelineConfig defaultConfig = PriceFormationPipelineConfig.create(specs.NAME,
            Market.ANY,
            Instrument.ANY,
            TradingTimeZone.GLOBAL,
            Region.ANY,
            specs.PARAM_ACTIVE_USD, Double.NaN,
            specs.PARAM_MAX_SKEW_POSITION_USD, Double.NaN,
            specs.PARAM_MIN_SKEW_FACTOR, Double.NaN,
            specs.PARAM_HIT_FRACTION, Double.NaN,
            specs.PARAM_HIT_STEP_FRACTION, Double.NaN,
            specs.PARAM_RR_INTERVAL_MS, 0L,
            specs.PARAM_RR_TARGET, Double.NaN,
            specs.PARAM_SKEW_STEP_PIPS, Double.NaN,
            specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 0L,
            specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 0L,
            specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
            specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L);

    private ConfigurationDataDefault setUpBaseSpreadConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setClientSpreadConfigs(Arrays.asList(
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0)
                ));
        return configuration;
    }

    private ConfigurationDataDefault setUpConfiguration() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.35d,
                specs.PARAM_RR_INTERVAL_MS, 2_000L,
                specs.PARAM_RR_TARGET, 0.9d,
                specs.PARAM_SKEW_STEP_PIPS, 0.001d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 100L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 200L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L));
        priceFormationPipelineConfig.add(defaultConfig);

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setClientSpreadConfigs(Arrays.asList(
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0)
                ));
        configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
        return configuration;
    }


    @Test
    // Rule 2 - if the absolute gradient position in USD is below activeUSD then no skew
    // Rule 5 - if we were previously not skewing or previous skew is of the opposite sign then immediately apply minSkewPips
    public void positionUSD_below_activeUSD() {
        given:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(TradingTimeZone.LDN);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -1_000_000, 0.79999));
        }
        then:
        // short position is below activeUSD config
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_199_985.0));
            assertThat(Math.abs(op.getGradientPositionInSystemBase()) <= activeUSD, is(true));
        }
        when:
        // absolute position is below activeUSD config NO skew
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79989, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.79989));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.data[0].sx.toString(), is("0"));
        }
        when:
        // absolute position is above activeUSD then SKEW
        // Rule 5: if we were previously not skewing, then skew by minSkewPips
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1200150 / 5000000 * 1pip / 2 = 0.120015 = 0.13 (ROUNDUP to 100th pip)
        // minSkewPips =  maxSkewPips * minSkewFactor
        // 0.13 * 0.9 = 0.117 = 0.12(ROUNDUP to 100th of pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_200_150.0));
            assertThat(Math.abs(op.getGradientPositionInSystemBase()) > activeUSD, is(true));

            // since SHORT, positive skew. Rounded to 100th of pip
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), is(0.800112));

            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.data[0].sx.toString(), is("R"));
        }
        when:
        // Rule 5: previous skew is of the opposite sign so immediately apply minSkewPips
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1200150 / 5000000 * 1pip / 2 = 0.120015 = 0.13 (ROUNDUP to 100th pip)
        // minSkewPips =  maxSkewPips * minSkewFactor
        // 0.13 * 0.9 = 0.117 = 0.12(ROUNDUP to 100th of pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, 2_000_000, 0.80010));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(1_200_150.0));

            // since LONG, -ve skew
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isNear(0.800088));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.data[0].sx.toString(), is("R"));
        }
        and:
        {
            pauseSkew_overrides_dynamicSkew();
        }

    }

    public void pauseSkew_overrides_dynamicSkew() {
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setSkewingPause(Currency.AUD, true));
        }
        then:
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.80010));
        }

    }

    @Test
    @DisplayName("Rule 3 - if minSkewFactor==1 then linear skewing mode is used")
    public void linearSkew_override() {
        given:
        {
            List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
            AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

            // set up config Adaptive Skew but DISABLED(ACTIVE_USD is NaN)
            priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                    Market.WSP_A,
                    Instrument.AUDUSD,
                    TradingTimeZone.GLOBAL,
                    Region.ANY,
                    specs.PARAM_ACTIVE_USD, 100d,
                    specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                    specs.PARAM_MIN_SKEW_FACTOR, 1.0d,
                    specs.PARAM_HIT_FRACTION, 0.5d,
                    specs.PARAM_HIT_STEP_FRACTION, 0.25d,
                    specs.PARAM_RR_INTERVAL_MS, 1_000L,
                    specs.PARAM_RR_TARGET, 1_000_000d,
                    specs.PARAM_SKEW_STEP_PIPS, 0.4d,
                    specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 2_000L,
                    specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 3_000L,
                    specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                    specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
            );
            priceFormationPipelineConfig.add(defaultConfig);

            ConfigurationDataDefault configuration = tdd.configuration_pricing_base();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration
                    .setClientSpreadConfigs(Arrays.asList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.SNG, 0.5)
                    ))
            );
        }
        when:
        {
            prophet.receive(TradingTimeZone.SNG);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(indirectPair, 1_000_000, 0.79999));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(1_199_985.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79990, 0.0005));
        }
        then:
        // since minSkewFactor==1, apply linear skew:
        // -(positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // -(1199985/5000000)*(0.5pip/2) = -0.05999925 = -0.06 (Rounded to 100th of pip)
        // since TZ is SNG, use 0.5 basespread
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isNear(0.799894));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.SKEW_IMPACT));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.SKEW_IMPACT));
            assertThat(ftl.operations[0].operation, Matchers.is(PliableBookOperation.OVERRIDE_SKEW));
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.06));
            assertThat(ftl.data[0].sx.toString(), is("L"));
        }
    }

    @Test
    // Rule 6 - if we have taken a significant risk increasing hit again:
    // abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD)) then skew harder immediately
    // skew = prevSkew + skewSign*hitStepFraction*maxSkewPips
    public void received_significant_risk_increasing_hit_again() {
        given:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -1_000_000, 0.79999));
        }
        when:
        // absolute position is above activeUSD then SKEW
        // Rule 5: if we were previously not skewing, then skew
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1200150 / 5000000 * 1pip / 2 = 0.120015 = 0.13 (ROUNDUP to 100th pip)
        // minSkewPips =  maxSkewPips * minSkewFactor
        // 0.13 * 0.9 = 0.117 = 0.12(ROUNDUP to 100th of pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_200_150.0));

            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.800112));
        }
        when:
        // Rule 6 - if we have taken a significant risk increasing hit again: abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD))
        // 1800825.075 > 1.5 * 1_200_150 = 1800225
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1800825.075 / 5000000 * 1pip / 2 = 0.1800825 = 0.19 (ROUNDUP to 100th pip)
        // then skew harder immediately: skew = prevSkew + skewSign*hitStepFraction*maxSkewPips
        // 0.12 + 1*0.35*0.19 = 0.1865pip = 0.1865pip = 0.19(ROUNDUP to 100th of pip)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, -500_500, 0.80010));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 3_000_000.0)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_800_825.075));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.800119));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.data[0].sx.toString(), is("H"));
        }
    }

    @Test
    // Rule 6 - if we have taken a significant risk increasing hit again:
    // abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD)) then skew harder immediately
    // Rule 7 - if uMidDelta = 0 then retain existing skew (skew = prevSkew)
    public void received_insignificant_risk_increasing_hit_again() {
        given:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -1_000_000, 0.79999));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_200_150.0));

            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), is(0.800112));
        }
        when:
        // Rule 6 - if we have taken a significant risk increasing hit again: abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD))
        // 1800223.8 !> 1.5 * 1_200_150 = 1800225
        // Rule 7: if uMidDelta = 0 then retain existing skew: skew = prev skew 0.12
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, -499_999, 0.80010));
        }
        then:
        // minSkewPips is 0.18. Therefore currentSkew of 0.12 is FLOORED at 0.18
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 3_000_000.0)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_800_223.8));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.800118));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.data[0].sx.toString(), is("U"));
        }
    }

    @Test
    // received_significant_risk_increasing_hit_again() but final skew limited to minSkewPips FLOOR
    // PARAM_HIT_STEP_FRACTION = 0.25
    public void short_pos_final_skew_limited_by_floor() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(defaultConfig);
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.25d,
                specs.PARAM_RR_INTERVAL_MS, 1_000L,
                specs.PARAM_RR_TARGET, 0.9d,
                specs.PARAM_SKEW_STEP_PIPS, 0.001d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 2_000L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 3_000L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -1_000_000, 0.79999));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_200_150.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.12));
        }
        when:
        // Rule 6 - if we have taken a significant risk increasing hit again: abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD))
        // 1800825.075 > 1.5 * 1_200_150 = 1800225
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1800825.075 / 5000000 * 1pip / 2 = 0.18008 = 0.19 (ROUNDUP to 100th pip)
        // then skew harder immediately: skew = prevSkew + skewSign*hitStepFraction*maxSkewPips
        // 0.12 + 1*0.25*(0.19) = 0.1675pip
        // However skew must lie in range: [minSkewPips,maxSkewPips] => [0.18, 0.19] => skew = 0.18
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, -500_500, 0.80010));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 3_000_000.0)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_800_825.075));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.800118));
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.data[0].sx.toString(), is("H"));
        }
    }

    @Test
    // received_significant_risk_increasing_hit_again() but final skew limited to maxSkewPips CEILING
    // PARAM_HIT_STEP_FRACTION = 0.45
    public void short_pos_final_skew_limited_by_ceiling() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        // set up config Adaptive Skew but DISABLED(ACTIVE_USD is NaN)
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.45d,
                specs.PARAM_RR_INTERVAL_MS, 1_000L,
                specs.PARAM_RR_TARGET, 0.9d,
                specs.PARAM_SKEW_STEP_PIPS, 0.4d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 2_000L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 3_000L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 100L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 50L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, -1_000_000, 0.79999));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_200_150.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.12));
        }
        when:
        // Rule 6 - if we have taken a significant risk increasing hit again: abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD))
        // 1800825.075 > 1.5 * 1_200_150 = 1800225
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1800825.075 / 5000000 * 1pip / 2 = 0.18008 = 0.19 (ROUNDUP to 100th pip)
        // then skew harder immediately: skew = prevSkew + skewSign*hitStepFraction*maxSkewPips
        // 0.12 + 1*0.45*(0.19) = 0.2055
        // However skew must lie in range: [minSkewPips,maxSkewPips] => [0.18, 0.19] => skew = 0.19
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, -500_500, 0.80010));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 3_000_000.0)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(-1_800_825.075));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            assertThat(wbf.getSkewedMidPrice(), isRoundedTo(0.800119));
        }

        enterStandDownMode();
    }

    @Test
    // received_significant_risk_increasing_hit_again() but final skew limited to maxSkewPips FLOOR
    // PARAM_HIT_STEP_FRACTION = 0.45
    public void long_pos_final_skew_limited_by_floor() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        // set up config Adaptive Skew but DISABLED(ACTIVE_USD is NaN)
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.45d,
                specs.PARAM_RR_INTERVAL_MS, 1_000L,
                specs.PARAM_RR_TARGET, 0.9d,
                specs.PARAM_SKEW_STEP_PIPS, 0.4d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 2_000L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 3_000L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, 1_000_000, 0.79999));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(1_200_150.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.12));
        }
        when:
        // Rule 6 - if we have taken a significant risk increasing hit again: abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD))
        // 1800825.075 > (1.5 * 1_200_150 = 1800225)
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1800825.075 / 5000000 * 1pip / 2 = 0.18008 = 0.19 (ROUNDUP to 100th pip)
        // then skew harder immediately: skew = prevSkew + skewSign*hitStepFraction*maxSkewPips
        // -0.12 + (-1)*0.45*(0.19) = -0.2055pip
        // However skew must lie in range: [-maxSkewPips,-minSkewPips] => [-0.19, -0.18] => skew = -0.19
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, 500_500, 0.80010));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 3_000_000.0)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(1_800_825.075));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.19));
        }
    }

    @Test
    // received_significant_risk_increasing_hit_again() but final skew limited to maxSkewPips CEILING
    // PARAM_HIT_STEP_FRACTION = 0.3
    public void long_pos_final_skew_limited_by_ceiling() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        // set up config Adaptive Skew but DISABLED(ACTIVE_USD is NaN)
        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.9d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.3d,
                specs.PARAM_RR_INTERVAL_MS, 1_000L,
                specs.PARAM_RR_TARGET, 0.9d,
                specs.PARAM_SKEW_STEP_PIPS, 0.4d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 2_000L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 3_000L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79999, 0.0005));
            prophet.receive(tdd.client_trade_001(indirectPair, 1_000_000, 0.79999));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 1_500_001)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(1_200_150.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.12));
        }
        when:
        // Rule 6 - if we have taken a significant risk increasing hit again: abs(positionUSD) > (1+hitFraction) * abs(prevPositionUSD))
        // 1800825.075 > (1.5 * 1_200_150 = 1800225)
        // maxSkewPips = (positionUSD / maxSkewPositionUSD) * (baseSpreadPips / 2)
        // 1800825.075 / 5000000 * 1pip / 2 = 0.18008 = 0.19 (ROUNDUP to 100th pip)
        // then skew harder immediately: skew = prevSkew + skewSign*hitStepFraction*maxSkewPips
        // -0.12 + (-1)*0.3*(0.19) = -0.177pip
        // However skew must lie in range: [-maxSkewPips,-minSkewPips] => [-0.19, -0.18] => skew = -0.18
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, 500_500, 0.80010));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 3_000_000.0)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(1_800_825.075));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.18));
        }
    }

    @Test
    // Rule 8: if the observed rate of risk reducing flow (rrFlowRate) is below rrTarget and we have a transient skew increment (transientSkewInc=true)
    // then skew = prevSkew + skewSign * skewStepPips;
    // This will only be actioned if the time elapsed since the last skew change exceeds skewStepIntervalTransientMillis.
    public void transientSkewIncAndBelowRiskReducingFlow() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.55d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.35d,
                specs.PARAM_RR_INTERVAL_MS, 600L,
                specs.PARAM_RR_TARGET, 0.12d,
                specs.PARAM_SKEW_STEP_PIPS, 0.01d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 100L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 50L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        and:
        {
            setUpLongPosition();
        }
        //t+2sec
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(100L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        // Rule 8:
        // rrFlowRate = the sum of risk reducing deal flow in USD over the previous rrInterval ms divided by abs(positionUSD)
        // (0.4mio USD)/3.3642 = 0.11889 < rrTarget(0.12)
        // transientSkewInc = TRUE i.e uMidDelta(1pip) > 0 != skewSign(-1) > 0
        // skew = prevSkew + skewSign * skewStepPips = -0.24 + (-1)(0.01) = -0.25
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 5_000_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_360_420.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.25));
            assertThat(ftl.data[0].sx.toString(), is("^"));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(99L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80020, 0.0005));
        }
        then:
        // Rule 8: Time since last skew change only 99ms. Does not exceed skewStepIntervalTransientMillis(100).
        // Therefore skew unchanged from previous
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_360_840.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.25));
            assertThat(ftl.data[0].sx.toString(), is("U"));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80030, 0.0005));
        }
        then:
        // Rule 8: Time since last skew change is now 100ms. Meets skewStepIntervalTransientMillis(100).
        // skew = prevSkew + skewSign * skewStepPips = -0.25 + (-1)(0.01) = -0.26
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.26));
            assertThat(ftl.data[0].sx.toString(), is("^"));
        }
    }

    @Test
    // Rule 9: if the observed rate of risk reducing flow (rrFlowRate) is below rrTarget and we have a transient skew DECREMENT (transientSkewInc=false)
    // then skew = prevSkew + skewSign * skewStepPips;
    // This will only be actioned if the time elapsed since the last skew change exceeds skewStepIntervalTransientMillis.
    public void transientSkewDecAndBelowRiskReducingFlow() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.55d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.35d,
                specs.PARAM_RR_INTERVAL_MS, 600L,
                specs.PARAM_RR_TARGET, 0.12d,
                specs.PARAM_SKEW_STEP_PIPS, 0.01d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 50L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 100L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        and:
        {
            setUpLongPosition();
        }
        //t+2sec
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(100L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79990, 0.0005));
        }
        then:
        // Rule 9:
        // rrFlowRate = the sum of risk reducing deal flow in USD over the previous rrInterval ms divided by abs(positionUSD)
        // (0.4mio USD)/3.3642 = 0.11889 < rrTarget(0.12)
        // transientSkewInc = FALSE i.e uMidDelta(-1pip) > 0 != skewSign(-1) > 0 is FALSE
        // skew = prevSkew + skewSign * skewStepPips = -0.24 + (-1)(0.01) = -0.25
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_359_580.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.25));
            assertThat(ftl.data[0].sx.toString(), is("+"));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(99L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79980, 0.0005));
        }
        then:
        // Rule 9: Time since last skew change only 99ms. Does not exceed skewStepIntervalNONTransientMillis(100).
        // Therefore skew unchanged from previous
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_359_160.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.25));
            assertThat(ftl.data[0].sx.toString(), is("U"));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79970, 0.0005));
        }
        then:
        // Rule 9: Time since last skew change is now 100ms. Meets skewStepIntervalNONTransientMillis(100).
        // skew = prevSkew + skewSign * skewStepPips = -0.25 + (-1)(0.01) = -0.26
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.26));
            assertThat(ftl.data[0].sx.toString(), is("+"));
        }
    }

    @Test
    // Rule 10: if the observed rate of risk reducing flow (rrFlowRate) is ABOVE rrTarget we will decrease skew one step but only once per episode (i.e., until flow rate decreases below threshold).
    // then skew = prevSkew - skewSign * skewStepPips;
    public void aboveRiskReducingFlowTarget() {
        List<PriceFormationPipelineConfig> priceFormationPipelineConfig = new ArrayList<>();
        AdaptiveSkewFeatureSpecs specs = AdaptiveSkewFeatureSpecs.INSTANCE;

        priceFormationPipelineConfig.add(PriceFormationPipelineConfig.create(specs.NAME,
                Market.WSP_A,
                Instrument.AUDUSD,
                TradingTimeZone.GLOBAL,
                Region.ANY,
                specs.PARAM_ACTIVE_USD, activeUSD,
                specs.PARAM_MAX_SKEW_POSITION_USD, 5_000_000d,
                specs.PARAM_MIN_SKEW_FACTOR, 0.55d,
                specs.PARAM_HIT_FRACTION, 0.5d,
                specs.PARAM_HIT_STEP_FRACTION, 0.35d,
                specs.PARAM_RR_INTERVAL_MS, 600L,
                specs.PARAM_RR_TARGET, 0.11d,
                specs.PARAM_SKEW_STEP_PIPS, 0.01d,
                specs.PARAM_SKEW_STEP_INTERVAL_TRANSIENT_MS, 50L,
                specs.PARAM_SKEW_STEP_INTERVAL_NON_TRANSIENT_MS, 100L,
                specs.PARAM_NO_INTEREST_TIMEOUT_MS, 0L,
                specs.PARAM_NO_INTEREST_STANDDOWN_MS, 0L)
        );
        priceFormationPipelineConfig.add(defaultConfig);

        given:
        {
            ConfigurationDataDefault configuration = setUpBaseSpreadConfiguration();
            configuration.getPriceFormationPipelineConfigs().replaceFeature(specs.NAME, priceFormationPipelineConfig);
            prophet.receive(configuration);
            prophet.receive(TradingTimeZone.LDN);
        }
        and:
        {
            setUpLongPosition();
        }
        //t+2sec
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(99L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.79990, 0.0005));
        }
        then:
        // Rule 10:
        // rrFlowRate = the sum of risk reducing deal flow in USD over the previous rrInterval ms divided by abs(positionUSD)
        // (0.4mio USD)/3.3642 = 0.11889 > rrTarget(0.11)
        // skew = prevSkew - skewSign * skewStepPips = -0.24 - (-1)(0.02) = -0.22
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_359_580.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.23));
            assertThat(ftl.data[0].sx.toString(), is("-"));
        }
        when:
        // rrFlowRate is still ABOVE rrTarget. We have already reduced skew by one step so do not reduce again
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.8, 0.0005));
        }
        then:
        // Rule 13: skew remains unchanged
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl = wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.23));
            assertThat(ftl.data[0].sx.toString(), is("U")); // rule is skew remains unchanged
        }
    }

    // Rule 12:
    // if no risk reduction after noInterestTimeoutMS while at max skew
    // then enter standdown mode and stand down skew for noInterestStanddownMS
    public void enterStandDownMode() {
        when:
        // on noInterestTimeoutMS of 100ms. Continue to Skew
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(100L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80000, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.2));
        }
        when:
        // noInterestTimeoutMS of 100ms now exceeded. Enter Stand Down mode
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.0));
            assertThat(ftl.data[0].sx.toString(), is("S"));
        }
        when:
        // Stand down for noInterestStanddownMS 50ms not exceeded. Therefore still stand down
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80000, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.0));
            assertThat(ftl.data[0].sx.toString(), is("S"));
        }
        when:
        // Stand down noInterestStanddownMS 50ms exceeded. Therefore allowed to skew again
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1L);
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80010, 0.0005));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.2));
        }
    }

    public void setUpLongPosition() {
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.80000, 0.0005));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, 3_500_000, 0.80000));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(4_200_000.0));

            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(indirectPair)).getFirst();
            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(AdaptiveSkewFeature.SPECS.getShortCode());
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.SKEW_IN_PIPS));
            assertThat(ftl.operations[0].newVal, isRoundedTo(-0.24));
        }
        when:
        {
            //t+0.9sec
            prophet.clearOutputBuffer();
            prophet.incrementTime(900L);
            prophet.receive(tdd.client_trade_001(indirectPair, -200_000, 0.80000));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_960_000.0));
        }
        when:
        {
            //t+1.1sec
            prophet.clearOutputBuffer();
            prophet.incrementTime(200L);
            prophet.receive(tdd.client_trade_001(indirectPair, -200_000, 0.80000));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_720_000.0));
        }
        when:
        {
            //t+1.5sec
            prophet.clearOutputBuffer();
            prophet.incrementTime(400L);
            prophet.receive(tdd.client_trade_001(indirectPair, 200_000, 0.80000));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3960000.0));
        }
        when:
        {
            //t+1.7sec
            prophet.incrementTime(200L);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, -200_000, 0.80000));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3720000.0));
        }
        when:
        // Total RR flow(last 0.6sec) is 0.5AUD * 0.8 = 0.4mio USD
        {
            //t+1.9sec
            prophet.incrementTime(200L);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(indirectPair, -300_000, 0.80000));
        }
        then:
        {
            OptimalPositions ops = prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(indirectPair, 7_500_000)).getLast();
            final OptimalPosition op = ops.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == indirectPair).findFirst().get();
            assertThat(op.getGradientPositionInSystemBase(), isRoundedTo(3_360_000.0));
        }
    }
}