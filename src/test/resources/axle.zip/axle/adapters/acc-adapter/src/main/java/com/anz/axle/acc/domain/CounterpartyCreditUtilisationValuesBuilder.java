package com.anz.axle.acc.domain;

import com.anz.axle.common.domain.Builder;
import com.anz.axle.common.domain.BuilderException;
import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("counterpartyCreditUtilisationValuesBuilder")
public class CounterpartyCreditUtilisationValuesBuilder implements Builder<Collection<CounterpartyCreditUtilisationValue>, CounterpartyCreditUtilisations> {

    @Autowired
    @Qualifier("counterpartyCreditUtilisationValueBuilder")
    private Builder<CounterpartyCreditUtilisationValue, CounterpartyCreditUtilisation> valueBuilder;

    @Override
    public Collection<CounterpartyCreditUtilisationValue> build(CounterpartyCreditUtilisations input) throws BuilderException {
        Collection<CounterpartyCreditUtilisationValue> values = new ArrayList<CounterpartyCreditUtilisationValue>();

        for(CounterpartyCreditUtilisation utilisation : input.findAll()) {
            CounterpartyCreditUtilisationValue value = valueBuilder.build(utilisation);
            values.add(value);
        }
        return values;
    }

    /**
     * Testing purposes only.
     * @param valueBuilder
     */
    public void setValueBuilder(CounterpartyCreditUtilisationValueBuilder valueBuilder) {
        this.valueBuilder = valueBuilder;
    }
}
