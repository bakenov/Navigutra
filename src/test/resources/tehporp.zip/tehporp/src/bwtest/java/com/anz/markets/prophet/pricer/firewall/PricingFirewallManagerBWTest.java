package com.anz.markets.prophet.pricer.firewall;


import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBookImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.StandaloneFilterOutcome;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.function.Consumer;

import static com.anz.markets.prophet.pricer.firewall.ArbitrageProtectionFirewallTest.createMarketDataWith;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PricingFirewallManagerBWTest {

    final Consumer<ClientPrice> dudClientPriceConsumer = clientPrice1 -> {
    };
    private NotifierDefault notifierDefault = new NotifierDefault<ClientPrice>().register(dudClientPriceConsumer);
    private DataRegisters dataRegisters = new DataRegisters();

    private final MidRate marketData = createMarketDataWith(1.001, 1.002);
    private final AggregatedBookImpl aggBook = new AggregatedBookImpl(marketData.getMarket(), marketData.getInstrument());
    private final ClientPrice clientPrice = ArbitrageProtectionFirewallTest.createClientPriceWith(1.003, 1.004);
    private final PricingFirewallManager pricingFirewallManager;

    private static final int REPS = 100_000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private static final int THRESHOLD = 200;

    private final StandaloneFilterOutcome filterOutcome = new StandaloneFilterOutcome();
    private final Consumer<ClientPrice> clientPriceConsumer;

    public PricingFirewallManagerBWTest() {
        Context.context().region(Region.GB);
        pricingFirewallManager = PricingFirewallManagerTest.pricingFirewallManager(notifierDefault,dataRegisters);
        clientPriceConsumer = pricingFirewallManager.consumerClientPrice();
    }

    public void scenario_ConsumeAggBookAndClientPrice() {
        filterOutcome.reset((FilteredMarketDataSnapshot) marketData);
        aggBook.aggregateBook((FilteredMarketDataSnapshot) marketData, filterOutcome);
        clientPriceConsumer.accept(clientPrice);
    }

    @Test
    public void test_AggBookAndClientPrice() {
        helper.testAllocationNotExceeded(
                this::scenario_ConsumeAggBookAndClientPrice, REPS, REPS,
                THRESHOLD
        );
    }
}
