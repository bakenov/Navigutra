package com.anz.markets.efx.ngaro.collections;

import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class EnumDoubleMapImplTest {


    @Test
    public void testMap() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        map.put(AnimalEnum.CAT, 1d);
        assertThat(map.size(), is(1));
        assertThat(map.isEmpty(), is(false));
        assertThat(map.get(AnimalEnum.CAT), is(1d));
        map.put(AnimalEnum.CAT, 2d);
        assertThat(map.size(), is(1));
        assertThat(map.isEmpty(), is(false));
        assertThat(map.get(AnimalEnum.CAT), is(2d));
        map.put(AnimalEnum.HIPPO, 3d);
        assertThat(map.size(), is(2));
        assertThat(map.isEmpty(), is(false));
        assertThat(map.get(AnimalEnum.CAT), is(2d));
        assertThat(map.get(AnimalEnum.HIPPO), is(3d));
        map.clear();
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
    }

    @Test
    public void testRemoveIf() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        map.put(AnimalEnum.CAT, 1d);
        map.put(AnimalEnum.CAT, 2d);
        map.put(AnimalEnum.DOG, 3d);
        map.put(AnimalEnum.HIPPO, 4d);
        map.put(AnimalEnum.HIPPO, 5d);
        map.put(AnimalEnum.HIPPO, 6d);

        assertThat(map.get(AnimalEnum.CAT), is(2d));
        assertThat(map.size(), is(3));

        map.removeIf((key, value) -> value == 2d);

        assertThat(Double.isNaN(map.get(AnimalEnum.CAT)), is(true));
        assertThat(map.size(), is(2));

        map.removeIf((key, value) -> value == 1000d);
        assertThat(map.remove(AnimalEnum.MOUSE), is(false));
        assertThat(map.size(), is(2));
    }

    @Test
    public void testForEach() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        map.put(AnimalEnum.CAT, 1d);
        map.put(AnimalEnum.CAT, 2d);
        map.put(AnimalEnum.CAT, 3d);
        map.put(AnimalEnum.HIPPO, 4d);
        map.put(AnimalEnum.HIPPO, 5d);
        map.put(AnimalEnum.HIPPO, 6d);

        final AtomicInteger i = new AtomicInteger();
        map.forEach((k, v) -> {
            assertThat(map.get(k), is(v));
            i.incrementAndGet();
        });
        assertThat(i.get(), is(2));
    }

    @Test
    public void testkeys() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        map.put(AnimalEnum.CAT, 1d);
        map.put(AnimalEnum.CAT, 2d);
        map.put(AnimalEnum.HIPPO, 4d);
        map.put(AnimalEnum.PENGUIN, 4d);
        map.put(AnimalEnum.MOUSE, 4d);
        map.put(AnimalEnum.HIPPO, 6d);

        final AtomicInteger i = new AtomicInteger(0);
        map.keys(k -> {
            if (i.get() == 0) {
                assertThat(k, is(AnimalEnum.CAT));
            }
            if (i.get() == 1) {
                assertThat(k, is(AnimalEnum.HIPPO));
            }
            if (i.get() == 2) {
                assertThat(k, is(AnimalEnum.MOUSE));
            }
            if (i.get() == 3) {
                assertThat(k, is(AnimalEnum.PENGUIN));
            }
            i.incrementAndGet();
        });
        assertThat(i.get(), is(4));
    }


    @Test
    public void testForEachValue() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        map.put(AnimalEnum.CAT, 1d);
        map.put(AnimalEnum.CAT, 2d);
        map.put(AnimalEnum.CAT, 3d);
        map.put(AnimalEnum.HIPPO, 4d);
        map.put(AnimalEnum.HIPPO, 5d);
        map.put(AnimalEnum.HIPPO, 6d);

        Map<Double, Boolean> values = new HashMap<>();
        values.put(3d, false);
        values.put(6d, false);

        map.forEach((k, v) -> {
            assertThat(values.containsKey(v), is(true));
            values.put(v, true);
        });
        assertThat(values.values().contains(false), is(false));
    }

    @Test
    public void testContains() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        assertThat(map.size(), is(0));
        assertThat(map.isEmpty(), is(true));
        map.put(AnimalEnum.CAT, 0d);
        map.put(AnimalEnum.CAT, 1d);
        map.put(AnimalEnum.DOG, 2d);
        map.put(AnimalEnum.MOUSE, 3d);
        map.put(AnimalEnum.HIPPO, 4d);
        map.put(AnimalEnum.PENGUIN, 5d);
        map.put(AnimalEnum.HIPPO, 6d);


        assertThat(map.containsKey(AnimalEnum.CAT), is(true));
        assertThat(map.containsKey(AnimalEnum.DOG), is(true));
        assertThat(map.containsKey(AnimalEnum.MOUSE), is(true));
        assertThat(map.containsKey(AnimalEnum.PENGUIN), is(true));
        assertThat(map.containsKey(AnimalEnum.HIPPO), is(true));
        assertThat(map.containsValue(1d), is(true));
        assertThat(map.containsValue(2d), is(true));
        assertThat(map.containsValue(3d), is(true));
        assertThat(map.containsValue(4d), is(false));
        assertThat(map.containsValue(5d), is(true));
        assertThat(map.containsValue(6d), is(true));
        assertThat(map.size(), is(5));

        // remove 1
        map.remove(AnimalEnum.CAT);
        assertThat(map.containsKey(AnimalEnum.CAT), is(false));
        assertThat(map.containsKey(AnimalEnum.DOG), is(true));
        assertThat(map.containsKey(AnimalEnum.MOUSE), is(true));
        assertThat(map.containsKey(AnimalEnum.PENGUIN), is(true));
        assertThat(map.containsKey(AnimalEnum.HIPPO), is(true));
        assertThat(map.containsValue(1d), is(false));
        assertThat(map.containsValue(2d), is(true));
        assertThat(map.containsValue(3d), is(true));
        assertThat(map.containsValue(4d), is(false));
        assertThat(map.containsValue(5d), is(true));
        assertThat(map.containsValue(6d), is(true));
        assertThat(map.size(), is(4));
    }

    @Test
    public void shouldNotIncrementSizeWhenPutNaNValue() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        map.put(AnimalEnum.CAT, Double.NaN);
        assertThat(map.size(), is(0));
    }

    @Test
    public void shouldRemoveWhenPutNaN() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        map.put(AnimalEnum.CAT, 0);
        assertThat(map.size(), is(1));
        map.put(AnimalEnum.CAT, Double.NaN);
        assertThat(map.size(), is(0));
    }

    @Test
    public void testToString() {
        EnumDoubleMap<AnimalEnum> map = new EnumDoubleMap<>(AnimalEnum.class);
        map.put(AnimalEnum.CAT, 0);
        map.put(AnimalEnum.MOUSE, 1);
        assertThat(map.toString(), is("CAT=0.0,MOUSE=1.0"));
    }

    @Test
    public void testFirstAndLastKey() {
        EnumDoubleMap<AlphabetEnum> map = new EnumDoubleMap<>(AlphabetEnum.class);
        map.put(AlphabetEnum.A, 0);
        map.put(AlphabetEnum.B,  1);
        map.put(AlphabetEnum.C,  1.1);
        assertThat(map.firstKey(), is(AlphabetEnum.A));
        assertThat(map.lastKey(), is(AlphabetEnum.C));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEmptyGetFirst() {
        EnumDoubleMap<AlphabetEnum> map = new EnumDoubleMap<>(AlphabetEnum.class);
        assertThat(map.firstKey(), is(AlphabetEnum.A));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEmptyGetLast() {
        EnumDoubleMap<AlphabetEnum> map = new EnumDoubleMap<>(AlphabetEnum.class);
        assertThat(map.lastKey(), is(AlphabetEnum.A));
    }

    @Test
    public void find_first() {
        final EnumDoubleMap<AnimalEnum> instruments = new EnumDoubleMap<>(AnimalEnum.class);
        Arrays.asList(AnimalEnum.VALUES).forEach(instrument -> instruments.put(instrument, 1d));

        // None found
        assertNull(instruments.findFirstKey(instrument -> instrument.isNot()));

        // Find first
        assertEquals(AnimalEnum.PENGUIN, instruments.findFirstKey(instrument -> instrument.isFlag()));
    }
}