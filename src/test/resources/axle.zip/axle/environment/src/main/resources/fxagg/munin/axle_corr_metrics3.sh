#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axle_corr_metrics - Plugin to monitor the Axle Correlator Metrics 3 - Listeners

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=axle
 #%# capabilities=autoconf

=cut

. $MUNIN_LIBDIR/plugins/plugin.sh

. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Axle Correlator Metrics 3 - Listeners'
    echo 'graph_args -l 0'
    echo 'graph_category axle'
    echo 'graph_scale no'
    echo 'main_listeners.label listeners (Main)'
    echo 'main_listeners.draw LINE2'
    echo 'main_listeners.colour FF0000'		# RED
    echo 'pub_listeners.label listeners (Publisher)'
    echo 'pub_listeners.draw LINE2'
    echo 'vag1_listeners.label listeners (VAG1)'
    echo 'vag1_listeners.draw LINE2'
    echo 'vag2_listeners.label listeners (VAG2)'
    echo 'vag2_listeners.draw LINE2'
    exit 0
fi

CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logs/Correlator-FxAgg.pid
PUB_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logspublisher/Correlator-Publisher.pid
PRICING_PUB_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logspricingpub/Correlator-PricingPublisher.pid
VAG1_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logsvag1/Correlator-VAG1.pid
VAG2_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logsvag2/Correlator-VAG2.pid

CORRELATOR_PORT=15903
PUB_CORRELATOR_PORT=15904
PRICING_PUB_CORRELATOR_PORT=15905
VAG1_CORRELATOR_PORT=15911
VAG2_CORRELATOR_PORT=15912

# function parameters: PIDFILE PORT NAME
function getvalue {
	PIDFILE=$1
	PORT=$2
	NAME=$3
	# If there is no pidfile present OR there is a pidfile but no corresponding process then return undefined
	if [ ! -f ${PIDFILE} ] || [ ! -d /proc/`cat ${PIDFILE}` ]; then
		echo "${NAME}_listeners.value U"
	else
		# get new engine stats
		read uptime contexts monitors submonitors javaapps listeners sublisteners eventtypes inputqueue received routequeue routed consumers outputqueue created sent processed << DONE
		`${APAMA_HOME}/bin/engine_watch -r -o -p ${PORT} | sed 's/,/ /g'`
DONE
		echo "${NAME}_listeners.value $listeners"
	fi
}

# print the values for all the correlators
getvalue $CORRELATOR_PIDFILE $CORRELATOR_PORT main
getvalue $PUB_CORRELATOR_PIDFILE $PUB_CORRELATOR_PORT pub
getvalue $PRICING_PUB_CORRELATOR_PIDFILE $PRICING_PUB_CORRELATOR_PORT pricing_pub
getvalue $VAG1_CORRELATOR_PIDFILE $VAG1_CORRELATOR_PORT vag1
getvalue $VAG2_CORRELATOR_PIDFILE $VAG2_CORRELATOR_PORT vag2

