package com.anz.axle.lg.adapter.apama.decoder;

import java.util.concurrent.TimeUnit;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link UtcTimestampConverter}
 */
public class UtcTimestampConverterTest {
    private static final DateTimeFormatter TIMESTAMP_SECONDS_FORMAT = DateTimeFormat.forPattern("yyyyMMdd-HH:mm:ss").withZoneUTC();
    private static final DateTimeFormatter TIMESTAMP_MILLISECONDS_FORMAT = DateTimeFormat.forPattern("yyyyMMdd-HH:mm:ss.SSS").withZoneUTC();

    @Test
    public void shouldConvertToNanos() {
        // Testing input in SECONDS format
        final long nanos1 = UtcTimestampConverter.dateTimeToNanos("20130828-04:54:23");
        assertEquals(nanos1, TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_SECONDS_FORMAT.parseDateTime("20130828-04:54:23").getMillis()));

        // Testing input in MILLISECONDS format
        final long nanos2 = UtcTimestampConverter.dateTimeToNanos("20141021-03:44:13.586");
        assertEquals(nanos2, TimeUnit.MILLISECONDS.toNanos(TIMESTAMP_MILLISECONDS_FORMAT.parseDateTime("20141021-03:44:13.586").getMillis()));
    }

    @Ignore// ngaro date/time decoder currently does not support validation, re-enable when supported
    @Test
    public void shouldReturnZero_WhenBadlyFormattedDateTimeString() {
        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISH"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos(""), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos(null), 0L);

        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISHRUBBISHRUB"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISH8-04:54:23"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-RU:54:23"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04:BB:23"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04:54:IS"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828R04:54:23"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828R04U54B23"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04R54U23"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISH8-RU:BB:IS"), 0L);

        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISHRUBBISHRUBBISH"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISH8-04:54:23.586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-RU:54:23.586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04:BB:23.586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04:54:IS.586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04:54:23.ISH"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828R04:54:23.586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828R04U54B23I586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("20130828-04R54U23B586"), 0L);
        assertEquals(UtcTimestampConverter.dateTimeToNanos("RUBBISH8-RU:BB:IS.ISH"), 0L);
    }

}
