package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Optional;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;


import com.anz.markets.efx.ngaro.api.Tenor;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SettleTypeToTenorTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private SettleTypeToTenor settleTypeToTenor = new SettleTypeToTenor();

    @Test
    public void apply() throws Exception {
        assertThat(settleTypeToTenor.apply("M1")).isEqualTo(Tenor.M1);
    }

    @Test
    public void apply_ebs_spot() throws Exception {
        assertThat(settleTypeToTenor.apply("0")).isEqualTo(Tenor.SP);
    }


    @Test
    public void apply_unknown() throws Exception {
        //given
        thrown.expect(IllegalArgumentException.class);

        settleTypeToTenor.apply("XX");
    }


}