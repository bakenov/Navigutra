package com.anz.axle.lg.adapter.hsp.chronicleitch;

import org.junit.Before;
import org.junit.Test;

import com.anz.markets.efx.ngaro.api.InstrumentKey;

import static com.anz.markets.efx.pricing.codec.api.EntryType.BID;
import static com.anz.markets.efx.pricing.codec.api.EntryType.OFFER;
import static org.junit.Assert.assertEquals;

public class SymbolOrderIdSideLookUpTest {

    private static final long GBPJPY = InstrumentKey.of("GBPJPY").instrumentId();
    private static final long GBPAUD = InstrumentKey.of("GBPAUD").instrumentId();
    private SymbolOrderIdSideLookUp lookUp;

    @Before
    public void setUp() throws Exception {
        lookUp = new SymbolOrderIdSideLookUp();
        lookUp.cache(GBPJPY, 1, BID);
        lookUp.cache(GBPJPY, 2, OFFER);
        lookUp.cache(GBPJPY, 3, BID);
        lookUp.cache(GBPJPY, 4, OFFER);

        lookUp.cache(GBPAUD, 1, OFFER);
        lookUp.cache(GBPAUD, 2, BID);
        lookUp.cache(GBPAUD, 3, OFFER);
        lookUp.cache(GBPAUD, 4, BID);

        lookUp.cache(GBPAUD, 5, BID);
    }

    @Test
    public void cache_lookup() throws Exception {
        assertEquals(lookUp.lookUpSide(GBPAUD, 4), BID);
        assertEquals(lookUp.lookUpSide(GBPJPY, 2), OFFER);
    }

    @Test
    public void cache_lookup_mutable() throws Exception {
        assertEquals(lookUp.lookUpSide(GBPAUD, 5), BID);
        assertEquals(lookUp.lookUpSide(GBPAUD, 5), BID);
        assertEquals(lookUp.lookUpSide(GBPAUD, 10), null);
    }

    @Test
    public void remove_entry() throws Exception {
        lookUp.remove(GBPAUD, 4);
        assertEquals(lookUp.lookUpSide(GBPAUD, 4), null);
        assertEquals(lookUp.lookUpSide(GBPJPY, 2), OFFER);
    }

    @Test
    public void cache_null() throws Exception {
        lookUp.cache(InstrumentKey.of(GBPAUD).instrumentId(), 10, null);
        assertEquals(lookUp.lookUpSide(InstrumentKey.of(GBPAUD).instrumentId(), 10), null);
    }
}