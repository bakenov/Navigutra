package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.efx.ngaro.math.Epsilon;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.pricing._1b_order_book_cleansing.MAFilterTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.BenchmarkSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.LatencyFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.BenchmarkCalculationType;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.google.common.collect.Lists;
import org.hamcrest.core.Is;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Market.WSP_A;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

@Requirement(Ref.PRICING__4_3_3)
public class BenchmarkSpread_Test extends BaseAcceptanceSpecification {
    private static final double EPSILON = Epsilon.EPS_1eNegative10.getValue();

    final Instrument ccyPair = Instrument.AUDUSD;

    private ConfigurationDataDefault configuration() {

        ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                .setPassiveHedgerConfigs(Collections.emptyList())
                // Set up L Filter
                .setLatencyFilterConfigs(Arrays.asList(
                        new LatencyFilterConfigImpl(Market.AXL, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.CNX, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.BARX, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.GS, Integer.MAX_VALUE),
                        new LatencyFilterConfigImpl(Market.HSP, 10)
                ));

        return configurationDataDefault;
    }

    @Test
    @DisplayName("Benchmark spread(TIGHTEST) taken from markets in WSP_U book")
    @RestartBeforeTest(reason = "Widening needs restart.")
    public void benchmarkSpreadTightestMktFromWSPUBook() {
        /**
         *  Verify benchmark spread using TIGHTEST spread method
         *  Verify only prices in WSP_U book are considered
         *  Verify only markets in Benchmark config are considered(see default BenchmarkSpreadConfigs for list of venues)
         **/
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76101, 0.76106));
        }
        then:
        {
            // WSP_A Benchmark spread is 0.76106-0.76101 = 0.5 pip
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.5));
            prophet.clearOutputBuffer();
        }
        when:
        {
            // HSP 0.4 pip spread tighter than CNX but will be filtered L-filter. Will not generate new client price
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76101, 0.76105, now() - 1000L));

            // trigger client price
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76099, 0.76105));
        }
        then:
        {   // HSP(tightest spread) filtered out
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.HSP)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_LATENCY), is(FilterDecision.FAIL));

            // WSP_A Benchmark spread for Client Prices 0.6 pip
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getMarket(), Is.is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.6));

            prophet.clearOutputBuffer();
        }
        when:
        {
            // HSP now has tightest spread of 0.4 pip.
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76101, 0.76105));
        }
        then:
        {
            // Benchmark spread for Client Prices now at 0.4 pip (HSP)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getMarket(), Is.is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.4));

            prophet.clearOutputBuffer();
        }
        when:
        {   // Send market update(tighter spread) from venue NOT configured as a reference market for AUD/USD. Does not generate Client price
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, ccyPair, 0.76102, 0.76105));

            // trigger Client Price.
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76102, 0.76107));
        }
        then:
        {
            // Benchmark spread for Client Prices still at 0.4 pip (HSP)
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getMarket(), Is.is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.4));
        }
    }

    @Ignore("5 second invalidation has been removed")
    @Test
    @DisplayName("Benchmark spread(TIGHTEST) ignore STALE(5sec hardcoded) market")
    public void benchmarkSpreadTightestMktIgnoreStaleMkt() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(configuration());
        }
        when:
        // t+0 CNX 0.5 pip spread
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76101, 0.76106));
        }
        then:
        {
            // WSP_A Benchmark spread is 0.76106-0.76101 = 0.5 pip
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.5));
            prophet.clearOutputBuffer();
        }
        when:
        // t+5.001 HSP 0.6 pip spread(TOB price to generate client price)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5) + TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76102, 0.76108));
        }
        then:
        {
            // Benchmark spread for Client Prices now at 0.6 pip (HSP) as CNX(0.5pip spread) is STALE
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getMarket(), Is.is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.6));
        }
    }

    @Test
    @RestartBeforeTest(reason = "Widening needs restart.")
    @DisplayName("Benchmark spread(AVERAGE) taken from markets in WSP_U book")
    @Requirement(Requirement.Ref.PRICING_AXPROPHET_1134)
    public void benchmarkSpreadAvgOfMktsFromWSPUBook() {
        /**
         *  Verify benchmark spread using AVG spread method
         *  Verify only markets in Benchmark config are considered
         **/
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configWithAverageBenchmark = configuration();

            configWithAverageBenchmark.setBenchmarkSpreadConfigs(Lists.newArrayList(
                    new BenchmarkSpreadConfigImpl(Market.ANY, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                            .setBenchmarkCalculationType(BenchmarkCalculationType.AVERAGE)
                            .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                            .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                            .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.CNX, Market.GS))
            ));

            prophet.receive(configWithAverageBenchmark);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76102, 0.76108));
        }

        then:
        {
            // WSP_A Benchmark spread is 0.6 pip
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.6));
            prophet.clearOutputBuffer();
        }
        when:
        {
            // HSP spread of 0.75 pip.
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76102, 0.761095));

            // GS spread of 0.65 pip.
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.76100, 0.761065));
        }
        then:
        {
            // Benchmark Average spread = (CNX(0.6) + HSP(0.75)) + GS(0.65) / 3 = 0.6667
            LinkedList<WholesaleBookFactors> wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(WSP_A));
            assertThat(wholesaleBookFactors.getLast().getBenchmarkSpread(), new IsRoundedTo(0.6667));

            prophet.clearOutputBuffer();
        }
        when:
        {   // Send market update from venue NOT configured as a reference market for AUD/USD. Will not generate Client price
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.BARX, ccyPair, 0.76103, 0.76104));

            // trigger Client Price
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.76104, 0.761105));
        }
        then:
        {
            // Avg Benchmark spread remains at 0.6667
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getMarket(), Is.is(Market.WSP_A));
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.6667));
        }
    }

    @Test
    @RestartBeforeTest(reason = "clear prices")
    @DisplayName("AXPROPHET-790 WSP_U can be used as a benchmark Market")
    @Requirement(Requirement.Ref.PRICING_AXPROPHET_1134)
    public void benchmarkMarketWSPU() {
        /**
         *  Verify WSP_U can be used as a Benchmark market
         **/
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configWithAverageBenchmark = configuration();

            configWithAverageBenchmark.setBenchmarkSpreadConfigs(Lists.newArrayList(
                    new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                            .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                            .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                            .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                            .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.GS, Market.WSP_U)),
                    new BenchmarkSpreadConfigImpl(Market.ANY, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                            .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                            .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                            .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                            .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.GS))
            ));

            prophet.receive(configWithAverageBenchmark);
        }
        when:
        // HSP spread 0.5pip
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76100, 0.76105));
        }
        then:
        {
            // WSP_A Benchmark spread is 0.5 pip
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.5));
        }
        when:
        // GS spread 0.4pip
        // WSP_U spread 0.3 pip
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.76102, 0.76106));
        }
        then:
        {
            // WSP_A Benchmark spread is 0.3 pip(as WSP_U has tightest spread
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.3));
        }
    }

    @Test
    @RelatedTest(MAFilterTest.class) // do_not_remove_any_market_when_TOB_inverted_on_threshold()
    @DisplayName("AXPROPHET-804 WSP_U crossed will be ignored as a reference mkt")
    public void crossedWSPUReferenceMktIgnored() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configWithAverageBenchmark = configuration();

            configWithAverageBenchmark
                    /**
                     * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
                     * set spread-multiplier config = 1.5
                     * threshold = 0.2 * 1.5 = 0.3 pips / 0.00003
                     */
                    .setStandardMarketSpreadConfigs(Lists.newArrayList(
                            new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                    ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.5).setSpotDecimalPlaces(4.0).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_BOOK_CROSSED),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_DISPERSION)
                    ))
                    .setBenchmarkSpreadConfigs(Lists.newArrayList(
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.GS, Market.WSP_U))
                    ));

            prophet.receive(configWithAverageBenchmark);
        }
        when:
        // HSP spread 0.5pip
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.75010, 0.75012));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.75015, 0.75017));
        }
        then:
        {
            // WSP_U TOB (0.75015, 0.75012) crossed by 0.3pip.  Threshold = 0.3. Therefore do NOT remove any market
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75015, 0.75012));
            assertThat(marketDataSnapshot.getSpread(), is(closeTo(-0.00003, EPSILON)));

            // benchmark spread of GS is used
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.2));
        }
    }

    @Test
    @RelatedTest(MAFilterTest.class) // do_not_remove_any_market_when_TOB_inverted_on_threshold()
    @DisplayName("AXPROPHET-804 WSP_U choice will not be allowed as a reference mkt")
    public void choiceWSPUReferenceMkt() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configWithAverageBenchmark = configuration();

            configWithAverageBenchmark
                    /**
                     * set standard-spread config for AUDUSD London TZ = 0.2 pips / 0.00002
                     * set spread-multiplier config = 1.5
                     * threshold = 0.2 * 1.5 = 0.3 pips / 0.00003
                     */
                    .setStandardMarketSpreadConfigs(Lists.newArrayList(
                            new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.00002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                    ))
                    .setInstrumentConfigs(Lists.newArrayList(
                            new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1.5).setSpotDecimalPlaces(4.0).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(5).setAllInFractionalPip(1).setPrecisionMultiplier(4)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_BOOK_CROSSED),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_DISPERSION)
                    ))
                    .setBenchmarkSpreadConfigs(Lists.newArrayList(
                            new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                    .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                    .setTooTightThresholdAsProportionOfBaseSpread(3.0)
                                    .setWidenedSpreadAsProportionOfBenchmarkSpread(1.2)
                                    .setBenchmarkSpreadMarkets(Arrays.asList(Market.HSP, Market.GS, Market.WSP_U))
                    ));

            prophet.receive(configWithAverageBenchmark);
        }
        when:
        // HSP spread 0.5pip
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.75009, 0.75012));
        }
        then:
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.3));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.75012, 0.75017));
        }
        then:
        {
            // WSP_U tob is choice with spread of 0
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75012, 0.75012));
            assertThat(marketDataSnapshot.getSpread(), is(closeTo(0.0000, EPSILON)));

            // WSP_U with choice spread not considered as valid benchmark
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(ccyPair)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.3));
        }
    }

    @Test
    @DisplayName("AXPROPHET-804 WSP_U with Failed Filters still used as a benchmark Market")
    @RestartBeforeTest(reason = "clear prices")
    public void benchmarkMarketWSPUWithFailedFilters() {
        double spreadAXL = 0.5;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configWithAverageBenchmark = configuration();

            configWithAverageBenchmark
                    .setFilterEnabledConfigs(union(
                            tdd.enableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKET_ORDER_BOOK_SLOWEST_MARKET_TOLERANCE_MS, 100L))
                    .setBenchmarkSpreadConfigs(Lists.newArrayList(
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(0.4)  // set small so widening is required
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.0)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.AXL)),
                        new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_B)
                                .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                .setTooTightThresholdAsProportionOfBaseSpread(0.4) // set small so widening is required
                                .setWidenedSpreadAsProportionOfBenchmarkSpread(1.0)
                                .setBenchmarkSpreadMarkets(Arrays.asList(Market.WSP_U))
                    ));

            prophet.receive(configWithAverageBenchmark);
        }
        when:
        // CAT_A AXL spread 0.5 => wins
        // CAT_B WSP_U spread 0.4
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.AXL, ccyPair, 0.76100, 0.76105)); // spread 0.5
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76100, 0.76104)); // spread 0.4

        }
        then:
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(spreadAXL));
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), Is.is(FactorWindow.CAT_A));
        }
        when:
        // AXL Spread 0.5
        // HSP filtered by AGG_BOOK_SLOWEST_MARKET
        // CAT_B WSP_U Spread 0.6 => wins

        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(105));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.76100, 0.76106));
        }
        then:
        {
            // WSP_U spread 0.6pip as HSP fails AGG_BOOK_SLOWEST_MARKET
            FilteredMarketDataSnapshot filteredWSPU = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(filteredWSPU.getSpread(), is(closeTo(0.00006, EPSILON)));

            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.6));
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), Is.is(FactorWindow.CAT_B));
        }
    }

    @Test
    // AXPROPHET-1369 custom aggbook i.e WSP_BENCH
    public void benchmarkMarketWSPBenchWithFailedFilters() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configWithAverageBenchmark = configuration();

            configWithAverageBenchmark
                    .setFilterEnabledConfigs(union(
                            tdd.enableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKET_ORDER_BOOK_SLOWEST_MARKET_TOLERANCE_MS, 100L))
                    .setBenchmarkSpreadConfigs(Lists.newArrayList(
                            new BenchmarkSpreadConfigImpl(Market.WSP_A, Region.GB, Instrument.AUDUSD, FactorWindow.CAT_A)
                                    .setBenchmarkCalculationType(BenchmarkCalculationType.MINIMUM)
                                    .setTooTightThresholdAsProportionOfBaseSpread(0.4)  // set small so widening is required
                                    .setWidenedSpreadAsProportionOfBenchmarkSpread(1.0)
                                    .setBenchmarkSpreadMarkets(Arrays.asList(Market.WSP_BENCH))
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_BENCH,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.HSP,Market.GS)
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP,Market.FASTMATCH,Market.GS,Market.RFX,Market.EBS);

            prophet.receive(configWithAverageBenchmark);
        }
        when:
        // WSP_BENCH spread is 0.4 as CNX is not part of this aggbook
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76101, 0.76106));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76100, 0.76104));
        }
        then:
        {
            FilteredMarketDataSnapshot fmdss = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_BENCH)).getLast();
            assertThat(fmdss.getTopOfBookBid().getPrice(), is(0.76100));
            assertThat(fmdss.getTopOfBookOffer().getPrice(), is(0.76104));

            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.4));
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), Is.is(FactorWindow.CAT_A));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(105));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.GS, ccyPair, 0.76099, 0.76105));
        }
        then:
        // HSP filtered by AGG_BOOK_SLOWEST_MARKET
        // WSP_BENCH spread is therefore 0.6
        {
            FilteredMarketDataSnapshot fmdss = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_BENCH)).getLast();
            assertThat(fmdss.getTopOfBookBid().getPrice(), is(0.76099));
            assertThat(fmdss.getTopOfBookOffer().getPrice(), is(0.76105));

            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getBenchmarkSpread(), new IsRoundedTo(0.6));
            assertThat(wholesaleBookFactors.getBenchmarkMarketCategory(), Is.is(FactorWindow.CAT_A));
        }
    }
}