package com.anz.markets.prophet.config.app;


import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersisterConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.simulator.ForwardPointSimulator;
import com.anz.markets.prophet.simulator.regulator.FrequencyRegulator;
import com.anz.markets.prophet.simulator.regulator.FrequencyRegulatorFactory;
import com.anz.markets.prophet.status.Context;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;


@Configuration
@PropertySources({
        @PropertySource(value = "classpath:conf/fromDatafabricSimulator.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class FromDatafabricSimulatorConfig extends JmxConfig {

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.df_sim:-7}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    @Bean
    public LegacyChroniclePersister fromDatafabricChroniclePersister(
            @Value("${chronicle.df.path:./chronicle.df}") final String chronicleFromDatafabric,
            @Value("${chronicle.df.type:INDEXED}") final LegacyChronicleConfig.ChronicleType chronicleType) throws IOException {

        Context.instance((byte) 0);
        Context.stage(Stage.SIMULATED);

        return new LegacyChroniclePersister(LegacyChroniclePersisterConfig.unchanged(chronicleFromDatafabric, chronicleType), true);
    }

    @Bean
    public ForwardPointSimulator createForwardPointSimulator(
            @Value("${simulator.forwardPoint.messagesPerSecond:1}") final double messagesPerSecond,
            @Qualifier("fromDatafabricChroniclePersister") final LegacyChroniclePersister LegacyChroniclePersister) throws InterruptedException {
        final FrequencyRegulator frequencyRegulator = FrequencyRegulatorFactory.createRegulatorSustained(messagesPerSecond);
        final ForwardPointSimulator forwardPointSimulator = new ForwardPointSimulator(frequencyRegulator, LegacyChroniclePersister.consumerForwardPoint());
        forwardPointSimulator.start();
        return forwardPointSimulator;
    }


}
