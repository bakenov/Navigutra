package com.anz.markets.prophet.atest.pricing._0b_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.LatencyFilterConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * L-Filter : latent market data filter (exclude that price update if source timestamp too old)
 */
@RestartBeforeTest(reason = "clear prices")
public class LFilterTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_1_6, incompleteness = "Config for latency needs to be definable per market.")
    @DisplayName("Don't remove market data that is not latent.")
    public void Should_not_remove_market_WHEN_is_not_latent() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setLatencyFilterConfigs(Arrays.asList(new LatencyFilterConfigImpl(Market.CNX, Long.MAX_VALUE)))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94332, 0.00004, now()));
        }
        then:
        // unskew book is generated
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(1));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.94330, 0.94334));
        }
        and:
        // cnx has not been filtered with latency filter and is passed.
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_LATENCY), is(FilterDecision.PASS));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_1_6)
    @DisplayName("Should remove market data that is latent.")
    public void should_remove_market_WHEN_is_latent() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setLatencyFilterConfigs(Arrays.asList(
                            new LatencyFilterConfigImpl(Market.CNX, 10L)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
            );
        }
        when:
        // received market data that is 9ms old
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94332, 0.00004, now() - 9L));
        }
        then:
        // market data should not be filtered out.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX));
            assertThat(marketDataSnapshotList.getFirst().getFilterOutcome(MarketDataFilterType.MARKET_LATENCY), is(FilterDecision.PASS));
        }
        when:
        // received market data that is 10ms old
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94330, 0.00004, now() - 10L));
        }
        then:
        // market data should be filtered out.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX));
            assertThat(marketDataSnapshotList.getFirst().getFilterOutcome(MarketDataFilterType.MARKET_LATENCY), is(FilterDecision.FAIL));
        }
        when:
        // AXPROPEHT-1446 Bidirectional market data latency filter
        // received market data that is 10ms from the future
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.94332, 0.00004, now() + 10L));
        }
        then:
        // market data should be filtered out.
        {
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX));
            assertThat(marketDataSnapshotList.getFirst().getFilterOutcome(MarketDataFilterType.MARKET_LATENCY), is(FilterDecision.FAIL));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_1_6)
    @DisplayName("Should fail and pass identical market data when filter status changes.")
    public void should_output_same_market_data_when_filter_outcome_change() throws InterruptedException {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLatencyFilterConfigs(Arrays.asList(
                            new LatencyFilterConfigImpl(Market.CNX, 1000L),
                            new LatencyFilterConfigImpl(Market.HSP, 1000L)
                    ))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
            );
        }
        when:
        {
            // not latent
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.95330, 0.95334, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, Instrument.AUDUSD, 0.95327, 0.95335, now()));
        }

        then:
        {   // CNX TOB
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.953305, 0.953335));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // latent CNX with identical price.
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.95330, 0.95334, now() - 1000L));
        }

        then:
        {   // CNX market data filtered out
            LinkedList<FilteredMarketDataSnapshot> marketDataSnapshotList = prophet.expect(FilteredMarketDataSnapshot.class, atLeast(1), isMarket(Market.CNX));
            assertThat(marketDataSnapshotList.get(0).getFilterOutcome(MarketDataFilterType.MARKET_LATENCY), is(FilterDecision.FAIL));
        }

        and:
        {
            // Previous CNX  is removed from WSP_U.  TOB is now HSP
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.WSP_U)).getFirst();
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookBid()).getMarket(), CoreMatchers.is(Market.HSP));
            assertThat(((MarketDataNewOrder) marketDataSnapshot.getTopOfBookOffer()).getMarket(), CoreMatchers.is(Market.HSP));

            // new client book with CNX mkt REMOVED. i.e HSP now TOB
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.953295, 0.953325));

            prophet.clearOutputBuffer();
        }

        when:
        {
            // not latent
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, Instrument.AUDUSD, 0.95330, 0.95334, now()));
        }

        then:
        {
            // new client book with CNX mkt included. i.e CNX now TOB again
            LinkedList<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrice.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.953305, 0.953335));
        }
    }
}
