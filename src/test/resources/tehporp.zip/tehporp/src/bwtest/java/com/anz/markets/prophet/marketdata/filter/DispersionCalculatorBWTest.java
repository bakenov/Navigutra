package com.anz.markets.prophet.marketdata.filter;


import com.anz.markets.prophet.domain.Market;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DispersionCalculatorBWTest {

    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private static final int THRESHOLD = 500;

    private final EnumDoubleMap<Market> midPrices = new EnumDoubleMap<>(Market.class);
    final DispersionCalculator dispersionCalculator;

    public DispersionCalculatorBWTest() {
        for (Market m : Market.values()) {
            midPrices.put(m, 2.0);
        }
        dispersionCalculator = new DispersionCalculator();
    }


    public void scenario() {
        for (int i = 0; i < REPS; i++) {
            dispersionCalculator.findOutlierMarket(midPrices);
        }
    }

    @Test
    public void testAAA_AllocationNotExceeded_WarmUp() {
        scenario();
    }

    @Test
    public void test_AllocationNotExceeded_Test() {
        helper.testAllocationNotExceeded(
                this::scenario,
                THRESHOLD // no allocation!
        );
    }

}
