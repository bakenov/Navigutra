package com.anz.markets.efx.fox.receiver;

import java.io.InputStream;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.instrument.config.InstrumentConfig;
import com.anz.markets.efx.fox.pricing.subscription.config.VenueInstrumentConfig;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class VenueInstrumentConfigLoader implements Runnable {
    private final VenueInstrumentConfig venueInstrumentConfig;
    private final SorEncoderSupplier encoderSupplier;

    public VenueInstrumentConfigLoader(final String fileName, final SorEncoderSupplier encoderSupplier) {
        final InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(Objects.requireNonNull(fileName));
        this.venueInstrumentConfig = VenueInstrumentConfig.yaml().load(inputStream);
        this.encoderSupplier = Objects.requireNonNull(encoderSupplier);
    }

    @Override
    public void run() {
        venueInstrumentConfig.getVenues().forEach((venue, securityTypeInstrumentGroups) -> {
            securityTypeInstrumentGroups.getSecurityTypes().forEach((securityType, instrumentGroups) -> {
                instrumentGroups.getInstrumentGroups().forEach(instrumentGroup -> {
                    instrumentGroup.getSymbols().forEach(symbol -> {
                        instrumentGroup.getTenors().forEach(tenor -> {
                            encoderSupplier.venueInstrumentConfig().messageStart(0,0)
                                    .venue(venue)
                                    .instrumentId(InstrumentKey.instrumentId(symbol, securityType, tenor))
                                    .priceIncrement(instrumentGroup.getPriceIncrement())
                                    .sizeIncrement(instrumentGroup.getSizeIncrement())
                                    .maxAllowedParentOrderQty(instrumentGroup.getMaxAllowedParentOrderQty())
                                    .clipSizeMultiple(instrumentGroup.getClipSizeMultiple())
                                    .minClipSize(instrumentGroup.getMinClipSize())
                                    .maxClipSize(instrumentGroup.getMaxClipSize())
                                    .staleDataTimeout(instrumentGroup.getStaleDataTimeout())
                                    .priority(instrumentGroup.getPriority())
                                    .proportion(instrumentGroup.getProportion())
                                    .enabled(instrumentGroup.isEnabled())
                                    .messageComplete();
                        });
                    });
                });
            });
        });
    }
}
