package com.anz.axle.lg.adapter.rfx.config;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;

import com.google.common.collect.ImmutableMap;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.DefaultApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.EncodingSubscriptionSender;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.FixEngine;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.UserRequestEncoder;
import com.anz.axle.lg.adapter.chroniclefix.tools.FixLogConsumer;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscriber;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestSender;
import com.anz.axle.lg.adapter.fix.UserRequestData;
import com.anz.axle.lg.adapter.rfx.common.PasswordManager;
import com.anz.axle.lg.adapter.rfx.common.TenorLookup;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

import static com.anz.axle.lg.adapter.fix.UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER;
import static com.anz.axle.lg.adapter.fix.UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_LOGOFFUSER;
import static com.anz.axle.lg.adapter.fix.UserRequestData.UserRequestDataType.USER_REQUEST_TYPE_LOGONUSER;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    private final String compId;
    private final String senderCompId;
    private final Venue venue;

    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId,
                     @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public SessionID rfxSessionId(@Value("${rfx.fix.sendercompid}") final String senderCompid,
                                  @Value("${rfx.fix.targetcompid}") final String targetCompid) {
        return new SessionID(senderCompid, targetCompid);
    }

    @Bean
    public SubscriptionRequestSender rfxEncodingSubscriptionSender(final FixMessageSender ebsMessageSender,final TenorLookup tenorLookup) {
        return new EncodingSubscriptionSender(new MarketDataRequestEncoder(tenorLookup), ebsMessageSender);
    }

    @Bean
    public SessionState rfxSessionState() {
        return new SessionState("RFX_Session");
    }

    @Bean
    public Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> rfxIncrementalRefreshEncoderFlagsAppender(
            @Value("${pricing.flag.impacted.by.trading.session.state}") final boolean enabled,
            final SessionState ebsSessionState) {
        return enabled ? PricingFlagsAppender.forSessionStateSelector(ebsSessionState) : PricingFlagsAppender.noOp();
    }

    @Bean
    public EbsUserResponseHandler ebsUserResponseHandler(final UserRequestHandler ebsUserRequestHandler,
                                                         final PricingSubscription ebsPricingSubscription,
                                                         final PasswordManager ebsPasswordManager,
                                                         final EbsBookRules ebsBookRules) {
        return new EbsUserResponseHandler(venue, ebsUserRequestHandler, ebsPricingSubscription, ebsPasswordManager, ebsBookRules);
    }

    @Bean
    public FixMessageSender ebsMessageSender(final SessionID ebsSessionId, @Lazy final FixEngine ebsFixEngine) {
        return new FixMessageSender(() ->
                ebsFixEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(ebsSessionId)).findFirst().get());
    }

    @Bean
    public EventLoop ebsChronicleEventLoop() {
        final EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false, venue.name()+"-");
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter ebsEventLoopStep(final EventLoop ebsChronicleEventLoop) {
        return new EventLoopAdapter(ebsChronicleEventLoop);
    }

    @Bean
    public FixEngineCfg fixEngineCfg(final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/ebs-chroniclefix.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final FixEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

    @Bean
    public TradingSessionRepository tradingSessionRepository() {
        return new DefaultTradingSessionRepository();
    }

    @Bean
    public TradingSessionParser tradingSessionParser(@Value("#{${ebs.fix.session.source.value.mapping}}") final Map<String, String> sourceMap,
                                                     @Value("#{${ebs.fix.session.timezone.value.mapping}}") final Map<String, String> timeZoneMap) {
        return new TradingSessionParser(sourceMap, timeZoneMap);
    }

    @Bean
    public EbsFillExecutionReportHandler ebsFillExecutionReportHandler(final TradingEncoderSupplier ebsTradingEncoderSupplier,
                                                                       final PrecisionClock precisionClock,
                                                                       final LongIdFactory messageIdGenerator,
                                                                       final TenorLookup tenorLookup,
                                                                       final SourceSequencer sourceSequencer,
                                                                       final MetricRepository<Metric, Venue> metricRepository,
                                                                       @Value("${ebs.ExecutionReport.object.pool.initial.size}") final int executionReportObjectPoolInitialSize) {

        final EbsExecutionReportHandler executionReportHandler = new EbsExecutionReportHandler(ebsTradingEncoderSupplier, precisionClock, senderCompId, compId, messageIdGenerator::get, tenorLookup, venue, sourceSequencer);
        final MonitoredQueue.MetricRecorder<Venue> tradingMetricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);

        return new DefaultEbsFillExecutionReportHandler(new MonitoredChronicleMessageHandler<>(executionReportHandler, tradingMetricRecorder), executionReportObjectPoolInitialSize);
    }

    @Bean
    public FixEngine ebsFixEngine(final FixEngineCfg fixEngineCfg,
                                  final ApplicationLogonHandler applicationLogonHandler,
                                  @Value("${appOptions:}") final String appOptions,
                                  final Consumer<FixLog> ebsFixLogConsumer,
                                  final VenueRequestKeyLookup ebsRequestKeyLookup,
                                  final PricingEncoderLookup pricingEncoderLookup,
                                  final PricingEncoderSupplier lastMarketTradePricingEncoderSupplier,
                                  final PrecisionClock precisionClock,
                                  final SubscriptionManager ebsSubscriptionManager,
                                  final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy,
                                  final EbsUserResponseHandler ebsUserResponseHandler,
                                  final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> ebsIncrementalRefreshEncoderFlagsAppender,
                                  final TradingSessionRepository tradingSessionRepository,
                                  final EventLoopAdapter ebsEventLoopStep,
                                  final MetricRepository<Metric, Venue> metricRepository,
                                  final TradingEncoderSupplier ebsTradingEncoderSupplier,
                                  final LongIdFactory messageIdGenerator,
                                  final TenorLookup tenorLookup,
                                  @Value("${ebs.fix.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                  final TradingSessionParser tradingSessionParser,
                                  final UserRequestHandler ebsUserRequestHandler,
                                  final SourceSequencer sourceSequencer,
                                  final EbsFillExecutionReportHandler ebsFillExecutionReportHandler) throws Exception {

        final FixSessionCfg ebsFixSessionCfg = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("ebs")).findFirst().get();
        ebsFixSessionCfg.sessionMessageProvider(new EbsSessionMessageProvider(venue.name(), OptionMatcher.HAS_RESET.test(appOptions), ebsFixSessionCfg));

        final EbsIncrementalRefreshHandler incrementalRefreshHandler =
                new EbsIncrementalRefreshHandler(ebsRequestKeyLookup, pricingEncoderLookup, lastMarketTradePricingEncoderSupplier, precisionClock, senderCompId, compId, ebsIncrementalRefreshEncoderFlagsAppender, tenorLookup, sourceSequencer);
        final EbsSnapshotFullRefreshHandler snapshotFullRefreshHandler =
                new EbsSnapshotFullRefreshHandler(ebsRequestKeyLookup, pricingEncoderLookup, precisionClock, ebsSubscriptionManager, senderCompId, compId, sourceSequencer);
        final DefaultMarketDataRequestRejectHandler marketDataRequestRejectHandler = new DefaultMarketDataRequestRejectHandler(ebsSubscriptionManager, subscriptionRequestRejectStrategy);

        final EbsOrderCancelRejectHandler orderCancelRejectHandler = new EbsOrderCancelRejectHandler(ebsTradingEncoderSupplier, precisionClock, senderCompId, compId, messageIdGenerator::get, tenorLookup, venue, sourceSequencer);
        final EbsTradingSessionListHandler tradingSessionListHandler = new EbsTradingSessionListHandler(tradingSessionRepository, tradingSessionParser);
        final EbsTradingSessionStatusHandler tradingSessionStatusHandler = new EbsTradingSessionStatusHandler(tradingSessionRepository);

        final MonitoredQueue.MetricRecorder<Venue> pricingMetricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value);
        final MonitoredQueue.MetricRecorder<Venue> tradingMetricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);

        final FixSessionApplication fixPricingApplication = new EbsFixSessionApplication(
                ebsUserResponseHandler,
                new MonitoredChronicleMessageHandler<>(incrementalRefreshHandler, pricingMetricRecorder),
                new MonitoredChronicleMessageHandler<>(snapshotFullRefreshHandler, pricingMetricRecorder),
                new MonitoredChronicleMessageHandler<>(marketDataRequestRejectHandler, pricingMetricRecorder),
                new MonitoredChronicleMessageHandler<>(orderCancelRejectHandler, tradingMetricRecorder),
                tradingSessionListHandler,
                tradingSessionStatusHandler,
                ebsFillExecutionReportHandler,
                applicationLogonHandler);
        ebsFixSessionCfg.messageNotifier(fixPricingApplication);

        ebsFixSessionCfg.consumer(ebsFixLogConsumer);

        final Consumer<FixSessionHandler> fixEngineLogoutHandler = f -> {
            ebsUserRequestHandler.send(USER_REQUEST_TYPE_LOGOFFUSER);
            for (int i = 0; i < waitForLogoutTimeoutInSec*2; i++) {
                LOGGER.info("Waiting for Application Session Logout Response and any messages after logout request...: {}", i+1);
                Jvm.pause(500);
            }
        };
        return FixEngine.create(venue.name()+"-FIX-ENGINE", fixEngineCfg.createInstance(ebsFixSessionCfg.hostId(), ebsEventLoopStep), fixEngineLogoutHandler, waitForLogoutTimeoutInSec);
    }

    @Bean
    public Consumer<FixLog> rfxFixLogConsumer(@Value("${rfx.fix.log_all}") final boolean enableLogging,
                                              @Value("${rfx.fix.file.log.path}") final String logPath,
                                              @Value("${rfx.fix.logging.base_path}") final String bashPath,
                                              @Value("${rfx.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public PasswordManager rfxPasswordManager(@Value("${rfx.fix.user.request.username}") final String userName,
                                              @Value("${rfx.fix.user.request.password}") final String password,
                                              @Value("${rfx.fix.user.password.file}") final String passwordPropertiesFileName) {
        return new PasswordManager(userName, password, venue, passwordPropertiesFileName);
    }

    @Bean
    public Supplier<UserRequestData> rfxLogonUserRequestData(final PasswordManager rfxPasswordManager,
                                                             @Value("#{${rfx.fix.user.request.custom.tag.values}}") final Map<Integer, String> customerTagValues,
                                                             @Value("#{${rfx.fix.user.request.name.values}}") final Map<String, String> userDataNameValues) {
        return () -> UserRequestData.logonUser(rfxPasswordManager.userName(), rfxPasswordManager.password(), customerTagValues, userDataNameValues);
    }

    @Bean
    public Supplier<UserRequestData> rfxLogoffUserRequestData(final PasswordManager rfxPasswordManager) {
        return () -> UserRequestData.logoffUser(rfxPasswordManager.userName(), rfxPasswordManager.password(), Collections.EMPTY_MAP, Collections.EMPTY_MAP);
    }

    @Bean
    public Supplier<UserRequestData> rfxChangePasswordUserRequestData(final PasswordManager rfxPasswordManager) {
        return () -> UserRequestData.changePasswordForUser(rfxPasswordManager.userName(), rfxPasswordManager.password(), rfxPasswordManager.generatePasswordAndSaveNewPassword());
    }

    @Bean
    public Map<UserRequestData.UserRequestDataType, Supplier<UserRequestData>> rfxUserRequestDataLookUp(final Supplier<UserRequestData> rfxLogonUserRequestData,
                                                                                                        final Supplier<UserRequestData> rfxLogoffUserRequestData,
                                                                                                        final Supplier<UserRequestData> rfxChangePasswordUserRequestData) {
        return ImmutableMap.of(
                USER_REQUEST_TYPE_LOGONUSER, rfxLogonUserRequestData,
                USER_REQUEST_TYPE_LOGOFFUSER, rfxLogoffUserRequestData,
                USER_REQUEST_TYPE_CHANGEPASSWORDFORUSER, rfxChangePasswordUserRequestData
        );
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler(final SessionID rfxSessionId,
                                                           final Supplier<LogonHandler> rfxSessionLogonHandlerSupplier) {

        return new DefaultApplicationLogonHandler(sessionID -> {
            if (sessionID.equals(rfxSessionId)) {
                return rfxSessionLogonHandlerSupplier.get();
            } else {
                return LogonHandler.NO_OP;
            }
        });
    }

    @Bean
    public UserRequestEncoder<UserRequest> userRequestEncoder() {
        return new EbsUserRequestEncoder();
    }

    @Bean
    public BooleanSupplier readyToSendHeartbeat(final SessionState ebsSessionState, final MarketDataSubscriber marketDataSubscriber) {
        return () -> ebsSessionState.getAsBoolean() && marketDataSubscriber.loggedOn();
    }

    @Bean
    public ScheduledFuture<?> executionReportPublishJob(final EbsFillExecutionReportHandler ebsFillExecutionReportHandler,
                                                        final Queue<Runnable> mainEventLoopQueue,
                                                        final ScheduledExecutorService scheduledExecutorService,
                                                        @Value("${ebs.ExecutionReport.delay.publish.time.in.mills}") int periodMills) {
        final long periodInNanos = TimeUnit.MILLISECONDS.toNanos(periodMills);
        final Runnable publishExecutionReports = () -> ebsFillExecutionReportHandler.publishExecutionReportsWithSendingTimeBefore(TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis()) - periodInNanos);
        return scheduledExecutorService.scheduleWithFixedDelay(() -> mainEventLoopQueue.appender().enqueue(publishExecutionReports), periodMills, periodMills, TimeUnit.MILLISECONDS);
    }
}
