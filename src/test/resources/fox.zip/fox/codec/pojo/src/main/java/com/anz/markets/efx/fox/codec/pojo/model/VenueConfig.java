package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoVenueConfigHandler;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class VenueConfig implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public VenueConfig() {
        this(new MessageHeader(), new Body());
    }

    public VenueConfig(final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
        if (body.venueCategories == null) {
            body.venueCategories = EnumSet.noneOf(VenueCategory.class);
        }
    }

    public static final class Body {
        public Venue venue;
        public String compId;
        public Set<VenueCategory> venueCategories;
        public boolean enabled;

        public Body() {
            super();
        }

        public Body(final Venue venue,
                    final String compId,
                    final Set<VenueCategory> venueCategories,
                    final boolean enabled) {
            this.venue = venue;
            this.compId = compId;
            this.venueCategories = venueCategories;
            this.enabled = enabled;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "venue=" + venue +
                    ", compId=" + compId +
                    ", venueCategories=" + venueCategories +
                    ", enabled=" + enabled +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "VenueConfig{" +
                "header=" + header +
                "body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.venueConfig());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.venueConfig().create(messageConsumer));
    }

    public void encode(final VenueConfigEncoder encoder) {
        encoder.messageStart(header.source,header.sourceSeq)
                .venue(body.venue)
                .compId().encode(body.compId)
                .venueCategories().addAll(body.venueCategories)
                .enabled(body.enabled)
                .messageComplete();
    }

    public static <M> VenueConfig decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoVenueConfigHandler handler = new PojoVenueConfigHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.venueConfig().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onVenueConfig(this);
    }
}
