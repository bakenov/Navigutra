package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LiquidityFilterConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import org.jetbrains.annotations.NotNull;

public class LiquidityFilterConfigImpl implements LiquidityFilterConfig, ProphetMarshallable {

    private final TradingTimeZone tradingTimeZone;
    private final Region region;
    private final Market market;
    private final Instrument instrument;
    private final double minimumLiquidity;
    private final double maximumDistancePips;

    public LiquidityFilterConfigImpl(final TradingTimeZone tradingTimeZone,
                                     final Region region,
                                     final Market market,
                                     final Instrument instrument,
                                     final double minimumLiquidity, // minimumLiquidity of 0 means disabled
                                     final double maximumDistancePips) {
        this.tradingTimeZone = tradingTimeZone;
        this.region = region;
        this.market = market;
        this.instrument = instrument;
        this.minimumLiquidity = minimumLiquidity;
        this.maximumDistancePips = maximumDistancePips;
    }

    @Override
    public TradingTimeZone getTradingTimeZone() {
        return tradingTimeZone;
    }

    @Override
    public Region getRegion() {
        return region;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public double getMinimumLiquidity() {
        return minimumLiquidity;
    }

    @Override
    public double getMaximumDistancePips() {
        return maximumDistancePips;
    }

    public static ProphetMarshallable constructReadMarshallable(final ProphetBytes in) {
        return new LiquidityFilterConfigImpl(
                TradingTimeZone.valueOf(in.readByte()),
                Region.valueOf(in.readByte()),
                Market.valueOf(in.readByte()),
                Instrument.readMarshallableValueOf(in),
                in.readDouble(),
                in.readDouble());
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        // no mutable fields
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(tradingTimeZone.getValue());
        out.writeByte(region.getValue());
        out.writeByte(market.getValue());
        out.writeShort(instrument.getValue());
        out.writeDouble(minimumLiquidity);
        out.writeDouble(maximumDistancePips);
    }

    @Override
    public String toString() {
        return "LiquidityFilterConfigImpl{" +
                "tradingTimeZone=" + tradingTimeZone +
                ", region=" + region +
                ", market=" + market +
                ", instrument=" + instrument +
                ", minimumLiquidity=" + minimumLiquidity +
                ", maximumDistance=" + maximumDistancePips +
                '}';
    }

}
