package com.anz.markets.prophet.risk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.positionrisk.Positions;
import org.jetbrains.annotations.NotNull;
import org.junit.Ignore;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

import static com.anz.markets.prophet.util.AmountUnit.MILLIONS;

@Ignore
public class OptimalPositionManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private Consumer<Positions> consumerOfPositions;
        private TestStubConsumer<OptimalPositions> optimalPositionsTestStubConsumer = new TestStubConsumer();
        private Positions positions;

        @Setup
        public void setup() throws IOException {
            final OptimalPositionManagerTest unitTest = new OptimalPositionManagerTest();
            final OptimalPositionManager optimalPositionManager = unitTest.createOptimalPositionManager(optimalPositionsTestStubConsumer.asList());
            consumerOfPositions = optimalPositionManager.consumerOfPositions();
            positions = MidRateTestHelper.createPositions(Currency.AUD, MILLIONS.toDollar(100), 1,
                    Currency.CAD, MILLIONS.toDollar(10), 1);
        }
    }

    @Benchmark
    public long acceptPositionsAndProduceOptimalPosition(@NotNull final Data data) throws Exception {
        data.consumerOfPositions.accept(data.positions);
        return data.optimalPositionsTestStubConsumer.getEvents().size();
    }
}
