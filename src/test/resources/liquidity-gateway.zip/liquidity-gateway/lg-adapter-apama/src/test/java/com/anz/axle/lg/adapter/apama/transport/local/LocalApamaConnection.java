package com.anz.axle.lg.adapter.apama.transport.local;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;
import com.apama.event.parser.EventType;

import com.anz.axle.lg.adapter.apama.transport.Connection;
import com.anz.axle.lg.adapter.apama.transport.ConnectionConfig;
import com.anz.axle.lg.adapter.apama.transport.ConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.Subscription;

public class LocalApamaConnection implements Connection {
    private static final Logger LOGGER = LoggerFactory.getLogger(LocalApamaConnection.class);

    private final ConnectionConfig connectionConfig;
    private final ConnectionStatusHandler connectionStatusHandler;
    private final Queue<String> messageQueue = new ManyToOneConcurrentArrayQueue<>(1000);
    private final Consumer<String> messageConsumer = messageQueue::offer;

    private volatile Thread pollerThread;

    public LocalApamaConnection(final ConnectionConfig connectionConfig, final ConnectionStatusHandler connectionStatusHandler) {
        this.connectionConfig = connectionConfig;
        this.connectionStatusHandler = connectionStatusHandler;
        pollerThread = new Thread(this::run);
        pollerThread.start();
        LOGGER.info("Started LocalApamaConnection");
        connectionStatusHandler.onConnect(this);
    }

    private void run() {
        while (pollerThread != null) {
            final String message = messageQueue.poll();
            if (message != null) {
                process(message);
            }
        }
    }

    private void process(final String message) {
        try {
            for (final String eventTypeName : subscriptions.keySet()) {
                if (message.contains(eventTypeName)) {
                    final LocalApamaSubscription subscription = subscriptions.get(eventTypeName);
                    final Event event = subscription.eventType().parse(message);
                    subscription.eventConsumer().accept(event);
                    LOGGER.info("Sent message: {}", message);
                    return;
                }
            }
        } catch (final Exception ex) {
            ex.printStackTrace();
            LOGGER.error("Failed to process message {}, exception {}", message, ex);
            connectionStatusHandler.onNotification(this, "Failed to process message");
        }
    }

    private final Map<String, LocalApamaSubscription> subscriptions = new ConcurrentHashMap<>();

    @Override
    public void close() {
        try {
            connectionStatusHandler.onDisconnect(this);
        } catch (final Exception ex) {
            LOGGER.error("onDisconnect failed with exception: {}", ex);
        }

        final Thread thread = pollerThread;
        pollerThread = null;
        try {
            thread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            LOGGER.error("LocalApamaConnection thread has been interrupted while waiting poller thread to finalise");
        }
    }

    public Consumer<String> messagePublisher() {
        return messageConsumer;
    }

    @Override
    public Subscription openSubscription(final EventType eventType, final Consumer<Event> eventConsumer) {
        final Runnable subscriptionCloser = () -> subscriptions.remove(eventType.getName());
        final LocalApamaSubscription subscription = new LocalApamaSubscription(eventType, eventConsumer, subscriptionCloser);
        subscriptions.put(eventType.getName(), subscription);
        return subscription;
    }

    @Override
    public ConnectionConfig connectionConfig() {
        return connectionConfig;
    }
}
