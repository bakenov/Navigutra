package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;


public class EnumObjTable<R extends Enum<R>, C extends Enum<C>, V> {
    private final V EMPTY = null;

    private transient R[] rowsKeyUniverse;
    private transient C[] columnsKeyUniverse;

    private final V[][] values;

    private int size;
    private final int rowCapacity;
    private final int columnCapacity;

    public EnumObjTable(final Class<R> rowType, final Class<C> columnType) {
        this(rowType, columnType, null);
    }

    public EnumObjTable(final Class<R> rowType, final Class<C> columnType, Supplier<V> supplier) {
        this.rowsKeyUniverse = rowType.getEnumConstants();
        this.columnsKeyUniverse = columnType.getEnumConstants();
        this.rowCapacity = rowsKeyUniverse.length;
        this.columnCapacity = columnsKeyUniverse.length;
        this.size = 0;
        this.values = (V[][]) new Object[rowCapacity][columnCapacity];
        if (supplier != null) {
            for (R row : rowsKeyUniverse) {
                for (C column : columnsKeyUniverse) {
                    put(row, column, supplier.get());
                }
            }
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean containsKey(R row, C column) {
        return values[row.ordinal()][column.ordinal()] != EMPTY;
    }

    public boolean containsValue(V value) {
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] == value) {
                    return true;
                }
            }
        }
        return false;
    }

    public V get(R row, C column) {
        return values[row.ordinal()][column.ordinal()];
    }

    public V put(R rowKey,
                 C columnKey,
                 V value) {
        if (!containsKey(rowKey, columnKey)) {
            size++;
        }
        final V prevValue = values[rowKey.ordinal()][columnKey.ordinal()];
        values[rowKey.ordinal()][columnKey.ordinal()] = value;
        return prevValue;
    }

    public V computeIfAbsent(R rowKey, C columnKey, Supplier<? extends V> valueSupplier) {
        V v = get(rowKey,columnKey);
        if (v == null) {
            v = valueSupplier.get();
            put(rowKey,columnKey,v);
        }
        return v;
    }


    public V computeIfAbsent(R rowKey, C columnKey, BiFunction<R, C, ? extends V> createFunction) {
        GcFriendlyAssert.notNull(createFunction);
        V x;
        if ((x = get(rowKey, columnKey)) == EMPTY) {
            V newValue;
            if ((newValue = createFunction.apply(rowKey, columnKey)) != EMPTY) {
                put(rowKey, columnKey, newValue);
                return newValue;
            }
        }
        return x;
    }

    public V remove(R rowKey, C columnKey) {
        final V previousValue = get(rowKey, columnKey);
        if (previousValue != EMPTY) {
            --size;
        }
        put(rowKey, columnKey, EMPTY);
        return previousValue;
    }

    public void clear() {
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                values[r][c] = EMPTY;
            }
        }
        size = 0;
    }

    public final void forEachRowKeyWithColumnKey(BiConsumer<R, V> action, C columnKey) {
        GcFriendlyAssert.notNull(action);
        int columnIndex = columnKey.ordinal();
        GcFriendlyAssert.isTrue(columnKey == columnsKeyUniverse[columnIndex]);

        for (int r = 0; r < rowCapacity; r++) {
            if (values[r][columnIndex] != EMPTY) {
                action.accept(rowsKeyUniverse[r], values[r][columnIndex]);
            }
        }
    }

    public final void forEachColumnKey(Consumer<C> action) {
        GcFriendlyAssert.notNull(action);
        for (int c = 0; c < columnCapacity; c++) {
            for (int r = 0; r < rowCapacity; r++) {
                if (values[r][c] != EMPTY) {
                    action.accept(columnsKeyUniverse[c]);
                    break;
                }
            }
        }
    }

    public final void forEachRowKey(Consumer<R> action) {
        GcFriendlyAssert.notNull(action);
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] != EMPTY) {
                    action.accept(rowsKeyUniverse[r]);
                    break;
                }
            }
        }
    }

    public final void forEachColumnKeyWithRowKey(BiConsumer<C, V> action, R rowKey) {
        GcFriendlyAssert.notNull(action);
        int rowIndex = rowKey.ordinal();
        GcFriendlyAssert.isTrue(rowKey == rowsKeyUniverse[rowIndex]);

        for (int c = 0; c < columnCapacity; c++) {
            if (values[rowIndex][c] != EMPTY) {
                action.accept(columnsKeyUniverse[c], values[rowIndex][c]);
            }
        }
    }

    public void forEach(Consumer<V> action) {
        GcFriendlyAssert.notNull(action);
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] != EMPTY) {
                    action.accept(values[r][c]);
                }
            }
        }
    }

    public void forEachIf(Predicate<V> predicate, Consumer<V> action) {
        GcFriendlyAssert.notNull(predicate);
        GcFriendlyAssert.notNull(action);
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] != EMPTY && predicate.test(values[r][c])) {
                    action.accept(values[r][c]);
                }
            }
        }
    }

    public void forEach(TriConsumer<R, C, V> action) {
        GcFriendlyAssert.notNull(action);
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] != EMPTY) {
                    action.accept(this.rowsKeyUniverse[r], this.columnsKeyUniverse[c], values[r][c]);
                }
            }
        }
    }

    public boolean removeIf(Predicate<V> filter) {
        GcFriendlyAssert.notNull(filter);
        boolean rv = false;
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] != EMPTY && filter.test(values[r][c])) {
                    remove(this.rowsKeyUniverse[r], this.columnsKeyUniverse[c]);
                    rv = true;
                }
            }
        }
        return rv;
    }

    @NotGcFriendly
    public String toString() {
        final ToStringHelpers.CollectTableValues toStringCollector = new ToStringHelpers.CollectTableValues();
        forEach(toStringCollector);
        return toStringCollector.toString();
    }

    @NotGcFriendly
    public String toStringRow(final R rowKey) {
        final ToStringHelpers.CollectMapValues toStringCollector = new ToStringHelpers.CollectMapValues();
        forEachColumnKeyWithRowKey(toStringCollector, rowKey);
        return toStringCollector.toString();
    }

    @NotGcFriendly
    public String toStringColumn(final C columnKey) {
        final ToStringHelpers.CollectMapValues toStringCollector = new ToStringHelpers.CollectMapValues();
        forEachRowKeyWithColumnKey(toStringCollector, columnKey);
        return toStringCollector.toString();
    }
}
