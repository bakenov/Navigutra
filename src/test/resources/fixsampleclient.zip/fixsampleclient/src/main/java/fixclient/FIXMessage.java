// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.util.ArrayList;

/**
 * A wrapper for a FIX message, including direction (send or receive). An XML
 * Script is parsed into a collection of these messages.
 */
public class FIXMessage
{
    private final FIXMessageDirection          direction;
    private final ArrayList<FIXField>          messageFields = new ArrayList<FIXField>();
    private final String                       messageType;
    private final ArrayList<FIXRepeatingGroup> groups        = new ArrayList<FIXRepeatingGroup>();

    /**
     * Main Constructor
     * 
     * @param messageType
     * @param direction
     */
    public FIXMessage(final String messageType,
                      final FIXMessageDirection direction)
    {
        this.messageType = messageType;
        this.direction = direction;
    }

    /**
     * @return Message type
     */
    public String getMessageType()
    {
        return this.messageType;
    }

    /**
     * @return the direction of the message
     */
    public FIXMessageDirection getDirection()
    {
        return this.direction;
    }

    /**
     * Adds a field to the message
     * 
     * @param key
     * @param value
     * @throws IllegalStateException
     */
    public void addField(final String key, final String value) throws IllegalStateException
    {
        this.messageFields.add(new FIXField(key, value));
    }

    /**
     * Returns a set containing all fields
     * 
     * @return a set containing all the fields in the message
     */
    public ArrayList<FIXField> getFields()
    {
        return this.messageFields;
    }

    /**
     * Gets a collection of groups for this message
     * 
     * @return Collection of FIXMessageGroup
     */
    public ArrayList<FIXRepeatingGroup> getRepeatingGroups()
    {
        return this.groups;
    }

    /**
     * Adds a group to a FIXMessage
     * 
     * @param group
     */
    public void addGroup(final FIXRepeatingGroup group)
    {
        this.groups.add(group);
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuffer buf = new StringBuffer(this.direction == FIXMessageDirection.SEND
                ? "SEND"
                : "RECEIVE");

        buf.append(" type=").append(this.messageType);

        for (final FIXField element : this.messageFields)
        {
            buf.append(" ")
                    .append(element.getId())
                    .append("=")
                    .append(element.getValue());
        }

        for (final FIXRepeatingGroup group : this.groups)
        {
            buf.append(" ").append(group.toString());
        }

        return buf.toString();
    }

    /**
     * An enumeration specifying the message direction of this FIX message
     * 
     */
    public enum FIXMessageDirection {
        /**
         * For Northbound messages
         */
        SEND,
        /**
         * For Southbound messages
         */
        RECEIVE;
    }
}
