package com.anz.axle.lg.adapter.d3.newsubscription;

import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.UpdateMessage;

public interface Subscription {
    Subscription NO_OP = new Subscription() {
        @Override
        public void subscribe(final long expireTimeMillis) {
            //no op
        }

        @Override
        public void resubscribe(long subscribeDelayMillis) {
            //no op
        }

        @Override
        public void processUpdate(final UpdateMessage updateMessage) {
            //no op
        }

        @Override
        public void processError(final ErrorMessage errorMessage) {
            //no op
        }

        @Override
        public void processError(final String errorMessage) {
            //no op
        }

        @Override
        public void handleExpired() {
            //no op
        }

        @Override
        public void handleMissedUpdate() {
            //no op
        }

        @Override
        public void retryFailed() {
            //no op
        }

        @Override
        public void publishLatestUpdate() {
            //no op
        }

        @Override
        public void stop() {
            //no op
        }
    };

    void subscribe(long expireTimeMillis);

    void resubscribe(long subscribeDelayMillis);

    void processUpdate(UpdateMessage updateMessage);

    void processError(ErrorMessage errorMessage);

    void processError(String errorMessage);

    void handleExpired();

    void handleMissedUpdate();

    void retryFailed();

    void publishLatestUpdate();

    void stop();
}
