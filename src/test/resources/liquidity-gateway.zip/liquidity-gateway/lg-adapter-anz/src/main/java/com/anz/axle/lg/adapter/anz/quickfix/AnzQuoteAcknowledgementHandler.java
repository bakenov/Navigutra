package com.anz.axle.lg.adapter.anz.quickfix;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Message;
import quickfix.field.MDReqRejReason;
import quickfix.field.QuoteAckStatus;
import quickfix.field.QuoteReqID;
import quickfix.field.QuoteStatus;
import quickfix.field.Text;
import quickfix.field.UnderlyingSymbol;

import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;

/**
 * The ANZ Direct API will send a QuoteAcknowledgement to the Client to reject an unsupported QuoteRequest
 * or cancel an existing Quote subscription
 */
public class AnzQuoteAcknowledgementHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(AnzQuoteAcknowledgementHandler.class);

    private final SubscriptionManager subscriptionManager;
    private final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy;

    public AnzQuoteAcknowledgementHandler(final SubscriptionManager subscriptionManager,
                                          final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy) {
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.subscriptionRequestRejectStrategy = Objects.requireNonNull(subscriptionRequestRejectStrategy);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_MASS_QUOTE_ACKNOWLEDGEMENT;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {

        final int quoteAckStatus = message.getInt(QuoteAckStatus.FIELD);
        final int quoteRequestId = message.getInt(QuoteReqID.FIELD);

        if (QuoteStatus.REJECTED == quoteAckStatus) {
            final char mdRequestRejectReason = message.isSetField(MDReqRejReason.FIELD) ? message.getChar(MDReqRejReason.FIELD) : null;
            final String rejectMessage = message.isSetField(Text.FIELD) ? message.getString(Text.FIELD) : "";
            LOGGER.error("QuoteRequest has been rejected with message: {}, rejection reason code: {}", rejectMessage, mdRequestRejectReason);
        }

        if (QuoteStatus.CANCELED_FOR_SYMBOL == quoteAckStatus) {
            final String symbol = message.getString(UnderlyingSymbol.FIELD);
            LOGGER.error("QuoteRequest has been cancelled for {} with QuoteRequestId: {}", symbol, quoteRequestId);
        }

        if (QuoteStatus.REJECTED == quoteAckStatus || QuoteStatus.CANCELED_FOR_SYMBOL == quoteAckStatus) {
            subscriptionManager.rejectRequest(quoteRequestId, subscriptionRequestRejectStrategy);
        }
    }
}
