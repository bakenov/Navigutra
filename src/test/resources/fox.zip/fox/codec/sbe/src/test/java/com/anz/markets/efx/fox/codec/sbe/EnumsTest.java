package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Function;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.ngaro.api.Venue;

/**
 * Unit test for {@link Enums}
 */
public class EnumsTest {

    private static final String NULL_VAL = "NULL_VAL";

    @Test
    public void timerGroup() {
        testMapping(TimerGroup.class, com.anz.markets.efx.fox.codec.sbe.raw.TimerGroup.class, Enums::timerGroup, Enums::timerGroup);
    }

    @Test
    public void initStage() {
        testMapping(InitStage.class, com.anz.markets.efx.fox.codec.sbe.raw.InitStage.class, Enums::initStage, Enums::initStage);
    }

    @Test
    public void venue() {
        testMapping(Venue.class, com.anz.markets.efx.fox.codec.sbe.raw.Venue.class, Enums::venue, Enums::venue);
    }

//    @Test
//    public void region() {
//        testMapping(Region.class, com.anz.markets.efx.fox.codec.sbe.raw.Region.class, Enums::region, Enums::region);
//    }

    private static <A extends Enum<A>, S extends Enum<S>> void testMapping(final Class<A> apiType,
                                                                           final Class<S> sbeType,
                                                                           final Function<A, S> apiToSbeConversion,
                                                                           final Function<S, A> sbeToApiConversion) {
        final A[] apiValues = apiType.getEnumConstants();
        final S[] sbeValues = sbeType.getEnumConstants();

        //check lengths
        Assert.assertEquals("api should have same number of constants minus NULL_VAL", apiValues.length, sbeValues.length - 1);

        //check all value names match and validate forward and backward mapping
        for (final A apiVal : apiValues) {
            final S sbeVal = Enum.valueOf(sbeType, apiVal.name());
            Assert.assertEquals("constants should have same name", apiVal.name(), sbeVal.name());

            Assert.assertEquals("should map to sbe constant", sbeVal, apiToSbeConversion.apply(apiVal));
            Assert.assertEquals("should map to api constant", apiVal, sbeToApiConversion.apply(sbeVal));
        }

        //check null mappings
        Assert.assertEquals("should map to sbe NULL_VAL", NULL_VAL, apiToSbeConversion.apply(null).name());
        Assert.assertEquals("null should map to api null", null, sbeToApiConversion.apply(null));
        Assert.assertEquals("NULL_VAL should map to api null", null, sbeToApiConversion.apply(Enum.valueOf(sbeType, NULL_VAL)));
    }
}
