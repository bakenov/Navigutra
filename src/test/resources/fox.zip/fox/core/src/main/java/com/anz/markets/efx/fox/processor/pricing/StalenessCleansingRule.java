package com.anz.markets.efx.fox.processor.pricing;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;

public class StalenessCleansingRule implements Consumer<VenueInstrument> {
    private CommandContext commandContext;

    public StalenessCleansingRule(final CommandContext commandContext) {
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public void accept(final VenueInstrument venueInstrument) {
        final MarketDataBook marketDataBook = venueInstrument.marketDataBook();
        if(!marketDataBook.flagsIsEmpty()) return;

        final long staleDataThresholdNanos = TimeUnit.SECONDS.toNanos(venueInstrument.staleDataTimeout());
        if (commandContext.precisionClock().nanos() - marketDataBook.sendingTimeNanos() > staleDataThresholdNanos) {
            marketDataBook.flag(Flag.LATENT);
        }
    }
}
