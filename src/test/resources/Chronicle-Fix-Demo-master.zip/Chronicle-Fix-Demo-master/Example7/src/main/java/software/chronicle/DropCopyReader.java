package software.chronicle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.messages.HeaderTrailer;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.function.Consumer;

public class DropCopyReader implements Consumer<HeaderTrailer> {
    private static final Logger LOG = LoggerFactory.getLogger(DropCopyReader.class);

    private final FixSessionHandler dropCopySession;

    public DropCopyReader(FixSessionHandler dropCopySession) {
        this.dropCopySession = dropCopySession;
    }

    @Override
    public void accept(HeaderTrailer headerTrailer) {
        if (headerTrailer instanceof NewOrderSingle) {
            LOG.warn("Sending NOS clordid={} to drop copy", ((NewOrderSingle) headerTrailer).clOrdID());
            dropCopySession.sendMessage(headerTrailer);
        }
    }
}