package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;

public interface TimerExpiryEncoder extends MessageEncoder<TimerExpiryEncoder.Body> {
    @Override
    Body messageStart(final int source, final long sourceSeq);

    interface Body {
        Body triggeredTime(long triggeredTime);
        Body timerId(long timerId);
        Trailer timerGroup(TimerGroup timerGroup);
    }
}
