package com.anz.markets.prophet.config.business.domain.indexed;


import com.anz.markets.prophet.config.business.domain.tabular.impl.VolatilityWideningPercentileConfig;
import com.anz.markets.prophet.domain.FactorWindow;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.WidenStrategy;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.domain.collections.NoGarbageIteratorArrayList;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class VolatilityWideningPercentileConfigs {

    private static final Logger LOGGER = LoggerFactory.getLogger(VolatilityWideningPercentileConfigs.class);

    private final int initialCapacityPerGroup = 15;
    private final EnumObjTable<FactorWindow, Instrument, EnumObjTable<Market, WidenStrategy, EnumObjMap<TradingTimeZone, NoGarbageIteratorArrayList<VolatilityWideningPercentileConfig>>>> unsortedConfigTable = new EnumObjTable<>(FactorWindow.class, Instrument.class);
    private final EnumObjTable<FactorWindow, Instrument, EnumObjTable<Market, WidenStrategy, EnumObjMap<TradingTimeZone, VolatilityWideningPercentileConfig[]>>> configTable = new EnumObjTable<>(FactorWindow.class, Instrument.class);
    private final VolatilityWideningPercentileConfig[] emptyConfig = new VolatilityWideningPercentileConfig[0];

    public VolatilityWideningPercentileConfigs(List<VolatilityWideningPercentileConfig> configs) {

        unsortedConfigTable.clear();
        configs.forEach(config ->
            config.forEachTimezone(ttz -> {
                if (!Double.isNaN(config.getWideningFactor(ttz))) {
                    unsortedConfigTable.computeIfAbsent(config.factorWindow, config.instrument, (fw, i) -> new EnumObjTable<>(Market.class, WidenStrategy.class));
                    unsortedConfigTable.get(config.factorWindow, config.instrument).computeIfAbsent(config.model, config.widenStrategy, (m, ws) -> new EnumObjMap<>(TradingTimeZone.class));
                    unsortedConfigTable.get(config.factorWindow, config.instrument).get(config.model, config.widenStrategy).computeIfAbsent(ttz, (tz)-> new NoGarbageIteratorArrayList<>(initialCapacityPerGroup));

                    unsortedConfigTable.get(config.factorWindow, config.instrument).get(config.model, config.widenStrategy).get(ttz).add(config);
                }
                else {
                    LOGGER.error("NAN widening factor. ignoring for: {} {} {} {} {}", config.instrument.name(), config.factorWindow.name(), config.model.name(), config.widenStrategy.name(), ttz.name());
                }
            })
        );

        propagateInstrumentWildcard();
        propagateFactorWindowWildcard();
        propagateMarketWildcard();
        propagateWidenStrategyWildcard();

        validateConfigs();
        sortAndPopulatesConfigsByPercentile();
    }

    private void validateConfigs() {
        unsortedConfigTable.forEach((fw, i, v) -> v.forEach((m, ws, tzv) -> {
            if (ws == WidenStrategy.BIDOFFER) {
                GcFriendlyAssert.isTrue(unsortedConfigTable.get(fw, i).containsKey(m, WidenStrategy.MID),
                        "Config must contain corresponding WidenStrategy.MID setting for: %s %s %s", i.name(), fw.name(), m.name());
            }
            else if (ws == WidenStrategy.MID) {
                GcFriendlyAssert.isTrue(unsortedConfigTable.get(fw, i).containsKey(m, WidenStrategy.BIDOFFER),
                        "Config must contain corresponding WidenStrategy.BIDOFFER setting for: %s %s %s", i.name(), fw.name(), m.name());
            }
        }));
    }

    //propagate instrument.ANY for all other unset configs.
    private void propagateInstrumentWildcard() {
        for (Instrument i : Instrument.VALUES) {
            unsortedConfigTable.forEachRowKey((fw) -> {
                if (i != Instrument.ANY && unsortedConfigTable.containsKey(fw, Instrument.ANY) && !unsortedConfigTable.containsKey(fw, i)) {
                    unsortedConfigTable.put(fw, i, unsortedConfigTable.get(fw, Instrument.ANY));
                }
            });
        }

        unsortedConfigTable.forEach((fw, i , v) -> {
            if (i != Instrument.ANY) {
                for (Market m : Market.VALUES) {
                    for (WidenStrategy ws : WidenStrategy.VALUES) {
                        if (!unsortedConfigTable.get(fw, i).containsKey(m, ws) && unsortedConfigTable.containsKey(fw, Instrument.ANY) && unsortedConfigTable.get(fw, Instrument.ANY).containsKey(m, ws)) {
                            unsortedConfigTable.get(fw, i).put(m, ws, unsortedConfigTable.get(fw, Instrument.ANY).get(m, ws));
                        }
                    }
                }
            }
        });
    }

    //propagate factorWindow.ANY for all other unset configs.
    private void propagateFactorWindowWildcard() {
        for (FactorWindow fw : FactorWindow.VALUES) {
            unsortedConfigTable.forEachColumnKey((i) -> {
                if (fw != FactorWindow.ANY && unsortedConfigTable.containsKey(FactorWindow.ANY, i) && !unsortedConfigTable.containsKey(fw, i)) {
                    unsortedConfigTable.put(fw, i, unsortedConfigTable.get(FactorWindow.ANY, i));
                }
            });
        }

        unsortedConfigTable.forEach((fw, i , v) -> {
            if (fw != FactorWindow.ANY) {
                for (Market m : Market.VALUES) {
                    for (WidenStrategy ws : WidenStrategy.VALUES) {
                        if (!unsortedConfigTable.get(fw, i).containsKey(m, ws) && unsortedConfigTable.containsKey(FactorWindow.ANY, i) && unsortedConfigTable.get(FactorWindow.ANY, i).containsKey(m, ws)) {
                            unsortedConfigTable.get(fw, i).put(m, ws, unsortedConfigTable.get(FactorWindow.ANY, i).get(m, ws));
                        }
                    }
                }
            }
        });
    }

    //propagate market.ANY for all other unset configs.
    private void propagateMarketWildcard() {
        for (Market m : Market.VALUES) {
            unsortedConfigTable.forEach((fw, i, v) ->
                unsortedConfigTable.get(fw, i).forEachColumnKey((ws) -> {
                    if (m != Market.ANY && unsortedConfigTable.get(fw, i).containsKey(Market.ANY, ws) && !unsortedConfigTable.get(fw, i).containsKey(m, ws)) {
                        unsortedConfigTable.get(fw, i).put(m, ws, unsortedConfigTable.get(fw, i).get(Market.ANY, ws));
                    }
                })
            );
        }
    }

    //propagate widenStrategy.ANY for all other unset configs.
    private void propagateWidenStrategyWildcard() {
        for (WidenStrategy ws : WidenStrategy.VALUES) {
            unsortedConfigTable.forEach((fw, i, v) ->
                unsortedConfigTable.get(fw, i).forEachRowKey((m) -> {
                    if (ws != WidenStrategy.ANY && unsortedConfigTable.get(fw, i).containsKey(m, WidenStrategy.ANY) && !unsortedConfigTable.get(fw, i).containsKey(m, ws)) {
                        unsortedConfigTable.get(fw, i).put(m, ws, unsortedConfigTable.get(fw, i).get(m, WidenStrategy.ANY));
                    }
                })
            );
        }
    }

    private void sortAndPopulatesConfigsByPercentile() {
        configTable.clear();

        unsortedConfigTable.forEach((fw, i, v) -> v.forEach((m, ws, tzv) -> tzv.forEach((tz, cfgs) -> {
            configTable.computeIfAbsent(fw, i, (facWin, inst) -> new EnumObjTable<>(Market.class, WidenStrategy.class));
            configTable.get(fw, i).computeIfAbsent(m, ws, (mkt, widSgy) -> new EnumObjMap<>(TradingTimeZone.class));
        })));

        unsortedConfigTable.forEach((fw, i, v) -> v.forEach((m, ws, tzv) -> tzv.forEach((tz, cfgs) -> {
            final List<VolatilityWideningPercentileConfig> configs = unsortedConfigTable.get(fw, i).get(m, ws).get(tz);
            if (configs.size() > 0) {
                final VolatilityWideningPercentileConfig[] sortedArray = configs.stream().sorted((o1, o2) -> o1.getPercentile() - o2.getPercentile() < 0 ? -1 : o1.getPercentile() - o2.getPercentile() > 0 ? 1 : 0).toArray(cnt -> new VolatilityWideningPercentileConfig[cnt]);
                configTable.get(fw, i).get(m, ws).put(tz, sortedArray);
            }
        })));
    }

    public VolatilityWideningPercentileConfig[] getConfigs(FactorWindow fw, Instrument i, Market m, WidenStrategy ws, TradingTimeZone ttz) {
        if (configTable.containsKey(fw, i) && configTable.get(fw, i).containsKey(m, ws) && configTable.get(fw, i).get(m, ws).containsKey(ttz)) {
            return configTable.get(fw, i).get(m, ws).get(ttz);
        }
        return emptyConfig;
    }
}
