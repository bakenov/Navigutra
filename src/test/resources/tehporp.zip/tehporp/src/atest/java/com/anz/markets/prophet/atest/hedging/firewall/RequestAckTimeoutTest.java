package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerState.SELL_REQ;
import static com.anz.markets.prophet.domain.HedgeTriggerType.MID_BGC_EP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "As hedger states are left hanging")
@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_2})
public class RequestAckTimeoutTest extends BaseAcceptanceSpecification {

    private NewOrder hedgingOrder1;
    private NewOrder hedgingOrder2;
    private CancelOrder cancelOrder;

    private ConfigurationDataDefault setUpConfiguration(long newOrderTimeout, long cancelTimeoutMS) {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setHedgePortfolioConfigs(asList(
                        new HedgePortfolioConfigImpl(Market.BGCMIDFX, Portfolio.HEDGER_MID_BGC).setEnabled(true).setMinimumTimeToLiveMS(100).setOrderUnknownTimeoutMS(newOrderTimeout).setCancelUnknownTimeoutMS(cancelTimeoutMS).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.FXALLMB, Portfolio.HEDGER_MID_FXALL).setEnabled(true).setMinimumTimeToLiveMS(0).setOrderUnknownTimeoutMS(newOrderTimeout).setCancelUnknownTimeoutMS(cancelTimeoutMS).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.EBSHEDGE, Portfolio.HEDGER_MID_EBS).setEnabled(true).setMinimumTimeToLiveMS(100).setOrderUnknownTimeoutMS(Long.MAX_VALUE).setCancelUnknownTimeoutMS(Long.MAX_VALUE).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.AXL, Portfolio.HEDGER_AGGRESSIVE).setEnabled(true).setMinimumTimeToLiveMS(100).setOrderUnknownTimeoutMS(Long.MAX_VALUE).setCancelUnknownTimeoutMS(Long.MAX_VALUE).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC),
                        new HedgePortfolioConfigImpl(Market.EBS, Portfolio.HEDGER_PASSIVE_EBS).setEnabled(true).setMinimumTimeToLiveMS(100).setOrderUnknownTimeoutMS(Long.MAX_VALUE).setCancelUnknownTimeoutMS(Long.MAX_VALUE).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.RFX, Portfolio.HEDGER_PASSIVE_RFX).setEnabled(true).setMinimumTimeToLiveMS(100).setOrderUnknownTimeoutMS(Long.MAX_VALUE).setCancelUnknownTimeoutMS(Long.MAX_VALUE).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC),
                        new HedgePortfolioConfigImpl(Market.AXL, Portfolio.HEDGER_ARBITRAGE).setEnabled(true).setMinimumTimeToLiveMS(100).setOrderUnknownTimeoutMS(Long.MAX_VALUE).setCancelUnknownTimeoutMS(Long.MAX_VALUE).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(2).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC)
                ));

        return configuration;
    }

    @Test
    public void newOrderAckTimeout() {
        setup:
        {
            long newOrderTimeout = 50L;
            long cancelTimeoutMS = 100L;
            prophet.receive(setUpConfiguration(newOrderTimeout, cancelTimeoutMS));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.disableHedger(HEDGER_MID_FXALL));
            prophet.receive(tdd.disableHedger(HEDGER_MID_EBS));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getMarket(), is(Market.BGCMIDFX));
        }
        when:
        // t+49ms, hedger still active
        {
            prophet.incrementTime(49);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1, 1.05000));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // t+50ms, hedger still has not received ack so hedger starts to terminate
        {
            prophet.incrementTime(1);
            // given less than sec resolution, push the time to Prophet through either sending a Trade or MarketData.
            // Make sure price has changed so that price makes it through to hedger core
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05001));
        }
        then:
        // to terminate, a mid hedger first sends a cancel
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getFirst();
        }
        when:
        // then when cancel is acknowledged hedger shuts down
        {
            prophet.incrementTime(1);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0, 0));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    public void newOrderAckTimeoutAndCancelTimeout() {
        setup:
        {
            long newOrderTimeout = 50L;
            long cancelTimeoutMS = 25L;
            prophet.receive(setUpConfiguration(newOrderTimeout, cancelTimeoutMS));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.disableHedger(HEDGER_MID_FXALL));
            prophet.receive(tdd.disableHedger(HEDGER_MID_EBS));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getMarket(), is(Market.BGCMIDFX));
        }
        when:
        // t+49ms, hedger still active
        {
            prophet.incrementTime(49);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1, 1.05000));
        }
        then:
        // hedger NOT disabled
        {
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // t+50ms, hedger still has not received ack so hedger starts to terminate
        {
            prophet.incrementTime(1);
            // given less than sec resolution, push the time to Prophet through either sending a Trade or MarketData.
            // Make sure price has changed so that price makes it through to hedger core
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05001));
        }
        then:
        // to terminate, a mid hedger first sends a cancel
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+75 cancel order still not acknowledged - hedger shuts down
        {
            prophet.incrementTime(25);
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_ORDER_TIMEOUT));
        }
    }

    @Test
    public void newOrderAckTimeoutAdhereMinTTLOtherOrder() {
        setup:
        {
            long newOrderTimeout = 50L;
            long cancelTimeoutMS = 100L;
            prophet.receive(setUpConfiguration(newOrderTimeout, cancelTimeoutMS));
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
        }
        when:
        // t+0, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_100, 0.75000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURUSD)).getLast();
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // t+49ms, ack received for order 2
        {
            prophet.incrementTime(49);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
        }
        and:
        // hedger NOT disabled
        {
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // t+50ms, hedger still has not received ack for order 1 so hedger starts to terminate
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1);
            // given less than sec resolution, push the time to Prophet through either sending a Trade or MarketData
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05010));
        }
        then:
        // must adhere to minTTL before we can send cancel for order 2. For order 1 we can send cancel immediately
        {
            cancelOrder = prophet.expect(CancelOrder.class, isCancelOrderInstrument(EURUSD)).getLast();
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // t+148 just before minimum ttl for order 1 */
        {
            prophet.incrementTime(98);
            // since less than 1 sec resolution minTTL triggered by 1 sec chime or mkt data
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        then:
        {
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
        when:
        // t+149 minimum ttl reached, should issue a cancel. Also receive cancel ack for order 1
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0.0, 0.0));
            // since less than 1 sec resolution minTTL triggered by 1 sec chime or mkt data
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05010));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, isCancelOrderInstrument(AUDUSD)).getLast();
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(EURUSD, MID_BGC_EP, SELL_REQ));
        }
        when:
        // t+150 hedgingOrder1 receive cancel ack for order 2
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder2, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_MID_BGC, DISABLE_BY_ORDER_TIMEOUT));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, MID_BGC_EP, SELL_REQ));
        }
    }

    @Test
    @RelatedTest(UnrealisedPositionFirewallTest.class) // firewallHandlesCancelOrderEvents()
    public void orderCancelAckTimeout() {
        setup:
        {
            long newOrderTimeout = 5;
            long cancelTimeoutMS = 50;

            prophet.receive(setUpConfiguration(newOrderTimeout, cancelTimeoutMS)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.FXALLMB, EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURUSD).setTradingTimeZone(TradingTimeZone.LDN).setRiskTriggerLowWaterMark(800000).setRiskTriggerHighWaterMark(1000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0)
                    ))

            );
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(HEDGER_MID_FXALL));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
        }
        when:
        // t+1, receive client deal to generate gradient op pos and MID_FXALL and MID_BGC hedgers sends hedge trades
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));  // generate gradientPositionInNotional=2250000.0
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.FXALLMB)).getFirst();
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.BGCMIDFX)).getFirst();

            assertThat(hedgingOrder1.getMarket(), is(Market.FXALLMB));
            // FXALLMID Unrealised position: EUR: -1mio   | -1.05mio USD

            assertThat(hedgingOrder2.getMarket(), is(Market.BGCMIDFX));
        }
        when:
        // t+5 BGCMID hedge order filled, gradientPositionInNotional=750000.0
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2, 1.05);
        }
        then:
        // since gradientPositionInNotional=750000.0 less than FXALLMID LowWaterMark, FXALLMID hedger sends cancel for its open order
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_FXALL_EP)).getLast();
            // MQL is 0ms, so will transition CANCEL_REQ -> CANCELLING straight away
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.CANCELLING));

            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(EURUSD));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+54, 49ms after sending order cancel, hedger still active
        {
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(49));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURUSD, 1, 1.05000));
        }
        // hedger NOT disabled
        {
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsOff(HEDGER_MID_FXALL));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        when:
        // t+55ms, 50ms after sending order cancel, hedger still has not received cancel ack so hedger terminates
        {
            prophet.incrementTime(1);
            // given less than sec resolution, push the time to Prophet through either sending a Trade or MarketData
            prophet.receive(tdd.client_trade_001(EURUSD, 1, 1.05000));
        }
        then:
        // hedger disabled
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(HEDGER_MID_FXALL, DISABLE_BY_ORDER_TIMEOUT));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
    }
}
