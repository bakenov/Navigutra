package com.anz.axle.lg.adapter.cnx;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;

import com.anz.axle.lg.adapter.health.HeartbeatMonitor;

public class HealthCheckFailActionState implements HeartbeatMonitor.FailActionState {
    private final Set<String> clientIdCache = new HashSet<>();
    private final HeartbeatMonitor.FailActionState failActionState;

    public HealthCheckFailActionState(final HeartbeatMonitor.FailActionState failActionState) {
        this.failActionState = Objects.requireNonNull(failActionState);
    }

    @Override
    public boolean isExecuteAction() {
        return failActionState.isExecuteAction();
    }

    @Override
    public void executeAction(final boolean executeAction) {
        failActionState.executeAction(executeAction);
    }

    public void cacheClientId(final String clientId) {
        if (clientId != null) {
            clientIdCache.add(clientId);
        }
    }

    public void executeAction(final Consumer<String> cancelByClientId) {
        clientIdCache.forEach(cancelByClientId);
    }
}
