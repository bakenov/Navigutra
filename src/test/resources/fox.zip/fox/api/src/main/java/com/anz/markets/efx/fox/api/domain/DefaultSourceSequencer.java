package com.anz.markets.efx.fox.api.domain;

public class DefaultSourceSequencer implements SourceSequencer {
    private final int sourceId;
    private long sequence;

    public DefaultSourceSequencer(final int sourceId, final long sequenceSeed) {
        this.sourceId = sourceId;
        this.sequence = sequenceSeed;
    }

    public DefaultSourceSequencer(final int source) {
        this(source, System.currentTimeMillis() * 1000);
    }

    @Override
    public int sourceId() {
        return sourceId;
    }

    @Override
    public long nextSequence() {
        return ++sequence;
    }
}
