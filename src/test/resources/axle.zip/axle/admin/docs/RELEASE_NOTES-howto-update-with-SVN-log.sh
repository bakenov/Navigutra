################################################################################
# Description & commands to prepare release notes based on SVN commit messages
################################################################################

#===============================================================================
# 1. Retrieve revision for tag, replace <MYTAG> with tag, e.g. axle-2.0.13
#===============================================================================
svn log --stop-on-copy http://daxa009s.unix.anz:3960/svn/repo/axle/tags/<MYTAG>

#e.g. output like
#
#------------------------------------------------------------------------
#r17360 | warnerb1 | 2011-09-10 08:14:36 +0000 (Sat, 10 Sep 2011) | 1 line
#
#[maven-release-plugin]  copy for tag axle-2.0.13
#------------------------------------------------------------------------

#===============================================================================
# 2. Get list of all commit messages
#    --> Replace <RNEW> with revision for tag associated with new release
#    --> Replace <ROLD> with revision for tag associated with previous release
#===============================================================================
svn log -r<RNEW>:<ROLD> http://daxa009s.unix.anz:3960/svn/repo/axle/trunk

#e.g.
# svn log -r17360:17244 http://daxa009s.unix.anz:3960/svn/repo/axle/trunk

#===============================================================================
# 3. Commit RELEASE_NOTES.txt
#===============================================================================

cd axle/admin/docs
svn ci -m "release notes" RELEASE_NOTES.txt

#===============================================================================
# 4. (Re-)Tag RELEASE_NOTES.txt
#    --> Replace (2x) <RNEW> with revision for tag associated with new release
#===============================================================================
svn rm http://daxa009s.unix.anz:3960/svn/repo/axle/tags/<MYTAG>/admin/docs/RELEASE_NOTES.txt -m "Re-tag release notes"
svn cp http://daxa009s.unix.anz:3960/svn/repo/axle/trunk/admin/docs/RELEASE_NOTES.txt \
	http://daxa009s.unix.anz:3960/svn/repo/axle/tags/<MYTAG>/admin/docs/RELEASE_NOTES.txt -m "Tag release notes"