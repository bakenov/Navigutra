package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.broker.domain.DomainEnums;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.datafabric.client.config.CurrencyPairService;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.ForwardPointsQuotePageKey;
import com.anz.axle.pricing.Quote;
import com.anz.axle.pricing.QuotePageType;
import com.anz.axle.pricing.QuoteState;
import com.anz.axle.spdee.dealing.QuotePriceType;
import com.google.common.base.Optional;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ForwardPointsQuotePageFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(ForwardPointsQuotePageFactory.class);

    private final CurrencyPairService currencyPairService;

    public static final String D3_SOURCE = "D3";

    private static final Quote STREAMABLE_ZERO_FORWARD_POINTS_QUOTE = new Quote(QuoteState.STREAMABLE, Decimal.ZERO, Decimal.ZERO, QuotePriceType.FORWARD_POINTS);

    public ForwardPointsQuotePageFactory(final CurrencyPairService currencyPairService) {
        this.currencyPairService = currencyPairService;
    }

    public static ForwardPointsQuotePage spotTenorForwardPointsQuotePageFrom(final D3ForwardQuote d3ForwardQuote,
                                                                             final LocalDate referenceSpotDate) {
        final ForwardPointsQuotePage spot = new ForwardPointsQuotePage();
        final ForwardPointsQuotePageKey key = new ForwardPointsQuotePageKey(d3ForwardQuote.symbol(), Tenor.SPOT.getKey());
        spot.setKey(key);
        spot.setTenorDate(referenceSpotDate);
        spot.setReferenceSpotDate(referenceSpotDate);
        spot.setSource(D3_SOURCE);
        spot.setConfigVersion(-1);
        spot.setQuotePageType(QuotePageType.BANDED);
        spot.getQuotes().add(STREAMABLE_ZERO_FORWARD_POINTS_QUOTE);
        spot.setState(QuoteState.STREAMABLE);
        return spot;
    }

    public Optional<ForwardPointsQuotePage> forwardPointsAndWholesaleSpotForwardPointQuotePageFrom(final D3ForwardQuote d3ForwardQuote) {
        final Optional<LocalDate> optionalReferenceSpotDate = d3ForwardQuote.spotDate();
        final Optional<LocalDate> optionalMaturityDate = d3ForwardQuote.maturityDate();
        final Tenor tenor = d3ForwardQuote.tenor();
        if (optionalReferenceSpotDate.isPresent() && optionalMaturityDate.isPresent()) {
            final LocalDate referenceSpotDate = optionalReferenceSpotDate.get();
            final LocalDate maturityDate = optionalMaturityDate.get();

            String tenorKey = tenor.getKey();
            if (tenor == Tenor.BROKEN) {
                tenorKey = tenorKey + ":" + maturityDate.toString("dd-MM-yyyy");
            }

            final QuoteState status = d3ForwardQuote.status();
            final String symbol = d3ForwardQuote.symbol();

            final ForwardPointsQuotePage forwardPointsQuotePage = new ForwardPointsQuotePage();
            forwardPointsQuotePage.setKey(new ForwardPointsQuotePageKey(symbol, tenorKey));
            forwardPointsQuotePage.setSource("D3");
            forwardPointsQuotePage.setConfigVersion(-1);
            forwardPointsQuotePage.setTenorDate(maturityDate);
            forwardPointsQuotePage.setReferenceSpotDate(referenceSpotDate);
            forwardPointsQuotePage.setQuotePageType(QuotePageType.BANDED);
            if (tenor == Tenor.SPOT) {
                forwardPointsQuotePage.getQuotes().add(STREAMABLE_ZERO_FORWARD_POINTS_QUOTE);
                if (involvesNDFCurrency(symbol)) {
                    forwardPointsQuotePage.getQuotes().add(createQuote(d3ForwardQuote, status, QuotePriceType.WHOLESALE_SPOT_PRICE));
                }
            } else {
                forwardPointsQuotePage.getQuotes().add(createQuote(d3ForwardQuote, status, QuotePriceType.FORWARD_POINTS));
            }
            forwardPointsQuotePage.setState(status);

            LOGGER.debug("Converted item {} to quote page {}", d3ForwardQuote, forwardPointsQuotePage);
            return Optional.of(forwardPointsQuotePage);
        } else {
            LOGGER.info("Not publishing forward points quote page as we cant get referenceSpotDate/maturityDate/tenor from {}.", d3ForwardQuote.trepName());
            return Optional.absent();
        }
    }

    private boolean involvesNDFCurrency(final String symbol) {
        final CurrencyPair currencyPair = currencyPairService.findbySymbol(symbol);
        return currencyPair != null && currencyPair.involves(DomainEnums.CurrencyType.N);
    }

    private static Quote createQuote(final D3ForwardQuote d3ForwardQuote,
                                     final QuoteState status,
                                     final QuotePriceType quotePriceType) {
        return new Quote(status, d3ForwardQuote.bid(), d3ForwardQuote.ask(), quotePriceType);
    }

}
