package com.anz.axle.acc.job;

import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public interface CurrentVenueCurrencyCreditCheckJobListener {
    void listen(CurrentVenueCurrencyCreditStates state);
}
