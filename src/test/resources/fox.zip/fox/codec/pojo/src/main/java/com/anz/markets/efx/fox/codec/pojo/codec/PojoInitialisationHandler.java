package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public class PojoInitialisationHandler implements InitialisationHandler {

    private final Consumer<? super Initialisation> messageConsumer;

    private Initialisation message = SorMessage.initialisation();

    public Initialisation message() {
        return message;
    }

    public PojoInitialisationHandler() {
        this(msg -> {});
    }

    public PojoInitialisationHandler(final Consumer<? super Initialisation> messageConsumer) {
        this.messageConsumer = Objects.requireNonNull(messageConsumer);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        message = SorMessage.initialisation();
    }

    @Override
    public void onBody(final Body body) {
        message.body.initStage = body.initStage();
    }

    @Override
    public void onMessageComplete() {
        messageConsumer.accept(message);
    }
}
