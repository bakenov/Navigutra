package com.anz.axle.lg.adapter.acceptance.shared;

import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.stub.Sink;
import com.anz.markets.efx.messaging.transport.stub.Source;
import com.anz.markets.efx.messaging.transport.stub.StubbedTransport;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingDecoders;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.base.PricingTranslator;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.trading.codec.api.TradingDecoders;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.base.TradingTranslator;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingDecoders;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoders;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingEncoders;

@Configuration
public class SharedAcceptanceConfig {

    @Bean
    public Queue<PricingMessage> pricingMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<TradingMessage> tradingResponseMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public Queue<TradingMessage> tradingRequestMessageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    public PrecisionClock precisionClock() {
        return new ControllableClock();
    }

    @Bean
    public SharedAcceptanceContext sharedAcceptanceContext(final Queue<PricingMessage> pricingMessageQueue,
                                                           final Queue<TradingMessage> tradingResponseMessageQueue,
                                                           final Queue<TradingMessage> tradingRequestMessageQueue,
                                                           final PrecisionClock precisionClock,
                                                           final LongIdFactory tradingMessageIdGenerator) {
        return new SharedAcceptanceContext() {
            @Override
            public Queue<PricingMessage> pricingMessageQueue() {
                return pricingMessageQueue;
            }

            @Override
            public Queue<TradingMessage> tradingResponseMessageQueue() {
                return tradingResponseMessageQueue;
            }

            @Override
            public Queue<TradingMessage> tradingRequestMessageQueue() {
                return tradingRequestMessageQueue;
            }

            @Override
            public PrecisionClock precisionClock() {
                return precisionClock;
            }

            @Override
            public LongIdFactory tradingMessageIdGenerator() {
                return tradingMessageIdGenerator;
            }
        };
    }

    @Bean
    public Transport transport(final Queue<PricingMessage> pricingMessageQueue,
                               final Queue<TradingMessage> tradingResponseMessageQueue,
                               final Queue<TradingMessage> tradingRequestMessageQueue) {

        //Topic sinks
        final Sink pricingMessageSink = pricingMessageSink(pricingMessageQueue);

        final Sink tradingResponseSink = tradingResponseSink(tradingResponseMessageQueue);

        //Topic source stubs
        final Source tradingRequestSource = tradingRequestSource(tradingRequestMessageQueue);


        return StubbedTransport.builder().
                sinks(publicationTopic -> {
                    if (publicationTopic.name().matches(".*TRADING_RESPONSE")) {
                        return tradingResponseSink;
                    } else {
                        return pricingMessageSink;
                    }
                }).sources(subscriptionTopic -> {
            if (subscriptionTopic.name().matches(".*TRADING_REQUEST")) {
                return tradingRequestSource;
            } else {
                return (messageHandler, topic1) -> false;
            }
        }).build();
    }

    /**
     * PojoTradingMessages are sourced from the tradingRequestMessageQueue, translated to SBE message and pushed to
     * the subscription message handler.
     *
     * @param tradingRequestMessageQueue       - source of PojoTradingRequestMessages
     * @return TradingRequest source
     */
    protected Source tradingRequestSource(final Queue<TradingMessage> tradingRequestMessageQueue) {
        final LongSupplier nanoTimeSource = () -> 0L;
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final TradingTranslator<TradingMessage> pojo2SbeTranslator = tradingPojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), nanoTimeSource.getAsLong())
        );
        return (topic, messageHandler) -> {
            final TradingMessage pojoTradingMessage = tradingRequestMessageQueue.poll();
            if (pojoTradingMessage != null) {
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoTradingMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };
    }

    /**
     * DirectBuffer content is translated to TradingMessage and placed to the tradingResponseMessageQueue.
     *
     * @param tradingResponseMessageQueue       - destination of PojoTradingResponseMessages
     * @return TradingResponse sink
     */
    protected Sink tradingResponseSink(final Queue<TradingMessage> tradingResponseMessageQueue) {
        final AtomicReference<TradingMessage> messageHolder = new AtomicReference<>();
        final TradingTranslator<SbeMessage> tradingSbe2PojoTranslator = tradingSbe2PojoTranslator(messageHolder::set);
        final SbeMessageForReading sbeMessage = new SbeMessageForReading();
        return Sink.create((buf, off, len) -> {
            tradingSbe2PojoTranslator.decode(sbeMessage.wrap(buf, off, len));
            sbeMessage.unwrap();
            return messageHolder.getAndSet(null);
        }, tradingResponseMessageQueue::offer);
    }

    /**
     * DirectBuffer content is translated to PricingMessage and placed to the pricingMessageQueue.
     *
     * @param pricingMessageQueue       - destination of PojoPricingMessages
     * @return PricingMessage sink
     */
    protected Sink pricingMessageSink(final Queue<PricingMessage> pricingMessageQueue) {
        final AtomicReference<PricingMessage> messageHolder = new AtomicReference<>();
        final PricingTranslator<SbeMessage> pricingSbe2PojoTranslator = pricingSbe2PojoTranslator(messageHolder::set);
        final SbeMessageForReading sbeMessage = new SbeMessageForReading();
        return Sink.create((buf, off, len) -> {
            pricingSbe2PojoTranslator.decode(sbeMessage.wrap(buf, off, len));
            sbeMessage.unwrap();
            return messageHolder.getAndSet(null);
        }, pricingMessageQueue::offer);
    }

    private TradingTranslator<TradingMessage> tradingPojo2SbeTranslator(final Consumer<? super SbeMessage> sbeMessageConsumer) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final TradingDecoders<TradingMessage> pojoTradingDecoders = new PojoTradingDecoders();
        final TradingEncoderSupplier sbeEncoderSupplier = new SbeTradingEncoders(() -> sbeMessage).toTradingEncoderSupplier(sbeMessageConsumer);
        return TradingTranslator.create(pojoTradingDecoders.newOrderSingleAndOrderCancelRequest(), sbeEncoderSupplier);
    }

    private TradingTranslator<SbeMessage> tradingSbe2PojoTranslator(final Consumer<? super TradingMessage> pojoMessageConsumer) {
        final TradingDecoders<SbeMessage> sbeTradingDecoders = new SbeTradingDecoders();
        final TradingEncoderSupplier pojoEncoderSupplier = new PojoTradingEncoderSupplier(pojoMessageConsumer);
        return TradingTranslator.create(sbeTradingDecoders.all(), pojoEncoderSupplier);
    }


    private PricingTranslator<SbeMessage> pricingSbe2PojoTranslator(final Consumer<? super PricingMessage> pojoMessageConsumer) {
        final PricingDecoders<SbeMessage> sbePricingDecoders = new SbePricingDecoders();
        final PricingEncoderSupplier pojoEncoderSupplier = new PojoPricingEncoderSupplier(pojoMessageConsumer);
        return PricingTranslator.create(sbePricingDecoders.all(), pojoEncoderSupplier);
    }
}
