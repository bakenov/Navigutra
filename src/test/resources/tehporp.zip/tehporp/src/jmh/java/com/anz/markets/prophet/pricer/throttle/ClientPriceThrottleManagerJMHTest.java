package com.anz.markets.prophet.pricer.throttle;

import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

public class ClientPriceThrottleManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        public ClientPriceThrottleManagerTest clientPriceThrottleManagerTest;
        public long timeIncrement;

        @Setup
        public void setup() throws IOException {
            ClientPriceThrottleManagerTest.setupClass();
            clientPriceThrottleManagerTest = new ClientPriceThrottleManagerTest();
            clientPriceThrottleManagerTest.setup();
            clientPriceThrottleManagerTest.clientPriceConsumer.accept(clientPriceThrottleManagerTest.price1);
            assertEquals(1, clientPriceThrottleManagerTest.accumulator.size());
            timeIncrement = TimeUnit.MILLISECONDS.toNanos(clientPriceThrottleManagerTest.clientPriceThrottleConfig.getNoActivityHeartbeatFrequencyMs() + 1);
        }
    }

    @Benchmark
    public long changePrice(@NotNull final Data data) throws Exception {
        ClientPriceThrottleManagerTest.timeSource.incrementNanos(TimeUnit.MILLISECONDS.toNanos(1));
        mutate((PriceAndQtyImpl) data.clientPriceThrottleManagerTest.price1.getBids().get(0));
        mutate((PriceAndQtyImpl) data.clientPriceThrottleManagerTest.price1.getOffers().get(0));
        data.clientPriceThrottleManagerTest.clientPriceConsumer.accept(data.clientPriceThrottleManagerTest.price1);
        return data.clientPriceThrottleManagerTest.accumulator.size();
    }

    private void mutate(final PriceAndQtyImpl clientPricePoint) {
        clientPricePoint.setPrice(clientPricePoint.getPrice() + (Math.random() - 0.5d));
    }
}
