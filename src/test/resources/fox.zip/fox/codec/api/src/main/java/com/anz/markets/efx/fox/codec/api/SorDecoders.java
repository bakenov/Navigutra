package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

public interface SorDecoders<M> {
    PricingRefreshCompleteHandler.DecoderFactory<M> pricingRefreshComplete();
    TimerExpiryHandler.DecoderFactory<M> timerExpiry();
    FirewallConfigHandler.DecoderFactory<M> firewallConfig();
    VenueConfigHandler.DecoderFactory<M> venueConfig();
    UserConfigHandler.DecoderFactory<M> userConfig();
    InitialisationHandler.DecoderFactory<M> initialisation();
    InstrumentConfigHandler.DecoderFactory<M> instrumentConfig();
    VenueInstrumentConfigHandler.DecoderFactory<M> venueInstrumentConfig();

    @Garbage(Garbage.Type.RESULT)
    default DecoderFactory<M> all() {
        return (handlerSupplier, forwardingLookup) -> MessageDecoder.composite(
                pricingRefreshComplete().create(handlerSupplier.pricingRefreshComplete(), forwardingLookup),
                timerExpiry().create(handlerSupplier.timerExpiryHandler(), forwardingLookup),
                firewallConfig().create(handlerSupplier.firewallConfigHandler(), forwardingLookup),
                venueConfig().create(handlerSupplier.venueConfigHandler(), forwardingLookup),
                userConfig().create(handlerSupplier.userConfigHandler(), forwardingLookup),
                initialisation().create(handlerSupplier.initialisationHandler(), forwardingLookup),
                instrumentConfig().create(handlerSupplier.instrumentConfigHandler(), forwardingLookup),
                venueInstrumentConfig().create(handlerSupplier.venueInstrumentConfigHandler(), forwardingLookup)
        );
    }

    @FunctionalInterface
    interface DecoderFactory<M> {
        MessageDecoder<M> create(SorHandlerSupplier sorHandlerSupplier, MessageDecoder.ForwardingLookup<M> forwardingLookup);
    }
}
