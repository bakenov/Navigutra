package com.anz.markets.efx.fox.codec.sbe;

import com.anz.markets.efx.fox.codec.api.TimerExpiryDecoder;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class TimerExpirySbeDecoder implements TimerExpiryDecoder {
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder timerExpiryDecoder = new com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder();

    private final SbeHeader header = new SbeHeader(headerDecoder);
    private final SbeBody body = new SbeBody();
    private int bodyLimit;
    private EncodingOrder.TimerExpiry encodingOrder = EncodingOrder.TimerExpiry.INITIAL;

    public boolean wrap(final SbeMessage sbeMessage) {
        headerDecoder.wrap(sbeMessage.buffer(), 0);
        if (headerDecoder.templateId() != com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder.TEMPLATE_ID) {
            clear();
            return false;
        }
        timerExpiryDecoder.wrap(sbeMessage.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        this.bodyLimit = timerExpiryDecoder.limit();
        encodingOrder = EncodingOrder.TimerExpiry.INITIAL;
        return true;
    }

    public void clear() {
        headerDecoder.wrap(null, 0);
        timerExpiryDecoder.wrap(null, 0, 0, 0);
    }

    @Override
    public Header header() {
        return header;
    }

    @Override
    public com.anz.markets.efx.fox.codec.api.TimerExpiryDecoder.Body body() {
        encodingOrder = EncodingOrder.TimerExpiry.BODY;
        timerExpiryDecoder.limit(bodyLimit);
        return body;
    }

    class SbeBody implements com.anz.markets.efx.fox.codec.api.TimerExpiryDecoder.Body {
        @Override
        public long triggeredTime() {
            encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
            return timerExpiryDecoder.triggeredTime();
        }

        @Override
        public long timerId() {
            encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
            return timerExpiryDecoder.timerId();
        }

        @Override
        public TimerGroup timerGroup() {
            encodingOrder.checkStrict(EncodingOrder.TimerExpiry.BODY);
            return TimerGroup.valueOf(timerExpiryDecoder.timerGroup().name());
        }
    }

    @Override
    public void appendTo(final StringBuilder stringBuilder) {
        timerExpiryDecoder.appendTo(stringBuilder);
    }
}
