package com.anz.axle.lg.adapter.apama.transport.local;

import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.adapter.apama.transport.Connection;
import com.anz.axle.lg.adapter.apama.transport.ConnectionConfig;
import com.anz.axle.lg.adapter.apama.transport.ConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.Transport;

public class LocalApamaTransport implements Transport {
    private static final Logger LOGGER = LoggerFactory.getLogger(LocalApamaTransport.class);
    private final Consumer<String> eventStringConsumer = this::publish;
    private volatile LocalApamaConnection connection;
    @Override
    public Connection openConnection(final ConnectionConfig connectionConfig, final ConnectionStatusHandler connectionStatusHandler) {
        return connection = new LocalApamaConnection(connectionConfig, connectionStatusHandler);
    }

    public Consumer<String> eventStringConsumer() {
        return eventStringConsumer;
    }

    private void publish(final String eventMessage) {
        if (connection != null) {
            connection.messagePublisher().accept(eventMessage);
        } else {
            LOGGER.error("Not yet connnected, could not publish: {}", eventMessage);
        }
    }
}
