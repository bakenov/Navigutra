package com.anz.markets.efx.ngaro.sbe;

import java.io.IOException;

import org.junit.Test;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

/**
 * Unit test for {@link FixedStringDecoder}
 */
public class FixedStringDecoderTest {

    @Test(expected = NullPointerException.class)
    public void noNullSource() {
        StringDecoders.forFixedLength(null, 7);
    }

    @Test(expected = IllegalArgumentException.class)
    public void noNegativeLength() {
        StringDecoders.forFixedLength((i) -> (byte)0, -1);
    }

    @Test
    public void decodeEmpty() throws Exception {
        final int len = 3;
        final int offset = 3;
        final FixedStringSource source = (i) -> (byte)"abc\0\0\0ghijklmno".charAt(offset + i);
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);

        //when
        final String output = dec.decodeStringOrNull();

        //then
        assertNull("output should be null at " + offset, output);
    }

    @Test
    public void decodeToString() throws Exception {
        //given
        final int len = 6;
        final int offset = 3;
        final StringBuilder input = new StringBuilder();
        final FixedStringSource source = (i) -> (byte)input.charAt(i + offset);
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);
        final String input1 = "abc123456jklmno";
        final String input2 = "abcXYZ\0\0\0jklmno";

        //when
        input.replace(0, input.length(), input1);
        final String output1 = dec.decodeStringOrNull();

        //then
        assertEquals("output1 should be 123456 at " + offset, "123456", output1);

        //when
        input.replace(0, input.length(), input2);
        final String output2 = dec.decodeStringOrNull();

        //then
        assertEquals("output2 should be XYZ at " + offset, "XYZ", output2);
    }

    @Test
    public void decodeToStringViaCache() throws Exception {
        //given
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);

        final int len = 6;
        final int offset = 3;
        final StringBuilder input = new StringBuilder();
        final FixedStringSource source = (i) -> (byte)input.charAt(i + offset);
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);
        final String input1 = "abc123456jklmno";
        final String input2 = "abcXYZ\0\0\0jklmno";
        final String input3 = "abc\0\0\0jklmno";

        //when
        input.replace(0, input.length(), input1);
        final String output1 = dec.decodeAndCache(cache);

        //then
        assertEquals("output1 should be 123456 at " + offset, "123456", output1);

        //when
        final String output11 = dec.decodeAndCache(cache);

        //then
        assertSame("output11 should be the same reference as output1 at " + offset, output1, output11);

        //when
        input.replace(0, input.length(), input2);
        final String output2 = dec.decodeAndCache(cache);

        //then
        assertEquals("output2 should be XYZ at " + offset, "XYZ", output2);

        //when
        final String output21 = dec.decodeAndCache(cache);

        //then
        assertSame("output21 should be the same reference as output2 at " + offset, output2, output21);


        //when
        input.replace(0, input.length(), input3);
        final String output3 = dec.decodeAndCache(cache);

        //then
        assertEquals("output3 should be null at " + offset, null, output3);

    }

    @Test
    public void decodeToAppendable() throws Exception {
        //given
        final int len = 6;
        final int offset = 3;
        final StringBuilder input = new StringBuilder();
        final FixedStringSource source = (i) -> (byte)input.charAt(i + offset);
        final StringBuilder output = new StringBuilder("pqrstuvwxyz");
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);
        final String input1 = "abc123456jklmno";
        final String input2 = "abcXYZ\0\0\0jklmno";
        final String input3 = "abc\0\0\0\0\0\0";

        //when
        input.replace(0, input.length(), input1);
        final Appendable a1 = dec.decodeTo(output, len);

        //then
        assertEquals("output should end with 123456", "pqrstuvwxyz123456", output.toString());
        assertSame("returned appendable should be same as the target", output, a1);

        //when
        input.replace(0, input.length(), input2);
        final Appendable a2 = dec.decodeTo(output, len);

        //then
        assertEquals("output should end with XYZ", "pqrstuvwxyz123456XYZ", output.toString());
        assertSame("returned appendable should be same as the target", output, a2);

        //when
        input.replace(0, input.length(), input1);
        final Appendable a3 = dec.decodeTo(output, 3);

        //then
        assertEquals("output should end with 123", "pqrstuvwxyz123456XYZ123", output.toString());
        assertSame("returned appendable should be same as the target", output, a3);

        //when
        input.replace(0, input.length(), input3);
        final Appendable a4 = dec.decodeTo(output, len);

        //then
        assertEquals("output should not have changed", "pqrstuvwxyz123456XYZ123", output.toString());
        assertSame("returned appendable should be same as the target", output, a4);
    }

    @Test(expected = RuntimeException.class)
    public void decodeToAppendable_throwsException() throws Exception {
        //given
        final int len = 6;
        final int offset = 3;
        final StringBuilder input = new StringBuilder("abc123456jklmno");
        final FixedStringSource source = (i) -> (byte)input.charAt(i + offset);
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);
        final Appendable output = new Appendable() {
            @Override
            public Appendable append(final CharSequence csq) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final char c) throws IOException {
                throw new IOException("Test appendable exception");
            }
        };

        //when
        dec.decodeTo(output, len);

        //then: expect exception
    }

    @Test
    public void decodeToByteWriter() throws Exception {
        //given
        final int len = 6;
        final int srcOffset = 3;
        final StringBuilder input = new StringBuilder();
        final FixedStringSource source = (i) -> (byte)input.charAt(i + srcOffset);
        final StringBuilder output = new StringBuilder("pqrstuvwxyz");
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);
        final String input1 = "abc123456jklmno";
        final String input2 = "abcXYZ\0\0\0jklmno";
        final String input3 = "abc\0\0\0\0\0\0";
        int tgtOffset = 0;

        //when
        input.replace(0, input.length(), input1);
        final int len1 = dec.decodeTo(output, ByteWriter.STRING_BUILDER);

        //then
        assertEquals("output should contain 123456 at " + tgtOffset, "123456vwxyz", output.toString());
        assertEquals("len1 should be " + len, len, len1);

        //when
        input.replace(0, input.length(), input2);
        final int len2 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, len);

        //then
        assertEquals("output should contain XYZ at " + tgtOffset, "XYZ456vwxyz", output.toString());
        assertEquals("len2 should be 3", 3, len2);

        //when
        tgtOffset = 1;
        input.replace(0, input.length(), input1);
        final int len3 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, 3);

        //then
        assertEquals("output should contain 123 at " + tgtOffset, "X12356vwxyz", output.toString());
        assertEquals("len3 should be 3", 3, len3);

        //when
        tgtOffset = 0;
        input.replace(0, input.length(), input3);
        final int len4 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, len);

        //then
        assertEquals("output should not have changed", "X12356vwxyz", output.toString());
        assertEquals("len4 should be 0", 0, len4);
    }
    @Test
    public void decodeToNull() throws Exception {
        //given
        final int len = 6;
        final int offset = 3;
        final StringBuilder input = new StringBuilder();
        final FixedStringSource source = (i) -> (byte)input.charAt(i + offset);
        final StringDecoder dec = StringDecoders.forFixedLength(source, len);
        final String input1 = "abc123456jklmno";
        final String input2 = "abcXYZ\0\0\0jklmno";
        final String input3 = "abc\0\0\0\0\0\0";

        //when
        input.replace(0, input.length(), input1);
        final int len1 = dec.decodeToNull();

        //then
        assertEquals("len1 should be " + len, len, len1);

        //when
        input.replace(0, input.length(), input2);
        final int len2 = dec.decodeToNull();

        //then
        assertEquals("len2 should be 3", 3, len2);

        //when
        input.replace(0, input.length(), input3);
        final int len3 = dec.decodeToNull();

        //then
        assertEquals("len3 should be 0", 0, len3);
    }
}