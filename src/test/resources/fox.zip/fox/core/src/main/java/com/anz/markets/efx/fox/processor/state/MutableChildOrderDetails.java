package com.anz.markets.efx.fox.processor.state;

import com.anz.markets.efx.fox.api.domain.ChildOrderDetails;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.api.TradingConstants;

public class MutableChildOrderDetails implements ChildOrderDetails {
    private MutableAsciiString orderId = AsciiString.fixedLength(TradingConstants.ORDER_ID_LENGTH);

    private long origClOrdId;
    private long clOrdId;
    private long clOrdLinkId;
    private VenueInstrument venueInstrument;
    private String strategyName;
    private TimeInForce timeInForce;
    private OrderType orderType;
    private String currency;
    private String settlCurrency;
    private Side side;
    private double price;
    private double orderQty;
    private String senderCompId;
    private long tradeDateMillis;
    private long settleDateMillis;
    private long transactTimeNanos;

    private OrderStatus orderStatus;
    private double lastQty;
    private double lastUsdQty;
    private double lastPx;
    private double commissionAdjLastPx;
    private double midPx;
    private double lastSpotRate;
    private double lastForwardPoints;
    private double leavesQty;
    private double cumQty;
    private double avgPx;
    private double commissionAdjAvgPx;
    private double commission;

    @Override
    public AsciiString orderId() {
        return orderId;
    }

    @Override
    public long origClOrdId() {
        return origClOrdId;
    }

    @Override
    public long clOrdId() {
        return clOrdId;
    }

    @Override
    public long clOrdLinkId() {
        return clOrdLinkId;
    }

    @Override
    public VenueInstrument venueInstrument() {
        return venueInstrument;
    }

    @Override
    public String strategyName() {
        return strategyName;
    }

    @Override
    public TimeInForce timeInForce() {
        return timeInForce;
    }

    @Override
    public OrderType orderType() {
        return orderType;
    }

    @Override
    public String currency() {
        return currency;
    }

    @Override
    public String settlCurrency() {
        return settlCurrency;
    }

    @Override
    public Side side() {
        return side;
    }

    @Override
    public double price() {
        return price;
    }

    @Override
    public double orderQty() {
        return orderQty;
    }

    @Override
    public String senderCompId() {
        return senderCompId;
    }

    @Override
    public long tradeDateMillis() {
        return tradeDateMillis;
    }

    @Override
    public long settleDateMillis() {
        return settleDateMillis;
    }

    @Override
    public long transactTimeNanos() {
        return transactTimeNanos;
    }

    @Override
    public OrderStatus orderStatus() {
        return orderStatus;
    }

    @Override
    public double lastQty() {
        return lastQty;
    }

    @Override
    public double lastUsdQty() {
        return lastUsdQty;
    }

    @Override
    public double lastPx() {
        return lastPx;
    }

    @Override
    public double commissionAdjLastPx() {
        return commissionAdjLastPx;
    }

    @Override
    public double midPx() {
        return midPx;
    }

    @Override
    public double lastSpotRate() {
        return lastSpotRate;
    }

    @Override
    public double lastForwardPoints() {
        return lastForwardPoints;
    }

    @Override
    public double leavesQty() {
        return leavesQty;
    }

    @Override
    public double cumQty() {
        return cumQty;
    }

    @Override
    public double avgPx() {
        return avgPx;
    }

    @Override
    public double commissionAdjAvgPx() {
        return commissionAdjAvgPx;
    }

    @Override
    public double commission() {
        return commission;
    }

    public MutableChildOrderDetails orderId(final StringDecoder orderId) {
        orderId.decodeTo(this.orderId, TradingConstants.ORDER_ID_LENGTH);
        return this;
    }

    public MutableChildOrderDetails origClOrdId(final long origClOrdId) {
        this.origClOrdId = origClOrdId;
        return this;
    }

    public MutableChildOrderDetails clOrdId(final long clOrdId) {
        this.clOrdId = clOrdId;
        return this;
    }

    public MutableChildOrderDetails clOrdLinkId(final long clOrdLinkId) {
        this.clOrdLinkId = clOrdLinkId;
        return this;
    }

    public MutableChildOrderDetails venueInstrument(final VenueInstrument venueInstrument) {
        this.venueInstrument = venueInstrument;
        return this;
    }

    public MutableChildOrderDetails strategyName(final String strategyName) {
        this.strategyName = strategyName;
        return this;
    }

    public MutableChildOrderDetails timeInForce(final TimeInForce timeInForce) {
        this.timeInForce = timeInForce;
        return this;
    }

    public MutableChildOrderDetails orderType(final OrderType orderType) {
        this.orderType = orderType;
        return this;
    }

    public MutableChildOrderDetails currency(final String currency) {
        this.currency = currency;
        return this;
    }

    public MutableChildOrderDetails settlCurrency(final String settlCurrency) {
        this.settlCurrency = settlCurrency;
        return this;
    }

    public MutableChildOrderDetails side(final Side side) {
        this.side = side;
        return this;
    }

    public MutableChildOrderDetails price(final double price) {
        this.price = price;
        return this;
    }

    public MutableChildOrderDetails orderQty(final double orderQty) {
        this.orderQty = orderQty;
        return this;
    }

    public MutableChildOrderDetails senderCompId(final String senderCompId) {
        this.senderCompId = senderCompId;
        return this;
    }

    public MutableChildOrderDetails tradeDateMillis(final long tradeDateMillis) {
        this.tradeDateMillis = tradeDateMillis;
        return this;
    }

    public MutableChildOrderDetails settleDateMillis(final long settleDateMillis) {
        this.settleDateMillis = settleDateMillis;
        return this;
    }

    public MutableChildOrderDetails transactTime(final long transactTimeNanos) {
        this.transactTimeNanos = transactTimeNanos;
        return this;
    }

    public MutableChildOrderDetails orderStatus(final OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
        return this;
    }

    public MutableChildOrderDetails lastQty(final double lastQty) {
        this.lastQty = lastQty;
        return this;
    }

    public MutableChildOrderDetails lastUsdQty(final double lastUsdQty) {
        this.lastUsdQty = lastUsdQty;
        return this;
    }

    public MutableChildOrderDetails lastPx(final double lastPx) {
        this.lastPx = lastPx;
        return this;
    }

    public MutableChildOrderDetails commissionAdjLastPx(final double commissionAdjLastPx) {
        this.commissionAdjLastPx = commissionAdjLastPx;
        return this;
    }

    public MutableChildOrderDetails midPx(final double midPx) {
        this.midPx = midPx;
        return this;
    }

    public MutableChildOrderDetails lastSpotRate(final double lastSpotRate) {
        this.lastSpotRate = lastSpotRate;
        return this;
    }

    public MutableChildOrderDetails lastForwardPoints(final double lastForwardPoints) {
        this.lastForwardPoints = lastForwardPoints;
        return this;
    }

    public MutableChildOrderDetails leavesQty(final double leavesQty) {
        this.leavesQty = leavesQty;
        return this;
    }

    public MutableChildOrderDetails cumQty(final double cumQty) {
        this.cumQty = cumQty;
        return this;
    }

    public MutableChildOrderDetails avgPx(final double avgPx) {
        this.avgPx = avgPx;
        return this;
    }

    public MutableChildOrderDetails commissionAdjAvgPx(final double commissionAdjAvgPx) {
        this.commissionAdjAvgPx = commissionAdjAvgPx;
        return this;
    }

    public MutableChildOrderDetails commission(final double commission) {
        this.commission = commission;
        return this;
    }

    public MutableChildOrderDetails reset() {
        orderId.clear();
        origClOrdId = 0;
        clOrdId = 0;
        clOrdLinkId = 0;
        venueInstrument = null;
        strategyName = null;
        timeInForce = null;
        orderType = null;
        currency = null;
        settlCurrency = null;
        side = null;
        price = Double.NaN;
        orderQty = Double.NaN;
        senderCompId = null;
        tradeDateMillis = 0;
        settleDateMillis = 0;
        transactTimeNanos = 0;

        lastQty = 0;
        lastUsdQty = 0;
        lastPx = Double.NaN;
        commissionAdjLastPx = 0;
        midPx = Double.NaN;
        lastSpotRate = Double.NaN;
        lastForwardPoints = Double.NaN;
        leavesQty = 0;
        cumQty = 0;
        avgPx = Double.NaN;
        commissionAdjAvgPx = 0;
        commission = 0;
        return this;
    }

    @Override
    public String toString() {
        return "MutableChildOrderDetails{" +
                "orderId=" + orderId +
                ", origClOrdId=" + origClOrdId +
                ", clOrdId=" + clOrdId +
                ", clOrdLinkId=" + clOrdLinkId +
                ", venue=" + venueInstrument.venue().venueId() +
                ", strategyName='" + strategyName + '\'' +
                ", instrument=" + venueInstrument.instrument().key()  +
                ", timeInForce=" + timeInForce +
                ", orderType=" + orderType +
                ", currency='" + currency + '\'' +
                ", settlCurrency='" + settlCurrency + '\'' +
                ", side=" + side +
                ", price=" + price +
                ", orderQty=" + orderQty +
                ", senderCompId='" + senderCompId + '\'' +
                ", tradeDateMillis=" + tradeDateMillis +
                ", settleDateMillis=" + settleDateMillis +
                ", transactTimeNanos=" + transactTimeNanos +
                ", orderStatus=" + orderStatus +
                ", lastQty=" + lastQty +
                ", lastUsdQty=" + lastUsdQty +
                ", lastPx=" + lastPx +
                ", commissionAdjLastPx=" + commissionAdjLastPx +
                ", midPx=" + midPx +
                ", lastSpotRate=" + lastSpotRate +
                ", lastForwardPoints=" + lastForwardPoints +
                ", leavesQty=" + leavesQty +
                ", cumQty=" + cumQty +
                ", avgPx=" + avgPx +
                ", commissionAdjAvgPx=" + commissionAdjAvgPx +
                ", commission=" + commission +
                '}';
    }
}
