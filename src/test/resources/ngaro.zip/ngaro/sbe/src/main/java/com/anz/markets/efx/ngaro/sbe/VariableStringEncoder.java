package com.anz.markets.efx.ngaro.sbe;

import java.util.Objects;

import org.agrona.ExpandableArrayBuffer;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.LongCodec;

/**
 * Encoder for variable length string into an SBE data element.
 * <p/>
 * This class is NOT thread safe!
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 */
public final class VariableStringEncoder<E> implements StringEncoder<E> {

    private final E enclosingEncoder;
    private final VariableStringTarget target;
    private final ExpandableArrayBuffer buffer;

    public VariableStringEncoder(final E enclosingEncoder, final VariableStringTarget target, final int initialBufferSize) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.target = Objects.requireNonNull(target);
        if (initialBufferSize < 0) {
            throw new IllegalArgumentException("Negative value for initialBufferSize: " + initialBufferSize);
        }
        this.buffer = new ExpandableArrayBuffer(initialBufferSize);
    }

    @Override
    public E encode(final CharSequence source, final int sourceOffset, final int length) {
        for (int i = 0; i < length; i++) {
            final byte b = (byte)source.charAt(i + sourceOffset);
            buffer.putByte(i, b);
        }
        target.putBytes(buffer, 0, length);
        return enclosingEncoder;
    }

    @Override
    public <S> E encode(final S source, final ByteReader<? super S> reader, final int sourceOffset, final int length) {
        for (int i = 0; i < length; i++) {
            final byte b = reader.readByte(source, sourceOffset + i);
            buffer.putByte(i, b);
        }
        target.putBytes(buffer, 0, length);
        return enclosingEncoder;
    }

    @Override
    public E encodeFrom(final StringDecoder stringDecoder) {
        final int length = stringDecoder.decodeTo(buffer, DirectBuffers.BYTE_WRITER);
        target.putBytes(buffer, 0, length);
        return enclosingEncoder;
    }

    @Override
    public E encodeEmpty() {
        target.putBytes(buffer, 0, 0);
        return enclosingEncoder;
    }

    @Override
    public E encodeLong(final long value) {
        final int length = LongCodec.encodeSigned(value, buffer, DirectBuffers.BYTE_WRITER);
        target.putBytes(buffer, 0, length);
        return enclosingEncoder;
    }
}