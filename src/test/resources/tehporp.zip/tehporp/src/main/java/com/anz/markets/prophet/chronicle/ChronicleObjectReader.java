package com.anz.markets.prophet.chronicle;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.util.EnumUtils;

public interface ChronicleObjectReader {
    int INGESTED_LOG_EVENT_INTERVAL = 10_000;
    int FILTERED_LOG_EVENT_INTERVAL = 10_000;

    void processEntity(final ProphetBytes bytes, final MessageType messageType);

    // convenience function to encapsulate what a message row looks like
    static MessageType readHeader(final ProphetBytes prophetBytes, final Header header) {
        final byte messageType = prophetBytes.readByte();
        header.readMarshallable(prophetBytes);
        return EnumUtils.valueOf(MessageType.VALUES, messageType, MessageType.UNKNOWN);
    }
}
