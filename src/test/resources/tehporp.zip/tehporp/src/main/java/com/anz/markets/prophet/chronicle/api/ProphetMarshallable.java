package com.anz.markets.prophet.chronicle.api;

public interface ProphetMarshallable {
    void readMarshallable(final ProphetBytes in);
    void writeMarshallable(final ProphetBytes out);
}
