package com.anz.markets.efx.fox.processor.state;

import com.anz.markets.efx.fox.api.domain.ParentOrderDetails;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.RegulatoryTradeIds;
import com.anz.markets.efx.trading.codec.api.StrategyParameters;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

public class ChildExecutionReportLinkedToParentOrderPublisher {
    public static void publish(final TradingEncoderSupplier encoderSupplier,
                               final ExecutionReportDecoder executionReportDecoder,
                               final ParentOrderDetails parentOrderDetails) {
        final Header header = executionReportDecoder.header();
        final ExecutionReportDecoder.Body body = executionReportDecoder.body();

        final ExecutionReportEncoder.Body executionReportEncoderBody = encoderSupplier.executionReport()
                .messageStart(header.source(), header.sourceSeq())
                .senderCompId().encodeFrom(body.senderCompId())
                .targetCompId().encodeFrom(body.targetCompId())
                .messageId(body.messageId())
                .orderId().encodeFrom(body.orderId())
                .clOrdId().encodeFrom(body.clOrdId())
                .origClOrdId().encodeFrom(body.origClOrdId())
                .clOrdLinkId().encodeLong(parentOrderDetails.orderId())
                .marketId().encodeFrom(body.marketId())
                .execId().encodeFrom(body.execId())
                .execType(body.execType())
                .ordStatus(body.ordStatus())
                .symbol().encodeFrom(body.symbol())
                .securityType(body.securityType())
                .settlType(body.settlType())
                .orderQty(body.orderQty())
                .ordType(body.ordType())
                .timeInForce(body.timeInForce())
                .displayQty(body.displayQty())
                .targetStrategyName().encodeFrom(body.targetStrategyName())
                .price(body.price())
                .side(body.side())
                .currency().encodeFrom(body.currency())
                .transactTime(body.transactTime())
                .tradeDate().encodeFrom(body.tradeDate())
                .settlDate().encodeFrom(body.settlDate())
                .maturityDate().encodeFrom(body.maturityDate())
                .settlCurrency().encodeFrom(body.settlCurrency())
                .expireTime(body.expireTime())
                .effectiveTime(body.effectiveTime())
                .lastQty(body.lastQty())
                .lastUsdQty(body.lastQty() > 0 ? parentOrderDetails.instrument().usdValue(body.lastQty()) : 0)
                .lastPx(body.lastPx())
                .leavesQty(body.leavesQty())
                .cumQty(body.cumQty())
                .avgPx(body.avgPx())
                .midPx(body.midPx())
                .lastSpotRate(body.lastSpotRate())
                .lastForwardPoints(body.lastForwardPoints())
                .commission(body.commission())
                .commissionAdjAvgPx(body.commissionAdjAvgPx())
                .commissionAdjLastPx(body.commissionAdjLastPx());

        final ExecutionReportDecoder.Party parties = executionReportDecoder.parties();
        final int partiesCount = parties.count() + parentOrderDetails.partyRoles().size();
        final ExecutionReportEncoder.Parties partiesGroup  = executionReportEncoderBody.partiesStart(partiesCount);
        for (ExecutionReportDecoder.Party party : parties) {
            partiesGroup.next().partyRole(party.partyRole()).partyId().encodeFrom(party.partyId());
        }
        for (PartyRole partyRole : parentOrderDetails.partyRoles().keySet()) {
            final String partyRoleValue = parentOrderDetails.partyRoles().get(partyRole);
            partiesGroup.next().partyRole(partyRole).partyId().encode(partyRoleValue);
        }
        final ExecutionReportDecoder.StrategyParameter strategyParameters = executionReportDecoder.strategyParameters();
        final int strategyParametersCount = strategyParameters.count();
        final StrategyParameters.Encoder.Next<ExecutionReportEncoder.RegulatoryTradeIds> strategyParametersGroup = partiesGroup.partiesComplete().strategyParametersStart(strategyParametersCount);

        for (ExecutionReportDecoder.StrategyParameter strategyParameter : strategyParameters) {
            strategyParametersGroup.next()
                    .strategyParameterName().encodeFrom(strategyParameter.strategyParameterName())
                    .strategyParameterValue().encodeFrom(strategyParameter.strategyParameterValue());
        }

        final ExecutionReportDecoder.RegulatoryTradeId regulatoryTradeIds = executionReportDecoder.regulatoryTradeIds();
        final int regulatoryTradeIdsCount = regulatoryTradeIds.count();
        final RegulatoryTradeIds.Encoder.Next<ExecutionReportEncoder.Hops> regulatoryTradeIdsGroup = strategyParametersGroup.strategyParametersComplete().regulatoryTradeIdsStart(regulatoryTradeIdsCount);
        for (ExecutionReportDecoder.RegulatoryTradeId regulatoryTradeId : regulatoryTradeIds) {
            regulatoryTradeIdsGroup.next()
                    .id().encodeFrom(regulatoryTradeId.regulatoryTradeId())
                    .source().encodeFrom(regulatoryTradeId.regulatoryTradeIdSource());
        }
        final ExecutionReportDecoder.Hop hops = executionReportDecoder.hops();
        final int hopsCount = hops.count();
        final Hops.Encoder.Next<ExecutionReportEncoder.QuoteId> hopsGroup = regulatoryTradeIdsGroup.regulatoryTradeIdsComplete().hopsStart(hopsCount);
        for (ExecutionReportDecoder.Hop hop : hops) {
            hopsGroup.next().hopReceivingTime(hop.hopReceivingTime())
                    .hopSendingTime(hop.hopSendingTime())
                    .hopMessageId(hop.hopMessageId())
                    .hopCompId().encodeFrom(hop.hopCompId());
        }
        hopsGroup.hopsComplete()
                .quoteId().encodeFrom(executionReportDecoder.trailer().quoteId())
                .rejectText().encodeFrom(executionReportDecoder.trailer().rejectText())
                .messageComplete();
    }

    private ChildExecutionReportLinkedToParentOrderPublisher() {
        throw new IllegalStateException("No ChildExecutionReportLinkedToParentOrderPublisher for you");
    }
}
