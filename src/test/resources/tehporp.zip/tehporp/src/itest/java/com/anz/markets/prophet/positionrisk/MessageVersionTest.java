package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueWrappers;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.HeaderPredicates;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.domain.chronicle.RawBytes;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.AmountUnit;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.anz.markets.prophet.util.ProphetMarshallableCopierTest.setMessageVersion;
import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class MessageVersionTest {
    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    @Before
    public void setup() {
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    @Test
    public void testMessageHeaderVersions() throws IOException, NoSuchFieldException, IllegalAccessException {
        Context.set(new Context(new TimeSourceChronicle()));
        final RawBytes rawBytes = createRawBytes(MessageType.ONE_SECOND, OneSecond.INSTANCE);
        final String basePath = FileUtil.tmpFile(this.getClass().getSimpleName());
        try (ProphetPersister persister = ChroniclePersisterFactory.coreConflate(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, true)) {
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            setMessageVersion(Context.context().header(), MessageVersion.VERSION_0_3);
            persister.sinkRawBytes().accept(rawBytes);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
        }

        final KeepTrack keepTrack = new KeepTrack();
        final ChronicleHook unknownMessageTypeStrategy = ChronicleHook.unknownMessageCounter();
        final Context.HeaderPredicate eventIdFilter = HeaderPredicates.FILTER_ALLOW_ALL;
        try (ProphetReader reader = ChronicleReaderFactory.createToolsCommonReader(ThreadUtils.SameThreadExecutor.INSTANCE, basePath, keepTrack, eventIdFilter, StartAt.EVENTID, 0, unknownMessageTypeStrategy, WaitStrategy.STOP_ON_STALL)) {
            ThreadUtils.sleep(10);
            assertEquals(MessageVersion.getLatestVersion(), keepTrack.versions.get(0));
            assertEquals(MessageVersion.VERSION_0_3, keepTrack.versions.get(1));
            assertEquals(MessageVersion.getLatestVersion(), keepTrack.versions.get(2));
        }
    }

    @Test
    public void testFutureMessageHeaderVersions() throws IOException, NoSuchFieldException, IllegalAccessException {
        Context.set(new Context(new TimeSourceChronicle()));
        final Positions positions = MidRateTestHelper.createPositions(Currency.CAD, AmountUnit.MILLIONS.toDollar(1), 1, Currency.USD, AmountUnit.MILLIONS.toDollar(1), 1);
        final RawBytes rawBytes = createRawBytes(MessageType.POSITIONS, positions);
        final String basePath = FileUtil.tmpFile(this.getClass().getSimpleName());
        try (ProphetPersister persister = ChroniclePersisterFactory.coreConflate(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, true)) {
            persister.sink(MessageType.POSITIONS).accept(positions);
            setMessageVersion(Context.context().header(), MessageVersion.valueOf((byte) 99));
            persister.sinkRawBytes().accept(rawBytes);
        }

        final KeepTrack keepTrack = new KeepTrack();
        final ChronicleHook unknownMessageTypeStrategy = ChronicleHook.unknownMessageCounter();
        final Context.HeaderPredicate eventIdFilter = HeaderPredicates.FILTER_ALLOW_ALL;
        // the below will also ensure that Positions are read correctly with a future version
        try (ProphetReader reader = ChronicleReaderFactory.createToolsCommonReader(ThreadUtils.SameThreadExecutor.INSTANCE, basePath, keepTrack, eventIdFilter, StartAt.EVENTID, 0, unknownMessageTypeStrategy, WaitStrategy.STOP_ON_STALL)) {
            ThreadUtils.sleep(10);
            assertEquals(MessageVersion.getLatestVersion(), keepTrack.versions.get(0));
            assertEquals(MessageVersion.UNKNOWN, keepTrack.versions.get(1));
        }
    }

    @NotNull
    private RawBytes createRawBytes(final MessageType mt, final ProphetMarshallable bm) {
        final RawBytes rawBytes = new RawBytes();
        final ProphetBytes bytes = ChronicleQueueWrappers.wrapFixedSize();
        bm.writeMarshallable(bytes);
        rawBytes.setMessageType(mt).readMarshallable(bytes);
        return rawBytes;
    }

    @Test
    public void ensure_message_version_matches_the_version_value_in_bytes() {
        final Set<MessageVersion> messageVersions = new HashSet<>(Arrays.asList(MessageVersion.values()));
        messageVersions.remove(MessageVersion.UNKNOWN);
        assertEquals(0, MessageVersion.UNKNOWN.getValue());

        for (MessageVersion messageVersion : messageVersions) {
            final String[] versionTokens = messageVersion.name().split("_");
            assertEquals("MessageVersion must follow pattern 'Version_<MAJOR>_<MINOR>'!", 3, versionTokens.length);
            assertEquals("MessageVersion must match version in bytes!", Byte.parseByte(versionTokens[2]), messageVersion.getValue());
        }
    }

    private class KeepTrack implements ChronicleObjectReader {
        final List<MessageVersion> versions = new ArrayList<>();

        @Override
        public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
            versions.add(Context.context().header().getMessageVersion());
        }
    }
}
