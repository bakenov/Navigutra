package com.anz.axle.adapters.ndf2trep.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({PropertiesConfig.class, PublisherConfig.class, SubscriberConfig.class})
public class ServerConfig {
}
