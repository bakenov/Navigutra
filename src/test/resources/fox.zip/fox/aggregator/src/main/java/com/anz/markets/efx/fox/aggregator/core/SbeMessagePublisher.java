package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public class SbeMessagePublisher implements Consumer<SbeMessage> {
    private final RequestKey requestKey;
    private final TopicRegistry topicRegistry;
    private final MessageHandler publisher;

    public SbeMessagePublisher(final RequestKey requestKey, final TopicRegistry topicRegistry, final MessageHandler publisher) {
        this.requestKey = Objects.requireNonNull(requestKey);
        this.topicRegistry = Objects.requireNonNull(topicRegistry);
        this.publisher = Objects.requireNonNull(publisher);
    }

    public static SbeMessagePublisher create(final RequestKey requestKey, final TopicRegistry topicRegistry, final MessageHandler publisher) {
        return new SbeMessagePublisher(requestKey, topicRegistry, publisher);
    }

    @Override
    public void accept(final SbeMessage sbeMessage) {
        final Topic topic = topicRegistry.topic(requestKey.market(), requestKey.instrumentKey());
        if (topic != null) {
            publisher.onMessage(topic, sbeMessage.buffer(), 0, sbeMessage.messageLength(), 0);
        }
    }
}
