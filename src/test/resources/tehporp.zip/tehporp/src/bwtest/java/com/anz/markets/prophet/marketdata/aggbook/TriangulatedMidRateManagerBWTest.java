package com.anz.markets.prophet.marketdata.aggbook;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;

public class TriangulatedMidRateManagerBWTest extends AbstractTriangulatedMidRateManagerForBwJmhTest {

    private static final int REPS = 100_000, THRESHOLD = 100;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private int counter = 1;

    public void testAcceptMidRateRepeatedly() {
        testAcceptMidRate(counter++);
    }

    @Test
    public void testAcceptMidRateUSDBase() {
        helper.testAllocationNotExceeded(
                this::testAcceptMidRateRepeatedly,
                REPS, REPS,
                THRESHOLD
        );
    }

}
