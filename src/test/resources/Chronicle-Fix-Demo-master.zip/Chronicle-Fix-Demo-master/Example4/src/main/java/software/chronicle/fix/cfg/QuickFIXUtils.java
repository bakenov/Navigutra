package software.chronicle.fix.cfg;

import net.openhft.chronicle.wire.Marshallable;
import quickfix.ConfigError;
import quickfix.FieldConvertError;
import quickfix.SessionID;
import quickfix.SessionSettings;
import software.chronicle.fix.staticcode.FixVersion;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;

/**
 * Created by peter on 26/01/2017.
 */
public class QuickFIXUtils {

    public static void main(String[] args) throws ConfigError, FieldConvertError, IOException, ClassNotFoundException {
        if (args.length != 2) {
            System.err.println("Usage: " + QuickFIXUtils.class.getSimpleName() + " <quickfix.ini file> <output file>");
            System.exit(1);
        }

        String quickfix_ini = args[0];
        String outfile = args[1];

        if( quickfix_ini == null || quickfix_ini.isEmpty() || outfile == null || outfile.isEmpty() )
        {
            System.err.println("Usage: " + QuickFIXUtils.class.getSimpleName() + " <quickfix.ini file> <output file>");
            System.exit(1);
        }

        if (Files.lines(Paths.get(quickfix_ini)).anyMatch(s -> s.contains("${")))
            throw new IllegalArgumentException("Can't convert file containing ${...} properties");

        SessionSettings ss = new SessionSettings(quickfix_ini);


//        SessionSettings ss = new SessionSettings( getResource("/example_quickfix.ini" ) );
        FixEngineCfg engineCfg = engineCfgFor(ss);
        try (PrintWriter out = new PrintWriter(outfile)) {
            out.println(engineCfg.toString());
        }
    }

    public static FixEngineCfg engineCfgFor(SessionSettings settings) throws FieldConvertError, ConfigError {
        FixEngineCfg engineCfg = new FixEngineCfg();
        Map<String, FixSessionCfg> cfgMap = engineCfg.sessionMap();
        for (SessionID sessionID : (Iterable<SessionID>) settings::sectionIterator) {
            Properties properties = settings.getSessionProperties(sessionID);
            StringBuilder sb = new StringBuilder();
            sb.append("!").append(FixSessionCfg.class.getName()).append(" {\n");

            convertDifferentNames(properties);

            for (Enumeration<?> enumeration = properties.propertyNames(); enumeration.hasMoreElements(); ) {
                String key = (String) enumeration.nextElement();
                Object value = properties.getProperty(key);
                sb.append(key).append(": ").append(value).append("\n");
            }

            sb.append("}\n");
//            System.out.println(sb);

            FixSessionCfg cfg = Marshallable.fromString(sb);

            cfgMap.put(sessionID.toString(), cfg);
        }
        return engineCfg;
    }

    private static void convertDifferentNames(Properties properties) {
        properties.put("fixVersion", fixVersion(properties.getProperty("BeginString")).name());
        properties.remove("BeginString");

        if (properties.getProperty("SocketAcceptAddress") != null || properties.getProperty("SocketAcceptPort") != null) {
            String address = properties.getProperty("SocketAcceptAddress");
            if (address != null) {
                address += ":";
            } else {
                address = "";
            }
            properties.put("socketAcceptorHostPort", (address + properties.getProperty("SocketAcceptPort")));
            properties.remove("SocketAcceptAddress");
            properties.remove("SocketAcceptPort");
        } else {
            properties.put("socketConnectHostPort", Arrays.toString(
                    new String[]{properties.getProperty("SocketConnectHost") + ":" + properties.getProperty("SocketConnectPort")}));
            properties.remove("SocketConnectHost");
            properties.remove("SocketConnectPort");
        }
    }

    private static FixVersion fixVersion(String string) {
        string = string.replace("FIX.", "V");
        string = string.replace(".", "_");
        FixVersion fixVersion = FixVersion.valueOf(string);
        assert fixVersion != null;
        return fixVersion;
    }
}
