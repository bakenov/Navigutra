package software.chronicle.fix;

import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.WireIn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;

import java.util.concurrent.CountDownLatch;

public class GeneratorNotifier implements MessageNotifier, Demarshallable {
    private static Logger LOGGER = LoggerFactory.getLogger(GeneratorNotifier.class);
    CountDownLatch loggedIn = new CountDownLatch(1);

    private GeneratorNotifier(WireIn w) {
    }

    @Override
    public MessageGenerator onExecutionReport(ExecutionReport executionReport) {
        LOGGER.info("Generator onExecutionReport received {}", executionReport.clOrdID());
        return null;
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        loggedIn.countDown();
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        LOGGER.error("Reject {}", reject);
    }
}
