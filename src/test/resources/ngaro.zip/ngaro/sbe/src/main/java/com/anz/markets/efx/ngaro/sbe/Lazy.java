package com.anz.markets.efx.ngaro.sbe;

import java.util.Objects;
import java.util.function.Supplier;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;

import com.anz.markets.efx.ngaro.core.CachingSupplier;

/**
 * Provides static methods for lazy initialisation. This is sometimes used for instance for SBE group elements since
 * they cannot be accessed before wrapping the encoder or decoder.
 */
public class Lazy {

    public static <T> CachingSupplier<T> cachingSupplier(final Supplier<? extends T> supplier) {
        return CachingSupplier.of(supplier);
    }

    public static FixedStringSource fixedStringSource(final Supplier<FixedStringSource> supplier) {
        Objects.requireNonNull(supplier);
        return new FixedStringSource() {
            FixedStringSource delegate = null;
            @Override
            public byte getByte(final int index) {
                if (delegate == null) {
                    delegate = supplier.get();
                }
                return delegate.getByte(index);
            }
        };
    }

    public static FixedStringTarget fixedStringTarget(final Supplier<FixedStringTarget> supplier) {
        Objects.requireNonNull(supplier);
        return new FixedStringTarget() {
            FixedStringTarget delegate = null;
            @Override
            public void putByte(final int index, final byte value) {
                if (delegate == null) {
                    delegate = supplier.get();
                }
                delegate.putByte(index, value);
            }
        };
    }

    public static VariableStringSource variableStringSource(final Supplier<VariableStringSource> supplier) {
        Objects.requireNonNull(supplier);
        return new VariableStringSource() {
            VariableStringSource delegate = null;
            @Override
            public int getBytes(final MutableDirectBuffer target, final int targetOffset, final int length) {
                if (delegate == null) {
                    delegate = supplier.get();
                }
                return delegate.getBytes(target, targetOffset, length);
            }
        };
    }

    public static VariableStringTarget variableStringTarget(final Supplier<VariableStringTarget> supplier) {
        Objects.requireNonNull(supplier);
        return new VariableStringTarget() {
            VariableStringTarget delegate = null;
            @Override
            public Object putBytes(final DirectBuffer source, final int sourceOffset, final int length) {
                if (delegate == null) {
                    delegate = supplier.get();
                }
                return delegate.putBytes(source, sourceOffset, length);
            }
        };
    }

    private Lazy() {
        throw new RuntimeException("No Lazy for you!");
    }
}
