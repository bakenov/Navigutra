package com.anz.axle.lg.adapter.d3.newsubscription;

import java.time.LocalDate;
import java.util.Map;
import java.util.Objects;
import java.util.Spliterator;
import java.util.function.LongConsumer;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.digitec.d3.pricing.streaming.Field;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.lg.adapter.d3.model.D3Codec;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import static java.util.Spliterators.spliteratorUnknownSize;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.StreamSupport.stream;

/**
 * Note that the encoded message will have exactly 2 entries:
 * <ol>
 *     <li>An entry for the {@link EntryType#BID} SPOT price and FORWARD points .</li>
 *     <li>An entry for the {@link EntryType#OFFER} SPOT price and FORWARD points .</li>
 * </ol>
 */
public final class DefaultUpdateProcessor implements UpdateProcessor {
    private static final Logger MESSAGES_LOGGER = LoggerFactory.getLogger("MESSAGES");

    public static final String BID_QUOTE_ENTRY_SUFFIX = "_1";
    public static final String OFFER_QUOTE_ENTRY_SUFFIX = "_2";

    private final RequestKey requestKey;
    private final PricingEncoderSupplier pricingEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String compId;
    private final String senderCompId;
    private final LongSupplier idGenerator;
    private final LongConsumer updateTimeNanosUpdater;
    private final SourceSequencer sourceSequencer;

    public DefaultUpdateProcessor(final RequestKey requestKey,
                                  final PricingEncoderSupplier pricingEncoderSupplier,
                                  final PrecisionClock precisionClock,
                                  final LongSupplier idGenerator,
                                  final LongConsumer updateTimeNanosUpdater,
                                  final String compId,
                                  final String senderCompId,
                                  final SourceSequencer sourceSequencer) {
        this.requestKey = Objects.requireNonNull(requestKey);
        this.pricingEncoderSupplier = Objects.requireNonNull(pricingEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.idGenerator = Objects.requireNonNull(idGenerator);
        this.updateTimeNanosUpdater = Objects.requireNonNull(updateTimeNanosUpdater);
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void processUpdate(final UpdateMessage updateMessage) {
        final long receivingTimeNanos = precisionClock.nanos();
        MESSAGES_LOGGER.info("{}", updateMessage);

        updateTimeNanosUpdater.accept(receivingTimeNanos);
        final Map<String, String> rawUpdates = stream(spliteratorUnknownSize(updateMessage.getFields(), Spliterator.ORDERED), false)
                .collect(toMap(Field::getKey, Field::getValue));

        final long messageId = idGenerator.getAsLong();
        final String quoteId = (rawUpdates.get(D3Codec.CURRENCY1) + "/" + rawUpdates.get(D3Codec.CURRENCY2)) + messageId;

        final String forwardSymbol = rawUpdates.get(D3Codec.CURRENCY1) + rawUpdates.get(D3Codec.CURRENCY2);
        if (!forwardSymbol.equals(requestKey.instrumentKey().symbol())) {
            throw new IllegalStateException("Symbol " + forwardSymbol + " does not match requested symbol " + requestKey.instrumentKey().symbol() + ". Update message: " + updateMessage);
        }

        final LocalDate settlementDate = D3Codec.asLocalDate(D3Codec.NEAR_DATE, rawUpdates::get)
                .orElseThrow(() ->
                        new IllegalArgumentException("NEAR_DATE field does not contain valid date. Update message: " + updateMessage)
                );

        if (requestKey.instrumentKey().settlementDate().isPresent()) {
            if (!requestKey.instrumentKey().settlementDate().get().equals(settlementDate)) {
                throw new IllegalStateException("SettlementDate " + settlementDate + " does not match requested settlementDate " + requestKey.instrumentKey().settlementDate().get() + ". Update message: " + updateMessage);
            }
        }

        final long sendingTimeNanos = precisionClock.nanos();
        final SnapshotFullRefreshEncoder.Body snapshotMessageEncoder = pricingEncoderSupplier.snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .possResend(false)
                .messageId(messageId)
                .sendingTime(sendingTimeNanos)
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .marketId(requestKey.market())
                .tradeDate().encodeNullable(D3Codec.asLocalDate(D3Codec.TRADING_DATE, rawUpdates::get).orElse(null))
                .settlDate().encodeNullable(settlementDate)
                .referenceSpotDate().encodeNullable(D3Codec.asLocalDate(D3Codec.SPOT_DATE, rawUpdates::get).orElse(null))
                ;

        D3Codec.asMarketDataFlag(D3Codec.STATUS, rawUpdates::get)
                .map(snapshotMessageEncoder.mdFlags()::add);

        final SnapshotFullRefreshEncoder.MdEntries.Next mdEntries_next = snapshotMessageEncoder.entriesStart(2);

        final double pip = D3Codec.asDouble(D3Codec.PIP, rawUpdates::get);
        final double bidPoints = D3Codec.asDouble(D3Codec.NEAR_FORWARD_POINT_BID, rawUpdates::get);
        final double offerPoints = D3Codec.asDouble(D3Codec.NEAR_FORWARD_POINT_ASK, rawUpdates::get);

        addEntry(mdEntries_next.next(), receivingTimeNanos, D3Codec.asDouble(D3Codec.SPOT_BID, rawUpdates::get), bidPoints / pip, EntryType.BID);
        addEntry(mdEntries_next.next(), receivingTimeNanos, D3Codec.asDouble(D3Codec.SPOT_ASK, rawUpdates::get), offerPoints / pip, EntryType.OFFER);

        mdEntries_next.entriesComplete()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
                .messageComplete();
    }

    private void addEntry(final SnapshotFullRefreshEncoder.MdEntries.Body mdEntries_body,
                          final long transactTimeNanos,
                          final double price,
                          final double priceOffset,
                          final EntryType side) {
        mdEntries_body
                .transactTime(transactTimeNanos)
                .mdMkt(requestKey.market())
                .mdEntryType(side)
                .mdEntryPx(price)
                .mdEntryForwardPoints(priceOffset)
                .mdEntrySize(Double.NaN)
                .minQty(Double.NaN)
                .mdEntryId(0)
                .quoteEntryId(0);
    }
}
