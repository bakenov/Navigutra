#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_price_freq_au - Plugin to monitor the Price Update Frequency (VAG2)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=z::deprecated
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Price Update Frequency (VAG2) [DEPRECATED]'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category z::deprecated'
    echo 'graph_scale no'
    echo 'price1.label Venue Price Updates (UBS)'
    echo 'price1.draw AREA'
    echo 'price3.label Venue Price Updates (EBS)'
    echo 'price3.draw STACK'
    echo 'price6.label Venue Price Updates (MSI)'
    echo 'price6.draw STACK'
    echo 'price14.label Venue Price Updates (HSP)'
    echo 'price14.draw STACK'
    echo 'price15.label Venue Price Updates (GCS)'
    echo 'price15.draw STACK'
    echo 'price4.label Venue Price Updates (CITI)'
    echo 'price4.draw STACK'
    echo 'price5.label AggBooks Aggregated'
    echo 'price5.draw LINE2'
    echo 'price5.colour FF0000'		# RED
    echo 'price11.label AggBooks Published to Main'
    echo 'price11.draw LINE2'
    echo 'price11.colour FFFFFF'	# WHITE
    exit 0
fi


echo "price1.value U"
echo "price3.value U"
echo "price6.value U"
echo "price14.value U"
echo "price15.value U"
echo "price4.value U"
echo "price5.value U"
echo "price11.value U"
exit 0