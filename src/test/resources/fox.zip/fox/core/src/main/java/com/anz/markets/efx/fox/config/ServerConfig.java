package com.anz.markets.efx.fox.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import java.util.Objects;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.pricing.client.api.PricingClient;

@Configuration
@Import({
        CommonConfig.class,
        MetricsConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PricingConfig.class,
        FirewallsConfig.class,
        ProcessorConfig.class,
        EventSourcingConfig.class,
        ReceiverConfig.class,
        SenderConfig.class
})
public class ServerConfig {
    private final PricingClient<MutableSbeMessage> pricingClient;
    private final Service receiverEventLoopService;
    private final Service processorEventLoopService;
    private final Service senderEventLoopService;


    public ServerConfig(final PricingClient<MutableSbeMessage> pricingClient,
                        final Service receiverEventLoopService,
                        final Service processorEventLoopService,
                        final Service senderEventLoopService) {
        this.pricingClient = Objects.requireNonNull(pricingClient);
        this.receiverEventLoopService = Objects.requireNonNull(receiverEventLoopService);
        this.processorEventLoopService = Objects.requireNonNull(processorEventLoopService);
        this.senderEventLoopService = Objects.requireNonNull(senderEventLoopService);
    }

    @PostConstruct
    public void start() {
        pricingClient.service().start();
        processorEventLoopService.start();
        receiverEventLoopService.start();
        senderEventLoopService.start();
    }

    @PreDestroy
    public void stop() {
        pricingClient.service().stop();
        receiverEventLoopService.stop();
        senderEventLoopService.stop();
        processorEventLoopService.stop();
    }
}
