package com.anz.markets.prophet.domain.collections;

import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CollectionsBWTest {
    private static final int REPS = 100_000, MAX_SIZE = 100, THRESHOLD = 100;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private final PoolingArrayList<MarketDataNewOrder> list;

    public CollectionsBWTest() {
        this.list = PoolingArrayList.max(MAX_SIZE, ObjectPoolArrays.factory(() -> new MarketDataNewOrderImpl()));
        for (int i = 0; i < MAX_SIZE; i++) {
            MarketDataNewOrderImpl cs = (MarketDataNewOrderImpl) list.addFromSupplier();
            list.assertInvariants();
            cs.setOrderId(String.valueOf(i));
        }
    }

    @Test
    public void testAAA_Warmup() {
        iterate0GarbageList();
        addRemoveAll();
    }

    @Test
    public void testIterate0GarbageList() {
        helper.testAllocationNotExceeded(
                this::iterate0GarbageList,
                THRESHOLD
        );
    }

    @Test
    public void testAddRemoveAll() {
        helper.testAllocationNotExceeded(
                this::addRemoveAll,
                THRESHOLD
        );
    }

    private long iterate0GarbageList() {
        long total = 0;
        for (int i = 0; i < REPS; i++) {
            for (MarketDataNewOrder cs : list) {
                total += cs.getOrderId().hashCode();
            }
        }
        return total;
    }

    private void addRemoveAll() {
        for (int i = 0; i < REPS; i++) {
            PoolingArrayListTest.fill(list, MAX_SIZE);
            PoolingArrayListTest.removeAllFromEnd(list, MAX_SIZE);
        }
    }
}
