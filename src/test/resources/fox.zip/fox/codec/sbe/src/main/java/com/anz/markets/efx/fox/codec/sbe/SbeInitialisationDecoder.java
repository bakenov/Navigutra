package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.InitialisationDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

final class SbeInitialisationDecoder {
    private final InitialisationDecoder initialisationDecoder = new InitialisationDecoder();
    private final Consumer<StringBuilder> messageLogger = initialisationDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.Initialisation encodingOrder = EncodingOrder.Initialisation.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final InitialisationHandler initialisationHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.Initialisation.INITIAL;
        initialisationDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            initialisationHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            initialisationHandler.messageForwarder(messageForwarder);
            initialisationHandler.messageLogger(messageLogger);
            body.decode(initialisationHandler);
            initialisationHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.Initialisation.INITIAL;
            initialisationDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements InitialisationHandler.Body {
        void decode(final InitialisationHandler initialisationHandler) {
            encodingOrder = EncodingOrder.Initialisation.BODY;
            initialisationHandler.onBody(this);
        }

        @Override
        public InitStage initStage() {
            encodingOrder.checkStrict(EncodingOrder.Initialisation.BODY);
            return Enums.initStage(initialisationDecoder.initStage());
        }
    }
}
