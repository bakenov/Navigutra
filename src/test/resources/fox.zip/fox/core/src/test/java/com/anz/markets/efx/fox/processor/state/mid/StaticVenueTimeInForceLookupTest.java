package com.anz.markets.efx.fox.processor.state.mid;

import org.junit.jupiter.api.Test;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import static org.assertj.core.api.Assertions.assertThat;

class StaticVenueTimeInForceLookupTest {
    private StaticVenueTimeInForceLookup venueTimeInForceLookup = new StaticVenueTimeInForceLookup();

    @Test
    void lookup() {
        assertThat(venueTimeInForceLookup.lookup(TimeInForce.DAY, Venue.FXALLMB)).isEqualTo(TimeInForce.DAY);
        assertThat(venueTimeInForceLookup.lookup(TimeInForce.GTC, Venue.FXALLMB)).isEqualTo(TimeInForce.DAY);
        assertThat(venueTimeInForceLookup.lookup(TimeInForce.GTC, Venue.EBSHEDGE)).isEqualTo(TimeInForce.GTC);
        assertThat(venueTimeInForceLookup.lookup(TimeInForce.DAY, Venue.EBSHEDGE)).isEqualTo(TimeInForce.GTC);
        assertThat(venueTimeInForceLookup.lookup(TimeInForce.IOC, Venue.EBS)).isEqualTo(TimeInForce.IOC);
    }
}