package com.anz.axle.lg.adapter.apama.decoder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.event.EbsTradingSessionStatus;
import com.anz.axle.lg.config.PricingEncoderLookup;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit test for {@link EbsTradingSessionStatusDecoder}
 */
@RunWith(Spockito.class)
public class EbsTradingSessionStatusDecoderTest {

    private static final EventParser EVENT_PARSER = new EventParser(EbsTradingSessionStatus.EVENT_TYPE);

    private PricingEncoderLookup pricingEncoderLookup;
    private String transport = "EBS_FIX_MARKETDATA_AND_TRADING";

    private EbsTradingSessionStatusDecoder ebsTradingSessionStatusDecoder;

    @Before
    public void setUp() throws Exception {
        pricingEncoderLookup = mock(PricingEncoderLookup.class);
        ebsTradingSessionStatusDecoder = new EbsTradingSessionStatusDecoder(pricingEncoderLookup, transport);
    }

    @Test
    @Spockito.Unroll({
            "| Status | Clean Times |",
            "|========|=============|",
            "| 2      | 0           |",
            "| 1003   | 0           |",
            "| 3      | 1           |",
            "| 1004   | 1           |"
    })
    @Spockito.Name("[{Status}] - {Clean Times} clean times")
    public void decode(final long status, final int cleanTimes) throws Exception {
        //given
        final String eventMessage = "com.apama.fix.ebs.EBSTradingSessionStatus(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"SESSID\"," + status + ",{})";
        final Event event = EVENT_PARSER.parse(eventMessage);

        //when
        ebsTradingSessionStatusDecoder.decode(event);

        //then
        verify(pricingEncoderLookup, times(cleanTimes)).clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_DISCONNECTED);
    }

}