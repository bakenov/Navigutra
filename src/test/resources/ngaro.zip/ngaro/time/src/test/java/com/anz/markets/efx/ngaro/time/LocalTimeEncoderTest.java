package com.anz.markets.efx.ngaro.time;

import java.nio.ByteBuffer;
import java.time.LocalTime;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteWriter;

public class LocalTimeEncoderTest {

    @Test
    public void encodeEpochNanos() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final int nn = 234567891;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeEpochNanos(string, ByteWriter.STRING_BUILDER, offset, (((hh * 60) + mm) * 60 + ss) * 1_000_000_000L + nn);
        localTimeEncoder.encodeEpochNanos(bytes, ByteWriter.BYTE_ARRAY, (((hh * 60) + mm) * 60 + ss) * 1_000_000_000L + nn);
        localTimeEncoder.encodeEpochNanos(buffer, ByteWriter.BYTE_BUFFER, (((hh * 60) + mm) * 60 + ss) * 1_000_000_000L + nn);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17:15:30.234567891xyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17:15:30.234567891", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17:15:30.234567891", new String(buffer.array()));
    }

    @Test
    public void encodeEpochMillis() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS.getDefaultEncoder();
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[8];
        final ByteBuffer buffer = ByteBuffer.allocate(8);

        //when
        localTimeEncoder.encodeEpochMillis(string, ByteWriter.STRING_BUILDER, offset, (((hh * 60) + mm) * 60 + ss) * 1000L);
        localTimeEncoder.encodeEpochMillis(bytes, ByteWriter.BYTE_ARRAY, (((hh * 60) + mm) * 60 + ss) * 1000L);
        localTimeEncoder.encodeEpochMillis(buffer, ByteWriter.BYTE_BUFFER, (((hh * 60) + mm) * 60 + ss) * 1000L);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17:15:30nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17:15:30", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17:15:30", new String(buffer.array()));
    }

    @Test
    public void encodeEpochSeconds() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS.getDefaultEncoder();
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[8];
        final ByteBuffer buffer = ByteBuffer.allocate(8);

        //when
        localTimeEncoder.encodeEpochSeconds(string, ByteWriter.STRING_BUILDER, offset, ((hh * 60) + mm) * 60 + ss);
        localTimeEncoder.encodeEpochSeconds(bytes, ByteWriter.BYTE_ARRAY, ((hh * 60) + mm) * 60 + ss);
        localTimeEncoder.encodeEpochSeconds(buffer, ByteWriter.BYTE_BUFFER, ((hh * 60) + mm) * 60 + ss);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17:15:30nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17:15:30", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17:15:30", new String(buffer.array()));
    }

    @Test
    public void encodeLocalTime() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final int nn = 234567891;
        final LocalTime localTime = LocalTime.of(hh, mm, ss, nn);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encode(string, ByteWriter.STRING_BUILDER, offset, localTime);
        localTimeEncoder.encode(bytes, ByteWriter.BYTE_ARRAY, localTime);
        localTimeEncoder.encode(buffer, ByteWriter.BYTE_BUFFER, localTime);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17:15:30.234567uvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17:15:30.234567", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17:15:30.234567", new String(buffer.array()));
    }

    @Test
    public void encodeLocalDateNull() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encode(string, ByteWriter.STRING_BUILDER, offset, null);
        localTimeEncoder.encode(bytes, ByteWriter.BYTE_ARRAY, null);
        localTimeEncoder.encode(buffer, ByteWriter.BYTE_BUFFER, null);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0:\0\0:\0\0.\0\0\0\0\0\0uvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0:\0\0:\0\0.\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0:\0\0:\0\0.\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeNull() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_MMM.getDefaultEncoder();
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeNull(string, ByteWriter.STRING_BUILDER, offset);
        localTimeEncoder.encodeNull(bytes, ByteWriter.BYTE_ARRAY);
        localTimeEncoder.encodeNull(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0:\0\0:\0\0.\0\0\0rstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0:\0\0:\0\0.\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0:\0\0:\0\0.\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeAllFormats() {
        final LocalTime input = LocalTime.of(17, 15, 30, 234567891);
        final LocalTimeFormat[] formats = {
                LocalTimeFormat.HHMM, LocalTimeFormat.HHMMSS, LocalTimeFormat.HHMMSSMMM, LocalTimeFormat.HHMMSSUUUUUU, LocalTimeFormat.HHMMSSNNNNNNNNN,
                LocalTimeFormat.HH_MM, LocalTimeFormat.HH_MM_SS, LocalTimeFormat.HH_MM_SS_MMM, LocalTimeFormat.HH_MM_SS_UUUUUU, LocalTimeFormat.HH_MM_SS_NNNNNNNNN
        };
        final String[] dateStrings = {
                "1715", "171530", "171530234", "171530234567", "171530234567891",
                "17:15", "17:15:30", "17:15:30.234", "17:15:30.234567", "17:15:30.234567891"
        };
        final char[] delims = {':', '/'};
        final char[] decimalSymbols = {'.', '_'};

        for (int f = 0; f < formats.length; f++) {
            for (final char delim : delims) {
                for (final char sym : decimalSymbols) {
                    final LocalTimeEncoder encoder = LocalTimeEncoder.valueOf(formats[f], delim, sym);
                    final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
                    final int offset = 3;
                    final byte[] bytes = new byte[formats[f].getLength()];
                    final ByteBuffer buffer = ByteBuffer.allocate(formats[f].getLength());

                    //when
                    encoder.encode(string, ByteWriter.STRING_BUILDER, offset, input);
                    encoder.encode(bytes, ByteWriter.BYTE_ARRAY, input);
                    encoder.encode(buffer, ByteWriter.BYTE_BUFFER, input);

                    //then
                    final String expected = dateStrings[f].replace('.', sym).replace(':', delim);
                    final String expectedString = "abc" + expected + "defghklmnopkrstuvwxyz".substring(expected.length());
                    Assert.assertEquals("encoded string not as expected", expectedString, string.toString());
                    Assert.assertEquals("encoded bytes not as expected", expected, new String(bytes));
                    Assert.assertEquals("encoded buffer not as expected", expected, new String(buffer.array()));
                }
            }
        }
    }

    @Test
    public void encodeHourMinuteSecond() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS.getDefaultEncoder();
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[8];
        final ByteBuffer buffer = ByteBuffer.allocate(8);

        //when
        localTimeEncoder.encode(string, ByteWriter.STRING_BUILDER, offset, hh, mm, ss, 0);
        localTimeEncoder.encode(bytes, ByteWriter.BYTE_ARRAY, hh, mm, ss);
        localTimeEncoder.encode(buffer, ByteWriter.BYTE_BUFFER, hh, mm, ss);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17:15:30nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17:15:30", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17:15:30", new String(buffer.array()));
    }

    @Test
    public void encodeHourMinuteSecondNano() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final int nn = 987654321;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encode(string, ByteWriter.STRING_BUILDER, offset, hh, mm, ss, nn);
        localTimeEncoder.encode(bytes, ByteWriter.BYTE_ARRAY, hh, mm, ss, nn);
        localTimeEncoder.encode(buffer, ByteWriter.BYTE_BUFFER, hh, mm, ss, nn);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17:15:30.987654321xyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17:15:30.987654321", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17:15:30.987654321", new String(buffer.array()));
    }

    @Test
    public void encodeHour() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int hh = 17;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeHour(string, ByteWriter.STRING_BUILDER, offset, hh);
        localTimeEncoder.encodeHour(bytes, ByteWriter.BYTE_ARRAY, hh);
        localTimeEncoder.encodeHour(buffer, ByteWriter.BYTE_BUFFER, hh);

        //then
        Assert.assertEquals("encoded string not as expected", "abc17fghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "17\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "17\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeMinute() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int mm = 15;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeMinute(string, ByteWriter.STRING_BUILDER, offset, mm);
        localTimeEncoder.encodeMinute(bytes, ByteWriter.BYTE_ARRAY, mm);
        localTimeEncoder.encodeMinute(buffer, ByteWriter.BYTE_BUFFER, mm);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdef15klmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\00015\0\0\0\0\0\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\00015\0\0\0\0\0\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeSecond() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int ss = 30;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeSecond(string, ByteWriter.STRING_BUILDER, offset, ss);
        localTimeEncoder.encodeSecond(bytes, ByteWriter.BYTE_ARRAY, ss);
        localTimeEncoder.encodeSecond(buffer, ByteWriter.BYTE_BUFFER, ss);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghk30nopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\00030\0\0\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\00030\0\0\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeMilli() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int milli = 123;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeMilli(string, ByteWriter.STRING_BUILDER, offset, milli);
        localTimeEncoder.encodeMilli(bytes, ByteWriter.BYTE_ARRAY, milli);
        localTimeEncoder.encodeMilli(buffer, ByteWriter.BYTE_BUFFER, milli);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmn123000000xyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0\000123000000", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0\000123000000", new String(buffer.array()));
    }

    @Test
    public void encodeMicro() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int micro = 123456;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeMicro(string, ByteWriter.STRING_BUILDER, offset, micro);
        localTimeEncoder.encodeMicro(bytes, ByteWriter.BYTE_ARRAY, micro);
        localTimeEncoder.encodeMicro(buffer, ByteWriter.BYTE_BUFFER, micro);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmn123456000xyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0\000123456000", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0\000123456000", new String(buffer.array()));
    }

    @Test
    public void encodeNano() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_NNNNNNNNN.getDefaultEncoder();
        final int nano = 12345678;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeNano(string, ByteWriter.STRING_BUILDER, offset, nano);
        localTimeEncoder.encodeNano(bytes, ByteWriter.BYTE_ARRAY, nano);
        localTimeEncoder.encodeNano(buffer, ByteWriter.BYTE_BUFFER, nano);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmn012345678xyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0\000012345678", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0\000012345678", new String(buffer.array()));
    }

    @Test
    public void encodeNanoIntoMicro() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final int nano = 123456789;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeNano(string, ByteWriter.STRING_BUILDER, offset, nano);
        localTimeEncoder.encodeNano(bytes, ByteWriter.BYTE_ARRAY, nano);
        localTimeEncoder.encodeNano(buffer, ByteWriter.BYTE_BUFFER, nano);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmn123456uvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0\000123456", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0\000123456", new String(buffer.array()));
    }

    @Test
    public void encodeNanoIntoMilli() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_MMM.getDefaultEncoder();
        final int nano = 123456789;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeNano(string, ByteWriter.STRING_BUILDER, offset, nano);
        localTimeEncoder.encodeNano(bytes, ByteWriter.BYTE_ARRAY, nano);
        localTimeEncoder.encodeNano(buffer, ByteWriter.BYTE_BUFFER, nano);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmn123rstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0\000123", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0\000123", new String(buffer.array()));
    }

    @Test
    public void encodeNanoIntoNoFraction() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS.getDefaultEncoder();
        final int nano = 123456789;
        final StringBuilder string = new StringBuilder("abcdefghklmnopqrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeNano(string, ByteWriter.STRING_BUILDER, offset, nano);
        localTimeEncoder.encodeNano(bytes, ByteWriter.BYTE_ARRAY, nano);
        localTimeEncoder.encodeNano(buffer, ByteWriter.BYTE_BUFFER, nano);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmnopqrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeDelimitersAndFractionSymbol() {
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_MMM.getDefaultEncoder();
        final StringBuilder string = new StringBuilder("abcdefghklmnopqrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[localTimeEncoder.getTimeFormat().getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(localTimeEncoder.getTimeFormat().getLength());

        //when
        localTimeEncoder.encodeDelimitersAndFractionSymbol(string, ByteWriter.STRING_BUILDER, offset);
        localTimeEncoder.encodeDelimitersAndFractionSymbol(bytes, ByteWriter.BYTE_ARRAY);
        localTimeEncoder.encodeDelimitersAndFractionSymbol(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abcde:gh:lm.opqrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0:\0\0:\0\0.\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0:\0\0:\0\0.\0\0\0", new String(buffer.array()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void delimiterInvalid() {
        //when
        LocalTimeEncoder.valueOf(LocalTimeFormat.HH_MM, '\uf111', '.');

        //then: expect exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void fractionSymbolInvalid() {
        //when
        LocalTimeEncoder.valueOf(LocalTimeFormat.HH_MM, ':', '\uf111');

        //then: expect exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeHourNegative() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeHour(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeHourTooLarge() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeHour(sb, ByteWriter.STRING_BUILDER, offset, 24);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMinuteNegative() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeMinute(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMinuteTooLarge() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeMinute(sb, ByteWriter.STRING_BUILDER, offset, 60);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeSecondNegative() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeSecond(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeSecondTooLarge() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeSecond(sb, ByteWriter.STRING_BUILDER, offset, 60);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMilliNegative() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeMilli(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMilliTooLarge() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeMilli(sb, ByteWriter.STRING_BUILDER, offset, 1_000);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMicroNegative() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeMicro(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeMicroTooLarge() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeMicro(sb, ByteWriter.STRING_BUILDER, offset, 1_000_000);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeNanoNegative() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeNano(sb, ByteWriter.STRING_BUILDER, offset, -1);

        //then: expecte exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void encodeNanoTooLarge() {
        //given
        final LocalTimeEncoder localTimeEncoder = LocalTimeFormat.HH_MM_SS_UUUUUU.getDefaultEncoder();
        final StringBuilder sb = new StringBuilder("abcdefghklmnopkrstuvwxyz");
        final int offset = 3;

        //when
        localTimeEncoder.encodeNano(sb, ByteWriter.STRING_BUILDER, offset, 1_000_000_000);

        //then: expecte exception
    }
}