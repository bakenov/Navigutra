package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public interface OrderConsumer {
    boolean accept(NewOrderSingleDecoder newOrderSingle, CommandContext commandContext);

    interface ErrorHandler {
        void accept(NewOrderSingleDecoder newOrderSingle, CommandContext commandContext, Rule rule);
    }
}
