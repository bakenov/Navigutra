package com.anz.markets.efx.fox.api.domain;

public interface UserSession {
    UserSessionKey userSessionKey();
    int onlinePortfolioSessions();
    void updateOnline();
    void updateOffline();
    boolean online();
}
