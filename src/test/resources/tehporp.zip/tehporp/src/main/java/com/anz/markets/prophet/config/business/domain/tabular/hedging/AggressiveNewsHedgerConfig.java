package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveNewsHedgerConfigImpl;

public interface AggressiveNewsHedgerConfig extends HedgeInstrumentConfig {
    AggressiveNewsHedgerConfig EMPTY = new AggressiveNewsHedgerConfigImpl();

    long getTriggerBeforeNewsMS();

    double getMinimumNewsWeight();

    double getMinimumRisk();

    double getMinimumOrderQuantity();

    double getMaximumSpread();

}
