package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.PriceRounder;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Quote;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultQuote;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.util.CurrentMillisIdFactory;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class BgcSnapshotFullRefreshHandler implements SnapshotFullRefreshHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcSnapshotFullRefreshHandler.class);

    private final PriceRounder priceRounder;
    private final InstrumentKey.Lookup instrumentKeyLookup;
    private final FixMessageSender fixPricingMessageSender;
    private InstrumentKey instrumentKey;
    private final Quote quote;
    private final Map<String, String> symbol7Map = new HashMap<>();
    private final LongIdFactory idGenerator = new CurrentMillisIdFactory();

    public BgcSnapshotFullRefreshHandler(final PriceRounder priceRounder,
                                         final InstrumentKey.Lookup instrumentKeyLookup,
                                         final FixMessageSender fixPricingMessageSender) {
        this.priceRounder = Objects.requireNonNull(priceRounder);
        this.instrumentKeyLookup = Objects.requireNonNull(instrumentKeyLookup);
        this.fixPricingMessageSender = Objects.requireNonNull(fixPricingMessageSender);
        this.quote = new DefaultQuote();
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        quote.reset();
        instrumentKey = null;
    }

    @Override
    public void onBody(final Body body) {
        LOGGER.debug("Body Received: instrument={}", body.instrumentId());
        quote.quoteID(Long.toString(idGenerator.get()));
        instrumentKey = instrumentKeyLookup.lookup(body.instrumentId());
        quote.symbol(symbol7(instrumentKey.symbol()));
        quote.securityType(instrumentKey.securityType().name());
        quote.transactTime(body.sendingTime(), TimeUnit.NANOSECONDS);
    }

    @Override
    public void onMdEntries_Body(final MdEntries.Body entry, final int entryIndex, final int maxEntryCount) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("onMdEntries_Body Received: price={}, type={}, size={}, entryIndex={}, maxEntryCount={}", entry.mdEntryPx(), entry.mdEntryType(), entry.mdEntrySize(), entryIndex, maxEntryCount);
        }

        final double price = priceRounder.round(instrumentKey.symbol(), entry.mdEntryType(), entry.mdEntryPx());
        if (EntryType.BID.equals(entry.mdEntryType())) {
            quote.bidPx(price);
            quote.bidSize(entry.mdEntrySize());
        } else {
            quote.offerPx(price);
            quote.offerSize(entry.mdEntrySize());
        }
    }

    @Override
    public void onMdEntriesComplete(final int entryCount) {
        if (entryCount == 0) {
            LOGGER.debug("onMdEntriesComplete entryCount=0. set zero prices");
            quote.bidPx(0.0);
            quote.bidSize(0.0);
            quote.offerPx(0.0);
            quote.offerSize(0.0);
        }
    }

    @Override
    public void onMessageComplete() {
        LOGGER.debug("Sending: Quote={}", quote);
        fixPricingMessageSender.accept(quote);
    }

    private String symbol7(final String symbol) {
        return symbol7Map.computeIfAbsent(symbol, SymbolNormaliser::toSymbol7);
    }
}
