package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.generators.MessageGenerator;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.MessageNotifier;

public class FixTradingApplication extends FixSessionApplication implements MessageNotifier {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixTradingApplication.class);
    private final ChronicleMessageHandler<ExecutionReport> executionReportHandler;

    public FixTradingApplication(final ChronicleMessageHandler<ExecutionReport> executionReportHandler, final ApplicationLogonHandler applicationLogonHandler) {
        super(applicationLogonHandler);
        this.executionReportHandler = Objects.requireNonNull(executionReportHandler);
    }

    @Override
    public MessageGenerator onExecutionReport(final ExecutionReport executionReport) {
        executionReportHandler.accept(executionReport);
        return null;
    }

    @Override
    public void onReject(final FixSessionHandler session, final Reject reject) {
        LOGGER.info("Received {}", reject);
    }
}