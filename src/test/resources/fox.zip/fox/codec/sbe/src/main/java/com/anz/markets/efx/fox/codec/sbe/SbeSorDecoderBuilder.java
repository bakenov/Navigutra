package com.anz.markets.efx.fox.codec.sbe;

import org.agrona.collections.Int2ObjectHashMap;

import java.util.Objects;
import java.util.function.IntFunction;
import java.util.function.Supplier;


import com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder;

import com.anz.markets.efx.fox.codec.sbe.raw.InitialisationDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class SbeSorDecoderBuilder {
    private static final MessageDecoder<SbeMessage> NO_OP = message -> false;

    private final Int2ObjectHashMap<MessageDecoder<SbeMessage>> templateIdToMessageDecoder = new Int2ObjectHashMap<>();
    private final IntFunction<MessageDecoder<SbeMessage>> templateIdToMessageDecoderLookup = templateId -> {
        final MessageDecoder<SbeMessage> messageDecoder = templateIdToMessageDecoder.get(templateId);
        return messageDecoder != null ? messageDecoder : NO_OP;
    };

    private final Supplier<MessageHeaderDecoder> messageHeaderDecoderSupplier;

    public SbeSorDecoderBuilder(final Supplier<MessageHeaderDecoder> messageHeaderDecoderSupplier) {
        this.messageHeaderDecoderSupplier = messageHeaderDecoderSupplier;
    }

    public static SbeSorDecoderBuilder create() {
        return new SbeSorDecoderBuilder(MessageHeaderDecoder::new);
    }

    public static SbeSorDecoderBuilder create(final Supplier<MessageHeaderDecoder> messageHeaderDecoderSupplier) {
        return new SbeSorDecoderBuilder(messageHeaderDecoderSupplier);
    }

    public SbeSorDecoderBuilder pricingRefreshComplete(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(PricingRefreshCompleteDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder timerExpiry(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(TimerExpiryDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder firewallConfig(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(FirewallConfigDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder venueConfig(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(VenueConfigDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder userConfig(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(UserConfigDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder initialisation(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(InitialisationDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder instrumentConfig(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(InstrumentConfigDecoder.TEMPLATE_ID, messageDecoder);
    }

    public SbeSorDecoderBuilder venueInstrumentConfig(final MessageDecoder<SbeMessage> messageDecoder) {
        return add(VenueInstrumentConfigDecoder.TEMPLATE_ID, messageDecoder);
    }

    private SbeSorDecoderBuilder add(final int templateId, MessageDecoder<SbeMessage> messageDecoder) {
        Objects.requireNonNull(messageDecoder);
        final MessageDecoder<SbeMessage> existing = templateIdToMessageDecoder.get(templateId);
        if (existing != null) {
            templateIdToMessageDecoder.put(templateId, existing.orThen(messageDecoder));
        } else {
            templateIdToMessageDecoder.put(templateId, messageDecoder);
        }
        return this;
    }

    public MessageDecoder<SbeMessage> build() {
        final MessageHeaderDecoder headerDecoder = messageHeaderDecoderSupplier.get();

        return message -> {
            headerDecoder.wrap(message.buffer(), 0);
            try {
                return templateIdToMessageDecoderLookup.apply(headerDecoder.templateId()).decode(message);
            } finally {
                headerDecoder.wrap(null, 0);
            }
        };
    }
}
