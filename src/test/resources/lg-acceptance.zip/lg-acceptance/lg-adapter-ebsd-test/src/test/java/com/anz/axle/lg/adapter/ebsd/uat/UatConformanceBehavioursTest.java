package com.anz.axle.lg.adapter.ebsd.uat;


import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import quickfix.field.ClOrdID;
import quickfix.field.MassCancelRequestType;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix44.OrderMassCancelRequest;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.ebsd.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.ebsd.acceptance.AcceptanceContext;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.instrumentId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.marketId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.senderCompId;
@Ignore("long running conformance test to be ignored.")
//@Category(UatTest.class)
@RunWith(Spockito.class)
public class UatConformanceBehavioursTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatConformanceBehavioursTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("EURGBP", SecurityType.FXSPOT, Tenor.SP);

    public static final String GB_LG_EBSD = "GB:lg-ebsd";
    public static final String GB_LG_ACC = "GB:lg-acc";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private OrderRepository orderRepository = new OrderRepository();

    @Before
    public void setup() throws Exception {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-ebsd" +
                                ",ebsd.fix.log.destination:STDOUT" +
                                ",ebsd.fix.file.log.path:logs/fixlog" +
                                ",ebsd.fix.trading.reset.on.logon:Y" +
                                ",ebsd.fix.trading.reset.on.logout:N" +
                                ",ebsd.fix.trading.reset.on.disconnect:N" +
                                ",ebsd.fix.pricing.sendercompid:IVA1.QUOTE.3" +
                                ",ebsd.fix.pricing.targetcompid:EBS.TEST.QUOTE" +
                                ",ebsd.fix.pricing.host:10.54.189.41" +
//                                ",ebsd.fix.pricing.host:localhost" +
                                ",ebsd.fix.pricing.port:9809" +
                                ",ebsd.fix.trading.sendercompid:IVA1.ORDER.3" +
                                ",ebsd.fix.trading.targetcompid:EBS.TEST.ORDER" +
                                ",ebsd.fix.trading.host:10.54.189.41" +
//                                ",ebsd.fix.trading.host:localhost" +
                                ",ebsd.fix.trading.port:9809" +
                                ",ebsd.fix.trading.account:IVA1" +
                                ",ebsd.fix.username:anz" +
                                ",ebsd.fix.password:anz123"
                ));

        application = new Application("lg-ebsd-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();

        orderRepository = new OrderRepository();
        TimeUnit.SECONDS.sleep(20);
    }

    private static final String SYMBOL = "EURGBP";
    private static final String CURRENCY = "EUR";
    private static final Side SIDE = Side.BUY;
    private static final EntryType ENTRYTYPE_SIDE = (SIDE == Side.SELL)  ? EntryType.BID : EntryType.OFFER;
    private static final double PRICE_OFFSET = 0.0005;

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void logonAndWait() throws Exception {
        while (true) {
            captureExecutionReports(1, 1);
        }
    }

    @Test
    public void partiallyFilled_and_wait() throws Exception {

        final NewOrderSingle newOrderSingle = partiallyFilledNewOrderSingle();

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        while (true) {
            captureExecutionReports(1, 1);
        }
    }

    @Test
    public void testDisconnectLogout() throws Exception {
        TimeUnit.SECONDS.toSeconds(10);
        final PriceEntry priceEntry = onDisconnect(5);
        if (priceEntry != null) {
            orderMassCancelRequest(MassCancelRequestType.CANCEL_ORDERS_FOR_A_SECURITY, priceEntry.instrumentKey.symbol());
        }
    }

    @Test
    public void cancel_all_orders() throws Exception {
        TimeUnit.SECONDS.toSeconds(10);
        orderMassCancelRequest(MassCancelRequestType.CANCEL_ALL_ORDERS, null);
        TimeUnit.SECONDS.toSeconds(10);
    }

    @Test
    public void send_resting_order_remote_logout_cancel_all() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitAnyPrice();
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, side);
        priceEntry.size = priceEntry.size * 50;

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, side, clOrdId, priceEntry);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        TimeUnit.SECONDS.toSeconds(5);
        captureExecutionReports(3, 30);
        TimeUnit.SECONDS.toSeconds(2);

        final PriceEntry onDisconnect = onDisconnect(5);
        if (onDisconnect != null) {
            captureExecutionReports(10, 5);
            orderMassCancelRequest(MassCancelRequestType.CANCEL_ALL_ORDERS, onDisconnect.instrumentKey.symbol());
        }

        TimeUnit.MINUTES.toSeconds(30);
    }

    @Test
    public void send_PartiallyFilled() throws Exception {

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitAnyPrice();
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, side);
        priceEntry.size = priceEntry.size * 10;

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, side, clOrdId, priceEntry);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        TimeUnit.SECONDS.toSeconds(5);
        captureExecutionReports(3, 30);

        TimeUnit.MINUTES.sleep(10);
    }

    private NewOrderSingle partiallyFilledNewOrderSingle() {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitAnyPrice();
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, side);
        priceEntry.size = priceEntry.size * 10;

        return newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, side, clOrdId, priceEntry);
    }

    private NewOrderSingle newOrderSingle(final OrderType orderType, final TimeInForce timeInForce, final double price, final Side side, final String clOrdId, final PriceEntry entry) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = timeInForce;
        if (timeInForce == TimeInForce.GTD) {
            newOrderSingle.body.expireTime = acceptanceContext.precisionClock().nanos() + 3600000000000L;
        }
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.orderQty = entry.size;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.currency = entry.currency();
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.price = price;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.settlCurrency = entry.currency();
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = entry.instrumentKey.symbol();
        return newOrderSingle;
    }

    private PriceEntry awaitAnyPrice() {
        final IncrementalRefreshMatcher matcher = IncrementalRefreshMatcher.build()
                .body().matches(senderCompId().eq(GB_LG_EBSD))
                 .body().matches(marketId().eq(Venue.EBSD))
                 .body().matches(instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .hops().countAtLeast(2);

        return new PriceListener(acceptanceContext.pricingMessageQueue()).awaitPrice(matcher);
    }

    private Side side(final EntryType mdEntryType) {
        switch (mdEntryType) {
            case BID:
                return Side.SELL;
            case OFFER:
                return Side.BUY;
            default:
                return null;
        }
    }

    private void captureExecutionReports(final int expectedNumOfExecutionReports, final int secondsToWait) throws InterruptedException {

        System.out.println("==============================================================");
        System.out.println("Start Execution Report capture: " + expectedNumOfExecutionReports + "," + secondsToWait);
        System.out.println("==============================================================");
        int receivedCount = 0;
        int loopCount = 0;

        while(true) {
            TradingMessage tradingResponseMessage = acceptanceContext.tradingResponseMessageQueue().poll();
            if (tradingResponseMessage != null) {
                receivedCount++;
                orderRepository.update((ExecutionReport)tradingResponseMessage);
            }
            if (receivedCount >= expectedNumOfExecutionReports || loopCount >= secondsToWait) break;
            loopCount++;
            TimeUnit.SECONDS.sleep(1);
        }

        System.out.println("==============================================================");
        System.out.println("Execution Reports received: " + receivedCount);
        System.out.println("==============================================================");
    }

    private double inMarketPrice(final double price, final Side side) {
        return price + ((side == Side.BUY) ? + PRICE_OFFSET : -PRICE_OFFSET);
    }

    private double offMarketPrice(final double price, final Side side) {
        return price + ((side == Side.BUY) ? - 10*PRICE_OFFSET : + 10*PRICE_OFFSET);
    }

    private PriceEntry onDisconnect(final int millisSecondsToWait) {
        System.out.println("==============================================================");
        System.out.println("Waiting for onDisconnect");
        System.out.println("==============================================================");
        while(true) {
            PricingMessage pricingMessage = acceptanceContext.pricingMessageQueue().poll();
            if (pricingMessage != null) {
                final PriceEntry priceEntry = new PriceEntry();
                pricingMessage.accept(new PricingMessageVisitor.Exception() {
                        @Override
                        public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                            priceEntry.msgType = "W";
                            priceEntry.flags.addAll(snapshotFullRefresh.body.mdFlags);
                            priceEntry.instrumentKey = InstrumentKey.of(snapshotFullRefresh.body.instrumentId);
                        }

                        @Override
                        public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                            priceEntry.msgType = "X";
                            priceEntry.flags.addAll(incrementalRefresh.body.mdFlags);
                            priceEntry.instrumentKey = InstrumentKey.of(incrementalRefresh.body.instrumentId);
                        }
                });
                if (!priceEntry.flags.isEmpty()) {
                    System.out.println("==============================================================");
                    System.out.println("onDisconnect..." + priceEntry);
                    System.out.println("==============================================================");
                    return priceEntry;
                }
            }
            TimeUnit.MILLISECONDS.toSeconds(millisSecondsToWait);
        }
    }

    private void orderMassCancelRequest(final char massCancelRequestType, final String symbol) throws InterruptedException {

        // cancel all orders by symbol 'q' - receive 'r' - OrderMassCancelReport
        final OrderMassCancelRequest orderMassCancelRequest = new OrderMassCancelRequest();
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-MC";

        orderMassCancelRequest.setChar(MassCancelRequestType.FIELD, massCancelRequestType);
        orderMassCancelRequest.setString(ClOrdID.FIELD, clOrdId);
        if (symbol != null) {
            orderMassCancelRequest.setString(Symbol.FIELD, symbol);
        }
        final Date transactTime = new Date();
        transactTime.setTime(System.currentTimeMillis());
        orderMassCancelRequest.setUtcTimeStamp(TransactTime.FIELD, transactTime, true);
        captureExecutionReports(30, 2);

        System.out.println("==============================================================");
        System.out.println("Dumping OrderRepository.");
        orderRepository.dumpAllOrderRequest();
        orderRepository.dumpExecutionsReceived();
        orderRepository.dumpAllExecutions();
        orderRepository.dumpOrderStatus();
        System.out.println("==============================================================");

        System.out.println("Sending OrderMassCancelRequest type(530)=" + String.valueOf(massCancelRequestType) + " symbol(55)=" + symbol);
        acceptanceContext.fixMessageSender().accept(orderMassCancelRequest);
        System.out.println("==============================================================");
        System.out.println("Sent OrderMassCancelRequest: " + orderMassCancelRequest);
        System.out.println("==============================================================");
        TimeUnit.SECONDS.toSeconds(10);
    }

    private static class OrderRepository {
        private final Map<String, ExecutionReport> executionReports = new HashMap<>();
        private final Map<String, NewOrderSingle> newOrderSingles = new HashMap<>();
        private final List<String> executionReportReceived = new LinkedList<>();

        public void newOrder(final NewOrderSingle newOrderSingle) {
            if (newOrderSingle != null) {
                newOrderSingles.put(newOrderSingle.body.clOrdId, newOrderSingle);
            }
        }

        public void update(final ExecutionReport executionReport) {
            if (executionReport != null) {
                executionReports.put(executionReport.body.orderId, executionReport);
                final String receivedER = format(executionReport);
                executionReportReceived.add(receivedER);
                System.out.println("Added ER: " + receivedER + " to Repo.");
            }
        }
        public void dumpExecutionsReceived() {
            System.out.println("---" +executionReportReceived.size()+" ER Received---------------------------------------------");
            executionReportReceived.forEach(e -> System.out.println(e));
        }

        public void dumpAllOrderRequest() {
            newOrderSingles.values().forEach(o -> System.out.println(o));
        }

        public void dumpAllExecutions() {
            System.out.println("---" +executionReports.size()+" Executions---------------------------------------------");
            executionReports.values().forEach(e -> System.out.println(e));
        }

        public void dumpOrderStatus() {
            System.out.println("---Order Status-----------------------------------------------");
            executionReports.values().forEach(e -> {
                System.out.println((e.body.leavesQty != 0 ? "Open" : "Filled") + format(e));
            });
        }

        private String format(final ExecutionReport e) {
            return String.format(" Order: orderId=%s|ordStatus=%s|execType=%s|orderQty=%2f|orderType=%s|price=%2f|currency=%s|leavesQty=%2f|cumQty=%2f|avgPx=%2f|lastPx=%2f|lastQty=%2f",
                    e.body.orderId,e.body.ordStatus,e.body.execType,e.body.orderQty,e.body.ordType,e.body.price,e.body.currency,
                    e.body.leavesQty,e.body.cumQty,e.body.avgPx,e.body.lastPx,e.body.lastQty);
        }
    }
}