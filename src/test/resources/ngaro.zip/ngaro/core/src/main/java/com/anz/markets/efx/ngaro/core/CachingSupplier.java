package com.anz.markets.efx.ngaro.core;

import java.util.Objects;
import java.util.function.Supplier;

/**
 * A supplier which caches the result from a delegate supplier and returns it in subsequent {@link #get()} calls until
 * {@link #reset()} is called.
 */
public final class CachingSupplier<T> implements Supplier<T> {

    private final Supplier<? extends T> delegate;
    private T cached;

    public CachingSupplier(final Supplier<? extends T> delegate) {
        this.delegate = Objects.requireNonNull(delegate);
    }

    public static <T> CachingSupplier<T> of(final Supplier<? extends T> delegate) {
        return new CachingSupplier<T>(delegate);
    }

    @Override
    public T get() {
        if (cached == null) {
            cached = delegate.get();
        }
        return cached;
    }

    public CachingSupplier<T> reset() {
        cached = null;
        return this;
    }

}
