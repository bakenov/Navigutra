package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import com.apama.event.Event;

import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.SecurityType;

public class EventToTranslatedSymbol implements Function<Event, String> {
    private final Map<String, String> spotSymbolMap;
    private final Map<String, String> ndfSymbolMap;
    private final Function<Event, String> eventToSymbol;
    private final Function<Event, SecurityType> eventToSecurityType;

    public EventToTranslatedSymbol(final Map<String, String> spotSymbolMap,
                                   final Map<String, String> ndfSymbolMap,
                                   final Function<Event, String> eventToSymbol,
                                   final Function<Event, SecurityType> eventToSecurityType) {
        this.spotSymbolMap = spotSymbolMap;
        this.ndfSymbolMap = ndfSymbolMap;
        this.eventToSymbol = eventToSymbol;
        this.eventToSecurityType = eventToSecurityType;
    }

    public static EventToTranslatedSymbol forEntryEvent(final Map<String, String> spotSymbolMap,
                                                        final Map<String, String> ndfSymbolMap) {
        return new EventToTranslatedSymbol(spotSymbolMap, ndfSymbolMap, EventFunctions.EVENT_TO_SYMBOL, EventFunctions.ENTRY_TO_SECURITY_TYPE);
    }

    public static EventToTranslatedSymbol forMessageEvent(final Map<String, String> spotSymbolMap,
                                                        final Map<String, String> ndfSymbolMap) {
        return new EventToTranslatedSymbol(spotSymbolMap, ndfSymbolMap, EventFunctions.EVENT_TO_SYMBOL, EventFunctions.MESSAGE_TO_SECURITY_TYPE);
    }

    @Override
    public String apply(final Event event) {
        final String symbol = eventToSymbol.apply(event);
        Objects.requireNonNull(symbol, "Could not find symbol in the event");

        final SecurityType securityType = eventToSecurityType.apply(event);
        final Map<String, String> symbolMap = securityType == SecurityType.FXSPOT ? spotSymbolMap : ndfSymbolMap;
        final String translatedSymbol = symbolMap.get(symbol);
        return translatedSymbol != null ? translatedSymbol : SymbolNormaliser.toSymbol6(symbol);
    }
}
