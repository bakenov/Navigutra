package com.anz.markets.prophet.config.app.importable;

import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.util.SystemProperties;
import com.sun.jdmk.comm.HtmlAdaptorServer;
import com.sun.jdmk.comm.HtmlParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;
import org.springframework.jmx.support.ConnectorServerFactoryBean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.DynamicMBean;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.registry.LocateRegistry;

@Configuration
public class JmxConfig {
    private static final Logger LOG = LoggerFactory.getLogger(JmxConfig.class);
    private static final int JMX_PORT_OFFSET = 1000;

    @Autowired
    private Environment env;

    @Autowired
    private JmxSettings jmxSettings;


    /**
     * Stay below ephemeral port range to avoid clashing.
     * cat /proc/sys/net/ipv4/ip_local_port_range
     * 32768   60999
     * <p>
     * Also this is base port which extra digit will be appended to the left so it needs to be well below 100,000.
     */
    @Value("${http.jmx.port.env:8880}")
    protected int envPort;

    @Value("${http.configdoc.offset.port:1}")
    protected int configDocOffsetPort;

    @Value("${jmx.url.core:service:jmx:jmxmp://127.0.0.1:2}")
    private String serviceUrlPrefix;

    @Autowired
    private ApplicationContext applicationContext;

    private HtmlAdaptorServer server;

    public int getPort() {
        return envPort + jmxSettings.portOffset;
    }

    @PostConstruct
    public void startHtmlJmxAdaptorServer() throws Exception {
        final MBeanServer platformServer = ManagementFactory.getPlatformMBeanServer();

        final ObjectName serverName = new ObjectName("connector:name=HtmlAdaptorServer,port=" + getPort());
        final ObjectName parserName = new ObjectName("connector:name=HtmlAdaptorServer,type=htmlParser");
        if (Main.isRunningInTestAcceptanceMode(env)) {
            LOG.info("Not starting {}, running in acceptance test mode", serverName);
        } else {
            // TODO: work out how to make this server use UTF8 as encoding rather than ISO-8859-1
            // <meta charset="UTF-8">
            // System.setProperty("openjdmk.charset", System.getProperty("file.encoding"));
            server = new HtmlAdaptorServer();
            server.setPort(getPort());

            platformServer.registerMBean(server, serverName);
            platformServer.registerMBean(new JmxHtmlParser(
                    env.getProperty("kdb.dashboard.url", "#undefined-kdb.dashboard.url"),
                    env.getProperty("kdb.url", "#undefined-kdb.url")), parserName);
            server.setParser(parserName);
            server.start();
            LOG.info("Started http jmx server - http://localhost:{}. JMXMP will start on {}.", server.getPort(), getServiceUrl());

            if (SystemProperties.ENABLE_JMX_CONNECTOR) {
                final int jmxPort = getPort() + JMX_PORT_OFFSET;
                LocateRegistry.createRegistry(jmxPort);
                JMXServiceURL url = new JMXServiceURL(String.format("service:jmx:rmi:///jndi/rmi://%s:%s/jmxrmi", InetAddress.getLocalHost().getHostAddress(), jmxPort));
                JMXConnectorServer jmxServer = JMXConnectorServerFactory.newJMXConnectorServer(url, null, platformServer);
                jmxServer.start();
                LOG.info("Started jmx service - {}.", url.toString());
            }
        }
    }

    @PreDestroy
    public void destroy() {
        if (server != null) {
            server.stop();
        }
    }

    @Bean
    @Profile("!ACCEPTANCE_TEST") // this clashes when multiple config in same jvms.
    public ConnectorServerFactoryBean connecterServerFactoryBean() throws MalformedObjectNameException {
        ConnectorServerFactoryBean factory = new ConnectorServerFactoryBean();
        factory.setObjectName("connector:name=jmxmp");
        factory.setServiceUrl(getServiceUrl());
        return factory;
    }

    @Bean
    public AnnotationMBeanExporter annotationMBeanExporter() {
        AnnotationMBeanExporter exporter = new AnnotationMBeanExporter();
        exporter.setEnsureUniqueRuntimeObjectNames(true);
        exporter.setAutodetect(true);
        return exporter;
    }

    private String getServiceUrl() {
        return serviceUrlPrefix + getPort();
    }

    public class JmxHtmlParser implements DynamicMBean, HtmlParser {

        private final String kdbUrl;
        private final String kdbDashboardUrl;

        public JmxHtmlParser(final String kdbDashboardUrl,
                             final String kdbUrl) {
            this.kdbUrl = kdbUrl;
            this.kdbDashboardUrl = kdbDashboardUrl;
        }

        @Override
        public String parseRequest(final String s) {
            return null;
        }

        @Override
        public String parsePage(final String s) {
            // TODO: colour
            // TODO: gc
            final StringBuilder replacement = new StringBuilder("Prophet Management Console - <b>")
                    .append(applicationContext.getDisplayName())
                    .append("</b><br>")
                    // TODO: get port numbers from config
                    .append(String.format("<a href='%s'>Simulator</a> | ", getHostUrl(envPort)))
                    .append(String.format("<a href='%s'>StarIn</a> | ", getHostUrl(envPort + 8)))
                    .append(String.format("<a href='%s'>Core</a> | ", getHostUrl(envPort + 6)))
                    .append(String.format("<a href='%s'>CoreMarketPrice</a> | ", getHostUrl(envPort + 20)))
                    .append(String.format("<a href='%s'>CoreClientPrice</a> | ", getHostUrl(envPort + 24)))
                    .append(String.format("<a href='%s'>CorePrice</a> | ", getHostUrl(envPort + 2)))
                    .append(String.format("<a href='%s'>CoreHedge</a> | ", getHostUrl(envPort + 3)))
                    .append(String.format("<a href='%s'>StarOut</a> | ", getHostUrl(envPort + 7)))
                    .append(String.format("<a href='%s'>Metrics</a> | ", getHostUrl(envPort + 5)))
                    .append(String.format("<a href='%s' target='_blank'>KDB Dashboard</a> | ", kdbDashboardUrl))
                    .append(String.format("<a href='%s' target='_blank'>KDB</a> | ", kdbUrl))
                    .append(String.format("<a href='%s' target='config_companion'>Config Documentation</a> <br> ", getHostUrl(envPort + configDocOffsetPort)));

            String target = "[JDMK5.1_r01]";
            if (s == null) {
                return s;
            } else if (s.contains(target)) {
                return s.replace(target, replacement);
            } else {
                LOG.warn("jdmk tool library must have changed. Please check update the code so that the project name on jmx html is parsed properly.");
                return s;
            }
        }

        @Override
        public Object getAttribute(
                final String attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
            return null;
        }

        @Override
        public void setAttribute(
                final Attribute attribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {

        }

        @Override
        public AttributeList getAttributes(final String[] attributes) {
            return null;
        }

        @Override
        public AttributeList setAttributes(final AttributeList attributes) {
            return null;
        }

        @Override
        public Object invoke(final String actionName,
                             final Object[] params,
                             final String[] signature) throws MBeanException, ReflectionException {
            if (actionName.equals("parseRequest")) {
                return this.parseRequest((String) params[0]);
            } else if (actionName.equals("parsePage")) {
                return this.parsePage((String) params[0]);
            }
            throw new UnsupportedOperationException("This action is not implemented: " + actionName);
        }

        @Override
        public MBeanInfo getMBeanInfo() {
            // i cant be bothered!
            return new MBeanInfo(this.getClass().getName(), "html parser", null, null, null, null);
        }

        private String getHostUrl(int port) {
            return String.format("http://%s:%d", getHostName(), port);
        }

        private String getHostName() {
            try {
                return InetAddress.getLocalHost().getHostName();
            } catch (UnknownHostException e) {
                return "localhost";
            }
        }
    }
}
