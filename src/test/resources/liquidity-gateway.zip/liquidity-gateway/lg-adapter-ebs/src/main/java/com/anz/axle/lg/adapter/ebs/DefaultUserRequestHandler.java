package com.anz.axle.lg.adapter.ebs;

import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.fix.staticcode.SessionID;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.chroniclefix.UserRequestEncoder;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserRequest;
import com.anz.axle.lg.adapter.fix.UserRequestData;
import com.anz.axle.lg.util.IntIdFactory;

public class DefaultUserRequestHandler implements UserRequestHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultUserRequestHandler.class);
    private final SessionID sessionID;
    private final Map<UserRequestData.UserRequestDataType, Supplier<UserRequestData>> userRequestDataLookUp;
    private final FixMessageSender fixMessageSender;
    private final UserRequestEncoder<UserRequest> userRequestEncoder;
    private final IntIdFactory requestIdFactory;

    public DefaultUserRequestHandler(final SessionID sessionID,
                                     final Map<UserRequestData.UserRequestDataType, Supplier<UserRequestData>> userRequestDataLookUp,
                                     final FixMessageSender fixMessageSender,
                                     final UserRequestEncoder<UserRequest> userRequestEncoder,
                                     final IntIdFactory requestIdFactory) {
        this.sessionID = Objects.requireNonNull(sessionID);
        this.userRequestDataLookUp = Objects.requireNonNull(userRequestDataLookUp);
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.userRequestEncoder = Objects.requireNonNull(userRequestEncoder);
        this.requestIdFactory = Objects.requireNonNull(requestIdFactory);
    }

    @Override
    public UserRequestData send(final UserRequestData.UserRequestDataType requestDataType, final String userRequestID) {
        final UserRequestData requestData = userRequestDataLookUp.get(requestDataType).get();
        final String requestId = userRequestID == null ? String.valueOf(requestIdFactory.get()) : userRequestID;
        final UserRequest userRequest = userRequestEncoder.encode(sessionID, requestId, requestData);
        LOGGER.info("{} Sending {} as {}", sessionID, requestData, userRequest);
        fixMessageSender.accept(userRequest);
        return requestData;
    }
}
