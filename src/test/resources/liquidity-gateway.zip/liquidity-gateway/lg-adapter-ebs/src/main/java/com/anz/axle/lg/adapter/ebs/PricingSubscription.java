package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;

public interface PricingSubscription {
    void subscribe(UserResponse userResponse);
}
