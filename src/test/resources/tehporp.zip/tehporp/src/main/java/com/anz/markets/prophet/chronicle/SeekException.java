package com.anz.markets.prophet.chronicle;

/**
 * Can't seek to the specified location in the chronicle
 **/
public class SeekException extends RuntimeException {
    public SeekException(final String msg, final long startPosition) {
        super(msg + ": " + startPosition);
    }
}
