#!/bin/bash

echo "Killing everything on correlator boxes"
ssh AxlSv@daxa025z "ps -ef | grep 'corr' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh AxlSv@daxa025z "ps -ef | grep 'iaf' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh AxlSv@daxa025z "ps -ef | grep 'java' | grep -v 'grep' | awk '{ print \$2 }' | xargs -l kill -9"
ssh AxlSv@daxa025z "rm -rf ~/axle/datafabric/logs/*.pid"

echo "Killing everything on proxy boxes"
ssh AxlSv@daxa025z "ps -ef | grep 'java' | grep -v 'grep' | grep -v 'delta' | awk '{ print \$2 }' | xargs -l kill -9; rm -f ~/apache-tomcat/conf/pid"
