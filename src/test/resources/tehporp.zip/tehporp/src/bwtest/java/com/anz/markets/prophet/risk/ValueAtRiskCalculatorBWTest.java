package com.anz.markets.prophet.risk;

import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.prophet.positionrisk.Position;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.util.Arrays;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ValueAtRiskCalculatorBWTest {
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();

    // reuse static data setup for all tests
    private static ValueAtRiskCalculatorTest valueAtRiskCalculatorTest;
    private static Position audPosition = new Position(Currency.AUD, Portfolio.CLIENTS_NET);
    private static Position cadPosition = new Position(Currency.CAD, Portfolio.CLIENTS_NET);
    private static Position chfPosition = new Position(Currency.CHF, Portfolio.CLIENTS_NET);
    private static Position cnhPosition = new Position(Currency.CNH, Portfolio.CLIENTS_NET);
    private static List<Position> positionList = Arrays.asList(audPosition, cadPosition, chfPosition);
    private static EnumDoubleMap<Currency> variance;

    private static final int REPS = 1_000_000;

    @BeforeClass
    public static void beforeClass() {
        audPosition.setPositionInSystemBase(1);
        cadPosition.setPositionInSystemBase(2);
        cadPosition.setPositionInSystemBase(2);
        chfPosition.setPositionInSystemBase(3);
        cnhPosition.setPositionInSystemBase(4);
        valueAtRiskCalculatorTest = new ValueAtRiskCalculatorTest();
        variance = valueAtRiskCalculatorTest.calculateVariance(positionList);
    }

    @Test
    public void testAAA_Warmup() {
        calculateVar(variance);
    }

    @Test
    public void testCalculateVaRForThreePositions() {
        helper.testAllocationNotExceeded(
                () -> calculateVar(variance),
                0 // no allocation!
        );
    }

    public void calculateVar(final EnumDoubleMap<Currency> varianceByCurrency) {
        for (int i = 0; i < REPS; i++) {
            valueAtRiskCalculatorTest.calculateAndAssert(varianceByCurrency);
        }
    }
}