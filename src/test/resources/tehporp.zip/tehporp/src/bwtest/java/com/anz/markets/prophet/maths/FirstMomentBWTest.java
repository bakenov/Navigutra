package com.anz.markets.prophet.maths;


import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.io.IOException;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FirstMomentBWTest {

    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private static final int THRESHOLD = 200;

    private static double[] midPrices = new double[]{2, 4, 4, 4, 5, 5, 7, 9};

    final FirstMoment firstMoment;

    public FirstMomentBWTest() throws IOException {
        firstMoment = new FirstMoment();
    }

    public void scenario_firstMomentCalculate() {
        for (int i = 0; i < REPS; i++) {
            for (int j = 0; j < midPrices.length; j++) {
                firstMoment.addValue(midPrices[j]);
            }
            firstMoment.calculate();
            firstMoment.clear();
        }
    }

    @Test
    public void aaa_AllocationNotExceeded_WarmUp() {
        scenario_firstMomentCalculate();
    }

    @Test
    public void test_AllocationNotExceeded_Test() {
        helper.testAllocationNotExceeded(
                this::scenario_firstMomentCalculate,
                THRESHOLD // no allocation!
        );
    }
}
