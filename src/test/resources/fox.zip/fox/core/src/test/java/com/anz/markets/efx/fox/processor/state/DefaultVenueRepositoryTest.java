package com.anz.markets.efx.fox.processor.state;

import java.util.EnumSet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.sbe.SorCodecUtil;
import com.anz.markets.efx.fox.processor.state.venue.DefaultVenueRepository;
import com.anz.markets.efx.fox.processor.timer.Timer;
import com.anz.markets.efx.fox.receiver.VenueSubscriber;
import com.anz.markets.efx.ngaro.api.Venue;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DefaultVenueRepositoryTest {
    @Mock
    private VenueSubscriber.Async venueSubscriber;
    @Mock
    private Timer timer;
    @Mock
    private Timer.Factory timerFactory;
    private int missedHeartbeatTimeoutMillis = 1000;

    private SorCodecUtil.Codec sorCodec;

    private DefaultVenueRepository venueRepository;

    @BeforeEach
    void setUp() {
        venueRepository = new DefaultVenueRepository(venueSubscriber, timerFactory, missedHeartbeatTimeoutMillis);
        sorCodec = SorCodecUtil.create();
    }

    @Test
    void lookup() {
    }

    @Test
    void after_init_should_lookup_should_lookup_by_venue_id_and_comp_id() {
        //given
        when(timerFactory.create(any())).thenReturn(timer);

        final String compId = "lg-fastc";
        final Venue venueId = Venue.FAST;
        final EnumSet<VenueCategory> venueCategories = EnumSet.of(VenueCategory.INTERBANK, VenueCategory.BANK);
        final boolean enabled = true;

        assertThat(venueRepository.lookup(venueId)).isNull();
        sorCodec.encoderSupplier().venueConfig().messageStart(0, 0)
                .venue(Venue.FAST)
                .compId().encode(compId)
                .venueCategories().addAll(venueCategories)
                .enabled(enabled)
                .messageComplete();

        //when
        final com.anz.markets.efx.fox.api.domain.Venue venue = venueRepository.apply(sorCodec.venueConfigDecoder());

        //then
        assertThat(venue.venueId()).isEqualTo(venueId);
        assertThat(venue.compId()).isEqualTo(compId);
        assertThat(venue.venueCategories()).isEqualTo(venueCategories);
        assertThat(venue.enabled()).isEqualTo(enabled);

        //when
        final com.anz.markets.efx.fox.api.domain.Venue venueById =  venueRepository.lookup(Venue.FAST);

        //then
        assertThat(venueById).isEqualTo(venue);

        //when
        final com.anz.markets.efx.fox.api.domain.Venue venueByCompId =  venueRepository.lookup(compId);

        //then
        assertThat(venueByCompId).isEqualTo(venue);

    }
}
