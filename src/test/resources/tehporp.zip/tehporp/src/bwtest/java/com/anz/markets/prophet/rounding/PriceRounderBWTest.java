package com.anz.markets.prophet.rounding;

import com.anz.markets.efx.ngaro.math.DoubleTools;
import com.anz.markets.prophet.domain.OrderSide;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import static org.junit.Assert.assertEquals;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PriceRounderBWTest {
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();

    private static final int REPS = 1_000_000;
    private static final double DELTA = 0.0000000001, FROM = 0.123123123;

    @Test
    public void testAAA_Warmup() {
        roundDown();
        roundUp();
    }

    @Test
    public void testRoundDown() {
        helper.testAllocationNotExceeded(
                this::roundDown,
                0 // no allocation!
        );
    }

    @Test
    public void testRoundUp() {
        helper.testAllocationNotExceeded(
                this::roundUp,
                0 // no allocation!
        );
    }

    public void roundDown() {
        for (int i = 0; i < REPS; i++) {
            assertEquals(0.123123, OrderSide.BID.roundPrice(6, FROM), DELTA);
        }
    }

    public void roundUp() {
        for (int i = 0; i < REPS; i++) {
            assertEquals(0.123124, OrderSide.OFFER.roundPrice(6, FROM), DELTA);
        }
    }
}

