package com.anz.axle.lg.adapter.deut.acceptance;

import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.MDEntryType;
import org.fix4j.spec.fix50sp2.fieldtype.MDUpdateAction;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.PricingFixSessionHelper;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;

public class StubbedPricingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StubbedPricingIntegrationTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);

    private static final String senderCompId = "GB:lg-deut";
    private static final Venue marketId = Venue.DEUT;
    private static final String QUOTE_ENTRY_ID = "12345678";
    private static final String QUANTITY_STRING = "1000000.00";
    private static final String PRICE_STRING = "0.7567";
    private static final String SYMBOL = "AUD/USD";
    private static final String NORMALISED_SYMBOL = "AUDUSD";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private MatchingSession pricingServer;
    private SharedAcceptanceContext acceptanceContext;
    private PricingFixSessionHelper pricingFixSessionHelper;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        setPersistStorePath("deut", testName.getMethodName());

        pricingFixSessionHelper = new PricingFixSessionHelper("deut", "GB_DEUT_MD_S", "GB_DEUT_MD_T", "FIX.4.4");

        application = new Application("lg-deut-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        if (pricingServer != null) pricingServer.shutdown();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private Predicate<Object> defaultSnapshotRefreshMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().countEquals(1)
                .hops().hasAny()
                .hops().countAtLeast(2);
    }

    private Predicate<Object> defaultIncrementalRefreshMessageMatcher() {
        return IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(marketId))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().countEquals(1)
                .hops().hasAny()
                .hops().countAtLeast(2);
    }

    private Predicate<Object> emptySnapshotMessageMatcher() {
        return SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                .entries().hasNone();
    }

    private final FixMessage defaultSnapshotRefreshFixMessage(final String requestId) {
        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATASNAPSHOTFULLREFRESH.getOrdinal())
                .withField(FieldTypes.MDReqID, requestId)
                .withField(FieldTypes.Symbol, SYMBOL)
                .withField(FieldTypes.NoMDEntries, 1)
                .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
                .withField(FieldTypes.MDEntryPx, PRICE_STRING)
                .withField(FieldTypes.MDEntrySize, QUANTITY_STRING)
                .withField(FieldTypes.QuoteEntryID, QUOTE_ENTRY_ID)
                .build();
    }

    private final FixMessage defaultIncrementalRefreshFixMessage(String requestId) {

        return new FixMessageBuilder()
                .withField(FieldTypes.MsgType, MsgType.Values.MARKETDATAINCREMENTALREFRESH.getOrdinal())
                .withField(FieldTypes.MDReqID, requestId)
                .withField(FieldTypes.NoMDEntries, 1)
                .withField(FieldTypes.MDUpdateAction, MDUpdateAction.Values.NEW.getOrdinal())
                .withField(FieldTypes.MDEntryType, MDEntryType.Values.BID.getOrdinal())
                .withField(FieldTypes.MDEntryID, QUOTE_ENTRY_ID)
                .withField(FieldTypes.Symbol, SYMBOL)
                .withField(FieldTypes.MDEntryPx, PRICE_STRING)
                .withField(FieldTypes.MDEntrySize, QUANTITY_STRING)
                .withField(FieldTypes.QuoteEntryID, QUOTE_ENTRY_ID)
                .build();
    }


    @Test
    public void should_receive_pricing_snapshot_for_the_registered_ccy_pair() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=" + SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataSnapshotRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataSnapshotRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultSnapshotRefreshMessageMatcher())
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                    LOGGER.info(snapshotFullRefresh.toString());
                    Assert.assertEquals(marketId, snapshotFullRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), snapshotFullRefresh.body.instrumentId);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.body.senderCompId);

                    Assert.assertNull(snapshotFullRefresh.body.tradeDate);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.size());
                    Assert.assertEquals(EntryType.BID, snapshotFullRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.get(0).mdEntryId);
                    Assert.assertEquals(1, snapshotFullRefresh.entries.get(0).quoteEntryId);
                    Assert.assertEquals(Double.parseDouble(PRICE_STRING), snapshotFullRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(Double.parseDouble(QUANTITY_STRING), snapshotFullRefresh.entries.get(0).mdEntrySize, 1e-6);
                    Assert.assertEquals(2, snapshotFullRefresh.hops.size());
                    Assert.assertEquals("GB:DEUT", snapshotFullRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, snapshotFullRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(snapshotFullRefresh.body.sendingTime, snapshotFullRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, snapshotFullRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(snapshotFullRefresh.body.messageId, snapshotFullRefresh.hops.get(1).hopMessageId);
                }
        });
    }

    @Test
    public void should_receive_pricing_incremental_refresh_for_the_registered_ccy_pair() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=" + SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataIncrementalRefresh is sent to adapter.
        LOGGER.info("Sending back price.");
        pricingServer.send(defaultIncrementalRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the  MarketDataIncrementalRefresh processed message is available in pricing queue.
        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultIncrementalRefreshMessageMatcher())
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                    LOGGER.info(incrementalRefresh.toString());
                    Assert.assertEquals(marketId, incrementalRefresh.body.marketId);
                    Assert.assertEquals(INSTRUMENT_KEY.instrumentId(), incrementalRefresh.body.instrumentId);
                    Assert.assertEquals(senderCompId, incrementalRefresh.body.senderCompId);
                    Assert.assertNull(incrementalRefresh.body.tradeDate);
                    Assert.assertEquals(1, incrementalRefresh.entries.size());
                    Assert.assertEquals(EntryType.BID, incrementalRefresh.entries.get(0).mdEntryType);
                    Assert.assertEquals(1, incrementalRefresh.entries.get(0).mdEntryId);
                    Assert.assertEquals(1, incrementalRefresh.entries.get(0).quoteEntryId);
                    Assert.assertEquals(Double.parseDouble(PRICE_STRING), incrementalRefresh.entries.get(0).mdEntryPx, 1e-6);
                    Assert.assertEquals(Double.parseDouble(QUANTITY_STRING), incrementalRefresh.entries.get(0).mdEntrySize, 1e-6);
                    Assert.assertEquals(2, incrementalRefresh.hops.size());
                    Assert.assertEquals("GB:DEUT", incrementalRefresh.hops.get(0).hopCompId);
                    Assert.assertEquals(0, incrementalRefresh.hops.get(0).hopReceivingTime);
                    Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(0).hopMessageId);
                    Assert.assertEquals(incrementalRefresh.body.sendingTime, incrementalRefresh.hops.get(0).hopSendingTime);
                    Assert.assertEquals(senderCompId, incrementalRefresh.hops.get(1).hopCompId);
                    Assert.assertEquals(incrementalRefresh.body.messageId, incrementalRefresh.hops.get(1).hopMessageId);
                }
        });
    }

    @Test
    public void market_data_request_rejected() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataRequest message received for ccy pair.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=" + SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        //When the MarketDataRequestReject is sent to adapter.
        pricingServer.send(pricingFixSessionHelper.marketDataRequestRejectFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }

    @Test
    public void should_send_empty_snapshot_when_marketdata_fix_disconnects() throws Exception {
        pricingServer = pricingFixSessionHelper.createPricingSession();

        //Given MarketDataSnapshotRefresh processed message is available in pricing queue.
        LOGGER.info("Waiting for MarketDataRequest...");
        final FixMessage marketDataRequest = pricingServer.discardUntil("35=V|55=" + SYMBOL);
        LOGGER.info("Got MDR: " + marketDataRequest.toPrettyString());

        LOGGER.info("Sending back price.");
        pricingServer.send(defaultSnapshotRefreshFixMessage(marketDataRequest.getField(FieldTypes.MDReqID).getValue()));

        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(defaultSnapshotRefreshMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println("==============================================================");

        //When pricingServer (venue simulator) is shutdown
        pricingServer.shutdown();

        //Then empty snapshot messages should be available in pricing queue
        final PricingMessage pricingSnapShotMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(emptySnapshotMessageMatcher())
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        System.out.println(pricingSnapShotMessage.toString());

        //pricingSnapShotMessage.accept(snapshotFullRefresh -> assertEquals("GB:lg-fastma", snapshotFullRefresh.body.senderCompId), incrementalRefresh -> {});
        System.out.println("==============================================================");
    }

    @Test
    public void should_not_send_empty_snapshot_when_not_logged_on() throws Exception {

        //Given pricingServer (venue simulator) is down
        //When adapter is not connected
        //Then the pricing queue should not contain any message
        Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build())
                .awaitNotMatching(500, TimeUnit.MILLISECONDS);

        System.out.println("==============================================================");
    }
}