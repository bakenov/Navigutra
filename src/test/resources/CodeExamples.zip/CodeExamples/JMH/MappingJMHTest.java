package com.anz.axle.adapters.ndf2trep.enrichment.margin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.DoubleUnaryOperator;

import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.markets.efx.ngaro.api.Venue;

public class MappingJMHTest {

    public static class InputData {
        private final String instrument;
        private final Venue market;
        private final double bid;
        private final double ask;

        InputData(String instrument, Venue maeket, double bid, double ask) {
            this.instrument = instrument;
            this.market = maeket;
            this.bid = bid;
            this.ask = ask;
        }
    }

    private static Random random = new Random();
    private static final List<String> INSTRUMENTS = new ArrayList<>();
    private static final List<Venue> VENUES = new ArrayList<>();
    private static final  Map<String, Integer> PIP_TABLE = new HashMap<>();

    private static final String SERVICE_NAME = "AXLE_DEV";
    private static final int N = 10000;

    static {
        INSTRUMENTS.add("AUDCAD");
        INSTRUMENTS.add("AUDEUR");
        INSTRUMENTS.add("AUDGBP");
        INSTRUMENTS.add("AUDNZD");
        INSTRUMENTS.add("AUDIDR");
        INSTRUMENTS.add("AUDJPY");
        INSTRUMENTS.add("AUDUSD");

        VENUES.add(Venue.valueOf("WSP_A"));
        VENUES.add(Venue.valueOf("WSP_U"));
        VENUES.add(Venue.valueOf("WSP_Z"));

        PIP_TABLE.put("AUDCAD", 10000);
        PIP_TABLE.put("AUDEUR", 10000);
        PIP_TABLE.put("AUDGBP", 10000);
        PIP_TABLE.put("AUDNZD", 10000);
        PIP_TABLE.put("AUDIDR", 10);
        PIP_TABLE.put("AUDJPY", 100);
        PIP_TABLE.put("AUDNOK", 10000);
        PIP_TABLE.put("AUDUSD", 10000);
    }

    private static List<InputData> buildInputData() {
        List<InputData> inputs = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            inputs.add(new InputData(getInstrument(), getVenue(), random.nextDouble(), random.nextDouble()));
        }
        return inputs;
    }

    private static String getInstrument() {
        return INSTRUMENTS.get(random.nextInt(INSTRUMENTS.size()));
    }

    private static Venue getVenue() {
        return VENUES.get(random.nextInt(VENUES.size()));
    }

    private static String getMarginConfig(String instrument) {
        int decNumber = 0;
        int pips = PIP_TABLE.get(instrument);
        switch (pips) {
            case 10 :
                decNumber = 1;
                break;
            case 100 :
                decNumber = 2;
                break;
            case 1000 :
                decNumber = 3;
                break;
            case 10000 :
                decNumber = 4;
                break;
            default :
        }
        if (random.nextBoolean())
            return "PERC,BID,-,0.009,ASK,+,0.008," + decNumber;
        return "PIPS ,BID,-,1, ask ,+,1," + decNumber;
    }

    @State(Scope.Benchmark)
    public static class Data {

        private MarginServiceImpl marginService;
        private Map<String, Map<String, List<String>>> marginConfigMap;

        private List<InputData> inputs;


        @Setup
        public void setup() {
            inputs = buildInputData();

            final Map<String, Set<String>> symbolVenuesFXSPOT = new HashMap<>();
            INSTRUMENTS.forEach((s) -> {
                Set<String> set = symbolVenuesFXSPOT.computeIfAbsent(s, (k) -> new HashSet<>());
                VENUES.forEach((v) -> set.add(v.name()));
            });


            final Map<String, Map<String, Set<String>>> instrumentRics = new HashMap<>();
            instrumentRics.put("EBS", new HashMap<>());
            instrumentRics.get("EBS").put("USDCNS", new HashSet<>());

            final Map<String, String> publishSourceId = new HashMap<>();
            publishSourceId.put("EBS", "AXLE_DEV");
            publishSourceId.put("WSP_A", "SPDEE");
            publishSourceId.put("WSP_Z", "AXLE_DEV");

            final Map<String, Set<String>> venueServiceNamesMap = new HashMap<>();
            VENUES.forEach((v) -> {
                Set<String> set = venueServiceNamesMap.computeIfAbsent(v.name(), (k) -> new HashSet<>());
                set.add(SERVICE_NAME);
            });

            final Map<String, String> serviceNamePublishSourceId = new HashMap<>();
            serviceNamePublishSourceId.put(SERVICE_NAME, SERVICE_NAME);

            RicRepository ricRepository = new RicRepository(symbolVenuesFXSPOT,
                    instrumentRics,
                    new HashMap<>(),
                    serviceNamePublishSourceId,
                    venueServiceNamesMap,
                    SERVICE_NAME);

            marginConfigMap = new HashMap<>();
            INSTRUMENTS.forEach((s) -> {
                addData(s, SERVICE_NAME, getMarginConfig(s));
            });
            marginService = new MarginServiceImpl(marginConfigMap, PIP_TABLE, ricRepository);
        }

        private void addData(String instrument, String source, String params) {
            Map<String, List<String>> map = marginConfigMap.computeIfAbsent(instrument, (k) -> new HashMap<>());
            map.put(source, new ArrayList<>(Arrays.asList(params.split(","))));
        }
    }

    @Benchmark
    public void addMargin(@NotNull final Data data) {
        for (InputData id : data.inputs) {
            DoubleUnaryOperator op = data.marginService.getBidMarginOperator(id.instrument, id.market);
            op.applyAsDouble(id.bid);
            op = data.marginService.getOfferMarginOperator(id.instrument, id.market);
            op.applyAsDouble(id.ask);
        }
    }
}
