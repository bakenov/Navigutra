package com.anz.markets.prophet.chronicle;

/**
 * An error so serious we should shut down
 */
public class FatalError extends RuntimeException {
    public FatalError(final Exception e) {
        super(e);
    }

    public FatalError(final String message) {
        super(message);
    }

    public FatalError(final String message, final Exception e) {
        super(message, e);
    }
}
