#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh daxa001z "rm -rf ~/axle/datafabric/workspace/*"
