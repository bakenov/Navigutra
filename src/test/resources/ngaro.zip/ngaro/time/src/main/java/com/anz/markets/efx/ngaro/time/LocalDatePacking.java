package com.anz.markets.efx.ngaro.time;

import java.time.LocalDate;

/**
 * Different int packings for elements of a {@link java.time.LocalDate} into an integer value.
 */
public enum LocalDatePacking {
    /**
     * Date encoded as int value in YYYYMMFF format, e.g. a value 20161215.
     * This is a human readable packing but it is not as efficient as {@link #BINARY}.
     */
    DECIMAL {
        @Override
        public int pack(final int year, final int month, final int day) {
            return 10_000 * year + 100 * month + day;
        }

        @Override
        public int unpackYear(final int packed) {
            return packed / 10_000;
        }

        @Override
        public int unpackMonth(final int packed) {
            return (packed / 100) % 100;
        }

        @Override
        public int unpackDay(final int packed) {
            return packed % 100;
        }

        @Override
        public int repack(final int packed, final LocalDatePacking packing) {
            switch (packing) {
                case DECIMAL:
                    return packed;
                default:
                    return pack(packing.unpackYear(packed), packing.unpackMonth(packed), packing.unpackDay(packed));
            }
        }
    },
    /**
     * Date encoded as positive int value in binary format with |22|4|5| bits for |YYYY|MM|DD|.
     * This is not a human readable packing but it is more efficient than {@link #DECIMAL}.
     */
    BINARY {
        @Override
        public int pack(final int year, final int month, final int day) {
            return ((year & 0x3fffff) << 9) | ((month & 0xf) << 5) | (day & 0x1f);
        }

        @Override
        public int unpackYear(final int packed) {
            return (packed >>> 9) & 0x3fffff;
        }

        @Override
        public int unpackMonth(final int packed) {
            return (packed >>> 5) & 0xf;
        }

        @Override
        public int unpackDay(final int packed) {
            return packed & 0x1f;
        }

        @Override
        public int repack(final int packed, final LocalDatePacking packing) {
            switch (packing) {
                case BINARY:
                    return packed;
                default:
                    return pack(packing.unpackYear(packed), packing.unpackMonth(packed), packing.unpackDay(packed));
            }
        }
    };

    public int pack(final LocalDate localDate) {
        return pack(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
    }
    public LocalDate unpack(final int packed) {
        return LocalDate.of(unpackYear(packed), unpackMonth(packed), unpackDay(packed));
    }
    abstract public int pack(int year, int month, int day);
    abstract public int repack(int packed, LocalDatePacking packing);
    abstract public int unpackYear(int packed);
    abstract public int unpackMonth(int packed);
    abstract public int unpackDay(int packed);
}
