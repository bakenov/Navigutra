#!/bin/bash

source ~/bin/shell-env/daxa009s/.functions

hosts="auq4014s auq4015s auq4016s auq4054s auq4009s auq4000s auq4011s auq4013s"
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "find ~/logs -type f -name '*pid*' -exec rm -rf {} \;; echo Removed PID files") ::: $hosts
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "ps -ef | egrep '(java|iaf|corr|stunnel|mstats)' | egrep -v '(grep|delta|pdc|mahi/apps|prophet)' | awk '{ print \$2 }' | xargs -I {} kill -9 {}; echo 'Killed (java|iaf|corr|stunnel|mstats)'") ::: $hosts

