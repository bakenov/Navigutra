package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.*;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.positionrisk.Positions;
import org.apache.logging.log4j.Level;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeTriggerState.BUYING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELLING;
import static com.anz.markets.prophet.domain.HedgeTriggerState.SELL_REQ;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCAD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.BGCMIDFX;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Market.FXALLMB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * AXPROPHET-896 New Aggressive Hedger strategy that triggers during period of not receiving mid hedger trades AND if specified
 * pnl(loss or profit) is met during that period
 *
 * AXPROPHET-937 Pnl is scaled to /1mio USD. (only when the currency positionInSystemBase is above 1mio USD)
 */

@RestartBeforeTest(reason = "As hedger states are left hanging")
@Requirement(value = {Requirement.Ref.HEDGING_AXPROPHET_896, Requirement.Ref.HEDGING_AXPROPHET_937})
public class AggressiveHedgeMonitorTest extends BaseAcceptanceSpecification {
    NewOrder newOrder;
    NewOrder newOrder2;
    CancelOrder cancelOrder;
    private double instrumentPos;

    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setMidHedgerConfigs(Arrays.asList(
                        new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                .setVarTriggerHighVar(10000)
                                .setRiskTriggerLowWaterMark(800_000.0)
                                .setRiskTriggerHighWaterMark(1_200_000.0)
                                .setOrderQuantity(1_000_000)
                                .setTradingTimeZone(TradingTimeZone.LDN)
                ))
                .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                        new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(1_000);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setHedgeMonitor("HEDGER_MID_BGC");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(-200.0);}}
                ));
                return configuration;
    }

    @Test
    public void noHedgeFillAndPnlLossSignificant_Sell() {
        double maxSpreadBps = 0.0002;
        double tobBid = 0.74998;
        double tobOffer = 0.75002;

        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, tobBid, tobOffer, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0 -> t+3.5s
        {
            createPnlLossPoints();
        }
        and:
        {
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            instrumentPos = opPos.getInstrumentPositionInNotional();
        }
        when:
        // @t+5.0s still no fill received.
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder2.getSide(),is(HedgeOrderSide.SELL));
            assertThat(newOrder2.getQuantity(),is(instrumentPos));
            assertThat(newOrder2.getPrice(),is(tobOffer - maxSpreadBps));
            prophet.expect(Level.INFO, newOrderComment("AGR_AXL_SLM"));

            // do NOT cancel existing Mid Hedger order
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // aggressive hedger order filled, mid hedger order is cancelled(since below low watermark)
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFill(newOrder2);
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class,exactly(1)).getFirst();

            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPnl(), is(0.0));
        }

        and:
        {
            secondCycle();
        }
    }

    public void secondCycle() {
        when:
        // t+6 -> t+9.5s
        {
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            createPnlLossPoints();
        }
        and:
        // @t+11s still no fill received.
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=-50;windowEndPnl=-250"));
        }
    }

    @Test
    public void noHedgeFillAndPnlLossSignificant_Buy() {
        double instrumentPos;
        double maxSpreadBps = 0.0002;
        double tobBid = 0.74998;
        double tobOffer = 0.75002;

        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("ANY");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-116.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, tobBid, tobOffer, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0 receive Client Deal generating PnL +50
        // BDGMid hedger sends hedging order
        {
            bgcMidHedgerSendsOrder(-1_000_000, 0.75005);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        when:
        // t+0.5s client deal received resulting in pnl -100
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -200 /1.5mioUSD = -133.33/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl -150
        // |PositionInSystemBase| of 2.25mio is > 1mio therefore pnl is scaled
        // -150 /2.25mioUSD = -66.67/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74995));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -150.0));

            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            instrumentPos = Math.abs(gradientPos.getInstrumentPositionInNotional());

            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s still no fill received.
        // Current/latest Pnl = -66.67.  Start PnL = +50.  Total change = -116.67
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, BUYING));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder2.getSide(),is(HedgeOrderSide.BUY));
            assertThat(newOrder2.getQuantity(),is(instrumentPos));
            assertThat(newOrder2.getPrice(),is(tobBid + maxSpreadBps));

            // do NOT cancel existing Mid Hedger order
            prophet.notExpect(CancelOrder.class);
        }
        when:
        // aggressive hedger order filled, mid hedger order is cancelled(since below low watermark)
        {
            prophet.receiveHedgeOrderFullFill(newOrder2);
        }
        then:
        {
            prophet.expect(CancelOrder.class,exactly(1));
        }
    }

    @Test
    public void noHedgeFillAndPnlLossSignificant_MinRiskNotMet() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(3_000_100);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setHedgeMonitor("ANY");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0 receive Client Deal generating PnL +50
        // BDGMid hedger sends hedging order
        {
            bgcMidHedgerSendsOrder(-1_000_000, 0.75005);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        when:
        // t+0.5s client deal received resulting in pnl -100
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -100 /1.5mioUSD = -66.666/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl -200
        // |PositionInSystemBase| of 2.25mio is > 1mio therefore pnl is scaled
        // -200 /2.25mioUSD = -88.888/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -200.0));

            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(gradientPos.getInstrumentPositionInNotional(), is(-3_000_000.0));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s still no fill received.
        // Current/latest Pnl = -88.89.  Start PnL = +50.  Total change = -138.89 => equal to/greater than pnlThreshold
        // However minRisk of 3_000_100 NOT Met => Aggressive Hedge order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.5 receive client deal
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000, 0.75000));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+6.0s still no fill received.
        // Current/latest Pnl = -88.89.  Start PnL = -66.67.  Total change = -22.22 => equal to/greater than pnlThreshold
        // minRisk of 3_000_100 also Met => Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, BUYING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    @Requirement(value = {Requirement.Ref.POSITION_AXPROPHET_964})
    @DisplayName("Verify biased notional position used for Min Risk and Order Amount. " +
            "Ensure correct config tier based on min risk is used")
    public void strategyToUseBiasedPositions() {
        double biasedMinRisk = 3_000_100;
        double tobBid = 0.74998;
        double maxSpreadBps = 0.0002;
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(2_000_000);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0003);
                                setHedgeMonitor("ANY");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(-1.0);}},
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(biasedMinRisk);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(maxSpreadBps);
                                setHedgeMonitor("ANY");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(-1.0);}},
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(5_000_000);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0005);
                                setHedgeMonitor("ANY");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, tobBid, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, tobBid, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));

            // set up biased position
            prophet.receive(tdd.biasPosition(Currency.AUD, 101.0));
        }
        given:
        // t+0 receive Client Deal generating PnL +50
        // BDGMid hedger sends hedging order
        {
            bgcMidHedgerSendsOrder(-1_000_000, 0.75005);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        when:
        // t+0.5s client deal received resulting in pnl -100
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -100 /1.5mioUSD = -66.666/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl -200
        // |PositionInSystemBase| of 2.25mio is > 1mio therefore pnl is scaled
        // -200 /2.25mioUSD = -88.888/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -200.0));

            // unbiased op pos does NOT meet min risk
            OptimalPositions pos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(opPos.getInstrumentPositionInNotional(), is(-3_000_000.0));

            // biased op pos DOES meet min risk
            OptimalPositions biasedPos = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition biasedOpPos = biasedPos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(biasedOpPos.getInstrumentPositionInNotional(), is(-3_000_101.0));

            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s still no fill received.
        // Current/latest Pnl = -88.89.  Start PnL = +50.  Total change = -138.89 => equal to/greater than pnlThreshold
        // minRisk of 3_000_100 also Met => Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, BUYING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder.getSide(),is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(),is(3_000_101.0)); // biased notional position
            assertThat(newOrder.getPrice(),is(tobBid + maxSpreadBps));
        }
    }

    @Test
    public void noHedgeFillAndPnlLossNotSignificant() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(1_000_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-201.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0 -> t+3.5s
        {
            createPnlLossPoints();
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => NOT EXCEED PnLThreshold(-201.0)
        // Therefore Aggressive hedger not triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    public void noHedgeFillAndPnlProfitSignificant_RollingWindow() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(77.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        when:
        // t+0 receive Client Deal generating PnL +100
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        // BDGMid hedger sends hedging order
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 100.0));
        }
        when:
        // t+0.5s client deal received resulting in pnl +50
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // 50 / 1.5mioUSD = 33.33/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 50.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl 250
        // |PositionInSystemBase| of 2.25mio is > 1mio therefore pnl is scaled
        // 250 / 2.25mioUSD = 111.11/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74980));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 250.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s still no fill received.
        // Current/latest Pnl = +111.11 Start PnL = +100.  Total change = +11.11 => not equal/greater than PnLTracker(77.0)
        // Aggressive Hedge order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
        when:
        // @t+6.0s still no fill received.
        // Current/latest Pnl = +111.11 Start PnL = +33.33  Total change = +77.78 => equal/greater than PnLTracker(77.0)
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder2.getSide(),is(HedgeOrderSide.SELL));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=33;windowEndPnl=111"));
        }
    }

    @Test
    // AXPROPHET-1137
    public void multipleMonitorsPositiveNegativePnl() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setHedgeMonitor("HEDGER_MID_BGC");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(12.0);}}
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setHedgeMonitor("HEDGER_MID_BGC");
                                setHedgeMonitorWindowSeconds(5);
                                setPnLThreshold(-22.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        when:
        // t+0 receive Client Deal generating PnL +100
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        // BDGMid hedger sends hedging order
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 100.0));
        }
        when:
        // t+0.5s client deal received resulting in pnl +200
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // 200 / 1.5mioUSD = 133.33/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 200.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl 250
        // |PositionInSystemBase| of 2.25mio is > 1mio therefore pnl is scaled
        // 250 / 2.25mioUSD = 111.11/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74995));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 250.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s still no fill received.
        // Current/latest Pnl = +111.11 Start PnL = +100.  Total change = +11.11 => not equal/greater than PnLTracker(12.0)
        // Aggressive Hedge order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
        when:
        // @t+6.0s still no fill received.
        // Current/latest Pnl = +111.11 Start PnL = +133.33  Total change = -22.222 => equal/greater than PnLTracker(-22.0)
        // Aggressive Hedge order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            assertThat(newOrder2.getSide(),is(HedgeOrderSide.SELL));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=133;windowEndPnl=111"));
        }
    }

    @Test
    public void singleMonitorsDiffHedgers() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(10000)
                                    .setRiskTriggerLowWaterMark(300_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.FXALLMB, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(10000)
                                    .setRiskTriggerLowWaterMark(700_000.0)
                                    .setRiskTriggerHighWaterMark(1_000_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC|HEDGER_MID_FXALL");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_FXALL));
        }
        when:
        // t+0 receive AUDUSD Client Deal generating PnL -50
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // t+0 AUDUSD Hedge Order placed by each Mid Hedger.  End of monitor wind  ow will be t+5.0sec
        {
            prophet.expect(NewOrder.class, exactly(2)).getFirst();
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(BGCMIDFX)).getFirst();
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(FXALLMB)).getFirst();

            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+1.5s AUDUSD client deal received resulting in pnl -130
        // AUD |PositionInSystemBase| of 0.9mio is < 1mio therefore pnl is NOT scaled
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 200_000, 0.75040));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -130.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+2.5s FXALLMID hedger order partially filled.  Therefore monitor windows cancelled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receiveHedgeOrderPartialFill(newOrder2, 700_000, 0.75);
        }
        then:
        {
            prophet.notExpect(ProfitAndLoss.class);
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s End of AUDUSD order window.
        // Current/latest Pnl = -130.  Start PnL = -50.  Total change = -80 => equal/greater than PnLTracker(-1)
        // However partial filled received earlier so NO Aggressive Hedge AUD/USD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void multipleMonitorsDiffHedgerSameInstrument() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(10000)
                                    .setRiskTriggerLowWaterMark(300_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.FXALLMB, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(10000)
                                    .setRiskTriggerLowWaterMark(700_000.0)
                                    .setRiskTriggerHighWaterMark(1_000_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}},
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_FXALL");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_FXALL));
        }
        when:
        // t+0 receive AUDUSD Client Deal generating PnL -50
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // t+0 AUDUSD Hedge Order placed by each Mid Hedger.  End of both monitor window will be t+5.0sec
        {
            prophet.expect(NewOrder.class, exactly(2)).getFirst();
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(BGCMIDFX)).getFirst();
            newOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(FXALLMB)).getFirst();

            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+1.5s AUDUSD client deal received resulting in pnl -130
        // AUD |PositionInSystemBase| of 0.9mio is < 1mio therefore pnl is NOT scaled
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 200_000, 0.75040));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -130.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s End of AUDUSD order window.
        // Current/latest Pnl = -130.  Start PnL = -50.  Total change = -80 => equal/greater than PnLTracker(-1)
        // Only one Aggressive order triggered(i.e can only place one order per instrument)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void multipleMonitorsSameHedgerDifferentInstrument() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(10000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDCAD)
                                    .setVarTriggerHighVar(10000)
                                    .setRiskTriggerLowWaterMark(300_000.0)
                                    .setRiskTriggerHighWaterMark(800_000.0)
                                    .setOrderQuantity(500_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-250.0);}},
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.USDCAD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(4);
                                    setPnLThreshold(20.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        when:
        // t+0 receive AUDUSD Client Deal generating PnL -50
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // t+0 AUDUSD Hedge Order placed.  End of monitor wind  ow will be t+5.0sec
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+0.5s AUDUSD client deal received resulting in pnl -450
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -450 / 1.5mioUSD = -300.0/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75040));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -450.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s USDCAD client deal received resulting in pnl 80
        // CAD |PositionInSystemBase| of 999_920 is < 1mio therefore pnl is NOT scaled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24990));
        }
        then:
        // t+1.5s USDCAD Hedge Order placed.  End of monitor window will be t+5.5sec => t+6s i.e rounded to nearest sec
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 80.0));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2.5s USDCAD client deal received resulting in pnl 200
        // CAD |PositionInSystemBase| of 1_999_840 is > 1mio therefore pnl is scaled
        // 200 / 1.99984mioUSD = 100.008/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 200.0));
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            instrumentPos = gradientPos.getInstrumentPositionInNotional();

            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s End of AUDUSD order window. Still no fill received
        // Current/latest AUD Pnl = -300.  Start PnL = -50.  Total change = -250 => equal/greater than PnLTracker(-250)
        // Aggressive Hedge AUD/USD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=-50;windowEndPnl=-300"));
        }
        when:
        // @t+6.0s end of USDCAD order window. still no fill received.
        // Current/latest CAD Pnl = 100.008.  Start PnL = 80.  Total change = +20.008 => equal/greater than PnLTracker(+20.0)
        // Aggressive Hedge USDCAD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD)).getFirst();
            assertThat(newOrder.getSide(),is(HedgeOrderSide.SELL));
            assertThat(newOrder.getQuantity(),is(instrumentPos));
            prophet.expect(Level.INFO, newOrderComment("windowStartPnl=80;windowEndPnl=100"));
        }
    }

    @Test
    public void differentHedgersAndInstrumentMonitors_Cancel() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(90000)
                                    .setRiskTriggerLowWaterMark(900_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.FXALLMB, Instrument.USDCAD)
                                    .setVarTriggerHighVar(90000)
                                    .setRiskTriggerLowWaterMark(200_000.0)
                                    .setRiskTriggerHighWaterMark(500_000.0)
                                    .setOrderQuantity(500_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(1_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}},
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.USDCAD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_FXALL");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(20.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_FXALL));
        }
        when:
        // t+0 receive AUDUSD Client Deal generating PnL -50
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // t+0 AUDUSD Hedge Order placed.  End of monitor wind  ow will be t+5.0sec
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+0.5s AUDUSD client deal received resulting in pnl -450
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -450 / 1.5mioUSD = -300.0/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75040));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -450.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s USDCAD client deal received resulting in pnl +80
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24990));
        }
        then:
        // t+1.5s USDCAD Hedge Order placed.  End of monitor window will be t+5.5sec => t+6s i.e rounded to nearest sec
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, +80.0));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2.5s USDCAD client deal received resulting in pnl +200
        // CAD |PositionInSystemBase| of 1_999_840 is > 1mio therefore pnl is scaled
        // 200 / 1.99984mioUSD = 100.008/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 200.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+3 receive AUDUSD clientdeal reducing pos to below lowwatermark. Cancel hedge order and Monitor
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.75000));
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD)).getFirst();
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(USDCAD));
        }
        when:
        // AUDUSD order cancelled
        {
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s End of AUDUSD order window. Still no fill received
        // Current/latest AUD Pnl = -300.  Start PnL = -50.  Total change = -250 => equal/greater than PnLTracker(-1)
        // But mid hedger order was canceled so NO Aggressive Hedge AUD/USD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_000);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+7.0s end of USDCAD order window. still no fill received.
        // Current/latest CAD Pnl = 100.008.  Start PnL = 80.  Total change = +20.008 => equal/greater than PnLTracker(+20.0)
        // Aggressive Hedge USDCAD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void differentHedgersAndInstrumentMonitors() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(90000)
                                    .setRiskTriggerLowWaterMark(900_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.FXALLMB, Instrument.USDCAD)
                                    .setVarTriggerHighVar(90000)
                                    .setRiskTriggerLowWaterMark(200_000.0)
                                    .setRiskTriggerHighWaterMark(500_000.0)
                                    .setOrderQuantity(500_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(1_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}},
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.USDCAD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_FXALL");
                                    setHedgeMonitorWindowSeconds(4);
                                    setPnLThreshold(20.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_FXALL));
        }
        when:
        // t+0 receive AUDUSD Client Deal generating PnL -50
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        // t+0 AUDUSD Hedge Order placed.  End of monitor wind  ow will be t+5.0sec
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+0.5s AUDUSD client deal received resulting in pnl -450
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -450 / 1.5mioUSD = -300.0/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75040));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -450.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s USDCAD client deal received resulting in pnl +80
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24990));
        }
        then:
        // t+1.5s USDCAD Hedge Order placed.  End of monitor window will be t+5.5sec => t+6s i.e rounded to nearest sec
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 80.0));
            newOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2.5s USDCAD client deal received resulting in pnl +200
        // CAD |PositionInSystemBase| of 1_999_840 is > 1mio therefore pnl is scaled
        // 200 / 1.99984mioUSD = 100.008/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 200.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s End of AUDUSD order window. Still no fill received
        // Current/latest AUD Pnl = -300.  Start PnL = -50.  Total change = -250 => equal/greater than PnLTracker(-1)
        // Aggressive Hedge AUD/USD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
            prophet.expect(Level.INFO, newOrderComment("refPortfolio=HEDGER_MID_BGC"));

            prophet.notExpect(HedgeDecision.class, isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(USDCAD));
        }
        when:
        // @t+6.0s end of USDCAD order window. still no fill received.
        // Current/latest CAD Pnl = +100.008.  Start PnL = +80.  Total change = +20.008 => equal/greater than PnLTracker(+20.0)
        // Aggressive Hedge USDCAD order triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD));
            prophet.expect(Level.INFO, newOrderComment("refPortfolio=HEDGER_MID_FXALL"));

            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void unableToPlaceAggressiveOrder_Retry() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(1_000_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.AXL, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.74998, 500_000),
                        new PriceAndQtyImpl(0.74980, 100_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75002, 1_000_000)),
                    tdd.now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        {
            createPnlLossPoints();
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => equal/exceed PnLTracker(-1.0)
        // However Aggressive hedger unable to place order since insufficient liquidity(MinimumOrderQuantity) in AXL market
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
        when:
        // @t+5.5s AXL market data update(now with sufficient liquidity)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75003, now()));
        }
        and:
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 500);
        }
        then:
        // @t+6.0 on the one sec chime re-evaluate and place out aggressive hedge order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void receiveHedgeFullFill_NoAggressiveOrder() {
        setup:
        {
            setup();
        }
        given:
        // t+0 receive Client Deal generating PnL -50
        // BDGMid hedger sends hedging order
        {
            bgcMidHedgerSendsOrder(1_000_000, 0.75005);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        and:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+0.5s client deal received resulting in pnl -200
        // |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -200 / 1.5mioUSD = -133.33/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75015));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -200.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl -250
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74995));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPnl(), is(-250.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+2.5 hedge order filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75000);  // PnL will be unchanged
        }
        then:
        {
            prophet.notExpect(ProfitAndLoss.class);
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => equal/exceed PnLTracker(-200.0)
        // However since mid hedger order filled Aggressive Hedge order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    public void receiveHedgePartialFill_NoAggressiveOrder() {
        setup:
        {
            setup();
        }
        given:
        {
            createPnlLossPoints();
        }
        when:
        // t+2.5 hedge order filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receiveHedgeOrderPartialFill(newOrder, 500_000, 0.75000);  // PnL will be unchanged
        }
        then:
        {
            prophet.notExpect(ProfitAndLoss.class);
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => equal/exceed PnLTracker(-200.0)
        // However since mid hedger order filled Aggressive Hedge order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    public void hedgeOrderCancelled_NoAggressiveOrder() {
        setup:
        {
            setup();
        }
        given:
        // t+0 receive Client Deal generating PnL -50
        // BDGMid hedger sends hedging order
        {
            bgcMidHedgerSendsOrder(1_000_000, 0.75005);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        and:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+0.5s client deal received resulting in pnl -200
        // AUD |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // -200 / 1.5mioUSD = -133.33/mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75015));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -200.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl -275
        // since below low-watermark, hedger cancel's order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_500_000, 0.74995));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -275.0));

            prophet.notExpect(NewOrder.class);
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getFirst();
        }
        when:
        // t+2.5 cancel order confirmed
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-275.  Start PnL=-50.  Total change = -225 => equal/exceed PnLTracker(-200.0)
        // However since mid hedger order cancelled, Aggressive Hedge order NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    public void differentTimeZone_NoAggressiveOrder() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.SNG);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-200.0);}}
                    ))
            );

            // different to SpeedUpByMonitor config tz of SNG
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        {
            createPnlLossPoints();
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => equal/exceed PnLTracker(-200.0)
        // However current timezone is SG(i.e NOT LDN) => do not trigger aggressive hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    public void differentHedger_NoAggressiveOrder() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_FXALL");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(-200.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        {
            createPnlLossPoints();
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => equal/exceed PnLTracker(-200.0)
        // However HedgeMonitor configured for "HEDGER_MID_FXALL" => do not trigger aggressive hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    // AXPROPHET-1374. SLM and SLP triggered simultaneously.
    // SLM places order first which is then filled resulting in position update
    // SLP re-evaluates and does NOT place order(since position has updated)
    public void hedgeMonitorAndPositionMonitorTriggeredSimultaneously() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumRisk(1_000);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setHedgeMonitor("HEDGER_MID_BGC");
                                setHedgeMonitorWindowSeconds(6);
                                setPnLThreshold(-1.0);}}
                    ))
                    .setAggressiveSpeedUpByPositionHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByPositionHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                setTradingTimeZone(TradingTimeZone.LDN);
                                setMinimumOrderQuantity(500_000);
                                setMaximumSpread(0.0002);
                                setMinimumRisk(1_000);
                                setPositionMonitorWindowSeconds(2);
                                setPnLThreshold(-1.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0 -> t+3.5s
        {
            createPnlLossPoints();
        }
        when:
        // t+4.0s market data update causing new pnl -450
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74980));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -450.0));
        }
        when:
        // t+5.0s market data update causing new pnl -550
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74970));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -550.0));
        }
        when:
        // @t+6.0s still no fill received.
        // Both SLP and SLM triggered. Order placed via SLM
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1000);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELL_REQ));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getFirst();
            prophet.expect(Level.INFO, newOrderComment("AGR_AXL_SLM"));
        }
        when:
        // @t+6.5s, aggressive order partially filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 500_000, 0.75000);
        }
        then:
        // position updated. Do NOT hedge via positionMonitor(SLP)
        {
            prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET));
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLP, SELLING));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    public void higherPriorityThanTwapWhenOrderAmountEqual() {
        /**
         * If TWAP and StopLoss monitor both want to place order then which ever has highest order amount wins
         * If order amounts equal then StopLoss Monitor strategy wins
         */
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.USDCAD)
                                    .setVarTriggerHighVar(1000000)
                                    .setRiskTriggerLowWaterMark(300_000.0)
                                    .setRiskTriggerHighWaterMark(1_000_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.USDCAD)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(5_000)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.USDCAD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(10.0);}}
                    ))
                    .setOptimalPositionConfigs(
                            Arrays.asList(
                                    new OptimalPositionConfig(Instrument.AUDJPY, Instrument.AUDJPY, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.AUDNZD, Instrument.AUDNZD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.AUDUSD, Instrument.AUDUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.EURAUD, Instrument.EURAUD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.EURCHF, Instrument.EURCHF, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURCZK, Instrument.USDCZK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURDKK, Instrument.USDDKK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURGBP, Instrument.EURGBP, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURHUF, Instrument.USDHUF, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURJPY, Instrument.EURJPY, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.EURNOK, Instrument.USDNOK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURPLN, Instrument.USDPLN, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURSEK, Instrument.USDSEK, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.EURUSD, Instrument.EURUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.GBPJPY, Instrument.GBPJPY, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.GBPUSD, Instrument.GBPUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.NZDUSD, Instrument.NZDUSD, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.USDCAD, Instrument.USDCAD, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDCHF, Instrument.USDCHF, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDCNH, Instrument.USDCNH, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDILS, Instrument.USDILS, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDJPY, Instrument.USDJPY, 0.6, 1.0, true),
                                    new OptimalPositionConfig(Instrument.USDMXN, Instrument.USDMXN, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDSGD, Instrument.USDSGD, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDTHB, Instrument.USDTHB, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDTRY, Instrument.USDTRY, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDHKD, Instrument.USDHKD, 0.6, 1.0, false),
                                    new OptimalPositionConfig(Instrument.USDZAR, Instrument.USDZAR, 0.6, 1.0, false)
                            ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 1.24998, 1.25002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        when:
        // t+0 receive Client Deal generating PnL 80
        // CAD |PositionInSystemBase| of 1_999_920 is > 1mio therefore pnl is scaled
        // 80 / 1.99992mioUSD = 40.0016/mio
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDCAD, 2_000_000, 1.24995));
        }
        then:
        // t+0 Mid Hedger Order placed.  End of monitor window will be t+5.0sec
        // TWAP strategy must wait till end of OrderRateWindow i.e t+5.0sec
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.BGCMIDFX)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 80.0));
        }
        when:
        // t+2.5s client deal received resulting in pnl 200
        // CAD |PositionInSystemBase| of 2_999_800 is > 1mio therefore pnl is scaled
        // 200 / 2.998mioUSD = 66.67111/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(2500));
            prophet.receive(tdd.client_trade_001(USDCAD, 1_000_000, 1.24985));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition2CurrencyPortfolioPnl(Currency.CAD, Portfolio.CLIENTS_NET, 200.0));
            prophet.notExpect(NewOrder.class);

            // instrumentPositionNotional(which SLMonitor strategy uses) is EQUAL TO gradient position(which TWAP strategy uses)
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == USDCAD).findFirst().get();
            assertThat(gradientPos.getInstrumentPositionInNotional(), is(gradientPos.getGradientPositionInNotional()));
        }
        when:
        // @t+5.0s End of SLMonitor order window. Still no fill received. Also end of TWAP Order Rate window
        // Current/latest Pnl = 66.67.  Start PnL = 40.  Total change = +26.67 => equal/greater than PnLTracker(10)
        // Since SLMonitor strategy order amount == TWAP strategy order amount, SLMonitor has HIGHER PRIORITY
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_TWAP, SELLING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(USDCAD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD));
        }
    }

    @Test
    public void twapAmtGreaterThanSLMonitorAmt() {
        /**
         * If TWAP and StopLoss monitor both want to place order then which ever has highest order amount wins
         */
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(1000000)
                                    .setRiskTriggerLowWaterMark(300_000.0)
                                    .setRiskTriggerHighWaterMark(1_000_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0001)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(5_000)
                    ))
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(10.0);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
        }
        when:
        // t+0 receive Client Deal generating PnL 50
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74995));
        }
        then:
        // t+0 Mid Hedger Order placed.  End of monitor window will be t+5.0sec
        // TWAP strategy must wait till end of OrderRateWindow i.e t+5.0sec
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.BGCMIDFX)).getFirst();
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 50.0));
        }
        when:
        // t+2.5s client deal received resulting in pnl 150
        // AUD |PositionInSystemBase| of 1.5mio is > 1mio therefore pnl is scaled
        // 150 / 1.5mioUSD = 100/mio
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(2500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.74990));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, 150.0));

            prophet.notExpect(NewOrder.class);

            // gradient position(which TWAP strategy uses) is GREATER THAN instrumentPositionNotional(which SLMonitor strategy uses
            OptimalPositions pos = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = pos.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(gradientPos.getGradientPositionInNotional() > gradientPos.getInstrumentPositionInNotional(), is(true));
        }
        when:
        // @t+5.0s End of SLMonitor order window. Still no fill received. Also end of TWAP Order Rate window
        // Current/latest Pnl = 100.  Start PnL = 50.  Total change = +50 => equal/greater than PnLTracker(10)
        // Since TWAP strategy order amount > SLMonitor strategy order amount, TWAP strategy places order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_SLM, SELLING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void disabledViaNanPnl() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .setAggressiveSpeedUpByMonitorHedgerConfigs(Arrays.asList(
                            new AggressiveSpeedUpByMonitorHedgerConfigImpl(Market.AXL, Instrument.AUDUSD) {{
                                    setTradingTimeZone(TradingTimeZone.LDN);
                                    setMinimumOrderQuantity(500_000);
                                    setMaximumSpread(0.0002);
                                    setHedgeMonitor("HEDGER_MID_BGC");
                                    setHedgeMonitorWindowSeconds(5);
                                    setPnLThreshold(Double.NaN);}}
                    ))
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        {
            createPnlLossPoints();
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 =>
        // However PnLTracker is NaN => do not trigger aggressive hedge order
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    @Test
    public void resetWhenHedgerTurnedOn() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        given:
        // t+0 -> t+1.5s
        {
            createPnlLossPoints();
        }
        when:
        // @t+1.5s aggressive hedger turned on i.e RESET STATES
        {
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // @t+5.0s
        // Current/latest Pnl=-250.  Start PnL=-50.  Total change = -200 => equal/exceed PnLTracker(-200.0)
        // However, monitor reset to IDLE when aggressive hedger turned on. Therefore Aggressive hedger not triggered
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
        when:
        // @t+7.0s
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_000);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.AGR_AXL_SLM));
        }
    }

    public void setup() {
        prophet.receive(setUpConfiguration());
        prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
        prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
    }

    public void createPnlLossPoints() {
        /**
         * create AUD pnl points of -50, -100, -150, -200, -250
         */
        given:
        // t+0 receive Client Deal generating PnL -50
        // BDGMid hedger sends hedging order
        {
            bgcMidHedgerSendsOrder(1_000_000, 0.75005);
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
        }
        and:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -50.0));
        }
        when:
        // t+0.5s client deal received resulting in pnl -100
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -100.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+1.5s client deal received resulting in pnl -150
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75005));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -150.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+2.5s client deal received resulting in pnl -200
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74995));
        }
        then:
        {
            prophet.expect(Positions.class, exactly(1), isPosition1CurrencyPortfolioPnl(Currency.AUD, Portfolio.CLIENTS_NET, -200.0));
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+3.5s client deal received resulting in pnl -250
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.74995));
        }
        then:
        {
            Positions positionsUpdate = prophet.expect(Positions.class, exactly(1), isPortfolio(Portfolio.CLIENTS_NET)).getFirst();
            assertThat(positionsUpdate.getPosition1().getCcy(), is(Currency.AUD));
            assertThat(positionsUpdate.getPosition1().getPnl(), is(-250.0));

            prophet.notExpect(NewOrder.class);
        }
    }

    public void bgcMidHedgerSendsOrder(double clientTradeAmt, double clientTradePrice) {
        /**
         *  Receive Client Deal generating PnL
         *  BDGMid hedger sends hedging order
         */
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.client_trade_001(AUDUSD, clientTradeAmt, clientTradePrice));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getFirst();
        }
    }
}
