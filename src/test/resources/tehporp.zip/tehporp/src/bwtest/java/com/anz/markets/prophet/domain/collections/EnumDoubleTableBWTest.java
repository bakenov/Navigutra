package com.anz.markets.prophet.domain.collections;

import com.anz.markets.efx.ngaro.collections.EnumDoubleTable;
import com.anz.markets.efx.ngaro.collections.ObjObjDoubleConsumer;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.util.function.Consumer;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EnumDoubleTableBWTest {

    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    final EnumDoubleTable<Instrument, Currency> table = new EnumDoubleTable<>(Instrument.class, Currency.class);

    final ObjObjDoubleConsumer<Instrument, Currency> biConsumer = new ObjObjDoubleConsumer<Instrument, Currency>() {
        @Override
        public void accept(final Instrument inst, final Currency ccy, final double value) {

        }
    };

    final Consumer<Instrument> instrumentConsumer = new Consumer<Instrument>() {
        @Override
        public void accept(final Instrument instrument) {

        }
    };

    final Consumer<Currency> currencyConsumer = new Consumer<Currency>() {
        @Override
        public void accept(final Currency currency) {

        }
    };

    public EnumDoubleTableBWTest() {
        table.put(Instrument.AUDUSD, Currency.AUD, 1d);
        table.put(Instrument.AUDUSD, Currency.GBP, 2d);
        table.put(Instrument.AUDUSD, Currency.NZD, 3d);
        table.put(Instrument.GBPUSD, Currency.AUD, 4d);
        table.put(Instrument.GBPUSD, Currency.GBP, 5d);
        table.put(Instrument.GBPUSD, Currency.NZD, 6d);
    }

    @Test
    public void testAAA_Warmup() {
        scenario_with_clear_size_isEmpty();
        scenario_with_RemoveIf();
        scenario3();
        scenario4();
    }


    @Test
    public void test_Allocation1() {
        helper.testAllocationNotExceeded(
                this::scenario_with_clear_size_isEmpty,
                100 // no allocation within measurement error
        );
    }

    @Test
    public void test_Allocation2() {
        helper.testAllocationNotExceeded(
                this::scenario_with_RemoveIf,
                100 // no allocation within measurement error
        );
    }

    @Test
    public void test_Allocation3() {
        helper.testAllocationNotExceeded(
                this::scenario3,
                100 // no allocation within measurement error
        );
    }

    @Test
    public void test_Allocation4() {
        helper.testAllocationNotExceeded(
                this::scenario4,
                100 // no allocation within measurement error
        );
    }

    /*
    A sample for some basic evidence on how to use
    @Test
    public void test_Allocation5() {
        helper.testAllocationNotExceeded(
                this::scenario5_fails_asAllocates,
                100 // no allocation within measurement error
        );
    }
         */

    void scenario_with_clear_size_isEmpty() {

        for (int i = 0; i < REPS; i++) {
            table.clear();
            table.size();
            table.isEmpty();
            table.put(Instrument.AUDUSD, Currency.AUD, 1d);
            table.put(Instrument.AUDUSD, Currency.GBP, 2d);
            table.put(Instrument.AUDUSD, Currency.NZD, 3d);
            table.put(Instrument.GBPUSD, Currency.AUD, 4d);
            table.put(Instrument.GBPUSD, Currency.GBP, 5d);
            table.put(Instrument.GBPUSD, Currency.NZD, 6d);

        }
    }

    void scenario_with_RemoveIf() {

        for (int i = 0; i < REPS; i++) {

            table.removeIf((key1, key2, value) -> {
                return value == 1d;
            });


            table.put(Instrument.AUDUSD, Currency.AUD, 1d);
            table.put(Instrument.AUDUSD, Currency.GBP, 2d);
            table.put(Instrument.AUDUSD, Currency.NZD, 3d);
            table.put(Instrument.GBPUSD, Currency.AUD, 4d);
            table.put(Instrument.GBPUSD, Currency.GBP, 5d);
            table.put(Instrument.GBPUSD, Currency.NZD, 6d);

        }
    }


    void scenario3() {
        for (int i = 0; i < REPS; i++) {
            table.forEachRowKey(instrumentConsumer);
            table.forEachColumnKey(currencyConsumer);
        }
    }


    void scenario4() {
        for (int i = 0; i < REPS; i++) {
            table.forEach(biConsumer);
        }
    }

    void scenario5_fails_asAllocates() {
        for (int i = 0; i < REPS; i++) {
            table.forEach((instrument, currency, value) -> {
                // nothing but has garbase
            });
        }
    }
}