package com.anz.markets.efx.fox.processor.state;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.api.domain.ParentOrder;

public interface ParentOrderFactory {
    ParentOrder create(final String strategyName);

    interface NamedFactory extends Supplier<ParentOrder> {
        String name();
    }

    static ParentOrderFactory of(NamedFactory... namedFactories) {
        final Map<String, Supplier<ParentOrder>> factoriesMap = new HashMap<>();
        Arrays.stream(namedFactories).forEach(namedFactory -> factoriesMap.put(namedFactory.name(), namedFactory));
        return strategyName -> {
            final Supplier<ParentOrder> factory = factoriesMap.get(strategyName);
            if (factory == null) throw new IllegalArgumentException("Unknown strategy name" + strategyName);
            return factory.get();
        };
    }
}
