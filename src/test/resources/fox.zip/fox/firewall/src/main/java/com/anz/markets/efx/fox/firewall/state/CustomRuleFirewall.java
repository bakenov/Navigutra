package com.anz.markets.efx.fox.firewall.state;

import java.util.Objects;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

/**
 *  Simple custom firewall that validates the new orders with specified set of the rules
 */
public class CustomRuleFirewall implements Firewall {
    private final String name;
    private final Rule[] rules;
    private final OrderConsumer.ErrorHandler errorHandler;

    public CustomRuleFirewall(final String firewallName,
                              final OrderConsumer.ErrorHandler errorHandler,
                              final Rule... rules) {
        this.name = Objects.requireNonNull(firewallName);
        this.rules = Objects.requireNonNull(rules);
        this.errorHandler = Objects.requireNonNull(errorHandler);
    }

    @Override
    public boolean accept(final NewOrderSingleDecoder newOrderSingle, final CommandContext commandContext) {
        for (Rule rule : rules) {
            if (!rule.validate(newOrderSingle, commandContext.precisionClock().nanos())) {
                errorHandler.accept(newOrderSingle, commandContext, rule);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onFirewallConfigRuleRequest(final CommandContext commandContext, final FirewallConfigDecoder firewallConfigDecoder) {
    }

    @Override
    public void applyFirewallConfigRuleResponse(final EventContext eventContext, final FirewallConfigDecoder firewallConfigDecoder) {
    }

    @Override
    public void applyExecutionReport(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
    }

    @Override
    public String firewallName() {
        return name;
    }
}
