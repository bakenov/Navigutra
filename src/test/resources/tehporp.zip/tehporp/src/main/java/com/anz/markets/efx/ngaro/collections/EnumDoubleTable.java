package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.function.Consumer;
import java.util.function.ObjDoubleConsumer;


public class EnumDoubleTable<R extends Enum<R>, C extends Enum<C>> {

    public static final double EMPTY = Double.NaN;
    transient R[] rowsKeyUniverse;
    transient C[] columnsKeyUniverse;

    final double[][] values;

    private int size;
    final int rowCapacity;
    final int columnCapacity;

    public EnumDoubleTable(final Class<R> keyTypeRow,
                           final Class<C> keyTypeColumn) {
        this.rowsKeyUniverse = keyTypeRow.getEnumConstants();
        this.columnsKeyUniverse = keyTypeColumn.getEnumConstants();
        this.rowCapacity = rowsKeyUniverse.length;
        this.columnCapacity = columnsKeyUniverse.length;
        this.size = 0;
        this.values = new double[rowCapacity][columnCapacity];

        for (int i = 0; i < rowCapacity; i++) {
            for (int j = 0; j < columnCapacity; j++) {
                this.values[i][j] = EMPTY;
            }
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isEmpty(double value) {
        return Double.isNaN(value);
    }

    public boolean containsColumnKey(R key) {
        for (int c = 0; c < columnCapacity; c++) {
            if (!isEmpty(values[key.ordinal()][c])) {
                return true;
            }
        }
        return false;
    }

    public boolean containsRowKey(C key) {
        for (int r = 0; r < rowCapacity; r++) {
            if (!isEmpty(values[r][key.ordinal()])) {
                return true;
            }
        }
        return false;
    }

    public boolean containsKey(R row, C column) {
        return !isEmpty(values[row.ordinal()][column.ordinal()]);
    }

    public boolean containsValue(double value) {
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (values[r][c] == value) {
                    return true;
                }
            }
        }
        return false;
    }

    public double get(R row, C column) {
        return values[row.ordinal()][column.ordinal()];
    }

    public double getOrDefault(final R row, final C column, final double defaultValue) {
        final double value = values[row.ordinal()][column.ordinal()];
        return isEmpty(value) ? defaultValue : value;
    }

    public double put(R rowKey,
                      C columnKey,
                      double value) {
        if (isEmpty(values[rowKey.ordinal()][columnKey.ordinal()])) {
            size++;
        }
        double prevValue = values[rowKey.ordinal()][columnKey.ordinal()];
        values[rowKey.ordinal()][columnKey.ordinal()] = value;
        return prevValue;
    }

    public double remove(R rowKey, C columnKey) {
        final double previousValue = values[rowKey.ordinal()][columnKey.ordinal()];
        if (!isEmpty(previousValue)) {
            --size;
        }
        values[rowKey.ordinal()][columnKey.ordinal()] = EMPTY;
        return previousValue;
    }

    public void clear() {
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                remove(rowsKeyUniverse[r], columnsKeyUniverse[c]);
            }
        }
    }

    public final void copyRow(R row, double[] target) {
        GcFriendlyAssert.notNull(row);
        final double[] rowValues = values[row.ordinal()];
        final int max = rowValues.length;
        int i = 0;
        final int maxTargetSize = target.length;
        for (int rIdx = 0; rIdx < max; rIdx++) {
            if (!isEmpty(rowValues[rIdx])) {
                if (i >= maxTargetSize) {
                    return;
                }
                target[i] = rowValues[rIdx];
                i++;
            }
        }
    }

    public final void forEachRowKey(Consumer<R> action) {
        GcFriendlyAssert.notNull(action);
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (!isEmpty(values[r][c])) {
                    action.accept(rowsKeyUniverse[r]);
                    break;
                }
            }
        }
    }

    public final void forEachRowKeyWithColumnKey(ObjDoubleConsumer<R> action, C columnKey) {
        GcFriendlyAssert.notNull(action);
        int columnIndex = columnKey.ordinal();
        GcFriendlyAssert.isTrue(columnKey == columnsKeyUniverse[columnIndex]);

        for (int r = 0; r < rowCapacity; r++) {
            if (!isEmpty(values[r][columnIndex])) {
                action.accept(rowsKeyUniverse[r], values[r][columnIndex]);
            }
        }
    }

    public final void forEachColumnKey(Consumer<C> action) {
        GcFriendlyAssert.notNull(action);
        for (int c = 0; c < columnCapacity; c++) {
            for (int r = 0; r < rowCapacity; r++) {
                if (!isEmpty(values[r][c])) {
                    action.accept(columnsKeyUniverse[c]);
                    break;
                }
            }
        }
    }

    public void forEach(ObjObjDoubleConsumer<R, C> action) {
        GcFriendlyAssert.notNull(action);
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if (!isEmpty(values[r][c])) {
                    action.accept(rowsKeyUniverse[r], columnsKeyUniverse[c], values[r][c]);
                }
            }
        }
    }

    public final void forEachColumnKeyWithRowKey(ObjDoubleConsumer<C> action, R rowKey) {
        GcFriendlyAssert.notNull(action);
        int rowIndex = rowKey.ordinal();
        GcFriendlyAssert.isTrue(rowKey == rowsKeyUniverse[rowIndex]);
        // TODO: optimise - minKeyValue, maxKeyValue?
        for (int c = 0; c < columnCapacity; c++) {
            if (!isEmpty(values[rowIndex][c])) {
                action.accept(columnsKeyUniverse[c], values[rowIndex][c]);
            }
        }
    }

    public boolean removeIf(ObjObjDoublePredicate<R, C> filter) {
        GcFriendlyAssert.notNull(filter);
        boolean rv = false;
        for (int r = 0; r < rowCapacity; r++) {
            for (int c = 0; c < columnCapacity; c++) {
                if ((!isEmpty(values[r][c])) && filter.test(rowsKeyUniverse[r], columnsKeyUniverse[c], values[r][c])) {
                    remove(rowsKeyUniverse[r], columnsKeyUniverse[c]);
                    rv = true;
                }
            }
        }
        return rv;
    }

    @NotGcFriendly
    public String toString() {
        final ToStringHelpers.CollectTableValues toStringCollector = new ToStringHelpers.CollectTableValues();
        forEach(toStringCollector);
        return toStringCollector.toString();
    }

    @NotGcFriendly
    public String toStringRow(final R rowKey) {
        final ToStringHelpers.CollectMapValues toStringCollector = new ToStringHelpers.CollectMapValues();
        forEachColumnKeyWithRowKey(toStringCollector, rowKey);
        return toStringCollector.toString();
    }

    @NotGcFriendly
    public String toStringColumn(final C columnKey) {
        final ToStringHelpers.CollectMapValues toStringCollector = new ToStringHelpers.CollectMapValues();
        forEachRowKeyWithColumnKey(toStringCollector, columnKey);
        return toStringCollector.toString();
    }
}
