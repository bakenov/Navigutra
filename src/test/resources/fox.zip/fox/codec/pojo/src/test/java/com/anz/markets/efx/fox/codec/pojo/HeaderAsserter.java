package com.anz.markets.efx.fox.codec.pojo;

import com.anz.markets.efx.ngaro.codec.Header;

import static org.junit.Assert.assertEquals;

public class HeaderAsserter {
    public static void assertHeader(final Header expectedHeader, final Header header) {
        assertEquals("source not as expected", expectedHeader.source(), header.source());
        assertEquals("sourceSeq not as expected", expectedHeader.sourceSeq(), header.sourceSeq());
    }

    public static void assertHeader(final Header expectedHeader, final int source, final long sourceSeq) {
        assertEquals("source not as expected", expectedHeader.source(), source);
        assertEquals("sourceSeq not as expected", expectedHeader.sourceSeq(), sourceSeq);
    }

    private HeaderAsserter() {
        throw new RuntimeException("No HeaderAsserter for you!");
    }
}
