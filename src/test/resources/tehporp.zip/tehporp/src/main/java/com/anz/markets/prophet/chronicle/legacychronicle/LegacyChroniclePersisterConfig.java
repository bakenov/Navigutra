package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.Append;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.PersisterConfig;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.core.threads.EventLoop;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.function.Predicate;

public class LegacyChroniclePersisterConfig implements PersisterConfig {
    protected static final Logger LOGGER = LogManager.getLogger(LegacyChroniclePersisterConfig.class);
    public static final ChronicleHook BEFORE_WRITE_THEN_BEFORE_WRITE = ChronicleHook.COMMON_BEFORE_WRITE.then(ChronicleHook.CORE_BEFORE_WRITE);

    private final String chroniclePath;
    private final LegacyChroniclePersister.OpenMode openMode;
    private final LegacyChronicleConfig.ChronicleType chronicleType;
    private final ChronicleHook beforeWrite;
    private final ChronicleHook afterWrite;
    private final Append append;
    private final ActivationAware activationAware;

    public LegacyChroniclePersisterConfig(final String chroniclePath,
                                          final LegacyChroniclePersister.OpenMode openMode,
                                          final LegacyChronicleConfig.ChronicleType chronicleType,
                                          final ChronicleHook beforeWrite,
                                          final ChronicleHook afterWrite,
                                          final Append append,
                                          final ActivationAware activationAware) {

        this.chroniclePath = chroniclePath;
        this.openMode = openMode;
        this.chronicleType = chronicleType;
        this.beforeWrite = beforeWrite;
        this.afterWrite = afterWrite;
        this.append = append;
        this.activationAware = activationAware;
    }

    // todo: need test case
    public Chronicle createChronicle(String chroniclePath) throws IOException {
        deleteChronicleIfOpenInOverwriteMode();

        return LegacyChronicleConfig.createChronicle(chroniclePath, chronicleType, LegacyChronicleConfig.ReadWrite.READ_WRITE);
    }

    private void deleteChronicleIfOpenInOverwriteMode() throws IOException {
        if (openMode == LegacyChroniclePersister.OpenMode.OVERWRITE) {
            LOGGER.warn("Chronicle persister in overwrite mode. Deleting existing chronicle files: {}", chroniclePath);
            for (final String extension : new String[]{".data", ".index"}) {
                final File file = new File(chroniclePath + extension);
                if (file.exists() && !file.delete()) {
                    throw new IOException("Unable to delete " + chroniclePath + extension + " chronicle data file.");
                }
            }
        }
    }

    public static LegacyChroniclePersisterConfig unchanged(final String chroniclePath,
                                                           final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChroniclePersisterConfig(chroniclePath, LegacyChroniclePersister.OpenMode.APPEND, chronicleType,
                ChronicleHook.DO_NOTHING, ChronicleHook.DO_NOTHING, Append.ALL, ActivationAware.NO);
    }

    public static LegacyChroniclePersisterConfig starfishOut(final String chroniclePath,
                                                             final LegacyChroniclePersister.OpenMode openMode,
                                                             final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChroniclePersisterConfig(chroniclePath, openMode, chronicleType,
                ChronicleHook.COMMON_BEFORE_WRITE.then(ChronicleHook.BEFORE_WRITE),
                ChronicleHook.DO_NOTHING, Append.ALL, ActivationAware.NO);
    }

    public static LegacyChroniclePersisterConfig testIn(final String chroniclePath,
                                                        final LegacyChroniclePersister.OpenMode openMode,
                                                        final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChroniclePersisterConfig(chroniclePath, openMode, chronicleType,
                ChronicleHook.eventInception(), ChronicleHook.DO_NOTHING, Append.ALL, ActivationAware.NO);
    }


    public static LegacyChroniclePersisterConfig starfishIn(final String chroniclePath,
                                                            final LegacyChroniclePersister.OpenMode openMode,
                                                            final LegacyChronicleConfig.ChronicleType chronicleType) {
        return new LegacyChroniclePersisterConfig(chroniclePath, openMode, chronicleType,
                ChronicleHook.eventInception(), ChronicleHook.DO_NOTHING, Append.ALL, ActivationAware.NO);
    }

    public static LegacyChroniclePersisterConfig core(final String chroniclePath,
                                                      final LegacyChroniclePersister.OpenMode openMode,
                                                      final LegacyChronicleConfig.ChronicleType chronicleType,
                                                      final ActivationAware activationMode) {
        return new LegacyChroniclePersisterConfig(chroniclePath, openMode, chronicleType,
                BEFORE_WRITE_THEN_BEFORE_WRITE,
                ChronicleHook.CORE_AFTER_WRITE, Append.ONLY_AFTER_LAST_EVENTID, activationMode);
    }

    public String chroniclePath() {
        return chroniclePath;
    }

    @Override
    public boolean active() {
        // NOTE: Legacy CQ3 code
        throw new UnsupportedOperationException();
    }

    @Override
    public Predicate<MessageType> messageTypePredicate() {
        // NOTE: Legacy CQ3 code
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean multipleWriterThreads() {
        // NOTE: Legacy CQ3 code
        throw new UnsupportedOperationException();
    }

    @Override
    public Append append() {
        return append;
    }

    @Override
    public ChronicleHook beforeWrite() {
        return beforeWrite;
    }

    @Override
    public ChronicleHook afterWrite() {
        return afterWrite;
    }

    @Override
    public RingBuffer ringBuffer() {
        throw new UnsupportedOperationException();
    }

    @Override
    public EventLoop eventLoop() {
        throw new UnsupportedOperationException();
    }

    @Override
    public ActivationAware activationAware() {
        return activationAware;
    }

    @Override
    public String toString() {
        return "LegacyChroniclePersisterConfig{" +
                "chroniclePath='" + chroniclePath + '\'' +
                ", chronicleType=" + chronicleType +
                ", beforeWrite=" + beforeWrite +
                ", append=" + append +
                ", activationAware=" + activationAware +
                '}';
    }
}
