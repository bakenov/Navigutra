package com.anz.axle.lg.adapter.cnx;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class CnxMarketDataSubscription implements MarketDataSubscription {

    private static final int DEFAULT_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK = true;

    private final String symbol;
    private final int marketDepth;
    private final boolean aggregateBook;
    private final boolean fullRefresh;
    private final InstrumentKey instrumentKey;
    private final StringToIntCache stringToIntCache;

    public CnxMarketDataSubscription(final String symbol, final int marketDepth, final boolean aggregateBook, final boolean fullRefresh, final StringToIntCache stringToIntCache) {
        this.symbol = Objects.requireNonNull(symbol);
        this.marketDepth = marketDepth;
        this.aggregateBook = aggregateBook;
        this.fullRefresh = fullRefresh;
        this.stringToIntCache = Objects.requireNonNull(stringToIntCache);
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), SecurityType.FXSPOT, Tenor.SP);
    }

    public static CnxMarketDataSubscription fullRefreshForIdAndSymbol(final String symbol, final boolean fullRefresh, final StringToIntCache stringToIntCache) {
        return new CnxMarketDataSubscription(symbol, DEFAULT_MARKET_DEPTH, DEFAULT_AGGREGATE_BOOK, fullRefresh, stringToIntCache);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return Venue.CNX;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public boolean fullRefresh() {
        return fullRefresh;
    }

    @Override
    public boolean aggregateBook() {
        return aggregateBook;
    }

    @Override
    public int marketDepth() {
        return marketDepth;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return stringToIntCache;
    }

    @Override
    public String toString() {
        return "CnxMarketDataSubscription{" +
                "id=" + instrumentKey.instrumentId() +
                ", symbol='" + symbol + '\'' +
                ", instrumentKey=" + instrumentKey +
                '}';
    }
}
