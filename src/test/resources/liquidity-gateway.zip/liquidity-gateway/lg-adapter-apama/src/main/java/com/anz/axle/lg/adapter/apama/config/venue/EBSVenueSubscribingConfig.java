package com.anz.axle.lg.adapter.apama.config.venue;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.apama.decoder.ApamaEventDecoder;
import com.anz.axle.lg.adapter.apama.decoder.EbsMarketDataIncrementalRefreshDecoder;
import com.anz.axle.lg.adapter.apama.decoder.EbsMarketDataSnapshotDecoder;
import com.anz.axle.lg.adapter.apama.decoder.EbsTradingSessionStatusDecoder;
import com.anz.axle.lg.adapter.apama.decoder.HeartbeatResponseDecoder;
import com.anz.axle.lg.adapter.apama.decoder.LoggedOffEventDecoder;
import com.anz.axle.lg.adapter.apama.ebs.DefaultEbsBookRules;
import com.anz.axle.lg.adapter.apama.ebs.EbsBookRules;
import com.anz.axle.lg.adapter.apama.ebs.EbsImplicitDeletionHandler;
import com.anz.axle.lg.adapter.apama.ebs.EventRequestKeyMatcher;
import com.anz.axle.lg.adapter.apama.ebs.EventToRequestKey;
import com.anz.axle.lg.adapter.apama.ebs.EventToTenor;
import com.anz.axle.lg.adapter.apama.ebs.EventToTranslatedSymbol;
import com.anz.axle.lg.adapter.apama.ebs.SettleTypeToTenor;
import com.anz.axle.lg.adapter.apama.event.EbsMarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.apama.event.EbsMarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.apama.event.EbsTradingSessionStatus;
import com.anz.axle.lg.adapter.apama.event.HeartbeatResponse;
import com.anz.axle.lg.adapter.apama.event.LoggedOff;
import com.anz.axle.lg.adapter.apama.transport.Connection;
import com.anz.axle.lg.adapter.apama.transport.ConnectionConfig;
import com.anz.axle.lg.adapter.apama.transport.ConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.MarketDataBooksClearingConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.Subscription;
import com.anz.axle.lg.adapter.apama.transport.Transport;
import com.anz.axle.lg.config.DefaultPricingEncoderLookup;
import com.anz.axle.lg.config.MarketDataRequestConfig;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.config.SbeMessagePublisher;
import com.anz.axle.lg.config.SnapshotterAccessor;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.config.VenueSymbolValidator;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamEncoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries.Factory;

@Configuration
public class EBSVenueSubscribingConfig {
    private static final Venue VENUE = Venue.EBS;

    private final String marketdataTransport;
    private final Map<String, String> spotSymbolMap;
    private final Map<String, String> ndfSymbolMap;
    private final String compId;
    private final String senderCompId;
    private final int source;



    public EBSVenueSubscribingConfig(final @Value("${apama.iaf.marketdata.transport.EBS}") String marketdataTransport,
                                     final @Value("#{${ebs.symbol.map.FXSPOT}}") Map<String, String> spotSymbolMap,
                                     final @Value("#{${ebs.symbol.map.FXNDF}}") Map<String, String> ndfSymbolMap,
                                     final @Value("${messaging.compId}") String compId,
                                     final @Value("${messaging.EBS.compId}") String senderCompId,
                                     final @Value("${messaging.source}") int source) {
        this.marketdataTransport = Objects.requireNonNull(marketdataTransport);
        this.spotSymbolMap = Objects.requireNonNull(spotSymbolMap);
        this.ndfSymbolMap = Objects.requireNonNull(ndfSymbolMap);
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.source = source;
    }

    @Bean
    public SourceSequencer sourceSequencer(@Value("${messaging.source.id}") final int sourceId) {
        return SourceSequencer.of(sourceId);
    }

    @Bean
    protected ConnectionConfig ebsConnectionConfig(final @Value("${apama.iaf.host.EBS}") String host,
                                                   final @Value("${apama.iaf.port.EBS}") int port,
                                                   final @Value("${apama.connectionPollingInterval:30000}") int connectionPollingInterval) {
        return new DefaultConnectionConfig(VENUE, host, port, connectionPollingInterval);
    }

    @Bean
    protected VenueRequestKeyLookup ebsVenueRequestKeyLookup() {
        return new DefaultVenueRequestKeyLookup(VENUE);
    }

    @Bean
    protected EbsImplicitDeletionHandler ebsImplicitDeletionHandler(final PrecisionClock precisionClock,
                                                                    @Value("#{${ebs.bookRules.map.FXSPOT}}") final Map<String, double[]> fxSpotBookRules,
                                                                    @Value("#{${ebs.bookRules.map.FXNDF}}") final Map<String, double[]> fxNdfBookRules) {
        final EbsBookRules ebsBookRules = new DefaultEbsBookRules(fxSpotBookRules, fxNdfBookRules);
        return new EbsImplicitDeletionHandler(precisionClock, ebsBookRules);
    }

    @Bean(destroyMethod = "clearAllBooksAndForwardEmptySnapshots")
    protected PricingEncoderLookup pricingEncoderLookup(final Function<Consumer<SbeMessage>, PricingEncoderSupplier> pricingEncoderSupplierFactory,
                                                        final PrecisionClock precisionClock,
                                                        final @Value("${market.data.book.initial.size:10}") int marketDataBookInitialSize,
                                                        final LongIdFactory messageIdFactory,
                                                        final TopicRegistry pricingTopicRegistry,
                                                        final MessageHandler publisher,
                                                        final EbsImplicitDeletionHandler ebsImplicitDeletionHandler) {
        return new DefaultPricingEncoderLookup(pricingTopicRegistry, requestKey -> {
            final SnapshotterBuilder builder = SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, marketDataBookInitialSize, DefaultMarketDataEntry::new, Factory.SIDE_PRICE))
                    .withDownstreamEncoder()
                    .forwardSnapshotsAndIncrementsTo(
                            pricingEncoderSupplierFactory.apply(SbeMessagePublisher.create(requestKey, pricingTopicRegistry, publisher)),
                            ebsImplicitDeletionHandler);

            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock,  messageIdFactory::get, compId, source);
            final UpstreamEncoderConnector upstreamEncoderConnector = builder.buildUpstreamEncoderConnector(UpdateTypeMismatchHandler.IGNORE_REPLACE_ON_ADD_AND_NOOP_ON_REMOVE);
            return SnapshotterAccessor.create(snapshotter, upstreamEncoderConnector);
        });
    }

    @Bean
    public MarketDataBooksClearingConnectionStatusHandler ebsConnectionStatusHandler(final PricingEncoderLookup ebsPricingEncoderLookup) {
        return new MarketDataBooksClearingConnectionStatusHandler(ebsPricingEncoderLookup);
    }

    @Bean
    protected Connection ebsApamaConnection(final Transport apamaTransport,
                                            final ConnectionConfig ebsConnectionConfig,
                                            final ConnectionStatusHandler ebsConnectionStatusHandler) {
        return apamaTransport.openConnection(ebsConnectionConfig, ebsConnectionStatusHandler);
    }

    @Bean
    protected ApamaEventDecoder ebsLoggedOffEventDecoder(final PricingEncoderLookup ebsPricingEncoderLookup) {
        return new LoggedOffEventDecoder(ebsPricingEncoderLookup, marketdataTransport);
    }

    @Bean
    protected ApamaEventDecoder ebsTradingSessionStatusDecoder(final PricingEncoderLookup ebsPricingEncoderLookup) {
        return new EbsTradingSessionStatusDecoder(ebsPricingEncoderLookup, marketdataTransport);
    }

    @Bean
    protected ApamaEventDecoder ebsHeartbeatResponseDecoder(final PricingEncoderLookup ebsPricingEncoderLookup) {
        return new HeartbeatResponseDecoder(ebsPricingEncoderLookup, marketdataTransport);
    }

    @Bean
    protected EventToTranslatedSymbol ebsEntryEventToTranslatedSymbol() {
        return EventToTranslatedSymbol.forEntryEvent(spotSymbolMap, ndfSymbolMap);
    }

    @Bean
    protected EventToTranslatedSymbol ebsMessageEventToTranslatedSymbol() {
        return EventToTranslatedSymbol.forMessageEvent(spotSymbolMap, ndfSymbolMap);
    }

    @Bean
    protected SettleTypeToTenor ebsSettleTypeToTenor() {
        return new SettleTypeToTenor();
    }

    @Bean
    protected EventToTenor ebsEntryEventToTenor(final SettleTypeToTenor ebsSettleTypeToTenor) {
        return EventToTenor.forEntryEvent(ebsSettleTypeToTenor);
    }

    @Bean
    protected EventToTenor ebsMessageEventToTenor(final SettleTypeToTenor ebsSettleTypeToTenor) {
        return EventToTenor.forMessageEvent(ebsSettleTypeToTenor);
    }

    @Bean
    protected BiPredicate<SecurityType, String> ebsSybmolValidator(final MarketDataRequestConfig marketDataRequestConfig) {
        return new VenueSymbolValidator(marketDataRequestConfig, VENUE);
    }

    @Bean
    protected EventToRequestKey ebsEntryEventToRequestKey(final BiPredicate<SecurityType, String> ebsSybmolValidator,
                                                          final VenueRequestKeyLookup ebsVenueRequestKeyLookup,
                                                          final EventToTenor ebsEntryEventToTenor,
                                                          final EventToTranslatedSymbol ebsEntryEventToTranslatedSymbol) {
        return EventToRequestKey.forEntryEvent(ebsSybmolValidator, ebsVenueRequestKeyLookup, ebsEntryEventToTranslatedSymbol, ebsEntryEventToTenor);
    }

    @Bean
    protected EventToRequestKey ebsMessageEventToRequestKey(final BiPredicate<SecurityType, String> ebsSybmolValidator,
                                                            final VenueRequestKeyLookup ebsVenueRequestKeyLookup,
                                                            final EventToTenor ebsMessageEventToTenor,
                                                            final EventToTranslatedSymbol ebsMessageEventToTranslatedSymbol) {
        return EventToRequestKey.forMessageEvent(ebsSybmolValidator, ebsVenueRequestKeyLookup, ebsMessageEventToTranslatedSymbol, ebsMessageEventToTenor);
    }

    @Bean
    protected EventRequestKeyMatcher ebsEntryEventRequestKeyMatcher(final EventToTranslatedSymbol ebsEntryEventToTranslatedSymbol,
                                                                    final EventToTenor ebsEntryEventToTenor) {
        return EventRequestKeyMatcher.forEntryEvent(ebsEntryEventToTranslatedSymbol, ebsEntryEventToTenor);
    }

    @Bean
    protected ApamaEventDecoder ebsApamaIncrementalRefreshEventDecoder(final EventToRequestKey ebsEntryEventToRequestKey,
                                                                       final EventRequestKeyMatcher ebsEntryEventRequestKeyMatcher,
                                                                       final PricingEncoderLookup ebsPricingEncoderLookup,
                                                                       final PrecisionClock precisionClock,
                                                                       final LongIdFactory messageIdFactory,
 final SourceSequencer sourceSequencer) {
        return new EbsMarketDataIncrementalRefreshDecoder(ebsEntryEventToRequestKey, ebsEntryEventRequestKeyMatcher, ebsPricingEncoderLookup, precisionClock, senderCompId, compId, messageIdFactory::get, sourceSequencer);
    }

    @Bean
    protected ApamaEventDecoder ebsApamaSnapshotEventDecoder(final EventToRequestKey ebsMessageEventToRequestKey,
                                                             final PricingEncoderLookup ebsPricingEncoderLookup,
                                                             final PrecisionClock precisionClock,
                                                             final LongIdFactory messageIdFactory,
                                                             final SourceSequencer sourceSequencer) {
        return new EbsMarketDataSnapshotDecoder(ebsMessageEventToRequestKey, ebsPricingEncoderLookup, precisionClock, senderCompId, compId, messageIdFactory::get, sourceSequencer);
    }

    @Bean
    protected Subscription ebsIncrementalRefreshSubscription(final Connection ebsApamaConnection,
                                                             final ApamaEventDecoder ebsApamaIncrementalRefreshEventDecoder) {
        return ebsApamaConnection.openSubscription(EbsMarketDataIncrementalRefresh.EVENT_TYPE, ebsApamaIncrementalRefreshEventDecoder::decode);
    }

    @Bean
    protected Subscription ebsSnapshotSubscription(final Connection ebsApamaConnection,
                                                   final ApamaEventDecoder ebsApamaSnapshotEventDecoder) {
        return ebsApamaConnection.openSubscription(EbsMarketDataSnapshotFullRefresh.EVENT_TYPE, ebsApamaSnapshotEventDecoder::decode);
    }

    @Bean
    protected Subscription ebsLoggedOffSubscription(final Connection ebsApamaConnection,
                                                    final ApamaEventDecoder ebsLoggedOffEventDecoder) {
        return ebsApamaConnection.openSubscription(LoggedOff.EVENT_TYPE, ebsLoggedOffEventDecoder::decode);
    }

    @Bean
    protected Subscription ebsTradingSessionStatusSubscription(final Connection ebsApamaConnection,
                                                               final ApamaEventDecoder ebsTradingSessionStatusDecoder) {
        return ebsApamaConnection.openSubscription(EbsTradingSessionStatus.EVENT_TYPE, ebsTradingSessionStatusDecoder::decode);
    }

    @Bean
    protected Subscription ebsHeartbeatResponseSubscription(final Connection ebsApamaConnection,
                                                            final ApamaEventDecoder ebsHeartbeatResponseDecoder) {
        return ebsApamaConnection.openSubscription(HeartbeatResponse.EVENT_TYPE, ebsHeartbeatResponseDecoder::decode);
    }

    @Bean
    protected VenuePublications ebsVenuePublications(final TopicRegistry pricingTopicRegistry,
                                                     final PublicationRegistry publicationRegistry,
                                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                                     @Value("#{${symbol.venues.FXNDF}}") final Map<String, Set<Venue>> fxNdfSymbolVenues) {

        return new VenuePublications(VENUE, pricingTopicRegistry, publicationRegistry, fxSpotSymbolVenues, fxNdfSymbolVenues);
    }

    @Autowired
    @Qualifier("ebsVenuePublications")
    private VenuePublications ebsVenuePublications;

    @PostConstruct
    public void init() {
        ebsVenuePublications.init();
    }

}