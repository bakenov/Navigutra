package com.anz.axle.direct.performance;

import com.anz.axle.direct.performance.metrics.BasicStats;
import com.anz.axle.direct.performance.metrics.Count;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.axle.direct.performance.metrics.Rates;
import com.anz.markets.prophet.status.Context;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.NumberFormat;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

public class SplunkLoggingMetricReporter implements MetricReporter {
    private static final Logger LOGGER = LoggerFactory.getLogger("metrics");
    public static final String DATE_TIME_FORMAT = "yyyy.MM.dd'D'HH:mm:ss.SSS";
    private static DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern(DATE_TIME_FORMAT).withZone(DateTimeZone.UTC);
    private final NumberFormat numberFormat;

    @Deprecated // todo: Delete on next release, we are already monitoring the metrics via KDB dashboards
    public SplunkLoggingMetricReporter() {
        numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setGroupingUsed(false);
        numberFormat.setMaximumFractionDigits(0);
        numberFormat.setMinimumFractionDigits(0);
    }

    @Override
    public void appendCounts(final Collection<Count> counters) {
        // not implemented
    }

    @Override
    public void appendBasicStats(final Collection<BasicStats> basicStatsList) {
        // not implemented
    }

    @Override
    public void appendHistograms(final Collection<Percentiles> percentilesList) {
        for (final Percentiles percentiles : percentilesList) {
            LOGGER.info("time={} type=HISTOGRAM, name={}, count={}, min={}, max={}, mean={}, " +
                            "median={}, p75={}, p95={}, p98={}, p99={}, p999={}",
                    DATE_TIME_FORMATTER.print(TimeUnit.NANOSECONDS.toMillis(Context.context().header().getEventTimeStampNS())),
                    percentiles.getName(),
                    percentiles.getCount(),
                    formatDouble(percentiles.getMin()),
                    formatDouble(percentiles.getMax()),
                    formatDouble(percentiles.getMean()),
                    formatDouble(percentiles.getPercentile(50.0)),
                    formatDouble(percentiles.getPercentile(75.0)),
                    formatDouble(percentiles.getPercentile(95.0)),
                    formatDouble(percentiles.getPercentile(98.0)),
                    formatDouble(percentiles.getPercentile(99.0)),
                    formatDouble(percentiles.getPercentile(99.9)));
        }
    }

    private String formatDouble(final double d) {
        return Double.isNaN(d) ? "0" : numberFormat.format(d);
    }

    @Override
    public void appendRates(final Collection<Rates> ratesList) {
        // not implemented
    }

    @Override
    public void beginReports() {
        // not implemented
    }

    @Override
    public void endReports() {
        // not implemented
    }

}
