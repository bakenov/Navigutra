package com.anz.markets.efx.ngaro.collections;

@FunctionalInterface
public interface ObjObjDoublePredicate<T, U> {

    boolean test(T t, U u, double v);
}
