#!/bin/bash

source ~/bin/shell-env/daxa009s/.dev-and-qa-hosts
source ~/bin/shell-env/daxa009s/.functions

ssh_background_all "nohup ~/bin/stats-scripts/log-vmstat.sh"
ssh_background_all "nohup ~/bin/stats-scripts/log-iostat.sh"

