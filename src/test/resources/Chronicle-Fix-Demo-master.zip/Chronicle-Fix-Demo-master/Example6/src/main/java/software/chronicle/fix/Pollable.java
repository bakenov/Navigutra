package software.chronicle.fix;

import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import java.util.concurrent.TimeUnit;

/**
 * Created by Jerry Shea on 13/11/18.
 */
public interface Pollable {

    FixLog poll(long timeout, TimeUnit timeUnit) throws InterruptedException;
}
