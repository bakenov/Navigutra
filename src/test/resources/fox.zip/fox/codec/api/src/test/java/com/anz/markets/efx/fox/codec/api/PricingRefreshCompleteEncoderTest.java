package com.anz.markets.efx.fox.codec.api;


import org.junit.Test;


import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

public class PricingRefreshCompleteEncoderTest {
    @Test
    public void encoderChaining() {
        final PricingRefreshCompleteEncoder encoder = mock(PricingRefreshCompleteEncoder.class, RETURNS_DEEP_STUBS);

        encoder.messageStart(2, 3)
                .instrumentId(4)
                .forceSnapshot(true)
                .messageComplete();
    }
}