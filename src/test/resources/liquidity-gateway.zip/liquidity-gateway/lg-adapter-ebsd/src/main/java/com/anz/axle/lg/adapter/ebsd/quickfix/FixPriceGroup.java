package com.anz.axle.lg.adapter.ebsd.quickfix;

import java.util.List;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.MDEntryType;

public class FixPriceGroup {
    private FixPriceGroup() {}

    public static List<Group> getPriceGroupsAndHandleEmptyBookCase(final Message message) throws FieldNotFound {
        final List<Group> groups = message.getGroups(quickfix.field.NoMDEntries.FIELD);
        // check if a special 'empty book' case:
        if (groups!=null && groups.size()==1 && groups.get(0).isSetField(MDEntryType.FIELD) && groups.get(0).getChar(MDEntryType.FIELD) == MDEntryType.EMPTY_BOOK) {
            return null;
        }
        return groups;
    }
}
