package com.anz.markets.efx.ngaro.core;

import java.nio.ByteBuffer;

@FunctionalInterface
public interface ByteReader<S> {
    byte readByte(S source, int index);

    ByteReader<AsciiString> ASCII_STRING = (s, i) -> s.get(i);
    ByteReader<CharSequence> CHAR_SEQUENCE = (s, i) -> (byte)s.charAt(i);
    ByteReader<ByteBuffer> BYTE_BUFFER = (s, i) -> s.get(i);
    ByteReader<byte[]> BYTE_ARRAY = (s, i) -> s[i];
}
