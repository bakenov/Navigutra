package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.ActivationProcessor;
import com.anz.markets.prophet.tools.ReadChronicle;
import com.anz.markets.prophet.util.SystemProperties;
import com.google.common.base.Supplier;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import net.openhft.chronicle.core.Jvm;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.runners.Parameterized;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.anz.markets.prophet.util.ThreadUtils.sleep;
import static org.junit.Assert.assertEquals;

/**
 * Good idea to set
 * <Logger name="com.anz.markets.prophet.chronicle" level="trace"/>
 * in log4j2.xml
 */
public class ChronicleFailoverTestBase {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ChronicleFailoverTestBase.class);
    protected static final int CORE_0 = 0, CORE_1 = 1;
    protected ExecutorService executorIn0 = executor("IN" + 0);
    protected ExecutorService executorIn1 = executor("IN" + 1);
    protected ExecutorService executorOut = executor("OUT");
    protected ProphetPersister chronicleInPersister;
    protected ProphetPersister chronicleOutPersister0, chronicleOutPersister1;
    protected ProphetReader chronicleInReader0, chronicleInReader1;
    protected ProphetReader chronicleOutReader;
    protected AccumulatingConsumer<Activate> activateConsumer;
    protected AccumulatingConsumer<Trade> tradeConsumer;
    protected static int id = 0;
    private String basePathIn;
    private String basePathOut;
    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    private ExecutorService executor(final String id) {
        return Executors.newSingleThreadExecutor(new ThreadFactoryBuilder().setNameFormat(id).build());
    }

    @Before
    public void setup() throws IOException {
        setupExtra();

        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;

        basePathIn = queueFileNameForTest("in");
        basePathOut = queueFileNameForTest("out");

        {
            // create a single persister to chronicle.in
            LOGGER.warn("Input: {}", basePathIn);
            chronicleInPersister = ChroniclePersisterFactory.createStarInPersister(basePathIn, LegacyChroniclePersister.OpenMode.APPEND);
        }

        {
            // create two persisters to chronicle.out. Initially 0 is active, 1 is inactive
            LOGGER.warn("Output: {}", basePathOut);
            chronicleOutPersister0 = ChroniclePersisterFactory.createCorePersister(basePathOut, LegacyChroniclePersister.OpenMode.APPEND, ActivationAware.YES, true, Predicates.alwaysTrue());
            chronicleOutPersister1 = ChroniclePersisterFactory.createCorePersister(basePathOut, LegacyChroniclePersister.OpenMode.APPEND, ActivationAware.YES, false, Predicates.alwaysTrue());
            populateInitialData();
        }

        {
            // two readers to pass from chronicle.in to one each of the persisters to chronicle.out
            chronicleInReader0 = createChronicleInReaderCore(CORE_0, chronicleOutPersister0, executorIn0, basePathIn);
            chronicleInReader1 = createChronicleInReaderCore(CORE_1, chronicleOutPersister1, executorIn1, basePathIn);
        }

        {
            // reader from chronicle out to check what gets written there
            activateConsumer = new AccumulatingConsumer<>(Activate::new);
            final ChronicleReaderGeneric<Activate> activationReader = new ChronicleReaderGeneric<>(new Activate(), activateConsumer);
            tradeConsumer = new AccumulatingConsumer<>(TradeImpl::new);
            final TradeReader tr = new TradeReader(tradeConsumer);
            final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
            map.put(MessageType.TRADE, tr);
            map.put(MessageType.ACTIVATE, activationReader);
            chronicleOutReader = ChronicleReaderFactory.createSimpleReader(executorOut, new ChronicleObjectReaderMulti(map), basePathOut, StartAt.START, RingBuffer.NO_RING);
        }
    }

    protected void setupExtra() {
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    @NotNull
    protected String queueFileNameForTest(final String postfix) throws IOException {
        return FileUtil.tmpFile(this.getClass().getSimpleName(), postfix);
    }

    protected void populateInitialData() {
    }

    protected ProphetReader createChronicleInReaderCore(final int coreId,
                                                                final ProphetPersister prophetPersister,
                                                                final ExecutorService executor,
                                                                final String basePathIn) throws IOException {
        final ActivationProcessor activationProcessor = new ActivationProcessor(prophetPersister.sink(MessageType.ACTIVATE), coreId);
        final ChronicleReaderGeneric<Activate> activationReader = new ChronicleReaderGeneric<>(new Activate(), activationProcessor);
        final TradeReader tr = new TradeReader(prophetPersister.sink(MessageType.TRADE));
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.TRADE, tr);
        map.put(MessageType.ACTIVATE, activationReader);
        return ChronicleReaderFactory.createSimpleReader(executor, new ChronicleObjectReaderMulti(map), basePathIn, StartAt.START, RingBuffer.NO_RING);
    }

    @After
    public void teardown() throws IOException {
        chronicleInPersister.close();
        chronicleInReader0.close();
        chronicleInReader1.close();

        chronicleOutReader.close();
        chronicleOutPersister0.close();
        chronicleOutPersister1.close();
    }

    protected void doFailover(int activation, int trades) {
        try {
            checkTradesActivation(activation + 0, trades + 0);

            final TradeImpl tradeToWrite = createTrade();
            final Activate activate = createActivate();

            LOGGER.warn("Start on core 0");
            sendTrades(tradeToWrite, 5);
            checkTradesActivation(activation + 0, trades + 5);

            LOGGER.warn("Flipping to core 1");
            sendActivate(activate, 1);
            sendTrades(tradeToWrite, 3);
            checkTradesActivation(activation + 1, trades + 8);

            LOGGER.warn("Flipping to core 0");
            sendActivate(activate, 0);
            sendTrades(tradeToWrite, 2);
            checkTradesActivation(activation + 2, trades + 10);

            LOGGER.warn("Flipping to core 1 again");
            sendActivate(activate, 1);
            // send no trades this time
            checkTradesActivation(activation + 3, trades + 10);

            LOGGER.warn("Flipping to core 0 again");
            sendActivate(activate, 0);
            sendTrades(tradeToWrite, 1);
            checkTradesActivation(activation + 4, trades + 11);
        } catch (Throwable e) {
            troubleshoot();
            Jvm.rethrow(e);
        }
    }

    private void dumpQueues(String msg) {
        try {
            System.out.println(msg+" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> In Q");
            ReadChronicle.main(basePathIn);
            System.out.println(msg+" Out Q");
            ReadChronicle.main(basePathOut);
            System.out.println(msg+" <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
        } catch (Exception e) {
            Jvm.rethrow(e);
        }
    }

    private void troubleshoot() {
        dumpQueues("trouble");
        troubleshoot("activate", activateConsumer);
        troubleshoot("trades  ", tradeConsumer);
    }

    private void troubleshoot(final String name, final AccumulatingConsumer consumer) {
        System.out.println(name + ": " + consumer.getEventIds());
        System.out.println(name + ": " + consumer.getEvents());
    }

    protected TradeImpl createTrade() {
        final TradeImpl trade = MidRateTestHelper.createTrade(Instrument.AUDUSD, OrderSide.BID, 1000, 1.345);
        trade.setInceptionTimeNanos(Context.context().timeSource().nowNanos());
        return trade;
    }

    protected Activate createActivate() {
        return new Activate();
    }

    protected void checkTradesActivation(final int actions, final int trades) {
        // wait for background threads. ANZ dev laptops can be slow so go round a few times
        for (int i=0; i<20 && (trades!=tradeConsumer.getEvents().size() || actions!=activateConsumer.getEvents().size()); i++) {
            sleep(SystemProperties.ACTIVATE_PAUSE_MS);
        }
        assertEquals("correct number of trades arrived", trades, tradeConsumer.getEvents().size());
        assertEquals("correct number of activations arrived", actions, activateConsumer.getEvents().size());
        int c = 0;
        for (Trade t : tradeConsumer.getEvents()) {
            assertEquals("trades in sequence", c, t.getInceptionTimeNanos());
            c++;
        }
    }

    protected void sendTrades(final TradeImpl tradeToWrite, int max) {
        for (int i = 0; i < max; i++) {
            tradeToWrite.setInceptionTimeNanos(id++);
            chronicleInPersister.sink(MessageType.TRADE).accept(tradeToWrite);
        }
    }

    protected void sendActivate(final Activate activate, int core) {
        activate.setInstanceToActivate(core);
        chronicleInPersister.sink(MessageType.ACTIVATE).accept(activate);
    }

    static class AccumulatingConsumer<T> extends TestStubConsumer<T> {
        final List<Header> headers = new ArrayList<>();

        public AccumulatingConsumer(final Supplier<T> supplier) {
            super(supplier);
        }

        @Override
        public void accept(final T t) {
            final Header header = new Header();
            this.copier.copy(Context.context().header(), header);
            headers.add(header);
            super.accept(t);
        }
    }
}
