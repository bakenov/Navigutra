package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.ngaro.codec.EnumSetDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.SimpleStringDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoUserConfigDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends UserConfigHandler> handlerSupplier;

    public PojoUserConfigDecoder(final Supplier<? extends UserConfigHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof UserConfig) {
            return decode((UserConfig) sorMessage);
        }
        return false;
    }

    public boolean decode(final UserConfig message) {
        final UserConfigHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source,message.header.sourceSeq);
        handler.onBody(new UserConfigHandler.Body() {
            final StringDecoder userName = new SimpleStringDecoder(() -> message.body.userName);
            final StringDecoder location = new SimpleStringDecoder(() -> message.body.location);
            final EnumerableSetDecoder<UserGroup> userGroups = new EnumSetDecoder<>(UserGroup::length, UserGroup::valueByOrdinal, message.body.userGroups);

            @Override
            public StringDecoder userName() {
                return userName;
            }

            @Override
            public EnumerableSetDecoder<UserGroup> userGroups() {
                return userGroups;
            }

            @Override
            public StringDecoder location() {
                return location;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoUserConfigDecoder() {
        throw new RuntimeException("No PojoUserConfigDecoder for you!");
    }
}
