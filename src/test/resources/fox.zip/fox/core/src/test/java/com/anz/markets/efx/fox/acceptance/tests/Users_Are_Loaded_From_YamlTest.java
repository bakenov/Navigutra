package com.anz.markets.efx.fox.acceptance.tests;

import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.matcher.UserConfigMatcher;
import com.anz.markets.efx.matcher.Asserter;

@RunWith(Spockito.class)
public class Users_Are_Loaded_From_YamlTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(Users_Are_Loaded_From_YamlTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("user.config.class.path", "conf/user-config-test.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_see_user_created_commands_and_events_on_startup() throws Exception {

        final UserConfigMatcher test123Matcher = UserConfigMatcher.build()
                .body().matches(UserConfigMatcher.userName().eq("test123"))
                .body().matches(UserConfigMatcher.userGroups().eq(EnumSet.of(UserGroup.TRADER, UserGroup.ADMIN)))
                .body().matches(UserConfigMatcher.location().eq("Melbourne"));

        final UserConfigMatcher test234Matcher = UserConfigMatcher.build()
                .body().matches(UserConfigMatcher.userName().eq("test234"))
                .body().matches(UserConfigMatcher.userGroups().eq(EnumSet.of(UserGroup.TRADER)))
                .body().matches(UserConfigMatcher.location().eq("Tokyo"));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(test123Matcher)
                .thenMatching(test234Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(test123Matcher)
                .thenMatching(test234Matcher)
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }
}
