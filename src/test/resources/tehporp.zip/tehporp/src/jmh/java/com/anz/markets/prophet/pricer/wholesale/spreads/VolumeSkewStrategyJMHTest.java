package com.anz.markets.prophet.pricer.wholesale.spreads;


import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.impl.SpreadFactorsModel;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.pricer.wholesale.WholesaleBook;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;

import static com.anz.markets.prophet.marketdata.TestConfigurationDataFactory.withDefaults;

public class VolumeSkewStrategyJMHTest {

    @State(Scope.Benchmark)
    public static class Data {

        private WholesaleBook wholesaleBook = new WholesaleBook(Market.WSP_A, Instrument.AUDUSD);
        private WholesaleBookFactorsImpl wholesaleBookFactors;
        final VolumeSkewStrategy volumeSkewStrategy = new VolumeSkewStrategy();

        @Setup
        public void setup() throws IOException {
            Context.context().region(Region.GB);
            Context.context().tradingTimeZone(TradingTimeZone.LDN);
            final ConfigurationDataDefault configurationDataDefault = withDefaults(new ConfigurationDataDefault());
            configurationDataDefault.setVolumeSkewConfigs(VolumeSkewStrategyTest.createDefaultVolumeSkewConfigs());
            final IndexedConfigurationData configuration = new IndexedConfigurationData(configurationDataDefault);
            volumeSkewStrategy.applyConfiguration(configuration);
            wholesaleBookFactors = wholesaleBook.getWholesaleBookFactors();
            VolumeSkewStrategyTest.addModelSpread(wholesaleBook, Level.QTY_1M, 0.2, 0.1);
            VolumeSkewStrategyTest.addModelSpread(wholesaleBook, Level.QTY_3M, 0.25, 0.15);
            VolumeSkewStrategyTest.addModelSpread(wholesaleBook, Level.QTY_5M, 0.35, 0.25);
            wholesaleBookFactors.setNotionalEquivPosition(10_000_000);

        }
    }

    @Benchmark
    public int acceptData(@NotNull final VolumeSkewStrategyJMHTest.Data data) throws Exception {
        data.volumeSkewStrategy.execute(data.wholesaleBook);
        final SpreadFactorsModel spreadFactorsModel = data.wholesaleBookFactors.getSpreadFactorsModel();
        return spreadFactorsModel.size();
    }
}
