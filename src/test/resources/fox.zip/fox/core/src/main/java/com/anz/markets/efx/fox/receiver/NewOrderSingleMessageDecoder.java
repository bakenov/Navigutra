package com.anz.markets.efx.fox.receiver;

import java.util.Objects;

import com.anz.markets.efx.fox.common.pricing.PricingRefresher;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.sbe.NewOrderSingleSbeDecoder;

public class NewOrderSingleMessageDecoder implements MessageDecoder<SbeMessage> {
    private final PricingRefresher pricingRefresher;
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);

    private final NewOrderSingleSbeDecoder newOrderSingleDecoder = new NewOrderSingleSbeDecoder();

    public NewOrderSingleMessageDecoder(final PricingRefresher pricingRefresher) {
        this.pricingRefresher = Objects.requireNonNull(pricingRefresher);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!newOrderSingleDecoder.wrap(message)) return false;

        final NewOrderSingleDecoder.Body body = newOrderSingleDecoder.body();
        final String symbol = body.symbol().decodeAndCache(symbolCache);
        final SecurityType securityType = body.securityType();
        final Tenor tenor = body.settlType();
        final long instrumentId = InstrumentKey.instrumentId(symbol, securityType, tenor);

        pricingRefresher.refresh(instrumentId, true);

        return true;
    }
}
