package com.anz.axle.adapters.ndf2trep.acceptance;

import com.anz.markets.adapters.trep.Item;
import com.google.common.collect.Maps;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import java.util.Map;

/**
 * TREP Subscribing client. It is meant to run locally to test prices published to TREP.
 * Configure your local property file with required TREP configuration.
 * example: conf/ndf2trep-D002564BB3C9B.properties:
 *      ndf.trep.publish.destination.servicename=SPDEE_DEV
 *      ndf.trep.publish.destination.sourceId=SPDEE_DEV-RED
 *      ndf.trep.subscription.user=spdee_test
 */
@ContextConfiguration(classes = {
        TestConfig.class,
        NdfTrepSubscriptionConfig.class,
        TrepSubscribingTest.Config.class
})
@Ignore("un-comment this line to run it manually")
public class TrepSubscribingTest extends AbstractJUnit4SpringContextTests {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrepSubscribingTest.class);

    @Configuration
    public static class Config {
        @Bean
        public Map<String, String> instrument2TrepRicMap() {
            final Map<String, String> instrument2TrepRicMap = Maps.newHashMap();
            instrument2TrepRicMap.put("AUDCAD", "AUDCAD");
            instrument2TrepRicMap.put("AUDCHF", "AUDCHF");
            instrument2TrepRicMap.put("AUDCNH", "AUDCNH");
            instrument2TrepRicMap.put("AUDJPY", "AUDJPY");
            instrument2TrepRicMap.put("AUDNZD", "AUDNZD");
            instrument2TrepRicMap.put("AUDUSD", "AUDUSD");
            instrument2TrepRicMap.put("CADCHF", "CADCHF");
            instrument2TrepRicMap.put("CADJPY", "CADJPY");
            instrument2TrepRicMap.put("CHFJPY", "CHFJPY");
            instrument2TrepRicMap.put("EURAUD", "EURAUD");
            instrument2TrepRicMap.put("EURCAD", "EURCAD");
            instrument2TrepRicMap.put("EURCHF", "EURCHF");
            instrument2TrepRicMap.put("EURCNH", "EURCNH");
            instrument2TrepRicMap.put("EURCZK", "EURCZK");
            instrument2TrepRicMap.put("EURDKK", "EURDKK");
            instrument2TrepRicMap.put("EURGBP", "EURGBP");
            instrument2TrepRicMap.put("EURHUF", "EURHUF");
            instrument2TrepRicMap.put("EURJPY", "EURJPY");
            instrument2TrepRicMap.put("EURMXN", "EURMXN");
            instrument2TrepRicMap.put("EURNOK", "EURNOK");
            instrument2TrepRicMap.put("EURNZD", "EURNZD");
            instrument2TrepRicMap.put("EURPLN", "EURPLN");
            instrument2TrepRicMap.put("EURSEK", "EURSEK");
            instrument2TrepRicMap.put("EURUSD", "EURUSD");
            instrument2TrepRicMap.put("GBPAUD", "GBPAUD");
            instrument2TrepRicMap.put("GBPCAD", "GBPCAD");
            instrument2TrepRicMap.put("GBPCHF", "GBPCHF");
            instrument2TrepRicMap.put("GBPJPY", "GBPJPY");
            instrument2TrepRicMap.put("GBPNZD", "GBPNZD");
            instrument2TrepRicMap.put("GBPUSD", "GBPUSD");
            instrument2TrepRicMap.put("NZDCAD", "NZDCAD");
            instrument2TrepRicMap.put("NZDJPY", "NZDJPY");
            instrument2TrepRicMap.put("NZDUSD", "NZDUSD");
            instrument2TrepRicMap.put("USDCAD", "USDCAD");
            instrument2TrepRicMap.put("USDCHF", "USDCHF");
            instrument2TrepRicMap.put("USDCNH", "USDCNH");
            instrument2TrepRicMap.put("USDDKK", "USDDKK");
            instrument2TrepRicMap.put("USDHKD", "USDHKD");
            instrument2TrepRicMap.put("USDILS", "USDILS");
            instrument2TrepRicMap.put("USDJPY", "USDJPY");
            instrument2TrepRicMap.put("USDMXN", "USDMXN");
            instrument2TrepRicMap.put("USDNOK", "USDNOK");
            instrument2TrepRicMap.put("USDPLN", "USDPLN");
            instrument2TrepRicMap.put("USDSEK", "USDSEK");
            instrument2TrepRicMap.put("USDSGD", "USDSGD");
            instrument2TrepRicMap.put("USDTHB", "USDTHB");
            instrument2TrepRicMap.put("USDTRY", "USDTRY");
            instrument2TrepRicMap.put("USDZAR", "USDZAR");
            instrument2TrepRicMap.put("NZDSGD", "NZDSGD");
            instrument2TrepRicMap.put("AUDSGD", "AUDSGD");
            instrument2TrepRicMap.put("NZDCHF", "NZDCHF");
            instrument2TrepRicMap.put("SGDJPY", "SGDJPY");
            instrument2TrepRicMap.put("XAUUSD", "XAUUSD");
            instrument2TrepRicMap.put("XAUEUR", "XAUEUR");
            instrument2TrepRicMap.put("XAGUSD", "XAGUSD");
            instrument2TrepRicMap.put("XPTUSD", "XPTUSD");
            instrument2TrepRicMap.put("XPDUSD", "XPDUSD");
            instrument2TrepRicMap.put("USDRUB", "USDRUB");

            return instrument2TrepRicMap;
        }
    }

    @Autowired
    protected TestMessageProcessor testRateProcessor;

    @Autowired
    @Qualifier("testTrepNdfSubscriber")
    protected TrepRateSubscriber testTrepNdfSubscriber;


    @Before
    public void beforeTest() throws Exception {
        testTrepNdfSubscriber.run();
    }

    @Test
    public void logTrepItems() throws Exception {
        while (true) {
            final Item latestUpdate = testRateProcessor.getLatestRateForRIC();
            if (latestUpdate != null) {
                LOGGER.info("TREP Item: {}", latestUpdate);
            }
        }
    }

}
