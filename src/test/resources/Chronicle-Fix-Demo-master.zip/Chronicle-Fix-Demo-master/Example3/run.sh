#!/bin/bash

mvn exec:java -DfastJava8IO
