package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.snapshot.change.EntriesChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.BeforeBookChangeCompleteHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.Side;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public final class EbsImplicitDeletionHandler implements BeforeBookChangeCompleteHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsImplicitDeletionHandler.class);
    private final EbsBookRules ebsBookRules;
    private final PrecisionClock precisionClock;


    public EbsImplicitDeletionHandler(final PrecisionClock precisionClock, final EbsBookRules ebsBookRules) {
        this.ebsBookRules = Objects.requireNonNull(ebsBookRules);
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    @Override
    public void beforeBookChangeComplete(final MarketDataBook marketDataBook, final EntriesChangedListener entriesChangedListener) {
        LOGGER.debug("received {} bids={} asks={}", marketDataBook.requestKey().instrumentKey(), marketDataBook.bids().size(), marketDataBook.asks().size());
        final EbsBookRules.Config config = ebsBookRules.configFor(marketDataBook.requestKey().instrumentKey().instrumentId());
        if (config == null) {
            LOGGER.warn("EbsBookRules.Config NOT found with {}", marketDataBook.requestKey().instrumentKey());
            return;
        }
        processImplicitDeletions(config, marketDataBook.bids(), entriesChangedListener, Side.BID);
        processImplicitDeletions(config, marketDataBook.asks(), entriesChangedListener, Side.ASK);
    }

    private void processImplicitDeletions(final EbsBookRules.Config config,
                                          final MarketDataEntries entries,
                                          final EntriesChangedListener entriesChangedListener,
                                          final Side side) {
        if (entries.size() > 1) {
            final double bestPrice = entries.get(0).price();
            final double cutOff = config.priceRangeSteps() * config.priceRangeIncrement() - 1.0e-10; //see FIX_EBS_Support.mon
            final double cutOffPrice = side == Side.BID ? (bestPrice - cutOff) : (bestPrice + cutOff);
            final int depth = config.depth();
            final long removeTimeNanos = precisionClock.nanos();
            for (int level = entries.size() - 1; level >= 1; level--) {
                if (level >= depth || isPriceCutOff(entries, level, cutOffPrice, side)) {
                    entries.remove(level, removeTimeNanos, entriesChangedListener);
                }//else: NOTE: if we assume a price-sorted book we could stop here
            }
        }
    }

    private static boolean isPriceCutOff(final MarketDataEntries entries, final int index, final double cutOffPrice, final Side side) {
        final double price = entries.get(index).price();
        return side == Side.BID ? price <= cutOffPrice : price >= cutOffPrice;
    }
}
