package com.anz.axle.lg.adapter.ebsu;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;

import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.core.Garbage;

public class SymbolConverter {
    private final SecurityType securityType;
    private final Map<String, String> ebsuSymbolMapping;

    public SymbolConverter( final SecurityType securityType,
                            final Map<String, String> ebsuSymbolMapping) {
        this.securityType = Objects.requireNonNull(securityType);
        this.ebsuSymbolMapping = new HashMap<>(Objects.requireNonNull(ebsuSymbolMapping));
    }

    /**
     * EBS Ultra instrument desc looks like "FXSPOT.AUDCAD(EBSM_CLOB)       "
     * @param securityDefinition instrument
     * @return symbol
     */
    @Garbage(Garbage.Type.RARE)
    public String toSymbol6(final InstrumentDirectory securityDefinition) {
        final String desc = securityDefinition.description();
        final int start = this.securityType.toString().length() + 1;
        String extractedSymbol = desc.substring(start, start + 6);
        return convertToMarketConventionSymbol(extractedSymbol);
    }

    public String convertToMarketConventionSymbol(String extractedSymbol) {
        return ebsuSymbolMapping.computeIfAbsent(extractedSymbol, ebsuSymbol -> ebsuSymbol);
    }
}
