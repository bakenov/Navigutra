package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.itch.sessioncode.messages.server.ErrorNotification;
import software.chronicle.itch.sessioncode.messages.server.LoginAccepted;
import software.chronicle.itch.sessioncode.messages.server.LoginRejected;
import software.chronicle.itch.staticcode.ItchServerSessionHandler;
import software.chronicle.itch.staticcode.ItchSessionHandler;
import software.chronicle.itchcboe.messages.CancelOrder;
import software.chronicle.itchcboe.messages.MarketSnapshot;
import software.chronicle.itchcboe.messages.MessageNotifier;
import software.chronicle.itchcboe.messages.ModifyOrder;
import software.chronicle.itchcboe.messages.NewOrder;
import software.chronicle.itchcboe.messages.datamodel.client.DefaultLogoutRequest;
import software.chronicle.itchcboe.messages.server.InstrumentDirectory;
import software.chronicle.itchcboe.messages.server.Sequenced;
import software.chronicle.itchcboe.messages.server.ServerHeartbeat;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;

public class ItchPricingApplication implements MessageNotifier {

    private static final Logger LOGGER = LoggerFactory.getLogger(ItchPricingApplication.class);

    private final transient ChronicleMessageHandler<Object> adminMessageMessageHandler;
    private final transient ChronicleMessageHandler<MarketSnapshot> marketSnapshotHandler;
    private final transient ChronicleMessageHandler<NewOrder> newOrderHandler;
    private final transient ChronicleMessageHandler<ModifyOrder> modifyOrderHandler;
    private final transient ChronicleMessageHandler<CancelOrder> cancelOrderHandler;

    public ItchPricingApplication(final ChronicleMessageHandler<Object> adminMessageMessageHandler,
                                  final ChronicleMessageHandler<MarketSnapshot> marketSnapshotHandler,
                                  final ChronicleMessageHandler<NewOrder> newOrderHandler,
                                  final ChronicleMessageHandler<ModifyOrder> modifyOrderHandler,
                                  final ChronicleMessageHandler<CancelOrder> cancelOrderHandler) {
        this.adminMessageMessageHandler = Objects.requireNonNull(adminMessageMessageHandler);
        this.marketSnapshotHandler = Objects.requireNonNull(marketSnapshotHandler);
        this.newOrderHandler = Objects.requireNonNull(newOrderHandler);
        this.modifyOrderHandler = Objects.requireNonNull(modifyOrderHandler);
        this.cancelOrderHandler = Objects.requireNonNull(cancelOrderHandler);
    }

    @Override
    public void onLoginAccepted(final ItchServerSessionHandler session, LoginAccepted loginAccepted) {
        LOGGER.info("Received {}", loginAccepted);
        adminMessageMessageHandler.accept(loginAccepted);
    }

    @Override
    public void onLoginRejected(final ItchServerSessionHandler session, final LoginRejected loginRejected) {
        LOGGER.info("Received {}", loginRejected);
    }

    /**
     * Indicates an error condition in response to an invalid request from the connected client.
     */
    @Override
    public void onErrorNotification(final ItchServerSessionHandler session, final ErrorNotification errorNotification) {
        LOGGER.info("Received {}", errorNotification);
    }

    /**
     * Lists currency pairs supported by the server. Requested by sending an Instrument Directory Request Packet (1.3.9)
     */
    @Override
    public void onInstrumentDirectory(final ItchServerSessionHandler session, final InstrumentDirectory instrumentDirectory) {
        LOGGER.info("Received {}", instrumentDirectory);
    }

    @Override
    public void onServerHeartbeat(final ItchServerSessionHandler session, final ServerHeartbeat serverHeartbeat) {
        LOGGER.debug("Received {}", serverHeartbeat);
    }

    @Override
    public void onMarketSnapshot(final ItchSessionHandler session, final MarketSnapshot marketSnapshot) {
        marketSnapshotHandler.accept(marketSnapshot);
    }

    @Override
    public void onEndOfSession(final ItchSessionHandler session, final Object sequenced) {
        LOGGER.info("Received onEndOfSession {}", sequenced);
        adminMessageMessageHandler.accept((Sequenced) sequenced);
    }

    @Override
    public void onNewOrder(final ItchSessionHandler session, final NewOrder newOrder) {
        LOGGER.debug("Received {}", newOrder);
        newOrderHandler.accept(newOrder);
    }

    @Override
    public void onModifyOrder(final ItchSessionHandler session, final ModifyOrder modifyOrder) {
        LOGGER.debug("Received {}", modifyOrder);
        modifyOrderHandler.accept(modifyOrder);
    }

    @Override
    public void onCancelOrder(final ItchSessionHandler session, final CancelOrder cancelOrder) {
        LOGGER.debug("Received {}", cancelOrder);
        cancelOrderHandler.accept(cancelOrder);
    }

    @Override
    public void onMessageBacklog(final long messageBacklogTimeMillis) {
        LOGGER.info("Received onMessageBacklog {}", messageBacklogTimeMillis);
    }

    @Override
    public void onUnsupportedMessageType(final ItchSessionHandler session, final int msgType) {
        LOGGER.warn("Received UnsupportedMessageType {}", msgType);
    }

    @Override
    public void onEndOfConnection(final String sessionID) {
        LOGGER.info("Received onEndOfConnection {}", sessionID);
        adminMessageMessageHandler.accept(new DefaultLogoutRequest());
    }

    @Override
    public void onSequenced(final ItchServerSessionHandler session, final Sequenced sequenced) {
        LOGGER.debug("Received {}", sequenced);
    }
}
