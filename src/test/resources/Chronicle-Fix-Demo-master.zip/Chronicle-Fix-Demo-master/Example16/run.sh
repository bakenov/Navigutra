#!/bin/bash

title="Available tests"
prompt="Select test:"
options=("Test Proxy" "Performance Test")

PS3=$'\n'"$prompt "
COLUMNS=24

while true; do
    printf "\n$title\n"
    select opt in "${options[@]}" "Quit"; do

        case "$REPLY" in

        1 ) MAVEN_OPTS=-ea mvn exec:java -Dexec.mainClass="software.chronicle.fix.StartAndSendOrdersToProxy"; break;;
        2 ) mvn exec:java -Dexec.mainClass="software.chronicle.fix.PerformanceRunProxy"; break;;

        $(( ${#options[@]}+1 )) ) echo "Quit"; exit;;
        *) echo "Invalid option";continue;;

        esac

    done
done


