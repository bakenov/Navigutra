#!/bin/bash

ssh AxlSv@daxa005z "rm -rf /app/apama/axle/datafabric/workspace/*"
