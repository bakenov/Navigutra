package com.anz.markets.efx.ngaro.codec;

public interface HeaderDecoder {
    Header header();
}
