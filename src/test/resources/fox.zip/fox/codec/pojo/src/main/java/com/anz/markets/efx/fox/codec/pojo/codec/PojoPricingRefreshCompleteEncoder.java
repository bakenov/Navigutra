package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoPricingRefreshCompleteEncoder implements PricingRefreshCompleteEncoder, PricingRefreshCompleteEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;

    private PricingRefreshComplete message = SorMessage.pricingRefreshComplete();

    public PojoPricingRefreshCompleteEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
    }

    public PricingRefreshComplete message() {
        return message;
    }

    @Override
    public PricingRefreshCompleteEncoder.Body messageStart(final int source, final long sourceSeq) {
        message = SorMessage.pricingRefreshComplete();
        message.header.source = source;
        message.header.sourceSeq = sourceSeq;
        return this;
    }

    @Override
    public Body instrumentId(final long instrumentId) {
        message.body.instrumentId = instrumentId;
        return this;
    }

    @Override
    public Trailer forceSnapshot(final boolean forceSnapshot) {
        message.body.forceSnapshot = forceSnapshot;
        return this;
    }


    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
