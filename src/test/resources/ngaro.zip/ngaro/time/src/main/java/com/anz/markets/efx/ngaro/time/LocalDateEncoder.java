package com.anz.markets.efx.ngaro.time;

import java.time.LocalDate;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteWriter;

/**
 * Encoder for local dates with date formats as defined by {@link LocalDateFormat}.
 * <br/>
 * All methods are zero garbage.
 * <p/>
 * This class is thread safe.
 *
 * @see LocalDateDecoder
 */
public final class LocalDateEncoder {

    public static final char DEFAULT_DELIMITER = '-';
    private static final byte NULL = 0;

    private final LocalDateFormat dateFormat;
    private final char delimiter;

    /**
     * Creates an encoder with the specified format. If {@code format} contains a delimiter then '-' is used.
     *
     * @param format the date format
     */
    LocalDateEncoder(final LocalDateFormat format) {
        this(format, DEFAULT_DELIMITER);
    }

    /**
     * Creates an encoder with the specified format and delimiter character. The {@code delimiter} character is ignored
     * if {@code format} contains no delimiter.
     *
     * @param format the date format
     * @param delimiter the delimiter character to use if {@code format} contains a delimiter character
     */
    private LocalDateEncoder(final LocalDateFormat format, final char delimiter) {
        this.dateFormat = Objects.requireNonNull(format);
        this.delimiter = delimiter;
        if (delimiter > 127) {
            throw new IllegalArgumentException("Invalid delimiter char: " + delimiter);
        }
    }

    /**
     * Returns an encoder with the specified format. If {@code format} contains a delimiter then '-' is used.
     *
     * @param format the date format
     */
    public static LocalDateEncoder valueOf(final LocalDateFormat format) {
        return format.getDefaultEncoder();
    }

    /**
     * Creates an encoder with the specified format and delimiter character. The {@code delimiter} character is ignored
     * if {@code format} contains no delimiter.
     *
     * @param format the date format
     * @param delimiter the delimiter character to use if {@code format} contains a delimiter character
     */
    public static LocalDateEncoder valueOf(final LocalDateFormat format, final char delimiter) {
        if (delimiter == DEFAULT_DELIMITER) {
            return valueOf(format);
        }
        return new LocalDateEncoder(format, delimiter);
    }

    public LocalDateFormat getDateFormat() {
        return dateFormat;
    }

    public char getDelimiter() {
        return delimiter;
    }

    /** @return true if value was not null */
    public <T> boolean encodeEpochMillis(final T target, final ByteWriter<? super T> writer, final long epochMillis) {
        return encodeEpochMillis(target, writer, 0, epochMillis);
    }

    /** @return true if value was not null */
    public <T> boolean encodeEpochMillis(final T target, final ByteWriter<? super T> writer, final int offset, final long epochMillis) {
        return encodeEpochDays(target, writer, offset, Math.floorDiv(epochMillis, Epoch.MILLIS_PER_DAY));
    }

    /** @return true if value was not null */
    public <T> boolean encodeEpochSeconds(final T target, final ByteWriter<? super T> writer, final long epochSeconds) {
        return encodeEpochSeconds(target, writer, 0, epochSeconds);
    }

    /** @return true if value was not null */
    public <T> boolean encodeEpochSeconds(final T target, final ByteWriter<? super T> writer, final int offset, final long epochSeconds) {
        return encodeEpochDays(target, writer, offset, Math.floorDiv(epochSeconds, Epoch.SECONDS_PER_DAY));
    }

    /** @return true if value was not null */
    public <T> boolean encodeEpochDays(final T target, final ByteWriter<? super T> writer, final long epochDays) {
        return encodeEpochDays(target, writer, 0, epochDays);
    }

    /** @return true if value was not null */
    public <T> boolean encodeEpochDays(final T target, final ByteWriter<? super T> writer, final int offset, final long epochDays) {
        if (epochDays == 0) {
            encodeNull(target, writer, offset);
            return false;
        }
        final int binaryDate = Epoch.fromEpochDays(LocalDatePacking.BINARY, epochDays);
        final int year = LocalDatePacking.BINARY.unpackYear(binaryDate);
        final int month = LocalDatePacking.BINARY.unpackMonth(binaryDate);
        final int day = LocalDatePacking.BINARY.unpackDay(binaryDate);
        encode(target, writer, offset, year, month, day);
        return true;
    }

    /** @return true if value was not null */
    public <T> boolean encodeNullable(final T target, final ByteWriter<? super T> writer, final LocalDate localDate) {
        return encodeNullable(target, writer, 0, localDate);
    }

    /** @return true if value was not null */
    public <T> boolean encodeNullable(final T target, final ByteWriter<? super T> writer, final int offset, final LocalDate localDate) {
        if (localDate == null) {
            encodeNull(target, writer, offset);
            return false;
        }
        encode(target, writer, offset, localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());
        return true;
    }

    /** @return true if value was not null */
    public <T> boolean encode(final T target, final ByteWriter<? super T> writer, final int year, final int month, final int day) {
        return encode(target, writer, 0, year, month, day);
    }

    /** @return true if value was not null */
    public <T> boolean encode(final T target, final ByteWriter<? super T> writer, final int offset, final int year, final int month, final int day) {
        if (year == 0 & month == 0 & day == 0) {
            encodeNull(target, writer, offset);
            return false;
        }
        encodeYear(target, writer, offset, year);
        encodeMonth(target, writer, offset, month);
        encodeDay(target, writer, offset, day);
        encodeDelimiters(target, writer, offset);
        return true;
    }

    /** @return true if value was not null */
    public <T> boolean encodePacked(final T target, final ByteWriter<? super T> writer, final int packedDate, final LocalDatePacking packing) {
        return encodePacked(target, writer, 0, packedDate, packing);
    }

    /** @return true if value was not null */
    public <T> boolean encodePacked(final T target, final ByteWriter<? super T> writer, final int offset, final int packedDate, final LocalDatePacking packing) {
        if (packedDate == 0) {
            encodeNull(target, writer, offset);
            return false;
        }
        encodeYear(target, writer, offset, packing.unpackYear(packedDate));
        encodeMonth(target, writer, offset, packing.unpackMonth(packedDate));
        encodeDay(target, writer, offset, packing.unpackDay(packedDate));
        encodeDelimiters(target, writer, offset);
        return true;
    }


    public <T> void encodeNull(final T target, final ByteWriter<? super T> writer) {
        encodeNull(target, writer, 0);
    }

    public <T> void encodeNull(final T target, final ByteWriter<? super T> writer, final int offset) {
        final int offsetYear = offset + dateFormat.getOffsetYear();
        final int offsetMonth = offset + dateFormat.getOffsetMonth();
        final int offsetDay = offset + dateFormat.getOffsetDay();
        writer.writeByte(target, offsetYear + 3, NULL);
        writer.writeByte(target, offsetYear + 2, NULL);
        writer.writeByte(target, offsetYear + 1, NULL);
        writer.writeByte(target, offsetYear + 0, NULL);
        writer.writeByte(target, offsetMonth + 1, NULL);
        writer.writeByte(target, offsetMonth + 0, NULL);
        writer.writeByte(target, offsetDay + 1, NULL);
        writer.writeByte(target, offsetDay + 0, NULL);
        encodeDelimiters(target, writer, offset);
    }

    public <T> void encodeYear(final T target, final ByteWriter<? super T> writer, final int year) {
        encodeYear(target, writer, 0, year);
    }
    public <T> void encodeYear(final T target, final ByteWriter<? super T> writer, final int offset, final int year) {
        if (year < 0 | year > 9999) {
            throw new IllegalArgumentException("Year is out of the valid range [0,9999]: " + year);
        }
        final int offsetYear = offset + dateFormat.getOffsetYear();
        int val = year;
        writer.writeByte(target, offsetYear + 3, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetYear + 2, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetYear + 1, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetYear + 0, ascii(val));
    }

    public <T> void encodeMonth(final T target, final ByteWriter<? super T> writer, final int month) {
        encodeMonth(target, writer, 0, month);
    }
    public <T> void encodeMonth(final T target, final ByteWriter<? super T> writer, final int offset, final int month) {
        if (month < 1 | month > 12) {
            throw new IllegalArgumentException("Month is out of the valid range [1,12]: " + month);
        }
        final int offsetMonth = offset + dateFormat.getOffsetMonth();
        int val = month;
        writer.writeByte(target, offsetMonth + 1, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetMonth + 0, ascii(val));
    }

    public <T> void encodeDay(final T target, final ByteWriter<? super T> writer, final int day) {
        encodeDay(target, writer, 0, day);
    }
    public <T> void encodeDay(final T target, final ByteWriter<? super T> writer, final int offset, final int day) {
        if (day < 1 | day > 31) {
            throw new IllegalArgumentException("Day is out of the valid range [1,31]: " + day);
        }
        final int offsetDay = offset + dateFormat.getOffsetDay();
        int val = day;
        writer.writeByte(target, offsetDay + 1, ascii(val % 10));
        val /= 10;
        writer.writeByte(target, offsetDay + 0, ascii(val));
    }

    public <T> void encodeDelimiters(final T target, final ByteWriter<? super T> writer) {
        encodeDelimiters(target, writer, 0);
    }
    public <T> void encodeDelimiters(final T target, final ByteWriter<? super T> writer, final int offset) {
        final int posDelim1 = dateFormat.getPositionDelimiter1();
        if (posDelim1 >= 0) {
            writer.writeByte(target, offset + posDelim1, (byte)delimiter);
        }
        final int posDelim2 = dateFormat.getPositionDelimiter2();
        if (posDelim2 >= 0) {
            writer.writeByte(target, offset + posDelim2, (byte)delimiter);
        }
    }

    private static final byte ascii(final int digit) {
        return (byte)('0' + digit);
    }
}
