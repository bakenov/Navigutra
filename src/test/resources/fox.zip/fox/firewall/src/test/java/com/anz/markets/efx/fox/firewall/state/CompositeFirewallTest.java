package com.anz.markets.efx.fox.firewall.state;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.SorCodecUtil;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CompositeFirewallTest {
    private static final String FIREWALL1 = "firewall1";
    private static final String FIREWALL2 = "firewall2";
    private final SorCodecUtil.Codec sorCodec = SorCodecUtil.create();
    @Mock
    private CommandContext commandContext;
    @Mock
    private EventContext eventContext;
    @Mock
    private ExecutionReportDecoder executionReport;
    @Mock
    private NewOrderSingleDecoder newOrderSingle;

    @Mock
    private OrderConsumer orderConsumer;
    @Mock
    private Firewall firewall1;

    @Mock
    private Firewall firewall2;

    private CompositeFirewall compositeFirewall;

    @BeforeEach
    public void setUp() {
        when(firewall1.firewallName()).thenReturn(FIREWALL1);
        when(firewall2.firewallName()).thenReturn(FIREWALL2);
        compositeFirewall = new CompositeFirewall("compositeFirewall", orderConsumer, firewall1, firewall2);
    }

    @Test
    void onFirewallConfigRuleRequest() {
        encodeFirewallConfig(FIREWALL1);

        final FirewallConfigDecoder firewallConfig = sorCodec.firewallConfigSbeDecoder();

        compositeFirewall.onFirewallConfigRuleRequest(commandContext, firewallConfig);

        verify(firewall1).onFirewallConfigRuleRequest(commandContext, firewallConfig);
    }

    @Test
    void applyFirewallConfigRuleResponse() {

        encodeFirewallConfig(FIREWALL2);

        final FirewallConfigDecoder firewallConfig = sorCodec.firewallConfigSbeDecoder();

        compositeFirewall.applyFirewallConfigRuleResponse(eventContext, firewallConfig);

        verify(firewall2).applyFirewallConfigRuleResponse(eventContext, firewallConfig);
    }

    @Test
    void applyExecutionReport() {
        compositeFirewall.applyExecutionReport(eventContext, executionReport);
        verify(firewall1).applyExecutionReport(eventContext, executionReport);
        verify(firewall2).applyExecutionReport(eventContext, executionReport);
    }

    @Test
    void firewallName() {
        assertThat(compositeFirewall.firewallName()).isEqualTo("compositeFirewall");
    }

    @Test
    void accept_returns_false_and_not_proceed_with_other_firewalls_when_first_firewall_returns_false() {
        //given
        when(firewall2.accept(newOrderSingle, commandContext)).thenReturn(false);

        //when and then
        assertThat(compositeFirewall.accept(newOrderSingle, commandContext)).isFalse();

        //and
        verify(firewall1, never()).accept(newOrderSingle, commandContext);
        verify(orderConsumer, never()).accept(newOrderSingle, commandContext);
    }

    @Test
    void accept_returns_true_and_passes_order_to_success_stream_when_all_firewalls_successful() {
        //given
        when(firewall1.accept(newOrderSingle, commandContext)).thenReturn(true);
        when(firewall2.accept(newOrderSingle, commandContext)).thenReturn(true);

        //when and then
        assertThat(compositeFirewall.accept(newOrderSingle, commandContext)).isTrue();

        //and
        verify(orderConsumer).accept(newOrderSingle, commandContext);
    }


    private void encodeFirewallConfig(final String firewallName) {
        sorCodec.encoderSupplier().firewallConfigEncoder().messageStart(1, 2)
                .firewallName().encode(firewallName)
                .ruleId(10)
                .period(1)
                .limitThreshold(0)
                .messageComplete();
    }
}