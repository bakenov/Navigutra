package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.adapters.rmds.ItemBuilder;
import com.anz.axle.common.domain.CurrencyBuilder;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.datafabric.client.config.CurrencyPairService;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.Quote;
import com.anz.axle.pricing.QuotePageType;
import com.anz.axle.pricing.QuoteState;
import com.anz.axle.spdee.dealing.QuotePriceType;
import com.anz.markets.adapters.trep.Item;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class ForwardPointsQuotePageFactoryTest {

    private ForwardPointsQuotePageFactory factory;

    @Mock
    private CurrencyPairService currencyPairService;

    @Before
    public void setUp() throws Exception {
        factory = new ForwardPointsQuotePageFactory(currencyPairService);

        Mockito.when(currencyPairService.findbySymbol("AUD/USD")).thenReturn(new CurrencyPair(CurrencyBuilder.AUD, CurrencyBuilder.USD));
        Mockito.when(currencyPairService.findbySymbol("USD/KR1")).thenReturn(new CurrencyPair(CurrencyBuilder.USD, CurrencyBuilder.KR1));
        Mockito.when(currencyPairService.findbySymbol("USD/SG2")).thenReturn(null);
    }

    @Test
    public void testSpotForwardPointsQuotePageCreation() {
        final LocalDate referenceDate = new LocalDate();
        final String referenceDateString = D3ForwardQuote.DATE_FORMATTER.print(referenceDate);

        final Item item = new ItemBuilder("AUD=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", referenceDateString)
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", referenceDateString)
                .withField("TIMACT", "02:42")
                .build();
        D3ForwardQuote d3ForwardQuote = new D3ForwardQuote(item, true);
        final ForwardPointsQuotePage page = ForwardPointsQuotePageFactory.spotTenorForwardPointsQuotePageFrom(d3ForwardQuote, referenceDate);
        assertThat(page.getSymbol(), is("AUD/USD"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.SPOT));
        assertThat(page.getTenorDate(), is(referenceDate));
        assertThat(page.getReferenceSpotDate(), is(referenceDate));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.STREAMABLE));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(1));
        assertThat(page.getQuotes().get(0).getBidPrice(), is(Decimal.ZERO));
        assertThat(page.getQuotes().get(0).getAskPrice(), is(Decimal.ZERO));
        assertThat(page.getQuotes().get(0).getQuotePriceType(), is(QuotePriceType.FORWARD_POINTS));
    }

    @Test
    public void testForwardPointsAndWholesaleForwardPointsQuotePageCreation_for_nonSpot_trep_update_where_all_currencies_are_deliverable() {
        final LocalDate referenceDate = new LocalDate();
        final LocalDate maturityDate = new LocalDate().plusDays(5);
        final String referenceDateString = D3ForwardQuote.DATE_FORMATTER.print(referenceDate);
        final String maturityDateString = D3ForwardQuote.DATE_FORMATTER.print(maturityDate);

        final Item item = new ItemBuilder("AUD2M=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", referenceDateString)
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", maturityDateString)
                .withField("TIMACT", "02:42")
                .build();
        D3ForwardQuote d3ForwardQuote = new D3ForwardQuote(item, true);
        final ForwardPointsQuotePage page = factory.forwardPointsAndWholesaleSpotForwardPointQuotePageFrom(d3ForwardQuote).get();
        assertThat(page.getSymbol(), is("AUD/USD"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.TWO_MONTH));
        assertThat(page.getTenorDate(), is(maturityDate));
        assertThat(page.getReferenceSpotDate(), is(referenceDate));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.STREAMABLE));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(1));
        assertThat(page.getQuotes().get(0).getBidPrice(), is(Decimal.valueOf("-42.65")));
        assertThat(page.getQuotes().get(0).getAskPrice(), is(Decimal.valueOf("-42.35")));
        assertThat(page.getQuotes().get(0).getQuotePriceType(), is(QuotePriceType.FORWARD_POINTS));
    }

    @Test
    public void test_forwardPointQuotePage_creation_for_nonSpot_trep_update_where_non_deliverable_currency_is_involved() {
        final LocalDate referenceDate = new LocalDate();
        final LocalDate maturityDate = new LocalDate().plusDays(5);
        final String referenceDateString = D3ForwardQuote.DATE_FORMATTER.print(referenceDate);
        final String maturityDateString = D3ForwardQuote.DATE_FORMATTER.print(maturityDate);

        final Item item = new ItemBuilder("KR12M=D3")
                .withField("GV1_TEXT", "USDKR1")
                .withField("GV1_DATE", referenceDateString)
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", maturityDateString)
                .withField("TIMACT", "02:42")
                .build();
        D3ForwardQuote d3ForwardQuote = new D3ForwardQuote(item, true);
        final ForwardPointsQuotePage page = factory.forwardPointsAndWholesaleSpotForwardPointQuotePageFrom(d3ForwardQuote).get();
        assertThat(page.getSymbol(), is("USD/KR1"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.TWO_MONTH));
        assertThat(page.getTenorDate(), is(maturityDate));
        assertThat(page.getReferenceSpotDate(), is(referenceDate));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.STREAMABLE));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(1));
        assertThat(page.getQuotes().get(0).getBidPrice(), is(Decimal.valueOf("-42.65")));
        assertThat(page.getQuotes().get(0).getAskPrice(), is(Decimal.valueOf("-42.35")));
        assertThat(page.getQuotes().get(0).getQuotePriceType(), is(QuotePriceType.FORWARD_POINTS));
    }

    @Test
    public void test_forwardPointQuotePage_creation_for_spot_trep_update_where_non_deliverable_currency_is_involved() {
        final LocalDate referenceDate = new LocalDate();
        final String referenceDateString = D3ForwardQuote.DATE_FORMATTER.print(referenceDate);

        final Item item = new ItemBuilder("KR1=D3")
                .withField("GV1_TEXT", "USDKR1")
                .withField("GV1_DATE", referenceDateString)
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", referenceDateString)
                .withField("TIMACT", "02:42")
                .build();
        D3ForwardQuote d3ForwardQuote = new D3ForwardQuote(item, true);
        final ForwardPointsQuotePage page = factory.forwardPointsAndWholesaleSpotForwardPointQuotePageFrom(d3ForwardQuote).get();
        assertThat(page.getSymbol(), is("USD/KR1"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.SPOT));
        assertThat(page.getTenorDate(), is(referenceDate));
        assertThat(page.getReferenceSpotDate(), is(referenceDate));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.STREAMABLE));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(2));

        {
            final Quote forwardPointQuote = Iterables.find(page.getQuotes(), byQuotePriceType(QuotePriceType.FORWARD_POINTS));
            assertThat(forwardPointQuote.getBidPrice(), is(Decimal.ZERO));
            assertThat(forwardPointQuote.getAskPrice(), is(Decimal.ZERO));
            assertThat(forwardPointQuote.getState(), is(QuoteState.STREAMABLE));
        }
        {
            final Quote wholesaleSpotQuote = Iterables.find(page.getQuotes(), byQuotePriceType(QuotePriceType.WHOLESALE_SPOT_PRICE));
            assertThat(wholesaleSpotQuote.getBidPrice(), is(Decimal.valueOf("-42.65")));
            assertThat(wholesaleSpotQuote.getAskPrice(), is(Decimal.valueOf("-42.35")));
            assertThat(wholesaleSpotQuote.getState(), is(QuoteState.STREAMABLE));
        }
    }

    @Test
    public void test_forwardPointQuotePage_creation_for_sg2_spot_quote_doesnt_generate_wholesale_quote() {
        final LocalDate referenceDate = new LocalDate();
        final String referenceDateString = D3ForwardQuote.DATE_FORMATTER.print(referenceDate);

        final Item item = new ItemBuilder("SG2=D3")
                .withField("GV1_TEXT", "USDSG2")
                .withField("GV1_DATE", referenceDateString)
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", referenceDateString)
                .withField("TIMACT", "02:42")
                .build();
        D3ForwardQuote d3ForwardQuote = new D3ForwardQuote(item, true);
        final ForwardPointsQuotePage page = factory.forwardPointsAndWholesaleSpotForwardPointQuotePageFrom(d3ForwardQuote).get();
        assertThat(page.getSymbol(), is("USD/SG2"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.SPOT));
        assertThat(page.getTenorDate(), is(referenceDate));
        assertThat(page.getReferenceSpotDate(), is(referenceDate));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.STREAMABLE));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(1));

        {
            final Quote forwardPointQuote = Iterables.find(page.getQuotes(), byQuotePriceType(QuotePriceType.FORWARD_POINTS));
            assertThat(forwardPointQuote.getBidPrice(), is(Decimal.ZERO));
            assertThat(forwardPointQuote.getAskPrice(), is(Decimal.ZERO));
            assertThat(forwardPointQuote.getState(), is(QuoteState.STREAMABLE));
        }
    }

    private Predicate<Quote> byQuotePriceType(final QuotePriceType quotePriceType) {
        return new Predicate<Quote>() {
            @Override
            public boolean apply(final Quote quote) {
                return quote.getQuotePriceType() == quotePriceType;
            }
        };
    }
}