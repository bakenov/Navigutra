package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;

public class PricePausedFirewallTest extends BaseAcceptanceSpecification {
    final Instrument indirectDriver = Instrument.AUDUSD;
    final Instrument directDriver = Instrument.USDJPY;
    final Instrument crossDriver = Instrument.EURDKK;
    final Instrument synthetic = Instrument.AUDJPY;

    @Test
    @Requirement(Ref.PRICING_AXPROPHET_1130)
    public void pricingPausedControlToImpactWSPZOnly() {
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setSyntheticInstrumentConfigs(Arrays.asList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.AUDJPY).setMarkets("ANY")
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.JPY, Market.ANY, 1.0)
                    ))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, indirectDriver, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directDriver, 85.550, 0.040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, crossDriver, 7.50050, 0.00040));
        }
        then:
        // WSP_A and WSP_Z client prices generated and FIRM
        {
            ClientPrice cpAIndirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_A)).getLast();
            assertThat(cpAIndirect, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice cpZIndirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_Z)).getLast();
            assertThat(cpZIndirect, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpADirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(directDriver, Market.WSP_A)).getLast();
            assertThat(cpADirect, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice cpZDirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(directDriver, Market.WSP_Z)).getLast();
            assertThat(cpZDirect, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpACross = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossDriver, Market.WSP_A)).getLast();
            assertThat(cpACross, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice cpZCross = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossDriver, Market.WSP_Z)).getLast();
            assertThat(cpZCross, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpASynthetic = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrumentAndMkt(synthetic, Market.WSP_A)).getLast();
            assertThat(cpASynthetic, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice cpZSynthetic = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrumentAndMkt(synthetic, Market.WSP_Z)).getLast();
            assertThat(cpZSynthetic, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // Receive AUD disabled control
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setPricePauseControl(false, Currency.AUD, Market.WSP_Z));

        }
        then:
        // Only republish instruments as INDICATIVE containing AUD and for WSP_Z market only
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_A));

            ClientPrice cpZIndirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_Z)).getLast();
            assertThat(cpZIndirect, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpZIndirect, PricingFirewallType.PRICE_PAUSE_CONTROL);

            ClientPrice cpZSynthetic = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(synthetic, Market.WSP_Z)).getLast();
            assertThat(cpZSynthetic, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpZSynthetic, PricingFirewallType.PRICE_PAUSE_CONTROL);
        }
        when:
        // Receive JPY disabled control
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setPricePauseControl(false, Currency.JPY, Market.WSP_Z));
        }
        then:
        // since AUDJPY already indicative no need to replublish
        // USDJPY now indicative
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(synthetic, Market.WSP_Z));

            ClientPrice cpZDirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(directDriver, Market.WSP_Z)).getLast();
            assertThat(cpZDirect, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
        when:
        // Receive DKK disabled control
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setPricePauseControl(false, Currency.DKK, Market.WSP_Z));
        }
        then:
        // cross driver EURDKK WSP_Z indicative
        {
            ClientPrice cpZCross = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(crossDriver, Market.WSP_Z)).getLast();
            assertThat(cpZCross, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
        when:
        // receive marketdatasnapshot for AUD/USD
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, indirectDriver, 0.75005, 0.00040));
        }
        then:
        // since AUD pricing disabled, AUD/USD WSP_Z still indicative
        {
            ClientPrice cpAIndirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_A)).getLast();
            assertThat(cpAIndirect, new QuoteTypeMatcher(QuoteType.FIRM));
            ClientPrice cpZIndirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_Z)).getLast();
            assertThat(cpZIndirect, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
        when:
        // Receive AUD enabled control
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.setPricePauseControl(true, Currency.AUD, Market.WSP_Z));
        }
        then:
        // only AUDUSD (WSP_Z) re-published as FIRM. JPY still disabled so no AUDJPY republish
        {

            prophet.expect(ClientPrice.class, exactly(1));
            ClientPrice cpZIndirect = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(indirectDriver, Market.WSP_Z)).getLast();
            assertThat(cpZIndirect, new QuoteTypeMatcher(QuoteType.FIRM));
        }
    }
}
