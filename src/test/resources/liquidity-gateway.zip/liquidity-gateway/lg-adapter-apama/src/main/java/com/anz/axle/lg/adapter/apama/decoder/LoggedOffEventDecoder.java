package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.LoggedOff;
import com.anz.axle.lg.config.PricingEncoderLookup;

/**
 * Decodes Apama events as defined by {@link com.anz.axle.lg.adapter.apama.event.LoggedOff}
 */
public final class LoggedOffEventDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggedOffEventDecoder.class);

    private final PricingEncoderLookup pricingEncoderLookup;
    private final String transport;


    public LoggedOffEventDecoder(final PricingEncoderLookup pricingEncoderLookup, final String transport) {
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.transport = transport;
    }

    @Override
    public void decode(final Event event) {
        final String eventTransport = event.getField(LoggedOff.FIELD_TRANSPORT);
        if (transport.equals(eventTransport)) {
            LOGGER.warn("Received LoggedOff event, clearing all books");
            pricingEncoderLookup.clearAllBooksAndForwardEmptySnapshots(PricingEncoderLookup.MD_FLAGS_LOGGED_OFF);
        }
    }
}
