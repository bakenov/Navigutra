package com.anz.markets.prophet.pricer.cross;

import com.anz.markets.prophet.ByteWatcherTodo;
import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.pricer.PriceUtil;
import com.anz.markets.prophet.util.AmountUnit;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.io.IOException;
import java.util.Random;
import java.util.function.Consumer;

public class CrossRateManagerBWTest {
    private static final int REPS = 100_000;
    public static final int THRESHOLD = 300;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private NoOpConsumer<ClientPrice> nfys;
    private ClientPrice clientPriceAUDCAD, clientPriceGPBUSD, clientPriceAUDUSD;
    private Consumer<ClientPrice> clientPriceConsumer;
    private final Random random = new Random(0);

    @BeforeClass
    public static void warmup() throws IOException {
        CrossRateManagerTest.setupClass();
        CrossRateManagerBWTest warmit = new CrossRateManagerBWTest();
        warmit.setup();
        warmit.checkPassThrough();
        warmit.setup();
        warmit.checkTwoPrice();
    }

    @Before
    public void setup() throws IOException {
        nfys = new NoOpConsumer<>();
        final CrossRateManager crossRateManager = CrossRateManagerTest.createCrossRateManager(nfys);
        clientPriceAUDCAD = MidRateTestHelper.createClientPrice(Instrument.AUDCAD, 1.0, MidRateTestHelper.SPREAD);
        clientPriceGPBUSD = MidRateTestHelper.createClientPrice(Instrument.GBPUSD, 1.62, MidRateTestHelper.SPREAD);
        clientPriceAUDUSD = MidRateTestHelper.createClientPrice(Instrument.AUDUSD, 1, 0.76, MidRateTestHelper.SPREAD, AmountUnit.MILLIONS.toDollar(1_000));
        clientPriceConsumer = crossRateManager.consumerClientPrice();
    }

    @Test
    public void testCheckPassThrough() throws IOException {
        helper.testAllocationNotExceeded(
                this::checkPassThrough,
                THRESHOLD
        );
    }

    @Test
    public void testCheckTwoPrice() throws IOException {
        helper.testAllocationNotExceeded(
                this::checkTwoPrice,
                ByteWatcherTodo.THRESHOLD_CrossRateManagerBWTest
        );
    }

    private void checkPassThrough() {
        for (int i = 1; i < REPS; i++) {
            clientPriceConsumer.accept(clientPriceAUDCAD);
            GcFriendlyAssert.isTrue(nfys.size() == i);
        }
    }

    private void checkTwoPrice() {
        for (int i = 1; i < REPS; i++) {
            mutate((PriceAndQtyImpl) clientPriceAUDUSD.getBids().get(0));
            mutate((PriceAndQtyImpl) clientPriceGPBUSD.getBids().get(0));
            clientPriceConsumer.accept(clientPriceAUDUSD);
            clientPriceConsumer.accept(clientPriceGPBUSD);
        }
        GcFriendlyAssert.isTrue(nfys.size() == 299525);
    }

    private void mutate(final PriceAndQtyImpl clientPricePoint) {
        clientPricePoint.setPrice(clientPricePoint.getPrice() + PriceUtil.randomMinAbs(random,0.5) / 1_000);
    }
}