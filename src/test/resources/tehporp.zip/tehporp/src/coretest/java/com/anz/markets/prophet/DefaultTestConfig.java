package com.anz.markets.prophet;

import com.anz.markets.disco.data.MutableSignals;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBook;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.riskpath.RiskPath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.function.Consumer;

import static com.anz.markets.prophet.config.app.CoreConfig.TRADING_TIME_ZONE_CHIME_SINK;

@Configuration
public class DefaultTestConfig {

    @Autowired
    Consumer<MarketData> marketDataConsumers;
    @Autowired
    Consumer<Adjustment> adjustmentConsumers;
    @Autowired
    Consumer<Trade> tradeConsumer;
    @Autowired
    Consumer<OneSecond> oneSecondConsumer;
    @Autowired
    Consumer<SpotDate> spotDateConsumer;
    @Autowired
    Consumer<ConfigurationData> configurationDataConsumer;
    @Autowired
    Consumer<TradingTimeZoneChime> tradingTimeZoneChimeConsumer;
    @Autowired
    Consumer<AggregatedBook> aggregatedBookConsumer;

    @Bean
    public TestStubConsumer<ValueAtRisk> varSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<Activate> activateSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubPortfolioAwareConsumer<Positions> positionsSink() {
        return new TestStubPortfolioAwareConsumer<>(() -> new Positions());
    }

    @Bean
    public TestStubConsumer<ClientPrice> clientPriceSink() {
        return new TestStubConsumer<>(() -> new ClientPriceImpl());
    }

    @Bean
    public TestStubConsumer<Signals> signalsSink() {
        return new TestStubConsumer<>(() -> new MutableSignals());
    }

    @Bean
    public TestStubPortfolioAwareConsumer<ProfitAndLoss> profitAndLossSink() {
        return new TestStubPortfolioAwareConsumer<>();
    }

    @Bean
    public TestStubConsumer<MidRate> marketDataSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<Order> orderSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<VolatilityControl> volatilityControlSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<HedgePauseSignal> hedgePauseSignalSink() { return new TestStubConsumer<>(); }

    @Bean
    public TestStubConsumer<HedgeCurrencyControl> hedgeCurrencyControlSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<OptimalPositions> optimalPositionsSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<RealisedVolatility> realisedVolatilitySink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<IndexedConfigurationData> configurationSink() {
        return new TestStubConsumer<>();
    }

    @Bean(name = TRADING_TIME_ZONE_CHIME_SINK)
    public TestStubConsumer<TradingTimeZoneChime> tradingTimeZoneChimeSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<HedgeStatus> hedgeStatusSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<HedgeDecision> hedgeDecisionSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<HedgeFirewallStatus> hedgeFirewallStatusSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<WholesaleBookFactors> wholesaleBookFactorsSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<EndOfWeekChime> endOfWeekChimeSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<RiskPath> riskPathManagerSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<AggregatedBook> aggregatedBookSink() {
        return new TestStubConsumer<>();
    }

    @Bean
    public TestStubConsumer<SkewCurrencyControl> skewCurrencyControlSink() {
        return new TestStubConsumer<>();
    }
}
