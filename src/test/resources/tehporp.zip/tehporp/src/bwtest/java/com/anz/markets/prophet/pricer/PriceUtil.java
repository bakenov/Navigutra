package com.anz.markets.prophet.pricer;

import java.security.SecureRandom;
import java.util.Random;

public class PriceUtil {

    /**
     * @param minAbs see below
     * @return a double between -1.0 and 1.0 but with its absolute value greater than minAbs e.g. -0.6, +0.7
     */
    public static double randomMinAbs(final Random random, final double minAbs) {
        double rv;
        while (true) {
            rv = (2 * random.nextDouble()) - 1; // between -1 and 1
            if (Math.abs(rv) >= minAbs) {
                break;
            }
        }
        return rv;
    }
}
