package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.SeekException;
import com.anz.markets.prophet.chronicle.config.StartAtSeeker;
import com.anz.markets.prophet.domain.chronicle.Header;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.wire.DocumentContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.function.ToLongFunction;

public class ChronicleQueueStartAtSeekerRB implements StartAtSeeker {
    protected static final Logger LOGGER = LogManager.getLogger(ChronicleQueueStartAtSeekerRB.class);
    private final ExcerptTailer tailer;

    // NOTE: Depending on the StartAt type, the config start position could be a queue INDEX, or any attribute of Header
    private final long configStartPosition;

    // For unmarshalling of headers while searching
    private final Header header = new Header();

    ChronicleQueueStartAtSeekerRB(final ExcerptTailer excerptTailer, final long startConfig) {
        this.tailer = excerptTailer;
        this.configStartPosition = startConfig;
    }

    @Override
    public void firstIndex() {
        // do nothing
    }

    @Override
    public void lastIndex() {
        tailer.toEnd();
    }

    @Override
    public void configIndex() {
        verifyIndex(configStartPosition);
    }

    @Override
    public void findIndex(final ToLongFunction<Header> headerToLongFunction, final boolean exactMatch) {
        if (configStartPosition <= 0) {
            return;
        }

        long lastConfigStartPosition = 0;
        // just keep tailing until the end
        while (true) {
            try (final DocumentContext dc = tailer.readingDocument()) {
                if (!dc.isPresent()) {
                    if (exactMatch) {
                        throw new SeekException("Could not seek to exact match", configStartPosition);
                    } else {
                        LOGGER.warn("We were looking for {} but did not find it before the end. Last we saw was {}", configStartPosition, lastConfigStartPosition);
                        // we are just past the end - this is going to have to be good enough
                        return;
                    }
                }

                ChronicleObjectReader.readHeader(ChronicleQueueWrappers.wrapReader(dc), header);
                long value = headerToLongFunction.applyAsLong(header);
                if (value == configStartPosition) {
                    // leave us pointing to this one
                    dc.rollbackOnClose();
                    return;
                } else if (value > configStartPosition && ! exactMatch) {
                    LOGGER.warn("We were looking for {} but went past it so are accepting {}", configStartPosition, value);
                    // leave us pointing to this one
                    dc.rollbackOnClose();
                    return;
                }
                lastConfigStartPosition = value;
            }
        }
    }

    private void verifyIndex(final long index) {
        if (index < 0) {
            return;
        }

        final boolean ok = tailer.moveToIndex(index);
        if (!ok) {
            throw new SeekException("Cannot seek by index", index);
        }
    }
}