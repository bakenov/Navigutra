package com.anz.markets.efx.ngaro.sbe;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link GroupCount}.
 */
@RunWith(MockitoJUnitRunner.class)
public class GroupCountTest {

    @Mock
    private IntSupplier limitReader;
    @Mock
    private IntConsumer limitWriter;
    @Mock
    private IntConsumer countWriter;

    private InOrder inOrder;

    private GroupCount groupCount;

    @Before
    public void beforeEach() {
        inOrder = inOrder(limitReader, limitWriter, countWriter);
        groupCount = new GroupCount(limitReader, limitWriter, countWriter);
    }

    @Test
    public void adjust_reduceCount() throws Exception {
        //given
        final int limit1 = 123;
        final int limit2 = 456;
        when(limitReader.getAsInt()).thenReturn(limit1, limit2);

        //when
        final int max = 22;
        groupCount.init(max);

        //then
        inOrder.verify(limitReader).getAsInt();

        //when
        final int count = 3;
        groupCount.increment();
        groupCount.increment();
        groupCount.increment();

        //then
        assertEquals("count not as expected", count, groupCount.count());

        //when
        groupCount.adjustAndReset();

        //then
        inOrder.verify(limitReader).getAsInt();
        inOrder.verify(limitWriter).accept(limit1);
        inOrder.verify(countWriter).accept(count);
        inOrder.verify(limitWriter).accept(limit2);
        assertEquals("count should have been reset", 0, groupCount.count());
    }

    @Test
    public void adjust_preserveCount() throws Exception {
        //given
        final int limit1 = 123;
        final int limit2 = 456;
        when(limitReader.getAsInt()).thenReturn(limit1, limit2);

        //when
        final int max = 3;
        groupCount.init(max);

        //then
        inOrder.verify(limitReader).getAsInt();

        //when
        final int count = 3;
        groupCount.increment();
        groupCount.increment();
        groupCount.increment();

        //then
        assertEquals("count not as expected", count, groupCount.count());

        //when
        groupCount.adjustAndReset();

        //then
        inOrder.verify(limitReader, never()).getAsInt();
        inOrder.verify(limitWriter, never()).accept(limit1);
        inOrder.verify(countWriter, never()).accept(count);
        inOrder.verify(limitWriter, never()).accept(limit2);
        assertEquals("count should have been reset", 0, groupCount.count());
    }

    @Test(expected = IllegalStateException.class)
    public void adjust_exceedMaxCount() throws Exception {
        //given
        final int limit1 = 123;
        final int limit2 = 456;
        when(limitReader.getAsInt()).thenReturn(limit1, limit2);

        //when
        final int max = 3;
        groupCount.init(max);

        //then
        inOrder.verify(limitReader).getAsInt();

        //when
        groupCount.increment();
        groupCount.increment();
        groupCount.increment();
        groupCount.increment();

        //then
        fail("Forth increment should have caused an exception");
    }
}