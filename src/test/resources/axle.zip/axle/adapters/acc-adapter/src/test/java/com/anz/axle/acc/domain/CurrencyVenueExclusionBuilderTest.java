package com.anz.axle.acc.domain;

import com.anz.axle.datafabric.client.config.CurrencyVenueExclusionKey;
import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.common.domain.*;
import org.joda.time.LocalDate;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public class CurrencyVenueExclusionBuilderTest {
    @Test
    public void test_that_exclusion_map_is_built() throws BuilderException {
        Currency aud = new Currency(1l, "AUD", "AUD", 2);
        Currency usd = new Currency(2l, "USD", "USD", 2);
        CurrencyPair audusd = new CurrencyPair(aud, usd);
        Venue venue = new Venue();
        venue.setAggregatorCode("BARX");

        CurrentVenueCurrencyCreditState state = new CurrentVenueCurrencyCreditState(true, audusd, venue, new LocalDate(), new LocalDate(), 0.83d);
        CurrencyVenueExclusionBuilder venueExclusionBuilder = new CurrencyVenueExclusionBuilder();
        venueExclusionBuilder.setKeyBuilder(new CurrencyVenueExclusionKeyBuilder());
        CurrencyVenueExclusion exclusion = venueExclusionBuilder.build(state);
        CurrencyVenueExclusionKey key = exclusion.getKey();

        assertEquals("BARX", key.getVenue());
        assertEquals("AUD/USD", key.getSymbol());
        assertEquals("CREDIT_CHECK", key.getSource());

        assertTrue(exclusion.isCommonExclusion());
        assertTrue(exclusion.isExcluded());
        assertEquals("BARX", exclusion.getVenue());
        assertEquals("AUD/USD", exclusion.getSymbol());
        assertEquals("CREDIT_CHECK", exclusion.getSource());
    }

    @Test
    public void test_that_non_breached_exclusion_map_is_built() throws BuilderException {
        Currency aud = new Currency(1l, "AUD", "AUD", 2);
        Currency usd = new Currency(2l, "USD", "USD", 2);
        CurrencyPair audusd = new CurrencyPair(aud, usd);
        Venue venue = new Venue();
        venue.setAggregatorCode("BARX");

        CurrentVenueCurrencyCreditState state = new CurrentVenueCurrencyCreditState(false, audusd, venue, new LocalDate(), new LocalDate(), 0.83d);
        CurrencyVenueExclusionBuilder venueExclusionBuilder = new CurrencyVenueExclusionBuilder();
        CurrencyVenueExclusionKeyBuilder venueExclusionKeyBuilder = new CurrencyVenueExclusionKeyBuilder();
        venueExclusionBuilder.setKeyBuilder(venueExclusionKeyBuilder);
        CurrencyVenueExclusion exclusion = venueExclusionBuilder.build(state);

        CurrencyVenueExclusionKey key = exclusion.getKey();

        assertEquals("BARX", key.getVenue());
        assertEquals("AUD/USD", key.getSymbol());
        assertEquals("CREDIT_CHECK", key.getSource());

        assertTrue(exclusion.isCommonExclusion());
        assertFalse(exclusion.isExcluded());
        assertEquals("BARX", exclusion.getVenue());
        assertEquals("AUD/USD", exclusion.getSymbol());
        assertEquals("CREDIT_CHECK", exclusion.getSource());
    }
}