package com.anz.axle.lg.adapter.rfx.config;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.LongConsumer;

import org.agrona.concurrent.UnsafeBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.adapter.rfx.common.SymbolPriceDecimalFormat;
import com.anz.axle.lg.adapter.rfx.common.TenorLookup;
import com.anz.axle.lg.adapter.rfx.trading.TradingSessionRepository;
import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.axle.lg.config.LongConsumerSupplier;
import com.anz.axle.lg.decoder.TradingRequestMessageHandler;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Subscription;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoderBuilder;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingEncoders;

@Configuration
public class TradingConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(TradingConfig.class);

    private final String compId;
    private final Venue venue;

    public TradingConfig(@Value("${messaging.compId}") final String compId, @Value("${venue}") final Venue venue) {
        this.compId = Objects.requireNonNull(compId);
        this.venue = Objects.requireNonNull(venue);
    }

    @Bean
    public LongConsumerSupplier receivedTimeConsumerSupplier() {
        return new LongConsumerSupplier();
    }

    @Bean
    public Topic rfxTradingResponseTopic(final PublicationRegistry publicationRegistry) {
        final Topic tradingResponseTopic = DefaultTopic.create(venue.name()+"_TRADING_RESPONSE");
        publicationRegistry.registerPublication(tradingResponseTopic);
        return tradingResponseTopic;
    }

    @Bean
    public Topic rfxTradingRequestTopic() {
        return DefaultTopic.create(venue.name()+"_TRADING_REQUEST");
    }

    @Bean
    public TradingEncoderSupplier rfxTradingEncoderSupplier(@Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity,
                                                            final MessageHandler publisher,
                                                            final Topic rfxTradingResponseTopic) {
        final Consumer<SbeMessage> tradingResponseConsumer = sbeMessage -> publisher.onMessage(
                rfxTradingResponseTopic, sbeMessage.buffer(), 0, sbeMessage.messageLength(), 0
        );
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbeTradingEncoders(() -> sbeMessage).toTradingEncoderSupplier(tradingResponseConsumer);
    }

    @Bean
    public SymbolPriceDecimalFormat symbolPriceDecimalFormat(@Value("#{${rfx.fix.symbol.price.decimal.places}}") final Map<Integer, Set<String>> decimalSymbols) {
        return new SymbolPriceDecimalFormat(decimalSymbols);
    }

    @Bean
    public TradingRequestMessageHandler rfxTradingRequestMessageHandler(@Qualifier("receivedTimeConsumerSupplier") final LongConsumer receivedTimeConsumer,
                                                                        final SessionState tradingSessionState,
                                                                        final TradingSessionRepository tradingSessionRepository,
                                                                        final TenorLookup tenorLookup,
                                                                        final SymbolPriceDecimalFormat symbolPriceDecimalFormat,
                                                                        final @Qualifier("rfxTradingEncoderSupplier") TradingEncoderSupplier rfxTradingEncoderSupplier,
                                                                        final FixMessageSender fixTradingMessageSender,
                                                                        final LongIdFactory messageIdGenerator,
                                                                        final PrecisionClock precisionClock,
                                                                        final SourceSequencer sourceSequencer) {
        final Consumer<NewOrderSingleDecoder> rfxNewOrderSingleHandler = new EbsNewOrderSingleHandler(rfxTradingEncoderSupplier, fixTradingMessageSender, tradingSessionState, tradingSessionRepository, tenorLookup, symbolPriceDecimalFormat, compId, messageIdGenerator, sourceSequencer);
        final Consumer<OrderCancelRequestDecoder> rfxOrderCancelRequestHandler = new EbsOrderCancelRequestHandler(rfxTradingEncoderSupplier, fixTradingMessageSender, tradingSessionState, tenorLookup, messageIdGenerator, precisionClock, compId, sourceSequencer);

        final MessageDecoder<SbeMessage> tradingMessageDecoder = SbeTradingDecoderBuilder.create()
                .newOrderSingle(new NewOrderSingleMessageDecoder(rfxNewOrderSingleHandler))
                .orderCancelRequest(new OrderCancelRequestMessageDecoder(rfxOrderCancelRequestHandler))
                .build();
        return new TradingRequestMessageHandler(receivedTimeConsumer, tradingMessageDecoder);
    }

    @Bean
    EndPointStatusHandler ebsEndPointStatusHandler() {
        return new LoggingStatusHandler(LOGGER);
    }

    @Bean
    public Subscription tradingRequestSubscription(final Connection connection,
                                                   final Topic ebsTradingRequestTopic,
                                                   final EndPointStatusHandler ebsEndPointStatusHandler,
                                                   final MessageHandler ebsTradingRequestMessageHandler) {
        return connection.openSubscription(ebsTradingRequestTopic, ebsEndPointStatusHandler, ebsTradingRequestMessageHandler);
    }

    @Bean
    public EbsOrderMassCancelRequestHandler ebsOrderMassCancelRequestHandler(final FixMessageSender ebsMessageSender,
                                                                             final LongIdFactory messageIdGenerator,
                                                                             final PrecisionClock precisionClock) {
        return new EbsOrderMassCancelRequestHandler(ebsMessageSender, messageIdGenerator, precisionClock);
    }

    @Bean
    public Runnable healthCheckFailAction(final EbsOrderMassCancelRequestHandler ebsOrderMassCancelRequestHandler) {
        return ebsOrderMassCancelRequestHandler::sendCancelAll;
    }
}
