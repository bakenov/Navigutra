package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.util.Arrays.asList;
import static java.util.concurrent.TimeUnit.DAYS;
import static java.util.concurrent.TimeUnit.HOURS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Ref.HEDGING_FIREWALL_4_9_15, Ref.PROFIT_AND_LOSS_4_2_8, Ref.PROFIT_AND_LOSS_4_2_9})
public class AggregatedPnlProfitFirewallTest extends ForEachHedgePortfolioBaseAcceptanceSpecification {

    // todo:
    // NaN pnl should update hedge firewall status as breached.

    // Aggregated PnL is the sum of Instantaneous PnL(before it is revaled) + Reval PnL
    @Test
    public void shouldSendBreachedNotBreachedStatusWhenMidRateChangesFor1DayWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_PROFIT_PER_DAY, 399.0, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.95110));
            prophet.clearOutputBuffer();
        }
        when:
        // t+0, first trade not breached.
        {
            // instantaneous pnl of 100
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 1_000_000, 0.95100));
        }
        then:
        // pnl 100 => not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_PROFIT_PER_DAY, NOT_BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+20, instantaneous pnl update with new mid rate - not breached.
        {
            prophet.incrementTime(20 * 1_000);
            // instantaneous pnl of 490
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.95149));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+30, reval - pnl 490 is crystallised.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+35, new mid rate. no change in aggregated pnl(no breach) as hedge trade 1 crystallised
        {
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.95160));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+1hr, next 1hr bucket hedge trade 2 received
        {
            // trade pnl of -10
            // Aggregated pnl = 490 + (-10) = 480
            prophet.incrementTime(HOURS.toMillis(1) - SECONDS.toMillis(35));
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 1_000_000, 0.95161));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+1hr+5sec, hedge trade 3 received
        {
            // trade pnl of +20
            // Aggregated pnl = 480 + 20 = 500 => breached
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 1_000_000, 0.95158));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio, BREACHED, 400, 500, 100, 500, 399));
        }
        when:
        // t+1day, first 100pnl point slides out
        {
            // prophet.incrementTime(DAYS.toMillis(1) - HOURS.toMillis(1) - SECONDS.toMillis(5));
            prophet.incrementTime(TimeUnit.HOURS.toMillis(12));
            prophet.incrementTime(TimeUnit.HOURS.toMillis(10));
            prophet.incrementTime(TimeUnit.MINUTES.toMillis(59));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(55));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio, NOT_BREACHED, 20, 0, 480, 500, 399));
        }
    }

    @Test
    public void verifyAggregatedProfitCalcLossToProfit() {
        firewallBreached(false);
    }

    public void firewallBreached(final boolean ignoreFirstStatus) {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_PROFIT_PER_DAY, 300.00, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -100.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.95100));
            prophet.clearOutputBuffer();
        }
        when:
        // t+0, first trade not breached.
        {
            // instantaneous pnl of -100
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, 2_000_000, 0.95105));
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_PROFIT_PER_DAY, NOT_BREACHED, portfolio));
            prophet.clearOutputBuffer();
        }
        when:
        // t+30, reval - pnl is crystallised. remain breached - no change therefore no status update.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+40, hedge trade 2 received
        {
            // trade pnl of +300
            // Aggregated pnl = -100 + (300) = 200
            prophet.incrementTime(10 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, -3_000_000, 0.95110));
        }
        then:
        {   // t+30 Agg P/L = -100 (LOWEST)
            // t+40 Agg P/L = 200 (HIGH)
            // PROFIT = 300.00  => Equals limit => NOT BREACHED
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio));
        }
        when:
        // t+1hour, i.e next 1hr bucket hedge trade 3 received
        {
            // trade pnl of +0.10
            // Aggregated pnl = 200 + (0.1) = 200.10
            prophet.incrementTime(TimeUnit.HOURS.toMillis(1) - TimeUnit.SECONDS.toMillis(40));
            prophet.receive(tdd.hedge_trade_001(portfolio, Instrument.AUDUSD, -10_000, 0.95101));
        }
        then:
        {   // t+30 Agg P/L = -100 (LOWEST)
            // t+1hr Agg P/L = 200.10 (HIGH)
            // PROFIT = 300.10  => BREACHED
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio, BREACHED, 300.10, 200.10, -100, 200.10, 300.00));
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() {
        firewallBreached(false);
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, AGGREGATED_PNL_PROFIT_PER_DAY));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_PROFIT_PER_DAY, portfolio)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
            assertThat(status.getPortfolio(), CoreMatchers.is(portfolio));
            prophet.clearOutputBuffer();
        }
        firewallBreached(true);
    }
}
