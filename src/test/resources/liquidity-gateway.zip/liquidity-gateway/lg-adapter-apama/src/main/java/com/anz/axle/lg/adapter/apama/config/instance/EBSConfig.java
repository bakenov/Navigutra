package com.anz.axle.lg.adapter.apama.config.instance;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.apama.config.core.EnablePublishing;
import com.anz.axle.lg.adapter.apama.config.venue.EBSVenueSubscribingConfig;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
@EnablePublishing
@Import(EBSVenueSubscribingConfig.class)
public class EBSConfig {

    @Bean
    public String instanceName() {
        return Venue.EBS.name();
    }
}
