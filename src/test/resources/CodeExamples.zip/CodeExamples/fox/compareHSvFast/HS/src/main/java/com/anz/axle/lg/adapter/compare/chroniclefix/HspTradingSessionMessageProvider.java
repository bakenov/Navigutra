package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.nio.ByteBuffer;
import java.util.Objects;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.fields.EncryptMethod;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.VanillaSessionMessageProvider;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.datamodel.DefaultLogon;

public class HspTradingSessionMessageProvider extends VanillaSessionMessageProvider {
    private static final Logger LOGGER = LoggerFactory.getLogger(HspTradingSessionMessageProvider.class);
    private boolean firstTime = true;

    private final String userName;
    private final String password;
    private FixSessionCfg fixSessionCfg;
    final boolean onceOffResetSeqNumber;

    public HspTradingSessionMessageProvider(final String name,
                                            final String userName,
                                            final String password,
                                            final boolean onceOffResetSeqNumber,
                                            final FixSessionCfg fixSessionCfg) {
        this.userName = Objects.requireNonNull(userName);
        this.password = Objects.requireNonNull(password);
        this.onceOffResetSeqNumber = onceOffResetSeqNumber;
        if (onceOffResetSeqNumber) {
            this.fixSessionCfg = Objects.requireNonNull(fixSessionCfg);
        }

        LOGGER.info("{} - Once-off sequence reset is {}", Objects.requireNonNull(name), onceOffResetSeqNumber ? "enabled" : "disabled");
    }

    @Override
    public Logon getLogon(@NotNull final Bytes<ByteBuffer> bytes, @NotNull final FixSessionContext context, @NotNull final SessionID sessionID, final long heartbeatInterval, final char resetSeqNumFlag) {

        final Logon logon = new DefaultLogon();

        logon.encryptMethod(EncryptMethod.NONE_OTHER);
        logon.heartBtInt(heartbeatInterval);

        final String rawData = userName + ":" + password;
        logon.rawData(rawData);
        logon.rawDataLength(rawData.length());

        if (onceOffResetSeqNumber) {
            onceOffResetSeqNumber(logon, resetSeqNumFlag);
        }

        return logon;
    }

    private void onceOffResetSeqNumber(final Logon logon, final char resetSeqNumFlag) {
        if (firstTime) {
            logon.resetSeqNumFlag( 'Y');
            fixSessionCfg.msgSequenceHandler().resetToInitialState();
            firstTime = false;
        } else {
            if (resetSeqNumFlag != FixMessage.UNSET_CHAR) {
                logon.resetSeqNumFlag(resetSeqNumFlag);
            }
        }
    }
}
