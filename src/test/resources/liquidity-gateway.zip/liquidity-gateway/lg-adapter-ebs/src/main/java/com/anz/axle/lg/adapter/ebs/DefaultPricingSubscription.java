package com.anz.axle.lg.adapter.ebs;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import com.anz.axle.lg.util.CachedFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.CustRepeatingBlocks_RelatedSymGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.MarketDataSubscriber;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.axle.lg.config.VenueSymbolMatrix;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class DefaultPricingSubscription implements PricingSubscription {

    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultPricingSubscription.class);
    private final TopicRegistry pricingTopicRegistry;
    private final PublicationRegistry publicationRegistry;
    private final MarketDataSubscriber marketDataSubscriber;
    private final Supplier<LogonHandler> logonHandlerSupplier;
    private final Supplier<LogonHandler> sessionStateLogonHandlerSupplier;
    private final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory;
    private final VenueSymbolMatrix fxSpotVenueSymbolMatrix;
    private final VenueSymbolMatrix fxNdfVenueSymbolMatrix;
    private final Map<String, Set<Tenor>> fxNdfSymbolTenors;
    private final TenorLookup tenorLookup;
    private final Venue venue;

    private final CachedFunction<String, String> symbol6Lookup = CachedFunction.of(SymbolNormaliser::toSymbol6);

    public DefaultPricingSubscription(final TopicRegistry pricingTopicRegistry,
                                      final PublicationRegistry publicationRegistry,
                                      final MarketDataSubscriber marketDataSubscriber,
                                      final Supplier<LogonHandler> logonHandlerSupplier,
                                      final Supplier<LogonHandler> sessionStateLogonHandlerSupplier,
                                      final Supplier<StringToIntCache> stringToIntQuoteIdCacheFactory,
                                      final Map<String, Set<Venue>> fxSpotSymbolVenues,
                                      final Map<String, Set<Venue>> fxNdfSymbolVenues,
                                      final Map<String, Set<Tenor>> fxNdfSymbolTenors,
                                      final TenorLookup tenorLookup,
                                      final Venue venue) {
        this.pricingTopicRegistry = Objects.requireNonNull(pricingTopicRegistry);
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.marketDataSubscriber = Objects.requireNonNull(marketDataSubscriber);
        this.logonHandlerSupplier = Objects.requireNonNull(logonHandlerSupplier);
        this.sessionStateLogonHandlerSupplier = Objects.requireNonNull(sessionStateLogonHandlerSupplier);
        this.stringToIntQuoteIdCacheFactory = Objects.requireNonNull(stringToIntQuoteIdCacheFactory);
        this.fxSpotVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxSpotSymbolVenues));
        this.fxNdfVenueSymbolMatrix = new VenueSymbolMatrix(Objects.requireNonNull(fxNdfSymbolVenues));
        this.fxNdfSymbolTenors = Objects.requireNonNull(fxNdfSymbolTenors);
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
        this.venue = Objects.requireNonNull(venue);
    }

    @Override
    public void subscribe(final UserResponse userResponse) {
        for (int i = 0; i < userResponse.noRelatedSym(); i++) {
            final CustRepeatingBlocks_RelatedSymGrp_1 relatedSymGrp = userResponse.custRepeatingBlocks_RelatedSymGrp_1(i);

            final String symbol = symbol6Lookup.apply(relatedSymGrp.symbol());
            final SecurityType securityType = FixCFICode.from(relatedSymGrp.cFICode());
            final Tenor tenor = tenorLookup.anzTenor(relatedSymGrp.settlType());
            if (tenor == null) {
                LOGGER.warn("Can not map Tenor {} to internal for SecurityType={} Symbol={} - skip MarketDataSubscription", relatedSymGrp.settlType(), securityType, symbol);
                continue;
            }
            if (!isCurrencyPairAvailable(symbol, securityType, tenor)) {
                continue;
            }

            final Topic topic = pricingTopicRegistry.topic(venue, InstrumentKey.of(symbol, securityType, tenor));
            publicationRegistry.registerPublication(topic);

            final EbsMarketDataSubscription fixSubscription = new EbsMarketDataSubscription(venue, symbol, securityType, tenor, stringToIntQuoteIdCacheFactory.get());
            marketDataSubscriber.schedule(fixSubscription);
        }
        logonHandlerSupplier.get().onLogon();
        sessionStateLogonHandlerSupplier.get().onLogon();
    }

    private boolean isCurrencyPairAvailable(final String symbol, final SecurityType securityType, final Tenor tenor) {
        final VenueSymbolMatrix venueSymbolMatrix = securityType == SecurityType.FXSPOT ? fxSpotVenueSymbolMatrix : fxNdfVenueSymbolMatrix;
        final boolean venueSymbolAvailable = venueSymbolMatrix.isPresent(venue, symbol);
        final boolean symbolTenorAvailable = isTenorPresent(symbol, tenor);
        return securityType == SecurityType.FXSPOT ? venueSymbolAvailable : venueSymbolAvailable && symbolTenorAvailable;
    }

    private boolean isTenorPresent(final String symbol, final Tenor tenor) {
        final Set<Tenor> tenors = fxNdfSymbolTenors.get(symbol);
        return tenors != null && tenors.contains(tenor);
    }
}
