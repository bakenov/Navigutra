package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.pricing.codec.api.RefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

public class DefaultSnapshotterDecoderLookup implements SnapshotterDecoderLookup {

    private final Map<RequestKey, SnapshotterDecoderSupplier> cache = new HashMap<>();
    private final VenueRequestKeyLookup requestKeyLookup;
    private final Function<RequestKey, SnapshotterDecoderSupplier> snapshotterDecoderSupplierFactory;
    private final ByteValueCache<String> symbolCache = new ByteValueCache<>(AsciiString::toString);

    public DefaultSnapshotterDecoderLookup(
            final VenueRequestKeyLookup requestKeyLookup,
            final Function<RequestKey, SnapshotterDecoderSupplier> snapshotterDecoderSupplierFactory) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.snapshotterDecoderSupplierFactory = Objects.requireNonNull(snapshotterDecoderSupplierFactory);
    }

    @Override
    public SnapshotterDecoderSupplier lookup(final RefreshHandler.Body body) {
        final RequestKey requestKey = requestKeyLookup.lookup(body.instrumentId());
        return lookup(requestKey);
    }

    @Override
    public SnapshotterDecoderSupplier lookup(final RequestKey requestKey) {
        return cache.computeIfAbsent(requestKey, snapshotterDecoderSupplierFactory);
    }
}