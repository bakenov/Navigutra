#!/bin/bash

source ~/bin/shell-env/daxa009z/.functions

dfhosts="auq4014s auq4015s auq4000s auq4013s"
otherhosts="auq4016s auq4054s auq4009s auq4011s"
parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "cd axle/environment/bin; ./start.sh") ::: $dfhosts

parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "cd axle/environment/bin; ./start.sh") ::: $otherhosts
