package com.anz.markets.prophet.atest.pricing._0a_pre_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


public class BandedMktToStackTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_AXPROPHET_1003)
    public void bandedBookToStackedBookConversion() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        // Standard BANDED Quantities converted to Stacked
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 1_000_000),
                            new PriceAndQtyImpl(0.75027, 3_000_000),
                            new PriceAndQtyImpl(0.75020, 5_000_000),
                            new PriceAndQtyImpl(0.75010, 10_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75051, 3_000_000),
                            new PriceAndQtyImpl(0.75059, 5_000_000),
                            new PriceAndQtyImpl(0.75069, 10_000_000)),
                    tdd.now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.DEUT)).getFirst();
            // LEVELS_TO_WRITE = 3 so only 3 levels are written to chron
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75030, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_2M, 0.75025, 0.75052));  // 0.7502550, 0.7505150
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_2M, 0.75009, 0.75071));  // 0.750095, 0.750710
        }
        when:
        // non-standard BANDED Quantities
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75040, 500_000),
                            new PriceAndQtyImpl(0.75035, 1_500_000),
                            new PriceAndQtyImpl(0.75030, 4_500_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 3_000_000),
                            new PriceAndQtyImpl(0.75060, 4_000_000)),
                    tdd.now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.DEUT)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_500K, 0.75040, Level.QTY_1M, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_1M, 0.75032, Level.QTY_2M, 0.75058)); // 0.750325, 0.750575
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_3M, 0.75027, Level.QTY_1M, 0.75075)); // bid 0.750275
        }
        when:
        // non BANDED Market remains untouched
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75041, 1_000_000),
                            new PriceAndQtyImpl(0.75035, 3_000_000),
                            new PriceAndQtyImpl(0.75030, 5_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 3_000_000),
                            new PriceAndQtyImpl(0.75060, 4_000_000)),
                    tdd.now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.CNX)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75041, Level.QTY_1M, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_3M, 0.75035, Level.QTY_3M, 0.75055));
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_5M, 0.75030, Level.QTY_4M, 0.75060));
        }
        when:
        // Banded market containing 'bad' quantities are left unchanged i.e banded quantities should be increasing
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75042, 1_000_000),
                            new PriceAndQtyImpl(0.75035, 1_000_000),
                            new PriceAndQtyImpl(0.75030, 3_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 3_000_000),
                            new PriceAndQtyImpl(0.75060, 4_000_000)),
                    tdd.now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.DEUT)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.75042, Level.QTY_1M, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_1M, 0.75035, Level.QTY_3M, 0.75055));
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_3M, 0.75030, Level.QTY_4M, 0.75060));
        }
        when:
        // ensure stacked book is sorted on price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75045, 1_000_000),
                            new PriceAndQtyImpl(0.75040, 3_000_000),
                            new PriceAndQtyImpl(0.75039, 5_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.750500, 1_000_000),
                            new PriceAndQtyImpl(0.750540, 3_000_000),
                            new PriceAndQtyImpl(0.750560, 5_000_000),
                            new PriceAndQtyImpl(0.750570, 10_000_000)),
                    tdd.now()));
        }
        then:
        // offer side: 5mio stack price(0.75058) is less than 2mio stack(0.75059)
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.DEUT)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.750450, Level.QTY_1M, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_2M, 0.750370, Level.QTY_2M, 0.75056));
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_2M, 0.750370, Level.QTY_5M, 0.75058));
        }
        when:
        // AXPROPHET-1257 ensure banded book is sorted on quantity for same price points before converting to stack
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.DEUT, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75046, 1_000_000),
                            new PriceAndQtyImpl(0.75042, 5_000_000),
                            new PriceAndQtyImpl(0.75042, 3_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 3_000_000),
                            new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 5_000_000)),
                    tdd.now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.DEUT)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.750460, Level.QTY_1M, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_2M, 0.750420, Level.QTY_2M, 0.75050));
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_2M, 0.750400, Level.QTY_1M, 0.75063));
        }
    }
}
