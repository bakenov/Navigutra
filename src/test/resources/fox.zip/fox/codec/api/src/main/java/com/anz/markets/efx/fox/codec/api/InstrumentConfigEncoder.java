package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;

public interface InstrumentConfigEncoder extends MessageEncoder<InstrumentConfigEncoder.Body> {
    @Override
    Body messageStart(final int source, final long sourceSeq);

    interface Body {
        Body instrumentId(long instrumentId);
        Body pipSizeDivisor(int pipSizeDivisor);
        Trailer enabled(boolean enabled);
    }
}
