package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.sbe.VenueConfigSbeDecoder;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class VenueConfigCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueConfigCommand.class);

    private final VenueRepository venueRepository;
    private final CommandContext commandContext;
    private final VenueConfigSbeDecoder venueConfigDecoder = new VenueConfigSbeDecoder();
    private final ByteValueCache<String> compIdCache = new ByteValueCache<>(AsciiString::toString);


    private final StringBuilder stringBuilder = new StringBuilder();

    public VenueConfigCommand(final VenueRepository venueRepository,
                              final CommandContext commandContext) {
        this.venueRepository = Objects.requireNonNull(venueRepository);
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!venueConfigDecoder.wrap(message)) return false;

        logMessage();

        final Venue venueId = venueConfigDecoder.body().venue();
        final String compId = venueConfigDecoder.body().compId().decodeAndCache(compIdCache);

        final com.anz.markets.efx.fox.api.domain.Venue foundVenueByVenueId = venueRepository.lookup(venueId);
        if (foundVenueByVenueId == null) {
            final com.anz.markets.efx.fox.api.domain.Venue foundVenueByCompId = venueRepository.lookup(compId);
            if (foundVenueByCompId == null) {
                commandContext.eventApplier().decode(message);
            } else {
                LOGGER.warn("Venue with compId {} already exists. Ignoring this venue config command.", compId);
            }
        } else {
            final com.anz.markets.efx.fox.api.domain.Venue foundVenueByCompId = venueRepository.lookup(compId);
            if (foundVenueByVenueId == foundVenueByCompId) {
                commandContext.eventApplier().decode(message);
            } else {
                LOGGER.warn("Cannot modify venue compId, venueId {}. Ignoring this venue config command.", venueId);
            }
        }
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        venueConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Create or Update Venue Command: {}", stringBuilder);
    }
}
