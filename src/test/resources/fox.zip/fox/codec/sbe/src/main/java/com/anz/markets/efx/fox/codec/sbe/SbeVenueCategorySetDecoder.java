package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueCategoriesDecoder;
import com.anz.markets.efx.ngaro.codec.EnumSetDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetDecoder;

public final class SbeVenueCategorySetDecoder implements EnumerableSetDecoder<VenueCategory> {

    private final EnumerableSetDecoder<VenueCategory> delegate;

    public SbeVenueCategorySetDecoder(final Supplier<VenueCategoriesDecoder> decoderSupplier) {
        Objects.requireNonNull(decoderSupplier);
        this.delegate = new EnumSetDecoder<>(VenueCategory::length, VenueCategory::valueByOrdinal, venueCategory -> Enums.venueCategory(venueCategory, decoderSupplier.get()), () -> false);
    }

    @Override
    public boolean containsAny() {
        return delegate.containsAny();
    }

    @Override
    public boolean contains(final VenueCategory venueCategory) {
        return delegate.contains(venueCategory);
    }

    @Override
    public void decodeTo(final Consumer<? super VenueCategory> consumer) {
        delegate.decodeTo(consumer);
    }

    @Override
    public void decodeTo(final BiConsumer<? super VenueCategory, ? super Boolean> consumer) {
        delegate.decodeTo(consumer);
    }

    @Override
    public <S extends Set<? super VenueCategory>> S decodeTo(final S target) {
        return delegate.decodeTo(target);
    }
}
