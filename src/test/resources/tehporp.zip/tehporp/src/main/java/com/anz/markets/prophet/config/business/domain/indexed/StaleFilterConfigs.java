package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.StaleFilterConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.prophet.maths.Maths;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Map stale filter config by currency group into each instrument.
 * <p>
 * When currency in the instrument belong to different currency group, the largest stale timeout is used for that instrument.
 */
public class StaleFilterConfigs {
    private static final Logger LOGGER = LoggerFactory.getLogger(StaleFilterConfigs.class);
    private final EnumObjMap<Instrument, EnumDoubleMap<TradingTimeZone>> staleTimeOutInNanosByInstrument = new EnumObjMap<>(Instrument.class);

    public StaleFilterConfigs(final List<StaleFilterConfig> staleFilterConfigs) {
        final EnumObjMap<Currency, StaleFilterConfig> staleFilterConfigByCurrency = createStaleFilterConfigByCurrencyGroup(staleFilterConfigs);

        for (final Instrument instrument : Instrument.VALUES) {
            final EnumDoubleMap<TradingTimeZone> stalenessByTimeZone = new EnumDoubleMap<>(TradingTimeZone.class);
            for (final TradingTimeZone tradingTimeZone : TradingTimeZone.values()) {
                // @todo consider allowing for global configuration
                if (tradingTimeZone != TradingTimeZone.GLOBAL) {
                    final double staleForBaseMinute = getStaleTimeOutForTermsNanos(staleFilterConfigByCurrency, tradingTimeZone, instrument.getDealt());
                    final double staleForTermsMinute = getStaleTimeOutForTermsNanos(staleFilterConfigByCurrency, tradingTimeZone, instrument.getTerms());

                    // stale timeout is the largest - e.g., if one symbol is EM and another is MAJOR, the stale time out will be one of EM.
                    stalenessByTimeZone.put(tradingTimeZone, Maths.max(staleForBaseMinute, staleForTermsMinute));
                }
            }
            staleTimeOutInNanosByInstrument.put(instrument, stalenessByTimeZone);
        }
    }

    public long getTimeoutNanos(final Instrument instrument,
                                final TradingTimeZone tradingTimeZone) {
        return (long) staleTimeOutInNanosByInstrument.get(instrument).get(tradingTimeZone);
    }

    private double getStaleTimeOutForTermsNanos(
            final EnumObjMap<Currency, StaleFilterConfig> staleFilterConfigByCurrency,
            final TradingTimeZone tradingTimeZone,
            final Currency currency) {

        if (!staleFilterConfigByCurrency.containsKey(currency)) {
            final long defaultStaleTimeOutMin = StaleFilterConfig.DEFAULT_STALE_TIME_OUT_MIN;
            LOGGER.warn("Missing StaleFilterConfig for {}.  Using default {} minutes.", currency, defaultStaleTimeOutMin);
            return TimeUnit.MINUTES.toNanos(defaultStaleTimeOutMin);
        }

        final StaleFilterConfig staleFilterConfig = staleFilterConfigByCurrency.get(currency);
        final double staleTimeOutInMinute = staleFilterConfig.get(tradingTimeZone);
        final double staleTimeOutInNanos = Maths.convertFractionalMinutesToNanos(staleTimeOutInMinute);

        GcFriendlyAssert.isFalse(staleTimeOutInNanos < 0 && staleTimeOutInMinute > 0, "Market stale timeout in minute is too large %s. This value will gets converted into nano seconds and does not fit into the data type which results in negative value (%s). Please set stale timeout to be smaller.", staleTimeOutInMinute, staleTimeOutInNanos);
        // check nanos but log minute so that it is properly guarded at the last point and when there is an issue we can trace back to the datapoint.
        GcFriendlyAssert.isTrue(staleTimeOutInNanos > 0, "Market stale timeout(minute) must be more than zero. Currency: %s, TradingTimeZone: %s, TimeoutMinute: %s", currency, tradingTimeZone, staleTimeOutInMinute);
        return staleTimeOutInNanos;
    }

    private EnumObjMap<Currency, StaleFilterConfig> createStaleFilterConfigByCurrencyGroup(
            final List<StaleFilterConfig> staleFilterConfigs) {
        final EnumObjMap<Currency, StaleFilterConfig> staleTimeOutInMinuteByCurrencyGroup = new EnumObjMap(Currency.class);
        return staleTimeOutInMinuteByCurrencyGroup.putAll(staleFilterConfigs, staleFilterConfig -> staleFilterConfig.getCurrency());
    }
}
