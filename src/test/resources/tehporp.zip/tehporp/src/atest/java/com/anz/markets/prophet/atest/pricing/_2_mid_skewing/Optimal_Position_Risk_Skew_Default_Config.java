package com.anz.markets.prophet.atest.pricing._2_mid_skewing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason = "op cached")
public class Optimal_Position_Risk_Skew_Default_Config extends BaseAcceptanceSpecification {

    private Instrument indirectPair = Instrument.AUDUSD;

    @Test
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1134})
    public void default_maxSkewQuantities_config() {
        precondition:
        {
            prophet.resetAllPositions();
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OPTIMAL_POSITION_SKEW_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_POSITION_SKEW_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_SKEW_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 0.5))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD, 1.0))  // set high Overall-skew threshold
                    .setMaxSkewQuantities(Arrays.asList(
                        new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 3_750_000.0),
                        new MaxSkewQuantities(Market.WSP_A, Currency.USD, 4_000_000.0),
                        new MaxSkewQuantities(Market.ANY, Currency.AUD, 6_000_000.0),
                        new MaxSkewQuantities(Market.ANY, Currency.USD, 4_000_000.0)
                    ));

            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75000, 0.00003)); // no OP change as position=0

            // send client deal to generated optimal positions
            prophet.receive(tdd.client_trade_001(indirectPair, 5_000_000, 0.75100));
        }
        then:
        {
            // Risk skew monitors equiv position
            final List<OptimalPositions> optimalPositionsUpdates = prophet.expect(OptimalPositions.class, atLeast(1), isOptimalPositionType(OptimalPositionType.PRICING));
            assertThat(optimalPositionsUpdates.size(), is(1));

            assertThat(optimalPositionsUpdates.get(0), isOptimalPosition(tdd.optimalPosition(indirectPair, 5000000.0, 5000000.0, 3750000.0, 7500000.0, 5625000.0, 0.14920381668873167, 0.75000)));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(indirectPair, 0.75002, 0.00003));
        }
        then:
        // AUD/USD LONG optimal position is on MaxSkewQuantities limit.  Apply -ve skew to improve OFFER(client buy). Maximum -ve skew of 0.5 * 0.00003(base spread)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_A)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750005));
        }
        and:
        // since there is no MaxSkewQuantity specified for WSP_B, use value for ANY market. -ve Skew = (3.75/6) * 0.00003(base spread)
        {
            WholesaleBookFactors wholesaleBookFactors = prophet.expect(WholesaleBookFactors.class, atLeast(1), isWholesaleBookFactors(Market.WSP_B)).getFirst();
            assertThat(wholesaleBookFactors.getSkewedMidPrice(), new IsRoundedTo(0.750010625));
        }
    }
}
