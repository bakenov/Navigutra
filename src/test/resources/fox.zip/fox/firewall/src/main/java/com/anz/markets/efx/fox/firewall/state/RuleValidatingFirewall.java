package com.anz.markets.efx.fox.firewall.state;

import java.util.Objects;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.fox.firewall.api.Rule;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

public class RuleValidatingFirewall implements OrderConsumer {
    private final Rule.Matcher ruleMatcher;
    private final OrderConsumer.ErrorHandler errorHandler;

    public RuleValidatingFirewall(final Rule.Matcher ruleMatcher,
                                  final ErrorHandler errorHandler) {
        this.ruleMatcher = Objects.requireNonNull(ruleMatcher);
        this.errorHandler = errorHandler;
    }

    @Override
    public boolean accept(final NewOrderSingleDecoder newOrderSingle, final CommandContext commandContext) {
        final Rule rule = ruleMatcher.match(newOrderSingle);

        if (rule.validate(newOrderSingle, commandContext.precisionClock().nanos())) {
            return true;
        } else {
            errorHandler.accept(newOrderSingle, commandContext, rule);
            return false;
        }
    }
}
