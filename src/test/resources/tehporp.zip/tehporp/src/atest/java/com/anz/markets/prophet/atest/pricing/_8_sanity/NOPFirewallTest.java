package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.NetOpenPositionLimitConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.PricingFirewallTypeMatcher;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import com.anz.markets.prophet.positionrisk.Positions;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import static com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType.PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED;
import static com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType.PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD;
import static com.anz.markets.prophet.matcher.LamdaMatcher.f;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason="flush prices")
public class NOPFirewallTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Cross Pair - should trigger on BID/OFFER when LONG BASE and LONG TERM position = threshold")
    public void whenEqualLimitLongBaseLongTermTriggerOnBidOffer() {
        final Instrument crossPair = Instrument.EURAUD;

        given:
        {
            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));
            // and inverse
            prophet.receive(new SpotDateImpl(Instrument.AUDEUR, LocalDate.now().plusDays(2)));

            // configure EURAUD as driver pair
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Arrays.asList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, crossPair, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, crossPair, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, crossPair, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3)
                    ))
                    .setMarketConfigs(Arrays.asList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURAUD),
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.AUDUSD),
                            new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURUSD)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.EURAUD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_U,Instrument.EURUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setStandardMarketSpreadConfigs(Arrays.asList(
                            // Driver Pairs
                            new StandardMarketSpreadConfigImpl(Instrument.EURAUD, 1.04E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                            new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 1.04E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                            new StandardMarketSpreadConfigImpl(Instrument.EURUSD, 1.04E-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                    ))

                    // configure EUR nop threshold(0.8) and 1.375 mio limit = 1.1 mio
                    // configure AUD nop threshold(0.8) and 1.0 mio limit = 0.8 mio
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8))
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(crossPair.getDealt()).setLimit(1_375_000),
                            new NetOpenPositionLimitConfigImpl(crossPair.getTerms()).setLimit(1_000_000),
                            new NetOpenPositionLimitConfigImpl(Currency.USD).setLimit(5_000_000)  // this config is required
                    ))
            );
        }

        when:
        {
            // set up AUD/USD and EUR/USD rates for USD equiv calcs
            // No position update as Notional positions are 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, crossPair, 1.40000, 0.00002));

            // AXPROPHET-927 Should have no impact on existing scenario
            prophet.receive(tdd.biasPosition(Currency.AUD, 2_000_000));
            prophet.receive(tdd.biasPosition(Currency.EUR, 2_000_000));

            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.8));
            // Trigger 2nd position updates for EUR and USD
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, 1_000_000, 1.1));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.CLIENTS_NET));
            OverallProfitVolumeFirewallTest.PositionsHelper positions = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsUpdates);

            assertThat(positions.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(1_000_000.0));
            assertThat(positions.getLatest(Currency.AUD).getPositionInSystemBase(), CoreMatchers.is(800_000.0));

            assertThat(positions.getLatest(Currency.EUR).getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positions.getLatest(Currency.EUR).getPositionInNotional(), CoreMatchers.is(1_000_000.0));
            assertThat(positions.getLatest(Currency.EUR).getPositionInSystemBase(), CoreMatchers.is(1_100_000.0));

            LinkedList<Positions> positionsBiasOffsets = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            OverallProfitVolumeFirewallTest.PositionsHelper positionsOffset = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsBiasOffsets);
            assertThat(positionsOffset.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsOffset.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));

            assertThat(positionsOffset.getLatest(Currency.EUR).getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsOffset.getLatest(Currency.EUR).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // Does not trigger any position update
            // Mid must be 1% different to generate position update
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, crossPair, 1.45000, 0.00002));
        }
        then:
        {   // get latest EUR/AUD Client Price from market update
            ClientPrice price = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrumentAndMkt(Instrument.EURAUD, Market.WSP_A)).getLast();

            // EUR(Long) OVER/ON limit - ANZ stop buying EUR ie. ALL EUR/AUD BIDS INDICATIVE
            // AUD(Long) OVER/ON limit - ANZ stop buying AUD i.e ALL EUR/AUD OFFERS INDICATIVE
            assertThat(price, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(price, PricingFirewallType.NET_OPEN_POSITION_THRESHOLD);
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Indirect Pair - should trigger on BID when LONG BASE and SHORT TERM position = threshold.")
    public void whenEqualLimitLongBaseShortTermTriggerOnBid() {
        final Instrument indirectPair = Instrument.AUDUSD;

        given:
        {
            // configure AUD nop threshold(0.8) and 1.0 mio limit = 0.8 mio
            // configure USD nop threshold(0.8) and 1.0 mio limit = 0.8 mio
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8))
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(indirectPair.getDealt()).setLimit(1_000_000),
                            new NetOpenPositionLimitConfigImpl(indirectPair.getTerms()).setLimit(1_000_000)
                    ))
                    // disable Mid Skewing
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
            );
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, indirectPair, 0.79000, 0.00004));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(1_000_000, 0.8));

            // Mid must be 1% different to generate position update
            // Triggers 2nd position update for AUD only
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, indirectPair, 0.80000, 0.00002));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.CLIENTS_NET));
            OverallProfitVolumeFirewallTest.PositionsHelper positions = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsUpdates);

            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(-800_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(-800_000.0));

            assertThat(positions.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(1_000_000.0));
            assertThat(positions.getLatest(Currency.AUD).getPositionInSystemBase(), CoreMatchers.is(800_000.0));
        }
        and:
        {   // get Client Price from latest market update
            LinkedList<ClientPrice> prices = prophet.expect(ClientPrice.class, exactly(2), isModel(Market.WSP_A));

            // AUD(Long) OVER/ON limit - ANZ stop buying AUD i.e AUD/USD BID INDICATIVE
            // USD(Short) below limit
            assertThat("Quote type should be FIRM", prices.getLast().getBidQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(prices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.NET_OPEN_POSITION_THRESHOLD));

            assertThat("Quote type should be FIRM", prices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(prices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }

        returnToFirmWhenFirewallConditionsNotMet();
    }

    private void returnToFirmWhenFirewallConditionsNotMet() {
        when:
        {
            prophet.clearOutputBuffer();
            // Mid must be 1% different to generate position update
            // Triggers 2nd position update for AUD only
            prophet.receive(tdd.client_trade_001(-1_000, 0.8));
        }
        then:
        {
            LinkedList<ClientPrice> prices = prophet.expect(ClientPrice.class, exactly(1), isModel(Market.WSP_A));

            // AUD(Long) OVER/ON limit - ANZ stop buying AUD i.e AUD/USD BID INDICATIVE
            // USD(Short) OVER/ON limit - ANZ stop selling USD ie. AUD/USD BIDS INDICATIVE
            assertThat("Quote type should be FIRM", prices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat("Quote type should be FIRM", prices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Indirect Pair - should NOT trigger when SHORT BASE and LONG TERM position < threshold.")
    public void whenUnderLimitShouldNotTrigger() {
        final Instrument indirectPair = Instrument.AUDUSD;

        given:
        // configure nop threshold(0.8) and 1mio limits for aud and usd.
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8))
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(indirectPair.getDealt()).setLimit(1_000_000),
                            new NetOpenPositionLimitConfigImpl(indirectPair.getTerms()).setLimit(1_000_000)
                    ))
                    // disable Mid Skewing
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            )
                    )
            );
        }

        when:
        {
            // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, indirectPair, 0.79000, 0.00004));

            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(-1_000_000, 0.79999));

            // Mid must be 1% different to generate position update
            // Triggers 2nd position update for AUD only
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, indirectPair, 0.79999, 0.00002));
        }

        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.CLIENTS_NET));
            OverallProfitVolumeFirewallTest.PositionsHelper positions = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsUpdates);

            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(799_990.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(799_990.0));

            assertThat(positions.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positions.getLatest(Currency.AUD).getPositionInSystemBase(), CoreMatchers.is(-799_990.0));
        }

        and:
        {
            // get latest Client Price from market update
            ClientPrice prices = prophet.expect(ClientPrice.class, exactly(2), isModel(Market.WSP_A)).getLast();

            // UNDER limit - expect client price to be firm
            assertThat(prices, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(prices);
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Direct Pair - should trigger on BID when LONG BASE and SHORT TERM position > threshold")
    public void whenOverLimitLongBaseShortTermTriggerOnBid() {
        final Instrument directPair = Instrument.USDCAD;

        given:
        {   // configure USD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            // configure CAD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8)
                    )
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(directPair.getDealt()).setLimit(1_250_000),
                            new NetOpenPositionLimitConfigImpl(directPair.getTerms()).setLimit(1_250_000)
                    ))
            );
        }
        when:
        {   // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.20000, 0.00010));

            // Trigger 1st position updates for USD and CAD
            prophet.receive(tdd.client_trade_001(directPair, 1_000_001, 1.3));

            // Mid must be 1% different to generate position update
            // Triggers 2nd position update for CAD only
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.29999, 0.00008));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2));
            OverallProfitVolumeFirewallTest.PositionsHelper positions = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(1_000_001.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(1_000_001.0));

            assertThat(positions.getLatest(Currency.CAD).getCcy(), CoreMatchers.is(Currency.CAD));
            assertThat(positions.getLatest(Currency.CAD).getPositionInNotional(), CoreMatchers.is(-1_300_001.3));
            assertThat(positions.getLatest(Currency.CAD).getPositionInSystemBase(), f(pos -> pos < -1000000)); //-1000008.6923745567
        }
        and:
        {
            // get latest Client Price from market update
            LinkedList<ClientPrice> prices = prophet.expect(ClientPrice.class, atLeast(3), isModel(Market.WSP_A));

            // USD(Long) OVER limit - ANZ stop buying USD ie. USD/CAD BID INDICATIVE
            // CAD(Short) OVER limit - ANZ stop selling CAD i.e USD/CAD BID INDICATIVE
            assertThat("Quote type should be INDICATIVE", prices.getLast().getBidQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(prices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.NET_OPEN_POSITION_THRESHOLD));

            assertThat("Quote type should be FIRM", prices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(prices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Direct Pair - should trigger on OFFER when SHORT BASE and LONG TERM position > threshold")
    public void whenOverLimitShortBaseLongTermTriggerOnOffer() {
        final Instrument directPair = Instrument.USDCAD;

        given:
        {   // configure USD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            // configure CAD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8)
                    )
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(directPair.getDealt()).setLimit(1_250_000),
                            new NetOpenPositionLimitConfigImpl(directPair.getTerms()).setLimit(1_250_000)
                    ))
            );
        }
        when:
        {   // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.20000, 0.00010));

            // Trigger 1st position updates for USD and CAD
            prophet.receive(tdd.client_trade_001(directPair, -1_000_001, 1.3));

            // Mid must be 1% different to generate position update
            // Triggers 2nd position update for CAD only
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.29999, 0.00008));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.CLIENTS_NET));

            // get latest positions
            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInNotional(), CoreMatchers.is(-1_000_001.0));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), CoreMatchers.is(-1_000_001.0));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.CAD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), CoreMatchers.is(1_300_001.3));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), f(pos -> pos > 1000000)); //1000008.6923745567
        }
        and:
        {
            // get latest Client Price from market update
            LinkedList<ClientPrice> prices = prophet.expect(ClientPrice.class, atLeast(3), isModel(Market.WSP_A));

            // USD(Short) OVER limit - ANZ stop selling USD ie. USD/CAD OFFER INDICATIVE
            // CAD(Long) OVER limit - ANZ stop buying CAD i.e USD/CAD OFFER INDICATIVE
            assertThat("Quote type should be FIRM", prices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(prices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type should be INDICATIVE", prices.getLast().getOfferQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(prices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.NET_OPEN_POSITION_THRESHOLD));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Direct Pair - should trigger on BID/OFFER when SHORT BASE and SHORT TERM position > threshold")
    public void whenOverLimitShortBaseShortTermTriggerOnBidOffer() {
        final Instrument directPair = Instrument.USDCAD;

        given:
        {   // configure USD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            // configure CAD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8)
                    )
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(directPair.getDealt()).setLimit(1_250_000),
                            new NetOpenPositionLimitConfigImpl(directPair.getTerms()).setLimit(1_250_000)
                    ))
            );
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
        }
        when:
        {   // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.20000, 0.00010));
            prophet.incrementTime(1000);
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 105., 0.010));
            prophet.incrementTime(1000);

            // Trigger 1st position updates for USD and CAD
            prophet.receive(tdd.client_trade_001(directPair, 1_000_001, 1.3));
            prophet.incrementTime(1000);

            // Trigger 2nd position updates for USD and JPY
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -2_000_002, 104.555));
            prophet.incrementTime(1000);

            // Mid must be 1% different to generate position update
            // Trigger 3rd position update for CAD only
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.29999, 0.00008));
        }
        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(3), isPortfolio(Portfolio.CLIENTS_NET));

            // get latest positions
            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), CoreMatchers.is(-1_000_001.0));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), CoreMatchers.is(-1_000_001.0));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.CAD));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInNotional(), CoreMatchers.is(-1_300_001.3));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), f(pos -> pos < -1000000)); //-1000008.6923745567
        }
        and:
        {
            // get latest Client Price from market update
            ClientPrice prices = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrumentAndMkt(directPair, Market.WSP_A)).getLast();

            // USD(Short) OVER limit - ANZ stop selling USD ie. USD/CAD OFFER INDICATIVE
            // CAD(Short) OVER limit - ANZ stop selling CAD i.e USD/CAD BID INDICATIVE
            assertThat(prices, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(prices, PricingFirewallType.NET_OPEN_POSITION_THRESHOLD);
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("Direct Pair - should trigger on BID/OFFER when LONG BASE and LONG TERM position > threshold")
    public void whenOverLimitLongBaseLongTermTriggerOnBidOffer() {
        final Instrument directPair = Instrument.USDCAD;

        given:
        {   // configure USD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            // configure CAD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8)
                    )
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(directPair.getDealt()).setLimit(1_250_000),
                            new NetOpenPositionLimitConfigImpl(directPair.getTerms()).setLimit(1_250_000)
                    ))
            );
            prophet.receive(tdd.forwardPoint(Instrument.USDCAD, -0.09d, -0.03d, LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), Tenor.SPOT_NEXT));
        }
        when:
        {   // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.20000, 0.00010));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 104.555, 0.010));

            // Trigger 1st position updates for USD and CAD
            prophet.receive(tdd.client_trade_001(directPair, -1_000_001, 1.3));
            // Trigger 2nd position updates for USD and JPY
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, 2_000_002, 104.555));

            // Mid must be 1% different to generate position update
            // Trigger 3rd position update for CAD only
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.29999, 0.00008));
        }

        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(3), isPortfolio(Portfolio.CLIENTS_NET));

            // get latest positions from market update
            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), CoreMatchers.is(1_000_001.0));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), CoreMatchers.is(1_000_001.0));

            assertThat(positionsUpdates.get(2).getPosition1().getCcy(), CoreMatchers.is(Currency.CAD));
            assertThat(positionsUpdates.get(2).getPosition1().getPositionInNotional(), CoreMatchers.is(1_300_001.3));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), f(pos -> pos > 1000000)); //-1000008.6923745567
        }

        and:
        {
            // get latest Client Price from market update
            ClientPrice prices = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrumentAndMkt(directPair, Market.WSP_A)).getLast();

            // USD(Short) OVER limit - ANZ stop selling USD ie. USD/CAD OFFER INDICATIVE
            // CAD(Long) OVER limit - ANZ stop buying CAD i.e USD/CAD OFFER INDICATIVE
            assertThat(prices, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(prices, PricingFirewallType.NET_OPEN_POSITION_THRESHOLD);
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_5)
    @DisplayName("should NOT trigger when BASE and TERM position = 0")
    public void shouldNotTriggerWhenBaseTermPositionZero() {
        final Instrument directPair = Instrument.USDCAD;

        given:
        {   // configure USD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            // configure CAD nop threshold(0.8) and 1.25 mio limit = 1.0 mio
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD, 0.8)
                    )
                    .setNetOpenPositionLimitConfigs(Lists.newArrayList(
                            new NetOpenPositionLimitConfigImpl(directPair.getDealt()).setLimit(1_250_000),
                            new NetOpenPositionLimitConfigImpl(directPair.getTerms()).setLimit(1_250_000)
                    ))
            );
        }

        when:
        {   // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.20000, 0.00010));

            // 2 client trades such that position is net zero
            // Trigger 1st position updates for USD and CAD
            prophet.receive(tdd.client_trade_001(directPair, -1_000_001, 1.3));
            // Trigger 2nd position updates for USD and CAD
            prophet.receive(tdd.client_trade_001(directPair, 1_000_001, 1.3));
        }

        then:
        {
            LinkedList<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.CLIENTS_NET));

            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), CoreMatchers.is(0.0));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), CoreMatchers.is(0.0));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.CAD));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInNotional(), CoreMatchers.is(0.0));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), CoreMatchers.is(0.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // Mid must be 1% different to generate position update
            // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, directPair, 1.29999, 0.00008));
        }
        then:
        {
            // get latest Client Price from market update
            ClientPrice prices = prophet.expect(ClientPrice.class, atLeast(1), isModel(Market.WSP_A)).getLast();
            assertThat(prices, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(prices);
        }
    }

}