package com.anz.markets.efx.fox.codec.pojo.codec;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteEncoder;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.TimerExpiryEncoder;
import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueConfigEncoder;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoSorEncoders implements SorEncoders<SorMessage> {

    @Override
    public MessageEncoder.Factory<SorMessage, PricingRefreshCompleteEncoder> pricingRefreshComplete() {
        return consumerSupplier -> new PojoPricingRefreshCompleteEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, TimerExpiryEncoder> timerExpiry() {
        return consumerSupplier -> new PojoTimerExpiryEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, FirewallConfigEncoder> firewallConfig() {
        return consumerSupplier -> new PojoFirewallConfigEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, VenueConfigEncoder> venueConfig() {
        return consumerSupplier -> new PojoVenueConfigEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, UserConfigEncoder> userConfig() {
        return consumerSupplier -> new PojoUserConfigEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, InitialisationEncoder> initialisation() {
        return consumerSupplier -> new PojoInitialisationEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, InstrumentConfigEncoder> instrumentConfig() {
        return consumerSupplier -> new PojoInstrumentConfigEncoder(consumerSupplier);
    }

    @Override
    public MessageEncoder.Factory<SorMessage, VenueInstrumentConfigEncoder> venueInstrumentConfig() {
        return consumerSupplier -> new PojoVenueInstrumentConfigEncoder(consumerSupplier);
    }
}
