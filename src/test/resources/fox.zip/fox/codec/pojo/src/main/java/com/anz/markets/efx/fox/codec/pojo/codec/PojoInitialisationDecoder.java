package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.pojo.model.Initialisation;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoInitialisationDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends InitialisationHandler> handlerSupplier;

    public PojoInitialisationDecoder(final Supplier<? extends InitialisationHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof Initialisation) {
            return decode((Initialisation) sorMessage);
        }
        return false;
    }

    public boolean decode(final Initialisation message) {
        final InitialisationHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source,message.header.sourceSeq);
        handler.onBody(new InitialisationHandler.Body() {
            @Override
            public InitStage initStage() {
                return message.body.initStage;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoInitialisationDecoder() {
        throw new RuntimeException("No PojoInitialisationDecoder for you!");
    }
}
