package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoOrderCancelRequestDecoder;
import org.junit.Before;
import org.junit.Test;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class BgcOrderCancelRequestHandlerTest {

    private BgcOrderCancelRequestHandler handler;
    private OrderCancelRequest bgcOrderCancelRequest;
    private PojoOrderCancelRequestDecoder orderCancelRequestDecoder;

    @Before
    public void setUp() {
        final FixMessageSender fixMessageSender = new FixMessageSender(() -> null) {
            @Override
            public void accept(final StandardHeaderTrailer message) {
                bgcOrderCancelRequest = (OrderCancelRequest) message;
            }
        };
        handler = new BgcOrderCancelRequestHandler(fixMessageSender);
        orderCancelRequestDecoder = new PojoOrderCancelRequestDecoder(() -> handler);
    }

    @Test
    public void sendOrderCancelRequest() {
        // given
        final com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest orderCancelRequest = new com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest();

        orderCancelRequest.body.senderCompId = "GB:lg-bgc";
        orderCancelRequest.body.clOrdId = "1";
        orderCancelRequest.body.origClOrdId = "11";
        orderCancelRequest.body.messageId = 1;
        orderCancelRequest.body.marketId = Venue.BGCMIDFX.name();
        orderCancelRequest.body.symbol = "NZDUSD";
        orderCancelRequest.body.side = Side.BUY;
        orderCancelRequest.body.transactTime = 1;

        // when
        orderCancelRequestDecoder.decode(orderCancelRequest);

        //then
        assertThat(bgcOrderCancelRequest.clOrdID().toString(), is("1"));
        assertThat(bgcOrderCancelRequest.origClOrdID().toString(), is("11"));
        assertThat(bgcOrderCancelRequest.symbol(), is("NZD/USD"));
        assertThat(bgcOrderCancelRequest.side(), is(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.BUY));
    }
}