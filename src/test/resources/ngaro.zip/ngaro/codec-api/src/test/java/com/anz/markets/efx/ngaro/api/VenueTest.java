package com.anz.markets.efx.ngaro.api;

import java.util.function.Consumer;
import java.util.stream.Stream;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class VenueTest {

    @Test
    public void valueByOrdinal() {
        Stream.of(Venue.values())
                .forEach(venue ->
                        assertThat(Venue.valueByOrdinal(venue.ordinal())).isEqualTo(venue)
                );
    }

    @Test
    public void forEach() {
        @SuppressWarnings({"unchecked", "rawType"})
        final Consumer<Venue> consumer = mock(Consumer.class);
        Venue.forEach(consumer);
        Stream.of(Venue.values()).forEach(venue -> verify(consumer).accept(venue));
    }
}