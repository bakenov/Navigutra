package com.anz.axle.lg.adapter.d3.acceptance;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HandlerRegistry implements Runnable {
    private final Map<String, Runnable> handlers;

    public HandlerRegistry() {
        this.handlers = new ConcurrentHashMap<>();
    }

    public void addHandler(final String name, final Runnable handler) {
        handlers.put(name, handler);
    }

    public void removeHandler(final String name) {
        handlers.remove(name);
    }

    @Override
    public void run() {
        handlers.forEach((name, handler) -> handler.run());
    }
}
