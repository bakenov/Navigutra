package com.anz.markets.prophet.chronicle;

public enum ApiVersion {
    // CQ3
    LEGACY_CHRONICLE,
    // CQ4 or later
    CHRONICLE_QUEUE;

    public boolean isLC() {
        return this.equals(LEGACY_CHRONICLE);
    }

    public boolean isCQ() {
        return this.equals(CHRONICLE_QUEUE);
    }

    @Deprecated
    public boolean isV3() {
        return isLC();
    }

    @Deprecated
    public boolean isV4() {
        return isCQ();
    }
}
