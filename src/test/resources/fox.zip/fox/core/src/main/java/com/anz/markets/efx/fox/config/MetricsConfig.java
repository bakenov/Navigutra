package com.anz.markets.efx.fox.config;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.IntFunction;
import java.util.function.LongConsumer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.fox.metric.Metric;
import com.anz.markets.efx.fox.metric.MetricDomain;
import com.anz.markets.efx.fox.metric.MetricLoggingConfig;
import com.anz.markets.efx.fox.metric.MetricRepositoryFactory;
import com.anz.markets.efx.metric.MetricRecorder;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.queue.Queue;

@Configuration
public class MetricsConfig {
    @Bean
    public MetricRepository<Metric, Venue> metricRepository() {
        return MetricRepositoryFactory.defaultMetricRepository();
    }

    static MetricDomain metricDomain(final int partitionIndex) {
        switch (partitionIndex) {
            case 0: return MetricDomain.PRICING_LOOP1;
            case 1: return MetricDomain.PRICING_LOOP2;
            case 2: return MetricDomain.PRICING_LOOP3;
            case 3: return MetricDomain.PRICING_LOOP4;
            default: throw new IllegalArgumentException("MetricDomain is not available for partition " + partitionIndex);
        }
    }

    static Metric priceLatencyMetric(final int partitionIndex) {
        switch (partitionIndex) {
            case 0: return Metric.DEPTH_PRICING_LOOP1_LATENCY_HST;
            case 1: return Metric.DEPTH_PRICING_LOOP2_LATENCY_HST;
            case 2: return Metric.DEPTH_PRICING_LOOP3_LATENCY_HST;
            case 3: return Metric.DEPTH_PRICING_LOOP4_LATENCY_HST;
            default: throw new IllegalArgumentException("PriceLatency Metric is not available for index " + partitionIndex);
        }
    }

    static IntFunction<LongConsumer> latencyMetricRecorderLookup(final MetricRepository<Metric, Venue> metricRepository) {
        return partitionIndex -> {
            final Metric metric = priceLatencyMetric(partitionIndex);
            final MetricRecorder recorder = metricRepository.getOrCreate(metric, null);
            return recorder::record;
        };
    }

    static ScheduledFuture<?> createMetricReporterJob(final MetricDomain eventLoopDomain,
                                                              final MetricRepository<Metric, Venue> metricRepository,
                                                              final Queue<Runnable> runnableQueue,
                                                              final ScheduledExecutorService scheduledExecutorService,
                                                              final int periodSeconds) {
        final MetricRepository<Metric, Venue> domainScopedMetricRepository = MetricRepositoryFactory.domainScoped(eventLoopDomain, metricRepository);
        final Runnable metricsReporter = () -> MetricLoggingConfig.logAndResetAll(domainScopedMetricRepository);
        return scheduledExecutorService.scheduleWithFixedDelay(() -> {
            runnableQueue.appender().enqueue(metricsReporter);
        }, periodSeconds, periodSeconds, TimeUnit.SECONDS);
    }
}
