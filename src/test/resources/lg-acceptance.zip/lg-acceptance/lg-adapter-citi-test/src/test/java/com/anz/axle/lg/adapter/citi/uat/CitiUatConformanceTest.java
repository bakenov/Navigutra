package com.anz.axle.lg.adapter.citi.uat;


import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.citi.acceptance.AcceptanceConfig;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;

@Category(UatTest.class)
@RunWith(Spockito.class)
public class CitiUatConformanceTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CitiUatConformanceTest.class);
    public static final String GB_LG_CITI = "GB:lg-citi";
    public static final String GB_LG_ACC = "GB:lg-acc";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-citi" +
                                ",citi.fix.log.destination:STDOUT" +
                                ",citi.fix.trading.reset.on.logon:Y" +
                                ",citi.fix.trading.reset.on.logout:Y" +
                                ",citi.fix.trading.reset.on.disconnect:Y" +

                                ",citi.fix.pricing.sendercompid:ANZ-TM-UAT-QUOTE" +
                                ",citi.fix.pricing.targetcompid:CITIFX" +
                                ",citi.fix.pricing.host:10.54.180.187" +
                                ",citi.fix.pricing.port:36000" +
                                ",citi.fix.pricing.password:citifxuat" +

                                ",citi.fix.trading.sendercompid:ANZ-TM-UAT-TRADE" +
                                ",citi.fix.trading.targetcompid:CITIFX" +
                                ",citi.fix.trading.host:10.54.180.187" +
                                ",citi.fix.trading.port:37000" +
                                ",citi.fix.trading.password:citifxuat" +
                                ",citi.fix.trading.metal.account:35944156" +
                                ",citi.fix.trading.currency.account:35944156" +
                                ",citi.fix.targetsubid:FXSPOT" +
                                ",citi.fix.xconnect.colo.specification.version:CSAT_7.0.16" +

                                ",citi.fix.log.destination:FILE" +
                                ",citi.fix.file.log.path:logs/fixlog" +
                                ",citi.fix.file.log.heartbeats:Y" +
                                ",citi.fix.file.include.milliseconds:Y" +
                                ",citi.fix.file.include.timestamp.for.messages:Y"
                ));

        application = new Application("lg-citi-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    @Spockito.Unroll({
            "| orderType             | symbol | currency | timeInForce | side | size    | priceOffset   | multipleExecutions |",
            "| PREVIOUSLY_QUOTED     | EURUSD | EUR      | FOK         | BUY  | 100000  | 0.0005        | false              |"
    })
    @Spockito.Name("[{row}]: {orderType} {timeInForce} {symbol} {currency} {side}")
    public void conformance(final OrderType orderType, final String symbol, final String currency, final TimeInForce timeInForce,
                            final Side side, final double size, final double priceOffset, final boolean multipleExecutions) throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP);
        final PriceEntry priceEntry = awaitPrice(instrumentKey.instrumentId(), side == Side.SELL ? EntryType.BID : EntryType.OFFER);
        final NewOrderSingle newOrderSingle = newOrderSingle(symbol, clOrdId, side, 0.0, priceEntry.quoteId, size, currency, orderType, timeInForce);
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
        assertFill(symbol, clOrdId, side, size, currency, orderType, multipleExecutions);
    }

    @Test
    public void conformanceSendTradeOnUnknownCurrencyPairThenRecoverAndSendEURUSDTrade(){
        String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        NewOrderSingle newOrderSingle = newOrderSingle("XXXZZZ", clOrdId, Side.BUY, 123.0,
                34567, 1_000_000, "XXX", OrderType.PREVIOUSLY_QUOTED, TimeInForce.IOC);
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
        clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final InstrumentKey instrumentKey = InstrumentKey.of("EURUSD", SecurityType.FXSPOT, Tenor.SP);
        final PriceEntry priceEntry = awaitPrice(instrumentKey.instrumentId(), EntryType.BID);
        newOrderSingle = newOrderSingle("EURUSD", clOrdId, Side.BUY, 0.0, priceEntry.quoteId,
                1_000_000, "EUR", OrderType.PREVIOUSLY_QUOTED, TimeInForce.IOC);
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
        assertFill("EURUSD", clOrdId, Side.BUY, 1_000_000, "EUR", OrderType.PREVIOUSLY_QUOTED, false);
    }

    private PriceEntry awaitPrice(final long instrumentId, final EntryType entryType) {
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(GB_LG_CITI))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.CITI))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentId))
                .entries().anyMatches(SnapshotFullRefreshMatcher.mdEntryType().eq(entryType))
                .hops().countAtLeast(2);
        return new PriceListener(acceptanceContext.pricingMessageQueue()).awaitPrice(matcher, entryType, 30);
    }

    private NewOrderSingle newOrderSingle(final String symbol, final String clOrdId, final Side side, final double price, final int quoteId,
                                          final double size, final String currency, final OrderType orderType, final TimeInForce timeInForce) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.timeInForce = timeInForce;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.quoteId = String.valueOf(quoteId);
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.symbol = symbol;
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.side = side;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private NewOrderSingle newOrderSingle(final String symbol, final String clOrdId, final Side side, final double size,
                                          final String currency, final OrderType orderType, final TimeInForce timeInForce) {
        return newOrderSingle(symbol, clOrdId, side, 0, currency, orderType, timeInForce);
    }

    private void assertFill(final String symbol, final String clOrdId, final Side side, final double size,
                            final String currency, final OrderType orderType, final boolean multipelExecutions) {
        if (multipelExecutions) {
            assertMultipleFills(symbol, clOrdId, side, size, currency, orderType);
        } else {
            assertSingleFill(symbol, clOrdId, side, size, currency, orderType);
        }
    }

    private void assertSingleFill(final String symbol, final String clOrdId, final Side side,
                                  final double size, final String currency, final OrderType orderType) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CITI))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CITI.name()))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CITI))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CITI.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.cumQty().eq(size))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().eq(size))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0d))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(40, TimeUnit.SECONDS);
    }

    private void assertMultipleFills(final String symbol, final String clOrdId, final Side side,
                                     final double size, final String currency, final OrderType orderType) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CITI))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CITI.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CITI))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PARTIALLY_FILLED))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CITI.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.cumQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.leavesQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CITI))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CITI.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.cumQty().eq(size))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0d))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }


}