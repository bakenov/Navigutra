package com.anz.axle.direct.performance;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class LoggingReporterFactory implements ReporterFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingReporterFactory.class);

    @Override
    public ProgressReporter createProgressReporter() {
        return new LoggingProgressReporter(LOGGER);
    }

    @Override
    public MetricReporter createMetricReporter() {
        LOGGER.info("Creating " + LoggingMetricReporter.class);
        return new LoggingMetricReporter();
    }
}
