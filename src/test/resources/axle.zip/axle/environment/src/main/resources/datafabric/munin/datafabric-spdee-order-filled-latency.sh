#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-spdee-order-filled-latency - Plugin to monitor the SPDEE Order Filled Latency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title SPDEE Order Filled Latency'
    echo 'graph_category spdee'
    echo 'graph_scale no'
    echo 'latencyFxAll.label SPDEE Order Filled Latency (FxAll)'
    echo 'latencyFxAll.draw LINE2'
    echo 'latencyFxAllRFS.label SPDEE Order Filled Latency (FxAll_RFS)'
    echo 'latencyFxAllRFS.draw LINE2'
    echo 'latency360t.label SPDEE Order Filled Latency (360T)'
    echo 'latency360t.draw LINE2'
    echo 'latency360tRFS.label SPDEE Order Filled Latency (360T_RFS)'
    echo 'latency360tRFS.draw LINE2'
    echo 'latencyBloomberg.label SPDEE Order Filled Latency (Bloomberg)'
    echo 'latencyBloomberg.draw LINE2'
    echo 'latencyBloombergRFS.label SPDEE Order Filled Latency (Bloomberg_RFS)'
    echo 'latencyBloombergRFS.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "latencyFxAll.value U"
        echo "latencyFxAllRFS.value U"
        echo "latency360t.value U"
        echo "latency360tRFS.value U"
        echo "latencyBloomberg.value U"
        echo "latencyBloombergRFS.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "latencyFxAll.value U"
        echo "latencyFxAllRFS.value U"
        echo "latency360t.value U"
        echo "latency360tRFS.value U"
        echo "latencyBloomberg.value U"
        echo "latencyBloombergRFS.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
grep dealing.order.ccm-create-to-ccm-filled-ack-commence,, $LOGFILE | tail -1 | awk -F, '
BEGIN {
        latencyFXALL=0;
        latencyFxAllRFS=0;
        latency360t=0;
        latency360tRFS=0;
        latencyBloomberg=0;
        latencyBloombergRFS=0;
}

/dealing.order.ccm-create-to-ccm-filled-ack-commence,,fxall,/ {latencyFxAll=$15}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,fxall_rfs,/ {latencyFxAllRFS=$15}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,360t,/ {latency360t=$15}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,360t_rfs,/ {latency360tRFS=$15}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,bloomberg,/ {latencyBloomberg=$15}
/dealing.order.ccm-create-to-ccm-filled-ack-commence,,bloomberg_rfs,/ {latencyBloombergRFS=$15}

END {
        print "latencyFxAll.value " latencyFxAll;
        print "latencyFxAllRFS.value " latencyFxAllRFS;
        print "latency360t.value " latency360t;
        print "latency360tRFS.value " latency360tRFS;
        print "latencyBloomberg.value " latencyBloomberg;
        print "latencyBloombergRFS.value " latencyBloombergRFS;
}
'
fi

