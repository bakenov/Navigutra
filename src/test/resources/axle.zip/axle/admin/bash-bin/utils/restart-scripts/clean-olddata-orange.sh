#!/bin/bash

./clean-olddata-onebox.sh daxa021z clean_olddata_correlator
./clean-olddata-onebox.sh daxa004z clean_olddata_correlator

./clean-olddata-onebox.sh daxa021z clean_olddata_proxybroker
./clean-olddata-onebox.sh daxa004z clean_olddata_proxybroker

./clean-olddata-onebox.sh qfxa001z clean_olddata_stp

