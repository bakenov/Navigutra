package com.anz.axle.lg.adapter.fxall.acceptance;

import java.util.concurrent.TimeUnit;

import org.fix4j.spec.fix50sp2.FieldTypes;
import org.fix4j.spec.fix50sp2.fieldtype.ExecType;
import org.fix4j.spec.fix50sp2.fieldtype.MsgType;
import org.fix4j.spec.fix50sp2.fieldtype.OrdStatus;
import org.fix4j.test.fixmodel.Field;
import org.fix4j.test.fixmodel.FixMessage;
import org.fix4j.test.session.MatchingSession;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.FixMessageBuilder;
import com.anz.axle.lg.adapter.acceptance.utils.TradingFixSessionHelper;
import com.anz.axle.lg.adapter.fxall.chroniclefix.generated.fields.CxlRejReason;
import com.anz.axle.lg.adapter.fxall.chroniclefix.generated.fields.CxlRejResponseTo;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.OrderCancelRejectReason;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.OrderCancelRejectMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.markets.efx.trading.codec.api.ExecType.REJECTED;
import static com.anz.markets.efx.trading.codec.api.ExecType.TRADE;
import static org.fix4j.test.util.Asserts.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class FxAllStubbedTradingIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(FxAllStubbedTradingIntegrationTest.class);
    private static final String NORMALISED_SYMBOL = "AUDCAD";
    private static final String SYMBOL = "AUD/CAD";
    private static final String CURRENCY = "AUD";
    private static final String SENDER_COMP_ID = "GB:lg-fxall";
    private static final String FIRST_HOP = "GB:FXALLMB";
    @Rule
    public final TestName testName = new TestName();
    private Application application;
    private AcceptanceContext acceptanceContext;
    private MatchingSession tradingServer;
    private TradingFixSessionHelper tradingTestHelper;
    private static final String FIX_DATA_DICTIONARY_FILE = "conf/FIX44-fxall.xml";
    private static final double TOLERANCE = 1e-15;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START:++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ {}", testName.getMethodName());

        tradingTestHelper = new TradingFixSessionHelper("fxall", "GB_FXALLMB_TR_S", "GB_FXALLMB_TR_T", "FIX.4.4", FIX_DATA_DICTIONARY_FILE);

        System.getProperties().put("fxall.fix.trading.waitForLogoutTimeoutInSec","2");
        System.getProperties().put("fxall.fix.log.queue.RollCycle","MINUTELY");

        tradingServer = tradingTestHelper.createTradingSession();

        application = new Application("lg-fxall-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
    }

    @After
    public void afterEach() throws Exception {
        waitForStop(application, 3, 500, testName.getMethodName());
        if (tradingServer != null) tradingServer.shutdown();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private NewOrderSingle newOrderSingleUMMessage(final String symbol) {
        final double quantity = 16863000000.0;
        final double price = 1;
        final Side side = Side.SELL;

        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = SENDER_COMP_ID;
        newOrderSingle.body.ordType = OrderType.LIMIT;
        newOrderSingle.body.clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        newOrderSingle.body.messageId = 1234567;
        newOrderSingle.body.currency = CURRENCY;
        newOrderSingle.body.symbol = symbol;
        newOrderSingle.body.price = price;
        newOrderSingle.body.orderQty = quantity;
        newOrderSingle.body.side = side;
        newOrderSingle.body.timeInForce = TimeInForce.DAY;
        newOrderSingle.body.settlCurrency = newOrderSingle.body.currency;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private OrderCancelRequest orderCancelRequestUMMessage(final String symbol) {
        final OrderCancelRequest orderCancelRequest = new OrderCancelRequest();
        orderCancelRequest.body.senderCompId = SENDER_COMP_ID;
        orderCancelRequest.body.clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        orderCancelRequest.body.origClOrdId = "1";
        orderCancelRequest.body.symbol = symbol;
        orderCancelRequest.body.side = Side.BUY;
        return orderCancelRequest;
    }

    private FixMessage executionReportFixMessage(final FixMessage newOrderSingle, final String orderId, final ExecType.Values executionStatus, final double fillQty) {
        final String execId = "2312321";
        final String settlDate = "20170702";
        final String orderQty = newOrderSingle.getField(FieldTypes.OrderQty).getValue();
        final double order_qty = Double.parseDouble(orderQty);
        final double cum_qty = fillQty;
        final double leaves_qty = order_qty - fillQty;
        final FixMessageBuilder fixMessageBuilder = new FixMessageBuilder();

        switch (executionStatus) {
            case PENDING_NEW:
                break;
            case NEW:
                break;
            case TRADE_PARTIAL_FILL_OR_FILL:
                fixMessageBuilder.withField(FieldTypes.ExecType, "F");
                fixMessageBuilder.withField(FieldTypes.OrdStatus, OrdStatus.Values.FILLED.getOrdinal());
                fixMessageBuilder.withField(FieldTypes.NoContraBrokers, "1");
                fixMessageBuilder.withField(FieldTypes.ContraBroker, "DA-BNPP");
                break;
            case REJECTED:
                fixMessageBuilder.withField(FieldTypes.ExecType, executionStatus.getOrdinal());
                fixMessageBuilder.withField(FieldTypes.OrdStatus, OrdStatus.Values.REJECTED.getOrdinal());
                fixMessageBuilder.withField(FieldTypes.Text, "Rejection Test");
                break;
            default:
                throw new IllegalArgumentException("Unknown execution status type: "+ executionStatus);
        }

        return fixMessageBuilder.withField(new Field(FieldTypes.MsgType, MsgType.Values.EXECUTIONREPORT.getOrdinal()))
                .withField(FieldTypes.OrderID, orderId)
                .withField(FieldTypes.ClOrdID, newOrderSingle)
                .withField(FieldTypes.OrdType, newOrderSingle)
                .withField(FieldTypes.ExecID, execId)
                .withField(FieldTypes.Symbol, newOrderSingle)
                .withField(FieldTypes.Side, newOrderSingle)
                .withField(FieldTypes.OrderQty, newOrderSingle)
                .withField(FieldTypes.Price, newOrderSingle)
                .withField(FieldTypes.Currency, newOrderSingle)
                .withField(FieldTypes.LastQty,fillQty)
                .withField(FieldTypes.LastPx, newOrderSingle.getField(FieldTypes.Price).getValue())
                .withField(FieldTypes.CumQty,cum_qty)
                .withField(FieldTypes.AvgPx, newOrderSingle.getField(FieldTypes.Price).getValue())
                .withField(FieldTypes.LeavesQty, leaves_qty)
                .withField(FieldTypes.ExecTransType, "0")
                .withField(FieldTypes.TransactTime, "20181114-20:53:19.665")
                .withField(FieldTypes.SettlType, "0")
                .withField(FieldTypes.SettlDate, settlDate)
                .build();
    }

    private FixMessage orderCancelRejectFixMessage(final String clOrdId, final String origClOrdId) {
        return new FixMessageBuilder().withField(new Field(FieldTypes.MsgType, MsgType.Values.ORDERCANCELREJECT.getOrdinal()))
                .withField(FieldTypes.ClOrdID, clOrdId)
                .withField(FieldTypes.OrigClOrdID, origClOrdId)
                .withField(FieldTypes.OrderID, "orderId")
                .withField(FieldTypes.OrdStatus, com.anz.axle.lg.adapter.fxall.chroniclefix.generated.fields.OrdStatus.REJECTED)
                .withField(FieldTypes.Text, "Minimum quote life for DA-INT-ANZPINK-CCG-1 of 1000ms is violated.")
                .withField(FieldTypes.CxlRejReason, CxlRejReason.BROKER_EXCHANGE_OPTION)
                .withField(FieldTypes.CxlRejResponseTo, CxlRejResponseTo.ORDER_CANCEL_REPLACE_REQUEST)
                .withField(FieldTypes.TransactTime, "20190321-20:53:19.665")
                .build();
    }

    @Test
    public void should_fill_order() throws Exception {
        //wait for trading server login
        tradingServer.discardUntil("35=A");
        Thread.sleep(100);

        final NewOrderSingle newOrderSingle = newOrderSingleUMMessage(NORMALISED_SYMBOL);

        LOGGER.info(newOrderSingle.toString());
        LOGGER.info("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        //When new order request is received by the trading server
        final FixMessage newOrderSingleFix = tradingServer.discardUntil("35=D|55=" + SYMBOL + "|");
        final String orderId = "wefqe323";
        final String execId = "2312321";
        final double order_qty = 16863000000.0;
        final double fill_qty = 6863000000.0;

        //Then Execution Report is sent to the adapter
        tradingServer.send(executionReportFixMessage(newOrderSingleFix, "wefqe323", ExecType.Values.TRADE_PARTIAL_FILL_OR_FILL, fill_qty));

        final TradingMessage tradingResponse = Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(SENDER_COMP_ID)))
                .awaitMatchAndGetLast(20, TimeUnit.SECONDS);

        tradingResponse.accept(new TradingMessageVisitor.Exception() {
            @Override
            public void onExecutionReport(final ExecutionReport executionReport) {
                assertEquals(SENDER_COMP_ID, executionReport.body.senderCompId);
                assertEquals(orderId, executionReport.body.orderId);
                assertEquals(execId, executionReport.body.execId);
                assertEquals(newOrderSingleFix.getField(11).getValue(), executionReport.body.clOrdId);
                assertEquals(TRADE, executionReport.body.execType);
                assertEquals(OrderStatus.FILLED, executionReport.body.ordStatus);
                assertEquals(Venue.FXALLMB.name(), executionReport.body.marketId);
                assertEquals(order_qty, executionReport.body.orderQty, TOLERANCE);
                assertEquals(1.0, executionReport.body.price, TOLERANCE);
                assertEquals(CURRENCY, executionReport.body.currency);
                assertNotNull(executionReport.body.settlDate);
                assertEquals(Side.SELL, executionReport.body.side);
                assertEquals(NORMALISED_SYMBOL, executionReport.body.symbol);
                assertEquals(fill_qty, executionReport.body.lastQty, TOLERANCE);
                assertEquals(1.0, executionReport.body.lastPx, TOLERANCE);
                assertEquals(0.0, executionReport.body.commissionAdjLastPx, TOLERANCE);
                assertEquals(0.0, executionReport.body.midPx, TOLERANCE);
                assertEquals(0.0, executionReport.body.lastForwardPoints, TOLERANCE);
                assertEquals(order_qty - fill_qty, executionReport.body.leavesQty, TOLERANCE);
                assertEquals(fill_qty, executionReport.body.cumQty, TOLERANCE);
                assertEquals(1.0, executionReport.body.avgPx, TOLERANCE);
                assertEquals(0.0, executionReport.body.commissionAdjAvgPx, TOLERANCE);
                assertEquals(0.0, executionReport.body.commission, TOLERANCE);

                assertEquals(1, executionReport.parties.size());
                assertEquals("DA-BNPP", executionReport.parties.get(0).partyId);
                assertEquals(PartyRole.CONTRA_FIRM, executionReport.parties.get(0).partyRole);

                assertEquals(0, executionReport.strategyParameters.size());
                assertEquals(0, executionReport.regulatoryTradeIds.size());
                assertEquals(2, executionReport.hops.size());
                assertEquals(FIRST_HOP, executionReport.hops.get(0).hopCompId);
                assertEquals(0, executionReport.hops.get(0).hopReceivingTime);
                assertEquals(acceptanceContext.precisionClock().nanos(), executionReport.hops.get(1).hopReceivingTime);
                assertEquals(SENDER_COMP_ID, executionReport.hops.get(1).hopCompId);
                assertEquals(executionReport.body.messageId, executionReport.hops.get(1).hopMessageId);
            }
        });
        LOGGER.info("==============================================================");
    }

    @Test
    public void new_order_single_rejected() throws Exception {

        //wait for trading server login
        tradingServer.discardUntil("35=A");
        Thread.sleep(100);
        final double fill_qty = 0.0;

        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(NORMALISED_SYMBOL);
        LOGGER.info(newOrderSingleUM.toString());
        LOGGER.info("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);
        final FixMessage newOrderSingle = tradingServer.discardUntil("35=D|55=" + SYMBOL + "|");

        //And Execution Report is sent with Status as Rejected
        tradingServer.send(executionReportFixMessage(newOrderSingle, "UNKNOWN", ExecType.Values.REJECTED, fill_qty));

        //Then Order with Rejected status is received
        final TradingMessage tradingResponse = Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(newOrderSingle.getField(11).getValue()))
                        .body().matches(ExecutionReportMatcher.orderId().eq("UNKNOWN"))
                        .body().matches(ExecutionReportMatcher.rejectText().eq("Rejection Test")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        tradingResponse.accept(new TradingMessageVisitor.Exception() {
            @Override
            public void onExecutionReport(final ExecutionReport executionReport) {
                    assertEquals(SENDER_COMP_ID, executionReport.body.senderCompId);
                    assertEquals("UNKNOWN", executionReport.body.orderId);
                    assertEquals("2312321", executionReport.body.execId);
                    assertEquals(newOrderSingle.getField(11).getValue(), executionReport.body.clOrdId);
                    assertEquals(REJECTED, executionReport.body.execType);
                    assertEquals(OrderStatus.REJECTED, executionReport.body.ordStatus);
                    assertEquals(Venue.FXALLMB.name(), executionReport.body.marketId);
                    assertEquals(CURRENCY, executionReport.body.currency);
                    assertNotNull(executionReport.body.settlDate);
                    assertEquals(Side.SELL, executionReport.body.side);
                    assertEquals(NORMALISED_SYMBOL, executionReport.body.symbol);
                    assertEquals(0.0, executionReport.body.commissionAdjLastPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.midPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.lastForwardPoints, TOLERANCE);
                    assertEquals(0.0, executionReport.body.commissionAdjAvgPx, TOLERANCE);
                    assertEquals(0.0, executionReport.body.commission, TOLERANCE);
                    assertEquals("Rejection Test", executionReport.body.rejectText);
                    assertEquals(0, executionReport.parties.size());
                    assertEquals(0, executionReport.strategyParameters.size());
                    assertEquals(0, executionReport.regulatoryTradeIds.size());
                    assertEquals(2, executionReport.hops.size());
                    assertEquals(FIRST_HOP, executionReport.hops.get(0).hopCompId);
                    assertEquals(0, executionReport.hops.get(0).hopReceivingTime);
                    assertEquals(SENDER_COMP_ID, executionReport.hops.get(1).hopCompId);
                    assertEquals(executionReport.body.messageId, executionReport.hops.get(1).hopMessageId);
                }
        });

        LOGGER.info(tradingResponse.toString());
        LOGGER.info("==============================================================");
    }

    @Test
    public void order_cancel_request_reject() throws Exception {

        //wait for trading server login
        Thread.sleep(1000);
        tradingServer.discardUntil("35=A");

        final OrderCancelRequest orderCancelRequest = orderCancelRequestUMMessage(NORMALISED_SYMBOL);
        LOGGER.info(orderCancelRequest.toString());
        LOGGER.info("==============================================================");
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequest);

        //Then verify that Order Cancel Request is sent
        tradingServer.discardUntil("35=F|55=" + SYMBOL + "|");
        LOGGER.info("==============================================================");

        //And OrderCancelReject is sent with Status as Rejected
        tradingServer.send(orderCancelRejectFixMessage(orderCancelRequest.body.clOrdId, orderCancelRequest.body.origClOrdId));
        Thread.sleep(100);

        //Then receive OrderCancelReject
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(OrderCancelRejectMatcher.build()
                        .body().matches(OrderCancelRejectMatcher.clOrdId().eq(orderCancelRequest.body.clOrdId))
                        .body().matches(OrderCancelRejectMatcher.origClOrdId().eq(orderCancelRequest.body.origClOrdId))
                        .body().matches(OrderCancelRejectMatcher.ordStatus().eq(OrderStatus.REJECTED))
                        .body().matches(OrderCancelRejectMatcher.cxlRejReason().eq(OrderCancelRejectReason.OTHER))
                        .body().matches(OrderCancelRejectMatcher.cxlRejResponseTo().eq(OrderCancelRequestType.ORDER_CANCEL_REPLACE_REQUEST))
                        .body().matches(OrderCancelRejectMatcher.text().eq("Minimum quote life for DA-INT-ANZPINK-CCG-1 of 1000ms is violated.")))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

    @Test
    public void should_send_logout_when_shutting_down() throws Exception {

        //wait for trading server login
        LOGGER.info("Waiting for Logon...");
        tradingServer.discardUntil("35=A");

        application.stop();

        final FixMessage logoutRequest = tradingServer.discardUntil("35=5");
        System.out.println(logoutRequest.toString());
        System.out.println("==============================================================");

        assertNotNull(logoutRequest.getField(FieldTypes.Text).getValue());
    }

    @Test
    public void should_send_logout_when_receive_logout() throws Exception {

        //wait for trading server login
        LOGGER.info("Waiting for Logon...");
        FixMessage logonMessage = tradingServer.discardUntil("35=A");
        assertNull(logonMessage.getField(FieldTypes.ResetSeqNumFlag));
        final FixMessage logoffMessage = new FixMessageBuilder().withField(FieldTypes.MsgType, "5").withField(FieldTypes.Text, "FXALLMB").build();
        // send logoff to adaptor
        tradingServer.send(logoffMessage);

        final FixMessage logoutRequest = tradingServer.discardUntil("35=5");

        System.out.println(logoutRequest.toString());
        System.out.println("==============================================================");
    }

    @Test
    public void should_send_heartbeat_when_trading_is_logged_on() throws Exception {

        //wait for trading server login
        LOGGER.info("Waiting for Logon...");
        tradingServer.discardUntil("35=A");

        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(HeartbeatMatcher.build()
                        .header().matches(HeartbeatMatcher.source().gt(0))
                        .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                        .body().matches(HeartbeatMatcher.senderCompId().eq("GB:lg-fxall"))
                        .body().matches(HeartbeatMatcher.messageId().gt(0L)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

}
