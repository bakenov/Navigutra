package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.domain.TradingTimeZone;

public interface AggressiveSpeedUpHedgerConfig extends HedgeInstrumentConfig {

    double getPnLThreshold();

    TradingTimeZone getTradingTimeZone();

    double getMaximumSpread();

    double getMinimumOrderQuantity();

    double getMinimumRisk();
}
