#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa0XXz "rm -rf ~/axle/datafabric/workspace"
ssh AxlSv@daxa0XXz "rm -rf ~/axle/datafabric/workspace"
ssh AxlSv@daxa0XXz "rm -rf ~/axle/datafabric/workspace"
