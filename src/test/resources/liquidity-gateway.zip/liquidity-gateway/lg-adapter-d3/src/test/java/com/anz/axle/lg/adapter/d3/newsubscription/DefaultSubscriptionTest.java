package com.anz.axle.lg.adapter.d3.newsubscription;

import java.io.IOException;
import java.util.function.LongSupplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.internal.util.collections.Sets;
import org.mockito.junit.MockitoJUnitRunner;

import de.digitec.d3.pricing.streaming.StreamingService;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DefaultSubscriptionTest {
    private String d3Symbol = "AUDUSD1M";
    @Mock
    private LongSupplier subscriptionIdGenerator;
    @Mock
    private UpdateProcessor delegateUpdateProcessor;
    @Mock
    private SubscriptionRegistry.Registerer registerer;
    @Mock
    private SubscriptionRegistry.Unregisterer unregisterer;
    @Mock
    private Queue.Appender<Runnable> requestsAppender;
    @Mock

    private Queue.Appender<Runnable> acknowledgeAppender;
    @Mock
    private PrecisionClock precisionClock;
    @Mock
    private StreamingService streamingService;

    @Captor
    private ArgumentCaptor<Runnable> subscribeRequest;
    @Captor
    private ArgumentCaptor<Runnable> unsubscribeRequest;
    @Captor
    private ArgumentCaptor<Runnable> subscribeAcknowledgement;
    @Captor
    private ArgumentCaptor<Runnable> unsubscribeAcknowledgement;

    @Mock
    private Snapshotter snapshotter;

    private long retryIntervalMillis = 1000;

    private InOrder inOrder;

    private DefaultSubscription subscription;

    @Before
    public void setUp() throws Exception {
        subscription = new DefaultSubscription(d3Symbol, subscriptionIdGenerator,
                delegateUpdateProcessor, registerer, unregisterer, requestsAppender, acknowledgeAppender,
                streamingService, precisionClock, snapshotter, retryIntervalMillis);

        inOrder = inOrder(registerer, unregisterer, requestsAppender, acknowledgeAppender, streamingService, snapshotter);
    }


    @Test
    public void should_subscribe_then_exprire_and_then_unsubscribe() throws Exception {
        //given
        final long subscriptionId = 234;
        when(subscriptionIdGenerator.getAsLong()).thenReturn(subscriptionId);
        when(streamingService.isConnected())
                .thenReturn(false) // initially not connected
                .thenReturn(true); // then should get connected
        final long expireTime = System.currentTimeMillis() + 1000;

        //1. when - subscribe on initial unsubscribed state
        subscription.subscribe(expireTime);

        //then
        inOrder.verify(registerer).register(subscriptionId, subscription);
        inOrder.verify(requestsAppender).enqueue(subscribeRequest.capture());

        //when - execute subscribe request
        subscribeRequest.getValue().run();

        //then
        inOrder.verify(streamingService).connect();
        inOrder.verify(streamingService).subscribe(String.valueOf(subscriptionId), d3Symbol);
        inOrder.verify(acknowledgeAppender).enqueue(subscribeAcknowledgement.capture());

        //when - execute acknowledgement
        subscribeAcknowledgement.getValue().run();

        //then - should be subscribed.

        //2. when - subscribe on subscribed
        final long expireTime2 = expireTime + 1000;
        subscription.subscribe(expireTime2);

        inOrder.verify(snapshotter).forwardCurrentSnapshot();

        when(precisionClock.millis())
                // set the clock to be between expireTime and expireTime2
                .thenReturn((expireTime2 + expireTime) / 2)
                // set the clock to be between expireTime and expireTime2
                .thenReturn(expireTime2 + 100);

        //when
        subscription.handleExpired();

        //then expect no effect
        inOrder.verify(requestsAppender, never()).enqueue(unsubscribeRequest.capture());

        //when
        subscription.handleExpired();
        inOrder.verify(requestsAppender).enqueue(unsubscribeRequest.capture());

        //when
        unsubscribeRequest.getValue().run();
        inOrder.verify(streamingService).unsubscribe(String.valueOf(subscriptionId));
        inOrder.verify(acknowledgeAppender).enqueue(unsubscribeAcknowledgement.capture());

        //when
        unsubscribeAcknowledgement.getValue().run();
        inOrder.verify(unregisterer).unregister(subscriptionId);
        inOrder.verify(snapshotter).clearBookAndForwardEmptySnapshot(any());
    }


    @Test
    public void should_fail_subscribe_then_resubscribe_and_then_get_subscribed() throws Exception {
        //given
        final long subscriptionId = 234;
        final long currentTime = System.currentTimeMillis();
        when(precisionClock.millis()).thenReturn(currentTime);

        when(subscriptionIdGenerator.getAsLong()).thenReturn(subscriptionId);
        when(streamingService.isConnected())
                .thenReturn(false) // first not connected
                .thenReturn(true); // second should be connected
        doThrow(new IOException("service is unavailable")).when(streamingService).connect();
        final long expireTime = System.currentTimeMillis() + 1000;

        //1. when - subscribe on initial unsubscribed state
        subscription.subscribe(expireTime);

        //then
        inOrder.verify(registerer).register(subscriptionId, subscription);
        inOrder.verify(requestsAppender).enqueue(subscribeRequest.capture());

        //when - execute subscribe request
        subscribeRequest.getValue().run();

        //then
        inOrder.verify(acknowledgeAppender).enqueue(unsubscribeAcknowledgement.capture());
        unsubscribeAcknowledgement.getValue().run();
        inOrder.verify(unregisterer).unregister(subscriptionId);

        //when - subscribe on initial subscriptionFailedState
        subscription.subscribe(expireTime);

        //then
        inOrder.verify(registerer).register(subscriptionId, subscription);
        inOrder.verify(requestsAppender).enqueue(subscribeRequest.capture());

        //when - execute subscribe request
        subscribeRequest.getValue().run();

        inOrder.verify(streamingService).subscribe(String.valueOf(subscriptionId), d3Symbol);
        inOrder.verify(acknowledgeAppender).enqueue(subscribeAcknowledgement.capture());

        //when - execute acknowledgement to get subscribed
        subscribeAcknowledgement.getValue().run();
        inOrder.verify(snapshotter).forwardCurrentSnapshotUpdatingFlags(any(), eq(Sets.newSet()));
    }

    @Test
    public void should_fail_subscribe_then_retry_and_then_get_subscribed() throws Exception {
        //given
        final long subscriptionId = 234;
        final long currentTime = System.currentTimeMillis();
        when(precisionClock.millis())
                .thenReturn(currentTime)
                .thenReturn(currentTime + retryIntervalMillis + 1);

        when(subscriptionIdGenerator.getAsLong()).thenReturn(subscriptionId);
        when(streamingService.isConnected())
                .thenReturn(false) // first not connected
                .thenReturn(true); // second should be connected
        doThrow(new IOException("service is unavailable")).when(streamingService).connect();
        final long expireTime = System.currentTimeMillis() + 1000;

        //1. when - subscribe on initial unsubscribed state
        subscription.subscribe(expireTime);

        //then
        inOrder.verify(registerer).register(subscriptionId, subscription);
        inOrder.verify(requestsAppender).enqueue(subscribeRequest.capture());

        //when - execute subscribe request
        subscribeRequest.getValue().run();

        //then
        inOrder.verify(acknowledgeAppender).enqueue(unsubscribeAcknowledgement.capture());
        unsubscribeAcknowledgement.getValue().run();
        inOrder.verify(unregisterer).unregister(subscriptionId);

        //when - subscribe on initial subscriptionFailedState
        subscription.retryFailed();

        //then
        inOrder.verify(registerer).register(subscriptionId, subscription);
        inOrder.verify(requestsAppender).enqueue(subscribeRequest.capture());

        //when - execute subscribe request
        subscribeRequest.getValue().run();

        inOrder.verify(streamingService).subscribe(String.valueOf(subscriptionId), d3Symbol);
        inOrder.verify(acknowledgeAppender).enqueue(subscribeAcknowledgement.capture());

        //when - execute acknowledgement to get subscribed
        subscribeAcknowledgement.getValue().run();
        inOrder.verify(snapshotter).forwardCurrentSnapshotUpdatingFlags(any(), eq(Sets.newSet()));
    }
}