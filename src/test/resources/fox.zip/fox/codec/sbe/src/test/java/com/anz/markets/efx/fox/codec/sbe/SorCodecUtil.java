package com.anz.markets.efx.fox.codec.sbe;

import java.nio.ByteBuffer;

import org.agrona.collections.MutableReference;
import org.agrona.concurrent.UnsafeBuffer;

import com.anz.markets.efx.fox.codec.api.InitialisationDecoder;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.api.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;

public class SorCodecUtil {
    public interface Codec {
        SorEncoderSupplier encoderSupplier();
        SbeMessage sbeMessage();
        VenueConfigDecoder venueConfigDecoder();
        UserConfigDecoder userConfigDecoder();
        InitialisationDecoder initialisationDecoder();
        InstrumentConfigDecoder instrumentConfigDecoder();
        VenueInstrumentConfigDecoder venueInstrumentConfigDecoder();
        FirewallConfigSbeDecoder firewallConfigSbeDecoder();
    }

    public static Codec create() {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final SorEncoders<SbeMessage> sbeSorEncoders = new SbeSorEncoders(() -> sbeMessage);
        final MutableReference<SbeMessage> encodedMessage = new MutableReference<>();
        final SorEncoderSupplier encoderSupplier = sbeSorEncoders.toSorEncoderSupplier(encodedMessage::set);
        final VenueConfigSbeDecoder venueSbeDecoder = new VenueConfigSbeDecoder();
        final UserConfigSbeDecoder userSbeDecoder = new UserConfigSbeDecoder();
        final InitialisationSbeDecoder initialisationSbeDecoder = new InitialisationSbeDecoder();
        final InstrumentConfigSbeDecoder instrumentConfigSbeDecoder = new InstrumentConfigSbeDecoder();
        final VenueInstrumentConfigSbeDecoder venueInstrumentConfigSbeDecoder = new VenueInstrumentConfigSbeDecoder();
        final FirewallConfigSbeDecoder firewallConfigSbeDecoder = new FirewallConfigSbeDecoder();

        return new Codec() {
            @Override
            public SorEncoderSupplier encoderSupplier() {
                return encoderSupplier;
            }

            @Override
            public SbeMessage sbeMessage() {
                return encodedMessage.get();
            }

            @Override
            public VenueConfigDecoder venueConfigDecoder() {
                venueSbeDecoder.wrap(encodedMessage.get());
                return venueSbeDecoder;
            }

            @Override
            public UserConfigDecoder userConfigDecoder() {
                userSbeDecoder.wrap(encodedMessage.get());
                return userSbeDecoder;
            }

            @Override
            public InitialisationDecoder initialisationDecoder() {
                initialisationSbeDecoder.wrap(encodedMessage.get());
                return initialisationSbeDecoder;
            }

            @Override
            public InstrumentConfigDecoder instrumentConfigDecoder() {
                instrumentConfigSbeDecoder.wrap(encodedMessage.get());
                return instrumentConfigSbeDecoder;
            }

            @Override
            public VenueInstrumentConfigDecoder venueInstrumentConfigDecoder() {
                venueInstrumentConfigSbeDecoder.wrap(encodedMessage.get());
                return venueInstrumentConfigSbeDecoder;
            }

            @Override
            public FirewallConfigSbeDecoder firewallConfigSbeDecoder() {
                firewallConfigSbeDecoder.wrap(encodedMessage.get());
                return firewallConfigSbeDecoder;
            }
        };
    }
}
