package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.LatencyFilterConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingArbitrageFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.matcher.PricingFirewallTypeMatcher;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.pfp.PliableBookOperation;
import com.anz.markets.prophet.pricer.pfp.PliableBookVariable;
import com.anz.markets.prophet.pricer.wholesale.spreads.ArbitrageSpreadStrategy;
import com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.domain.Region.JP;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement(Ref.PRICING_4_7_2)
@RestartBeforeTest(reason = "Firewall maintain states.")
public class ArbitrageProtectionFirewallTest extends BaseAcceptanceSpecification {

    final Instrument ccyPair = Instrument.AUDUSD;

    private ConfigurationDataDefault configWithArbThresholdFactor(double threshold, boolean enabledPriceWidening) {

        ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()

                // Set up for SM Filter. Threshold of 0.05pip * 1(multiplier)
                .setInstrumentConfigs(Lists.newArrayList(
                        new InstrumentConfigImpl(Instrument.AUDUSD).setSpreadMultiplier(1).setSpotDecimalPlaces(4.0).setSpotFractionalPip(1.0).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0.0).setAllInDecimalPlaces(5.0)
                ))
                .setStandardMarketSpreadConfigs(Lists.newArrayList(
                        new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 0.000005, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                ))

                .setClientSpreadConfigs(Lists.newArrayList(
                        new ClientSpreadConfigImpl(Market.WSP_A, ccyPair, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, ccyPair, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, ccyPair, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),

                        new ClientSpreadConfigImpl(Market.WSP_A, ccyPair, Level.QTY_1M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, ccyPair, Level.QTY_3M.getQty(), Region.JP).set(TradingTimeZone.LDN, 0.9),
                        new ClientSpreadConfigImpl(Market.WSP_A, ccyPair, Level.QTY_5M.getQty(), Region.JP).set(TradingTimeZone.LDN, 1.6)
                ))
                // set arbitrage threshold limit
                .setPricingArbitrageFirewallConfigs(Lists.newArrayList(
                        new PricingArbitrageFirewallConfigImpl(Market.ANY, Instrument.AUDUSD, threshold, true, enabledPriceWidening)
                ))
                // clear hedger config else for each pair configured, the corresponding MarketConfigs must exist
                .setPassiveHedgerConfigs(Collections.emptyList());

        return configurationDataDefault;
    }

    @Test
    @DisplayName("Arbitrage firewall should not trigger when both sides are EQUAL than threshold.")
    public void shouldNotTriggerWhenEqualToThreshold() {

        given:
        {
            /* arbitrage threshold limit */
            final double threshold = 0.4;

            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false));
        }

        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));

        }
        then:
        /* expect client price to be INDICATIVE as both side's differences are EQUAL to threshold
        *  PROPHET Client OFFER - REFERENCE BID == threshold
        *  REFERENCE OFFER - PROPHET Client BID == threshold
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Arbitrage firewall should NOT trigger due to using JP MarketConfigImpl")
    public void shouldNotTriggerUsingJPMarketConfig() {

        given:
        {
            // set Region to JP
            prophet.setRegion(JP);

            /* arbitrage threshold limit */
            final double threshold = 0.45;

            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false)
                    .setMarketConfigs(Arrays.asList(
                            // Driver Pairs
                            new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.CNX).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.HSP).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true),

                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.EURCHF).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.EURJPY).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.EURUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.GBPJPY).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.NZDUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDCAD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDCHF).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDCNH).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDJPY).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.RFX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.EURCHF).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.EURJPY).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.EURUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.GBPJPY).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.GBPUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.NZDUSD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDCAD).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDCHF).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDCNH).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.EBS).setRegion(JP).setInstrument(Instrument.USDJPY).setEnabled(true).setStepSizePips(0.5),
                            new MarketConfigImpl(Market.RFX).setRegion(JP).setInstrument(Instrument.AUDUSD).setEnabled(true).setStepSizePips(0.5)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP,Market.RFX)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.RFX)
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.JP,Market.CNX,Market.HSP,Market.RFX)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.JP,Market.HSP,Market.RFX)
            );
        }
        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106)); // Reference Mkt in GB only
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76103, 0.76107));  // Reference Mkt in JP only
        }
        then:
        /* expect client price to be FIRM as both side's differences are GREATER than threshold
        *  PROPHET Client OFFER - REFERENCE BID = 0.5 > threshold
        *  REFERENCE OFFER - PROPHET Client BID = 0.5 > threshold
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Arbitrage firewall should trigger when both sides are LESS than threshold.")
    public void shouldTriggerWhenLessThanThreshold() {
        /* arbitrage threshold limit */
        final double threshold = 0.41;
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false));
        }

        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));

        }
        then:
        /*
        *   expect client price to be firm as both side's differences are LESS than threshold
        *   PROPHET Client OFFER - REFERENCE BID (0.4) < threshold (0.41)
        *   REFERENCE OFFER - PROPHET Client BID (0.4) < threshold (0.41)
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be INDICATIVE", clientPrices.getLast().getBidQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.ARBITRAGE));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.ARBITRAGE));
        }
        when:
        // AXPROPHET-473 verify arbitrage widening
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76103, 0.76105));
            prophet.clearOutputBuffer();

            // enable arbitrage widening
            prophet.receive(configWithArbThresholdFactor(threshold, true)
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));
        }
        then:
        {
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Instrument.AUDUSD)).getFirst();
            assertThat(wbf.getArbitrageSpreadBid(), isRoundedTo(0.31)); // SkewedMid - (ReferenceOffer - arbThreshold)
            assertThat(wbf.getArbitrageSpreadOffer(), isRoundedTo(0.31)); // (ReferenceBid + arbThreshold) - SkewedMid
            assertThat(wbf.getModelSpread(), isRoundedTo(0.62));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(ArbitrageSpreadStrategy.FEATURE_NAME);
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.ACTIVE_IMPACT));
            assertThat(ftl.getNumOperationLines(), Matchers.is(2));
            assertThat(ftl.operations[0].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftl.operations[0].var, Matchers.is(PliableBookVariable.BID_SPREAD_IN_PIPS));
            assertThat(ftl.operations[0].oldVal, Matchers.is(0.30));
            assertThat(ftl.operations[0].newVal, isRoundedTo(0.31));
            assertThat(ftl.operations[1].operation, Matchers.is(PliableBookOperation.WIDEN_SPREAD));
            assertThat(ftl.operations[1].var, Matchers.is(PliableBookVariable.OFFER_SPREAD_IN_PIPS));
            assertThat(ftl.operations[1].oldVal, Matchers.is(0.30));
            assertThat(ftl.operations[1].newVal, isRoundedTo(0.31));

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            // Bid/Ask model spreads widened by 0.4pip due to arbitrage resulting in 0.7pip Bid/Offer model spread
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.761019, 0.761081));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Arbitrage firewall should not trigger when both sides are GREATER than negative threshold.")
    public void shouldNotTriggerWhenGreaterThanNegativeThreshold() {
        given:
        {
            /* arbitrage threshold limit */
            final double threshold = -0.1;

            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false));
        }

        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));

        }
        then:
        /*
        *   expect client price to be firm as both side's differences are GREATER than threshold
        *   PROPHET Client OFFER - REFERENCE BID > threshold
        *   REFERENCE OFFER - PROPHET Client BID > threshold
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Arbitrage firewall triggered on BID side only")
    public void shouldTriggerOnBidSideOnly() {
        /* arbitrage threshold limit */
        final double threshold = 0.6;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false)
                    .setMarketConfigs(Arrays.asList(
                            new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76101, 0.76107));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76104, 0.76106)); // not a reference mkt so NOT included in ARB firewall
        }
        then:
        /* expect client price on BID side to be INDICATIVE since difference is EQUAL to threshold
        *  REFERENCE OFFER(RAW BOOK) - PROPHET Client BID (0.5) < threshold(0.6) => PROPHET BID INDICATIVE
        *  PROPHET Client OFFER - REFERENCE BID(RAW BOOK) (0.7) >= threshold(0.6)  => PROPHET OFFER FIRM
        */
        {
            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(2), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be INDICATIVE", clientPrices.getLast().getBidQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.ARBITRAGE));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
        when:
        // AXPROPHET-473 verify arbitrage widening
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76103, 0.76105));
            prophet.clearOutputBuffer();

            // enable arbitrage widening
            prophet.receive(configWithArbThresholdFactor(threshold, true)
                    .setMarketConfigs(Arrays.asList(
                    new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                    new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76103, 0.76105));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76104, 0.76106));
        }
        then:
        {
            WholesaleBookFactors wsbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Instrument.AUDUSD)).getFirst();
            assertThat(wsbf.getSkewedMidPrice(), isRoundedTo(0.76105));
            // ref is 0.76101~0.76107
            assertThat(wsbf.getArbitrageSpreadBid(), isRoundedTo(0.4)); // SkewedMid - (ReferenceOffer - arbThreshold)
            assertThat(wsbf.getArbitrageSpreadOffer(), isRoundedTo(0.2)); //  (ReferenceBid + arbThreshold) - SkewedMid
            assertThat(wsbf.getModelSpread(), isRoundedTo(0.7)); // Max of all bid spreads is ArbitrageSpreadBid(0.4).  Max of all offer spreads is base spread(0.3)

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.76101, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Arbitrage firewall triggered on OFFER side only")
    public void shouldTriggerOnOfferSideOnly() {
        /* arbitrage threshold limit */
        final double threshold = 0.6;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false)
                    .setMarketConfigs(Arrays.asList(
                            new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76101, 0.76107));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76102, 0.76104)); // not a reference mkt so NOT included in ARB firewall
        }
        then:
        /* expect client price on OFFER side to be INDICATIVE since differences is EQUAL to threshold
        *  REFERENCE OFFER(RAW BOOK) - PROPHET Client BID (0.7) >= threshold(0.6) => PROPHET BID FIRM
        *  PROPHET Client OFFER - REFERENCE BID(RAW BOOK) (0.5) < threshold(0.6) => PROPHET OFFER INDICATIVE
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(2), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.76100, 0.76106));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.ARBITRAGE));
        }
        when:
        // AXPROPHET-473 verify arbitrage widening
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76103, 0.76105));
            prophet.clearOutputBuffer();

            // enable arbitrage widening
            prophet.receive(configWithArbThresholdFactor(threshold, true)
                    .setMarketConfigs(Arrays.asList(
                    new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                    new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
            );
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76103, 0.76105));
            prophet.clearOutputBuffer();

            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76102, 0.76104));
        }
        then:
        {
            WholesaleBookFactors wsbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(Instrument.AUDUSD)).getFirst();
            assertThat(wsbf.getSkewedMidPrice(), isRoundedTo(0.76103));
            // ref mkt is .76101, 0.76107
            assertThat(wsbf.getArbitrageSpreadBid(), isRoundedTo(0.2)); // SkewedMid - (ReferenceOffer - arbThreshold)
            assertThat(wsbf.getArbitrageSpreadOffer(), isRoundedTo(0.4)); //  (ReferenceBid + arbThreshold) - SkewedMid
            assertThat(wsbf.getModelSpread(), isRoundedTo(0.7)); // Max of all bid spreads is base spread(0.3).  Max of all offer spreads is ArbitrageSpreadOffer(0.4)

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.76100, 0.76107));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("CNX configured as NOT reference market. If CNX included in raw book then firewall would be triggered on OFFER side")
    public void firewallTakesIntoAccountReferenceMarketConfig() {

        given:
        // CNX is NOT a reference market. Therefore NOT part of RAW Book
        {
            /* arbitrage threshold limit */
            final double threshold = 0.41;

            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false)
                    .setMarketConfigs(Arrays.asList(
                            new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX,Market.HSP)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.HSP)
            );
        }

        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));  // NOT PART OF RAW BOOK
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76103, 0.76107));

        }
        then:
        /*
        *   expect client price to be firm as both side's differences are GREATER than threshold
        *   PROPHET Client OFFER - REFERENCE BID (0.5) < threshold (0.41)
        *   REFERENCE OFFER - PROPHET Client BID (0.5) < threshold (0.41)
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Arbitrage firewall should trigger since against configured markets")
    public void configuredAgainstDifferentMarkets() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(0.5, false)
                    // configure arb firewall for other markets
                    .setPricingArbitrageFirewallConfigs(Lists.newArrayList(
                            new PricingArbitrageFirewallConfigImpl(Market.WSP_A, Instrument.AUDUSD, 0.1, true, true),  // set small so arb wont be triggered
                            new PricingArbitrageFirewallConfigImpl(Market.WSP_B, Instrument.AUDUSD, 0.6, true, true) // set large so if used arb will be triggered
                    ))
            );
        }
        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));

        }
        then:
        /*
        * Using WSP_A arb config, not triggered
        */
        {
            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.AUDUSD, Market.WSP_A));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be INDICATIVE", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Since No Auto_Reset flag, prices should automatically return to firm if firewall conditions not met")
    public void returnToFirmWhenFirewallConditionsNotMet() {
        given:
        {
            /* arbitrage threshold limit */
            final double threshold = 0.41;

            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false));
        }

        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76104, 0.76106));

        }
        then:
        /*
        *   expect client price to be firm as both side's differences are LESS than threshold
        *   PROPHET Client OFFER - REFERENCE BID (0.4) < threshold (0.41)
        *   REFERENCE OFFER - PROPHET Client BID (0.4) < threshold (0.41)
        */
        {

            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getFirst(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be INDICATIVE", clientPrices.getLast().getBidQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.ARBITRAGE));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.ARBITRAGE));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76103, 0.76107));
        }
        then:
        /*
        *   expect client price to be firm as both side's differences are GREATER than threshold
        *   PROPHET Client OFFER - REFERENCE BID (0.5) < threshold (0.41)
        *   REFERENCE OFFER - PROPHET Client BID (0.5) < threshold (0.41)
        */
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(1), isClientPriceInstrument(Instrument.AUDUSD)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrice.getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrice, new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrice.getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrice, new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Raw book does not include latent L-Filter prices")
    public void rawBookDoesNotIncludeLatentPrices() {

        given:
        {   /* arbitrage threshold limit */
            final double threshold = 0.30;

            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault config = configWithArbThresholdFactor(threshold, false);
            config.setLatencyFilterConfigs(Arrays.asList(
                    new LatencyFilterConfigImpl(Market.CNX, Integer.MAX_VALUE),
                    new LatencyFilterConfigImpl(Market.HSP, 10)
            ));

            prophet.receive(config);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76101, 0.76106));

            /**
             * (3)	Reference rates would be sourced from nominated markets (configurable) and obtained from PROPHET’s Raw** aggregated book.
             ** Raw book, in this case, would still filter out stale markets (S-filter) and latent rates (L-filter).
             */
            // Will be filtered by SM-filter. Also filtered by L-filter so NOT included in Raw Aggregated Book
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76106, 0.76105, now() - 1000L));

            // triggers price change and this price should be indicative
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76103, 0.76107));
        }
        then:
        /* RAW BOOK should NOT include HSP since filtered by L-Filter. Thus only CNX price included)
        *  PROPHET Client OFFER - REFERENCE BID(RAW BOOK) (5.0) > threshold (3.0)  => Prophet OFFER FIRM
        *
        *  IF HSP price(filtered out by L-Filter) was incorrectly included in RAW Book, then Prophet Offer would be INDICATIVE:
        *  PROPHET Client OFFER - REFERENCE BID(RAW BOOK including HSP) (0.2) < threshold (3.0)  => Prophet OFFER INDICATIVE
        */
        {
            // Check Client Prices
            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(2), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.76102, 0.76108));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    @DisplayName("Raw book does not include crossed SM-Filter prices")
    public void rawBookDoesNotIncludeCrossedPrices() {

        given:
        {   /* arbitrage threshold limit */
            final double threshold = 0.16;

            prophet.receive(TradingTimeZone.LDN);

            prophet.receive(configWithArbThresholdFactor(threshold, false));
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76103, 0.76107));
            /**
             * (3)	Reference rates would be sourced from nominated markets (reference) and obtained from PROPHET's Raw** aggregated book.
             ** Raw book has now been changed to have all filters like WSPU
             */
            // Will be filtered by SM filter. (If RAW book still included then ARB firewall would be triggered)
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.76107, 0.76104));

            // triggers price change and this price should be indicative
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76105, 0.76106));
        }
        then:
        /* expect client price to be INDICATIVE on both side's since differences are EQUAL to threshold
        *  PROPHET Client OFFER - REFERENCE BID(RAW BOOK) (4.5) >= threshold (1.6)
        *  REFERENCE OFFER(RAW BOOK) - PROPHET Client BID (4.5) >= threshold (1.6)
        */
        {
            // Check Client Prices
            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, atLeast(2), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.761025, 0.761085));

            assertThat("Quote type on BID side should be FIRM", clientPrices.getLast().getBidQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }

    @Test
    public void triggerWhenTobAggBookUnchanged() {
        /* arbitrage threshold limit */
        final double threshold = 0.9;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // Only HSP is a Reference Market
            prophet.receive(configWithArbThresholdFactor(threshold, false)
                    .setMarketConfigs(Arrays.asList(
                            new MarketConfigImpl(Market.CNX).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true),
                            new MarketConfigImpl(Market.HSP).setRegion(GB).setInstrument(Instrument.AUDUSD).setEnabled(true)))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.CNX)
                    .addAggBook(Market.WSP_R,Instrument.AUDUSD,TradingTimeZone.GLOBAL,Region.GB,Market.HSP)
            );
        }
        when:
        // send HSP price which does not change Aggbook TOB
        {
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.CNX, ccyPair, 0.76100, 0.76106));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.HSP, ccyPair, 0.75090, 0.76108));
        }
        then:
        /* expect client price on BID side to be INDICATIVE
        *  REFERENCE OFFER(RAW BOOK) 0.76108 - PROPHET Client BID (0.76100) < threshold(0.9) => PROPHET BID INDICATIVE
        *  PROPHET Client OFFER 0.76106 - REFERENCE BID(RAW BOOK) (0.75090) >= threshold(0.9)  => PROPHET OFFER FIRM
        */
        {
            LinkedList<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(2), isClientPriceInstrument(Instrument.AUDUSD));
            assertThat(clientPrices.getLast(), isClientPricePoint(0, Level.QTY_1M, 0.76100, 0.76106));

            assertThat("Quote type on BID side should be INDICATIVE", clientPrices.getLast().getBidQuoteType(), is(QuoteType.INDICATIVE));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.ARBITRAGE));

            assertThat("Quote type on OFFER side should be FIRM", clientPrices.getLast().getOfferQuoteType(), is(QuoteType.FIRM));
            assertThat(clientPrices.getLast(), new PricingFirewallTypeMatcher(OrderSide.OFFER));
        }
    }
}