package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.WireIn;
import net.openhft.chronicle.wire.Wires;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import static software.chronicle.generated.code.messages.NewOrderSingle.newNewOrderSingle;

/**
 * @author Rob Austin.
 */
public class ClientMessageNotifier implements MessageNotifier, Demarshallable {

    private final BlockingQueue<String> q;

    private ClientMessageNotifier(WireIn w) {
        q = new ArrayBlockingQueue<>(1);
    }

    @NotNull
    private static NewOrderSingle newOrderSingle(FixSessionContext context) {
        final NewOrderSingle serverExpects = newNewOrderSingle(Wires.acquireBytes(), context);
        serverExpects.ordType('2');
        // side is required
        //serverExpects.side('1');
        serverExpects.symbol(Bytes.from("LCOM1"));
        serverExpects.clOrdID(Bytes.allocateDirect("CL_ORD_ID".getBytes()));
        serverExpects.handlInst('3');
        serverExpects.transactTime(1451902315496L);
        serverExpects.orderQty(1);
        serverExpects.price(200.0);
        serverExpects.timeInForce('0');
        serverExpects.maturityMonthYear("201106");
        serverExpects.securityType("FUT");
        serverExpects.idSource("5");
        serverExpects.securityID(Bytes.from("LCOM1"));
        serverExpects.account(Bytes.from("ABCTEST1"));
        return serverExpects;
    }

    @Override
    public MessageGenerator onExecutionReport(ExecutionReport executionReport) {
        executionReport.sendingTime(0);
        String e = executionReport.toString();
        q.add(e);
        return null;
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        reject.sendingTime(0);
        q.add(reject.toString());
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        session.sendMessage(newOrderSingle(session.context()));
    }

    public BlockingQueue<String> queue() {
        return q;
    }
}
