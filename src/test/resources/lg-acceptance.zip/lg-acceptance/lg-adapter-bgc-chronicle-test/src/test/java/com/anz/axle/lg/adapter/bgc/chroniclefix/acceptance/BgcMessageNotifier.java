package com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.BusinessMessageReject;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelReject;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Quote;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultExecutionReport;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultLogon;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultLogout;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultNewOrderSingle;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultOrderCancelReject;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultOrderCancelRequest;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultQuote;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Logout;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.FixSessionHandler;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class BgcMessageNotifier implements MessageNotifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcMessageNotifier.class);
    private final BlockingQueue<StandardHeaderTrailer> queue = new ArrayBlockingQueue<>(1024);

    public BlockingQueue<StandardHeaderTrailer> queue() {
        return queue;
    }

    private void queue(final StandardHeaderTrailer original, final StandardHeaderTrailer copy) {
        LOGGER.info("Received: {}", original);
        queue.add(copyTo(original, copy));
    }

    private StandardHeaderTrailer copyTo(final StandardHeaderTrailer from, final StandardHeaderTrailer to) {
        from.copyTo(to);
        return to;
    }

    @Override
    public void onLogon(final FixSessionHandler session, final Logon logon) {
        queue(logon, new DefaultLogon());
    }

    @Override
    public void onLogout(final FixSessionHandler session, final Logout logout) {
        queue(logout, new DefaultLogout());
    }

    @Override
    public void onQuote(final FixSessionHandler session, final Quote quote) {
        queue(quote, new DefaultQuote());
    }

    @Override
    public void onExecutionReport(final FixSessionHandler session, final ExecutionReport executionReport) {
        queue(executionReport, new DefaultExecutionReport());
    }

    @Override
    public void onOrderCancelReject(final FixSessionHandler session, final OrderCancelReject orderCancelReject) {
        queue(orderCancelReject, new DefaultOrderCancelReject());
    }

    @Override
    public void onOrderCancelRequest(final FixSessionHandler session, final OrderCancelRequest orderCancelRequest) {
        queue(orderCancelRequest, new DefaultOrderCancelRequest());
    }

    @Override
    public void onNewOrderSingle(final FixSessionHandler session, final NewOrderSingle newOrderSingle) {
        queue(newOrderSingle, new DefaultNewOrderSingle());
    }

    @Override
    public void onBusinessMessageReject(final FixSessionHandler session, final BusinessMessageReject businessMessageReject) {
        LOGGER.error("onBusinessMessageReject |{}| received!", businessMessageReject);
    }

    @Override
    public void onUnsupportedMessageType(final FixSessionHandler session, final int msgType) {
        LOGGER.error("onUnsupportedMessageType |{}| received!", msgType);
    }
}
