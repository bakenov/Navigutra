package com.anz.axle.lg.adapter.fast.chroniclefix;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import software.chronicle.fix.datamodel.AbstractDataModel;
import software.chronicle.fix.sessioncode.fields.Text;

import com.anz.axle.lg.adapter.chroniclefix.FixMessageHandler;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.MDReqID;
import com.anz.axle.lg.adapter.fast.chroniclefix.generated.fields.MDReqRejReason;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestRejectStrategy;

public final class FastMarketDataRequestRejectHandler implements FixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(FastMarketDataRequestRejectHandler.class);

    private final SubscriptionManager subscriptionManager;
    private final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy;

    public FastMarketDataRequestRejectHandler(final SubscriptionManager subscriptionManager,
                                              final SubscriptionRequestRejectStrategy subscriptionRequestRejectStrategy) {
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.subscriptionRequestRejectStrategy = Objects.requireNonNull(subscriptionRequestRejectStrategy);
    }

    @Override
    public void accept(final AbstractDataModel message) throws IllegalArgumentException {
        final int mdRequestId = message.getInt(MDReqID.FIELD);
        final char mdRequestRejectReason = message.getChar(MDReqRejReason.FIELD);
        final String rejectMessage = message.getString(Text.FIELD);

        LOGGER.error("MarketDataRequest has been rejected with message: {}, rejection reason code: {}", rejectMessage, mdRequestRejectReason);

        subscriptionManager.rejectRequest(mdRequestId, subscriptionRequestRejectStrategy);

    }
}
