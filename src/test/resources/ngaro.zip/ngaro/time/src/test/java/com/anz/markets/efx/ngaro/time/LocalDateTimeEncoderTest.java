package com.anz.markets.efx.ngaro.time;

import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteWriter;

public class LocalDateTimeEncoderTest {

    @Test
    public void encodeEpochNanos() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        final LocalDateTime localDateTime = LocalDateTime.of(2017, 02, 28, 17, 15, 31, 123456789);
        encoder.encodeEpochNanos(string, ByteWriter.STRING_BUILDER, offset, localDateTime.toEpochSecond(ZoneOffset.UTC) * Epoch.NANOS_PER_SECOND + localDateTime.getNano());
        encoder.encodeEpochNanos(bytes, ByteWriter.BYTE_ARRAY, localDateTime.toEpochSecond(ZoneOffset.UTC) * Epoch.NANOS_PER_SECOND + localDateTime.getNano());
        encoder.encodeEpochNanos(buffer, ByteWriter.BYTE_BUFFER, localDateTime.toEpochSecond(ZoneOffset.UTC) * Epoch.NANOS_PER_SECOND + localDateTime.getNano());

        //then
        Assert.assertEquals("encoded string not as expected", "abc2017-02-28T17:15:31.123456789klmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "2017-02-28T17:15:31.123456789", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "2017-02-28T17:15:31.123456789", new String(buffer.array()));
    }

    @Test
    public void encodeEpochMillis() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_MMM);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        final LocalDateTime localDateTime = LocalDateTime.of(2017, 02, 28, 17, 15, 31, 123456789);
        encoder.encodeEpochMillis(string, ByteWriter.STRING_BUILDER, offset, localDateTime.toEpochSecond(ZoneOffset.UTC) * Epoch.MILLIS_PER_SECOND + localDateTime.getNano() / Epoch.NANOS_PER_MILLI);
        encoder.encodeEpochMillis(bytes, ByteWriter.BYTE_ARRAY, localDateTime.toEpochSecond(ZoneOffset.UTC) * Epoch.MILLIS_PER_SECOND + localDateTime.getNano() / Epoch.NANOS_PER_MILLI);
        encoder.encodeEpochMillis(buffer, ByteWriter.BYTE_BUFFER, localDateTime.toEpochSecond(ZoneOffset.UTC) * Epoch.MILLIS_PER_SECOND + localDateTime.getNano() / Epoch.NANOS_PER_MILLI);

        //then
        Assert.assertEquals("encoded string not as expected", "abc2017-02-28T17:15:31.123cdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "2017-02-28T17:15:31.123", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "2017-02-28T17:15:31.123", new String(buffer.array()));
    }

    @Test
    public void encodeEpochSeconds() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        final LocalDateTime localDateTime = LocalDateTime.of(2017, 02, 28, 17, 15, 31, 123456789);
        encoder.encodeEpochSeconds(string, ByteWriter.STRING_BUILDER, offset, localDateTime.toEpochSecond(ZoneOffset.UTC));
        encoder.encodeEpochSeconds(bytes, ByteWriter.BYTE_ARRAY, localDateTime.toEpochSecond(ZoneOffset.UTC));
        encoder.encodeEpochSeconds(buffer, ByteWriter.BYTE_BUFFER, localDateTime.toEpochSecond(ZoneOffset.UTC));

        //then
        Assert.assertEquals("encoded string not as expected", "abc2017-02-28T17:15:31yzabcdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "2017-02-28T17:15:31", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "2017-02-28T17:15:31", new String(buffer.array()));
    }

    @Test
    public void encodeLocalDateTime() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_MMM);
        final LocalDateTime localDateTime = LocalDateTime.of(2017, 02, 28, 17, 15, 31, 123456789);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        encoder.encode(string, ByteWriter.STRING_BUILDER, offset, localDateTime);
        encoder.encode(bytes, ByteWriter.BYTE_ARRAY, localDateTime);
        encoder.encode(buffer, ByteWriter.BYTE_BUFFER, localDateTime);

        //then
        Assert.assertEquals("encoded string not as expected", "abc2017-02-28T17:15:31.123cdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "2017-02-28T17:15:31.123", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "2017-02-28T17:15:31.123", new String(buffer.array()));
    }

    @Test
    public void encodeLocalDateNull() {
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_MMM);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        encoder.encode(string, ByteWriter.STRING_BUILDER, offset, null);
        encoder.encode(bytes, ByteWriter.BYTE_ARRAY, null);
        encoder.encode(buffer, ByteWriter.BYTE_BUFFER, null);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0cdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeNull() {
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_UUUUUU);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        encoder.encodeNull(string, ByteWriter.STRING_BUILDER, offset);
        encoder.encodeNull(bytes, ByteWriter.BYTE_ARRAY);
        encoder.encodeNull(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abc\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0\0\0\0fghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test
    public void encodeAllFormats() {
        final LocalDateTime input = LocalDateTime.of(2017, 02, 24, 17, 15, 30, 123456789);
        final LocalDateFormat[] dateFormats = {LocalDateFormat.YYYYMMDD, LocalDateFormat.MMDDYYYY, LocalDateFormat.DDMMYYYY,
                LocalDateFormat.YYYY_MM_DD, LocalDateFormat.MM_DD_YYYY, LocalDateFormat.DD_MM_YYYY};
        final LocalTimeFormat[] timeFormats = {
                LocalTimeFormat.HHMM, LocalTimeFormat.HHMMSS, LocalTimeFormat.HHMMSSMMM, LocalTimeFormat.HHMMSSUUUUUU, LocalTimeFormat.HHMMSSNNNNNNNNN,
                LocalTimeFormat.HH_MM, LocalTimeFormat.HH_MM_SS, LocalTimeFormat.HH_MM_SS_MMM, LocalTimeFormat.HH_MM_SS_UUUUUU, LocalTimeFormat.HH_MM_SS_NNNNNNNNN
        };
        final String[] dateStrings = {"20170224", "02242017", "24022017",
                "2017-02-24", "02-24-2017", "24-02-2017"};
        final String[] timeStrings = {
                "1715", "171530", "171530123", "171530123456", "171530123456789",
                "17:15", "17:15:30", "17:15:30.123", "17:15:30.123456", "17:15:30.123456789"
        };
        final char[] dateDelims = {'-', '/'};
        final char[] timeDelims = {':', '.'};
        final char[] decimalSymbols = {'.', '_'};
        final char[] dateTimeSeparators = {'T', '_', ' ', LocalDateTimeEncoder.NO_SEPARATOR};

        for (int df = 0; df < dateFormats.length; df++) {
            for (int tf = 0; tf < timeFormats.length; tf++) {
                for (final char ddelim : dateDelims) {
                    for (final char tdelim : timeDelims) {
                        for (final char sym : decimalSymbols) {
                            for (final char sep : dateTimeSeparators) {
                                final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(dateFormats[df], timeFormats[tf], sep, ddelim, tdelim, sym);
                                final String format = encoder.getDateTimeFormatString();
                                final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
                                final int offset = 3;
                                final byte[] bytes = new byte[encoder.getLength()];
                                final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

                                //when
                                encoder.encode(string, ByteWriter.STRING_BUILDER, offset, input);
                                encoder.encode(bytes, ByteWriter.BYTE_ARRAY, input);
                                encoder.encode(buffer, ByteWriter.BYTE_BUFFER, input);

                                //then
                                final String expected = dateStrings[df].replace('-', ddelim) + (sep == LocalDateTimeEncoder.NO_SEPARATOR ? "" : sep) + timeStrings[tf].replace('.', sym).replace(':', tdelim);
                                final String expectedString = "abc" + expected + "defghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz".substring(expected.length());
                                Assert.assertEquals("encoded string not as expected for format " + format, expectedString, string.toString());
                                Assert.assertEquals("encoded bytes not as expected for format " + format, expected, new String(bytes));
                                Assert.assertEquals("encoded buffer not as expected for format " + format, expected, new String(buffer.array()));
                            }
                        }
                    }
                }
            }
        }
    }

    @Test
    public void encodeYearMonthDayHourMinuteSecond() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final int year = 2017;
        final int month = 02;
        final int day = 28;
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        encoder.encode(string, ByteWriter.STRING_BUILDER, offset, year, month, day, hh, mm, ss, 0);
        encoder.encode(bytes, ByteWriter.BYTE_ARRAY, year, month, day, hh, mm, ss);
        encoder.encode(buffer, ByteWriter.BYTE_BUFFER, year, month, day, hh, mm, ss);

        //then
        Assert.assertEquals("encoded string not as expected", "abc2017-02-28T17:15:30yzabcdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "2017-02-28T17:15:30", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "2017-02-28T17:15:30", new String(buffer.array()));
    }

    @Test
    public void encodeYearMonthDayHourMinuteSecondNano() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final int year = 2017;
        final int month = 02;
        final int day = 28;
        final int hh = 17;
        final int mm = 15;
        final int ss = 30;
        final int nn = 223344321;
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        encoder.encode(string, ByteWriter.STRING_BUILDER, offset, year, month, day, hh, mm, ss, nn);
        encoder.encode(bytes, ByteWriter.BYTE_ARRAY, year, month, day, hh, mm, ss, nn);
        encoder.encode(buffer, ByteWriter.BYTE_BUFFER, year, month, day, hh, mm, ss, nn);

        //then
        Assert.assertEquals("encoded string not as expected", "abc2017-02-28T17:15:30.223344321klmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "2017-02-28T17:15:30.223344321", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "2017-02-28T17:15:30.223344321", new String(buffer.array()));
    }

    @Test
    public void encodeDelimitersAndFractionSymbol() {
        //given
        final LocalDateTimeEncoder encoder = LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder string = new StringBuilder("abcdefghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz");
        final int offset = 3;
        final byte[] bytes = new byte[encoder.getLength()];
        final ByteBuffer buffer = ByteBuffer.allocate(encoder.getLength());

        //when
        encoder.encodeDateTimeSeparator(string, ByteWriter.STRING_BUILDER, offset);
        encoder.encodeDateTimeSeparator(bytes, ByteWriter.BYTE_ARRAY);
        encoder.encodeDateTimeSeparator(buffer, ByteWriter.BYTE_BUFFER);

        //then
        Assert.assertEquals("encoded string not as expected", "abcdefghklmnoTkrstuvwxyzabcdefghklmnopkrstuvwxyz", string.toString());
        Assert.assertEquals("encoded bytes not as expected", "\0\0\0\0\0\0\0\0\0\0T\0\0\0\0\0\0\0\0", new String(bytes));
        Assert.assertEquals("encoded buffer not as expected", "\0\0\0\0\0\0\0\0\0\0T\0\0\0\0\0\0\0\0", new String(buffer.array()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void delimiterInvalid() {
        //when
        LocalDateTimeEncoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM, '\uf111');

        //then: expect exception
    }

}