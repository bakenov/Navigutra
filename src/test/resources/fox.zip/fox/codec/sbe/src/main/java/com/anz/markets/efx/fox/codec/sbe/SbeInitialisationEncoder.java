package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.InitialisationEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public final class SbeInitialisationEncoder implements InitialisationEncoder, InitialisationEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.InitialisationEncoder initialisationEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.InitialisationEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();

    private EncodingOrder.Initialisation encodingOrder = EncodingOrder.Initialisation.INITIAL;

    SbeInitialisationEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                             final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.InitialisationEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.InitialisationEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.InitialisationEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.InitialisationEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        initialisationEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.Initialisation.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        initialisationEncoder.buffer().setMemory(offset, initialisationEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public Trailer initStage(final InitStage initStage) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.Initialisation.TRAILER);
        initialisationEncoder.initStage(Enums.initStage(initStage));
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.Initialisation.TRAILER);
                message.messageLength(headerLength + initialisationEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.Initialisation.INITIAL;
                headerEncoder.wrap(null, 0);
                initialisationEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
