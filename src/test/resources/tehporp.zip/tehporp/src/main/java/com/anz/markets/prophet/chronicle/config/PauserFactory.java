package com.anz.markets.prophet.chronicle.config;


import net.openhft.chronicle.threads.BusyPauser;
import net.openhft.chronicle.threads.LightPauser;
import net.openhft.chronicle.threads.Pauser;

public enum PauserFactory {
    INSTANCE;

    public static Pauser create() {
        final long busyPeriodNS = 0;
        final long parkPeriodNS = 10_000; // LightPauser requires minimum 10k parkPeriod to actually pause
        return new LightPauser(busyPeriodNS, parkPeriodNS);
    }

    public static Pauser none() {
        return Pauser.busy();
    }
}
