package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings("CPD-START")
public class InstrumentConfigImpl implements InstrumentConfig, ProphetMarshallable {
    private Instrument instrument;
    private boolean emergingMarket;
    private double spreadMultiplier;
    private double spotDecimalPlaces;
    private double spotFractionalPip;
    private double fwdPtsDecimalPlaces;
    private double fwdPtsFractionalPip;
    private double allInDecimalPlaces;
    private double allInFractionalPip;
    private double precisionMultiplier;
    private boolean autoPriced;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public InstrumentConfigImpl() {
    }

    public InstrumentConfigImpl(final Instrument instrument) {
        this.instrument = instrument;
    }

    public double getSpreadMultiplier() {
        return spreadMultiplier;
    }

    @Override
    public boolean isEmergingMarket() {
        return emergingMarket;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }


    public InstrumentConfigImpl setEmergingMarket(final boolean emergingMarket) {
        this.emergingMarket = emergingMarket;
        return this;
    }

    public InstrumentConfigImpl setSpreadMultiplier(final double spreadMultiplier) {
        this.spreadMultiplier = spreadMultiplier;
        return this;
    }

    @Override
    public double getSpotDecimalPlaces() {
        return spotDecimalPlaces;
    }

    public InstrumentConfigImpl setSpotDecimalPlaces(final double spotDecimalPlaces) {
        this.spotDecimalPlaces = spotDecimalPlaces;
        return this;
    }

    @Override
    public double getSpotFractionalPip() {
        return spotFractionalPip;
    }

    public InstrumentConfigImpl setSpotFractionalPip(final double spotFractionalPip) {
        this.spotFractionalPip = spotFractionalPip;
        return this;
    }

    @Override
    public double getFwdPtsDecimalPlaces() {
        return fwdPtsDecimalPlaces;
    }

    public InstrumentConfigImpl setFwdPtsDecimalPlaces(final double fwdPtsDecimalPlaces) {
        this.fwdPtsDecimalPlaces = fwdPtsDecimalPlaces;
        return this;
    }

    @Override
    public double getFwdPtsFractionalPip() {
        return fwdPtsFractionalPip;
    }

    public InstrumentConfigImpl setFwdPtsFractionalPip(final double fwdPtsFractionalPip) {
        this.fwdPtsFractionalPip = fwdPtsFractionalPip;
        return this;
    }

    @Override
    public double getAllInDecimalPlaces() {
        return allInDecimalPlaces;
    }

    public InstrumentConfigImpl setAllInDecimalPlaces(final double allInDecimalPlaces) {
        this.allInDecimalPlaces = allInDecimalPlaces;
        return this;
    }

    @Override
    public double getAllInFractionalPip() {
        return allInFractionalPip;
    }

    public InstrumentConfigImpl setAllInFractionalPip(final double allInFractionalPip) {
        this.allInFractionalPip = allInFractionalPip;
        return this;
    }

    @Override
    public double getPrecisionMultiplier() {
        return precisionMultiplier;
    }

    @Override
    public double getSpotDecimalPlacesActual() {
        return spotDecimalPlaces + spotFractionalPip;
    }

    public InstrumentConfigImpl setPrecisionMultiplier(final double precisionMultiplier) {
        this.precisionMultiplier = precisionMultiplier;
        return this;
    }

    @Override
    public boolean isAutoPriced() {
        return autoPriced;
    }

    public InstrumentConfigImpl setAutoPriced(final boolean autoPriced) {
        this.autoPriced = autoPriced;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        // old style FieldReflectionBytesMarshallable.
        Context.context().header().before(MessageVersion.VERSION_0_88, () -> {
            instrument = in.readEnum(Instrument.class);
            emergingMarket = in.readBoolean();
            spreadMultiplier = in.readDouble();
            spotDecimalPlaces = in.readDouble();
            spotFractionalPip = in.readDouble();
            fwdPtsDecimalPlaces = in.readDouble();
            fwdPtsFractionalPip = in.readDouble();
            allInDecimalPlaces = in.readDouble();
            allInFractionalPip = in.readDouble();
            precisionMultiplier = in.readDouble();
        });

        Context.context().header().since(MessageVersion.VERSION_0_88, () -> {
            instrument = Instrument.readMarshallableValueOf(in);
            emergingMarket = in.readBoolean();
            spreadMultiplier = in.readDouble();
            spotDecimalPlaces = in.readDouble();
            spotFractionalPip = in.readDouble();
            fwdPtsDecimalPlaces = in.readDouble();
            fwdPtsFractionalPip = in.readDouble();
            allInDecimalPlaces = in.readDouble();
            allInFractionalPip = in.readDouble();
            precisionMultiplier = in.readDouble();
            autoPriced = in.readBoolean();
        });
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeShort(instrument.getValue());
        out.writeBoolean(emergingMarket);
        out.writeDouble(spreadMultiplier);
        out.writeDouble(spotDecimalPlaces);
        out.writeDouble(spotFractionalPip);
        out.writeDouble(fwdPtsDecimalPlaces);
        out.writeDouble(fwdPtsFractionalPip);
        out.writeDouble(allInDecimalPlaces);
        out.writeDouble(allInFractionalPip);
        out.writeDouble(precisionMultiplier);
        out.writeBoolean(autoPriced);
    }

    @Override
    public String toString() {
        return "InstrumentConfigImpl{" +
                "instrument=" + instrument +
                ", emergingMarket=" + emergingMarket +
                ", spreadMultiplier=" + spreadMultiplier +
                ", spotDecimalPlaces=" + spotDecimalPlaces +
                ", spotFractionalPip=" + spotFractionalPip +
                ", fwdPtsDecimalPlaces=" + fwdPtsDecimalPlaces +
                ", fwdPtsFractionalPip=" + fwdPtsFractionalPip +
                ", allInDecimalPlaces=" + allInDecimalPlaces +
                ", allInFractionalPip=" + allInFractionalPip +
                ", precisionMultiplier=" + precisionMultiplier +
                ", autoPriced=" + autoPriced +
                '}';
    }

}
