package com.anz.axle.lg.adapter.bgc.chroniclefix;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import software.chronicle.fix.codegen.CodeGenerator;
import software.chronicle.fix.codegen.FixType;

public class BgcChronicleFixCodeGenerator {

    public static void main(final String[] args) throws IOException {
        final long startTime = System.currentTimeMillis();
        final CodeGenerator cg = new CodeGenerator();
        cg.codePackage("com.anz.axle.lg.adapter.bgc.chroniclefix.generated");
        cg.schemaFile("lg-adapter-bgc-chronicle", "src/main/resources/conf/FIX44-bgc.xml");
        cg.codeDirectory("lg-adapter-bgc-chronicle", "target/generated-sources");
        cg.clean(true);

        // Retain decimal precision when reading floating point.
        cg.includeDecimalPrecision(false);

        // internal representation for datetimes
        cg.internalTimeUnit(TimeUnit.NANOSECONDS);

        // TODO: Double unset value 0 not NaN

        // this will cause the MDEntryID field to be bytes ( which has lower latency ) rather than a String
        // TODO: use AsciiString not Bytes
        cg.classOverride(f -> f.name().equals("MDEntryID") || f.name().equals("MDReqID") || f.name().equals("ClOrdID") || f.name().equals("OrigClOrdID") || f.name().equals("OrderID") ? FixType.BYTES : null);
        cg.run();
        System.out.println("BgcChronicleFixCodeGenerator completed in " + (System.currentTimeMillis() - startTime) + " ms");
    }
}