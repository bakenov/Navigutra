package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.Objects;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import software.chronicle.itchcboe.messages.server.Sequenced;

public class SequenceTimestampParser {

    private final PrecisionClock precisionClock;

    private final long MILLIS_IN_SEC = 1000;
    private final long MILLIS_IN_MIN = 60 * MILLIS_IN_SEC;
    private final long MILLIS_IN_HOUR = 60 * MILLIS_IN_MIN;
    private final long MILLIS_IN_DAY = 24 * MILLIS_IN_HOUR;
    private static final long NYC_OFFSET_MILLLIS = TimeZone.getTimeZone("America/New_York").getOffset(NanoClock.nanoClockUTC().millis());

    public SequenceTimestampParser(final PrecisionClock precisionClock) {
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    public long sendingTimeNanosOrNow(final Sequenced sequenced) {
        return (sequenced != null) ? sendingTimeNanos(sequenced.time()) : precisionClock.nanos();
    }

    public long sendingTimeNanos(final long hhMMSSmmm) {
        return sendingTimeNanos(hhMMSSmmm, precisionClock.millis());
    }

    public long sendingTimeNanos(final long hhMMSSmmm, final long currentTimeMillis) {
        final long currentTimeMillisNY = currentTimeMillis + NYC_OFFSET_MILLLIS;
        final long startOfDayNY = currentTimeMillisNY - (currentTimeMillisNY % MILLIS_IN_DAY);
        final long sendingTimeMillisNY = startOfDayNY + toMillis(hhMMSSmmm);
        final long sendingTimeMillisUTC = sendingTimeMillisNY + (-1 * NYC_OFFSET_MILLLIS);

        return TimeUnit.MILLISECONDS.toNanos(sendingTimeMillisUTC);
    }

    public long toMillis(final long hhMMSSmmm) {
        final long hh = (hhMMSSmmm/1000000_0);
        final long mm = (hhMMSSmmm/100000) - (hh*100);
        final long ss = (hhMMSSmmm/1000) - ((hh*10000) + (mm*100)) ;
        final long mmm = (hhMMSSmmm - ((hh*10000000) + (mm*100000) + (ss*1000)));
        return (hh * MILLIS_IN_HOUR) + (mm * MILLIS_IN_MIN) + (ss * MILLIS_IN_SEC) + mmm;
    }
}
