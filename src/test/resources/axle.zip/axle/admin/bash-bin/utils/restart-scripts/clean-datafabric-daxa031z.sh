#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh daxa031z "rm -rf ~/axle/datafabric/workspace/*"
