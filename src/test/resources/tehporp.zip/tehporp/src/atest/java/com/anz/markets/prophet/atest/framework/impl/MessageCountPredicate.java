package com.anz.markets.prophet.atest.framework.impl;

import java.util.List;
import java.util.function.Predicate;

public interface MessageCountPredicate extends Predicate<List> {
    AtLeastMessageCountPredicate AT_LEAST_ONE = new AtLeastMessageCountPredicate(1);
    ExactMessageCountPredicate EXACTLY_ONE = new ExactMessageCountPredicate(1);
    ExactMessageCountPredicate EXACTLY_TWO = new ExactMessageCountPredicate(2);
}
