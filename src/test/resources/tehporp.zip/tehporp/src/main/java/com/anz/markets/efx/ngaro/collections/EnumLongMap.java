package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.Arrays;
import java.util.function.Consumer;
import java.util.function.ObjLongConsumer;


public class EnumLongMap<K extends Enum<K>> {

    public final static long EMPTY = Long.MAX_VALUE;
    private final K[] keyUniverse;
    private final long[] entries;
    private int size;
    private final int capacity;
    private Class<K> keyType;

    public EnumLongMap(final Class<K> keyType) {
        this.keyType = keyType;
        this.keyUniverse = keyType.getEnumConstants();
        this.capacity = keyUniverse.length;
        this.entries = new long[capacity];
        for (int i = 0; i < capacity; i++) {
            this.entries[i] = EMPTY;
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public static boolean isEmpty(long value) {
        return value == EMPTY;
    }

    public boolean containsKey(K key) {
        return !isEmpty(entries[key.ordinal()]);
    }

    public boolean containsKey(final Object key) {
        return containsKey((K) key);
    }

    public boolean containsValue(final Object value) {
        GcFriendlyAssert.notNull(value);
        for (int i = 0; i < capacity; i++) {
            if (value.equals(this.entries[i])) {
                return true;
            }
        }
        return false;
    }

    public long get(final Object key) {
        return entries[((K) key).ordinal()];
    }

    public long getOrDefault(final K key, long defaultValue) {
        final long value = entries[key.ordinal()];
        return isEmpty(value) ? defaultValue : value;
    }

    public long put(K key, long value) {
        final long prevValue = entries[key.ordinal()];
        if (isEmpty(value)) {
            remove(key);
        } else {
            if (!containsKey(key)) {
                size++;
            }
            entries[key.ordinal()] = value;
        }
        return prevValue;
    }

    public boolean remove(final Object key) {
        if (containsKey(key)) {
            entries[((K) key).ordinal()] = EMPTY;
            size--;
            return true;
        }
        return false;
    }

    public void clear() {
        for (int i = 0; i < capacity; i++) {
            entries[i] = EMPTY;
        }
        size = 0;
    }

    public final void keys(Consumer<K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (!isEmpty(entries[i])) {
                    action.accept(this.keyUniverse[i]);
                }
            }
        }
    }

    public void forEach(ObjLongConsumer<? super K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (!isEmpty(entries[i])) {
                    action.accept(this.keyUniverse[i], entries[i]);
                }
            }
        }
    }

    public void forEachAndRemove(ObjLongConsumer<? super K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (!isEmpty(entries[i])) {
                    action.accept(this.keyUniverse[i], entries[i]);
                    entries[i] = EMPTY;
                }
            }
        }
    }

    public boolean removeIf(final ObjLongPredicate<K> filter) {
        GcFriendlyAssert.notNull(filter);
        boolean rv = false;
        for (int i = 0; i < capacity; i++) {
            if (!isEmpty(entries[i])) {
                if (filter.test(this.keyUniverse[i], entries[i])) {
                    remove(this.keyUniverse[i]);
                    rv = true;
                }
            }
        }
        return rv;
    }

    public Class<K> getKeyType() {
        return keyType;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        final EnumLongMap<?> that = (EnumLongMap<?>) o;
        return size == that.size && Arrays.equals(this.entries, ((EnumLongMap<?>) o).entries);
    }

    // TODO: hashCode. Not urgent as these are not (currently) put into HashMaps etc.
}
