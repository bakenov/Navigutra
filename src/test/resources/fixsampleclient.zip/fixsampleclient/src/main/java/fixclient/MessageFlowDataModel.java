// |---------------------------------------------------------------
// | Copyright (C) 2007-2011 Thomson Reuters, --
// | Thomson Reuters Building, South Colonnade, London E145EP --
// | All rights reserved. Duplication or distribution prohibited --
// |---------------------------------------------------------------
package fixclient;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 * Data model for JTables displaying FIX messages. Fields 35, 34, 11, and 39 are
 * broken out as separate columns
 */
public class MessageFlowDataModel extends DefaultTableModel
{
    private static final long  serialVersionUID = 1L;
    private final List<Object> tableData        = new ArrayList<Object>();
    private final List<String> columnNames      = new ArrayList<String>();

    /**
     * Initializes the FIX data field columns
     */
    public MessageFlowDataModel()
    {
        super();
        this.columnNames.add("35-MsgType");
        this.columnNames.add("34-MsgSeqNum");
        this.columnNames.add("11-ClOrdID");
        this.columnNames.add("39-OrdStatus");
        this.columnNames.add("Message");
    }

    /**
     * @see javax.swing.table.AbstractTableModel#getColumnClass(int)
     */
    @Override
    public Class<?> getColumnClass(final int columnIndex)
    {
        return String.class;
    }

    /**
     * @see javax.swing.table.DefaultTableModel#getColumnCount()
     */
    @Override
    public int getColumnCount()
    {
        return this.columnNames.size();
    }

    /**
     * @see javax.swing.table.DefaultTableModel#getColumnName(int)
     */
    @Override
    public String getColumnName(final int columnIndex)
    {
        return this.columnNames.get(columnIndex);
    }

    /**
     * @see javax.swing.table.DefaultTableModel#getValueAt(int, int)
     */
    @Override
    public Object getValueAt(final int rowIndex, final int columnIndex)
    {
        final int reverseRow = getRowCount() - rowIndex - 1;
        return super.getValueAt(reverseRow, columnIndex);
    }

    /**
     * @see javax.swing.table.DefaultTableModel#isCellEditable(int, int)
     */
    @Override
    public boolean isCellEditable(final int rowIndex, final int columnIndex)
    {
        return false;
    }

    /**
     * 
     */
    public void clear()
    {
        this.tableData.clear();
    }

}
