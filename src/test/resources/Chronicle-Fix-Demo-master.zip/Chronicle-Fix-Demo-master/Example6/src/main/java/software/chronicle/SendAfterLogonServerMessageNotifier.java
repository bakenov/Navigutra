package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.Wires;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Logout;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

/**
 * @author Rob Austin.
 */
public class SendAfterLogonServerMessageNotifier implements MessageNotifier, Marshallable {
    private transient final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private transient boolean sessionAlive;

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        LOG.info(reject.toString());
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        this.sessionAlive = true;
        LOG.info("onLogon: " + logon.senderCompID() + " sending NOS");
        final NewOrderSingle serverExpects = NewOrderSingle.newNewOrderSingle(Wires.acquireBytes(), session.context());
        serverExpects.ordType('2');
        serverExpects.side('1');
        serverExpects.symbol(Bytes.from("LCOM1"));
        serverExpects.clOrdID(Bytes.allocateDirect("CL_ORD_ID".getBytes()));
        serverExpects.handlInst('3');
        serverExpects.transactTime(1451902315496L);
        serverExpects.orderQty(1);
        serverExpects.price(200.0);
        serverExpects.timeInForce('0');
        serverExpects.maturityMonthYear("201106");
        serverExpects.securityType("FUT");
        serverExpects.idSource("5");
        serverExpects.securityID(Bytes.from("LCOM1"));
        serverExpects.account(Bytes.from("ABCTEST1"));
        session.sendMessage(serverExpects);
    }

    @Override
    public void onLogout(FixSessionHandler session, Logout logout) {
        LOG.info(logout.toString());
    }

    @Override
    public void onEndOfConnection(SessionID sessionID) {
        this.sessionAlive = false;
        LOG.info("onEndOfConnection");
    }

    public boolean sessionAlive() {
        return sessionAlive;
    }
}
