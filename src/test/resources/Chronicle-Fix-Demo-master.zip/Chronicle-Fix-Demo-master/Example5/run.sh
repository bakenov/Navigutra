#!/bin/bash

#As single process
#mvn exec:java -Dexec.mainClass="software.chronicle.fix.AcceptorSupportingMultipleClientsTest"

#As 2 processes
#mvn exec:java -Dexec.mainClass="software.chronicle.fix.AcceptorMain"
#mvn exec:java -Dexec.mainClass="software.chronicle.fix.ConnectorMain"

title="Available tests"
prompt="Select test:"
options=("Run as single process" "Run as separate processes")

PS3=$'\n'"$prompt "
COLUMNS=24

while true; do
    printf "\n$title\n"
    select opt in "${options[@]}" "Quit"; do

        case "$REPLY" in

        1 ) MAVEN_OPTS=-ea mvn exec:java -Dexec.mainClass="software.chronicle.fix.AcceptorSupportingMultipleClientsTest"
            break;;

        2 ) echo "Starting acceptor. Logging to acceptor.log"
            MAVEN_OPTS=-ea mvn exec:java -Dexec.mainClass="software.chronicle.fix.AcceptorMain" > acceptor.log 2>&1 &
            ACCEPTOR=$!

            echo "Starting connector. Logging to connector.log"
            MAVEN_OPTS=-ea mvn exec:java -Dexec.mainClass="software.chronicle.fix.ConnectorMain" > connector.log 2>&1 &
            CONNECTOR=$!

            echo "Waiting for connector to complete..."
            wait $CONNECTOR

            echo "Closing acceptor..."
            kill $ACCEPTOR

            echo "Waiting for acceptor to stop..."
            wait $ACCEPTOR

            echo "Done"
            break;;

        $(( ${#options[@]}+1 )) ) echo "Quit"; exit;;
        *) echo "Invalid option";continue;;

        esac

    done
done

