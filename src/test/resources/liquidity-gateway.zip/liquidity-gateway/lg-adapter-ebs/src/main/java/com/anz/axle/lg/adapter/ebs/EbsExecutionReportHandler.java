package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.Parties_PartyIDsGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import net.openhft.chronicle.bytes.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.function.LongSupplier;

import static com.anz.axle.lg.adapter.chroniclefix.ChronicleFixUtils.zeroIfUnSet;
import static com.anz.axle.lg.adapter.fix.Converter.nanToZero;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.FOK;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.GTC;
import static com.anz.markets.efx.trading.codec.api.TimeInForce.IOC;
import static com.anz.markets.efx.trading.codec.api.TradingConstants.VAR_STRING_MAX_LENGTH;

public final class EbsExecutionReportHandler implements ChronicleMessageHandler<ExecutionReport> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsExecutionReportHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();
    private static final Bytes EMPTY_BUFFER = Bytes.allocateElasticDirect();
    private final TradingEncoderSupplier tradingResponseEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;
    private final TenorLookup tenorLookup;
    private final Venue venue;
    private final SourceSequencer sourceSequencer;

    private final CachedFunction<String, String> symbol6Lookup = CachedFunction.of(SymbolNormaliser::toSymbol6);
    private final FixedLengthAsciiString fixedLengthRejectText = new FixedLengthAsciiString(VAR_STRING_MAX_LENGTH);

    public EbsExecutionReportHandler(final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                     final PrecisionClock precisionClock,
                                     final String senderCompId,
                                     final String compId,
                                     final LongSupplier messageIdGenerator,
                                     final TenorLookup tenorLookup,
                                     final Venue venue,
                                     final SourceSequencer sourceSequencer) {
        this.tradingResponseEncoderSupplier = Objects.requireNonNull(tradingResponseEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
        this.venue = Objects.requireNonNull(venue);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final ExecutionReport message) throws IllegalArgumentException {
        accept(message, Long.MIN_VALUE);
    }

    @Override
    public void accept(final ExecutionReport message, final long receivedByAdapterTimestampNanos) throws IllegalArgumentException {

        final long receivingTimeNanos = receivedByAdapterTimestampNanos <= 0 ? precisionClock.nanos() : receivedByAdapterTimestampNanos;
        LOGGER.debug("ExecutionReport received: {}", message);
        final long sequenceNumber = message.msgSeqNum();
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = zeroIfUnSet(message.sendingTime());
        final OrderStatus orderStatus = orderStatus(message.ordStatus());
        final OrderType orderType = orderType(message.ordType());

        final Bytes clOrdID = message.clOrdID().isEqual("[N/A]") ? message.origClOrdID() : message.clOrdID();
        final Bytes origClOrdID = message.origClOrdID() != null ? message.origClOrdID() : clOrdID;
        final Bytes orderID = message.orderID().isEqual("[N/A]") ? EMPTY_BUFFER : message.orderID();

        final ExecutionReportEncoder.Body bodyEncoder = tradingResponseEncoderSupplier.executionReport()
                .messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .orderId().encode(orderID)
                .clOrdId().encode(clOrdID)
                .origClOrdId().encode(origClOrdID)
                .clOrdLinkId().encodeEmpty()
                .marketId().encode(venue.name())
                .execId().encodeNullable(message.execID())
                .execType(execType(message.execType()))
                .settlDate().encodeFormatted(message.settlDate(), DATE_DECODER)
                .ordStatus(orderStatus)
                .symbol().encode(symbol6Lookup.apply((message.symbol())))
                .securityType(FixCFICode.from(message.cFICode()))
                .settlType(tenorLookup.anzTenor(message.settlType()))
                .orderQty(nanToZero(message.orderQty()))
                .ordType(orderType)
                .targetStrategyName().encodeEmpty()
                .price(nanToZero(message.price() == null ? 0.0 : message.price().parseDouble()))
                .side(side(message.side()))
                .currency().encodeNullable(message.currency())
                .timeInForce(timeInForce(message.timeInForce()))
                .lastPx(nanToZero(message.lastPx()))
                .lastQty(nanToZero(message.lastQty()))
                .leavesQty(orderStatus == OrderStatus.REJECTED ? 0.0 : leavesQty(message))
                .cumQty(nanToZero(message.cumQty()))
                .avgPx(nanToZero(message.avgPx()))
                .tradeDate().encodeFormatted(message.tradeDate(), DATE_DECODER)
                .settlCurrency().encodeNullable(message.settlCurrency())
                .transactTime(zeroIfUnSet(message.transactTime()))
                .expireTime(zeroIfUnSet(message.expireTime()));

        addParties(bodyEncoder, contraBroker(message))
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsStart(2)
                .next()
                .hopCompId().encode(senderCompId)
                .hopMessageId(sequenceNumber)
                .hopReceivingTime(0)
                .hopSendingTime(sendingTimeNanos)
                .next()
                .hopCompId().encode(compId)
                .hopMessageId(messageId)
                .hopReceivingTime(receivingTimeNanos)
                .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
                .quoteId().encodeEmpty()
                .rejectText().encode(fixedLengthRejectText.set(message.text()))
                .messageComplete();
    }

    private ExecutionReportEncoder.StrategyParameters addParties(final ExecutionReportEncoder.Body bodyEncoder, final String contraBroker) {

        if (contraBroker != null) {
            return bodyEncoder.partiesStart(1)
                    .next()
                    .partyRole(PartyRole.CONTRA_FIRM)
                    .partyId().encodeNullable(contraBroker)
                    .partiesComplete();
        } else {
            return bodyEncoder.partiesEmpty();
        }
    }

    private String contraBroker(final ExecutionReport message) {
        for (int i = 0; i < message.noPartyIDs(); i++) {
            final Parties_PartyIDsGrp_1 partyIDsGrp = message.parties_PartyIDsGrp_1(i);
            if (partyIDsGrp.partyRole() == com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.PartyRole.CONTRA_FIRM) {
                return partyIDsGrp.partyID();
            }
        }
        return null;
    }

    private ExecType execType(final char execType) {
        switch (execType) {
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.NEW: return ExecType.NEW;

            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.CANCELED:
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.TRIGGERED_OR_ACTIVATED_BY_SYSTEM: return ExecType.TRIGGERED_OR_ACTIVATED_BY_SYSTEM;

            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.REPLACE: return ExecType.REPLACED;
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.REJECTED: return ExecType.REJECTED;
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.ExecType.TRADE: return ExecType.TRADE;
            default: throw new IllegalArgumentException("Unsupported execType " + execType);
        }
    }

    private TimeInForce timeInForce(final char timeInForce) {
        switch (timeInForce) {
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce.GOOD_TILL_CANCEL: return GTC;
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce.IMMEDIATE_OR_CANCEL: return IOC;
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.TimeInForce.FILL_OR_KILL: return FOK;

            default: return null;
        }
    }

    private OrderType orderType(final char ordType) throws IllegalArgumentException {
        switch (ordType) {
            case OrdType.FIXING_ORDER : return OrderType.FIXING_ORDER;
            case OrdType.LIMIT : return OrderType.LIMIT;
            default:
                throw new IllegalArgumentException("Unsupported ordType " + ordType);
        }
    }

    private Side side(final char side) throws IllegalArgumentException {
        switch (side) {
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.BUY : return Side.BUY;
            case com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.Side.SELL : return Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side " + side);
        }
    }

    private OrderStatus orderStatus(final char ordStatus) throws IllegalArgumentException {
        switch (ordStatus) {
            case OrdStatus.NEW: return OrderStatus.NEW;
            case OrdStatus.FILLED: return OrderStatus.FILLED;
            case OrdStatus.PARTIALLY_FILLED: return OrderStatus.PARTIALLY_FILLED;
            case OrdStatus.CANCELED: return OrderStatus.CANCELED;
            case OrdStatus.REJECTED : return OrderStatus.REJECTED;
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private double leavesQty(final ExecutionReport message) {
        final double leavesQty = nanToZero(message.leavesQty());
        final OrderStatus orderStatus = orderStatus(message.ordStatus());
        return (orderStatus == OrderStatus.CANCELED || orderStatus == OrderStatus.REJECTED) ? 0.0 : leavesQty;
    }
}
