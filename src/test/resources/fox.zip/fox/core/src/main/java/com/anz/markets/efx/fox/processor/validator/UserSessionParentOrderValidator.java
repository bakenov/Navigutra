package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.fox.processor.state.usersession.UserSessionKeyFactory;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import java.util.Objects;

public class UserSessionParentOrderValidator implements ParentOrderValidator {
    private final ByteValueCache<UserSessionKey> userSessionKeyCache = new ByteValueCache<>(new UserSessionKeyFactory());
    private final ErrorHandler errorHandler;

    public UserSessionParentOrderValidator(final ErrorHandler handler) {
        this.errorHandler = Objects.requireNonNull(handler);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
        final UserSessionKey userSessionKey = parentOrderDecoder.body().senderCompId().decodeAndCache(userSessionKeyCache);
        if (userSessionKey != UserSessionKey.UNKNOWN) {
            return true;
        }

        errorHandler.onError(OrderTextMessage.INVALID_SENDERCOMPID.getText(), parentOrderDecoder, commandContext);
        return false;
    }
}
