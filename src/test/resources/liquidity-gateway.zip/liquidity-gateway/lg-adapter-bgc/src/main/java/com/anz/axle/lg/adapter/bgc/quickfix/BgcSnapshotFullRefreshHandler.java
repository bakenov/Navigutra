package com.anz.axle.lg.adapter.bgc.quickfix;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Message;
import quickfix.field.BidPx;
import quickfix.field.BidSize;
import quickfix.field.MsgType;
import quickfix.field.OfferPx;
import quickfix.field.OfferSize;
import quickfix.field.QuoteID;
import quickfix.field.SecurityType;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix44.Quote;

import com.anz.axle.lg.adapter.PriceRounder;
import com.anz.axle.lg.util.CurrentMillisIdFactory;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;

public class BgcSnapshotFullRefreshHandler implements SnapshotFullRefreshHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcSnapshotFullRefreshHandler.class);
    private static final boolean INCLUDE_MILLISECONDS = true;
    private final Consumer<Message> fixMessageSender;
    private final PriceRounder priceRounder;
    private final Quote quote = new Quote();
    private final Date transactTime = new Date();
    private final Map<String, String> symbol7Map = new HashMap<>();
    private final LongIdFactory idGenerator = new CurrentMillisIdFactory();
    private final InstrumentKey.Lookup instrumentKeyLookup;
    private InstrumentKey instrumentKey;

    public BgcSnapshotFullRefreshHandler(final Consumer<Message> fixMessageSender,
                                         final PriceRounder priceRounder,
                                         final InstrumentKey.Lookup instrumentKeyLookup) {
        this.fixMessageSender = Objects.requireNonNull(fixMessageSender);
        this.priceRounder = Objects.requireNonNull(priceRounder);
        this.instrumentKeyLookup = Objects.requireNonNull(instrumentKeyLookup);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        quote.clear();
        instrumentKey = null;
    }

    @Override
    public void onBody(final Body body) {
        LOGGER.debug("Body Received: instrument={}", body.instrumentId());
        quote.getHeader().setString(MsgType.FIELD, MsgType.QUOTE);
        quote.setString(QuoteID.FIELD, Long.toString(idGenerator.get()));

        instrumentKey = instrumentKeyLookup.lookup(body.instrumentId());
        quote.setString(Symbol.FIELD, symbol7(instrumentKey.symbol()));
        quote.setString(SecurityType.FIELD, instrumentKey.securityType().name());
        quote.setUtcTimeStamp(TransactTime.FIELD, transactTime(body.sendingTime()), INCLUDE_MILLISECONDS);
    }

    @Override
    public void onMdEntries_Body(final MdEntries.Body entry, final int entryIndex, final int maxEntryCount) {
        LOGGER.debug("onMdEntries_Body Received: price={}, type={}, size={}, entryIndex={}, maxEntryCount={}", entry.mdEntryPx(), entry.mdEntryType(), entry.mdEntrySize(), entryIndex, maxEntryCount);

        final double price = priceRounder.round(instrumentKey.symbol(), entry.mdEntryType(), entry.mdEntryPx());

        quote.setDouble(EntryType.BID.equals(entry.mdEntryType()) ? BidPx.FIELD : OfferPx.FIELD, price);
        quote.setDouble(EntryType.BID.equals(entry.mdEntryType()) ? BidSize.FIELD : OfferSize.FIELD, entry.mdEntrySize());
    }

    @Override
    public void onMdEntriesComplete(final int entryCount) {
        if (entryCount == 0) {
            LOGGER.debug("onMdEntriesComplete entryCount=0. set zero prices");
            quote.setDouble(BidPx.FIELD, 0.0);
            quote.setDouble(BidSize.FIELD, 0.0);
            quote.setDouble(OfferPx.FIELD, 0.0);
            quote.setDouble(OfferSize.FIELD, 0.0);
        }
    }

    @Override
    public void onMessageComplete() {
        LOGGER.debug("Sending: Quote={}", quote);
        fixMessageSender.accept(quote);
    }

    private String symbol7(final String symbol) {
        return symbol7Map.computeIfAbsent(symbol, SymbolNormaliser::toSymbol7);
    }

    private Date transactTime(long transactTimeNanos) {
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(transactTimeNanos));
        return transactTime;
    }
}
