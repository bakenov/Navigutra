package com.anz.axle.lg.adapter.d3.model;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


import com.anz.markets.efx.pricing.codec.api.Flag;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class D3CodecTest {
    @Rule
    public final ExpectedException thrown = ExpectedException.none();

    private Map<String, String> updateMessage;

    @Before
    public void setup() {
        updateMessage = new HashMap<>();
    }

    @Test
    public void test_formatDate() {
        assertThat(
                D3Codec.formatDate(LocalDate.of(1999, 12, 28)),
                equalTo("19991228")
        );
    }

    @Test
    public void test_asLocalDate() {
        updateMessage.put("FIELD1", "19991228");

        assertThat(
                D3Codec.asLocalDate("FIELD1", updateMessage::get).get(),
                equalTo(LocalDate.of(1999, 12, 28))
        );
    }

    @Test
    public void asLocalDate_returns_empty_optional_when_given_empty_value() {
        updateMessage.put("FIELD1", "");
        assertFalse(D3Codec.asLocalDate("FIELD1", updateMessage::get).isPresent());
    }

    @Test
    public void asLocalDate_throws_exception_when_given_invalid_value() {
        thrown.expect(StringIndexOutOfBoundsException.class);
        updateMessage.put("FIELD1", "abcdef");

        D3Codec.asLocalDate("FIELD1", updateMessage::get);
    }

    @Test
    public void asDouble_returns_empty_optional_when_given_empty_value() {
        updateMessage.put("FIELD1", "");
        assertThat(D3Codec.asDouble("FIELD1", updateMessage::get), equalTo(Double.NaN));
    }

    @Test
    public void asDouble_throws_exception_when_given_invalid_value() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage(equalTo("Field [FIELD1] does not contain valid double [abcdef]."));
        updateMessage.put("FIELD1", "abcdef");

        D3Codec.asDouble("FIELD1", updateMessage::get);
    }

    @Test
    public void test_asDouble_for_valid_value() {
        updateMessage.put("FIELD1", "123.49");
        assertThat(D3Codec.asDouble("FIELD1", updateMessage::get), equalTo(123.49d));
    }

    @Test
    public void asBoolean_returns_false_for_empty_value() {
        updateMessage.put("FIELD1", "");
        assertFalse(D3Codec.asBoolean("FIELD1", updateMessage::get));
    }

    @Test
    public void asBoolean_returns_false_for_invalid_value() {
        updateMessage.put("FIELD1", "12345");
        assertFalse(D3Codec.asBoolean("FIELD1", updateMessage::get));
    }

    @Test
    public void test_asBoolean_for_valid_value() {
        updateMessage.put("FIELD1", "false");
        updateMessage.put("FIELD2", "FALSE");
        updateMessage.put("FIELD3", "TRUE");
        updateMessage.put("FIELD4", "true");
        assertFalse(D3Codec.asBoolean("FIELD1", updateMessage::get));
        assertFalse(D3Codec.asBoolean("FIELD2", updateMessage::get));
        assertTrue(D3Codec.asBoolean("FIELD3", updateMessage::get));
        assertTrue(D3Codec.asBoolean("FIELD4", updateMessage::get));
    }


    @Test
    public void test_translation_to_lg_marketDataFlag() {
        updateMessage.put("FIELD1", "STALE");
        updateMessage.put("FIELD2", "INDICATIVE");
        updateMessage.put("FIELD3", "ERROR");
        updateMessage.put("FIELD4", "FIRM");
        assertEquals(Flag.LATENT, D3Codec.asMarketDataFlag("FIELD1", updateMessage::get).get());
        assertEquals(Flag.INDICATIVE, D3Codec.asMarketDataFlag("FIELD2", updateMessage::get).get());
        assertEquals(Flag.SOURCE_ERROR, D3Codec.asMarketDataFlag("FIELD3", updateMessage::get).get());
        assertFalse(D3Codec.asMarketDataFlag("FIELD4", updateMessage::get).isPresent());
    }

    @Test
    public void should_fail_on_unknown_string() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("Unknown state [abcdef]");
        updateMessage.put("FIELD1", "abcdef");
        D3Codec.asMarketDataFlag("FIELD1", updateMessage::get);
    }

    @Test
    public void should_fail_on_null() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("Unknown state [null]");
        D3Codec.asMarketDataFlag("FIELD1", updateMessage::get);
    }

}
