package com.anz.markets.prophet.chronicle.config;

public enum Append {
    ALL,
    ONLY_AFTER_LAST_EVENTID;

    public boolean enabled() {
        return this == ONLY_AFTER_LAST_EVENTID;
    }
}
