package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.PriceAndQty;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

public class IsClientPricePoint extends BaseMatcher<ClientPrice> {
    private final int level;
    private final Level expectedLevelQty;
    private final double expectedBidPx;
    private final double expectedOffersPx;
    private ClientPrice actualClientPrice;
    private PriceAndQty actualBid;
    private PriceAndQty actualOffers;

    public IsClientPricePoint(final int level,
                              final Level expectedLevelQty,
                              final double expectedBidPx,
                              final double expectedOffersPx) {
        this.level = level;
        this.expectedLevelQty = expectedLevelQty;
        this.expectedBidPx = expectedBidPx;
        this.expectedOffersPx = expectedOffersPx;
    }

    @Override
    public boolean matches(final Object o) {
        actualClientPrice = (ClientPrice) o;
        if (actualClientPrice.getBids().size() <= level) {
            throw new IllegalArgumentException("Client price does not have bid at " + expectedLevelQty);
        }
        actualBid = actualClientPrice.getBids().get(level);

        if (actualClientPrice.getOffers().size() <= level) {
            throw new IllegalArgumentException("Client price does not have offers at " + expectedLevelQty);
        }
        actualOffers = actualClientPrice.getOffers().get(level);
        if (!new IsRoundedTo(expectedBidPx).matches(actualBid.getPrice())) {
            return false;
        } else {
            return new IsRoundedTo(expectedOffersPx).matches(actualOffers.getPrice());
        }
    }

    @Override
    public void describeTo(final Description description) {
        description.appendText("level: ").appendValue(level).appendText(", qty: ").appendValue(expectedLevelQty).appendText(", bid: ").appendValue(expectedBidPx).appendText(", offers: ").appendValue(expectedOffersPx);
    }

    @Override
    public void describeMismatch(final Object item,
                                 final Description description) {
        description.appendText("level: ").appendValue(level).appendText(", qty: ").appendValue(expectedLevelQty).appendText(", bid: ").appendValue(actualBid.getPrice()).appendText(", offers: ").appendValue(actualOffers.getPrice());
    }
}
