package com.anz.markets.efx.fox.firewall.rule.customer;

import com.anz.markets.efx.fox.firewall.api.Rule;

public enum CustomerRuleType {
    STALE_ORDER(Rule.Priority.HIGHEST, StaleOrderRule.class, "checks the new order for staleness");

    private final Rule.Priority priority;
    private final CharSequence description;
    private final Class<? extends Rule> klass;

    CustomerRuleType(final Rule.Priority priority,
                     final Class<? extends Rule> klass,
                     final CharSequence description) {
        this.priority = priority;
        this.description = description;
        this.klass = klass;
    }

    public Class<? extends Rule> getRuleClass() {
        return klass;
    }

    public CharSequence getDescription() {
        return description;
    }

    public Rule.Priority getPriority() {
        return priority;
    }

}
