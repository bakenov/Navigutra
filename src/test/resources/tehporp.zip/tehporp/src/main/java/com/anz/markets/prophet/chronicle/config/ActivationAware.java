package com.anz.markets.prophet.chronicle.config;

public enum ActivationAware {
    YES, NO;

    public boolean yes() {
        return this == YES;
    }
}
