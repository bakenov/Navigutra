package com.anz.axle.lg.adapter.ebsu.config;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.function.Consumer;

@Configuration
public class LastMarketTradeConfig {

    private static final String EBSU_TICKER_TOPIC_NAME = "EBSU_LAST_MARKET_TRADE";

    @Bean
    public Topic lastMarketTradeTopic() {
        return DefaultTopic.create(EBSU_TICKER_TOPIC_NAME);
    }

    @Bean
    public PricingEncoders<SbeMessage> sbeLastMarketTradePricingEncoders(@Value("${messaging.sbe.buffer.capacity:8192}") final int sbeMessageBufferCapacity) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(sbeMessageBufferCapacity);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        return new SbePricingEncoders(() -> sbeMessage);
    }

    @Bean
    public PricingEncoderSupplier lastMarketTradePricingEncoderSupplier(final PricingEncoders<SbeMessage> sbeLastMarketTradePricingEncoders,
                                                                        final MessageHandler publisher,
                                                                        final Topic lastMarketTradeTopic) {
        Objects.requireNonNull(sbeLastMarketTradePricingEncoders);
        Objects.requireNonNull(publisher);
        Objects.requireNonNull(lastMarketTradeTopic);
        final Consumer<SbeMessage> lastMarketTradeSbeMessageConsumer = sbeMessage -> {
            publisher.onMessage(lastMarketTradeTopic, sbeMessage.buffer(), 0, sbeMessage.messageLength(), 0);
        };
        return PricingEncoderSupplier.create(sbeLastMarketTradePricingEncoders, lastMarketTradeSbeMessageConsumer);
    }

}
