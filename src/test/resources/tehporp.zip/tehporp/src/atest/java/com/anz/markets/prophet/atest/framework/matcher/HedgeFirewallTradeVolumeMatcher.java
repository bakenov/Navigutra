package com.anz.markets.prophet.atest.framework.matcher;

import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HedgeFirewallTradeVolumeMatcher extends BaseMatcher<HedgeFirewallStatus> {
    private final HedgeFirewallStatus expected;

    private final double expectedCurrentVolume;
    private final double expectedChangeVolume;
    private final double expectedLimit;

    private double actualCurrentVolume;
    private double actualChangeVolume;
    private double actualLimit;

    public HedgeFirewallTradeVolumeMatcher(final HedgeFirewallStatus expected,
                                           final double expectedCurrentVolume,
                                           final double expectedChangeVolume,
                                           final double expectedLimit) {
        this.expected = expected;
        this.expectedCurrentVolume = expectedCurrentVolume;
        this.expectedChangeVolume = expectedChangeVolume;
        this.expectedLimit = expectedLimit;
    }

    @Override
    public boolean matches(final Object o) {
        final HedgeFirewallStatus actual = (HedgeFirewallStatus) o;
        parseDescription(actual.getDescription());

        return actual.getPortfolio() == expected.getPortfolio() && actual.getHedgeFirewallType() == expected.getHedgeFirewallType()
                && actual.getStatus() == expected.getStatus()
                && new IsRoundedTo(expectedCurrentVolume).matches(actualCurrentVolume)
                && new IsRoundedTo(expectedChangeVolume).matches(actualChangeVolume)
                && new IsRoundedTo(expectedLimit).matches(actualLimit);
    }

    public void parseDescription(final CharSequence description) {
        final Pattern p = Pattern.compile("(.*)/(.*)/(.*)");
        final Matcher m = p.matcher(description.toString());
        if (m.matches()) {
            actualCurrentVolume = parseNumber(m.group(1));
            actualChangeVolume = parseNumber(m.group(2));
            actualLimit = parseNumber(m.group(3));
        }
    }

    private double parseNumber(final String desc) {
        try {
            if (desc.equals(String.valueOf(Double.NaN))) {
                return Double.NaN;
            }
            NumberFormat format = NumberFormat.getInstance(Locale.ENGLISH);
            Number number = format.parse(desc);
            return number.doubleValue();
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid number: " + desc);
        }
    }

    @Override
    public void describeTo(final Description description) {
        description.appendText("portfolio: ").appendValue(expected.getPortfolio())
                .appendText(", type: ").appendValue(expected.getHedgeFirewallType())
                .appendText(", status: ").appendValue(expected.getStatus())
                .appendText(", currentVolume: ").appendValue(expectedCurrentVolume)
                .appendText(", changeVolume: ").appendValue(expectedChangeVolume)
                .appendText(", limit: ").appendValue(expectedLimit);
    }

    @Override
    public void describeMismatch(final Object item,
                                 final Description description) {
        final HedgeFirewallStatus actual = (HedgeFirewallStatus) item;

        description.appendText("portfolio: ").appendValue(actual.getPortfolio())
                .appendText(", type: ").appendValue(actual.getHedgeFirewallType())
                .appendText(", status: ").appendValue(actual.getStatus())
                .appendText(", currentVolume: ").appendValue(actualCurrentVolume)
                .appendText(", changeVolume: ").appendValue(actualChangeVolume)
                .appendText(", limit: ").appendValue(actualLimit);

    }
}
