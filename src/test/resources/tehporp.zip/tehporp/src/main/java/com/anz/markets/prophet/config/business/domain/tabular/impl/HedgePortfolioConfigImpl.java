package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgePortfolioConfig;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;

public class HedgePortfolioConfigImpl implements HedgePortfolioConfig, ProphetMarshallable {
    private Market market;
    private Portfolio portfolio;
    private String hedgerName;
    private String bookName;
    private boolean enabled;
    private long maximumOpenOrders;
    private double maximumOpenQuantity;
    private long maximumOpenVarOrders;
    private long throttleLimitNumberOrder;
    private long throttleLimitTimePeriodMS;
    private long throttleLimitRejectNumberOrder;
    private long throttleLimitRejectTimePeriodMS;
    private long orderUnknownTimeoutMS;
    private long cancelUnknownTimeoutMS;
    private long orderCompleteTimeoutMS;
    // TODO: is this necessary?
    private OrderType orderType;
    private TimeInForce orderTimeInForce;
    private long minimumTimeToLiveMS;
    private int maxNumberCancelRejects = 10;
    private int orderQuantityPrecision = 0;

    public HedgePortfolioConfigImpl() {
    }

    public HedgePortfolioConfigImpl(final Market market,
                                    final Portfolio portfolio) {
        this.market = market;
        this.portfolio = portfolio;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Portfolio getPortfolio() {
        return portfolio;
    }

    @Override
    public String getHedgerName() {
        return hedgerName;
    }

    @Override
    public String getBookName() {
        return bookName;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public long getMaximumOpenOrders() {
        return maximumOpenOrders;
    }

    @Override
    public double getMaximumOpenQuantity() {
        return maximumOpenQuantity;
    }

    @Override
    public long getMaximumOpenVarOrders() {
        return maximumOpenVarOrders;
    }

    @Override
    public long getThrottleLimitNumberOrder() {
        return throttleLimitNumberOrder;
    }

    @Override
    public long getThrottleLimitTimePeriodMS() {
        return throttleLimitTimePeriodMS;
    }

    @Override
    public long getThrottleLimitRejectNumberOrder() {
        return throttleLimitRejectNumberOrder;
    }

    @Override
    public long getThrottleLimitRejectTimePeriodMS() {
        return throttleLimitRejectTimePeriodMS;
    }

    @Override
    public long getOrderUnknownTimeoutMS() {
        return orderUnknownTimeoutMS;
    }

    @Override
    public long getCancelUnknownTimeoutMS() {
        return cancelUnknownTimeoutMS;
    }

    @Override
    public long getOrderCompleteTimeoutMS() {
        return orderCompleteTimeoutMS;
    }

    @Override
    public OrderType getOrderType() {
        return orderType;
    }

    @Override
    public TimeInForce getOrderTimeInForce() {
        return orderTimeInForce;
    }

    @Override
    public int getMaxNumberCancelRejects() {
        return maxNumberCancelRejects;
    }

    @Override
    public int getOrderQuantityPrecision() {
        return orderQuantityPrecision;
    }

    public long getMinimumTimeToLiveMS() {
        return minimumTimeToLiveMS;
    }

    public HedgePortfolioConfigImpl setHedgerName(final String hedgerName) {
        this.hedgerName = hedgerName;
        return this;
    }

    public HedgePortfolioConfigImpl setBookName(final String bookName) {
        this.bookName = bookName;
        return this;
    }

    public HedgePortfolioConfigImpl setEnabled(final boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public HedgePortfolioConfigImpl setMaximumOpenOrders(final int maximumOpenOrders) {
        this.maximumOpenOrders = maximumOpenOrders;
        return this;
    }

    public HedgePortfolioConfigImpl setMaximumOpenQuantity(final double maximumOpenQuantity) {
        this.maximumOpenQuantity = maximumOpenQuantity;
        return this;
    }

    public HedgePortfolioConfigImpl setMaximumOpenVarOrders(final int maximumOpenVarOrders) {
        this.maximumOpenVarOrders = maximumOpenVarOrders;
        return this;
    }

    public HedgePortfolioConfigImpl setThrottleLimitNumberOrder(final int throttleLimitNumberOrder) {
        this.throttleLimitNumberOrder = throttleLimitNumberOrder;
        return this;
    }

    public HedgePortfolioConfigImpl setThrottleLimitTimePeriodMS(final long throttleLimitTimePeriodMS) {
        this.throttleLimitTimePeriodMS = throttleLimitTimePeriodMS;
        return this;
    }

    public HedgePortfolioConfigImpl setThrottleLimitRejectNumberOrder(final int throttleLimitRejectNumberOrder) {
        this.throttleLimitRejectNumberOrder = throttleLimitRejectNumberOrder;
        return this;
    }

    public HedgePortfolioConfigImpl setThrottleLimitRejectTimePeriodMS(final long throttleLimitRejectTimePeriodMS) {
        this.throttleLimitRejectTimePeriodMS = throttleLimitRejectTimePeriodMS;
        return this;
    }

    public HedgePortfolioConfigImpl setOrderUnknownTimeoutMS(final long timeoutMS) {
        this.orderUnknownTimeoutMS = timeoutMS;
        return this;
    }

    public HedgePortfolioConfigImpl setCancelUnknownTimeoutMS(final long timeoutMS) {
        this.cancelUnknownTimeoutMS = timeoutMS;
        return this;
    }

    public HedgePortfolioConfigImpl setOrderCompleteTimeoutMS(final long timeoutMS) {
        this.orderCompleteTimeoutMS = timeoutMS;
        return this;
    }

    public HedgePortfolioConfigImpl setOrderType(final OrderType orderType) {
        this.orderType = orderType;
        return this;
    }

    public HedgePortfolioConfigImpl setOrderTimeInForce(final TimeInForce timeInForce) {
        this.orderTimeInForce = timeInForce;
        return this;
    }

    public HedgePortfolioConfigImpl setMinimumTimeToLiveMS(final long minimumTimeToLiveMS) {
        this.minimumTimeToLiveMS = minimumTimeToLiveMS;
        return this;
    }

    public HedgePortfolioConfigImpl setMaxNumberCancelRejects(final int maxNumberCancelRejects) {
        this.maxNumberCancelRejects = maxNumberCancelRejects;
        return this;
    }

    public HedgePortfolioConfigImpl setOrderQuantityPrecision(final int orderQuantityPrecision) {
        this.orderQuantityPrecision = orderQuantityPrecision;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        market = Market.valueOf(in.readByte());
        portfolio = Portfolio.valueOf(in.readByte());
        hedgerName = in.readUTF8();
        bookName = in.readUTF8();
        // haven't changed storage type from long to int
        maximumOpenOrders = in.readLong();
        maximumOpenQuantity = in.readDouble();
        maximumOpenVarOrders = in.readLong();
        throttleLimitNumberOrder = in.readLong();
        throttleLimitTimePeriodMS = in.readLong();
        throttleLimitRejectNumberOrder = in.readLong();
        throttleLimitRejectTimePeriodMS = in.readLong();
        orderUnknownTimeoutMS = in.readLong();
        orderType = OrderType.valueOf(in.readByte());
        orderTimeInForce = TimeInForce.valueOf(in.readByte());
        Context.context().header().since(MessageVersion.VERSION_0_23, () -> minimumTimeToLiveMS = in.readLong());
        Context.context().header().since(MessageVersion.VERSION_0_24, () -> enabled = in.readBoolean());
        Context.context().header().since(MessageVersion.VERSION_0_24, () -> cancelUnknownTimeoutMS = in.readLong());
        Context.context().header().since(MessageVersion.VERSION_0_24, () -> orderCompleteTimeoutMS = in.readLong());
        Context.context().header().since(MessageVersion.VERSION_0_31, () -> maxNumberCancelRejects = in.readInt());
        Context.context().header().since(MessageVersion.VERSION_0_36, () -> orderQuantityPrecision = in.readInt());
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(market.getValue());
        out.writeByte(portfolio.getValue());
        out.writeUTF8(hedgerName);
        out.writeUTF8(bookName);
        out.writeLong(maximumOpenOrders);
        out.writeDouble(maximumOpenQuantity);
        out.writeLong(maximumOpenVarOrders);
        out.writeLong(throttleLimitNumberOrder);
        out.writeLong(throttleLimitTimePeriodMS);
        out.writeLong(throttleLimitRejectNumberOrder);
        out.writeLong(throttleLimitRejectTimePeriodMS);
        out.writeLong(orderUnknownTimeoutMS);
        out.writeByte(orderType.getValue());
        out.writeByte(orderTimeInForce.getValue());
        out.writeLong(minimumTimeToLiveMS);
        out.writeBoolean(enabled);
        out.writeLong(cancelUnknownTimeoutMS);
        out.writeLong(orderCompleteTimeoutMS);
        out.writeInt(maxNumberCancelRejects);
        out.writeInt(orderQuantityPrecision);
    }

    @Override
    public String toString() {
        return "HedgePortfolioConfigImpl{" +
                "market=" + market +
                ", portfolio=" + portfolio +
                ", hedgerName='" + hedgerName + '\'' +
                ", bookName='" + bookName + '\'' +
                ", enabled=" + enabled +
                ", maximumOpenOrders=" + maximumOpenOrders +
                ", maximumOpenQuantity=" + maximumOpenQuantity +
                ", maximumOpenVarOrders=" + maximumOpenVarOrders +
                ", throttleLimitNumberOrder=" + throttleLimitNumberOrder +
                ", throttleLimitTimePeriodMS=" + throttleLimitTimePeriodMS +
                ", throttleLimitRejectNumberOrder=" + throttleLimitRejectNumberOrder +
                ", throttleLimitRejectTimePeriodMS=" + throttleLimitRejectTimePeriodMS +
                ", orderUnknownTimeoutMS=" + orderUnknownTimeoutMS +
                ", cancelUnknownTimeoutMS=" + cancelUnknownTimeoutMS +
                ", orderCompleteTimeoutMS=" + orderCompleteTimeoutMS +
                ", orderType=" + orderType +
                ", orderTimeInForce=" + orderTimeInForce +
                ", minimumTimeToLiveMS=" + minimumTimeToLiveMS +
                ", maxNumberCancelRejects=" + maxNumberCancelRejects +
                ", orderQuantityPrecision=" + orderQuantityPrecision +
                '}';
    }
}