#!/bin/bash
# -*- sh -*-
source ~/axle/environment/shell/axle.rc &> /dev/null

: << =cut

=head1 NAME

datafabric7 - Plugin to monitor the Datafabric

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=datafabric
 #%# capabilities=autoconf

=cut

HOME_DATACENTRE=${datafabric.node}
HOME_DATACENTRE_SHORT=`echo $HOME_DATACENTRE | awk -F. '{ print $(NF-1); }'`

if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Datafabric 7 -' $HOME_DATACENTRE '- Operation Times for Non-Trading Region (ms)'
    echo 'graph_category datafabric'
    echo 'graph_scale no'
    echo 'df7_1.label Account Config'
    echo 'df7_1.draw LINE2'
    echo 'df7_2.label Currency Pair'
    echo 'df7_2.draw LINE2'
    echo 'df7_3.label Currency Pair Config'
    echo 'df7_3.draw LINE2'
    echo 'df7_4.label Currency Venue Exclusions'
    echo 'df7_4.draw LINE2'
    echo 'df7_5.label General Config'
    echo 'df7_5.draw LINE2'
    echo 'df7_6.label Trade Limit'
    echo 'df7_6.draw LINE2'
    echo 'df7_7.label Venue Priority'
    echo 'df7_7.draw LINE2'
    echo 'df7_8.label Counterparty Credit Utilisations'
    echo 'df7_8.draw LINE2'
    echo 'df7_9.label Audit'
    echo 'df7_9.draw LINE2'
    echo 'df7_10.label Component Status'
    echo 'df7_10.draw LINE2'
    echo 'df7_11.label Invocations'
    echo 'df7_11.draw LINE2'
    echo 'df7_12.label Ping'
    echo 'df7_12.draw LINE2'
    exit 0
fi

function emptyRecord() {
  echo "df7_1.value U"
  echo "df7_2.value U"
  echo "df7_3.value U"
  echo "df7_4.value U"
  echo "df7_5.value U"
  echo "df7_6.value U"
  echo "df7_7.value U"
  echo "df7_8.value U"
  echo "df7_9.value U"
  echo "df7_10.value U"
  echo "df7_11.value U"
  echo "df7_12.value U"
}

GEMFIRE_HOME=~/gemfire
LOGS=~/axle/datafabric/logs
if [ -f /etc/redhat-release ] ; then
    DATEPATH=date
else
    DATEPATH=/opt/sfw/bin/date
fi

# Munin plugins are executed every 5 minutes (production setting as of 2015-06-02)
# In case this changes, be sure to adjust the extract reuse and the stat sweep windows below (in all fabric plugins)

LATEST_DAT=`ls -ltr $LOGS/ | grep .dat | grep "$HOME_DATACENTRE.statistics-" | tr -s ' ' | tail -1 | awk -F' ' '{ print $(NF); }'`
LATEST_DAT_FILE=$LOGS/$LATEST_DAT
# Reuse stat extract if it was created within the last 1.5 minutes - this number is based on below:
#  - the plugin is executed every 5 minutes (dictated by the master)
#  - it takes around 3 minutes to produce the file (in the lab)
#  - deduct a further half minute to not to overlap with the next schedule
STATS_FILE="`find -L $LOGS -cmin -1.5 -type f -name "${HOME_DATACENTRE}.statreport-*.txt" | sort | tail -1`"

if [ "$LATEST_DAT_FILE" == "" ] && [ "$STATS_FILE" == "" ]; then
  emptyRecord
  exit 0
fi

# Refresh the cache - this is a very resource intensive operation
if [ "$STATS_FILE" == "" ]; then
  TIME_STAMP=`$DATEPATH -u '+%Y-%m-%d_%H-%M-00'`
  STATS_FILE=$LOGS/$HOME_DATACENTRE.statreport-$TIME_STAMP.txt
  # use a 5 minute period up until the start of the present minute
  TIME_FROM=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC' --date '-5 min'`
  TIME_UNTIL=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC'`
  DF_STAT_EXTRACT_CMD="${GEMFIRE_HOME}/bin/gemfire stats -starttime=\"${TIME_FROM}\" -endtime=\"${TIME_UNTIL}\" -archive=\"${LATEST_DAT_FILE}\" -persec"

  $DF_STAT_EXTRACT_CMD > "$STATS_FILE"
fi

# If there are no data, bail out honouring semantics
if [ ! -s "$STATS_FILE" ]; then
  emptyRecord
  exit 0
fi

egrep "(Partitioned Region|createsCompleted|putsCompleted|destroysCompleted|getsCompleted|containsKeyCompleted|putAllsCompleted|containsValueForKeyCompleted|createTime|putTime|containsKeyTime|putAllsTime|containsValueForKeyTime)" $STATS_FILE | awk -F' ' '
BEGIN {
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:createsCompleted:average"] = "df7_1_1";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:putsCompleted:average"] = "df7_1_2";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:destroysCompleted:average"] = "df7_1_3";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:getsCompleted:average"] = "df7_1_4";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:containsKeyCompleted:average"] = "df7_1_5";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:putAllsCompleted:average"] = "df7_1_6";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:containsValueForKeyCompleted:average"] = "df7_1_7";

  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:createTime:average"] = "df7_1_1t";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:putTime:average"] = "df7_1_2t";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:destroyTime:average"] = "df7_1_3t";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:getTime:average"] = "df7_1_4t";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:containsKeyTime:average"] = "df7_1_5t";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:putAllsTime:average"] = "df7_1_6t";
  lookingfor["Partitioned Region /axle_configuration_AccountConfig Statistics:containsValueForKeyTime:average"] = "df7_1_7t";

  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:createsCompleted:average"] = "df7_2_1";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:putsCompleted:average"] = "df7_2_2";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:destroysCompleted:average"] = "df7_2_3";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:getsCompleted:average"] = "df7_2_4";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:containsKeyCompleted:average"] = "df7_2_5";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:putAllsCompleted:average"] = "df7_2_6";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:containsValueForKeyCompleted:average"] = "df7_2_7";

  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:createTime:average"] = "df7_2_1t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:putTime:average"] = "df7_2_2t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:destroyTime:average"] = "df7_2_3t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:getTime:average"] = "df7_2_4t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:containsKeyTime:average"] = "df7_2_5t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:putAllsTime:average"] = "df7_2_6t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPair Statistics:containsValueForKeyTime:average"] = "df7_2_7t";

  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:createsCompleted:average"] = "df7_3_1";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:putsCompleted:average"] = "df7_3_2";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:destroysCompleted:average"] = "df7_3_3";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:getsCompleted:average"] = "df7_3_4";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:containsKeyCompleted:average"] = "df7_3_5";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:putAllsCompleted:average"] = "df7_3_6";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:containsValueForKeyCompleted:average"] = "df7_3_7";

  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:createTime:average"] = "df7_3_1t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:putTime:average"] = "df7_3_2t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:destroyTime:average"] = "df7_3_3t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:getTime:average"] = "df7_3_4t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:containsKeyTime:average"] = "df7_3_5t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:putAllsTime:average"] = "df7_3_6t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyPairConfig Statistics:containsValueForKeyTime:average"] = "df7_3_7t";

  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:createsCompleted:average"] = "df7_4_1";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:putsCompleted:average"] = "df7_4_2";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:destroysCompleted:average"] = "df7_4_3";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:getsCompleted:average"] = "df7_4_4";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:containsKeyCompleted:average"] = "df7_4_5";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:putAllsCompleted:average"] = "df7_4_6";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:containsValueForKeyCompleted:average"] = "df7_4_7";

  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:createTime:average"] = "df7_4_1t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:putTime:average"] = "df7_4_2t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:destroyTime:average"] = "df7_4_3t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:getTime:average"] = "df7_4_4t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:containsKeyTime:average"] = "df7_4_5t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:putAllsTime:average"] = "df7_4_6t";
  lookingfor["Partitioned Region /axle_configuration_CurrencyVenueExclusions Statistics:containsValueForKeyTime:average"] = "df7_4_7t";

  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:createsCompleted:average"] = "df7_5_1";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:putsCompleted:average"] = "df7_5_2";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:destroysCompleted:average"] = "df7_5_3";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:getsCompleted:average"] = "df7_5_4";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:containsKeyCompleted:average"] = "df7_5_5";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:putAllsCompleted:average"] = "df7_5_6";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:containsValueForKeyCompleted:average"] = "df7_5_7";

  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:createTime:average"] = "df7_5_1t";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:putTime:average"] = "df7_5_2t";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:destroyTime:average"] = "df7_5_3t";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:getTime:average"] = "df7_5_4t";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:containsKeyTime:average"] = "df7_5_5t";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:putAllsTime:average"] = "df7_5_6t";
  lookingfor["Partitioned Region /axle_configuration_GeneralConfig Statistics:containsValueForKeyTime:average"] = "df7_5_7t";

  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:createsCompleted:average"] = "df7_6_1";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:putsCompleted:average"] = "df7_6_2";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:destroysCompleted:average"] = "df7_6_3";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:getsCompleted:average"] = "df7_6_4";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:containsKeyCompleted:average"] = "df7_6_5";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:putAllsCompleted:average"] = "df7_6_6";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:containsValueForKeyCompleted:average"] = "df7_6_7";

  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:createTime:average"] = "df7_6_1t";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:putTime:average"] = "df7_6_2t";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:destroyTime:average"] = "df7_6_3t";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:getTime:average"] = "df7_6_4t";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:containsKeyTime:average"] = "df7_6_5t";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:putAllsTime:average"] = "df7_6_6t";
  lookingfor["Partitioned Region /axle_configuration_TradeLimit Statistics:containsValueForKeyTime:average"] = "df7_6_7t";

  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:createsCompleted:average"] = "df7_7_1";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:putsCompleted:average"] = "df7_7_2";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:destroysCompleted:average"] = "df7_7_3";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:getsCompleted:average"] = "df7_7_4";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:containsKeyCompleted:average"] = "df7_7_5";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:putAllsCompleted:average"] = "df7_7_6";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:containsValueForKeyCompleted:average"] = "df7_7_7";

  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:createTime:average"] = "df7_7_1t";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:putTime:average"] = "df7_7_2t";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:destroyTime:average"] = "df7_7_3t";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:getTime:average"] = "df7_7_4t";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:containsKeyTime:average"] = "df7_7_5t";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:putAllsTime:average"] = "df7_7_6t";
  lookingfor["Partitioned Region /axle_configuration_VenuePriority Statistics:containsValueForKeyTime:average"] = "df7_7_7t";

  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:createsCompleted:average"] = "df7_8_1";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:putsCompleted:average"] = "df7_8_2";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:destroysCompleted:average"] = "df7_8_3";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:getsCompleted:average"] = "df7_8_4";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:containsKeyCompleted:average"] = "df7_8_5";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:putAllsCompleted:average"] = "df7_8_6";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:containsValueForKeyCompleted:average"] = "df7_8_7";

  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:createTime:average"] = "df7_8_1t";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:putTime:average"] = "df7_8_2t";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:destroyTime:average"] = "df7_8_3t";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:getTime:average"] = "df7_8_4t";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:containsKeyTime:average"] = "df7_8_5t";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:putAllsTime:average"] = "df7_8_6t";
  lookingfor["Partitioned Region /axle_credit_CounterpartyCreditUtilisations Statistics:containsValueForKeyTime:average"] = "df7_8_7t";

  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:createsCompleted:average"] = "df7_9_1";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:putsCompleted:average"] = "df7_9_2";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:destroysCompleted:average"] = "df7_9_3";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:getsCompleted:average"] = "df7_9_4";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:containsKeyCompleted:average"] = "df7_9_5";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:putAllsCompleted:average"] = "df7_9_6";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:containsValueForKeyCompleted:average"] = "df7_9_7";

  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:createTime:average"] = "df7_9_1t";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:putTime:average"] = "df7_9_2t";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:destroyTime:average"] = "df7_9_3t";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:getTime:average"] = "df7_9_4t";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:containsKeyTime:average"] = "df7_9_5t";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:putAllsTime:average"] = "df7_9_6t";
  lookingfor["Partitioned Region /axle_monitoring_Audit Statistics:containsValueForKeyTime:average"] = "df7_9_7t";

  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:createsCompleted:average"] = "df7_10_1";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:putsCompleted:average"] = "df7_10_2";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:destroysCompleted:average"] = "df7_10_3";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:getsCompleted:average"] = "df7_10_4";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:containsKeyCompleted:average"] = "df7_10_5";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:putAllsCompleted:average"] = "df7_10_6";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:containsValueForKeyCompleted:average"] = "df7_10_7";

  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:createTime:average"] = "df7_10_1t";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:putTime:average"] = "df7_10_2t";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:destroyTime:average"] = "df7_10_3t";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:getTime:average"] = "df7_10_4t";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:containsKeyTime:average"] = "df7_10_5t";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:putAllsTime:average"] = "df7_10_6t";
  lookingfor["Partitioned Region /axle_util_ComponentStatus Statistics:containsValueForKeyTime:average"] = "df7_10_7t";

  lookingfor["Partitioned Region /axle_util_Invocations Statistics:createsCompleted:average"] = "df7_11_1";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:putsCompleted:average"] = "df7_11_2";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:destroysCompleted:average"] = "df7_11_3";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:getsCompleted:average"] = "df7_11_4";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:containsKeyCompleted:average"] = "df7_11_5";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:putAllsCompleted:average"] = "df7_11_6";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:containsValueForKeyCompleted:average"] = "df7_11_7";

  lookingfor["Partitioned Region /axle_util_Invocations Statistics:createTime:average"] = "df7_11_1t";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:putTime:average"] = "df7_11_2t";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:destroyTime:average"] = "df7_11_3t";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:getTime:average"] = "df7_11_4t";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:containsKeyTime:average"] = "df7_11_5t";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:putAllsTime:average"] = "df7_11_6t";
  lookingfor["Partitioned Region /axle_util_Invocations Statistics:containsValueForKeyTime:average"] = "df7_11_7t";

  lookingfor["Partitioned Region /axle_util_Ping Statistics:createsCompleted:average"] = "df7_12_1";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:putsCompleted:average"] = "df7_12_2";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:destroysCompleted:average"] = "df7_12_3";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:getsCompleted:average"] = "df7_12_4";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:containsKeyCompleted:average"] = "df7_12_5";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:putAllsCompleted:average"] = "df7_12_6";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:containsValueForKeyCompleted:average"] = "df7_12_7";

  lookingfor["Partitioned Region /axle_util_Ping Statistics:createTime:average"] = "df7_12_1t";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:putTime:average"] = "df7_12_2t";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:destroyTime:average"] = "df7_12_3t";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:getTime:average"] = "df7_12_4t";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:containsKeyTime:average"] = "df7_12_5t";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:putAllsTime:average"] = "df7_12_6t";
  lookingfor["Partitioned Region /axle_util_Ping Statistics:containsValueForKeyTime:average"] = "df7_12_7t";
}
/^[a-zA-Z]/ {
  section  = substr($0,1,index($0,",")-1);
}
/^  / {
  statistic = $1;
  for (i=2; i<=NF; i++) {
    fieldandvalue = $i;
    equals = index(fieldandvalue,"=");
    if (equals > 0) {
      fieldname = substr(fieldandvalue,1,equals-1);
      value = substr(fieldandvalue,equals+1);
      outputname = lookingfor[section ":" statistic ":" fieldname];
      if (outputname != "") {
        values[outputname] = value;
      }
    }
  }
}
END {
  df7_1_count = values["df7_1_1"] + values["df7_1_2"] + values["df7_1_3"] + values["df7_1_4"] + values["df7_1_5"] + values["df7_1_6"] + values["df7_1_7"];
  df7_1_time = values["df7_1_1t"] + values["df7_1_2t"] + values["df7_1_3t"] + values["df7_1_4t"] + values["df7_1_5t"] + values["df7_1_6t"] + values["df7_1_7t"];
  if (df7_1_count > 0) { df7_1 = (df7_1_time / 1000000) / df7_1_count; } else { df7_1 = 0; }
  print "df7_1.value " df7_1;

  df7_2_count = values["df7_2_1"] + values["df7_2_2"] + values["df7_2_3"] + values["df7_2_4"] + values["df7_2_5"] + values["df7_2_6"] + values["df7_2_7"];
  df7_2_time = values["df7_2_1t"] + values["df7_2_2t"] + values["df7_2_3t"] + values["df7_2_4t"] + values["df7_2_5t"] + values["df7_2_6t"] + values["df7_2_7t"];
  if (df7_2_count > 0) { df7_2 = (df7_2_time / 1000000) / df7_2_count; } else { df7_2 = 0; }
  print "df7_2.value " df7_2;

  df7_3_count = values["df7_3_1"] + values["df7_3_2"] + values["df7_3_3"] + values["df7_3_4"] + values["df7_3_5"] + values["df7_3_6"] + values["df7_3_7"];
  df7_3_time = values["df7_3_1t"] + values["df7_3_2t"] + values["df7_3_3t"] + values["df7_3_4t"] + values["df7_3_5t"] + values["df7_3_6t"] + values["df7_3_7t"];
  if (df7_3_count > 0) { df7_3 = (df7_3_time / 1000000) / df7_3_count; } else { df7_3 = 0; }
  print "df7_3.value " df7_3;

  df7_4_count = values["df7_4_1"] + values["df7_4_2"] + values["df7_4_3"] + values["df7_4_4"] + values["df7_4_5"] + values["df7_4_6"] + values["df7_4_7"];
  df7_4_time = values["df7_4_1t"] + values["df7_4_2t"] + values["df7_4_3t"] + values["df7_4_4t"] + values["df7_4_5t"] + values["df7_4_6t"] + values["df7_4_7t"];
  if (df7_4_count > 0) { df7_4 = (df7_4_time / 1000000) / df7_4_count; } else { df7_4 = 0; }
  print "df7_4.value " df7_4;

  df7_5_count = values["df7_5_1"] + values["df7_5_2"] + values["df7_5_3"] + values["df7_5_4"] + values["df7_5_5"] + values["df7_5_6"] + values["df7_5_7"];
  df7_5_time = values["df7_5_1t"] + values["df7_5_2t"] + values["df7_5_3t"] + values["df7_5_4t"] + values["df7_5_5t"] + values["df7_5_6t"] + values["df7_5_7t"];
  if (df7_5_count > 0) { df7_5 = (df7_5_time / 1000000) / df7_5_count; } else { df7_5 = 0; }
  print "df7_5.value " df7_5;

  df7_6_count = values["df7_6_1"] + values["df7_6_2"] + values["df7_6_3"] + values["df7_6_4"] + values["df7_6_5"] + values["df7_6_6"] + values["df7_6_7"];
  df7_6_time = values["df7_6_1t"] + values["df7_6_2t"] + values["df7_6_3t"] + values["df7_6_4t"] + values["df7_6_5t"] + values["df7_6_6t"] + values["df7_6_7t"];
  if (df7_6_count > 0) { df7_6 = (df7_6_time / 1000000) / df7_6_count; } else { df7_6 = 0; }
  print "df7_6.value " df7_6;

  df7_7_count = values["df7_7_1"] + values["df7_7_2"] + values["df7_7_3"] + values["df7_7_4"] + values["df7_7_5"] + values["df7_7_6"] + values["df7_7_7"];
  df7_7_time = values["df7_7_1t"] + values["df7_7_2t"] + values["df7_7_3t"] + values["df7_7_4t"] + values["df7_7_5t"] + values["df7_7_6t"] + values["df7_7_7t"];
  if (df7_7_count > 0) { df7_7 = (df7_7_time / 1000000) / df7_7_count; } else { df7_7 = 0; }
  print "df7_7.value " df7_7;

  df7_8_count = values["df7_8_1"] + values["df7_8_2"] + values["df7_8_3"] + values["df7_8_4"] + values["df7_8_5"] + values["df7_8_6"] + values["df7_8_7"];
  df7_8_time = values["df7_8_1t"] + values["df7_8_2t"] + values["df7_8_3t"] + values["df7_8_4t"] + values["df7_8_5t"] + values["df7_8_6t"] + values["df7_8_7t"];
  if (df7_8_count > 0) { df7_8 = (df7_8_time / 1000000) / df7_8_count; } else { df7_8 = 0; }
  print "df7_8.value " df7_8;

  df7_9_count = values["df7_9_1"] + values["df7_9_2"] + values["df7_9_3"] + values["df7_9_4"] + values["df7_9_5"] + values["df7_9_6"] + values["df7_9_7"];
  df7_9_time = values["df7_9_1t"] + values["df7_9_2t"] + values["df7_9_3t"] + values["df7_9_4t"] + values["df7_9_5t"] + values["df7_9_6t"] + values["df7_9_7t"];
  if (df7_9_count > 0) { df7_9 = (df7_9_time / 1000000) / df7_9_count; } else { df7_9 = 0; }
  print "df7_9.value " df7_9;

  df7_10_count = values["df7_10_1"] + values["df7_10_2"] + values["df7_10_3"] + values["df7_10_4"] + values["df7_10_5"] + values["df7_10_6"] + values["df7_10_7"];
  df7_10_time = values["df7_10_1t"] + values["df7_10_2t"] + values["df7_10_3t"] + values["df7_10_4t"] + values["df7_10_5t"] + values["df7_10_6t"] + values["df7_10_7t"];
  if (df7_10_count > 0) { df7_10 = (df7_10_time / 1000000) / df7_10_count; } else { df7_10 = 0; }
  print "df7_10.value " df7_10;

  df7_11_count = values["df7_11_1"] + values["df7_11_2"] + values["df7_11_3"] + values["df7_11_4"] + values["df7_11_5"] + values["df7_11_6"] + values["df7_11_7"];
  df7_11_time = values["df7_11_1t"] + values["df7_11_2t"] + values["df7_11_3t"] + values["df7_11_4t"] + values["df7_11_5t"] + values["df7_11_6t"] + values["df7_11_7t"];
  if (df7_11_count > 0) { df7_11 = (df7_11_time / 1000000) / df7_11_count; } else { df7_11 = 0; }
  print "df7_11.value " df7_11;

  df7_12_count = values["df7_12_1"] + values["df7_12_2"] + values["df7_12_3"] + values["df7_12_4"] + values["df7_12_5"] + values["df7_12_6"] + values["df7_12_7"];
  df7_12_time = values["df7_12_1t"] + values["df7_12_2t"] + values["df7_12_3t"] + values["df7_12_4t"] + values["df7_12_5t"] + values["df7_12_6t"] + values["df7_12_7t"];
  if (df7_12_count > 0) { df7_12 = (df7_12_time / 1000000) / df7_12_count; } else { df7_12 = 0; }
  print "df7_12.value " df7_12;
}
'
