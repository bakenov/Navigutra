package com.anz.axle.lg.adapter.apama.decoder;


import java.nio.ByteBuffer;
import java.util.function.Consumer;

import org.agrona.concurrent.UnsafeBuffer;

import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.LastMarketTradeEncoder;
import com.anz.markets.efx.pricing.codec.api.MarketDataRequestEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.base.PricingTranslator;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;

public enum DecoderTestMode {
    MOCK {
        @Override
        public PricingEncoderSupplier encoderSupplier(final PricingEncoderSupplier finalEncoderSupplier) {
            return finalEncoderSupplier;
        }
    },
    SBE {
        @Override
        public PricingEncoderSupplier encoderSupplier(final PricingEncoderSupplier finalEncoderSupplier) {

            final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
            final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
            final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
            final SbePricingEncoders sbePricingEncoders = new SbePricingEncoders(() -> sbeMessage);

            final SbePricingDecoders sbePricingDecoders = new SbePricingDecoders();

            final PricingEncoders<SbeMessage> finalPricingEncoders = new PricingEncoders<SbeMessage>() {
                @Override
                public MessageEncoder.Factory<SbeMessage, MarketDataRequestEncoder> marketDataRequest() {
                    return supplier -> finalEncoderSupplier.marketDataRequest();
                }

                @Override
                public MessageEncoder.Factory<SbeMessage, SnapshotFullRefreshEncoder> snapshotFullRefresh() {
                    return supplier -> finalEncoderSupplier.snapshotFullRefresh();
                }

                @Override
                public MessageEncoder.Factory<SbeMessage, IncrementalRefreshEncoder> incrementalRefresh() {
                    return supplier -> finalEncoderSupplier.incrementalRefresh();
                }

                @Override
                public MessageEncoder.Factory<SbeMessage, LastMarketTradeEncoder> lastMarketTrade() {
                    return supplier -> finalEncoderSupplier.lastMarketTrade();
                }
            };

            final PricingTranslator<SbeMessage> pricingTranslator = PricingTranslator.create(
                    sbePricingDecoders.snapshotFullAndIncrementalRefresh(),
                    finalPricingEncoders.toPricingEncoderSupplier(sbeMessage2 -> {})
            );

            final Consumer<SbeMessage> sbeMessageConsumer  = sbeMessage1 -> pricingTranslator.decode(sbeMessage1);

            return PricingEncoderSupplier.create(sbePricingEncoders, sbeMessageConsumer);
        }
    };

    public abstract PricingEncoderSupplier encoderSupplier(final PricingEncoderSupplier finalEncoderSupplier);

}
