package com.anz.markets.efx.ngaro.sbe;

import com.anz.markets.efx.ngaro.codec.StringEncoder;

/**
 * Contains static factory methods to create encoders for fixed or variable length strings.
 */
public final class StringEncoders {

    public static <E> StringEncoder<E> forFixedLength(final E enclosingEncoder, final FixedStringTarget target, final int length) {
        return new FixedStringEncoder<>(enclosingEncoder, target, length);
    }

    public static <E> StringEncoder<E> forVariableLength(final E enclosingEncoder, final VariableStringTarget target, final int maxLength) {
        return new VariableStringEncoder<>(enclosingEncoder, target, maxLength);
    }

    private StringEncoders() {
        throw new RuntimeException("No StringEncoders for you!");
    }
}
