package com.anz.markets.prophet;

/**
 * Temporary class to capture all our ByteWatcher funnies. Sometimes a seemingly unrelated change will
 * make one or more other BW tests fail (even though perf test run shows 0 GCs still).
 * <p>
 * This class exists to keep track of these and keep the build green (so at least we can see when
 * something else has gone wrong)
 * <p>
 * TODO: work out why these happen and fix them
 */
public class ByteWatcherTodo {
    public static final long THRESHOLD_CrossRateManagerBWTest = 36_000_000,
            THRESHOLD_AggregatedBookManagerBWTest = 38_400_032;
}
