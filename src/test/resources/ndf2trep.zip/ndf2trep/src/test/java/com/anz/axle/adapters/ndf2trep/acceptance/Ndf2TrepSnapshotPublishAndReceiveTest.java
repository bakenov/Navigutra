package com.anz.axle.adapters.ndf2trep.acceptance;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

import com.anz.axle.adapters.ndf2trep.enrichment.margin.MarginService;
import com.anz.markets.efx.ngaro.maths.DoubleTools;
import com.anz.markets.efx.ngaro.maths.Epsilon;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.adapters.ndf2trep.publisher.TrepQuote;
import com.anz.axle.applicationboot.Application;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.servicelifecycle.Awaitable;
import com.anz.markets.adapters.trep.Item;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;

import static com.anz.markets.efx.ngaro.api.SecurityType.FXSPOT;
import static com.anz.markets.efx.ngaro.api.Tenor.SP;
import static com.anz.markets.efx.ngaro.api.Venue.EBS;
import static com.anz.markets.efx.pricing.codec.api.EntryType.BID;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test Setup:
 * Publish pojo snapshot to subscription
 * Ndf2trep receive and publish to trep server
 * Subscribe to trep server to receive published quote and assert
 */
@RunWith(Spockito.class)
public class Ndf2TrepSnapshotPublishAndReceiveTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(Ndf2TrepSnapshotPublishAndReceiveTest.class);

    private Application application;
    private Queue<PricingMessage> messageQueue;

    private TestMessageProcessor testRateProcessor;
    private TrepRateSubscriber testTrepNdfSubscriber;
    private MarginService marginService;
    private PrecisionClock precisionClock;

    @Before
    public void setup() throws Exception {

        System.setProperty("appName", "ndf2trep-acceptance");
        application = new Application("ndf2trep-acceptance", TestConfig.class);
        application.startAndAwaitStarted();

        final AnnotationConfigApplicationContext ctx = application.getApplicationContext();
        messageQueue = ctx.getBean("pricingMessageQueue", Queue.class);
        testRateProcessor = ctx.getBean("testRateProcessor", TestMessageProcessor.class);
        precisionClock = ctx.getBean("precisionClock", PrecisionClock.class);
        marginService = ctx.getBean("marginService", MarginService.class);

        testTrepNdfSubscriber = ctx.getBean("testTrepNdfSubscriber", TrepRateSubscriber.class);
        testTrepNdfSubscriber.run();

        awaitTrepLogon();
        testTrepNdfSubscriber.awaitConnected(10, TimeUnit.SECONDS);
    }

    @After
    public void afterEach() {
        testTrepNdfSubscriber.cleanup();
        application.stop();
    }

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_1_LIVE = Table.parse(SnapshotFullRefresh.Entry.class, new String[]{
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   []         |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 |   []         |    2      |   4          | 0                 |",
            "|3155692600000 | RFX            |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   []         |    1      |   3          | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_1_INDIC = Table.parse(SnapshotFullRefresh.Entry.class, new String[]{
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   []         |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 |   []         |    2      |   4          | 0                 |",
            "|3155692600000 | RFX            |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   [LATENT]   |    1      |   3          | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_2 = Table.parse(SnapshotFullRefresh.Entry.class, new String[]{
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.3345  |        0.0           |     1e6     |  500000 |   []         |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.3320  |        0.0001        |     2e6     |  800000 |   []         |    2      |   4          | 0                 |",
    });

    private static final List<SnapshotFullRefresh.Entry[]> snapshotEntries() {
        return Arrays.asList(SNAP_ENTRIES_1_LIVE, SNAP_ENTRIES_1_INDIC, SNAP_ENTRIES_2);
    }

    private static final Hop[] HOPS = Table.parse(Hop.class, new String[]{
            "|   hopCompId  | hopMessageId | hopReceivingTime | hopSendingTime |",
            "|==============|==============|==================|================|",
            "| GB:HopName:1 |   123456789  |    66655556666   |  66655557777   |",
            "| AU:HopName:2 |   123123123  |    66556655666   |  66556655777   |",
    });

    @Test
    @Spockito.Unroll({
            "|idx | senderCompId | messageId | possResend | sendingTime | origSendingTime | symbol | ricName |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|====|==============|===========|============|=============|=================|========|=========|===============|==========|============|===========|============|===================|===================|",
            "| 0  | GB:Sender:01 |    9876   |    false   |  1122334455 |    1122334000   | USDCNY | CN11M   |   FXNDF       | EBS      | 2016-01-14 |     M1    | 2016-01-16 |     2016-01-06    | []                |",
            "|----|--------------|-----------|------------|-------------|-----------------|--------|---------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void ndfPriceIsPublishedToTrep(
            final int idx, final String senderCompId, final long messageId, final boolean possResend,
            final long sendingTime, final long origSendingTime,
            final String symbol, final String ricName, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags) throws Exception {

        final SnapshotFullRefresh.Entry[] snapShotEntry = snapshotEntries().get(idx);
        for (SnapshotFullRefresh.Entry e: snapShotEntry) {
            e.transactTime = precisionClock.nanos();
        }

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType), marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                snapShotEntry, HOPS);

        testRateProcessor.clear();

        // publish snapshot for Subscription
        messageQueue.add(snapshot);

        TrepQuote.Builder builder = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(ricName + "=AXLE_DEV-AUTOTEST");
        snapshot.entries.forEach((entry) -> {
            switch (entry.mdEntryType) {
                case BID:
                    builder.updateBid(entry.mdEntryPx, 1);
                    break;
                case OFFER:
                    builder.updateOffer(entry.mdEntryPx, 1);
                    break;
            }
        });

        final TrepQuote trepQuote = builder.build();

        LOGGER.info("Checking receiver for: " + trepQuote);
        Item latestUpdate = getLatestUpdateForService(trepQuote);//received.get(0);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received>" + latestUpdate + " expected> " + trepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(trepQuote).isNotNull().as("Expected TrepQuote");
        assertThat(latestUpdate.getName()).isEqualTo(trepQuote.getName()).as("ServiceName");
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), trepQuote.getBid(), Double.valueOf(latestUpdate.getValue("BID")).doubleValue()));
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), trepQuote.getAsk(), Double.valueOf(latestUpdate.getValue("ASK")).doubleValue()));
        assertThat(latestUpdate.getValue("GEN_TEXT16")).isEqualTo(trepQuote.getQuoteType().getDisplay()).as("GEN_TEXT16");
    }

    @Test
    @Spockito.Unroll({
            "|idx | senderCompId | messageId | possResend | sendingTime | origSendingTime | symbol | ricName |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|====|==============|===========|============|=============|=================|========|=========|===============|==========|============|===========|============|===================|===================|",
            "| 1  | GB:Sender:01 |    9876   |    false   |  1122334455 |    1122334000   | USDCNY | CN11M   |   FXNDF       | EBS      | 2016-01-14 |     M1    | 2016-01-16 |     2016-01-06    | []                |",
            "|----|--------------|-----------|------------|-------------|-----------------|--------|---------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void ndfPriceIsPublishedToTrep_IndicativeBid(
            final int idx, final String senderCompId, final long messageId, final boolean possResend,
            final long sendingTime, final long origSendingTime,
            final String symbol, final String ricName, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags) throws Exception {

        final SnapshotFullRefresh.Entry[] snapShotEntry = snapshotEntries().get(idx);
        for (SnapshotFullRefresh.Entry e : snapShotEntry) {
            e.transactTime = precisionClock.nanos();
        }

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType), marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                snapShotEntry, HOPS);

        testRateProcessor.clear();

        // publish snapshot for Subscription
        messageQueue.add(snapshot);

        TrepQuote.Builder builder = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(ricName + "=AXLE_DEV-AUTOTEST");
        snapshot.entries.forEach((entry) -> {
            switch (entry.mdEntryType) {
                case BID:
                    builder.updateBid(entry.mdEntryPx, 1);
                    break;
                case OFFER:
                    builder.updateOffer(entry.mdEntryPx, 1);
                    break;
            }
        });

        final TrepQuote trepQuote = builder.isIndicative(true).build();

        LOGGER.info("Checking receiver for: " + trepQuote);
        Item latestUpdate = getLatestUpdateForService(trepQuote);//received.get(0);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received>" + latestUpdate + " expected> " + trepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(trepQuote).isNotNull().as("Expected TrepQuote");
        assertThat(latestUpdate.getName()).isEqualTo(trepQuote.getName()).as("ServiceName");
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), trepQuote.getBid(), Double.valueOf(latestUpdate.getValue("BID")).doubleValue()));
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), trepQuote.getAsk(), Double.valueOf(latestUpdate.getValue("ASK")).doubleValue()));
        assertThat(latestUpdate.getValue("GEN_TEXT16")).isEqualTo(trepQuote.getQuoteType().getDisplay()).as("GEN_TEXT16");
    }

    @Test
    @Spockito.Unroll({
            "|idx | senderCompId | messageId | possResend | sendingTime | origSendingTime | symbol | ricName |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|====|==============|===========|============|=============|=================|========|=========|===============|==========|============|===========|============|===================|===================|",
            "| 0  | GB:Sender:01 |    9876   |    false   |  1122334455 |    1122334000   | USDCNY | CN11M   |   FXNDF       | EBS      | 2016-01-14 |     M1    | 2016-01-16 |     2016-01-06    | [DISABLED] |",
            "|----|--------------|-----------|------------|-------------|-----------------|--------|---------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void publishEmptyQuoteWhenBodyContainsFlags(
            final int idx, final String senderCompId, final long messageId, final boolean possResend,
            final long sendingTime, final long origSendingTime,
            final String symbol, final String ricName, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags) throws Exception {

        final SnapshotFullRefresh.Entry[] snapShotEntry = snapshotEntries().get(idx);
        for (SnapshotFullRefresh.Entry e : snapShotEntry) {
            e.transactTime = System.nanoTime();
        }

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType), marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                snapShotEntry, HOPS);

        testRateProcessor.clear();

        // publish snapshot for Subscription
        messageQueue.add(snapshot);

        final TrepQuote trepQuote = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(ricName + "=AXLE_DEV-AUTOTEST")
                .isIndicative(true)
                .build();

        LOGGER.info("Checking receiver for: " + trepQuote);
        Item latestUpdate = getLatestUpdateForService(trepQuote);
        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received>" + latestUpdate + " expected> " + trepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(trepQuote).isNotNull().as("Expected TrepQuote");
        assertThat(latestUpdate.getName()).isEqualTo(trepQuote.getName()).as("ServiceName");
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), trepQuote.getBid(), Double.valueOf(latestUpdate.getValue("BID")).doubleValue()));
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), trepQuote.getAsk(), Double.valueOf(latestUpdate.getValue("ASK")).doubleValue()));
        assertThat(latestUpdate.getValue("GEN_TEXT16")).isEqualTo(trepQuote.getQuoteType().getDisplay()).as("GEN_TEXT16");
    }

    //https://jira.service.anz/browse/AXPROPHET-1491
    //For this test, only values from column 1 (symbol), column 3 (mdEntryType) and column 4 (mdEntryPx) will be input parameter
    // and value from column 5(pxSentToTrep) will be the expected outcome.
    //Refer to AXPROPHET-1491_PriceToTrep_Calculation_BasedOnMargin.xlsx spread sheet to know how pxSentToTrep is calculated
    //With Test Data 1 from table - Verifying whether Margin in PERC is applied on price with 5DPS and rounded to 4 DPS
    //With Test Data 2 from table - Verifying whether Margin in PIPS is applied and rounding not affected since DPS is set to 4
    //With Test Data 3 from table - Verifying whether Margin in PERC is NOT applied (since margin is 0) but rounded to 4 DPS
    //With Test Data 4 from table - Verifying whether Margin in PERC is applied on price with 4DPS and rounding remains to 4 DPS but rounded down.
    //With Test Data 5 from table - Verifying whether Margin in PERC is applied on price with 4DPS and rounding remains to 4 DPS but rounded up.
    //With Test Data 6 from table - Verifying whether Margin in PIPS is applied at right position based on configuration.
    @Test
    @Spockito.Unroll({
            "|  symbol      |      mdMkt     | mdEntryType | mdEntryPx | pxSentToTrep |mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|==============|=====================|=============|=========|==============|===========|==============|===================|",
            "|  AUDCAD      | EBS            |      BID    |   0.90229 | 0.8941       | 0.0                 |     1e6     |  500000 |   []         |    1      |   7          | 0                 |",
            "|  AUDJPY      | RFX            |     OFFER   |   72.211  | 72.212       | 0.0001              |     2e6     |  600000 |   []         |    2      |   8          | 0                 |",
            "|  AUDNZD      | EBS            |     BID     |   1.05767 | 1.0576       | 0.0002              |     3e6     |  700000 |   []         |    3      |   9          | 0                 |",
            "|  AUDCAD      | RFX            |     BID     |   0.9025  | 0.8943       | 0.0003              |     4e6     |  800000 |   []         |    4      |   10         | 0                 |",
            "|  AUDCAD      | EBS            |     OFFER   |   0.9025  | 0.9098       | 0.0004              |     5e6     |  900000 |   []         |    5      |   11         | 0                 |",
            "|  USDJPY      | RFX            |     BID     |   72.45678| 72.256       | 0.0001              |     6e6     |  950000 |   []         |    6      |   11         | 0                 |",
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void spotPriceFromSnapshotFullRefreshIsPublishedToTrepWithPercPipsMargin(final String symbol, final Venue mdMkt, final EntryType mdEntryType, final double mdEntryPx,
                     final double pxSentToTrep, final double mdEntryForwardPoints, final double mdEntrySize,
                     final double minQty, final EnumSet<Flag> mdEntryFlags, final int mdEntryId, final int quoteEntryId,
                     final int mdEntryPositionNo) throws Exception {

        SnapshotFullRefresh.Entry[] snapShotEntry = new SnapshotFullRefresh.Entry[1];
        snapShotEntry[0] = new SnapshotFullRefresh.Entry();
        snapShotEntry[0].mdMkt = mdMkt;
        snapShotEntry[0].mdEntryType = mdEntryType;
        snapShotEntry[0].mdEntryPx = mdEntryPx;
        snapShotEntry[0].mdEntryForwardPoints = mdEntryForwardPoints;
        snapShotEntry[0].mdEntrySize = mdEntrySize;
        snapShotEntry[0].minQty = minQty;
        snapShotEntry[0].mdEntryFlags = mdEntryFlags;
        snapShotEntry[0].mdEntryId = mdEntryId;
        snapShotEntry[0].quoteEntryId = quoteEntryId;
        snapShotEntry[0].mdEntryPositionNo = mdEntryPositionNo;
        snapShotEntry[0].transactTime = precisionClock.nanos();

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body("GB:Sender:0", 9876, false, 1122334455, 1122334000, InstrumentKey.instrumentId(symbol, FXSPOT, SP), EBS, LocalDate.parse("2016-01-14"), LocalDate.parse("2016-01-16"), LocalDate.parse("2016-01-06"), null),
                snapShotEntry, HOPS);

        testRateProcessor.clear();

        // publish snapshot for Subscription
        messageQueue.add(snapshot);
        String fullRicName = symbol + "=AXLE_DEV-AUTOTEST";

        TrepQuote.Builder builder = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(fullRicName);
        snapshot.entries.forEach((entry) -> {
            switch (entry.mdEntryType) {
                case BID:
                    builder.updateBid(marginService.applyMargin(fullRicName, entry.mdEntryType, entry.mdEntryPx), 1);
                    break;
                case OFFER:
                    builder.updateOffer(marginService.applyMargin(fullRicName, entry.mdEntryType, entry.mdEntryPx), 1);
                    break;
            }
        });

        final TrepQuote trepQuote = builder.build();

        LOGGER.info("Checking receiver for: {}", trepQuote);
        Item latestUpdate = getLatestUpdateForService(trepQuote);//received.get(0);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received={}, expected={}", latestUpdate, trepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(trepQuote).isNotNull().as("Expected TrepQuote");
        if (mdEntryType == BID) {
            assertThat(trepQuote.getBid()).isEqualTo(pxSentToTrep);
        } else {
            assertThat(trepQuote.getAsk()).isEqualTo(pxSentToTrep);
        }
    }

    //https://jira.service.anz/browse/AXPROPHET-1491
    //For this test, only values from column 1 (symbol), column 3 (mdEntryType) and column 4 (mdEntryPx) will be input parameter
    // and value from column 5(pxSentToTrep) will be the expected outcome.
    //Refer to AXPROPHET-1491_PriceToTrep_Calculation_BasedOnMargin.xlsx spread sheet to know how pxSentToTrep is calculated
    //With Test Data 1 from table - Verifying whether Margin in PERC is applied on price with 5DPS and rounded to 4 DPS
    //With Test Data 2 from table - Verifying whether Margin in PIPS is applied and rounding not affected since DPS is set to 4
    //With Test Data 3 from table - Verifying whether Margin in PERC is NOT applied (since margin is 0) but rounded to 4 DPS
    //With Test Data 4 from table - Verifying whether Margin in PERC is applied on price with 4DPS and rounding remains to 4 DPS but rounded down.
    //With Test Data 5 from table - Verifying whether Margin in PERC is applied on price with 4DPS and rounding remains to 4 DPS but rounded up.
    //With Test Data 6 from table - Verifying whether Margin in PIPS is applied at right position based on configuration.
    @Test
    @Spockito.Unroll({
            "|  symbol      |      mdMkt     | mdEntryType | mdEntryPx | pxSentToTrep |mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|==============|=====================|=============|=========|==============|===========|==============|===================|",
            "|  AUDCAD      | EBS            |      BID    |   0.90229 | 0.8941       | 0.0                 |     1e6     |  500000 |   []         |    1      |   7          | 0                 |",
            "|  AUDJPY      | RFX            |     OFFER   |   72.211  | 72.212       | 0.0001              |     2e6     |  600000 |   []         |    2      |   8          | 0                 |",
            "|  AUDNZD      | EBS            |     BID     |   1.05767 | 1.0576       | 0.0002              |     3e6     |  700000 |   []         |    3      |   9          | 0                 |",
            "|  AUDCAD      | RFX            |     BID     |   0.9025  | 0.8943       | 0.0003              |     4e6     |  800000 |   []         |    4      |   10         | 0                 |",
            "|  AUDCAD      | EBS            |     OFFER   |   0.9025  | 0.9098       | 0.0004              |     5e6     |  900000 |   []         |    5      |   11         | 0                 |",
            "|  USDJPY      | RFX            |     BID     |   72.45678| 72.256       | 0.0001              |     6e6     |  950000 |   []         |    6      |   11         | 0                 |"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void spotPriceFromIncrementalRefreshIsPublishedToTrepWithPercPipsMargin(final String symbol, final Venue mdMkt, final EntryType mdEntryType, final double mdEntryPx,
                                                             final double pxSentToTrep, final double mdEntryForwardPoints, final double mdEntrySize,
                                                             final double minQty, final EnumSet<Flag> mdEntryFlags, final int mdEntryId, final int quoteEntryId,
                                                             final int mdEntryPositionNo) throws Exception {

        SnapshotFullRefresh.Entry[] snapShotEntry = new SnapshotFullRefresh.Entry[1];
        snapShotEntry[0] = new SnapshotFullRefresh.Entry();
        snapShotEntry[0].mdMkt = mdMkt;
        snapShotEntry[0].mdEntryType = mdEntryType;
        snapShotEntry[0].mdEntryPx = mdEntryPx;
        snapShotEntry[0].mdEntryForwardPoints = mdEntryForwardPoints;
        snapShotEntry[0].mdEntrySize = mdEntrySize;
        snapShotEntry[0].minQty = minQty;
        snapShotEntry[0].mdEntryFlags = mdEntryFlags;
        snapShotEntry[0].mdEntryId = mdEntryId;
        snapShotEntry[0].quoteEntryId = quoteEntryId;
        snapShotEntry[0].mdEntryPositionNo = mdEntryPositionNo;
        snapShotEntry[0].transactTime = precisionClock.nanos();

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body("GB:Sender:0", 9876, false, 1122334455, 1122334000, InstrumentKey.instrumentId(symbol, FXSPOT, SP), EBS, LocalDate.parse("2016-01-14"), LocalDate.parse("2016-01-16"), LocalDate.parse("2016-01-06"), null),
                snapShotEntry, HOPS);

        testRateProcessor.clear();

        // publish snapshot for Subscription
        messageQueue.add(snapshot);

        IncrementalRefresh.Entry[] incEntry = new IncrementalRefresh.Entry[1];
        incEntry[0] = new IncrementalRefresh.Entry();
        incEntry[0].mdMkt = mdMkt;
        incEntry[0].mdEntryType = mdEntryType;
        incEntry[0].mdEntryPx = mdEntryPx;
        incEntry[0].mdEntryForwardPoints = mdEntryForwardPoints;
        incEntry[0].mdEntrySize = mdEntrySize;
        incEntry[0].minQty = minQty;
        incEntry[0].mdEntryFlags = mdEntryFlags;
        incEntry[0].mdEntryId = mdEntryId;
        incEntry[0].quoteEntryId = quoteEntryId;
        incEntry[0].mdEntryPositionNo = mdEntryPositionNo;
        incEntry[0].transactTime = precisionClock.nanos();

        final IncrementalRefresh increment = PricingMessage.incrementalRefresh(
                new MessageHeader(),

                new IncrementalRefresh.Body("GB:Sender:0", 9876, 11223, InstrumentKey.instrumentId(symbol, FXSPOT, SP), EBS, LocalDate.parse("2016-01-14"), LocalDate.parse("2016-01-16"), LocalDate.parse("2016-01-06"), null),
                incEntry, HOPS);

        messageQueue.add(increment);

        String fullRicName = symbol + "=AXLE_DEV-AUTOTEST";

        TrepQuote.Builder builder = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(fullRicName);
        snapshot.entries.forEach((entry) -> {
            switch (entry.mdEntryType) {
                case BID:
                    builder.updateBid(marginService.applyMargin(fullRicName, entry.mdEntryType, entry.mdEntryPx), 1);
                    break;
                case OFFER:
                    builder.updateOffer(marginService.applyMargin(fullRicName, entry.mdEntryType, entry.mdEntryPx), 1);
                    break;
            }
        });

        final TrepQuote trepQuote = builder.build();

        LOGGER.info("Checking receiver for: {}", trepQuote);
        Item latestUpdate = getLatestUpdateForService(trepQuote);//received.get(0);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received={}, expected={}", latestUpdate, trepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(trepQuote).isNotNull().as("Expected TrepQuote");
        if (mdEntryType == BID) {
            assertThat(trepQuote.getBid()).isEqualTo(pxSentToTrep);
        } else {
            assertThat(trepQuote.getAsk()).isEqualTo(pxSentToTrep);
        }
    }

    private void awaitTrepLogon() throws Exception {
        final Awaitable trepLogonAwaitable = application.getApplicationContext().getBean("trepLogonServiceLifecycle", Awaitable.class);
        trepLogonAwaitable.awaitStarted(10, TimeUnit.SECONDS);
        LOGGER.info("trepLogonAwaitable.awaitStarted");
    }

    private Item getLatestUpdateForService(TrepQuote trepQuote) throws InterruptedException {
        LOGGER.info("getLatestUpdateForService()    trepQuote={}", trepQuote);
        Item latestUpdate = null;
        for (int i = 0; i < 15; i++) {
            latestUpdate = testRateProcessor.getLatestRateForRIC();
            if (latestUpdate!=null && latestUpdate.getName().equals(trepQuote.getName()) && Double.valueOf(latestUpdate.getValue("BID")).equals(trepQuote.getBid()) ) {
                return latestUpdate;
            } else {
                LOGGER.info("Skipping latest rate polled from subscription: " + latestUpdate);
            }
            TimeUnit.MILLISECONDS.sleep(10);
        }
        return latestUpdate;
    }
}