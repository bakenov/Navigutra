package com.anz.markets.prophet.pricer.firewall;


import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

public class NOPProtectionFirewallBWTest extends AbstractNOPProtectionFirewallForBwJmhTest {

    private static final int REPS = 100_000;
    private static final int THRESHOLD = 200;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();


    public NOPProtectionFirewallBWTest() {
        super();
        warmup();
    }

    public void scenario_applyPosition() {
        for (int i = 0; i < REPS; i++) {
            super.testApplyPosition();
        }
    }

    public void scenario_processClientPrice() {
        for (int i = 0; i < REPS; i++) {
            this.testPerformClientPrice();
        }
    }

    public void warmup() {
        scenario_applyPosition();
        scenario_processClientPrice();
    }

    @Test
    public void test_applyPosition() {
        helper.testAllocationNotExceeded(
                this::scenario_applyPosition,
                THRESHOLD // no allocation!
        );
    }

    @Test
    public void test_processClientPrice() {
        helper.testAllocationNotExceeded(
                this::scenario_processClientPrice,
                THRESHOLD // no allocation!
        );
    }
}
