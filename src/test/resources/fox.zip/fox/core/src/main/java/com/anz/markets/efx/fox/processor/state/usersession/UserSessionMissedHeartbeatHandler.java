package com.anz.markets.efx.fox.processor.state.usersession;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.UserSession;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.domain.ParentOrderDetails;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import com.anz.markets.efx.ngaro.api.Venue;

public class UserSessionMissedHeartbeatHandler implements TimerScheduler.ExpiryHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserSessionMissedHeartbeatHandler.class);

    private final UserSession userSession;

    public UserSessionMissedHeartbeatHandler(final UserSession userSession) {
        this.userSession = Objects.requireNonNull(userSession);
    }

    @Override
    public TimerGroup timerGroup() {
        return TimerGroup.USER_SESSION_MISSED_HEARTBEAT;
    }

    @Override
    public boolean onExpiryCommand(final long timerId, final long triggeredTime, final CommandContext commandContext) {
        if (userSession.online()) {
            final int onlinePortfolioSessions = userSession.onlinePortfolioSessions();
            final UserSessionKey userSessionKey = userSession.userSessionKey();
            LOGGER.info("Online {} portfolio sessions: {}", userSessionKey.portfolio(), onlinePortfolioSessions);
            if (onlinePortfolioSessions == 1) {
                final ParentOrderRepository parentOrderRepository = commandContext.parentOrderRepository();
                parentOrderRepository.forEach(order -> {
                    final ParentOrderDetails orderDetails = order.details();
                    final int source = commandContext.source();
                    final long sourceSeq = commandContext.idGenerator().getAsLong();
                    if (orderDetails.portfolio().equals(userSessionKey.portfolio())) {
                        commandContext.tradingEncoderSupplier().orderCancelRequest().messageStart(source, sourceSeq)
                                .marketId().encode(Venue.FOX.name())
                                .clOrdId().encodeLong(commandContext.idGenerator().getAsLong())
                                .origClOrdId().encodeLong(orderDetails.origClOrdId())
                                .clOrdLinkId().encodeLong(orderDetails.clOrdLinkId())
                                .messageId(sourceSeq)
                                .orderId().encodeLong(orderDetails.orderId())
                                .orderQty(orderDetails.orderQty())
                                .ordType(orderDetails.orderType())
                                .timeInForce(orderDetails.timeInForce())
                                .senderCompId().encode(commandContext.senderCompId())
                                .targetCompId().encode(commandContext.senderCompId())
                                .securityType(orderDetails.instrument().key().securityType())
                                .settlType(orderDetails.instrument().key().tenor())
                                .symbol().encode(orderDetails.instrument().key().symbol())
                                .side(orderDetails.side())
                                .transactTime(commandContext.precisionClock().nanos())
                                .partiesEmpty()
                                .hopsEmpty()
                                .text().encode("Unmanaged portfolio")
                                .messageComplete();
                    }
                });
            }
        }
        return false;
    }

    @Override
    public boolean onExpiryEvent(final long timerId, final long triggeredTime) {
        userSession.updateOffline();
        return true;
    }

}
