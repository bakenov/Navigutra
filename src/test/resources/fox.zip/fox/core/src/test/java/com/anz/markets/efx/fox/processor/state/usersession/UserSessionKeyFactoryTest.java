package com.anz.markets.efx.fox.processor.state.usersession;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.ngaro.core.AsciiString;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class UserSessionKeyFactoryTest {

    @Test
    @Spockito.Unroll({
            "| senderCompId                    | sessionId                     | userName                        | portfolio     | region |",
            "|=================================|===============================|=================================|===============|========|",
            "| PROPHET.HEDGER_MID_FXALL_GB     | PROPHET.HEDGER_MID_FXALL_GB   | prophet-autotrader-MidHedger    | XEFX          | GB     |",
            "| PROPHET.HEDGER_MID_EBS_GB       | PROPHET.HEDGER_MID_EBS_GB     | prophet-autotrader-MidHedgerEBS | XEFX          | GB     |",
            "| PROPHET.HEDGER_MID_EBS_JP       | PROPHET.HEDGER_MID_EBS_JP     | prophet-autotrader-MidHedgerEBS | XEFX          | JP     |",
            "| PROPHET.HEDGER_MID_BGC_JP       | PROPHET.HEDGER_MID_BGC_JP     | prophet-autotrader-MidHedgerBGC | XEFX          | JP     |",
            "| FXTrader.GB.wibowoa.P_WIBOWOA   | FXTrader.GB.wibowoa.P_WIBOWOA | wibowoa                         | P_WIBOWOA     | GB     |",
            "| FXTrader.JP.wibowoa.P_WIBOWOA   | FXTrader.JP.wibowoa.P_WIBOWOA | wibowoa                         | P_WIBOWOA     | JP     |",
            "| FXTrader.GB.wibowoa.XEFX        | FXTrader.GB.wibowoa.XEFX      | wibowoa                         | XEFX          | GB     |",
            "| FXTrader.wertwrtwrtrwwrt        | null                          | null                            | null          | null   |",
            "|---------------------------------|-------------------------------|---------------------------------|---------------|--------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void apply(final String senderCompId, final String sessionId, final String userName, final String portfolio, final Region region) {
        final UserSessionKeyFactory factory = new UserSessionKeyFactory();
        final UserSessionKey key = factory.apply(AsciiString.immutable(senderCompId));

        if (sessionId != null && userName != null && portfolio != null && region != null) {
            assertThat(key).isEqualTo(UserSessionKey.of(sessionId, userName, portfolio, region));
        } else {
            assertThat(key).isSameAs(UserSessionKey.UNKNOWN);
        }
    }
}