package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.codec.SimpleStringDecoder;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoFirewallConfigDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends FirewallConfigHandler> handlerSupplier;

    public PojoFirewallConfigDecoder(final Supplier<? extends FirewallConfigHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof FirewallConfig) {
            return decode((FirewallConfig) sorMessage);
        }
        return false;
    }

    public boolean decode(final FirewallConfig message) {
        final FirewallConfigHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source, message.header.sourceSeq);
        handler.onBody(new FirewallConfigHandler.Body() {
            final StringDecoder firewallName = new SimpleStringDecoder(() -> message.body.firewallName);
            final StringDecoder regionPattern = new SimpleStringDecoder(() -> message.body.regionPattern);
            final StringDecoder orderTypePattern = new SimpleStringDecoder(() -> message.body.orderTypePattern);
            final StringDecoder deskPattern = new SimpleStringDecoder(() -> message.body.deskPattern);
            final StringDecoder portfolioPattern = new SimpleStringDecoder(() -> message.body.portfolioPattern);
            final StringDecoder usernamePattern = new SimpleStringDecoder(() -> message.body.usernamePattern);
            final StringDecoder venuePattern = new SimpleStringDecoder(() -> message.body.venuePattern);
            final StringDecoder securityTypePattern = new SimpleStringDecoder(() -> message.body.securityTypePattern);
            final StringDecoder tenorPattern = new SimpleStringDecoder(() -> message.body.tenorPattern);
            final StringDecoder symbolPattern = new SimpleStringDecoder(() -> message.body.symbolPattern);
            final StringDecoder periodUnit = new SimpleStringDecoder(() -> message.body.periodUnit);
            final StringDecoder comment = new SimpleStringDecoder(() -> message.body.comment);
            final StringDecoder lastEditUsername = new SimpleStringDecoder(() -> message.body.lastEditUsername);

            @Override
            public StringDecoder firewallName() {
                return firewallName;
            }

            @Override
            public long ruleId() {
                return message.body.ruleId;
            }

            @Override
            public StringDecoder regionPattern() {
                return regionPattern;
            }

            @Override
            public StringDecoder orderTypePattern() {
                return orderTypePattern;
            }

            @Override
            public StringDecoder deskPattern() {
                return deskPattern;
            }

            @Override
            public StringDecoder portfolioPattern() {
                return portfolioPattern;
            }

            @Override
            public StringDecoder usernamePattern() {
                return usernamePattern;
            }

            @Override
            public StringDecoder venuePattern() {
                return venuePattern;
            }

            @Override
            public StringDecoder securityTypePattern() {
                return securityTypePattern;
            }

            @Override
            public StringDecoder tenorPattern() {
                return tenorPattern;
            }

            @Override
            public StringDecoder symbolPattern() {
                return symbolPattern;
            }

            @Override
            public long period() {
                return message.body.period;
            }

            @Override
            public StringDecoder periodUnit() {
                return periodUnit;
            }

            @Override
            public boolean local() {
                return message.body.local;
            }

            @Override
            public StringDecoder comment() {
                return comment;
            }

            @Override
            public StringDecoder lastEditUsername() {
                return lastEditUsername;
            }

            @Override
            public long lastEditTime() {
                return message.body.lastEditTime;
            }

            @Override
            public double limitThreshold() {
                return message.body.limitThreshold;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoFirewallConfigDecoder() {
        throw new RuntimeException("No PojoFirewallConfigDecoder for you!");
    }
}
