package com.anz.markets.efx.ngaro.api;

import java.time.LocalDate;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DefaultInstrumentKeyTest {

    @Test
    public void instrumentId_for_spot_matches_expected_attributes() {
        final InstrumentKey instrumentKey1 = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);
        final InstrumentKey instrumentKey2 = InstrumentKey.of(instrumentKey1.instrumentId());

        assertThat(instrumentKey1).isEqualTo(instrumentKey2);
        assertThat(instrumentKey1.instrumentId()).isEqualTo(instrumentKey2.instrumentId());
        assertThat(instrumentKey1.symbol()).isEqualTo(instrumentKey2.symbol());
        assertThat(instrumentKey1.securityType()).isEqualTo(instrumentKey2.securityType());
        assertThat(instrumentKey1.tenor()).isEqualTo(instrumentKey2.tenor());
        assertThat(instrumentKey1.settlementDate()).isEqualTo(instrumentKey2.settlementDate());
    }


    @Test
    public void instrumentId_for_ndf_matches_expected_attributes() {
        final InstrumentKey instrumentKey1 = InstrumentKey.of("AUDUSD", SecurityType.FXNDF, LocalDate.of(2018, 12, 11));
        final InstrumentKey instrumentKey2 = InstrumentKey.of(instrumentKey1.instrumentId());

        assertThat(instrumentKey1).isEqualTo(instrumentKey2);
        assertThat(instrumentKey1.instrumentId()).isEqualTo(instrumentKey2.instrumentId());
        assertThat(instrumentKey1.symbol()).isEqualTo(instrumentKey2.symbol());
        assertThat(instrumentKey1.securityType()).isEqualTo(instrumentKey2.securityType());
        assertThat(instrumentKey1.tenor()).isEqualTo(instrumentKey2.tenor());
        assertThat(instrumentKey1.settlementDate()).isEqualTo(instrumentKey2.settlementDate());
    }

    @Test
    public void instrumentId_for_ndf_matched_expected_attributes_and_symbol_has_special_chars_replaced_with_underscore() {
        final InstrumentKey instrumentKey1 = InstrumentKey.of("AUD+SD", SecurityType.FXNDF, LocalDate.of(2018, 12, 11));
        final InstrumentKey instrumentKey2 = InstrumentKey.of(instrumentKey1.instrumentId());

        assertThat(instrumentKey1).isEqualTo(instrumentKey2);
        assertThat(instrumentKey1.instrumentId()).isEqualTo(instrumentKey2.instrumentId());
        assertThat(instrumentKey1.symbol()).isEqualTo(instrumentKey2.symbol());
        assertThat(instrumentKey1.symbol()).isEqualTo("AUD_SD");
        assertThat(instrumentKey1.securityType()).isEqualTo(instrumentKey2.securityType());
        assertThat(instrumentKey1.tenor()).isEqualTo(instrumentKey2.tenor());
        assertThat(instrumentKey1.settlementDate()).isEqualTo(instrumentKey2.settlementDate());
    }

}