package com.anz.axle.acc.domain;


import org.joda.time.LocalDate;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

public class BusinessLocalDateTest {
    @Test
    public void test_business_date() {
        assertTrue(new BusinessLocalDate(new LocalDate(2010, 11, 3)).isBusinessDay());
        assertFalse(new BusinessLocalDate(new LocalDate(2010, 11, 6)).isBusinessDay());
        assertFalse(new BusinessLocalDate(new LocalDate(2010, 11, 7)).isBusinessDay());
    }

    @Test
    public void test_roll_back_business_days() {
        BusinessLocalDate start = new BusinessLocalDate(new LocalDate(2011, 1, 27));
        BusinessLocalDate end = start.rollBack(10);
        assertEquals(new LocalDate(2011, 1, 13), end.getDate());
    }

    @Test
    public void test_roll_forward_business_days() {
        BusinessLocalDate start = new BusinessLocalDate(new LocalDate(2011, 1, 27));
        BusinessLocalDate end = start.rollForward(10);
        assertEquals(new LocalDate(2011, 2, 10), end.getDate());
    }
}
