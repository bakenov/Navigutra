package com.anz.markets.prophet.pricer.firewall;

import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBook;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBookImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

import static com.anz.markets.prophet.pricer.firewall.ArbitrageProtectionFirewallTest.createMarketDataWith;

public class PricingFirewallManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        TestStubConsumer<ClientPrice> testStubConsumer = new TestStubConsumer<>();
        NotifierDefault notifierDefault = new NotifierDefault<ClientPrice>().register(new TestStubConsumer<>());
        DataRegisters dataRegisters = new DataRegisters();
        private Consumer<MidRate> consumerOfMarketData;
        private Consumer<ClientPrice> consumerOfClientPrice;
        private ClientPrice clientPrice;
        private MidRate marketData;

        @Setup
        public void setup() throws IOException {
            marketData = createMarketDataWith(1.001, 1.002);
            clientPrice = ArbitrageProtectionFirewallTest.createClientPriceWith(1.003, 1.004);
            PricingFirewallManager pricingFirewallManager = PricingFirewallManagerTest.pricingFirewallManager(notifierDefault,dataRegisters);
            consumerOfMarketData = pricingFirewallManager.consumerOfReferenceMidRate();
            consumerOfClientPrice = pricingFirewallManager.consumerClientPrice();
        }
    }

    @Benchmark
    public long acceptMarketData_and_ClientPrice(@NotNull final Data data) throws Exception {

        AggregatedBookImpl aggBook = new AggregatedBookImpl(data.marketData.getMarket(), data.marketData.getInstrument());
        aggBook.aggregateBook((FilteredMarketDataSnapshotImpl)data.marketData);
        data.consumerOfMarketData.accept(aggBook);
        data.consumerOfClientPrice.accept(data.clientPrice);
        return data.testStubConsumer.getEvents().size();
    }
}
