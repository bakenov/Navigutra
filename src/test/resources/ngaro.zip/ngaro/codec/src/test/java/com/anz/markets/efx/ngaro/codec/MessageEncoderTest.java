package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * Unit test for static and default methods in {@link MessageEncoder}.
 */
@RunWith(MockitoJUnitRunner.class)
public class MessageEncoderTest {

    @Mock
    private Consumer<String> messageConsumer;

    private static class MyFactory implements MessageEncoder.Factory<String, MessageEncoder<?>> {
        @Override
        public MessageEncoder<?> create(final Supplier<? extends Consumer<? super String>> messageConsumerSupplier) {
            Objects.requireNonNull(messageConsumerSupplier);
            @SuppressWarnings("unchecked")//ok here as we are not really using the step anywhere
            final MessageEncoder<?> encoderFirstStep = mock(MessageEncoder.class);
            return encoderFirstStep;
        }
    }

    @Test
    public void factory_create_by_consumer() {
        final MessageEncoder<?> encoder = new MyFactory().create(messageConsumer);
        assertNotNull("encoder should not be null", encoder);
    }

    @Test
    public void factory_create_by_supplier() {
        final MessageEncoder<?> encoder = new MyFactory().create(() -> messageConsumer);
        assertNotNull("encoder should not be null", encoder);
    }

    @Test(expected = NullPointerException.class)
    public void factory_create_null_consumer() {
        new MyFactory().create((Consumer<? super String>) null);
    }

}