package software.chronicle;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog.ReadWrite;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author Jerry Shea.
 */
public class StartAndSendOrders {

    static {

        ClassAliasPool.CLASS_ALIASES.addAlias(ClientMessageNotifier.class,
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                LoggingMode.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                ConsumerToChronicleQueue.class,
                ReadWrite.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main(String[] args) throws Exception {

        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port", "host1.port");

        ExecutorService executorService = Executors.newFixedThreadPool(2);
        // reads incoming and outgoing messages and constructs order stats.
        // This could also be done in a separate process
        OrderStatsReader orderStatsReader = new OrderStatsReader();
        executorService.submit(new FixLogReader(orderStatsReader));
        // drop copy listener
        ChronicleFixEngine dropCopy = fixEngineCfg.createInstance(3);
        DropCopyReader dropCopyReader = new DropCopyReader(dropCopy.sessions().iterator().next());
        executorService.submit(new FixLogReader(dropCopyReader));

        try (final Closeable ignored = fixEngineCfg.createInstance(1)) {

            try (final ChronicleFixEngine initiator = fixEngineCfg.createInstance(2)) {

                ClientMessageNotifier clientMessageNotifier = (ClientMessageNotifier) initiator.sessions().iterator().next().messageNotifier();

                while (clientMessageNotifier.queue().size() < ClientMessageNotifier.ORDERS)
                    Thread.sleep(1000);
            }
        }

        Thread.sleep(100);
        System.out.println(orderStatsReader.toString());
        executorService.shutdownNow();
    }
}

