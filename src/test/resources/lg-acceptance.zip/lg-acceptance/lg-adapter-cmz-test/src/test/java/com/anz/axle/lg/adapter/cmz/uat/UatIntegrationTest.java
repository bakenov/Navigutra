package com.anz.axle.lg.adapter.cmz.uat;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.cmz.acceptance.AcceptanceConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

@Category(UatTest.class)
public class UatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatIntegrationTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("CADJPY", SecurityType.FXSPOT, Tenor.SP);


    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
            StringUtils.parseMap(
                "appName:lg-cmz" +
                ",cmz.fix.log.destination:STDOUT" +
                ",cmz.fix.trading.reset.on.logon:Y" +
                ",cmz.fix.trading.reset.on.logout:Y" +
                ",cmz.fix.trading.reset.on.disconnect:Y" +
                ",cmz.fix.pricing.sendercompid:ANZMD2" +
                ",cmz.fix.pricing.targetcompid:COBAFXMD" +
                ",cmz.fix.pricing.host:daxa019z.unix.anz" +
                ",cmz.fix.pricing.port:19000" +
                ",cmz.fix.trading.sendercompid:ANZORD2" +
                ",cmz.fix.trading.targetcompid:COBAFXORD" +
                ",cmz.fix.trading.host:daxa019z.unix.anz" +
                ",cmz.fix.trading.port:19000" +
                ",cmz.fix.account:ANZBANK2"
            ));

        application = new Application("lg-cmz-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_receive_price_placeOrder_receive_ExecutionReport() throws Exception {

        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lg-cmz"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.CMZ))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().anyMatches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(30, TimeUnit.SECONDS);

        System.out.println(message);
        System.out.println("==============================================================");

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                    final SnapshotFullRefresh.Entry firstEntry = snapshotFullRefresh.entries.get(0);

                    final NewOrderSingle newOrderSingle = new NewOrderSingle();
                    newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
                    newOrderSingle.body.timeInForce = TimeInForce.FOK;
                    newOrderSingle.body.messageId = 1;
                    newOrderSingle.body.orderQty = firstEntry.mdEntrySize;
                    newOrderSingle.body.clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
                    newOrderSingle.body.currency = INSTRUMENT_KEY.symbol().substring(0, 3);
                    newOrderSingle.body.ordType = OrderType.PREVIOUSLY_QUOTED;
                    newOrderSingle.body.quoteId = firstEntry.quoteEntryId + "";
                    newOrderSingle.body.price = firstEntry.mdEntryPx;
                    newOrderSingle.body.securityType = SecurityType.FXSPOT;
                    newOrderSingle.body.senderCompId = "AU:lg-acc";
                    newOrderSingle.body.settlCurrency = newOrderSingle.body.currency;
                    newOrderSingle.body.side = firstEntry.mdEntryType == EntryType.OFFER ? Side.BUY : Side.SELL;
                    newOrderSingle.body.symbol = INSTRUMENT_KEY.symbol();
                    newOrderSingle.body.securityType = INSTRUMENT_KEY.securityType();
                    newOrderSingle.body.settlType = INSTRUMENT_KEY.tenor();
                    newOrderSingle.parties.add(new Party(PartyRole.SETTLEMENT_ACCOUNT, "Test Account"));
                    newOrderSingle.parties.add(new Party(PartyRole.ORDER_ORIGINATION_TRADER, "anton"));
                    newOrderSingle.parties.add(new Party(PartyRole.TRADING_SUB_ACCOUNT, "44564"));

                    System.out.println(newOrderSingle.toString());
                    System.out.println("==============================================================");

                    acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
                }
        });

        final List<TradingMessage> tradingResponses = Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-cmz"))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(TimeInForce.FOK))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CMZ.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(OrderType.LIMIT))
                        .body().matches(ExecutionReportMatcher.side().eq(Side.SELL))
                        .parties().atIndex(0).matches(ExecutionReportMatcher.partyRole().eq(PartyRole.SETTLEMENT_ACCOUNT))
                        .parties().atIndex(0).matches(ExecutionReportMatcher.partyId().eq("Test Account"))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetAll(30, TimeUnit.SECONDS);

        System.out.println("tradingResponses: "+ tradingResponses);
        System.out.println("==============================================================");
    }
}