package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.OrderCancelRejectSbeDecoder;

public class ChildOrderCancelRejectCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChildOrderCancelRejectCommand.class);

    private final ChildOrderRepository childOrderRepository;
    private final CommandContext commandContext;

    private final OrderCancelRejectSbeDecoder orderCancelRejectDecoder = new OrderCancelRejectSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public ChildOrderCancelRejectCommand(final ChildOrderRepository childOrderRepository,
                                         final CommandContext commandContext) {
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!orderCancelRejectDecoder.wrap(message)) return false;

        logMessage();

        //FIXME in adapters OrderCancelReject must provide marketId
        //then verify that this is a venue order cancel reject
        final long childOrigClOrdId = orderCancelRejectDecoder.body().origClOrdId().decodeLongOrZero();

        if (childOrigClOrdId > 0) {
            final ChildOrder childOrder = childOrderRepository.lookupByClOrdId(childOrigClOrdId);
            if (childOrder != null) {
                childOrder.parentOrder().onChildOrderCancelReject(commandContext, orderCancelRejectDecoder);
            } else {
                LOGGER.error("Could not find child order by clOrdId {}", childOrigClOrdId);
            }
        } else {
            LOGGER.error("OrderCancelReject must provide clOrdId");
        }
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        orderCancelRejectDecoder.appendTo(stringBuilder);
        LOGGER.info("Action child OCRJ: {}", stringBuilder);
    }
}
