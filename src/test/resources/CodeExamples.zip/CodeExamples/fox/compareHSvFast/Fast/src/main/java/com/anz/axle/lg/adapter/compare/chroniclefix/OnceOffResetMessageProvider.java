package com.anz.axle.lg.adapter.fast.chroniclefix;

import java.nio.ByteBuffer;
import java.util.Objects;

import org.jetbrains.annotations.NotNull;

import net.openhft.chronicle.bytes.Bytes;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.messages.Logon;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.VanillaSessionMessageProvider;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.messages.FixMessage;

public class OnceOffResetMessageProvider extends VanillaSessionMessageProvider {
    private boolean firstTime = true;
    private final FixSessionCfg fixSessionCfg;

    public OnceOffResetMessageProvider(final FixSessionCfg fixSessionCfg) {
        this.fixSessionCfg = Objects.requireNonNull(fixSessionCfg);
    }

    @Override
    public Logon getLogon(@NotNull final Bytes<ByteBuffer> bytes, @NotNull final FixSessionContext context, @NotNull final SessionID sessionID, final long heartbeatInterval, final char resetSeqNumFlag) {
        final Logon logon = super.getLogon(bytes, context, sessionID, heartbeatInterval); // doesn't matter whether you create a DefaultLogon or call super.getLogon now
        if (firstTime) {
            logon.resetSeqNumFlag('Y');
            fixSessionCfg.msgSequenceHandler().resetToInitialState();
            firstTime = false;
        } else {
            if (resetSeqNumFlag != FixMessage.UNSET_CHAR) {
                logon.resetSeqNumFlag(resetSeqNumFlag);
            }
        }
        return logon;
    }
}
