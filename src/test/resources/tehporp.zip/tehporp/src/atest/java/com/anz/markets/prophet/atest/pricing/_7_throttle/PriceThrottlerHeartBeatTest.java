package com.anz.markets.prophet.atest.pricing._7_throttle;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.framework.impl.TestDataDictionaryImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveSpeedUpByPositionHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.PricingModel;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.MINUTES;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class PriceThrottlerHeartBeatTest extends BaseAcceptanceSpecification {

    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setClientPriceThrottleConfigs(Lists.newArrayList(
                        clientPriceConfigHeartbeat(Market.WSP_A),
                        clientPriceConfigHeartbeat(Market.WSP_B),
                        clientPriceConfigHeartbeat(Market.WSP_C),
                        clientPriceConfigHeartbeat(Market.WSP_Z)
                ));
        return configuration;
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_8_2)
    @DisplayName("Should heart beat when no activity every 1 second - low frequency")
    @RestartBeforeTest(reason = "requires NO activity prior to test")
    public void testHeartBeatLowFrequency() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.70100, 0.00003));
        }
        then:
        {
            prophet.expect(ClientPrice.class, atLeast(1), isPublishable(Market.WSP_B));
            prophet.clearOutputBuffer();
        }
        when:
        {
            int secondsToWait = 6;
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(secondsToWait));
        }
        then:
        {
            LinkedList<ClientPrice> clientPriceList = prophet.expect(ClientPrice.class, atLeast(6), isPublishable(Market.WSP_B));

            // all prices are the same.  Also, ExternalEventTimeNS will be the same as the original client price
            for (int i = 0; i < clientPriceList.size() - 1; i++) {
                assertThat(clientPriceList.get(i), isClientPrice(clientPriceList.get(i + 1)));
                assertThat(clientPriceList.get(i).getExternalEventTimeNS(), CoreMatchers.is(clientPriceList.get(i + 1).getExternalEventTimeNS()));
            }
        }
    }

    @Test
    @Requirement(Requirement.Ref.PRICING_4_8_2)
    @DisplayName("Should heart beat when no significant movement every 1 second")
    public void testHeartBeatNoSignificantPriceMovement() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75000, 0.00003));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A));
            prophet.clearOutputBuffer();
        }
        when:
        {   // price movement is NOT significant.
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75001, 0.00003));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottled(Market.WSP_A));
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.incrementTime(900);
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.75001));
        }
    }

    @Test
    @DisplayName("When pricing model disabled, should publish indicative and cease heartbeat}")
    @RestartBeforeTest(reason = "requires NO activity prior to test")
    public void testHeartBeatStopWhenModelDisabled() {
        setup:
        {
            prophet.receive(setUpConfiguration());
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.70100, 0.00003));
            prophet.clearOutputBuffer();
        }
        when:
        {
            int secondsToWait = 6;
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(secondsToWait));
        }
        then:
        {
            LinkedList<ClientPrice> clientPriceList = prophet.expect(ClientPrice.class, atLeast(6), isPublishable(Market.WSP_B));

            // all prices are the same.  Also, ExternalEventTimeNS will be the same as the original client price
            for (int i = 0; i < clientPriceList.size() - 1; i++) {
                assertThat(clientPriceList.get(i), isClientPrice(clientPriceList.get(i + 1)));
                assertThat(clientPriceList.get(i).getExternalEventTimeNS(), CoreMatchers.is(clientPriceList.get(i + 1).getExternalEventTimeNS()));
            }
        }
        when:
        {
            prophet.clearOutputBuffer();

            final List<PricingModel> pricingModels = (tdd.configuration_pricing_base().getPricingModels());
            for (PricingModel p : pricingModels) {
                if (p.getMarket() == Market.WSP_B) {
                    ((PricingModelImpl) p).setEnabled(false);
                }
            }
            prophet.receive(tdd.configuration_pricing_base()
                    .setPricingModels(pricingModels)
            , false);
        }
        then:
        {
            // expect indicative prices
            LinkedList<ClientPrice> clientPriceList = prophet.expect(ClientPrice.class, atLeast(1), isPublishable(Market.WSP_B));
            for (ClientPrice cp : clientPriceList) {
                assertThat(cp.isBidOrOfferIndicative(), CoreMatchers.is(true));
            }
            prophet.clearOutputBuffer();
        }
        when:
        {
            int secondsToWait = 6;
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(secondsToWait));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isPublishable(Market.WSP_B));
        }
    }

    @Test
    @RestartBeforeTest(reason = "requires NO activity prior to test")
    // AXPROPHET-1112
    public void continueEmptyBookHeartbeatAUDUSD() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            // received market data that is stale
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.70100, 0.00003));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.AUDUSD));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class,  exactly(1), isPublishable(Market.WSP_A)).getLast();
            assertThat(cp.isEmpty(), is(true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1000);
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class,  exactly(1), isPublishable(Market.WSP_A)).getLast();
            assertThat(cp.isEmpty(), is(true));
        }
    }

    @Test
    // AXPROPHET-1112
    public void noEmptyBookHeartbeatNonAUDUSD() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            // received market data that is stale
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURUSD, 1.2500, 0.0004));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.EURUSD));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class,  exactly(1), isPublishable(Market.WSP_A)).getLast();
            assertThat(cp.isEmpty(), is(true));
        }
        when:
        // wait > default noActivityHeartbeat(20 seconds)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(21));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.EURUSD));
        }
    }


    private ClientPriceThrottleConfigImpl clientPriceConfigHeartbeat(final Market market) {
        return new ClientPriceThrottleConfigImpl(market, Currency.AUD, Currency.USD)
                .setNoActivityHeartbeatFrequencyMs(1000)
                .setLimit(1)
                .setTimePeriod(250)
                .setMinimumPriceDeltaFractionOfSpread(DONT_CARE_LARGE_DOUBLE)
                .setOverrideLimit(1)
                .setOverrideTimePeriod(100)
                .setOverrideMinimumPriceDeltaFractionOfMid(DONT_CARE_LARGE_DOUBLE);
    }
}
