package com.anz.markets.efx.fox.aggregator.config;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.markets.efx.fox.aggregator.core.PublicationRegistry;
import com.anz.markets.efx.fox.aggregator.core.TopicRegistry;
import com.anz.markets.efx.fox.pricing.subscription.config.VenueInstrumentConfig;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;

@Configuration
public class PricingPublicationConfig {
    private final static Logger LOGGER = LoggerFactory.getLogger(PricingPublicationConfig.class);

    private final PublicationRegistry publicationRegistry;
    private final String marketDataPublicationClassPath;
    private final TopicRegistry aggBookTopicRegistry;

    public PricingPublicationConfig(final PublicationRegistry publicationRegistry,
                                    final TopicRegistry aggBookTopicRegistry,
                                    final @Value("${publication.venue.instrument.config.class.path}") String marketDataPublicationClassPath) {
        this.publicationRegistry = Objects.requireNonNull(publicationRegistry);
        this.marketDataPublicationClassPath = Objects.requireNonNull(marketDataPublicationClassPath);
        this.aggBookTopicRegistry = Objects.requireNonNull(aggBookTopicRegistry);
    }

    @Bean
    @Resource
    public List<InstrumentKey> publishableInstruments() {
        final InputStream marketDataPublicationStream = this.getClass().getClassLoader().getResourceAsStream(marketDataPublicationClassPath);
        final VenueInstrumentConfig venueInstrumentConfig = VenueInstrumentConfig.yaml().load(marketDataPublicationStream);

        final List<InstrumentKey> publishableInstruments = new ArrayList<>();

        venueInstrumentConfig.getVenues().forEach((venue, securityTypeInstrumentGroups) -> {
            securityTypeInstrumentGroups.getSecurityTypes().forEach((securityType, instrumentGroups) -> {
                instrumentGroups.getInstrumentGroups().forEach(instrumentGroup -> {
                    instrumentGroup.getSymbols().forEach(symbol -> {
                        if (venue == Venue.FOX) {
                            publishableInstruments.add(InstrumentKey.of(symbol));
                        }
                    });
                });
            });
        });
        return publishableInstruments;
    }


    @PostConstruct
    public void start() {
        publishableInstruments().forEach(instrumentKey -> {
            final Topic topic = aggBookTopicRegistry.topic(Venue.FOX, instrumentKey);
            LOGGER.info("Registering publication for {}", topic);
            publicationRegistry.registerPublication(topic);
        });
    }
}
