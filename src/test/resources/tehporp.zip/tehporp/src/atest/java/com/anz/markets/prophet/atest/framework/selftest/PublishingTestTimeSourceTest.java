package com.anz.markets.prophet.atest.framework.selftest;

import com.anz.markets.prophet.atest.framework.impl.PublishingTestTimeSource;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.status.Context;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static org.junit.Assert.assertEquals;

public class PublishingTestTimeSourceTest {
    private static final long START_TIME_MS = 10_000;
    private PublishingTestTimeSource underTest = new PublishingTestTimeSource(START_TIME_MS);
    private CheckTimeStampOneSecondConsumer consumer = new CheckTimeStampOneSecondConsumer();
    private CheckTimeStampHourChimeConsumer hourChimeConsumer = new CheckTimeStampHourChimeConsumer();

    @Test
    public void testOneSecondPublish() {
        Context.set(new Context(underTest));

        underTest.setConsumerOneSecond(consumer);

        underTest.incrementMillis(400);
        assertEquals(0, consumer.received.size());

        underTest.incrementMillis(599);
        assertEquals(0, consumer.received.size());

        underTest.incrementMillis(1);
        assertEquals(1, consumer.received.size());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(START_TIME_MS + 1000), consumer.received.get(0).longValue());

        underTest.incrementMillis(1200);
        assertEquals(2, consumer.received.size());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(START_TIME_MS + 2000), consumer.received.get(1).longValue());

        underTest.incrementMillis(3500);
        assertEquals(5, consumer.received.size());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(START_TIME_MS + 3000), consumer.received.get(2).longValue());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(START_TIME_MS + 4000), consumer.received.get(3).longValue());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(START_TIME_MS + 5000), consumer.received.get(4).longValue());
    }

    @Test
    public void testHourChimePublish() {
        Context.set(new Context(underTest));

        underTest.setConsumerOneSecond(consumer);
        underTest.setConsumerHourChime(hourChimeConsumer);

        // one second before hour
        underTest.incrementMillis(TimeUnit.HOURS.toMillis(1) - TimeUnit.SECONDS.toMillis(1));
        assertEquals(0, hourChimeConsumer.received.size());

        // on one hour
        underTest.incrementMillis(TimeUnit.SECONDS.toMillis(1));
        assertEquals(1, hourChimeConsumer.received.size());

        // one second after hour.
        underTest.incrementMillis(TimeUnit.SECONDS.toMillis(1));
        assertEquals(1, hourChimeConsumer.received.size());

        // second hour
        underTest.incrementMillis(TimeUnit.HOURS.toMillis(1) - TimeUnit.SECONDS.toMillis(1));
        assertEquals(2, hourChimeConsumer.received.size());
    }

    private class CheckTimeStampOneSecondConsumer implements Consumer<OneSecond> {
        final List<Long> received = new ArrayList<>();

        @Override
        public void accept(final OneSecond oneSecond) {
            received.add(Context.context().timeSource().nowNanos());
        }
    }

    private class CheckTimeStampHourChimeConsumer implements Consumer<HourChime> {
        final List<Long> received = new ArrayList<>();

        @Override
        public void accept(final HourChime hourChime) {
            received.add(Context.context().timeSource().nowNanos());
        }
    }
}
