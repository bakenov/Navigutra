here=$(dirname $0)

# This command outputs monitoring data from a chronicle FIX monitor queue

# -wJSON says to use JSON Wire for output
# -s supresses output of index message
# -f like tail -f, waits forever and outputs new data as it arrives in the queue
# -d monitor tells the queue reader to look in "monitor" relative dir - the location of Chronicle FIX's monitor chronicle

$CHRONICLE_QUEUE_HOME/bin/queue_reader.sh -wJSON -s -f -l -d monitor >> ingest_splunk.json &

# separate output into 3 files for splunk to ingest
$here/tail_grep_wrap.sh Latency sl &
$here/tail_grep_wrap.sh NetworkStats nws &
$here/tail_grep_wrap.sh SessionInfo si &

wait $(jobs -p)