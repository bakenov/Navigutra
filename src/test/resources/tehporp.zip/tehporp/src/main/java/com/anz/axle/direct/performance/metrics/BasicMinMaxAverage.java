package com.anz.axle.direct.performance.metrics;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

// Sourced from the excellent com.anz.axle.direct.performance.metrics (SPDEE)

public class BasicMinMaxAverage implements Metric<BasicStats> {
    private final ReadWriteLock lock = new ReentrantReadWriteLock(false);
    private final String name;
    private long min;
    private long max;
    private long total;
    private long count;

    public BasicMinMaxAverage(final String name) {
        this.name = name;
        this.min = Long.MAX_VALUE;
        this.max = Long.MIN_VALUE;
        this.total = 0;
        this.count = 0;
    }

    @Override
    public void record(final long value) {
        lock.writeLock().lock();
        try {
            while (max < value) {
                max = value;
            }
            while (min > value) {
                min = value;
            }
            total += value;
            count++;
        } finally {
            lock.writeLock().unlock();
        }

    }

    @Override
    public BasicStats snapshot() {
        lock.readLock().lock();
        try {
            return new BasicStatsSnapshot(name, min, max, total, count);
        } finally {
            lock.readLock().unlock();
        }

    }

    @Override
    public void clear() {
        lock.writeLock().lock();
        this.min = Long.MAX_VALUE;
        this.max = Long.MIN_VALUE;
        this.total = 0;
        this.count = 0;
        lock.writeLock().unlock();

    }

    @Override
    public String getName() {
        return name;
    }

    private final class BasicStatsSnapshot implements BasicStats {
        private final long min;
        private final long max;
        private final long total;
        private final long count;
        private String name;

        private BasicStatsSnapshot(final String name,
                                   final long min,
                                   final long max,
                                   final long total,
                                   final long count) {
            this.name = name;
            this.min = min;
            this.max = max;
            this.total = total;
            this.count = count;
        }

        @Override
        public double getMin() {
            return count == 0 ? Double.NaN : min;
        }

        @Override
        public double getMean() {
            return count > 0 ? (double) total / count : Double.NaN;
        }

        @Override
        public double getMax() {
            return count == 0 ? Double.NaN : max;
        }

        @Override
        public long getCount() {
            return count;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return "BasicMinMaxAverageSnapshot" +
                    "name = '" + name + '\'' +
                    ", min = " + min +
                    ", max = " + max +
                    ", total = " + total +
                    ", count = " + count +
                    '}';
        }
    }
}
