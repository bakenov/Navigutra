package com.anz.markets.prophet.atest.framework;

// placeholder for junit 5 DisplayName, reverted to JUnit4 because of intellij issue running with both 4/5
public @interface DisplayName {
    String[] value() default "";
}
