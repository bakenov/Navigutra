package com.anz.markets.efx.fox.config;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.fox.firewall.rule.StaleOrderRule;
import com.anz.markets.efx.fox.firewall.state.CompositeFirewall;
import com.anz.markets.efx.fox.processor.command.FirewallErrorHandler;
import com.anz.markets.efx.fox.processor.command.AcceptedParentOrderConsumer;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidatorRepository;

@Configuration
public class FirewallsConfig {

    @Bean
    public OrderConsumer firewalledOrderConsumer(final ParentOrderRepository.WithInit parentOrderRepository,
                                                 final UserRepository userRepository,
                                                 final ParentOrderValidatorRepository parentOrderValidatorRepository) {
        return new AcceptedParentOrderConsumer(parentOrderRepository, userRepository, parentOrderValidatorRepository);
    }

    @Bean
    public OrderConsumer.ErrorHandler firewallErrorHandler() {
        return new FirewallErrorHandler();
    }

    @Bean
    public Firewall inboundFirewall(final UserRepository userRepository,
                                    final InstrumentRepository instrumentRepository,
                                    final OrderConsumer firewalledOrderConsumer,
                                    final OrderConsumer.ErrorHandler firewallErrorHandler,
                                    final @Value("${firewall.stale.order.timeout.millis:1000}") long staleOrderTimeoutMillis){
        return new CompositeFirewall("Inbound Order Firewalls",
                firewalledOrderConsumer,
                Firewall.customRules("Custom rules firewal",
                        firewallErrorHandler,
                        new StaleOrderRule(staleOrderTimeoutMillis)),
                Firewall.orderSubmitThroughput("Inbound Burst Submit Order Throughput",
                        userRepository,
                        firewallErrorHandler),
                Firewall.orderSubmitThroughput("Inbound Sustained Submit Order Throughput",
                        userRepository,
                        firewallErrorHandler),
                Firewall.orderTotalUsdQuantityThroughput("Inbound Total USD Quantity Throughput",
                        userRepository,
                        instrumentRepository,
                        firewallErrorHandler),
                Firewall.orderMaxQuantity("Inbound Order Max Quantity",
                        userRepository,
                        firewallErrorHandler),
                Firewall.liveOrders("Inbound Live Orders",
                        userRepository,
                        firewallErrorHandler)
                );
    }

}
