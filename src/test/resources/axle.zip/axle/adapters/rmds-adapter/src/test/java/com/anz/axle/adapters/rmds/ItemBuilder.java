package com.anz.axle.adapters.rmds;

import com.anz.axle.common.TestUtils;
import com.anz.axle.common.domain.Currency;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.datafabric.support.AbstractTestBuilder;
import com.anz.markets.adapters.trep.Item;

/**
 * Created with IntelliJ IDEA.
 * User: svonjan0
 * Date: 15/05/13
 * Time: 11:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class ItemBuilder extends AbstractTestBuilder<Item> {
    private Item entity;

    public ItemBuilder(String name) {
        entity = new Item();
        entity.setName(name);
    }

    public ItemBuilder(long i) {
        entity = new Item();
        String symbol = TestUtils.getAllSymbols()[(int) i % TestUtils.getAllSymbols().length];
        entity.setName(Currency.extractBaseCurrency(symbol) + (TestUtils.getTenors()[(int) i % TestUtils.getTenors().length]) + "=D3");
        withField("GV1_TEXT", CurrencyPair.toSymbolCompact(symbol));
        withField("GV1_DATE", "17 MAY 2013");
        withField("ASK", "-42.35");
        withField("BID", "-42.65");
        withField("GEN_TEXT16", "LIVE");
        withField("MATUR_DATE", "17 JUL 2013");
        withField("TIMACT", "02:42");
    }

    public ItemBuilder withField(String key, String value) {
        entity.getFields().put(key, value);
        return this;
    }

    public static ItemBuilder forSpot(final String id, final String symbol, final String spotDate) {
        return new ItemBuilder(id)
                .withField("GV1_DATE", spotDate)
                .withField("MATUR_DATE", spotDate)
                .withField("GV1_TEXT", symbol);
    }

    public Item build() {
        return entity;
    }
}
