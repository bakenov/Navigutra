package com.anz.markets.efx.ngaro.codec;

import java.util.function.Function;

import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;
import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;

/**
 * Decoder for string values.
 */
public interface StringDecoder {

    @Garbage(Garbage.Type.RESULT)
    String decodeStringOrNull();

    /** @return the target appendable */
    <A extends Appendable> A decodeTo(A target, int maxTargetLength);

    /** @return the length of the decoded string */
    <T> int decodeTo(T target, ByteWriter<? super T> writer, int targetOffset, int maxTargetLength);

    /**
     * Decodes a value and looks it up in the cache. The cached value is returned if present in the cache, otherwise
     * the decoded value is added to the cache and returned.
     *
     * @param cache cache for decoded values
     * @return null if empty; or a string from the cache (existing or newly cached) otherwise
     */
    @Garbage(value = Garbage.Type.RARE, description = "Garbage only possible if caching of a value causes eviction of another value due to a full cache")
    <T> T decodeAndCache(ByteValueCache<T> cache);

    long decodeLong(long defaultValue);

    default long decodeLongOrZero() {
        return decodeLong(0);
    }

    @Garbage(Garbage.Type.RESULT)
    default String decodeStringOrEmpty() {
        final String s = decodeStringOrNull();
        return s != null ? s : "";
    }

    /**
     * Decodes and transforms a value using the specified {@code transform}.
     *
     * @param transform a transformer from string decoder to result type
     * @return the transformed decoding result
     * @see EnumTransforms
     * @see EnumTransforms#toEnumOrNull(Class)
     */
    default <T> T decodeAndTransform(final Function<? super StringDecoder, T> transform) {
        return transform.apply(this);
    }

    /** @return the length of the decoded string */
    default int decodeToNull() {
        return decodeTo(null, ByteWriter.NULL);
    }

    /** @return the length of the decoded string */
    default int decodeTo(MutableAsciiString target, int maxTargetLength) {
        return decodeTo(target, ByteWriter.MUTABLE_ASCII_STRING, 0, maxTargetLength);
    }

    /** @return the target appendable */
    default <A extends Appendable> A decodeTo(final A target) {
        return decodeTo(target, Integer.MAX_VALUE);
    }

    /** @return the length of the decoded string */
    default <T> int decodeTo(final T target, final ByteWriter<? super T> writer) {
        return decodeTo(target, writer, 0, Integer.MAX_VALUE);
    }
}
