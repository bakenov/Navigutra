package com.anz.markets.efx.fox.acceptance.api;

public interface PropertyApplier {
    void    set(String key, String val);
    String  get(String key);
    void    rollback();
}
