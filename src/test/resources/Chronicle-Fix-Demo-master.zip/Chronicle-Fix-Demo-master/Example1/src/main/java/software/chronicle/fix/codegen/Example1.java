package software.chronicle.fix.codegen;

import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * @author Rob Austin.
 */
public class Example1 {

    public static void main(String[] args) throws Exception
    {
        new Example1().testTransform();
    }

    public void testTransform() throws Exception {
        // the sample fix message schema generator looks at these message and creates just down version
        // of the schema than will parse all the fields in these messages.

        String samples = "8=FIX.4.1\u00019=112\u000135=0\u000149=BRKR\u000156=INVMGR\u000134=235\u000152=19980604-07:58:28\u0001112=19980604-07:58:28\u000110=157\u0001\n" +
                "8=FIX.4.1\u00019=154\u000135=6\u000149=BRKR\u000156=INVMGR\u000134=236\u000152=19980604-07:58:48\u000123=115685\u000128=N\u000155=SPMI.MI\u000154=2\u000127=200000\u000144=10100.000000\u000125=H\u000110=159\u0001\n" +
                "8=FIX.4.1\u00019=90\u000135=0\u000149=INVMGR\u000156=BRKR\u000134=236\u000152=19980604-07:59:30\u000110=225\u0001\n" +
                "8=FIX.4.1\u00019=112\u000135=0\u000149=BRKR\u000156=INVMGR\u000134=237\u000152=19980604-07:59:48\u0001112=19980604-07:59:48\u000110=225\u0001\n" +
                "8=FIX.4.1\u00019=154\u000135=6\u000149=BRKR\u000156=INVMGR\u000134=238\u000152=19980604-07:59:56\u000123=115686\u000128=N\u000155=FIA.MI\u000154=2\u000127=250000\u000144=7900.000000\u000125=H\u000110=231\u0001\n" +
                "8=FIX.4.1\u00019=90\u000135=0\u000149=INVMGR\u000156=BRKR\u000134=237\u000152=19980604-08:00:31\u000110=203\u0001\n" +
                "8=FIX.4.1\u00019=154\u000135=6\u000149=BRKR\u000156=INVMGR\u000134=239\u000152=19980604-08:00:36\u000123=115687\u000128=N\u000155=PIRI.MI\u000154=1\u000127=300000\u000144=5950.000000\u000125=H\u000110=168\u0001\n" +
                "8=FIX.4.1\u00019=90\u000135=0\u000149=INVMGR\u000156=BRKR\u000134=238\u000152=19980604-08:01:31\u000110=026\u0001\n" +
                "8=FIX.4.1\u00019=112\u000135=0\u000149=BRKR\u000156=INVMGR\u000134=240\u000152=19980604-08:01:36\u0001112=19980604-08:01:36\u000110=190\u0001\n" +
                "8=FIX.4.1\u00019=90\u000135=0\u000149=INVMGR\u000156=BRKR\u000134=239\u000152=19980604-08:02:31\u000110=026\u0001\n" +
                "8=FIX.4.1\u00019=112\u000135=0\u000149=BRKR\u000156=INVMGR\u000134=241\u000152=19980604-08:02:36\u0001112=19980604-08:02:36\u000110=018\u0001\n" +
                "8=FIX.4.1\u00019=90\u000135=0\u000149=INVMGR\u000156=BRKR\u000134=240\u000152" +
                "=19980604-08:03:31\u000110=220\u0001";

        System.out.println( "Input FIX messages:\n" + samples );

        final Reader sampleFixMessage = new StringReader(samples);

        System.out.println("\nUsing FIX protocol schema file:\n" + Example1.class.getResource("/FIX41.xml").getFile());

        final Reader existingSchema = new InputStreamReader(Example1.class.getResourceAsStream("/FIX41.xml"));
        final QuickFixSchemaParser parser = QuickFixSchemaParser.loadFrom(existingSchema);
        SchemaParser transform = parser.transform(sampleFixMessage);

        final StringWriter out = new StringWriter(2024);
        transform.toXml(out);

        String result = out.toString().replace( "\r", "" );
        System.out.println( "\nGenerated FIX schema:\n" + result );

        final String expectedOptimizedSchema = "<fix major=\"4\" minor=\"1\">\n" +
                "    <header>\n" +
                "        <field name=\"BeginString\" required=\"Y\"/>\n" +
                "        <field name=\"BodyLength\" required=\"Y\"/>\n" +
                "        <field name=\"MsgType\" required=\"Y\"/>\n" +
                "        <field name=\"SenderCompID\" required=\"Y\"/>\n" +
                "        <field name=\"TargetCompID\" required=\"Y\"/>\n" +
                "        <field name=\"MsgSeqNum\" required=\"Y\"/>\n" +
                "        <field name=\"SendingTime\" required=\"Y\"/>\n" +
                "    </header>\n" +
                "    <trailer>\n" +
                "        <field name=\"CheckSum\" required=\"Y\"/>\n" +
                "    </trailer>\n" +
                "    <messages>\n" +
                "        <message name=\"IndicationofInterest\" msgtype=\"6\" msgcat=\"app\">\n" +
                "            <group name=\"NoIOIQualifiers\" required=\"N\">\n" +
                "                <field name=\"IOIQualifier\" required=\"N\"/>\n" +
                "            </group>\n" +
                "            <field name=\"IOIID\" required=\"Y\"/>\n" +
                "            <field name=\"IOITransType\" required=\"Y\"/>\n" +
                "            <field name=\"Symbol\" required=\"Y\"/>\n" +
                "            <field name=\"Side\" required=\"Y\"/>\n" +
                "            <field name=\"IOIShares\" required=\"Y\"/>\n" +
                "            <field name=\"Price\" required=\"N\"/>\n" +
                "            <field name=\"IOIQltyInd\" required=\"N\"/>\n" +
                "        </message>\n" +
                "        <message name=\"Heartbeat\" msgtype=\"0\" msgcat=\"admin\">\n" +
                "            <field name=\"TestReqID\" required=\"N\"/>\n" +
                "        </message>\n" +
                "    </messages>\n" +
                "    <fields>\n" +
                "        <field number=\"8\" name=\"BeginString\" type=\"STRING\"/>\n" +
                "        <field number=\"9\" name=\"BodyLength\" type=\"INT\"/>\n" +
                "        <field number=\"10\" name=\"CheckSum\" type=\"STRING\"/>\n" +
                "        <field number=\"23\" name=\"IOIID\" type=\"STRING\"/>\n" +
                "        <field number=\"25\" name=\"IOIQltyInd\" type=\"STRING\">\n" +
                "            <value enum=\"H\" description=\"HIGH\"/>\n" +
                "            <value enum=\"L\" description=\"LOW\"/>\n" +
                "            <value enum=\"M\" description=\"MEDIUM\"/>\n" +
                "        </field>\n" +
                "        <field number=\"27\" name=\"IOIShares\" type=\"STRING\"/>\n" +
                "        <field number=\"28\" name=\"IOITransType\" type=\"STRING\">\n" +
                "            <value enum=\"C\" description=\"CANCEL\"/>\n" +
                "            <value enum=\"N\" description=\"NEW\"/>\n" +
                "            <value enum=\"R\" description=\"REPLACE\"/>\n" +
                "        </field>\n" +
                "        <field number=\"34\" name=\"MsgSeqNum\" type=\"INT\"/>\n" +
                "        <field number=\"35\" name=\"MsgType\" type=\"STRING\">\n" +
                "            <value enum=\"0\" description=\"HEARTBEAT\"/>\n" +
                "            <value enum=\"1\" description=\"TEST_REQUEST\"/>\n" +
                "            <value enum=\"2\" description=\"RESEND_REQUEST\"/>\n" +
                "            <value enum=\"3\" description=\"REJECT\"/>\n" +
                "            <value enum=\"4\" description=\"SEQUENCE_RESET\"/>\n" +
                "            <value enum=\"5\" description=\"LOGOUT\"/>\n" +
                "            <value enum=\"6\" description=\"INDICATION_OF_INTEREST\"/>\n" +
                "            <value enum=\"7\" description=\"ADVERTISEMENT\"/>\n" +
                "            <value enum=\"8\" description=\"EXECUTION_REPORT\"/>\n" +
                "            <value enum=\"9\" description=\"ORDER_CANCEL_REJECT\"/>\n" +
                "            <value enum=\"A\" description=\"LOGON\"/>\n" +
                "            <value enum=\"B\" description=\"NEWS\"/>\n" +
                "            <value enum=\"C\" description=\"EMAIL\"/>\n" +
                "            <value enum=\"D\" description=\"ORDER_SINGLE\"/>\n" +
                "            <value enum=\"E\" description=\"ORDER_LIST\"/>\n" +
                "            <value enum=\"F\" description=\"ORDER_CANCEL_REQUEST\"/>\n" +
                "            <value enum=\"G\" description=\"ORDER_CANCEL\"/>\n" +
                "            <value enum=\"H\" description=\"ORDER_STATUS_REQUEST\"/>\n" +
                "            <value enum=\"J\" description=\"ALLOCATION\"/>\n" +
                "            <value enum=\"K\" description=\"LIST_CANCEL_REQUEST\"/>\n" +
                "            <value enum=\"L\" description=\"LIST_EXECUTE\"/>\n" +
                "            <value enum=\"M\" description=\"LIST_STATUS_REQUEST\"/>\n" +
                "            <value enum=\"N\" description=\"LIST_STATUS\"/>\n" +
                "            <value enum=\"P\" description=\"ALLOCATION_ACK\"/>\n" +
                "            <value enum=\"Q\" description=\"DONT_KNOW_TRADE\"/>\n" +
                "            <value enum=\"R\" description=\"QUOTE_REQUEST\"/>\n" +
                "            <value enum=\"S\" description=\"QUOTE\"/>\n" +
                "            <value enum=\"T\" description=\"SETTLEMENT_INSTRUCTIONS\"/>\n" +
                "        </field>\n" +
                "        <field number=\"44\" name=\"Price\" type=\"FLOAT\"/>\n" +
                "        <field number=\"49\" name=\"SenderCompID\" type=\"STRING\"/>\n" +
                "        <field number=\"52\" name=\"SendingTime\" type=\"TIME\"/>\n" +
                "        <field number=\"54\" name=\"Side\" type=\"STRING\">\n" +
                "            <value enum=\"1\" description=\"BUY\"/>\n" +
                "            <value enum=\"2\" description=\"SELL\"/>\n" +
                "            <value enum=\"3\" description=\"BUY_MINUS\"/>\n" +
                "            <value enum=\"4\" description=\"SELL_PLUS\"/>\n" +
                "            <value enum=\"5\" description=\"SELL_SHORT\"/>\n" +
                "            <value enum=\"6\" description=\"SELL_SHORT_EXEMPT\"/>\n" +
                "            <value enum=\"7\" description=\"D\"/>\n" +
                "            <value enum=\"8\" description=\"CROSS\"/>\n" +
                "        </field>\n" +
                "        <field number=\"55\" name=\"Symbol\" type=\"STRING\"/>\n" +
                "        <field number=\"56\" name=\"TargetCompID\" type=\"STRING\"/>\n" +
                "        <field number=\"112\" name=\"TestReqID\" type=\"STRING\"/>\n" +
                "    </fields>\n" +
                "</fix>\n";

        assert expectedOptimizedSchema.equals( result.toString().replace("\r", "") );
    }
}