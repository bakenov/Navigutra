package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoUserConfigHandler;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class UserConfig implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public UserConfig() {
        this(new MessageHeader(), new Body());
    }

    public UserConfig(final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
        if (body.userGroups == null) {
            body.userGroups = EnumSet.noneOf(UserGroup.class);
        }
    }

    public static final class Body {
        public String userName;
        public Set<UserGroup> userGroups;
        public String location;

        public Body() {
            super();
        }

        public Body(final String userName,
                    final Set<UserGroup> userGroups,
                    final String location) {
            this.userName = userName;
            this.userGroups = userGroups;
            this.location = location;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "userName=" + userName +
                    ", userGroups=" + userGroups +
                    ", location=" + location +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "UserConfig{" +
                "header=" + header +
                "body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.userConfig());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.userConfig().create(messageConsumer));
    }

    public void encode(final UserConfigEncoder encoder) {
        encoder.messageStart(header.source,header.sourceSeq)
                .userName().encode(body.userName)
                .userGroups().addAll(body.userGroups)
                .location().encode(body.location)
                .messageComplete();
    }

    public static <M> UserConfig decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoUserConfigHandler handler = new PojoUserConfigHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.userConfig().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onUserConfig(this);
    }
}
