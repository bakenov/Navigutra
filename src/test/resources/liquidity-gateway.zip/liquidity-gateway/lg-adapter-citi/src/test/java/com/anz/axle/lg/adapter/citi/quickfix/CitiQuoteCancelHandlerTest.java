package com.anz.axle.lg.adapter.citi.quickfix;

import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import quickfix.Message;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.FormattedTimeParser;
import com.anz.axle.lg.util.test.FixMessageFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CitiQuoteCancelHandlerTest {
    private static final String SENDER_COMP_ID = "GB:CITI";
    private static final String COMP_ID = "GB:lg-citi";
    private static final FormattedTimeParser FORMATTED_TIME_PARSER = new FormattedTimeParser();
    private static final long CURRENT_TIME = 34523453;
    private static final long MSG_SEQ_NUM = 4319;
    private static final String MSG_SEQ_NUM_STRING = "4319";
    private static final String SENDING_TIME_STRING = "20161129-06:23:35.982";
    private static final long SENDING_TIME_NANOS = FORMATTED_TIME_PARSER.parseNanos(SENDING_TIME_STRING);
    private static final String SYMBOL7 = "CAD/CHF";
    private static final String SYMBOL6 = "CADCHF";
    private static final SecurityType SECURITY_TYPE = SecurityType.FXSPOT;
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(SYMBOL6, SECURITY_TYPE, Tenor.SP);
    private static final String QUOTE_REQ_ID = "1234567";
    private static final int QUOTE_REQ_ID_INT = Integer.parseInt(QUOTE_REQ_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(QUOTE_REQ_ID);
    private MockitoPricingEncoder encoders = new MockitoPricingEncoder();
    private FixMessageFactory messageFactory;
    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderSupplier encoderSupplier = mock(PricingEncoderSupplier.class);
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    @Mock
    private Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private CitiQuoteCancelHandler citiQuoteCancelHandler;
    private InOrder inOrder;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    @Before
    public void setUp() throws Exception {
        citiQuoteCancelHandler = new CitiQuoteCancelHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, flagsAppender, sourceSequencer);
        messageFactory = new FixMessageFactory("/conf/FIX44-citi.xml");
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);
        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),


                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),
                encoders.messageEncoder);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY)).thenReturn(RequestKey.of(Venue.CITI, INSTRUMENT_KEY));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(QUOTE_REQ_ID_INT)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        when(marketDataSubscription.symbol()).thenReturn(SYMBOL7);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
    }

    @Test
    public void shouldProcessQuoteCancel() throws Exception {
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "Z",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CITI_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CITI_MD_S",
                "131=", QUOTE_REQ_ID,
                "117=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p",
                "298=", "1",
                "295=", "1",
                "55=", SYMBOL6,
                "10=", "33");
        //when
        citiQuoteCancelHandler.accept(snapshotMessage);

        //then
        verifyEmptySnapshot();
        verifyHops();
    }


    private void verifyEmptySnapshot() {

        inOrder.verify(encoders.snapshotBody).marketId(Venue.CITI);
        inOrder.verify(encoders.snapshotBody).instrumentId(INSTRUMENT_KEY.instrumentId());

        inOrder.verify(encoders.snapshotBody.senderCompId()).encode(COMP_ID);
        inOrder.verify(encoders.snapshotBody).messageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotBody).sendingTime(SENDING_TIME_NANOS);
        inOrder.verify(encoders.snapshotBody).entriesEmpty();
    }

    private void verifyHops() {
        inOrder.verify(encoders.snapshotHops).hopsStart(2);
        inOrder.verify(encoders.snapshotHops_next).next();
        inOrder.verify(encoders.snapshotHops_body.hopCompId()).encode(SENDER_COMP_ID);
        inOrder.verify(encoders.snapshotHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotHops_body).hopSendingTime(SENDING_TIME_NANOS);
        inOrder.verify(encoders.snapshotHops_body).next();
        inOrder.verify(encoders.snapshotHops_body.hopCompId()).encode(COMP_ID);
        inOrder.verify(encoders.snapshotHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotHops_body).hopReceivingTime(CURRENT_TIME);
        inOrder.verify(encoders.snapshotHops_body).hopSendingTime(CURRENT_TIME);
        inOrder.verify(encoders.snapshotHops_body).hopsComplete();
        inOrder.verify(encoders.messageEncoder).messageComplete();
    }
}