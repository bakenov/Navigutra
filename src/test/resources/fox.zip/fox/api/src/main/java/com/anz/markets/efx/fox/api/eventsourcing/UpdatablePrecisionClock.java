package com.anz.markets.efx.fox.api.eventsourcing;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.concurrent.TimeUnit;
import java.util.function.LongConsumer;

import com.anz.axle.microtime.PrecisionClock;

public class UpdatablePrecisionClock implements PrecisionClock, LongConsumer {
    private long currentTimeNanos;

    @Override
    public ZoneId getZone() {
        return ZoneId.systemDefault();
    }

    @Override
    public Clock withZone(final ZoneId zoneId) {
        return Clock.fixed(Instant.ofEpochMilli(TimeUnit.NANOSECONDS.toMillis(currentTimeNanos)), getZone());
    }

    @Override
    public long millis() {
        return TimeUnit.NANOSECONDS.toMillis(currentTimeNanos);
    }

    @Override
    public long micros() {
        return TimeUnit.NANOSECONDS.toMicros(currentTimeNanos);
    }

    @Override
    public long nanos() {
        return currentTimeNanos;
    }

    @Override
    public Instant instant() {
        return Instant.ofEpochMilli(TimeUnit.NANOSECONDS.toMillis(currentTimeNanos));
    }

    @Override
    public void accept(final long currentTimeNanos) {
        this.currentTimeNanos = currentTimeNanos;
    }
}
