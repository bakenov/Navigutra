/*
 * Copyright 2014-2018 Chronicle Software
 *
 * http://chronicle.software
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package software.chronicle.fix.warmupexample;

import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixInstance;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.QueueMsgSequenceHandler;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import static software.chronicle.fix.cfg.ConnectionType.initiator;

public class WarmedUpSessionTest {
    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(ClientMessageNotifier.class,
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                QueueMsgSequenceHandler.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                TimeUnit.class);
    }

    public static void cleanup() throws Exception {
        IOTools.deleteDirWithFiles("store", 10);
        IOTools.deleteDirWithFiles("log", 10);
        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");
    }

    public static void main(String[] args) throws Exception {
        cleanup();
        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config-example14.yaml");
        final FixSessionCfg initiatorFixConfig = fixEngineCfg.fixSessionCfgs().stream().filter(cfg -> cfg.connectionType() == initiator).findFirst().get();

        try (final Closeable ignored = FixInstance.fixEngineMain(1, fixEngineCfg)) {

            try (final ChronicleFixEngine client = FixInstance.fixEngineMain(2, fixEngineCfg)) {
                // logged in
                //LockSupport.park();
            }
        }
    }
}
