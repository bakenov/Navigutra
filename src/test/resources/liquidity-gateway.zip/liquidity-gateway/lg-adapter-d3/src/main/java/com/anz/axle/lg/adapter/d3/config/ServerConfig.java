package com.anz.axle.lg.adapter.d3.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Objects;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.lg.adapter.d3.StreamingServiceHealthChecker;
import com.anz.axle.lg.adapter.d3.newsubscription.SubscriptionRegistry;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
@Import({
        CommonConfig.class,
        TimerConfig.class,
        D3Config.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PublisherConfig.class,
        SubscriberConfig.class
})
public class ServerConfig {

    private SubscriptionRegistry subscriptionRegistry;
    private StreamingServiceHealthChecker streamingServiceHealthChecker;
    private Service serviceRequestEventLoop;
    private Service mainEventLoop;
    private Connection connection;
    private final ThreadPoolTaskScheduler timerTickScheduler;
    private final Runnable subscriptionLoader;

    public ServerConfig(
            final SubscriptionRegistry subscriptionRegistry,
            final StreamingServiceHealthChecker streamingServiceHealthChecker,
            final Service serviceRequestEventLoop,
            final Service mainEventLoop,
            final Connection connection,
            final ThreadPoolTaskScheduler timerTickScheduler,
            final Runnable subscriptionLoader) {
        this.subscriptionRegistry = Objects.requireNonNull(subscriptionRegistry);
        this.streamingServiceHealthChecker = Objects.requireNonNull(streamingServiceHealthChecker);
        this.serviceRequestEventLoop = Objects.requireNonNull(serviceRequestEventLoop);
        this.mainEventLoop = Objects.requireNonNull(mainEventLoop);
        this.timerTickScheduler = Objects.requireNonNull(timerTickScheduler);
        this.connection = Objects.requireNonNull(connection);
        this.subscriptionLoader = Objects.requireNonNull(subscriptionLoader);
    }

    @PostConstruct
    void start() {
        streamingServiceHealthChecker.start();
        mainEventLoop.start();
        serviceRequestEventLoop.start();
        subscriptionLoader.run();
    }

    @PreDestroy
    void stop() {
        timerTickScheduler.shutdown();
        streamingServiceHealthChecker.stop();
        subscriptionRegistry.submitStop();
        serviceRequestEventLoop.stop();
        mainEventLoop.stop();
        connection.close();
    }
}
