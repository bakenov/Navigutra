package com.anz.axle.adapters.rmds.consumer.filtering;

import com.anz.axle.adapters.rmds.consumer.D3ForwardQuote;
import com.anz.axle.common.util.Decision;
import com.google.common.base.Optional;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.format.ISOPeriodFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

/**
 * This class enforces the AXLE business rule of not pricing out beyond 2 years.
 *
 * The rule is enforced by stopping tenors that have more than two years
 * difference between the trade and the maturity date to make their way into the
 * fabric. See AX-4693 for more details.
 */
@Component
@ManagedResource(objectName = "axle.rmds-adaptor:name=MaturityFilter")
public final class MaturityFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(MaturityFilter.class);
    private static final Period MATURITY_LIMIT_PERIOD = Period.parse("P2Y1M", ISOPeriodFormat.standard());
    private static final Decision MATURITY_FILTER_FAILED_DECISION = Decision.no("rmds.update.filter.maturity.notpass");

    @Value("${filtering.maturity.skipFilter:false}")
    private boolean skipFilter;


    public Decision filter(final D3ForwardQuote item) {
        if (!skipFilter) {
            final Optional<LocalDate> optionalSpotDate = item.spotDate();
            if (!optionalSpotDate.isPresent()) {
                LOGGER.info("Not processing item as spot date is empty");
                return MATURITY_FILTER_FAILED_DECISION;
            }

            final Optional<LocalDate> optionalMaturityDate = item.maturityDate();
            if (!optionalMaturityDate.isPresent()) {
                LOGGER.info("Not processing item as maturity date is empty");
                return MATURITY_FILTER_FAILED_DECISION;
            }

            final LocalDate limitDate = optionalSpotDate.get().plus(MATURITY_LIMIT_PERIOD);
            if (optionalMaturityDate.get().isAfter(limitDate)) {
                LOGGER.info("Not processing item as maturity date breaches the configured limit. item[{}], limitDate[{}]", item, limitDate);
                return MATURITY_FILTER_FAILED_DECISION;
            }
        }

        return Decision.yes();
    }

    @ManagedAttribute
    public void setSkipFilter(final boolean skip) {
        this.skipFilter = skip;
    }


    @ManagedAttribute
    public boolean isSkipFilter() {
        return skipFilter;
    }

}
