package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.data.kdb.KDBSignalsBatchPublisher;
import com.anz.markets.prophet.domain.marketdata.impl.InstrumentAndMarketEnablementFilter;
import com.anz.markets.prophet.kdb.KDBPublisher;

public class KDBPublisherModule extends AbstractModule {

    private final KDBPublisher publisher;
    private final boolean synchronous;

    public KDBPublisherModule(KDBPublisher publisher, boolean synchronous) {
        this.publisher = publisher;
        this.synchronous = synchronous;
    }

    @Override
    public void sub(MessageBus messageBus) {
        final KDBSignalsBatchPublisher KDBSignalsBatchPublisher = new KDBSignalsBatchPublisher(publisher, synchronous, InstrumentAndMarketEnablementFilter.ANY);
        messageBus.sub(KDBSignalsBatchPublisher.consumeSignals(), Signals.class);
        messageBus.subAny(KDBSignalsBatchPublisher.consumerOfEvent());
    }

}
