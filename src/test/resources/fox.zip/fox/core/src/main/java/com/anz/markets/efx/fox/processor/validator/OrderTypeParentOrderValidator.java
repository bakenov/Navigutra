package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.state.OrderTextMessage;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderType;

import java.util.Objects;

public class OrderTypeParentOrderValidator implements ParentOrderValidator {
    private final OrderType[] allowedOrderTypes;
    private final ErrorHandler errorHandler;

    public OrderTypeParentOrderValidator(final ErrorHandler handler,
                                         final OrderType... orderTypes) {
        allowedOrderTypes = Objects.requireNonNull(orderTypes);
        errorHandler = Objects.requireNonNull(handler);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
        final OrderType orderType =  parentOrderDecoder.body().ordType();

        for(OrderType validType : allowedOrderTypes) {
            if (orderType.equals(validType))
                return true;
        }

        errorHandler.onError(OrderTextMessage.INVALID_ORDER_TYPE.getText(), parentOrderDecoder, commandContext);
        return false;
    }
}

