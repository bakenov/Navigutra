package com.anz.markets.prophet.config.app;

import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.chronicle.ChronicleLookupTableReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.ConsumerHedgingConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.business.ConfigReader;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeControlImpl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControlImpl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.HedgerFirewallResetImpl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import com.anz.markets.prophet.domain.impl.HedgePauseSignalImpl;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.order.impl.OrderEventImpl;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.pnl.ProfitAndLossImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.domain.time.SpotDateRollChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.event.EndEventAppenderReader;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.AdjustmentReader;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.AdjustmentsImpl;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.TradeReader;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.ValueAtRiskImpl;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.risk.realvol.RealisedVolatilityImpl;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;
import java.util.EnumMap;
import java.util.function.Consumer;

@Configuration
@Import({BusinessConfig.class, ConsumerHedgingConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class CoreHedgingConfig extends JmxConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(CoreHedgingConfig.class);

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.core:3}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    // chronicle in & out
    @Bean
    public ProphetPersister outboundChroniclePersister(
            @Value("${chronicle.hedger.out.path:./chronicle.hedger.out}") final String outboundChroniclePath,
            @Value("${chronicle.open.mode:APPEND}") final LegacyChroniclePersister.OpenMode openMode,
            @Value("${core.instance}") final byte coreInstance,
            @Value("${default.active.core.instance}") final int defaultActiveCoreInstance,
            @Value("${chronicle.out.activation:YES}") final ActivationAware activationMode) throws IOException {

        Context.instance(coreInstance);
        Context.stage(Stage.HEDGE);

        return ChroniclePersisterFactory.createCorePersister(outboundChroniclePath, openMode, activationMode, coreInstance == defaultActiveCoreInstance, Predicates.alwaysTrue());
    }

    // tell Main to run this in main thread
    @Bean(name = Main.RUNNER_BEAN)
    public ProphetReader chronicleReader(
            @Value("#{'${chronicle.core.hedger.in.path:./chronicle.out.conflated,./chronicle.out}'.split(',')}") final String[] chronicleInPaths,
            final ChronicleObjectReader configReader,
            final ChronicleObjectReader tradingTimeZoneChimeReader,
            final ChronicleObjectReader tradeReader,
            final ChronicleObjectReader adjustmentReader,
            final ChronicleObjectReader adjustmentsReader,
            final ChronicleObjectReader oneSecondReader,
            final ChronicleObjectReader hourChimeReader,
            final ChronicleObjectReader hedgeControlReader,
            final ChronicleObjectReader hedgeCurrencyControlReader,
            final ChronicleObjectReader econNewsReader,
            final ChronicleObjectReader orderEventReader,
            final ChronicleObjectReader marketDataSnapshotReader,
            final ChronicleObjectReader optimalPositionsReader,
            final ChronicleObjectReader valueAtRiskReader,
            final ChronicleObjectReader operatingHourChimeReader,
            final ChronicleObjectReader hedgerFirewallResetReader,
            final ChronicleObjectReader dealVolumeSignalReader,
            final ChronicleObjectReader profitAndLossReader,
            final ChronicleObjectReader positionsReader,
            final ChronicleObjectReader realisedVolatilityReader,
            final ChronicleObjectReader spotDateRollChimeReader,
            final ChronicleObjectReader endOfWeekChimeReader,
            final EndEventAppenderReader endEventAppenderReader,
            @Value("${chronicle.in.start.index}") final int startIndex,
            final ChronicleReaderGeneric<Activate> activationReader) throws IOException {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CONFIGURATION, configReader);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneChimeReader);
        map.put(MessageType.ADJUSTMENT, adjustmentReader);
        map.put(MessageType.ADJUSTMENTS, adjustmentsReader);
        map.put(MessageType.TRADE, tradeReader);
        map.put(MessageType.ONE_SECOND, oneSecondReader);
        map.put(MessageType.HOUR_CHIME, hourChimeReader);
        map.put(MessageType.ACTIVATE, activationReader);
        map.put(MessageType.HEDGE_CONTROL, hedgeControlReader);
        map.put(MessageType.HEDGE_CURRENCY_CONTROL, hedgeCurrencyControlReader);
        map.put(MessageType.ECONNEWS, econNewsReader);
        map.put(MessageType.ORDER_EVENT, orderEventReader);
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, marketDataSnapshotReader);
        map.put(MessageType.OPTIMAL_POSITIONS, optimalPositionsReader);
        map.put(MessageType.VALUE_AT_RISK, valueAtRiskReader);
        map.put(MessageType.OPERATING_HOUR_CHIME, operatingHourChimeReader);
        map.put(MessageType.HEDGER_FIREWALL_RESET, hedgerFirewallResetReader);
        map.put(MessageType.HEDGE_PAUSE_SIGNAL, dealVolumeSignalReader);
        map.put(MessageType.PROFIT_AND_LOSS, profitAndLossReader);
        map.put(MessageType.POSITIONS, positionsReader);
        map.put(MessageType.REALISED_VOLATILITY, realisedVolatilityReader);
        map.put(MessageType.SPOT_DATE_ROLL_CHIME, spotDateRollChimeReader);
        map.put(MessageType.END_OF_WEEK_CHIME, endOfWeekChimeReader);
        map.put(MessageType.END_EVENT, endEventAppenderReader);

        return ChronicleReaderFactory.createCoreReader(chronicleInPaths, startIndex, true, endEventAppenderReader, RingBuffer.NO_RING, map);
    }

    // chronicle readers. These deserialise their types from the inbound chronicle and pass on to their consumers

    @Bean
    public EndEventAppenderReader endEventAppenderReader(final ProphetPersister prophetPersister) {
        return new EndEventAppenderReader(prophetPersister.sink(MessageType.END_EVENT));
    }

    @Bean
    public ChronicleReaderGeneric<Activate> activationReader(
            @Qualifier("activateConsumers") final Consumer<Activate> activateConsumers) {
        return new ChronicleReaderGeneric<>(new Activate(), activateConsumers);
    }

    @Bean
    public ConfigReader configReader(final Consumer<ConfigurationData> configurationDataConsumer) {
        return new ConfigReader(new NotifierDefault<>(configurationDataConsumer));
    }

    @Bean
    public AdjustmentReader adjustmentReader(final Consumer<Adjustment> adjustmentConsumers) {
        return new AdjustmentReader(adjustmentConsumers);
    }

    @Bean
    public ChronicleReaderGeneric adjustmentsReader(final Consumer<Adjustments> adjustmentsConsumers) {
        return new ChronicleReaderGeneric(new AdjustmentsImpl(), adjustmentsConsumers);
    }

    @Bean
    public TradeReader tradeReader(final Consumer<Trade> tradeConsumer) {
        return new TradeReader(tradeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneChimeReader(
            final Consumer<TradingTimeZoneChime> tradingTimeZoneManager) {
        return new ChronicleReaderGeneric<>(TradingTimeZoneChime.INSTANCE, tradingTimeZoneManager);
    }

    @Bean
    public ChronicleReaderGeneric hedgeControlReader(final Consumer<HedgeControl> hedgeControlConsumer) {
        return new ChronicleReaderGeneric(new HedgeControlImpl(), hedgeControlConsumer);
    }

    @Bean
    public ChronicleReaderGeneric hedgeCurrencyControlReader(final Consumer<HedgeCurrencyControl> hedgeCurrencyControlConsumer) {
        return new ChronicleReaderGeneric(new HedgeCurrencyControlImpl(), hedgeCurrencyControlConsumer);
    }

    @Bean
    public ChronicleReaderGeneric econNewsReader(final Consumer<EconNews> econNewsConsumer) {
        return new ChronicleReaderGeneric(new EconNewsImpl(), econNewsConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> oneSecondReader(final Consumer<OneSecond> oneSecondConsumer) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, oneSecondConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<HourChime> hourChimeReader(final Consumer<HourChime> hourChimeConsumer) {
        return new ChronicleReaderGeneric<>(HourChime.INSTANCE, hourChimeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<EndOfWeekChime> endOfWeekChimeReader(final Consumer<EndOfWeekChime> endOfWeekChimeConsumer) {
        return new ChronicleReaderGeneric<>(EndOfWeekChime.INSTANCE, endOfWeekChimeConsumer);
    }

    @Bean
    public ChronicleObjectReader marketDataSnapshotReader(final Consumer<MarketDataSnapshot> marketDataConsumer,
                                                          final Consumer<MarketDataSnapshot> unskewedMidRateConsumer,
                                                          final Consumer<MarketDataSnapshot> allAggBookConsumer) {
        final Consumer<FilteredMarketDataSnapshot> consumer = fmds -> {
            if (fmds.getMarket().isInternalAgg()) {
                allAggBookConsumer.accept(fmds);
            }

            if (fmds.getMarket() == Market.WSP_U) {
                unskewedMidRateConsumer.accept(fmds);
            } else if (!fmds.getMarket().isInternalMarket()) {
                marketDataConsumer.accept(fmds);
            }
        };
        return new ChronicleLookupTableReader<>(FilteredMarketDataSnapshotImpl::forAggBook, consumer,
                FilteredMarketDataSnapshot::getInstrument,
                FilteredMarketDataSnapshot::getMarket,
                Instrument.class, Market.class);
    }

    @Bean
    public ChronicleObjectReader optimalPositionsReader(final Consumer<OptimalPositions> optimalPositionsConsumer) {
        return new ChronicleReaderGeneric<>(new OptimalPositions(), optimalPositionsConsumer);
    }

    @Bean
    public ChronicleObjectReader positionsReader(final Consumer<Positions> positionsConsumer) {
        return new ChronicleReaderGeneric<>(new Positions(), positionsConsumer);
    }

    @Bean
    public ChronicleObjectReader valueAtRiskReader(final Consumer<ValueAtRisk> valueAtRiskConsumer) {
        return new ChronicleReaderGeneric<>(new ValueAtRiskImpl(), valueAtRiskConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<OperatingHourChime> operatingHourChimeReader(
            final Consumer<OperatingHourChime> operatingHourChimeConsumer) {
        return new ChronicleReaderGeneric<>(new OperatingHourChime(), operatingHourChimeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<SpotDateRollChime> spotDateRollChimeReader(final Consumer<SpotDateRollChime> spotDateRollChimeConsumer) {
        return new ChronicleReaderGeneric<>(SpotDateRollChime.INSTANCE, spotDateRollChimeConsumer);
    }

    // chronicle persister consumers AKA sinks. These are the very last things in the consumer chain, and write to out chronicle
    @Bean
    public Consumer<Activate> activateSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ACTIVATE);
    }

    @Bean
    public Consumer<Order> orderSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sinkOrder();
    }

    @Bean
    public Consumer<IndexedConfigurationData> configurationSink(final ProphetPersister prophetPersister) {
        return configurationData -> prophetPersister.sink(MessageType.CONFIGURATION).accept(configurationData.getConfigurationData());
    }

    @Bean
    public Consumer<HedgeDecision> hedgeDecisionSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.HEDGE_DECISION);
    }

    @Bean
    public Consumer<HedgeStatus> hedgeStatusSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.HEDGE_STATUS);
    }

    @Bean
    public Consumer<HedgeCurrencyControl> hedgeCurrencyControlSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.HEDGE_CURRENCY_CONTROL);
    }

    @Bean
    public Consumer<HedgeFirewallStatus> hedgeFirewallStatusSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.HEDGE_FIREWALL_STATUS);
    }

    @Bean
    public Consumer<RiskPath> riskPathSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.RISK_PATH);
    }

    @Bean
    public Consumer<ProfitAndLoss> profitAndLossSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.PROFIT_AND_LOSS);
    }

    @Bean
    public ChronicleReaderGeneric<OrderEvent> orderEventReader(final Consumer<OrderEvent> orderEventConsumer) {
        return new ChronicleReaderGeneric<>(new OrderEventImpl(), orderEventConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<HedgerFirewallReset> hedgerFirewallResetReader(
            final Consumer<HedgerFirewallReset> hedgerFirewallResetConsumer) {
        return new ChronicleReaderGeneric<>(new HedgerFirewallResetImpl(), hedgerFirewallResetConsumer);
    }

    @Bean
    public ChronicleObjectReader dealVolumeSignalReader(final Consumer<HedgePauseSignal> dealVolumeSignalReaderConsumer) {
        return new ChronicleReaderGeneric<>(new HedgePauseSignalImpl(), dealVolumeSignalReaderConsumer);
    }

    @Bean
    public ChronicleObjectReader profitAndLossReader(final Consumer<ProfitAndLoss> profitAndLossConsumer) {
        return new ChronicleReaderGeneric<>(new ProfitAndLossImpl(), profitAndLossConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<RealisedVolatility> realisedVolatilityReader(final Consumer<RealisedVolatility> realisedVolatilityConsumer) {
        return new ChronicleReaderGeneric<>(new RealisedVolatilityImpl(), realisedVolatilityConsumer);
    }
}
