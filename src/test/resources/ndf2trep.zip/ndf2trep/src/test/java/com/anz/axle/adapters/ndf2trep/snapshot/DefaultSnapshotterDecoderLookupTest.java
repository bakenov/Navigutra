package com.anz.axle.adapters.ndf2trep.snapshot;

import java.util.function.Function;

import org.junit.Before;
import org.junit.Test;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.snapshot.state.ImmutableRequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

public class DefaultSnapshotterDecoderLookupTest {

    private DefaultSnapshotterDecoderLookup testObj;

    @Before
    public void before() {
        Function<RequestKey, SnapshotterDecoderSupplier> snapshotterDecoderSupplierFactory = requestKey -> mock(SnapshotterDecoderSupplier.class);

        testObj = new DefaultSnapshotterDecoderLookup(snapshotterDecoderSupplierFactory);
    }

    private RequestKey requestKey1 = new ImmutableRequestKey(Venue.BARX, InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP));
    private RequestKey requestKey2 = new ImmutableRequestKey(Venue.BARX, InstrumentKey.of("AUDUSD", SecurityType.FXNDF, Tenor.M1));

    @Test
    public void lookup() {
        testObj.lookup(requestKey1);
        testObj.lookup(requestKey2);

        assertEquals(2, testObj.snapshotterDecoderSuppliers().size());
    }

}