#!/bin/bash

echo "Cleaning data on orange correlator boxes"
scp clean-olddata-functions.sh AxlSv@daxa021z:/var/tmp
ssh AxlSv@daxa021z "/var/tmp/clean-olddata-functions.sh  clean_olddata_correlator"

scp clean-olddata-functions.sh AxlSv@daxa004z:/var/tmp
ssh AxlSv@daxa004z "/var/tmp/clean-olddata-functions.sh  clean_olddata_correlator"

scp clean-olddata-functions.sh axle@daxa026z:/var/tmp

echo "Cleaning data on orange proxy broker boxes"
scp clean-olddata-functions.sh AxlSv@daxa021z:/var/tmp
ssh AxlSv@daxa021z "/var/tmp/clean-olddata-functions.sh  clean_olddata_proxybroker"

scp clean-olddata-functions.sh AxlSv@daxa004z:/var/tmp
ssh AxlSv@daxa004z "/var/tmp/clean-olddata-functions.sh  clean_olddata_proxybroker"


