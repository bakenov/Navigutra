package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;

import org.agrona.DirectBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Topic;

public class Publisher implements MessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(Publisher.class);

    private final PublicationLookup publicationLookup;

    public Publisher(final PublicationLookup publicationLookup) {
        this.publicationLookup = Objects.requireNonNull(publicationLookup);
    }

    @Override
    public void onMessage(final Topic topic, final DirectBuffer buffer, final int offset, final int length, final long receiveTimeNanosSinceEpoch) {
        final Publication publication = publicationLookup.publication(topic);

        if (publication != null) {
            publication.publish(buffer, offset, length);
        } else {
            LOGGER.error("No publication for topic {}", topic);
        }
    }
}
