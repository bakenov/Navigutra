package com.anz.axle.lg.adapter.citi;

import java.util.Objects;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;

public class CitiMarketDataSubscription implements MarketDataSubscription {
    private static final int DEFAULT_MARKET_DEPTH = 0;
    private static final boolean DEFAULT_AGGREGATE_BOOK = false;
    private static final boolean DEFAULT_FULL_REFRESH = true;
    private static Venue venue;
    private final String symbol;
    private final InstrumentKey instrumentKey;
    private final StringToIntCache mdEntryIdCache;


    public CitiMarketDataSubscription(final String symbol, final StringToIntCache mdEntryIdCache) {
        this.symbol = Objects.requireNonNull(symbol);
        this.instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(symbol), SecurityType.FXSPOT, Tenor.SP);
        this.mdEntryIdCache = Objects.requireNonNull(mdEntryIdCache);
    }

    public static CitiMarketDataSubscription idAndSymbol(final Venue venue,
                                                         final String symbol,
                                                         final StringToIntCache mdEntryIdCache) {
        CitiMarketDataSubscription.venue = venue;
        return new CitiMarketDataSubscription(symbol, mdEntryIdCache);
    }

    @Override
    public long id() {
        return instrumentKey.instrumentId();
    }

    @Override
    public Venue market() {
        return venue;
    }

    @Override
    public String symbol() {
        return symbol;
    }

    @Override
    public InstrumentKey instrumentKey() {
        return instrumentKey;
    }

    @Override
    public boolean fullRefresh() {
        return DEFAULT_FULL_REFRESH;
    }

    @Override
    public boolean aggregateBook() {
        return DEFAULT_AGGREGATE_BOOK;
    }

    @Override
    public int marketDepth() {
        return DEFAULT_MARKET_DEPTH;
    }

    @Override
    public StringToIntCache stringToIntCache() {
        return mdEntryIdCache;
    }

    @Override
    public String toString() {
        return "CitiMarketDataSubscription{" +
                "id=" + id() +
                ", symbol='" + symbol + '\'' +
                ", instrumentKey=" + instrumentKey +
                '}';
    }
}
