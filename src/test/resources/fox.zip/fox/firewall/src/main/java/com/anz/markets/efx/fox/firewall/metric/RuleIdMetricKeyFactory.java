package com.anz.markets.efx.fox.firewall.metric;

import java.util.function.ToLongFunction;

import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;

public class RuleIdMetricKeyFactory implements ToLongFunction<FirewallConfigDecoder> {
    @Override
    public long applyAsLong(final FirewallConfigDecoder firewallConfig) {
        final FirewallConfigDecoder.Body body = firewallConfig.body();
        return -body.ruleId();
    }
}
