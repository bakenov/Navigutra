package com.anz.axle.adapters.ndf2trep.acceptance;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.ngaro.maths.DoubleTools;
import com.anz.markets.efx.ngaro.maths.Epsilon;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.adapters.ndf2trep.publisher.TrepQuote;
import com.anz.axle.applicationboot.Application;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.servicelifecycle.Awaitable;
import com.anz.markets.adapters.trep.Item;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test Setup:
 * Publish pojo snapshot to subscription
 * TopOfBook snapshot filter and forward to trep
 * Ndf2trep receive and publish to trep server
 * Subscribe to trep server to receive published quote and assert
 */
@RunWith(Spockito.class)
public class Ndf2TrepTopOfBookSnapshotPublishAndReceiveTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(Ndf2TrepTopOfBookSnapshotPublishAndReceiveTest.class);

    private Application application;
    private Queue<PricingMessage> messageQueue;
    private PrecisionClock precisionClock;

    private TestMessageProcessor testRateProcessor;
    private TrepRateSubscriber testTrepNdfSubscriber;

    @Before
    public void setup() throws Exception {

        System.setProperty("appName", "ndf2trep-acceptance");
        application = new Application("ndf2trep-acceptance", TestConfig.class);
        application.startAndAwaitStarted();

        final AnnotationConfigApplicationContext ctx = application.getApplicationContext();
        messageQueue = ctx.getBean("pricingMessageQueue", Queue.class);
        testRateProcessor = ctx.getBean("testRateProcessor", TestMessageProcessor.class);
        precisionClock = ctx.getBean("precisionClock", PrecisionClock.class);

        testTrepNdfSubscriber = ctx.getBean("testTrepNdfSubscriber", TrepRateSubscriber.class);
        testTrepNdfSubscriber.run();

        awaitTrepLogon();
    }

    @After
    public void afterEach() {
        testTrepNdfSubscriber.cleanup();
        application.stop();
    }

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_INDICATIVE = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   [LATENT]   |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 |  [DISABLED]  |    2      |   4          | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.2345  |        0.0           |     1e6     |  500000 |   []         |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 |   []         |    2      |   4          | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] TOP_OF_BOOK_SNAP_ENTRIES_INDICATIVE = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.2430  |        0.0           |     1e6     |  500000 |   [LATENT]   |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.2119  |        0.0001        |     2e6     |  800000 |  [DISABLED]  |    2      |   4          | 0                 |",
    });

    private static final SnapshotFullRefresh.Entry[] TOP_OF_BOOK_SNAP_ENTRIES = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|=============|===========|======================|=============|=========|==============|===========|==============|===================|",
            "|3155692600000 | EBS            |      BID    |   1.2430  |        0.0           |     1e6     |  500000 |   []         |    1      |   3          | 0                 |",
            "|3155692600000 | CNX            |     OFFER   |   1.2119  |        0.0001        |     2e6     |  800000 |   []         |    2      |   4          | 0                 |",
    });

    private static final Hop[] HOPS = Table.parse(Hop.class, new String[] {
            "|   hopCompId  | hopMessageId | hopReceivingTime | hopSendingTime |",
            "|==============|==============|==================|================|",
            "| GB:HopName:1 |   123456789  |    66655556666   |  66655557777   |",
            "| AU:HopName:2 |   123123123  |    66556655666   |  66556655777   |",
    });

    @Test
    @Spockito.Unroll({
            "|idx | senderCompId | messageId | possResend | sendingTime | origSendingTime | symbol | ricName |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|====|==============|===========|============|=============|=================|========|=========|===============|==========|============|===========|============|===================|===================|",
            "| 0  | GB:Sender:01 |    9876   |    false   |  1122334455 |    1122334000   | USDCNY | CN11M   |   FXNDF       | EBS      | 2016-01-14 |     M1    | 2016-01-16 |     2016-01-06    | []                |",
            "|----|--------------|-----------|------------|-------------|-----------------|--------|---------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void topOfBookSnapshotPriceIsPublishedToTrep_Indicative(
            final int idx, final String senderCompId, final long messageId, final boolean possResend,
            final long sendingTime, final long origSendingTime,
            final String symbol, final String ricName, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags) throws Exception {

        testRateProcessor.clear();

        // publish snapshot1 for Subscription
        for(SnapshotFullRefresh.Entry e : SNAP_ENTRIES_INDICATIVE) {
            e.transactTime = precisionClock.nanos();
        }

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType),
                        marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                SNAP_ENTRIES_INDICATIVE, HOPS);


        // publish topOfBooksnapshot with better price for Subscription
        for(SnapshotFullRefresh.Entry e : TOP_OF_BOOK_SNAP_ENTRIES_INDICATIVE) {
            e.transactTime = precisionClock.nanos();
        }

        final SnapshotFullRefresh topOfBooksnapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime,InstrumentKey.instrumentId(symbol, securityType, settlType),
                        marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                TOP_OF_BOOK_SNAP_ENTRIES_INDICATIVE, HOPS);

        // expected to receive these quotes
        final TrepQuote expectedTrepQuote = buildTrepQuote(topOfBooksnapshot, ricName, true);

        // start test/send quotes from UM
        messageQueue.add(snapshot);
        messageQueue.add(topOfBooksnapshot);

        LOGGER.info("Checking receiver for: " + expectedTrepQuote);

        final Item latestUpdate = getLatestUpdateForService(expectedTrepQuote);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received>" + latestUpdate +" expected> "+expectedTrepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(expectedTrepQuote).isNotNull().as("Expected TrepQuote");
        assertThat(latestUpdate.getName()).isEqualTo(expectedTrepQuote.getName()).as("ServiceName");
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), expectedTrepQuote.getBid(), Double.valueOf(latestUpdate.getValue("BID")).doubleValue()));
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), expectedTrepQuote.getAsk(), Double.valueOf(latestUpdate.getValue("ASK")).doubleValue()));
        assertThat(latestUpdate.getValue("GEN_TEXT16")).isEqualTo(expectedTrepQuote.getQuoteType().getDisplay()).as("GEN_TEXT16");
    }

    @Test
    @Spockito.Unroll({
            "|idx | senderCompId | messageId | possResend | sendingTime | origSendingTime | symbol | ricName |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|====|==============|===========|============|=============|=================|========|=========|===============|==========|============|===========|============|===================|===================|",
            "| 0  | GB:Sender:01 |    9876   |    false   |  1122334455 |    1122334000   | USDCNY | CN11M   |   FXNDF       | EBS      | 2016-01-14 |     M1    | 2016-01-16 |     2016-01-06    | []                |",
            "|----|--------------|-----------|------------|-------------|-----------------|--------|---------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void topOfBookSnapshotPriceIsPublishedToTrep(
            final int idx, final String senderCompId, final long messageId, final boolean possResend,
            final long sendingTime, final long origSendingTime,
            final String symbol, final String ricName, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags) throws Exception {

        testRateProcessor.clear();

        // publish snapshot1 for Subscription
        for(SnapshotFullRefresh.Entry e : SNAP_ENTRIES) {
            e.transactTime = precisionClock.nanos();
        }

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType),
                        marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                SNAP_ENTRIES, HOPS);


        // publish topOfBooksnapshot with better price for Subscription
        for(SnapshotFullRefresh.Entry e : TOP_OF_BOOK_SNAP_ENTRIES) {
            e.transactTime = precisionClock.nanos();
        }

        final SnapshotFullRefresh topOfBooksnapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType),
                        marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                TOP_OF_BOOK_SNAP_ENTRIES, HOPS);

        // expected to receive these quotes
        final TrepQuote expectedTrepQuote = buildTrepQuote(topOfBooksnapshot, ricName, false);

        // start test/send quotes from UM
        messageQueue.add(snapshot);
        messageQueue.add(topOfBooksnapshot);

        LOGGER.info("Checking receiver for: " + expectedTrepQuote);

        final Item latestUpdate = getLatestUpdateForService(expectedTrepQuote);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received>" + latestUpdate +" expected> "+expectedTrepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(expectedTrepQuote).isNotNull().as("Expected TrepQuote");
        assertThat(latestUpdate.getName()).isEqualTo(expectedTrepQuote.getName()).as("ServiceName");
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), expectedTrepQuote.getBid(), Double.valueOf(latestUpdate.getValue("BID")).doubleValue()));
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), expectedTrepQuote.getAsk(), Double.valueOf(latestUpdate.getValue("ASK")).doubleValue()));
        assertThat(latestUpdate.getValue("GEN_TEXT16")).isEqualTo(expectedTrepQuote.getQuoteType().getDisplay()).as("GEN_TEXT16");
    }

    private static final IncrementalRefresh.Entry[] INC_ENTRIES = Table.parse(IncrementalRefresh.Entry.class, new String[] {
            "| transactTime | mdUpdateAction |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryFlags | mdEntryId | mdEntryRefId | quoteEntryId | mdEntryPositionNo |",
            "|==============|================|================|=============|===========|======================|=============|=========|==============|===========|==============|==============|===================|",
            "|      121     |       NEW      | EBS            |      BID    |   1.2145  |        0.0           |     1e6     |  500000 |   [LATENT]   |    1      |      1       |      3       | 0                 |",
            "|      131     |       NEW      | RFX            |     OFFER   |   1.2120  |        0.0001        |     2e6     |  800000 |  [DISABLED]  |    2      |      2       |      4       | 0                 |",
            "|      141     |      CHANGE    | CNX            |      BID    |   1.2145  |        0.0           |     2e6     |  800000 |      []      |    1      |      1       |      5       | 0                 |",
            "|      151     |      DELETE    | RFX            |     OFFER   |   1.2120  |        0.0001        |     2e6     |  800000 |  [DISABLED]  |    2      |      2       |      4       | 0                 |",
    });

    @Test
    @Spockito.Unroll({
            "|idx | senderCompId | messageId | possResend | sendingTime | origSendingTime | symbol | ricName |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           | mdEntryPositionNo |",
            "|====|==============|===========|============|=============|=================|========|=========|===============|==========|============|===========|============|===================|===================|===================|",
            "| 0  | GB:Sender:01 |    9876   |    false   |  1122334455 |    1122334000   | USDCNY | CN11M   |   FXNDF       | EBS      | 2016-01-14 |     M1    | 2016-01-16 |     2016-01-06    | []                | 0                 |",
            "|----|--------------|-----------|------------|-------------|-----------------|--------|---------|---------------|----------|------------|-----------|------------|-------------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void snapshotAndIncrementIsPublishedToTrep(
            final int idx, final String senderCompId, final long messageId, final boolean possResend,
            final long sendingTime, final long origSendingTime,
            final String symbol, final String ricName, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags) throws Exception {

        testRateProcessor.clear();

        // publish snapshot1 for Subscription
        SnapshotFullRefresh.Entry bidEntry = SNAP_ENTRIES[0];
        bidEntry.transactTime = System.nanoTime();
        SnapshotFullRefresh.Entry askEntry = SNAP_ENTRIES[1];
        askEntry.transactTime = System.nanoTime();

        final SnapshotFullRefresh snapshot1 = PricingMessage.snapshotFullRefresh(
                new MessageHeader(),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, sendingTime, origSendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType),
                        marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                SNAP_ENTRIES_INDICATIVE, HOPS);

        messageQueue.add(snapshot1);

        //given
        for(IncrementalRefresh.Entry e : INC_ENTRIES) {
            e.transactTime = precisionClock.nanos();
        }
        final IncrementalRefresh increment = PricingMessage.incrementalRefresh(
                new MessageHeader(),
                new IncrementalRefresh.Body(senderCompId, messageId, sendingTime, InstrumentKey.instrumentId(symbol, securityType, settlType), marketId,
                        tradeDate, settlDate, referenceSpotDate, mdFlags),
                INC_ENTRIES, HOPS);

        messageQueue.add(increment);

        // expect change BID and deleted ASK from INC_ENTRIES
        final TrepQuote expectedTrepQuote = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(ricName+"=AXLE_DEV-AUTOTEST")
                .updateBid(1.2145,1)
                .build();

        LOGGER.info("Checking receiver for: " + expectedTrepQuote);
        final Item latestUpdate = getLatestUpdateForService(expectedTrepQuote);

        LOGGER.info("assertReceivedItemMatchSentTrepQuote: received>" + latestUpdate +" expected> "+expectedTrepQuote);

        assertThat(latestUpdate).isNotNull().as("Item not found/received");
        assertThat(expectedTrepQuote).isNotNull().as("Expected TrepQuote");
        assertThat(latestUpdate.getName()).isEqualTo(expectedTrepQuote.getName()).as("ServiceName");
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), expectedTrepQuote.getBid(), Double.valueOf(latestUpdate.getValue("BID")).doubleValue()));
        assertThat(DoubleTools.equalsEpsilon(Epsilon.EPS_1eNegative7.getValue(), expectedTrepQuote.getAsk(), Double.valueOf(latestUpdate.getValue("ASK")).doubleValue()));
        assertThat(latestUpdate.getValue("GEN_TEXT16")).isEqualTo(expectedTrepQuote.getQuoteType().getDisplay()).as("GEN_TEXT16");
    }

    private void awaitTrepLogon() throws Exception {
        final Awaitable trepLogonAwaitable = application.getApplicationContext().getBean("trepLogonServiceLifecycle", Awaitable.class);
        trepLogonAwaitable.awaitStarted(10, TimeUnit.SECONDS);
        LOGGER.info("trepLogonAwaitable.awaitStarted");
    }

    private Item getLatestUpdateForService(final TrepQuote trepQuote) throws InterruptedException {
        LOGGER.info("getLatestUpdateForService()    trepQuote={}   testRateProcessor.hashCode()={}", trepQuote, testRateProcessor.hashCode());
        Item latestUpdate = null;
        for (int i = 0; i < 15; i++) {
            latestUpdate = testRateProcessor.getLatestRateForRIC();
            if (latestUpdate!=null && latestUpdate.getName().equals(trepQuote.getName()) && Double.valueOf(latestUpdate.getValue("BID")).equals(trepQuote.getBid()) ) {
                return latestUpdate;
            } else {
                LOGGER.info("Skipping latest rate polled from subscription: " + latestUpdate);
                TimeUnit.MILLISECONDS.sleep(10);
            }
        }
        return latestUpdate;
    }

    private TrepQuote buildTrepQuote(final SnapshotFullRefresh snapshot, final String ricName, final boolean isIndicative) {
        TrepQuote.Builder builder = new TrepQuote.Builder().serviceName("AXLE_DEV-AUTOTEST").ricName(ricName+"=AXLE_DEV-AUTOTEST");
        snapshot.entries.forEach((entry) -> {
            switch (entry.mdEntryType) {
                case BID:
                    builder.updateBid(entry.mdEntryPx,1);
                    break;
                case OFFER:
                    builder.updateOffer(entry.mdEntryPx,1);
                    break;
            }
        });
        return builder.isIndicative(isIndicative).build();
    }
}
