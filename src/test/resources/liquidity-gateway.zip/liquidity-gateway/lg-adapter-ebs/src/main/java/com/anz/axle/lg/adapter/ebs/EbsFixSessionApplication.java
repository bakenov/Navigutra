package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataIncrementalRefresh;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataRequestReject;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MessageNotifier;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.OrderCancelReject;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradeCaptureReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradingSessionList;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradingSessionStatus;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;

import java.util.Objects;

public class EbsFixSessionApplication extends FixSessionApplication implements MessageNotifier {

    private static final Logger LOGGER = LoggerFactory.getLogger(EbsFixSessionApplication.class);

    private final ChronicleMessageHandler<UserResponse> userResponseHandler;
    private final ChronicleMessageHandler<MarketDataIncrementalRefresh> incrementalRefreshHandler;
    private final ChronicleMessageHandler<MarketDataSnapshotFullRefresh> snapshotFullRefreshHandler;
    private final ChronicleMessageHandler<MarketDataRequestReject> marketDataRequestRejectHandler;
    private final ChronicleMessageHandler<OrderCancelReject> orderCancelRejectHandler;
    private final ChronicleMessageHandler<TradingSessionList> tradingSessionListHandler;
    private final ChronicleMessageHandler<TradingSessionStatus> tradingSessionStatusHandler;
    final EbsExecutionReportMergeHandler ebsFillExecutionReportHandler;

    public EbsFixSessionApplication(final ChronicleMessageHandler<UserResponse> userResponseHandler,
                                    final ChronicleMessageHandler<MarketDataIncrementalRefresh> incrementalRefreshHandler,
                                    final ChronicleMessageHandler<MarketDataSnapshotFullRefresh> snapshotFullRefreshHandler,
                                    final ChronicleMessageHandler<MarketDataRequestReject> marketDataRequestRejectHandler,
                                    final ChronicleMessageHandler<OrderCancelReject> orderCancelRejectHandler,
                                    final ChronicleMessageHandler<TradingSessionList> tradingSessionListHandler,
                                    final ChronicleMessageHandler<TradingSessionStatus> tradingSessionStatusHandler,
                                    final EbsExecutionReportMergeHandler ebsFillExecutionReportHandler,
                                    final ApplicationLogonHandler applicationLogonHandler) {
        super(Objects.requireNonNull(applicationLogonHandler));
        this.userResponseHandler = Objects.requireNonNull(userResponseHandler);
        this.incrementalRefreshHandler = Objects.requireNonNull(incrementalRefreshHandler);
        this.snapshotFullRefreshHandler = Objects.requireNonNull(snapshotFullRefreshHandler);
        this.marketDataRequestRejectHandler = Objects.requireNonNull(marketDataRequestRejectHandler);
        this.orderCancelRejectHandler = Objects.requireNonNull(orderCancelRejectHandler);
        this.tradingSessionListHandler = Objects.requireNonNull(tradingSessionListHandler);
        this.tradingSessionStatusHandler = Objects.requireNonNull(tradingSessionStatusHandler);
        this.ebsFillExecutionReportHandler = Objects.requireNonNull(ebsFillExecutionReportHandler);
    }

    @Override
    public void onUserResponse(final FixSessionHandler session, final UserResponse userResponse) {
        userResponseHandler.accept(userResponse);
    }

    @Override
    public void onMarketDataRequestReject(final FixSessionHandler session, final MarketDataRequestReject marketDataRequestReject) {
        marketDataRequestRejectHandler.accept(marketDataRequestReject);
    }

    @Override
    public void onMarketDataSnapshotFullRefresh(final FixSessionHandler session, final MarketDataSnapshotFullRefresh marketDataSnapshotFullRefresh) {
        snapshotFullRefreshHandler.accept(marketDataSnapshotFullRefresh);
    }

    @Override
    public void onMarketDataIncrementalRefresh(final FixSessionHandler session, final MarketDataIncrementalRefresh marketDataIncrementalRefresh) {
        incrementalRefreshHandler.accept(marketDataIncrementalRefresh);
    }

    @Override
    public void onExecutionReport(final FixSessionHandler session, final ExecutionReport executionReport) {
        ebsFillExecutionReportHandler.onExecutionReport(executionReport);
    }

    @Override
    public void onTradingSessionList(final FixSessionHandler session, final TradingSessionList tradingSessionList) {
        tradingSessionListHandler.accept(tradingSessionList);
    }

    @Override
    public void onTradingSessionStatus(final FixSessionHandler session, final TradingSessionStatus tradingSessionStatus) {
        tradingSessionStatusHandler.accept(tradingSessionStatus);
    }

    @Override
    public void onOrderCancelReject(final FixSessionHandler session, final OrderCancelReject orderCancelReject) {
        LOGGER.info("Receive: {}", orderCancelReject);
        orderCancelRejectHandler.accept(orderCancelReject);
    }

    @Override
    public void onSentReject(final SessionID sessionID, final Reject reject) {
        LOGGER.warn("Session {} Sending Reject: {}", sessionID, reject);
    }

    @Override
    public void onTradeCaptureReport(final FixSessionHandler session, final TradeCaptureReport tradeCaptureReport) {
        ebsFillExecutionReportHandler.onTradeCaptureReport(tradeCaptureReport);
    }
}
