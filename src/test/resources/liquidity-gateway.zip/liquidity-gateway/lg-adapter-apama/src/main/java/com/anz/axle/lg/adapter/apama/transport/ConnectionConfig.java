package com.anz.axle.lg.adapter.apama.transport;

import java.util.Collections;
import java.util.Map;

import com.anz.markets.efx.ngaro.api.Venue;

public interface ConnectionConfig {
    Venue venue();
    String host();
    int port();
    int connectionPollingInterval();
    String channelName();
    /** See {@link com.apama.services.event.ChannelConfig} */
    default Map<String,Object> channelConfig() {
        return Collections.emptyMap();
    }
}
