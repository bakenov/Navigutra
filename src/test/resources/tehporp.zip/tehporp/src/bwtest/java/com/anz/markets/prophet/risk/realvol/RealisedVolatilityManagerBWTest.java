package com.anz.markets.prophet.risk.realvol;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.impl.MidRateImpl;
import com.anz.markets.prophet.status.Context;
import org.junit.Test;

import java.util.function.Consumer;

import static com.anz.markets.prophet.risk.realvol.RealisedVolatilityCalculateTest.SAMPLES;
import static com.anz.markets.prophet.risk.realvol.RealisedVolatilityCalculateTest.SAMPLES_DEFAULT;

public class RealisedVolatilityManagerBWTest {
    private static final int REPS = 100_000;
    public static final int THRESHOLD = 513;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private final Consumer<MidRate> consumerMidRate;
    private NoOpConsumer<RealisedVolatility> consumerRealisedVolatility;
    private MidRateImpl midRateAUDUSD, midRateUSDJPY;
    private int counter = 0;

    public RealisedVolatilityManagerBWTest() {
        Context.region(Region.GB);
        consumerRealisedVolatility = new NoOpConsumer<>();
        final RealisedVolatilityManager realisedVolatilityManager = RealisedVolatilityManagerTest.createRealisedVolatilityManager(consumerRealisedVolatility.asList(), SAMPLES_DEFAULT, false);
        consumerMidRate = realisedVolatilityManager.consumerOfMarketData();
        midRateAUDUSD = MidRateTestHelper.createMidRate(Instrument.AUDUSD, 0.75000);
        midRateUSDJPY = MidRateTestHelper.createMidRate(Instrument.USDJPY, 104);
    }

    @Test
    public void testAcceptChangedMidRate() {
        helper.testAllocationNotExceeded(
                () -> acceptChangedMidRate(),
                REPS, REPS,
                THRESHOLD
        );
    }

    public void acceptChangedMidRate() {
        mutateRate(midRateAUDUSD);
        consumerMidRate.accept(midRateAUDUSD);
        mutateRate(midRateUSDJPY);
        consumerMidRate.accept(midRateUSDJPY);
        if (consumerRealisedVolatility.size() < (counter - SAMPLES)) {
            throw new AssertionError("did not publish");
        }
        ++counter;
    }

    private void mutateRate(final MidRateImpl midRate) {
        // change the rate a lot to force publish
        midRate.setRate(midRate.getMidRate() + (Math.random() - 0.5d));
    }
}
