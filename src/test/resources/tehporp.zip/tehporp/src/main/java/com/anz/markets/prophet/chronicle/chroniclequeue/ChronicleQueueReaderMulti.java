package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.ReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.tools.ToolsCommon;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.util.SystemProperties;
import com.google.common.base.Throwables;
import net.openhft.chronicle.threads.Pauser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Coordinates multiple ChronicleReaders to read from multiple chronicles ensuring that only one is open
 * at a time, and we never re-read an event i.e. we read up to eventId X from chronicle N and then when
 * we switch to chronicle N+1, we start reading events from X+1
 **/
public class ChronicleQueueReaderMulti implements ProphetReader {
    protected static final Logger LOGGER = LogManager.getLogger(ChronicleQueueReaderMulti.class);
    private final String[] chronicleInPaths;
    private final ReaderConfig baseConfig;
    private volatile ChronicleQueueReader activeCQReader;
    private volatile boolean closed = false;
    private long previousRbReadPosition;

    private ChronicleQueueReaderMulti(final String[] chronicleInPaths,
                                      final ReaderConfig baseConfig) {
        GcFriendlyAssert.isTrue(chronicleInPaths.length < 3, "needs more work for > 2");
        this.chronicleInPaths = chronicleInPaths;
        this.baseConfig = baseConfig;
    }

    @Override
    public void run() {
        try {
            final boolean rb = baseConfig.ringBuffer().enabled();
            final ReaderConfig config = ReaderConfigBuilder.create(baseConfig).withWaitStrategy(WaitStrategy.STOP_ON_STALL).withRingBuffer(RingBuffer.NO_RING).build();
            activeCQReader = new ChronicleQueueReader(chronicleInPaths[0], config);
            activeCQReader.run();
            activeCQReader.close();
            activeCQReader = null;

            if (!closed) {
                final long lastEventId = Context.context().header().getEventId();
                final WaitStrategy waitStrategy = rb ? new WaitStrategyRB() : WaitStrategy.LOG_START_MESSAGE;
                final ReaderConfig secondConfig = ReaderConfigBuilder.create(baseConfig)
                        // seek to same eventId that we are currently at then...
                        .withStartAt(StartAt.EVENTID)
                        .withStartPosition(lastEventId)
                        .withWaitStrategy(waitStrategy)
                        .withRingBuffer(RingBuffer.NO_RING)
                        // ...set the filter to ignore that eventId and start at the next one. This ensures that we "hand off" at exactly the same eventid
                        .withHeaderFilter(new ToolsCommon.EventIdPredicate(new ToolsCommon.Range(lastEventId), true, false))
                        .build();

                activeCQReader = new ChronicleQueueReader(chronicleInPaths[1], secondConfig);
                activeCQReader.run();
                activeCQReader.close();
                activeCQReader = null;
            }

            if (!closed && rb) {
                final long lastEventId = Context.context().header().getEventId();
                LOGGER.info("Handing over to RB lastEventId {}", lastEventId);
                final ReaderConfig thirdConfig = ReaderConfigBuilder.create(baseConfig)
                        .withStartAt(StartAt.INDEX)
                        .withStartPosition(previousRbReadPosition)
                        .withWaitStrategy(WaitStrategy.LOG_START_MESSAGE)
                        // ...set the filter to ignore the previous eventId and start at the next one. This ensures that we "hand off" at exactly the same eventid
                        .withHeaderFilter(new ToolsCommon.EventIdPredicate(new ToolsCommon.Range(lastEventId), true, false))
                        .build();
                activeCQReader = new ChronicleQueueReader(chronicleInPaths[1], thirdConfig);
                activeCQReader.run();
                activeCQReader.close();
                activeCQReader = null;
            }

        } catch (Throwable e) {
            LOGGER.error("Could not run MultiReader", e);
            throw Throwables.propagate(e);
        }
    }

    @Override
    public void close() {
        LOGGER.info("Closing");
        this.closed = true;
        if (activeCQReader != null) {
            activeCQReader.close();
        }
    }

    public static ProphetReader create(final String[] chronicleInPaths,
                                       final ReaderConfig baseConfig) {
        if (chronicleInPaths.length == 1) {
            return new ChronicleQueueReader(chronicleInPaths[0], baseConfig);
        } else {
            return new ChronicleQueueReaderMulti(chronicleInPaths, baseConfig);
        }
    }

    private class WaitStrategyRB implements WaitStrategy {
        private long stopAtMillis;

        @Override
        public void onTailerStalled(final Pauser pauser) {
            if (stopAtMillis == 0) {
                stopAtMillis = System.currentTimeMillis() + SystemProperties.CQ_RING_BUFFER_STALL_WAIT_MILLIS;

                final ReaderConfig thirdConfig = ReaderConfigBuilder.create(baseConfig).build();
                try (ChronicleQueueReader rbReader = new ChronicleQueueReader(chronicleInPaths[1], thirdConfig)) {
                    previousRbReadPosition = rbReader.getTailerIndex();
                }
                LOGGER.info("Drainer queue stalled. Got readPosition {} from RB", previousRbReadPosition);
            } else if (System.currentTimeMillis() > stopAtMillis) {
                LOGGER.info("Drainer queue stalled. Wait time elapsed. Stopping.");
                WaitStrategy.STOP_ON_STALL.onTailerStalled(pauser);
            } else {
                pauser.pause();
            }
        }
    }
}
