package com.anz.markets.efx.ngaro.api;

import org.agrona.collections.Long2ObjectHashMap;

public class DefaultInstrumentKeyLookup implements InstrumentKey.Lookup {
    private final Long2ObjectHashMap<InstrumentKey> instrumentKeyMap = new Long2ObjectHashMap<>();

    @Override
    public InstrumentKey lookup(final long instrumentId) {
        return instrumentKeyMap.computeIfAbsent(instrumentId, InstrumentKey::of);
    }
}
