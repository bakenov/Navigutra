package com.anz.axle.lg.adapter.acceptance.utils;

import org.fix4j.test.integration.quickfix.QuickFixProperties;
import org.fix4j.test.session.ContextFactory;
import org.fix4j.test.session.FixConnectionMode;
import org.fix4j.test.session.FixSessionId;
import org.fix4j.test.session.MatchingSession;
import org.fix4j.test.session.SessionContext;
import org.fix4j.test.util.StringUtils;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.getRandomFreeLocalPort;

public class TradingFixSessionHelper {
    private static final int TRADING_FIX_PORT = 34011;
    private final String tradingSenderCompId;
    private final String tradingTargetCompId;
    private final String acceptorFixVersion;
    private final int port;

    public TradingFixSessionHelper(String appName, String tradingSenderCompId, String tradingTargetCompId, String acceptorFixVersion) {

        if (appName == null) throw new IllegalArgumentException("appName must not be null");

        final String useDefaultPort = System.getProperty("useDefaultPort");
        this.port = useDefaultPort == null ? getRandomFreeLocalPort() : TRADING_FIX_PORT;

        this.tradingSenderCompId = tradingSenderCompId;
        this.tradingTargetCompId = tradingTargetCompId;
        this.acceptorFixVersion = acceptorFixVersion;

        System.out.println("Trading Session on port: "+port);

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + appName +
                                "," + appName + ".fix.socket.use.ssl:N" +
                                "," + appName + ".fix.log.destination:STDOUT" +
                                "," + appName + ".fix.reconnectInterval:1" +
                                "," + appName + ".fix.sendercompid:" + tradingSenderCompId +
                                "," + appName + ".fix.targetcompid:" + tradingTargetCompId +
                                "," + appName + ".fix.host:localhost" +
                                "," + appName + ".fix.port:" + port+

                                "," + appName + ".fix.trading.sendercompid:" + tradingSenderCompId +
                                "," + appName + ".fix.trading.targetcompid:" + tradingTargetCompId +
                                "," + appName + ".fix.trading.reset.on.logon:Y" +
                                "," + appName + ".fix.trading.reset.on.logout:Y" +
                                "," + appName + ".fix.trading.reset.on.disconnect:Y" +
                                "," + appName + ".fix.trading.host:localhost" +
                                "," + appName + ".fix.trading.port:" + port+
                                "," + appName + ".fix.file.log.path:target/fix/log/" +
                                "," + appName + ".fix.file.store.path:target/fix/store/" +

                                ",fix4j.default.fix.msg.wait.timeout.ms:30000" +
                                ",fix4j.quickfix.use.data.dictionary:N"
                ));
    }

    public TradingFixSessionHelper(final String appName, final String tradingSenderCompId, final String tradingTargetCompId, final String acceptorFixVersion, final String dataDictionaryLocation) {
        this(appName,tradingSenderCompId, tradingTargetCompId, acceptorFixVersion);

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "fix4j.quickfix.data.dictionary:" + dataDictionaryLocation +
                                "," + QuickFixProperties.USE_DATA_DICTIONARY.getKey() + ":Y"
                ));
    }

    public MatchingSession createTradingSession() {
        final ContextFactory contextFactory = new FixAssertContextFactory(FixAssertQuickFixSessionFactory::new);

        SessionContext sessionContext = contextFactory.createSessionContext(
                new FixSessionId(acceptorFixVersion, tradingTargetCompId, tradingSenderCompId),
                FixConnectionMode.ACCEPTOR,
                StringUtils.parseMap("fix4j.quickfix.socket.accept.port:" + port));

        sessionContext.fixEngineSession.startup();

        return new CustomMatchingSession(sessionContext);
    }
}
