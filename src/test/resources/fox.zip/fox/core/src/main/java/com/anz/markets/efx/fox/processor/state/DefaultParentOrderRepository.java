package com.anz.markets.efx.fox.processor.state;

import java.util.Objects;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

public class DefaultParentOrderRepository implements ParentOrderRepository.WithInit {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultParentOrderRepository.class);

    private final ParentOrderFactory parentOrderFactory;
    private final Mutable parentOrderRepository;

    private final ByteValueCache<String> strategyNameCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> senderCompIdCache = new ByteValueCache<>(AsciiString::toString);

    public DefaultParentOrderRepository(final ParentOrderFactory parentOrderFactory,
                                        final Mutable parentOrderRepository) {
        this.parentOrderRepository = Objects.requireNonNull(parentOrderRepository);
        this.parentOrderFactory = Objects.requireNonNull(parentOrderFactory);
    }

    @Override
    public ParentOrder lookupByOrderId(final long orderId) {
        return parentOrderRepository.lookupByOrderId(orderId);
    }

    @Override
    public ParentOrder lookupByClOrderId(final String compId, final long clOrdId) {
        return parentOrderRepository.lookupByClOrderId(compId, clOrdId);
    }

    public ParentOrder init(final EventContext eventContext, final ExecutionReportDecoder executionReportDecoder) {
        final ParentOrder parentOrder = parentOrderFactory.create(executionReportDecoder.body().targetStrategyName().decodeAndCache(strategyNameCache));
        parentOrder.applyParentExecutionReport(eventContext, executionReportDecoder);
        final String compId = executionReportDecoder.body().targetCompId().decodeAndCache(senderCompIdCache);
        final long origClOrdId = executionReportDecoder.body().origClOrdId().decodeLongOrZero();
        final long orderId = executionReportDecoder.body().orderId().decodeLongOrZero();
        parentOrderRepository.add(orderId, parentOrder);
        parentOrderRepository.add(compId, origClOrdId, parentOrder);

        return parentOrder;
    }

    @Override
    public void forEach(final Consumer<? super ParentOrder> consumer) {
        parentOrderRepository.forEach(consumer);
    }
}
