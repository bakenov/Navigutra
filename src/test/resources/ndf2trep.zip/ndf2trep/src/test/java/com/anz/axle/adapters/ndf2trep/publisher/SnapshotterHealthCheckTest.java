package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.anz.axle.adapters.ndf2trep.snapshot.SnapshotterDecoderLookup;
import com.anz.axle.adapters.ndf2trep.snapshot.SnapshotterDecoderSupplier;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamDecoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SnapshotterHealthCheckTest {

    private static final Set<Flag> MISSED_HEARTBEAT = new HashSet<>(Arrays.asList(Flag.MISSED_HEARTBEAT));
    private SnapshotterHealthCheck healthCheckExecutor;
    private Snapshotter mockSnapshotter;
    private SnapshotterDecoderLookup snapshotterDecoderLookup;
    private PrecisionClock precisionClock;

    @Before
    public void beforeEach() {
        snapshotterDecoderLookup = mock(SnapshotterDecoderLookup.class);
        precisionClock = mock(PrecisionClock.class);
        mockSnapshotter = mock(Snapshotter.class);
        when(mockSnapshotter.sendingTimeNanosOfCurrentSnapshot()).thenReturn(TimeUnit.MILLISECONDS.toNanos(200L));

        SnapshotterDecoderSupplier supplier = new SnapshotterDecoderSupplier() {
            @Override
            public UpstreamDecoderConnector upstreamDecoderConnector() {
                return null;
            }
            @Override
            public Snapshotter snapshotter() {
                return mockSnapshotter;
            }
        };

        Collection<SnapshotterDecoderSupplier> suppliers = Arrays.asList(supplier);

        when(snapshotterDecoderLookup.snapshotterDecoderSuppliers()).thenReturn(suppliers);
        when(precisionClock.nanos()).thenReturn(TimeUnit.MILLISECONDS.toNanos(500L));
        healthCheckExecutor = new SnapshotterHealthCheck(100L, snapshotterDecoderLookup, precisionClock);
    }

    @Test
    public void testRunHealthChecks_clearBookAndForwardEmptySnapshot() throws Exception {

        healthCheckExecutor.run();

        ArgumentCaptor<Set<? extends Flag>> flags = ArgumentCaptor.forClass(Set.class);
        verify(mockSnapshotter, times(1)).clearBookAndForwardEmptySnapshot(flags.capture());
        assertThat(flags.getValue()).isEqualTo(MISSED_HEARTBEAT);
    }
}