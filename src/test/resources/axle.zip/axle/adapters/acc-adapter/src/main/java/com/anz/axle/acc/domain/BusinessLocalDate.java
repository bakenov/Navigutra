package com.anz.axle.acc.domain;

import org.joda.time.DateTimeConstants;
import org.joda.time.LocalDate;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 * Encapsulates business date identification and rolling
 * business days.
 *
 * This class is immutable.
 *
 * @author jonesr18
 */
public class BusinessLocalDate {
    private LocalDate theDate;

    public BusinessLocalDate(LocalDate date) {
        theDate = date;
    }

    public LocalDate getDate() {
        return theDate;
    }

    public boolean isBusinessDay() {
        return isBusinessDay(theDate);
    }

    private boolean isBusinessDay(LocalDate thisDate) {
        return thisDate.getDayOfWeek() != DateTimeConstants.SATURDAY
                && thisDate.getDayOfWeek() != DateTimeConstants.SUNDAY;
    }

    public BusinessLocalDate rollBack(int businessDays) {
        return roll(businessDays, false);
    }

    public BusinessLocalDate rollForward(int businessDays) {
        return roll(businessDays, true);
    }

    private BusinessLocalDate roll(int businessDays, boolean forward) {
        LocalDate start = theDate.plusDays(0);
        int counter = businessDays;
        while(counter > 0) {
            start = start.plusDays((forward ? 1 : -1));
            if(isBusinessDay(start)) {
                counter--;
            }
        }
        return new BusinessLocalDate(start);
    }
}
