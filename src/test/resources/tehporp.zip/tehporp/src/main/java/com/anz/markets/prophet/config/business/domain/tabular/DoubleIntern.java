package com.anz.markets.prophet.config.business.domain.tabular;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class DoubleIntern implements Serializable {

    private static final long serialVersionUID = 6510596310020518995L;

    public static final DoubleIntern NaN;

    private static final Map<Double, DoubleIntern> intern = new HashMap<>();

    private double x;

    public static DoubleIntern get(Double x) {
        return intern.computeIfAbsent(x, y -> new DoubleIntern(x));
    }

    private DoubleIntern(final double x) {
        this.x = x;
    }

    public final double get() {
        return x;
    }

    static {
        NaN = DoubleIntern.get(Double.NaN);
    }
}