package com.anz.markets.prophet.config.business.domain.tabular.hedging;

import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;

/**
 * Configuration for each hedger.
 */
public interface HedgePortfolioConfig extends ProphetMarshallable {
    HedgePortfolioConfig EMPTY = new HedgePortfolioConfigImpl();

    boolean isEnabled();

    Market getMarket();

    Portfolio getPortfolio();

    String getHedgerName();

    String getBookName();

    /**
     * Controls how many maximum open order each hedger is allowed to dispatch.
     * Note that this value is a different configuration point to the HedgeFirewallConfig MAXIMUM_ACTIVE_ORDER firewall type. If this value
     * is set lower than MAXIMUM_ACTIVE_ORDER firewall then the firewall will never be breached.
     */
    long getMaximumOpenOrders();

    double getMaximumOpenQuantity();

    long getMaximumOpenVarOrders();

    long getThrottleLimitNumberOrder();

    long getThrottleLimitTimePeriodMS();

    long getThrottleLimitRejectNumberOrder();

    long getThrottleLimitRejectTimePeriodMS();

    /**
     * Does not applies to aggressive hedger (IOC)
     */
    long getMinimumTimeToLiveMS();

    long getOrderUnknownTimeoutMS();

    long getCancelUnknownTimeoutMS();

    long getOrderCompleteTimeoutMS();

    OrderType getOrderType();

    TimeInForce getOrderTimeInForce();

    int getMaxNumberCancelRejects();

    int getOrderQuantityPrecision();
}
