package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Topic;

public class DefaultPublicationRegistry implements PublicationLookup, PublicationRegistry {

    private final Connection connection;
    private final EndPointStatusHandler endPointStatusHandler;
    private final ConcurrentMap<Topic, Publication> topicToPublication = new ConcurrentHashMap<>();

    public DefaultPublicationRegistry(final Connection connection,
                                      final EndPointStatusHandler endPointStatusHandler) {
        this.connection = Objects.requireNonNull(connection);
        this.endPointStatusHandler = Objects.requireNonNull(endPointStatusHandler);
    }

    @Override
    public Publication publication(final Topic topic) {
        return topicToPublication.get(topic);
    }

    @Override
    public void registerPublication(final Topic topic) {
        if (!topicToPublication.containsKey(topic)) {
            topicToPublication.put(topic, connection.openPublication(topic, endPointStatusHandler));
        }
    }
}
