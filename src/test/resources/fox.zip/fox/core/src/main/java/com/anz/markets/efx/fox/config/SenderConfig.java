package com.anz.markets.efx.fox.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.tools4j.eventsourcing.api.ExecutionQueue;
import org.tools4j.eventsourcing.api.IndexPredicate;
import org.tools4j.eventsourcing.api.MessageConsumer;
import org.tools4j.eventsourcing.api.Poller;
import org.tools4j.eventsourcing.common.PayloadBufferPoller;
import org.tools4j.eventsourcing.common.PollingProcessStep;
import org.tools4j.mmap.region.impl.OS;
import org.tools4j.nobark.loop.Step;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.fox.common.MessageConsumerToDecoderAdapterViaByteBuffer;
import com.anz.markets.efx.fox.metric.Metric;
import com.anz.markets.efx.fox.sender.NewOrderSingleRouter;
import com.anz.markets.efx.fox.sender.OrderCancelRequestRouter;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoderBuilder;

@Configuration
public class SenderConfig {
    private static final long POLLER_LOW_RESULTION_CLOCK_CORRECTION = OS.ifWindows(50_000_000, 0);

    @Bean
    public Connection senderConnection(final Transport transport) {
        return transport.openConnection(() -> {
        });
    }

    @Bean
    public MessageDecoder<SbeMessage> tradingResponsePublishingDecoder(final Connection senderConnection,
                                                                       final @Value("${trading.response.topic}") String tradingResponseTopicName,
                                                                       final EndPointStatusHandler transportEndPointStatusHandler) {
        final Topic tradingResponsesTopic = DefaultTopic.create(tradingResponseTopicName);
        final Publication publication = senderConnection.openPublication(tradingResponsesTopic, transportEndPointStatusHandler);

        return sbeMessage -> publication.publish(sbeMessage.buffer(), 0, sbeMessage.messageLength());
    }

    @Bean
    public Function<String, MessageDecoder<SbeMessage>> venueTradingRequestPublishingMessageDecoder(final Connection senderConnection,
                                                                                                    final EndPointStatusHandler transportEndPointStatusHandler,
                                                                                                    final @Value("${venue.trading.request.topic.suffix}") String venueTradingRequestTopicSuffix) {
        final Map<String, MessageDecoder<SbeMessage>> venuePublishingMessageDecoderMap = new HashMap<>();

        final Function<String, MessageDecoder<SbeMessage>> venuePublishingMessageDecoderFactory = marketId -> {
            final Topic venueTradingRequestTopic = DefaultTopic.create(marketId + venueTradingRequestTopicSuffix);
            final Publication publication = senderConnection.openPublication(venueTradingRequestTopic, transportEndPointStatusHandler);
            return sbeMessage -> publication.publish(sbeMessage.buffer(), 0, sbeMessage.messageLength());
        };

        Venue.forEach(venue -> {
            venuePublishingMessageDecoderMap.computeIfAbsent(venue.name(), venuePublishingMessageDecoderFactory);
        });

        return marketId -> venuePublishingMessageDecoderMap.computeIfAbsent(marketId, venuePublishingMessageDecoderFactory);
    }

    @Bean
    public MessageConsumer senderMessageConsumer(final MessageDecoder<SbeMessage> tradingResponsePublishingDecoder,
                                                 final Function<String, MessageDecoder<SbeMessage>> venueTradingRequestPublishingMessageDecoder,
                                                 final @Value("${messaging.sbe.buffer.capacity}") int bufferCapacity) {

        final MessageDecoder<SbeMessage> tradingResponse = SbeTradingDecoderBuilder.create()
                .newOrderSingle(new NewOrderSingleRouter(venueTradingRequestPublishingMessageDecoder))
                .orderCancelRequest(new OrderCancelRequestRouter(venueTradingRequestPublishingMessageDecoder))
                .executionReport(tradingResponsePublishingDecoder)
                .orderCancelReject(tradingResponsePublishingDecoder)
                .heartbeat(tradingResponsePublishingDecoder)
                .build();

        return new MessageConsumerToDecoderAdapterViaByteBuffer(tradingResponse, bufferCapacity);
    }

    @Bean(destroyMethod = "close")
    public Poller senderPoller(final ExecutionQueue executionQueue,
                               final PrecisionClock systemPrecisionClock,
                               final @Value("${event.sourcing.sender.no.events.created.before.startup.time}") boolean noEventsCreatedBeforeStartupTime) throws IOException {
        return executionQueue.createPoller(
                Poller.Options.builder()
                        .bufferPoller(new PayloadBufferPoller())
                        .skipWhen(
                        noEventsCreatedBeforeStartupTime ? IndexPredicate.eventTimeBefore(systemPrecisionClock.nanos() - POLLER_LOW_RESULTION_CLOCK_CORRECTION) : IndexPredicate.never()
                ).build());
    }

    @Bean
    Queue<Runnable> senderLoopRunnableQueue(@Value("${sender.loop.runnable.queue.capacity:256}") final int queueCapacity, final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(queueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(Metric.SENDER_LOOP_RUNNABLE_CNT, null).record(value));
    }

    @Bean
    public EventLoopStep senderStep(final Poller senderPoller,
                                    final MessageConsumer senderMessageConsumer) {
        final Step senderStep = new PollingProcessStep(senderPoller, senderMessageConsumer);
        return EventLoopStep.whenFinalisationRequired(senderStep::perform);
    }

    @Bean
    EventLoopStep senderRunnableProcessingStep(final Queue<Runnable> senderLoopRunnableQueue) {
        Objects.requireNonNull(senderLoopRunnableQueue);

        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return EventLoopStep.whenFinalisationRequired(() -> senderLoopRunnableQueue.poller().processNext(runnableProcessor));
    }

    @Bean
    public EventLoopStep senderTransportStep(final Connection senderConnection,
                                             final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        return EventLoopStep.whenFinalisationNotRequired(() -> senderConnection.pollingStrategy().processNext());
    }

    @Bean
    public EventLoopService senderEventLoopService(@Value("${sender.finalisation.timeout.seconds}") int finalisationTimeoutSeconds,
                                                   final EventLoopStep senderStep,
                                                   final EventLoopStep senderTransportStep,
                                                   final EventLoopStep senderRunnableProcessingStep,
                                                   final Supplier<IdleStrategy> eventSourcingIdleStrategyFactory) {
        return new EventLoopService("EventSender", finalisationTimeoutSeconds, TimeUnit.SECONDS, eventSourcingIdleStrategyFactory.get(), senderStep, senderTransportStep, senderRunnableProcessingStep);
    }
}
