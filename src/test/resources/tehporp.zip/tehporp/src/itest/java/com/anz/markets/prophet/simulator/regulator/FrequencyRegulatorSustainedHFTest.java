package com.anz.markets.prophet.simulator.regulator;

import org.junit.Test;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertTrue;


public class FrequencyRegulatorSustainedHFTest {
    final double ONE_PC = 0.01;

    @Test
    public void testLowSpeed() throws Exception {
        testAtGivenRateAndTimePeriod(1000, 2);
    }

    @Test
    public void testHighSpeed() throws Exception {
        testAtGivenRateAndTimePeriod(50000, 2);
    }

    @Test
    public void testLongerDuration() throws Exception {
        testAtGivenRateAndTimePeriod(10000, 10);
    }


    private void testAtGivenRateAndTimePeriod(final double expectedRatePerSecond,
                                              final int testLengthSeconds) throws InterruptedException {
        final FrequencyRegulatorSustainedHF regulator = new FrequencyRegulatorSustainedHF(expectedRatePerSecond);

        final AtomicLong count = new AtomicLong(0); // just so have a final object
        final AtomicBoolean keepRunning = new AtomicBoolean(true);
        final AtomicLong startNS = new AtomicLong(0);
        final AtomicLong finishNS = new AtomicLong(0);
        start(regulator, count, keepRunning, startNS, finishNS);
        Thread.sleep(TimeUnit.SECONDS.toMillis(testLengthSeconds));
        stop(keepRunning, finishNS);

        final long duration = finishNS.get() - startNS.get();
        final double nsToSec = 1. / TimeUnit.SECONDS.toNanos(1);
        final double actualRatePerSecond = count.get() / (nsToSec * duration);
        final double pcDiff = Math.abs(actualRatePerSecond - expectedRatePerSecond) / expectedRatePerSecond;
        assertTrue(pcDiff < ONE_PC);
    }

    private void start(final FrequencyRegulatorSustainedHF regulator,
                       final AtomicLong count,
                       final AtomicBoolean keepRunning,
                       final AtomicLong startNS,
                       final AtomicLong finishNS) {
        Executors.newSingleThreadExecutor().submit(
                (Runnable) () -> {
                    startNS.set(System.nanoTime());
                    while (keepRunning.get()) {
                        regulator.check();
                        count.incrementAndGet();
                    }
                    finishNS.set(System.nanoTime());
                });
    }

    private void stop(final AtomicBoolean keepRunning,
                      final AtomicLong finishNS) {
        keepRunning.set(false);
        while (finishNS.get() == 0) {
            ;
        }
    }
}