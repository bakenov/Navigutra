package com.anz.markets.prophet.config.app;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.chronicle.ChronicleByteReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderMulti;
import com.anz.markets.prophet.chronicle.ChronicleObjectReaderNoOp;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.ConsumerConflateConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.impl.ClientPriceImpl;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.marketdata.MarketDataReader;
import com.anz.markets.prophet.status.Context;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.function.Consumer;

/**
 * This was copied and cut down from CoreConfig
 */
@Configuration
@Import({ConsumerConflateConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core-conflate.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class CoreConflateConfig extends JmxConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(CoreConflateConfig.class);

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.core_conflate:4}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    // chronicle in & out
    @Bean
    public ProphetPersister outboundChroniclePersister(
            @Value("${chronicle.conflated.path:./chronicle.in.conflated}") final String outboundChroniclePath,
            @Value("${chronicle.open.mode:APPEND}") final LegacyChroniclePersister.OpenMode openMode,
            @Value("${core.instance}") final byte coreInstance) throws IOException {

        GcFriendlyAssert.isTrue(coreInstance == 0, "designed to only work as a single core for now");

        Context.instance(coreInstance);
        Context.stage(Stage.PRICE_CONFLATE);

        return ChroniclePersisterFactory.createCorePersister(outboundChroniclePath, openMode, ActivationAware.NO, true, Predicates.alwaysTrue());
    }

    // tell Main to run this in main thread
    @Bean(name = Main.RUNNER_BEAN)
    public ProphetReader chronicleReader(@Value("${chronicle.conflated.path:./chronicle.in.conflated}") final String outboundChroniclePath,
                                         @Value("${chronicle.in.path:./chronicle.in}") final String chronicleInPath,
                                         final ChronicleObjectReader marketDataReader,
                                         final ChronicleObjectReader marketDataReaderFMDS,
                                         final ChronicleObjectReader clientPriceReader,
                                         final ChronicleObjectReader noOpReader,
                                         final ProphetPersister prophetPersister,
                                         @Qualifier("tradingTimeZoneChimeReader") final ChronicleObjectReader tradingTimeZoneReader) throws IOException {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        // we don't support ACTIVATE message in this core - no need to run 2 of them
        // map.put(MessageType.ACTIVATE, activationReader);
        // business messages that we need to process
        map.put(MessageType.MARKET_DATA_SNAPSHOT, marketDataReader);
        map.put(MessageType.MARKET_DATA_INCREMENT, marketDataReader);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneReader);
        // separate MDR for FMDS
        map.put(MessageType.FILTERED_MARKET_DATA_SNAPSHOT, marketDataReaderFMDS);
        // and....
        map.put(MessageType.CLIENT_PRICE, clientPriceReader);
        // drop these altogether
        map.put(MessageType.WHOLESALE_BOOK_FACTORS, noOpReader);

        // and everything else we pass through as raw bytes so we don't pay for serialise/deserialise
        final ChronicleByteReader passThrough = new ChronicleByteReader(prophetPersister.sinkRawBytes());
        final ChronicleObjectReaderMulti objectReaderMulti = new ChronicleObjectReaderMulti(map, passThrough);

        return ChronicleReaderFactory.createCoreConflateReader(outboundChroniclePath, chronicleInPath, objectReaderMulti);
    }

    // chronicle readers. These deserialise their types from the inbound chronicle and pass on to their consumers

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneChimeReader(
            final Consumer<TradingTimeZoneChime> tradingTimeZoneChimeConsumer,
            final ProphetPersister prophetPersister) {
        return new ChronicleReaderGeneric<>(TradingTimeZoneChime.INSTANCE,
                // send to MarketSnapshotManager to flush and then write to chronicle
                tradingTimeZoneChimeConsumer, prophetPersister.sink(MessageType.TIMEZONE_CHIME));
    }

    @Bean
    public ChronicleReaderGeneric<Activate> activationReader(
            @Qualifier("activateConsumers") final Consumer<Activate> activateConsumers) {
        return new ChronicleReaderGeneric<>(new Activate(), activateConsumers);
    }

    @Bean
    public MarketDataReader marketDataReader(final Consumer<MarketData> marketDataConsumers) {
        return new MarketDataReader(Arrays.asList(marketDataConsumers));
    }

    @Bean
    public MarketDataReader marketDataReaderFMDS(final Consumer<MarketData> marketDataConsumersFMDS) {
        return new MarketDataReader(Arrays.asList(marketDataConsumersFMDS));
    }

    @Bean
    public ChronicleReaderGeneric<ClientPrice> clientPriceReader(final Consumer<ClientPrice> clientPriceConsumer) {
        return new ChronicleReaderGeneric<>(new ClientPriceImpl(), clientPriceConsumer);
    }

    @Bean
    public ChronicleObjectReader noOpReader() {
        return new ChronicleObjectReaderNoOp();
    }

    @Bean
    public Consumer<Activate> activateSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ACTIVATE);
    }

    @Bean
    public Consumer<MarketData> marketDataSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sinkMarketData();
    }

    @Bean
    public Consumer<MidRate> midRateSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sinkMidRate();
    }

    @Bean
    public Consumer<ClientPrice> clientPriceSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.CLIENT_PRICE);
    }
}
