package com.anz.markets.prophet.config.business.domain.tabular;


import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.efx.ngaro.collections.EnumBooleanTable;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumSet;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Lists;

import java.util.List;

public class BaseTermsToInstrumentMarketConfigImpl implements BaseTermsToInstrumentMarketConfig {

    private Market market;
    private Currency baseCurrency;
    private Currency termsCurrency;
    private transient Instrument instrument;

    public BaseTermsToInstrumentMarketConfigImpl() {
    }

    public BaseTermsToInstrumentMarketConfigImpl(final Market market, final Currency baseCurrency, final Currency termsCurrency) {
        this.market = GcFriendlyAssert.notNull(market, "market should not be null");
        this.baseCurrency = GcFriendlyAssert.notNull(baseCurrency, "base currency should not be null");
        this.termsCurrency = GcFriendlyAssert.notNull(termsCurrency, "terms currency should not be null");
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @JsonIgnore
    @Override
    public Instrument getInstrument() {
        if (instrument == null && baseCurrency != null && termsCurrency != null) {
            if (baseCurrency.isGenuineCurrency()
                    && termsCurrency.isGenuineCurrency()
                    && Instrument.has(baseCurrency, termsCurrency)) {
                instrument = Instrument.get(baseCurrency, termsCurrency);
            }
            else {
                instrument = Instrument.UNKNOWN;
            }
        }
        return instrument;
    }

    @JsonIgnore
    // Note: This is only used while exploding instruments which have the same dealt/terms pairs
    // i.e. USDIN1 and USDIN1_M1 are both mapped to pairs USD/IN1 but USDIN1_M1 is the primary
    public void setInstrument(final Instrument instrument) {
        this.instrument = instrument;
        this.baseCurrency = instrument.getDealt();
        this.termsCurrency = instrument.getTerms();
    }

    @Override
    public Currency getBaseCurrency() {
        return baseCurrency;
    }

    @Override
    public Currency getTermsCurrency() {
        return termsCurrency;
    }

    public BaseTermsToInstrumentMarketConfigImpl setMarket(final Market market) {
        this.market = market;
        return this;
    }

    public BaseTermsToInstrumentMarketConfigImpl setBaseCurrency(final Currency baseCurrency) {
        this.baseCurrency = baseCurrency;
        return this;
    }

    public BaseTermsToInstrumentMarketConfigImpl setTermsCurrency(final Currency termsCurrency) {
        this.termsCurrency = termsCurrency;
        return this;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        setBaseCurrency(Currency.valueOf(in.readByte()));
        setTermsCurrency(Currency.valueOf(in.readByte()));
        setMarket(Market.valueOf(in.readByte()));
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeByte(getBaseCurrency().getValue());
        out.writeByte(getTermsCurrency().getValue());
        out.writeByte(getMarket().getValue());
    }

    private static final ProphetMarshallableCopier copier = new ProphetMarshallableCopier();
    private static final EnumObjMap<Market, EnumObjTable<Currency, Currency, BaseTermsToInstrumentMarketConfig>> configByMarketCurrencies = new EnumObjMap<>(Market.class); // intermediate config store
    private static final EnumBooleanTable<Market, Instrument> hasConfigForMarketInstrument = new EnumBooleanTable<>(Market.class, Instrument.class);

    /**
     * convert configs from base/terms currency, to instrument based config.
     * apply ANY wildcards for base/terms currencies while we are at it.
     * also apply ANY wildcards for market
     * @param configs raw base/terms currency based list of config.
     */
    public static List<? extends BaseTermsToInstrumentMarketConfig> propagateCurrencyAndMarketWildcards(final List<? extends BaseTermsToInstrumentMarketConfig> configs, final EnumSet<Instrument> allowableInstruments) {
        final EnumSet<Market> clientPricingModels = new EnumSet<>(Market.class);
        Market.CLIENT_PRICING_MARKETS.forEach(m -> clientPricingModels.add(m));
        return propagateCurrencyAndMarketWildcards(configs, allowableInstruments, clientPricingModels);
    }

    public synchronized static List<? extends BaseTermsToInstrumentMarketConfig> propagateCurrencyAndMarketWildcards(final List<? extends BaseTermsToInstrumentMarketConfig> configs, final EnumSet<Instrument> allowableInstruments, final EnumSet<Market> activePricingModels) {
        // Note: This method is synchronized so acceptance tests running in 3-core mode doesn't cause contention with the static maps

        final List<BaseTermsToInstrumentMarketConfig> explodedConfigs = Lists.newArrayList();

        configByMarketCurrencies.clear();
        hasConfigForMarketInstrument.clear();

        // store all the defined configuration in the temporary collections configByMarketCurrencies, configByMarketInstrument and in the explodedConfigs
        configs.forEach(cfg -> {
            configByMarketCurrencies.computeIfAbsent(cfg.getMarket(), market -> new EnumObjTable<>(Currency.class, Currency.class));
            configByMarketCurrencies.get(cfg.getMarket()).put(cfg.getBaseCurrency(), cfg.getTermsCurrency(), cfg);
            if (cfg.getMarket() != Market.ANY && cfg.getInstrument() != Instrument.UNKNOWN && allowableInstruments.contains(cfg.getInstrument())) {
                explodedConfigs.add(cfg);
                hasConfigForMarketInstrument.put(cfg.getMarket(), cfg.getInstrument(), true);
            }
        });

        // explodes config from configByMarketCurrencies to fill any allowableInstruments and pricing models (aka market) gaps
        allowableInstruments.keys( instrument -> activePricingModels.keys(market -> {
            if (!hasConfigForMarketInstrument.get(market, instrument)) {
                BaseTermsToInstrumentMarketConfig wildCardedConfig = getBaseTermsExplodedConfig(market, instrument);
                if (wildCardedConfig == EMPTY) {
                    wildCardedConfig = getBaseTermsExplodedConfig(Market.ANY, instrument);
                }

                // if there is no config here then there is no Market.ANY, Instrument.ANY specified
                if (wildCardedConfig != EMPTY) {
                    addExplodedConfig(explodedConfigs, market, instrument, wildCardedConfig);
                    hasConfigForMarketInstrument.put(market, instrument, true);
                }
            }
        }));

        return explodedConfigs;
    }

    private static BaseTermsToInstrumentMarketConfig getBaseTermsExplodedConfig(final Market market, final Instrument instrument) {
        final Currency base = instrument.getDealt();
        final Currency terms = instrument.getTerms();
        if (!configByMarketCurrencies.containsKey(market)) {
            return EMPTY;
        }
        if (configByMarketCurrencies.get(market).containsKey(base, terms)) {
            return configByMarketCurrencies.get(market).get(base, terms);
        } else if (configByMarketCurrencies.get(market).containsKey(Currency.ANY, terms)) {
            return configByMarketCurrencies.get(market).get(Currency.ANY, terms);
        } else if (configByMarketCurrencies.get(market).containsKey(base, Currency.ANY)) {
            return configByMarketCurrencies.get(market).get(base, Currency.ANY);
        } else if (configByMarketCurrencies.get(market).containsKey(Currency.ANY, Currency.ANY)) {
            return configByMarketCurrencies.get(market).get(Currency.ANY, Currency.ANY);
        }
        return EMPTY;
    }

    private static void addExplodedConfig(final List<BaseTermsToInstrumentMarketConfig> explodedConfigs, final Market mkt, final Instrument inst, final BaseTermsToInstrumentMarketConfig cfg) {
        Instrument
                .forPair(inst.getDealt(), inst.getTerms())
                .keys(instrument -> {
                    // Don't re-add existing config for market/instrument
                    for (BaseTermsToInstrumentMarketConfig config : explodedConfigs) {
                        if (config.getInstrument() == instrument && config.getMarket() == mkt) {
                            return;
                        }
                    }

                    try {
                        BaseTermsToInstrumentMarketConfig dest = cfg.getClass().newInstance();
                        copier.copy(cfg, dest);
                        ((BaseTermsToInstrumentMarketConfigImpl) dest).setMarket(mkt);
                        ((BaseTermsToInstrumentMarketConfigImpl) dest).setInstrument(instrument);
                        explodedConfigs.add(dest);
                    } catch (InstantiationException | IllegalAccessException e) {
                        e.printStackTrace();
                    }
                });
    }

    @Override
    public String toString() {
        return "BaseTermsToInstrumentMarketConfigImpl{" +
                "market=" + market +
                ", baseCurrency=" + baseCurrency +
                ", termsCurrency=" + termsCurrency +
                ", instrument=" + instrument +
                '}';
    }
}
