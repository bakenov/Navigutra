package com.anz.markets.efx.fox.processor.state.venue;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.Venue;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigDecoder;
import com.anz.markets.efx.fox.processor.event.VenueConfigEvent;
import com.anz.markets.efx.fox.processor.timer.Timer;
import com.anz.markets.efx.fox.receiver.VenueSubscriber;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;

public class DefaultVenueRepository implements VenueRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultVenueRepository.class);

    private final VenueSubscriber.Async venueSubscriber;
    private final Timer.Factory timerFactory;
    private final long missedHeartbeatTimeoutMillis;

    private final Map<com.anz.markets.efx.ngaro.api.Venue, DefaultVenue> venueByVenueIdMap = new EnumMap<>(com.anz.markets.efx.ngaro.api.Venue.class);
    private final Map<String, DefaultVenue> venueByCompIdMap = new HashMap<>();
    private final ByteValueCache<String> compIdCache = new ByteValueCache<>(AsciiString::toString);


    public DefaultVenueRepository(final VenueSubscriber.Async venueSubscriber,
                                  final Timer.Factory timerFactory,
                                  final long missedHeartbeatTimeoutMillis) {
        this.venueSubscriber = Objects.requireNonNull(venueSubscriber);
        this.timerFactory = Objects.requireNonNull(timerFactory);
        this.missedHeartbeatTimeoutMillis = missedHeartbeatTimeoutMillis;
    }

    @Override
    public Venue lookup(final com.anz.markets.efx.ngaro.api.Venue venueId) {
        return venueByVenueIdMap.get(venueId);
    }

    @Override
    public Venue lookup(final String compId) {
        return venueByCompIdMap.get(compId);
    }

    @Override
    public Venue apply(final VenueConfigDecoder venueConfigDecoder) {
        final com.anz.markets.efx.ngaro.api.Venue venueId = venueConfigDecoder.body().venue();
        final String compId = venueConfigDecoder.body().compId().decodeAndCache(compIdCache);
        final EnumSet<VenueCategory> venueCategories = venueConfigDecoder.body().venueCategories().decodeTo(EnumSet.noneOf(VenueCategory.class));
        final boolean enabled = venueConfigDecoder.body().enabled();

        final DefaultVenue foundVenueById = venueByVenueIdMap.get(venueId);
        if (foundVenueById == null) {
            final DefaultVenue venue = new DefaultVenue(venueId, compId, venueCategories, enabled, timerFactory, missedHeartbeatTimeoutMillis);

            venueByVenueIdMap.put(venueId, venue);
            venueByCompIdMap.put(compId, venue);
            venueSubscriber.subscribe(venueId);
            //LOGGER.info("Created {}", venue);
            return venue;
        } else {
            foundVenueById.venueCategories().clear();
            foundVenueById.venueCategories().addAll(venueCategories);
            foundVenueById.enabled(enabled);

            //LOGGER.info("Updated {}", foundVenueById);
            return foundVenueById;
        }
    }
}
