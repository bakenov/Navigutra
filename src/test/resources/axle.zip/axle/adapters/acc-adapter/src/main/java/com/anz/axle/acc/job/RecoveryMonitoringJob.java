package com.anz.axle.acc.job;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.quartz.CronTrigger;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Component("recoveryMonitoringJob")
public class RecoveryMonitoringJob implements Runnable {
    private static final Logger LOG = Logger.getLogger(RecoveryMonitoringJob.class);

    private volatile Map<String, ProblemHistory> histories = new HashMap<String, ProblemHistory>();

    @Autowired
    @Qualifier("scheduler")
    private SchedulerFactoryBean schedulerFactory = null;

    private int[] backOffMinutes;

    public void setBackOffMinutes(int[] backOffMinutes) {
        this.backOffMinutes = backOffMinutes;
    }

    @Override
    public void run() {
         try {
            reschedule(getPausedTriggers());
            cleanupRecoveredTriggers();    
        } catch (Throwable e) {
            throw new RuntimeException("Could not resume paused triggers.", e);
        }
    }

    private void cleanupRecoveredTriggers() throws SchedulerException {
        Scheduler scheduler = schedulerFactory.getScheduler();
        Set<TriggerKey> triggerKeys = scheduler.getTriggerKeys(GroupMatcher.anyGroup());
        for (TriggerKey triggerKey : triggerKeys) {
            CronTrigger trigger = (CronTrigger)scheduler.getTrigger(triggerKey);
            if(!"recovery".equals(trigger.getDescription()) && histories.containsKey(trigger.getKey().getName())) {
                LOG.info("Removing recovery management record for recovered trigger " + trigger.getKey().getName());
                histories.remove(trigger.getKey().getName());
            }
        }
    }

    private void reschedule(List<CronTrigger> pausedTriggers) throws SchedulerException {
        for(CronTrigger thisTrigger : pausedTriggers) {
            ProblemHistory history = null;
            if(histories.containsKey(thisTrigger.getKey().getName())) {
                history = histories.get(thisTrigger.getKey().getName());
            } else {
                history = new ProblemHistory();
                histories.put(thisTrigger.getKey().getName(), history);
            }
            
            int appropriateDelay = history.getCurrentDelay();
            if(history.retry()) {
                history.recordRetry();
                Scheduler scheduler = schedulerFactory.getScheduler();
                scheduler.resumeTrigger(TriggerKey.triggerKey(thisTrigger.getKey().getName(), thisTrigger.getKey().getGroup()));
                Date next = scheduler.rescheduleJob(thisTrigger.getKey(), thisTrigger);
                LOG.warn("Resuming trigger " + thisTrigger.getKey().getName() + " as part of recovery management. Next fire: " + next);
            } else {
                  LOG.warn("Trigger " +  thisTrigger.getKey().getName() + " sleeping for " + appropriateDelay + " minutes since " + history.getLastRetry());
            }
        }
    }

    private List<CronTrigger> getPausedTriggers() throws SchedulerException {
        List<CronTrigger> pausedTriggers = new ArrayList<CronTrigger>();
        Scheduler scheduler = schedulerFactory.getScheduler();
        Set<TriggerKey> triggerKeys = scheduler.getTriggerKeys(GroupMatcher.anyGroup());
        for (TriggerKey key : triggerKeys) {
            CronTrigger trigger = (CronTrigger)scheduler.getTrigger(key);
            if(scheduler.getTriggerState(key) == Trigger.TriggerState.PAUSED) {
                pausedTriggers.add(trigger);
            }
        }
        return pausedTriggers;
    }

    private class ProblemHistory {
        private DateTime lastRetry = new DateTime();
        private int count = 0;

        public int getCurrentDelay() {
            if(count < backOffMinutes.length) {
                return backOffMinutes[count];
            } else {
                return backOffMinutes[backOffMinutes.length - 1];
            }
        }

        public boolean retry() {
            if(minutesSinceLastRetry() >= getCurrentDelay()) {
                return true;
            }
            return false;
        }

        public void recordRetry() {
            count++;
            lastRetry = new DateTime();
        }

        public DateTime getLastRetry() {
            return lastRetry;
        }

        public int minutesSinceLastRetry() {
            if(lastRetry == null) {
                return 0;
            }
            return new Duration(lastRetry, new DateTime()).toPeriod().getMinutes();
        }

        public int count() {
            return count;
        }
    }
}
