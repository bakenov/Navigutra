package com.anz.axle.adapters.wssdeal.pipe;

import anz.markets.messaging.pipes.intf.AbstractPipe;
import anz.markets.messaging.types.PDMessage;
import anz.markets.canonical.model.v2.TradeMessageWrapperType;
import com.anz.axle.common.filter.Filter;
import com.anz.axle.common.filter.FilterException;
import org.apache.log4j.Logger;

/**
 * Created by talwarg on 24/02/2015.
 */
public class TradeMessageFilterPipe  extends AbstractPipe<TradeMessageWrapperType,TradeMessageWrapperType> {
    private static final Logger LOG = Logger.getLogger(TradeMessageFilterPipe.class);

    private Filter<TradeMessageWrapperType> tradeMessageFilter;

    public TradeMessageFilterPipe(Filter<TradeMessageWrapperType> tradeMessageFilter){
        this.tradeMessageFilter = tradeMessageFilter;
    }


    @Override
    public boolean onMessage(final PDMessage<TradeMessageWrapperType> tradeMessagePDMessage) {
        try {
            if(tradeMessageFilter.accept(tradeMessagePDMessage.getContent())){
                return getSink().onMessage(tradeMessagePDMessage);
            }
            LOG.info(String.format("TradeMessage %s filtered out and will not be processed.", tradeMessagePDMessage.getContent()));
        } catch (FilterException e) {
            LOG.info(String.format("Failed to apply filter on message %s. TradeMessage not processed", tradeMessagePDMessage.getContent()));
        }
        return false;
    }
}
