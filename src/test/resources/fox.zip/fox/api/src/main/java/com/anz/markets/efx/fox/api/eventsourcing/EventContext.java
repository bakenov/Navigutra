package com.anz.markets.efx.fox.api.eventsourcing;

import com.anz.axle.microtime.PrecisionClock;

public interface EventContext {
    PrecisionClock precisionClock();
}
