package com.anz.markets.prophet.config.app;


import com.anz.axle.direct.performance.LoggingReporterFactory;
import com.anz.axle.direct.performance.ReporterFactory;
import com.anz.axle.direct.performance.TeamcityReporterFactory;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersisterConfig;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReader;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChronicleReaderConfig;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.app.importable.SchedulingConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.perftest.CollectMetrics;
import com.anz.markets.prophet.perftest.PerfRecorder;
import com.anz.markets.prophet.perftest.PerfRecorderHeaderPercentiles;
import com.anz.markets.prophet.perftest.PerfTestMetricsCollector;
import com.anz.markets.prophet.perftest.PerfTestMetricsReaderChronicleIn;
import com.anz.markets.prophet.perftest.PerfTestMetricsReaderChronicleOut;
import com.anz.markets.prophet.perftest.PerfTestPhase;
import com.anz.markets.prophet.perftest.PerformanceTest;
import com.anz.markets.prophet.perftest.garbage.GcProbe;
import com.anz.markets.prophet.perftest.garbage.GcProbeJmx;
import com.anz.markets.prophet.perftest.garbage.GcProbeNoop;
import com.anz.markets.prophet.perftest.garbage.GcStatsConsumer;
import com.anz.markets.prophet.simulator.ClientTradeSimulatorImpl;
import com.anz.markets.prophet.simulator.MarketDataService;
import com.anz.markets.prophet.simulator.MarketDataSimulatorImpl;
import com.anz.markets.prophet.simulator.TradeService;
import com.anz.markets.prophet.simulator.regulator.FrequencyRegulator;
import com.anz.markets.prophet.simulator.regulator.FrequencyRegulatorFactory;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.function.Consumer;

@Configuration
@Import({BusinessConfig.class, SchedulingConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/perfTest.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class PerfTestConfig extends JmxConfig {

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        final String regionName = env.getRequiredProperty("region");
        GcFriendlyAssert.notNull(regionName, "No Region Name specified in config");
        Region region = Region.valueOf(regionName);
        Context.region(region);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.perftest:-9}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    @Bean
    public LegacyChroniclePersister inboundChroniclePersister(
            @Value("${chronicle.in.path:./chronicle.in}") final String inChroniclePath,
            @Value("${chronicle.out.type:INDEXED}") final LegacyChronicleConfig.ChronicleType chronicleType) throws IOException {

        Context.instance((byte) 0);
        Context.stage(Stage.SIMULATED);

        return  new LegacyChroniclePersister(LegacyChroniclePersisterConfig.starfishIn(inChroniclePath, LegacyChroniclePersister.OpenMode.APPEND, chronicleType), true);
    }

    @Bean
    public MarketDataService createMarketDataSimulator(
            @Value("${simulator.marketdata.isEnabled:true}") final boolean simulatorEnabledFlag,
            @Value("${simulator.marketdata.logProgress:false}") final boolean logProgress,
            @Value("${simulator.performanceTest.isEnabled:true}") final boolean performanceTestEnabledFlag,
            @Value("${simulator.marketdata.messagesPerSecond:10000}") final double messagesPerSecond,
            @Qualifier("inboundChroniclePersister") final LegacyChroniclePersister LegacyChroniclePersister,
            @Value("${simulator.marketdata.tradingTimeZone:LDNNYK}") final TradingTimeZone timeZone,
            final ConfigurationDataDefault configurationDataDefault) throws InterruptedException {
        // TODO: pluggable frequencyRegulator
        final FrequencyRegulator frequencyRegulator = FrequencyRegulatorFactory.createRegulatorSustained(messagesPerSecond);
        final List<Market> marketsToSimulate = MarketDataSimulatorImpl.DEFAULT_MARKETS_TO_SIMULATE;
        final Consumer<MarketData> consumerMarketDataMessage = LegacyChroniclePersister.consumerMarketDataMessage();
        final List<Consumer<TradingTimeZoneChime>> consumerTradingTimeZone = Arrays.asList(LegacyChroniclePersister.consumerTradingTimeZoneChime());
        final MarketDataService marketDataService = new MarketDataSimulatorImpl(
                simulatorEnabledFlag, MarketDataSimulatorImpl.SimulationStrategy.RANDOMWALK, logProgress,
                frequencyRegulator, consumerMarketDataMessage, consumerTradingTimeZone, false,
                marketsToSimulate, timeZone, LegacyChroniclePersister.consumerSpotDate(), configurationDataDefault);
        if (!performanceTestEnabledFlag) {
            marketDataService.start();
        }
        return marketDataService;
    }

    @Bean
    public TradeService createTradeSimulator(
            @Value("${simulator.trade.isEnabled:true}") final boolean simulatorEnabledFlag,
            @Value("${simulator.trade.logProgress:false}") final boolean logProgress,
            @Value("${simulator.performanceTest.isEnabled:true}") final boolean performanceTestEnabledFlag,
            @Value("${simulator.trade.messagesPerSecond:100}") final double messagesPerSecond,
            MarketDataService marketDataService,
            @Qualifier("inboundChroniclePersister") final LegacyChroniclePersister LegacyChroniclePersister) throws InterruptedException {
        // TODO: Configurable choice of regulator
        FrequencyRegulator frequencyRegulator = FrequencyRegulatorFactory.createRegulatorSustained(messagesPerSecond);
        final TradeService simulator = new ClientTradeSimulatorImpl(marketDataService, simulatorEnabledFlag, logProgress, frequencyRegulator, LegacyChroniclePersister.consumerTrade());
        if (!performanceTestEnabledFlag) {
            simulator.start();
        }
        return simulator;
    }

    @Bean
    public PerformanceTest createPerformanceTest(
            @Value("${simulator.performanceTest.isEnabled:true}") final boolean performanceTestEnabledFlag,
            @Value("${simulator.performanceTest.warmupDurationSeconds:60}") final long warmupDurationSeconds,
            @Value("${simulator.performanceTest.runDurationSeconds:600}") final long runDurationSeconds,
            final MarketDataService marketDataSimulator,
            final TradeService tradeSimulator,
            @Qualifier("createSimulatorMetricsReaderOut") final PerfTestMetricsCollector metricsReaderChronicleOut,
            @Qualifier("createMetricsReaderHedgerOut") final PerfTestMetricsCollector metricsReaderChronicleHedgerOut,
            final PerfTestMetricsReaderChronicleIn metricsReaderChronicleIn,
            final ReporterFactory reporterFactory,
            final GcProbe garbageCollectorRecorder) throws InterruptedException {
        final List<PerfTestPhase> phases = new ArrayList<>();
        phases.add(new PerfTestPhase("Warmup", warmupDurationSeconds, marketDataSimulator, tradeSimulator, metricsReaderChronicleOut, metricsReaderChronicleHedgerOut, metricsReaderChronicleIn, garbageCollectorRecorder, CollectMetrics.DISABLED, reporterFactory));
        phases.add(new PerfTestPhase("Performance", runDurationSeconds, marketDataSimulator, tradeSimulator, metricsReaderChronicleOut, metricsReaderChronicleHedgerOut, metricsReaderChronicleIn, garbageCollectorRecorder, CollectMetrics.ENABLED, reporterFactory));
        final PerformanceTest performanceTest = new PerformanceTest(phases);
        performanceTest.run();
        return performanceTest;
    }

    @Bean
    public ReporterFactory reporterFactory(
            @Value("${simulator.performanceTest.reporterFactory:TEAMCITY}") final String reporter) {
        if (reporter.equalsIgnoreCase("TEAMCITY")) {
            return new TeamcityReporterFactory();
        } else {
            return new LoggingReporterFactory();
        }
    }

    @Bean
    GcProbe createGarbageCollectorRecorder(
            @Value("${performanceTest.gcCollector.targetHost:localhost}") final String targetHost,
            @Value("${performanceTest.gcCollector.targetPort:28886}") final int targetJmxPort,
            @Value("${performanceTest.gcCollector.collectionIntervalMS:500}") final long collectionIntervalMS,
            @Qualifier("createSimulatorMetricsReaderOut") final GcStatsConsumer gcMetricsReaderOut) throws IOException {
        if (targetJmxPort > 0) {
            return new GcProbeJmx(targetHost, targetJmxPort, collectionIntervalMS, gcMetricsReaderOut);
        } else {
            return new GcProbeNoop();
        }
    }

    @Bean
    PerfTestMetricsReaderChronicleOut createSimulatorMetricsReaderOut() {
        List<PerfRecorder> perfRecorders = new ArrayList<>();
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chOut.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS));
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chOut.receive.to.start", Header::getEventTimeStampNS, Header::getStartTimeStampNS));
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chOut.receive.to.finish", Header::getEventTimeStampNS, Header::getFinishTimeStampNS));
        return new PerfTestMetricsReaderChronicleOut(perfRecorders);
    }

    @Bean
    PerfTestMetricsReaderChronicleIn createSimulatorMetricsReaderIn() {
        List<PerfRecorder> perfRecorders = new ArrayList<>();
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chIn.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS));
        return new PerfTestMetricsReaderChronicleIn(perfRecorders);
    }

    @Bean
    public LegacyChronicleReader outboundChronicleReader(
            @Value("${chronicle.out.path:./chronicle.out}") final String chronicleOutPath,
            @Value("${chronicle.out.type:INDEXED}") final LegacyChronicleConfig.ChronicleType chronicleType,
            final ExecutorService executorService,
            @Qualifier("createSimulatorMetricsReaderOut") final ChronicleObjectReader metricsReaderOut) throws IOException {
        final LegacyChronicleReader cr = new LegacyChronicleReader(executorService, metricsReaderOut,
                LegacyChronicleReaderConfig.readOnlyNotReallyUntilWeWorkOutTheProblem(chronicleOutPath, chronicleType));
        return cr;
    }

    @Bean
    PerfTestMetricsReaderChronicleOut createMetricsReaderHedgerOut() {
        List<PerfRecorder> perfRecorders = new ArrayList<>();
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chOutH.start.to.finish", Header::getStartTimeStampNS, Header::getFinishTimeStampNS));
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chOutH.receive.to.start", Header::getEventTimeStampNS, Header::getStartTimeStampNS));
        perfRecorders.add(new PerfRecorderHeaderPercentiles("chOutH.receive.to.finish", Header::getEventTimeStampNS, Header::getFinishTimeStampNS));
        return new PerfTestMetricsReaderChronicleOut(perfRecorders);
    }

    @Bean
    public LegacyChronicleReader outboundChronicleReaderHedgerOut(
            @Value("${chronicle.out.path2:./chronicle.hedger.out}") final String chronicleOutPath,
            @Value("${chronicle.out.type:INDEXED}") final LegacyChronicleConfig.ChronicleType chronicleType,
            final ExecutorService executorService,
            @Qualifier("createMetricsReaderHedgerOut") final PerfTestMetricsReaderChronicleOut metricsReaderOut) throws IOException {
        final LegacyChronicleReader cr = new LegacyChronicleReader(executorService, metricsReaderOut,
                LegacyChronicleReaderConfig.readOnlyNotReallyUntilWeWorkOutTheProblem(chronicleOutPath, chronicleType));
        return cr;
    }

    @Bean
    public LegacyChronicleReader inboundChronicleReader(
            @Value("${chronicle.in.path:./chronicle.in}") final String chronicleInPath,
            @Value("${chronicle.out.type:INDEXED}") final LegacyChronicleConfig.ChronicleType chronicleType,
            final ExecutorService executorService,
            final PerfTestMetricsReaderChronicleIn metricsReaderIn) throws IOException {
        final LegacyChronicleReader cr = new LegacyChronicleReader(executorService, metricsReaderIn,
                LegacyChronicleReaderConfig.perfTestChronicleInReader(chronicleInPath, chronicleType));
        return cr;
    }

    @Bean
    public ExecutorService executorService() {
        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("chronicle-read-%d").build();
        return Executors.newFixedThreadPool(3, threadFactory);
    }


}
