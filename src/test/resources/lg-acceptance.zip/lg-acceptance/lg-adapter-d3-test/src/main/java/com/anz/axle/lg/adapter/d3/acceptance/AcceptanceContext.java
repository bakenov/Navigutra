package com.anz.axle.lg.adapter.d3.acceptance;

import java.util.Queue;
import java.util.concurrent.TimeUnit;

import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;

public interface AcceptanceContext {
    Queue<PricingMessage> pricingMessageQueue();
    Queue<PricingMessage> pricingRequestMessageQueue();
    PrecisionClock precisionClock();
    LongIdFactory pricingMessageIdGenerator();
    Queue<SubscriptionRequest> subscriptionRequestQueue();
    Queue<UpdateMessage> updateMessageQueue();
    Queue<ErrorMessage> errorMessageQueue();
    Queue<Throwable> throwableQueue();
    HandlerRegistry onStreamingServiceSubscribeHandlerRegistry();
    void awaitMainEventLoopRunnableQueueIsProcessed(final long time, final TimeUnit timeUnit) throws InterruptedException;
}
