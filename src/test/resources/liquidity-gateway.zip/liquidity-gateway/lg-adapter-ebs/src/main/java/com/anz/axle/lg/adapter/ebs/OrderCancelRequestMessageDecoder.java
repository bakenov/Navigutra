package com.anz.axle.lg.adapter.ebs;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.api.OrderCancelRequestDecoder;
import com.anz.markets.efx.trading.codec.sbe.OrderCancelRequestSbeDecoder;

import java.util.Objects;
import java.util.function.Consumer;

public class OrderCancelRequestMessageDecoder implements MessageDecoder<SbeMessage> {

    private final OrderCancelRequestSbeDecoder orderCancelRequestSbeDecoder = new OrderCancelRequestSbeDecoder();
    private final Consumer<OrderCancelRequestDecoder> orderCancelRequestDecoderConsumer;

    public OrderCancelRequestMessageDecoder(final Consumer<OrderCancelRequestDecoder> orderCancelRequestDecoderConsumer) {
        this.orderCancelRequestDecoderConsumer = Objects.requireNonNull(orderCancelRequestDecoderConsumer);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!orderCancelRequestSbeDecoder.wrap(message)) return false;
        orderCancelRequestDecoderConsumer.accept(orderCancelRequestSbeDecoder);
        return true;
    }
}
