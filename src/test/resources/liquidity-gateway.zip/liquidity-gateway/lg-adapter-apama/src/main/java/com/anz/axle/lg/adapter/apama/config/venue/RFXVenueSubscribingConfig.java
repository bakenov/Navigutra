package com.anz.axle.lg.adapter.apama.config.venue;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.apama.decoder.ApamaEventDecoder;
import com.anz.axle.lg.adapter.apama.decoder.IAFStatusResponseDecoder;
import com.anz.axle.lg.adapter.apama.decoder.LoggedOffEventDecoder;
import com.anz.axle.lg.adapter.apama.decoder.ReutersMapiDepthDecoder;
import com.anz.axle.lg.adapter.apama.event.Depth;
import com.anz.axle.lg.adapter.apama.event.IAFStatusResponse;
import com.anz.axle.lg.adapter.apama.event.LoggedOff;
import com.anz.axle.lg.adapter.apama.transport.Connection;
import com.anz.axle.lg.adapter.apama.transport.ConnectionConfig;
import com.anz.axle.lg.adapter.apama.transport.ConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.MarketDataBooksClearingConnectionStatusHandler;
import com.anz.axle.lg.adapter.apama.transport.Subscription;
import com.anz.axle.lg.adapter.apama.transport.Transport;
import com.anz.axle.lg.config.DefaultPricingEncoderLookup;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.axle.lg.config.SbeMessagePublisher;
import com.anz.axle.lg.config.SnapshotterAccessor;
import com.anz.axle.lg.config.TopicRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.publisher.PublicationRegistry;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpstreamEncoderConnector;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.Snapshotter;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.SnapshotterBuilder;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultMarketDataEntry;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;

@Configuration
public class RFXVenueSubscribingConfig {
    private static final Venue VENUE = Venue.RFX;

    private final String marketdataTransport;
    private final String compId;
    private final String senderCompId;
    private final int source;

    public RFXVenueSubscribingConfig(final @Value("${apama.iaf.marketdata.transport.RFX}") String marketdataTransport,
                                     final @Value("${messaging.compId}") String compId,
                                     final @Value("${messaging.RFX.compId}") String senderCompId,
                                     final @Value("${messaging.source}") int source) {
        this.marketdataTransport = Objects.requireNonNull(marketdataTransport);
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.source = source;
    }

    @Bean
    public SourceSequencer sourceSequencer(@Value("${messaging.source.id}") final int sourceId) {
        return SourceSequencer.of(sourceId);
    }

    @Bean
    protected ConnectionConfig rfxConnectionConfig(final @Value("${apama.iaf.host.RFX}") String host,
                                                   final @Value("${apama.iaf.port.RFX}") int port,
                                                   final @Value("${apama.connectionPollingInterval:30000}") int connectionPollingInterval) {
        return new DefaultConnectionConfig(VENUE, host, port, connectionPollingInterval);
    }

    @Bean
    protected VenueRequestKeyLookup rfxVenueRequestKeyLookup() {
        return new DefaultVenueRequestKeyLookup(VENUE);
    }

    @Bean(destroyMethod = "clearAllBooksAndForwardEmptySnapshots")
    protected PricingEncoderLookup rfxPricingEncoderLookup(final Function<Consumer<SbeMessage>, PricingEncoderSupplier> pricingEncoderSupplierFactory,
                                                           final PrecisionClock precisionClock,
                                                           final @Value("${market.data.book.initial.size:10}") int marketDataBookInitialSize,
                                                           final LongIdFactory messageIdFactory,
                                                           final TopicRegistry pricingTopicRegistry,
                                                           final MessageHandler publisher) {
        return new DefaultPricingEncoderLookup(pricingTopicRegistry, requestKey -> {
            final SnapshotterBuilder builder = SnapshotterBuilder
                    .withMarketDataBook(new DefaultMarketDataBook(requestKey, marketDataBookInitialSize, DefaultMarketDataEntry::new, MarketDataEntries.Factory.SIDE_PRICE))
                    .withDownstreamEncoder()
                    .forwardSnapshotsAndIncrementsTo(
                            pricingEncoderSupplierFactory.apply(SbeMessagePublisher.create(requestKey, pricingTopicRegistry, publisher)));

            final Snapshotter snapshotter = builder.buildSnapshotter(precisionClock,  messageIdFactory::get, compId, source);
            final UpstreamEncoderConnector upstreamEncoderConnector = builder.buildUpstreamEncoderConnector(UpdateTypeMismatchHandler.WARN);
            return SnapshotterAccessor.create(snapshotter, upstreamEncoderConnector);
        });
    }

    @Bean
    public MarketDataBooksClearingConnectionStatusHandler rfxConnectionStatusHandler(final PricingEncoderLookup rfxPricingEncoderLookup) {
        return new MarketDataBooksClearingConnectionStatusHandler(rfxPricingEncoderLookup);
    }

    @Bean
    protected Connection rfxApamaConnection(final Transport apamaTransport,
                                            final ConnectionConfig rfxConnectionConfig,
                                            final ConnectionStatusHandler rfxConnectionStatusHandler) {
        return apamaTransport.openConnection(rfxConnectionConfig, rfxConnectionStatusHandler);
    }

    @Bean
    protected ApamaEventDecoder rfxLoggedOffEventDecoder(final PricingEncoderLookup rfxPricingEncoderLookup) {
        return new LoggedOffEventDecoder(rfxPricingEncoderLookup, marketdataTransport);
    }

    @Bean
    protected ApamaEventDecoder rfxHeartbeatResponseDecoder(final PricingEncoderLookup rfxPricingEncoderLookup) {
        return new IAFStatusResponseDecoder(rfxPricingEncoderLookup, marketdataTransport);
    }

    @Bean
    protected ApamaEventDecoder rfxApamaDepthEventDecoder(final VenueRequestKeyLookup rfxVenueRequestKeyLookup,
                                                          final PricingEncoderLookup rfxPricingEncoderLookup,
                                                          final PrecisionClock precisionClock,
                                                          final @Value("#{${mapi.symbol.map}}") Map<String, String> mapiSymbolMap,
                                                          final LongIdFactory messageIdFactory,
                                                          final SourceSequencer sourceSequencer) {
        return new ReutersMapiDepthDecoder(rfxVenueRequestKeyLookup, rfxPricingEncoderLookup, precisionClock, mapiSymbolMap, senderCompId, compId, messageIdFactory::get, sourceSequencer);
    }

    @Bean
    protected Subscription rfxDepthSubscription(final Connection rfxApamaConnection,
                                                final ApamaEventDecoder rfxApamaDepthEventDecoder) {
        return rfxApamaConnection.openSubscription(Depth.EVENT_TYPE, rfxApamaDepthEventDecoder::decode);
    }

    @Bean
    protected Subscription rfxLoggedOffSubscription(final Connection rfxApamaConnection,
                                                    final ApamaEventDecoder rfxLoggedOffEventDecoder) {
        return rfxApamaConnection.openSubscription(LoggedOff.EVENT_TYPE, rfxLoggedOffEventDecoder::decode);
    }

    @Bean
    protected Subscription rfxHeartbeatResponseSubscription(final Connection rfxApamaConnection,
                                                            final ApamaEventDecoder rfxHeartbeatResponseDecoder) {
        return rfxApamaConnection.openSubscription(IAFStatusResponse.EVENT_TYPE, rfxHeartbeatResponseDecoder::decode);
    }

    @Bean
    protected VenuePublications rfxVenuePublications(final TopicRegistry pricingTopicRegistry,
                                                     final PublicationRegistry publicationRegistry,
                                                     @Value("#{${symbol.venues.FXSPOT}}") final Map<String, Set<Venue>> fxSpotSymbolVenues) {

        return new VenuePublications(VENUE, pricingTopicRegistry, publicationRegistry, fxSpotSymbolVenues, Collections.emptyMap());
    }

    @Autowired
    @Qualifier("rfxVenuePublications")
    private VenuePublications rfxVenuePublications;

    @PostConstruct
    public void init() {
        rfxVenuePublications.init();
    }

}
