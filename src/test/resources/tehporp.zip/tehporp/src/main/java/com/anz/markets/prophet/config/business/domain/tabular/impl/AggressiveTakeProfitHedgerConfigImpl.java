package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveTakeProfitHedgerConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.jetbrains.annotations.NotNull;


@SuppressWarnings("CPD-START")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AggressiveTakeProfitHedgerConfigImpl implements AggressiveTakeProfitHedgerConfig, ProphetMarshallable {
    private Market market;
    private Instrument instrument;
    private double maximumRiskIncrease = Double.NaN;
    private double triggeringTradeMultiplier = Double.NaN;
    private double minimumTriggerQuantity = Double.NaN;
    private double minimumPriceImprovementPips = Double.NaN;
    private long activePeriodMS;
    private String counterparty;
    private double minimumOrderQuantity;
    private boolean liquidityCheckEnabled = true;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public AggressiveTakeProfitHedgerConfigImpl() {
    }

    public AggressiveTakeProfitHedgerConfigImpl(final Market market,
                                                final Instrument instrument) {
        this.market = market;
        this.instrument = instrument;
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public double getMaximumRiskIncrease() {
        return maximumRiskIncrease;
    }

    @Override
    public double getTriggeringTradeMultiplier() {
        return triggeringTradeMultiplier;
    }

    @Override
    public double getMinimumTriggerQuantity() {
        return minimumTriggerQuantity;
    }

    @Override
    public double getMinimumOrderQuantity() {
        return minimumOrderQuantity;
    }

    @Override
    public double getMinimumPriceImprovementPips() {
        return minimumPriceImprovementPips;
    }

    @Override
    public long getActivePeriodMS() {
        return activePeriodMS;
    }

    @Override
    public String getCounterparty() {
        return counterparty;
    }

    @Override
    public boolean isLiquidityCheckEnabled() {
        return this.liquidityCheckEnabled;
    }

    public AggressiveTakeProfitHedgerConfigImpl setMaximumRiskIncrease(final double maximumRiskIncrease) {
        this.maximumRiskIncrease = maximumRiskIncrease;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setTriggeringTradeMultiplier(final double triggeringTradeMultiplier) {
        this.triggeringTradeMultiplier = triggeringTradeMultiplier;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setMinimumTriggerQuantity(final double minimumTriggerQuantity) {
        this.minimumTriggerQuantity = minimumTriggerQuantity;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setMinimumPriceImprovementPips(
            final double minimumPriceImprovementPips) {
        this.minimumPriceImprovementPips = minimumPriceImprovementPips;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setActivePeriodMS(final long activePeriodMS) {
        this.activePeriodMS = activePeriodMS;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setCounterparty(final String counterparty) {
        this.counterparty = counterparty;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setMinimumOrderQuantity(final double minimumOrderQuantity) {
        this.minimumOrderQuantity = minimumOrderQuantity;
        return this;
    }

    public AggressiveTakeProfitHedgerConfigImpl setLiquidityCheckEnabled(final boolean liquidityCheckEnabled) {
        this.liquidityCheckEnabled = liquidityCheckEnabled;
        return this;
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        this.market = Market.valueOf(in.readByte());
        this.instrument = Instrument.readMarshallableValueOf(in);
        Context.context().header().since(MessageVersion.VERSION_0_21, () -> {
            this.maximumRiskIncrease = in.readDouble();
            this.triggeringTradeMultiplier = in.readDouble();
            this.minimumTriggerQuantity = in.readDouble();
            this.minimumPriceImprovementPips = in.readDouble();
            this.activePeriodMS = in.readLong();
            this.counterparty = in.readUTF8();
        });
        Context.context().header().since(MessageVersion.VERSION_0_36, () -> minimumOrderQuantity = in.readDouble() );
        Context.context().header().since(MessageVersion.VERSION_0_52, () -> liquidityCheckEnabled = in.readBoolean());
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        out.writeByte(this.market.getValue());
        out.writeShort(this.instrument.getValue());
        out.writeDouble(this.maximumRiskIncrease);
        out.writeDouble(this.triggeringTradeMultiplier);
        out.writeDouble(this.minimumTriggerQuantity);
        out.writeDouble(this.minimumPriceImprovementPips);
        out.writeLong(this.activePeriodMS);
        out.writeUTF8(this.counterparty);
        out.writeDouble(this.minimumOrderQuantity);
        out.writeBoolean(this.liquidityCheckEnabled);
    }

    @Override
    public String toString() {
        return "AggressiveTwapHedgerConfigImpl{" +
                "market=" + market +
                ", instrument=" + instrument +
                ", maximumRiskIncrease=" + maximumRiskIncrease +
                ", triggeringTradeMultiplier=" + triggeringTradeMultiplier +
                ", minimumTriggerQuantity=" + minimumTriggerQuantity +
                ", minimumOrderQuantity=" + minimumOrderQuantity +
                ", minimumPriceImprovementPips=" + minimumPriceImprovementPips +
                ", activePeriodMS=" + activePeriodMS +
                ", counterparty=" + counterparty +
                ", liquidityCheckEnabled=" + liquidityCheckEnabled +
                '}';
    }

}
