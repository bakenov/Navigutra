package com.anz.axle.lg.adapter.hsp.chronicleitch.acceptance;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.itch.sessioncode.messages.client.LoginRequest;
import software.chronicle.itch.sessioncode.messages.client.LogoutRequest;
import software.chronicle.itch.staticcode.ItchClientSessionHandler;
import software.chronicle.itch.staticcode.ItchServerSessionHandler;
import software.chronicle.itch.staticcode.ItchSessionHandler;
import software.chronicle.itchcboe.messages.MessageNotifier;
import software.chronicle.itchcboe.messages.client.ClientHeartbeat;
import software.chronicle.itchcboe.messages.client.InstrumentDirectoryRequest;
import software.chronicle.itchcboe.messages.client.MarketDataSubscribeRequest;
import software.chronicle.itchcboe.messages.server.InstrumentDirectory;
import software.chronicle.itchcboe.messages.server.LoginAccepted;
import software.chronicle.itchcboe.messages.server.Sequenced;
import software.chronicle.itchcboe.messages.server.ServerHeartbeat;

public class TestMessageNotifier implements MessageNotifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(TestMessageNotifier.class);
    private final BlockingQueue<Marshallable> queue = new ArrayBlockingQueue<>(1024);

    public BlockingQueue<Marshallable> queue() {
        return queue;
    }

    @Override
    public void onLoginRequest(final ItchClientSessionHandler session, final LoginRequest loginRequest) {
        queue.add(((Marshallable) loginRequest).deepCopy());
    }

    @Override
    public void onLoginAccepted(final ItchServerSessionHandler session, final LoginAccepted loginAccepted) {
        queue.add(((Marshallable) loginAccepted).deepCopy());
    }

    @Override
    public void onClientHeartbeat(final ItchClientSessionHandler session, final ClientHeartbeat clientHeartbeat) {
        queue.add(((Marshallable) clientHeartbeat).deepCopy());
    }

    @Override
    public void onServerHeartbeat(final ItchServerSessionHandler session, final ServerHeartbeat serverHeartbeat) {
        queue.add(((Marshallable) serverHeartbeat).deepCopy());
    }

    @Override
    public void onInstrumentDirectory(final ItchServerSessionHandler session, final InstrumentDirectory instrumentDirectory) {
        queue.add(((Marshallable) instrumentDirectory).deepCopy());
    }

    @Override
    public void onInstrumentDirectoryRequest(final ItchClientSessionHandler session, final InstrumentDirectoryRequest instrumentDirectoryRequest) {
        queue.add(((Marshallable) instrumentDirectoryRequest).deepCopy());
    }

    @Override
    public void onSequenced(final ItchServerSessionHandler session, final Sequenced sequenced) {
        queue.add(((Marshallable) sequenced).deepCopy());
    }

    @Override
    public void onMarketDataSubscribeRequest(final ItchClientSessionHandler session, final MarketDataSubscribeRequest marketDataSubscribeRequest) {
        queue.add(((Marshallable) marketDataSubscribeRequest).deepCopy());
    }

    @Override
    public void onLogoutRequest(final ItchClientSessionHandler session, final LogoutRequest logoutRequest) {
        queue.add(((Marshallable) logoutRequest).deepCopy());
    }

    @Override
    public void onUnsupportedMessageType(final ItchSessionHandler session, final int msgType) {
        LOGGER.error("onUnsupportedMessageType |{}| received!", msgType);
    }
}
