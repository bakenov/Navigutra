package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import org.junit.Test;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_CONFIGURED;
import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class HedgeFirewallManagerTest extends ForEachHedgePortfolioBaseAcceptanceSpecification {

    @Test
    public void firewallBreachedShouldDisableHedgePortfolio() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -499.99, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_HOUR, Double.NEGATIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_DAY, Double.NEGATIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_PROFIT_PER_DAY, Double.POSITIVE_INFINITY, true),

                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_MIN, Double.NEGATIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_HOUR, Double.NEGATIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, REVAL_PNL_LOSS_PER_DAY, Double.NEGATIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, REALISED_POSITION_PER_30_SEC, Double.POSITIVE_INFINITY, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, UNREALISED_POSITION_PER_30_SEC, Double.POSITIVE_INFINITY, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9500));
        }
        when:
        {
            // make sure hedger is enable.
            prophet.receive(tdd.enableHedger(portfolio));
        }
        then:
        {
            // assert that it is on before breaching it.
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOn(portfolio));
        }
        when:
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9500));
        }
        and:
        {
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9495));
        }
        then:
        {
            // breached
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -500.0, -500.0, -500.0, 0, -499.99));

            // hedge status is now off (receive PENDING_DISABLE_FIREWALL, followed by DISABLED_FIREWALL)
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void firewallNotConfiguredShouldDisableHedgePortfolio() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setHedgeFirewallConfigs(asList())
            );
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.9500));
        }
        when:
        {
            // make sure hedger is enable.
            prophet.receive(tdd.enableHedger(portfolio));
        }
        then:
        {
            // assert that it is on before breaching it.
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOn(portfolio));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9505));
        }
        then:
        {
            // breached
            and:
            {
                // todo: revisit after all firewall done to assert for all firewall type.
                final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
                assertThat(status.getStatus(), is(NOT_CONFIGURED));
                assertThat(status.getPortfolio(), is(portfolio));
            }
            and:
            {
                // hedge status is now off (receive PENDING_DISABLE_FIREWALL, followed by DISABLED_FIREWALL)
                prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
                prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsOff(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
            }
        }
    }
}
