#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_price_freq_au - Plugin to monitor the Price Update Frequency (All Venue)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=z::deprecated
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Price Update Frequency (All) [DEPRECATED]'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category z::deprecated'
    echo 'graph_scale no'
    echo 'price1.label Venue Price Updates (BARX)'
    echo 'price1.draw AREA'
    echo 'price2.label Venue Price Updates (CNX)'
    echo 'price2.draw STACK'
    echo 'price3.label Venue Price Updates (EBS)'
    echo 'price3.draw STACK'
    echo 'price19.label Venue Price Updates (EBSD)'
    echo 'price19.draw STACK'
    echo 'price4.label Venue Price Updates (RFX)'
    echo 'price4.draw STACK'
    echo 'price6.label Venue Price Updates (MSI)'
    echo 'price6.draw STACK'
    echo 'price7.label Venue Price Updates (CME)'
    echo 'price7.draw STACK'
    echo 'price8.label Venue Price Updates (DEUT)'
    echo 'price8.draw STACK'
    echo 'price9.label Venue Price Updates (GS)'
    echo 'price9.draw STACK'
    echo 'price9.colour 0080ff'		# don't use red
    echo 'price10.label Venue Price Updates (CMZ)'
    echo 'price10.draw STACK'        
    echo 'price14.label Venue Price Updates (HSP)'
    echo 'price14.draw STACK'        
    echo 'price15.label Venue Price Updates (UBS)'
    echo 'price15.draw STACK'
    echo 'price16.label Venue Price Updates (GCS)'
    echo 'price16.draw STACK'
    echo 'price17.label Venue Price Updates (CITI)'
    echo 'price17.draw STACK'
    echo 'price20.label Venue Price Updates (FXBK)'
    echo 'price20.draw STACK'
    echo 'price18.label Venue Price Updates (ANZD)'
    echo 'price18.draw STACK'
    exit 0
fi

echo "price1.value U"
echo "price2.value U"
echo "price3.value U"
echo "price19.value U"
echo "price4.value U"
echo "price6.value U"
echo "price7.value U"
echo "price8.value U"
echo "price9.value U"
echo "price10.value U"
echo "price14.value U"
echo "price15.value U"
echo "price16.value U"
echo "price17.value U"
echo "price20.value U"
echo "price18.value U"
exit 0
