package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.common.EndEventImpl;
import com.anz.markets.prophet.event.EndEventHopAppender;
import com.anz.markets.prophet.event.EventContext;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.GloballyUniqueSequenceIdGenerator;
import com.anz.markets.prophet.status.TimeSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

import static com.anz.markets.prophet.chronicle.ChronicleObjectReader.FILTERED_LOG_EVENT_INTERVAL;
import static com.anz.markets.prophet.status.TimeSource.UNSET_TIMESTAMP_NS;

/**
 * Used to hook into events while reading messages from or persisting messages into a chronicle queue
 */
public interface ChronicleHook {
    void onEvent(final Context context, final MessageType messageType);

    /**
     * Enable composite hooks
     */
    default ChronicleHook then(final ChronicleHook afterHook) {
        return (context, messageType) -> {
            onEvent(context, messageType);
            afterHook.onEvent(context, messageType);
        };
    }

    Logger LOGGER = LoggerFactory.getLogger(ChronicleHook.class);

    ChronicleHook
            DO_NOTHING = (context, messageType) -> { /**/ },
            START_READ = (context, messageType) -> {
                final Header header = context.header();
                header.setStartTimeStampNS(context.timeSource().nowNanosRealTime());
                header.setMsgTypeBeingRead(messageType);
            },
            COMMON_BEFORE_WRITE = (context, messageType) -> {
                final Header header = context.header();
                header.setProcessedByCoreInstance(context.instance());
                if (messageType == MessageType.END_EVENT) {
                    // END_EVENT start time stamp is set after de-marshalling the header of the first message from a unique eventID
                    header.setStartTimeStampNS(context.eventContext().getAfterHeaderReadStartTimeStampNS());
                }
            },
            BEFORE_WRITE = (context, messageType) -> {
                final Header header = context.header();
                header.setFinishTimeStampNS(context.timeSource().nowNanosRealTime());
            },
            CORE_BEFORE_WRITE = (context, messageType) -> {
                final Header header = context.header();
                final MessageType msgTypeBeingRead = header.getMsgTypeBeingRead();
                final long finishTimeStampNS = header.getFinishTimeStampNS();

                // If message to be written is not the same as message being read, then it implies that a message was created (also, don't mess with END_EVENT timestamps)
                final boolean newMessageCreated = (msgTypeBeingRead != MessageType.UNKNOWN) && (messageType != MessageType.END_EVENT) && (messageType != msgTypeBeingRead);
                // Use prior message's finish time stamp as this message's start time stamp, if any
                final boolean priorMessageHasFinishTimeStamp = finishTimeStampNS != UNSET_TIMESTAMP_NS;
                if (newMessageCreated && priorMessageHasFinishTimeStamp) {
                    header.setIntermediateStartTimeStampNS(finishTimeStampNS);
                }

                header.setFinishTimeStampNS(context.timeSource().nowNanosRealTime());
            },
            CORE_AFTER_WRITE = (context, messageType) -> {
                context.header().setIntermediateStartTimeStampNS(TimeSource.UNSET_TIMESTAMP_NS);
            };

    static ChronicleHook eventInception() {
        return new EventInceptionHook();
    }

    static ChronicleHook endEventInception(final Consumer<EndEvent> endEventSink) {
        return new EndEventInceptionHook(endEventSink);
    }

    static ChronicleHook endEventHop(final EndEventHopAppender hopAppender) {
        return new EndEventHook(hopAppender);
    }

    static ChronicleHook unknownMessageCounter() {
        return new UnknownMessageTypeHook();
    }

    class UnknownMessageTypeHook implements ChronicleHook {
        private long unknownCount = 0;

        @Override
        public void onEvent(final Context context, final MessageType messageType) {
            // TODO: we can't distinguish between unknown vs filtered as UNKNOWN's value is 0.
            if ((unknownCount++ % FILTERED_LOG_EVENT_INTERVAL) == 0) {
                LOGGER.info("Filtered empty/unknown data {}", unknownCount);
            }
        }
    }

    /**
     * Sets up an event's unique id and timestamps as they enter the prophet realm
     */
    class EventInceptionHook implements ChronicleHook {
        private final GloballyUniqueSequenceIdGenerator eventIdGenerator = initEventIdGenerator();

        private GloballyUniqueSequenceIdGenerator initEventIdGenerator() {
            final Context context = Context.context();
            // initing here to ensure region/instance/stage is set correctly.
            final Region region = context.region();
            if (region == Region.UNKNOWN) {
                LOGGER.warn("Region has not been set.  Event id generator will use UNKNOWN region.");
            }
            final Stage stage = context.stage();
            if (stage == Stage.UNKNOWN) {
                LOGGER.warn("Stage has not been set.  Event id generator will use UNKNOWN stage.");
            }
            return new GloballyUniqueSequenceIdGenerator(region.getValue(), stage.getValue(), context.instance(), true);
        }

        @Override
        public void onEvent(final Context context, final MessageType messageType) {
            final Header header = context.header();
            final long nowTimeStampNS = context.timeSource().nowNanos();

            header.setEventId(eventIdGenerator.incrementAndGetId());
            header.setEventTimeStampNS(nowTimeStampNS);
            header.setFinishTimeStampNS(nowTimeStampNS);
        }
    }

    /**
     * Create a corresponding endEvent on for a message read from chronicle.in
     * <p>
     * Use ONLY when reading from chronicle.in
     */
    class EndEventInceptionHook implements ChronicleHook {
        private final EndEventImpl endEvent = new EndEventImpl();
        private final Consumer<EndEvent> endEventSink;

        EndEventInceptionHook(final Consumer<EndEvent> endEventSink) {
            this.endEventSink = endEventSink;
        }

        @Override
        public void onEvent(final Context context, final MessageType messageType) {
            final EventContext eventContext = context.eventContext();
            endEvent.setStage(context.stage());
            endEvent.setMessageType(messageType);
            endEvent.addFirstHop(eventContext.getCurrentEventStartTimeStampNS(), eventContext.getCurrentEventFinishTimeStampNS());
            endEventSink.accept(endEvent);
        }
    }

    /**
     * Hook for triggering addition of a hop info
     */
    class EndEventHook implements ChronicleHook {
        private final EndEventHopAppender hopAppender;

        EndEventHook(final EndEventHopAppender hopAppender) {
            this.hopAppender = hopAppender;
        }

        @Override
        public void onEvent(final Context context, final MessageType messageType) {
            if (messageType == MessageType.END_EVENT) {
                hopAppender.appendHopDetails();
            }
        }
    }
}
