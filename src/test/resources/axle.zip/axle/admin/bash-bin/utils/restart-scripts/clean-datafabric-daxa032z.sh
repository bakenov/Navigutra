#!/bin/bash
echo "Cleaning datafabric workspaces"
ssh AxlSv@daxa032z "rm -rf ~/axle/datafabric/workspace/*"

