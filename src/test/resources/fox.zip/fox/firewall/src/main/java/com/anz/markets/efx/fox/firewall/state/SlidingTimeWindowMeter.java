package com.anz.markets.efx.fox.firewall.state;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class SlidingTimeWindowMeter {
    private static final int DEFAULT_BUCKETS = 1024;
    private final long[] buckets;
    private final long bucketDurationNanos;

    private long nextBucket = 0;
    private long totalRate = 0;
    private long currentWindowRate = 0;

    public SlidingTimeWindowMeter(final long windowSize,
                                  final TimeUnit timeUnit) {
        this(
                determineBucketsFor(windowSize, timeUnit),
                timeUnit.toNanos(windowSize) / determineBucketsFor(windowSize, timeUnit),
                TimeUnit.NANOSECONDS);
    }

    private static int determineBucketsFor(final long windowSize,
                                           final TimeUnit timeUnit) {
        return (int) Math.min(timeUnit.toNanos(windowSize), DEFAULT_BUCKETS);
    }

    public SlidingTimeWindowMeter(final int buckets,
                                  final long bucketDuration,
                                  final TimeUnit timeUnit) {
        if (bucketDuration <= 0) {
            throw new IllegalArgumentException("invalid bucketDuration: " + bucketDuration);
        }
        this.buckets = new long[buckets];
        bucketDurationNanos = timeUnit.toNanos(bucketDuration);
    }

    public void add(final long timeInNanos, final long count) {
        tick(timeInNanos);
        currentWindowRate += count;
    }

    public long get(final long timeInNanos) {
        tick(timeInNanos);
        return totalRate + currentWindowRate;
    }

    private void tick(final long timeInNanos) {
        final long newBucket = toBucket(timeInNanos);
        nextBucket = fastForward(newBucket);
        while (nextBucket < newBucket) {
            nextBucket = stepForward();
        }
    }

    private long fastForward(final long newBucket) {
        if (newBucket - nextBucket > buckets.length) {
            Arrays.fill(buckets, 0);
            totalRate = 0;
            currentWindowRate = 0;
            return newBucket;
        }
        return nextBucket;
    }

    private long stepForward() {
        final int nextBucketIndex = index(nextBucket);
        totalRate += currentWindowRate - buckets[nextBucketIndex];
        buckets[nextBucketIndex] = currentWindowRate;
        currentWindowRate = 0;
        return nextBucket + 1;
    }

    private long toBucket(final long timeInNanos) {
        return timeInNanos / bucketDurationNanos;
    }

    private int index(final long bucket) {
        return (int) (bucket % buckets.length);
    }
}
