#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axlestats_price_receive_freq_au - Plugin to monitor the Price Receive Frequency

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=z::deprecated
 #%# capabilities=autoconf

=cut

#. $MUNIN_LIBDIR/plugins/plugin.sh


TAIL=/usr/bin/tail
. ~/apama/bin/apama_env > /dev/null


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title Price Receive Frequency [DEPRECATED]'
    #echo 'graph_args --upper-limit 768'
    echo 'graph_category z::deprecated'
    echo 'graph_scale no'
    echo 'price1.label Venue Price Updates Received (ANZD)'
    echo 'price1.draw AREA'
    echo 'price2.label Venue Price Updates Received (BARX)'
    echo 'price2.draw STACK'
    echo 'price3.label Venue Price Updates Received (CMZ)'
    echo 'price3.draw STACK'
    echo 'price4.label Venue Price Updates Received (CNX)'
    echo 'price4.draw STACK'
    echo 'price5.label Venue Price Updates Received (GS)'
    echo 'price5.draw STACK'
    echo 'price6.label Venue Price Updates Received (CME)'
    echo 'price6.draw STACK'
    echo 'price7.label Venue Price Updates Received (MSI)'
    echo 'price7.draw STACK'
    echo 'price8.label Venue Price Updates Received (UBS)'
    echo 'price8.draw STACK'
    echo 'price9.label Venue Price Updates Received (FXBK)'
    echo 'price9.draw STACK'
    exit 0
fi

echo "price1.value U"
echo "price2.value U"
echo "price3.value U"
echo "price4.value U"
echo "price5.value U"
echo "price6.value U"
echo "price7.value U"
echo "price8.value U"
echo "price9.value U"
exit 0