package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;
import java.util.function.LongSupplier;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.MarketDataIncrementalRefresh_MDEntry;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static com.anz.axle.lg.adapter.apama.decoder.FixNumericConstants.MIN_QTY;

public final class MarketDataEntriesEncoder {

    public static void encodeIncrementalEntries(final PricingEncoderSupplier mdMessageEncoderFactory,
                                                final RequestKey requestKey,
                                                final List<? extends Event> mdEntries,
                                                final int startIndex,
                                                final BiPredicate<? super RequestKey, ? super Event> entryAcceptor,
                                                final long sendingTimeNanos,
                                                final long receivingTimeNanos,
                                                final int maxImplicitUpdates,
                                                final String senderCompId,
                                                final String compId,
                                                final LongSupplier messageIdSupplier,
                                                final PrecisionClock precisionClock,
                                                final SourceSequencer sourceSequencer) {
        final int entriesCount = MdEntries.count(requestKey, mdEntries, startIndex, entryAcceptor);
        if (entriesCount > 0) {
            final long messageId = messageIdSupplier.getAsLong();
            final IncrementalRefreshEncoder.MdEntries.Next mdEntries_next = mdMessageEncoderFactory.incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                    .senderCompId().encode(compId)
                    .messageId(messageId)
                    .sendingTime(sendingTimeNanos)
                    .instrumentId(requestKey.instrumentKey().instrumentId())
                    .marketId(requestKey.market())
                    .tradeDate().encodeNull()
                    .settlDate().encodeNull()
                    .referenceSpotDate().encodeNull()
                    .mdFlags().clear()
                    .entriesStart(entriesCount * 2 + maxImplicitUpdates);

            for (int i = startIndex; i < mdEntries.size(); i++) {
                final Event mdEntry = mdEntries.get(i);
                if (!entryAcceptor.test(requestKey, mdEntry)) {
                    continue;
                }
                final double entryPx = mdEntry.getField(MarketDataIncrementalRefresh_MDEntry.FIELD_MD_ENTRY_PX);
                final double entrySize = mdEntry.getField(MarketDataIncrementalRefresh_MDEntry.FIELD_MD_ENTRY_SIZE);
                final EntryType side = MarketDataIncrementalRefresh_MDEntry.FIELD_MD_ENTRY_TYPE.getSide(mdEntry);
                //final String entryId = mdEntry.getField(MarketDataIncrementalRefresh_MDEntry.FIELD_MD_ENTRY_ID);
                final String mdUpdateActionStr = mdEntry.getField(MarketDataIncrementalRefresh_MDEntry.FIELD_MD_UPDATE_ACTION);
                final Map<Long, String> extraParams = mdEntry.getField(MarketDataIncrementalRefresh_MDEntry.FIELD_EXTRA_PARAMS);
                final double minQty = Double.parseDouble(extraParams.getOrDefault(MIN_QTY, "0"));
                //final String previousEntryId = extraParams.get(MD_ENTRY_REF_ID);
                final UpdateAction updateAction = updateAction(mdUpdateActionStr);

                final IncrementalRefreshEncoder.MdEntries.Body mdEntries_mdEntryRefId = mdEntries_next.next()
                        .transactTime(sendingTimeNanos)
                        .mdUpdateAction(updateAction)
                        .mdMkt(requestKey.market())
                        .mdEntryType(side)
                        .mdEntryPx(entryPx)
                        .mdEntrySize(entrySize)
                        .minQty(minQty)
                        .mdEntryFlags().clear()
                        .mdEntryId(0);

//                if (updateAction == UpdateAction.CHANGE && previousEntryId != null) {
//                    mdEntries_mdEntryRefId
//                        .mdEntryRefId(0) //FIXME previousEntryId
//                        .quoteEntryId(0);
//                } else {
//                    mdEntries_mdEntryRefId
//                        .mdEntryRefId(0)
//                        .quoteEntryId(0);
//                }
            }
            mdEntries_next.entriesComplete()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .messageComplete();
        }
    }

    private static UpdateAction updateAction(final String mdUpdateActionStr) {
        final UpdateAction updateAction;
        switch (mdUpdateActionStr) {
            case "0":
                updateAction = UpdateAction.NEW;
                break;
            case "1":
                updateAction = UpdateAction.CHANGE;
                break;
            case "2":
                updateAction = UpdateAction.DELETE;
                break;
            default:
                throw new IllegalArgumentException("Unsupported MDUpdateAction: " + mdUpdateActionStr);
        }
        return updateAction;
    }

    public static void encodeZeroEntriesForEmptySnapshot(final PricingEncoderSupplier encoderSupplier,
                                                         final Flag flag,
                                                         final RequestKey requestKey,
                                                         final long sendingTimeNanos,
                                                         final long receivingTimeNanos,
                                                         final String senderCompId,
                                                         final String compId,
                                                         final long messageId,
                                                         final PrecisionClock precisionClock,
                                                         final SourceSequencer sourceSequencer) {
        encoderSupplier.snapshotFullRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .possResend(false)
                .sendingTime(sendingTimeNanos)
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .marketId(requestKey.market())
                .tradeDate().encodeNull()
                .settlDate().encodeNull()
                .referenceSpotDate().encodeNull()
                .mdFlags().add(flag)
                .entriesEmpty()
                .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                .hopsComplete()
            .messageComplete();
    }
}
