package com.anz.axle.lg.adapter.apama.ebs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.tools4j.spockito.Spockito;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.event.EbsMarketDataSnapshotFullRefresh;
import com.anz.axle.lg.adapter.apama.event.MarketDataIncrementalRefresh_MDEntry;
import com.anz.markets.efx.ngaro.api.SecurityType;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class EventFunctionsTest {
    static final EventParser ENTRY_EVENT_PARSER = new EventParser(MarketDataIncrementalRefresh_MDEntry.EVENT_TYPE);
    static final EventParser MESSAGE_EVENT_PARSER = new EventParser(EbsMarketDataSnapshotFullRefresh.EVENT_TYPE);

    @Test
    @Spockito.Unroll({
            "| cfiCode | SecurityType |",
            "| RCSXXX   | FXSPOT  |",
            "| FFCNNO   | FXNDF   |",
            "| null     | FXSPOT  |"
    })
    @Spockito.Name("[{cfiCode}]: {SecurityType}")
    public void ENTRY_TO_SECURITY_TYPE(final String cfiCode, final SecurityType securityType) throws Exception {
        //given
        final String entryEventString = "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,1e+07,\"\",{461:\"" + cfiCode + "\",63:\"0\"})";
        final Event entryEvent = ENTRY_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.ENTRY_TO_SECURITY_TYPE.apply(entryEvent)).isEqualTo(securityType);
    }

    @Test
    public void ENTRY_TO_SETTL_DATE() throws Exception {
        //given
        final String settlDate = "30042017";
        final String entryEventString = "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,1e+07,\"\",{461:\"FFCNNO\",63:\"B\",64:\"" + settlDate + "\"})";
        final Event entryEvent = ENTRY_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.ENTRY_TO_SETTL_DATE.apply(entryEvent)).isEqualTo(settlDate);
    }

    @Test
    public void ENTRY_TO_SETTL_TYPE() throws Exception {
        //given
        final String settlType = "B";
        final String entryEventString = "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"AUD/USD\",.7885,1e+07,\"\",{461:\"FFCNNO\",63:\"" + settlType + "\",64:\"30042017\"})";
        final Event entryEvent = ENTRY_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.ENTRY_TO_SETTL_TYPE.apply(entryEvent)).isEqualTo(settlType);
    }

    @Test
    public void ENTRY_EVENT_TO_SYMBOL() throws Exception {
        //given
        final String symbol = "AUD/USD";
        final String entryEventString = "com.apama.fix.MarketDataIncrementalRefresh_MDEntry(\"1\",\"1\",\"\",\"" + symbol + "\",.7885,1e+07,\"\",{461:\"RCSXXX\",63:\"0\"})";
        final Event entryEvent = ENTRY_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.EVENT_TO_SYMBOL.apply(entryEvent)).isEqualTo(symbol);
    }

    @Test
    @Spockito.Unroll({
            "| cfiCode | SecurityType |",
            "| RCSXXX   | FXSPOT  |",
            "| FFCNNO   | FXNDF   |",
            "| null     | FXSPOT  |"
    })
    @Spockito.Name("[{cfiCode}]: {SecurityType}")
    public void MESSAGE_TO_SECURITY_TYPE(final String cfiCode, final SecurityType securityType) throws Exception {
        //given
        final String entryEventString = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"AUD/USD\",2," +
                "[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"0\",\"461\":\"" + cfiCode + "\",\"52\":\"20150225-05:06:24.575\"})";
        final Event entryEvent = MESSAGE_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.MESSAGE_TO_SECURITY_TYPE.apply(entryEvent)).isEqualTo(securityType);
    }

    @Test
    public void MESSAGE_TO_SETTL_DATE() throws Exception {
        //given
        final String settlDate = "30042017";
        final String entryEventString = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"AUD/USD\",2," +
                "[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"B\",\"64\":\"" + settlDate + "\",\"461\":\"FFCNNO\",\"52\":\"20150225-05:06:24.575\"})";
        final Event entryEvent = MESSAGE_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.MESSAGE_TO_SETTL_DATE.apply(entryEvent)).isEqualTo(settlDate);
    }

    @Test
    public void MESSAGE_TO_SETTL_TYPE() throws Exception {
        //given
        final String settlType = "B";
        final String entryEventString = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"AUD/USD\",2," +
                "[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"" + settlType + "\",\"64\":\"30042017\",\"461\":\"FFCNNO\",\"52\":\"20150225-05:06:24.575\"})";
        final Event entryEvent = MESSAGE_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.MESSAGE_TO_SETTL_TYPE.apply(entryEvent)).isEqualTo(settlType);
    }

    @Test
    public void MESSAGE_EVENT_TO_SYMBOL() throws Exception {
        //given
        final String symbol = "AUD/USD";
        final String entryEventString = "com.apama.fix.ebs.MarketDataSnapshotFullRefresh(\"EBS_FIX_MARKETDATA_AND_TRADING\",\"FIX.4.4:ANZ_UAT_BAU_EBS->ICAP_Ai_Server\",\"1\",\"" + symbol + "\",2," +
                "[com.apama.fix.MarketDataSnapshotFullRefresh_MDEntry(\"0\",.7882,4e+06,\"\",{})]," +
                "{},{\"35\":\"W\",\"63\":\"B\",\"64\":\"20170430\",\"461\":\"FFCNNO\",\"52\":\"20150225-05:06:24.575\"})";
        final Event entryEvent = MESSAGE_EVENT_PARSER.parse(entryEventString);

        //when + then
        assertThat(EventFunctions.EVENT_TO_SYMBOL.apply(entryEvent)).isEqualTo(symbol);
    }

}