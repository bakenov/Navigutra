package com.anz.axle.adapters.ndf2trep.config;

public enum MessagingProvider {
    UM, AERON, CHRONICLE
}
