package com.anz.markets.efx.fox.processor.pricing;

import java.lang.reflect.Modifier;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class UpstreamSnapshotFullRefreshHandlerRouterTest {
    @Test
    public void publicMethodsAreImplemented() throws Exception {
        Stream.of(UpstreamSnapshotFullRefreshHandlerRouter.class.getMethods())
                .filter(method -> Modifier.isPublic(method.getModifiers()))
                .filter(method -> !method.getDeclaringClass().equals(Object.class) )
                .forEach(method -> {
                    System.out.println("Checking if " + method.getName() + " declaring class is " + UpstreamSnapshotFullRefreshHandlerRouter.class.getName());
                    assertThat(method.getDeclaringClass()).isEqualTo(UpstreamSnapshotFullRefreshHandlerRouter.class);
                });
    }
}