package com.anz.axle.lg.adapter.hsp.chronicleitch;

import software.chronicle.itch.staticcode.AppMessage;
import software.chronicle.itch.staticcode.ItchServerSessionHandler;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ItchAppMessageSender implements Consumer<AppMessage> {
    private final Supplier<ItchServerSessionHandler> supplier;
    private ItchServerSessionHandler session;

    public ItchAppMessageSender(final Supplier<ItchServerSessionHandler> supplier) {
        this.supplier = Objects.requireNonNull(supplier);
    }

    @Override
    public void accept(final AppMessage message) {
        session().sendMessage(message);
    }

    private ItchServerSessionHandler session() {
        if (session == null) {
            session = supplier.get();
        }
        return session;
    }
}
