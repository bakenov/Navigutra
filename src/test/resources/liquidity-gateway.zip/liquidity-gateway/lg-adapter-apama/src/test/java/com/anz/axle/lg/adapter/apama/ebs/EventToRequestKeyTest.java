package com.anz.axle.lg.adapter.apama.ebs;

import java.util.function.BiPredicate;
import java.util.function.Function;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.event.Event;

import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EventToRequestKeyTest {
    @Mock
    private Function<Event, Tenor> eventToTenor;
    @Mock
    private Function<Event, String> eventToTranslatedSymbol;
    @Mock
    private Function<Event, String> eventToSymbol;
    @Mock
    private Function<Event, SecurityType> eventToSecurityType;
    @Mock
    private VenueRequestKeyLookup requestKeyLookup;
    @Mock
    private Event event;
    @Mock
    private BiPredicate<SecurityType, String> symbolValidator;

    //under test
    private EventToRequestKey eventToRequestKey;

    @Before
    public void setUp() throws Exception {
        eventToRequestKey = new EventToRequestKey(symbolValidator, eventToSymbol, eventToTranslatedSymbol, eventToSecurityType, eventToTenor, requestKeyLookup);
    }

    @Test
    public void apply_when_NDF() throws Exception {
        //given
        final String symbol = "USDTWS";
        final String translatedSymbol = "USDTW1";

        final SecurityType securityType = SecurityType.FXNDF;
        final Tenor tenor = Tenor.EOM1;

        when(symbolValidator.test(securityType, symbol)).thenReturn(true);
        when(eventToSymbol.apply(event)).thenReturn(symbol);
        when(eventToTranslatedSymbol.apply(event)).thenReturn(translatedSymbol);
        when(eventToSecurityType.apply(event)).thenReturn(securityType);
        when(eventToTenor.apply(event)).thenReturn(tenor);

        //when
        eventToRequestKey.apply(event);

        //then
        verify(requestKeyLookup).lookup(InstrumentKey.instrumentId(translatedSymbol, securityType, tenor));
    }

    @Test
    public void apply_when_SPOT() throws Exception {
        //given
        final String symbol = "AUDUSD";
        final String translatedSymbol = "AUDUSD";

        final SecurityType securityType = SecurityType.FXSPOT;

        when(eventToSymbol.apply(event)).thenReturn(symbol);
        when(symbolValidator.test(securityType, symbol)).thenReturn(true);
        when(eventToTranslatedSymbol.apply(event)).thenReturn(translatedSymbol);
        when(eventToSecurityType.apply(event)).thenReturn(securityType);

        //when
        eventToRequestKey.apply(event);

        //then
        verify(requestKeyLookup).lookup(InstrumentKey.instrumentId(symbol, securityType, Tenor.SP));
    }

}