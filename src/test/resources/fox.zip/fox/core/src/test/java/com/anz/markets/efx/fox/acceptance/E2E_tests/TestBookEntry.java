package com.anz.markets.efx.fox.acceptance.E2E_tests;

import java.util.EnumSet;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

public class TestBookEntry {
    public Venue marketId;
    public EntryType entryType;
    public double entryPx;
    public double entrySize;
    public EnumSet<Flag> entryFlag;

    public TestBookEntry() { super();}

    public TestBookEntry(final Venue marketId, final EntryType entryType, final double entryPx, final double entrySize,
                         final EnumSet<Flag> entryFlag) {
        this.marketId = marketId;
        this.entryType = entryType;
        this.entryPx = entryPx;
        this.entrySize = entrySize;
        this.entryFlag = entryFlag;
    }

    public static SnapshotFullRefresh.Entry makeEntry(final Venue market, final EntryType entry_type, final double entry_price,
                                                      final double entry_size, final EnumSet<Flag> entry_flag ){

        final long transact_time = 00123456;
        final double entry_fwd_points = 0.0;
        final double min_qty = 5000;
        final int entry_id = 1;
        final int quote_entry_id = 100;
        final int entry_position_no = 0;
        final SnapshotFullRefresh.Entry snapShotEntry = new SnapshotFullRefresh.Entry(transact_time, market,
                entry_type, entry_price, entry_fwd_points, entry_size,
                min_qty, entry_flag, entry_id, quote_entry_id, entry_position_no);

        return snapShotEntry;
    }
    @Override
    public String toString(){
        return "TestBookEntry{" +
                "marketId='" + marketId + '\'' +
                ", entryType=" + entryType +
                ", entryPx=" + entryPx +
                ", entrySize=" + entrySize +
                ", entryFlag=" + entryFlag +
                '}';
    }
}