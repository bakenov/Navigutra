package com.anz.axle.lg.adapter.barx;

import com.anz.markets.efx.pricing.codec.api.EntryType;

public class EntryIdPacking {
    private final static long PRICE_BAND_BITS = 28;

    public static int toId(final EntryType entryType, final int priceBand) {
        return (entryType.ordinal() << PRICE_BAND_BITS ) | priceBand;
    }
}