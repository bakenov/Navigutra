package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Before;
import org.junit.Test;

import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_1;
import software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1;
import software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1;
import software.chronicle.itchcboe.messages.MarketSnapshot;
import software.chronicle.itchcboe.messages.datamodel.DefaultMarketSnapshot;

import com.anz.axle.lg.adapter.fix.StringToIntCacheFactory;
import com.anz.axle.lg.adapter.fix.DefaultSubscriptionManager;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.PricingFlagsAppender;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.fix.SubscriptionManagerSymbolRepository;
import com.anz.axle.lg.adapter.fix.SubscriptionRequestSender;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoSnapshotFullRefreshEncoder;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class HspMarketSnapshotHandlerTest {

    private static final String SENDER_COMP_ID = "GB:GS";
    private static final String COMP_ID = "GB:lg-gs";
    private static final String SYMBOL_7 = "GBP/AUD";
    private static final String SYMBOL_6 = "GBPAUD";
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(SYMBOL_6);


    private static final long CURRENT_TIME = 34523453;

    private PricingEncoderSupplier encoderSupplier;
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager;
    private AtomicInteger id;
    private SymbolOrderIdSideLookUp lookUp;
    private HspMarketSnapshotHandler handler;
    private List<PricingMessage> pricingMessages;
    private String[] symbols;
    private Map<Long, StringToIntCache> string2IntMap = new HashMap<>();
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23, 50L);

    @Before
    public void setUp() throws Exception {
        pricingMessages = new ArrayList<>();
        lookUp = new SymbolOrderIdSideLookUp();
        encoderSupplier = new PojoPricingEncoderSupplier(m -> pricingMessages.add(m));
        id = new AtomicInteger(1);
        subscriptionManager = new DefaultSubscriptionManager(() -> id.incrementAndGet(), SubscriptionManagerSymbolRepository.create());
        symbols = new String[] {"AUD/CAD","AUD/CHF","AUD/JPY","AUD/NZD","AUD/USD","CAD/JPY","CHF/JPY","EUR/AUD","EUR/CAD","EUR/CHF","EUR/CZK","EUR/DKK","EUR/GBP","EUR/HUF","EUR/JPY","EUR/NOK"
                ,"EUR/NZD","EUR/PLN","EUR/SEK","EUR/USD","GBP/AUD","GBP/CAD","GBP/CHF","GBP/JPY","GBP/NZD","GBP/USD","NZD/JPY","NZD/USD","SGD/JPY","USD/CAD","USD/CHF","USD/CNH"
                ,"USD/DKK","USD/HKD","USD/ILS","USD/JPY","USD/MXN","USD/NOK","USD/PLN","USD/SEK","USD/SGD","USD/TRY","USD/ZAR","XAG/USD","XAU/USD"};
        scheduleAndSendSubscribeRequest(symbols);

                handler = new HspMarketSnapshotHandler(
                new DefaultVenueRequestKeyLookup(Venue.HSPMD),
                pricingEncoderLookup,
                precisionClock,
                subscriptionManager,
                () -> System.currentTimeMillis(),
                SENDER_COMP_ID,
                COMP_ID,
                lookUp,
                PricingFlagsAppender.noOp(), sourceSequencer);

        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
    }

    @Test
    public void handleEmptyMarketSnapshot() throws Exception {
        //given
        final String EMPTY_SNAPSHOT = "!software.chronicle.itchcboe.messages.datamodel.DefaultMarketSnapshot {\n" +
                "  length: 4,\n" +
                "  marketSnapshot_CcyPairsGrp_1s: [ ],\n" +
                "  noCcyPairs: 0\n" +
                "}\n";
        final MarketSnapshot snapshot = Marshallable.fromString(EMPTY_SNAPSHOT);

        //when
        handler.accept(snapshot);

        //then
        final PojoSnapshotFullRefreshEncoder pojoEncoder = (PojoSnapshotFullRefreshEncoder) encoderSupplier.snapshotFullRefresh();
        assertThat(pojoEncoder.message().body.instrumentId, is(0L));
    }

    @Test
    public void handleMarketSnapshot() throws Exception {
        //given
        final String SNAPSHOT_BID_OFFER = "!software.chronicle.itchcboe.messages.datamodel.DefaultMarketSnapshot {\n" +
                "  length: 109,\n" +
                "  marketSnapshot_CcyPairsGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/AUD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.81818, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"14705\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.83048, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"14706\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 } ],\n" +
                "  noCcyPairs: 1\n" +
                "}";
        final MarketSnapshot snapshot = Marshallable.fromString(SNAPSHOT_BID_OFFER);

        //when
        handler.accept(snapshot);

        //then
        assertThat("cached new BID orderId", lookUp.lookUpSide(INSTRUMENT_KEY.instrumentId(), entryId(INSTRUMENT_KEY.instrumentId(), "14705")), is(EntryType.BID));
        assertThat("cached new OFFER orderId", lookUp.lookUpSide(INSTRUMENT_KEY.instrumentId(), entryId(INSTRUMENT_KEY.instrumentId(), "14706")), is(EntryType.OFFER));

        final PojoSnapshotFullRefreshEncoder pojoEncoder = (PojoSnapshotFullRefreshEncoder) encoderSupplier.snapshotFullRefresh();
        final SnapshotFullRefresh.Body body = pojoEncoder.message().body;
        assertThat(body.instrumentId, is(INSTRUMENT_KEY.instrumentId()));
        assertThat(body.marketId, is(Venue.HSPMD));

        assertThat(pojoEncoder.message().entries.size(), is(2));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryId, is(entryId(INSTRUMENT_KEY.instrumentId(), "14705")));
        assertThat(pojoEncoder.message().entries.get(0).mdEntryPx, is(1.81818));
        assertThat(pojoEncoder.message().entries.get(0).mdEntrySize, is(1000000.0));

        assertThat(pojoEncoder.message().entries.get(1).mdEntryType, is(EntryType.OFFER));
        assertThat(pojoEncoder.message().entries.get(1).mdEntryId, is(entryId(INSTRUMENT_KEY.instrumentId(), "14706")));
        assertThat(pojoEncoder.message().entries.get(1).mdEntryPx, is(1.83048));
        assertThat(pojoEncoder.message().entries.get(1).mdEntrySize, is(1000000.0));
    }

    private int entryId(final long instrumentId, final String entryId) {
        return string2IntMap.get(instrumentId).put(entryId);
    }

    @Test
    public void handleLargeMarketSnapshot() throws Exception {
        //given
        final String LARGE_SNAPSHOT = "!software.chronicle.itchcboe.messages.datamodel.DefaultMarketSnapshot {\n" +
                "  length: 559,\n" +
                "  marketSnapshot_CcyPairsGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/NOK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.6853, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"121\" } ],\n" +
                "          noBidOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.6973, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"25\" } ],\n" +
                "          noBidOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.6797, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"125\" } ],\n" +
                "          noBidOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.7045, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"199\" } ],\n" +
                "          noBidOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.7075, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"159\" } ],\n" +
                "          noBidOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.6826, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 6, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7138, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"160\" } ],\n" +
                "          noOfferOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7238, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"26\" } ],\n" +
                "          noOfferOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7368, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"126\" } ],\n" +
                "          noOfferOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7321, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"122\" } ],\n" +
                "          noOfferOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7344, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"124\" } ],\n" +
                "          noOfferOrders: 1 }, !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7166, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !software.chronicle.itchcboe.components.datamodel.DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"200\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 6 } ],\n" +
                "  noCcyPairs: 1\n" +
                "}";

        final MarketSnapshot snapshot = Marshallable.fromString(LARGE_SNAPSHOT.replace("EUR/NOK", SYMBOL_7));

        //when
        handler.accept(snapshot);

        //then
        final PojoSnapshotFullRefreshEncoder pojoEncoder = (PojoSnapshotFullRefreshEncoder) encoderSupplier.snapshotFullRefresh();
        final SnapshotFullRefresh.Body body = pojoEncoder.message().body;

        assertThat(body.instrumentId, is(INSTRUMENT_KEY.instrumentId()));
        assertThat(pojoEncoder.message().entries.size(), is(12));
    }

    @Test
    public void handleLargeMarketSnapshotWithManyCcyPairs() throws Exception {
        ClassAliasPool.CLASS_ALIASES.addAlias(DefaultMarketSnapshot.class,
                DefaultMarketSnapshot_CcyPairsGrp_1.class,
                DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1.class,
                DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1.class);
        //given
        final String LARGE_SNAPSHOT_WITH_MANY_CCY_PAIRS = "!DefaultMarketSnapshot {\n" +
                "  length: 4189,\n" +
                "  marketSnapshot_CcyPairsGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/USD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.11688, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"155065\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.32, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 468E3, orderId: \"154762\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.13858, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"155066\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/USD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.2522, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"147059\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.26438, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"147060\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/CHF, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.98718, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"29897\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.9898, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"29898\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 112.719, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"127293\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 113.667, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"127294\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 128.241, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"71001\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 128.702, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"71002\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/CAD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.33392, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"41592\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.3477, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"41593\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: AUD/USD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.71715, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"34193\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.71919, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"34194\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/CHF, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.11819, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"20511\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.13147, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"20512\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/GBP, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.90159, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"100317\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.90441, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"100318\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: NZD/USD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.68567, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"25121\" } ],\n" +
                "          noBidOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.672, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 500E3, orderId: \"25123\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 2, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.68819, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"25122\" } ],\n" +
                "          noOfferOrders: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.7032, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 243458.0, orderId: \"25124\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 2 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/NOK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 8.5424, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"18231\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 8.5652, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"18232\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/DKK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 6.55929, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"8801\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 6.57185, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"8802\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/SEK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.0726, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"26089\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.0983, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"26090\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 141.552, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"33042\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 142.607, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"33043\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: AUD/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 81.147, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"33390\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 81.309, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"33391\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/NOK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 9.7113, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"15548\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 9.7275, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"15549\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/SEK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 10.3096, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"24233\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 10.347, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"24234\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/DKK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 7.45758, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"1412\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 7.46767, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"1413\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: CHF/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 113.694, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"9075\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 114.891, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"9076\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: AUD/CHF, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.70959, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"4135\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.71172, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"4136\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: AUD/CAD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 0.9616, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"10247\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 0.96391, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"10248\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/AUD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.57635, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"20725\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.5857, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"20726\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/CAD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.50641, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"14415\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.52731, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"14416\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/AUD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.74473, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"17531\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.75148, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"17532\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/CHF, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.23694, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"11303\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.25169, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"11304\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: CAD/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 84.228, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"7817\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 84.429, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"7818\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/SGD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.36536, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"17368\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.37992, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"17369\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: AUD/NZD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.03846, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"17154\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.04994, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"17155\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/MXN, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 20.2645, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"16406\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 20.3771, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"16407\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: NZD/JPY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 77.589, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"16984\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 77.809, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"16985\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/NZD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.64743, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"6819\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.65933, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"6820\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/CAD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.67972, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"11873\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.69056, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"11874\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: GBP/NZD, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 1.82225, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"7807\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 1.83583, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"7808\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/ZAR, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 14.2505, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"11834\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 14.4245, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"11835\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/TRY, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 5.30871, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"10889\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 5.33612, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"10890\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/HUF, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 319.21, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"7255\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 323.969, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"7256\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: EUR/CZK, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 25.6451, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"1961\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 25.9078, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"1962\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/CNH, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 6.9133, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"14451\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 6.9262, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"14452\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 }, !DefaultMarketSnapshot_CcyPairsGrp_1 { ccyPair: USD/ILS, marketSnapshot_CcyPairsGrp_BidPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_1 { bidPrice: 3.6892, marketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_BidPricesGrp_BidOrdersGrp_1 { amount: 1E6, orderId: \"1287\" } ],\n" +
                "          noBidOrders: 1 } ],\n" +
                "      noBidPrices: 1, marketSnapshot_CcyPairsGrp_OfferPricesGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_1 { offerPrice: 3.7524, marketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1s: [ !DefaultMarketSnapshot_CcyPairsGrp_OfferPricesGrp_OfferOrdersGrp_1 { amount: 1E6, orderId: \"1288\" } ],\n" +
                "          noOfferOrders: 1 } ],\n" +
                "      noOfferPrices: 1 } ],\n" +
                "  noCcyPairs: 39\n" +
                "}";

        final MarketSnapshot snapshot = Marshallable.fromString(LARGE_SNAPSHOT_WITH_MANY_CCY_PAIRS);

        //when
        handler.accept(snapshot);

        //then
        assertThat("noCcyPairs: 39", pricingMessages.size(), is(39));
        final SnapshotFullRefresh fullRefresh_1 = (SnapshotFullRefresh) pricingMessages.get(0);
        assertThat(fullRefresh_1.entries.size(), is(2));

        final SnapshotFullRefresh fullRefresh_39 = (SnapshotFullRefresh) pricingMessages.get(38);
        assertThat(fullRefresh_39.entries.size(), is(2));

        final SnapshotFullRefresh fullRefresh_NZDUSD = (SnapshotFullRefresh)pricingMessages.stream()
                .filter(s -> ((SnapshotFullRefresh)s).body.instrumentId == InstrumentKey.of("NZDUSD").instrumentId())
                .findFirst().get();
        assertThat(fullRefresh_NZDUSD.entries.size(), is(4));

        assertThat(fullRefresh_NZDUSD.entries.get(0).mdEntryType, is(EntryType.BID));
        assertThat(fullRefresh_NZDUSD.entries.get(0).mdEntryId, is(entryId(InstrumentKey.of("NZDUSD").instrumentId(), "25121")));
        assertThat(fullRefresh_NZDUSD.entries.get(0).mdEntryPx, is(0.68567));
        assertThat(fullRefresh_NZDUSD.entries.get(0).mdEntrySize, is(1000000.0));

        assertThat(fullRefresh_NZDUSD.entries.get(1).mdEntryType, is(EntryType.BID));
        assertThat(fullRefresh_NZDUSD.entries.get(1).mdEntryId, is(entryId(InstrumentKey.of("NZDUSD").instrumentId(), "25123")));
        assertThat(fullRefresh_NZDUSD.entries.get(2).mdEntryType, is(EntryType.OFFER));
        assertThat(fullRefresh_NZDUSD.entries.get(2).mdEntryId, is(entryId(InstrumentKey.of("NZDUSD").instrumentId(), "25122")));
        assertThat(fullRefresh_NZDUSD.entries.get(3).mdEntryType, is(EntryType.OFFER));
        assertThat(fullRefresh_NZDUSD.entries.get(3).mdEntryId, is(entryId(InstrumentKey.of("NZDUSD").instrumentId(), "25124")));
    }

    private void scheduleAndSendSubscribeRequest(final String ... symbols) {
        final SubscriptionRequestSender sender =  new SubscriptionRequestSender() {
            @Override
            public void sendSubscribeRequest(final long requestId, final MarketDataSubscription marketDataSubscription) {}
            @Override
            public void sendUnsubscribeRequest(final long requestId, final MarketDataSubscription marketDataSubscription) {}
        };

        final StringToIntCacheFactory stringToIntCacheFactory = new StringToIntCacheFactory(1000, 25, 1000, 8, 1);

        Arrays.asList(symbols).forEach(symbol -> {
            final StringToIntCache stringToIntCache = stringToIntCacheFactory.get();
            final MarketDataSubscription subscription = new HspItchMarketDataSubscription(Venue.HSPMD, symbol, stringToIntCache);
            string2IntMap.put(subscription.instrumentKey().instrumentId(), stringToIntCache);

            subscriptionManager.scheduleAndSendSubscribeRequest(subscription, sender);
        });
    }
}