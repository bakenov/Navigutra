package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Objects;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Function;

import com.apama.event.Event;

import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;


public final class EventRequestKeyMatcher implements BiPredicate<RequestKey, Event> {
    private final Function<Event, String> eventToSymbol;
    private final Function<Event, SecurityType> eventToSecurityType;
    private final Function<Event, Tenor> eventToTenor;

    public EventRequestKeyMatcher(final Function<Event, String> eventToSymbol,
                                  final Function<Event, SecurityType> eventToSecurityType,
                                  final Function<Event, Tenor> eventToTenor) {
        this.eventToSymbol = Objects.requireNonNull(eventToSymbol);
        this.eventToSecurityType = Objects.requireNonNull(eventToSecurityType);
        this.eventToTenor = Objects.requireNonNull(eventToTenor);
    }

    public static EventRequestKeyMatcher forEntryEvent(final Function<Event, String> ebsEntryEventToTranslatedSymbol, final Function<Event, Tenor> eventToTenor) {
        return new EventRequestKeyMatcher(ebsEntryEventToTranslatedSymbol,
                                          EventFunctions.ENTRY_TO_SECURITY_TYPE,
                                          eventToTenor);
    }

    @Override
    public boolean test(final RequestKey requestKey, final Event event) {
        final String symbol = eventToSymbol.apply(event);
        if (!symbol.equals(requestKey.instrumentKey().symbol())) return false;

        final SecurityType securityType = eventToSecurityType.apply(event);
        if (securityType != requestKey.instrumentKey().securityType()) return false;

        if (securityType == SecurityType.FXNDF) {
            final Tenor tenor = eventToTenor.apply(event);
            return tenor.equals(requestKey.instrumentKey().tenor());
        } else {
            return true;
        }
    }
}
