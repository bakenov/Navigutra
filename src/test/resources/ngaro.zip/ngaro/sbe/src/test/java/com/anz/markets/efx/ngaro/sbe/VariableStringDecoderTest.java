package com.anz.markets.efx.ngaro.sbe;

import java.io.IOException;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.junit.Test;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.core.ByteWriter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Unit test for {@link VariableStringDecoder}
 */
public class VariableStringDecoderTest {

    @Test(expected = NullPointerException.class)
    public void noNullSource() {
        StringDecoders.forVariableLength(null, 7);
    }
    @Test(expected = IllegalArgumentException.class)
    public void noNegativeLength() {
        StringDecoders.forVariableLength((tgt, off, len) -> 0, -1);
    }

    @Test
    public void decodeEmpty() throws Exception {
        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());

        //when
        input.putBytes(offset, "\000efghijklmno".getBytes());
        final String output = dec.decodeStringOrNull();

        //then
        assertNull("output should be null", output);
    }

    @Test
    public void decodeToString() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());

        //when
        input.putBytes(offset, "\006123456abcde".getBytes());
        final String output1 = dec.decodeStringOrNull();

        //then
        assertEquals("output1 should be 123456", "123456", output1);

        //when
        input.putBytes(offset, "\003XYZabcde".getBytes());
        final String output2 = dec.decodeStringOrNull();

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);
    }

    @Test
    public void decodeToStringViaCache() throws Exception {
        //given
        final ByteValueCache<String> cache = new ByteValueCache<>(AsciiString::toString);

        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());

        //when
        input.putBytes(offset, "\006123456abcde".getBytes());
        final String output1 = dec.decodeAndCache(cache);

        //then
        assertEquals("output1 should be 123456", "123456", output1);

        //when
        final String output11 = dec.decodeAndCache(cache);

        //then
        assertSame("output1 should be the same reference to  output1", output1, output11);
        assertTrue(cache.getCacheSize() == 1);

        //when
        input.putBytes(offset, "\003XYZabcde".getBytes());
        final String output2 = dec.decodeAndCache(cache);

        //then
        assertEquals("output2 should be XYZ", "XYZ", output2);

        //when
        final String output21 = dec.decodeAndCache(cache);

        //then
        assertSame("output21 should be the same reference to  output2", output2, output21);
        assertTrue(cache.getCacheSize() == 2);


        //when
        input.putBytes(offset, "\000sfgabcde".getBytes());
        final String output3 = dec.decodeAndCache(cache);

        //then
        assertEquals("output3 should be equal to null", null, output3);
    }

    @Test
    public void decodeToAppendable() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());
        final StringBuilder output = new StringBuilder("pqrstuvwxyz");

        //when
        input.putBytes(offset, "\006123456abcdefg".getBytes());
        final Appendable a1 = dec.decodeTo(output);

        //then
        assertEquals("output should end with 123456", "pqrstuvwxyz123456", output.toString());
        assertSame("returned appendable should be same as target", output, a1);

        //when
        input.putBytes(offset, "\003XYZabcdefg".getBytes());
        final Appendable a2 = dec.decodeTo(output);

        //then
        assertEquals("output should end with XYZ", "pqrstuvwxyz123456XYZ", output.toString());
        assertSame("returned appendable should be same as target", output, a2);

        //when
        input.putBytes(offset, "\003123456abcdefg".getBytes());
        final Appendable a3 = dec.decodeTo(output, Integer.MAX_VALUE);

        //then
        assertEquals("output should end with 123", "pqrstuvwxyz123456XYZ123", output.toString());
        assertSame("returned appendable should be same as target", output, a3);

        //when
        input.putBytes(offset, "\000abcdefg".getBytes());
        final Appendable a4 = dec.decodeTo(output);

        //then
        assertEquals("output should not have changed", "pqrstuvwxyz123456XYZ123", output.toString());
        assertSame("returned appendable should be same as target", output, a4);
    }

    @Test(expected = RuntimeException.class)
    public void decodeToAppendable_throwsException() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());
        final Appendable output = new Appendable() {
            @Override
            public Appendable append(final CharSequence csq) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
                throw new IOException("Test appendable exception");
            }

            @Override
            public Appendable append(final char c) throws IOException {
                throw new IOException("Test appendable exception");
            }
        };

        //when
        input.putBytes(offset, "\006123456abcdefg".getBytes());
        dec.decodeTo(output);

        //then: expect exception
    }

    @Test
    public void decodeToByteWriter() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());
        final StringBuilder output = new StringBuilder("pqrstuvwxyz");
        int tgtOffset = 0;

        //when
        input.putBytes(offset, "\006123456abcdefg".getBytes());
        final int len1 = dec.decodeTo(output, ByteWriter.STRING_BUILDER);

        //then
        assertEquals("output should contain 123456 at " + tgtOffset, "123456vwxyz", output.toString());
        assertEquals("len1 should be 6", 6, len1);

        //when
        input.putBytes(offset, "\003XYZabcdefg".getBytes());
        final int len2 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, Integer.MAX_VALUE);

        //then
        assertEquals("output should contain XYZ at " + tgtOffset, "XYZ456vwxyz", output.toString());
        assertEquals("len2 should be 3", 3, len2);

        //when
        tgtOffset = 1;
        input.putBytes(offset, "\003123456abcdefg".getBytes());
        final int len3 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, 3);

        //then
        assertEquals("output should contain 123 at " + tgtOffset, "X12356vwxyz", output.toString());
        assertEquals("len3 should be 3", 3, len3);

        //when
        tgtOffset = 0;
        input.putBytes(offset, "\000abcdefg".getBytes());
        final int len4 = dec.decodeTo(output, ByteWriter.STRING_BUILDER, tgtOffset, Integer.MAX_VALUE);

        //then
        assertEquals("output should not have changed", "X12356vwxyz", output.toString());
        assertEquals("len4 should be 0", 0, len4);
    }

    @Test
    public void decodeToNull() throws Exception {
        //given
        final int offset = 3;
        final MutableDirectBuffer input = new ExpandableArrayBuffer();
        final VariableStringSource source = (dst, off, len) -> {
            final int inLen = input.getByte(offset);
            final int readLen = Math.min(len, inLen);
            input.getBytes(offset + 1, dst, off, readLen);
            return readLen;
        };
        final StringDecoder dec = StringDecoders.forVariableLength(source, input.capacity());

        //when
        input.putBytes(offset, "\006123456abcdefg".getBytes());
        final int len1 = dec.decodeToNull();

        //then
        assertEquals("len1 should be 6", 6, len1);

        //when
        input.putBytes(offset, "\003XYZabcdefg".getBytes());
        final int len2 = dec.decodeToNull();

        //then
        assertEquals("len2 should be 3", 3, len2);

        //when
        input.putBytes(offset, "\000abcdefg".getBytes());
        final int len3 = dec.decodeToNull();

        //then
        assertEquals("len3 should be 0", 0, len3);
    }
}