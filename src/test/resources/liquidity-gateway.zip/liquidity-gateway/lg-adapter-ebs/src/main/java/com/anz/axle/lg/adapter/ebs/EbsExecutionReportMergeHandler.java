package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.TradeCaptureReport;

public interface EbsExecutionReportMergeHandler {

    void onExecutionReport(ExecutionReport executionReport);
    void onTradeCaptureReport(TradeCaptureReport tradeCaptureReport);
}
