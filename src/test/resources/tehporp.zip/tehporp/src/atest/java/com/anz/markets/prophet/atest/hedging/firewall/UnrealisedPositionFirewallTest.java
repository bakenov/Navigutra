package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgePortfolioConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderType;
import com.anz.markets.prophet.domain.order.TimeInForce;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.jetbrains.annotations.NotNull;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.SUSPICIOUS_DISCREPANCY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeTriggerState.BUY_REQ;
import static com.anz.markets.prophet.domain.HedgeTriggerType.AGR_AXL_TWAP;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURGBP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_ARBITRAGE;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_BGC;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_MID_FXALL;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_EBS;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_PASSIVE_RFX;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_FIREWALL;
import static com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition.DISABLE_BY_ORDER_TIMEOUT;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_17})
public class UnrealisedPositionFirewallTest extends RealisedPositionFirewallTest {

    private NewOrder hedgingOrder1;
    private NewOrder hedgingOrder2;
    private NewOrder hedgingOrder3;

    @Test
    public void openOrderTriggersBreach() {
        setup:
        {
            double unrealisedPositionLimit = 2_850_000;
            prophet.receive(setUpConfiguration(unrealisedPositionLimit)
                    .setAggressiveTwapHedgerConfigs(Lists.newArrayList(
                            new AggressiveTwapHedgerConfigImpl(Market.AXL, AUDUSD).setMaximumSpread(0.0001).setMinimumQuantity(3_000_000).setMinimumRisk(3_000_000).setOrderRateLimit(3_000_000).setOrderRateTimePeriodMS(1_000)
                    ))
                    .setHedgePortfolioConfigs(asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderCompleteTimeoutMS(10_000),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
        }
        when:
        // t+0, receive client deal to generate op pos
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, 0.9510));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, HEDGER_AGGRESSIVE));
        }
        when:
        // t+2 hedge order filled
        {
            prophet.incrementTime(1 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, HEDGER_AGGRESSIVE));
        }
        when:
        // t+3, send hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, 0.9510));
        }
        and:
        // t+4 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +6mio AUD     | +5.7mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*AUD.*5700000.*breached 2850000.0 limit.*"));
        }
        and: /* immediately goes to pending */
        {
            // todo: for some reason we are getting two hedge status at the same time instance.
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatusIsPendingDisable(HEDGER_AGGRESSIVE, DISABLE_BY_FIREWALL));
        }

        iocOrderTimesOut();
    }

    @Test
    public void resetFirewallWhenEnablingHedger() throws InterruptedException {
        setup:
        {
            double unrealisedPositionLimit = 2_850_000;
            prophet.receive(setUpConfiguration(unrealisedPositionLimit)
                    .setAggressiveTwapHedgerConfigs(Lists.newArrayList(
                            new AggressiveTwapHedgerConfigImpl(Market.AXL, AUDUSD).setMaximumSpread(0.0001).setMinimumQuantity(3_000_000).setMinimumRisk(3_000_000).setOrderRateLimit(3_000_000).setOrderRateTimePeriodMS(1_000)
                    ))
                    .setHedgePortfolioConfigs(asList(
                            new HedgePortfolioConfigImpl(Market.FXALLMB, HEDGER_MID_FXALL).setEnabled(true).setHedgerName("autotrader-MidHedger").setBookName("HEDGING_MODEL_M1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.BGCMIDFX, HEDGER_MID_BGC).setEnabled(true).setHedgerName("autotrader-MidHedgerBGC").setBookName("HEDGING_MODEL_M2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.EBSHEDGE, HEDGER_MID_EBS).setEnabled(true).setHedgerName("autotrader-MidHedgerEBS").setBookName("HEDGING_MODEL_M3").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_AGGRESSIVE).setEnabled(true).setHedgerName("autotrader-HungryHedger").setBookName("HEDGING_MODEL_1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50).setOrderCompleteTimeoutMS(10_000),
                            new HedgePortfolioConfigImpl(Market.EBS, HEDGER_PASSIVE_EBS).setEnabled(true).setHedgerName("autotrader-ChillaxHedger").setBookName("HEDGING_MODEL_P1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.RFX, HEDGER_PASSIVE_RFX).setEnabled(true).setHedgerName("autotrader-ChillaxHedgerRFX").setBookName("HEDGING_MODEL_P2").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.GTC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50),
                            new HedgePortfolioConfigImpl(Market.AXL, HEDGER_ARBITRAGE).setEnabled(true).setHedgerName("autotrader-StatArber").setBookName("HEDGING_MODEL_A1").setMaximumOpenOrders(5).setOrderType(OrderType.LIMIT).setOrderTimeInForce(TimeInForce.IOC).setMinimumTimeToLiveMS(1).setMaximumOpenVarOrders(50)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, 0.9510));
        }

        triggerFirewall();

        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.incrementTime(1_000); // increment time to cause a decision to be scheduled
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
            prophet.notExpect(NewOrder.class);
        }
        triggerFirewall();
    }

    public void triggerFirewall() {
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, HEDGER_AGGRESSIVE));
        }
        when:
        // t+2 hedge order filled
        {
            prophet.incrementTime(1 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, HEDGER_AGGRESSIVE));
        }
        when:
        // t+3, send hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_000_000, 0.9510));
        }
        and:
        // t+4 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +6mio AUD     | +5.7mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(getPositionFirewallType(), BREACHED, HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*AUD.*5700000.*breached 2850000.0 limit.*"));
        }
        and: /* immediately goes to pending */
        {
            // todo: for some reason we are getting two hedge status at the same time instance.
            prophet.expect(HedgeStatus.class, exactly(2), hedgeStatusIsPendingDisable(HEDGER_AGGRESSIVE, DISABLE_BY_FIREWALL));
        }

        iocOrderTimesOut();
    }

    private void iocOrderTimesOut() {
        when: /* hedger disabled when ioc timeout in 10ms */
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(9));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            // receiving 2 DISABLE_BY_ORDER_TIMEOUT!
            prophet.expect(HedgeStatus.class, atLeast(1), hedgeStatusIsOff(HEDGER_AGGRESSIVE, DISABLE_BY_ORDER_TIMEOUT));
        }
        and:
        // t+1 after orderRateTimePeriod before TWAP kicks in
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        and:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, AGR_AXL_TWAP, BUY_REQ));
        }
    }

    @Test
    public void multipleOpenOrdersTriggerBreach() {
        setup:
        {
            double unrealisedPosLimitBGCMid = 6_299_999;
            prophet.receive(setUpConfiguration(unrealisedPosLimitBGCMid)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURUSD).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURGBP).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: EUR: -2mio   | -2.1mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }

        when:
        // t+5 hedge order filled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1, 1.05000);
            // BGCMID Unrealised position: EUR: -2mio   | -2.1mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+10, receive client deal and MID_BGC send hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }

        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: EUR: -4mio   | -4.2mio USD
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC));
        }
        when:
        // t+15, receive client deal and MID_BGC send hedge trade 3
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 2_400_000, 0.85000));
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: EUR: -6mio   | -6.3mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*EUR.*6300000.*breached 6299999.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
        and: /* immediately goes to pending */
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsPendingDisable(HEDGER_MID_BGC, DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void crossPairBreachOnTermsCcy() {
        setup:
        {
            double unrealisedPosLimitBGCMid = 4_624_999;
            prophet.receive(setUpConfiguration(unrealisedPosLimitBGCMid)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, GBPUSD).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURGBP).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1 receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(GBPUSD, -2_000_100, 1.25000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position:
            // GBP: +2mio   | +2.5 USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
        when:
        // t+5, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.receive(tdd.client_trade_001(EURGBP, 2_000_100, 0.85123));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position:
            // EUR: -2mio           | -2.1mio USD
            // GBP: +2+1.7mio       | +4.625 USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*GBP.*4625000.*breached 4624999.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
        and:
        // hedgePortfolioState=PENDING_DISABLED, reason=DISABLE_BY_FIREWALL
        {
            prophet.expect(HedgeStatus.class, exactly(1), hedgeStatusIsPendingDisable(HEDGER_MID_BGC, DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void breachOnMidRateChange() {
        setup:
        {
            double unrealisedPositionLimit = 5_700_000;
            prophet.receive(setUpConfiguration(unrealisedPositionLimit)
                    .setAggressiveTwapHedgerConfigs(Lists.newArrayList(
                            new AggressiveTwapHedgerConfigImpl(Market.AXL, AUDUSD).setMaximumSpread(0.0001).setMinimumQuantity(3_000_000).setMinimumRisk(3_000_000).setOrderRateLimit(3_000_000).setOrderRateTimePeriodMS(1_000)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
        }
        when:
        // t+0, receive client deal and send hedge trade 1
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_200_000, 0.9510));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            assertThat(hedgingOrder1.getPrice(), Matchers.is(0.95008));
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_AGGRESSIVE));
        }

        when:
        // t+6 hedge order 1 filled
        {
            prophet.incrementTime(5 * 1_000);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE));
        }
        when:
        // t+11, receive client deal send hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_200_000, 0.9510));
        }
        and:
        // t+12 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +6mio AUD     | +5.7mio USD
        }
        and:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE));
        }
        when:
        // t+17 market mid updates
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95001));
        }
        then:
        // breaches
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*AUD.*5700060.*breached 5700000.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_AGGRESSIVE));
        }
        when:
        // t+22 market mid updates
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95000));
        }
        // not breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), Matchers.is(""));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_AGGRESSIVE));
        }
    }

    @Test
    public void unbreachWhenFilledTradeSlidesOutWindow() {
        setup:
        {
            double unrealisedPositionLimit = 2_850_000;
            prophet.receive(setUpConfiguration(unrealisedPositionLimit)
                    .setAggressiveTwapHedgerConfigs(Lists.newArrayList(
                            new AggressiveTwapHedgerConfigImpl(Market.AXL, AUDUSD).setMaximumSpread(0.0001).setMinimumQuantity(3_000_000).setMinimumRisk(3_000_000).setOrderRateLimit(3_000_000).setOrderRateTimePeriodMS(1_000)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.94998, Level.QTY_10M.getQty(), 0.95002, Level.QTY_10M.getQty()));
        }
        when:
        // t+1, receive client deal to generate op pos
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_200_000, 0.9510));
        }
        and:
        // t+2 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_AGGRESSIVE));
        }

        when:
        // t+7 hedge order filled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder1);
            // Unrealised position: AUD: +3mio AUD     | +2.85mio USD
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE));
        }
        when:
        // t+11, send hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.receive(tdd.client_trade_001(AUDUSD, -3_200_000, 0.9510));
        }
        and:
        // t+1 after orderRateTimePeriod
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 1_000);
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.BUY));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(3_000_000.0));
            // Unrealised position: AUD: +6mio AUD     | +5.7mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*AUD.*5700000.*breached 2850000.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_AGGRESSIVE));
        }
        when:
        // t33
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(21));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE));
        }
        when:
        // t37 first filled order slides out
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_AGGRESSIVE)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), matches(""));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_AGGRESSIVE));
        }
    }

    @Test
    public void unbreachWhenOpenOrderSlidesOutWindow() {
        setup:
        {
            double unrealisedPosLimitBGCMid = 4_199_999;
            prophet.receive(setUpConfiguration(unrealisedPosLimitBGCMid)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURUSD).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURGBP).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(2000000.0)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1, receive client deal to generate op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 2_000_100, 1.05000));
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: EUR: -2mio   | -2.1mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
        when:
        // t+15, receive client deal and MID_BGC send hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(14));
            prophet.receive(tdd.client_trade_001(EURGBP, 2_400_000, 0.85000));
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), Matchers.is(2_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: EUR: -4mio   | -4.2mio USD
        }
        and:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*EUR.*4200000.*breached 4199999.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
        when:
        // t31 first open order slides out
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(16));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), matches(""));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
    }

    @Test
    public void midHedgerFirewallsIndependentOfEachOther() {
        setup:
        {
            double unrealisedPosLimit = 1_699_999;
            prophet.receive(setUpConfiguration(unrealisedPosLimit)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.FXALLMB, AUDUSD).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, AUDUSD).setRiskTriggerLowWaterMark(500000).setRiskTriggerHighWaterMark(1000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(HEDGER_MID_FXALL));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.85000));

        }
        when:
        // t+1, receive client deal to generate gradient op pos and MID_BGC hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.85000));  // generate gradientPositionInNotional=3000000.0
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.FXALLMB)).getFirst();
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.BGCMIDFX)).getFirst();

            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.FXALLMB));
            // FXALLMID Unrealised position: AUD: -1mio   | -0.85mio USD

            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder2.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: AUD: -1mio   | -0.85mio USD
        }
        and:
        {
            final HedgeFirewallStatus statusBGCMid = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(statusBGCMid.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(statusBGCMid.getPortfolio(), Matchers.is(HEDGER_MID_BGC));

            final HedgeFirewallStatus statusFXALLMid = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL)).getFirst();
            assertThat(statusFXALLMid.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(statusFXALLMid.getPortfolio(), Matchers.is(HEDGER_MID_FXALL));
        }
        when:
        // t+5 BGCMID hedge order filled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(4));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2, 0.85);
            // BGCMID Unrealised position: AUD: -1mio   | -0.85mio USD
        }
        then:
        // after hedge fill, gradient pos still above BGC HighWaterMark so BGC places another hedge trade
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder3.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: AUD: -2mio   | -1.75mio USD  => BREACH
        }
        and:
        // BGCMid firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*AUD.*1700000.*breached 1699999.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_BGC));
        }
        and:
        // FXALL firewalls NOT breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL));
        }
    }

    @Test
    public void firewallHandlesCancelOrderEvents() {
        CancelOrder cancelOrder;

        setup:
        {
            double unrealisedPosLimit = 2_099_999;

            prophet.receive(setUpConfiguration(unrealisedPosLimit)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.FXALLMB, EURGBP).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                            new MidHedgerConfigImpl(Market.FXALLMB, EURUSD).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, EURUSD).setRiskTriggerLowWaterMark(750000).setRiskTriggerHighWaterMark(1000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0)
                    ))
                    , false);
            prophet.receive(tdd.enableHedger(HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(HEDGER_MID_FXALL));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));

        }
        when:
        // t+1, receive client deal to generate gradient op pos and MID_FXALL and MID_BGC hedgers sends hedge trades
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));  // generate gradientPositionInNotional=2250000.0
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.FXALLMB)).getFirst();
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.BGCMIDFX)).getFirst();

            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.FXALLMB));
            // FXALLMID Unrealised position: EUR: -1mio   | -1.05mio USD

            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder2.getMarket(), Matchers.is(Market.BGCMIDFX));
            // BGCMID Unrealised position: EUR: -1mio   | -1.05mio USD
        }
        and:
        {
            final HedgeFirewallStatus statusBGCMid = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC)).getFirst();
            assertThat(statusBGCMid.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(statusBGCMid.getPortfolio(), Matchers.is(HEDGER_MID_BGC));

            final HedgeFirewallStatus statusFXALLMid = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL)).getFirst();
            assertThat(statusFXALLMid.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(statusFXALLMid.getPortfolio(), Matchers.is(HEDGER_MID_FXALL));
        }
        when:
        // t+5 BGCMID hedge order filled, gradientPositionInNotional=750000.0
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(3));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder1));
            prophet.receive(tdd.hedgeOrderConfirmed(hedgingOrder2));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receiveHedgeOrderFullFill(hedgingOrder2, 1.05);
            // BGCMID Unrealised position: EUR: -1mio   | -1.05mio USD
        }
        then:
        // BGCMid firewalls NOT breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_BGC));

        }
        and:
        // since gradientPositionInNotional=750000.0 less than FXALLMID LowWaterMark, FXALLMID hedger sends cancel for its open order
        {
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(EURUSD, HedgeTriggerType.MID_FXALL_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), Matchers.is(HedgeTriggerState.CANCELLING));

            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
            assertThat(cancelOrder.getMarket(), Matchers.is(Market.FXALLMB));
        }
        when:
        // t10 receive client deal to generate gradient op pos on EURGBP and MID_FXALL sends hedge trade
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 15_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder3 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP)).getFirst();
            assertThat(hedgingOrder3.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder3.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder3.getMarket(), Matchers.is(Market.FXALLMB));
            // FXALLMID Unrealised position:
            // EUR: -2mio   | -2.10mio USD
        }
        and:
        // FXALLMID firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*EUR.*2100000.*breached 2099999.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_FXALL));
        }
        when:
        // t15 FXALLMID open order cancelled
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(hedgingOrder1, cancelOrder, 0, 0));
        }
        then:
        // FXALLMID firewall unbreach
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), matches(""));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_FXALL));
        }
    }

    @Test
    public void firewallHandlesRejectOrderEvents() {
        setup:
        {
            double unrealisedPosLimit = 2_099_999;
            prophet.receive(setUpConfiguration(unrealisedPosLimit)
                    .setMidHedgerConfigs(Lists.newArrayList(
                            new MidHedgerConfigImpl(Market.FXALLMB, EURUSD).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0),
                            new MidHedgerConfigImpl(Market.FXALLMB, EURGBP).setRiskTriggerLowWaterMark(1000000).setRiskTriggerHighWaterMark(2000000.0).setVarTriggerHighVar(50000.0).setOrderQuantity(1000000.0)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_MID_FXALL));

            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        // t+1, receive client deal to generate gradient op pos and hedger sends hedge trade 1
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(EURUSD, 1_500_000, 1.05000));  // generate gradientPositionInNotional=2250000.0
        }
        then:
        {
            hedgingOrder1 = prophet.expect(NewOrder.class, exactly(1), isOrderMarket(Market.FXALLMB)).getFirst();

            assertThat(hedgingOrder1.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder1.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder1.getMarket(), Matchers.is(Market.FXALLMB));
            // FXALLMID Unrealised position: EUR: -1mio   | -1.05mio USD
        }
        when:
        // t10 receive client deal to generate gradient op pos on EURGBP and MID_FXALL sends hedge trade
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(9));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 15_00_000, 0.85000));  // EURGBP gradientPositionNotional > 2mio
        }
        then:
        {
            hedgingOrder2 = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP)).getFirst();
            assertThat(hedgingOrder2.getSide(), Matchers.is(HedgeOrderSide.SELL));
            assertThat(hedgingOrder2.getQuantity(), Matchers.is(1_000_000.0));
            assertThat(hedgingOrder2.getMarket(), Matchers.is(Market.FXALLMB));
            // FXALLMID Unrealised position:
            // EUR: -2mio   | -2.10mio USD
        }
        and:
        // FXALLMID firewall breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL)).getFirst();
            assertThat(status.getStatus(), Matchers.is(BREACHED));
            assertThat(status.getDescription().toString(), matches(".*EUR.*2100000.*breached 2099999.0 limit.*"));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_FXALL));
        }
        when:
        // t+15 hedgingOrder2 rejected.
        {
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(5));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderReject(hedgingOrder2));
        }
        then:
        // firewall unbreached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(getPositionFirewallType(), HEDGER_MID_FXALL)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), matches(""));
            assertThat(status.getPortfolio(), Matchers.is(HEDGER_MID_FXALL));
        }
    }

    @NotNull
    protected HedgeFirewallType getPositionFirewallType() {
        return UNREALISED_POSITION_PER_30_SEC;
    }

    private ConfigurationDataDefault setUpConfiguration(double unrealisedPositionLimit) {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setHedgeFirewallConfigs(asList(
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, unrealisedPositionLimit, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, SUSPICIOUS_DISCREPANCY, NaN, true),

                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, UNREALISED_POSITION_PER_30_SEC, unrealisedPositionLimit, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_BGC, GB, SUSPICIOUS_DISCREPANCY, NaN, true),

                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, UNREALISED_POSITION_PER_30_SEC, unrealisedPositionLimit, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, AGGREGATED_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, true),
                        new HedgeFirewallConfigImpl(HEDGER_MID_FXALL, GB, SUSPICIOUS_DISCREPANCY, NaN, true)
                ));

        return configuration;
    }
}
