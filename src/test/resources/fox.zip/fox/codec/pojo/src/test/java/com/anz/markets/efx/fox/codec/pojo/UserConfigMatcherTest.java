package com.anz.markets.efx.fox.codec.pojo;

import java.util.EnumSet;
import java.util.function.Predicate;

import org.junit.Test;

import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.matcher.UserConfigMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import static com.anz.markets.efx.matcher.Matchers.translate;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class UserConfigMatcherTest {
    private Predicate<UserConfig> predicate = Matchers.isA(UserConfig.class);
    private UserConfigMatcher matcher = new UserConfigMatcher() {
        @Override
        public Matcher<UserConfigMatcher, UserConfig.Body> body() {
            return matcher -> andThen(translate(userConfig -> userConfig.body, matcher));
        }

        @Override
        public boolean test(Object o) {
            return o instanceof UserConfig && predicate.test((UserConfig) o);
        }

        private UserConfigMatcher andThen(final Predicate<? super UserConfig> next) {
            predicate = Matchers.and(predicate, next);
            return this;
        }
    };

    @Test
    public final void testBodyMethod(){
        final UserConfig userConfig = SorMessage.userConfig(
                new MessageHeader(),
                new UserConfig.Body("user1", EnumSet.of(UserGroup.TRADER, UserGroup.ADMIN), "Melbourne"));
        assertTrue(matcher.test(userConfig));
        assertNotNull(matcher.body());
    }
}
