package com.anz.markets.efx.ngaro.core;

import java.nio.ByteBuffer;

@FunctionalInterface
public interface ByteWriter<T> {
    void writeByte(T target, int index, byte b);

    ByteWriter<Object> NULL = (t, i, b) -> {};
    ByteWriter<MutableAsciiString> MUTABLE_ASCII_STRING = (t, i, b) -> {
        t.set(i, b);
    };
    ByteWriter<StringBuilder> STRING_BUILDER = (t, i, b) -> {
        t.setLength(Math.max(t.length(), i + 1));
        t.setCharAt(i, (char)b);
    };
    ByteWriter<ByteBuffer> BYTE_BUFFER = (t, i, b) -> t.put(i, b);
    ByteWriter<byte[]> BYTE_ARRAY = (t, i, b) -> t[i] = b;
}
