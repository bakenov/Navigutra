package com.anz.markets.efx.fox.processor.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import java.util.Objects;

public class AlwaysRejectParentOrderValidator implements ParentOrderValidator {
    private final String rejectReason;
    private final ErrorHandler errorHandler;


    public AlwaysRejectParentOrderValidator(final ErrorHandler handler,
                                            final String reason) {
        this.errorHandler = Objects.requireNonNull(handler);
        this.rejectReason = Objects.requireNonNull(reason);
    }

    @Override
    public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
        errorHandler.onError(rejectReason, parentOrderDecoder, commandContext);
        return false;
    }
}
