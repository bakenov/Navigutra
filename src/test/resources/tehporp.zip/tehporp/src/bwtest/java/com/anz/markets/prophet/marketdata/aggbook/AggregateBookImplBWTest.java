package com.anz.markets.prophet.marketdata.aggbook;


import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBook;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBookImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataNewOrderImpl;
import com.anz.markets.prophet.domain.marketdata.impl.StandaloneFilterOutcome;
import com.anz.markets.prophet.marketdata.filter.SnapshotGenerator;
import org.junit.Test;

public class AggregateBookImplBWTest {

    private static final int REPS = 100_000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private static final int THRESHOLD = 100;

    static final FilteredMarketDataSnapshotImpl[] snaps = new FilteredMarketDataSnapshotImpl[]{
            new SnapshotGenerator(Market.RFX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.CNX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.GS, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.FASTMATCH, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.HSP, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.CITI, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.MSI, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot(),
            new SnapshotGenerator(Market.EBS, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot()
    };


    private final StandaloneFilterOutcome filterOutcome = new StandaloneFilterOutcome();

    private final AggregatedBook aggregateBook;

    public AggregateBookImplBWTest() {
        aggregateBook = new AggregatedBookImpl(Market.WSP_U, Instrument.AUDUSD);
    }

    @Test
    public void test__Allocation() {
        helper.testAllocationNotExceeded(
                this::performBookAggregation,
                REPS, REPS,
                THRESHOLD
        );
    }

    private void performBookAggregation() {
        for (FilteredMarketDataSnapshotImpl filteredMarketDataSnapshot : snaps) {
            MarketDataNewOrderImpl marketDataNewOrder = (MarketDataNewOrderImpl) filteredMarketDataSnapshot.getTopOfBookBid();
            marketDataNewOrder.setPrice(marketDataNewOrder.getPrice() - 0.0001);
            filterOutcome.reset(filteredMarketDataSnapshot);
            aggregateBook.aggregateBook(filteredMarketDataSnapshot,filterOutcome);
        }
        double midRate = aggregateBook.getMidRate();
    }
}
