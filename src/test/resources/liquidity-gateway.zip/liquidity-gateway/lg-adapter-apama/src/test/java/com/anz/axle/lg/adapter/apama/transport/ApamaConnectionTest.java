package com.anz.axle.lg.adapter.apama.transport;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.engine.beans.interfaces.EngineClientInterface;
import com.apama.event.Event;
import com.apama.event.IEventListener;
import com.apama.net.beans.interfaces.BaseClientInterface;
import com.apama.services.event.IEventService;
import com.apama.services.event.IEventServiceChannel;

import com.anz.axle.lg.adapter.apama.event.EbsMarketDataIncrementalRefresh;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class ApamaConnectionTest {

    @Mock
    private EngineClientInterface engineClient;

    @Mock
    private IEventService eventService;

    @Mock
    private IEventServiceChannel serviceChannel;

    @Mock
    private ConnectionStatusHandler connectionStatusHandler;

    @Captor
    private ArgumentCaptor<PropertyChangeListener> beanConnectedCaptor;

    @Mock
    private Consumer<Event> eventConsumer;

    @Mock
    private ConnectionConfig connectionConfig;

    private ApamaConnection apamaConnection;

    @Before
    public void setUp() throws Exception {
        Mockito.doNothing().when(engineClient).addPropertyChangeListener(same(BaseClientInterface.PROPERTY_BEAN_CONNECTED), beanConnectedCaptor.capture());

        apamaConnection = new ApamaConnection(engineClient, eventService, serviceChannel, connectionStatusHandler, connectionConfig);
    }

    @Test
    public void close() throws Exception {
        //when
        apamaConnection.close();

        //then
        verify(eventService).dispose();
        verify(engineClient).dispose();
    }

    @Test
    public void openSubscription() throws Exception {
        //when
        final Subscription subscription = apamaConnection.openSubscription(EbsMarketDataIncrementalRefresh.EVENT_TYPE, eventConsumer);

        //then
        verify(serviceChannel).addEventListener(any(IEventListener.class), same(EbsMarketDataIncrementalRefresh.EVENT_TYPE));
        assertThat(subscription).isNotNull();

        //when
        subscription.close();

        //then
        verify(serviceChannel).removeEventListener(any(IEventListener.class), same(EbsMarketDataIncrementalRefresh.EVENT_TYPE));
    }

    @Test
    public void connectionConfig() throws Exception {
        assertThat(apamaConnection.connectionConfig()).isEqualTo(connectionConfig);
    }

    @Test
    public void should_disconnect_when_disconnect_event_fired() throws Exception {
        //given
        final PropertyChangeEvent disconnectEvent = new PropertyChangeEvent("test",
                BaseClientInterface.PROPERTY_BEAN_CONNECTED, Boolean.TRUE, Boolean.FALSE);

        //when
        beanConnectedCaptor.getValue().propertyChange(disconnectEvent);

        //then
        verify(connectionStatusHandler).onDisconnect(apamaConnection);
    }


    @Test
    public void should_connect_when_connect_event_fired() throws Exception {
        //given
        final PropertyChangeEvent connectEvent = new PropertyChangeEvent("test",
                BaseClientInterface.PROPERTY_BEAN_CONNECTED, Boolean.FALSE, Boolean.TRUE);

        //when
        beanConnectedCaptor.getValue().propertyChange(connectEvent);

        //then
        verify(connectionStatusHandler).onConnect(apamaConnection);
    }

    @Test
    public void should_notify_when_disconnect_event_fired_and_already_disconnected() throws Exception {
        //given
        final PropertyChangeEvent disconnectEvent = new PropertyChangeEvent("test",
                BaseClientInterface.PROPERTY_BEAN_CONNECTED, Boolean.FALSE, Boolean.FALSE);

        //when
        beanConnectedCaptor.getValue().propertyChange(disconnectEvent);

        //then
        verify(connectionStatusHandler).onNotification(same(apamaConnection), anyString());
    }

}