package com.anz.markets.efx.ngaro.api;

import java.util.function.Consumer;

public enum Venue {
    FAST, FASTMD, KGI, DEUT, UBS, CNX, HSP, HSPMD, BARX, MSI, GS, GCS, RFX, CITI, CITIFW, CMZ, FXBK, D3, EBS, EBSD, JPM, AXL, LMAX, LMAXP, ANZD, D3NDF, D3BLEND, BGC, DBS, OCX, FOX,
    WSP_A, WSP_API_1, WSP_API_2, WSP_API_3, WSP_API_4, WSP_API_5, WSP_API_6, WSP_B, WSP_C, WSP_MU, WSP_R, WSP_U, WSP_Z, MAHI1, MAHI2, MAHI3, CMEJMP, EBSHEDGE, FXALLMB, TRSBE, EBSU;


    private static final Venue[] VALUES = values();

    public static int length() {
        return VALUES.length;
    }

    public static Venue valueByOrdinal(final int ordinal) {
        return VALUES[ordinal];
    }

    public static void forEach(final Consumer<? super Venue> consumer) {
        for (final Venue value : VALUES) {
            consumer.accept(value);
        }
    }
}
