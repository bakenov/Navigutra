#!/bin/bash

#mvn exec:java -Dtest=testMissingRequiredTag
#or
#mvn exec:java -Dtest=testFailValidation

title="Available tests"
prompt="Select test:"
options=("testMissingRequiredTag" "testFailValidation")

PS3=$'\n'"$prompt "
COLUMNS=24

while true; do
    printf "\n$title\n"
    select opt in "${options[@]}" "Quit"; do

        case "$REPLY" in

        1 ) MAVEN_OPTS=-ea mvn exec:java -Dtest=$opt; break;;
        2 ) MAVEN_OPTS=-ea mvn exec:java -Dtest=$opt; break;;

        $(( ${#options[@]}+1 )) ) echo "Quit"; exit;;
        *) echo "Invalid option";continue;;

        esac

    done
done

