package com.anz.axle.lg.adapter.apama.event;

import java.util.Map;

import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;
import com.apama.event.parser.IntegerFieldType;
import com.apama.event.parser.StringFieldType;

public class EbsTradingSessionStatus {
    public static final String EVENT_NAME = "com.apama.fix.ebs.EBSTradingSessionStatus";
    public static final Field<String> FIELD_TRANSPORT = GeneralApamaEventFields.FIELD_TRANSPORT;
    public static final Field<String> FIELD_SESSION = GeneralApamaEventFields.FIELD_SESSION;
    public static final Field<Long> FIELD_TRADING_SESSION_STATUS  = new Field<>("TradSesStatus", IntegerFieldType.TYPE);
    public static final Field<String> FIELD_TRADING_SESSION_ID = new Field<>("TradingSessionID", StringFieldType.TYPE);
    public static final Field<Map<String, String>> FIELD_PAYLOAD = GeneralApamaEventFields.FIELD_PAYLOAD;

    public static final EventType EVENT_TYPE = initEventType();

    private static EventType initEventType() {
        return new EventType(EVENT_NAME,
                FIELD_TRANSPORT,
                FIELD_SESSION,
                FIELD_TRADING_SESSION_ID,
                FIELD_TRADING_SESSION_STATUS,
                FIELD_PAYLOAD);
    }
}
