package software.chronicle.fix;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.jlbh.JLBH;
import net.openhft.chronicle.core.jlbh.JLBHOptions;
import net.openhft.chronicle.core.jlbh.JLBHTask;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.core.threads.EventHandler;
import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.core.time.SystemTimeProvider;
import net.openhft.chronicle.core.util.Histogram;
import net.openhft.chronicle.core.util.NanoSampler;
import net.openhft.chronicle.network.ServerThreadingStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.WireType;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.ConnectionType;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.messages.Logon;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.*;
import software.chronicle.fix.staticcode.context.DynamicTimestampResolutionFixSessionContext;
import software.chronicle.fix.staticcode.context.FixSessionContext;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;
import software.chronicle.generated.code.fields.OrdStatus;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;
import software.chronicle.generated.code.messages.datamodel.DefaultExecutionReport;
import software.chronicle.generated.code.messages.datamodel.DefaultNewOrderSingle;
import software.chronicle.generated.code.parsers.MessageParser;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static software.chronicle.fix.cfg.ConnectionType.acceptor;

/**
 * Created by daniel on 02/03/2016.
 * <p>
 * On dev fixEngine: Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz
 * <p>
 * Throughput 2000
 * <p>
 * Percentile   run1         run2         run3         run4      % Variation   var(log)
 * 50:            16.90        16.90        16.90        16.90         0.00       12.59
 * 90:            18.94        18.94        18.94        18.94         0.00       12.89
 * 99:            26.11        30.21        23.04        23.04        17.18       13.62
 * 99.9:          35.84        39.94        33.79        37.89        10.81       14.75
 * 99.99:        540.67       671.74       401.41      1540.10        65.41       24.76
 * worst:        638.98      1081.34       606.21      2064.38        61.59       26.50
 * <p>
 * Throughput 10,000
 * <p>
 * Percentile   run1         run2         run3      % Variation   var(log)
 * 50:            16.90        16.90        16.13         3.08        7.62
 * 90:            18.94        18.94        18.94         0.00        7.86
 * 99:            26.11        22.02        20.99         3.15        7.87
 * 99.9:          88.06        33.79        83.97        49.75        9.10
 * 99.99:        999.42       167.94       802.82        71.59       12.21
 * worst:       1146.88       249.86       966.66        65.67       12.94
 * <p>
 * Throughput 50,000
 * <p>
 * Percentile   run1         run2         run3      % Variation   var(log)
 * 50:            15.62        15.10        15.62         2.21        7.51
 * 90:            17.92        16.90        16.90         0.00        7.62
 * 99:            22.02        30.21        29.18         2.29        8.91
 * 99.9:         120.83       352.26        33.79        86.27       11.04
 * 99.99:        335.87       802.82        96.26        83.03       12.70
 * worst:        450.56       901.12       151.55        76.73       13.21
 */
public class QueuelessPerformanceRun implements JLBHTask {
    private static final Logger LOG = LoggerFactory.getLogger(QueuelessPerformanceRun.class);
    private static final FixSessionContext sessionContext = new DynamicTimestampResolutionFixSessionContext(SystemTimeProvider.INSTANCE, TimeUnit.MILLISECONDS, TimeUnit.MILLISECONDS);
    private static final ExecutionReport executionReport = ExecutionReport.newExecutionReport(null, sessionContext);
    private static final Bytes clOrdId = Bytes.elasticByteBuffer();

    private static final NewOrderSingle newOrderSingle = NewOrderSingle.newNewOrderSingle(null, sessionContext);
    private static final Bytes erBytes = Bytes.elasticByteBuffer();
    private static final Bytes nosBytes = Bytes.elasticByteBuffer();
    private static final String PERFORMANCE_YAML = System.getProperty("performance.yaml", "performance.yaml");
    private static final String SYMBOL_STR = "LCOM1";
    private static final String ACCOUNT_STR = "ABCTEST1";
    private static final String SEC_ID_STR = "LCOM1";
    private static final Bytes SYMBOL = Bytes.allocateDirect(SYMBOL_STR.length());
    private static final Bytes ACCOUNT = Bytes.allocateDirect(ACCOUNT_STR.length());
    private static final Bytes SEC_ID = Bytes.allocateDirect(SEC_ID_STR.length());
    private static final LoggingMode LOGGING_MODE = LoggingMode.valueOf(System.getProperty("logging_mode", "UNBUFFERED"));

    private static PerformanceConfig config;
    private static Map<String, EventGroup> eventGroups = new HashMap<>();

    static {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(false);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    private JLBH jlbh;
    private NanoSampler createExecutionReportSampler;
    private FixSessionHandler client;

    private volatile long startTime = 0;

    public static void main(String[] args) throws IOException {
        runWith(new QueuelessPerformanceRun());
    }

    static void runWith(QueuelessPerformanceRun performanceRun) throws IOException {
        IOTools.deleteDirWithFiles("acceptor", 10);
        IOTools.deleteDirWithFiles("initiator", 10);
        IOTools.deleteDirWithFiles("networkStats", 10);

        System.setProperty("MonitorInitialDelay", "0");
        ClassAliasPool.CLASS_ALIASES.addAlias(PerformanceConfig.class, RollCycles.class);
        SingleChronicleQueueBuilder.addAliases();
        config = Marshallable.fromFile(PerformanceConfig.class, PERFORMANCE_YAML);

        if (config.hostPort.equals(PerformanceConfig.HOST_PORT)) {
            TCPRegistry.reset();
            TCPRegistry.createServerSocketChannelFor(config.hostPort);
        }

        JLBHOptions jlbhOptions = new JLBHOptions()
                .iterations(config.iterations)
                .throughput(config.throughput)
                .runs(config.runs)
                .recordOSJitter(config.checkJitter)
                .accountForCoordinatedOmmission(true)
                .warmUpIterations(config.warmupIterations)
                .pauseAfterWarmupMS(500)
                .jlbhTask(performanceRun);
        JLBH jlbh = new JLBH(jlbhOptions);
        if (config.jlbhEventLoop) {
            EventHandler handler = jlbh.eventLoopHandler();
            eventGroup("init_").addHandler(handler);
            Jvm.pause(Integer.MAX_VALUE);
        } else
            jlbh.start();
    }

    private class SenderEventHandler implements EventHandler {

        @Override
        public boolean action() {
            long startTimeNs = startTime;
            if (startTimeNs != 0) {
                startTime = 0;
                ((MessageGenerator) newOrderSingle).bytes(nosBytes);

                clOrdId.clear();
                clOrdId.append(startTimeNs);
                SYMBOL.clear();
                ACCOUNT.clear();
                SEC_ID.clear();
                SYMBOL.append(SYMBOL_STR);
                ACCOUNT.append(ACCOUNT_STR);
                SEC_ID.append(SEC_ID_STR);
                newOrderSingle.clOrdID(clOrdId);
                newOrderSingle.side('1');
                newOrderSingle.ordType('2');
                newOrderSingle.symbol(SYMBOL);
                newOrderSingle.handlInst('3');
                newOrderSingle.transactTime(1451902315496l);
                newOrderSingle.account(ACCOUNT);
                newOrderSingle.orderQty(1);
                newOrderSingle.price(200.0);
                newOrderSingle.timeInForce('0');
                newOrderSingle.maturityMonthYear("201106");
                newOrderSingle.securityType("FUT");
                newOrderSingle.idSource("5");
                newOrderSingle.securityID(SEC_ID);
                client.sendMessage(newOrderSingle);
            }
            return false;
        }
    }

    private static ExecutionReport createExecutionReport(Bytes tempBuffer, Bytes clOrdID) {
        ((MessageGenerator) executionReport).bytes(tempBuffer);
        executionReport.clOrdID(clOrdID);
        executionReport.side('1');
        executionReport.avgPx(23.56);
        executionReport.transactTime(1453365641096l);
        executionReport.ordStatus(OrdStatus.NEW);
        return executionReport;
    }

    @NotNull
    static EventGroup eventGroup(String name) {
        if (!eventGroups.containsKey(name)) {
            EventGroup eventGroup;
            if (config.affinityCpu != -1)
                // non-busy pauser is pointless when using affinity
                eventGroup = new EventGroup(true, Pauser.busy(), true, config.affinityCpu, -1, name);
            else
                eventGroup = new EventGroup(true, config.useBusyPauser ? Pauser.busy() : Pauser.balanced(), config.useAffinity, name);
            if (config.concurrentFix)
                eventGroup.setConcThreadPauserSupplier(Pauser::busy);
            eventGroups.put(name, eventGroup);
        }
        return eventGroups.get(name);
    }

    @Override
    public void init(JLBH jlbh) {
        this.jlbh = jlbh;

        try {
            if (config.isServer) {
                createExecutionReportSampler = this.jlbh.addProbe("createExecutionReportSampler");

                EventGroup acpt = eventGroup("acpt_");
                final ChronicleFixEngine engine = buildEngine(acpt);
                FixSessionCfg sc = acceptorConfig(jlbh);
                engine.add(sc);
                MyProbe probes = (MyProbe) sc.probes();
                //acpt.setupTimeLimitMonitor(50_000, () -> probes.readTimeNS);
            }
            if (config.isClient) {
                MyNotifier messageNotifier = new MyNotifier();
                EventGroup eg = eventGroup("init_");
                eg.addHandler(new SenderEventHandler());
                final ChronicleFixEngine engine = buildEngine(eg);
                client = engine.add(initiatorConfig(jlbh, messageNotifier));

                final CountDownLatch latch = messageNotifier.latch();

                // wait till logged in
                boolean success = latch.await(5, TimeUnit.SECONDS);
                if (!success)
                    throw new TimeoutException("while waiting to become loggedin");
            }
        } catch (Exception t) {
            Jvm.rethrow(t);
        }
    }

    @Override
    public void complete() {
        System.exit(0);
    }

    @Override
    public void run(long startTimeNs) {
        if (!config.isClient) {
            return;
        }

        while (startTime != 0)
            ;
        startTime = startTimeNs;
    }

    @NotNull
    protected FixSessionCfg acceptorConfig(final JLBH lth) {
        // TODO: move to YAML
        @NotNull FixSessionCfg acceptorConfig = new FixSessionCfg("acceptor");
        acceptorConfig.socketAcceptorHostPort(config.hostPort);
        acceptorConfig.targetCompID("Acceptor");
        acceptorConfig.senderCompID("Initiator");
        acceptorConfig.messageParser(new MessageParser());
        acceptorConfig.messageNotifier(new MyNotifier());
        acceptorConfig.messageGenerator(new MessageGenerator((char) 0, sessionContext));
        acceptorConfig.loggingMode(LOGGING_MODE);
        acceptorConfig.fileStorePath("acceptor");
        acceptorConfig.fixVersion(FixVersion.UNDEFINED);
        acceptorConfig.connectionType(acceptor);
        acceptorConfig.blockUntilReplicated(false);
        acceptorConfig.heartBtInt(30);
        acceptorConfig.msgSequenceHandler(new VanillaMsgSequenceHandle());
        acceptorConfig.allowSequenceResetDecrease(false);
        MyProbe probes = new MyProbe(false, lth);
        acceptorConfig.probes(probes);
        SingleChronicleQueueBuilder builder = SingleChronicleQueueBuilder.builder().wireType(WireType.BINARY_LIGHT);
        PerformanceRun.configurePretouch(config, acceptorConfig, builder);
        acceptorConfig.queueBuilder(builder);
        if (config.concurrentFix)
            acceptorConfig.serverThreadingStrategy(ServerThreadingStrategy.CONCURRENT);
        return acceptorConfig;
    }

    @NotNull
    protected FixSessionCfg initiatorConfig(final JLBH lth, final MessageNotifier messageNotifier) {

        // TODO: move to YAML
        @NotNull FixSessionCfg initiatorConfig = new FixSessionCfg("initiator");
        initiatorConfig.socketConnectHostPort(new String[]{config.hostPort});
        initiatorConfig.fixVersion(FixVersion.V4_2);
        initiatorConfig.targetCompID("Acceptor");
        initiatorConfig.senderCompID("Initiator");
        initiatorConfig.messageParser(new MessageParser());
        initiatorConfig.messageNotifier(messageNotifier);
        initiatorConfig.messageGenerator(new MessageGenerator((char) 0, sessionContext));
        initiatorConfig.loggingMode(LOGGING_MODE);
        initiatorConfig.fileStorePath("initiator");
        initiatorConfig.blockUntilReplicated(false);
        initiatorConfig.connectionType(ConnectionType.initiator);
        initiatorConfig.heartBtInt(30);
        initiatorConfig.msgSequenceHandler(new VanillaMsgSequenceHandle());
        initiatorConfig.allowSequenceResetDecrease(false);
        initiatorConfig.resetOnLogon(true);
        initiatorConfig.probes(new MyProbe(true, lth));
        initiatorConfig.queueless(true);
        SingleChronicleQueueBuilder builder = SingleChronicleQueueBuilder.builder().wireType(WireType.BINARY_LIGHT);
        PerformanceRun.configurePretouch(config, initiatorConfig, builder);
        initiatorConfig.queueBuilder(builder);
        if (config.concurrentFix)
            initiatorConfig.serverThreadingStrategy(ServerThreadingStrategy.CONCURRENT);
        return initiatorConfig;
    }

    @NotNull
    protected ChronicleFixEngine buildEngine(EventLoop eventLoop) {
        return new ChronicleFixEngine(eventLoop, Collections.emptyList());
    }

    static public class MyProbe extends VoidFixSessionProbes {
        static {
            ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(false);
        }

        private final Histogram parsedHistogram;
        private final Histogram processedHistogram;
        private final Histogram client2ServerNetwork;
        private final Histogram networkHistogram;
        private final Histogram publishCompletedHistogram;
        private final Histogram publishComplete2TcpWritten;
        private Histogram readToWrite;
        private long readTimeNS = Long.MAX_VALUE;
        private long parsingStarts = Long.MAX_VALUE;
        private long messageParsedFinished = Long.MAX_VALUE;
        private long readyToPublish = Long.MAX_VALUE;
        private long publishCompleted = Long.MAX_VALUE;

        MyProbe(boolean isInitiator, JLBH lth) {

            final String type = isInitiator ? "Initiator" : "Acceptor";

            // parse time
            if (!isInitiator)
                parsedHistogram = (Histogram) lth.addProbe(type + ":3 parse NOS");
            else
                parsedHistogram = (Histogram) lth.addProbe(type + ":3 parse ER");
            // parse finished -> processing done
            if (!isInitiator)
                processedHistogram = (Histogram) lth.addProbe(type + ":4 NOS processed");
            else
                processedHistogram = (Histogram) lth.addProbe(type + ":4 ER processed");
            networkHistogram = (Histogram) lth.addProbe(type + ":2 socket->parse");
            // generates message and sends -> other end socket receives
            if (!isInitiator)
                client2ServerNetwork = (Histogram) lth.addProbe(type + ":1 init2AcceptNetwork");
            else
                client2ServerNetwork = (Histogram) lth.addProbe(type + ":1 accept2InitNetwork");
            // acceptor socket receives -> acceptor writes response to socket
            if (!isInitiator) {
                readToWrite = (Histogram) lth.addProbe(type + ":5 readToWrite");
            }
            // Construct outgoing bytes and publish to chronicle
            publishCompletedHistogram = (Histogram) lth.addProbe(type + ":6 publishCompleted");
            // publish complete to TCP written
            publishComplete2TcpWritten = (Histogram) lth.addProbe(type + ":7 publishComplete2TcpWritten");
        }

        @Override
        public void onPreParseComplete() {
            long now = System.nanoTime();

            parsingStarts = now;
            networkHistogram.sample(parsingStarts - readTimeNS);
        }

        @Override
        public void onMessageProcessed(StandardHeaderTrailer messageParsed) {
            processedHistogram.sample(System.nanoTime() - messageParsedFinished);
            this.readTimeNS = Long.MAX_VALUE;
        }

        @Override
        public void onReadTime(long readTimeNS, ByteBuffer inBB, int position, int limit) {
            this.readTimeNS = readTimeNS;
        }

        @Override
        public void onMessageParsed(StandardHeaderTrailer messageParsed) {
            // don't time additional messages if they came in the same packet.
            messageParsedFinished = System.nanoTime();
            long time = messageParsedFinished - parsingStarts;
            parsedHistogram.sampleNanos(time);

            if (messageParsed instanceof DefaultNewOrderSingle) {
                long startTime = ((DefaultNewOrderSingle) messageParsed).createdNS();
                client2ServerNetwork.sample(readTimeNS - startTime);
            } else if (messageParsed instanceof DefaultExecutionReport) {
                long startTime = ((DefaultExecutionReport) messageParsed).createdNS();
                client2ServerNetwork.sample(readTimeNS - startTime);
            }
        }

        @Override
        public void onReadyToPublish(StandardHeaderTrailer generator) {
            readyToPublish = System.nanoTime();
            if (generator.msgType() == 'D') {
                ((NewOrderSingle) generator).createdNS(readyToPublish);
            } else if (generator.msgType() == '8') {
                ((ExecutionReport) generator).createdNS(readyToPublish);
            }
        }

        @Override
        public void onPublishComplete(FixLog fixLog) {
            publishCompleted = System.nanoTime();
            publishCompletedHistogram.sampleNanos(publishCompleted - readyToPublish);
        }


        @Override
        public void onWriteTime(long writeTimeNS, ByteBuffer byteBuffer, int position, int limit) {

            if (readToWrite != null) {
                // This is also called for unsolicited writes e.g. HBs
                if (readTimeNS != 0L) {
                    readToWrite.sampleNanos(writeTimeNS - readTimeNS);
                    readTimeNS = 0L;
                }
            }
            publishComplete2TcpWritten.sampleNanos(writeTimeNS - publishCompleted);
        }
    }

    private class MyNotifier implements MessageNotifier {
        private final CountDownLatch loggedOnLatch = new CountDownLatch(1);
        long next = System.currentTimeMillis() + 5000;

        @Override
        public MessageGenerator onNewOrderSingle(NewOrderSingle newOrderSingle) {
            if (next < System.currentTimeMillis()) {
                LOG.warn("------- " + newOrderSingle.msgSeqNum());
                next += 5000;
            }
            long now = System.nanoTime();
            ExecutionReport executionReport = createExecutionReport(erBytes, newOrderSingle.clOrdID());
            long nanoTime = System.nanoTime() - now;
            createExecutionReportSampler.sampleNanos(nanoTime);
            if (!config.isClient) {
                jlbh.sample(System.nanoTime() - now);
            }
            return (MessageGenerator) executionReport;
        }

        @Override
        public MessageGenerator onExecutionReport(ExecutionReport executionReport) {
            Bytes clOrdId = executionReport.clOrdID();
            long startTime = clOrdId.parseLong();
            long nanoTime = System.nanoTime() - startTime;
            jlbh.sample(nanoTime);
            return null;
        }

        @Override
        public void onLogon(FixSessionHandler session, Logon logon) {

            // the acknowledgement of the logon
            loggedOnLatch.countDown();
        }

        @Override
        public void onReject(FixSessionHandler session, Reject reject) {
            LOG.warn("got a reject {}", reject);
        }

        public CountDownLatch latch() {
            return loggedOnLatch;
        }
    }
}
