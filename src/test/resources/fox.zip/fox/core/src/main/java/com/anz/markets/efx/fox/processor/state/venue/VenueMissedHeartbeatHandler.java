package com.anz.markets.efx.fox.processor.state.venue;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.Venue;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;

public class VenueMissedHeartbeatHandler implements TimerScheduler.ExpiryHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueMissedHeartbeatHandler.class);

    private final Venue venue;

    public VenueMissedHeartbeatHandler(final Venue venue) {
        this.venue = Objects.requireNonNull(venue);
    }

    @Override
    public TimerGroup timerGroup() {
        return TimerGroup.VENUE_MISSED_HEARTBEAT;
    }

    @Override
    public boolean onExpiryCommand(final long timerId, final long triggeredTime, final CommandContext commandContext) {
        if (venue.online()) {
            //Handling in venue goes dead
        }
        return false;
    }

    @Override
    public boolean onExpiryEvent(final long timerId, final long triggeredTime) {
        venue.updateOffline();
        return true;
    }

}
