package com.anz.markets.disco;

public enum MessageSource {
    EXOGENOUS, ENDOGENOUS;
}
