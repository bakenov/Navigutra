package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.domain.chronicle.MessageType;
import net.openhft.chronicle.core.threads.EventLoop;

import java.util.function.Predicate;

public interface PersisterConfig {
    boolean active();
    Predicate<MessageType> messageTypePredicate();
    Append append();
    ActivationAware activationAware();
    ChronicleHook beforeWrite();
    ChronicleHook afterWrite();
    // TODO: not currently used
    boolean multipleWriterThreads();
    RingBuffer ringBuffer();
    // only used for test currently
    EventLoop eventLoop();
}
