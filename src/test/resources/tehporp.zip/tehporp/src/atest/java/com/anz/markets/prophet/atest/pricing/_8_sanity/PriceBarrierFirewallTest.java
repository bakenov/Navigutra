package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceBarrierFirewallConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.control.PricingFirewallResetImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.LinkedList;

import static com.anz.markets.prophet.domain.Market.WSP_A;
import static com.anz.markets.prophet.domain.Market.WSP_B;
import static com.anz.markets.prophet.domain.Market.WSP_C;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PriceBarrierFirewallTest extends BaseAcceptanceSpecification {

    @Test
    @Requirement(Ref.PRICING_4_7_8)
    @DisplayName("Firewall triggered when BID over CEILING limit")
    public void trigger_when_bid_over_ceiling() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, true))
                    // {"instrument":"EURDKK","priceFloor":7.415,"priceCeiling":7.485,"affectedCurrency":"DKK"},
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48510, 0.00004));
        }

        then:
        {
            // EUR/DKK BID price is EQUAL to CEILING limit(7.4850). Firewall NOT triggered
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.48500, 7.48520));

            // DKK client prices still FIRM
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48536, 0.00004));
        }

        then:
        // expect firewall to be triggered for DKK pairs.
        {
            // EUR/DKK BID price is GREATER then CEILING limit(7.4850). Firewall triggered on WSP_A/B/C
            LinkedList<ClientPrice> clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK));
            assertThat(clientPriceEURDKK.getFirst(), isClientPricePoint(0, Level.QTY_1M, 7.48526, 7.48546));
            assertThat(clientPriceEURDKK.get(1), isClientPricePoint(0, Level.QTY_1M, 7.48521, 7.48551));
            assertThat(clientPriceEURDKK.get(2), isClientPricePoint(0, Level.QTY_1M, 7.48501, 7.48571));

            // Verify DKK pairs for ALL models and ALL pairs are INDICATIVE
            for (int i = 0; i < 3; i++) {
                // Verify quote type at each level of book
                assertThat(clientPriceEURDKK.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceEURDKK.get(i), PricingFirewallType.PRICE_BARRIER);
            }

            LinkedList<ClientPrice> clientPriceUSDDKK = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(Instrument.USDDKK));
            for (int i = 0; i < clientPriceUSDDKK.size(); i++) {
                // Verify quote type at each level of book
                assertThat(clientPriceUSDDKK.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceUSDDKK.get(i), PricingFirewallType.PRICE_BARRIER);
            }

            and:
            // Since only DKK pairs set to indicative DO NOT EXPECT EUR/USD price
            {
                prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.EURUSD));
            }

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48510, 0.00004));
        }

        then:
        {
            // EUR/DKK WSP_A BID price is EQUAL to CEILING limit(7.4850). Firewall NOT triggered
            LinkedList<ClientPrice> clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK));
            assertThat(clientPriceEURDKK.getFirst(), isClientPricePoint(0, Level.QTY_1M, 7.48500, 7.48520));
            assertThat(clientPriceEURDKK.get(1), isClientPricePoint(0, Level.QTY_1M, 7.48495, 7.48525));
            assertThat(clientPriceEURDKK.get(2), isClientPricePoint(0, Level.QTY_1M, 7.48475, 7.48545));

            // Verify EURDKK quote type at each level of book
            for (int i = 0; i < 3; i++) {
                // Verify quote type at each level of book
                assertThat(clientPriceEURDKK.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPriceEURDKK.get(i));
            }

            // USDDKK client prices still FIRM
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_8)
    @DisplayName("Firewall triggered when OFFER below FLOOR limit")
    public void trigger_when_offer_below_floor() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    // {"instrument":"EURDKK","priceFloor":7.415,"priceCeiling":7.485,"affectedCurrency":"DKK"},
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41490, 0.00004));
        }

        then:
        {
            // EUR/DKK OFFER price is EQUAL to FLOOR limit(7.41500). Firewall NOT triggered
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.41480, 7.41500));

            // DKK client prices still FIRM
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41489, 0.00004));
        }

        then:
        // expect firewall to be triggered for DKK pairs.
        {
            // EUR/DKK OFFER price is LESS then FLOOR limit(7.41500). Firewall triggered
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.41479, 7.41499));

            and:
            // Verify DKK pairs for ALL models and ALL pairs are INDICATIVE
            {
                // Verify quote type at each level of book
                assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceEURDKK, PricingFirewallType.PRICE_BARRIER);

                ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDDKK)).getFirst();
                // Verify quote type at each level of book
                assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceUSDDKK, PricingFirewallType.PRICE_BARRIER);

            }

            and:
            // Since only DKK pairs set to indicative DO NOT EXPECT EUR/USD price
            {
                prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.EURUSD));
            }
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_7_8, Ref.PRICING_4_7_11})
    @DisplayName("Do not reset firewall if autoReset is false until manual reset")
    public void doNotResetFirewallWhenAutoResetIsFalseUntilManualReset() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, false))
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41490, 0.00004));
        }

        then:
        {
            // EUR/DKK OFFER price is EQUAL to FLOOR limit(7.41500). Firewall NOT triggered
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.41480, 7.41500));

            // DKK client prices still FIRM
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41489, 0.00004));
        }

        then:
        // expect firewall to be triggered for DKK pairs.
        {
            // EUR/DKK OFFER price is LESS then FLOOR limit(7.41500). Firewall triggered
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.41479, 7.41499));

            and:
            // Verify DKK pairs for ALL models and ALL pairs are INDICATIVE
            {
                // Verify quote type at each level of book
                assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceEURDKK, PricingFirewallType.PRICE_BARRIER);

                ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDDKK)).getFirst();
                // Verify quote type at each level of book
                assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPriceUSDDKK, PricingFirewallType.PRICE_BARRIER);

            }
            prophet.clearOutputBuffer();
        }

        when:
        {   // reset another firewall
            prophet.receive(PricingFirewallResetImpl.of(PricingFirewallType.PRICE_SPIKE));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41490, 0.00004));
        }

        then:
        // expect firewall to STILL be triggered for DKK pairs.
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPriceEURDKK, PricingFirewallType.PRICE_BARRIER);

            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDDKK)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPriceUSDDKK, PricingFirewallType.PRICE_BARRIER);

            prophet.clearOutputBuffer();
        }

        when:
        {   // Price Spike Firewall manually reset by user
            prophet.receive(PricingFirewallResetImpl.of(PricingFirewallType.PRICE_BARRIER));

            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41491, 0.00004));
        }

        then:
        // expect DKK pairs to be FIRM
        {
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(clientPriceEURDKK);

            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDDKK)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));
            checkFirewallTriggered(clientPriceUSDDKK);
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_8)
    @DisplayName("Only WSP_A and WSP_B models triggered.")
    // AXPROPHET-773 do not reset all markets when one market is reset
    public void wspA_wsp_B_models_triggered_only() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET, true))
                    // {"instrument":"EURDKK","priceFloor":7.415,"priceCeiling":7.485,"affectedCurrency":"DKK"},
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "", 7.41500, 7.48500, Currency.DKK)
                    ));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48510, 0.00004));
        }
        then:
        {
            // EUR/DKK BID price is EQUAL to CEILING limit(7.4850). Firewall NOT triggered
            ClientPrice clientPriceEURDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURDKK)).getFirst();
            assertThat(clientPriceEURDKK, isClientPricePoint(0, Level.QTY_1M, 7.48500, 7.48520));
            assertThat(clientPriceEURDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            // DKK client prices still FIRM
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            // Verify quote type at each level of book
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.FIRM));

            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.incrementTime(1);
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48520, 0.00004));
        }
        then:
        // expect firewall to be triggered for DKK pairs.
        {
            // EUR/DKK BID price is GREATER then CEILING limit(7.4850). Firewall triggered on WSP_A and WSP_B
            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA, isClientPricePoint(0, Level.QTY_1M, 7.48510, 7.48530));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB, isClientPricePoint(0, Level.QTY_1M, 7.48505, 7.48535));
            assertThat(cpEURDKK_wspB, new QuoteTypeMatcher(QuoteType.INDICATIVE));

            ClientPrice cpEURDKK_wspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_C)).getLast();
            assertThat(cpEURDKK_wspC, isClientPricePoint(0, Level.QTY_1M, 7.48485, 7.48555));
            assertThat(cpEURDKK_wspC, new QuoteTypeMatcher(QuoteType.FIRM));

            and:
            // Since only DKK pairs set to indicative DO NOT EXPECT EUR/USD price
            {
                prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.EURUSD));
            }
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.48512, 0.00004));
        }
        then:
        {
            // EUR/DKK WSP_A BID price is GREATER than CEILING limit(7.4850). Firewall STILL triggered
            // EUR/DKK WSP_B BID price is BELOW CEILING limit(7.4850). Firewall reset
            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA, isClientPricePoint(0, Level.QTY_1M, 7.48502, 7.48522));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB, isClientPricePoint(0, Level.QTY_1M, 7.48497, 7.48527));
            assertThat(cpEURDKK_wspB, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpEURDKK_wspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_C)).getLast();
            assertThat(cpEURDKK_wspC, isClientPricePoint(0, Level.QTY_1M, 7.48477, 7.48547));
            assertThat(cpEURDKK_wspC, new QuoteTypeMatcher(QuoteType.FIRM));

            // USDDKK WSP_A still INDICATIVE
            ClientPrice clientPriceUSDDKK = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPriceUSDDKK, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
    }

    @Test
    @DisplayName("AXPROPHET-1206 Firewall also checks against specified markets")
    public void trigger_when_ref_markets_specified() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;
        final Instrument driverPairB = Instrument.EURDKK;
        final Instrument crossPair = Instrument.USDDKK;

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_BARRIER_ENABLED, true))
                    // {"instrument":"EURDKK","priceFloor":7.415,"priceCeiling":7.485,"affectedCurrency":"DKK"},
                    .setPriceBarrierFirewallConfigs(Arrays.asList(
                            new PriceBarrierFirewallConfig(Instrument.EURDKK, "BARX,HSP,RFX", 7.41500, 7.48500, Currency.DKK)
                    ));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.10000, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41490, 0.00004));
        }
        then:
        // EUR/DKK OFFER price is EQUAL to FLOOR limit(7.41500). Firewall NOT triggered
        // But there are NO Ref Markets(BARX,HSP) prices so FIREWALL TRIGGERED
        {
            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41500, is(true));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB, new QuoteTypeMatcher(QuoteType.INDICATIVE));

            ClientPrice cpEURDKK_wspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_C)).getLast();
            assertThat(cpEURDKK_wspC, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
        when:
        // Ref Market BARX OFFER(7.41500) is EQUAL TO FLOOR(7.41500) => Firewall NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41498, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41491, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41500));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41500, is(true));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpEURDKK_wspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_C)).getLast();
            assertThat(cpEURDKK_wspC, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // DEUT OFFER(7.41499) is BELOW FLOOR(7.41500) => DEUT is NOT a REF MARKET so Firewall NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.DEUT, driverPairB, 7.41497, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41492, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.DEUT)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41499));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41500, is(true));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // Ref Market BARX OFFER(7.41499) is BELOW FLOOR(7.41500) => Firewall TRIGGERED
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41497, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41493, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41499));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() >= 7.41500, is(true)); // WSP_A offer is still above floor though
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB, new QuoteTypeMatcher(QuoteType.INDICATIVE));

            ClientPrice cpEURDKK_wspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_C)).getLast();
            assertThat(cpEURDKK_wspC, new QuoteTypeMatcher(QuoteType.INDICATIVE));
        }
        when:
        // Ref Market HSP OFFER(7.41499) is BELOW FLOOR(7.41500) => Firewall still TRIGGERED
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, driverPairB, 7.41497, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41492, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41499));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);
        }
        when:
        // Ref Market BARX OFFER(7.41500) is EQUAL TO FLOOR(7.41500) => Firewall NOT triggered
        // But HSP HSP OFFER(7.41501) is still BELOW TO FLOOR(7.41500) so do NOT return to FIRM
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.BARX, driverPairB, 7.41498, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41491, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.BARX)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41500));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);
        }
        when:
        // Ref Market HSP OFFER(7.41500) is EQUAL TO FLOOR(7.41500) => Firewall NOT triggered
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Market.HSP, driverPairB, 7.41498, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41492, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.HSP)).getLast();
            assertThat(md.getTopOfBookOffer().getPrice(), isRoundedTo(7.41500));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpEURDKK_wspB = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_B)).getLast();
            assertThat(cpEURDKK_wspB, new QuoteTypeMatcher(QuoteType.FIRM));

            ClientPrice cpEURDKK_wspC = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_C)).getLast();
            assertThat(cpEURDKK_wspC, new QuoteTypeMatcher(QuoteType.FIRM));
        }
        when:
        // While both REF Markets OFFERS EQUAL FLOOR, WSP_* OFFERS BELOW FLOOR(7.41500) => Firewall TRIGGERED
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41489, 0.00004));  // trigger client price
        }
        then:
        {
            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookOffer().getPrice() < 7.41500, is(true));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);
        }
        when:
        // REF Market(RFX) BID ABOVE CEILING, FIREWALL TRIGGERED
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(Market.RFX, driverPairB, 7.48501, 7.48510));
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 7.41491, 0.00004));  // trigger client price
        }
        then:
        {
            FilteredMarketDataSnapshot md = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.RFX)).getLast();
            assertThat(md.getTopOfBookBid().getPrice() > 7.48500, is(true));

            ClientPrice cpEURDKK_wspA = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.EURDKK, WSP_A)).getLast();
            assertThat(cpEURDKK_wspA.getTopOfBookBid().getPrice() > 7.48500, is(false));
            assertThat(cpEURDKK_wspA, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cpEURDKK_wspA, PricingFirewallType.PRICE_BARRIER);
        }
    }
}
