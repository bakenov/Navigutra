package com.anz.markets.efx.fox.processor.state;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import com.anz.markets.efx.fox.api.domain.User;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.codec.api.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;

public class DefaultUserRepository implements UserRepository {
    private final Map<String, User> userMap = new HashMap<>();
    private final ByteValueCache<String> userNameCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> locationCache = new ByteValueCache<>(AsciiString::toString);

    @Override
    public User lookup(final String userName) {
        return userMap.get(userName);
    }

    @Override
    public User lookup(final StringDecoder userNameDecoder) {
        final String userName = userNameDecoder.decodeAndCache(userNameCache);
        return lookup(userName);
    }

    @Override
    public User init(final UserConfigDecoder userConfigDecoder) {
        final String userName = userConfigDecoder.body().userName().decodeAndCache(userNameCache);
        final String location = userConfigDecoder.body().location().decodeAndCache(locationCache);
        final EnumSet<UserGroup> userGroups = userConfigDecoder.body().userGroups().decodeTo(EnumSet.noneOf(UserGroup.class));
        final User user = new User(userName, userGroups, location, "TODO");

        userMap.put(userName, user);
        return user;
    }
}
