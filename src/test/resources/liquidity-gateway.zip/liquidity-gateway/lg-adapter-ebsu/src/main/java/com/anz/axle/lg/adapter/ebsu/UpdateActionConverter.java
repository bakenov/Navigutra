package com.anz.axle.lg.adapter.ebsu;

import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import org.jetbrains.annotations.NotNull;
import software.chronicle.ebs.itch.generated.incremental.fields.UpdateFlags;
import software.chronicle.ebs.itch.generated.incremental.messages.server.PriceLevelUpdate;

public class UpdateActionConverter {
    public static UpdateAction from(@NotNull PriceLevelUpdate priceLevelUpdate) {
        if (priceLevelUpdate.levelAmount() == 0) {
            if ((priceLevelUpdate.updateFlags() & UpdateFlags.PRICE_LEVEL_OUT_OF_SCOPE) == UpdateFlags.PRICE_LEVEL_OUT_OF_SCOPE) {
                // it dropped off the bottom of the levels
            }
            return UpdateAction.DELETE;
        } else {
            if ((priceLevelUpdate.updateFlags() & UpdateFlags.PRICE_LEVEL_BACK_IN_SCOPE) == UpdateFlags.PRICE_LEVEL_BACK_IN_SCOPE) {
                // it came back in to the levels
                return UpdateAction.NEW;
            }
            return UpdateAction.CHANGE;
        }
    }
}
