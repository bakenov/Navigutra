package com.anz.markets.prophet.config.business.domain.tabular.general;

import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.StandardMarketSpreadConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Configure common pricing attribute for each instrument.
 *
 * @see Instrument
 */
public interface InstrumentConfig extends ProphetMarshallable {

    double DEFAULT_SPREAD_MULTIPLIER = 0;

    /**
     * Instrument for this config
     */
    Instrument getInstrument();

    /**
     * Multiplier for the standard spread - used to determine if market/aggregated book is crossed.
     *
     * @todo this needs to be moved into standard market spread.
     * @todo this should be assigned against a specific pricing-filter
     * @see StandardMarketSpreadConfig
     */
    double getSpreadMultiplier();

    /**
     * Not currently used. A flag to indicate whether an instrument/currency is considered as Emerging-market instrument/currency
     */
    boolean isEmergingMarket();

    /**
     * Number of decimal places (full-pips) in spot according to a standard market-convention. Used to convert spot-rate from pips to basis-point, and vice versa.
     */
    double getSpotDecimalPlaces();

    /**
     * Not currently used.
     */
    double getSpotFractionalPip();

    /**
     * Not currently used. Number of decimal places on forward-points, to be used by PROPHET as part of the rate-calculation
     */
    double getFwdPtsDecimalPlaces();

    /**
     * Not currently used.
     */
    double getFwdPtsFractionalPip();

    /**
     * Not currently used.
     */
    double getAllInDecimalPlaces();

    /**
     * Not currently used.
     */
    double getAllInFractionalPip();

    /**
     * Not currently used. Indicates the position (digit) of the decimal place of a spot-rate in which a forward-point will be applied to e.g. getPrecisionMultiplier = 4 means PROPHET will convert a forward-point of this instrument from its original value of say 1.28 to 1.28/(10^4) then applied this to the spot-rate accordingly.
     */
    double getPrecisionMultiplier();

    /**
     * Get total spot decimal places considering fractional pip.
     * Not configurable in config store, used programatically instead.
     */
    @JsonIgnore
    double getSpotDecimalPlacesActual();

    /**
     *  Used by Wookiee, included here for consistency and to prevent KDB deserialisation warnings
     */
    boolean isAutoPriced();
}
