package com.anz.markets.efx.fox.processor.state.sweeper;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DefaultStrategyParameters {
    private List<Venue> markets;

    private final ByteValueCache<String> parameterCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> parameterValueCache = new ByteValueCache<>(AsciiString::toString);
    private final Map<String, List<Venue>> valueToVenueListCache = new HashMap<>();

    public void init(final ExecutionReportDecoder newOrderSingleDecoder) {
        markets = Collections.EMPTY_LIST;

        for(ExecutionReportDecoder.StrategyParameter strategyParameter : newOrderSingleDecoder.strategyParameters()) {
            final String name = strategyParameter.strategyParameterName().decodeAndCache(parameterCache);
            final String value = strategyParameter.strategyParameterValue().decodeAndCache(parameterValueCache);

            if ("Markets".equals(name)) markets = computeMarkets(value);
        }
    }

    public List<Venue> markets() {
        return markets;
    }

    private List<Venue> computeMarkets(final String marketsString) {
        if (marketsString != null && !marketsString.isEmpty()) {
            return valueToVenueListCache.computeIfAbsent(marketsString, val -> Arrays.stream(val.split(".*,.*")).map(Venue::valueOf).collect(Collectors.toList()));
        }
        return Collections.EMPTY_LIST;
    }
}
