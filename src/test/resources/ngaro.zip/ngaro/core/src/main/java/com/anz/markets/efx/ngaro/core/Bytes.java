package com.anz.markets.efx.ngaro.core;

/**
 * Class with static methods and constants dealing with bytes.
 */
public final class Bytes {

    public static <T> void setAll(final T target, final ByteWriter<? super T> writer, final int targetOffset, final int length, final byte b) {
        for (int i = 0; i < length; i++) {
            writer.writeByte(target, targetOffset + i, b);
        }
    }

    public static <S,T> void copy(final S source, final ByteReader<? super S> reader, final int sourceOffset, final T target, final ByteWriter<? super T> writer, final int targetOffset, final int length) {
        for (int i = 0; i < length; i++) {
            final byte b = reader.readByte(source, sourceOffset + i);
            writer.writeByte(target, targetOffset + i, b);
        }
    }

    private Bytes() {
        throw new RuntimeException("No Bytes for you!");
    }
}
