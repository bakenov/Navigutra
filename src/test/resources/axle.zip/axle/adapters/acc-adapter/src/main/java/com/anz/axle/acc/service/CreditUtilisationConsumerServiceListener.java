package com.anz.axle.acc.service;

import com.anz.axle.datafabric.client.config.CurrencyVenueExclusion;
import com.anz.axle.datafabric.client.trading.CounterpartyCreditUtilisationValue;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public interface CreditUtilisationConsumerServiceListener {
    void onConsume(CurrencyVenueExclusion exclusion);
    void onConsume(CounterpartyCreditUtilisationValue utilisation);
}
