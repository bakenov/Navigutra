package com.anz.axle.lg.adapter.cnx.uat;


import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.google.common.util.concurrent.AtomicDouble;
import quickfix.field.ClOrdID;
import quickfix.field.ClientID;
import quickfix.field.OrderID;
import quickfix.field.OrigClOrdID;
import quickfix.field.TransactTime;
import quickfix.fix42.OrderCancelRequest;
import quickfix.fix42.OrderStatusRequest;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.cnx.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.cnx.acceptance.AcceptanceContext;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.Party;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.instrumentId;
import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.mdEntryType;

@Category(UatTest.class)
@RunWith(Spockito.class)
public class UatConformanceTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatConformanceTest.class);
    public static final String GB_LG_CNX = "GB:lg-cnx";
    public static final String GB_LG_ACC = "GB:lg-acc";

    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-cnx" +
                                ",cnx.fix.log.destination:FILE" +
                                ",cnx.fix.trading.reset.on.logon:Y" +
                                ",cnx.fix.trading.reset.on.logout:Y" +
                                ",cnx.fix.trading.reset.on.disconnect:Y" +

                                ",cnx.fix.pricing.sendercompid:i2ANZcustfixstr1" +
                                ",cnx.fix.pricing.targetcompid:CNX" +
                                ",cnx.fix.pricing.host:10.54.180.210" +
                                ",cnx.fix.pricing.port:442" +
                                ",cnx.fix.pricing.password:test1234" +

                                ",cnx.fix.trading.sendercompid:i2ANZcustfixtrd1" +
                                ",cnx.fix.trading.targetcompid:CNX" +
                                ",cnx.fix.trading.host:10.54.180.210" +
                                ",cnx.fix.trading.port:443" +
                                ",cnx.fix.trading.password:test1234" +

                                ",cnx.fix.ticks.sendercompid:i2ANZcustfixtick" +
                                ",cnx.fix.ticks.targetcompid:CNX" +
//                                ",cnx.fix.ticks.host:10.54.180.189" +
                                ",cnx.fix.ticks.host:10.54.180.210" +
                                ",cnx.fix.ticks.port:442" +
                                ",cnx.fix.ticks.password:test1234"
                ));

        application = new Application("lg-cnx-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    //@Ignore
    @Spockito.Unroll({
            "| orderType | symbol | currency | timeInForce | side | size    | priceOffset   | multipleExecutions |",
            "| LIMIT     | AUDUSD | AUD      | IOC         | BUY  | 100000  | 0.0005        | false              |"
    })
    @Spockito.Name("[{row}]: {orderType} {timeInForce} {symbol} {currency} {side}")
    public void conformance(final OrderType orderType, final String symbol, final String currency, final TimeInForce timeInForce,
                            final Side side, final double size, final double priceOffset, final boolean multipleExecutions) throws Exception {

        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP);
        final double price = awaitPrice(instrumentKey, side == Side.SELL ? EntryType.BID : EntryType.OFFER) + priceOffset;

        final NewOrderSingle newOrderSingle = newOrderSingle(symbol, clOrdId, side, price, size, currency, orderType, timeInForce);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");

        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        assertFill(symbol, clOrdId, side, size, currency, orderType, multipleExecutions);
    }

    @Test
    @Spockito.Unroll({
            "| orderType | symbol | currency | timeInForce | side | size    | priceOffset   | multipleExecutions |",
            "| LIMIT     | AUDUSD | AUD      | GTC         | BUY  | 1000000 | 0.0005        | false              |"
    })
    @Spockito.Name("[{row}]: {orderType} {timeInForce} {symbol} {currency} {side}")
    public void cancelAllOpenRestingOrders(final OrderType orderType, final String symbol, final String currency, final TimeInForce timeInForce,
                                    final Side side, final double size, final double priceOffset, final boolean multipleExecutions) throws Exception {

        final NewOrderSingle newOrderSingle = createRestingNewOrderSingle(orderType, symbol, currency, timeInForce, side, size, priceOffset);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
        TimeUnit.SECONDS.sleep(5);
        acceptanceContext.tradingRequestMessageQueue().add(createRestingNewOrderSingle(orderType, symbol, currency, timeInForce, side, size, priceOffset));
        TimeUnit.SECONDS.sleep(5);

        final String clientId = "warnerb";
        final NewOrderSingle newOrderSingleWithAccount = createRestingNewOrderSingle(orderType, symbol, currency, timeInForce, side, size, priceOffset);
        newOrderSingleWithAccount.parties.add(new Party(PartyRole.CLIENT_ID, clientId));
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleWithAccount);
        TimeUnit.SECONDS.sleep(10);

        sendOrderCancelRequest(null);
        sendOrderCancelRequest(clientId);
        TimeUnit.SECONDS.sleep(10);
        // expect to see 3 ER with 58=user cancel
        assert3UserCancelExecutionReports();
    }

    private void assert3UserCancelExecutionReports() {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.rejectText().eq("user cancel"))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.rejectText().eq("user cancel"))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.rejectText().eq("user cancel"))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private NewOrderSingle createRestingNewOrderSingle(final OrderType orderType, final String symbol, final String currency, final TimeInForce timeInForce,
                                                       final Side side, final double size, final double priceOffset) {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP);
        final double price = awaitPrice(instrumentKey, side == Side.SELL ? EntryType.BID : EntryType.OFFER);

        final NewOrderSingle newOrderSingle = newOrderSingle(symbol, clOrdId, side, offMarketPrice(price, side, priceOffset), size, currency, orderType, timeInForce);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        return newOrderSingle;
    }

    private void sendOpenOrderRequest() throws Exception {
        final OrderStatusRequest orderStatusRequest = new OrderStatusRequest();
        orderStatusRequest.setString(ClOrdID.FIELD, "OPEN_ORDER");
        orderStatusRequest.setString(OrderID.FIELD, "OPEN_ORDER");
        orderStatusRequest.setString(7559, "Y");

        System.out.println("Sending...OrderStatusRequest=" + orderStatusRequest);
        System.out.println("==============================================================");
        acceptanceContext.fixMessageSender().accept(orderStatusRequest);
        TimeUnit.SECONDS.sleep(10);
    }

    private void sendOrderCancelRequest(final String clientId) throws Exception {
        final OrderCancelRequest orderCancelRequest= new OrderCancelRequest();
        orderCancelRequest.setString(ClOrdID.FIELD, "OPEN_ORDER");
        orderCancelRequest.setString(OrigClOrdID.FIELD, "OPEN_ORDER");
        orderCancelRequest.setString(7559, "Y");
        if (clientId != null) orderCancelRequest.setString(ClientID.FIELD, clientId);
        orderCancelRequest.setUtcTimeStamp(TransactTime.FIELD, new Date(acceptanceContext.precisionClock().millis()));

        System.out.println("Sending...OrderCancelRequest=" + orderCancelRequest);
        System.out.println("==============================================================");
        acceptanceContext.fixMessageSender().accept(orderCancelRequest);
        TimeUnit.SECONDS.sleep(10);
    }

    private double offMarketPrice(final double price, final Side side, final double priceOffset) {
        return price + ((side == Side.BUY) ? - 10*priceOffset : + 500*priceOffset);
    }

    private double awaitPrice(final InstrumentKey instrumentKey, final EntryType entryType) {
        final PricingMessage pricingMessage = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(IncrementalRefreshMatcher.build()
                        .body().matches(instrumentId().eq(instrumentKey.instrumentId()))
                        .entries().anyMatches(mdEntryType().eq(entryType))
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(100, TimeUnit.SECONDS);

        final AtomicDouble foundPrice = new AtomicDouble(0);
        pricingMessage.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                    foundPrice.set(incrementalRefresh.entries.stream()
                            .filter(entry -> entry.mdEntryType == entryType)
                            .mapToDouble(entry -> entry.mdEntryPx)
                            .findFirst().orElse(0));
                }
        });
        return foundPrice.get();
    }

    private NewOrderSingle newOrderSingle(final String symbol, final String clOrdId, final Side side, final double price,
                                          final double size, final String currency, final OrderType orderType, final TimeInForce timeInForce) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = timeInForce;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.price = price;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = symbol;
        return newOrderSingle;
    }

    private NewOrderSingle newOrderSingle(final String symbol, final String clOrdId, final Side side, final double size,
                                          final String currency, final OrderType orderType, final TimeInForce timeInForce) {
        return newOrderSingle(symbol, clOrdId, side, 0, currency, orderType, timeInForce);
    }

    private void assertFill(final String symbol, final String clOrdId, final Side side, final double size,
                            final String currency, final OrderType orderType, final boolean multipelExecutions) {
        if (multipelExecutions) {
            assertMultipleFills(symbol, clOrdId, side, size, currency, orderType);
        } else {
            assertSingleFill(symbol, clOrdId, side, size, currency, orderType);
        }
    }

    private void assertSingleFill(final String symbol, final String clOrdId, final Side side,
                                  final double size, final String currency, final OrderType orderType) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CNX))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CNX.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CNX))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CNX.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.cumQty().eq(size))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().eq(size))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0d))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private void assertMultipleFills(final String symbol, final String clOrdId, final Side side,
                                     final double size, final String currency, final OrderType orderType) {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CNX))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CNX.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CNX))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.PARTIALLY_FILLED))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CNX.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.cumQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.leavesQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .thenMatching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq(GB_LG_CNX))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.CNX.name()))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.cumQty().eq(size))
                        .body().matches(ExecutionReportMatcher.lastPx().gt(0d))
                        .body().matches(ExecutionReportMatcher.lastQty().gt(0d))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(0d))
                        .body().matches(ExecutionReportMatcher.avgPx().gt(0d))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }
}