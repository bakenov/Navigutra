package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.sbe.VenueConfigSbeDecoder;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class VenueConfigEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(VenueConfigEvent.class);

    private final VenueRepository venueRepository;
    private final VenueConfigSbeDecoder venueConfigDecoder = new VenueConfigSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public VenueConfigEvent(final VenueRepository venueRepository) {
        this.venueRepository = Objects.requireNonNull(venueRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!venueConfigDecoder.wrap(message)) return false;
        logMessage();

        venueRepository.apply(venueConfigDecoder);
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        venueConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying venue: {}", stringBuilder);
    }
}
