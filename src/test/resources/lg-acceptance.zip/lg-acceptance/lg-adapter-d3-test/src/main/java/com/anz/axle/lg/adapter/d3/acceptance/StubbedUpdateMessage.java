package com.anz.axle.lg.adapter.d3.acceptance;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

import de.digitec.d3.pricing.streaming.Field;
import de.digitec.d3.pricing.streaming.UpdateMessage;

public class StubbedUpdateMessage implements UpdateMessage {
    private final String symbol;
    private final int type;
    private final String subscriptionId;
    private final Map<String, Field> fieldsMap = new HashMap<>();

    public StubbedUpdateMessage(final String symbol,
                                final int type, final
                                String subscriptionId,
                                Field... fields) {
        this.symbol = Objects.requireNonNull(symbol);
        this.type = type;
        this.subscriptionId = Objects.requireNonNull(subscriptionId);
        Objects.requireNonNull(fields);
        for(Field field : fields) {
            fieldsMap.put(field.getKey(), field);
        }
    }

    @Override
    public String getSymbol() {
        return symbol;
    }

    @Override
    public int getType() {
        return type;
    }

    @Override
    public String getSubscriptionId() {
        return subscriptionId;
    }

    @Override
    public Field getField(final String key) {
        return fieldsMap.get(key);
    }

    @Override
    public void addField(final Field field) {
        fieldsMap.put(field.getKey(), field);
    }

    @Override
    public int getFieldSize() {
        return fieldsMap.size();
    }

    @Override
    public Iterator<Field> getFields() {
        return fieldsMap.values().iterator();
    }
}
