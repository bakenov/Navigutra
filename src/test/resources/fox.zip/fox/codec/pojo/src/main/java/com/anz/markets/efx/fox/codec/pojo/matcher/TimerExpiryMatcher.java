package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface TimerExpiryMatcher extends Predicate<Object> {

    Matcher<TimerExpiryMatcher, Header> header();
    Matcher<TimerExpiryMatcher, TimerExpiry.Body> body();

    static TimerExpiryMatcher build() {
        return new TimerExpiryMatcher() {
            private Predicate<TimerExpiry> predicate = Matchers.isA(TimerExpiry.class);

            @Override
            public Matcher<TimerExpiryMatcher, Header> header() {
                return matcher -> andThen(translate(pricingRefreshComplete -> pricingRefreshComplete.header, matcher));
            }

            @Override
            public Matcher<TimerExpiryMatcher, TimerExpiry.Body> body() {
                return matcher -> andThen(translate(timerExpiry -> timerExpiry.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof TimerExpiry && predicate.test((TimerExpiry) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private TimerExpiryMatcher matcher() {
                return this;
            }

            private TimerExpiryMatcher andThen(final Predicate<? super TimerExpiry> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<TimerExpiry.Body, Long> triggeredTime() {
        return ComparisonMatcher.create("triggeredTime", b -> b.triggeredTime);
    }

    static ComparisonMatcher<TimerExpiry.Body, Long> timerId() {
        return ComparisonMatcher.create("timerId", b -> b.timerId);
    }

    static ComparisonMatcher<TimerExpiry.Body, TimerGroup> timerGroup() {
        return ComparisonMatcher.create("timerGroup", b -> b.timerGroup);
    }
}
