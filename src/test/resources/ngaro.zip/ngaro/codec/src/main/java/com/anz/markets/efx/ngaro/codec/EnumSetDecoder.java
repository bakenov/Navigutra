package com.anz.markets.efx.ngaro.codec;

import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

public final class EnumSetDecoder<V extends Enum<V>> implements EnumerableSetDecoder<V> {

    public interface Getter<V> {
        boolean get(V value);
    }

    private final IntSupplier lengthSupplier;
    private final IntFunction<V> ordinalToValue;
    private final Getter<? super V> getter;
    private final BooleanSupplier isEmpty;

    public EnumSetDecoder(final IntSupplier lengthSupplier,
                          final IntFunction<V> ordinalToValue,
                          final Getter<? super V> getter,
                          final BooleanSupplier isEmpty) {
        this.lengthSupplier = Objects.requireNonNull(lengthSupplier);
        this.ordinalToValue = Objects.requireNonNull(ordinalToValue);
        this.getter = Objects.requireNonNull(getter);
        this.isEmpty = Objects.requireNonNull(isEmpty);
    }

    public EnumSetDecoder(final IntSupplier lengthSupplier,
                          final IntFunction<V> ordinalToValue,
                          final Set<? super V> backingSet) {
        this(lengthSupplier, ordinalToValue, backingSet::contains, backingSet::isEmpty);
    }

    @Override
    public boolean containsAny() {
        return !isEmpty.getAsBoolean();
    }

    @Override
    public boolean contains(final V value) {
        return getter.get(value);
    }

    @Override
    public void decodeTo(final Consumer<? super V> consumer) {
        for (int ordinal = 0; ordinal < lengthSupplier.getAsInt(); ordinal++) {
            final V value = ordinalToValue.apply(ordinal);
            if (getter.get(value)) {
                consumer.accept(value);
            }
        }
    }

    @Override
    public void decodeTo(final BiConsumer<? super V, ? super Boolean> consumer) {
        for (int ordinal = 0; ordinal < lengthSupplier.getAsInt(); ordinal++) {
            final V value = ordinalToValue.apply(ordinal);
            consumer.accept(value, getter.get(value));
        }
    }

    @Override
    public <S extends Set<? super V>> S decodeTo(final S target) {
        for (int ordinal = 0; ordinal < lengthSupplier.getAsInt(); ordinal++) {
            final V value = ordinalToValue.apply(ordinal);
            if (getter.get(value)) {
                target.add(value);
            }
        }
        return target;
    }
}
