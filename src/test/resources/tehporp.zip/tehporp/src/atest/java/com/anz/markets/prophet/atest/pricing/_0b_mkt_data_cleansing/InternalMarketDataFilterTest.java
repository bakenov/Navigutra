package com.anz.markets.prophet.atest.pricing._0b_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQty;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * AXPROPHET-858 Internal Market Data Filter : Remove ANZD market data (from orderbook) for AXL market.
 */

@Ignore("No longer receive AXL market as part of AXPROPHET-1369")
public class InternalMarketDataFilterTest extends BaseAcceptanceSpecification {

    private static final PriceAndQty BID_1 = new PriceAndQtyImpl(0.7005, 1_000_000);
    private static final PriceAndQty BID_2 = new PriceAndQtyImpl(0.7004, 1_000_000);
    private static final PriceAndQty BID_3 = new PriceAndQtyImpl(0.7003, 1_000_000);
    private static final PriceAndQty BID_4 = new PriceAndQtyImpl(0.7001, 2_000_000);

    private static final PriceAndQty OFFER_1 = new PriceAndQtyImpl(0.7006, 1_000_000);
    private static final PriceAndQty OFFER_2 = new PriceAndQtyImpl(0.7007, 1_000_000);
    private static final PriceAndQty OFFER_3 = new PriceAndQtyImpl(0.7008, 1_000_000);
    private static final PriceAndQty OFFER_4 = new PriceAndQtyImpl(0.7009, 2_000_000);

    private static final List<PriceAndQty> bids = Arrays.asList(BID_1, BID_2, BID_3, BID_4);
    private static final List<PriceAndQty> offers = Arrays.asList(OFFER_1, OFFER_2, OFFER_3, OFFER_4);

    @Test
    @DisplayName({"Given AXL market data snapshot, filter all of the ANZD market data"})
    public void GIVEN_AXL_market_data_snapshot_THEN_remove_ANZD_market_data() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY),
                            tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
            );
        }
        when:
        {
            long triggerTime = now();
            final List<String> bidOrderIds = Arrays.asList("M:AXL:36000967241:CMZ:01.24464", "M:AXL:36000967241:ANZD:02.24465", "M:AXL:36000967241:CNX:03.24466", "M:AXL:36000967241:ANZD:04.24467");
            final List<String> offerOrderIds = Arrays.asList("M:AXL:36000967241:ANZD:05.24468", "M:AXL:36000967241:CNX:06.24469","M:AXL:36000967241:ANZD:07.24470", "M:AXL:36000967241:CMZ:08.24471");

            prophet.receive(tdd.marketDataSnapshotWithBidOfferOrderIds(Market.AXL, Instrument.AUDUSD, bids, bidOrderIds, offers, offerOrderIds, triggerTime));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.AXL)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(2));
            assertThat(marketDataSnapshot.getOfferEventList().size(), is(2));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.70050, 0.70070));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_1M, 0.70030, 0.70090));
        }
    }

    @Test
    @DisplayName({"Given non AXL market data snapshot, do not filter any of the ANZD market data"})
    public void GIVEN_non_AXL_market_data_snapshot_THEN_do_not_remove_ANZD_market_data() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY),
                            tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
            );
        }
        when:
        {
            long triggerTime = now();
            final List<String> bidOrderIds = Arrays.asList("M:RFX:36000967243:CMZ:01.24464", "M:RFX:36000967243:ANZD:02.24465", "M:RFX:36000967243:ANZD:03.24466", "M:RFX:36000967243:ANZD:04.24467");
            final List<String> offerOrderIds = Arrays.asList("M:RFX:36000967243:CMZ:05.24468", "M:RFX:36000967243:ANZD:06.24469", "M:RFX:36000967243:ANZD:07.24470", "M:RFX:36000967243:ANZD:08.24471");

            prophet.receive(tdd.marketDataSnapshotWithBidOfferOrderIds(Market.RFX, Instrument.AUDUSD, bids, bidOrderIds, offers, offerOrderIds, triggerTime));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.RFX)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(3));  // we only output depth up to 3
            assertThat(marketDataSnapshot.getOfferEventList().size(), is(3)); // we only output depth up to 3
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.7005, 0.7006));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_1M, 0.7004, 0.7007));
            assertThat(marketDataSnapshot, isMarketPricePoint(2, Level.QTY_1M, 0.7003, 0.7008));
        }
    }
}
