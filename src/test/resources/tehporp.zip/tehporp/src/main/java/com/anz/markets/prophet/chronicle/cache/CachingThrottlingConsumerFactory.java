package com.anz.markets.prophet.chronicle.cache;

import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;

import java.util.Objects;
import java.util.function.Consumer;

public class CachingThrottlingConsumerFactory {

    public static CachingThrottlingConsumer<SpotDate> forSpotDate(final Consumer<SpotDate> consumer) {
        return new CachingThrottlingConsumer<>(
                SpotDateImpl::new,
                spotDate -> spotDate.getInstrument().name(),
                (spotDate1, spotDate2) -> Objects.equals(spotDate1.getSpotDate(), spotDate2.getSpotDate()) && Objects.equals(spotDate1.getTradeDate(), spotDate2.getTradeDate()),
                consumer);
    }

    public static CachingThrottlingConsumer<ForwardPoint> forForwardPoint(final Consumer<ForwardPoint> consumer) {
        return new CachingThrottlingConsumer<>(
                ForwardPointImpl::new,
                fwdPt -> String.join(":", String.valueOf(fwdPt.getInstrument()),
                        String.valueOf(fwdPt.getSource()),
                        Long.toString(fwdPt.getReferenceSpotDate().getDaysSinceEpoch()),
                        Long.toString(fwdPt.getTenorDate().getDaysSinceEpoch())),
                (fwdPt1, fwdPt2) -> Objects.equals(fwdPt1.getBidPoints(), fwdPt2.getBidPoints()) && Objects.equals(fwdPt1.getOfferPoints(), fwdPt2.getOfferPoints()),
                consumer);
    }
}
