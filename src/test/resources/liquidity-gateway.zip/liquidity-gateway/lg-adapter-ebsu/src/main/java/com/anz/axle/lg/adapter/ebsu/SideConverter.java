package com.anz.axle.lg.adapter.ebsu;

import com.anz.markets.efx.pricing.codec.api.AggressorAction;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import software.chronicle.ebs.itch.generated.preview.fields.MarketSide;

public class SideConverter {
    public static EntryType entryType(final char marketSide) {
        switch (marketSide) {
            case MarketSide.BUY:
                return EntryType.BID;
            case MarketSide.SELL:
                return EntryType.OFFER;
            default:
                throw new IllegalArgumentException("Unknown entry type " + marketSide);
        }
    }

    public static AggressorAction aggressorAction(final char marketSide) {
        switch (marketSide) {
            case MarketSide.BUY:
                return AggressorAction.PAID;
            case MarketSide.SELL:
                return AggressorAction.GIVEN;
            default:
                throw new IllegalArgumentException("Unknown entry type " + marketSide);
        }
    }
}
