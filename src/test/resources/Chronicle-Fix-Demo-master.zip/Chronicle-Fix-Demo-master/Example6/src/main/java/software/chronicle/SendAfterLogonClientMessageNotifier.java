package software.chronicle;

import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.WireIn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Logout;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * @author Rob Austin.
 */
public class SendAfterLogonClientMessageNotifier implements MessageNotifier, Marshallable {
    private transient final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private transient ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<>(1);
    private transient  boolean sessionAlive;


    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        this.sessionAlive = true;
        LOG.info("onLogon: " + logon.senderCompID());
        // any updates before the login will be ignored
        queue.clear();
    }

    @Override
    public MessageGenerator onNewOrderSingle(NewOrderSingle newOrderSingle) {
        newOrderSingle.sendingTime(0);
        queue.add(newOrderSingle.toString());
        return null;
    }

    public ArrayBlockingQueue<String> queue() {
        return queue;
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        LOG.info(reject.toString());
    }

    @Override
    public void onLogout(FixSessionHandler session, Logout logout) {
        LOG.info(logout.toString());
    }

    @Override
    public void onEndOfConnection(SessionID sessionID) {
        this.sessionAlive = false;
        LOG.info("onEndOfConnection");
    }

    public boolean sessionAlive() {
        return sessionAlive;
    }
}
