package com.anz.axle.lg.adapter.rfx.acceptance.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * The class processes the adapter log and builds state history
 */
public class AdapterLogProcessor {

    private static final String LOGON_MANAGER_CLASS = "DefaultLogonManager";
    private static final String TR_MATCHING = "TR MATCHING";
    private static final String SESSION_STATE = "SessionState";
    private static final String RFX_NEW_ORDER = "RfxNewOrderSingleHandler";
    private static final String RFX_EXEC = "DefaultRfxFillExecutionReportHandler";
    private static final String MSG_PARSER = "MessageParser";
    private static final String EXCEPTION = "Exception";
    private static final String JAVA = "java";

    private static final String FIX_DELIMITER = "\001";
    private static final String APP_DELIMITER = "|";

    public static void main(final String[] args) {
        final long startTime = System.currentTimeMillis();
        String logFileName = null;
        int startLineNum = 0;
        boolean fixOnly = true;
        switch(args.length) {
            case 0:
                logFileName = "lg-acceptance/lg-adapter-rfx-test/logs/no_appName.log";
                break;
            case 1:
                try {
                    startLineNum = Integer.parseInt(args[0]);
                    logFileName = "lg-acceptance/lg-adapter-rfx-test/logs/no_appName.log";
                } catch (NumberFormatException nfe) {
                    logFileName = args[0];
                    startLineNum = 0;
                }
                break;
            case 2:
                logFileName = args[0];
                startLineNum = Integer.parseInt(args[1]);
                break;

        }
        logFileName = new File(logFileName).getAbsolutePath();
        System.out.println("startLineNum=" + startLineNum + "    logFileName=" + logFileName);


        try{
            FileInputStream fstream = new FileInputStream(logFileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
            String strLine;
            int currentLineNum = 0;
            /* read log line by line */
            while ((strLine = br.readLine()) != null)   {
                /* parse strLine to obtain what you want */
                if (currentLineNum >= startLineNum) {
                    if (fixOnly) {
                        if (strLine.contains("8=FIXT.1.1")) {
                            System.out.println (replaceSOH(strLine));
                        }
                    } else {
                        if ((strLine.contains(LOGON_MANAGER_CLASS) ||
                                strLine.contains(TR_MATCHING) ||
                                strLine.startsWith(" ") ||
                                strLine.startsWith("}") ||
                                strLine.startsWith(JAVA) ||
                                strLine.contains(TR_MATCHING) ||
                                strLine.contains(SESSION_STATE) ||
                                strLine.contains(RFX_NEW_ORDER) ||
                                strLine.contains(RFX_EXEC) ||
                                strLine.contains(MSG_PARSER) ||
                                strLine.contains(EXCEPTION)) &&
                                !strLine.contains("35=0")) {
                            System.out.println ("" + currentLineNum + "  " + strLine);
                        }
                    }
                }
                currentLineNum++;
            }
            fstream.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static String replaceSOH(String line) {
        return line.replaceAll(FIX_DELIMITER, APP_DELIMITER);
    }
}
