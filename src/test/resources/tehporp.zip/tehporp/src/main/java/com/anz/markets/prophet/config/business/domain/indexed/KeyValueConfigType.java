package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.domain.CovarianceCategory;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.EnumValueDescriptor;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;

import java.util.HashMap;
import java.util.Map;

/**
 * Generic set of key values pair with type information.
 */
public enum KeyValueConfigType implements EnumValueDescriptor {

    /**
     * Define the threshold(millisecond) where E-Filter uses to determine whether a market should be removed (If there is a market whose TOB rates exceed this threshold: Prophet should remove a single market whose TOB market rate is the oldest).
     */
    MARKET_ORDER_BOOK_SLOWEST_MARKET_TOLERANCE_MS("market.orderBookSlowestMarketConfigToleranceMs", long.class),

    /**
     * List of instruments that should be hedged.
     */
    HEDGING_TRADEABLE_HEDGING_INSTRUMENTS("hedging.tradeable.hedgingInstruments", Instrument[].class),

    /**
     * List of currencies that should be used when calculating optimal position for price skewing.
     */
    RISK_COVARIANCE_MATRIX_MANAGED_ASSETS("risk.covarianceMatrixManagedAssets", Currency[].class),

    /**
     * List of insutruments that should be used when calculating optimal position for price skewing.
     */
    EQUILVALENT_POSITION_MINIMAL_INSTRUMENT_SET("risk.equivalentPositionMinimalInstrumentSet", Instrument[].class),

    /**
     * A flag to control whether Equivalent-Position(Risk). Skew should be applied, as part of the price formation process.
     */
    @Deprecated PRICING_OPTIMAL_POSITION_SKEW_ENABLED("pricing.optimalPositionSkewEnabled", boolean.class),

    /**
     * Applied to baseSpread for an Instrument, Internal Market(A,B,C), at a timezone
     */
    @Deprecated PRICING_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD("pricing.maxSkewAsProportionOfBaseSpread", double.class),

    /**
     * Applied to baseSpread for an Instrument, Internal Market(A,B,C), at a timezone
     */
    @Deprecated PRICING_OVERALL_MAX_SKEW_AS_PROPORTION_OF_BASE_SPREAD("pricing.overallMaxSkewAsProportionOfBaseSpread", double.class),

    /**
     * Not Used at this time
     */
    PRICING_PREDICTOR_SKEW_ENABLED("pricing.predictorSkewEnabled", boolean.class),

    /**
     * A flag to control whether Net-Open-Position(NOP) Skew should be applied, as part of the price formation process.
     */
    @Deprecated PRICING_POSITION_SKEW_ENABLED("pricing.positionSkewEnabled", boolean.class),

    /**
     * A flag to control whether Overall Skew should be applied, as part of the price-formation process.
     */
    @Deprecated PRICING_OVERALL_SKEW_ENABLED("pricing.overallSkewEnabled", boolean.class),

    /**
     * Value represent percentage Threshold in which price should turn indicative when position >= NOP limit * threshold.
     */
    PRICING_FIREWALL_NET_OPEN_POSITION_INDICATIVE_PRICE_THRESHOLD("pricing.firewall.netOpenPositionIndicativePriceThreshold", double.class),

    /**
     * A flag to control whether NOP-pricing firewall should be applied as part of the Sanity Checking process.
     */
    PRICING_FIREWALL_NET_OPEN_POSITION_ENABLED("pricing.firewall.netOpenPosition.enabled", boolean.class),

    /**
     * A flag to control whether Overall-Profit-Volume firewall should be applied as part of the Sanity Checking process.
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED("pricing.firewall.overallProfitVolume.enabled", boolean.class),

    /**
     * A flag to control whether Overall-Profit-Volume firewall automatically resets from indicative (if false then needs to be manually reset)
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_AUTO_RESET("pricing.firewall.overallProfitVolume.auto_reset", boolean.class),

    /**
     * Define the maximum P/L(of Overall book) for the firewall NOT to be triggered.
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD("pricing.firewall.overallProfitVolume.pnlLimitUsd", double.class),

    /**
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS("pricing.firewall.overallProfitVolume.pnlLimitPeriodSeconds", int.class),

    /**
     * Define the maximum Trade-volume(of Overall book) for the firewall NOT to be triggered.
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD("pricing.firewall.overallProfitVolume.volumeLimitUsd", double.class),

    /**
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS("pricing.firewall.overallProfitVolume.volumeLimitPeriodSeconds", int.class),

    /**
     * Minimum latch time(ms) to turn prices INDICATIVE once the firewall is breached.
     */
    PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS("pricing.firewall.overallProfitVolume.triggeredDurationSeconds", int.class),

    /**
     * Define the maximum permissible time spent by messages in chronicle.in before turning client pricing indicative after delayMS.
     */
    PRICING_FIREWALL_INPUT_LATENCY_BARRIER_MS("pricing.firewall.inputLatency.barrierMS", long.class),

    /**
     * Once latency triggered, define the lower threshold upon which to resume firm pricing
     */
    PRICING_FIREWALL_INPUT_LATENCY_RESUME_MS("pricing.firewall.inputLatency.resumeMS", long.class),

    /**
     * The monitoring delay before turning client pricing indicative
     */
    PRICING_FIREWALL_INPUT_LATENCY_DELAY_MS("pricing.firewall.inputLatency.delayMS", long.class),

    /**
     * Define the maximum permissible time spent by messages in chronicle.in before turning client pricing indicative immediately
     */
    PRICING_FIREWALL_INPUT_LATENCY_HARD_BARRIER_MS("pricing.firewall.inputLatency.hardBarrierMS", long.class),


    /**
     * A flag to control whether Price-Barrier firewall should be applied as part of the Sanity Checking process.
     */
    PRICING_FIREWALL_PRICE_BARRIER_ENABLED("pricing.firewall.priceBarrier.enabled", boolean.class),

    /**
     * A flag to control whether Price-Barrier firewall automatically resets from indicative (if false then needs to be manually reset)
     */
    PRICING_FIREWALL_PRICE_BARRIER_AUTO_RESET("pricing.firewall.priceBarrier.auto_reset", boolean.class),

    /**
     * A flag to control whether Price-Spike firewall should be applied as part of the Sanity Checking process.
     */
    PRICING_FIREWALL_PRICE_SPIKE_ENABLED("pricing.firewall.priceSpike.enabled", boolean.class),

    /**
     * A flag to control whether Price-Spike firewall automatically resets from indicative (if false then needs to be manually reset)
     */
    PRICING_FIREWALL_PRICE_SPIKE_AUTO_RESET("pricing.firewall.priceSpike.auto_reset", boolean.class),

    /**
     * A flag to control whether outside operating hour firewall should be applied as part of the Sanity Checking process.
     */
    PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED("pricing.firewall.outsideOperatingHour.enabled", boolean.class),

    /**
     * A flag to control whether tagged indicative client prices should be firewalles
     */
    PRICING_FIREWALL_TAGGED_INDICATIVE_ENABLED("pricing.firewall.taggedIndicative.enabled", boolean.class),

    /**
     * A flag to control whether calculation decision data should be recorded in chronicle out.  Currently turns on/off skew and wholesalebookfactor data.
     */
    CALCULATION_DATA_COLLECTION_ENABLED("general.calculationDataCollectionEnabled", boolean.class),

    /**
     * Specifies which instruments should have verbose analytic data enabled.  This will dynamically add additional detail to output chronicles.  Requires CALCULATION_DATA_COLLECTION_ENABLED to be on.  Turn off for maximum throughput.  Turn on for detailed analytics that flow into KDB.
     */
    CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET("general.calculationDataCollectionVerboseInstrumentSet", Instrument[].class),

    /**
     * A flag to control whether calculation decision data should be recorded in chronicle out
     */
    VOLATILITY_PRICE_WIDENING_ENABLED("pricing.widening.volatility.enabled", boolean.class),

    /**
     * A flag to control whether calculation decision data should be recorded in chronicle out
     */
    RISK_PRICE_WIDENING_ENABLED("pricing.widening.risk.enabled", boolean.class),

    /**
     * A flag to control whether calculation decision data should be recorded in chronicle out
     */
    ECONNEWS_PRICE_WIDENING_ENABLED("pricing.widening.econews.enabled", boolean.class),

    /**
     * A flag to control whether calculation decision data should be recorded in chronicle out
     */
    MARKETGAP_PRICE_WIDENING_ENABLED("pricing.widening.marketgap.enabled", boolean.class),

    /**
     * Define the threshold(millisecond) after which fwd points are defined as stale
     */
    PRICING_FWD_POINTS_MAX_AGE_MS("pricing.fwdPointsMaxAgeMs", long.class),

    /**
     * If forward points differ by greater than : "point X 'forwardPointDivergenceMultiplier'" failfast
     */
    PRICING_FWD_DIVERGENCE_ALLOWANCE("pricing.forwardPointDivergenceAllowance", double.class),

    /**
     * Define the threshold(millisecond) after which fwd points are defined as stale
     */
    RISK_PATH_PUBLISHING_REGION("riskPathPublishing.region", Region.class),

    /**
     * Define the threshold(millisecond) after which fwd points are defined as stale
     */
    RISK_PATH_PUBLISHING_ENABLED("riskPathPublishing.enabled", boolean.class),

    /**
     * Market gap definitions to use midRate from this market (WSP_U / WSP_MU)
     */
    MARKETGAP_PRICE_WIDENING_MIDRATE_MARKET("pricing.widening.marketgap.midRateMarketChooser", Market.class),

    /**
     * Define the maximum allowed bias control input for an individual currency
     */
    POSITION_BIAS_OFFSET_CURRENCY_LIMIT_USD("position.bias.perCurrency.limitUSD", double.class),

    /**
     * Define the maximum allowed bias control input in aggregate across all currencies
     */
    POSITION_BIAS_OFFSET_TOTAL_LIMIT_USD("position.bias.total.limitUSD", double.class),

    /**
     * covariance category (from kdb) which will be used for pricing
     */
    COVAR_RISK_FACTOR_PRICING_CATEGORY("risk.pricing.covarCategory", CovarianceCategory.class),

    /**
     * covariance category (from kdb) which will be used for hedging
     */
    COVAR_RISK_FACTOR_HEDGING_CATEGORY("risk.hedging.covarCategory", CovarianceCategory.class),

    /**
     * pause period for hedging (from kdb) which will be used upon receipt of a pause command
     */
    PAUSE_HEDGING_PERIOD_SEC("hedging.control.pausePeriodSeconds", int.class),

    /**
     * pause period for skewing (from kdb) which will be used upon receipt of a pause command
     */
    PAUSE_SKEWING_PERIOD_SEC("skewing.control.pausePeriodSeconds", int.class),

    /**
     * Use percentile bucket functionality for volatility spread widening.
     */
    VOLATILITY_PRICE_WIDENING_PERCENTILE("pricing.widening.volatility.percentile", boolean.class),

    /**
     * Rate Limit Throttle : The rolling window time to monitor
     */
    THROTTLER_RATE_LIMIT_PER_SECONDS("throttler.rateLimitPeriodSeconds", int.class),

    /**
     * Rate Limit Throttle : Limiter activates when number of messages observed in the rolling window exceeds this value
     */
    THROTTLER_RATE_LIMIT_MESSAGES_HIGH("throttler.rateLimitMessagesHigh", int.class),

    /**
     * Rate Limit Throttle : limiter deactivates when number of messages observed in the rolling window falls below this value
     */
    THROTTLER_RATE_LIMIT_MESSAGES_LOW("throttler.rateLimitMessagesLow", int.class),

    RESERVED_FOR_INTERNAL_USE("place holder for a string type. This was added for test but use me if you are defining a string value", String.class),

    /** Specifies the models that True Throttle will be enabled for.  The complement of client markets will be enabled on the traditional Fixed Rate Throttler. */
    TRUE_THROTTLE_MARKETS("truethrottle.models", Market[].class),

    /**
     * A flag to control whether the indicative-control firewall should be applied.
     */
    PRICING_FIREWALL_PAUSE_CONTROL_ENABLED("pricing.firewall.pause.control.enabled", boolean.class),

    /** Specifies the models that will automatically use PassthroughSpread strategy for Local Market instruments. */
    LOCAL_MARKET_PASSTHROUGH_MODELS("localmarket.passthrough.models", Market[].class),

    /** Specifies which markets will have price point aggregation turned on. */
    AGGREGATE_PRICE_POINT_MARKETS("market.data.aggregatePricePoints.markets", Market[].class),

    /** The lower boundary for the manual volatility factor */
    MANUAL_VOLATILITY_FACTOR_MINIMUM("pricing.widening.manual.minimum", double.class),

    /**
     * The input latency threshold before price pipeline short-circuiting becomes more aggressive - Nanos.
     */
    PRICING_SHORTCIRCUIT_AGGRESSIVE_LATENCY_THRESHOLD_NS("pricing.shortcircuit.aggressiveLatencyThresholdNS", long.class),

    /**
     * Price pipeline short-circuiting aggressive multiplier.
     */
    PRICING_SHORTCIRCUIT_AGGRESSIVE_MULTIPLIER("pricing.shortcircuit.aggressiveMultiplier", double.class),

    /**
     * Price pipeline short-circuiting normal multiplier.
     */
    PRICING_SHORTCIRCUIT_NORMAL_MULTIPLIER("pricing.shortcircuit.normalMultiplier", double.class),


    /**
     * Portfolios to monitor for risk reducing flow.  Currently used in RiskReducingFlowManager and StanddownSkewFillRateFeatures.
     */
    PRICING_RISK_REDUCING_FLOW_PORTFOLIOS("pricing.rrflow.portfolios", Portfolio[].class),

    /**
     * Market used in hedging liquidity check.
     */
    HEDGING_LIQUIDITY_CHECK_MARKET("hedging.liquidity.check.market", Market.class),

    /**
     * Max simultaneous skew experiments.
     */
    PRICING_MAX_SIMULTANEOUS_SKEW_EXPERIMENTS("pricing.skewx.maxSimultaneous", int.class),

    /**
     * Turn on DISCO signal generation.
     */
    DISCO_ENABLED("disco.enabled", boolean.class),

    /**
     * Use mid rate for position calculation.
     */
    POSITION_IN_SYSTEM_BASE_USE_MIDRATE_ENABLED("position.insystembase.midrate.enabled", boolean.class)

    ;

    /**
     * todo: collapse this into enum name.
     */
    private String keyName;
    private Class type;

    private static final Map<CharSequence, KeyValueConfigType> MAP_BY_KEY_NAME = new HashMap<>();

    KeyValueConfigType(final String keyName,
                       final Class type) {
        this.keyName = keyName;
        this.type = type;
    }


    public String getKeyName() {
        return keyName;
    }

    public Class getType() {
        return type;
    }

    @Override
    public String getDocumentation() {
        final String typeName = type.getName();
        if (type.isArray()) {
            final String qualifiedName = typeName.substring(2, typeName.length() - 1);
            final String simpleName = qualifiedName.substring(qualifiedName.lastIndexOf('.') + 1);
            return String.format("List of comma delimited [%s](#%s)", simpleName, qualifiedName);
        } else {
            return typeName;
        }
    }

    public static KeyValueConfigType getByKeyName(CharSequence key) {
        return MAP_BY_KEY_NAME.get(key);
    }

    static {
        for (KeyValueConfigType keyValueConfigType : KeyValueConfigType.values()) {
            if (MAP_BY_KEY_NAME.containsKey(keyValueConfigType.getKeyName())) {
                throw new IllegalArgumentException("Duplicate key name found. This is a bug.");
            }
            MAP_BY_KEY_NAME.put(keyValueConfigType.getKeyName(), keyValueConfigType);
        }
    }
}
