package com.anz.markets.efx.fox.aggregator.config;

import java.util.Objects;

import org.slf4j.Logger;

import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;

public class LoggingEndPointStatusHandler implements EndPointStatusHandler {

    private final Logger logger;

    public LoggingEndPointStatusHandler(final Logger logger) {
        this.logger = Objects.requireNonNull(logger);
    }

    @Override
    public void onStatus(final Event event, final Topic topic, final Object status) {
        switch (event) {
            case INFO:
                logger.debug("Status: event=INFO, topic={}, status={}", topic.name(), status);
                break;
            case CLOSE:
                logger.info("Status: event=CLOSE, topic={}, status={}", topic.name(), status);
                break;
            case NOTIFICATION:
                logger.warn("Status: event=NOTIFICATION, topic={}, status={}", topic.name(), status);
                break;
            case EXCEPTION:
                logger.error("Status: event=EXCEPTION, topic={}, status={}", topic.name(), status, status);//second status to print exception trace
                break;
            default:
                logger.error("Unknown Status: event={}, topic={}, status={}", event, topic.name(), status);
                break;
        }
    }
}
