package com.anz.axle.lg.adapter.barx.quickfix;

import quickfix.field.Currency;
import quickfix.field.FutSettDate;
import quickfix.field.MsgType;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.QuoteReqID;
import quickfix.field.SecurityType;
import quickfix.field.Symbol;
import quickfix.fix44.QuoteRequest;

import com.anz.axle.lg.adapter.fix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

public class BarxMarketDataRequestEncoder implements MarketDataRequestEncoder<QuoteRequest> {
    protected static final int STREAMING_QUOTE_DURATION_FIELD = 6065;
    protected static final int STREAMING_QUOTE_DURATION_VALUE_TILL_LOGOUT = 0;
    protected static final int STREAMING_QUOTE_DURATION_VALUE_END = -1;
    protected static final String SUBSCRIPTION_FUTURE_SETTLEMENT_DATE = "SP";

    private final QuoteRequest quoteRequest = new QuoteRequest();
    private final QuoteRequest.NoRelatedSym group = new QuoteRequest.NoRelatedSym();

    @Override
    public QuoteRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(quoteRequest, requestId, subscription, STREAMING_QUOTE_DURATION_VALUE_TILL_LOGOUT);
    }

    @Override
    public QuoteRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(quoteRequest, requestId, subscription, STREAMING_QUOTE_DURATION_VALUE_END);
    }

    private QuoteRequest encode(final QuoteRequest quoteRequest, final long requestId, final MarketDataSubscription subscription, final int streamingQuoteDuration) {
        quoteRequest.clear();
        quoteRequest.getHeader().setString(MsgType.FIELD, MsgType.QUOTE_REQUEST);
        quoteRequest.setString(QuoteReqID.FIELD, Long.toString(requestId));

        group.clear();
        group.setChar(OrdType.FIELD, OrdType.FOREX_MARKET);
        group.setString(FutSettDate.FIELD, SUBSCRIPTION_FUTURE_SETTLEMENT_DATE);
        group.setInt(STREAMING_QUOTE_DURATION_FIELD, streamingQuoteDuration);
        group.setString(Symbol.FIELD, subscription.symbol());
        group.setString(Currency.FIELD, subscription.symbol().substring(0, 3));
        group.setString(SecurityType.FIELD, SecurityType.FOREIGN_EXCHANGE_CONTRACT);

        // from DestinationInstrumentData_BARX.evt
        // # BARX is configured the same for all currency pairs (Bands of 1m,3m & 5m)
        group.setDouble(OrderQty.FIELD, (double)subscription.orderQty());

        quoteRequest.addGroup(group);
        return quoteRequest;
    }
}
