package com.anz.axle.lg.adapter.hsp.chroniclefix;

import java.util.Objects;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.components.ExecutionReport_ContraBrokersGrp_1;
import com.anz.axle.lg.adapter.hsp.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.Parties;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

import static com.anz.axle.lg.adapter.fix.Converter.nanToZero;

public final class HspExecutionReportHandler implements ChronicleMessageHandler<ExecutionReport> {
    private static final Logger LOGGER = LoggerFactory.getLogger(HspExecutionReportHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    private final TradingEncoderSupplier tradingResponseEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final Venue venue;
    private final LongSupplier messageIdGenerator;

    private final CachedFunction<String, String> symbol6Lookup = CachedFunction.of(SymbolNormaliser::toSymbol6);
    private final SourceSequencer sourceSequencer;

    public HspExecutionReportHandler(final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                     final PrecisionClock precisionClock,
                                     final String senderCompId,
                                     final String compId,
                                     final Venue venue,
                                     final LongSupplier messageIdGenerator,
 final SourceSequencer sourceSequencer) {
        this.tradingResponseEncoderSupplier = Objects.requireNonNull(tradingResponseEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.venue = Objects.requireNonNull(venue);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final ExecutionReport message) throws IllegalArgumentException {

        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("ExecutionReport received: {}", message);

        final long sequenceNumber = message.msgSeqNum();
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = message.sendingTime();

        final OrderStatus orderStatus = orderStatus(message.ordStatus());

        final ExecutionReportEncoder.Body bodyEncoder = tradingResponseEncoderSupplier.executionReport()
                .messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .orderId().encode(message.orderID())
                .clOrdId().encode(message.clOrdID())
                .origClOrdId().encode(message.clOrdID())
                .clOrdLinkId().encodeEmpty()
                .marketId().encode(venue.name())
                .execId().encodeNullable(message.execID())
                .execType(execType(message.execType()))
                .settlDate().encodeFormatted(message.futSettDate(), DATE_DECODER)
                .ordStatus(orderStatus)
                .symbol().encode(symbol6Lookup.apply((message.symbol())))
                .securityType(SecurityType.FXSPOT)
                .orderQty(nanToZero(message.orderQty()))
                .targetStrategyName().encodeEmpty()
                .price(nanToZero(message.price()))
                .side(side(message.side()))
                .currency().encodeNullable(message.currency())
                .timeInForce(timeInForce(message.timeInForce()))
                .tradeDate().encodeFormatted(message.tradeDate(), DATE_DECODER)
                .settlCurrency().encode(message.currency())
                .lastPx(nanToZero(message.lastPx()))
                .lastQty(nanToZero(message.lastShares()))
                .leavesQty(nanToZero(message.leavesQty()))
                .cumQty(nanToZero(message.cumQty()))
                .avgPx(nanToZero(message.avgPx()))
                .transactTime(message.transactTime());

        addParties(bodyEncoder, message.account(), contraBrokerOrNull(message))
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .quoteId().encodeEmpty()
                .rejectText().encodeNullable(message.text())
                .messageComplete();
    }

    private ExecutionReportEncoder.StrategyParameters addParties(final ExecutionReportEncoder.Body bodyEncoder, final String account, final String contraBroker) {
        int partiesCount = 0;
        if (account != null) partiesCount ++;
        if (contraBroker != null) partiesCount ++;

        final Parties.Encoder.Next<ExecutionReportEncoder.StrategyParameters> partiesNext = bodyEncoder.partiesStart(partiesCount);

        if (account != null) {
            partiesNext.next()
                    .partyRole(PartyRole.SETTLEMENT_ACCOUNT)
                    .partyId().encodeNullable(account);
        }
        if (contraBroker != null) {
            partiesNext.next()
                    .partyRole(PartyRole.CONTRA_FIRM)
                    .partyId().encodeNullable(contraBroker);
        }
        return partiesNext.partiesComplete();
    }

    private String contraBrokerOrNull(final ExecutionReport message) {
        String contraBroker = null;
        if (message.noContraBrokers() > 0) {
            final ExecutionReport_ContraBrokersGrp_1 brokersGrp_1 = message.executionReport_ContraBrokersGrp_1(0);
            contraBroker = brokersGrp_1.contraBroker();
        }
        return contraBroker;
    }

    private ExecType execType(final char execType) {
        switch (execType) {
            case '0' : return ExecType.NEW;
            case '3' : return ExecType.DONE_FOR_DAY; // hotspot description as 'Average Trade'
            case '4' : return ExecType.CANCELED;
            case '5' : return ExecType.REPLACED;
            case '6' : return ExecType.PENDING_CANCEL;
            case '8' : return ExecType.REJECTED;
            case 'C' : return ExecType.EXPIRED;
            case 'E' : return ExecType.PENDING_REPLACE;
            case 'F' : return ExecType.TRADE;
            case 'I' : return ExecType.ORDER_STATUS;
            default: throw new IllegalArgumentException("Unsupported execType " + execType);
        }
    }
    private Side side(final char side) throws IllegalArgumentException {
        switch (side) {
            case com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.Side.BUY : return Side.BUY;
            case com.anz.axle.lg.adapter.hsp.chroniclefix.generated.fields.Side.SELL : return Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side " + side);
        }
    }

    private OrderStatus orderStatus(final char ordStatus) {
        switch (ordStatus) {
            case '0' :
            case 'D' : // fallthrough 'D' = 'Accepted for bidding' that we are mapping to NEW(0). Since we don't have Accepted for bidding mapped to OrderStatus emun (yet).
                return OrderStatus.NEW;
            case '1' : return OrderStatus.PARTIALLY_FILLED;
            case '2' : return OrderStatus.FILLED;
            case '3' : return OrderStatus.DONE_FOR_DAY;
            case '4' : return OrderStatus.CANCELED;
            case '6' : return OrderStatus.PENDING_CANCEL;
            case '8' : return OrderStatus.REJECTED;
            case '9' : return OrderStatus.SUSPENDED;
            case 'A' : return OrderStatus.PENDING_NEW;
            case 'C' : return OrderStatus.EXPIRED;
            case 'E' : return OrderStatus.PENDING_REPLACE;
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }

    private TimeInForce timeInForce(final char timeInForce) {
        switch (timeInForce) {
            case '0' : return TimeInForce.DAY;
            case '1' : return TimeInForce.GTC;
            case '3' : return TimeInForce.IOC;
            case '4' : return TimeInForce.FOK;
            case '6' : return TimeInForce.GTD;
            default: throw new IllegalArgumentException("Unsupported timeInForce " + timeInForce);
        }
    }

}
