NGARO
----

<a href="http://www.islandive.com/whitsunday-aboriginals.php">The Ngaro</a> is an Aboriginal tribe that inhabited the
<a href="https://en.wikipedia.org/wiki/Whitsunday_Islands">Whitsunday Islands</a> at least 8000 years prior to the
Europeans arriving in 1770. <a href="https://en.wikipedia.org/wiki/Whitsunday_Island">Whitsunday Island</a> is the largest
island of this group of islands located off the coast of Central Queensland and it features the white sands of
<a href="https://en.wikipedia.org/wiki/Whitehaven_Beach">Whitehaven Beach</a>. The beach was awarded Queensland's
Cleanest Beach in 2008.

This name was chosen because classes in this repository are designed to create the cleanest applications by completely
avoiding garbage. Garbage free programming is used to minimise latencies in our trading applications.

![Whitehaven Beach](https://bitbucket.service.anz/projects/EFX/repos/ngaro/browse/whitehaven-beach.jpg?raw)