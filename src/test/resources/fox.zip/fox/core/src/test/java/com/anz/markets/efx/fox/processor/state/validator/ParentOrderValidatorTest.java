package com.anz.markets.efx.fox.processor.state.validator;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.processor.validator.OrderQuantityParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.OrderTypeParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.ParentOrderValidator;
import com.anz.markets.efx.fox.processor.validator.TimeInForceParentOrderValidator;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class ParentOrderValidatorTest {

    @Mock
    private CommandContext commandContext;

    private ParentOrderValidator.NamedValidator validatorEMatch;
    private ParentOrderValidatorTest.TestValidationErrorHandler errorHandler;
    private TradingCodecTestHelper  codecHelper;

    class TestParentOrderValidator implements ParentOrderValidator.NamedValidator {
        private final List<ParentOrderValidator> validators;
        private final ParentOrderValidator.ErrorHandler errorHandler;

        public TestParentOrderValidator(final ParentOrderValidator.ErrorHandler handler) {
            errorHandler = Objects.requireNonNull(handler);
            validators = Arrays.asList(
                    new TimeInForceParentOrderValidator(errorHandler, TimeInForce.GTC,TimeInForce.DAY),
                    new OrderTypeParentOrderValidator(errorHandler, OrderType.FIXING_ORDER),
                    new OrderQuantityParentOrderValidator(errorHandler)
            );
        }

        @Override
        public boolean validate(final NewOrderSingleDecoder parentOrderDecoder,
                                final CommandContext commandContext) {
            for(ParentOrderValidator validator : validators) {
                if (!validator.validate(parentOrderDecoder, commandContext))
                    return false;
            }
            return true;
        }

        @Override
        public String name() {
            return "TestValidator";
        }
    }


    class TestValidationErrorHandler implements ParentOrderValidator.ErrorHandler {
        private boolean isPassed = true;

        public boolean isPassed() { return isPassed; }

        @Override
        public void onError(final String errorMessage,
                            final NewOrderSingleDecoder parentOrderDecoder,
                            final CommandContext commandContext) {
            // Just reject execution report
            this.isPassed = false;
        }
    }



    @Before
    public void setUp() {
        errorHandler = new ParentOrderValidatorTest.TestValidationErrorHandler();
        codecHelper = new TradingCodecTestHelper();
        validatorEMatch = new ParentOrderValidatorTest.TestParentOrderValidator(errorHandler);
    }

    @Test
    public void should_pass_on_all_correct_parameters() {
        codecHelper.expectedOrderType(OrderType.FIXING_ORDER);
        codecHelper.expectedQuantity(1000000);
        codecHelper.expectedTimeInForce(TimeInForce.GTC);

        // Check valid parameters
        validatorEMatch.validate(codecHelper.encodeNewOrderSingle(), commandContext);
        assertThat(errorHandler.isPassed()).isTrue();
    }

    @Test
    public void should_reject_unsupported_timeInForce() {
        // Check unsupported TimeInForce
        codecHelper.expectedOrderType(OrderType.FIXING_ORDER);
        codecHelper.expectedQuantity(1000000);
        codecHelper.expectedTimeInForce(TimeInForce.IOC);

        validatorEMatch.validate(codecHelper.encodeNewOrderSingle(), commandContext);
        assertThat(errorHandler.isPassed()).isFalse();
    }

    @Test
    public void should_reject_unsupported_orderType() {
        // Check unsupported OrderType
        codecHelper.expectedOrderType(OrderType.LIMIT);
        codecHelper.expectedQuantity(1000000);
        codecHelper.expectedTimeInForce(TimeInForce.GTC);

        validatorEMatch.validate(codecHelper.encodeNewOrderSingle(), commandContext);
        assertThat(errorHandler.isPassed()).isFalse();
    }

    @Test
    public void should_reject_negative_quantity() {
        // Check negative Qty
        codecHelper.expectedOrderType(OrderType.FIXING_ORDER);
        codecHelper.expectedQuantity(-1000000);
        codecHelper.expectedTimeInForce(TimeInForce.GTC);

        validatorEMatch.validate(codecHelper.encodeNewOrderSingle(), commandContext);
        assertThat(errorHandler.isPassed()).isFalse();
    }

    @Test
    public void should_reject_zero_quantity() {
        // Check zero Qty
        codecHelper.expectedOrderType(OrderType.LIMIT);
        codecHelper.expectedQuantity(0);
        codecHelper.expectedTimeInForce(TimeInForce.GTC);

        validatorEMatch.validate(codecHelper.encodeNewOrderSingle(), commandContext);
        assertThat(errorHandler.isPassed()).isFalse();
    }
}
