package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticWideningFactor;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Ignore;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@Ignore("we now do not triangulate inverse pair")
public class TriangulationTest_IndirectIndirect_AUDEUR extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = Ref.PRICING_4_6)
    @DisplayName("Triangulation of cross pair from INDIRECT-INDIRECT driver pairs: AUDEUR")
    public void given_AUDUSD_EURUSD_driver_pairs_triangulate_AUDEUR_cross_pair() throws Exception {

        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverPairB = Instrument.EURUSD;
        final Instrument crossPair = Instrument.AUDEUR;

        given:
        {
            // set spot date cross
            prophet.receive(new SpotDateImpl(crossPair, LocalDate.now().plusDays(2)));

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                            new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0)
                    ))
                    .setSyntheticWideningFactors(Arrays.asList(
                            SyntheticWideningFactor.createWithDefaultWideningFactor(Currency.AUD, Currency.EUR, Market.WSP_A, 1.0)

                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }
        when:
        {
            // receive driver pair AUDUSD MID Rate = 0.76105;
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.76105, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairA)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.76103500, 0.76106500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.76102000, 0.76108000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.76101250, 0.76108750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.76100000, 0.76110000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.7609200, 0.7611800));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.7608600, 0.7612400));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.7607700, 0.7613300));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.7607300, 0.7613700));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.7606000, 0.7615000));
        }

        when:
        {
            // receive driver pair EURUSD MID rate = 1.12985;
            prophet.receive(tdd.marketDataSnapshot(driverPairB, 1.12985, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(driverPairB)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.12983500, 1.12986500));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.12982000, 1.12988000));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.12981250, 1.12988750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.12980000, 1.12990000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.1297200, 1.1299800));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.1296600, 1.1300400));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.1295700, 1.1301300));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.1295300, 1.1301700));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 1.1294000, 1.1303000));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(crossPair)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            // we have some issues with a subset of triang acceptance tests whereby prophet and excel do not agree
            // on numbers after 8th decimal place. It seems (after lots of excel'ing) that this is an artefact of
            // slightly different calculation methods prophet vs excel and different intermediates.
            // We have modified this test to reflect *prophet's* numbers

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.67356277077, 0.67360720813));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.67354271983, 0.67362726103));
            // excel -  0.67354271986, 0.67362726106
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.67353269469, 0.67363728781));
            // excel -  0.67353269472, 0.67363728784
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.67351454174, 0.67365544374));
            // excel -  0.67351454181, 0.67365544381
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.67343867628, 0.67373135168));
            // excel -  0.67343867996, 0.67373135536
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.67333935114, 0.67383068371));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.67323047999, 0.67393974110));
            // excel -  0.67323049169, 0.67393975279
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.67313494908, 0.67403525235));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.67300695354, 0.67416342717));
            // excel -  0.67300695969, 0.67416343332
        }
    }
}
