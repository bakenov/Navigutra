package com.anz.markets.efx.fox.aggregator.core;

import java.util.Objects;
import java.util.function.LongConsumer;

import org.agrona.DirectBuffer;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleHandler;
import com.anz.markets.efx.trading.codec.api.TradingDecoders;
import com.anz.markets.efx.trading.codec.api.TradingHandlerSupplier;

public final class TradingResponseMessageHandler implements MessageHandler {

    private final MessageDecoder<SbeMessage> tradingResponseDecoder;
    private final LongConsumer receivedTimeNanosConsumer;
    private final SbeMessageForReading sbeMessage;

    public TradingResponseMessageHandler(final LongConsumer receivedTimeNanosConsumer,
                                         final MessageDecoder<SbeMessage> tradingResponseDecoder) {
        this.receivedTimeNanosConsumer = Objects.requireNonNull(receivedTimeNanosConsumer);
        this.tradingResponseDecoder = Objects.requireNonNull(tradingResponseDecoder);
        this.sbeMessage = new SbeMessageForReading();
    }

    public static TradingResponseMessageHandler create(final TradingDecoders<SbeMessage> sbeTradingDecoders,
                                                       final LongConsumerSupplier receivedTimeConsumerSupplier,
                                                       final NewOrderSingleHandler newOrderSingleHandler) {

        final MessageDecoder<SbeMessage> newOrderSingle = sbeTradingDecoders.executionReportAndOrderCancelReject().create(
                TradingHandlerSupplier.newOrderSingle(newOrderSingleHandler),
                MessageDecoder.ForwardingLookup.noop());

        return new TradingResponseMessageHandler(receivedTimeConsumerSupplier, newOrderSingle);
    }

    @Override
    public void onMessage(final Topic topic, final DirectBuffer buffer, final int offset, final int length, final long receiveTimeNanosSinceEpoch) {
        receivedTimeNanosConsumer.accept(receiveTimeNanosSinceEpoch);
        try {
            tradingResponseDecoder.decode(sbeMessage.wrap(buffer, offset, length));
        } finally {
            sbeMessage.unwrap();
            receivedTimeNanosConsumer.accept(0);
        }
    }
}
