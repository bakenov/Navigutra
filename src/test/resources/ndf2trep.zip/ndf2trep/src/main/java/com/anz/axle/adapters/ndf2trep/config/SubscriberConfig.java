package com.anz.axle.adapters.ndf2trep.config;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import com.anz.axle.adapters.ndf2trep.enrichment.margin.MarginService;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.IdleStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.aeron.driver.ThreadingMode;
import net.openhft.chronicle.wire.WireType;

import com.anz.axle.adapters.ndf2trep.publisher.HealthCheckService;
import com.anz.axle.adapters.ndf2trep.publisher.PricingSubscriber;
import com.anz.axle.adapters.ndf2trep.publisher.RicRepository;
import com.anz.axle.adapters.ndf2trep.publisher.Scheduler;
import com.anz.axle.adapters.ndf2trep.publisher.SnapshotterHealthCheck;
import com.anz.axle.adapters.ndf2trep.publisher.TransportPollerScheduler;
import com.anz.axle.adapters.ndf2trep.publisher.TrepTopOfBookSnapshotFullRefreshHandler;
import com.anz.axle.adapters.ndf2trep.snapshot.DefaultSnapshotterDecoderLookup;
import com.anz.axle.adapters.ndf2trep.snapshot.SnapshotterDecoderLookup;
import com.anz.axle.adapters.ndf2trep.snapshot.SnapshotterDecoderSupplier;
import com.anz.axle.adapters.ndf2trep.snapshot.UpstreamIncrementalRefreshHandlerRouter;
import com.anz.axle.adapters.ndf2trep.snapshot.UpstreamSnapshotFullRefreshHandlerRouter;
import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.trep.publisher.TrepStreamableQueue;
import com.anz.markets.efx.messaging.transport.aeron.AeronConfig;
import com.anz.markets.efx.messaging.transport.aeron.AeronEndPointConfig;
import com.anz.markets.efx.messaging.transport.aeron.AeronTransport;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.chronicle.ChronicleConfig;
import com.anz.markets.efx.messaging.transport.chronicle.ChronicleTransport;
import com.anz.markets.efx.messaging.transport.resilience.ResilientTransport;
import com.anz.markets.efx.messaging.transport.um.OperationalModeValue;
import com.anz.markets.efx.messaging.transport.um.TransportValue;
import com.anz.markets.efx.messaging.transport.um.UmConfig;
import com.anz.markets.efx.messaging.transport.um.UmEndPointConfig;
import com.anz.markets.efx.messaging.transport.um.UmTransport;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshHandler;
import com.anz.markets.efx.pricing.codec.api.LastMarketTradeHandler;
import com.anz.markets.efx.pricing.codec.api.MarketDataRequestHandler;
import com.anz.markets.efx.pricing.codec.api.PricingHandlerSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.connect.UpdateTypeMismatchHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.IdGenerator;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKeyLookup;

@Configuration
public class SubscriberConfig {

    @Bean
    public PricingSubscriber pricingSubscriber(
            final Connection connection,
            final PricingHandlerSupplier pricingHandlerSupplier,
            final RicRepository ricRepository) {

        return new PricingSubscriber(connection, pricingHandlerSupplier, ricRepository);
    }

    @Bean
    public RequestKeyLookup requestKeyLookup() {
        return new DefaultRequestKeyLookup();
    }

    @Bean
    public PricingHandlerSupplier pricingHandlerSupplier(final SnapshotterDecoderLookup snapshotterDecoderLookup, final RequestKeyLookup requestKeyLookup) {

        return new PricingHandlerSupplier() {
            @Override
            public SnapshotFullRefreshHandler snapshotFullRefresh() {
                return new UpstreamSnapshotFullRefreshHandlerRouter(snapshotterDecoderLookup, requestKeyLookup);
            }

            @Override
            public IncrementalRefreshHandler incrementalRefresh() {
                return new UpstreamIncrementalRefreshHandlerRouter(snapshotterDecoderLookup, requestKeyLookup);
            }

            @Override
            public MarketDataRequestHandler marketDataRequest() {
                throw new UnsupportedOperationException("marketDataRequest is not supported on this wire");
            }

            @Override
            public LastMarketTradeHandler lastMarketTrade() {
                throw new UnsupportedOperationException("lastMarketTrade is not supported on this wire");
            }
        };
    }

    @Bean
    public SnapshotterDecoderLookup snapshotterDecoderLookup(@Value("${ndf.trep.publish.destination.servicename}") final String componentId,
                                                             @Value("${stale.price.timestamp.offset.milliseconds}") final long stalePriceTimestampOffsetMilliseconds,
                                                             @Value("${initial.book.entries:100}") final int initialBookEntries,
                                                             final PrecisionClock precisionClock,
                                                             final SnapshotFullRefreshHandler forwardTopOfBookSnapshotFullRefreshHandler) {
        final LongSupplier messageIdSupplier = new IdGenerator();
        return new DefaultSnapshotterDecoderLookup(
                SnapshotterDecoderSupplier.create(
                        precisionClock,
                        messageIdSupplier,
                        SnapshotterDecoderSupplier.createBuilder(initialBookEntries, forwardTopOfBookSnapshotFullRefreshHandler, precisionClock, stalePriceTimestampOffsetMilliseconds),
                        UpdateTypeMismatchHandler.WARN,
                        componentId)
        );
    }

    @Bean(name = "forwardTopOfBookSnapshotFullRefreshHandler")
    public SnapshotFullRefreshHandler forwardTopOfBookSnapshotFullRefreshHandler(final TrepStreamableQueue trepStreamableQueue,
                                                                                 final RicRepository ricRepository,
                                                                                 final MarginService marginService) {
        return new TrepTopOfBookSnapshotFullRefreshHandler(trepStreamableQueue, ricRepository, marginService);
    }

    @Bean
    public IntSupplier requestIdSupplier() {
        return new IntSupplier() {
            final AtomicInteger idSeed = new AtomicInteger(0);
            @Override
            public int getAsInt() {
                return idSeed.getAndIncrement();
            }
        };
    }

    @Bean
    public Runnable healthCheckJob(@Value("${missing.heartbeat.interval.milliseconds}") final long missingHeartbeatIntervalMilliseconds,
                                                        final SnapshotterDecoderLookup snapshotterDecoderLookup,
                                                        final PrecisionClock precisionClock) {
        return new SnapshotterHealthCheck(missingHeartbeatIntervalMilliseconds, snapshotterDecoderLookup, precisionClock);
    }

    @Bean
    public Scheduler transportPollerScheduler(final Connection connection) {
        return new TransportPollerScheduler(connection);
    }

    @Bean
    public HealthCheckService healthCheckService(final Runnable healthCheckJob,
                                                 final ScheduledExecutorService scheduledExecutorService,
                                                 final Scheduler scheduler,
                                                 @Value("${check.heartbeat.delay.milliseconds}") final long delay) {
        return new HealthCheckService(healthCheckJob, scheduledExecutorService, scheduler, delay);
    }

    @Bean
    public PrecisionClock precisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public UmConfig umConfig(final @Value("${messaging.um.transport}") TransportValue transport,
                             final @Value("${messaging.um.operational_mode}") OperationalModeValue operationalMode,
                             final @Value("${messaging.um.resolver_unicast_daemons:}#{T(java.util.Collections).emptySet()}") Set<String> resolverUnicastDaemons,
                             final @Value("${messaging.um.default.context.attribute:}") String defaultContextAttributes,
                             final @Value("${messaging.um.default.source.attribute:}") String defaultSourceAttributes,
                             final @Value("${messaging.um.default.receiver.attribute:}") String defaultReceiverAttributes,
                             final Supplier<IdleStrategy> backoffIdleStrategy){

        final Map<String, Object> contextAttributes = convertAttributesToMap(defaultContextAttributes);
        final Map<String, Object> sourceAttributes = convertAttributesToMap(defaultSourceAttributes);
        final Map<String, Object> receiverAttributes = convertAttributesToMap(defaultReceiverAttributes);


        return new UmConfig() {
            @Override
            public UmEndPointConfig getEndPointConfig() {
                return UmEndPointConfig.forSingleTransport(transport);
            }

            @Override
            public OperationalModeValue getOperationalMode() {
                return operationalMode;
            }

            @Override
            public long getProcessEventsMillis() {
                return 0;
            }

            @Override
            public String toString() {
                return toString(new StringBuilder()).toString();
            }

            @Override
            public Map<String, ?> getDefaultContextAttributes() {
                return contextAttributes;
            }

            @Override
            public Map<String, ?> getDefaultSourceAttributes() {
                return sourceAttributes;
            }

            @Override
            public Map<String, ?> getDefaultReceiverAttributes() {
                return receiverAttributes;
            }

            @Override
            public Set<String> getResolverUnicastDaemons() {
                return resolverUnicastDaemons;
            }

            @Override
            public Supplier<IdleStrategy> getIdleStrategyFactory() {
                return backoffIdleStrategy;
            }
        };
    }

    @Bean
    public Supplier<IdleStrategy> backoffIdleStrategy(final @Value("${messaging.um.idle.strategy.backoff.maxSpins}") long maxSpins,
                                                      final @Value("${messaging.um.idle.strategy.backoff.maxYields}") long maxYields,
                                                      final @Value("${messaging.um.idle.strategy.backoff.minParkPeriodNs}") long minParkPeriodNs,
                                                      final @Value("${messaging.um.idle.strategy.backoff.maxParkPeriodNs}") long maxParkPeriodNs) {

        return () -> new BackoffIdleStrategy(maxSpins, maxYields, minParkPeriodNs, maxParkPeriodNs);
    }

    private Map<String, Object> convertAttributesToMap(final String configAttribute) {

        if (configAttribute.isEmpty()) {
            return java.util.Collections.emptyMap();
        }

        final ImmutableMap.Builder<String, Object> attributeMapBuilder = new ImmutableMap.Builder<>();
        Splitter.on( "," ).withKeyValueSeparator( ':' ).split( configAttribute ).forEach((key, value) -> attributeMapBuilder.put(key.trim().replaceAll("^\'|\'$", ""), value.trim().replaceAll("^\'|\'$", "")));
        return attributeMapBuilder.build();
    }

    @Bean
    public AeronConfig aeronConfig(final @Value("${messaging.aeron.directory}") String aeronDirectory,
                                   final @Value("${messaging.aeron.channel}") String aeronChannel,
                                   final @Value("${messaging.aeron.mediadriver.embedded}") boolean embeddedMediaDriver,
                                   final @Value("${messaging.aeron.mediadriver.dirsDeleteOnStart}") boolean mediaDriverDirsDeleteOnStart,
                                   final @Value("${messaging.aeron.mediadriver.threadingMode}") ThreadingMode threadingMode) {
        return new AeronConfig() {
            @Override
            public boolean getMediaDriverEmbedded() {
                return embeddedMediaDriver;
            }

            @Override
            public boolean getMediaDriverDirsDeleteOnStart() {
                return mediaDriverDirsDeleteOnStart;
            }

            @Override
            public ThreadingMode getThreadingMode() {
                return threadingMode;
            }

            @Override
            public boolean getAllowSubscriptions() {
                return true;
            }

            @Override
            public AeronEndPointConfig getEndPointConfig() {
                return AeronEndPointConfig.forSingleChannel(aeronChannel);
            }

            @Override
            public String getAeronDirectory() {
                return aeronDirectory;
            }

            @Override
            public String toString() {
                return toString(new StringBuilder()).toString();
            }
        };
    }

    @Bean
    public ChronicleConfig chronicleConfig(final @Value("${messaging.chronicle.directory}") String chronicleDirectory,
                                           final @Value("${messaging.chronicle.wireType}") WireType chronicleWireType,
                                           final @Value("${messaging.chronicle.blockSize}") int blockSize,
                                           final @Value("${messaging.chronicle.bufferCapacity}") int bufferCapacity) {
        return new ChronicleConfig() {
            @Override
            public String getChronicleDirectory() {
                return chronicleDirectory;
            }

            @Override
            public WireType getWireType() {
                return chronicleWireType;
            }

            @Override
            public int getBlockSize() {
                return blockSize;
            }

            @Override
            public int getBufferCapacity() {
                return bufferCapacity;
            }

            @Override
            public boolean getAllowSubscriptions() {
                return true;
            }

            @Override
            public String toString() {
                return toString(new StringBuilder()).toString();
            }
        };
    }

    @Bean (name="transport")
    public Transport transport(final PrecisionClock precisionClock,
                               final UmConfig umConfig,
                               final AeronConfig aeronConfig,
                               final ChronicleConfig chronicleConfig,
                               final @Value("${messaging.provider}") MessagingProvider messagingProvider,
                               final ScheduledExecutorService executorService,
                               final @Value("${messaging.seconds_to_retry_endpoint}")  long secondsToRetryEndpoint) {
        final Transport transport;
        switch (messagingProvider) {
            case UM:
                transport = new UmTransport(precisionClock, umConfig);
                break;
            case AERON:
                transport = new AeronTransport(precisionClock, aeronConfig, executorService);
                break;
            case CHRONICLE:
                transport =  new ChronicleTransport(precisionClock, chronicleConfig);
                break;
            default:
                throw new IllegalArgumentException("Messaging provider not supported: " + messagingProvider);
        }
        return new ResilientTransport(transport, executorService, secondsToRetryEndpoint);
    }

    @Bean(destroyMethod = "close")
    @DependsOn("transport")
    public Connection connection(final Transport transport) {
        return transport.openConnection(() -> {});
    }

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("async-%d").build());
    }

    @Bean
    public MarginService marginService(@Value("#{${symbol.serviceName.margins.FXSPOT}}") final Map<String, Map<String, List<String>>> marginMap,
                                       @Value("#{${symbol.pips}}") final Map<String, Long> symbolPipsMap,
                                       final RicRepository ricRepository) {
        return new MarginService(marginMap, symbolPipsMap, ricRepository);
    }
}
