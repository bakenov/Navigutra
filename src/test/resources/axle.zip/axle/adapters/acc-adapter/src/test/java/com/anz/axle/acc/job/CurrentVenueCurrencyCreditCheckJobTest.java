package com.anz.axle.acc.job;

import com.anz.axle.acc.AbstractUnitTest;
import com.anz.axle.acc.service.CreditUtilisationConsumerService;
import com.anz.axle.acc.service.CreditUtilisationProducerService;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.jmock.Expectations;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class CurrentVenueCurrencyCreditCheckJobTest extends AbstractUnitTest {
    private CurrentVenueCurrencyCreditCheckJob job = null;
    private CreditUtilisationProducerService creditUtilisationService = null;
    private CreditUtilisationConsumerService communicationService = null;
    private CurrentVenueCurrencyCreditCheckJobListener listener = null;
    private SchedulerFactoryBean schedulerFactory = null;
    private Scheduler scheduler = null;
    private CronTriggerImpl cronTrigger = null;
    private TriggerKey key = TriggerKey.triggerKey("currentVenueCurrencyCreditCheckJobTrigger", Scheduler.DEFAULT_GROUP);;

    @Before
    public void beforeEachTest() {
        creditUtilisationService = mock(CreditUtilisationProducerService.class);
        communicationService = mock(CreditUtilisationConsumerService.class);
        listener = mock(CurrentVenueCurrencyCreditCheckJobListener.class);
        schedulerFactory = mock(SchedulerFactoryBean.class);
        scheduler = mock(Scheduler.class);
        cronTrigger = mock(CronTriggerImpl.class);

        job = new CurrentVenueCurrencyCreditCheckJob();
        job.setCreditUtilisationProducerService(creditUtilisationService);
        job.setCreditUtilisationConsumerService(communicationService);
        job.setListener(listener);
        job.setSchedulerFactory(schedulerFactory);
    }

    @Test
    public void test_job_sends_credit_states_to_communication_service_and_listener() throws SchedulerException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates(null);
        checking(new Expectations() {
            {
                oneOf(creditUtilisationService).findCurrentVenueCurrencyCreditStatesSince(with(any(LocalDate.class)));
                will(returnValue(states));

                oneOf(listener).listen(with(states));

                oneOf(communicationService).consume(with(states));
                will(returnValue(true));

                oneOf(schedulerFactory).getScheduler();
                will(returnValue(scheduler));
                oneOf(scheduler).getTrigger(key);
                will(returnValue(cronTrigger));

                one(cronTrigger).getDescription();
                will(returnValue("recovery"));
                one(cronTrigger).setDescription("ok");
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).rescheduleJob(key, cronTrigger);
            }
        });
        job.run();
    }

    @Test
    public void test_that_listener_does_not_get_states_after_unsuccessful_send_and_trigger_is_paused() throws SchedulerException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates(null);
        checking(new Expectations() {
            {
                oneOf(creditUtilisationService).findCurrentVenueCurrencyCreditStatesSince(with(any(LocalDate.class)));
                will(returnValue(states));
                oneOf(communicationService).consume(with(states));
                will(returnValue(false));
                oneOf(schedulerFactory).getScheduler();
                will(returnValue(scheduler));
                oneOf(scheduler).getTrigger(key);
                will(returnValue(cronTrigger));

                one(cronTrigger).setDescription("recovery");
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).rescheduleJob(key, cronTrigger);
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).pauseTrigger(key);
                never(listener).listen(with(states));
            }
        });
        job.run();
        assertThat(mockLogAppender.contains("Sleeping trigger currentVenueCurrencyCreditCheckJobTrigger for recovery management."), is(true));
    }

    @Test
    public void test_that_listener_does_not_get_states_after_send_exception() throws SchedulerException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates(null);
        checking(new Expectations() {
            {
                oneOf(creditUtilisationService).findCurrentVenueCurrencyCreditStatesSince(with(any(LocalDate.class)));
                will(returnValue(states));
                oneOf(communicationService).consume(with(states));
                will(throwException(new RuntimeException("foo")));
                oneOf(schedulerFactory).getScheduler();
                will(returnValue(scheduler));
                oneOf(scheduler).getTrigger(key);
                will(returnValue(cronTrigger));

                one(cronTrigger).setDescription("recovery");
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).rescheduleJob(key, cronTrigger);
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).pauseTrigger(key);
                never(listener).listen(with(states));
            }
        });
        job.run();
        assertThat(mockLogAppender.contains("There was an issue sending data to the consumer service."), is(true));
    }


    @Test
    public void test_that_listener_and_service_do_not_get_states_after_find_exception() throws SchedulerException {
        final CurrentVenueCurrencyCreditStates states = new CurrentVenueCurrencyCreditStates(null);
        checking(new Expectations() {
            {
                oneOf(creditUtilisationService).findCurrentVenueCurrencyCreditStatesSince(with(any(LocalDate.class)));
                will(throwException(new RuntimeException("foo")));
                oneOf(schedulerFactory).getScheduler();
                will(returnValue(scheduler));
                oneOf(scheduler).getTrigger(key);
                will(returnValue(cronTrigger));

                one(cronTrigger).setDescription("recovery");
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).rescheduleJob(key, cronTrigger);
                oneOf(cronTrigger).getKey();
                will(returnValue(key));
                one(scheduler).pauseTrigger(key);
                never(communicationService).consume(with(states));
                never(listener).listen(with(states));
            }
        });
        job.run();
        assertThat(mockLogAppender.contains("There was an issue sending data to the consumer service."), is(true));
    }
}
