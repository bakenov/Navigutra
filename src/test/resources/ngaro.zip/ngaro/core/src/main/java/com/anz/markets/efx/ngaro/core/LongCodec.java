package com.anz.markets.efx.ngaro.core;

import java.util.Objects;

public class LongCodec {
    public static final String LONG_MIN_VALUE_STRING = "-9223372036854775808";

    /**
     * All possible chars for representing a number as a String
     */
    final static char[] digits = {
            '0' , '1' , '2' , '3' , '4' , '5' ,
            '6' , '7' , '8' , '9' , 'a' , 'b' ,
            'c' , 'd' , 'e' , 'f' , 'g' , 'h' ,
            'i' , 'j' , 'k' , 'l' , 'm' , 'n' ,
            'o' , 'p' , 'q' , 'r' , 's' , 't' ,
            'u' , 'v' , 'w' , 'x' , 'y' , 'z'
    };

    final static char [] DigitTens = {
            '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
            '1', '1', '1', '1', '1', '1', '1', '1', '1', '1',
            '2', '2', '2', '2', '2', '2', '2', '2', '2', '2',
            '3', '3', '3', '3', '3', '3', '3', '3', '3', '3',
            '4', '4', '4', '4', '4', '4', '4', '4', '4', '4',
            '5', '5', '5', '5', '5', '5', '5', '5', '5', '5',
            '6', '6', '6', '6', '6', '6', '6', '6', '6', '6',
            '7', '7', '7', '7', '7', '7', '7', '7', '7', '7',
            '8', '8', '8', '8', '8', '8', '8', '8', '8', '8',
            '9', '9', '9', '9', '9', '9', '9', '9', '9', '9',
    } ;

    final static char [] DigitOnes = {
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    } ;


    /**
     * Copied from Long.getChars:
     * Places characters representing the integer value into the
     * ByteWriter. The characters are placed into
     * the writer backwards starting with the least significant
     * digit at the specified index (exclusive), and working
     * backwards from there.
     *
     * Will fail if value == Long.MIN_VALUE
     */
    private static <T> void encodeSigned(long value, final T target, final ByteWriter<? super T> writer, final int index) {
        long q;
        int r;
        int charPos = index;
        char sign = 0;

        if (value < 0) {
            sign = '-';
            value = -value;
        }

        // Get 2 digits/iteration using longs until quotient fits into an int
        while (value > Integer.MAX_VALUE) {
            q = value / 100;
            // really: r = value - (q * 100);
            r = (int)(value - ((q << 6) + (q << 5) + (q << 2)));
            value = q;
            writer.writeByte(target, --charPos, (byte) DigitOnes[r]);
            writer.writeByte(target, --charPos, (byte) DigitTens[r]);
        }

        // Get 2 digits/iteration using ints
        int q2;
        int i2 = (int)value;
        while (i2 >= 65536) {
            q2 = i2 / 100;
            // really: r = i2 - (q * 100);
            r = i2 - ((q2 << 6) + (q2 << 5) + (q2 << 2));
            i2 = q2;
            writer.writeByte(target, --charPos, (byte) DigitOnes[r]);
            writer.writeByte(target, --charPos, (byte) DigitTens[r]);
        }

        // Fall thru to fast mode for smaller numbers
        // assert(i2 <= 65536, i2);
        for (;;) {
            q2 = (i2 * 52429) >>> (16+3);
            r = i2 - ((q2 << 3) + (q2 << 1));  // r = i2-(q2*10) ...
            writer.writeByte(target, --charPos, (byte) digits[r]);
            i2 = q2;
            if (i2 == 0) break;
        }
        if (sign != 0) {
            writer.writeByte(target, --charPos, (byte) sign);
        }
    }

    // Requires positive value
    private static int stringSize(final long value) {
        long p = 10;
        for (int i=1; i<19; i++) {
            if (value < p)
                return i;
            p = 10*p;
        }
        return 19;
    }

    private static <T> void encodeMinLong(final T target, final ByteWriter<? super T> writer) {
        for (int i = 0; i < LONG_MIN_VALUE_STRING.length(); i++) {
            writer.writeByte(target, i, (byte) LONG_MIN_VALUE_STRING.charAt(i));
        }
    }

    /**
     * Writes {@code long} represented as string to ByteWriter.  The argument is converted to signed decimal
     * representation and returned as a string, exactly as if the
     * argument and the radix 10 were given as arguments to the {@link
     * #Long.toString(long, int)} method.
     *
     * @param   value   a {@code long} to be converted.
     * @param   target target
     * @param   writer writer
     */
    public static <T> int encodeSigned(final long value, final T target, final ByteWriter<? super T> writer) {
        if (value == Long.MIN_VALUE) {
            encodeMinLong(target, writer);
            return LONG_MIN_VALUE_STRING.length();
        }
        int size = (value < 0) ? stringSize(-value) + 1 : stringSize(value);
        encodeSigned(value, target, writer, size);
        return size;
    }


    /**
     * Encode unsigned long to hex.
     * @param value
     * @param target
     * @param writer
     * @param <T>
     */
    public static <T> void encodeUnsignedHex(final long value, final T target, final ByteWriter<? super T> writer) {
        encodeUnsigned(value, 4, target, writer);
    }

    /**
     * Format a long (treated as unsigned) into a String.
     * @param value the value to format
     * @param shift the log2 of the base to format in (4 for hex, 3 for octal, 1 for binary)
     */
    private static <T> void encodeUnsigned(final long value, final int shift, final T target, final ByteWriter<? super T> writer) {
        // assert shift > 0 && shift <=5 : "Illegal shift value";
        int mag = Long.SIZE - Long.numberOfLeadingZeros(value);
        int chars = Math.max(((mag + (shift - 1)) / shift), 1);
        encodeUnsigned(value, shift, target, writer, chars);
    }

    /**
     * Format a long (treated as unsigned) into a character buffer.
     * @param value the unsigned long to format
     * @param shift the log2 of the base to format in (4 for hex, 3 for octal, 1 for binary)
     * @param target target to write to
     * @param writer writer to write with
     * @param len the number of characters to write
     * @return the lowest character location used
     */
    private static <T> int encodeUnsigned(long value, final int shift, final T target, final ByteWriter<? super T> writer, final int len) {
        int charPos = len;
        int radix = 1 << shift;
        int mask = radix - 1;
        do {
            writer.writeByte(target, --charPos, (byte) digits[((int) value) & mask]);
            value >>>= shift;
        } while (value != 0 && charPos > 0);

        return charPos;
    }

    public static void encodeSigned(final long value, final MutableAsciiString asciiString) {
        asciiString.clear();
        encodeSigned(value, asciiString, ByteWriter.MUTABLE_ASCII_STRING);
    }

    public static void encodeUnsignedHex(final long value, final MutableAsciiString asciiString) {
        asciiString.clear();
        encodeUnsignedHex(value, asciiString, ByteWriter.MUTABLE_ASCII_STRING);
    }

    /**
     * Parses the string argument as a signed {@code long} in the
     * radix specified by the second argument. The characters in the
     * string must all be digits of the specified radix (as determined
     * by whether {@link Character#digit(char, int)} returns
     * a nonnegative value), except that the first character may be an
     * ASCII minus sign {@code '-'} ({@code '\u005Cu002D'}) to
     * indicate a negative value or an ASCII plus sign {@code '+'}
     * ({@code '\u005Cu002B'}) to indicate a positive value. The
     * resulting {@code long} value is returned.
     *
     * <p>Note that neither the character {@code L}
     * ({@code '\u005Cu004C'}) nor {@code l}
     * ({@code '\u005Cu006C'}) is permitted to appear at the end
     * of the string as a type indicator, as would be permitted in
     * Java programming language source code - except that either
     * {@code L} or {@code l} may appear as a digit for a
     * radix greater than or equal to 22.
     *
     * <p>An exception of type {@code NumberFormatException} is
     * thrown if any of the following situations occurs:
     * <ul>
     *
     * <li>The first argument is {@code null} or is a string of
     * length zero.
     *
     * <li>The {@code radix} is either smaller than {@link
     * Character#MIN_RADIX} or larger than {@link
     * Character#MAX_RADIX}.
     *
     * <li>Any character of the string is not a digit of the specified
     * radix, except that the first character may be a minus sign
     * {@code '-'} ({@code '\u005Cu002d'}) or plus sign {@code
     * '+'} ({@code '\u005Cu002B'}) provided that the string is
     * longer than length 1.
     *
     * <li>The value represented by the string is not a value of type
     *      {@code long}.
     * </ul>
     *
     * <p>Examples:
     * <blockquote><pre>
     * parseLong("0", 10) returns 0L
     * parseLong("473", 10) returns 473L
     * parseLong("+42", 10) returns 42L
     * parseLong("-0", 10) returns 0L
     * parseLong("-FF", 16) returns -255L
     * parseLong("1100110", 2) returns 102L
     * parseLong("99", 8) throws a NumberFormatException
     * parseLong("Hazelnut", 10) throws a NumberFormatException
     * parseLong("Hazelnut", 36) returns 1356099454469L
     * </pre></blockquote>
     *
     * @param      source       the {@code S} containing the
     *                     {@code long} representation to be parsed.
     * @param      reader
     * @param      radix   the radix to be used while parsing {@code s}.
     * @return     the {@code long} represented by the string argument in
     *             the specified radix.
     * @throws     NumberFormatException  if the string does not contain a
     *             parsable {@code long}.
     */
    public static <S> long decodeSigned(final S source, final ByteReader<? super S> reader, final int length, final int radix)
            throws NumberFormatException
    {
        Objects.requireNonNull(source, "source is required");
        Objects.requireNonNull(reader, "reader is required");

        if (radix < Character.MIN_RADIX) {
            throw new NumberFormatException("radix " + radix +
                    " less than Character.MIN_RADIX");
        }
        if (radix > Character.MAX_RADIX) {
            throw new NumberFormatException("radix " + radix +
                    " greater than Character.MAX_RADIX");
        }

        long result = 0;
        boolean negative = false;
        int i = 0;
        long limit = -Long.MAX_VALUE;
        long multmin;
        int digit;

        if (length > 0) {
            char firstChar = (char) reader.readByte(source, 0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Long.MIN_VALUE;
                } else if (firstChar != '+')
                    throw numberFormatException(source);

                if (length == 1) // Cannot have lone "+" or "-"
                    throw numberFormatException(source);
                i++;
            }
            multmin = limit / radix;
            while (i < length) {
                // Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(reader.readByte(source, i++),radix);
                if (digit < 0) {
                    throw numberFormatException(source);
                }
                if (result < multmin) {
                    throw numberFormatException(source);
                }
                result *= radix;
                if (result < limit + digit) {
                    throw numberFormatException(source);
                }
                result -= digit;
            }
        } else {
            throw numberFormatException(source);
        }
        return negative ? result : -result;
    }

    /**
     * Parses the string argument as an unsigned {@code long} in the
     * radix specified by the second argument.  An unsigned integer
     * maps the values usually associated with negative numbers to
     * positive numbers larger than {@code MAX_VALUE}.
     *
     * The characters in the string must all be digits of the
     * specified radix (as determined by whether {@link
     * java.lang.Character#digit(char, int)} returns a nonnegative
     * value), except that the first character may be an ASCII plus
     * sign {@code '+'} ({@code '\u005Cu002B'}). The resulting
     * integer value is returned.
     *
     * <p>An exception of type {@code NumberFormatException} is
     * thrown if any of the following situations occurs:
     * <ul>
     * <li>The first argument is {@code null} or is a string of
     * length zero.
     *
     * <li>The radix is either smaller than
     * {@link java.lang.Character#MIN_RADIX} or
     * larger than {@link java.lang.Character#MAX_RADIX}.
     *
     * <li>Any character of the string is not a digit of the specified
     * radix, except that the first character may be a plus sign
     * {@code '+'} ({@code '\u005Cu002B'}) provided that the
     * string is longer than length 1.
     *
     * <li>The value represented by the string is larger than the
     * largest unsigned {@code long}, 2<sup>64</sup>-1.
     *
     * </ul>
     *
     *
     * @param      s   the {@code String} containing the unsigned integer
     *                  representation to be parsed
     * @param      radix   the radix to be used while parsing {@code s}.
     * @return     the unsigned {@code long} represented by the string
     *             argument in the specified radix.
     * @throws     NumberFormatException if the {@code String}
     *             does not contain a parsable {@code long}.
     * @since 1.8
     */
    public static <S> long decodeUnsigned(final S source, final ByteReader<? super S> reader, final int length, int radix)
            throws NumberFormatException {
        Objects.requireNonNull(source, "source is required");
        Objects.requireNonNull(reader, "reader is required");

        if (length > 0) {
            char firstChar = (char) reader.readByte(source, 0);
            if (firstChar == '-') {
                throw new
                        NumberFormatException("Illegal leading minus sign on unsigned string in source " + source);
            } else {
                if (length <= 12 || // Long.MAX_VALUE in Character.MAX_RADIX is 13 digits
                        (radix == 10 && length <= 18) ) { // Long.MAX_VALUE in base 10 is 19 digits
                    return decodeSigned(source, reader, length, radix);
                }

                // No need for range checks on len due to testing above.
                long first = decodeSigned(source, reader, length - 1, radix);
                int second = Character.digit(reader.readByte(source, length - 1), radix);
                if (second < 0) {
                    throw new NumberFormatException("Bad digit in source " + source);
                }
                long result = first * radix + second;
                if (Long.compareUnsigned(result, first) < 0) {
                    /*
                     * The maximum unsigned value, (2^64)-1, takes at
                     * most one more digit to represent than the
                     * maximum signed value, (2^63)-1.  Therefore,
                     * parsing (len - 1) digits will be appropriately
                     * in-range of the signed parsing.  In other
                     * words, if parsing (len -1) digits overflows
                     * signed parsing, parsing len digits will
                     * certainly overflow unsigned parsing.
                     *
                     * The compareUnsigned check above catches
                     * situations where an unsigned overflow occurs
                     * incorporating the contribution of the final
                     * digit.
                     */
                    throw new NumberFormatException("String value " +  source + " exceeds range of unsigned long.");
                }
                return result;
            }
        } else {
            throw numberFormatException(source);
        }
    }





    public static long decodeSigned(final AsciiString source) {
        return decodeSigned(source, ByteReader.ASCII_STRING, source.length(), 10);
    }

    public static long decodeUnsignedHex(final AsciiString source) {
        return decodeUnsigned(source, ByteReader.ASCII_STRING, source.length(), 16);
    }

    /**
     * Factory method for making a <code>NumberFormatException</code>
     * given the specified input which caused the error.
     *
     * @param   object   the input causing the error
     */
    static NumberFormatException numberFormatException(Object object) {
        return new NumberFormatException("For input string: \"" + object + "\"");
    }
}
