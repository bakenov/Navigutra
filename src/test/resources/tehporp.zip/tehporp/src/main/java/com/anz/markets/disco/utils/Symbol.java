package com.anz.markets.disco.utils;

import net.openhft.chronicle.core.pool.StringInterner;

import java.util.HashMap;

public class Symbol {

    public static final Symbol EMPTY;

    private final int index;
    private final String symbol;

    private static int nextIndex;
    private static final HashMap<String, Symbol> m = new HashMap<>();

    private static final StringInterner interner = new StringInterner(4096);

    public static synchronized Symbol get(CharSequence s) {
        return m.computeIfAbsent(interner.intern(s), s1 -> new Symbol(nextIndex++, s1));
    }

    private Symbol(int index, String symbol) {
        this.index = index;
        this.symbol = symbol;
    }

    public int getIndex() {
        return index;
    }

    @Override
    public boolean equals(final Object o) {
        return this == o;
    }

    @Override
    public int hashCode() {
        return index;
    }

    public String toString() {
        return symbol;
    }

    public String getValue() {
        return symbol;
    }

    static {
        EMPTY = Symbol.get("");
    }
}
