package com.anz.axle.adapters.rmds.consumer;

import java.util.List;

public interface ItemProvider {
    List<String> getItems();
}
