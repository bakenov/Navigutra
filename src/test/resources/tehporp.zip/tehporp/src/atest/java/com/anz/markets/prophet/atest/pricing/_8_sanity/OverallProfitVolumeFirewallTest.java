package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.control.PricingFirewallResetImpl;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.matcher.PricingFirewallTypeMatcher;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import com.anz.markets.prophet.positionrisk.Position;
import com.anz.markets.prophet.positionrisk.Positions;
import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class OverallProfitVolumeFirewallTest extends BaseAcceptanceSpecification {

    /**
     * Every OneSecond chime the OverallProfitVolumeFirewall checks to whether the firewall has been triggered or
     * can be reset.
     */
    private void tickSecond() {
        sleepSeconds(1);
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall triggered when change in loss is over limit")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void shouldTriggerWhenChangeInLossOverPnlLimit() {
        // 0 trade:     PnL NaN
        // 1st trade:   PnL -10_000
        // 2nd trade:   PnL -20_000
        // 3rd trade:   PnL -20_010
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(Instrument.AUDEUR, LocalDate.now().plusDays(2)));

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 10_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 20_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.10000, 0.00040));

            // AXPROPHET-927 Should have no impact on existing scenario (put here after we have prices)
            prophet.receive(tdd.biasPosition(Currency.AUD, -2_000_000));
            prophet.receive(tdd.biasPosition(Currency.EUR, -2_000_000));

            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.74000));

            // Trigger 2nd position updates for USD and JPY
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, -1_000_000, 1.09000));
        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.CLIENTS_NET));

            // get latest positions
            assertThat(positionsUpdates.get(0).countPositions(), CoreMatchers.is(2));
            assertThat(positionsUpdates.get(0).getPosition1().getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positionsUpdates.get(0).getPosition1().getPositionInSystemBase(), CoreMatchers.is(-750_000.0));
            assertThat(positionsUpdates.get(0).getPosition2().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInNotional(), CoreMatchers.is(740_000.0));
            assertThat(positionsUpdates.get(0).getPosition2().getPositionInSystemBase(), CoreMatchers.is(740_000.0));

            assertThat(positionsUpdates.get(1).countPositions(), CoreMatchers.is(2));
            assertThat(positionsUpdates.get(1).getPosition1().getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positionsUpdates.get(1).getPosition1().getPositionInSystemBase(), CoreMatchers.is((-1_100_000.0)));

            assertThat(positionsUpdates.get(1).getPosition2().getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInNotional(), CoreMatchers.is(740_000.0 + 1_090_000.0));
            assertThat(positionsUpdates.get(1).getPosition2().getPositionInSystemBase(), CoreMatchers.is(740_000.0 + 1_090_000.0));

            List<Positions> positionsBiasOffsets = prophet.expect(Positions.class, atLeast(2), isPortfolio(Portfolio.BIASED_CLIENTS_NET));
            OverallProfitVolumeFirewallTest.PositionsHelper positionsOffset = new OverallProfitVolumeFirewallTest.PositionsHelper(positionsBiasOffsets);
            assertThat(positionsOffset.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positionsOffset.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(-1_000_000.0 - (-2_000_000.0))); // CLIENT_NET - zero point (i.e. BIAS_OFFSET)

            assertThat(positionsOffset.getLatest(Currency.EUR).getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positionsOffset.getLatest(Currency.EUR).getPositionInNotional(), CoreMatchers.is(-1_000_000.0 - (-2_000_000.0)));

            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(2), isProfitAndLossPortfolio(Portfolio.CLIENTS_NET));
            // PnL -10_000 from first trade
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(-750_000.0 + 740_000.0));

            // PnL -20_000
            // Range between high(-10_000) and low(-20_000) pnl is 10k which equals limit of 10_000: Firewall NOT triggered
            assertThat(profitAndLoss.get(1).getValueSystemBaseCurrency(), CoreMatchers.is(-750_000.0 - 1_100_000.0 + 1_830_000.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        and:
        // do NOT expect firewall to be triggered
        {   // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();

            prophet.clearOutputBuffer();
        }

        when:
        // send third trade at loss such that PnL limit breached
        {
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.7499));

            // PnL -20_100
            // range between high(-10_000) and low pnl(-20_100) is 10_100 > 10_000 limit: Firewall triggered
            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(-20_000.0 - 750_000.0 + 749_900.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {
            // Verify client prices for ALL models and ALL pairs are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 5 instruments AUDUSD, EURUSD, USDJPY, AUDJPY (i.e diver and synthetic pairs)
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 4, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(cp, PricingFirewallType.OVERALL_PROFIT_VOLUME);
            });
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall triggered when change in profit is over limit")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void shouldTriggerWhenChangeInProfitOverPnlLimit() {
        // 0 trade:     PnL NaN
        // 1st trade:   PnL 20_000
        // 2nd trade:   PnL 10_000
        // 3rd trade:   PnL 9_990
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // set spot date cross
            prophet.receive(new SpotDateImpl(Instrument.AUDEUR, LocalDate.now().plusDays(2)));

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 10_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 20_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );

        }
        when:
        {   // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.74000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.10000, 0.00040));

            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.76000));
        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(1));
            PositionsHelper positions = new PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positions.getLatest(Currency.AUD).getPositionInSystemBase(), CoreMatchers.is(-740_000.0));

            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(760_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(760_000.0));

            // PnL equals 20_000: Firewall NOT triggered as this is the first sample(pnl started as NaN and this is NOT considered as 0)
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), CoreMatchers.is(-740_000.0 + 760_000.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
            prophet.clearOutputBuffer();
        }

        when:
        {   // Trigger 2nd position updates for EUR and USD
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, -1_000_000, 1.09000));
        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(1));
            PositionsHelper positions = new PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.EUR).getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positions.getLatest(Currency.EUR).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positions.getLatest(Currency.EUR).getPositionInSystemBase(), CoreMatchers.is((-1_100_000.0)));

            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(760_000.0 + 1_090_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(760_000.0 + 1_090_000.0));

            // PnL equals limit of 10_000
            // Range between high(20_000) and low(10_000) pnl is 10k which equals limit of 10_000: Firewall NOT triggered
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), CoreMatchers.is(20_000.0 - 1_100_000.0 + 1_090_000.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        and:
        // do NOT expect firewall to be triggered
        {   // trigger a client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();

            prophet.clearOutputBuffer();
        }

        when:
        // send third trade at loss such that PnL limit breached
        {
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.7401));

            // PnL 9_900
            // range between high(20_000) and low pnl(9_990) is 10_100 > 10_000 limit: Firewall triggered
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), CoreMatchers.is(10_000.0 + 740_000.0 - 740_100.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {
            // Verify client prices for ALL models and ALL pairs are INDICATIVE
            final List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class);
            // should be 3 markets (WSP_A/B/C) and 5 instruments AUDUSD, EURUSD, USDJPY, AUDJPY (i.e diver and synthetic pairs)
            final List<ClientPrice> lastClientPrices = lastClientPrices(clientPrices, 4, 4);
            lastClientPrices.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(cp, PricingFirewallType.OVERALL_PROFIT_VOLUME);
            });
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall triggered when change from loss to profit is over limit")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void shouldTriggerWhenChangeFromLossToProfitOverPnlLimit() {
        // 0 trade:     PnL NaN
        // 1st trade:   PnL -10_000
        // 2nd trade:   PnL 10_000
        // 3rd trade:   PnL 10_010
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    // disable Mid Skewing
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 20_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 20_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );

        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.10000, 0.00040));

            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.74000));
        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(1));
            PositionsHelper positions = new PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positions.getLatest(Currency.AUD).getPositionInSystemBase(), CoreMatchers.is(-750_000.0));
            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(740_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(740_000.0));

            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            // PnL -10_000 from first trade
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(-750_000.0 + 740_000.0));

            prophet.clearOutputBuffer();
        }

        when:
        // Trigger 2nd position update
        {
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, -1_000_000, 1.12000));

        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(1));
            PositionsHelper positions = new PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.EUR).getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positions.getLatest(Currency.EUR).getPositionInNotional(), CoreMatchers.is(-1_000_000.0));
            assertThat(positions.getLatest(Currency.EUR).getPositionInSystemBase(), CoreMatchers.is((-1_100_000.0)));
            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(740_000.0 + 1_120_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(740_000.0 + 1_120_000.0));

            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            // PnL 10_000
            // Range between high(10_000) and low(-10_000) pnl is 20k which equals limit of 20_000: Firewall NOT triggered
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(-10_000 - 1_100_000.0 + 1_120_000.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
            prophet.clearOutputBuffer();
        }

        and:
        // do NOT expect firewall to be triggered
        {   // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();

            prophet.clearOutputBuffer();
        }

        when:
        // send third trade at profit such that PnL limit breached
        {
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.7499));

            // PnL 10_100
            // range between high(10_100) and low pnl(-10_000) is 20_100 > 20_000 limit: Firewall triggered
            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(10_000.0 + 750_000.0 - 749_900.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {
            // Verify client AUD/USD prices for ALL models are INDICATIVE
            List<ClientPrice> pricesAUDUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < pricesAUDUSD.size(); i++) {
                assertThat(pricesAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(pricesAUDUSD.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall triggered when change from profit to loss is over limit")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void shouldTriggerWhenChangeFromProfitToLossOverPnlLimit() {
        // 0 trade:     PnL NaN
        // 1st trade:   PnL 10_000
        // 2nd trade:   PnL -10_000
        // 3rd trade:   PnL -10_010
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    // disable Mid Skewing
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 20_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 20_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );

        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.10000, 0.00040));

            // Trigger 1st position updates for AUD and USD
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_000_000, 0.74000));
        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(1));
            PositionsHelper positions = new PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.AUD).getCcy(), CoreMatchers.is(Currency.AUD));
            assertThat(positions.getLatest(Currency.AUD).getPositionInNotional(), CoreMatchers.is(1_000_000.0));
            assertThat(positions.getLatest(Currency.AUD).getPositionInSystemBase(), CoreMatchers.is(750_000.0));
            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(-740_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(-740_000.0));

            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            // PnL 10_000 from first trade
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(750_000.0 - 740_000.0));

            prophet.clearOutputBuffer();
        }

        when:
        // Trigger 2nd position update
        {
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, 1_000_000, 1.12000));

        }

        then:
        {
            List<Positions> positionsUpdates = prophet.expect(Positions.class, atLeast(1));
            PositionsHelper positions = new PositionsHelper(positionsUpdates);

            // get latest positions
            assertThat(positions.getLatest(Currency.EUR).getCcy(), CoreMatchers.is(Currency.EUR));
            assertThat(positions.getLatest(Currency.EUR).getPositionInNotional(), CoreMatchers.is(1_000_000.0));
            assertThat(positions.getLatest(Currency.EUR).getPositionInSystemBase(), CoreMatchers.is((1_100_000.0)));
            assertThat(positions.getLatest(Currency.USD).getCcy(), CoreMatchers.is(Currency.USD));
            assertThat(positions.getLatest(Currency.USD).getPositionInNotional(), CoreMatchers.is(-740_000.0 - 1_120_000.0));
            assertThat(positions.getLatest(Currency.USD).getPositionInSystemBase(), CoreMatchers.is(-740_000.0 - 1_120_000.0));

            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            // PnL -10_000
            // Range between high(10_000) and low(-10_000) pnl is 20k which equals limit of 20_000: Firewall NOT triggered
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(10_000 + 1_100_000.0 - 1_120_000.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
            prophet.clearOutputBuffer();
        }

        and:
        // do NOT expect firewall to be triggered
        {   // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();

            prophet.clearOutputBuffer();
        }

        when:
        // send third trade at profit such that PnL limit breached
        {
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.7499));

            // PnL -10_100
            // range between high(10_000) and low pnl(-10_010) is 20_010 > 20_000 limit: Firewall triggered
            List<ProfitAndLoss> profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1));
            assertThat(profitAndLoss.get(0).getValueSystemBaseCurrency(), CoreMatchers.is(-10_000.0 - 750_000.0 + 749_900.0));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {
            // Verify client AUD/USD prices for ALL models are INDICATIVE
            List<ClientPrice> pricesAUDUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < pricesAUDUSD.size(); i++) {
                assertThat(pricesAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(pricesAUDUSD.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall monitors PnL during sliding window period")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void shouldMonitorPnLDuringSlidingWindow() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 10_000.))
                    // For this test, PNL window set to 2 seconds
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 2))

                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 20_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );
        }

        when:
        {
            // trigger FIRST OverallProfitVolumeFirewall calc @ time t(0)
            tickSecond();

            // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.75000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.10000, 0.00040));

            // Trigger 1st position updates for AUD and USD @ time t
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.74000));

            // trigger FIRST OverallProfitVolumeFirewall calc @ t+1
            tickSecond();
        }

        then:
        {
            // PnL = -10_000: Firewall NOT triggered
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), CoreMatchers.is(-750_000.0 + 740_000.0));
            prophet.clearOutputBuffer();
        }

        when:
        {
            // Trigger 2nd position updates for USD and JPY
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, -1_000_000, 1.09000));

            // trigger SECOND OverallProfitVolumeFirewall calc @ t+2
            tickSecond();
        }

        then:
        {
            // PnL -20_000
            // Range between high(-10_000) and low(-20_000) pnl is 20k which equals limit of 20_000: Firewall NOT triggered
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), CoreMatchers.is(-750_000.0 - 1_100_000.0 + 1_830_000.0));
            prophet.clearOutputBuffer();
        }

        and:
        // do NOT expect firewall to be triggered
        {
            // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.7501, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.7500, 0.00040));
            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
            prophet.clearOutputBuffer();
        }

        when:
        {   // send third trade at loss such that PnL limit would be breached IF it were to be considered inside sliding window period
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -1_000_000, 0.7499));

            // PnL of -20_100
            // within the last TWO second window: Range between high(-20_000) and low(-20_010) pnl is only $10: Firewall NOT triggered
            ProfitAndLoss profitAndLoss = prophet.expect(ProfitAndLoss.class, atLeast(1)).getLast();
            assertThat(profitAndLoss.getValueSystemBaseCurrency(), CoreMatchers.is(-20_000.0 - 750_000.0 + 749_900.0));

            // trigger THIRD OverallProfitVolumeFirewall calc @ t+3
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // do NOT expect firewall to be triggered.
        {
            // trigger Client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.7499, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall only triggered when trade volume OVER limit")
    public void shouldTriggerWhenOverTradeVolumeLimit() {
        // Verify when firewall is triggered:
        // 1) for all ccy pairs (AUD/USD-driver, USD/JPY-driver, AUD/JPY-triangulated cross)
        // 2) for all pricing models
        // 3) for each depth in client book
        // the quote state is INDICATIVE
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 1_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 1_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 3))
            );
        }

        when:
        // send first trade such that volume is on the limit
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));

            // send BUY 1mio USD client deal to be ON volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // do NOT expect firewall to be triggered
        {
            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
            prophet.clearOutputBuffer();
        }

        when:
        // send second trade(different pair) such that volume limit breached
        {
            // send SELL 1_000 USD/CAD client deal to BREACH volume limit
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000, 88.500));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {   // Verify client prices for ALL models and ALL pairs are INDICATIVE
            List<ClientPrice> pricesAUDUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < pricesAUDUSD.size(); i++) {
                assertThat(pricesAUDUSD.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(pricesAUDUSD.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }

            List<ClientPrice> pricesUSDJPY = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.USDJPY));
            for (int i = 0; i < pricesUSDJPY.size(); i++) {
                assertThat(pricesUSDJPY.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(pricesUSDJPY.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }

            List<ClientPrice> pricesAUDJPY = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDJPY));
            for (int i = 0; i < pricesAUDJPY.size(); i++) {
                assertThat(pricesAUDJPY.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));

                checkFirewallTriggered(pricesAUDJPY.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }
        }

        when:
        {
            prophet.clearOutputBuffer();

            // ensure OverallProfitVolumeFirewall calc. Should still be indicative so no new client prices generated
            tickSecond();

            // trigger client prices
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80002, 0.00004));
        }

        then:
        // expect firewall to SILL be triggered as we are within time window
        {
            checkQuoteType(QuoteType.INDICATIVE);
            checkFirewallTriggered(PricingFirewallType.OVERALL_PROFIT_VOLUME);
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("Firewall monitors Volume during sliding window period")
    public void shouldMonitorVolumeDuringSlidingWindow() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 20_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 100))

                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 2_000_000.))
                    // For this test, Volume window set to 2 seconds
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 2))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );
        }

        when:
        {
            // trigger FIRST OverallProfitVolumeFirewall calc @ time t(0)
            tickSecond();

            // No position update as Notional position is 0
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00040));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.EURUSD, 1.25000, 0.00040));

            // Trigger 1st position updates for AUD and USD @ time t
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));

            // trigger FIRST OverallProfitVolumeFirewall calc @ t+1
            tickSecond();

            // Trigger 2nd position updates for EUR and USD
            prophet.receive(tdd.client_trade_001(Instrument.EURUSD, 800_000, 1.25000));

            // trigger SECOND OverallProfitVolumeFirewall calc @ t+2
            tickSecond();
        }

        then:
        // Do not expect firewall to be triggered. Volume equals limit of 2mio USD
        {
            // Trigger client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.79999, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
            prophet.clearOutputBuffer();
        }

        when:
        {   // send third trade such that Volume limit would be breached IF it was considered inside window period
            // However, within the last TWO second time window our Volume is 1imo USD so firewall is NOT breached
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, -900_000, 0.80000));

            // trigger THIRD OverallProfitVolumeFirewall calc @ t+3 i.e  within the last TWO seconds period our Volume is ~1.72 mio USD
            tickSecond();
        }

        then:
        // do NOT expect firewall to be triggered.
        {
            // trigger Client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00040));

            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("End of latching period - return to FIRM if not breached")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void atEndOfLatchingPeriodReturnToFIRM() {
        final int triggerDuration = 2;
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 1_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 1_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 3))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, triggerDuration))
            );
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));
        }
        when:
        // send first trade such that volume is on the limit
        {
            prophet.clearOutputBuffer();
            // send BUY 1mio USD client deal to be ON volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // do NOT expect firewall to be triggered - thus NO indicative client prices
        {
            prophet.notExpect(ClientPrice.class);
        }
        when:
        // send second trade(different pair) such that volume limit breached
        {
            prophet.clearOutputBuffer();
            // send SELL 1_000 USD/CAD client deal to BREACH volume limit
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000, 88.500));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {   // Verify client prices for ALL models and ALL pairs are INDICATIVE
            List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(9));
            final List<ClientPrice> lastPrices = lastClientPrices(clientPrices, 3, 4);
            lastPrices.forEach(prices -> assertThat(prices, new QuoteTypeMatcher(QuoteType.INDICATIVE)));
            checkFirewallTriggered(PricingFirewallType.OVERALL_PROFIT_VOLUME);
            prophet.clearOutputBuffer();
        }
        when:
        {
            for (int i = 0; i < triggerDuration; ++i) {
                tickSecond();
            }
        }
        then:
        // expect firewall to reset and force push client prices as FIRM
        {
            List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(9));
            for (int i = 0; i < clientPrices.size(); i++) {
                assertThat(clientPrices.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPrices.get(i));
            }
        }
    }

    @Test
    @Requirement(value = {Ref.PRICING_4_7_6, Ref.PRICING_4_7_11})
    @DisplayName("End of latching period - remain INDICATIVE if autoReset is false until manual reset ")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void atEndOfLatchingPeriodRemainINDICATIVEAutoResetFalse() {
        final int triggerDuration = 2;
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .setPricingModels(
                            Arrays.asList(
                                    new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                    new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                            ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_AUTO_RESET, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 1_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 1_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 3))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, triggerDuration))
            );
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));
        }
        when:
        // send first trade such that volume is on the limit
        {
            prophet.clearOutputBuffer();

            // send BUY 1mio USD client deal to be ON volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // do NOT expect firewall to be triggered - thus NO indicative client prices
        {
            prophet.notExpect(ClientPrice.class);
        }
        when:
        // send second trade(different pair) such that volume limit breached
        {
            // send SELL 1_000 USD/CAD client deal to BREACH volume limit
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000, 88.500));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {   // Verify client prices for ALL models and ALL pairs are INDICATIVE
            List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(9));
            for (int i = 0; i < clientPrices.size(); i++) {
                assertThat(clientPrices.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPrices.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }
            prophet.clearOutputBuffer();
        }
        when:
        // firewall triggered for triggerDuration
        {
            for (int i = 0; i < triggerDuration; ++i) {
                tickSecond();
            }
            // at end of duration prices remain indicative. Send market data to generate client price
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80002, 0.00004));
        }
        then:
        // expect firewall to still be triggered and prices still indicative
        {
            List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(5));
            for (int i = 0; i < clientPrices.size(); i++) {
                assertThat(clientPrices.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(clientPrices.get(i), PricingFirewallType.OVERALL_PROFIT_VOLUME);
            }
            prophet.clearOutputBuffer();
        }
        when:
        {   // Firewall manually reset by user
            prophet.receive(PricingFirewallResetImpl.of(PricingFirewallType.OVERALL_PROFIT_VOLUME));

            tickSecond();
        }
        then:
        // expect firewall to NOT be triggered. Prices now FIRM
        {
            List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(9));
            for (int i = 0; i < clientPrices.size(); i++) {
                assertThat(clientPrices.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPrices.get(i));
            }
            prophet.clearOutputBuffer();
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));
        }
        then:
        // expect Prices remain FIRM
        {
            List<ClientPrice> clientPrices = prophet.expect(ClientPrice.class, exactly(5));
            for (int i = 0; i < clientPrices.size(); i++) {
                assertThat(clientPrices.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(clientPrices.get(i));
            }
        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @DisplayName("End of latching period - remain INDICATIVE if still breached")
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void atEndOfLatchingPeriodRemainINDICATIVE() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 1_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 1_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 3))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 3))
            );
        }

        when:
        // send first trade such that volume is on the limit
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));

            // send BUY 1mio USD client deal to be ON volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // do NOT expect firewall to be triggered
        {
            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
            prophet.clearOutputBuffer();
        }

        when:
        // send second trade(different pair) such that volume limit breached
        {
            // send SELL 1_000 USD/CAD client deal to BREACH volume limit
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000, 88.500));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {   // Verify client prices for ALL models and ALL pairs are INDICATIVE
            checkQuoteType(QuoteType.INDICATIVE);
            checkFirewallTriggered(PricingFirewallType.OVERALL_PROFIT_VOLUME);
            prophet.clearOutputBuffer();
        }

        when:
        {
            // ensure OverallProfitVolumeFirewall calc
            tickSecond();

            // send BUY 1.0mio USD client deal to breach volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }

        then:
        // expect firewall STILL be breached. Therefore send market data to generate client price
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80001, 0.00004));

            final List<ClientPrice> pricesAUDUSD = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
            final ClientPrice clientPrice = pricesAUDUSD.get(pricesAUDUSD.size() - 1);
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));

            checkFirewallTriggered(clientPrice, PricingFirewallType.OVERALL_PROFIT_VOLUME);

        }
    }

    @Test
    @Requirement(Ref.PRICING_4_7_6)
    @RestartBeforeTest(reason = "Firewall keeps state.")
    public void manualResetVolumeFirewallDuringLatchingPeriod() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            // configure firewall threshold, limits and period
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_ENABLED, true))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_USD, 1_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_PNL_LIMIT_PERIOD_SECONDS, 10))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_USD, 1_000_000.))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_VOLUME_LIMIT_PERIOD_SECONDS, 30))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OVERALL_PROFIT_VOLUME_TRIGGERED_DURATION_SECONDS, 10))
            );
        }

        when:
        // send first trade such that volume is on the limit
        {
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.USDJPY, 88.500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(Market.CNX, Instrument.AUDUSD, 0.80000, 0.00004));

            // send BUY 1mio USD client deal to be ON volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));

            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // do NOT expect firewall to be triggered
        {
            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
            prophet.clearOutputBuffer();
        }
        when:
        // send second trade(different pair) such that volume limit breached
        {
            // send SELL 1_000 USD/CAD client deal to BREACH volume limit
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, -1_000, 88.500));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // expect firewall to be triggered. When triggered will push new client prices
        {   // Verify client prices for ALL models and ALL pairs are INDICATIVE
            checkQuoteType(QuoteType.INDICATIVE);
            checkFirewallTriggered(PricingFirewallType.OVERALL_PROFIT_VOLUME);
            prophet.clearOutputBuffer();
        }
        when:
        // manual reset
        {
            prophet.receive(PricingFirewallResetImpl.of(PricingFirewallType.OVERALL_PROFIT_VOLUME));

            // send BUY 1mio USD client deal to be ON volume limit
            prophet.receive(tdd.client_trade_001(Instrument.AUDUSD, 1_250_000, 0.80000));
            tickSecond(); // ensure OverallProfitVolumeFirewall calc
        }
        then:
        // expect firewall not breached. Therefore send market data to generate client price
        {
            checkQuoteType(QuoteType.FIRM);
            checkFirewallTriggered();
        }
    }

    private void checkQuoteType(final QuoteType expectedQuoteType) {
        List<ClientPrice> prices = prophet.expect(ClientPrice.class);
        final ClientPrice clientPrice = prices.get(prices.size() - 1);
        assertThat("Quote type should be " + expectedQuoteType, clientPrice.getBidQuoteType(), is(expectedQuoteType));
        assertThat("Quote type should be " + expectedQuoteType, clientPrice.getOfferQuoteType(), is(expectedQuoteType));
    }


    private void checkFirewallTriggered(final PricingFirewallType... firewallTypes) {
        List<ClientPrice> prices = prophet.expect(ClientPrice.class);
        final ClientPrice clientPrice = prices.get(prices.size() - 1);
        assertThat(clientPrice, new PricingFirewallTypeMatcher(OrderSide.BID,firewallTypes));
        assertThat(clientPrice, new PricingFirewallTypeMatcher(OrderSide.OFFER,firewallTypes));
    }

    private void sleepSeconds(final int seconds) {
        prophet.incrementTime(TimeUnit.SECONDS.toMillis(seconds));
    }


    private List<ClientPrice> lastClientPrices(final List<ClientPrice> clientPrices, final int expectedInstruments,
                                               final int expectedMarkets) {
        final Set<Instrument> instruments = clientPrices.stream().map(ClientPrice::getInstrument).collect(Collectors.toSet());
        assertThat(instruments.size(), is(expectedInstruments));
        final Set<Market> markets = clientPrices.stream().map(ClientPrice::getMarket).collect(Collectors.toSet());
        assertThat(markets.size(), is(expectedMarkets));
        ArrayList<ClientPrice> result = new ArrayList<>();
        instruments.forEach(instrument ->
                markets.forEach(market -> {
                    Optional<ClientPrice> clientPrice = clientPrices.stream().filter(cp -> (cp.getMarket() == market && cp.getInstrument() == instrument)).reduce((a, b) -> b);
                    if (clientPrice.isPresent()) {
                        result.add(clientPrice.get());
                    }
                })
        );
        return result;
    }

    public static class PositionsHelper {
        final Collection<Positions> positions;

        public PositionsHelper(Collection<Positions> positions) {
            this.positions = positions;
        }

        private static class PositionHolder {
            Position value;
        }

        public Position getLatest(final Currency currency) {
            PositionHolder result = new PositionHolder();
            for (final Positions pos : positions) {
                pos.forEach(p -> {
                    if (p.getCcy() == currency) {
                        result.value = p;
                    }
                });
            }
            GcFriendlyAssert.notNull(result.value, "Cannot find position for " + currency);
            return result.value;
        }
    }

}
