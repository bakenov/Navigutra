package com.anz.axle.adapters.ndf2trep.acceptance;

import com.anz.markets.adapters.trep.Item;
import com.anz.markets.adapters.trep.consumer.AbstractMarketDataSubscriber;
import com.reuters.rfa.common.Handle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;

public class TrepRateSubscriber extends AbstractMarketDataSubscriber<Item> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrepRateSubscriber.class);

    private final String subscriptionName;
    private final MessageProcessor<Item> processor;
    private final CountDownLatch connectedLatch = new CountDownLatch(1);

    public TrepRateSubscriber(final String subscriptionName, final MessageProcessor<Item> processor) {
        LOGGER.debug("TrepRateSubscriber()   subscriptionName: {}    processor.hashCode()={}", subscriptionName, processor.hashCode());
        this.subscriptionName = Objects.requireNonNull(subscriptionName);
        this.processor = Objects.requireNonNull(processor);
    }

    @PostConstruct
    @Override
    public synchronized void init() {
        LOGGER.info("Activating Trep Rate subscriber.");
        super.init();

    }

    @Override
    public synchronized void onRefresh(final Item item) {
        LOGGER.debug("onRefresh()   subscriptionName: {}  this.hashCode()={}  processor.hashCode()={}   item: {}", subscriptionName, this.hashCode(), processor.hashCode(), item);
        processor.process(item, subscriptionName);
    }

    @Override
    public synchronized void onUpdate(final Item item) {
        LOGGER.debug("onUpdate()   subscriptionName: {}  this.hashCode()={}  processor.hashCode()={}   item: {}", subscriptionName, this.hashCode(), processor.hashCode(), item);
        processor.process(item, subscriptionName);
    }

    @Override
    public synchronized void onError(final String name) {
        LOGGER.error("Error in subscription: {}", name);
    }

    @Override
    public void onStreamClosed(final Handle handle) {

    }

    @Override
    public void onStreamClosed(final Object context, final Handle handle) {

    }

    @Override
    public synchronized void onConnectionUp() {
        LOGGER.info("Connection is established");
        connectedLatch.countDown();
    }

    @Override
    public synchronized void onConnectionDown() {
        LOGGER.warn("Connection is down");
    }


    public synchronized void awaitConnected(final long time, final TimeUnit timeUnit) throws InterruptedException {
        connectedLatch.await(time, timeUnit);
    }
}
