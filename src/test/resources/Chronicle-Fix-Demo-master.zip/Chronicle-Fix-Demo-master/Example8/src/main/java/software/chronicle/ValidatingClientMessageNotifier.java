package software.chronicle;

import net.openhft.chronicle.wire.Demarshallable;
import net.openhft.chronicle.wire.WireIn;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.messages.MessageNotifier;

import java.util.concurrent.CountDownLatch;

/**
 * @author Rob Austin.
 */
public class ValidatingClientMessageNotifier implements MessageNotifier, Demarshallable {

    private final CountDownLatch l;

    private ValidatingClientMessageNotifier(WireIn w) {
        l = new CountDownLatch(1);
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        l.countDown();
    }

    public CountDownLatch latch() {
        return l;
    }
}
