package com.anz.markets.efx.ngaro.collections;

@FunctionalInterface
public interface ObjLongPredicate<T> {

    boolean test(T t, long v);
}
