package software.chronicle.fix;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.wire.Marshallable;
import org.jetbrains.annotations.NotNull;
import software.chronicle.fix.ClientMessageNotifier;
import software.chronicle.fix.ServerMessageNotifier;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

/**
 * Created by Rob Austin
 */
public class AcceptorMain {
    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                ClientMessageNotifier.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main(String[] args) throws IOException {

        // clean up from the last run
        IOTools.deleteDirWithFiles("acceptor");

        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        TCPRegistry.reset();
        TCPRegistry.setAlias("host.port", "localhost", 8090);

        final FixEngineCfg acceptorCfg = Marshallable.fromFile("fix-acceptor-config.yaml");

        // we will config the acceptor programmatically from the config fix-acceptor-config.yaml
        try (final ChronicleFixEngine acceptor = new ChronicleFixEngine(acceptorCfg.fixSessionCfgs())) {
            LockSupport.park();
        }
    }

    @NotNull
    private static FixSessionCfg getFixSessionCfg(FixEngineCfg cfg, String senderCompID) {
        return cfg.fixSessionCfgs().stream().filter(c -> senderCompID.equals(c.senderCompID())).findFirst().get();
    }

}

