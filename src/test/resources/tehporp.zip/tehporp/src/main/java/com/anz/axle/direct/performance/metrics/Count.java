package com.anz.axle.direct.performance.metrics;

public interface Count extends Named {
    long getCount();

    default double getRate() { return 0; }
}
