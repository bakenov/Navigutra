package com.anz.axle.lg.adapter.apama.transport;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.apama.engine.beans.interfaces.EngineClientInterface;
import com.apama.services.event.IEventService;
import com.apama.services.event.IEventServiceChannel;

import com.anz.axle.lg.adapter.apama.config.venue.DefaultConnectionConfig;
import com.anz.markets.efx.ngaro.api.Venue;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ApamaTransportTest {

    @Mock
    private EngineClientInterface engineClient;

    @Mock
    private IEventService eventService;

    @Mock
    private IEventServiceChannel eventServiceChannel;

    @Mock
    private ConnectionStatusHandler connectionStatusHandler;

    private ApamaTransport apamaTransport;

    @Before
    public void setUp() throws Exception {
        apamaTransport = new ApamaTransport(() -> engineClient, engineClientInterface -> eventService);
    }

    @Test
    public void openConnection() throws Exception {
        //given
        final ConnectionConfig connectionConfig = new DefaultConnectionConfig(Venue.CNX, "localhost", 16904, 30000);
        when(eventService.addChannel("", Collections.emptyMap())).thenReturn(eventServiceChannel);
        //when
        final Connection apamaConnection = apamaTransport.openConnection(connectionConfig, connectionStatusHandler);

        //then
        verify(engineClient).setHost(connectionConfig.host());
        verify(engineClient).setPort(connectionConfig.port());
        verify(engineClient).setProcessName(connectionConfig.venue().name());
        verify(engineClient).setConnectionPollingInterval(connectionConfig.connectionPollingInterval());
        verify(engineClient).connectInBackground();

        assertThat(apamaConnection).isNotNull();
    }

}