package com.anz.markets.efx.fox.receiver;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.messaging.transport.api.Subscription;

public interface VenueSubscriber {
    Subscription subscribe(Venue venue);

    interface Async {
        void subscribe(Venue venue);
    }
}
