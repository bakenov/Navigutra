package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.Set;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.pojo.model.UserConfig;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.matcher.ValueMatcher;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface UserConfigMatcher extends Predicate<Object> {

    Matcher<UserConfigMatcher, UserConfig.Body> body();

    static UserConfigMatcher build() {
        return new UserConfigMatcher() {
            private Predicate<UserConfig> predicate = Matchers.isA(UserConfig.class);

            @Override
            public Matcher<UserConfigMatcher, UserConfig.Body> body() {
                return matcher -> andThen(translate(userConfig -> userConfig.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof UserConfig && predicate.test((UserConfig) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private UserConfigMatcher matcher() {
                return this;
            }

            private UserConfigMatcher andThen(final Predicate<? super UserConfig> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<UserConfig.Body, String> userName() {
        return ComparisonMatcher.create("userName", b -> b.userName);
    }

    static ValueMatcher<UserConfig.Body, Set<UserGroup>> userGroups() {
        return ValueMatcher.create("userGroups", b -> b.userGroups);
    }

    static ComparisonMatcher<UserConfig.Body, String> location() {
        return ComparisonMatcher.create("location", b -> b.location);
    }
}
