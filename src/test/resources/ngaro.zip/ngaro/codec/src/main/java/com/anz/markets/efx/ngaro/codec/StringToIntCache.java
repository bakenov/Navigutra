package com.anz.markets.efx.ngaro.codec;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;

public interface StringToIntCache {
    int put(StringDecoder stringDecoder);
    int remove(StringDecoder stringDecoder);

    <S> int put(S source, ByteReader<? super S> reader, int sourceOffset, int length);
    <S> int remove(S source, ByteReader<? super S> reader, int sourceOffset, int length);

    default int put(final AsciiString source) {
        return put(source, 0, source.length());
    }
    default int remove(final AsciiString source) {
        return remove(source, 0, source.length());
    }

    default int put(final AsciiString source, int sourceOffset, int length) {
        return put(source, ByteReader.ASCII_STRING, sourceOffset, length);
    }
    default int remove(final AsciiString source, int sourceOffset, int length) {
        return remove(source, ByteReader.ASCII_STRING, sourceOffset, length);
    }

    default int put(final CharSequence source) {
        return put(source, 0, source.length());
    }
    default int remove(final CharSequence source) {
        return remove(source, 0, source.length());
    }

    default int put(CharSequence source, int sourceOffset, int length) {
        return put(source, ByteReader.CHAR_SEQUENCE, sourceOffset, length);
    }
    default int remove(CharSequence source, int sourceOffset, int length) {
        return remove(source, ByteReader.CHAR_SEQUENCE, sourceOffset, length);
    }

    default <S> int put(final S source, final ByteReader<? super S> reader, final int length) {
        return put(source, reader, 0, length);
    }

    default <S> int remove(final S source, final ByteReader<? super S> reader, final int length) {
        return remove(source, reader, 0, length);
    }

    StringDecoder get(int key);

    String getStringOrNull(int key);

    void clear();

    int size();
}
