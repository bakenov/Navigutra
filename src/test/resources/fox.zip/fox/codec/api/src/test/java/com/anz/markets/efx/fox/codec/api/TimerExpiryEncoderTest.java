package com.anz.markets.efx.fox.codec.api;


import org.junit.Test;

import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

public class TimerExpiryEncoderTest {
    @Test
    public void encoderChaining() {
        final TimerExpiryEncoder encoder = mock(TimerExpiryEncoder.class, RETURNS_DEEP_STUBS);

        encoder.messageStart(4, 5)
                .triggeredTime(45445)
                .timerId(6754)
                .timerGroup(TimerGroup.PARENT_ORDER_RELEASE)
                .messageComplete();
    }
}