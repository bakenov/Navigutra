package com.anz.axle.lg.adapter.d3.config;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anz.axle.lg.adapter.d3.newsubscription.SubscriptionRegistry;
import com.anz.axle.lg.adapter.d3.pricingrequest.D3MarketDataRequestHandler;
import com.anz.axle.lg.adapter.d3.pricingrequest.PricingRequestMessageHandler;
import com.anz.axle.lg.config.LoggingStatusHandler;
import com.anz.axle.lg.config.LongConsumerSupplier;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Subscription;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.base.DefaultTopic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.pricing.codec.api.PricingDecoders;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultRequestKeyLookup;

@Configuration
public class SubscriberConfig {

    @Bean
    public EndPointStatusHandler subscriptionStatusHandler() {
        return new LoggingStatusHandler(LoggerFactory.getLogger(SubscriberConfig.class));
    }

    @Bean
    public LongConsumerSupplier receivedTimeConsumerSupplier() {
        return new LongConsumerSupplier();
    }

    @Bean
    public MessageHandler pricingRequestMessageHandler(final @Value("${venue}") Venue venue,
                                                       final @Value("${securitytype}") SecurityType securityType,
                                                       final SubscriptionRegistry subscriptionRegistry,
                                                       final LongConsumerSupplier receivedTimeConsumerSupplier) {
        final PricingDecoders<SbeMessage> sbePricingDecoders = new SbePricingDecoders();
        final D3MarketDataRequestHandler d3MarketDataRequestHandler = new D3MarketDataRequestHandler(venue, subscriptionRegistry, securityType, new DefaultRequestKeyLookup());
        final MessageDecoder<SbeMessage> marketDataRequestDecoder = sbePricingDecoders.marketDataRequest().create(d3MarketDataRequestHandler, MessageDecoder.ForwardingLookup.noop());
        return new PricingRequestMessageHandler(receivedTimeConsumerSupplier, marketDataRequestDecoder);
    }

    @Bean
    public Subscription pricingRequestSubscription(final @Value("${venue}") Venue venue,
                                                   final Connection connection,
                                                   final MessageHandler pricingRequestMessageHandler,
                                                   final EndPointStatusHandler subscriptionStatusHandler) {
        final Topic pricingRequestTopic = DefaultTopic.create(venue.name() + "_PRICING_REQUEST");
        return connection.openSubscription(pricingRequestTopic, subscriptionStatusHandler, pricingRequestMessageHandler);
    }

}
