package com.anz.axle.environment.dls;

import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

/**
  */
public class TimezoneConfigGenerator {
    private static final Logger LOG = Logger.getLogger(TimezoneConfigGenerator.class);


    private LocalDate targetTime = new LocalDate();
    public File targetDir;

    private static final TimeZonePairs TIMEZONE_PAIRS[] = { //
            new TimeZonePairs("nz_to_utc", "NZ", "UTC"), //
            new TimeZonePairs("nz_to_au", "NZ", "Australia/Melbourne"), //
            new TimeZonePairs("nyc_to_au", "America/New_York", "Australia/Melbourne"), //
            new TimeZonePairs("nyc_to_utc", "America/New_York", "UTC"), //
            new TimeZonePairs("au_to_utc", "Australia/Melbourne", "UTC")//
    };


    public TimezoneConfigGenerator(LocalDate targetTime, String targetDir) {
        this.targetTime = targetTime;
        this.targetDir = new File(targetDir);

        try {
            build();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void build() throws FileNotFoundException {


        File outputFile = new File(targetDir, "timezone_config.properties");
        PrintWriter writer = new PrintWriter(new FileOutputStream(outputFile));
        writer.println("#  Target Date " + targetTime);
        for (TimeZonePairs timeZonePairs : TIMEZONE_PAIRS) {
            timeZonePairs.writeTo(targetTime, writer);
        }
        writer.close();

    }


    public static void main(String args[]) {

        LocalDate targetDate = new LocalDate();
        if (args.length == 1) {
            DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
            targetDate = formatter.parseLocalDate(args[0]);

        }

        TimezoneConfigGenerator dlsMonitor = new TimezoneConfigGenerator(targetDate, ".");


    }

}
