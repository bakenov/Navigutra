package com.anz.axle.lg.adapter.cnx.quickfix;

import org.junit.Test;

import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateType;
import quickfix.field.MarketDepth;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.fix42.MarketDataRequest;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CnxLastMarketTradeSubscriptionRequestEncoderTest {

    @Test
    public void testLastMarketTradeSubscription() throws Exception {
        final int marketDepthInt = 0;
        final boolean aggregateBook = true;
        final boolean fullRefresh = false;
        final String expectedSymbol = "AUD/USD";
        final String requestId = "34214521";

        final CnxLastMarketTradeSubscriptionRequestEncoder encoder = new CnxLastMarketTradeSubscriptionRequestEncoder();

        final MarketDataSubscription subscription = mock(MarketDataSubscription.class);
        when(subscription.aggregateBook()).thenReturn(aggregateBook);
        when(subscription.symbol()).thenReturn(expectedSymbol);
        when(subscription.marketDepth()).thenReturn(marketDepthInt);
        when(subscription.fullRefresh()).thenReturn(fullRefresh);

        final MarketDataRequest lastMarketTradeRequest = encoder.encodeSubscribe(Integer.parseInt(requestId), subscription);

        final MDReqID mdReqId = lastMarketTradeRequest.getMDReqID();
        final MarketDepth marketDepth = lastMarketTradeRequest.getMarketDepth();
        final SubscriptionRequestType subscriptionRequestType = lastMarketTradeRequest.getSubscriptionRequestType();
        final MDUpdateType mdUpdateType = lastMarketTradeRequest.getMDUpdateType();
        final MarketDataRequest.NoMDEntryTypes bidMdEntryTypesGroup = new MarketDataRequest.NoMDEntryTypes();
        lastMarketTradeRequest.getGroup(1, bidMdEntryTypesGroup);
        final MDEntryType tradeEntryType = bidMdEntryTypesGroup.getMDEntryType();

        final MarketDataRequest.NoRelatedSym noRelatedSymGroup = new MarketDataRequest.NoRelatedSym();
        lastMarketTradeRequest.getGroup(1, noRelatedSymGroup);
        final Symbol symbol = noRelatedSymGroup.getSymbol();

        assertEquals(mdReqId.getValue(), requestId);
        assertEquals(marketDepth.getValue(), marketDepthInt);
        assertEquals(subscriptionRequestType.getValue(), CnxLastMarketTradeSubscriptionRequestEncoder.LAST_MARKET_TRADE_SUBSCRIPTION_REQUEST_TYPE_SUBSCRIBE);
        assertEquals(mdUpdateType.getValue(), MDUpdateType.INCREMENTAL_REFRESH);
        assertEquals(tradeEntryType.getValue(), MDEntryType.TRADE);
        assertEquals(symbol.getValue(), expectedSymbol);
    }
}