package com.anz.axle.lg.adapter.apama.transport;

public interface Subscription extends AutoCloseable {
    @Override
    void close();
}
