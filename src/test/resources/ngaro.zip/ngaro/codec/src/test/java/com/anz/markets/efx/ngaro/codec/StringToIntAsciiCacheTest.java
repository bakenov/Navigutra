package com.anz.markets.efx.ngaro.codec;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntSupplier;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import static org.assertj.core.api.Assertions.assertThat;

public class StringToIntAsciiCacheTest {
    private final static int STRING_LENGTH = 20;
    private final static int POOL_SIZE = 1000;
    private ObjectPool<MutableAsciiString> objectPool = new ObjectPool<>(mutableAsciiStringConsumer -> new FixedLengthAsciiString(STRING_LENGTH), POOL_SIZE);
    private AtomicInteger integer = new AtomicInteger(0);
    private IntSupplier intSupplier = () -> integer.incrementAndGet();

    private StringToIntAsciiCache cache = new StringToIntAsciiCache(objectPool, STRING_LENGTH, intSupplier, 1000, 8);

    @Test
    public void consequent_put_retruns_the_same_key() {
        final String stringValue = "1234565";
        final StringDecoder stringDecoder1 = SimpleStringDecoder.forString(stringValue);
        final int key1 = cache.put(stringDecoder1);
        final int key2 = cache.put(stringDecoder1);

        assertThat(key1).isEqualTo(key2);

        assertThat(stringValue).isEqualTo(cache.getStringOrNull(key2));
    }

    @Test
    public void put_1000_times_more_than_pool_size_and_ensure_clears_removes_from_cache() {
        final MutableAsciiString asciiString = AsciiString.fixedLength(STRING_LENGTH);
        final AsciiStringEncoder asciiStringEncoder = AsciiStringEncoder.forMutableAsciiString(this, asciiString, STRING_LENGTH);
        final AsciiStringDecoder stringDecoder = AsciiStringDecoder.forAsciiString(asciiString);

        for (int i = 0; i < POOL_SIZE * 1000; i++) {
            asciiStringEncoder.encodeLong(i);
            final int key = cache.put(stringDecoder);
            cache.getStringOrNull(key);
        }
        cache.clear();
        assertThat(cache.size()).isEqualTo(0);
    }

    @Test
    public void remove_should_remove_from_both_collections() {
        final String stringValue = "1234565";
        final StringDecoder stringDecoder1 = SimpleStringDecoder.forString(stringValue);
        final int key1 = cache.put(stringDecoder1);

        assertThat(key1).isGreaterThan(0);
        assertThat(stringValue).isEqualTo(cache.getStringOrNull(key1));

        final int removedKey = cache.remove(stringDecoder1);

        assertThat(removedKey).isEqualTo(key1);
        assertThat(cache.size()).isEqualTo(0);

        assertThat(cache.getStringOrNull(removedKey)).isNull();

    }

    @Test
    public void clear_should_remove_all_from_both_collections() {
        final String stringValue = "1234565";
        final StringDecoder stringDecoder1 = SimpleStringDecoder.forString(stringValue);
        final int key1 = cache.put(stringDecoder1);

        assertThat(key1).isGreaterThan(0);
        assertThat(stringValue).isEqualTo(cache.getStringOrNull(key1));

        cache.clear();

        assertThat(cache.size()).isEqualTo(0);
        assertThat(cache.getStringOrNull(key1)).isNull();
    }
}