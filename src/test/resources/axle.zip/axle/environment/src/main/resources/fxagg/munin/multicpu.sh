#!/bin/bash
# -*- sh -*-

: <<=cut

=head1 NAME

multicpu - Munin plugin to monitor cpu usage of processes. Which processes
are configured in plugin-conf.d

=head1 APPLICABLE SYSTEMS

Any system with a compatible ps command.

=head1 CONFIGURATION

There is no default configuration.  This is an example:

[multicpu]
env.pidfiles /var/run/some.pid /var/run/someotherpid

The names are used to grep with directly, after cleaning. So, this plugin
only supports very basic pattern matching. To fix: see multips

=head1 INTERPRETATION

This plugin adds up the RSS of all processes matching the
regex given as the process name, as reported by ps.

=head1 MAGIC MARKERS

#%# family=manual
#%# capabilities=autoconf

=head1 VERSION

0.2 second release, it should now work on machines without GNU sed
0.1 first release, based on:
multicpu.in 1590 2008-04-17 18:21:31Z matthias
As distributed in Debian.

=head1 BUGS

None known

=head1 AUTHOR

Originally: matthias?
Modified by: github.com/dominics github.com/yhager
Thanks to: wix

=head1 LICENSE

GPLv2

=cut
# NB pidfiles are no longer defined at $DEFAULTS_FILE. They are now defined at env.pidfiles:
pidfiles=`find ~/logs/ -name "*.pid" -print`

. $MUNIN_LIBDIR/plugins/plugin.sh

if [ "$1" = "autoconf" ]; then
    echo yes
    exit 0
fi

if [ -z "$pidfiles" ]; then
    echo "Configuration required"
    exit 1
fi

if [ "$1" = "config" ]; then
    echo graph_title Cpu Usage
    echo 'graph_category axle'
    echo 'graph_args --vertical-label cpu(%)'
    echo 'graph_scale no'
    linetype=LINE2
    i=1
    for pidfile in $pidfiles; do
        textname=$(basename $pidfile | sed 's/.pid//')
        fieldname=$(clean_fieldname $textname)

        echo "$fieldname.label $fieldname"
        echo "$fieldname.draw $linetype"
        echo "$fieldname.info Info from prstat"

        # don't use red on the eighth line
        if [ "$i" -eq "8" ]; then
            echo "$fieldname.colour 0080ff"
        fi

        # always use red for the fxagg correlator
        if [ "$textname" = "Correlator-FxAgg" ]; then
            echo "$fieldname.colour FF0000"
        fi
        i=$(($i + 1))
    done
    exit 0
fi

if [ `uname` = 'SunOS' ]; then
    num_cpu=`/usr/sbin/psrinfo | wc -l`
else
    num_cpu=`lscpu -p | grep -v '^#' | wc -l`
fi

for pidfile in $pidfiles; do
    textname=$(basename $pidfile | sed 's/.pid//')
    fieldname=$(clean_fieldname $textname)

    printf "$fieldname.value "

    if [ ! -f $pidfile ] ; then
        #pidfile doesn't exist - undefined
        echo "U"
        continue
    fi

    if [ ! -d /proc/$(cat $pidfile) ] ; then
        #pidfile exist but no process for that pid - undefined
        echo "U"
        continue
    fi

    if [ `uname` = 'SunOS' ]; then 
        PROCESSES=`prstat -p $(cat $pidfile) 1 1 | head -2 | tail -1`
    else        
        PROCESSES=`ps -p $(cat $pidfile) -o pid,user,size,rss,state,pri,nice,time,pcpu,comm --no-headers`
    fi

    echo $PROCESSES | while read pid user size rss state pri nice time cpu name
    do
        len=${#cpu}
        if [ $len -gt 0 ]; then
            value=$(expr $len - 1)
            # dont multiply by num_cpu (misleading)
            echo ${cpu:0:$value}
        else
            echo "U"
        fi
    done
done

