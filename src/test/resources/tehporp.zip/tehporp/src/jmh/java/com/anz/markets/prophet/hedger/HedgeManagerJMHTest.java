package com.anz.markets.prophet.hedger;

import com.anz.markets.prophet.TestStubConsumer;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.trigger.HedgeTriggerMidEqPosTest;
import com.anz.markets.prophet.pricer.OptimalPositionBuilder;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import org.jetbrains.annotations.NotNull;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.io.IOException;
import java.util.function.Consumer;

public class HedgeManagerJMHTest {

    @State(Scope.Benchmark)
    public static class Data {
        private Consumer<OptimalPositions> optimalPositionsConsumer;
        private OptimalPositions optimalPositions;
        private TestStubConsumer<Order> orderTestStubConsumer = new TestStubConsumer();
        private TestStubConsumer<HedgeStatus> testHedgeStatusSink = new TestStubConsumer();
        private TestStubConsumer<HedgeDecision> testHedgeDecisionSink = new TestStubConsumer();
        private TestStubConsumer<HedgeCurrencyControl> testHedgeCurrencyControlSink = new TestStubConsumer();

        @Setup
        public void setup() throws IOException {
            final HedgeTriggerMidEqPosTest unitTest = new HedgeTriggerMidEqPosTest();
            // unitTest.tradeableInstruments -> into config
            final HedgeManager hedgeManager = new HedgeManager(true, false, orderTestStubConsumer, testHedgeStatusSink, testHedgeDecisionSink, testHedgeCurrencyControlSink);
            for (final Portfolio portfolio : Portfolio.VALUES) {
                hedgeManager.consumerOfHedgeControl().accept(new HedgeControl() {
                    public Portfolio getPortfolio() {
                        return portfolio;
                    }

                    @Override
                    public boolean isEnabled() {
                        return true;
                    }
                });
            }
            optimalPositionsConsumer = hedgeManager.consumerOfOptimalPositions();
            optimalPositions = createOptimalPositions();
        }

        private OptimalPositions createOptimalPositions() {
            final OptimalPosition optimalPosition = OptimalPositionBuilder.createOptimalPositionWithNotional(Instrument.AUDUSD, 15e5);
            OptimalPositions optimalPositions = new OptimalPositions();
            optimalPositions.ops.add(optimalPosition);
            return optimalPositions;
        }
    }

    @Benchmark
    public long acceptOptimalPosition(@NotNull final Data data) throws Exception {
        data.optimalPositionsConsumer.accept(data.optimalPositions);
        return data.orderTestStubConsumer.getEvents().size();
    }
}
