package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.model.FirewallConfig;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;
import com.anz.markets.efx.ngaro.codec.SimpleStringEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoFirewallConfigEncoder implements FirewallConfigEncoder, FirewallConfigEncoder.Body, MessageEncoder.Trailer {

    private final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier;
    private final StringEncoder<FirewallConfigEncoder.Body> firewallName;
    private final StringEncoder<FirewallConfigEncoder.Body> regionPattern;
    private final StringEncoder<FirewallConfigEncoder.Body> orderTypePattern;
    private final StringEncoder<FirewallConfigEncoder.Body> deskPattern;
    private final StringEncoder<FirewallConfigEncoder.Body> portfolioPattern;
    private final StringEncoder<FirewallConfigEncoder.Body> usernamePattern;
    private final StringEncoder<FirewallConfigEncoder.Body> venuePattern;
    private final StringEncoder<FirewallConfigEncoder.Body> securityTypePattern;
    private final StringEncoder<FirewallConfigEncoder.Body> tenorPattern;
    private final StringEncoder<FirewallConfigEncoder.Body> symbolPattern;
    private final StringEncoder<FirewallConfigEncoder.Body> periodUnit;
    private final StringEncoder<FirewallConfigEncoder.Body> comment;
    private final StringEncoder<FirewallConfigEncoder.Body> lastEditUsername;

    private FirewallConfig message = SorMessage.firewallConfig();

    public PojoFirewallConfigEncoder(final Supplier<? extends Consumer<? super SorMessage>> consumerSupplier) {
        this.consumerSupplier = Objects.requireNonNull(consumerSupplier);
        this.firewallName = new SimpleStringEncoder<>(this, s -> message.body.firewallName = s);
        this.regionPattern = new SimpleStringEncoder<>(this, s -> message.body.regionPattern = s);
        this.orderTypePattern = new SimpleStringEncoder<>(this, s -> message.body.orderTypePattern = s);
        this.deskPattern = new SimpleStringEncoder<>(this, s -> message.body.deskPattern = s);
        this.portfolioPattern = new SimpleStringEncoder<>(this, s -> message.body.portfolioPattern = s);
        this.usernamePattern = new SimpleStringEncoder<>(this, s -> message.body.usernamePattern = s);
        this.venuePattern = new SimpleStringEncoder<>(this, s -> message.body.venuePattern = s);
        this.tenorPattern = new SimpleStringEncoder<>(this, s -> message.body.tenorPattern = s);
        this.securityTypePattern = new SimpleStringEncoder<>(this, s -> message.body.securityTypePattern = s);
        this.symbolPattern = new SimpleStringEncoder<>(this, s -> message.body.symbolPattern = s);
        this.periodUnit = new SimpleStringEncoder<>(this, s -> message.body.periodUnit = s);
        this.comment = new SimpleStringEncoder<>(this, s -> message.body.comment = s);
        this.lastEditUsername = new SimpleStringEncoder<>(this, s -> message.body.lastEditUsername = s);
    }

    public FirewallConfig message() {
        return message;
    }

    @Override
    public Body messageStart(int source, long sourceSeq) {
        message = SorMessage.firewallConfig();
        message.header.source = source;
        message.header.sourceSeq = sourceSeq;
        return this;
    }

    @Override
    public StringEncoder<Body> firewallName() {
        return firewallName;
    }

    @Override
    public Body ruleId(long ruleId) {
        message.body.ruleId = ruleId;
        return this;
    }

    @Override
    public StringEncoder<Body> regionPattern() {
        return regionPattern;
    }

    @Override
    public StringEncoder<Body> orderTypePattern() {
        return orderTypePattern;
    }

    @Override
    public StringEncoder<Body> deskPattern() {
        return deskPattern;
    }

    @Override
    public StringEncoder<Body> portfolioPattern() {
        return portfolioPattern;
    }

    @Override
    public StringEncoder<Body> usernamePattern() {
        return usernamePattern;
    }

    @Override
    public StringEncoder<Body> venuePattern() {
        return venuePattern;
    }

    @Override
    public StringEncoder<Body> securityTypePattern() {
        return securityTypePattern;
    }

    @Override
    public StringEncoder<Body> tenorPattern() {
        return tenorPattern;
    }

    @Override
    public StringEncoder<Body> symbolPattern() {
        return symbolPattern;
    }

    @Override
    public Body period(final long period) {
        message.body.period = period;
        return this;
    }

    @Override
    public StringEncoder<Body> periodUnit() {
        return periodUnit;
    }

    @Override
    public Body local(final boolean local) {
        message.body.local = local;
        return this;
    }

    @Override
    public StringEncoder<Body> comment() {
        return comment;
    }

    @Override
    public StringEncoder<Body> lastEditUsername() {
        return lastEditUsername;
    }

    @Override
    public Body lastEditTime(final long lastEditTime) {
        message.body.lastEditTime = lastEditTime;
        return this;
    }

    @Override
    public Trailer limitThreshold(final double limitThreshold) {
        message.body.limitThreshold = limitThreshold;
        return this;
    }

    @Override
    public void messageComplete() {
        consumerSupplier.get().accept(message);
    }

}
