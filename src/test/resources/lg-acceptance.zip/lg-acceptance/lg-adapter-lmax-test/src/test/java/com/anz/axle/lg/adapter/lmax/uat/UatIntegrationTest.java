package com.anz.axle.lg.adapter.lmax.uat;


import java.util.concurrent.TimeUnit;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.experimental.categories.Category;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.UatTest;
import com.anz.axle.lg.adapter.lmax.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.lmax.acceptance.AcceptanceContext;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;

@Category(UatTest.class)
public class UatIntegrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatIntegrationTest.class);
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);


    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
            StringUtils.parseMap(
                "appName:lg-lmax" +
                ",default.log.level:DEBUG" +
                ",lmax.fix.log.destination:FILE" +
                ",lmax.fix.pricing.sendercompid:anzfxmduat1" +
                ",lmax.fix.pricing.targetcompid:LMAX-MD" +
                ",lmax.fix.pricing.host:daxa003z.unix.anz" +
                ",lmax.fix.pricing.port:14179" +
                ",lmax.fix.pricing.password:anzfxmduat1" +

                ",lmax.fix.trading.reset.on.logon:Y" +
                ",lmax.fix.trading.reset.on.logout:Y" +
                ",lmax.fix.trading.reset.on.disconnect:Y" +

                ",lmax.fix.trading.sendercompid:anzfxuattk1" +
                ",lmax.fix.trading.targetcompid:LMAXLD-TK" +
                ",lmax.fix.trading.host:daxa003z.unix.anz" +
                ",lmax.fix.trading.port:14177" +
                ",lmax.fix.trading.password:anzfxuattk1" +
                ",lmax.fix.account:ANZBANK2" +
                ",lmax.fix.pricing.order.qty.contract.size:10000"
            ));

        application = new Application("lg-lmax-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Ignore
    @Test
    public void should_receive_price_placeOrder_receive_ExecutionReport() throws Exception {

        final PricingMessage message = Asserter.of(acceptanceContext.pricingMessageQueue())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq("GB:lg-lmax"))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.LMAX))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(INSTRUMENT_KEY.instrumentId()))
                        .entries().anyMatches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .hops().hasAny()
                        .hops().countAtLeast(2))
                .awaitMatchAndGetLast(30, TimeUnit.SECONDS);

        System.out.println(message);
        System.out.println("==============================================================");

        message.accept(new PricingMessageVisitor.Exception() {
                @Override
                public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                    final SnapshotFullRefresh.Entry firstEntry = snapshotFullRefresh.entries.get(0);

                    final NewOrderSingle newOrderSingle = new NewOrderSingle();
                    newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
                    newOrderSingle.body.messageId = 1;
                    newOrderSingle.body.orderQty = firstEntry.mdEntrySize;
                    newOrderSingle.body.clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
                    newOrderSingle.body.currency = INSTRUMENT_KEY.symbol().substring(0, 3);
                    newOrderSingle.body.ordType = OrderType.MARKET;
                    newOrderSingle.body.timeInForce = TimeInForce.IOC;

                    // need tag 21(HandlInst) - Required by FIX 4.2 but not used. Example val 2
                    newOrderSingle.body.price = firstEntry.mdEntryPx;
                    newOrderSingle.body.securityType = SecurityType.FXSPOT;
                    newOrderSingle.body.senderCompId = "AU:lg-acc";
                    newOrderSingle.body.side = firstEntry.mdEntryType == EntryType.OFFER ? Side.BUY : Side.SELL;
                    newOrderSingle.body.symbol = INSTRUMENT_KEY.symbol();

                    System.out.println("NewOrderSingle Request=" + newOrderSingle.toString());
                    System.out.println("==============================================================");

                    acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
                }
        });
/*
        while (true) {
            System.out.println("Message from LMAX: " + acceptanceContext.tradingResponseMessageQueue().poll());
            TimeUnit.SECONDS.sleep(2);
        }
        */
    }
}