package com.anz.markets.efx.fox.processor.state.mid;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public class StaticVenueTimeInForceLookup implements VenueTimeInForceLookup {
    @Override
    public TimeInForce lookup(final TimeInForce parentTimeInForce, final Venue venue) {
        if (parentTimeInForce == TimeInForce.GTC && venue == Venue.FXALLMB) return TimeInForce.DAY;
        if (parentTimeInForce == TimeInForce.DAY && venue == Venue.EBSHEDGE) return TimeInForce.GTC;

        return parentTimeInForce;
    }
}
