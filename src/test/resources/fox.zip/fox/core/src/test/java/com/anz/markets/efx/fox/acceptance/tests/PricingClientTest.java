package com.anz.markets.efx.fox.acceptance.tests;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.PricingClientEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

@RunWith(Spockito.class)
public class PricingClientTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(PricingClientTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("venue.instrument.config.class.path", "conf/venue-instrument-config.yaml");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_1 = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryPositionNo | mdEntryFlags | mdEntryId | quoteEntryId |",
            "|==============|================|=============|===========|======================|=============|=========|===================|==============|===========|==============|",
            "|0             |   BARX         |      BID    |   1.2345  |        0.0           |     1e6     |  500000 | 1                 |   []         |    1      |     1        |",
            "|0             |   CNX          |     OFFER   |   1.2320  |        0.0001        |     2e6     |  800000 | 1                 |   []         |    2      |     2        |",
    });

    private static final SnapshotFullRefresh.Entry[] SNAP_ENTRIES_2 = Table.parse(SnapshotFullRefresh.Entry.class, new String[] {
            "| transactTime |      mdMkt     | mdEntryType | mdEntryPx | mdEntryForwardPoints | mdEntrySize |  minQty | mdEntryPositionNo | mdEntryFlags | mdEntryId | quoteEntryId |",
            "|==============|================|=============|===========|======================|=============|=========|===================|==============|===========|==============|",
            "|0             |   BARX         |      BID    |   1.3345  |        0.0           |     1e6     |  500000 | 1                 |   []         |    1      |       1      |",
            "|0             |   CNX          |     OFFER   |   1.3320  |        0.0001        |     2e6     |  800000 | 1                 |   []         |    2      |       2      |",
    });

    private static final List<SnapshotFullRefresh.Entry[]> snapshotEntries() {
        return Arrays.asList(SNAP_ENTRIES_1, SNAP_ENTRIES_2);
    }

    private static final Hop[] HOPS = Table.parse(Hop.class, new String[] {
            "|   hopCompId  | hopMessageId | hopReceivingTime | hopSendingTime |",
            "|==============|==============|==================|================|",
            "| GB:HopName:1 |   123456789  |    66655556666   |  66655557777   |",
            "| AU:HopName:2 |   123123123  |    66556655666   |  66556655777   |",
    });

    @Test
    @Spockito.Unroll({
            "| source | sourceSeq |idx | senderCompId | messageId | possResend | origSendingTime | symbol |  securityType | marketId | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|========|===========|====|==============|===========|============|=================|========|===============|==========|============|===========|============|===================|===================|",
            "| 1024   |  23456    | 0  | GB:Sender:01 |    9876   |    false   |    1122334000   | AUDUSD |   FXSPOT      | FAST     | 2016-01-14 |    SP     | 2016-01-16 |     2016-01-06    | []                |",
            "|--------|-----------|----|--------------|-----------|------------|-----------------|--------|---------------|----------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {senderCompId}")
    public void should_produce_snapshot_when_polled(
            final int source, final long sourceSeq, final int idx, final String senderCompId,
            final long messageId, final boolean possResend,
            final long origSendingTime, final String symbol, final SecurityType securityType, final Venue marketId,
            final LocalDate tradeDate, final Tenor settlType, final LocalDate settlDate,
            final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags
    ) {
        final SnapshotFullRefresh.Entry[] snapShotEntry = snapshotEntries().get(idx);
        final long currentTimeNanos = acceptanceContext.precisionClock().nanos();
        Arrays.stream(snapShotEntry).forEach(e -> e.transactTime = currentTimeNanos);

        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, securityType, settlType);

        final SnapshotFullRefresh snapshot = PricingMessage.snapshotFullRefresh(
                new MessageHeader(source, sourceSeq),
                new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, currentTimeNanos, origSendingTime, instrumentKey.instrumentId(), marketId, tradeDate, settlDate, referenceSpotDate, mdFlags),
                snapShotEntry, HOPS);

        acceptanceContext.venueEndpointLookup()
                .lookup(marketId)
                    .pricingQueue(symbol, securityType)
                        .add(snapshot);

        final PricingClientEndpoint pricingClientEndpoint = acceptanceContext.pricingClientEndpoint();

        while(!pricingClientEndpoint.pollAll(instrumentKey.instrumentId())) {}

        Asserter.of(pricingClientEndpoint.polledSnapshots())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(marketId))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.2345))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.2320))
                        .hops().hasAny())
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }
}
