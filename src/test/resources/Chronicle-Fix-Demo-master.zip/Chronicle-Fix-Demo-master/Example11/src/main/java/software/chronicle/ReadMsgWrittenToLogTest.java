package software.chronicle;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;
import net.openhft.chronicle.wire.DocumentContext;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.ClientMessageNotifierExample11;
import software.chronicle.ServerMessageNotifierExample11;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.FixInstance;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.TimeUnit;

import static software.chronicle.LogWriterExample11.DIR_NAME;
import static software.chronicle.fix.cfg.ConnectionType.acceptor;

/**
 * @author Rob Austin.
 */
public class ReadMsgWrittenToLogTest {

    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(ClientMessageNotifierExample11.class,
                ServerMessageNotifierExample11.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main( String[] args ) throws Exception
    {
        new ReadMsgWrittenToLogTest().sendTestExecutionReportTest();
    }

    public void sendTestExecutionReportTest() throws Exception {

        IOTools.deleteDirWithFiles(DIR_NAME, 10);
        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");
        final FixSessionCfg acceptorFixConfig = fixEngineCfg.fixSessionCfgs().stream().filter(cfg
                -> cfg.connectionType() == acceptor).findFirst().get();

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");

        try (final Closeable ignored = FixInstance.fixEngineMain(1, fixEngineCfg)) {

            try (final Closeable ignored2 = FixInstance.fixEngineMain(2, fixEngineCfg)) {

                // note software.chronicle.ClientMessageNotifier.onLogon() sends a new order
                // single just after the logon.

                // wait for the new order single to arrive
                ((ServerMessageNotifierExample11) acceptorFixConfig.messageNotifier()).messageReceived.await();

            }

        }

        // read the the log message

        for (; ; ) {
            try (DocumentContext dc = SingleChronicleQueueBuilder.binary(DIR_NAME).build()
                    .createTailer().readingDocument()) {
                if (!dc.isPresent())
                    continue;

                final String text = dc.wire().getValueIn().text().replace('\u0001', '|');

                // we only look at the startsWith because of time stamps
                assert text.startsWith("8=FIX.4.4|9=72|35=A|34=1|49=CLIENT|56=SERVER|52=");
                return;
            }
        }

    }
}

