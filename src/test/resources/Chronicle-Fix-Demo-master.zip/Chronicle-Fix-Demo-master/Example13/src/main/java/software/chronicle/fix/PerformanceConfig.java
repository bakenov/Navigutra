package software.chronicle.fix;

import net.openhft.chronicle.wire.AbstractMarshallable;

/**
 * Created by jerry on 15/08/17.
 */
public class PerformanceConfig extends AbstractMarshallable {
    public static final String HOST_PORT = "host.port";

    public int throughput = 10_000;
    public int iterations = 200_000;
    public int warmupIterations = 100_000;
    public int runs = 4;
    public boolean isClient = true;
    public boolean isServer = true;
    public String hostPort = HOST_PORT;
    public boolean checkJitter = true;
    public boolean useAffinity = true;
    public int affinityCpu = -1;
    public boolean useBusyPauser = true;
    public boolean jlbhEventLoop = false;
    public boolean pretouch = true;
    public boolean pretouchOutOfProcess = false;
    public boolean concurrentFix = false;
}
