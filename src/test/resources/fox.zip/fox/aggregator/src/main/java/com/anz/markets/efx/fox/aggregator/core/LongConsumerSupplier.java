package com.anz.markets.efx.fox.aggregator.core;

import java.util.function.LongConsumer;
import java.util.function.LongSupplier;

public final class LongConsumerSupplier implements LongConsumer, LongSupplier {
    private long value = 0;

    @Override
    public void accept(final long value) {
        this.value = value;
    }

    @Override
    public long getAsLong() {
        return value;
    }
}
