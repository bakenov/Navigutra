package com.anz.markets.efx.ngaro.time;

import java.time.LocalDate;
import java.util.Objects;

import com.anz.markets.efx.ngaro.core.ByteReader;

/**
 * Decoder for local dates with date formats as defined by {@link LocalDateFormat}.
 * <br/>
 * All methods are zero garbage except for the ones returning an object such as {@link LocalDate}.
 * <p/>
 * This class is thread safe.
 *
 * @see LocalDateEncoder
 */
public final class LocalDateDecoder {

    public static final char NO_DELIMITER = Character.MAX_VALUE;

    private final LocalDateFormat dateFormat;

    public LocalDateDecoder(final LocalDateFormat dateFormat) {
        this.dateFormat = Objects.requireNonNull(dateFormat);
    }

    public LocalDateFormat getDateFormat() {
        return dateFormat;
    }

    public <S> long decodeEpochMillis(final S source, final ByteReader<? super S> reader) {
        return decodeEpochDays(source, reader) * Epoch.MILLIS_PER_DAY;
    }
    public <S> long decodeEpochMillis(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeEpochDays(source, reader, offset) * Epoch.MILLIS_PER_DAY;
    }

    public <S> long decodeEpochSeconds(final S source, final ByteReader<? super S> reader) {
        return decodeEpochDays(source, reader) * Epoch.SECONDS_PER_DAY;
    }
    public <S> long decodeEpochSeconds(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeEpochDays(source, reader, offset) * Epoch.SECONDS_PER_DAY;
    }

    public <S> long decodeEpochDays(final S source, final ByteReader<? super S> reader) {
        return decodeEpochDays(source, reader, 0);
    }
    public <S> long decodeEpochDays(final S source, final ByteReader<? super S> reader, final int offset) {
        final int year = decodeYear(source, reader, offset);
        final int month = decodeMonth(source, reader, offset);
        final int day = decodeDay(source, reader, offset);
        return (year == 0 & month == 0 & day == 0) ? 0 : Epoch.toEpochDays(year, month, day);
    }

    public <S> LocalDate decodeLocalDateOrNull(final S source, final ByteReader<? super S> reader) {
        return decodeLocalDateOrNull(source, reader, 0);
    }
    public <S> LocalDate decodeLocalDateOrNull(final S source, final ByteReader<? super S> reader, final int offset) {
        final int year = decodeYear(source, reader, offset);
        final int month = decodeMonth(source, reader, offset);
        final int day = decodeDay(source, reader, offset);
        return (year == 0 & month == 0 & day == 0) ? null : LocalDate.of(year, month, day);
    }

    public <S> int decodeYear(final S source, final ByteReader<? super S> reader) {
        return decodeYear(source, reader, 0);
    }
    public <S> int decodeYear(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetYear = offset + dateFormat.getOffsetYear();
        final byte byte0 = reader.readByte(source, offsetYear + 0);
        final byte byte1 = reader.readByte(source, offsetYear + 1);
        final byte byte2 = reader.readByte(source, offsetYear + 2);
        final byte byte3 = reader.readByte(source, offsetYear + 3);
        if (byte0 == 0 & byte1 == 0 & byte2 == 0 & byte3 == 0) {
            return 0;
        }
        return 1000 * digit(byte0) + 100 * digit(byte1) + 10 * digit(byte2) + digit(byte3);
    }

    public <S> int decodeMonth(final S source, final ByteReader<? super S> reader) {
        return decodeMonth(source, reader, 0);
    }
    public <S> int decodeMonth(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetMonth = offset + dateFormat.getOffsetMonth();
        final byte byte0 = reader.readByte(source, offsetMonth + 0);
        final byte byte1 = reader.readByte(source, offsetMonth + 1);
        if (byte0 == 0 & byte1 == 0) {
            return 0;
        }
        return 10 * digit(byte0) + digit(byte1);
    }

    public <S> int decodeDay(final S source, final ByteReader<? super S> reader) {
        return decodeDay(source, reader, 0);
    }
    public <S> int decodeDay(final S source, final ByteReader<? super S> reader, final int offset) {
        final int offsetDay = offset + dateFormat.getOffsetDay();
        final byte byte0 = reader.readByte(source, offsetDay + 0);
        final byte byte1 = reader.readByte(source, offsetDay + 1);
        if (byte0 == 0 & byte1 == 0) {
            return 0;
        }
        return 10 * digit(byte0) + digit(byte1);
    }

    public <S> int decodePacked(final LocalDatePacking packing, final S source, final ByteReader<? super S> reader) {
        return decodePacked(packing, source, reader, 0);
    }

    public <S> int decodePacked(final LocalDatePacking packing, final S source, final ByteReader<? super S> reader, final int offset) {
        return packing.pack(
                decodeYear(source, reader, offset),
                decodeMonth(source, reader, offset),
                decodeDay(source, reader, offset)
        );
    }

    /**
     * Returns the first delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter1(final S source, final ByteReader<? super S> reader) {
        return decodeDelimiter1(source, reader, 0);
    }
    /**
     * Returns the first delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @param offset the read offset
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter1(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeDelimiter(0, source, reader, offset);
    }

    /**
     * Returns the second delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter2(final S source, final ByteReader<? super S> reader) {
        return decodeDelimiter2(source, reader, 0);
    }
    /**
     * Returns the second delimiter, or {@link #NO_DELIMITER} if the format has no delimiters
     * @param source the source to read from
     * @param reader the reader reading from {@code source}
     * @param offset the read offset
     * @return the delimiter or {@link #NO_DELIMITER} if the format has no delimiters
     */
    public <S> char decodeDelimiter2(final S source, final ByteReader<? super S> reader, final int offset) {
        return decodeDelimiter(1, source, reader, offset);
    }
    private <S> char decodeDelimiter(final int index, final S source, final ByteReader<? super S> reader, final int offset) {
        final int position;
        switch (index) {
            case 0:
                position = dateFormat.getPositionDelimiter1();
                break;
            case 1:
                position = dateFormat.getPositionDelimiter2();
                break;
            default:
                //should not happen
                throw new IllegalArgumentException("Invalid delimiter index: " + index);
        }
        if (position < 0) {
            return NO_DELIMITER;
        }
        return (char)reader.readByte(source, offset + position);
    }

    private static final int digit(final byte character) {
        return character - '0';
    }
}
