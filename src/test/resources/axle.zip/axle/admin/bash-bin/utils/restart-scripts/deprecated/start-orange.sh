#!/bin/bash

echo "" | mailx -r "build.box@anz.com" -s "ORANGE ENV - starting all regions" "axletest@anz.com"

ssh axle@daxa011z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'
ssh AxlSv@daxa004z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'

ssh axle@daxa015z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'
ssh AxlSv@daxa004z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'

echo "" | mailx -r "build.box@anz.com" -s "ORANGE ENV - FINISHED starting all regions" "axletest@anz.com"
