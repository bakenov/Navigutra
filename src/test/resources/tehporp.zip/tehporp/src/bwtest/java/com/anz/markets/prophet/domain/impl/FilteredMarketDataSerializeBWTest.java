package com.anz.markets.prophet.domain.impl;

import com.anz.markets.prophet.MidRateTestHelper;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FilteredMarketDataSerializeBWTest extends MarketDataSerializeBWTest {
    private final FilteredMarketDataSnapshotImpl marketDataSnapshot;

    public FilteredMarketDataSerializeBWTest() {
        super();
        marketDataSnapshot = FilteredMarketDataSnapshotImpl.forAggBook();
        new ProphetMarshallableCopier()
                .copyIntoFilteredMarketData(
                        MidRateTestHelper.createMarketData(marketDataIncrement.getEventsList().size() / 2),
                        marketDataSnapshot
                );

        System.out.println("size of serialised  MDS=" + serialiseDeserialiseMarketDataSnapshotImpl());
        System.out.println("size of serialised FMDS=" + serialiseDeserialiseFilteredMarketDataSnapshotImpl());
    }

    @Test
    public void testSerialiseDeserialiseMarketDataSnapshotImpl() {
        counter = 0;
        helper.testAllocationNotExceeded(
                this::serialiseDeserialiseMarketDataSnapshotImpl,
                REPS, REPS,
                THRESHOLD
        );
    }

    private long serialiseDeserialiseMarketDataSnapshotImpl() {
        bytes1.writePosition(0);
        marketDataSnapshot.setEventId(IDS[counter++]);
        marketDataSnapshot.bytesMarshallableMarketDataSnapshot().writeMarshallable(bytes1);
        bytes1.readPosition(0);
        marketDataSnapshot.bytesMarshallableMarketDataSnapshot().readMarshallable(bytes1);
        return bytes1.position();
    }

    @Test
    public void testSerialiseDeserialiseFilteredMarketDataSnapshotImpl() {
        counter = 0;
        helper.testAllocationNotExceeded(
                this::serialiseDeserialiseFilteredMarketDataSnapshotImpl,
                REPS, REPS,
                THRESHOLD
        );
    }

    private long serialiseDeserialiseFilteredMarketDataSnapshotImpl() {
        bytes1.writePosition(0);
        marketDataSnapshot.setEventId(IDS[counter++]);
        marketDataSnapshot.writeMarshallable(bytes1);
        bytes1.readPosition(0);
        marketDataSnapshot.readMarshallable(bytes1);
        return bytes1.position();
    }
}
