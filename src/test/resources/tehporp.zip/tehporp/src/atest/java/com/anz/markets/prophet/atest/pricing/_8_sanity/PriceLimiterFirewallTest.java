package com.anz.markets.prophet.atest.pricing._8_sanity;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import org.junit.Test;

import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason="clear throttler")
@Requirement({Ref.PRICING_AXPROPHET_1121})
public class PriceLimiterFirewallTest extends BaseAcceptanceSpecification {

    @Test
    public void basic_limiter_test() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.THROTTLER_RATE_LIMIT_PER_SECONDS, 4))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.THROTTLER_RATE_LIMIT_MESSAGES_HIGH, 3))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.THROTTLER_RATE_LIMIT_MESSAGES_LOW, 2))
            );
        }
        when:
        // clientPrice published @t+0.5, @t+1sec, t+1.5sec, t+2sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.0101, 0.00008));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.0105, 0.00008));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.0102, 0.00008));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.0106, 0.00008));
        }
        then:
        {
            LinkedList<ClientPrice> cp = prophet.expect(ClientPrice.class, exactly(4), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < cp.size(); i++) {
                // Verify quote type at each level of book
                assertThat(cp.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(cp.get(i));
            }
        }
        when:
        // @t+3sec, chime evaluates and activates firewall
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // slidingWindow(3sec) count of 4 is ABOVE THROTTLER_RATE_LIMIT_MESSAGES_HIGH(3).
        // Push last sent price as indicative
        {
            LinkedList<ClientPrice> cp = prophet.expect(ClientPrice.class, exactly(4), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < cp.size(); i++) {
                // Verify quote type at each level of book
                assertThat(cp.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp.get(i), PricingFirewallType.RATE_LIMITER);
            }
            assertThat(cp.get(0).getMidRate(), is(1.0106));
        }
        when:
        // @t+3sec receive Client Price but since firewall ACTIVE do not publish
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.0103, 0.00008));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class);
        }
        when:
        // @t+4sec, chime evaluates slidingWindow(3sec) count of 5 which is not equal/below  THROTTLER_RATE_LIMIT_MESSAGES_LOW(2).
        // and since firewall is still active push last received client price as indicative
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            LinkedList<ClientPrice> cp = prophet.expect(ClientPrice.class, exactly(4), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < cp.size(); i++) {
                // Verify quote type at each level of book
                assertThat(cp.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp.get(i), PricingFirewallType.RATE_LIMITER);
            }
            assertThat(cp.get(0).getMidRate(), is(1.0103));
        }
        when:
        // @t+5sec, chime evaluates slidingWindow(4sec) count of 4 which is not equal/below  THROTTLER_RATE_LIMIT_MESSAGES_LOW(2).
        // and since firewall is still active push last received client price as indicative
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            LinkedList<ClientPrice> cp = prophet.expect(ClientPrice.class, exactly(4), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < cp.size(); i++) {
                // Verify quote type at each level of book
                assertThat(cp.get(i), new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp.get(i), PricingFirewallType.RATE_LIMITER);
            }
            assertThat(cp.get(0).getMidRate(), is(1.0103));
        }
        when:
        // @t+6sec, chime evaluates slidingWindow(4sec) count of 2 which is equal/below THROTTLER_RATE_LIMIT_MESSAGES_LOW(2).
        // Deactivate firewall so no need to publish any client price
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class);
        }
        when:
        // @t+6sec receive Client Price and since firewall is NOT active, able to push FIRM client price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 1.0105, 0.00008));
        }
        then:
        {
            LinkedList<ClientPrice> cp = prophet.expect(ClientPrice.class, exactly(4), isClientPriceInstrument(Instrument.AUDUSD));
            for (int i = 0; i < cp.size(); i++) {
                // Verify quote type at each level of book
                assertThat(cp.get(i), new QuoteTypeMatcher(QuoteType.FIRM));
                checkFirewallTriggered(cp.get(i));
            }
        }
    }
    
    @Test
    public void throttler_and_limiter_test() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.THROTTLER_RATE_LIMIT_PER_SECONDS, 3))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.THROTTLER_RATE_LIMIT_MESSAGES_HIGH, 3))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.THROTTLER_RATE_LIMIT_MESSAGES_LOW, 1))
            );
        }
        when:
        // @t+0.5 TWO marketDataSnapshot received
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCAD, 1.0101, 0.00008));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCAD, 1.0105, 0.00008));
        }
        then:
        // only ONE client price is PUBLISHABLE(and thus received by Limiter Firewall)
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A, Instrument.USDCAD));
            prophet.expect(ClientPrice.class, exactly(1), isThrottled(Market.WSP_A, Instrument.USDCAD));
        }
        when:
        // @t+1.0 chime pushes publishable price
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
        }
        then:
        // only one client price is PUBLISHABLE(and thus received by Limiter Firewall)
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A, Instrument.USDCAD));
        }
        when:
        // @t+1.5 marketDataSnapshot received
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCAD, 1.0102, 0.00008));
        }
        then:
        // client price is PUBLISHABLE(and thus is received by Limiter Firewall)
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A, Instrument.USDCAD));
        }
        when:
        // @t+2sec, chime evaluates and activates firewall
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // slidingWindow(3sec) count of 3(PUBLISHABLE client price) is NOT above THROTTLER_RATE_LIMIT_MESSAGES_HIGH(3).
        // Do not push last sent price as indicative
        // (If the THROTTLED client price(@t0) was included then LIMITER FIREWALL would have been enabled and pushed an indicative price)
        {
            prophet.notExpect(ClientPrice.class);
        }
        when:
        // @t+2sec, receive marketDataSnapshot
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCAD, 1.0100, 0.00008));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A, Instrument.USDCAD));
        }
        when:
        // @t+3sec, chime evaluates LIMIT FIREWALL
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
        }
        then:
        // LIMIT FIREWALL ACTIVATED so push last client price as INDICATIVE
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrumentAndMkt(Instrument.USDCAD, Market.WSP_A)).getLast();
            assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(cp, PricingFirewallType.RATE_LIMITER);
            assertThat(cp.getMidRate(), is(1.0100));
        }
    }
}