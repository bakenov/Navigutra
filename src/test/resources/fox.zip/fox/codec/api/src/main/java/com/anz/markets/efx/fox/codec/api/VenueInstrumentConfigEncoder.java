package com.anz.markets.efx.fox.codec.api;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageEncoder;

public interface VenueInstrumentConfigEncoder extends MessageEncoder<VenueInstrumentConfigEncoder.Body> {
    @Override
    Body messageStart(final int source, final long sourceSeq);

    interface Body {
        Body venue(Venue venue);
        Body instrumentId(long instrumentId);
        Body priceIncrement(double priceIncrement);
        Body sizeIncrement(int sizeIncrement);
        Body clipSizeMultiple(int clipSizeMultiple);
        Body maxAllowedParentOrderQty(double maxAllowedParentOrderQty);
        Body minClipSize(int minClipSize);
        Body maxClipSize(int maxClipSize);
        Body staleDataTimeout(int staleDataTimeout);
        Body priority(int priority);
        Body proportion(int proportion);
        Trailer enabled(boolean enabled);
    }
}
