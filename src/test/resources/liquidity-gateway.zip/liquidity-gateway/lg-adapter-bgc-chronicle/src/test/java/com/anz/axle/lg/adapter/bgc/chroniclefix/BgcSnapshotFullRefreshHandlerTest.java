package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.PriceRounder;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Quote;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingDecoders;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.google.common.collect.Sets;
import org.junit.Before;
import org.junit.Test;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class BgcSnapshotFullRefreshHandlerTest {

    private PriceRounder priceRounder;
    final private List<Quote> quotes = new ArrayList<>();
    private BgcSnapshotFullRefreshHandler handler;
    private MessageDecoder<PricingMessage> snapshotFullRefreshDecoder;

    @Before
    public void setUp() throws Exception {

        final Map<Integer, Set<String>> symbolDecimalPlaceToRound = new HashMap<>();
        symbolDecimalPlaceToRound.put(3, Sets.newHashSet("EURJPY", "USDJPY", "EURHUF"));
        priceRounder = new PriceRounder(symbolDecimalPlaceToRound, 5);

        quotes.clear();
        final FixMessageSender fixMessageSender = new FixMessageSender(() -> null) {
            @Override
            public void accept(final StandardHeaderTrailer message) {
                quotes.add((Quote) message);
            }
        };
        handler = new BgcSnapshotFullRefreshHandler(priceRounder, new DefaultInstrumentKeyLookup(), fixMessageSender);
        snapshotFullRefreshDecoder = new PojoPricingDecoders().snapshotFullRefresh().create(handler, MessageDecoder.ForwardingLookup.noop());
    }

    @Test
    public void round_price_to_3_decimal_place() throws Exception {
        // given
        final InstrumentKey instrumentKey = InstrumentKey.of("EURJPY", SecurityType.FXSPOT, Tenor.SP);
        final SnapshotFullRefresh fullRefresh = new SnapshotFullRefresh();
        fullRefresh.body.instrumentId = instrumentKey.instrumentId();
        fullRefresh.body.sendingTime = 0;

        fullRefresh.entries.add(createEntry(EntryType.BID, 0.12345d, 1.0d));
        fullRefresh.entries.add(createEntry(EntryType.OFFER, 0.13345d, 2.0d));

        // when
        snapshotFullRefreshDecoder.decode(fullRefresh);

        // then
        assertThat(quotes.size(), is(1));
        final Quote quote = quotes.get(0);
        assertThat(quote.symbol(), is("EUR/JPY"));
        assertThat(quote.bidPx(), is(0.123d));
        assertThat(quote.bidSize(), is(1.0d));
        assertThat(quote.offerPx(),is(0.134d));
        assertThat(quote.offerSize(), is(2.0d));
    }

    @Test
    public void round_price_to_default_5_decimal_place() throws Exception {
        final InstrumentKey instrumentKey = InstrumentKey.of("USDAUD", SecurityType.FXSPOT, Tenor.SP);

        final SnapshotFullRefresh fullRefresh = new SnapshotFullRefresh();
        fullRefresh.body.instrumentId = instrumentKey.instrumentId();
        fullRefresh.body.sendingTime = 0;

        fullRefresh.entries.add(createEntry(EntryType.BID, 0.12345678d, 1.0d));
        fullRefresh.entries.add(createEntry(EntryType.OFFER, 0.12345678d, 2.0d));

        // when
        snapshotFullRefreshDecoder.decode(fullRefresh);

        // then
        assertThat(quotes.size(), is(1));
        final Quote quote = quotes.get(0);
        assertThat(quote.symbol(), is("USD/AUD"));
        assertThat(quote.bidPx(), is(0.12345d));
        assertThat(quote.offerPx(),is(0.12346d));
    }

    private SnapshotFullRefresh.Entry createEntry(final EntryType type, final double price, final double size) {
        final SnapshotFullRefresh.Entry entry =  new SnapshotFullRefresh.Entry();
        entry.mdEntryFlags = EnumSet.noneOf(Flag.class);
        entry.mdEntryType = type;
        entry.mdEntryPx = price;
        entry.mdEntrySize = size;
        return entry;
    }
}