package com.anz.axle.adapters.ndf2trep.publisher;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.jetbrains.annotations.TestOnly;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;

public class RicRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(RicRepository.class);
    private final InstrumentCache instrumentCache = new InstrumentCache();
    private final Map<String, Map<String, String>> ndfTrepInstrumentToTenorRicMap;
    private final Map<String, String> venueServiceNames;
    private final Map<String, List<String>> serviceNameRicMap;
    private final Set<String> topicNames;
    private final String serviceName;
    private Venue venueSubscribe;

    public RicRepository(final Map<String, Set<String>> symbolVenuesFXSPOT,
                         final Map<String, Map<String, Set<String>>> venueSymbolTenorsFXNDF,
                         final Map<String, String> venueSubscriptionSourceId,
                         final Map<String, String> venuePublishSourceId,
                         final Map<String, String> venuePublishServiceNames,
                         final String serviceName) {

        Objects.requireNonNull(symbolVenuesFXSPOT, "NULL symbolVenuesFXSPOT");
        Objects.requireNonNull(venueSymbolTenorsFXNDF, "NULL venueSymbolTenorsFXNDF");
        Objects.requireNonNull(venueSubscriptionSourceId, "NULL venueSubscriptionSourceId");
        Objects.requireNonNull(venuePublishSourceId, "NULL venuePublishSourceId");
        Objects.requireNonNull(venuePublishServiceNames, "NULL venuePublishServiceNames");

        this.venueServiceNames = venuePublishServiceNames;
        this.serviceName = serviceName;
        this.ndfTrepInstrumentToTenorRicMap = new HashMap<>();
        this.serviceNameRicMap = new HashMap<>();
        this.topicNames = new HashSet<>();

        setConfiguredVenue(venuePublishServiceNames);
        initFxSpot(symbolVenuesFXSPOT, venueSubscriptionSourceId, venuePublishSourceId);
        initFxNdf(venueSymbolTenorsFXNDF, venueSubscriptionSourceId, venuePublishSourceId);

        LOGGER.info("loaded: {}", ndfTrepInstrumentToTenorRicMap);
    }

    private void setConfiguredVenue(Map<String, String> venuePublishServiceNames) {
        venuePublishServiceNames.forEach((k, v) -> {
            if (venueSubscribe == null && v.equals(serviceName)) {
                venueSubscribe = Venue.valueOf(k);
            }
        });
        if (venueSubscribe == null) {
            LOGGER.warn("Venue to subscribe is null: serviceName={}, venuePublishServiceNames={}", serviceName, venuePublishServiceNames);
        }
    }

    private void initFxSpot(final Map<String, Set<String>> symbolVenuesFXSPOT,
                            final Map<String, String> venueSubscriptionSourceId,
                            final Map<String, String> venuePublishSourceId) {
        symbolVenuesFXSPOT.forEach((symbol, venues) -> {
            venues.forEach(venue -> {
                if (venuePublishSourceId.containsKey(venue) && venueServiceNames.containsKey(venue)) {
                    final String instrument = instrumentCache.lookup(SecurityType.FXSPOT, venue, symbol);
                    final String sourceId = venuePublishSourceId.get(venue).trim();
                    final String serviceName = venueServiceNames.get(venue).trim();
                    final String ric = symbol.trim() + "=" + sourceId;

                    if (serviceName.equals(this.serviceName)) {
                        ndfTrepInstrumentToTenorRicMap.computeIfAbsent(instrument, (i) -> new HashMap<>()).put(Tenor.SP.toString(), ric);

                        serviceNameRicMap.computeIfAbsent(serviceName, (id) -> new ArrayList<>()).add(ric);

                        final String topic = createTopicName(instrument, venue, venueSubscriptionSourceId);
                        topicNames.add(topic);
                    }
                    else {
                        LOGGER.info("Ignoring symbol/venue config: {}/{} due to param: ndf.trep.publish.destination.servicename OR vmarg: venue.publish NOT specified/relevant.  {}", symbol, venue, this.serviceName);
                    }
                }
                else {
                    LOGGER.info("Ignoring symbol/venue config: {}/{} due to venue.publish.sourceId OR venue.publish.serviceName NOT specified", symbol, venue);
                }
            });
        });
    }

    private void initFxNdf(final Map<String, Map<String, Set<String>>> venueSymbolTenorsFXNDF,
                           final Map<String, String> venueSubscriptionSourceId,
                           final Map<String, String> venuePublishSourceId) {
        venueSymbolTenorsFXNDF.forEach((venue, symbolTenors) -> {
            symbolTenors.forEach((symbol, tenors) -> {
                tenors.forEach(tenor -> {
                    if (venuePublishSourceId.containsKey(venue) && venueServiceNames.containsKey(venue)) {
                        final String instrument = instrumentCache.lookup(SecurityType.FXNDF, venue, symbol);
                        final String[] keyValue = tenor.split(":");
                        Assert.isTrue(keyValue.length == 2, "TENOR key/value pair not found");

                        final String keyTenor = keyValue[0].trim();
                        final String valueTenor = keyValue[1].trim();
                        Assert.notNull(Tenor.valueOf(keyTenor), keyTenor + " NOT a valid tenor");

                        final String sourceId = venuePublishSourceId.get(venue).trim();
                        final String serviceName = venueServiceNames.get(venue).trim();
                        final String ric = valueTenor + "=" + sourceId;

                        if (serviceName.equals(this.serviceName)) {
                            ndfTrepInstrumentToTenorRicMap.computeIfAbsent(instrument, (i) -> new HashMap<>());
                            ndfTrepInstrumentToTenorRicMap.get(instrument).put(keyTenor, ric);

                            serviceNameRicMap.computeIfAbsent(serviceName, (id) -> new ArrayList<>());
                            serviceNameRicMap.get(serviceName).add(ric);

                            final String topic = createTopicName(instrument, venue, venueSubscriptionSourceId);
                            topicNames.add(topic);
                        }
                        else {
                            LOGGER.info("Ignoring symbol/venue config: {}/{}/{} due to param: ndf.trep.publish.destination.servicename OR vmarg: venue.publish NOT specified/relevant.  {}", symbol, venue, tenor, this.serviceName);
                        }
                    }
                    else {
                        LOGGER.info("Ignoring symbol/venue/tenor config: {}/{}/{} due to venue.publish.sourceId OR venue.publish.serviceName NOT specified", symbol, venue, tenor);
                    }
                });
            });
        });
    }

    private String getInstrument(String symbol, String venue, SecurityType type) {
        return instrumentCache.lookup(type, venue, symbol);
    }

    public String getSpotConfiguredInstrument(String symbol) {
        return getInstrument(symbol, venueSubscribe.name(), SecurityType.FXSPOT);
    }

    private String createTopicName(String instrument, String venue, final Map<String, String> venueSubscriptionSourceId) {
        return instrument +
                (venueSubscriptionSourceId.containsKey(venue) && !venueSubscriptionSourceId.get(venue).trim().isEmpty() ? "_" + venueSubscriptionSourceId.get(venue).trim() : "");
    }

    public Set<String> getTopicNames() {
        return topicNames;
    }

    public Collection<String> getRicNames(String serviceName) {
        return serviceNameRicMap.getOrDefault(serviceName, new ArrayList<>());
    }

    public String getRicName(final String instrument, final String tenor){
        final Map<String, String> tenorRicMap = ndfTrepInstrumentToTenorRicMap.get(instrument);
        return tenorRicMap != null ? tenorRicMap.get(tenor) : null;
    }

    public String getServiceName() {
        return serviceName;
    }

    @TestOnly
    public Set<String> getInstruments() {
        return ndfTrepInstrumentToTenorRicMap.keySet();
    }
}
