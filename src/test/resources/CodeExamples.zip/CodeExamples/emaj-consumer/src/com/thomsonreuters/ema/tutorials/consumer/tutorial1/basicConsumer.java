/*
	basicConsumer - tutorial1 - Creating a barebones EMA consumer application

	This tutorial is the first part in a series of tutorials with the goal of creating a basic consumer application.
	
	The goal of this tutorial is to create a barebones consumer shell interface allowing us to structure and explain 
	functionality within subsequent tutorials. In addition, setup a Java build environment to successfully build and 
	run our basic EMA Java application

	The series includes the following:

		o Tutorial 1 - Creating a barebones EMA consumer application
		o Tutorial 2 - Requesting and displaying MarketPrice data
		o Tutorial 3 - Parsing and Decoding MarketPrice data
		o Tutorial 4 - Requesting, parsing and decoding Level 2 data
		o Tutorial 5 - Dispatching messages within the user thread
 */

package com.thomsonreuters.ema.tutorials.consumer.tutorial1;

import com.thomsonreuters.ema.access.Msg;
import com.thomsonreuters.ema.access.AckMsg;
import com.thomsonreuters.ema.access.GenericMsg;
import com.thomsonreuters.ema.access.RefreshMsg;
import com.thomsonreuters.ema.access.ReqMsg;
import com.thomsonreuters.ema.access.StatusMsg;
import com.thomsonreuters.ema.access.UpdateMsg;
import com.thomsonreuters.ema.access.EmaFactory;
import com.thomsonreuters.ema.access.OmmConsumer;
import com.thomsonreuters.ema.access.OmmConsumerClient;
import com.thomsonreuters.ema.access.OmmConsumerConfig;
import com.thomsonreuters.ema.access.OmmConsumerEvent;
import com.thomsonreuters.ema.access.OmmException;

// basicConsumer
// The basicConsumer interface manages all control for the consumption of real-time data.  Implementing the
// EMA interface: OmmConsumerClient, we now have the opportunity to capture multiple, realtime events to 
// process the different types of messages we can receive once we subscribe to a market data item.  The
// interface below implements a number of required callbacks to achieve this goal.
//
public class basicConsumer implements OmmConsumerClient
{
	//*************************************************************************************************
	// Callback methods required by the OmmConsumerClient Interface.
	//
	// The following methods allow us to capture realtime events such as status and data events.  The
	// relevant events will be implemented and described in subsequent tutorials.
	//*************************************************************************************************
	public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event){}
	public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event){}
	public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event){}	
	public void onAllMsg(Msg msg, OmmConsumerEvent consumerEvent){}
	public void onAckMsg(AckMsg ackMsg, OmmConsumerEvent consumerEvent){}
	public void onGenericMsg(GenericMsg genericMsg, OmmConsumerEvent consumerEvent){}

	//*************************************************************************************************
	// main
	// Application entry point to manage the life of the consumer.
	//
	//*************************************************************************************************
	public static void main(String[] args)
    {
		// Main interface to manage all consumer communication to our Provider
        basicConsumer basicConsumer = new basicConsumer();
		
		// Done processing
		System.out.print("Processing complete");		
    }	
}
