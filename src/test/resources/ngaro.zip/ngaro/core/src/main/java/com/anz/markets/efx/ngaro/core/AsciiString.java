package com.anz.markets.efx.ngaro.core;

/**
 * Byte value string considering 0 bytes as termination characters.
 */
public interface AsciiString extends Comparable<AsciiString>, CharSequence {
    /** Null byte, first such character marks end of string*/
    byte NULL = 0;
    ImmutableAsciiString EMPTY = new ImmutableAsciiString(new byte[0]);

    int length();

    /**
     * Returns the byte at the specified index. Note that reading beyond {@link #length()} can either lead to an
     * {@link IndexOutOfBoundsException} or also return {@link #NULL} depending on the implementation.
     *
     * @param index the index
     * @return the character at the specified index, or sometimes {@link #NULL} if {@code index >= length}
     * @throws IndexOutOfBoundsException Always if {@code index < 0} or also possible (but not necessarily) if
     *                                  {@code index >= length}
     */
    byte get(int index);
    /** @return the length of the read string*/
    <T> int get(T target, ByteWriter<? super T> writer, int offset, int maxLength);

    @Garbage(Garbage.Type.RESULT)
    String toString();

    @Garbage(Garbage.Type.RESULT)
    default String toStringOrNull() {
        return length() == 0 ? null : toString();
    }

    default boolean isEmpty() {
        return length() == 0;
    }

    default boolean contains(final AsciiString other) {
        return indexOf(other) >= 0;
    }

    default int indexOf(final AsciiString other) {
        return indexOf(other, 0);
    }

    default int indexOf(final AsciiString other, final int fromIndex) {
        //see String.indexOf(..)
        final int thisLen = length();
        final int otherLen = other.length();
        if (fromIndex >= thisLen) {
            return (otherLen == 0 ? thisLen : -1);
        }
        final int thisStart = fromIndex < 0 ? 0 : fromIndex;
        if (otherLen == 0) {
            return thisStart;
        }
        final byte first = other.get(0);
        final int max = thisLen - otherLen;
        for (int i = thisStart; i <= max; i++) {
            /* Look for first byte */
            if (get(i) != first) {
                while (++i <= max && get(i) != first);
            }
            /* Found first character, now look at the rest of v2 */
            if (i <= max) {
                int j = i + 1;
                final int end = j + otherLen - 1;
                for (int k = 0 + 1; j < end && get(j) == other.get(k); j++, k++);
                if (j == end) {
                    /* Found whole string. */
                    return i;
                }
            }
        }
        return -1;
    }

    default char charAt(final int index) {
        return (char)get(index);
    }

    @Garbage(Garbage.Type.RESULT)
    default AsciiString subSequence(int start, int end) {
        if (start < 0) {
            throw new IndexOutOfBoundsException("Negative start index: " + start);
        }
        if (start > end) {
            throw new IndexOutOfBoundsException("start index larger than end index: " + start + " > " + end);
        }
        final int length = length();
        if (end > length) {
            throw new IndexOutOfBoundsException("end index greater than length: " + end + " > " + length);
        }
        if (start == 0 & end == length) {
            return this;
        }
        if (start == end) {
            return ImmutableAsciiString.EMPTY;
        }
        final byte[] bytes = new byte[end - start];
        for (int i = start; i < end; i++) {
            bytes[i - start] = get(i);
        }
        return new ImmutableAsciiString(bytes);
    }

    @Override
    default int compareTo(final AsciiString o) {
        return compare(this, o);
    }

    default int compareTo(final CharSequence o) {
        return compare(this, o);
    }

    static int hashCode(final AsciiString s) {
        final int len = s.length();
        int hash = 0;
        for (int i = 0; i < len; i++) {
            hash = 31 * hash + s.get(i);
        }
        return hash;
    }

    static int compare(final AsciiString s1, final AsciiString s2) {
        final int len1 = s1.length();
        final int len2 = s2.length();
        final int minLen = Math.min(len1, len2);
        for (int i = 0; i < minLen; i++) {
            final int cmp = Byte.compare(s1.get(i), s2.get(i));
            if (cmp != 0) {
                return cmp;
            }
        }
        if (len1 < len2) {
            return -1;
        }
        if (len1 > len2) {
            return +1;
        }
        return 0;
    }

    static int compare(final CharSequence s1, final CharSequence s2) {
        final int len1 = s1.length();
        final int len2 = s2.length();
        final int minLen = Math.min(len1, len2);
        for (int i = 0; i < minLen; i++) {
            final int cmp = Character.compare(s1.charAt(i), s2.charAt(i));
            if (cmp != 0) {
                return cmp;
            }
        }
        if (len1 < len2) {
            return -1;
        }
        if (len1 > len2) {
            return +1;
        }
        return 0;
    }

    @Garbage(Garbage.Type.RESULT)
    static ImmutableAsciiString immutable(final String s) {
        return s.isEmpty() ? EMPTY : new ImmutableAsciiString(s);
    }

    @Garbage(Garbage.Type.RESULT)
    static ImmutableAsciiString immutable(final CharSequence s) {
        return s.length() == 0 ? EMPTY : new ImmutableAsciiString(s);
    }

    @Garbage(Garbage.Type.RESULT)
    static FixedLengthAsciiString fixedLength(final int length) {
        return new FixedLengthAsciiString(length);
    }

    @Garbage(Garbage.Type.RESULT)
    static ExpandableAsciiString expandable() {
        return new ExpandableAsciiString();
    }

    @Garbage(Garbage.Type.RESULT)
    static ExpandableAsciiString expandable(final int initialCapacity) {
        return new ExpandableAsciiString(initialCapacity);
    }

}
