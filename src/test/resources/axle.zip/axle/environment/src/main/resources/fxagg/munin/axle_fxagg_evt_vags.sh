#!/bin/bash
# (c) 2016 ANZ

TITLE="Correlator Event Metrics (VAGs)"
CORNAMES="VAG1|VAG2"
#COLORS1="blue|pink"
#COLORS2="dark blue|purple"
COLORS1="5DA5DA|F17CB0"
COLORS2="004D99|B276B2"
LOGDIRS="vag1fxagg|vag2fxagg"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_evt.common