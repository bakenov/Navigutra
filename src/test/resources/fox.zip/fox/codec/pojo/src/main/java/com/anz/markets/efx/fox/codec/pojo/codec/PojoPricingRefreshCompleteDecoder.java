package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoPricingRefreshCompleteDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends PricingRefreshCompleteHandler> handlerSupplier;

    public PojoPricingRefreshCompleteDecoder(final Supplier<? extends PricingRefreshCompleteHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof PricingRefreshComplete) {
            return decode((PricingRefreshComplete) sorMessage);
        }
        return false;
    }

    public boolean decode(final PricingRefreshComplete message) {
        final PricingRefreshCompleteHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source, message.header.sourceSeq);
        handler.onBody(new PricingRefreshCompleteHandler.Body() {
            @Override
            public long instrumentId() {
                return message.body.instrumentId;
            }

            @Override
            public boolean forceSnapshot() {
                return message.body.forceSnapshot;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoPricingRefreshCompleteDecoder() {
        throw new RuntimeException("No PojoPricingRefreshCompleteDecoder for you!");
    }
}
