function rm_old_logs {
rm *-0*.log
rm *-0*.dat
rm *-1*.log
rm *-1*.dat
rm *.log.*
rm .*.log.*
}

function clean_olddeployments_logsarchive {
cd ~/axle/
rm -rf *-2.0.*
rm -rf *-2.1.*
rm -rf *-3.0.*
rm -rf *-3.1.*
rm -rf *-3.2.*
rm axle-env-*

cd ~/archive/logs
rm -rf previous*
rm -rf 2012*

}


function clean_olddata_proxybroker {

cd ~/apache-tomcat-6.0.26-fxadmin/bin
rm core
rm_old_logs
cd ~/apache-tomcat-6.0.26-fxadmin/logs
rm_old_logs

cd ~/apache-tomcat/logs
rm core
rm_old_logs
cd ~/apache-tomcat/bin
rm_old_logs


clean_olddeployments_logsarchive
}


function clean_olddata_correlator {

cd ~/axle/logs
rm_old_logs

cd ~/logs/datafabric
rm_old_logs

clean_olddeployments_logsarchive 
}


function cleanstp_olddeployments {
cd /app/axle/axle
rm -rf *-2.0.*
rm -rf *-2.1.*
rm -rf *-3.0.*
rm -rf *-3.1.*
rm -rf *-3.2.*
rm axle-env-*

}

function clean_olddata_correlator_proxybroker {

cd ~/axle/logs
rm_old_logs

cd ~/logs/datafabric
rm_old_logs


cd ~/apache-tomcat-6.0.26-fxadmin/bin
rm core
rm_old_logs
cd ~/apache-tomcat-6.0.26-fxadmin/logs
rm_old_logs

cd ~/apache-tomcat/logs
rm core
rm_old_logs
cd ~/apache-tomcat/bin
rm_old_logs


clean_olddeployments_logsarchive
}


function clean_olddata_stp {
cleanstp_olddeployments

}

function clean_olddata_spdee {
clean_olddeployments

}


echo " "
echo "EXECUTING:" $1 
hostname           
echo " "
$1

sleep 2    
echo " "
echo "AFTER CLEANUP:"
hostname
df -h | grep apama
echo " "
