package com.anz.markets.efx.fox.aggregator.core;

import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;

@FunctionalInterface
public interface TopicRegistry {
    /**
     * Returns a topic by market and 7 character symbol, such as {@code topic("EBS", "AUD/USD"}. Throws an exception if
     * no such topic exists.
     *
     * @param market the market
     * @param instrumentKey the symbol such as "AUDUSD" or "AUD/USD"; symbols for FXNDF can be ANZ or standard
     * @return the topic for this market and symbol
     * @throws IllegalArgumentException if no such topic exists
     */
    Topic topic(Venue market, InstrumentKey instrumentKey);
}
