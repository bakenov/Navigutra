package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.MessageSource;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.prophet.domain.LongHolder;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.marketdata.InstrumentAndMarket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.util.HashMap;

public class LogMessageTypesModule extends AbstractModule {

    private final Logger log = LoggerFactory.getLogger(LogMessageTypesModule.class);

    private final HashMap<Symbol, LongHolder> counts = new HashMap<>();
    private final HashMap<Symbol, EnumObjMap<Market, LongHolder>> marketCounts = new HashMap<>();

    private final int N = 3;

    private final MessageSource messageSource;


    public LogMessageTypesModule(final MessageSource messageSource) {
        super(LogMessageTypesModule.class.getSimpleName() + "_" + messageSource.name());
        this.messageSource = messageSource;
    }

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.subAnyPrior(this::consumeAnyMessage);
    }

    private void consumeAnyMessage(Symbol messageType, Object message) {
        if (getStage().getMessageBus().getMessageSource() == messageSource) {
            long n = counts.computeIfAbsent(messageType, s -> new LongHolder()).value++;
            if (n <= N) {
                log.info("[{}] Received {} {} message: {}.", getStage().getName(), messageSource.name(), messageType, message);
            }

            if (message instanceof InstrumentAndMarket) {
                final Market market = ((InstrumentAndMarket) message).getMarket();
                marketCounts.computeIfAbsent(messageType, s -> new EnumObjMap<>(Market.class)).computeIfAbsent(market, s -> new LongHolder()).value++;
            }
        }
    }

    @Override
    public void finish() {
        final DecimalFormat intf = new DecimalFormat("#,###");

        counts.forEach((symbol, count) -> {
            log.info("[{}] Total {} {} {} messages received.", getStage().getName(), messageSource.name(), intf.format(count.value), symbol);

            if (marketCounts.containsKey(symbol)) {
                marketCounts.get(symbol).forEach((market, count2) -> {
                    int pct = (int) Math.round(100 * count2.value / (double) count.value);
                    log.info("[{}]     {} {} ({}%)", getStage().getName(), intf.format(count2.value), market, pct);
                });
            }
        });
    }
}
