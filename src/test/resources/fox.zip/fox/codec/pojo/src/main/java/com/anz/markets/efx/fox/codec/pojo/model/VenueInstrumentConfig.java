package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoVenueInstrumentConfigHandler;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class VenueInstrumentConfig implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public VenueInstrumentConfig() {
        this(new MessageHeader(), new Body());
    }

    public VenueInstrumentConfig(final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
    }

    public static final class Body {
        public Venue venue;
        public long instrumentId;
        public double priceIncrement;
        public int sizeIncrement;
        public int clipSizeMultiple;
        public double maxAllowedParentOrderQty;
        public int minClipSize;
        public int maxClipSize;
        public int staleDataTimeout;
        public int priority;
        public int proportion;
        public boolean enabled;

        public Body() {
            super();
        }

        public Body(final Venue venue,
                    final long instrumentId,
                    final double priceIncrement,
                    final int sizeIncrement,
                    final int clipSizeMultiple,
                    final double maxAllowedParentOrderQty,
                    final int minClipSize,
                    final int maxClipSize,
                    final int staleDataTimeout,
                    final int priority,
                    final int proportion,
                    final boolean enabled) {
            this.venue = venue;
            this.instrumentId = instrumentId;
            this.priceIncrement = priceIncrement;
            this.sizeIncrement = sizeIncrement;
            this.clipSizeMultiple = clipSizeMultiple;
            this.maxAllowedParentOrderQty = maxAllowedParentOrderQty;
            this.minClipSize = minClipSize;
            this.maxClipSize = maxClipSize;
            this.staleDataTimeout = staleDataTimeout;
            this.priority = priority;
            this.proportion = proportion;
            this.enabled = enabled;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "venue=" + venue +
                    ", instrumentId=" + instrumentId +
                    ", priceIncrement=" + priceIncrement +
                    ", sizeIncrement=" + sizeIncrement +
                    ", clipSizeMultiple=" + clipSizeMultiple +
                    ", maxAllowedParentOrderQty=" + maxAllowedParentOrderQty +
                    ", minClipSize=" + minClipSize +
                    ", maxClipSize=" + maxClipSize +
                    ", staleDataTimeout=" + staleDataTimeout +
                    ", priority=" + priority +
                    ", proportion=" + proportion +
                    ", enabled=" + enabled +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "InstrumentConfig{" +
                "header=" + header +
                "body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.venueInstrumentConfig());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.venueInstrumentConfig().create(messageConsumer));
    }

    public void encode(final VenueInstrumentConfigEncoder encoder) {
        encoder.messageStart(header.source,header.sourceSeq)
                .venue(body.venue)
                .instrumentId(body.instrumentId)
                .priceIncrement(body.priceIncrement)
                .sizeIncrement(body.sizeIncrement)
                .clipSizeMultiple(body.clipSizeMultiple)
                .maxAllowedParentOrderQty(body.maxAllowedParentOrderQty)
                .minClipSize(body.minClipSize)
                .maxClipSize(body.maxClipSize)
                .staleDataTimeout(body.staleDataTimeout)
                .priority(body.priority)
                .proportion(body.proportion)
                .enabled(body.enabled)
                .messageComplete();
    }

    public static <M> VenueInstrumentConfig decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoVenueInstrumentConfigHandler handler = new PojoVenueInstrumentConfigHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.venueInstrumentConfig().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onVenueInstrumentConfig(this);
    }
}
