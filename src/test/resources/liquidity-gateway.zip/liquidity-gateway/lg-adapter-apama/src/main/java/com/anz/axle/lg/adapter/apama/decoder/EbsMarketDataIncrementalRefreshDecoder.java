package com.anz.axle.lg.adapter.apama.decoder;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.apama.event.Event;

import com.anz.axle.lg.adapter.apama.event.EbsMarketDataIncrementalRefresh;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static com.anz.axle.lg.adapter.apama.decoder.EbsMarketDataEntries.hasNoMarket;
import static com.anz.axle.lg.adapter.apama.decoder.FixStringConstants.SENDING_TIME;
import static com.anz.axle.lg.adapter.apama.decoder.MarketDataEntriesEncoder.encodeIncrementalEntries;
import static com.anz.axle.lg.adapter.apama.decoder.MarketDataEntriesEncoder.encodeZeroEntriesForEmptySnapshot;

/**
 * Decodes Apama events as defined by {@link EbsMarketDataIncrementalRefresh}
 */
public final class EbsMarketDataIncrementalRefreshDecoder implements ApamaEventDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsMarketDataIncrementalRefreshDecoder.class);

    private final Function<Event, RequestKey> entryEventToRequestKey;
    private final BiPredicate<RequestKey, Event> entryEventRequestKeyMatcher;
    private final BiPredicate<RequestKey, Event> entryEventRequestKeyBidOrAskMatcher;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdSupplier;
    private final SourceSequencer sourceSequencer;

    public EbsMarketDataIncrementalRefreshDecoder(final Function<Event, RequestKey> entryEventToRequestKey,
                                                  final BiPredicate<RequestKey, Event> entryEventRequestKeyMatcher,
                                                  final PricingEncoderLookup pricingEncoderLookup,
                                                  final PrecisionClock precisionClock,
                                                  final String senderCompId,
                                                  final String compId,
                                                  final LongSupplier messageIdSupplier,
                                                  final SourceSequencer sourceSequencer) {
        this.entryEventToRequestKey = Objects.requireNonNull(entryEventToRequestKey);
        this.entryEventRequestKeyMatcher = Objects.requireNonNull(entryEventRequestKeyMatcher);
        this.senderCompId = senderCompId;
        this.compId = compId;
        this.messageIdSupplier = messageIdSupplier;
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
        this.entryEventRequestKeyBidOrAskMatcher = this.entryEventRequestKeyMatcher.and((requestKey, event) -> MdEntries.isBidOrOffer(event));
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    @Override
    public void decode(final Event ebsIncrement) {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("Apama event received: {}", ebsIncrement);

        // Only process Price Depth View messages
        if (!EbsMarketDataIncrementalRefresh.FIELD_SERVICE_ID.isPriceDepthView(ebsIncrement)) {
            return;
        }

        final List<Event> mdEntries = ebsIncrement.getField(EbsMarketDataIncrementalRefresh.FIELD_MD_NO_ENTRIES);
        final Map<String, String> payload = ebsIncrement.getField(EbsMarketDataIncrementalRefresh.FIELD_PAYLOAD);
        final long sendingTimeNanos = UtcTimestampConverter.dateTimeToNanos(payload.get(SENDING_TIME));

        int index = 0;
        while (index < mdEntries.size()) {
            index = encodeCurrentRequestKeyAndReturnNextRequestKeyIndex(mdEntries, index, sendingTimeNanos, receivingTimeNanos);
        }
    }

    private int encodeCurrentRequestKeyAndReturnNextRequestKeyIndex(final List<Event> mdEntries,
                                                                    final int startIndex,
                                                                    final long sendingTimeNanos,
                                                                    final long receivingTimeNanos) {
        final Event mdEntry = mdEntries.get(startIndex);
        final RequestKey requestKey = entryEventToRequestKey.apply(mdEntry);
        if (requestKey == null) {
            //invalid symbol, skip the entry
            return startIndex + 1;
        } else {

            final PricingEncoderSupplier encoderSupplier = pricingEncoderLookup.lookup(requestKey);
            if (hasNoMarket(requestKey, mdEntries, startIndex, entryEventRequestKeyBidOrAskMatcher)) {
                encodeZeroEntriesForEmptySnapshot(encoderSupplier, Flag.NO_MARKET, requestKey, sendingTimeNanos, receivingTimeNanos, senderCompId, compId, messageIdSupplier.getAsLong(), precisionClock, sourceSequencer);
            } else {
                final int sizeOfCurrentSnapshot = pricingEncoderLookup.sizeOfCurrentSnapshot(requestKey);
                encodeIncrementalEntries(encoderSupplier, requestKey, mdEntries, startIndex,
                        entryEventRequestKeyBidOrAskMatcher, sendingTimeNanos, receivingTimeNanos, sizeOfCurrentSnapshot, senderCompId, compId, messageIdSupplier, precisionClock, sourceSequencer);
            }
            return forwardToNextRequestKey(mdEntries, requestKey, startIndex);
        }
    }


    private boolean hasRequestKeyOccurredFirstTime(final List<Event> mdEntries,
                                                   final int endIndex,
                                                   final RequestKey requestKey) {
        for (int i = 0; i <= endIndex; i++) {
            if (entryEventRequestKeyMatcher.test(requestKey, mdEntries.get(i))) {
                return false;
            }
        }
        return true;
    }

    private int forwardToNextRequestKey(final List<Event> mdEntries,
                                        final RequestKey requestKeyAtStartIndex,
                                        final int startIndex) {
        for (int i = startIndex + 1; i < mdEntries.size(); i++) {
            final Event entry = mdEntries.get(i);
            final RequestKey requestKey = entryEventToRequestKey.apply(entry);
            if (requestKey != null) {
                if (!requestKeyAtStartIndex.equals(requestKey) &&
                        hasRequestKeyOccurredFirstTime(mdEntries, startIndex, requestKey)) {
                    return i;
                }
            }
        }
        return mdEntries.size();
    }
}
