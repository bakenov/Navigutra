package com.anz.markets.efx.fox.processor.state.usersession;

import java.util.function.Consumer;
import java.util.function.ToIntFunction;

import org.agrona.collections.MutableReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.api.domain.UserSessionKey;
import com.anz.markets.efx.fox.codec.api.Region;
import com.anz.markets.efx.fox.processor.timer.Timer;
import com.anz.markets.efx.fox.processor.timer.TimerScheduler;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DefaultUserSessionTest {
    @Mock
    private Consumer<UserSessionKey> onGoingOnlineHandler;
    @Mock
    private Consumer<UserSessionKey> onGoingOfflineHandler;
    @Mock
    private ToIntFunction onlinePortfolioSessionsLookup;
    @Mock
    private Timer timer;

    private int missingHeartbeatTimeoutMillis = 1000;

    private MutableReference<TimerScheduler.ExpiryHandler> expiryHandlerRef = new MutableReference<>();
    private Timer.Factory timerFactory = expiryHandler -> {
        expiryHandlerRef.set(expiryHandler);
        return timer;
    };

    private UserSessionKey key = UserSessionKey.of("id1", "user1", "XEFX", Region.GB);
    private DefaultUserSession userSession;

    @BeforeEach
    void setUp() {
        userSession = new DefaultUserSession(key, timerFactory, onGoingOnlineHandler, onGoingOfflineHandler, onlinePortfolioSessionsLookup, missingHeartbeatTimeoutMillis);
    }

    @Test
    void onlinePortfolioSessions() {
        //given
        when(onlinePortfolioSessionsLookup.applyAsInt("XEFX")).thenReturn(5);
        //when + then
        assertThat(userSession.onlinePortfolioSessions()).isEqualTo(5);
    }

    @Test
    void updateOffline_whenOffline() {
        //given
        assertThat(userSession.online()).isFalse();

        //when
        userSession.updateOffline();

        //then
        verify(onGoingOnlineHandler, never()).accept(key);
        verify(onGoingOfflineHandler, never()).accept(key);
    }

    @Test
    void updateOffline_whenOnline() {
        //given
        userSession.updateOnline();
        assertThat(userSession.online()).isTrue();

        //when
        userSession.updateOffline();

        //then
        verify(onGoingOfflineHandler).accept(key);
    }

    @Test
    void updateOnline_First_WhenOffline_And_When_Online() {
        //given
        assertThat(userSession.online()).isFalse();

        //when
        userSession.updateOnline();
        //and
        userSession.updateOnline();

        //then
        verify(onGoingOnlineHandler, times(1)).accept(key);
        assertThat(userSession.online()).isTrue();
        verify(timer, times(2)).cancel();
        verify(timer, times(2)).schedule(missingHeartbeatTimeoutMillis);
    }


    @Test
    void userSessionKey() {
        //when + then
        assertThat(userSession.userSessionKey()).isEqualTo(key);
    }

}