#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-stp-to-risksystem-freq - Plugin to monitor the STP Trades to Risk System Frequency (All)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title STP Trade to Risk System Frequency'
    echo 'graph_category stp'
    echo 'graph_scale no'
    echo 'freqStp.label Trade Delivery To Risk System'
    echo 'freqStp.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "freqStp.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "freqStp.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
grep 'publisher-stp,trade-date-to-risksystem,stp-adapter,,' $LOGFILE | tail -100 | awk -F, '
BEGIN {
        freqStp=0;
}

{freqStp=$19}

END {
        print "freqStp.value " freqStp;
}
'
fi

