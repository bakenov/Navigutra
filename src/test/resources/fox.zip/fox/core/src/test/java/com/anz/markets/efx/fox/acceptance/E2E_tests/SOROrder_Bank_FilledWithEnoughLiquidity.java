package com.anz.markets.efx.fox.acceptance.E2E_tests;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.NewOrderSingleMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessageVisitor;

@RunWith(Spockito.class)
public class SOROrder_Bank_FilledWithEnoughLiquidity {
    private static final Logger LOGGER = LoggerFactory.getLogger(SOROrder_Bank_FilledWithEnoughLiquidity.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    private static final TestBookEntry[] ENTRIES = Table.parse(TestBookEntry.class, new String[] {
            "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
            "|==========|==============|=============|=============|============|",
            "| FAST     |   OFFER      |   0.91673   |     1e6     |   []       |",
            "| GS       |   OFFER      |   0.91675   |     3e6     |   []       |",
            "| BARX     |   OFFER      |   0.91676   |     1e6     |   []       |",
    });


    private static final List<TestBookEntry> snapshotEntries() {
        return Arrays.asList(ENTRIES);
    }

    private static final Hop[] HOPS = Table.parse(Hop.class, new String[] {
            "|   hopCompId  | hopMessageId | hopReceivingTime | hopSendingTime |",
            "|==============|==============|==================|================|",
            "| GB:HopName:1 |   123456789  |    66655556666   |  66655557777   |",
            "| AU:HopName:2 |   123123123  |    66556655666   |  66556655777   |",
    });

    @Test
    @Spockito.Unroll({
            "| source  | sourceSeq  | expectedVenue  | senderCompId  | messageId | possResend | origSendingTime | symbol |  securityType | tradeDate  | settlType | settlDate  | referenceSpotDate | mdFlags           |",
            "|=========|============|================|===============|===========|============|=================|========|===============|============|===========|============|===================|===================|",
            "|  1024   |    234566  |    GS          | FGB:Sender:1  |    9876   |    false   |    1122334000   | AUDUSD |   FXSPOT      | 2018-11-24 |    SP     | 2018-11-26 |     2018-11-26    | []                |",
            "|---------|------------|----------------|---------------|-----------|------------|-----------------|--------|---------------|------------|-----------|------------|-------------------|-------------------|"
    })
    @Spockito.Name("[{row}]: {expectedVenue}")
    public void fox_should_route_order_to_Bank_and_fill(
            final int source, final long sourceSeq, final String expectedVenue, final String senderCompId,
            final long messageId, final boolean possResend,
            final long origSendingTime, final String symbol, final SecurityType securityType, final LocalDate tradeDate,
            final Tenor settlType, final LocalDate settlDate, final LocalDate referenceSpotDate, final EnumSet<Flag> mdFlags
    ) throws Exception {

        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, securityType, settlType);

        // Iterating through the TestBookEntry and publish the snapshots
        snapshotEntries().forEach(snapshot -> {
            final SnapshotFullRefresh.Entry[] snapShotEntries = new SnapshotFullRefresh.Entry[1];
            //add the snapshots to the entries list
            snapShotEntries[0] = TestBookEntry.makeEntry(snapshot.marketId, snapshot.entryType, snapshot.entryPx,
                    snapshot.entrySize, snapshot.entryFlag);
            final long currentTimeNanos = acceptanceContext.precisionClock().nanos();
            final SnapshotFullRefresh fullRefresh = PricingMessage.snapshotFullRefresh(
                    new MessageHeader(source, sourceSeq),
                    new SnapshotFullRefresh.Body(senderCompId, messageId, possResend, currentTimeNanos,
                            origSendingTime, instrumentKey.instrumentId(), snapshot.marketId, tradeDate,
                            settlDate, referenceSpotDate, mdFlags), snapShotEntries, HOPS);
            final VenueEndpoint venueEndpoint = acceptanceContext.venueEndpointLookup().lookup(
                    snapshot.marketId);

            venueEndpoint.pricingQueue(symbol, securityType).add(fullRefresh);
        });

        Thread.sleep(1000); //Fixme: have not found a way to make sure that the price update is applied

        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();
        final String clOrdId = "2345";
        final OrderType orderType = OrderType.LIMIT;
        final SecurityType orderSecurityType = SecurityType.FXSPOT;
        final String currency = "AUD";
        final Side side = Side.BUY;
        final double price = 0.91673;
        final double quantity = 3000000;
        final TimeInForce timeInForce = TimeInForce.IOC;
        final NewOrderSingle order = newOrderSingle(1, symbol,  "FOX", orderSecurityType, settlType,
                clOrdId, side, price, quantity, currency, orderType, timeInForce);

        sorEndpoint.tradingRequest().add(order);

        snapshotEntries().forEach(market ->
            Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                    .matching(SnapshotFullRefreshMatcher.build()
                            .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(senderCompId))
                            .body().matches(SnapshotFullRefreshMatcher.marketId().eq(market.marketId))
                            .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                            .hops().hasAny())
                    .awaitMatchAndGetLast(5, TimeUnit.SECONDS));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq(order.body.senderCompId))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(order.body.ordType))
                        .body().matches(NewOrderSingleMatcher.quoteId().eq(order.body.quoteId))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        final ExecutionReportMatcher executionReportMatcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:fox"))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.origClOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.NEW))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.NEW))
                .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                .body().matches(ExecutionReportMatcher.securityType().eq(orderSecurityType))
                .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                .body().matches(ExecutionReportMatcher.currency().eq(currency))
                .body().matches(ExecutionReportMatcher.side().eq(side))
                .body().matches(ExecutionReportMatcher.price().eq(price))
                .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0);


        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(executionReportMatcher)
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);

        final VenueEndpoint tradingVenue = acceptanceContext.venueEndpointLookup().lookup(Venue.valueOf(expectedVenue));
        //Expect NewOrderSingle on the expected venue
        final TradingMessage venueNos = Asserter.of(tradingVenue.tradingRequest())
                .matching(NewOrderSingleMatcher.build()
                        .body().matches(NewOrderSingleMatcher.senderCompId().eq("GB:fox"))
                        .body().matches(NewOrderSingleMatcher.ordType().eq(OrderType.LIMIT))
                        .body().matches(NewOrderSingleMatcher.price().eq(order.body.price))
                        .body().matches(NewOrderSingleMatcher.orderQty().eq(order.body.orderQty))
                        .body().matches(NewOrderSingleMatcher.currency().eq(order.body.currency))
                        .body().matches(NewOrderSingleMatcher.side().eq(order.body.side))
                        .body().matches(NewOrderSingleMatcher.symbol().eq(order.body.symbol))
                )
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);

        venueNos.accept(new TradingMessageVisitor.Silent() {
            @Override
            public void onNewOrderSingle(final NewOrderSingle nos) {

                final ExecutionReport executionReport1 = new ExecutionReport();
                executionReport1.body.transactTime = acceptanceContext.precisionClock().nanos();
                executionReport1.body.timeInForce = nos.body.timeInForce;
                executionReport1.body.messageId = acceptanceContext.precisionClock().nanos();
                executionReport1.body.marketId = nos.body.marketId;
                executionReport1.body.orderQty = nos.body.orderQty;
                executionReport1.body.orderId = "555556";
                executionReport1.body.clOrdId = nos.body.clOrdId;
                executionReport1.body.origClOrdId = nos.body.clOrdId;
                executionReport1.body.clOrdLinkId = nos.body.clOrdLinkId;
                executionReport1.body.execId = "45678";
                executionReport1.body.quoteId = nos.body.quoteId;
                executionReport1.body.currency = nos.body.currency;
                executionReport1.body.ordType = nos.body.ordType;
                executionReport1.body.price = nos.body.price;
                executionReport1.body.securityType = nos.body.securityType;
                executionReport1.body.senderCompId = "GB:lg-gs";
                executionReport1.body.settlCurrency = nos.body.currency;
                executionReport1.body.side = nos.body.side;
                executionReport1.body.symbol = nos.body.symbol;
                executionReport1.body.execType = ExecType.TRADE;
                executionReport1.body.ordStatus = OrderStatus.FILLED;
                executionReport1.body.leavesQty = nos.body.orderQty;
                executionReport1.body.cumQty = nos.body.orderQty;
                executionReport1.body.lastQty = nos.body.orderQty;
                executionReport1.body.lastPx = 0.91673;

                tradingVenue.tradingResponse().add(executionReport1);
            }
        });

        Asserter.of(sorEndpoint.tradingResponse())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-gs"))
                        .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                        .body().matches(ExecutionReportMatcher.ordType().eq(orderType))
                        .body().matches(ExecutionReportMatcher.securityType().eq(orderSecurityType))
                        .body().matches(ExecutionReportMatcher.symbol().eq(symbol))
                        .body().matches(ExecutionReportMatcher.currency().eq(currency))
                        .body().matches(ExecutionReportMatcher.side().eq(side))
                        .body().matches(ExecutionReportMatcher.price().eq(price))
                        .body().matches(ExecutionReportMatcher.orderQty().eq(quantity))
                        .body().matches(ExecutionReportMatcher.timeInForce().eq(timeInForce))
                        .body().matches(ExecutionReportMatcher.marketId().eq("GS"))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0))
                .awaitMatchAndGetLast(5, TimeUnit.SECONDS);
    }

    private NewOrderSingle newOrderSingle(final long messageId,
                                          final String symbol, final String marketId,
                                          final SecurityType securityType,
                                          final Tenor tenor,
                                          final String clOrdId, final Side side,
                                          final double price, final double size,
                                          final String currency, final OrderType orderType,
                                          final TimeInForce timeInForce) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = timeInForce;
        newOrderSingle.body.messageId = messageId;
        newOrderSingle.body.marketId = marketId;
        newOrderSingle.body.orderQty = size;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.clOrdLinkId = "45345345";
        newOrderSingle.body.currency = currency;
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.price = price;
        newOrderSingle.body.targetStrategyName = "Sweeper";
        newOrderSingle.body.securityType = securityType;
        newOrderSingle.body.settlType = tenor;
        newOrderSingle.body.senderCompId = "GB:fox-clnt";
        newOrderSingle.body.settlCurrency = currency;
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = symbol;
        return newOrderSingle;
    }

}
