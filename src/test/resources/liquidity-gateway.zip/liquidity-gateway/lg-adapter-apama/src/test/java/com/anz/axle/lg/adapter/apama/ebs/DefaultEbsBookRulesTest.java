package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Collections;
import java.util.Map;

import org.junit.Test;

import com.anz.markets.efx.ngaro.api.SecurityType;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link DefaultEbsBookRules}
 */
public class DefaultEbsBookRulesTest {

    private static final double NO_TOLERANCE = 0.0;
    private static final String SYMBOL = "NZDJPY";
    private static final int DEPTH = 3;
    private static final double PRICE_RANGE_INCREMENT = 0.01;
    private static final int PRICE_RANGE_STEPS = 5;

    @Test
    public void configFor_whenSymbolExists() {
        //given
        final Map<String, double[]> fxSpotBookRules = Collections.singletonMap(SYMBOL, new double[] {DEPTH, PRICE_RANGE_INCREMENT, PRICE_RANGE_STEPS});
        final EbsBookRules ebsBookRules = new DefaultEbsBookRules(fxSpotBookRules, Collections.emptyMap());

        //when
        final EbsBookRules.Config config = ebsBookRules.configFor(SYMBOL, SecurityType.FXSPOT);

        //then
        assertEquals("Config.depth", DEPTH, config.depth());
        assertEquals("Config.priceRangeIncrement", PRICE_RANGE_INCREMENT, config.priceRangeIncrement(), NO_TOLERANCE);
        assertEquals("Config.priceRangeSteps", PRICE_RANGE_STEPS, config.priceRangeSteps());
    }

    @Test(expected = IllegalArgumentException.class)
    public void configFor_whenSymbolNotFound() {
        //given
        final Map<String, double[]> fxSpotBookRules = Collections.singletonMap(SYMBOL, new double[] {DEPTH, PRICE_RANGE_INCREMENT, PRICE_RANGE_STEPS});
        final EbsBookRules ebsBookRules = new DefaultEbsBookRules(fxSpotBookRules, Collections.emptyMap());

        //when
        final EbsBookRules.Config config = ebsBookRules.configFor("BLA", SecurityType.FXSPOT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateBookRules_depthMapSizeInvalid() throws Exception {
        final Map<String, double[]> fxSpotBookRules = Collections.singletonMap(SYMBOL, null);
        new DefaultEbsBookRules(fxSpotBookRules, Collections.emptyMap());
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateBookRules_priceDepthRangeSizeInvalid() throws Exception {
        final Map<String, double[]> fxSpotBookRules = Collections.singletonMap(SYMBOL, new double[] {DEPTH});
        new DefaultEbsBookRules(fxSpotBookRules, Collections.emptyMap());
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateBookRules_depthNonIntegral() throws Exception {
        final Map<String, double[]> fxSpotBookRules = Collections.singletonMap(SYMBOL, new double[] {1.123, PRICE_RANGE_INCREMENT, PRICE_RANGE_STEPS});
        new DefaultEbsBookRules(fxSpotBookRules, Collections.emptyMap());
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateBookRules_priceRangeStepsNonIntegral() throws Exception {
        final Map<String, double[]> fxSpotBookRules = Collections.singletonMap(SYMBOL, new double[] {DEPTH, PRICE_RANGE_INCREMENT, 2.834798345});
        new DefaultEbsBookRules(fxSpotBookRules, Collections.emptyMap());
    }

}