package com.anz.markets.efx.fox.codec.pojo.codec;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class PojoSorDecoders implements SorDecoders<SorMessage> {

    @Override
    public PricingRefreshCompleteHandler.DecoderFactory<SorMessage> pricingRefreshComplete() {
        return (handlerSupplier, forwardingLookup) -> new PojoPricingRefreshCompleteDecoder(handlerSupplier);
    }

    @Override
    public TimerExpiryHandler.DecoderFactory<SorMessage> timerExpiry() {
        return (handlerSupplier, forwardingLookup) -> new PojoTimerExpiryDecoder(handlerSupplier);
    }

    @Override
    public FirewallConfigHandler.DecoderFactory<SorMessage> firewallConfig() {
        return (handlerSupplier, forwardingLookup) -> new PojoFirewallConfigDecoder(handlerSupplier);
    }
    
    @Override
    public VenueConfigHandler.DecoderFactory<SorMessage> venueConfig() {
        return (handlerSupplier, forwardingLookup) -> new PojoVenueConfigDecoder(handlerSupplier);
    }

    @Override
    public UserConfigHandler.DecoderFactory<SorMessage> userConfig() {
        return (handlerSupplier, forwardingLookup) -> new PojoUserConfigDecoder(handlerSupplier);
    }

    @Override
    public InitialisationHandler.DecoderFactory<SorMessage> initialisation() {
        return (handlerSupplier, forwardingLookup) -> new PojoInitialisationDecoder(handlerSupplier);
    }

    @Override
    public InstrumentConfigHandler.DecoderFactory<SorMessage> instrumentConfig() {
        return (handlerSupplier, forwardingLookup) -> new PojoInstrumentConfigDecoder(handlerSupplier);
    }

    @Override
    public VenueInstrumentConfigHandler.DecoderFactory<SorMessage> venueInstrumentConfig() {
        return (handlerSupplier, forwardingLookup) -> new PojoVenueInstrumentConfigDecoder(handlerSupplier);
    }
}
