package com.anz.markets.efx.fox.processor.state.ematch;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EMatchStrategyParameters {
    private List<Venue> markets;
    private String benchmarkFix;

    private final ByteValueCache<String> parameterCache = new ByteValueCache<>(AsciiString::toString);
    private final ByteValueCache<String> parameterValueCache = new ByteValueCache<>(AsciiString::toString);
    private final Map<String, List<Venue>> valueToVenueListCache = new HashMap<>();

    public void init(final ExecutionReportDecoder newOrderSingleDecoder) {
        markets = Collections.EMPTY_LIST;

        final ExecutionReportDecoder.StrategyParameter strategyParameters = newOrderSingleDecoder.strategyParameters();
        for(ExecutionReportDecoder.StrategyParameter strategyParameter : strategyParameters) {
            final String name = strategyParameter.strategyParameterName().decodeAndCache(parameterCache);
            final String value = strategyParameter.strategyParameterValue().decodeAndCache(parameterValueCache);

            if ("Markets".equals(name)) markets = computeMarkets(value);
            if ("BenchmarkFix".equals(name)) benchmarkFix = value;
        }
    }

    public List<Venue> markets() {
        return markets;
    }

    public String benchmarkFix() { return benchmarkFix; }

    private List<Venue> computeMarkets(final String marketsString) {
        if (marketsString != null && !marketsString.isEmpty()) {
            return valueToVenueListCache.computeIfAbsent(marketsString, val -> Arrays.stream(val.split(".*,.*")).map(Venue::valueOf).collect(Collectors.toList()));
        }
        return Collections.EMPTY_LIST;
    }

}
