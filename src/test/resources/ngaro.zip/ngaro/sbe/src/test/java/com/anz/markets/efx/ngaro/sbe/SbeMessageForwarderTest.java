package com.anz.markets.efx.ngaro.sbe;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SbeMessageForwarderTest {
    @Mock
    private MessageDecoder<SbeMessage> decoder1;

    @Mock
    private MessageDecoder<SbeMessage> decoder2;

    @Mock
    private SbeMessage message;

    @Mock
    private MessageDecoder.ForwardingLookup<SbeMessage> forwardingLookup;

    private SbeMessageForwarder messageForwarder;

    @Before
    public void setUp() throws Exception {
        messageForwarder = new SbeMessageForwarder(forwardingLookup);
        when(forwardingLookup.apply("decoder1")).thenReturn(decoder1);
        when(forwardingLookup.apply("decoder2")).thenReturn(decoder2);
    }

    @Test
    public void wrap() throws Exception {

    }

    @Test
    public void should_forward_decoder1_when_destination_points_to_decoder1() throws Exception {
        //given
        messageForwarder.wrap(message);

        //when
        messageForwarder.forward("decoder1");

        //then
        verify(decoder1).decode(message);
    }

    @Test
    public void should_forward_decoder2_when_destination_points_to_decoder2() throws Exception {
        //given
        messageForwarder.wrap(message);

        //when
        messageForwarder.forward("decoder2");

        //then
        verify(decoder2).decode(message);
    }

    @Test(expected = NullPointerException.class)
    public void should_throw_npe_when_message_is_not_wrapped() throws Exception {
        //when
        messageForwarder.forward("decoder2");
    }

}