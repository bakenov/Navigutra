package com.anz.axle.acc;

import com.anz.axle.util.ManifestPrinter;
import org.apache.log4j.Logger;
import org.apache.log4j.net.SMTPAppender;
import org.apache.log4j.spi.TriggeringEventEvaluator;
import org.quartz.impl.StdScheduler;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public class ACCAdapter implements Runnable {

	private static final Logger LOG = Logger.getLogger(ACCAdapter.class);
	@SuppressWarnings("unused")
	private final ClassPathXmlApplicationContext context;
	
	public ACCAdapter(ClassPathXmlApplicationContext context) {
		this.context = context;
	}

	public void run() {
		boolean interrupted=false;
        StdScheduler scheduler = (StdScheduler) context.getBean("scheduler");
        applyEmailThrottling();
        Runtime.getRuntime().addShutdownHook(new Shutdown(scheduler));
        
		while(!interrupted) {
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				interrupted=true;
				LOG.info("Thread interrupted");
			}
		}
		LOG.info("AXLE ACC Adapter stopped.");
	}

    private void applyEmailThrottling() {
		SMTPAppender errorEmailAppender = (SMTPAppender) Logger.getRootLogger().getAppender("errorEmailAppender");
		SMTPAppender fatalEmailAppender = (SMTPAppender) Logger.getRootLogger().getAppender("fatalEmailAppender");
		if (errorEmailAppender != null) {
			errorEmailAppender.setEvaluator((TriggeringEventEvaluator) context.getBean("throttledTriggeringEventEvaluator"));
		}
		if (fatalEmailAppender != null) {
			fatalEmailAppender.setEvaluator((TriggeringEventEvaluator) context.getBean("throttledTriggeringEventEvaluator"));
		}
	}

	public static void main(String[] args) {
        LOG.info("=================================================");
        LOG.info("Welcome to the ACC Adapter");
        LOG.info("=================================================");
        ManifestPrinter manifestPrinter = new ManifestPrinter("META-INF/MANIFEST.MF");
        manifestPrinter.log();
        LOG.info("=================================================");

		LOG.info("Initialising Spring context...");
		ClassPathXmlApplicationContext startingContext = null;
		try {
			startingContext = new ClassPathXmlApplicationContext("conf/config.xml");
		} catch (Exception e) {
			LOG.error("Exception caught during initialisation.",e);
			System.exit(-1);
		}

    	Thread t = new Thread(new ACCAdapter(startingContext), "ACCAdapter");
		t.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			LOG.info("Caught interrupted exception.",e);
		}
	}
}
