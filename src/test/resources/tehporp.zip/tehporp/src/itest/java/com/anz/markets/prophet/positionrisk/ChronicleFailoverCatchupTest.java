package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.domain.impl.TradeImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class ChronicleFailoverCatchupTest extends ChronicleFailoverTestBase {
    private static final int COUNT = 99;
    private static final int TRADES_PER_ITERATION = 5;

    @Override
    protected void populateInitialData() {
        final TradeImpl tradeToWrite = createTrade();
        final Activate activate = createActivate();

        for (int i = 0; i < COUNT; i++) {
            sendActivate(activate, COUNT % 1);
            sendTrades(tradeToWrite, TRADES_PER_ITERATION);
        }
    }

    @Override
    protected void setupExtra() {
        id = 0;
    }

    @Test
    public void testCatchup() {
        checkTradesActivation(COUNT, COUNT * TRADES_PER_ITERATION);

        for (int i = 0; i < COUNT; i++) {
            assertEquals(this.activateConsumer.headers.get(i).getProcessedByCoreInstance(), COUNT % 1);
            checkTrades(i * TRADES_PER_ITERATION, (i + 1) * TRADES_PER_ITERATION, COUNT % 1);
        }
    }

    private void checkTrades(final int from, final int to, final int core) {
        for (int i = from; i < to; i++) {
            assertEquals(this.tradeConsumer.headers.get(i).getProcessedByCoreInstance(), core);
        }
    }
}
