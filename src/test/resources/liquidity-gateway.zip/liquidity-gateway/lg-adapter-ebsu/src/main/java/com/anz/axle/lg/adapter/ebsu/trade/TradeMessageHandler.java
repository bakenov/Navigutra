package com.anz.axle.lg.adapter.ebsu.trade;

import com.anz.axle.lg.adapter.ebsu.SecurityInfoHolder;
import com.anz.axle.lg.adapter.ebsu.SideConverter;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.LastMarketTradeEncoder;
import net.openhft.chronicle.core.util.Histogram;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.ebs.instrument.InstrumentDictionary;
import software.chronicle.ebs.itch.generated.incremental.messages.server.TradePrice;
import software.chronicle.ebs.itch.generated.preview.messages.server.InstrumentDirectory;
import software.chronicle.ebs.util.DecodeUtil;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

public final class TradeMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(TradeMessageHandler.class);

    private final LongSupplier sequenceNumberSupplier;
    private final SecurityInfoHolder securityInfoHolder;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final Venue market;
    private final boolean encodeHops;
    private final long dumpHistosEveryNanos;
    private final Histogram sendToRcv;
    private final Histogram processed;
    private final Histogram completed;
    private final SourceSequencer sourceSequencer;
    private InstrumentDictionary securityDictionary;
    private long lastHistosDumpNanos = 0;

    public TradeMessageHandler(@NotNull final SecurityInfoHolder securityInfoHolder,
                               @NotNull final LongSupplier sequenceNumberSupplier,
                               @NotNull final PrecisionClock precisionClock,
                               @NotNull final String senderCompId,
                               @NotNull final String compId,
                               @NotNull final Venue market,
                               final boolean encodeHops,
                               final int dumpHistosEveryMillis,
                               @NotNull final SourceSequencer sourceSequencer) {
        this.securityInfoHolder = Objects.requireNonNull(securityInfoHolder);
        this.sequenceNumberSupplier = Objects.requireNonNull(sequenceNumberSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.market = Objects.requireNonNull(market);
        this.encodeHops = encodeHops;
        this.dumpHistosEveryNanos = TimeUnit.MILLISECONDS.toNanos(dumpHistosEveryMillis);
        this.sendToRcv = new Histogram();
        this.processed = new Histogram();
        this.completed = new Histogram();
    }

    public void accept(@NotNull final InstrumentDictionary securityDictionary) {
        this.securityDictionary = securityDictionary;
    }

    public void accept(final TradePrice message, final long receivingTimeNanos) {
        LOGGER.debug("TradePrice received: {}", message);

//        if (message.marketRegion() != expectedRegion) {
//            throw new IllegalStateException();
//        }

        int locateCode = (int) message.locateCode();
        if (securityDictionary == null || (! securityDictionary.contains(locateCode))) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("No security definition for {}", locateCode);
            }
            return;
        }
        final InstrumentDirectory securityDefinition = securityDictionary.get(locateCode);

        final long sequenceNumber = message.sequenceNumber();
        final long sendingTimeNanos = message.timestamp();
        final long messageId = sequenceNumberSupplier.getAsLong();

        final SecurityInfoHolder.SecurityInfo securityInfo = securityInfoHolder.get(locateCode, securityDefinition);

        final LastMarketTradeEncoder.Body encoder = securityInfo.pricingEncoderSupplier.lastMarketTrade().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        final LastMarketTradeEncoder.Body body = encoder.senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(market)
                .instrumentId(securityInfo.instrumentKey.instrumentId())
                .sendingTime(sendingTimeNanos)
                .mdEntryPx(DecodeUtil.price(message.takePrice()))
                .mdEntrySize(0.0)
                .aggressorAction(SideConverter.aggressorAction(message.marketSide()));

        // not using eventNumber, updateFlags

        long beforeMessageCompleteNanos = precisionClock.nanos();

        if (encodeHops) {
            body.hopsStart(2)
                    .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(0)
                    .hopSendingTime(sendingTimeNanos)
                    .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                    .messageComplete();
        } else {
            body.hopsEmpty().messageComplete();
        }

        if (dumpHistosEveryNanos > 0) {
            sampleAndDumpHistos(receivingTimeNanos, sendingTimeNanos, beforeMessageCompleteNanos);
        }
    }

    private void sampleAndDumpHistos(final long receivingTimeNanos, final long sendingTimeNanos, final long beforeMessageCompleteNanos) {
        sendToRcv.sampleNanos(receivingTimeNanos - sendingTimeNanos);
        processed.sampleNanos(beforeMessageCompleteNanos - receivingTimeNanos);
        completed.sampleNanos(precisionClock.nanos() - beforeMessageCompleteNanos);
        if ((receivingTimeNanos - lastHistosDumpNanos) > dumpHistosEveryNanos) {
            LOGGER.info("histos\nsendToRcv {}: {}\nprocessed {}: {}\ncompleted {}: {}",
                    sendToRcv.totalCount(), sendToRcv.toMicrosFormat(),
                    processed.totalCount(), processed.toMicrosFormat(),
                    completed.totalCount(), completed.toMicrosFormat());
            sendToRcv.reset();
            processed.reset();
            completed.reset();
            lastHistosDumpNanos = receivingTimeNanos;
        }
    }

    public void connectionInterrupted() {
        LOGGER.info("Clearing books");
        // TODO: is there any way we can indicate?
    }
}
