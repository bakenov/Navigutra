package com.anz.markets.efx.fox.receiver.pricing;

import java.util.Objects;
import java.util.function.Consumer;

import org.tools4j.eventsourcing.api.ExecutionQueue;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.api.domain.SourceSequencer;
import com.anz.markets.efx.fox.common.pricing.PricingRefresher;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.pricing.client.api.PricingClient;

public class PricingClientPollerAndExecutionQueueForwarder implements PricingRefresher {
    private final PricingClient<MutableSbeMessage> pricingClient;

    private final Consumer<MutableSbeMessage> sbeMessageConsumer;

    public PricingClientPollerAndExecutionQueueForwarder(final ExecutionQueue executionQueue,
                                                         final PricingClient<MutableSbeMessage> pricingClient,
                                                         final PrecisionClock precisionClock,
                                                         final SourceSequencer sourceSequencer) {
        this.pricingClient = Objects.requireNonNull(pricingClient);

        this.sbeMessageConsumer = mutableSbeMessage -> {
            if (mutableSbeMessage.messageLength() == 0) {
                throw new IllegalStateException("Polled snapshot length should be greater than zero");
            } else {
                executionQueue.appender()
                        .accept(sourceSequencer.sourceId(),
                                sourceSequencer.nextSequence(),
                                precisionClock.nanos(),
                                mutableSbeMessage.buffer(), 0, mutableSbeMessage.messageLength());
            }
        };
    }

    @Override
    public boolean refresh(final long instrumentId, final boolean forceSnapshot) {
        return pricingClient.poller().pollAll(sbeMessageConsumer, instrumentId);
    }
}
