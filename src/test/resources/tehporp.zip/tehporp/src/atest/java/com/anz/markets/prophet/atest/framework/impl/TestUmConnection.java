package com.anz.markets.prophet.atest.framework.impl;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.EndPoint;
import com.anz.markets.efx.messaging.transport.api.EndPointStatusHandler;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.messaging.transport.api.Publication;
import com.anz.markets.efx.messaging.transport.api.Subscription;
import com.anz.markets.efx.messaging.transport.api.Topic;
import org.agrona.DirectBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class TestUmConnection implements Connection {
    private static final Logger LOGGER = LoggerFactory.getLogger(TestUmConnection.class);
    private final List<EndPoint> endPoints = new LinkedList<>();
    private final EndPointList<TestUmSubscription> subscribers = new EndPointList<>();
    private final EndPointList<TestUmPublication> publishers = new EndPointList<>();
    private final PrecisionClock clock = NanoClock.nanoClockUTC();

    @Override
    public void close() {
        // do nothing
    }

    @Override
    public PollingStrategy pollingStrategy() {
        return null;
    }

    @Override
    public Subscription openSubscription(final Topic topic, final EndPointStatusHandler endPointStatusHandler, final MessageHandler messageHandler) {

        return subscribers.getForTopic(topic).orElseGet(() -> {
            TestUmSubscription s = new TestUmSubscription(topic, messageHandler);
            subscribers.add(s);
            publishers.getForTopic(topic).ifPresent(p -> p.setSubscriber(s));
            LOGGER.info("Adding subscription for topic {}", topic.name());
            return s;
        });
    }

    @Override
    public Publication openPublication(final Topic topic, final EndPointStatusHandler endPointStatusHandler) {
        return publishers.getForTopic(topic).orElseGet(() -> {
            TestUmPublication p = new TestUmPublication(topic, this);
            publishers.add(p);
            subscribers.getForTopic(topic).ifPresent(p::setSubscriber);
            LOGGER.info("Now publishing on topic {}", topic.name());
            return p;
        });
    }

    private synchronized boolean doPublish(final Optional<TestUmSubscription> subscriber,
                                           final String topicName,
                                           final DirectBuffer buffer,
                                           final int offset,
                                           final int length) {
        subscriber.ifPresent(s ->  {
            LOGGER.info("Publish for topic: {}", topicName);
            s.handleMessage(buffer, offset, length);
        });
        return subscriber.isPresent();
    }

    public class TestUmSubscription implements Subscription {

        private final Topic topic;
        private final MessageHandler messageHandler;
        private long lastReceivedTimeNanosSinceEpoch = 0;

        public TestUmSubscription(final Topic topic, final MessageHandler messageHandler) {
            this.topic = topic;
            this.messageHandler = messageHandler;
        }

        @Override
        public long getLastReceivedTimeNanosSinceEpoch() {
            return lastReceivedTimeNanosSinceEpoch;
        }

        @Override
        public Topic topic() {
            return topic;
        }

        @Override
        public void close() {
            endPoints.remove(this);
        }

        public void handleMessage(final DirectBuffer messageBuffer, final int offset, final int length) {
            lastReceivedTimeNanosSinceEpoch = clock.nanos();
            LOGGER.info("Received message on topic {}", topic.name());
            messageHandler.onMessage(topic, messageBuffer, offset, length, lastReceivedTimeNanosSinceEpoch);
        }
    }

    public class TestUmPublication implements Publication {

        private final TestUmConnection connection;
        private final Topic topic;
        private Optional<TestUmSubscription> subscriber = Optional.empty();

        public TestUmPublication(final Topic topic, final TestUmConnection connection) {
            this.topic = topic;
            this.connection = connection;
        }

        @Override
        public boolean publish(final DirectBuffer buffer, final int offset, final int length) {
            return connection.doPublish(subscriber, topic.name(), buffer, offset, length);
        }

        @Override
        public Topic topic() {
            return topic;
        }

        public void setSubscriber(TestUmSubscription subscriber) {
            this.subscriber = Optional.of(subscriber);
        }

        @Override
        public void close() {
            endPoints.remove(this);
        }
    }

    public class EndPointList<E extends EndPoint> extends ArrayList<E> {
        public Optional<E> getForTopic(final Topic topic) {
            for (int i=0; i<size(); i++) {
                if (get(i).topic().equals(topic)) {
                    return Optional.of(get(i));
                }
            }

            return Optional.empty();
        }
    }
}