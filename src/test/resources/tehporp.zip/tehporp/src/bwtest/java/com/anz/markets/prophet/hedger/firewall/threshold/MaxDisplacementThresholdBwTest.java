package com.anz.markets.prophet.hedger.firewall.threshold;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MaxDisplacementThresholdBwTest extends AbstractMaxDisplacementThresholdForBwJmhTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MaxDisplacementThresholdBwTest.class);

    private static final int REPS = 100_000;
    private static final int THRESHOLD = 200;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    private int counter;

    @Test
    public void test_acceptValue() {
        helper.testAllocationNotExceeded(
                this::scenario_acceptValue, REPS, REPS,
                THRESHOLD // no allocation!
        );
    }

    private void scenario_acceptValue() {
        this.testAcceptValueAndCalculateDisplacement(counter++);
    }
}
