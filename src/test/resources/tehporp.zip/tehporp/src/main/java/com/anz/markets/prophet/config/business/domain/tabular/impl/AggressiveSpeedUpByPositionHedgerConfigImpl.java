package com.anz.markets.prophet.config.business.domain.tabular.impl;


import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpByPositionHedgerConfig;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.AggressiveSpeedUpHedgerConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;

public class AggressiveSpeedUpByPositionHedgerConfigImpl extends AggressiveSpeedUpHedgerConfigImpl implements AggressiveSpeedUpByPositionHedgerConfig, AggressiveSpeedUpHedgerConfig, ProphetMarshallable {

    private long positionMonitorWindowSeconds;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public AggressiveSpeedUpByPositionHedgerConfigImpl() {
    }

    public AggressiveSpeedUpByPositionHedgerConfigImpl(final Market market, final Instrument instrument) {
        super(market, instrument);
    }

    @Override
    public long getPositionMonitorWindowSeconds() {
        return this.positionMonitorWindowSeconds;
    }

    public AggressiveSpeedUpByPositionHedgerConfigImpl setPositionMonitorWindowSeconds(final long positionMonitorWindowSeconds) {
        this.positionMonitorWindowSeconds = positionMonitorWindowSeconds;
        return this;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) throws IllegalStateException {
        super.readMarshallable(in);
        this.positionMonitorWindowSeconds = in.readLong();
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        super.writeMarshallable(out);
        out.writeLong(this.positionMonitorWindowSeconds);
    }

    @Override
    public String toString() {
        return "AggressiveSpeedUpByPositionHedgerConfigImpl{" +
                "market=" + getMarket() +
                ", instrument=" + getInstrument() +
                ", pnLThreshold=" + getPnLThreshold() +
                ", minimumRisk=" + getMinimumRisk() +
                ", positionMonitorWindowSeconds=" + positionMonitorWindowSeconds +
                ", tradingTimeZone=" + getTradingTimeZone() +
                ", maximumSpread=" + getMaximumSpread() +
                ", minimumOrderQuantity=" + getMinimumOrderQuantity() +
                '}';
    }
}
