package com.anz.markets.prophet.atest.pricing._6_inverse;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceSpikeFirewallConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SyntheticInstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.SyntheticInstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.matcher.QuoteTypeMatcher;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURAUD;
import static com.anz.markets.prophet.domain.Instrument.USDAUD;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Market.WSP_A;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.domain.TradingTimeZone.LDN;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@Requirement(value = {Requirement.Ref.PRICING_4_9})
public class InverseFromDriverPairTest extends BaseAcceptanceSpecification {


    @Test
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1134})
    public void calculateUSDAUDFromAUDUSDDriver() {
        // above parity source pair
        given:
        {
            final ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base();
            final List<SyntheticInstrumentConfig> syntheticInstrumentConfigs = new ArrayList<>(configurationDataDefault.getSyntheticInstrumentConfigs());
            syntheticInstrumentConfigs.add(new SyntheticInstrumentConfigImpl().setInstrument(USDAUD).setMarkets(Market.ANY.toString()));
            final List<ClientPriceThrottleConfig> clientPriceThrottleConfigs = new ArrayList<>(configurationDataDefault.getClientPriceThrottleConfigs());
            clientPriceThrottleConfigs.add(new ClientPriceThrottleConfigImpl(Market.ANY, Currency.USD, Currency.AUD).setNoActivityHeartbeatFrequencyMs(20000).
                    setStartStopTimePeriodMS(0).
                    setLimit(1).
                    setTimePeriod(1).
                    setMinimumPriceDeltaFractionOfSpread(0.01).
                    setOverrideLimit(1).
                    setOverrideTimePeriod(1).
                    setOverrideMinimumPriceDeltaFractionOfMid(0.000001).
                    setMinimumPriceDeltaFractionOfPreviousSpread(0.001));

            prophet.receive(configurationDataDefault
                    .setClientSpreadConfigs(Arrays.asList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(LDN, 0.3),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(LDN, 0.5),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(LDN, 0.6),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_10M.getQty(), Region.GB).set(LDN, 0.8),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_15M.getQty(), Region.GB).set(LDN, 1.4),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_20M.getQty(), Region.GB).set(LDN, 2.0),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_30M.getQty(), Region.GB).set(LDN, 3.2),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_40M.getQty(), Region.GB).set(LDN, 4.0),
                            new ClientSpreadConfigImpl(WSP_A, AUDUSD, Level.QTY_50M.getQty(), Region.GB).set(LDN, 5.0)
                    ))
                    .setSyntheticInstrumentConfigs(syntheticInstrumentConfigs)
                    .setClientPriceThrottleConfigs(clientPriceThrottleConfigs)
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 1.45000, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(AUDUSD, WSP_A)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.4499850, 1.4500150));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.4499700, 1.4500300));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.4499625, 1.4500375));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.4499500, 1.4500500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.4498700, 1.4501300));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.4498100, 1.4501900));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.449720, 1.4502800));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.449680, 1.4503200));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 1.449550, 1.4504500));
        }
        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrumentAndMkt(USDAUD, WSP_A)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.68964803812, 0.68966230685));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.68964250922, 0.68966783621));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.68963974483, 0.68967060096));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.68963406742, 0.68967627908));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.68962759054, 0.68968276296));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.68959334680, 0.68971700911));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.68956554092, 0.68974485128));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.68952202333, 0.68978837293));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.68950967135, 0.68980075341));

            assertThat(clientPrice.getSkewedMid(), new IsRoundedTo(0.6896551724));
            assertThat(clientPrice.getUnskewedMid(), new IsRoundedTo(0.6896551724));

            prophet.notExpect(org.apache.logging.log4j.Level.ERROR, matches(".*"));
        }
        and:
        // reset config for next test
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
    }

    
    @Test
    public void calculateAUDEURFromEURAUDDriver() {
        // above parity source pair
        given:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Arrays.asList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_1M.getQty(), Region.GB).set(LDN, 0.3),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_3M.getQty(), Region.GB).set(LDN, 0.5),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_5M.getQty(), Region.GB).set(LDN, 0.6),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_10M.getQty(), Region.GB).set(LDN, 0.8),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_15M.getQty(), Region.GB).set(LDN, 1.4),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_20M.getQty(), Region.GB).set(LDN, 2.0),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_30M.getQty(), Region.GB).set(LDN, 3.2),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_40M.getQty(), Region.GB).set(LDN, 4.0),
                            new ClientSpreadConfigImpl(WSP_A, EURAUD, Level.QTY_50M.getQty(), Region.GB).set(LDN, 5.0)
                    ))
                    .setMarketConfigs(Arrays.asList(
                            // Driver Pair
                            new MarketConfigImpl(CNX).setRegion(GB).setInstrument(EURAUD)
                    ))
                    .clearAggBooks()
                    .addAggBook(Market.WSP_U,Instrument.EURAUD, TradingTimeZone.GLOBAL, Region.GB,Market.CNX)
                    .setPassiveHedgerConfigs(Collections.emptyList())
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_CROSSED)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(EURAUD, 1.45000, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURAUD)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.4499850, 1.4500150));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.4499700, 1.4500300));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.4499625, 1.4500375));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.4499500, 1.4500500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.4498700, 1.4501300));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.4498100, 1.4501900));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.449720, 1.4502800));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.449680, 1.4503200));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 1.449550, 1.4504500));
        }
        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDEUR)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.68964803812, 0.68966230685));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.68964250922, 0.68966783621));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.68963974483, 0.68967060096));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.68963406742, 0.68967627908));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.68962759054, 0.68968276296));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.68959334680, 0.68971700911));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.68956554092, 0.68974485128));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.68952202333, 0.68978837293));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.68950967135, 0.68980075341));
        }
        and:
        // reset config for next test
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
    }

    @Test
    public void calculateGBPEURFromEURGBPDriver() {
        // below parity source pair
        given:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURGBP, 0.85000, 0.00001));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURGBP)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.849985, 0.850015));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.84997, 0.85003));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.8499625, 0.8500375));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.84995, 0.85005));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.84987, 0.850130));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.84981, 0.85019));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.84972, 0.85028));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.84968, 0.85032));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.84955, 0.85045));
        }
        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.GBPEUR)).getFirst();
            assertThat(clientPrice.getBids().size(), is(8));

            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.17644671365, 1.17649446451));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.17642673214, 1.17651444841));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.17641220149, 1.17652898349));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.17636818605, 1.17657303035));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.17625334621, 1.17668794832));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.17613302185, 1.17680845449));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.17605830324, 1.17688321687));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.17592013141, 1.17702186203));
        }
        and:
        // reset config for next test
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
    }

    @Test
    public void inverseIndicativeWhenDriverIndicative() {
        given:
        {
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_PRICE_SPIKE_ENABLED, true))
                    .setPriceSpikeFirewallConfigs(Arrays.asList(
                            new PriceSpikeFirewallConfig(Instrument.EURGBP, 2, 50, 0.001, 0.2, 4000))
                    )
                    .setSyntheticInstrumentConfigs(Lists.newArrayList(
                            new SyntheticInstrumentConfigImpl().setInstrument(Instrument.GBPEUR).setMarkets("WSP_A|WSP_B|WSP_C|WSP_Z")
                    ))
            );
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURGBP, 0.82000, 0.0004));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURGBP, 0.83000, 0.0004));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.EURGBP)).getFirst();
            assertThat(clientPrice, new QuoteTypeMatcher(QuoteType.INDICATIVE));
            checkFirewallTriggered(clientPrice, PricingFirewallType.PRICE_SPIKE);
        }
        and:
        {
            List<ClientPrice> clientPrice = prophet.expect(ClientPrice.class, atLeast(3), isClientPriceInstrument(Instrument.GBPEUR));
            clientPrice.forEach(cp -> {
                assertThat(cp, new QuoteTypeMatcher(QuoteType.INDICATIVE));
                checkFirewallTriggered(cp, PricingFirewallType.PRICE_SPIKE);
            });
        }
        and:
        // reset config for next test
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
    }
}
