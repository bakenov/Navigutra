package com.anz.markets.prophet.atest.pricing._0b_mkt_data_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.PriceAndQty;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


public class IncrementalMarketDataTest extends BaseAcceptanceSpecification {

    private static final PriceAndQty BID_1 = new PriceAndQtyImpl(0.7005, 1_000_000);
    private static final PriceAndQty BID_2 = new PriceAndQtyImpl(0.7004, 1_000_000);
    private static final String bidId1 = "M:AXL:36000967241:CMZ:01.24464";
    private static final String bidId2 = "M:AXL:36000967241:CNX:03.24466";

    private static final PriceAndQty OFFER_1 = new PriceAndQtyImpl(0.7006, 1_000_000);
    private static final PriceAndQty OFFER_2 = new PriceAndQtyImpl(0.7007, 1_000_000);
    private static final String askId1 = "M:AXL:36000967241:CNX:06.24469";
    private static final String askId2 = "M:AXL:36000967241:CMZ:08.24471";

    private static final List<PriceAndQty> bids = Arrays.asList(BID_1, BID_2);
    private static final List<PriceAndQty> offers = Arrays.asList(OFFER_1, OFFER_2);
    private static final List<String> bidOrderIds = Arrays.asList(bidId1, bidId2);
    private static final List<String> offerOrderIds = Arrays.asList(askId1, askId2);

    @Test
    public void TestIncremental() {

        setup:
        {
            prophet.receive(tdd.configuration_pricing_001()
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LATENCY),
                            tdd.disableFilter(MarketDataFilterType.MARKET_STALE),
                            tdd.disableFilter(MarketDataFilterType.AGG_BOOK_SLOWEST_MARKET)
                    ))
            );
        }
        when:
        {
            long triggerTime = now();
            prophet.receive(tdd.marketDataSnapshotWithBidOfferOrderIds(Market.AXL, Instrument.AUDUSD, bids, bidOrderIds, offers, offerOrderIds, triggerTime));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.AXL)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(2));
            assertThat(marketDataSnapshot.getOfferEventList().size(), is(2));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.70050, 0.70060));
            assertThat(marketDataSnapshot, isMarketPricePoint(1, Level.QTY_1M, 0.70040, 0.70070));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataIncrementDelete(Market.AXL, Instrument.AUDUSD, bidId1, OrderSide.BID, now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.AXL)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(1));
            assertThat(marketDataSnapshot.getOfferEventList().size(), is(2));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.70040, 0.70060));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataIncrementDelete(Market.AXL, Instrument.AUDUSD, askId1, OrderSide.OFFER, now()));
        }
        then:
        {
            FilteredMarketDataSnapshot marketDataSnapshot = prophet.expect(FilteredMarketDataSnapshot.class, isMarket(Market.AXL)).getFirst();
            assertThat(marketDataSnapshot.getBidEventList().size(), is(1));
            assertThat(marketDataSnapshot.getOfferEventList().size(), is(1));
            assertThat(marketDataSnapshot, isMarketPricePoint(0, Level.QTY_1M, 0.70040, 0.70070));
        }
    }
}

