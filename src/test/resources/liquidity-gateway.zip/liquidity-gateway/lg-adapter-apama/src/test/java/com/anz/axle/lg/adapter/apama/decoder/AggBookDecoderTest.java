package com.anz.axle.lg.adapter.apama.decoder;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.function.LongSupplier;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.mockito.InOrder;

import com.apama.event.Event;
import com.apama.event.parser.EventParser;

import com.anz.axle.lg.adapter.apama.event.AggBook;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.DefaultVenueRequestKeyLookup;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test for {@link AggBookDecoder}
 */
@RunWith(Parameterized.class)
public class AggBookDecoderTest {

    private static final EventParser APAMA_EVENT_PARSER = new EventParser(AggBook.EVENT_TYPE);

    private final DecoderTestMode mode;

    private String senderCompId = "GB:AXL";
    private String compId = "GB:lg-axl";
    //mocks
    private VenueRequestKeyLookup requestKeyLookup;
    private PricingEncoderLookup pricingEncoderLookup;
    private MockitoPricingEncoder encoders;
    private PricingEncoderSupplier encoderSupplier;
    private LongSupplier messageIdSupplier;
    private InOrder inOrder;
    private PrecisionClock precisionClock;

    //under test
    private AggBookDecoder aggBookDecoder;
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    public AggBookDecoderTest(final DecoderTestMode mode) {
        this.mode = Objects.requireNonNull(mode);
    }

    @Parameterized.Parameters
    public static Collection<DecoderTestMode> testParameters() {
        return Arrays.asList(DecoderTestMode.values());
    }

    @Before
    public void beforeEach() {
        //initialise mocks
        encoders = new MockitoPricingEncoder();

        precisionClock = mock(PrecisionClock.class);
        //when(precisionClock.nanos()).thenReturn(cu);

        messageIdSupplier = mock(LongSupplier.class);
        when(messageIdSupplier.getAsLong()).thenReturn(10L);

        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.CITI);

        encoderSupplier = mock(PricingEncoderSupplier.class, RETURNS_MOCKS);
        when(encoderSupplier.incrementalRefresh()).thenReturn(encoders.incrementalEncoder);
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);

        final PricingEncoderSupplier modedEncoderSupplier = mode.encoderSupplier(encoderSupplier);

        pricingEncoderLookup = mock(PricingEncoderLookup.class);
        when(pricingEncoderLookup.lookup(any())).thenReturn(modedEncoderSupplier);

        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotEntries_next,
                encoders.snapshotEntries_body,

                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),
                encoders.messageEncoder);
    }

    @Test
    public void shouldDecode_aggBook() throws Exception {
        //given
        final long currentTime = 1234567890123L;
        when(precisionClock.nanos()).thenReturn(currentTime);
        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.AXL);
        aggBookDecoder = new AggBookDecoder(requestKeyLookup, pricingEncoderLookup, precisionClock, senderCompId, senderCompId, sourceSequencer);
        final String evtStr = "anz.AggBook(\"GB:fxagg\",42000130618,1493192053.35727,\"USD/JPY\"," +
                "[\"CMZ\",\"CITI\",\"BARX\",\"CNX\",\"MSI\",\"UBS\",\"ANZD\",\"GS\",\"EBS\",\"FXBK\"],0,[" +
                "anz.Entry(0,0,113.794,1e+06,0,\"10000\")," +
                "anz.Entry(0,1,113.794,1e+06,0,\"10001\")," +
                "anz.Entry(0,2,113.793,1e+06,0,\"10002\"),anz.Entry(0,3,113.793,2e+06,0,\"\")," +
                "anz.Entry(0,4,113.792,1e+06,0,\"10003\"),anz.Entry(0,3,113.792,2e+06,0,\"\")," +
                "anz.Entry(0,2,113.791,3e+06,0,\"10004\"),anz.Entry(0,1,113.791,3e+06,0,\"10018\")," +
                "anz.Entry(0,5,113.791,1e+06,0,\"10005\"),anz.Entry(0,3,113.791,6e+06,0,\"\")," +
                "anz.Entry(0,4,113.79,3e+06,0,\"10006\"),anz.Entry(0,6,113.79,1e+06,0,\"\")," +
                "anz.Entry(0,1,113.79,5e+06,0,\"10007\"),anz.Entry(0,5,113.79,2e+06,0,\"10019\")," +
                "anz.Entry(0,4,113.789,5e+06,0,\"10008\"),anz.Entry(0,3,113.789,2e+06,0,\"\"),anz.Entry(0,6,113.789,2e+06,0,\"\")," +
                "anz.Entry(0,3,113.788,3500000,0,\"\"),anz.Entry(0,1,113.787,1e+07,0,\"10016\")," +
                "anz.Entry(0,7,113.787,1e+06,0,\"10009\"),anz.Entry(0,8,113.785,3e+06,0,\"\")," +
                "anz.Entry(0,2,113.784,5e+06,0,\"10010\"),anz.Entry(0,7,113.781,2e+06,0,\"10009\")," +
                "anz.Entry(0,8,113.78,6e+06,0,\"\"),anz.Entry(0,7,113.78,2e+06,0,\"10009\")," +
                "anz.Entry(0,9,113.776,1e+06,0,\"10011\"),anz.Entry(0,8,113.775,5e+06,0,\"\")," +
                "anz.Entry(0,9,113.772,3e+06,0,\"10012\"),anz.Entry(0,8,113.77,6e+06,0,\"\")," +
                "anz.Entry(0,9,113.766,5e+06,0,\"10013\"),anz.Entry(0,8,113.765,3e+06,0,\"\")," +
                "anz.Entry(0,9,113.761,1e+07,0,\"10014\"),anz.Entry(0,8,113.76,7e+06,0,\"\")," +
                "anz.Entry(0,8,113.755,2e+06,0,\"\"),anz.Entry(0,8,113.75,6e+06,0,\"\"),anz.Entry(0,8,113.745,2e+06,0,\"\")," +
                "anz.Entry(0,8,113.74,1.1e+07,0,\"\"),anz.Entry(0,8,113.735,2e+06,0,\"\"),anz.Entry(0,8,113.73,5e+06,0,\"\")," +
                "anz.Entry(0,8,113.725,2e+06,0,\"\"),anz.Entry(0,8,113.72,5e+06,0,\"\"),anz.Entry(0,8,113.715,3e+06,0,\"\")" +
                "],[" +
                "anz.Entry(0,4,113.802,1e+06,0,\"10003\"),anz.Entry(0,3,113.802,2e+06,0,\"\")," +
                "anz.Entry(0,0,113.803,1e+06,0,\"10015\"),anz.Entry(0,5,113.803,1e+06,0,\"10020\")," +
                "anz.Entry(0,2,113.804,1e+06,0,\"10002\"),anz.Entry(0,4,113.804,3e+06,0,\"10006\")," +
                "anz.Entry(0,1,113.804,1e+06,0,\"10001\"),anz.Entry(0,5,113.804,2e+06,0,\"10021\")," +
                "anz.Entry(0,3,113.804,1e+06,0,\"\"),anz.Entry(0,2,113.805,3e+06,0,\"10004\")," +
                "anz.Entry(0,4,113.805,5e+06,0,\"10008\"),anz.Entry(0,6,113.805,1e+06,0,\"\"),anz.Entry(0,3,113.805,2e+06,0,\"\")," +
                "anz.Entry(0,6,113.806,2e+06,0,\"\"),anz.Entry(0,1,113.806,3e+06,0,\"10018\"),anz.Entry(0,3,113.806,8e+06,0,\"\")," +
                "anz.Entry(0,1,113.807,5e+06,0,\"10007\"),anz.Entry(0,3,113.807,5e+06,0,\"\"),anz.Entry(0,8,113.81,5e+06,0,\"\")," +
                "anz.Entry(0,1,113.811,1e+07,0,\"10016\"),anz.Entry(0,7,113.811,1e+06,0,\"10017\")," +
                "anz.Entry(0,2,113.812,5e+06,0,\"10010\"),anz.Entry(0,8,113.815,3e+06,0,\"\")," +
                "anz.Entry(0,9,113.817,1e+06,0,\"10011\"),anz.Entry(0,7,113.818,2e+06,0,\"10017\")," +
                "anz.Entry(0,7,113.819,2e+06,0,\"10017\"),anz.Entry(0,8,113.82,8e+06,0,\"\")," +
                "anz.Entry(0,9,113.823,3e+06,0,\"10012\"),anz.Entry(0,8,113.825,2e+06,0,\"\")," +
                "anz.Entry(0,9,113.827,5e+06,0,\"10013\"),anz.Entry(0,8,113.83,9e+06,0,\"\")," +
                "anz.Entry(0,9,113.832,1e+07,0,\"10014\"),anz.Entry(0,8,113.835,3e+06,0,\"\")," +
                "anz.Entry(0,8,113.84,6e+06,0,\"\"),anz.Entry(0,8,113.845,2e+06,0,\"\"),anz.Entry(0,8,113.85,6e+06,0,\"\")," +
                "anz.Entry(0,8,113.855,2e+06,0,\"\"),anz.Entry(0,8,113.86,6e+06,0,\"\"),anz.Entry(0,8,113.865,2e+06,0,\"\")," +
                "anz.Entry(0,8,113.87,6e+06,0,\"\"),anz.Entry(0,8,113.875,2e+06,0,\"\")" +
                "])";
        final int bids = 42;
        final int asks = 41;
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        aggBookDecoder.decode(evt);

        //then:
        verifySnapshot("USDJPY", Venue.AXL, bids +  asks, 1493192053357270000L);
        verifyEntry(0, Venue.CMZ, EntryType.BID, 113.794, 1e+06, 0, "10000");
        verifyEntry(0, Venue.CITI, EntryType.BID, 113.794, 1e+06, 0, "10001");
        verifyEntry(0, Venue.MSI, EntryType.OFFER, 113.802, 1e+06, 0, "10003");
        verifyEntry(0, Venue.CNX, EntryType.OFFER, 113.802, 2e+06, 0, null);
    }

    @Test
    public void shouldDecode_empty() throws Exception {
        //given
        final long currentTime = 1234567890123L;
        when(precisionClock.nanos()).thenReturn(currentTime);
        requestKeyLookup = new DefaultVenueRequestKeyLookup(Venue.AXL);
        aggBookDecoder = new AggBookDecoder(requestKeyLookup, pricingEncoderLookup, precisionClock, senderCompId, senderCompId, sourceSequencer);
        final String evtStr = "anz.AggBook(\"GB:fxagg\",42000130618,1493192053.35727,\"USD/JPY\",[],0,[],[]])";
        final Event evt = APAMA_EVENT_PARSER.parse(evtStr);

        //when
        aggBookDecoder.decode(evt);

        //then:
        verifySnapshot("USDJPY", Venue.AXL, 0, 1493192053357270000L);
        verify(encoders.snapshotEntries_next, never()).next();
    }

    private void verifySnapshot(final String symbol,
                                final Venue venue,
                                final int entriesCount,
                                final long sendingTimeNanos) {

        inOrder.verify(encoders.snapshotBody).sendingTime(sendingTimeNanos);
        inOrder.verify(encoders.snapshotBody).instrumentId(InstrumentKey.instrumentId(symbol, SecurityType.FXSPOT, Tenor.SP));
        inOrder.verify(encoders.snapshotBody).marketId(venue);
        inOrder.verify(encoders.snapshotBody).entriesStart(entriesCount);
    }

    private void verifyEntry(final long transactTimeNanos,
                             final Venue venue,
                             final EntryType side,
                             final double price,
                             final double quantity,
                             final long flags,
                             final String quoteId) {

        inOrder.verify(encoders.snapshotEntries_body).transactTime(transactTimeNanos);
        inOrder.verify(encoders.snapshotEntries_body).mdMkt(venue);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryType(side);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryPx(price);
        inOrder.verify(encoders.snapshotEntries_body).mdEntrySize(quantity);
        inOrder.verify(encoders.snapshotEntries_body).minQty(0);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryId(0);
        if (quoteId != null) {
            final int quoteEntryId = Integer.parseInt(quoteId);
            inOrder.verify(encoders.snapshotEntries_body).quoteEntryId(quoteEntryId);
        } else {
            if (mode == DecoderTestMode.MOCK) {
                inOrder.verify(encoders.snapshotEntries_body).quoteEntryId(0);
            } else {
                inOrder.verify(encoders.snapshotEntries_body).quoteEntryId(anyInt());
            }
        }
    }
}