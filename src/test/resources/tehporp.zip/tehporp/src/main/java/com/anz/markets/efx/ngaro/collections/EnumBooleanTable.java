package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

public class EnumBooleanTable<R extends Enum<R>, C extends Enum<C>> {
    private final static double IS_SET = 1.0;
    private final EnumDoubleTable<R, C> table;

    public EnumBooleanTable(final Class<R> rowType,
                            final Class<C> columnType) {
        table = new EnumDoubleTable<>(rowType, columnType);
    }

    public void clear() {
        table.clear();
    }

    public boolean put(R rowKey,
                       C columnKey,
                       boolean value) {
        if (value) {
            return !table.isEmpty(table.put(rowKey, columnKey, IS_SET));
        }
        return !table.isEmpty(table.remove(rowKey, columnKey));
    }

    public boolean get(R row, C column) {
        return !table.isEmpty(table.get(row, column));
    }

    public final void forEachRowKeyWithColumnKey(final C columnKey, final ObjBooleanConsumer<R> action) {
        GcFriendlyAssert.notNull(action);
        final int columnIndex = columnKey.ordinal();
        GcFriendlyAssert.isTrue(columnKey == table.columnsKeyUniverse[columnIndex]);

        for (int r = 0; r < table.rowCapacity; r++) {
            if (!table.isEmpty(table.values[r][columnIndex])) {
                action.accept(table.rowsKeyUniverse[r], isSet(table.values[r][columnIndex]));
            }
        }
    }

    private static boolean isSet(final double value) {
        return IS_SET == value;
    }

}