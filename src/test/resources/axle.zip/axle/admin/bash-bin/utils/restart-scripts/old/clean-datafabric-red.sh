#!/bin/bash

ssh axle@daxa003z "rm -rf /app/apama/axle/datafabric/workspace/*"
ssh AxlSv@daxa020z "rm -rf /app/apama/axle/datafabric/workspace/*"
