package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.codec.sbe.UserConfigSbeDecoder;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class UserConfigEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserConfigEvent.class);

    private final UserRepository userRepository;
    private final UserConfigSbeDecoder userConfigDecoder = new UserConfigSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();

    public UserConfigEvent(final UserRepository userRepository) {
        this.userRepository = Objects.requireNonNull(userRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!userConfigDecoder.wrap(message)) return false;
        logMessage();

        userRepository.init(userConfigDecoder);
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        userConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying user: {}", stringBuilder);
    }
}
