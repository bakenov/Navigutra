package com.anz.markets.prophet.atest.risk._2_pnl;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.positionrisk.Positions;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.MarketType.ECN;
import static com.anz.markets.prophet.domain.Portfolio.CLIENTS_NET;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class ProfitAndLossBiasOffsetTest extends BaseAcceptanceSpecification {
    @Test
    @Requirement(value = Ref.PROFIT_AND_LOSS_AXPROPHET_979)
    public void accumulatedPnlIndirectCcy() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 1.0000, 0.00004, now()));
            prophet.receive(tdd.client_trade_001(1_000_000, 0.9));
            prophet.receive(tdd.biasPosition(Currency.AUD, 9_000_000));
        }
        then:
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), is(0.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // market data update
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 1.0001, 0.00004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.9999, 0.00004, now()));
        }
        then:
        {
            LinkedList<ProfitAndLoss> biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(2), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET));
            assertThat(biasOffsetPnL.getFirst().getValueSystemBaseCurrency(), is(-900.0));
            assertThat(biasOffsetPnL.getLast().getValueSystemBaseCurrency(), is(900.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // receive position bias
            prophet.receive(tdd.biasPosition(Currency.AUD, 5_000_000));
        }
        then:
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), is(900.0));
        }

        when:
        {
            prophet.clearOutputBuffer();
            // market data updates
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.99980, 0.00004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 1.00010, 0.00004, now()));
        }
        then:
        {
            LinkedList<ProfitAndLoss> biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(2), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET));
            assertThat(biasOffsetPnL.getFirst().getValueSystemBaseCurrency(), is(1400.0));
            assertThat(biasOffsetPnL.getLast().getValueSystemBaseCurrency(), is(-100.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // receive position bias
            prophet.receive(tdd.biasPosition(Currency.AUD, 0));
            // market data update
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 0.9999, 0.00004, now()));
        }
        then:
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), is(-100.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // receive position bias
            prophet.receive(tdd.biasPosition(Currency.AUD, -2_000_000));
            // market data update
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.AUDUSD, 1.0001, 0.00004, now()));
        }
        then:
        {
            LinkedList<ProfitAndLoss> biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(2), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET));
            assertThat(biasOffsetPnL.getFirst().getValueSystemBaseCurrency(), is(-100.0));
            assertThat(biasOffsetPnL.getLast().getValueSystemBaseCurrency(), is(300.0));
        }
    }

    @Test
    @Requirement(value = Ref.PROFIT_AND_LOSS_AXPROPHET_979)
    public void accumulatedPnlDirectCcy() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDJPY, 90.000, 0.004, now()));
            // client trade has no impact on bias position pnl
            prophet.receive(tdd.client_trade_001(Instrument.USDJPY, 1_000_000, 90.010));
            prophet.receive(tdd.biasPosition(Currency.JPY, -90_000_000));
        }
        then:
        // initial offset adjustment is at market mid. pnl is therefore 0
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getFirst();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), is(0.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // market data update
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDJPY, 90.005, 0.004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDJPY, 89.995, 0.004, now()));
        }
        then:
        {
            LinkedList<ProfitAndLoss> biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(2), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET));
            assertThat(biasOffsetPnL.getFirst().getValueSystemBaseCurrency(), isRoundedTo(-55.552));
            assertThat(biasOffsetPnL.getLast().getValueSystemBaseCurrency(), isRoundedTo(55.559));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // receive position bias
            prophet.receive(tdd.biasPosition(Currency.JPY, -50_000_000));
        }
        then:
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getLast();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), isRoundedTo(55.559));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // market data update
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDJPY, 90.004, 0.004, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDJPY, 90.014, 0.004, now()));
        }
        then:
        {
            LinkedList<ProfitAndLoss> biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(2), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET));
            assertThat(biasOffsetPnL.getFirst().getValueSystemBaseCurrency(), isRoundedTo(0.0025));
            assertThat(biasOffsetPnL.getLast().getValueSystemBaseCurrency(), isRoundedTo(-61.714));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // receive position bias
            prophet.receive(tdd.biasPosition(Currency.JPY, 80_000_000));
        }
        then:
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getLast();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), isRoundedTo(-61.714));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // market data update
            prophet.receive(tdd.marketDataSnapshot(CNX, Instrument.USDJPY, 90.005, 0.004, now()));
        }
        then:
        {
            ProfitAndLoss biasOffsetPnL = prophet.expect(ProfitAndLoss.class, exactly(1), isProfitAndLossPortfolio(Portfolio.BIAS_OFFSET)).getLast();
            assertThat(biasOffsetPnL.getValueSystemBaseCurrency(), isRoundedTo(-150.584));
        }
    }
}