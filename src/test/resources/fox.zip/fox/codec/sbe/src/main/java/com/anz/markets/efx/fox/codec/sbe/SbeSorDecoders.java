package com.anz.markets.efx.fox.codec.sbe;

import com.anz.markets.efx.fox.codec.api.FirewallConfigHandler;
import com.anz.markets.efx.fox.codec.api.InitialisationHandler;
import com.anz.markets.efx.fox.codec.api.PricingRefreshCompleteHandler;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorHandlerSupplier;
import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.api.UserConfigHandler;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.FirewallConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InitialisationDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.PricingRefreshCompleteDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.TimerExpiryDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

@Garbage(Garbage.Type.RESULT)
public final class SbeSorDecoders implements SorDecoders<SbeMessage> {

    private final PricingRefreshCompleteHandler.DecoderFactory<SbeMessage> pricingRefreshComplete =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.pricingRefreshComplete(handlerSupplier),
                    templateId -> templateId == PricingRefreshCompleteDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final TimerExpiryHandler.DecoderFactory<SbeMessage> timerExpiry =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.timerExpiry(handlerSupplier),
                    templateId -> templateId == TimerExpiryDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final FirewallConfigHandler.DecoderFactory<SbeMessage> firewallConfig =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.firewallConfig(handlerSupplier),
                    templateId -> templateId == FirewallConfigDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final VenueConfigHandler.DecoderFactory<SbeMessage> venueConfig =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.venueConfig(handlerSupplier),
                    templateId -> templateId == VenueConfigDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final UserConfigHandler.DecoderFactory<SbeMessage> userConfig =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.userConfig(handlerSupplier),
                    templateId -> templateId == UserConfigDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final InitialisationHandler.DecoderFactory<SbeMessage> initialisation =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.initialisation(handlerSupplier),
                    templateId -> templateId == InitialisationDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final InstrumentConfigHandler.DecoderFactory<SbeMessage> instrumentConfig =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.instrumentConfig(handlerSupplier),
                    templateId -> templateId == InstrumentConfigDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final VenueInstrumentConfigHandler.DecoderFactory<SbeMessage> venueInstrumentConfig =
            (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
                    SorHandlerSupplier.venueInstrumentConfig(handlerSupplier),
                    templateId -> templateId == VenueInstrumentConfigDecoder.TEMPLATE_ID,
                    forwardingLookup);

    private final SorDecoders.DecoderFactory<SbeMessage> all = (handlerSupplier, forwardingLookup) -> new SbeMessageDecoder(
            handlerSupplier, templateId ->
                templateId == PricingRefreshCompleteDecoder.TEMPLATE_ID ||
                templateId == TimerExpiryDecoder.TEMPLATE_ID ||
                templateId == FirewallConfigDecoder.TEMPLATE_ID ||
                templateId == VenueConfigDecoder.TEMPLATE_ID ||
                templateId == UserConfigDecoder.TEMPLATE_ID ||
                templateId == InitialisationDecoder.TEMPLATE_ID ||
                templateId == InstrumentConfigDecoder.TEMPLATE_ID ||
                templateId == VenueInstrumentConfigDecoder.TEMPLATE_ID,
            forwardingLookup);

    @Override
    public PricingRefreshCompleteHandler.DecoderFactory<SbeMessage> pricingRefreshComplete() {
        return pricingRefreshComplete;
    }

    @Override
    public TimerExpiryHandler.DecoderFactory<SbeMessage> timerExpiry() {
        return timerExpiry;
    }

    @Override
    public FirewallConfigHandler.DecoderFactory<SbeMessage> firewallConfig() {
        return firewallConfig;
    }
   
    @Override
    public VenueConfigHandler.DecoderFactory<SbeMessage> venueConfig() {
        return venueConfig;
    }

    @Override
    public UserConfigHandler.DecoderFactory<SbeMessage> userConfig() {
        return userConfig;
    }

    @Override
    public DecoderFactory<SbeMessage> all() {
        return all;
    }

    @Override
    public InitialisationHandler.DecoderFactory<SbeMessage> initialisation() {
        return initialisation;
    }

    @Override
    public InstrumentConfigHandler.DecoderFactory<SbeMessage> instrumentConfig() {
        return instrumentConfig;
    }

    @Override
    public VenueInstrumentConfigHandler.DecoderFactory<SbeMessage> venueInstrumentConfig() {
        return venueInstrumentConfig;
    }
}
