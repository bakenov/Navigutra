package com.anz.axle.lg.adapter.cnx.quickfix;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.Message;
import quickfix.field.MDEntryPx;
import quickfix.field.MDReqID;
import quickfix.field.MsgSeqNum;
import quickfix.field.NoMDEntries;
import quickfix.field.SendingTime;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.util.Formatter;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.api.AggressorAction;
import com.anz.markets.efx.pricing.codec.api.LastMarketTradeEncoder;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;


public final class CnxLastMarketTradeHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(CnxLastMarketTradeHandler.class);
    private static final int CNX_AGGRESSOR_ACTION_FIELD = 7562;
    private final PricingEncoderSupplier pricingEncoderSupplier;
    private final SubscriptionManager subscriptionManager;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final SourceSequencer sourceSequencer;

    public CnxLastMarketTradeHandler(final PricingEncoderSupplier pricingEncoderSupplier,
                                     final PrecisionClock precisionClock,
                                     final SubscriptionManager subscriptionManager,
                                     final String senderCompId,
                                     final String compId,
 final SourceSequencer sourceSequencer) {
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.pricingEncoderSupplier = Objects.requireNonNull(pricingEncoderSupplier);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_INCREMENTAL;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.info("Tick MarketDataIncrementalRefresh received: {}", message);
        final int mdRequestId = message.getInt(MDReqID.FIELD);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = sequenceNumber;
        final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
        final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());
        final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(mdRequestId);

        final LastMarketTradeEncoder encoder = pricingEncoderSupplier.lastMarketTrade();
        encoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .marketId(subscription.market())
                .instrumentId(subscription.instrumentKey().instrumentId())
                .sendingTime(sendingTimeNanos)
                .mdEntryPx(price(message))
                .mdEntrySize(0.0)
                .aggressorAction(aggressorActionOrNull(message))
        .hopsStart(2)
            .next()
                .hopCompId().encode(senderCompId)
                .hopMessageId(sequenceNumber)
                .hopReceivingTime(0)
                .hopSendingTime(sendingTimeNanos)
            .next()
                .hopCompId().encode(compId)
                .hopMessageId(messageId)
                .hopReceivingTime(receivingTimeNanos)
                .hopSendingTime(precisionClock.nanos())
            .hopsComplete()
        .messageComplete();
    }

    private AggressorAction aggressorActionOrNull(final Message message) throws FieldNotFound {
        if (message.isSetField(CNX_AGGRESSOR_ACTION_FIELD)) {
            final char aggressorAction = message.getChar(CNX_AGGRESSOR_ACTION_FIELD);
            switch (aggressorAction) {
                case 'P':
                    return AggressorAction.PAID;
                case 'G':
                    return AggressorAction.GIVEN;
                default:
                    throw new IllegalArgumentException("Unsupported AggressorAction field value: " + aggressorAction);
            }
        } else {
            return null;
        }
    }

    private double price(final Message message) throws FieldNotFound {
        final List<Group> groups = message.getGroups(NoMDEntries.FIELD);
        if (groups == null || groups.size() != 1){
            throw new FieldNotFound(Formatter.slf4j("CNX LastMarketTrade increment must contain exactly one pricing group. Message received: {}", message));
        }
        return groups.get(0).getDouble(MDEntryPx.FIELD);
    }
}
