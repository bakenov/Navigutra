package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

final class SbeInstrumentConfigDecoder {
    private final InstrumentConfigDecoder instrumentConfigDecoder = new InstrumentConfigDecoder();
    private final Consumer<StringBuilder> messageLogger = instrumentConfigDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.InstrumentConfig encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final InstrumentConfigHandler instrumentConfigHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;
        instrumentConfigDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            instrumentConfigHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            instrumentConfigHandler.messageForwarder(messageForwarder);
            instrumentConfigHandler.messageLogger(messageLogger);
            body.decode(instrumentConfigHandler);
            instrumentConfigHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;
            instrumentConfigDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements InstrumentConfigHandler.Body {

        void decode(final InstrumentConfigHandler instrumentConfigHandler) {
            encodingOrder = EncodingOrder.InstrumentConfig.BODY;
            instrumentConfigHandler.onBody(this);
        }

        @Override
        public long instrumentId() {
            encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
            return instrumentConfigDecoder.instrumentId();
        }

        @Override
        public int pipSizeDivisor() {
            encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
            return instrumentConfigDecoder.pipSizeDivisor();
        }

        @Override
        public boolean enabled() {
            encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
            return instrumentConfigDecoder.enabled() == YesNo.YES;
        }
    }
}
