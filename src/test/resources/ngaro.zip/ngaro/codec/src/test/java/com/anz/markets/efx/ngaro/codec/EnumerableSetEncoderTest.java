package com.anz.markets.efx.ngaro.codec;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.function.BiPredicate;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

/**
 * Unit test for default implementations in {@link EnumerableSetEncoder}
 */
public class EnumerableSetEncoderTest {

    private enum TestEnum {
        BINGO,
        BONGO;
    }

    private static class EnumEncoder implements EnumerableSetEncoder<EnumEncoder, TestEnum> {

        final EnumSet<TestEnum> set = EnumSet.noneOf(TestEnum.class);

        @Override
        public EnumEncoder clear() {
            set.clear();
            return this;
        }

        @Override
        public EnumEncoder add(final TestEnum value) {
            set.add(value);
            return this;
        }

        @Override
        public <S> EnumEncoder addAll(final S source, final BiPredicate<? super S, ? super TestEnum> reader) {
            for (final TestEnum v : TestEnum.values()) {
                if (reader.test(source, v)) {
                    set.add(v);
                }
            }
            return this;
        }
    }

    @Test
    public void clear() throws Exception {
        //given
        final EnumEncoder encoder = new EnumEncoder();
        encoder.set.addAll(Arrays.asList(TestEnum.values()));

        //when
        encoder.clear();

        //then
        assertTrue("Should be empty", encoder.set.isEmpty());

    }

    @Test
    public void add() throws Exception {
        //given
        final EnumEncoder encoder = new EnumEncoder();

        //when
        encoder.add(TestEnum.BINGO);

        //then
        assertTrue("Should contain value", encoder.set.contains(TestEnum.BINGO));
        assertFalse("Should not contain value", encoder.set.contains(TestEnum.BONGO));
    }

    @Test
    public void addAll_Set() throws Exception {
        //given
        final EnumEncoder encoder = new EnumEncoder();

        //when
        encoder.addAll(EnumSet.allOf(TestEnum.class));

        //then
        assertTrue("Should contain all values", encoder.set.containsAll(EnumSet.allOf(TestEnum.class)));
    }

    @Test
    public void addAll_Predicate() throws Exception {
        //given
        final EnumEncoder encoder = new EnumEncoder();

        //when
        encoder.addAll(v -> v.ordinal() > 0);

        //then
        assertFalse("Should not contain value", encoder.set.contains(TestEnum.BINGO));
        assertTrue("Should contain value", encoder.set.contains(TestEnum.BONGO));
    }

    @Test
    public void addAllFrom() throws Exception {
        //given
        final class Mocks {
            @Mock
            EnumerableSetDecoder<TestEnum> decoder;
            {MockitoAnnotations.initMocks(this);}
        }
        final Mocks mocks = new Mocks();
        when(mocks.decoder.contains(TestEnum.BINGO)).thenReturn(Boolean.TRUE);
        when(mocks.decoder.contains(TestEnum.BONGO)).thenReturn(Boolean.FALSE);
        final EnumEncoder encoder = new EnumEncoder();

        //when
        encoder.addAllFrom(mocks.decoder);

        //then
        assertTrue("Should contain value", encoder.set.contains(TestEnum.BINGO));
        assertFalse("Should not contain value", encoder.set.contains(TestEnum.BONGO));
    }

}