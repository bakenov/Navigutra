package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.chronicle.ApiVersion;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.mangement.ReporterByEventId;
import com.anz.markets.prophet.mangement.ToHtml;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSourceChronicle;
import com.anz.markets.prophet.util.SystemProperties;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(Parameterized.class)
public class ReporterByEventIdTest {
    private static final long START_EVENT_ID = 111_111_111, MID_EVENT_ID = 222_222_222, END_EVENT_ID = 333_333_333;
    private static final int MIDDLE_COUNT = 20;
    private String basePath, basePath2;
    private ReporterByEventId underTest;
    private ApiVersion previousApiVersion;

    @Parameterized.Parameter
    public ApiVersion apiVersion;

    @Parameterized.Parameters(name = "{index}: ApiVersion({0})")
    public static Object[] data() {
        return new Object[] { ApiVersion.LEGACY_CHRONICLE, ApiVersion.CHRONICLE_QUEUE };
    }

    @Before
    public void setup() throws IOException {
        Context.set(new Context(new TimeSourceChronicle()));
        final Header header = Context.context().header();
        previousApiVersion = SystemProperties.CHRONICLE_API_VERSION;
        SystemProperties.CHRONICLE_API_VERSION = apiVersion;
        basePath = FileUtil.tmpFile(this.getClass().getSimpleName());
        basePath2 = FileUtil.tmpFile(this.getClass().getSimpleName(), "2");
        try (ProphetPersister persister = ChroniclePersisterFactory.coreConflate(basePath, LegacyChroniclePersister.OpenMode.OVERWRITE, true)) {
            header.setEventId(START_EVENT_ID);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            header.setEventId(MID_EVENT_ID);
            for (int i = 0; i < MIDDLE_COUNT; i++) {
                persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
            }
            header.setEventId(END_EVENT_ID);
            persister.sink(MessageType.ONE_SECOND).accept(OneSecond.INSTANCE);
        }
        try (ProphetPersister persister2 = ChroniclePersisterFactory.coreConflate(basePath2, LegacyChroniclePersister.OpenMode.OVERWRITE, true)) {
        }

        underTest = new ReporterByEventId(new String[]{basePath});
    }

    @After
    public void close() {
        SystemProperties.CHRONICLE_API_VERSION = previousApiVersion;
    }

    @Test
    public void testStartAtFirstEventId() throws IOException {
        checkResult(START_EVENT_ID, 1);
    }

    @Test
    public void testStartAtMidEventId() throws IOException {
        checkResult(MID_EVENT_ID, MIDDLE_COUNT);
    }

    @Test
    public void testStartAtEndEventId() throws IOException {
        checkResult(END_EVENT_ID, 1);
    }

    @Test
    public void testInvalidEventIdBefore() throws IOException {
        final String result = checkResult(END_EVENT_ID - 5, 0, 0);
        assertEquals(ReporterByEventId.EVENT_ID_NOT_FOUND, result);
    }

    @Test
    public void testInvalidEventIdAfter() throws IOException {
        final String result = checkResult(END_EVENT_ID + 5, 0, 0);
        assertEquals(ReporterByEventId.EVENT_ID_NOT_FOUND, result);
    }

    @Test
    public void testTwoChroniclesEventIdOnlyInOne() throws IOException {
        underTest = new ReporterByEventId(new String[]{basePath, basePath2});
        final Map<String, String> map = underTest.byEventId(END_EVENT_ID);
        assertEquals(2, map.size());
        final String result = map.get(basePath2);
        assertEquals(ReporterByEventId.EVENT_ID_NOT_FOUND, result);
    }

    private void checkResult(final long eventId, final int expected) throws IOException {
        checkResult(eventId, eventId, expected);
    }

    private String checkResult(final long startPosition, final long eventId, final int expected) throws IOException {
        final Map<String, String> map = underTest.byEventId(startPosition);
        assertEquals(1, map.size());
        final String result = map.get(basePath);
        String[] resultLines = result.split(ToHtml.NEWLINE);
        resultLines = returnValidLines(resultLines);
        assertEquals(expected, resultLines.length);
        for (int i = 0; i < resultLines.length; i++) {
            assertTrue(resultLines[i].contains(Long.toString(eventId)));
        }
        return result;
    }

    private String[] returnValidLines(final String[] resultLines) {
        if (resultLines.length > 2) {
            assert (resultLines[0].equals("["));
            assert (resultLines[resultLines.length - 1].equals("]"));
            return Arrays.copyOfRange(resultLines, 1, resultLines.length - 1);
        } else {
            // contains an error message
            return new String[0];
        }
    }
}
