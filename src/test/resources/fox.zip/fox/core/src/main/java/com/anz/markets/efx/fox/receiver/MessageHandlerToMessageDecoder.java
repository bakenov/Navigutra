package com.anz.markets.efx.fox.receiver;

import java.util.Objects;
import java.util.function.LongConsumer;

import org.agrona.DirectBuffer;

import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;

public final class MessageHandlerToMessageDecoder implements MessageHandler {

    private final MessageDecoder<SbeMessage> messageDecoder;
    private final LongConsumer receivedTimeNanosConsumer;
    private final SbeMessageForReading sbeMessage;

    public MessageHandlerToMessageDecoder(final LongConsumer receivedTimeNanosConsumer,
                                          final MessageDecoder<SbeMessage> messageDecoder) {
        this.receivedTimeNanosConsumer = Objects.requireNonNull(receivedTimeNanosConsumer);
        this.messageDecoder = Objects.requireNonNull(messageDecoder);
        this.sbeMessage = new SbeMessageForReading();
    }

    @Override
    public void onMessage(final Topic topic, final DirectBuffer buffer, final int offset, final int length, final long receiveTimeNanosSinceEpoch) {
        receivedTimeNanosConsumer.accept(receiveTimeNanosSinceEpoch);
        try {
            messageDecoder.decode(sbeMessage.wrap(buffer, offset, length));
        } finally {
            sbeMessage.unwrap();
            receivedTimeNanosConsumer.accept(0);
        }
    }
}
