package com.anz.markets.prophet.chime.bespoke;

import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.bespoke.RateChime;

import java.util.function.Consumer;

public class RateChimer implements Consumer<OneSecond> {
    private final RateChime rateChime;
    private final Consumer<RateChime> chimeConsumer;

    private int secondsSinceLast = 0;

    public RateChimer(final int periodSec, final Consumer<RateChime> chimeConsumer) {
        this.chimeConsumer = chimeConsumer;
        this.rateChime = new RateChime(periodSec);
    }

    @Override
    public void accept(final OneSecond data) {
        ++secondsSinceLast;
        if (secondsSinceLast >= rateChime.getPeriodSec()) {
            chimeConsumer.accept(rateChime);
            secondsSinceLast = 0;
        }
    }

}
