#!/bin/bash
# (c) 2016 ANZ

TITLE="Depth Latency (VAG2)"
GREPSTR="LatencyDepthPerVag.VAG2"

source /app/axle/axle/environment/fxagg/munin/axle_fxagg_lat.common