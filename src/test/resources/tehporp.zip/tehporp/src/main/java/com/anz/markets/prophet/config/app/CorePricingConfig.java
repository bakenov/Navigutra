package com.anz.markets.prophet.config.app;

import com.anz.markets.disco.data.Signals;
import com.anz.markets.prophet.Main;
import com.anz.markets.prophet.backtest.BackTestManager;
import com.anz.markets.prophet.chronicle.ChronicleByteReader;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.ChronicleReaderGeneric;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ActivationAware;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.factory.ChroniclePersisterFactory;
import com.anz.markets.prophet.chronicle.factory.ChronicleReaderFactory;
import com.anz.markets.prophet.chronicle.legacychronicle.LegacyChroniclePersister;
import com.anz.markets.prophet.config.app.importable.BusinessConfig;
import com.anz.markets.prophet.config.app.importable.ConsumerPricingConfig;
import com.anz.markets.prophet.config.app.importable.JmxConfig;
import com.anz.markets.prophet.config.app.importable.JmxSettings;
import com.anz.markets.prophet.config.business.ConfigReader;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.CovCorrAvgs;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Stage;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.RawBytes;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.BiasPositionControlImpl;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.ManualSkewControlImpl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.PricePauseControlImpl;
import com.anz.markets.prophet.domain.control.PricingFirewallReset;
import com.anz.markets.prophet.domain.control.PricingFirewallResetImpl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControlImpl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.control.VolatilityControlImpl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.forward.ForwardPointImpl;
import com.anz.markets.prophet.domain.impl.CovCorrAvgsImpl;
import com.anz.markets.prophet.domain.impl.EconNewsImpl;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.domain.time.SpotDateRollChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.marketdata.MarketDataReader;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.AdjustmentReader;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.AdjustmentsImpl;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.TradeReader;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.syscontrol.NotifierDefault;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.function.Consumer;
import java.util.function.Predicate;

@Configuration
@Import({BusinessConfig.class, ConsumerPricingConfig.class})
@PropertySources({
        @PropertySource(value = "classpath:conf/core.properties"),
        @PropertySource(value = "file:./conf/environment.properties", ignoreResourceNotFound = true)
})
public class CorePricingConfig extends JmxConfig {
    protected static final Logger LOGGER = LoggerFactory.getLogger(CorePricingConfig.class);
    public static final String TRADING_TIME_ZONE_CHIME_SINK = "TRADING_TIME_ZONE_CHIME_SINK";

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public static JmxSettings jmxSettings(@Value("${http.jmx.port.offset.core:2}") final int portOffset) {
        return new JmxSettings(portOffset);
    }

    // chronicle in & out
    @Bean
    public ProphetPersister outboundChroniclePersister(
            @Value("${chronicle.out.path:./chronicle.out}") final String outboundChroniclePath,
            @Value("${chronicle.ringBufferEnabled.core2starout:NO_RING}") final RingBuffer ringBuffer,
            @Value("${chronicle.open.mode:APPEND}") final LegacyChroniclePersister.OpenMode openMode,
            @Value("${core.instance}") final byte coreInstance,
            @Value("${default.active.core.instance}") final int defaultActiveCoreInstance,
            @Value("${chronicle.out.activation:YES}") final ActivationAware activationMode,
            final BackTestManager backTestManager) throws IOException {

        Context.instance(coreInstance);
        Context.stage(Stage.PRICE);

        final Predicate<MessageType> messageTypePredicate = backTestManager.isBackTestEnabled() ? backTestManager.messageTypeFilterPredicate() : Predicates.alwaysTrue();
        return ChroniclePersisterFactory.createCorePersister(outboundChroniclePath, openMode, activationMode, coreInstance == defaultActiveCoreInstance, messageTypePredicate, ringBuffer);
    }

    // tell Main to run this in main thread
    @Bean(name = Main.RUNNER_BEAN)
    public ProphetReader chronicleReader(
            @Value("#{'${chronicle.core.in.path:./chronicle.in.conflated,./chronicle.in}'.split(',')}") final String[] chronicleInPaths,
            @Value("${chronicle.ringBufferEnabled.starin2core:NO_RING}") final RingBuffer ringBuffer,
            final ChronicleObjectReader configReader,
            final ChronicleObjectReader tradeReader,
            final ChronicleObjectReader marketDataReader,
            final ChronicleObjectReader adjustmentReader,
            final ChronicleObjectReader adjustmentsReader,
            final ChronicleObjectReader oneSecondReader,
            final ChronicleObjectReader hourChimeReader,
            final ChronicleObjectReader endOfWeekChimeReader,
            final ChronicleObjectReader tradingTimeZoneChimeReader,
            final ChronicleObjectReader spotDateReader,
            final ChronicleObjectReader forwardPointReader,
            final ChronicleObjectReader volatilityControlReader,
            final ChronicleObjectReader econNewsReader,
            final ChronicleObjectReader pricingFirewallResetReader,
            final Consumer<RawBytes> rawBytesSink,
            final ChronicleObjectReader operatingHourChimeReader,
            final ChronicleObjectReader biasPositionControlReader,
            final ChronicleObjectReader covCorAvgsReader,
            final ChronicleObjectReader spotDateRollChimeReader,
            final ChronicleObjectReader skewCurrencyControlReader,
            final ChronicleObjectReader manualSkewControlReader,
            final ChronicleObjectReader pricePauseControlReader,
            final Consumer<EndEvent> endEventSink,
            @Value("${chronicle.in.start.index}") final int startIndex,
            @Value("${chronicle.in.pauser.enabled:true}") final boolean usePauser,
            @Value("${chronicle.in.secondary.use.pauser:true}") final boolean secondaryUsePauser,
            @Value("${core.instance}") final byte coreInstance,
            final ChronicleReaderGeneric<Activate> activationReader) throws IOException {
        final EnumMap<MessageType, ChronicleObjectReader> map = Maps.newEnumMap(MessageType.class);
        map.put(MessageType.CONFIGURATION, configReader);
        map.put(MessageType.TRADE, tradeReader);
        map.put(MessageType.MARKET_DATA_SNAPSHOT, marketDataReader);
        map.put(MessageType.MARKET_DATA_INCREMENT, marketDataReader);
        map.put(MessageType.ADJUSTMENT, adjustmentReader);
        map.put(MessageType.ADJUSTMENTS, adjustmentsReader);
        map.put(MessageType.ONE_SECOND, oneSecondReader);
        map.put(MessageType.HOUR_CHIME, hourChimeReader);
        map.put(MessageType.END_OF_WEEK_CHIME, endOfWeekChimeReader);
        map.put(MessageType.TIMEZONE_CHIME, tradingTimeZoneChimeReader);
        map.put(MessageType.ACTIVATE, activationReader);
        map.put(MessageType.SPOT_DATE, spotDateReader);
        map.put(MessageType.FORWARD_POINT, forwardPointReader);
        map.put(MessageType.VOLATILITY_CONTROL, volatilityControlReader);
        map.put(MessageType.ECONNEWS, econNewsReader);
        map.put(MessageType.PRICING_FIREWALL_RESET, pricingFirewallResetReader);
        map.put(MessageType.OPERATING_HOUR_CHIME, operatingHourChimeReader);
        map.put(MessageType.BIAS_OFFSET_CONTROL, biasPositionControlReader);
        map.put(MessageType.COV_CORR, covCorAvgsReader);
        map.put(MessageType.SPOT_DATE_ROLL_CHIME, spotDateRollChimeReader);
        map.put(MessageType.SKEW_CURRENCY_CONTROL, skewCurrencyControlReader);
        map.put(MessageType.MANUAL_SKEW_CONTROL, manualSkewControlReader);
        map.put(MessageType.PRICE_PAUSE_CONTROL, pricePauseControlReader);

        final ChronicleByteReader passThrough = new ChronicleByteReader(rawBytesSink);
        map.put(MessageType.HEDGE_CONTROL, passThrough);
        map.put(MessageType.HEDGE_CURRENCY_CONTROL, passThrough);
        map.put(MessageType.ORDER_EVENT, passThrough);
        map.put(MessageType.HEDGER_FIREWALL_RESET, passThrough);

        final boolean thisCoreUsesPauser = (coreInstance != 0 && secondaryUsePauser) || usePauser;

        final int tailerId = ringBuffer.enabled() ? coreInstance + 1 : ReaderConfig.NO_TAILER_ID;
        return ChronicleReaderFactory.createCoreReaderForChronicleIn(chronicleInPaths, startIndex, thisCoreUsesPauser, endEventSink, ringBuffer, tailerId, map);
    }

    // chronicle readers. These deserialise their types from the inbound chronicle and pass on to their consumers

    @Bean
    public ChronicleReaderGeneric<Activate> activationReader(
            @Qualifier("activateConsumers") final Consumer<Activate> activateConsumers) {
        return new ChronicleReaderGeneric<>(new Activate(), activateConsumers);
    }

    @Bean
    public ConfigReader configReader(final Consumer<ConfigurationData> configurationDataConsumer) {
        return new ConfigReader(new NotifierDefault<>(configurationDataConsumer));
    }

    @Bean
    public AdjustmentReader adjustmentReader(final Consumer<Adjustment> adjustmentConsumers) {
        return new AdjustmentReader(adjustmentConsumers);
    }

    @Bean
    public ChronicleReaderGeneric adjustmentsReader(final Consumer<Adjustments> adjustmentsConsumers) {
        return new ChronicleReaderGeneric(new AdjustmentsImpl(), adjustmentsConsumers);
    }

    @Bean
    public TradeReader tradeReader(final Consumer<Trade> tradeConsumer) {
        return new TradeReader(tradeConsumer);
    }

    @Bean
    public MarketDataReader marketDataReader(final Consumer<MarketData> marketDataConsumers) {
        return new MarketDataReader(Arrays.asList(marketDataConsumers));
    }

    @Bean
    public ChronicleReaderGeneric spotDateReader(final Consumer<SpotDate> spotDateConsumer) {
        return new ChronicleReaderGeneric(new SpotDateImpl(), spotDateConsumer);
    }

    @Bean
    public ChronicleReaderGeneric forwardPointReader(final Consumer<ForwardPoint> forwardPointConsumer) {
        return new ChronicleReaderGeneric(new ForwardPointImpl(), forwardPointConsumer);
    }

    @Bean
    public ChronicleReaderGeneric volatilityControlReader(final Consumer<VolatilityControl> volatilityControlConsumer) {
        return new ChronicleReaderGeneric(new VolatilityControlImpl(), volatilityControlConsumer);
    }

    @Bean
    public ChronicleReaderGeneric biasPositionControlReader(final Consumer<BiasPositionControl> biasPositionControlConsumer) {
        return new ChronicleReaderGeneric(new BiasPositionControlImpl(), biasPositionControlConsumer);
    }

    @Bean
    public ChronicleReaderGeneric econNewsReader(final Consumer<EconNews> econNewsConsumer) {
        return new ChronicleReaderGeneric(new EconNewsImpl(), econNewsConsumer);
    }

    @Bean
    public ChronicleReaderGeneric covCorAvgsReader(final Consumer<CovCorrAvgs> covCorrAvgsConsumer) {
        return new ChronicleReaderGeneric(new CovCorrAvgsImpl(), covCorrAvgsConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<OneSecond> oneSecondReader(final Consumer<OneSecond> oneSecondConsumer) {
        return new ChronicleReaderGeneric<>(OneSecond.INSTANCE, oneSecondConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<TradingTimeZoneChime> tradingTimeZoneChimeReader(
            final Consumer<TradingTimeZoneChime> tradingTimeZoneManager) {
        return new ChronicleReaderGeneric<>(TradingTimeZoneChime.INSTANCE, tradingTimeZoneManager);
    }

    @Bean
    public ChronicleReaderGeneric<HourChime> hourChimeReader(final Consumer<HourChime> hourChimeConsumer) {
        return new ChronicleReaderGeneric<>(HourChime.INSTANCE, hourChimeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<EndOfWeekChime> endOfWeekChimeReader(
            final Consumer<EndOfWeekChime> endOfWeekChimeConsumer) {
        return new ChronicleReaderGeneric<>(EndOfWeekChime.INSTANCE, endOfWeekChimeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<PricingFirewallReset> pricingFirewallResetReader(
            final Consumer<PricingFirewallReset> firewallResetConsumer) {
        return new ChronicleReaderGeneric<>(new PricingFirewallResetImpl(), firewallResetConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<OperatingHourChime> operatingHourChimeReader(
            final Consumer<OperatingHourChime> operatingHourChimeConsumer) {
        return new ChronicleReaderGeneric<>(new OperatingHourChime(), operatingHourChimeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<SpotDateRollChime> spotDateRollChimeReader(final Consumer<SpotDateRollChime> spotDateRollChimeConsumer) {
        return new ChronicleReaderGeneric<>(SpotDateRollChime.INSTANCE, spotDateRollChimeConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<SkewCurrencyControl> skewCurrencyControlReader(final Consumer<SkewCurrencyControl> skewCurrencyControlConsumer) {
        return new ChronicleReaderGeneric<>(new SkewCurrencyControlImpl(), skewCurrencyControlConsumer);
    }

    @Bean
    public ChronicleReaderGeneric<ManualSkewControl> manualSkewControlReader(final Consumer<ManualSkewControl> manualSkewControlConsumer,
                                                                             final Consumer<ManualSkewControl> manualSkewControlSink) {
        return new ChronicleReaderGeneric<>(new ManualSkewControlImpl(), manualSkewControlConsumer, manualSkewControlSink);
    }

    @Bean
    public ChronicleReaderGeneric<PricePauseControl> pricePauseControlReader(final Consumer<PricePauseControl> pricePauseControlConsumer) {
        return new ChronicleReaderGeneric<>(new PricePauseControlImpl(), pricePauseControlConsumer);
    }

    // chronicle persister consumers AKA sinks. These are the very last things in the consumer chain, and write to out chronicle
    @Bean
    public Consumer<ValueAtRisk> varSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.VALUE_AT_RISK);
    }

    @Bean
    public Consumer<WholesaleBookFactors> wholesaleBookFactorsSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.WHOLESALE_BOOK_FACTORS);
    }

    @Bean
    public Consumer<Activate> activateSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ACTIVATE);
    }

    @Bean
    public Consumer<SpotDateRollChime> spotDateRollChimeSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.SPOT_DATE_ROLL_CHIME);
    }

    @Bean
    public Consumer<Positions> positionsSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.POSITIONS);
    }

    @Bean
    public Consumer<ClientPrice> clientPriceSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.CLIENT_PRICE);
    }

    @Bean
    public Consumer<Signals> signalsSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.SIGNALS);
    }

    @Bean
    public Consumer<ProfitAndLoss> profitAndLossSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.PROFIT_AND_LOSS);
    }

    @Bean
    public Consumer<MidRate> marketDataSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sinkMidRate();
    }

    @Bean
    public Consumer<Order> orderSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sinkOrder();
    }

    @Bean
    public Consumer<OptimalPositions> optimalPositionsSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.OPTIMAL_POSITIONS);
    }

    @Bean(name = TRADING_TIME_ZONE_CHIME_SINK)
    public Consumer<TradingTimeZoneChime> tradingTimeZoneChimeSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.TIMEZONE_CHIME);
    }

    @Bean
    public Consumer<EndOfWeekChime> endOfWeekChimeSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.END_OF_WEEK_CHIME);
    }

    @Bean
    public Consumer<RealisedVolatility> realisedVolatilitySink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.REALISED_VOLATILITY);
    }

    @Bean
    public Consumer<VolatilityControl> volatilityControlSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.VOLATILITY_CONTROL);
    }

    @Bean
    public Consumer<IndexedConfigurationData> configurationSink(final ProphetPersister prophetPersister) {
        return configurationData -> prophetPersister.sink(MessageType.CONFIGURATION).accept(configurationData.getConfigurationData());
    }

    @Bean
    public Consumer<EconNews> econNewsSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ECONNEWS);
    }

    @Bean
    public Consumer<OneSecond> oneSecondSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ONE_SECOND);
    }

    @Bean
    public Consumer<OperatingHourChime> operatingHourChimeSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.OPERATING_HOUR_CHIME);
    }

    @Bean
    public Consumer<HourChime> oneHourSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.HOUR_CHIME);
    }

    @Bean
    public Consumer<Trade> tradeSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.TRADE);
    }

    @Bean
    public Consumer<Adjustment> adjustmentSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ADJUSTMENT);
    }

    @Bean
    public Consumer<Adjustment> biasAdjustmentSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ADJUSTMENT);
    }

    @Bean
    public Consumer<Adjustments> adjustmentsSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.ADJUSTMENTS);
    }

    @Bean
    public Consumer<RawBytes> rawBytesSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sinkRawBytes();
    }

    @Bean
    public Consumer<HedgePauseSignal> hedgePauseSignalSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.HEDGE_PAUSE_SIGNAL);
    }

    @Bean
    public Consumer<EndEvent> endEventSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.END_EVENT);
    }

    @Bean
    public Consumer<SkewCurrencyControl> skewCurrencyControlSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.SKEW_CURRENCY_CONTROL);
    }

    @Bean
    public Consumer<ManualSkewControl> manualSkewControlSink(final ProphetPersister prophetPersister) {
        return prophetPersister.sink(MessageType.MANUAL_SKEW_CONTROL);
    }
}
