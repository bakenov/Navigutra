package com.anz.axle.adapters.ndf2trep.publisher;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class TrepAsserter {

    public static void assertEqualTrepQuote(final TrepQuote actual, final TrepQuote expected) {
        assertThat("ServiceName", actual.getServiceName(), is(expected.getServiceName()));
        assertThat("Name", actual.getName(), is(expected.getName()));
        assertThat("Ask", actual.getAsk(), is(expected.getAsk()));
        assertThat("Bid", actual.getBid(), is(expected.getBid()));
        assertThat("QuoteType", actual.getQuoteType(), is(expected.getQuoteType()));
    }

}
