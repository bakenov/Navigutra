package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;

@RunWith(Spockito.class)
public class ReceiveHeartbeat_Then_UserSession_Is_Up_Test {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReceiveHeartbeat_Then_UserSession_Is_Up_Test.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();

    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_receive_user_session_heartbeat() throws Exception {
        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "FXTrader.GB.anufriea.XEFX";

        sorEndpoint.tradingRequest().add(heartbeat);

        final HeartbeatMatcher heartbeatMatcher = HeartbeatMatcher.build()
                .header().matches(HeartbeatMatcher.source().gt(0))
                .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                .body().matches(HeartbeatMatcher.senderCompId().eq(heartbeat.body.senderCompId))
                .body().matches(HeartbeatMatcher.messageId().gt(0L));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

    }
}
