package com.anz.markets.prophet.atest.pricing._7_throttle;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.ThrottlerPublishReason;
import com.anz.markets.prophet.matcher.PricingFirewallTypeMatcher;
import com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.Collections;
import java.util.LinkedList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RestartBeforeTest(reason="clear prices")
@Requirement(value = {Ref.PRICING_AXPROPHET_1183})
public class TrueThrottlerTest extends BaseAcceptanceSpecification {
    // epsTargetAllowingHeadroom = 1000 / 250 * 1 = 4
    private int normalLimit = 1;
    private int normalPeriodMS = 250;

    // epsTarget = (1000 / 200) * 2 = 10
    private int overrideLimit = 2;
    private int overridePeriodMS = 200;

    private ConfigurationDataDefault setUpConfiguration() {
        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.TRUE_THROTTLE_MARKETS, new Market[]{Market.WSP_A, Market.WSP_B}))
                .setClientSpreadConfigs(Lists.newArrayList(
                        // spread config for driver pairs
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.0)
                ))
                .setClientPriceThrottleConfigs(Lists.newArrayList(
                        clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.AUD, Currency.USD, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.AUD, Currency.USD, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.AUD, Currency.USD, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.AUD, Currency.USD, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002),
                        clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, 30,
                                overrideLimit, overridePeriodMS, 0.00002)
                ))
                .setSyntheticWideningFactors(Collections.emptyList());

        return configuration;
    }

    @Test
    @DisplayName("Rule 8 and AXPROPHET-1112 Empty Heartbeat continues for AUD/USD ONLY")
    public void continueEmptyBookHeartbeatAUDUSD() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.70100, 0.00003));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.AUDUSD));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class,  exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_TO_EMPTY)).getLast();
            assertThat(cp.isEmpty(), is(true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5_000);
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class,  exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.HEARTBEAT)).getFirst();
            assertThat(cp.isEmpty(), is(true));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.USDJPY));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class,  exactly(1), isThrottleReason(Market.WSP_A, Instrument.USDJPY, ThrottlerPublishReason.PRICE_TO_EMPTY)).getLast();
            assertThat(cp.isEmpty(), is(true));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5_000);
        }
        then:
        {
            prophet.notExpect(ClientPrice.class,  isClientPriceInstrument(Instrument.USDJPY));
        }
    }

    @Test
    @DisplayName("Rule 11 Heartbeat test")
    public void scenario0() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // @t10 first cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
        }
        when:
        // @t10 + heartbeat interval(5_000ms), publish
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5_000);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02)); // trigger
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.HEARTBEAT));
        }
    }

    @Test
    @DisplayName("Rule 2 queued price and Rule 3 recheck publish")
    public void scenario1() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // @t20 1st cp published
        {
            prophet.incrementTime(20);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75050, 0.0001));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST)).getLast();
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75045));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75055));
        }
        when:
        // @t30 2nd cp published, @t40 third cp published
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75051, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75053, 0.0001));
        }
        then:
        {
            LinkedList<ClientPrice> cp = prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE));
            assertThat(cp.get(0).getTopOfBookBid().getPrice(), isNear(0.75046));
            assertThat(cp.get(0).getTopOfBookOffer().getPrice(), isNear(0.75056));
            assertThat(cp.get(1).getTopOfBookBid().getPrice(), isNear(0.75048));
            assertThat(cp.get(1).getTopOfBookOffer().getPrice(), isNear(0.75058));
        }
        when:
        // t900, epsObserved=3, cp throttled and queued(rule 2 met: tt_p < z and tt_r < z)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(860);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.UNPUBLISHED));
        }
        when:
        // t950, epsObserved=3, 4th cp throttled and replaces existing cp in queued(rule 2 met: tt_p < z and tt_r < z)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.UNPUBLISHED));
        }
        when:
        // t@1025 RECHECK queued price after SOTHE frequency interval(125ms),
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(75);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02)); // trigger recheck
        }
        then:
        // given epsObserved=2(last 1sec window), throttle and queue(rule 2 met: tt_p < z and tt_r < z))
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.UNPUBLISHED));
        }
        when:
        // t@1150 RECHECK queued price after SOTHE frequency interval(125ms),
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(125);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.550, 0.02)); // trigger recheck
        }
        then:
        // given epsObserved=1(last 1sec window), now able to publish
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.RECHECK_PROTECTIVE)).getLast();
            assertThat(cp.getMidRate(), isNear(0.75052));
        }
    }

    @Test
    @DisplayName("Rule 4 rebound check met - publish and throttle scenarios")
    public void scenario2() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // @t10 1st cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.setManualGlobalVol(2d));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75050, 0.0001));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST)).getLast();
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75040));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75060));
            assertThat(cp.getMidRate(), isNear(0.75050));
        }
        when:
        // @t15 2nd cp published on Rule 4(tt_r >= z and epsObserved < epsTargetAllowingHeadroom)
        // tt_p = 0, tt_r = 1.0, z = 0.075
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5);
            prophet.receive(tdd.setManualGlobalVol(0d));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_REBOUND)).getLast();
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75045));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75055));
            assertThat(cp.getMidRate(), isNear(0.75050));
        }
        when:
        // @t30 3rd cp published, @t40 fourth cp published
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(15);
            prophet.receive(tdd.setManualGlobalVol(2d));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75053, 0.0001));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE)).getLast();
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75043));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75063));
            assertThat(cp.getMidRate(), isNear(0.75053));
        }
        when:
        // @t900, 5th cp is THROTTLED on Rule 4(tt_r >= z BUT epsObserved !< epsTargetAllowingHeadroom)
        // epsObserverd = 4, epsTargetAllowingHeadroom = 4, tt_p = 0, tt_r = 1.0, z = 0.3
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(860);
            prophet.receive(tdd.setManualGlobalVol(0d));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.UNPUBLISHED)).getLast();
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75048));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75058));
            assertThat(cp.getMidRate(), isNear(0.75053));
        }
        when:
        // @t1020, before the SOTHE frequency interval(125ms) a new marketdata arrives (epsObservered now 2)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(120);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_REBOUND)).getLast();
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75047));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75057));
            assertThat(cp.getMidRate(), isNear(0.75052));
        }
        when:
        // @t1025, SOTHE frequency interval(125ms)elapsed so recheck queued cp
        // But a new cp has been published since, do NOT republish
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02)); // trigger recheck
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
    }

    @Test
    @DisplayName("Rule 5 Watermark adjustment on Offer side only")
    public void scenario3() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // 10 cps published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            ClientPrice nonWaterMarkedCp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST)).getFirst();
            assertThat(nonWaterMarkedCp.getMidRate(), isNear(0.75052));
            assertThat(nonWaterMarkedCp, isClientPricePoint(0, Level.QTY_1M, 0.75047, 0.75057));
            assertThat(nonWaterMarkedCp, isClientPricePoint(1, Level.QTY_2M, 0.750455, 0.750585));
            assertThat(nonWaterMarkedCp, isClientPricePoint(2, Level.QTY_2M, 0.750410, 0.750630));


            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(9), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE)).getFirst();
            assertThat(cp.getMidRate(), isNear(0.75054));
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75049));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75059));
        }
        when:
        // @t110, 11th cp is WATERMARKED on rule 5: epsObserved(10) >= epsTarget(10)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        // OFFER SIDE Watermarking only by +0.2pip
        {
            ClientPrice waterMarkedCp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE_WATERMARK)).getFirst();
            assertThat(waterMarkedCp.getMidRate(), isNear(0.75053));
            assertThat(waterMarkedCp, isClientPricePoint(0, Level.QTY_1M, 0.75047, 0.75059));
            assertThat(waterMarkedCp, isClientPricePoint(1, Level.QTY_2M, 0.750455, 0.750605));
            assertThat(waterMarkedCp, isClientPricePoint(2, Level.QTY_2M, 0.750410, 0.750650));
        }
    }

    @Test
    @DisplayName("Rule 5 Watermark adjustment on Bid side only")
    public void scenario4() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // 10 cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));

        }
        then:
        {
            ClientPrice nonWaterMarkedCp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST)).getFirst();
            assertThat(nonWaterMarkedCp.getMidRate(), isNear(0.75054));
            assertThat(nonWaterMarkedCp, isClientPricePoint(0, Level.QTY_1M, 0.750490, 0.750590));
            assertThat(nonWaterMarkedCp, isClientPricePoint(1, Level.QTY_2M, 0.750475, 0.750605));
            assertThat(nonWaterMarkedCp, isClientPricePoint(2, Level.QTY_2M, 0.750430, 0.750650));


            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(9), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE)).getFirst();
            assertThat(cp.getMidRate(), isNear(0.75052));
            assertThat(cp.getTopOfBookBid().getPrice(), isNear(0.75047));
            assertThat(cp.getTopOfBookOffer().getPrice(), isNear(0.75057));
        }
        when:
        // @t110, 11th cp is WATERMARKED on rule 5: epsObserved(10) >= epsTarget(10)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        // BID SIDE Watermarking only by -0.2pip
        {
            ClientPrice waterMarkedCp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE_WATERMARK)).getFirst();
            assertThat(waterMarkedCp.getMidRate(), isNear(0.75053));
            assertThat(waterMarkedCp, isClientPricePoint(0, Level.QTY_1M, 0.750470, 0.750590));
            assertThat(waterMarkedCp, isClientPricePoint(1, Level.QTY_2M, 0.750455, 0.750605));
            assertThat(waterMarkedCp, isClientPricePoint(2, Level.QTY_2M, 0.750410, 0.750650));
        }
    }

    @Test
    @DisplayName("Rule 9 empty to non-empty price but wait for epsObserved rule to be met")
    public void scenario5() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // 3 cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
            prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE));
        }
        when:
        // @t40, 4th cp(empty) is published
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.AUDUSD));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_TO_EMPTY));
        }
        when:
        // @t50, 5th cp is non-empty.
        // Rule 8: DO NOT PUBLISH since epsObserved(4) !< 0.8 * epsTargetAllowingHeadroom(4)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
        when:
        // @t1015, epsObserved(3) now < 0.8 * epsTargetAllowingHeadroom(4)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(965);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FROM_EMPTY)).getFirst();
            assertThat(cp.getMidRate(), isNear(0.75054));
        }
    }

    @Test
    @DisplayName("Rule 9 empty to non-empty price but wait for heartbeat")
    public void scenario6() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // 3 cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
            prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE));
        }
        when:
        // @t40, 4th cp(empty) is published
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.emptyMarketDataSnapshot(Instrument.AUDUSD));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_TO_EMPTY));
        }
        when:
        // @t50, 5th cp is non-empty.
        // Rule 8: DO NOT PUBLISH since epsObserved(4) !< 0.8 * epsTargetAllowingHeadroom(4)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
        when:
        // @t50 + heartbeat interval(5000ms), publish
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5_000);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02)); // trigger
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.HEARTBEAT)).getFirst();
            assertThat(cp.getMidRate(), isNear(0.75052));
        }
    }

    @Test
    @DisplayName("Rule 6 transition from non-indicative to indicative")
    public void scenario7() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .putKeyValueConfig(
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    )
            );
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "OPEN Mon 01:00 GMT"));
        }
        when:
        // 3 cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75050, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75051, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75053, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
            prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE));
        }
        when:
        // opening hours CLOSE.
        // @t40 cp INDICATIVE, publish immediately
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "CLOSE Mon 01:00 GMT"));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_TO_INDICATIVE));
        }
        when:
        // @t90 cp still indicative but indicative prices are throttled to SOHE frequency period(125ms)(which has not been met
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(50);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75055, 0.0001));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
        when:
        // @t165, SOHE frequency period(125ms) after last published cp, heartbeat latest cp
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(75);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02)); //trigger eval
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.RECHECK_SOTHE_INDICATIVE)).getLast();
            assertThat(cp.getMidRate(), isNear(0.75055));
        }
    }

    @Test
    @DisplayName("Rule 7 indicative to firm price but wait for epsObserved rule to be met")
    public void scenario8() {
        setup:
        {
            prophet.receive(setUpConfiguration()
                    .putKeyValueConfig(
                            new KeyValueConfigImpl(KeyValueConfigType.PRICING_FIREWALL_OUTSIDE_OPERATING_HOUR_ENABLED, true)
                    )
            );
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "OPEN Mon 01:00 GMT"));
        }
        when:
        // 3 cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
            prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE));
        }
        when:
        // @t40, 4th cp(INDICATIVE) is published
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "CLOSE Mon 01:00 GMT"));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_TO_INDICATIVE));
        }
        when:
        // @t50, 5th cp is FIRM
        // Rule 8: DO NOT PUBLISH since epsObserved(4) !< 0.8 * epsTargetAllowingHeadroom(4)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
        when:
        // @t1015, epsObserved(3) now < 0.8 * epsTargetAllowingHeadroom(4)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(965);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        // even though cp is same as last sent cp, since we are moving from INDIC to FIRM we publish(and no need to check Primary rules 1/2/3/4)
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FROM_INDICATIVE)).getFirst();
            assertThat(cp.getMidRate(), isNear(0.75054));
        }
    }

    @Test
    @DisplayName("Rule 7 indicative to firm price but wait for heartbeat")
    public void scenario9() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // 3 cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
            prophet.expect(ClientPrice.class, exactly(2), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_PROTECTIVE));
        }
        when:
        // @t40, 4th cp(INDICATIVE) is published
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "CLOSE Mon 01:00 GMT"));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_TO_INDICATIVE));
        }
        when:
        // @t50, 5th cp is FIRM.
        // Rule 8: DO NOT PUBLISH since epsObserved(4) !< 0.8 * epsTargetAllowingHeadroom(4)
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(tdd.createOperatingHourChime(OperatingHourEntity.WSP_A, "OPEN Mon 01:00 GMT"));
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75052, 0.0001));
        }
        then:
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrument(Instrument.AUDUSD));
        }
        when:
        // @t50 + heartbeat interval(5000ms), publish
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5_000);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.500, 0.02)); // trigger
        }
        then:
        {
            ClientPrice cp = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.HEARTBEAT)).getFirst();
            assertThat(cp.getMidRate(), isNear(0.75052));
        }
    }

    @Test
    @DisplayName("AXPROPHET-706 config change results in pushing INDICATIVE price")
    public void postConfigChangeForcePushIndicative() {
        setup:
        {
            prophet.receive(setUpConfiguration());
        }
        when:
        // 1st cp published
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75054, 0.0001));
        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.PRICE_FIRST));
        }
        when:
        // receive config update
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10);
            prophet.receive(setUpConfiguration(), false);
        }
        then:
        // publish previous client price
        {
            ClientPrice clientPriceWSPA = prophet.expect(ClientPrice.class, exactly(1), isThrottleReason(Market.WSP_A, ThrottlerPublishReason.CONFIG_TO_INDICATIVE)).getFirst();
            assertThat(clientPriceWSPA.getMidRate(), isRoundedTo(0.75054));

            assertThat("Quote type on BID side should be INDICATIVE", clientPriceWSPA.getBidQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPA, new PricingFirewallTypeMatcher(OrderSide.BID,PricingFirewallType.CONFIGURATION_CHANGED));

            assertThat("Quote type on OFFER side should be INDICATIVE", clientPriceWSPA.getOfferQuoteType(), Matchers.is(QuoteType.INDICATIVE));
            assertThat(clientPriceWSPA, new PricingFirewallTypeMatcher(OrderSide.OFFER,PricingFirewallType.CONFIGURATION_CHANGED));

        }
    }

    private ClientPriceThrottleConfigImpl clientPriceConfigOverrideThrottle(final Market market, Currency baseCurrency, Currency termsCurrency,
                                                                            int normalLimit, int normalPeriodMS,
                                                                            double normalDeltaFractionOfSpread,
                                                                            int overrideLimit, int overridePeriodMS,
                                                                            double overrideDeltaFractionOfMid) {
        return new ClientPriceThrottleConfigImpl(market, baseCurrency, termsCurrency)
                .setNoActivityHeartbeatFrequencyMs(5_000)
                .setLimit(normalLimit)
                .setTimePeriod(normalPeriodMS)
                .setMinimumPriceDeltaFractionOfSpread(DONT_CARE_LARGE_DOUBLE)
                .setMinimumPriceDeltaFractionOfPreviousSpread(normalDeltaFractionOfSpread)  // aka panic threshold
                .setOverrideLimit(overrideLimit)
                .setOverrideTimePeriod(overridePeriodMS)
                .setOverrideMinimumPriceDeltaFractionOfMid(overrideDeltaFractionOfMid);
    }
}
