package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.efx.ngaro.collections.EnumLongMap;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.filter.LatencyFilterConfig;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.efx.ngaro.collections.EnumDoubleMap;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class LatencyFilterConfigs {

    private final EnumLongMap<Market> latencyTimeOutNanosByMarket = new EnumLongMap<>(Market.class);

    public LatencyFilterConfigs(final List<LatencyFilterConfig> latencyFilterConfigs) {
        for (LatencyFilterConfig filterConfig : latencyFilterConfigs) {
            GcFriendlyAssert.isTrue(filterConfig.getLatencyMs() > 0, "Market latency ms must be more than zero. Market: %s, Latency: %s", filterConfig.getMarket(), filterConfig.getLatencyMs());
            final long latencyNanos = TimeUnit.MILLISECONDS.toNanos(filterConfig.getLatencyMs());
            if (filterConfig.getMarket().isWildcard()) {
                for (Market market : Market.VALUES) {
                    latencyTimeOutNanosByMarket.put(market,latencyNanos);
                }
            } else {
                latencyTimeOutNanosByMarket.put(filterConfig.getMarket(),latencyNanos);
            }
        }
    }

    public long getLatencyTimeOutNanosByMarket(final Market market) {
        return latencyTimeOutNanosByMarket.get(market);
    }
}
