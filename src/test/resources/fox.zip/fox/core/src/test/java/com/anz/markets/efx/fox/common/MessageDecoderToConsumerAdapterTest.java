package com.anz.markets.efx.fox.common;

import org.agrona.DirectBuffer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.tools4j.eventsourcing.api.MessageConsumer;

import com.anz.markets.efx.fox.common.MessageDecoderToConsumerAdapter;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MessageDecoderToConsumerAdapterTest {
    private MessageDecoderToConsumerAdapter messageDecoderToConsumerAdapter;

    @Mock
    private SbeMessage sbeMessage;
    @Mock
    private MessageConsumer messageConsumer;
    @Mock
    private DirectBuffer directBuffer;
    @BeforeEach
    void setUp() {
        messageDecoderToConsumerAdapter = new MessageDecoderToConsumerAdapter(messageConsumer);
    }

    @Test
    void decode() {
        //given
        when(sbeMessage.buffer()).thenReturn(directBuffer);
        when(sbeMessage.messageLength()).thenReturn(100);

        //when
        messageDecoderToConsumerAdapter.decode(sbeMessage);

        //then
        verify(messageConsumer).accept(directBuffer, 0, 100);
    }
}