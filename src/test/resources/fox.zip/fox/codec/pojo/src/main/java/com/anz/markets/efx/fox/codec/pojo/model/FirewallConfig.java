package com.anz.markets.efx.fox.codec.pojo.model;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.FirewallConfigEncoder;
import com.anz.markets.efx.fox.codec.api.SorDecoders;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoFirewallConfigHandler;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
public final class FirewallConfig implements SorMessage {

    public final MessageHeader header;
    public final Body body;

    public FirewallConfig() {
        this(new MessageHeader(),new Body());
    }

    public FirewallConfig( final MessageHeader header, final Body body) {
        this.header = Objects.requireNonNull(header);
        this.body = Objects.requireNonNull(body);
    }

    public static final class Body {
        public String firewallName;
        public long ruleId;
        public String regionPattern;
        public String orderTypePattern;
        public String deskPattern;
        public String portfolioPattern;
        public String usernamePattern;
        public String venuePattern;
        public String securityTypePattern;
        public String tenorPattern;
        public String symbolPattern;
        public long period;
        public String periodUnit;
        public boolean local;
        public String comment;
        public String lastEditUsername;
        public long lastEditTime;
        public double limitThreshold;

        public Body() {
            super();
        }

        public Body(final String firewallName,
                    final long ruleId,
                    final String regionPattern,
                    final String orderTypePattern,
                    final String deskPattern,
                    final String portfolioPattern,
                    final String usernamePattern,
                    final String venuePattern,
                    final String securityTypePattern,
                    final String tenorPattern,
                    final String symbolPattern,
                    final long period,
                    final String periodUnit,
                    final boolean local,
                    final String comment,
                    final String lastEditUsername,
                    final long lastEditTime,
                    final double limitThreshold
                    ) {
            this.firewallName = firewallName;
            this.ruleId = ruleId;
            this.regionPattern = regionPattern;
            this.orderTypePattern = orderTypePattern;
            this.deskPattern = deskPattern;
            this.portfolioPattern = portfolioPattern;
            this.usernamePattern = usernamePattern;
            this.venuePattern = venuePattern;
            this.securityTypePattern = securityTypePattern;
            this.tenorPattern = tenorPattern;
            this.symbolPattern = symbolPattern;
            this.period = period;
            this.periodUnit = periodUnit;
            this.local = local;
            this.comment = comment;
            this.lastEditUsername = lastEditUsername;
            this.lastEditTime = lastEditTime;
            this.limitThreshold = limitThreshold;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "firewallName=" + firewallName +
                    ", ruleId=" + ruleId +
                    ", regionPattern=" + regionPattern +
                    ", orderTypePattern=" + orderTypePattern +
                    ", deskPattern=" + deskPattern +
                    ", portfolioPattern=" + portfolioPattern +
                    ", usernamePattern=" + usernamePattern +
                    ", venuePattern=" + venuePattern +
                    ", securityTypePattern=" + securityTypePattern +
                    ", tenorPattern=" + tenorPattern +
                    ", symbolPattern=" + symbolPattern +
                    ", period=" + period +
                    ", periodUnit=" + periodUnit +
                    ", local=" + local +
                    ", comment=" + comment +
                    ", lastEditUsername=" + lastEditUsername +
                    ", lastEditTime=" + lastEditTime +
                    ", limitThreshold=" + limitThreshold +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "FirewallConfig{" +
                "header=" + header +
                ", body=" + body +
                '}';
    }

    @Override
    public Header header() {
        return header;
    }

    public void encode(final SorEncoderSupplier sorEncoderSupplier) {
        encode(sorEncoderSupplier.firewallConfigEncoder());
    }

    public <M> void encode(final SorEncoders<M> sorEncoders, final Consumer<? super M> messageConsumer) {
        encode(sorEncoders.firewallConfig().create(messageConsumer));
    }

    public void encode(final FirewallConfigEncoder encoder) {
        encoder.messageStart(header.source, header.sourceSeq)
                .firewallName().encode(body.firewallName)
                .ruleId(body.ruleId)
                .regionPattern().encode(body.regionPattern)
                .orderTypePattern().encode(body.orderTypePattern)
                .deskPattern().encode(body.deskPattern)
                .portfolioPattern().encode(body.portfolioPattern)
                .usernamePattern().encode(body.usernamePattern)
                .venuePattern().encode(body.venuePattern)
                .securityTypePattern().encode(body.securityTypePattern)
                .tenorPattern().encode(body.tenorPattern)
                .symbolPattern().encode(body.symbolPattern)
                .period(body.period)
                .periodUnit().encodeNullable(body.periodUnit)
                .local(body.local)
                .comment().encode(body.comment)
                .lastEditUsername().encode(body.lastEditUsername)
                .lastEditTime(body.lastEditTime)
                .limitThreshold(body.limitThreshold)
                .messageComplete();
    }

    public static <M> FirewallConfig decode(final M message, final SorDecoders<M> sorDecoders) {
        final PojoFirewallConfigHandler handler = new PojoFirewallConfigHandler();
        final MessageDecoder.ForwardingLookup<M> forwardingLookup = MessageDecoder.ForwardingLookup.noop();
        sorDecoders.firewallConfig().create(handler, forwardingLookup).decode(message);
        return handler.message();
    }

    public void accept(final MessageVisitor visitor) {
        visitor.onFirewallConfig(this);
    }
}
