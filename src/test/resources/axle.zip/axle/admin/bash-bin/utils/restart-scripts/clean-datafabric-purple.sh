#!/bin/bash

parallel --tag ssh -q -o BatchMode=yes {} $(printf "%q" "rm -rf ~/axle/datafabric/workspace/*; rm ~/axle/datafabric/logs/*; echo 'Cleaned datafabric workspaces'") ::: auq4000s auq4014s auq4015s auq4013s auq4009s
