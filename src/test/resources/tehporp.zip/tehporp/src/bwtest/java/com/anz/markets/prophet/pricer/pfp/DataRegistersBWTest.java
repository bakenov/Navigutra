package com.anz.markets.prophet.pricer.pfp;

import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.marketdata.filter.SnapshotGenerator;
import com.anz.markets.prophet.pricer.OptimalPositionBuilder;
import com.anz.markets.prophet.pricer.pfp.cache.ClientPriceDataRegisterDependencyManager;
import com.anz.markets.prophet.pricer.pfp.cache.DataRegisters;
import com.anz.markets.prophet.status.Context;
import org.junit.Ignore;
import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.util.function.Consumer;

import static com.anz.markets.prophet.MidRateTestHelper.createMidRate;
import static com.anz.markets.prophet.marketdata.TestConfigurationDataFactory.withDefaults;

@Ignore("failing in TC")
public class DataRegistersBWTest {

    private static final int REPS = 1_000_000;
    private static final int THRESHOLD = 5000;  // allows for logging.

    private final FilteredMarketDataSnapshot SNAPSHOT1 = new SnapshotGenerator(Market.CNX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
    private final FilteredMarketDataSnapshot SNAPSHOT2 = new SnapshotGenerator(Market.RFX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();

    public static final MidRate MIDRATE_AUDUSD = createMidRate(Instrument.AUDUSD, 0.75);

    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();

    private OptimalPositions optimalPositions;

    private final Consumer<FilteredMarketDataSnapshot> consumerForMarketData;
    private final Consumer<MidRate> consumerForMidRate;

    private final Consumer<OptimalPositions> consumerForPosition;

    private final Consumer<FilteredMarketDataSnapshot> consumerMarketDataTrigger;
    private final Consumer<MidRate> consumerMidRateTrigger;

    public DataRegistersBWTest() {
        Context.context().region(Region.GB);

        final IndexedConfigurationData config = new IndexedConfigurationData(withDefaults(new ConfigurationDataDefault()));

        optimalPositions = new OptimalPositions();
        optimalPositions.ops.add(OptimalPositionBuilder.createOptimalPositionWithNotional(Instrument.AUDUSD, 15e5));
        optimalPositions.ops.add(OptimalPositionBuilder.createOptimalPositionWithNotional(Instrument.EURUSD, 1e5));
        optimalPositions.ops.add(OptimalPositionBuilder.createOptimalPositionWithNotional(Instrument.NZDUSD, 1e5));

        DataRegisters dataRegisters = new DataRegisters();
        dataRegisters.consumerIndexedConfigurationData().accept(config);
        consumerForMidRate = dataRegisters.consumerOfMidRate();
        consumerForPosition = dataRegisters.consumerOfOptimalPositions();
        consumerForMarketData = dataRegisters.consumerOfMarketData();

        final ClientPriceDataRegisterDependencyManager clientPriceDataRegisterDependencyManager = new ClientPriceDataRegisterDependencyManager(dataRegisters);
        clientPriceDataRegisterDependencyManager.consumerIndexedConfigurationData().accept(new IndexedConfigurationData(withDefaults(new ConfigurationDataDefault())));

        consumerMarketDataTrigger = clientPriceDataRegisterDependencyManager.consumerToTriggerPriceFormationAsNecessary();
        consumerMidRateTrigger = clientPriceDataRegisterDependencyManager.consumerOfMidrateForTriggeringPriceFormation();

        warmup();
    }

    public void warmup() {
        acceptDataSnapshot();
        acceptMidRate();
        acceptPositions();
        acceptMidRateTrigger();
        acceptDataSnapshotTrigger();
    }

    @Test
    public void testAcceptPositions() {
        helper.testAllocationNotExceeded(
                this::acceptPositions,
                THRESHOLD
        );
    }

    @Test
    public void testAcceptMidRate() {
        helper.testAllocationNotExceeded(
                this::acceptMidRate,
                THRESHOLD
        );
    }

    @Test
    public void testAcceptDataSnapshot() {
        helper.testAllocationNotExceeded(
                this::acceptDataSnapshot,
                THRESHOLD
        );
    }

    @Test
    public void testAcceptDataSnapshotTrigger() {
        helper.testAllocationNotExceeded(
                this::acceptDataSnapshotTrigger,
                THRESHOLD
        );
    }

    @Test
    public void testAcceptMidRateTrigger() {
        helper.testAllocationNotExceeded(
                this::acceptMidRateTrigger,
                THRESHOLD
        );
    }

    private void acceptDataSnapshot() {
        for (int i = 0; i < REPS; i++) {
            if (i % 2 == 0) {
                consumerForMarketData.accept(SNAPSHOT1);
            } else {
                consumerForMarketData.accept(SNAPSHOT2);
            }
        }
    }

    private void acceptMidRate() {
        for (int i = 0; i < REPS; i++) {
            consumerForMidRate.accept(MIDRATE_AUDUSD);
        }
    }

    private void acceptPositions() {
        for (int i = 0; i < REPS; i++) {
            consumerForPosition.accept(optimalPositions);
        }
    }


    private void acceptMidRateTrigger() {
        for (int i = 0; i < REPS; i++) {
            consumerForMidRate.accept(MIDRATE_AUDUSD);
            consumerMidRateTrigger.accept(MIDRATE_AUDUSD);
        }
    }

    private void acceptDataSnapshotTrigger() {
        for (int i = 0; i < REPS; i++) {
            consumerForMidRate.accept(MIDRATE_AUDUSD);
            if (i % 2 == 0) {
                consumerMarketDataTrigger.accept(SNAPSHOT1);
            } else {
                consumerMarketDataTrigger.accept(SNAPSHOT2);
            }
        }
    }


}
