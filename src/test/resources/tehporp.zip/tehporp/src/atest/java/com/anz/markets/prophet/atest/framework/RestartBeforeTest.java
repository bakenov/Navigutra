package com.anz.markets.prophet.atest.framework;

import com.anz.markets.prophet.domain.OperatingHourSpecification;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * RequireRestart will restart prophet before test run. Please only use it where it is needed as it add significant
 * over head in running time of the test.
 */
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface RestartBeforeTest {
    boolean value() default true;

    String reason();

    /**
     * Default to sending OPEN for all operating hour entities.
     */
    OperatingHourSpecification.State initialOperatingHourChime() default OperatingHourSpecification.State.OPEN;
}
