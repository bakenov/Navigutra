package software.chronicle;

import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.Wires;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import static software.chronicle.generated.code.messages.ExecutionReport.newExecutionReport;

/**
 * @author Rob Austin.
 */
public class ServerMessageNotifier implements MessageNotifier, Marshallable {

    @Override
    public MessageGenerator onNewOrderSingle(NewOrderSingle newOrderSingle) {
        //  System.out.println("received - onNewOrderSingle=" + newOrderSingle);

        final ExecutionReport executionReport = newExecutionReport(Wires.acquireBytes());
        executionReport.avgPx(12.0);
        executionReport.clOrdID(Bytes.allocateDirect("CL_ORD_ID".getBytes()));
        executionReport.side('1');
        return (MessageGenerator) executionReport;
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        System.err.println(reject);
    }
}
