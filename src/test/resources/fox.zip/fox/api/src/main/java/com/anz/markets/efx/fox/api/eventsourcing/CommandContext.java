package com.anz.markets.efx.fox.api.eventsourcing;

import java.util.function.LongSupplier;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.UserRepository;
import com.anz.markets.efx.fox.api.domain.VenueInstrumentRepository;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.api.domain.UserSessionRepository;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

public interface CommandContext {
    String senderCompId();
    int source();
    TradingEncoderSupplier tradingEncoderSupplier();
    SorEncoderSupplier sorEncoderSupplier();
    MessageDecoder<SbeMessage> eventApplier();
    LongSupplier idGenerator();
    PrecisionClock precisionClock();
    UserSessionRepository userSessionRepository();
    ParentOrderRepository parentOrderRepository();
    UserRepository userRepository();
    InstrumentRepository instrumentRepository();
    VenueRepository venueRepository();
    VenueInstrumentRepository venueInstrumentRepository();
}
