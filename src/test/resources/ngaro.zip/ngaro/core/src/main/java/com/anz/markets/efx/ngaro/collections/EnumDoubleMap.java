package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.ObjDoubleConsumer;
import java.util.function.Predicate;


public class EnumDoubleMap<K extends Enum<K>> {

    private final double EMPTY = Double.NaN; // do not change this, callers rely on returning NaN for missing entries
    private final K[] keyUniverse;
    private final double[] entries;
    private int size;
    private final int capacity;
    private Class<K> keyType;

    public EnumDoubleMap(final Class<K> keyType) {
        this.keyType = keyType;
        this.keyUniverse = keyType.getEnumConstants();
        this.capacity = keyUniverse.length;
        this.entries = new double[capacity];
        for (int i = 0; i < capacity; i++) {
            this.entries[i] = EMPTY;
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public static boolean isEmpty(double value) {
        return Double.isNaN(value);
    }

    public boolean containsKey(K key) {
        return !isEmpty(entries[key.ordinal()]);
    }

    public boolean containsKey(final Object key) {
        return containsKey((K) key);
    }

    public boolean containsValue(final Object value) {
        GcFriendlyAssert.notNull(value);
        for (int i = 0; i < capacity; i++) {
            if (value.equals(this.entries[i])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Enum ordinal based order of keys in map
     * @return first enum that is in map
     */
    public K firstKey() {
        if (size > 0) {
            for (int i = 0; i < capacity; i++) {
                if (containsKey(keyUniverse[i])) {
                    return keyUniverse[i];
                }
            }
        }
        throw new IllegalArgumentException("Empty map");
    }

    /**
     * Enum ordinal based order of keys in map
     * @return last enum that is in map
     */
    public K lastKey() {
        if (size > 0) {
            for (int i = (capacity - 1); i >= 0; i--) {
                if (containsKey(keyUniverse[i])) {
                    return keyUniverse[i];
                }
            }
        }
        throw new IllegalArgumentException("Empty map");
    }

    public double get(final Object key) {
        return entries[((K) key).ordinal()];
    }

    public double getOrDefault(final K key, double defaultValue) {
        final double value = entries[key.ordinal()];
        return isEmpty(value) ? defaultValue : value;
    }

    public double put(K key, double value) {
        final double prevValue = entries[key.ordinal()];
        if (Double.isNaN(value)) {
            remove(key);
        } else {
            if (!containsKey(key)) {
                size++;
            }
            entries[key.ordinal()] = value;
        }
        return prevValue;
    }

    public boolean remove(final Object key) {
        if (containsKey(key)) {
            entries[((K) key).ordinal()] = EMPTY;
            size--;
            return true;
        }
        return false;
    }

    /**
     * Put all items in the list with given key function.
     *
     * @param values      Values in list
     * @param keyGetter   a function to retrieve key from item in the list
     * @param valueGetter a function to retrieve value from item in the list
     * @return this map
     */
    public <V> EnumDoubleMap<K> putAll(final List<V> values,
                                       final Function<V, K> keyGetter, final Function<V, Double> valueGetter) {

        for (int i = 0; i < values.size(); i++) {
            final V v = values.get(i);
            this.put(keyGetter.apply(v), valueGetter.apply(v));
        }
        return this;
    }

    public void clear() {
        for (int i = 0; i < capacity; i++) {
            entries[i] = EMPTY;
        }
        size = 0;
    }

    public void keys(Consumer<K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (!isEmpty(entries[i])) {
                    action.accept(this.keyUniverse[i]);
                }
            }
        }
    }

    public K findFirstKey(final Predicate<K> keyPredicate) {
        GcFriendlyAssert.notNull(keyPredicate);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                final K k = keyUniverse[i];
                if (!isEmpty(entries[i]) && keyPredicate.test(k)) {
                    return k;
                }
            }
        }
        return null;
    }

    public void forEach(ObjDoubleConsumer<? super K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (!isEmpty(entries[i])) {
                    action.accept(this.keyUniverse[i], entries[i]);
                }
            }
        }
    }

    public void forEachAndRemove(ObjDoubleConsumer<? super K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (!isEmpty(entries[i])) {
                    action.accept(this.keyUniverse[i], entries[i]);
                    entries[i] = EMPTY;
                }
            }
        }
    }

    public boolean removeIf(final ObjDoublePredicate<K> filter) {
        GcFriendlyAssert.notNull(filter);
        boolean rv = false;
        for (int i = 0; i < capacity; i++) {
            if (!isEmpty(entries[i])) {
                if (filter.test(this.keyUniverse[i], entries[i])) {
                    remove(this.keyUniverse[i]);
                    rv = true;
                }
            }
        }
        return rv;
    }

    public Class<K> getKeyType() {
        return keyType;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        final EnumDoubleMap<?> that = (EnumDoubleMap<?>) o;
        return size == that.size && Arrays.equals(this.entries, ((EnumDoubleMap<?>) o).entries);
    }

    // TODO: hashCode. Not urgent as these are not (currently) put into HashMaps etc.

    @NotGcFriendly
    public String toString() {
        final ToStringHelpers.CollectMapValues toStringCollector = new ToStringHelpers.CollectMapValues();
        forEach(toStringCollector);
        return toStringCollector.toString();
    }


}
