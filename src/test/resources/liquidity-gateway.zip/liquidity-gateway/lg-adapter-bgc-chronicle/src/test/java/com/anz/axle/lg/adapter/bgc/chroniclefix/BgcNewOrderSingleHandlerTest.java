package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoNewOrderSingleDecoder;
import org.junit.Before;
import org.junit.Test;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class BgcNewOrderSingleHandlerTest {

    private BgcNewOrderSingleHandler handler;
    private NewOrderSingle bgcNewOrderSingle;
    private PojoNewOrderSingleDecoder newOrderSingleDecoder;

    @Before
    public void setUp() throws Exception {
        final FixMessageSender fixMessageSender = new FixMessageSender(() -> null) {
            @Override
            public void accept(final StandardHeaderTrailer message) {
                bgcNewOrderSingle = (NewOrderSingle) message;
            }
        };
        handler = new BgcNewOrderSingleHandler(fixMessageSender);
        newOrderSingleDecoder = new PojoNewOrderSingleDecoder(() -> handler);
    }

    @Test
    public void sendNewOrderSingle() {
        // given
        final com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle newOrderSingle = new com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle();
        newOrderSingle.body.clOrdId = "12345";
        newOrderSingle.body.symbol = "NZDUSD";
        newOrderSingle.body.side = Side.BUY;
        newOrderSingle.body.transactTime = 1;
        newOrderSingle.body.orderQty = 1000000.0;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;

        // when
        newOrderSingleDecoder.decode(newOrderSingle);

        //then
        assertThat(bgcNewOrderSingle.clOrdID().toString(), is("12345"));
        assertThat(bgcNewOrderSingle.symbol(), is("NZD/USD"));
        assertThat(bgcNewOrderSingle.side(), is(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.BUY));
        assertThat(bgcNewOrderSingle.orderQty(), is(newOrderSingle.body.orderQty));
        assertThat(bgcNewOrderSingle.price(), is(1.0));
        assertThat(bgcNewOrderSingle.ordType(), is(OrdType.LIMIT));
    }
}