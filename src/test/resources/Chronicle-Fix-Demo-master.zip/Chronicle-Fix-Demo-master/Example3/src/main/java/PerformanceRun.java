import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;

import java.io.IOException;

/**
 * Created by daniel on 02/03/2016.
 * <p>
 * On dev fixEngine: Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz
 * <p>
 * Throughput 2000
 * <p>
 * Percentile   run1         run2         run3         run4      % Variation   var(log)
 * 50:            16.90        16.90        16.90        16.90         0.00       12.59
 * 90:            18.94        18.94        18.94        18.94         0.00       12.89
 * 99:            26.11        30.21        23.04        23.04        17.18       13.62
 * 99.9:          35.84        39.94        33.79        37.89        10.81       14.75
 * 99.99:        540.67       671.74       401.41      1540.10        65.41       24.76
 * worst:        638.98      1081.34       606.21      2064.38        61.59       26.50
 * <p>
 * Throughput 10,000
 * <p>
 * Percentile   run1         run2         run3      % Variation   var(log)
 * 50:            16.90        16.90        16.13         3.08        7.62
 * 90:            18.94        18.94        18.94         0.00        7.86
 * 99:            26.11        22.02        20.99         3.15        7.87
 * 99.9:          88.06        33.79        83.97        49.75        9.10
 * 99.99:        999.42       167.94       802.82        71.59       12.21
 * worst:       1146.88       249.86       966.66        65.67       12.94
 * <p>
 * Throughput 50,000
 * <p>
 * Percentile   run1         run2         run3      % Variation   var(log)
 * 50:            15.62        15.10        15.62         2.21        7.51
 * 90:            17.92        16.90        16.90         0.00        7.62
 * 99:            22.02        30.21        29.18         2.29        8.91
 * 99.9:         120.83       352.26        33.79        86.27       11.04
 * 99.99:        335.87       802.82        96.26        83.03       12.70
 * worst:        450.56       901.12       151.55        76.73       13.21
 */
public class PerformanceRun extends software.chronicle.fix.PerformanceRun {

    /**
     * PerformanceRun was moved from default package, but we left this here so as not to break customer scripts
     */
    public static void main(String[] args) throws IOException {
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
        software.chronicle.fix.PerformanceRun.main(args);
    }
}
