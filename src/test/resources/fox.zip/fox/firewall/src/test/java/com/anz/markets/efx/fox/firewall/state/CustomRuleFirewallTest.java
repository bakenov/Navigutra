package com.anz.markets.efx.fox.firewall.state;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.OrderConsumer;
import com.anz.markets.efx.fox.firewall.rule.StaleOrderRule;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Tests for class CustomRuleFirewall
 */
@ExtendWith(MockitoExtension.class)
public class CustomRuleFirewallTest {

    private static final String NAME = "NAME";
    private static final long TIMEOUT = 1000;

    @Mock
    private NewOrderSingleDecoder newOrderSingle;
    @Mock
    private NewOrderSingleDecoder.Body body;
    @Mock
    private OrderConsumer.ErrorHandler errorHandler;
    @Mock
    private PrecisionClock clock;
    @Mock
    private CommandContext commandContext;

    private CustomRuleFirewall firewall;
    private StaleOrderRule rule;

    private long currentTime;
    private long transactionTime;

    @BeforeEach
    void setUp() {
        transactionTime = System.nanoTime();
        rule = new StaleOrderRule(TIMEOUT);
        newOrderSingle = mock(NewOrderSingleDecoder.class);
        body = mock(NewOrderSingleDecoder.Body.class);
        errorHandler = mock(OrderConsumer.ErrorHandler.class);
        clock = mock(PrecisionClock.class);
        commandContext = mock(CommandContext.class);
        when(newOrderSingle.body()).thenReturn(body);
        when(body.transactTime()).thenReturn(transactionTime);
        when(commandContext.precisionClock()).thenReturn(clock);

        firewall = new CustomRuleFirewall(NAME, errorHandler, rule);
    }

    @Test
    void validate_should_succeed() {
        currentTime = transactionTime + 100;
        when(clock.nanos()).thenReturn(currentTime);
        assertThat(firewall.accept(newOrderSingle, commandContext)).isTrue();
    }

    @Test
    void validate_should_not_succeed() {
        currentTime = transactionTime + TimeUnit.NANOSECONDS.convert(TIMEOUT, TimeUnit.MILLISECONDS) + 100;
        when(clock.nanos()).thenReturn(currentTime);
        doAnswer((i) -> {
            assertThat(((StaleOrderRule)i.getArgument(2)).description().contains("Stale Order Firewall")).isTrue();
            return null;
        }).when(errorHandler).accept(any(), any(), any());
        assertThat(firewall.accept(newOrderSingle, commandContext)).isFalse();
    }

}
