package com.anz.axle.adapters.wssdeal;

import com.anz.axle.util.ManifestPrinter;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class WssDealAdapter{
    private static final Logger LOG = Logger.getLogger(WssDealAdapter.class);

    private final ClassPathXmlApplicationContext context;

    public WssDealAdapter(ClassPathXmlApplicationContext context) {
        this.context = context;
    }

    public static void main(String[] args) {
        String contextFile = args.length == 0 ? "wssdeal-adapter-context.xml" : args[0];

        LOG.info("=================================================");
        LOG.info("Welcome to the WssDeal Adapter");
        LOG.info("=================================================");
        ManifestPrinter manifestPrinter = new ManifestPrinter("META-INF/MANIFEST.MF");
        manifestPrinter.log();
        LOG.info("=================================================");

        LOG.info("Initializing Spring context...");
        ClassPathXmlApplicationContext startingContext = null;
        try {
            startingContext = new ClassPathXmlApplicationContext(contextFile);
            Runtime.getRuntime().addShutdownHook(new ShutDownHook(startingContext));
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Exception caught during initialization.",e);
            System.exit(-1);
        }
    }

    static class ShutDownHook extends Thread{
        private ClassPathXmlApplicationContext startingContext;

        public ShutDownHook(ClassPathXmlApplicationContext startingContext){
            this.startingContext = startingContext;
        }

        public void run(){
            System.out.println("Starting shutdown sequence...");
            startingContext.close();
            System.out.println("Shutdown done.");
        }
    }
}
