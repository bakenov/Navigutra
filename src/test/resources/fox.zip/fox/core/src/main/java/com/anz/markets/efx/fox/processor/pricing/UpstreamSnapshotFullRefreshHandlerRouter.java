package com.anz.markets.efx.fox.processor.pricing;

import java.util.Objects;
import java.util.function.Consumer;

import com.anz.markets.efx.ngaro.codec.Hops;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.pricing.client.api.SnapshotterDecoderLookup;
import com.anz.markets.efx.pricing.client.api.SnapshotterDecoderSupplier;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKeyLookup;

public final class UpstreamSnapshotFullRefreshHandlerRouter implements SnapshotFullRefreshHandler {

    private final SnapshotterDecoderLookup snapshotterDecoderLookup;
    private final RequestKeyLookup requestKeyLookup;

    private SnapshotFullRefreshHandler delegate;
    private MessageForwarder messageForwarder;
    private Consumer<StringBuilder> messageLogger;

    private int source;
    private long sourceSeq;

    public UpstreamSnapshotFullRefreshHandlerRouter(final SnapshotterDecoderLookup snapshotterDecoderLookup,
                                                    final RequestKeyLookup requestKeyLookup) {
        this.snapshotterDecoderLookup = Objects.requireNonNull(snapshotterDecoderLookup);
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
    }

    @Override
    public void onMessageStart(final int source, final long sourceSeq) {
        delegate = null;
        this.source = source;
        this.sourceSeq = sourceSeq;
    }

    @Override
    public void messageForwarder(final MessageForwarder messageForwarder) {
        this.messageForwarder = messageForwarder;
    }

    @Override
    public void messageLogger(final Consumer<StringBuilder> messageLogger) {
        this.messageLogger = messageLogger;
    }

    @Override
    public void onBody(final Body body) {
        final RequestKey requestKey = requestKeyLookup.lookup(body.marketId(), body.instrumentId());
        final SnapshotterDecoderSupplier supplier = snapshotterDecoderLookup.lookup(requestKey);

        delegate = supplier.upstreamDecoderConnector().snapshotFullRefresh();
        delegate.onMessageStart(source, sourceSeq);
        delegate.messageForwarder(messageForwarder);
        delegate.messageLogger(messageLogger);
        delegate.onBody(body);
    }

    @Override
    public void onMdEntriesStart(final int mdEntriesCount) {
        delegate.onMdEntriesStart(mdEntriesCount);
    }

    @Override
    public void onMdEntries_Body(final MdEntries.Body entry, final int mdEntriesIndex, final int mdEntriesCount) {
        delegate.onMdEntries_Body(entry, mdEntriesIndex, mdEntriesCount);
    }

    @Override
    public void onMdEntriesComplete(final int entryCount) {
        delegate.onMdEntriesComplete(entryCount);
    }

    @Override
    public void onHopsStart(final int hopsCount) {
        delegate.onHopsStart(hopsCount);
    }

    @Override
    public void onHops_Body(final Hops.Handler.Body hop, final int hopsIndex, final int hopsCount) {
        delegate.onHops_Body(hop, hopsIndex, hopsCount);
    }

    @Override
    public void onHopsComplete(final int hopsCount) {
        delegate.onHopsComplete(hopsCount);
    }

    @Override
    public void onMessageComplete() {
        delegate.onMessageComplete();
        delegate = null;
        this.source = 0;
        this.sourceSeq = 0;
    }
}