package com.anz.markets.efx.fox.config;

public enum MessagingProvider {
    UM, AERON
}
